Reading the required references now.
**Should you apply? Yes: on the core requirements this role reads as written for your background.** Status: `conditional_go`. The one condition you can't settle yourself is checking that the posting is real and still open. My web searches were blocked in this session, so I couldn't confirm it.

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7a · unclear: R6 (Define and maintain the metrics layer), R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience (HIPAA))

R1, R2, R3, R4, R5: each matched by a specific achievement you described; R6, R7b, R8: open questions, not confirmed gaps; R9: a real bridge with a clear limit.

**Opportunity ledger.** The mandate is clear and coherent (RR5). I couldn't confirm the employer or that the posting is live (RR1). Pay and location aren't stated (RR2, RR4). Two things are open: whether the two juniors report to you (RR3), and how experiments that touch care get signed off (RR6).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) The employer and a live posting check out (RR1). (2) Pay, location and working pattern meet your own floor (RR2, RR4). (3) R9 is presented honestly as related experience (GDPR/CCPA), never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, about 400 people, Series C | `[grounded]` JD header, not checked independently (RR1) |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, partnership with PMs and clinicians | `[grounded]` JD |
| Team | Mentor two junior analysts | `[grounded]` JD |
| Tooling | Looker named; warehouse not named | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | A full analytics-lead remit (definitions, experimentation, BI, mentoring) under a Senior IC title | `[inferred]` from the responsibilities list against the title |
| Market calibration | Not produced: the role-family search was refused | none |
| Unknowns | Pay; location and working pattern; whether the juniors report to this role; who governs experiments on care features | none |
| Contradictions | None found; only one source to compare | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics. This is what you told me, with nothing to inspect yet, so `medium` is the first-pass ceiling | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse, plus building a 40+ dashboard Looker instance. "Expert" is self-rated on both sides, so expect a live SQL exercise | `[grounded]` your background; `[generic]` that this title usually gets a SQL screen | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year on a base of about 2M subscribers, including the pricing test behind an 11% retention lift | `[grounded]` your background | Have one test readout ready to walk through end to end |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. This is the closest match to the JD's named tool | `[grounded]` your background | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. A redacted memo would be the inspectable proof | `[grounded]` your background | Offer: a redacted memo raises this to `high` |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" is a real lead. You haven't said whether you defined the metric definitions and the semantic or LookML model yourself, so I won't assume it | `[grounded]` the word "governed" in your background; `[inferred]` that it may involve a modelled metrics layer | See G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | A pricing test behind a retention lift is analysis that became a decision. You haven't said who owned the decision, so say "my test informed" unless you owned it | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing about clinical or care-side partners yet. The closest current evidence is your exec and VP-level stakeholders, who are a different audience | `[grounded]` silence in your background | See G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring or managing anyone. Building a program and a Looker instance makes it plausible, but plausible is not evidence | `[grounded]` silence in your background | See G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You built the warehouse consent-state model and handled GDPR/CCPA consumer PII. That is real privacy-governance work. The limit is that HIPAA's rules for protected health information (minimum-necessary access, business associate agreements, de-identification standards) are a separate regime you haven't worked under | `[grounded]` your background; `[generic]` that HIPAA differs from GDPR/CCPA in these respects | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed dashboards, but no word on who defined the metric definitions or the model behind them | It's the first responsibility the JD lists; owning it would make R6 a direct match | Writing LookML explores and measures; settling a contested definition such as "active subscriber" or "churn"; a metrics glossary or dbt metrics others relied on | A redacted LookML excerpt, a metric-definitions doc, a governance page | `[grounded]` your background is silent on this; `[inferred]` that resolving it moves R6 |
| G2 | Clinician partnership (R7b, important) | discovery | No care-side or expert-domain partners mentioned | The JD names clinicians as partners alongside PMs | Working with nutritionists, food-safety or ops experts on what a metric should mean; any subject-matter partner whose judgment overrode the data | A memo or readout written for a domain-expert audience | `[grounded]` silence in your background |
| G3 | Mentoring (R8, important) | discovery | No people development mentioned | The JD names a fixed mentoring load of two | Onboarding analysts onto your Looker instance; reviewing others' test designs or SQL; a junior you brought up to running tests | A review-feedback example, a training doc, an onboarding guide | `[grounded]` silence in your background |
| G4 | HIPAA (R9, preferred) | transferability | Consent-state model and GDPR/CCPA PII handling | A preferred requirement where an honest bridge could set you apart | Access controls, purpose limitation, deletion or suppression workflows you built | A redacted design doc for the consent-state model | `[grounded]` your background; `[generic]` where the regimes differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have much of a footprint, the posting may be stale or copied from another site, or it may not be a real employer that is hiring | `[generic]` pattern for companies of this size, not a claim about this one; my searches were refused, so nothing was checked | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | Not stated anywhere in the posting | The figure may or may not match a senior title with a mentoring load | `[inferred]` from the posting's silence | What salary range and equity are budgeted for this role? | unresolved |
| RR3 | Mentoring two juniors under an individual-contributor title | unknown | — | "mentor two junior analysts" | The role may carry management load without the manager title or pay | `[inferred]` from the JD's wording against its title | Do the two junior analysts report to this role, and does it own their reviews? | unresolved |
| RR4 | Location and working pattern not stated | unknown | — | Not stated anywhere in the posting | It could be office-based, hybrid or remote | `[grounded]` the posting's silence | Is this role remote, hybrid or office-based, and where? | unresolved |
| RR5 | Clear, coherent mandate | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The scope is specific: named tool, named partners, named team size | `[grounded]` JD | What would a successful first year in this role look like? | noted |
| RR6 | Experimentation on a care product: how it's governed | unknown | — | "design and analyze A/B tests" in a "care-navigation app" | Tests on care-related flows may need clinical or compliance sign-off, which slows test speed compared with consumer subscription | `[generic]` pattern for regulated health products, not a claim about this one | Which experiments need clinical or compliance sign-off, and how long does that usually take? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program in your own words: "designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Write "behind", not "drove", unless you owned the pricing decision | See R3, R7a | `[grounded]` your background | pending your approval |
| E2 | Second line: "built the company's Looker instance from scratch — 40+ governed dashboards." Add "metrics layer" only if G1 confirms you defined it | See R4, R6 | `[grounded]` your background | pending your approval |
| E3 | Present the consent-state model as GDPR/CCPA privacy governance that carries over to HIPAA work. Never write "HIPAA experience" | See R9 | `[grounded]` your background | pending your approval |
| A1 | Confirm the posting is live on the company's own site before you spend effort on an application | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions for RR1, RR2, RR3, RR4, RR5 and RR6 word for word in the screen | The register doubles as interview prep | `[grounded]` register | pending your approval |
| W1 | Prepare one redacted metrics memo as a work sample | See R5 | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent the search "Harborlight Health care navigation app careers" and it was refused. It would have confirmed the employer and the live posting, and could have closed RR1 |
| 2. Role-family sweep | unavailable | I sent the search "senior product analyst digital health salary range 2026" and it was refused. It would have produced the market-calibration row and a pay band to set against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no search to run |

## Dossier and upgrades

If you want to keep this assessment for later steps, I can save it as a `tuesday-dossier.md`.

**What would make this assessment stronger:**
- **Allow web search:** I'd check the employer and posting, which could clear RR1 and lift the cap from `conditional_go`. I'd also get a market pay band for RR2.
- **Your pay floor, location and working-pattern requirements:** these would become checkable hard-gate rows instead of unknowns.
- **One inspectable artifact:** for example a redacted metrics memo, a LookML excerpt, an experiment readout or the consent-state design doc. Any of these would raise the matching row (R5, R6, R3 or R9) to `high`.
- **The hiring manager's name:** I'd know which story to lead with for that reader.
- **A deeper research pass:** funding, leadership churn and employee reports, for up to 5 more searches and 2 more fetches. Just say so and I'll run it.

**Questions:**

1. What are your non-negotiables on pay, location and working pattern (remote, hybrid or office)?
2. **G1:** On the Looker build, did you personally define the metric definitions and the model behind the dashboards, for example LookML measures or a metrics glossary others relied on, or did you build dashboards on definitions someone else owned?
3. **G3:** Have you mentored or reviewed the work of other analysts, such as onboarding people onto your Looker instance or reviewing their test designs or SQL? Who, and for how long?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.