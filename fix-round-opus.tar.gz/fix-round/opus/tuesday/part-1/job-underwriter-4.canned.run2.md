Lots of references. Read them in parallel.
Research is done. Here's the full assessment.

## Decision snapshot

**Yes, go for it, once one thing is settled: the posting says "fully remote" but the careers page says Leeds four days a week (R1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R8 · unclear: R5b (monitor rating models), R7 (recommendations for product)
- `important`: adjacent: R10 (pet-insurance product)
- `preferred`: direct: R9

R1: the working pattern decides whether this is worth your time; R5b, R7: open questions about your work, not missing skills; R10: a bridge whose limit you state yourself.

**Opportunity ledger.** The employer and the posting check out as real and live (RR4). The two sources disagree on the working pattern (RR1), the salary isn't stated (RR2), and the team size isn't stated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor confirms which working pattern is current, and it works for you (R1, RR1); (2) you describe the pet-insurance gap as adjacent experience, never as experience you have (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics for pet insurance: build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page; JD names her |
| Line management | None stated. Your having never managed anyone doesn't count against any requirement here | `[grounded]` JD lists no reports |
| Scope read | Rating-model monitoring is likely to weigh heavily with this hiring manager. Her public talk was "Small Books, Loud Errors", on monitoring rating models in small books, and before this she spent six years as head of pricing analytics at Calloway Re | `[grounded]` search-result snippet of her profile; `[inferred]` that it shapes what she'll probe |
| Market calibration | UK senior pricing analyst at insurers and insurtechs (n=612): median base £58,400, interquartile range £52,100 to £64,900. The posting gives no salary, so this is a range to expect, not Brindlemoor's offer (RR2). The sweep didn't establish norms for scope | `[generic]` Pricewell 2026 survey, search snippet only; `[grounded]` JD, for the missing salary |
| Unknowns | Salary; size of the pricing team; how big the pet book is | — |
| Contradictions | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` JD vs. fetched careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Working pattern: "Fully remote (UK)" (careers page: Leeds four days a week) | hard_gate | unclear | none | hard_gate | The employer's two sources disagree, and you haven't said where you're based or how many office days you'd accept, so nothing settles this yet | `[grounded]` JD vs. careers page; no candidate constraint given | Closing question R1; RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific self-report; nothing inspectable yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily"; no artifact | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | Upgrade menu: model documentation |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built a rating model | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" might include monitoring, but you didn't say so. Where a reading is ambiguous I take the weaker one | `[grounded]` wording of your background | Closing question G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. "Ran" doesn't say whose design it was, so expect a probe on that | `[grounded]` your background | none |
| R7 | Turn results into recommendations for product | must_have | unclear | low | discovery | Your stated audience is underwriting; you didn't mention product teams | `[grounded]` your background is silent on product | Closing question G2 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance product knowledge (implied by the product) | important | adjacent | medium | transferability | Pricing a UK general-insurance book with GLMs and price tests carries over. You've never priced pet risk | `[inferred]` requirement, from the JD naming the product; `[grounded]` "never worked on pet insurance" | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | You built and maintained the model; what maintaining it involved is unstated | It's a must-have, and it's the hiring manager's public topic | Actual-vs-expected tracking by segment; drift or stability checks on rating factors; deciding when to refit; spotting an error after go-live | A sanitized monitoring dashboard screenshot or a model-validation pack | `[grounded]` wording of your background; `[inferred]` that monitoring weighs heavily, from her talk |
| G2 | Recommendations for product (R7, must_have) | discovery | Recommendations to underwriting are clear; product isn't mentioned | It's a must-have; closing it brings every must-have row with evidence to `direct` | A test result that changed a product feature, cover option or excess; joint work with a product or digital team; input to a pricing-proposition launch | A price-test readout deck or recommendation note | `[grounded]` your background is silent on product |
| G3 | Pet-insurance product (R10, important) | transferability | GI pricing method carries over; pet risk is new | The bridge is credible, and its limit is the obvious thing to be asked about | GLM build on a new book; any work on a small or thin-data segment like young drivers | A one-page note on how you'd approach a first pet rating review | `[inferred]` bridge, from your motor GLM work; `[generic]` that a domain switch draws this question |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The working pattern differs between the JD and the careers page (R1) | risk_signal | medium | "Fully remote (UK)" vs. "Leeds office four days a week" | One of the two versions is out of date, or the policy changed after the posting went out | `[grounded]` both sources; `[inferred]` the cause | Is this role fully remote, or Leeds four days a week? Which one is current? | unresolved |
| RR2 | Salary not stated | unknown | — | Neither source gives a figure | The figure may sit anywhere relative to the £52.1k–£64.9k range in role reality | `[inferred]` from the missing figure, against the `[generic]` range | What salary is budgeted for this role? | unresolved |
| RR3 | Team size unstated beside "own pricing analytics" | unknown | — | "Own pricing analytics for our pet-insurance product" | You could be the only pricing analyst on the book | `[inferred]` from "own" against the JD's silence on the team | Who else works on pet pricing, and what support does this role have? | unresolved |
| RR4 | Employer and posting verify | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | The role is real and live, and the reporting line matches the hiring manager you named | `[grounded]` careers page fetched; search-result snippet of her profile | What does success in the first six months look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the working pattern with the recruiter before you spend time on the application | R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with "built and maintained the GLM rating model for our young-driver book" and "ran 14 price tests last year with the underwriting team", kept in your own wording. Don't write "designed" unless you designed them | R4, R6; the hiring manager's talk was on rating-model monitoring | `[grounded]` your background and her talk snippet | pending your approval |
| P2 | Describe pet as new to you: "five years pricing a UK motor book with GLMs; new to pet" | R10 | `[grounded]` your own words | pending your approval |
| Q1 | Ask the verification questions from RR1 to RR4 word for word in the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance" (no results) and "Brindlemoor insurtech careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved: the contradictions row, R1, RR1 and RR4 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary remote GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. Moved: market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. Moved: the scope read, G1 and P1 |

I can write this up as a `tuesday-dossier.md` to carry into later steps, if that's useful.

**Upgrade menu**
- Where you're based and how many office days you'd accept: settles R1, which decides between go and no-go.
- The budgeted salary: closes RR2 and compares it with the market range.
- Inspectable pricing artifacts, sanitized (model documentation or a validation pack, a monitoring dashboard screenshot, a price-test readout deck): would raise R4, R5a, R6 and R5b from `medium` toward `high`.
- A deeper research pass on Brindlemoor (funding, leadership turnover, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1 — Would Leeds four days a week work for you, or is fully remote a must?

G1 — When you maintained the young-driver GLM, did that include monitoring, such as actual-vs-expected tracking, drift checks or deciding when to refit? What exactly was yours?

G2 — Did any of your price-test results lead to recommendations to a product team, not just underwriting? What changed as a result?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.