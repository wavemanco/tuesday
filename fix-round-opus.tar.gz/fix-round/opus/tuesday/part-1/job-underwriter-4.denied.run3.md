Now the files Step 1 names.
**Yes, apply. On what you've given me you meet every listed requirement, and three things need confirming first (listed below). Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6, R7, R8a · adjacent: R9 (Own pricing analytics for the product) · unclear: R8b (Recommendations to product)
- `preferred`: direct: R10 · adjacent: R11 (Pet-insurance domain knowledge)

R9: you've owned one book's pricing model, not yet a whole product's pricing; R8b: nothing you gave shows a product-team audience; R11: motor pricing carries over to pet, with clear limits.

**Opportunity ledger.** Four entries are open and none is alarming. I couldn't confirm the employer because my searches were refused (RR1). The salary isn't stated (RR2). Team size behind "own" is unknown (RR3), and so is who signs off rate changes between underwriting and product (RR4). One entry is in the role's favour: a specific, coherent posting (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: you're UK-based and can work in the UK without sponsorship; (2) RR1: the posting checks out on Brindlemoor's own careers page; (3) RR2: the salary clears your floor; (4) R9 and R11 are framed honestly as adjacent: book-level ownership and motor domain, never pet expertise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not checked against the company's own site (RR1) |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager Odile Varga, Director of Pricing | `[grounded]` your message |
| Line management | None stated. The JD asks for no people management | `[grounded]` JD's requirements list |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | One product, one analyst "owning" its pricing analytics with two internal audiences. That reads as a senior individual-contributor role, possibly a small or one-person pricing function | `[inferred]` from "own" plus the absence of any team or management language |
| Market calibration | Not available, because the role-family sweep didn't run (Evidence status, row 2) | — |
| Unknowns | Salary; pricing team size; who decides rate changes; whether the product is new or established | — |
| Contradictions | None between the JD and your background. The live posting wasn't checked | `[grounded]` inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK): UK-based, able to work in the UK | hard_gate | unclear | low | hard_gate | You work at a UK motor insurer, which suggests you're UK-based. You haven't said where you live or whether you need sponsorship | `[inferred]` from your current UK employer | G1's question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior. That clears "4+" on your own figures; nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". Specific, but self-reported; expect a technical probe | `[grounded]` your background; `[generic]` pricing hires usually include a technical exercise | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | You built and maintained one rating model. "Maintained" is your word; "monitor" is the JD's. Expect a probe on how you tracked model performance | `[grounded]` your background | none |
| R7 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with the underwriting team. "Ran" is your word, and how much of each test's design was yours isn't stated, so expect a probe | `[grounded]` your background | none |
| R8a | Turn results into recommendations for underwriting | must_have | direct | medium | none | Price tests run with underwriting, plus the quarterly review to its head | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | must_have | unclear | low | discovery | Your background names underwriting as your audience. A product team doesn't appear | `[grounded]` silence in your background | G2's question |
| R9 | Own pricing analytics for the product, end to end | must_have | adjacent | medium | transferability | You've owned one book's model (young drivers). Owning a whole product's pricing analytics is wider | `[grounded]` your background; `[inferred]` the JD's "own" means the whole product | G3's question |
| R10 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R11 | Pet-insurance domain knowledge | preferred | adjacent | medium | transferability | The JD asks only for "insurance experience a plus", not pet. Personal-lines pricing methods carry over. Pet-specific risk drivers (vet-cost inflation, breed and age) and policy types (such as lifetime cover) weren't part of your motor work | `[inferred]` requirement derived from "our pet-insurance product"; `[generic]` what motor and pet pricing share and don't | See G4; frame as adjacent |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Fully remote (UK) (R1, hard_gate) | hard_gate | A UK employer, but no stated location or right to work | It's the only gate. If it's met, the condition goes away | — | — | `[inferred]` from your current employer |
| G2 | Recommendations to product (R8b, must_have) | discovery | Underwriting is your only named audience | Half of the role's output goes to product. Evidence here would make R8b direct | Feeding price-test results into a quote-journey or cover change; working with a product or digital team on a launch or price change; a recommendation that changed product terms, not just rates | A sanitized recommendation paper or deck, or a change note | `[grounded]` silence in your background; `[inferred]` that it moves R8b |
| G3 | Own pricing analytics end to end (R9, must_have) | transferability | Owner of the young-driver GLM | The JD's "own" suggests the whole product. Wider ownership would close the gap | Being the main pricing contact for a whole channel or product; owning monitoring, rate-change sign-off or the review pack across books; covering the full pricing cycle from data to rate change | A model governance document or a review pack you authored | `[grounded]` your background; `[inferred]` JD scope |
| G4 | Pet-insurance domain (R11, preferred) | transferability | Motor only | It's preferred, so it won't block you. Interviewers may test whether you know what's different about pet | Carries over: GLM rating, price testing, presenting to underwriting. Doesn't: vet-cost inflation, breed and age risk, lifetime-cover dynamics. Strengthener: a short self-study of pet rating factors, presented as learning, not experience | — | `[generic]` how motor and pet pricing differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be small or new with a thin footprint, or the posting may be stale or aggregated. It wasn't checked because my searches were refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Brindlemoor's own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no salary in the JD) | The budget may sit below what a senior title usually pays, or the company may just not publish salaries | `[generic]` postings without a salary vary either way | What salary range is budgeted for this role? | unresolved |
| RR3 | "Own" with no team mentioned | unknown | — | "Own pricing analytics for our pet-insurance product" | This may be a one-person pricing function, where you'd carry the whole product alone | `[inferred]` from "own" and the JD's silence on team size | How many people work in pricing today, and who would I work with day to day? | unresolved |
| RR4 | Two audiences, decision rights unstated | unknown | — | "recommendations for underwriting and product" | Rate changes may need agreement from both sides, which slows decisions | `[inferred]` from the two named audiences | Who signs off a rate change: underwriting, product, or pricing? | unresolved |
| RR5 | Specific, coherent posting | positive_signal | — | "build and monitor rating models, design and read price tests" | The work is clearly defined and requirements match responsibilities; no bundled roles | `[grounded]` JD | How do you measure whether a price test succeeded? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Open with the GLM and the price tests, in your words: "built and maintained the GLM rating model for our young-driver book" and "ran 14 price tests last year with the underwriting team". Don't say "designed" or "owned pricing" unless G2 or G3 confirms it | see R4, R6, R7 | `[grounded]` your background | pending your approval |
| P2 | On pet, say "motor pricing, ready to learn pet's risk drivers". Never imply pet experience | see R11 | `[grounded]` your background; `[generic]` what differs | pending your approval |
| P3 | Before investing time, check the role is on Brindlemoor's own careers page and ask the recruiter about salary | see RR1, RR2 | `[grounded]` register | pending your approval |
| P4 | Ask the verification questions for RR1 to RR5 word for word in interviews | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; the call was refused (search permission not granted). It would have confirmed the company and the live posting, and cleared RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote 2026"; the call was refused. It would have given the market-calibration line and a salary range for RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have shown which story to lead with for this reader (P1) |

If you'd like, I can save this as a `tuesday-dossier.md` file that you can keep and reuse in later steps.

## Upgrade menu

- **Search permission:** reruns targets 1 to 3. That clears or confirms RR1, gives a salary range for RR2, and shows how to angle P1 for this reader.
- **Your salary floor and any other must-haves (location, hours):** checked against the role's terms in the hard-gates line.
- **A sanitized price-test read-out, a GLM model write-up, or a past quarterly review pack:** R5, R6 and R7 move up from `medium` to `high`.
- **Answers to G2 and G3:** R8b and R9 could become direct.
- **A deeper research pass on Brindlemoor** (funding, leadership changes, hiring patterns, employee reviews, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1: Are you based in the UK, and can you work here without visa sponsorship?

G2: Have you ever made a recommendation to a product or digital team rather than underwriting, such as a cover change, a quote-journey change or a launch? What was yours, and what happened?

G3: Beyond the young-driver GLM, which parts of the pricing cycle did you own yourself, across which books?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.