Need to read many references. Let me read them in parallel.
Short answer: no, you're not wasting your time. But the "3+ years product management" requirement is a real obstacle, and better wording on your resume won't get you past it. My recommendation is to apply with conditions, through a person rather than a cold application.

## Decision snapshot

**Not a waste of time, but R1b, the titled-PM-years must-have, is absent and will be your main obstacle. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (product-management-equivalent work), R2 (shipped API or platform products) · unclear: R4b (stakeholder management with sales), R5 (agile delivery) · absent: R1b (3+ years titled PM experience)
- `important`: direct: R7 · adjacent: R6 (run discovery with integration partners), R10 (coordinate launches with sales and support) · unclear: R8 (own the roadmap), R9 (define and track adoption metrics)

R1b: you confirmed it's absent, and wording can't close it. R1a and R2: the bridge that has to carry R1b. R8 and R9: where the unconfirmed triage-tool lead could land.

**Opportunity ledger.** The mandate has real resources behind it: two named engineering squads (RR4). The employer couldn't be verified because my searches were refused (RR1). Pay and location are both unstated (RR2, RR3).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting checks out as live and from Quartzline (RR1); (2) you get in through a referral or the hiring manager, not a cold application (R1b, A2); (3) R1a and R2 are framed honestly as adjacent, never as product-management experience; (4) pay and location clear whatever your limits are (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, ~150 people, Series B | `[grounded]` JD header; not verified independently (RR1) |
| Mandate | Own the roadmap for a partner-facing API platform; partner discovery; specs; delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated. Probably: a roadmap set, adoption metrics defined and reported, at least one launch coordinated | `[inferred]` from the responsibilities list; no outcomes are stated |
| Scope read | A single-platform PM role with dedicated engineering, not a role combining several jobs | `[inferred]` from "two engineering squads" against one named product area |
| Unknowns | Pay; location and work model; who the role reports to; who has the final say on the roadmap | `[grounded]` the JD doesn't mention them |
| Contradictions | None inside the JD; none checked against a careers page (couldn't search) | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Product-management-equivalent work (requirements, gathering roadmap input, coordinating across teams) | must_have | adjacent | medium | transferability | You state requirements documents, quarterly roadmap-input sessions, and coordinating PMs and engineers on custom builds. That's specific and plausible but not yet probed. Limit: it was done as input to someone else's product decisions | `[grounded]` your resume as pasted | G2 |
| R1b | 3+ years with the PM title | must_have | absent | none | capability | You confirmed you've never held a PM title. Not a gate (it's a length-of-experience requirement), but no rewording closes it. `[generic]` Postings that mark years as a must-have are often screened literally at the first pass | `[grounded]` your statement; `[generic]` screening pattern | G1, a closure path rather than a question |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your company's REST APIs, end to end through go-live. That shipped integrations, not the API product itself. Whether any custom build became a product feature isn't stated | `[grounded]` your resume as pasted | G2 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs, integration architecture. Specific, but nothing inspectable yet; expect a live probe | `[grounded]` your resume as pasted | Offer an inspectable artifact (see upgrade menu) |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | You coordinated your engineers, the client's engineers, and PMs; you ran scoping workshops and UAT | `[grounded]` your resume as pasted | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Your resume doesn't mention sales. The role's setting suggests contact, but that isn't evidence of it | `[grounded]` resume says nothing on sales | G4 |
| R5 | Agile delivery experience | must_have | unclear | low | discovery | UAT and go-live show delivery work, but no method is named | `[grounded]` resume says nothing on method | G4 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and roadmap-input sessions with clients: the right audience, but in service of a client build or someone else's roadmap, not deciding what the platform builds | `[grounded]` your resume as pasted | G2 |
| R7 | Write specs | important | direct | medium | none | Requirements documents and an integration playbook the whole team uses. Specific; no copy inspected | `[grounded]` your resume as pasted | Upgrade menu: a redacted requirements doc |
| R8 | Own the roadmap | important | unclear | low | discovery | Your resume shows input to a roadmap, not ownership of one. An unconfirmed memory note suggests you built an internal triage tool; if true, that could be ownership on a small scale | `[grounded]` resume; memory note only, unconfirmed | G3 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Your resume states no metrics. The memory note mentions adoption by support agents; unconfirmed, and nothing about measurement | `[grounded]` resume says nothing; memory note only | G3 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-lives coordinated across teams. Limit: a client go-live isn't a market launch with sales and support enablement | `[grounded]` your resume as pasted | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | 3+ years titled PM (R1b, must_have) | capability | No PM title, confirmed | `[generic]` The likeliest point where a cold application gets filtered out | Not closable by rewording. Ways through: a referral or hiring-manager route; an internal transfer to PM at your current employer; a role whose posting doesn't make PM years a must-have | n/a | `[grounded]` your statement; `[generic]` filtering pattern |
| G2 | Product ownership inside integration work (R1a, R2, R6) | transferability | Scoping, requirements, roadmap input, coordinating custom builds | Decides whether the bridge reads as "has done product work without the title" or "implementation only" | A custom build that became a feature for all customers; a prioritization call you made or pushed through; client feedback from your sessions that changed what shipped | A requirements doc, a playbook excerpt, release notes naming the feature | `[grounded]` resume; `[generic]` that interviews probe this line |
| G3 | Roadmap ownership and adoption metrics (R8, R9) | discovery | Only an unconfirmed memory note about a triage tool | If confirmed, it's the one example of building something, having users, and seeing it adopted | The triage tool: who decided what it did, how many agents used it, whether you measured usage | Screenshots, a usage count, an announcement message | `[grounded]` resume says nothing; memory note only |
| G4 | Sales, agile, launches (R4b, R5, R10) | discovery | Nothing stated | Lower priority; strengthens the case but won't change the decision | Pre-sales scoping calls; sprint ceremonies with your engineers; enabling support teams at go-live | n/a | `[grounded]` resume says nothing |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified from sources I could check (searches refused) | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be fine and I simply couldn't check; or the posting may be stale or aggregated | `[generic]` pattern, not a claim about this company | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no pay terms in the JD) | The figure may sit below what the title implies, or they just don't publish pay | `[inferred]` from the missing figure | What's the budgeted pay range for this role? | unresolved |
| RR3 | Location and work model not stated | unknown | — | (no location in the JD) | Could be onsite, hybrid or remote | `[grounded]` JD doesn't say | Where is the role based, and how many office days are expected? | unresolved |
| RR4 | Dedicated engineering resources named | positive_signal | — | "drive delivery with two engineering squads" | The role has engineers to deliver with, not just influence | `[grounded]` JD | Do both squads work only on the API platform, or are they shared? | noted |
| RR5 | Who has the final say on the roadmap is unstated | unknown | — | "Own the roadmap" | Priorities may effectively be set by sales commitments | `[generic]` pattern at B2B companies of this stage | Who has final say when a sales commitment and the roadmap conflict? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Quartzline's own site, or that the recruiter uses a Quartzline email address | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Find a referral or reach the hiring manager directly, not only a cold application | see R1b, G1 | `[generic]` titled-years filtering pattern | pending your approval |
| E1 | Lead your resume with "Led 30+ client integrations of our REST APIs end to end", followed by the requirements docs and roadmap-input sessions. Don't retitle any role as product management | see R1a, R2, R3 | `[grounded]` your own resume wording | pending your approval |
| W1 | If Quartzline's API docs are public, a one-page integration-partner teardown: friction points and a proposed spec change | Gives R3 and R7 something inspectable | `[inferred]` assumes public docs exist (unverified) | pending your approval |
| Q1 | Ask the verification questions for RR1 to RR5 word for word in your first call | The risk register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a note from a previous conversation that you built an internal request-triage tool support agents adopted. It's unconfirmed and used here only as the basis for G3.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform Series B" and "Quartzline careers product manager platform APIs"; both were refused (web search permission not granted). Would have cleared or confirmed RR1 and the contradictions row in Role reality |
| 2. Role-family sweep | unavailable | Searched "platform API product manager salary Series B startup 2026"; refused. Would have added a market-calibration line and a pay range to set against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

---

If it's useful, I can save this as a `tuesday-dossier.md` for later steps.

**What would sharpen this:**
- Web search permission: checks the employer (RR1) and adds a pay range and market calibration.
- A redacted requirements doc or playbook excerpt: raises R3, R7 and R1a toward `high`.
- Your pay floor, location and work-authorization constraints: turns the hard-gates line into actual checks.
- The hiring manager's name: lets me check their public profile and decide which of your stories to lead with.
- A deeper research pass on Quartzline (funding, leadership changes, hiring patterns, news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions:**

G3: A note from a previous conversation says you built an internal request-triage tool that support agents adopted. Is that right? If so, who decided what it did, how many people used it, and did you track usage?

G2: Did any custom build you coordinated become a feature for every customer? What, if anything, did you decide about its scope?

RR2/RR3: Do you have a pay floor, a location or work-model limit, or a work-authorization constraint this role would have to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.