Lots of reference files. Let me read the required ones.
**Yes, it's worth applying, as long as you're based in the US and the pay range clears your floor. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5, R7, R8
- `important`: adjacent: R6 (dbt-modelled warehouse in BigQuery) · unclear: R9 (ingestion from our app and CRM), R10 (data contracts our analysts depend on)

R6: a Snowflake-to-BigQuery bridge, with its limit named; R9, R10: stated responsibilities your background doesn't cover yet; R2, R3, R4, R5, R7, R8 (`medium`): self-reported, nothing inspected yet.

**Opportunity ledger.** The posted pay sits above the market median and its top end is above the report's upper quartile (RR1). The posting is live and matches what you pasted (RR2). Three things are unknown: who you'd report to (RR3), whether you'd build the warehouse from scratch or inherit one (RR4), and the equity terms (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work remotely from the US or from Denver (R1); (2) your pay floor is at or below $166,000 (RR1); (3) you present BigQuery as a warehouse you haven't used yet, not as one you know (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states. Founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` your paste of the about page (I didn't fetch it) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse, and data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow "or similar" | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity (equity not specified) | `[grounded]` JD |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One domain (reporting), from ingestion through to analyst-facing contracts. No direct reports mentioned | `[inferred]` from the JD's responsibilities and its silence on people management |
| Market calibration | The Datawright 2026 report puts Senior DE base pay at Series B–D companies at a $151,000 median, with an IQR of $139,000–$163,500. It defines Senior as 5–8 years and typical scope as one domain's pipelines with no reports. This posting matches that title and scope. Its floor is $9,000 above the IQR's low end and its top is $2,500 above the high end. This is a market band, not this employer's offer (RR1) | `[generic]` the pay report your recruiter sent (US, n=2,310); `[grounded]` JD, for the posted range |
| Unknowns | Reporting line and hiring manager; whether the dbt/BigQuery warehouse already exists; team size; equity terms; what "data contracts" means here | — |
| Contradictions | None between your pasted JD and the live posting | `[grounded]` live posting fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | The location is a term of the job, and you haven't said where you're based or whether you're authorized to work in the US | `[grounded]` JD states the term; your background is silent on it | Closing question R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company. Specific, but self-reported with no artifact | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily". Self-reported, and "strong" will be tested in interviews rather than read off a resume | `[grounded]` your background; `[generic]` that this role family tests SQL and Python live | none |
| R4 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. Specific and self-reported, with no repo or docs inspected | `[grounded]` your background | Upgrade menu: dbt docs or a lineage screenshot |
| R5 | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse", not a particular one, and Snowflake is one | `[grounded]` JD wording and your background | none |
| R6 | dbt-modelled warehouse in BigQuery (the named stack) | important | adjacent | medium | transferability | This is inferred from the responsibilities, not the requirements list. You've never used BigQuery. Your dbt modelling and warehouse work carries over. The limit: you haven't touched BigQuery-specific pricing, partitioning, clustering or IAM | `[inferred]` requirement drawn from the JD's responsibilities; `[generic]` that those are the BigQuery-specific differences from Snowflake | Gap queue G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated plainly. Self-reported | `[grounded]` your background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Specific and self-reported | `[grounded]` your background | Upgrade menu: a sanitized suite excerpt |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | A stated responsibility. Your background doesn't say what sources you've ingested from or who built the ingestion | `[grounded]` your background is silent on it | Gap queue G2 |
| R10 | The data contracts our analysts depend on | important | unclear | low | discovery | A stated responsibility. Your background doesn't mention contracts, schema agreements or analyst-facing interfaces. The Great Expectations work is nearby but isn't the same thing | `[grounded]` your background is silent on it; `[inferred]` that the test suite is near contract work | Closing question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | About 180 dbt models on Snowflake; no BigQuery | It's the platform you'd run from day one, so it's the most predictable objection | dbt adapter or cross-warehouse work; warehouse cost or performance tuning on Snowflake (clustering, warehouse sizing), which maps onto BigQuery partitioning and slot cost; any GCP use at all | A small personal dbt project run against BigQuery's sandbox | `[grounded]` your background; `[generic]` that the warehouse is the likeliest objection and that a hands-on port narrows it |
| G2 | App and CRM ingestion (R9, important) | discovery | Nothing about sources or ingestion tooling | It's half of the stated mandate | Ingesting a product database or event stream; pulling from a CRM or HRIS API (payroll companies usually run one); running Fivetran or Airbyte connectors, or custom Python extractors in Airflow | A DAG excerpt or an architecture diagram | `[grounded]` your background is silent on it; `[generic]` that payroll companies typically ingest from a CRM or HRIS |
| G3 | Data contracts (R10, important) | discovery | Great Expectations suite; no mention of contracts | It's the analyst-facing part of the role and the one you're least clearly matched on | Agreeing schemas with upstream engineers; dbt model contracts or versioned models; exposures; Great Expectations checks that block bad loads before analysts see them; SLAs on mart freshness | A contract YAML, a schema-change runbook, or a Great Expectations checkpoint config | `[grounded]` your background; `[inferred]` that the test suite is the nearest existing evidence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay is at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is above the report's median ($151,000) and its top is above the IQR's high end ($163,500), so the pay isn't lowballing the seniority | `[grounded]` JD; `[generic]` pay report band | Where in the range do candidates with 6 years usually land, and what is the equity grant? | noted |
| RR2 | Employer and posting check out | positive_signal | — | "Accepting applications" | The posting is live on the company's own careers site and matches what you pasted | `[grounded]` live posting fetched | — | noted |
| RR3 | No hiring manager named | unknown | — | (posting names no one) | Reporting line, team size and who sets priorities aren't stated | `[inferred]` from the posting's silence | Who does this role report to, and how big is the data team? | unresolved |
| RR4 | "Build and run": greenfield or existing? | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role could be building the warehouse from scratch or taking over an existing dbt/BigQuery setup. That changes the scope and the first 90 days | `[inferred]` from the JD's wording | Does a dbt project on BigQuery already exist, and what state is it in? | unresolved |
| RR5 | Equity terms unspecified | unknown | — | "plus equity" | The grant size, instrument and vesting aren't stated | `[grounded]` JD's wording | What's the equity grant for this level, and on what vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own facts: "built our dbt project on Snowflake, about 180 models" and "set up our Great Expectations test suite". Keep "about" and keep "set up". Don't upgrade either to "owned the platform" | R4, R8 | `[grounded]` your background | pending your approval |
| P2 | Name BigQuery plainly as the one platform you haven't used. Don't use "cloud-warehouse agnostic" to blur it | R6 | `[grounded]` your background | pending your approval |
| W1 | Optional: a weekend port of a few dbt models to the BigQuery sandbox, so you can speak to it from hands-on use | R6, G1 | `[generic]` that a hands-on sample narrows a platform objection | pending your approval |
| Q1 | Ask the RR1, RR3, RR4 and RR5 questions in the recruiter screen | The register doubles as screen prep | `[grounded]` register | pending your approval |
| A1 | Anchor your pay ask within the posted range, not on the report's median, which sits below the range's midpoint | RR1 | `[grounded]` JD and pay report | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer careers" and fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It shows "Accepting applications", with text identical to your paste. Moved role reality's contradictions row and RR2 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already gives the band, the seniority definition and the scope, which fix the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there's nothing to search for |

I can also save all of this as a `tuesday-dossier.md` file that stays with you across the search, if you'd like.

## Upgrade menu

- **Your resume:** it replaces the background you typed, so I can check how R2–R10 actually read on the page.
- **Proof of your work:** your dbt docs site, a lineage graph screenshot, or a sanitized Great Expectations suite excerpt would raise R4 and R8 to `high`.
- **Your location and work authorization:** closes R1.
- **Your pay floor:** settles condition 2 against RR1.
- **Answers to G1–G3:** R6's bridge gets firmer, and R9 and R10 resolve.
- **The hiring manager's name:** sharpens the scope read and tells me which story P1 should lead with.
- **A deeper research pass on Pellucid Learning:** leadership churn since the Series C, hiring patterns, employee reports and recent news, using up to 5 more searches and 2 more fetches. Say the word and it runs.

## Questions

R1: Are you based in the US, or in Denver, and authorized to work here without sponsorship?

Constraints: What's the lowest base salary you'd accept?

G3: Have you set up schema agreements, dbt model contracts, or checks that stop bad data before analysts see it? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.