Now the files named for Step 1.
# Job underwriting: Senior Pricing Analyst at Brindlemoor

## Decision snapshot

**Yes, go for it, once the conditions below are met. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R7
- `important`: direct: R8a · adjacent: R9 (Pet-insurance product) · unclear: R8b (Recommendations to product)
- `preferred`: direct: R6

R9: the motor-to-pet bridge to argue, with its limits stated; R8b: a product audience your background doesn't show yet; R2, R3, R4, R5, R7: direct, but your own account so far, so expect them to be probed.

**Opportunity ledger.** I couldn't verify the employer because my web searches were refused (RR1). The salary isn't stated (RR2) and the team's scope is unstated (RR3). On the plus side, the mandate is clear and names its audiences and a hiring manager (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the posting check out as real and live (RR1); (2) you confirm the UK-remote terms work for you (R1); (3) the salary clears your floor (RR2); (4) the pet-insurance side is presented honestly as adjacent, not as pet experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech | `[grounded]` JD header; not checked independently (RR1) |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Line management | The JD doesn't mention any. "Senior" here reads as owning the work, not managing people, so never having managed anyone isn't a gap against this posting | `[grounded]` JD's silence; `[inferred]` reading of "Own pricing analytics" without reports named |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | One product line, a full pricing cycle (model, test, recommend) and two stakeholder groups. That's a normal remit for a senior individual contributor | `[inferred]` from the JD's responsibilities list |
| First-year outcomes | Not stated | `[grounded]` JD's silence |
| Unknowns | Salary; team size and whether there's a separate actuarial function; who signs off price changes; whether the employer is verified | — |
| Contradictions | None in the JD as pasted | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You didn't say where you're based or whether you have UK right to work. A current job at a UK insurer is indirect context, not confirmation | `[grounded]` your message's silence on location and eligibility | Closing question R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst, is above the bar. You told me this but nothing has been inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated. Expect a technical exercise or probe | `[grounded]` your background; `[generic]` that pricing loops often include a technical test | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. That's building and maintaining, the JD's own verbs | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. "Ran" doesn't say which design choices were yours (cells, sample sizes, success metrics), so be ready to say exactly what you owned | `[grounded]` your background; `[generic]` that interviewers probe design ownership on test work | Prepare a precise account of your part in test design |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | Tests run with underwriting, plus the quarterly review to its head | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | important | unclear | low | discovery | Your background names underwriting audiences only. Product may never have come up | `[grounded]` your background is silent on product | See G2 |
| R9 | Pricing a pet-insurance product | important | adjacent | medium | transferability | The GLM method, price-test practice and underwriting partnership carry over. The limit: pet rating factors (species, breed, age at entry, cover type such as lifetime versus time-limited) and vet-cost claims behaviour are all new to you | `[grounded]` your stated motor work and no pet experience; `[generic]` the typical pet rating factors | See G1 |
| R6 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R9, important) | transferability | Motor GLM and pricing tests; you've said you've never worked on pet | The bridge is credible. Its weak point is domain intuition: knowing which factors drive pet claims costs | Any non-motor or health-like book you touched; modelling claims inflation or ageing effects in young-driver work; rating-factor reviews where you challenged a factor's shape | A sanitized factor-review note, a test write-up, or a short "how I'd structure a pet GLM" page | `[grounded]` your stated background; `[generic]` that domain intuition is the likeliest objection |
| G2 | Recommendations to product (R8b, important) | discovery | Only underwriting audiences are stated | The JD names product as a second audience | Proposals on cover options, excess levels, discounts or channel pricing; working with marketing or distribution on what a test meant for the proposition | A deck or memo where a recommendation went to a non-underwriting team | `[grounded]` your background is silent on product |
| G3 | UK remote terms (R1, hard_gate) | hard_gate | Location and right to work aren't stated | It's a gate: wording can't fix it, only the facts settle it | — | — | `[grounded]` JD term, your silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have much of a footprint, the posting may be stale or copied from elsewhere, or there may be no real employer behind it. The checks were refused, so nothing points either way yet | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no salary in the JD) | It may sit below what a 5-year senior expects, or they may just not publish salaries | `[inferred]` from the missing figure | What salary range is budgeted for this role? | unresolved |
| RR3 | Team and sign-off scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" could mean a team of one with no actuarial or data support, or it could sit inside a larger pricing function | `[inferred]` from the ownership language against no team being described | Who else works in pricing, and who signs off a rate change? | unresolved |
| RR4 | Clear mandate and named audiences | positive_signal | — | "turn the results into recommendations for underwriting and product" | The scope is defined, and the role reports to a named Director of Pricing | `[grounded]` JD and your message | What would a strong first year in this role look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with your own wording: "built and maintained the GLM rating model for our young-driver book" and "ran 14 price tests last year with the underwriting team". Keep "with" and don't upgrade it to "led" | see R4, R7 | `[grounded]` your background | pending your approval |
| E2 | Name the quarterly pricing review to the head of underwriting as the recommendation evidence | see R5, R8a | `[grounded]` your background | pending your approval |
| A1 | Check that Brindlemoor's careers page lists the role before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask about salary at the first recruiter contact | see RR2 | `[grounded]` RR2 | pending your approval |
| W1 | Optional one-page note: how you'd adapt your GLM and test approach to a pet book, with what you'd need to learn stated plainly | narrows R9's limit | `[grounded]` R9; `[generic]` that a short work sample answers a domain objection | pending your approval |
| Q1 | Ask the RR1–RR4 verification questions word for word during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance". The call was refused (no web permission). It would have confirmed the company exists and the posting is live, and would have resolved RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote GLM". The call was refused. It would have given a market calibration line for role reality and a salary band to set against RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing". The call was refused. It would have informed the scope read and which story to lead with for this reader |

---

If you like, I can save all of this as a `tuesday-dossier.md` to carry into later steps.

**Upgrade menu**
- Allow web search and I'll rerun targets 1–3. That can clear RR1, add a salary band for RR2, and sharpen the scope read.
- Deeper research on Brindlemoor (funding, leadership changes, hiring patterns, employee reports, recent news) costs up to 5 more searches and 2 more fetches. Say the word and it runs.
- A sanitized test write-up or factor-review deck would raise R7 and R4 to `high`.
- Your salary floor would let me set RR2 against something concrete.

**Questions**

R1: Are you UK-based with the right to work in the UK, and is there a salary floor or any other non-negotiable this role would need to meet?

G1: Have you worked on anything beyond motor (a home, health or other non-motor line, a claims-inflation model, a rating-factor review) that you'd point to when asked about pet?

G2: Has any of your pricing work led to a recommendation for a product, proposition or marketing team rather than underwriting? What was it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.