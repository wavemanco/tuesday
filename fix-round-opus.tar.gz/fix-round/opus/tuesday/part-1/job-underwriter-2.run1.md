Now the files Step 1 names.
## Decision snapshot

**No, you're not wasting your time. But R1b (3+ years titled PM experience) is a must-have you don't meet, and no rewording fixes it. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (Product-management-equivalent work), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery experience) · absent: R1b (3+ years titled product management experience)
- `important`: direct: R7 · adjacent: R6 (Discovery with integration partners), R9 (Coordinate launches with sales and support), R10 (Own the roadmap) · unclear: R8 (Define and track adoption metrics)

R1b is a real miss that wording can't close; R1a and R2 are credible bridges with stated limits; R5 and R8 are open questions that answers could move.

**Opportunity ledger.** I couldn't verify the employer, because the web searches were refused (RR1). Compensation, location and reporting line aren't stated (RR2, RR3, RR5). On the positive side, the mandate is concrete: two named squads and named responsibilities (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the posting verify as live and as described (RR1). (2) Your application presents R1a and R2 as adjacent work and never as titled PM experience or shipped API products, accepting R1b as a named risk. (3) Pay and location turn out acceptable to you once stated (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline: B2B logistics tech, about 150 people, Series B | `[grounded]` JD header; not independently verified (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated. Likely includes an adoption-metrics baseline, since defining the metrics is listed as a duty rather than inherited | `[inferred]` from "define and track adoption metrics" |
| Scope read | One PM across two squads on one platform surface. That's an ordinary single-PM remit, not a head-of-product role | `[inferred]` from squad count and the single-platform mandate |
| Market calibration | Not established: the role-family sweep couldn't run (Evidence status, row 2) | — |
| Unknowns | Pay; location and remote policy; who this PM reports to; whether the API platform exists already or is being built | — |
| Contradictions | None between the JD and your background as described. The careers page wasn't checked | `[grounded]` JD and your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Product-management-equivalent work: requirements, prioritization input, coordinating engineering | must_have | adjacent | medium | transferability | Specific self-report: requirements documents, roadmap-input sessions, coordinating your engineers, the client's engineers and PMs on custom builds. Limit: you fed product decisions rather than making them; product owned prioritization. Medium is the intake ceiling for unprobed claims, so expect a probe | `[grounded]` your message | See G4 |
| R1b | 3+ years titled product management experience | must_have | absent | none | capability | You stated it yourself: "I have never held a PM title." No discovery question can change a fact you've already confirmed. `[generic]` A years-of-experience requirement marked must-have is often screened literally at the first filter | `[grounded]` your own statement; `[generic]` screening pattern | Carry as material risk; closure paths in G5 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ end-to-end integrations of your employer's REST APIs. Limit: you sat on the delivery and integration side of someone else's API product. You didn't decide what the API exposed, version it, or own its adoption. That is a different side of the same work, not the same work | `[grounded]` your message | See G4 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs and integration architecture are stated in role-relevant terms. Expect a hands-on probe | `[grounded]` your message | none |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and product managers, and ran client scoping workshops through go-live | `[grounded]` your message | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Your message doesn't mention sales. `[generic]` Solutions-engineering roles often sit next to sales, but that's a pattern about the role, not a claim about you | `[grounded]` silence in your message; `[generic]` role pattern | See G3 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | Your message doesn't say how the builds ran. Working alongside engineering teams on custom builds is indirect context only | `[grounded]` silence in your message | Closing question G1 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly roadmap-input sessions are partner-facing elicitation. Limit: scoping one client's build is not deciding what to build for many partners | `[grounded]` your message | See G4 |
| R7 | Write specs and drive delivery with engineering | important | direct | medium | none | Requirements documents and integration architecture, carried through UAT and go-live, plus the playbook the whole team uses | `[grounded]` your message | none |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | No metrics in your message. Agent memory suggests an internal request-triage tool that support agents adopted. That's a `memory_lead`: unconfirmed, and only a basis for a question | `[grounded]` silence in your message; memory lead unconfirmed | Closing question G2 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | 30+ go-lives are coordinated launches for one client each. Limit: a platform launch goes to many partners and needs sales and support enablement, which your message doesn't mention | `[grounded]` your message | See G3 |
| R10 | Own the roadmap for the API platform | important | adjacent | medium | transferability | You ran quarterly roadmap-input sessions. Limit: input to a roadmap, not ownership of one | `[grounded]` your message | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Agile delivery (R5, must_have) | discovery | Builds coordinated with engineers; delivery method unstated | A must-have; an answer moves R5 to direct or adjacent | Sitting in sprint planning or backlog grooming for custom builds; writing tickets or acceptance criteria; running UAT against sprint increments | A Jira epic or user-story set, sanitized | `[grounded]` silence on method |
| G2 | Adoption metrics (R8, important) | discovery | Nothing confirmed; the triage-tool memory lead is unverified | If real, it's a tool you built that others adopted, which is the closest thing in your history to a product you owned | Tracking how many support agents used the triage tool; integration time-to-go-live trends across clients; API call volume after go-live | A dashboard screenshot, usage numbers, a rollout note | `[grounded]` silence in your message; lead unconfirmed |
| G3 | Sales and support coordination (R4b, R9) | discovery | Your message doesn't mention either function | R4b is a must-have; R9 is the launch half of the role | Pre-sales scoping calls; support handoff at go-live; training support on integration issues | A handoff doc or runbook | `[grounded]` silence in your message |
| G4 | Product decision-making vs. input (R1a, R2, R6, R10) | transferability | Strong delivery-side evidence; product owned the decisions | `[generic]` The "were you the decider?" line is what this kind of interview probes on career-switcher candidates | Bridge: you saw 30+ partners hit the same API friction, which is raw discovery material. Limit: you didn't prioritize the fix. Strengthener: a work sample (plan P4) | The integration playbook, sanitized; roadmap-input session notes | `[grounded]` your message; `[generic]` interview pattern |
| G5 | Titled PM years (R1b, must_have) | capability | Zero, as you stated | Wording can't close this. Only routing and the reader's discretion can | Closure paths: an internal move to a PM or technical-PM title at your current vendor; target postings for "technical PM, integrations" or "PM, developer platform" with lower year bars; a referral to the Quartzline hiring manager | — | `[grounded]` your statement; `[generic]` closure paths |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be real and small, or the posting may be stale, aggregated or not tied to a live hire. I couldn't check because search was refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Quartzline's careers page, and who would I be interviewing with? | unresolved |
| RR2 | Compensation unstated | unknown | — | Posting gives no figure | The budget may sit anywhere in or below the role-family band. Without the sweep, there's no band to compare against | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and work arrangement unstated | unknown | — | Posting gives no location | Could be remote, hybrid or office-based | `[inferred]` from the posting's silence | Where is this role based, and what's the in-office expectation? | unresolved |
| RR4 | Concrete mandate: two named squads and named duties | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | Resources are named and success is meant to be measured | `[grounded]` JD | Are the two squads dedicated to the API platform or shared? | noted |
| RR5 | "Own the roadmap" with no stated reporting line | unknown | — | "Own the roadmap for our partner-facing API platform" | Ownership could be real, or the roadmap could be set by a CPO or CTO and handed down | `[inferred]` from ownership language against silence on reporting | Who does this PM report to, and which roadmap calls are theirs alone? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own words: "led 30+ client integrations of our REST APIs end to end," "wrote the internal integration playbook the whole team uses," "ran quarterly roadmap-input sessions" | See R1a, R2, R7 | `[grounded]` your message | pending your approval |
| P2 | Never describe yourself as having "owned the roadmap," "shipped API products," "run product discovery," or held a PM title. These are the JD's words, and they don't match your history as stated | See R1b, R2, R10 | `[grounded]` your message vs. JD | pending your approval |
| P3 | Get in front of a human (a referral or the hiring manager) rather than only the application portal | `[generic]` Titled-years must-haves are often screened literally before a person reads the bridge case | `[generic]` hiring pattern | pending your approval |
| P4 | Work sample: a one-page spec for a partner-API improvement, drawn from integration friction you've actually seen, with no invented client facts | See G4, R1a, R2 | `[generic]` that a work sample narrows a titled-experience gap | pending your approval |
| P5 | Verify the posting is live before investing effort | See RR1 | `[grounded]` RR1 | pending your approval |
| P6 | Ask RR1, RR2, RR3, RR4 and RR5's verification questions verbatim with the recruiter or in the interview loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: an internal request-triage tool adopted by support agents (agent memory, unconfirmed). Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform Series B"; refused by the host's permission check. Would have confirmed the organization row and contradictions row, and cleared or confirmed RR1 |
| 2. Role-family sweep | unavailable | Searched "solutions engineer to product manager API platform transition career path"; refused by the host's permission check. Would have given the market calibration row and a band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Whenever you want it, I can write this up as a `tuesday-dossier.md` file you can keep.

**Upgrade menu**
- **Allow web search** (the host refused both calls): L1 reruns and can clear RR1 and fill the market calibration row.
- **The live posting link or Quartzline's careers page:** RR1 closes and the decision's first condition clears.
- **Your constraints** (pay floor, location, start date): the hard-gates line gets real checks instead of "unknown."
- **The integration playbook, sanitized:** R7 and R1a move toward `high`.
- **A hiring manager's name:** the role's scope gets a read and P1 can lead with the right story for that reader.
- **A deeper pass on Quartzline** (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G2: Did you build an internal request-triage tool that support agents adopted? If so, what part was yours, how many agents used it, and did you track usage?

G1: How did the custom builds run? Did you write tickets, sit in sprint planning, or work to a backlog?

Constraints: What are your non-negotiables on pay, location or remote work, and start date?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.