Running a quick check on the employer and market pay, then the full assessment follows.
Yes, you should apply. You're a strong fit. The JD names no hard requirement you fail to meet. My checks on the employer and market pay didn't run because web search was denied, so verify those two things yourself before you put in serious effort.

## Decision snapshot

**Yes, apply — R1, R2, R3, R4, R5, every `must_have` row, land `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R7b (Partner with clinicians) · unclear: R6 (Define and maintain the metrics layer), R7a (Partner with PMs to turn analysis into roadmap decisions), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience (HIPAA))

R6, R7a, R8 — untested so far, and the first closing questions go to R8 and R6; R7b, R9 — honest bridges with their limits named, not blockers.

**Opportunity ledger.** I couldn't confirm that the employer exists as described, because the research calls were refused (RR1). Pay and work location aren't stated (RR2, RR3). How freely you can run experiments on a clinical-facing app is unknown (RR5). One entry is good news: the team, the reporting setup and the BI tool are all spelled out (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and a live posting check out (RR1); (2) the pay and work arrangement meet your terms (RR2, RR3); (3) R9 is framed as GDPR/CCPA PII work, never as healthcare or HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not checked independently (RR1) |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, Looker dashboards, partnering with PMs and clinicians, mentoring two juniors | `[grounded]` JD |
| Scope read | A senior individual contributor who leads informally (two juniors to mentor, no direct reports stated) and owns the whole analytics stack | `[inferred]` from "mentor two junior analysts" and "own product analytics", against no mention of people management |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established: the role-family search was refused, and I don't use memory as a source for pay bands | — |
| Unknowns | Pay; location and remote policy; reporting line; experimentation volume and limits on clinical flows | `[grounded]` JD silent on each |
| Contradictions | None in the JD; not compared with a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years of product analytics at a ~2M-subscriber company. Stated and specific, nothing inspectable yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" gets tested live, so expect a probe | `[grounded]` your background; `[generic]` that senior analyst loops usually include a live SQL exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Specific, but nothing inspectable | `[grounded]` your background | Offer a sanitized test readout: it would raise this row to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards. An exact tool match | `[grounded]` your background | A redacted dashboard screenshot would raise this row to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads and presents to the VP Product monthly | `[grounded]` your background | A redacted memo would raise this row to `high` |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" suggests governed metric definitions, but you haven't said you owned the metric definitions or the semantic model. Low, because that would be a practice I'm inferring rather than something you stated | `[inferred]` from "governed dashboards"; `[grounded]` that your background doesn't say it outright | see G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | unclear | low | discovery | Presenting to the VP Product is reporting. Whether analysis you led changed a roadmap call isn't stated (the pricing test may count) | `[grounded]` your background | see G2 |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | What carries over: writing for non-technical execs (R5). The limit: you haven't worked with clinicians, who bring clinical-safety and evidence-standard concerns | `[grounded]` your background; `[generic]` that clinical partners weigh patient-safety risk in product decisions | see G4 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background says nothing about mentoring or leading other analysts | `[grounded]` your background is silent | see G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | What carries over: handling GDPR/CCPA consumer PII and building the warehouse's consent-state model. The limit: no PHI or HIPAA work | `[grounded]` your background; `[generic]` that HIPAA adds PHI-specific rules (de-identification, business associate agreements, minimum-necessary access) that GDPR/CCPA work doesn't exercise | see G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | A governed Looker build, but no stated ownership of metric definitions | A named responsibility. Owning the definitions turns R6 `direct` | Writing LookML views and explores; owning the definition of "active subscriber" or churn; running a metric review or deprecation process; reconciling conflicting team definitions | A redacted LookML file, a metric dictionary, a definitions doc | `[grounded]` your background is silent; `[inferred]` that this moves R6 |
| G2 | PM partnership on roadmap (R7a, important) | discovery | Monthly VP Product presentations; no analysis-to-decision example stated | The JD's stated purpose for the role | The pricing test leading to a pricing change; an analysis that killed or reprioritized a feature; sitting in quarterly planning | A decision memo, a test readout with the decision recorded | `[grounded]` your background |
| G3 | Mentoring (R8, important) | discovery | Nothing stated | The only row with `none` confidence | Onboarding new analysts; reviewing others' SQL or test designs; running office hours; training PMs on Looker | A training doc, an onboarding guide, a peer review | `[grounded]` your background is silent |
| G4 | Clinician partnership (R7b, important) | transferability | Exec-facing writing; no clinician context | A named stakeholder group | Partnering with an ops, food-safety or nutrition team on decisions with safety stakes | A doc written for a specialist, non-analyst audience | `[inferred]` the bridge from R5 |
| G5 | HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | Preferred tier only; a strong talking point if framed honestly | Access controls you set up; data deletion or minimization requests; PII masking in Looker | A redacted consent-model diagram | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be real and simply unverified this run, the posting may be stale, or the posting may not come from a real hiring employer | `[generic]` pattern for unverified postings, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (JD silent) | The figure may sit below what a senior role pays, or the company may just not publish pay | `[inferred]` from the posting's silence | What base salary and equity range is budgeted for this role? | unresolved |
| RR3 | Work location and arrangement not stated | unknown | — | (JD silent) | The role could be remote, hybrid or on-site | `[grounded]` JD silent | Is this role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Team, tooling and mentoring scope stated | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The scope and resources are concrete | `[grounded]` JD | How do the two junior analysts split their time today? | noted |
| RR5 | Limits on experimentation for a care product unknown | unknown | — | "design and analyze A/B tests" | Tests on clinical-facing flows may need extra review, which would slow test volume compared with consumer subscription | `[generic]` regulated health products often gate experiments on clinical flows | Which parts of the app can be A/B tested, and what review do clinical-facing tests go through? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the Looker build in your own words: "Built the company's Looker instance from scratch — 40+ governed dashboards" | see R4, R6 | `[grounded]` your background | pending your approval |
| P2 | Use the pricing test as written: "the pricing test behind an 11% retention lift". Don't upgrade it to "drove" or "owned" unless that's true | see R3, R7a | `[grounded]` your background | pending your approval |
| P3 | Frame privacy experience as "handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse". Never as healthcare or HIPAA experience | see R9 | `[grounded]` your background | pending your approval |
| P4 | Confirm pay, location and that the employer is real with the recruiter before the loop | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| P5 | Ask the verification questions for RR1, RR2, RR3, RR4 and RR5 word for word in interviews | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Harborlight Health care navigation app Series C" was refused. It would have confirmed the company and the live posting, and cleared or confirmed RR1 |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary 2026" was refused. It would have filled the market calibration row and the pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name given |

## Next steps

I can write all of this up as `tuesday-dossier.md` if you want a copy to keep.

**What would sharpen this:**
- **Allow web search:** clears or confirms RR1 and adds a market pay band.
- **Your pay floor, location needs and work authorization:** these become hard-gate rows and settle RR2 and RR3.
- **Inspectable artifacts:** a sanitized test readout, a redacted dashboard screenshot or LookML file, or a redacted metrics memo would raise R3, R4, R6 and R5 to `high`.
- **The hiring manager's name:** a sharper scope read and a better choice of which story to lead with.
- **A deeper research pass on Harborlight:** funding and leadership churn, employee reports and recent news, up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions:**

G3 — Have you mentored, onboarded or reviewed the work of other analysts? What did you do, and for how many people?

G1 — In the Looker build, did you define and own the metric definitions, such as the LookML model or a metric dictionary, or did someone else set them?

Constraints — What are your pay floor and location requirements, and do you need visa sponsorship?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.