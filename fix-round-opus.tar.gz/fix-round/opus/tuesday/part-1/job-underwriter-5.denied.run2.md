Now the references named at Step 1.
## Decision snapshot

**Yes, it looks worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or the Denver office)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R7 (BigQuery as the warehouse) · unclear: R8 (Ingestion from the app and CRM), R9 (Data contracts analysts depend on)

R7: the Snowflake-to-BigQuery bridge is credible, and its limit is stated below; R8, R9: your background doesn't mention either yet, and one answer each could settle them.

**Opportunity ledger.** The pay is stated and sits at or above the market report (RR2), and the company says it raised money recently (RR5). On the other side, I couldn't check that the employer and the posting are live (RR1). The reporting line is unnamed (RR3), and the scope may be the whole reporting stack rather than one domain (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or the Denver office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work remotely from the US or from Denver (R1); (2) the posting is confirmed live on Pellucid's own careers page (RR1); (3) $148k–$166k meets your floor, which you haven't told me yet; (4) BigQuery is presented as new to you, never as experience you have (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016 in Denver; 264 employees; Series C of $52M in February 2026 | `[grounded]` about-page text you pasted (not checked live, RR1) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow "or similar", SQL and Python | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | "Build and run" across ingestion, the warehouse and contracts reads as end-to-end ownership of the reporting stack, which may be broader than one domain | `[inferred]` from the JD's three named areas set against the report's "ownership of one domain's pipelines" |
| Market calibration | The posting's "5+ years" matches the report's "Senior typically means 5–8 years", and Series C falls inside its B–D bracket. Its $148k–$166k range starts above the report's 25th percentile ($139k), brackets the median ($151k), has a $157k midpoint, and tops out above the 75th percentile ($163.5k) (RR2) | `[generic]` Datawright 2026 report you pasted (US, n=2,310; not checked live); `[grounded]` JD for the posted figures |
| Unknowns | Who the role reports to; how big the data team is; on-call expectations behind "run"; equity terms | `[grounded]` JD is silent on each |
| Contradictions | None between the JD and the about-page text as pasted. I couldn't check either against the live site | `[grounded]` pasted texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | Your background says nothing about where you are based or what locations you can work from, so the gate isn't settled | `[grounded]` JD terms; background silent | Closing question R1 |
| R2 | 5+ years of data engineering | must_have | direct | medium | none | "6 years of data engineering at a B2B payroll company" exceeds the bar. It is self-report from intake, so it stays at `medium` | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily". Specific but not yet inspected; expect a technical screen to probe it | `[grounded]` your background; `[generic]` that this role family tests both live | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models". Snowflake is a cloud warehouse, so the requirement as written is met | `[grounded]` your background | Optional: a sanitized model-lineage screenshot or project README would raise it to `high` |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration": the exact tool named | `[grounded]` your background | none |
| R6 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite" is direct, and you set it up yourself | `[grounded]` your background | Optional: a sanitized expectation-suite excerpt would raise it to `high` |
| R7 | BigQuery as the warehouse | important | adjacent | medium | transferability | The JD names BigQuery as the stack but only asks for "a cloud warehouse". You say you've "never used BigQuery". What carries over: dbt modelling on another cloud warehouse. The limit: BigQuery's cost model (billing by bytes scanned), partitioning and clustering, and its SQL dialect all differ from Snowflake's | `[grounded]` JD and your background; `[generic]` the platform differences | G1; optional work sample W1 |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | Six years of data engineering with Airflow suggests you ran ingestion, but your background names no sources or tools for it | `[grounded]` background silent on ingestion; `[inferred]` the likelihood, from the Airflow role | G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | A 180-model dbt project and a Great Expectations suite are close to contract work, but whether you defined contracts with consumers isn't stated | `[grounded]` background silent on contracts; `[inferred]` closeness, from the dbt and Great Expectations work | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery as the warehouse (R7, important) | transferability | dbt on Snowflake, and no BigQuery | It is the stack you would work in from day one, so the bridge needs a stated limit rather than a claim | Any warehouse migration or cost-tuning you did on Snowflake; a personal dbt project run against BigQuery | Work sample W1 | `[grounded]` your background; `[generic]` that a stack mismatch draws a question in screens |
| G2 | Ingestion from the app and CRM (R8, important) | discovery | No ingestion sources or tools named | It is the first of the JD's three named areas | Pulling a CRM (Salesforce, HubSpot) or a payroll-app database into Snowflake; using Fivetran, Airbyte or custom Python extractors; CDC from a production database | A sanitized DAG, a connector config, or a design doc | `[grounded]` background silent |
| G3 | Data contracts (R9, important) | discovery | dbt and Great Expectations work, but no contracts named | The JD names contracts as something analysts depend on, which makes them a likely interview topic | dbt model contracts or enforced schemas; agreed SLAs or schema-change rules with analysts or upstream app teams; tests that block a bad load | An example contract, schema YAML, or an incident write-up | `[grounded]` JD and background; `[inferred]` interview salience, from the JD's wording |
| G4 | Location (R1, hard_gate) | hard_gate | Not stated | It is the posting's only hard gate | — | — | `[grounded]` JD terms |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver." | The company may be too new or small to have much of a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Severity is `medium`, not `high`, because pay is stated and there is no urgency pressure | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay stated, at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The pay is transparent: the floor is above the report's 25th percentile and the top is above its 75th | `[grounded]` JD; `[generic]` band from the pasted report | Where in the range would you place six years of experience, and what is the equity (type, amount, vesting)? | noted |
| RR3 | No hiring manager named | unknown | — | (the posting names no hiring manager) | The reporting line could be analytics or engineering, which changes who owns the data contracts | `[inferred]` from the posting's silence | Who does this role report to, and how is the data team organized? | unresolved |
| RR4 | Scope may be wider than one domain | unknown | — | "Build and run the pipelines … ingestion …, a dbt-modelled warehouse …, and the data contracts" | You may be the only owner of the whole reporting stack, plus on-call for it, against a typical one-domain scope | `[inferred]` from the JD's three areas; `[generic]` the report's typical scope | How many data engineers are there today, which parts would be mine alone, and what does on-call look like? | unresolved |
| RR5 | Recent funding | positive_signal | — | "Series C ($52M, February 2026)" | The hire is likely funded, though it isn't verified (RR1) | `[inferred]` from the pasted about-page | How is data-team headcount planned for the next year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Pellucid's own careers page before applying | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your own words: "built our dbt project on Snowflake — about 180 models" and "set up our Great Expectations test suite" | R4, R6 | `[grounded]` your background | pending your approval |
| A3 | State BigQuery plainly as new to you, and present Snowflake as your cloud-warehouse experience | R7 | `[grounded]` "Never used BigQuery" | pending your approval |
| W1 | Optional: a small personal dbt project run against BigQuery, which you can then name honestly as hands-on exposure | R7, G1 | `[generic]` that a small sample narrows a stack objection | pending your approval |
| Q1 | Ask the verification questions from RR1–RR5 word for word during the process | Register | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried to fetch pellucidlearning.com/careers/senior-data-engineer to check the pasted posting; the permission was refused. It would have resolved RR1 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | I searched "Datawright 2026 Data Engineering Pay Report" to check the pasted report was genuine and current; the permission was refused. Market calibration rests on the report as you pasted it |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can save this as a `tuesday-dossier.md` if you'd like to keep it or reuse it later.

**Upgrade menu**
- Allow web access, or paste the live careers-page URL after checking it yourself, to close RR1 and possibly lift the conditions.
- Your pay floor and any other non-negotiables, to add them as gate rows and settle condition (3).
- An answer to G2, to resolve R8.
- A sanitized dbt lineage view or Great Expectations suite excerpt, to move R4 or R6 to `high`.
- The hiring manager's name, to fill the scope read and decide which story to lead with.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1: Are you based in the US, and can you work remotely from the US or from the Denver office?

Constraints: Is $148k–$166k at or above your pay floor, and is there anything else you won't trade, such as on-call?

G3: Have you defined or enforced a contract with analysts or upstream teams, for example dbt model contracts, schema-change rules, or tests that block a load? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.