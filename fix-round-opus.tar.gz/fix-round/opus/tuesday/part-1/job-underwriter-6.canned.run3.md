Now the required references.
## Decision snapshot

**Yes, it's worth going for, as long as two days a week in the Bristol office works for you. Prepare for R5 and R6 before you apply. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days a week)
- `must_have` — direct: R2a, R3, R4a · adjacent: R5 (Experience owning a forecast) · unclear: R2b (at a B2B software company), R4b (spreadsheet modelling), R6 (working with finance on billing or revenue data)
- `important` — direct: R7a, R8 · absent: R7b (Own billing data)

R5: the forecast you fed into but never owned; R6, R7b: the billing gap you named yourself; R2b, R4b: probably fine, not yet shown.

**Opportunity ledger.** The pay is stated and sits inside the market range (RR3), and the company exists as the posting describes (RR5). Three points are open: the role isn't on Quillfield's own site (RR1), it's unclear how much billing work the role takes on (RR2), and it's unclear who owns the forecast number (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) two days a week in Bristol works for you (R1); (2) you present R5 honestly as forecast-input work, never as owning the forecast; (3) R6 turns up some finance-facing revenue-data work, or you treat the billing gap openly as the thing you'd learn first (R6, R7b, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance use; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Terms | Bristol, hybrid with two office days a week; £61,500–£67,000 plus share options | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` recruiter, and public profile (linkedin.example/in/tamsin-achebe) |
| Scope read | A Lead who reports to a Head of RevOps, taking on finance-facing work (billing data, the CFO forecast) on top of standard sales ops | `[inferred]` from her title and the JD's mandate |
| Market calibration | UK B2B software RevOps lead pay: median base £64,200, middle half £57,800–£70,400. The posting's £61.5–67k sits around the median | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide, n=438, from the search summary; `[grounded]` JD for the posted range |
| Unknowns | Who owns the forecast number; whether billing operations move to this role or stay with finance; which billing system is used; team size | — |
| Contradictions | None in the posting. The role isn't on Quillfield's own site (see RR1) | `[grounded]` careers search and fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You didn't say where you're based or whether you can do office days, so the gate isn't settled either way | `[grounded]` JD terms; intake silent | Closing question R1 |
| R2a | 4+ years in revenue operations or sales operations | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team. Specific, but self-reported with nothing to inspect yet | `[grounded]` intake | none |
| R2b | …at a B2B software company | must_have | unclear | low | discovery | "B2B payments company" may or may not be a software company. Quillfield sells payments software, so your domain is close either way | `[grounded]` intake and About page | Say what your employer sells (upgrade menu) |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certificate can be checked but hasn't been | `[grounded]` intake | Certificate link raises this to high |
| R4a | Strong SQL | must_have | direct | medium | none | SQL weekly, in your own words; no sample inspected | `[grounded]` intake | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows tool use, not that you've built a model | `[grounded]` intake; the distinction is the JD's own word "modelling" | Upgrade menu: a model you built |
| R5 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which feeds a forecast; finance owned the company forecast. Limit: you haven't owned the number or answered to a CFO for it | `[grounded]` intake; `[generic]` that a pipeline review is a forecast input | See G1 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Billing data is ruled out by you. The JD says billing *or* revenue data, and whether finance used your renewal reporting is unestablished | `[grounded]` intake | See G2 |
| R7a | Own the CRM | important | direct | medium | none | Salesforce admin certified, and you rebuilt the pipeline and renewal dashboards | `[grounded]` intake | none |
| R7b | Own billing data | important | absent | none | capability | You said you've never worked on billing data. Treated as a real gap with a way to close it, not something to dress up | `[grounded]` intake | See G3 |
| R8 | Build pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them is open (R6) | `[grounded]` intake | A sanitized dashboard screenshot raises this to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R5, must_have) | transferability | A monthly pipeline review run with the sales director; finance owned the forecast | It's the role's headline duty ("run the quarterly revenue forecast with the CFO"), so it's where the interview will probe hardest | Giving finance a pipeline or commit number each month; building the stage-weighted or renewal-likelihood view finance used; reconciling forecast against actual after a quarter closed | A sanitized pipeline-review deck or forecast-input sheet | `[grounded]` intake; `[generic]` that headline duties draw the hardest probes |
| G2 | Finance on revenue data (R6, must_have) | discovery | Renewal dashboards exist; who used them is unknown | It's a must-have, and the JD accepts revenue data, not only billing | Finance using your renewal dashboards; reconciling bookings or ARR with finance; working out a CRM-versus-finance revenue mismatch | A dashboard screenshot, a reconciliation sheet | `[grounded]` JD's "billing or revenue data" |
| G3 | Billing data (R7b, important) | capability | Confirmed none | Billing data is in the role's first line of duties | Closure path: learn the basics of subscription billing data (invoices, credit notes, MRR movements), ask which billing system Quillfield uses, and present it openly as your 90-day ramp | — | `[grounded]` intake; `[inferred]` closure path from the JD's mandate |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not found on Quillfield's own site | unknown | — | Posted on Tallyboard Jobs | The posting may be job-board-only or the careers page may have moved. The employer is real, and the recruiter and Tamsin's public profile back it up | `[grounded]` careers fetch returned no page and search found no listing; `[generic]` that small firms often post only on job boards | Is the role open now, and does it report to Tamsin? | unresolved |
| RR2 | CRM, billing data, reporting and the CFO forecast bundled into one role | risk_signal | low | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | Billing operations may move to this role from finance with no handover, adding finance-ops work to sales ops | `[inferred]` from the bundled mandate | Who owns billing operations today, and what moves to this role in the first quarter? | unresolved |
| RR3 | Pay stated and in market range | positive_signal | — | "£61,500–£67,000 plus share options" | Transparent pay at about the median for the title | `[grounded]` JD; `[generic]` band | How are the share options sized and vested? | noted |
| RR4 | Forecast ownership is shared | unknown | — | "run the quarterly revenue forecast with the CFO" | It's unclear whether the CFO owns the number and this role builds it, or the reverse | `[inferred]` from "with the CFO" | Who signs off the quarterly forecast, and who answers for the miss? | unresolved |
| RR5 | Established, funded company | positive_signal | — | "Founded 2018 in Bristol; 96 employees. Series A (£11M) closed in April 2025" | A real company with recent funding behind it | `[grounded]` About page | What's the plan for revenue operations over the next year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own words: "rebuilt our pipeline and renewal dashboards" and "run the monthly pipeline review with our sales director" | R7a, R8, R5 | `[grounded]` intake | pending your approval |
| P2 | Describe forecasting exactly as it was: you run the monthly pipeline review; finance owned the company forecast. Don't say "owned" or "built" the forecast | R5 | `[grounded]` intake | pending your approval |
| P3 | Keep "for the UK team" on the RevOps claim | R2a | `[grounded]` intake | pending your approval |
| P4 | Raise the billing gap yourself, with the G3 ramp plan, rather than waiting to be asked | R7b, RR2 | `[grounded]` intake; `[generic]` that a gap you name yourself lands better than one the interviewer finds | pending your approval |
| P5 | Tamsin spent four years in sales ops at a payments company, so your payments sales-ops background is familiar ground for her | Positioning for this reader | `[grounded]` public profile; `[inferred]` relevance | pending your approval |
| P6 | Ask RR1, RR2, RR4 verbatim at the recruiter screen | Register as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers" → "About Quillfield" (quillfield.co.uk/about), and 'Quillfield careers "Revenue Operations Lead"' → no results; fetched quillfield.co.uk/careers → no page. Moved the organization row, RR1 and RR5 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B SaaS Bristol" → "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" → "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring-manager and scope rows, and P5 |

I can write all this up as a `tuesday-dossier.md` you can keep or reuse later, if that's useful.

## Upgrade menu

- Where you're based and your pay floor → R1 settles, and the £61.5–67k range gets checked against your floor.
- What your current employer sells → R2b settles.
- A model you've built (capacity, quota, renewal) → R4b moves from `unclear`.
- A link to your Salesforce certificate or a sanitized dashboard screenshot → R3 or R8 rises to `high`.
- A deeper research pass on Quillfield (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches) → feeds the risk register. Say the word and it runs.

**Questions**

G1: When finance built the company forecast, what did you hand them from the pipeline review (a number, a commit call, a weighted view), and did you ever check it against actuals?

G2: Did finance use your renewal dashboards, or have you worked with them to reconcile bookings or revenue figures?

R1: Can you work two days a week from Quillfield's Bristol office?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.