Now the Step 1 files.
**No, you're not wasting your time. Your weak point is R1b: you've never held a PM title, and the posting asks for 3+ years of product management. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — adjacent: R1a (product-management work, 3+ years) · absent: R1b (product management in a PM role, 3+ years)
- `important` — direct: R3, R4a, R6 · adjacent: R2 (shipped API or platform products), R7 (own the roadmap), R8 (write specs and drive delivery), R10 (coordinate launches) · unclear: R4b (stakeholder management with sales), R5 (agile delivery), R9 (define and track adoption metrics)

R1b — no wording fixes it, so it depends on who reads your application; R2, R8 — bridges that G1 could make stronger; R9 — the open row G2 asks about.

**Opportunity ledger.** Nothing about the employer looks wrong, but nothing is confirmed either. The web search was refused, so the employer isn't verified (RR1). Pay (RR2) and work arrangement (RR3) aren't stated, and the posting doesn't say what year-one success looks like (RR5). One entry is good news: the posting names two engineering squads you'd work with (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: you find the role live on Quartzline's own careers page; (2) your application reaches someone who will weigh R1a against R1b, which means a referral or the hiring manager rather than a cold upload (A2); (3) pay and work arrangement meet your terms (RR2, RR3); (4) you present R2 and R8 as adjacent experience, never as having shipped an API product yourself.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, about 150 people, Series B | `[grounded]` JD header; not checked against the company's own site (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` the JD is silent |
| Scope read | A normal full-cycle PM remit (discovery through launch) for one product area, with named engineering capacity. One role, not several stitched together | `[inferred]` from the six responsibilities and the two named squads |
| Who the platform serves | Integration partners: the kind of technical counterpart you've worked with for 7 years | `[grounded]` JD's "partner-facing API platform", "integration partners" |
| Market calibration | Not established. The role-family search was refused, so I have no pay band or scope norm to give you | — |
| Unknowns | Pay, location and work arrangement, hiring manager, what success means in year one | `[grounded]` JD is silent on each |
| Contradictions | None inside the JD; it wasn't compared with any outside source | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Product-management work, 3+ years (the work itself) | must_have | adjacent | medium | transferability | 7 years of work that overlaps PM: requirements documents, quarterly roadmap-input sessions for product, coordinating engineers and PMs on custom builds. Limit: you gathered input and others decided what to build; none of it was your own product call | `[grounded]` your resume as you described it | Make the bridge case in the application (E1, A3) |
| R1b | Product management in a PM role, 3+ years | must_have | absent | none | capability | You've never held a PM title, so this can't be met. It's a length-of-experience requirement, not a hard gate. `[generic]` A stated year count on a must-have is often screened literally at first pass, so it matters most before any person reads the rest | `[grounded]` you said "never held a PM title"; `[generic]` screening pattern | Closure path in G4; carried as the main fit risk |
| R2 | Shipped API or platform products | important | adjacent | medium | transferability | 30+ end-to-end client integrations of your company's REST APIs. Limit: you implemented a product others shipped. Owning what goes into the API is a different job | `[grounded]` your resume | G1 |
| R3 | Technical fluency: reading API docs, discussing schemas | important | direct | medium | none | Postman, SQL, reading OpenAPI specs, plus integration architecture work. Specific, but nothing inspectable yet, so expect them to test it | `[grounded]` your resume | none |
| R4a | Stakeholder management across engineering and customers | important | direct | medium | none | Coordinated your engineers, the client's engineers and product managers on custom builds | `[grounded]` your resume | none |
| R4b | Stakeholder management with sales | important | unclear | low | discovery | Your resume doesn't mention sales. I won't assume a solutions engineer worked with sales; that has to come from you | `[grounded]` resume silent | G3 |
| R5 | Agile delivery | important | unclear | low | discovery | Your resume doesn't mention a delivery method | `[grounded]` resume silent | G3 |
| R6 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops and quarterly roadmap-input sessions collecting client feedback, with the integration counterparts this role serves | `[grounded]` your resume | none |
| R7 | Own the roadmap | important | adjacent | medium | transferability | You fed the roadmap through the input sessions. Limit: you didn't set priorities on it | `[grounded]` your resume | Name the limit in A3 |
| R8 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | Requirements documents, integration architecture, UAT and go-live, coordinating engineers. Limit: these were per-client integrations and custom builds, not specs for a product many partners use | `[grounded]` your resume | G1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Your resume doesn't mention metrics. The integration playbook "the whole team uses" shows adoption but not measurement. A note from an earlier conversation mentions a request-triage tool that support agents adopted. It's unconfirmed, so it only prompts a question | `[grounded]` your resume; memory note unconfirmed | G2 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live coordination across 30+ integrations. Limit: a client go-live isn't a market launch with sales and support enablement | `[grounded]` your resume | G3 covers the sales side |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped API or platform products; specs (R2, R8, important) | transferability | Custom builds you coordinated and requirements you wrote. Nothing shows whether any of it became part of the general product | A custom build that made it into the core API would be the strongest bridge to R2 that you could have | A client endpoint or field that later shipped to all customers; a requirements doc product reused as a spec; an integration pattern that went into the product's public docs | A sanitized requirements doc, a changelog or release note, a docs page | `[grounded]` resume silent on what happened after go-live; `[inferred]` that this would be the strongest bridge |
| G2 | Define and track adoption metrics (R9, important) | discovery | Nothing on measurement. One unconfirmed lead (the triage tool) | The resume gives no evidence for one of the six things the posting says the job does | Tracking playbook use; time-to-go-live across integrations; API call volume after go-live; triage tool usage, if you built it | A dashboard screenshot, a usage report, the tool's own stats | `[grounded]` resume silent; lead from memory, unconfirmed |
| G3 | Sales and agile (R4b, R5, important) | discovery | Neither is mentioned | Both are listed requirements, and the evidence may well exist | Pre-sales scoping calls, handing over to account teams, delivering in sprints with your engineers, Jira boards | A sprint board, a handover doc | `[grounded]` resume silent |
| G4 | Product management in a PM role, 3+ years (R1b, must_have) | capability | You've confirmed you've never held a PM title | No wording solves this. Only a reader who weighs R1a can get past it | Closure path: applications that reach the hiring manager directly; a work sample (W1); and, as a fallback, an internal move to a PM title or a "technical PM / integrations PM" role at a company that accepts adjacent experience | — | `[grounded]` your own statement; `[inferred]` closure path |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The search was refused, so nothing confirms the company or the posting. It may be fine; it simply isn't checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation unstated | unknown | — | (no pay in the posting) | The posted range may be below your floor, or they may just not publish pay | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and work arrangement unstated | unknown | — | (none in the posting) | Might be on-site, hybrid or remote | `[inferred]` from the posting's silence | Where is this role based, and what's the in-office expectation? | unresolved |
| RR4 | Engineering resources named | positive_signal | — | "drive delivery with two engineering squads" | The role comes with real delivery capacity, not just accountability | `[grounded]` JD | Do the two squads work only on the API platform, or do they share time with other products? | noted |
| RR5 | No year-one success definition | unknown | — | "define and track adoption metrics" | Whoever takes the role may be the one who defines success | `[inferred]` from the JD setting metrics as a task with no target | What would make this hire a success at twelve months? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your resume and note with your own lines: "Led 30+ client integrations of our REST APIs end to end" and "Ran quarterly roadmap-input sessions collecting client feedback for product." Never use "shipped", "owned the roadmap" or "ran discovery" about your past | See R1a, R2, R6, R7 | `[grounded]` your own wording | pending your approval |
| A3 | Name the title gap yourself, along the lines of: "I haven't held the PM title; for 7 years I've written the requirements and run the client roadmap-input sessions" | See R1b, R7. If you name it, the reader doesn't find it as a surprise | `[grounded]` your resume | pending your approval |
| A2 | Get a referral or reach the hiring manager rather than applying cold | `[generic]` Readers who can weigh adjacent experience usually sit past the first screen; this is a role-family pattern, not a fact about Quartzline | `[generic]` pattern | pending your approval |
| W1 | A one-page sample: a spec or an adoption-metrics plan for a partner API endpoint | See R1b, R9. It gives the reader something to inspect | `[inferred]` from R1b and R9 | pending your approval |
| A1 | Confirm the posting is live on Quartzline's careers page before you invest effort | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3, RR4 and RR5 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a memory note about a request-triage tool that support agents adopted, unconfirmed, asked about in G2. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform Series B". The search was refused. It would have confirmed the company and the posting (RR1) and filled role reality's Contradictions row |
| 2. Role-family sweep | unavailable | Searched "product manager platform APIs B2B Series B scope requirements salary". The search was refused. It would have filled market calibration and given a band to set against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search |

I can save all of this as a `tuesday-dossier.md` file whenever you want it.

## Upgrade menu

- **Allow web search:** targets 1 and 2 run. That could clear RR1 and add a market band for pay. After that, a deeper pass on Quartzline (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) runs if you say yes.
- **Your pay floor and location terms:** hard-gate rows get built and the snapshot's gate check stops being unknown.
- **An answer to G1:** R2 and R8 may get stronger bridges.
- **An answer to G2:** R9 moves out of `unclear`.
- **A sanitized requirements doc, playbook excerpt or usage report:** R3, R8 or R9 can move toward `high`.
- **The hiring manager's name:** tells us which of your stories to lead with for that reader.

## Questions

G1 — Did any custom build you specified end up in the general product or the public API? What was your part, and what shipped?

G2 — Have you ever defined or tracked whether people used something, such as the playbook, integration go-lives, or the request-triage tool my notes mention (if that's real)? What did you measure?

G3 — Did you work with sales in your current role, and did your team deliver in sprints or another agile setup?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip. If you'd like interview prep afterwards, the mock-interview module handles that.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.