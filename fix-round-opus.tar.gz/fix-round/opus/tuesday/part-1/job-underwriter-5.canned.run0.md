I'm checking that Pellucid Learning and the posting are live before I write the assessment.
I ran this through the job-underwriter, the module that decides whether a role is worth applying to. Two searches confirmed the posting is open and the About page matches what you pasted.

## Decision snapshot

**Yes, it's worth applying to, on the conditions below. Every `must_have` row (R2, R3, R4, R5, R6) lands `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R7 (Warehouse in BigQuery) · unclear: R8 (Ingestion from app and CRM), R9 (Data contracts analysts depend on)

R7 is a short bridge from Snowflake, with its limit named. R8 and R9 are duties your background doesn't mention yet, and that may be just because you haven't said.

**Opportunity ledger.** The role looks sound and open about its terms. The pay range sits at or above the market band you supplied (RR1), the posting and employer check out live (RR4), and the funding and stack are concrete (RR5). Two things are unknown: the equity terms (RR2) and the size and shape of the team the role sits in (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: you're in the US and authorized to work there, or can work from Denver. (2) R7: BigQuery is framed honestly as new to you, with Snowflake as the bridge. (3) RR3: the team and ownership scope check out as one domain's pipelines in the recruiter screen.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states; founded 2016 in Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` About page, matched by a live search result |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow "or similar", data quality testing | `[grounded]` JD |
| Scope read | One domain (platform reporting) covering ingestion through to analyst-facing contracts; no direct reports mentioned | `[inferred]` from the JD's responsibility list and its silence on managing people |
| Market calibration | "Senior" usually means 5–8 years and ownership of one domain's pipelines with no reports. This title and scope fit that pattern, and your 6 years sit inside it | `[generic]` Datawright 2026 report you supplied (US, n=2,310, Series B–D); `[inferred]` that this role matches it |
| Compensation | Posting: $148,000–$166,000 base plus equity. Report band: median $151,000, interquartile range $139,000–$163,500 | `[grounded]` JD for the posting's figure; `[generic]` report band, never this employer's offer (RR1) |
| Unknowns | Team size and who the role reports to; whether the BigQuery warehouse already exists or is being built; equity terms | — |
| Contradictions | None between the posting, its live careers page and the About page | `[grounded]` search results for both pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you're authorized to work in the US. The JD allows remote work only within the US | `[grounded]` JD; your background is silent | Question R1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years, which clears 5+. It's self-reported with nothing to inspect, and `medium` is the most a first pass can give | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily." Specific, but nothing to inspect yet | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models." Snowflake is a cloud warehouse, so the requirement as written is met | `[grounded]` your background | Optional: a dbt docs site or a repo would raise this to `high` |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow by name, the JD's own example | `[grounded]` your background | none |
| R6 | Experience with data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite." That's setup work, not just use | `[grounded]` your background | Optional: a sanitized suite config or Data Docs page would raise this to `high` |
| R7 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | You say "Never used BigQuery." Your dbt modelling and warehouse work carry over. The limit is BigQuery-specific work such as cost control, partitioning and permissions, which Snowflake work doesn't exercise | `[grounded]` your background; `[generic]` what differs between warehouses | See gap queue G1 |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | Airflow orchestration suggests you've built ingestion, but you haven't said which sources you ingested | `[inferred]` from your Airflow work; `[grounded]` your background is silent on sources | See gap queue G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | A Great Expectations suite is near this, but tests are not the same as agreed contracts with consumers. Whether you've set schemas or service levels with analysts is unstated | `[inferred]` from the GE suite; `[grounded]` your background is silent on contracts | See gap queue G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | dbt on Snowflake at about 180 models; no BigQuery | It's the one named tool you haven't used, and it is the easiest gap for a screener to spot | Any warehouse migration or cross-warehouse dbt work; cost or performance tuning on Snowflake (the skill carries over, the platform doesn't) | A small public dbt project run against BigQuery | `[grounded]` your background; `[generic]` that a named-tool gap draws a screening question |
| G2 | Ingestion from app and CRM (R8, important) | discovery | Airflow orchestration, with sources not named | A core JD duty, and a payroll company very likely had both app-database and SaaS sources | Pulling from a production app database (change data capture, replicas, exports); syncing a CRM or HR/payroll SaaS through its API or a connector tool; handling schema changes from an upstream team | A DAG excerpt, an architecture diagram, a pipeline design doc | `[grounded]` the JD's duty; `[inferred]` that payroll work likely involved such sources |
| G3 | Data contracts (R9, important) | discovery | A Great Expectations suite, with no contract work stated | The JD names contracts as something analysts depend on, so it's likely probed | Agreeing schemas or freshness service levels with analysts; dbt model contracts or exposures; owning how a breaking upstream change was handled | A contract spec, a dbt `contract:` config, a service-level doc | `[grounded]` JD; `[inferred]` that GE work sits near contract work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The posting's floor is $9,000 above the band's lower quartile and its top is $2,500 above the upper quartile. For this title it pays at market or better | `[grounded]` posting and the report you supplied; the band itself is `[generic]` | Where in the $148k–$166k range would 6 years' experience land, and how is the range set? | noted |
| RR2 | Equity unspecified | unknown | — | "plus equity" | Its type, size and vesting are unstated, so its value can't be judged from the posting | `[inferred]` from the posting's silence on terms | Is the equity options or RSUs, how many, at what strike or valuation, and over what vesting? | unresolved |
| RR3 | Team shape and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | This could be the only data engineer owning everything from ingestion to contracts, or one of a team. No hiring manager or team is named | `[inferred]` from the JD's silence on team and reporting line | How many data engineers and analysts are there today, who does this role report to, and which pipelines would I own on day one? | unresolved |
| RR4 | Posting and employer verified live | positive_signal | — | "Accepting applications" | The posting is open and the About page matches what you pasted | `[grounded]` search results for the careers page and the About page | What does the hiring process look like, and on what timeline? | noted |
| RR5 | Recent funding and a named stack | positive_signal | — | "Series C ($52M, February 2026)"; "a dbt-modelled warehouse in BigQuery" | The employer is recently funded and the role has a defined toolset | `[grounded]` About page and JD | Is the BigQuery warehouse already in production, or would this role be building it? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dbt project you built on Snowflake (about 180 models) and the Great Expectations suite you set up, in those words | See R4, R6 | `[grounded]` your background | pending your approval |
| P2 | Name BigQuery plainly as new to you, with Snowflake and dbt as the bridge. Never imply you've used BigQuery | See R7 | `[grounded]` "Never used BigQuery" | pending your approval |
| W1 | Optional: a small public dbt project run against BigQuery, to turn R7 into work someone can inspect | See R7, G1 | `[generic]` that a hands-on sample narrows a tool gap | pending your approval |
| A1 | Set RR1's range against your own floor before the recruiter screen | See RR1 | `[grounded]` posting | pending your approval |
| Q1 | Ask the verification questions from RR1 through RR5 word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer careers", which returned "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), marked accepting applications. Searched "Pellucid Learning online tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Both checked the pasted text and moved role reality's organization and contradictions rows, plus RR4 |
| 2. Role-family sweep | skipped | The Datawright 2026 report you supplied already fixes the market calibration line and RR1's comparison |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Closing

Once you answer the questions below, I can save this as a `tuesday-dossier.md` so later prep work starts from it. Just say so.

**Upgrade menu**
- **Your location and work authorization:** closes R1, and the status likely moves to `go` or `no_go`.
- **Your pay floor:** RR1 gets set against your number, not just the market.
- **Answers to G2 and G3:** R8 and R9 resolve, and the plan gains stories for the JD's core duties.
- **An inspectable artifact** (a dbt docs site, a repo, a sanitized GE config or Data Docs page): R4 and R6 move to `high`.
- **The hiring manager's name:** role reality's scope read and which story the plan leads with for that reader.
- **A deeper research pass on Pellucid** (leadership changes, hiring patterns, employee reports, recent news), up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

R1 — Are you based in the US and authorized to work there without sponsorship, or able to work from Denver?

G2 — At the payroll company, which sources did your Airflow pipelines pull from, such as an app database or a CRM or other SaaS API, and which parts of that ingestion did you build yourself?

G3 — Have you ever agreed schemas, freshness targets or other guarantees with the analysts using your models, or handled a breaking upstream change for them? What was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.