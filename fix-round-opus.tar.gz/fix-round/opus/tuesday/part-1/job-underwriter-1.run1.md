Let me read the required references.
**Yes, apply. You're a strong fit on paper. Before you put real effort in, check that the employer and the terms are what the posting says. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important`: direct: R7a · adjacent: R7b (Partner with clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R6: probably yours, but you haven't said who built the model under the dashboards; R8: nothing about mentoring yet; R7b and R9: a credible bridge from consumer-PII and exec-facing work, with its limits named.

**Opportunity ledger.** I couldn't confirm the employer because my research calls were refused (RR1). Pay and location aren't stated (RR2, RR3). The scope reads like an analytics lead's job (RR4), and the app's experiment traffic is unknown (RR6). On the positive side, the mandate and tooling are concrete and analysis is tied to roadmap decisions (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and a live posting check out (RR1); (2) pay, location and work arrangement meet your non-negotiables (RR2, RR3); (3) you confirm R6 as your own work, or describe it honestly as adjacent; (4) the analytics team's structure and the traffic behind its experiments are acceptable to you (RR4, RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health: digital-health scale-up, about 400 people, Series C | `[grounded]` JD header; not checked independently (see RR1) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve dashboards, turning analysis into roadmap decisions with PMs and clinicians, mentoring two juniors | `[grounded]` JD |
| Scope read | "Own" product analytics plus two direct mentees sounds like a lead-analyst remit under a Senior title | `[inferred]` from "Own product analytics" and "mentor two junior analysts" |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established. The role-family sweep didn't run, so there's no salary band to compare against | n/a |
| Unknowns | Compensation; location and remote policy; reporting line; experiment traffic volume; who owns the metrics layer today | `[grounded]` JD silent on each |
| Contradictions | None inside the JD; the careers page wasn't checked | `[grounded]` JD read in full |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You stated 6 years of product analytics at a consumer-subscription company. That's specific, but it's self-report with nothing inspected, which is the ceiling at intake | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse, plus building a consent-state model in it, is work that requires depth | `[grounded]` your background | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year on a base of about 2M subscribers, including the pricing test behind an 11% retention lift | `[grounded]` your background | Have one test's design doc or readout ready (sanitized) |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your background | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | A sanitized memo excerpt would raise this to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests a modelled layer underneath, but you haven't said that you defined the metric definitions or the LookML model. Assuming it would credit you with a practice you never stated | `[grounded]` your background is silent on the model layer; `[inferred]` that a governed Looker instance has one | See G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | You present monthly to the VP Product and run the experimentation program. The pricing test is a decision your analysis drove | `[grounded]` your background | Pick 1–2 more decisions your analysis changed |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | The bridge: you translate analysis for non-technical execs. The limit: clinicians are a different audience, with clinical-safety stakes and evidence norms you haven't worked with | `[grounded]` your background; `[generic]` that clinical stakeholders weigh safety and evidence differently | See G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring, managing or onboarding analysts | `[grounded]` your background is silent | See G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | The bridge: GDPR/CCPA consumer PII, and you built the warehouse consent-state model. The limit: no PHI, and none of HIPAA's specific mechanics (de-identification standards, minimum-necessary access, BAAs) | `[grounded]` your background; `[generic]` HIPAA's mechanics differ from GDPR/CCPA | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | A Looker instance you built, with governed dashboards; no statement about who defined metrics or wrote the model | A must-have, and the first item in the JD's responsibility list. Resolving it moves R6 to `direct` or `adjacent` | Writing LookML views and explores; owning canonical definitions (active subscriber, churn, retention cohort); a metrics dictionary; dbt or Snowflake models feeding Looker; settling disputes between teams' numbers | A sanitized LookML snippet, a metrics glossary, a model-layer diagram | `[grounded]` your background is silent; `[inferred]` that it moves the row |
| G2 | Clinician partnership (R7b, important) | transferability | Exec and VP Product stakeholders only | Clinicians are named partners in the JD | Working with ops, nutrition or food-safety teams; any analysis where a wrong answer had safety or compliance stakes | A memo written for a non-analyst domain expert | `[grounded]` JD names clinicians; `[generic]` that this audience is a likely interview topic |
| G3 | Mentoring juniors (R8, important) | discovery | Nothing stated | A named responsibility with two named reports | Onboarding analysts onto your Looker instance; reviewing others' SQL or test designs; teaching experiment design; formal or informal reports | A review doc, an onboarding guide, a peer reference | `[grounded]` your background is silent |
| G4 | HIPAA / healthcare data (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | Preferred only, so it won't block you, but it's the clearest point of difference against healthcare-native candidates | The consent-state model itself; access controls or masking you set up in Snowflake | A short write-up of the consent model's design | `[grounded]` your background; `[generic]` how healthcare-native candidates compare |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The posting could be real and simply unchecked, stale or aggregated, or it might not represent a real hiring employer | `[generic]` pattern for unverified postings, not a claim about this one | Can you point me at this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation unstated | unknown | — | (no pay figure in the posting) | The posting may withhold the range, or it may sit below market for "Senior" with lead-level scope | `[inferred]` from the posting's silence | What base salary range and equity are budgeted for this role? | unresolved |
| RR3 | Location, remote policy and work-authorization terms unstated | unknown | — | (no location in the posting) | Terms that could conflict with your constraints are missing | `[grounded]` JD silent | Is this role remote, hybrid or on-site, and where, and do you sponsor visas? | unresolved |
| RR4 | Lead-level scope under a Senior title | risk_signal | low | "Own product analytics for our care-navigation app… mentor two junior analysts" | You may carry the whole analytics function without lead title, pay or decision rights | `[inferred]` from "own" plus the mentoring remit | Who does this role report to, and does anyone else senior on the analytics side own metric definitions? | unresolved |
| RR5 | Concrete mandate, tied to decisions | positive_signal | — | "partner with product managers and clinicians to turn analysis into roadmap decisions" | Analysis has a stated route into decisions, and the tooling is named | `[grounded]` JD | Which roadmap decisions in the last two quarters came out of analysis? | noted |
| RR6 | "Experiment design at scale" against unknown app traffic | unknown | — | "design and analyze A/B tests… experiment design at scale" | A care-navigation app may have far less traffic than ~2M subscribers, which changes the experiment toolkit you'd need (power, sequential testing, quasi-experiments) | `[generic]` that consumer-health apps often run on smaller samples; `[inferred]` that this shapes the role | Roughly how many monthly active users do experiments run against, and how many tests shipped last year? | unresolved |

## Application plan

These are proposed and need your approval. Every positioning line below uses your own words.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Open with the experimentation program, in your words: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | see R3 | `[grounded]` your background, quoted | pending your approval |
| P2 | Second line: "Built the company's Looker instance from scratch — 40+ governed dashboards." Don't add "metrics layer" or "semantic model" until G1 confirms it | see R4, R6 | `[grounded]` your background, quoted | pending your approval |
| P3 | Present privacy work as "handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse." Never call it HIPAA experience | see R9 | `[grounded]` your background, quoted | pending your approval |
| P4 | Verify the employer and terms with the recruiter before investing in the loop | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| P5 | Ask the register's verification questions word for word in recruiter and hiring-manager rounds, with RR4 and RR6 first | They decide whether the scope suits you | `[grounded]` register | pending your approval |
| P6 | Learn HIPAA basics before interviews (PHI, de-identification, minimum necessary) so you can say concretely where your consent work carries over | see R9 | `[generic]` closure path for a preferred-tier gap | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app"; the call was refused (permission not granted). It would have confirmed the entity, its stage and size, and whether the posting is live, which would close or confirm RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary 2026"; the call was refused. It would have filled the market calibration row and given RR2 a band to compare against |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search |

---

I can turn this into a `tuesday-dossier.md` file you can keep and reuse in later prep. Just say so.

**Upgrade menu**
- **Allow web search:** I'll redo targets 1–2, which confirms or clears RR1 and fills the market calibration row and RR2's band.
- **The posting's URL or the careers page:** RR1 clears or escalates.
- **Your non-negotiables (pay floor, location, remote, visa):** the hard-gates line gets checked against you rather than left unknown.
- **An answer to G1:** R6 resolves, which is the must-have row still open.
- **A sanitized Looker or LookML artifact, test readout or metrics memo:** R3, R4, R5 or R6 can rise to `high`.
- **The hiring manager's name:** role reality's scope read, and which story P1 leads with for that reader.
- **A deeper research pass** (funding and leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

Constraints — What are your non-negotiables on pay, location or remote work, and work authorization?

G1 — For the Looker instance, did you personally define the metric definitions and write the model layer (LookML, dbt or similar), or did you build dashboards on a model someone else owned?

G3 — Have you mentored, onboarded or reviewed the work of other analysts, formally or informally? Who, and what did you actually do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.