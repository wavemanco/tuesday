Checking whether Harborlight Health is a real, findable company and what senior product analyst roles usually pay. Then I'll write up the fit assessment.
Yes. You fit well enough that this is worth applying for. The only conditions are the checks below: whether the company and posting are real, and whether pay and location suit you. I couldn't look up Harborlight online because the web searches weren't permitted, so nothing here is verified against outside sources.

## Decision snapshot

**Yes, you're a strong fit on paper. R1, R2, R3, R4 and R5, every `must_have` row, land `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7a · adjacent: R7b (Partnering with clinicians) · unclear: R6 (Define and maintain the metrics layer), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R6, R8: open, waiting on your answers; R7b, R9: real bridges with named limits; R3 (`medium`): your lead story, expect probes on what was yours.

**Opportunity ledger.** Nothing has been checked yet. The employer is unconfirmed (RR1), pay and working pattern aren't stated (RR2, RR3), the mentoring scope is undefined (RR4) and "at scale" has no user count behind it (RR6). One entry is positive: a clear mandate on a stack you've already built (RR5).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting are confirmed (RR1); (2) pay and working pattern meet your floor (RR2, RR3); (3) R9 is framed as privacy-governance work next to HIPAA, never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, about 400 people, Series C | `[grounded]` JD header; not confirmed by research (RR1) |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, turning analysis into roadmap decisions with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD is silent |
| Scope read | A senior individual contributor who also coaches the two juniors. It reads as owning the function's analytics, not managing a team | `[inferred]` from "own product analytics" plus "mentor" rather than "manage" |
| Domain shift | Care-navigation metrics are judged by whether patients get the right care, not just engagement. Clinicians have a say in what gets tested | `[generic]` pattern for care-navigation products, not a claim about this one |
| Unknowns | Pay; location and remote policy; user base size; whether mentoring means line management; who owns metric definitions today | none |
| Contradictions | None in the posting as pasted | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years stated, in exactly this function. Self-reported, nothing inspected yet, so `medium` | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" gets tested in a live SQL round, not on the CV | `[grounded]` your background; `[generic]` that this role family uses live SQL rounds | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ tests a year on about 2M subscribers, including the pricing test behind an 11% retention lift. Expect probes on design choices (power, guardrail metrics, novelty effects) and on what was yours versus the team's | `[grounded]` your background; `[generic]` probe pattern | Have the pricing-test design and readout ready to walk through |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards. Same tool the JD names | `[grounded]` your background | none |
| R5 | Strong writing for non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads. A sanitized memo would be the inspectable proof | `[grounded]` your background | Prepare a redacted memo excerpt as a writing sample |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" suggests you defined the metrics behind them, but you didn't say you own the metric definitions or the semantic (LookML) model | `[grounded]` background is silent on metric definitions; `[inferred]` from "governed" | G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | You present to the VP Product monthly, and a test you designed drove a pricing decision. You didn't say how often you work day to day with individual PMs | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | What carries over: explaining analysis to non-technical execs. The limit: clinicians bring a patient-safety and evidence-quality view that commercial stakeholders don't | `[grounded]` your background; `[generic]` how clinical stakeholders read evidence | G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your background doesn't mention mentoring, reviews or onboarding. Running a 30+ test program may have involved coaching others, but you didn't say so | `[grounded]` background is silent | G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse. The limit: no PHI, de-identification standards, business associate agreements (BAAs) or clinical and claims data | `[grounded]` your background; `[generic]` what HIPAA work involves | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Looker built from scratch with governed dashboards; whether you own metric definitions isn't stated | It's the first item in the mandate, so a direct answer turns R6 into a lead story | Writing the LookML model; settling definitions of "active subscriber" or "churn" across teams; a metrics dictionary; dbt models feeding Looker | A metrics dictionary page, an excerpt from the LookML model, a definitions doc | `[grounded]` background is silent; `[inferred]` that it's central to the mandate |
| G2 | Mentoring (R8, important) | discovery | Nothing on people development | A senior title with named juniors means you'll likely be asked how you develop people | Reviewing juniors' SQL or test designs; onboarding new analysts; running office hours on the dashboards; informally coaching an intern | A review checklist, an onboarding doc, a peer's feedback | `[grounded]` background is silent; `[generic]` that this gets asked |
| G3 | Clinician partnership (R7b, important) | transferability | Strong exec communication; no clinical audience | Clinicians are named as partners | Working with a food-safety or nutrition team on a test; any stakeholder group that could veto launches | A memo where a domain expert shaped the analysis | `[inferred]` bridge from exec communication |
| G4 | HIPAA (R9, preferred) | transferability | Consent-state model plus GDPR/CCPA PII handling | It's only a "plus", but it's the clearest domain-shift question you'll get | Access controls on PII tables; data-retention or deletion workflows; work with legal or privacy teams | A schema diagram of the consent model (sanitized) | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | This is low because the research was refused, not because it found nothing. The company may still be new, or the posting may be old or reposted by an aggregator. It is the standard pattern | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | none (posting silent) | The budget may sit below a senior band, or the company may simply not publish pay | `[inferred]` from the posting's silence | What's the budgeted range for this role, including equity? | unresolved |
| RR3 | Location and working pattern not stated | unknown | — | none (posting silent) | Could be office-based, hybrid or remote | `[inferred]` from the posting's silence | Is this role remote, hybrid or office-based, and where? | unresolved |
| RR4 | Mentoring scope undefined | unknown | — | "mentor two junior analysts" | Could be informal coaching or line management without the title or pay | `[inferred]` from "mentor" rather than "manage" | Will the two analysts report to this role, and does it carry their reviews? | unresolved |
| RR5 | Clear mandate on a named stack | positive_signal | — | "build self-serve dashboards in Looker" | The scope is concrete and matches your own build | `[grounded]` JD | What's the state of the Looker instance today, and what's broken? | noted |
| RR6 | "At scale" with no user count given | unknown | — | "experiment design at scale" | Care-navigation apps paid for by employers or insurers often have smaller samples and clinical limits on what can be randomized, so your 2M-subscriber playbook may need adapting | `[generic]` pattern for this product type, not a claim about this one | How many active users does the app have, and what experiments need clinical sign-off? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Harborlight's own careers page before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the resume with the experimentation program and the pricing test "behind an 11% retention lift", in your own wording | see R3: your strongest `direct` evidence | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Describe the consent-state model and GDPR/CCPA work as privacy-governance experience, never as HIPAA | see R9 | `[grounded]` your background | resume_edits_pending_approval |
| W1 | A one-page note on adapting an experimentation program to a care-navigation app with clinical sign-off | see R7b, RR6: narrows the domain gap | `[generic]` role-family pattern | pending your approval |
| Q1 | Ask the RR1–RR6 verification questions in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app"; the call was refused (WebSearch permission not granted). This would have settled RR1 and role reality's Organization row |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary 2026"; the call was refused. This would have given a market pay band for RR2 and a market-calibration line |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save all of this as a `tuesday-dossier.md` file for later steps if you want.

## Upgrade menu

- Allow web search, or paste the live posting's URL → RR1 closes and the decision can move to `go`; a market pay band fills RR2.
- Your pay floor, location and remote needs → RR2 and RR3 checked against you; hard-gate rows created.
- An answer to G1 or G2 → R6 or R8 resolves.
- A redacted metrics memo, a LookML or metrics-dictionary excerpt, or a pricing-test readout → R3, R4, R5 or R6 can rise to `high`.
- The hiring manager's name → sharper positioning in the application plan.
- A deeper research pass on Harborlight (funding, leadership turnover, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1: Did you define the metrics behind those governed dashboards, for example writing the LookML model or settling what "churn" meant across teams? What part was yours?

G2: Have you coached or reviewed the work of other analysts, even informally, such as code reviews, test-design reviews or onboarding?

RR2/RR3: What's your pay floor, and do you need remote, hybrid or a specific location?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.