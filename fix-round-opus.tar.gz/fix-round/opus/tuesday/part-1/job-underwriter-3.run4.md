Now the files named for Step 1.
## Decision snapshot

**No, don't pursue this one, and you're right that something is off. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, 5 days a week), R2 (Base compensation of $70–85k)
- `must_have`: direct: R3, R5, R6 · unclear: R4 (8+ years growth leadership), R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops)
- `important`: adjacent: R11 (Team of one, hands-on execution) · unclear: R12 (B2B / merchant-facing growth motion)

R1, R2: these decide it, whatever happens on the other rows; R7, R8, R9, R10: the parts of the bundled mandate your background doesn't mention, which only matter if a gate moves.

**Opportunity ledger.** The posting has problems apart from your fit. The pay conflicts with your floor (RR1) and looks low for the mandate (RR2). The location conflicts with your remote-only rule (RR3). It folds about seven functions into one person (RR4) with no stated budget or authority (RR5), expects evenings and weekends (RR6), and gives no success metrics (RR7). Equity is undefined (RR8) and the employer is unverified (RR9). One entry points the other way: it says it has been profitable since day one and reports to the CEO (RR10).

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week), R2 (Base compensation of $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR3 (`severity: high`).
- **What would have to be different:** Novaline would have to offer the role fully remote (R1, RR3) **and** pay a base of at least $150k, which is $65k above the top of its posted range (R2, RR1). The posting says "no exceptions" on location, so only the employer can change these terms.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup at Series A that says it has been profitable since day one | `[grounded]` JD header; not verified (see RR9) |
| Mandate | Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting | To the CEO, with a dotted line to the board | `[grounded]` JD |
| Team and resources | "A team of one to start." No budget, headcount plan or decision rights stated | `[grounded]` JD; silence on budget `[grounded]` |
| Working pattern | On-site in Austin, 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity terms given | `[grounded]` JD |
| First-year outcomes | Not stated: "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | A "Head of" title and an 8+ year bar sit on a solo seat covering roughly seven functions, at a base well below what the title and years usually pay | `[inferred]` from the JD's title, years bar and function list against its stated base and team size |
| Market calibration | Not produced: the role-family search was refused (see Evidence status) | — |
| Unknowns | Equity terms; marketing budget; hiring plan; what the board's dotted line means in practice; how success is measured | — |
| Contradictions | "Profitable since day one" alongside a $70–85k base for the most senior growth hire. This is a tension inside the posting, not a contradiction between two sources | `[inferred]` from the two JD statements together |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit: remote-only, living in Portland, not relocating. The gate fails because the JD calls the on-site rule "no exceptions" | `[grounded]` JD quote and your stated constraint | Only Novaline changing its terms resolves this |
| R2 | Base compensation of $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor of $150k base. The gate fails because the top of the posted range is $65k below that floor | `[grounded]` JD figure and your stated constraint | Only Novaline changing its terms resolves this |
| R3 | Own all revenue growth end to end, reporting to the CEO | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled, as Head of Growth. This is self-report, specific but with nothing inspectable yet, so expect a probe | `[grounded]` your background | none, given `no_go` |
| R4 | 8+ years growth leadership | must_have | unclear | medium | discovery | Nine years in growth, as growth lead and then Head of Growth. You didn't say how many of the nine were in a leadership title, so the 8+ bar isn't settled | `[grounded]` your background, which doesn't give the split | see G1 |
| R5 | Paid acquisition | must_have | direct | medium | none | You say you owned paid. Self-report only so far | `[grounded]` your background | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and are deep in Braze. Self-report only so far | `[grounded]` your background | none |
| R7 | SEO/content | must_have | unclear | none | discovery | Your background doesn't mention it | `[grounded]` your background is silent | see G2 |
| R8 | Brand and PR | must_have | unclear | none | discovery | Your background doesn't mention it | `[grounded]` your background is silent | see G2 |
| R9 | Partnerships | must_have | unclear | none | discovery | Your background doesn't mention it | `[grounded]` your background is silent | see G2 |
| R10 | Sales ops | must_have | unclear | none | discovery | Your background doesn't mention it. Your experience is in B2C subscription, where a sales function may not have existed | `[grounded]` your background is silent; `[inferred]` from B2C subscription that a sales function may have been absent | see G2 |
| R11 | Team of one, hands-on execution | important | adjacent | medium | transferability | You built and managed teams of 3–7, which is leadership rather than solo execution. Being deep in SQL, GA4 and Braze suggests hands-on skill. The limit is that nothing so far shows you running every channel yourself | `[grounded]` your background; `[inferred]` hands-on depth from the tool depth you described | see G3 |
| R12 | B2B / merchant-facing growth motion | important | unclear | none | discovery | Requirement inferred: "e-commerce enablement" plus "sales ops" points to selling to businesses. Both of your companies were B2C subscription | `[inferred]` requirement from the JD's sector and sales-ops line; `[grounded]` your B2C background | see G4 |

## Gap recovery queue

All of these gaps are moot unless R1 and R2 move. They are recorded here so that a similar role can reuse them.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leadership years (R4, must_have) | discovery | Nine years in growth, with two titled leadership roles, but no dates for each title | A literal reading of "8+ years leadership" checks titled years | Years as growth lead counted alongside years as Head of Growth; any earlier role where you led a channel or a person | A resume with dates for each title | `[grounded]` your background has no dates; `[generic]` that postings with titled-years bars are often screened literally |
| G2 | SEO/content, brand, PR, partnerships, sales ops (R7, R8, R9, R10, must_have) | discovery | Your background doesn't mention any of these | They make up most of the mandate; any one could be probed | Owning an SEO or content program; working with a PR agency on a launch; a channel or affiliate partnership deal; building pipeline reporting in a CRM | A content performance dashboard, a press plan, a partnership agreement summary | `[grounded]` your background is silent |
| G3 | Solo execution (R11, important) | transferability | You managed teams of 3–7; solo execution isn't shown | A team of one means doing the work rather than directing it | Periods before your team was hired; channels you ran personally; SQL analyses you built yourself | Queries or dashboards you built, experiment write-ups you authored | `[inferred]` from team size against the JD's "team of one" |
| G4 | B2B motion (R12, important) | discovery | B2C subscription only | Selling to merchants usually involves sales-assisted funnels | B2B2C partnerships; a self-serve business tier; any sales-assisted funnel | Funnel reporting for a business segment | `[generic]` B2B growth pattern; `[inferred]` requirement from the JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay conflicts with your $150k floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The top of the posted range is $65k below your floor | `[grounded]` JD figure and your stated floor | Is the base range firm, or is there room above $85k for this role? | confirmed |
| RR2 | Pay looks low for the seniority and mandate | risk_signal | medium | "8+ years growth leadership required … $70–85k base" | The posted base may be priced for a mid-level marketer while the role requires a senior leader, with equity filling the gap. Not confirmed, because the market search was refused | `[inferred]` from the JD's own years bar and mandate against its stated base | How did you set the base range for this role, and what is it benchmarked against? | unresolved |
| RR3 | On-site only, which conflicts with your remote-only rule (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out remote work | `[grounded]` JD | Is there any remote arrangement for this role? | confirmed |
| RR4 | Several specializations bundled into one role | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one" | Several full-time roles' worth of work folded into one seat | `[inferred]` from the function list against "team of one" | What share of your time do you expect on each function in the first six months, and which would you drop if they conflicted? | unresolved |
| RR5 | Responsibility with no stated budget, authority or hiring plan | unknown | — | "Own all revenue growth end to end … team of one to start" | You may be accountable for revenue without a set budget or approved hires | `[inferred]` from the scope language against the JD's silence on resources | What marketing budget and headcount are approved for the first year, and who signs off on spending? | unresolved |
| RR6 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work presented as culture rather than occasional | `[inferred]` from the JD's phrasing | In the last quarter, how many evenings or weekends did the team work, and what triggered them? | unresolved |
| RR7 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability to the CEO and board with no fixed definition of success | `[inferred]` from the JD's revenue mandate against its silence on metrics | What number would make this hire a success at 12 months, and who sets it? | unresolved |
| RR8 | Equity not defined | unknown | — | "meaningful equity upside" | The equity may not make up for the low base; no grant size, vesting terms or valuation given | `[inferred]` from the undefined term | What percentage or share count is offered, at what strike price, on what vesting schedule? | unresolved |
| RR9 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The check could not run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR10 | Says it is profitable and reports to the CEO | positive_signal | — | "profitable since day one … Report to the CEO" | If true, runway risk is lower and the role sits close to decisions | `[grounded]` JD states it, but it is not verified | What does profitability look like today in revenue and margin terms? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | See R1, R2, RR1, RR3 | `[grounded]` evidence map and register | pending your approval |
| A2 | If Novaline contacts you, ask RR1's and RR3's questions before any interview | Both gates are settled by those two answers | `[grounded]` RR1, RR3 | pending your approval |
| A3 | If you go ahead anyway, ask the questions for RR2 and RR4 through RR8 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: the constraint claims in R1 and R2 (your own stated limits). Unverified leads: the background claims behind R3, R4, R5, R6 and R11 are self-report. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth" and the search was refused. It would have confirmed the company and the live posting (RR9, the Organization row) |
| 2. Role-family sweep | unavailable | Searched "Head of Growth startup Series A base salary 2026" and the search was refused. It would have produced the market calibration line and confirmed or cleared RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given (the CEO isn't named), so there was nothing to search |

I can save this as a `tuesday-dossier.md` file if you want a record of it.

**Upgrade menu**
- Allow web search → RR9 can be checked, RR2 confirmed or cleared, and the market calibration line filled in. This will not move R1 or R2.
- A resume with dates for each title → closes G1 (R4).
- A deeper research pass on Novaline (funding, leadership churn, employee reports; up to 5 more searches and 2 more fetches). It is unlikely to change a decision set by two failed gates, but say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.