I'm checking Brindlemoor and the role against public sources before giving you the full go/no-go.
# Job underwriting: Senior Pricing Analyst at Brindlemoor

## Decision snapshot

**Yes, go for it, but first find out where the job is actually based. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Working location: fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8a · adjacent: R10 (Pet-insurance pricing knowledge) · unclear: R8b (Recommendations to product)
- `preferred` — direct: R9

R10 — a real bridge from motor, with its limit named; R8b — no evidence either way yet; R1 — the one row that could flip the answer.

**Opportunity ledger.** The posting you pasted says "Fully remote (UK)" but Brindlemoor's own careers page says Leeds four days a week (RR1). Salary isn't stated (RR2), and the company's size and stage aren't established (RR3). It's unclear whether "own pricing analytics" means a team or one person (RR5). One entry runs the other way: the hiring manager's public work is on exactly the model-monitoring side of the role (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Working location: fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern resolves to something you'll accept — R1, RR1; (2) the salary clears your floor — RR2; (3) R10 is framed honestly as motor pricing that transfers, never as pet experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described in the posting as an insurtech with a pet-insurance product | `[grounded]` JD header; `[grounded]` careers page exists at brindlemoor.co.uk |
| Mandate | Build and monitor rating models, design and read price tests, and make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing, named as Odile Varga | `[grounded]` JD and careers page |
| People management | The JD asks for none, and the requirements list no line-management experience | `[grounded]` JD |
| Scope read | A single-product pricing remit reporting to a director, with "own" suggesting you'd be the main pricing analyst for this product | `[inferred]` from "Own pricing analytics for our pet-insurance product" |
| Hiring manager's footprint | Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books; previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile, search snippet only |
| Market calibration | UK senior pricing analyst, insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900. This is a benchmark, not Brindlemoor's offer | `[generic]` Pricewell 2026 pay survey (n=612), search snippet only |
| Unknowns | Salary; team size; company stage and size; whether the role has reports | — |
| Contradictions | The JD you pasted says "Fully remote (UK)". The live careers page says "Leeds office four days a week". Both are recorded; neither is assumed correct | `[grounded]` pasted JD; `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Working location: "Fully remote (UK)", against the careers page's "Leeds office four days a week" | hard_gate | unclear | none | hard_gate | You haven't said where you're based or what pattern you'd accept, and the employer's two sources disagree on the terms | `[grounded]` JD against careers page; your background is silent on location | Closing question R1; RR1's question to the recruiter |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific but self-reported, with nothing to inspect yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". Specific and self-reported; expect a technical probe | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for your young-driver book | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | Upgrade menu: a sanitized review deck |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with the underwriting team. Your role in designing them versus reading them isn't separated yet | `[grounded]` your background | Upgrade menu: a test readout |
| R7 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers build. "Maintained" is your word: how you monitored the model isn't stated, so this cell doesn't claim monitoring | `[grounded]` your background | Plan P1 |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | Tests run with underwriting, and a quarterly review to its head | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | important | unclear | none | discovery | Nothing you've said mentions a product team either way | `[grounded]` your background is silent on product | Closing question G2 |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance pricing knowledge | important | adjacent | medium | transferability | You've said you've never worked on pet. GLM rating, price testing and underwriting stakeholders carry over. The limit is that pet risk drivers (breed, age, vet-cost inflation, cover type) are a different rating structure from motor | `[grounded]` your background; `[inferred]` requirement from "our pet-insurance product"; `[generic]` the pet rating factors named | See G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working location (R1, hard_gate) | hard_gate | Your location and acceptable pattern are unknown, and the employer's sources contradict each other | It's the only row that could turn this into a no | — | The recruiter's written answer | `[grounded]` JD against careers page |
| G2 | Recommendations to product (R8b, important) | discovery | Your recommendations go to underwriting. Product isn't mentioned | It's a stated part of the mandate, and an answer turns an unclear row into an example you can use | Working with a product or proposition team on cover options, excess levels, or the price of a new tier; feeding test results into a product launch; a pricing input to a broker or aggregator channel decision | A sanitized recommendation paper, or an email summary of an agreed change | `[grounded]` your background is silent; `[inferred]` that it strengthens the application |
| G3 | Pet-insurance knowledge (R10, important) | transferability | Strong motor GLM and testing record; no pet exposure | The most likely objection to you as a candidate | Rating a sub-book with its own factor structure, like young drivers; handling claims inflation in your models; any non-motor line you touched | A one-page note on how you'd approach a pet rating model (plan W1) | `[grounded]` your background; `[generic]` that domain-switch candidates get probed on this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One version is stale, or the posting you saw was rewritten by a third party | `[grounded]` both texts; `[generic]` that aggregator copies drift from the source | Is this role fully remote, or based in Leeds four days a week as your careers page says? | unresolved |
| RR2 | Salary not stated | unknown | — | No figure in the JD | It may sit inside the benchmark range in role reality, or the company may just not publish salaries | `[inferred]` from the posting's silence, against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Company stage and size not established | unknown | — | "Brindlemoor (insurtech)" | Small insurtechs often have a thin public footprint. A company-name search returned nothing beyond the careers page and the hiring manager's profile | `[grounded]` search results; `[generic]` the pattern | How large is the business, and how is it funded? | unresolved |
| RR4 | Hiring manager is a specialist in model monitoring | positive_signal | — | Talk: "Small Books, Loud Errors" | Pricing is led by someone with deep analytics experience who will value monitoring discipline | `[grounded]` public profile snippet | How do you monitor the pet rating model today? | noted |
| RR5 | Ownership with no team stated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only pricing analyst on the product, which means wide scope and no peer review | `[inferred]` from "own" against the JD's silence on team size | How many people work in pricing, and who would review my models? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the young-driver GLM you built and maintained. Before you do, write down how you actually checked it kept performing. If you have a real answer, it fits this reader's public work; if you don't, don't imply one | see R4, R7, RR4 | `[grounded]` your background and the hiring manager's profile | pending your approval |
| P2 | Ask the recruiter RR1's question before investing time in an application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| P3 | Frame pet as a bridge: "I've priced motor, including a young-driver book with its own GLM; I haven't priced pet cover yet." Use that, not "insurance pricing across lines" | see R10 | `[grounded]` your own words | pending your approval |
| P4 | Put 14 price tests last year front and centre, with your part in designing versus reading them stated precisely | see R6 | `[grounded]` your background | pending your approval |
| W1 | Optional one-page note on how you'd approach a pet rating model | see R10, G3 | `[generic]` that a short sample can narrow a domain gap | pending your approval |
| Q1 | Ask the verification questions from RR1 to RR5 word for word in the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

Not managing anyone yet isn't a gap for this role: the JD asks for none (role reality). RR5 checks whether that's actually true.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved R1, RR1, RR3 and the contradictions row |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary 2026 remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Snippet only, page not fetched. Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Snippet only. Moved the hiring manager row, RR4 and P1 |

---

I can turn all this into a `tuesday-dossier.md` you can keep and reuse later, whenever you'd like.

**Upgrade menu**
- Your location and the working pattern you'd accept → R1 resolves and the decision firms up to `go` or `no_go`.
- Your salary floor → RR2 can be set against the £52k–£65k range.
- The link where you found the "Fully remote" version → shows which source in RR1 is stale.
- A sanitized quarterly pricing-review deck or a price-test readout → R5 and R6 move to `high`.
- An answer to G2 → R8b resolves.
- A deeper research pass on Brindlemoor (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Just say if you want it.

**Questions**

R1 — Where are you based, and would Leeds four days a week work for you, or is fully remote a must?

RR2 — What's the lowest base salary you'd move for?

G2 — Have any of your test results or pricing reviews led to a change a product or proposition team owned, such as a cover option, an excess level or a new tier? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.