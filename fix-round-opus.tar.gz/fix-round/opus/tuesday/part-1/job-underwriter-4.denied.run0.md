Now the referenced files for Step 1.
**Should you go for it? Yes, but check two things first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R7, R8, R9a · unclear: R9b (Recommendations for product)
- `important`: adjacent: R10 (Pet-insurance pricing domain)
- `preferred`: direct: R6

R10: your pricing methods carry over, but you haven't worked in this kind of insurance; R9b: no evidence yet of recommendations made to a product team; R7 (`medium`): who designed the tests and who read the results still needs confirming.

**Opportunity ledger.** Nothing about the employer has been checked yet, so none of it is a concern so far. Brindlemoor itself couldn't be verified (RR1), the salary isn't given (RR2), and the posting doesn't say whether the senior title includes managing people (RR3). One entry is a good sign: the hiring manager is a dedicated Director of Pricing (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and a live posting are confirmed (RR1); (2) you're UK-based with the right to work here (R1); (3) the move from motor to pet pricing is presented as related experience, not as pet-insurance expertise (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not checked against any outside source (RR1) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | An individual-contributor role that owns pricing for one product. The JD mentions no reports, team or budget | `[inferred]` from the responsibilities list and its silence on people |
| Management | Not a stated requirement. "Senior" here is about level, and the JD asks for no management experience | `[grounded]` JD requirements list |
| Unknowns | Salary; whether the role includes mentoring or managing anyone; whether the rating model exists or is built from scratch; who sits on the product side | — |
| Contradictions | None inside the JD. Not checked against a careers page, because research couldn't run | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK): UK-based, with the right to work here | hard_gate | unclear | low | hard_gate | Your current job at a UK motor insurer suggests you meet it, but you haven't stated your location or right to work | `[inferred]` from your UK employer | Question R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst. Clears the bar; you stated it, but there's no document to check | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used "daily", as you put it. Specific, but nothing to check yet | `[grounded]` your background | Have a code or query example ready for a technical round |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which matches the requirement almost word for word | `[grounded]` your background | none |
| R6 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. Your wording leaves open which parts were yours (design, reading the results) and which were underwriting's. Kept at `medium` until you confirm | `[grounded]` your background; `[generic]` that interviewers for this kind of role ask who owned the test design | Question G2 below |
| R8 | Build and monitor rating models | must_have | direct | medium | none | Building the young-driver GLM covers "build". Maintaining it is close to "monitor", but monitoring work isn't spelled out | `[grounded]` your background | Be ready to describe how you tracked model performance |
| R9a | Recommendations for underwriting | must_have | direct | medium | none | Your quarterly review to the head of underwriting and the tests you ran with underwriting both point to this | `[grounded]` your background | none |
| R9b | Recommendations for product | must_have | unclear | low | discovery | Your background mentions underwriting but not product. Product-side work may exist and just not be mentioned | `[grounded]` your background is silent on product | Question G1 below |
| R10 | Pet-insurance pricing domain | important | adjacent | medium | transferability | The GLM, price-test and stakeholder skills carry straight over. You said you've never worked on pet insurance. Limit: pet pricing uses different rating factors (species, breed, age at entry) and different claims drivers, such as vet-fee inflation and lifetime vs. annual cover | `[grounded]` you have no pet exposure; `[generic]` how pet rating factors differ from motor | See G3 in the queue; frame as related experience |

R10 is `[inferred]` as a requirement: the JD names pet insurance as the product but doesn't ask for pet experience.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations for product (R9b, must_have) | discovery | Underwriting is clearly your audience; product isn't mentioned | Closing R9b leaves only R10 below `direct` among the non-gate rows | Price changes that fed a product or proposition change; work with a product, digital or proposition team on quote journeys, add-ons or cover options; test results that changed what a product offered rather than what it charged | A deck slide or a meeting note, with confidential details removed | `[grounded]` your background is silent on product |
| G2 | Ownership of price tests (R7, must_have) | discovery | 14 tests run "with the underwriting team", with no split of who did what | The JD asks you to design and read tests yourself, so the split decides how strongly you can claim this | Choosing test cells and sample sizes; setting success metrics; calling results and recommending a rollout | A test plan or results summary, with confidential details removed | `[grounded]` your wording; `[generic]` that interviews probe who owned the design |
| G3 | Pet-insurance domain (R10, important) | transferability | Only motor pricing | Makes the case for related experience and states its limits | Any non-motor lines you've touched; work on renewal or retention pricing, or on lifetime-value pricing; any reading or analysis of pet-market pricing | A short note on how you'd adapt a motor GLM to pet rating factors | `[inferred]` bridge from your motor GLM work; `[generic]` pet rating differences |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have much public footprint, the posting may be old or copied by a job aggregator, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not given | unknown | — | (no figure in the posting) | The pay may sit below the senior band, or the company may simply not publish salaries | `[inferred]` from the missing figure | What salary range is budgeted for this role? | unresolved |
| RR3 | Unclear whether the role includes managing people | unknown | — | "Senior Pricing Analyst" | The role may be purely hands-on, or it may expect you to mentor or manage junior analysts | `[generic]` "senior" titles vary on this | Does this role have direct reports or mentoring duties, now or planned? | unresolved |
| RR4 | Hiring manager is a dedicated Director of Pricing | positive_signal | — | "Odile Varga, Director of Pricing" | Pricing is a separate function with its own leadership, so your work would be reviewed by a pricing specialist | `[inferred]` from the title | How is pricing's remit split with underwriting and product? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with "Built and maintained the GLM rating model for our young-driver book", in your own words, not "owned" | see R4, R8 | `[grounded]` your background | pending your approval |
| E2 | Keep "ran 14 price tests last year with the underwriting team" as written until G2 is answered. Don't change it to "designed" | see R7 | `[grounded]` your background | pending your approval |
| P1 | Present pet insurance as new to you but methodologically close: the same GLM and test skills applied to a new set of rating factors | see R10 | `[grounded]` you have no pet exposure | pending your approval |
| A1 | Confirm the posting is live on Brindlemoor's own site before you put in application effort | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions for RR1–RR4 word for word during the interviews | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Brindlemoor pet insurance careers" was refused because web search permission isn't granted. It would have checked that the employer exists and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | The search "senior pricing analyst UK insurance salary 2026" was refused. It would have given a market salary band to set against RR2, plus the market calibration line |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have shown which of your stories to lead with for this reader |

If you'd like, I can save all of this as a `tuesday-dossier.md` to carry into later prep.

**Upgrade menu**
- A link to the live posting on Brindlemoor's site → RR1 resolves, and the employer condition comes off the decision.
- Allowing web search → targets 1–3 run, and you get a salary band for RR2. A deeper pass after that (funding, leadership changes, news; up to 5 more searches and 2 more fetches) is available if you say so.
- Your salary floor and any non-negotiables → hard-gate checks against your own constraints.
- A test plan or results summary with confidential details removed → R7 rises to `high`.

**Questions**

R1: Are you UK-based with the right to work here without sponsorship?

G1: Have any of your pricing results turned into recommendations for a product or proposition team, rather than underwriting? What changed as a result?

G2: For those 14 tests, which parts were yours: choosing the test cells, setting the success metric, or calling the result?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.