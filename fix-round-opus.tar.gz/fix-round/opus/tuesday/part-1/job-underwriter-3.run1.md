Let me read the required references.
**No, this one isn't worth pursuing. Both of your hard constraints fail: R1 (on-site in Austin) and R2 (the pay). Status: `no_go`.** Your sense that something is off also holds up when you go through the posting line by line; the risk register below shows where.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, 5 days a week), R2 ($70–85k base)
- `must_have`: direct: R3, R4, R5, R6 · unclear: R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops)
- `important`: adjacent: R11 (Hands-on solo execution, team of one), R12 (Growth in an e-commerce enablement business)

R1, R2 fail on the job's terms, not on your experience; R7, R8, R9, R10 aren't in your background as you gave it, but that doesn't mean they're missing; R11, R12 are close fits whose limits are named in the map.

**Opportunity ledger.** The posting looks like several jobs priced as one junior job. It asks for 8+ years of leadership at a base well below senior pay (RR3). It folds seven functions into a team of one (RR4) and gives you all of revenue with no stated budget or authority (RR5). It expects evenings and weekends (RR6), defines no success metrics (RR7) and puts no number on the equity (RR8). Novaline itself could not be verified in this session (RR9). One point runs the other way: you'd report to the CEO with a line to the board, at a company that says it's profitable (RR10).

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week), R2 ($70–85k base)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** two things would both have to change. Novaline would have to offer the role fully remote from Portland, which the posting rules out with "no exceptions". It would also have to pay at least $150k base. Your other route is revising one of your own non-negotiables, which is your call to make.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline: e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting; not checked against any outside source (RR9) |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and reporting | "A team of one to start"; reports to the CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" | `[grounded]` posting |
| First-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | Seven growth functions with nobody to delegate to. In practice that's a hands-on generalist job with a leadership title | `[inferred]` from the function list against "team of one" |
| Market calibration | Not established. The pay-range search was blocked in this session (Evidence status, target 2) | — |
| Unknowns | Budget, decision rights, equity terms, what the board line means day to day, how success is judged | — |
| Contradictions | "8+ years growth leadership required" beside "team of one": senior leadership is required, but there's nobody to lead | `[inferred]` from the two posting lines read together |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own constraint (remote-only, staying in Portland), which is specific and stated. The fit fails because the posting rules out any exception | `[grounded]` posting and your stated constraint | Only a change of terms resolves it, from Novaline or from you |
| R2 | $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor, which is specific and stated. The fit fails because the top of the range, $85k, is $65k below your floor | `[grounded]` posting and your stated constraint | Only a change of terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | 9 years in growth, as Growth Lead then Head of Growth. You didn't split the years between the two titles, so expect a probe on how many were leadership years | `[grounded]` your intake | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You stated you owned paid at two B2C subscription companies; nothing inspectable yet | `[grounded]` your intake | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You stated you owned lifecycle and work deeply in Braze; nothing inspectable yet | `[grounded]` your intake | none |
| R6 | Own revenue growth at scale | must_have | direct | medium | none | $8M→$40M ARR over three years, with a budget you controlled. Your stated scope was paid, lifecycle and experimentation, not all seven functions | `[grounded]` your intake | none |
| R7 | SEO/content | must_have | unclear | low | discovery | Your intake doesn't mention it either way | `[grounded]` intake silent | see G1 |
| R8 | Brand and PR | must_have | unclear | low | discovery | Your intake doesn't mention it either way | `[grounded]` intake silent | see G1 |
| R9 | Partnerships | must_have | unclear | low | discovery | Your intake doesn't mention it either way | `[grounded]` intake silent | see G1 |
| R10 | Sales ops | must_have | unclear | low | discovery | Your intake doesn't mention it either way | `[grounded]` intake silent | see G1 |
| R11 | Hands-on solo execution across functions (implied by "team of one") | important | adjacent | medium | transferability | You led teams of 3–7 and are hands-on in SQL, GA4 and Braze. Limit: your intake doesn't show a period of running several functions with no team | `[inferred]` requirement from "team of one"; `[grounded]` your intake | see G2 |
| R12 | Growth in an e-commerce enablement business | important | adjacent | medium | transferability | Your history is two B2C subscription companies. Limit: "enablement" plus "sales ops" suggests a business-buyer sales motion your intake doesn't show | `[inferred]` requirement from "e-commerce enablement" and "sales ops" in the posting | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand/PR, partnerships, sales ops (R7, R8, R9, R10, must_have) | discovery | Your intake covers paid, lifecycle and experimentation only | It wouldn't move this decision, because R1 and R2 decide it. It matters for future Head of Growth postings that list the same functions | Owning a content or SEO roadmap; managing an agency for PR; running co-marketing or affiliate deals; owning CRM pipeline hygiene for a sales team | A channel-mix dashboard, a partnership one-pager, a content performance report | `[grounded]` intake silence; `[inferred]` that these recur in similar postings |
| G2 | Solo execution (R11, important) | transferability | Team leadership 3–7; hands-on tooling | Same: no effect on this decision | A period before your first hire; covering a gap between hires | A launch you shipped end to end yourself | `[grounded]` intake |
| G3 | E-commerce enablement / business-buyer motion (R12, important) | transferability | Two B2C subscription companies | Same: no effect on this decision | Any B2B2C or merchant-facing programme; work alongside a sales team | A funnel spec covering a sales handoff | `[inferred]` from the posting's sector and sales-ops line |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base below your floor (see R2) | red_flag | high | "$70–85k base" | No offer in this range reaches $150k | `[grounded]` posting and your floor | Is the base range firm, or is there a separate senior band for this role? | confirmed |
| RR2 | Location conflicts with remote-only (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out remote work outright | `[grounded]` posting | Is there any path to a fully remote arrangement for this role? | confirmed |
| RR3 | Seniority–pay mismatch | risk_signal | medium | "8+ years growth leadership required" / "$70–85k base" | Senior years and a "Head of" title priced at a junior level. It stays a risk signal because the market band wasn't established | `[inferred]` from the years and title against the stated range | How did you arrive at this range for a role requiring 8+ years of leadership? | unresolved |
| RR4 | Several specialist roles folded into one | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops … team of one" | Seven functions with no team and no stated hiring plan | `[inferred]` from the function list against "team of one"; `[generic]` that this pattern usually comes junior-priced | Which of these seven functions get headcount in the next 12 months, and when? | unresolved |
| RR5 | Responsibility without stated authority or resources | risk_signal | medium | "Own all revenue growth end to end" | You could be accountable for revenue with no budget or decision rights | `[inferred]` from the scope language against silence on budget | What budget does this role control, and which spend decisions does it make alone? | unresolved |
| RR6 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work is framed as part of the culture, not as an exception | `[grounded]` posting | In the last quarter, how often did "when it matters" happen? | unresolved |
| RR7 | No success metrics for a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Full accountability, with the measure of success still to be defined | `[grounded]` posting | What would make this hire a success at 6 and 12 months? | unresolved |
| RR8 | Equity unquantified | unknown | — | "meaningful equity upside" | The equity may or may not make up for the base gap. It is unknowable without numbers | `[inferred]` from the posting's undefined equity | What percentage, strike price, vesting terms and latest valuation come with the grant? | unresolved |
| RR9 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR10 | Direct CEO line and stated profitability | positive_signal | — | "Report to the CEO with a dotted line to the board" / "profitable since day one" | Real seniority of access, and a company not dependent on its next funding round | `[grounded]` posting | What has profitability made possible that a funded-only startup couldn't do? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort here | see R1, R2, RR1, RR2 | `[grounded]` map and register | pending your approval |
| A2 | If you go ahead anyway, ask the RR1 and RR2 questions before any interview loop | Those two decide the outcome before fit does | `[grounded]` register | pending your approval |
| A3 | Reuse the RR3–RR8 questions as a first-call screen on similar Head of Growth postings | They target the patterns that made this one feel off | `[inferred]` from this register | pending your approval |

## Evidence status

Verified: R1, R2, which are your own statements of your constraints. The claims behind R3–R12 are unverified leads from your intake.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin". The call was refused by this session's permissions. It would have set role reality's Organization row and cleared or confirmed RR9 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026". The call was refused by this session's permissions. It would have filled the market calibration row and confirmed or reduced RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can save this assessment as `tuesday-dossier.md` for later sessions if you'd like.

**Upgrade menu**
- Allow web search: confirms whether Novaline and this posting are real (RR9) and gives a market pay range to set the $70–85k against (RR3).
- Your resume: firms up R3–R6 and may close G1 for future postings.
- Equity numbers from Novaline: resolve RR8.
- A deeper research pass on Novaline (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

No questions this turn. Nothing you could answer would change R1 or R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.