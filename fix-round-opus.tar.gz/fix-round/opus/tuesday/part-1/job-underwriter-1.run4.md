Quick update: I've read the job-underwriter playbook and now I'm running the default research pass (company check + market sweep) before writing your assessment.
You fit this role strongly, and I'd apply once two quick checks clear. The assessment is below, with the summary first. The searches I tried to run to check the company were refused permission, so nothing here about Harborlight comes from research.

## Decision snapshot

**Yes, apply. You fit well: R1, R2, R3, R4 and R5 are all `direct`. Apply once the employer and your own terms check out. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important`: direct: R7a · adjacent: R7b (Partner with clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R6: one answer from you likely makes this `direct`; R8: the one duty with nothing behind it yet; R7b, R9: the healthcare bridge, with its limit stated.

**Opportunity ledger.** Not checked yet. I couldn't confirm the employer (RR1), and the posting doesn't state pay (RR2) or location (RR3). On the plus side, the scope is concrete and well defined (RR4), and the role puts analytics next to clinical decisions (RR5).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight and this posting turn out to be real and live (RR1); (2) the pay and location work for you (RR2, RR3); (3) you present R8 mentoring and the R9 healthcare bridge honestly, at the strength the evidence supports.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a Series C digital-health scale-up with about 400 people | `[grounded]` JD header; not verified (RR1) |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two juniors | `[grounded]` JD |
| Scope read | One person who both builds and leads: you own the analytics function's output and grow two juniors, but there's no line saying you manage them | `[inferred]` from "mentor" rather than "manage" and the title "Senior" rather than "Lead" |
| First-year outcomes | Not stated | `[grounded]` JD is silent |
| Market calibration | Not established. The role-family search couldn't run, so I'm not giving a pay band | — |
| Unknowns | Pay; location or remote policy; who the role reports to; whether "metrics layer" means LookML, dbt or something else; how mature their experimentation platform is | `[grounded]` JD is silent on each |
| Contradictions | None inside the JD; it couldn't be checked against a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years against five or more, specific but self-reported. `medium` is the ceiling on a first pass | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" for six years. Expect a live SQL exercise | `[grounded]` your background; `[generic]` that senior analyst loops usually include one | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ tests a year on about 2M subscribers, including the pricing test behind an 11% retention lift | `[grounded]` your background | Have the pricing test's design ready (power, guardrails, duration); a write-up would raise this to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your background | A screenshot or the LookML structure (sanitized) would raise this to high |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product every month | `[grounded]` your background | A redacted memo is the artifact that raises this to high |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | "Governed dashboards" on an instance you built suggests you owned the definitions, but your background doesn't actually say so. Credited only as adjacent until you say whether you defined the metrics | `[inferred]` from "governed" and "built from scratch" | G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | Monthly VP Product presentations, plus a pricing test that changed the product | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | You have translated analysis for non-technical leaders, but never for clinicians | `[grounded]` background, no clinical partners; `[generic]` that clinical stakeholders weigh patient safety and outcomes differently from commercial ones | G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your background says nothing about mentoring or leading people | `[grounded]` background is silent | G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model. That is regulated-PII work, but not PHI under HIPAA | `[grounded]` your background; `[generic]` that HIPAA adds PHI-specific rules (business associate agreements, de-identification standards) that consumer privacy work doesn't cover | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | A Looker instance and governed dashboards, but no statement that you wrote or own the metric definitions | It's the first duty the JD lists. If it becomes `direct`, the whole `must_have` tier is `direct` | Writing the LookML model or explores; settling how "active subscriber" or "churn" is defined across teams; a metrics dictionary or certification process; dbt models feeding Looker | A sanitized LookML file tree, a metric dictionary page, a definition-change log | `[grounded]` the background doesn't say; `[inferred]` that this moves R6 |
| G2 | Mentoring (R8, important) | discovery | Nothing | A named, ongoing duty with two people attached, so interviewers will ask about it | Onboarding a new analyst; reviewing others' SQL or test designs; teaching PMs to use self-serve Looker; an intern; running an analytics guild | A review checklist, onboarding doc, or a peer's or manager's comment | `[grounded]` the background doesn't say |
| G3 | Clinicians and HIPAA (R7b, R9) | transferability | **Carries over:** explaining analysis to non-technical execs; modelling consent and PII. **Limit:** no clinical partners, no PHI, no healthcare outcome metrics. **Strengthener:** say plainly that you haven't worked in healthcare, then point to the consent-state model as how you'd handle PHI rules | Two rows rest on this bridge; overstating it falls apart on the first follow-up question | Your own words: "handled GDPR/CCPA consumer PII", "built the consent-state model for our warehouse" | A sanitized schema or design doc for the consent model | `[grounded]` your background; `[generic]` that healthcare interviewers probe PHI handling |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (search permission refused) | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may simply not have been checked yet, the posting may be old or reposted by an aggregator, or rarely it may not be a real employer | `[generic]` pattern, not a claim about this company | Can you share the role's page on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (absent from the JD) | The figure may be below the market band for this scope, or they may just not publish it | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and remote policy not stated | unknown | — | (absent from the JD) | Could conflict with your constraints, which I don't know yet | `[grounded]` JD is silent | Is this remote, hybrid or office-based, and where? | unresolved |
| RR4 | Concrete, coherent scope | positive_signal | — | "define and maintain the metrics layer… build self-serve dashboards in Looker" | The work is clearly defined, and it names the tool you used to build an instance | `[grounded]` JD | What does the metrics layer run on today, and who maintains it? | noted |
| RR5 | Analytics tied to clinical decisions | positive_signal | — | "partner with product managers and clinicians to turn analysis into roadmap decisions" | Analysis is meant to reach real decisions, not just reports | `[grounded]` JD | Which roadmap decision did analytics change most recently? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Open with the experimentation program in your own words: "designed and ran… 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | see R3 | `[grounded]` your background | pending your approval |
| P2 | Second: building the Looker instance and 40+ governed dashboards. Say "metrics layer" only if G1 confirms you owned the definitions | see R4, R6 | `[grounded]` your background | pending your approval |
| P3 | Name the monthly exec metrics memo as proof of written communication | see R5 | `[grounded]` your background | pending your approval |
| P4 | Present healthcare as a bridge, not experience: "no healthcare yet; I handled GDPR/CCPA consumer PII and built our warehouse's consent-state model." Never write "HIPAA experience" | see R9, G3 | `[grounded]` your background | pending your approval |
| P5 | Ask RR1–RR3's questions at the recruiter screen, before spending time on take-homes | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app"; permission refused. It would have confirmed the company's stage, size and product and whether the posting is live, which is what RR1 and the contradictions row wait on |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary 2026"; permission refused. It would have filled the market calibration row and the pay check in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you'd like, I can write this up as a `tuesday-dossier.md` file you can keep.

**Upgrade menu**
- Allow web search → target 1 can clear or confirm RR1, and target 2 can fill the market band for RR2.
- Your pay floor and location needs → hard-gate rows get added and checked against the role.
- An answer to G1 → R6 likely becomes `direct`.
- An answer to G2 → R8 is resolved one way or the other.
- A redacted metrics memo, a test write-up or a LookML snapshot → R3, R4 or R5 rises to `high`.
- The hiring manager's name → sharpens the scope read and which story you lead with.
- A deeper research pass on Harborlight (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

RR2/RR3: What are your non-negotiables: a pay floor, remote or location needs, anything else?

G1: In the Looker build, did you personally define and maintain the metric definitions (LookML model, metric dictionary, certification), or did you mainly build dashboards on a model someone else owned?

G2: Have you ever mentored, onboarded or regularly reviewed the work of other analysts, even informally?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.