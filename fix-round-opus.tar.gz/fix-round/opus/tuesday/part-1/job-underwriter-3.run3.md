Reading the required references.
Quick update: I've read the evaluation playbook. Now I'm running a few searches to check that Novaline exists and to see what this kind of role usually pays.
## Decision snapshot

**No, this one isn't worth pursuing. R1 and R2 are both hard gates and both fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin five days a week), R2 (Base pay meeting your $150k floor)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (SEO/content), R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops)
- `important`: unclear: R10 (Hands-on execution as a team of one)

R1, R2: both fail on the posting's own terms, and no wording changes that. R6, R7, R8, R9: channels your background doesn't mention, which only matters if the gates move.

**Opportunity ledger.** This section answers why it feels off, and it's a separate problem from your fit. Seven functions with no team and no stated budget are priced below your floor (RR1, RR3, RR4). The posting also normalizes evenings and weekends (RR5), refuses to define success (RR6), and leaves the equity unquantified (RR7). Being profitable and reporting straight to the CEO count in its favor (RR9). I couldn't confirm Novaline exists as described because the searches weren't permitted (RR8).

- **Hard gates:** failed: R1 (On-site in Austin five days a week), R2 (Base pay meeting your $150k floor).
- **Severe red flags:** RR1 (`severity: high`), RR3 (`severity: high`).
- **What would have to be different:** Novaline would need to offer fully remote work from Portland (R1, which the posting rules out with "no exceptions") and a base of at least $150k (R2, which is $65k above the top of its posted range). Only the employer can change these terms.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting text; existence not verified (RR8) |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and resources | "A team of one to start"; no budget mentioned | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin, five days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" | `[grounded]` posting |
| Scope read | Seven functions that each usually have their own owner, all held by one person with no team | `[generic]` role-family pattern for bundled growth mandates |
| Market calibration | Not run. The role-family sweep was refused, so there's no sourced salary range here. See RR2 | — |
| Unknowns | Growth budget; equity size and terms; how success is measured; whether the business is B2B or B2C | — |
| Contradictions | The posting asks for 8+ years of leadership and a board-facing mandate, yet the pay sits $65k below your floor. It calls itself profitable since day one while offering cash that low | `[inferred]` from the posting's own terms set against each other |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin five days a week, "no exceptions" (against your remote-only constraint) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint, which is specific and firm. The fit fails because the posting rules out exceptions and you won't relocate from Portland | `[grounded]` posting and your stated constraint | Surface only; it moves only if the employer changes its terms |
| R2 | Base pay of at least $150k (your constraint, against the posted $70–85k) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The top of the posted range is $65k short of it. Equity doesn't count toward a base-pay floor | `[grounded]` posting and your stated constraint | Surface only; it moves only if the employer changes its terms |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | Nine years in growth, as growth lead and then Head of Growth twice. Medium because this is self-reported and unprobed | `[grounded]` your stated background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid, with a budget you controlled, through a scale-up from $8M to $40M ARR | `[grounded]` your stated background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and work deeply in Braze | `[grounded]` your stated background | none |
| R6 | SEO/content | must_have | unclear | low | discovery | Your background doesn't mention it | `[grounded]` silence in your background | Not worth pursuing while R1 and R2 fail |
| R7 | Brand and PR | must_have | unclear | low | discovery | Your background doesn't mention it | `[grounded]` silence in your background | Same |
| R8 | Partnerships | must_have | unclear | low | discovery | Your background doesn't mention it | `[grounded]` silence in your background | Same |
| R9 | Sales ops | must_have | unclear | low | discovery | Your background doesn't mention it. Your two companies were B2C subscription businesses | `[grounded]` your stated background | Same |
| R10 | Hands-on execution as a team of one | important | unclear | low | discovery | You managed teams of 3–7. Whether you've done all the execution yourself isn't stated | `[inferred]` requirement, from "a team of one to start" | Same |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand/PR, partnerships, sales ops (R6, R7, R8, R9, must_have) | discovery | Nothing in your background covers these four channels | It doesn't matter here, because R1 and R2 decide the case. It matters for roles with a similarly broad mandate | Content-led acquisition tests you ran; launch PR you coordinated; affiliate or co-marketing deals | Channel dashboards, launch plans | `[grounded]` silence in your background |
| G2 | Solo execution (R10, important) | discovery | Team leadership is clear; solo execution isn't | Same as G1 | Periods when you ran the function before you hired; hands-on SQL and Braze builds | Query samples, campaign builds | `[inferred]` from the posting's "team of one" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay conflicts with your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted range can't reach $150k without a near-doubling | `[grounded]` posting and your floor | Is the base range firm, or is there budget well above $85k for the right person? | confirmed |
| RR2 | Pay looks low for the seniority asked | risk_signal | medium | "8+ years growth leadership required" | 8+ years of growth leadership usually pays well above this range. Unconfirmed because the salary sweep was refused | `[generic]` role-family pattern, not sourced this run | How did you set the range for this role? | unresolved |
| RR3 | Several full roles folded into one title | red_flag | high | "Own all revenue growth end to end … team of one … we believe in players who don't need a bench" | Seven functions with no team and low pay look like a headcount gap filled with one senior hire | `[grounded]` posting lists the functions; `[generic]` that this pattern usually means low pay | Which of the seven functions do you expect handled in the first six months, and when does hiring start? | unresolved |
| RR4 | Owns all revenue growth, with no budget or authority stated | risk_signal | medium | "Own all revenue growth end to end" | You may carry the revenue number without a growth budget you control | `[inferred]` from the scope language and the silence on budget | What is the annual growth budget, and who approves spend? | unresolved |
| RR5 | Expected to be always on | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work is framed as culture rather than as the exception | `[grounded]` posting | How many weekends last quarter did "when it matters" cover? | unresolved |
| RR6 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You'd be accountable for growth that has no fixed definition | `[grounded]` posting | What revenue or growth number defines a successful first year? | unresolved |
| RR7 | Equity not quantified | unknown | — | "meaningful equity upside" | The equity may be small, or may not make up for the low cash | `[inferred]` from the missing grant size and terms | What's the grant as a percentage, the strike price, the vesting schedule and the latest valuation? | unresolved |
| RR8 | Employer not established from sources I could attribute | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be real and small, or the posting may be stale or aggregated | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Novaline's own careers page? | unresolved |
| RR9 | Profitable, with a direct line to the CEO | positive_signal | — | "profitable since day one … Report to the CEO with a dotted line to the board" | You'd have real access and less funding-runway pressure | `[grounded]` posting | How does the board's dotted line work in practice? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | See R1, R2, RR1 | `[grounded]` map and register | Recommendation; your call |
| Q1 | If you engage anyway, ask the RR1 and R1 questions on the first recruiter call, before you put any work in | Either answer ends it in five minutes | `[grounded]` register | Pending your approval |

## Evidence status

Verified: R1 and R2 claims, which are your own stated constraints. The other rows' claims are self-reported leads.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin", which was refused because web search permission wasn't granted. It would have confirmed whether the company exists and whether the posting is live (RR8) |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026", which was also refused. It would have produced the market calibration line and confirmed or cleared RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

---

If you'd like, I can save all of this as a `tuesday-dossier.md` file.

**Upgrade menu**
- Grant web search permission and I'll rerun targets 1 and 2. That checks that Novaline exists (RR8) and puts a sourced salary range against the posting (RR2). It won't change the decision, but it would tell you whether your sense that the pay is off holds up against the market.
- A link to the live posting would clear RR8 without any searching.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.