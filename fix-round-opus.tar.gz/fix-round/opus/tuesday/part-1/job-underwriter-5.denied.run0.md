Quick status: I've loaded the assessment rules. Next I'm checking that Pellucid's careers posting is live before I write the evaluation.
# Pellucid Learning: Senior Data Engineer

## Decision snapshot

**Yes, it's worth applying to, provided the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote within the US, or the Denver office)
- `must_have`: direct: R2, R3, R4, R6, R7
- `important`: adjacent: R5 (BigQuery as the warehouse) · unclear: R8 (Ingestion from our app and CRM), R9 (Data contracts our analysts depend on)

R5: a bridge from Snowflake to BigQuery, with its limit named; R8, R9: parts of the job your background doesn't mention yet.

**Opportunity ledger.** The stated terms look good. The posted pay is at or above the band in your recruiter's report (RR2). Still open: the equity terms (RR3), who you'd report to and how big the team is (RR4), whether the role can enforce data contracts on the teams upstream (RR5), and the fact that I couldn't check the posting myself (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote within the US, or the Denver office); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you're based in the US or can work from Denver (R1); (2) the posting is confirmed live on Pellucid's own site (RR1); (3) you present BigQuery as new to you, not as a skill you have (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016 in Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about page you pasted |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts analysts depend on | `[grounded]` JD |
| Requirements | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar for orchestration; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; remote within the US, or the Denver office | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD is silent |
| Scope read | One domain's pipelines (platform reporting), from ingestion to contracts, with no direct reports mentioned | `[inferred]` from the JD's mandate, which names one reporting domain and no team to manage |
| Market calibration | "Senior" in the report usually means 5–8 years and owning one domain's pipelines with no direct reports, so this role's title and scope match that norm. For Series B–D companies the report gives a base median of $151,000 and an interquartile range of $139,000–$163,500. The posted range starts $9,000 above the 25th percentile and ends $2,500 above the 75th; its midpoint ($157,000) is $6,000 above the median. That band describes the market, not Pellucid's offer to you | `[generic]` Datawright 2026 Data Engineering Pay Report (US, n=2,310), as you pasted it; `[grounded]` JD for the posted range |
| Unknowns | Hiring manager and reporting line; data team size; equity size, type and vesting; who owns the source schemas the contracts sit on; what "run" means for operations | — |
| Contradictions | None between the JD and the about page | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote within the US, or the Denver office | hard_gate | unclear | none | hard_gate | The JD limits where you can work from. Your message doesn't say where you're based | `[grounded]` JD; background silent | Closing question G1 |
| R2 | 5+ years of data engineering | must_have | direct | medium | none | You stated 6 years. That's specific, but it's self-reported with nothing to inspect, and intake material can't go above `medium` | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily". Self-reported, so expect a technical screen to test it | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the company's dbt project on Snowflake, about 180 models. Snowflake meets "a cloud warehouse" | `[grounded]` your background | Upgrade menu: an inspectable artifact |
| R5 | BigQuery as the warehouse | important | adjacent | medium | transferability | `[grounded]` The JD names BigQuery as the stack but asks only for "a cloud warehouse", and you've never used BigQuery. `[generic]` dbt modelling usually carries over between warehouses; SQL dialect, cost model and partitioning are what differ. Limit: no hands-on BigQuery | `[grounded]` JD and your background; `[generic]` portability across warehouses | Gap queue G2 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You named Airflow, the exact tool the JD names | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the company's Great Expectations test suite | `[grounded]` your background | none |
| R8 | Ingestion from the app and the CRM | important | unclear | low | discovery | You describe the transformation and orchestration layers but not how data got in or from which sources. Low rather than none because a 180-model project had sources feeding it | `[inferred]` from the dbt project needing upstream sources | Closing question G3 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | A Great Expectations suite tests data. A contract also commits to schemas and expectations between producers and consumers. Nearby work, but not the same practice, so the call is `unclear` until you say more | `[grounded]` your background; `[generic]` that contracts go beyond testing | Closing question G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Remote within the US, or Denver (R1, hard_gate) | hard_gate | Nothing about where you're based | A gate. If you're outside the US and can't relocate to Denver, the decision becomes `no_go` | — | — | `[grounded]` JD terms |
| G2 | BigQuery (R5, important) | transferability | Carries over: dbt modelling, testing, orchestration. Doesn't carry over: BigQuery's dialect, costs and partitioning | It's the one named tool you haven't used | Any dbt migration or cross-warehouse work; cost or performance tuning on Snowflake | A small dbt-on-BigQuery practice project you could show | `[grounded]` your background; `[inferred]` that a practice project narrows the gap |
| G3 | Ingestion from the app and CRM (R8, important) | discovery | Nothing yet on sources or ingestion tooling | It's a third of the mandate | Pulling payroll app databases into Snowflake; syncing a CRM such as Salesforce or HubSpot; Fivetran, Airbyte or hand-written Python extractors; CDC from a production database | A design doc, a DAG, a repo excerpt | `[grounded]` background silent |
| G4 | Data contracts (R9, important) | discovery | A test suite, but no stated agreements with upstream producers or analysts | The JD names contracts directly | Agreeing schemas with app engineers; tests that block deploys when a source changes; dbt model contracts or versioned models; SLAs with analysts | A contract spec, a schema-change runbook, a CI config | `[grounded]` background; `[generic]` what counts as contract work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not independently confirmed | risk_signal | low | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | You copied the text from the company's own pages, so this is very likely fine. I couldn't fetch them to confirm the role is still open. Rated low rather than the usual medium because the source is first-party | `[generic]` pattern for any unverified posting, not a claim about this one | Is this role still open, and who would I interview with? | unresolved |
| RR2 | Posted pay at or above the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The pay is transparent and competitive for the stated scope | `[grounded]` JD; `[generic]` Datawright band | Where in the range do you expect to land for 6 years of experience? | noted |
| RR3 | Equity not quantified | unknown | — | "plus equity" | The grant may be small or have unusual vesting | `[inferred]` from the posting's silence on its terms | What type of equity is it, how big is the grant, and what's the vesting schedule? | unresolved |
| RR4 | No hiring manager or team named | unknown | — | "The posting names no hiring manager" (your note) | The role could be the first data hire or one of a team. That changes on-call load and who reviews your work | `[inferred]` from the JD's silence on the team | Who does this role report to, and how many people are on the data team? | unresolved |
| RR5 | Contracts owned without clear authority upstream | unknown | — | "the data contracts our analysts depend on" | The role may answer for contracts without the power to stop app-team schema changes | `[inferred]` from the JD's scope against its silence on who owns the sources | When the app team changes a schema, what process makes them honor the contract? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own wording: "Built our dbt project on Snowflake — about 180 models" and "set up our Great Expectations test suite" | Covers R4 and R7 | `[grounded]` your background | pending your approval |
| P2 | List BigQuery as new to you. Don't put it under skills; say your dbt and warehouse modelling are on Snowflake | Keeps R5 honest | `[grounded]` your background | pending your approval |
| W1 | Optional: a small dbt-on-BigQuery practice project before interviews | Narrows the R5 limit | `[inferred]` from G2 | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3, RR4 and RR5 word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | My one fetch of pellucidlearning.com/careers/senior-data-engineer was refused permission. It would have shown whether the posting is live and matches your copy. RR1 stays open |
| 2. Role-family sweep | skipped | The Datawright report you pasted already settles the market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you'd like, I can bundle all of this into a `tuesday-dossier.md` file to carry into later steps.

**Upgrade menu**
- Your location and US work status → closes R1 and decides the gate.
- Your base pay floor → I can set it against the $148,000–$166,000 range and add it as a gate row.
- A link to a repo, design doc or anonymized dbt project → R4 and R7 can move toward `high`.
- Permission to fetch the careers page → closes RR1 and lifts that condition.
- The hiring manager's name → sharpens the scope read and which story you lead with.
- A deeper research pass on Pellucid (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

G1: Are you based in the US, or could you work from the Denver office?

G3: When you built the Snowflake project, how did data get in, from which sources (app databases, a CRM, anything else), and which parts of that ingestion did you build yourself?

G4: Did you ever set agreements with the engineers who produced the data, such as schema change rules, deploy-blocking checks or SLAs with analysts, beyond the Great Expectations tests?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.