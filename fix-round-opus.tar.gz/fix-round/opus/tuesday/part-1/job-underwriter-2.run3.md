Now the Step 1 reference files.
**Not a waste of your time, Nadia, and this is one of the closest PM roles to what you already do. The catch is the posting's one must-have: 3+ years of product management, which you don't have under that title (R1b). Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (3+ years PM experience, product-shaped work), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery experience) · absent: R1b (3+ years PM experience, titled)
- `important`: direct: R6 · adjacent: R7 (Write specs, drive delivery with two squads), R8 (Own the API platform roadmap), R10 (Coordinate launches with sales and support) · unclear: R9 (Define and track adoption metrics)

R1b: the posting's marked must-have, and no answer from you can close it; R2, R7, R8: real bridges whose limits need saying out loud; R9: rests only on an unconfirmed lead.

**Opportunity ledger.** I couldn't check the employer because my research calls were refused, so RR1 stands. Pay and location are not stated (RR2, RR3) and it's unclear who actually owns the roadmap (RR5). One entry points the other way: the mandate names its resources and how success is measured (RR4).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer and posting check out (RR1).
  2. R1b is handled by reaching a person, not only the online form. See A1 in the plan.
  3. R2, R7 and R8 are described honestly as adjacent work, never as PM ownership.
  4. Your own limits on pay and location are met (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline: B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently checked (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Must-have marking | Only the "3+ years product management experience" line is labeled must-have; the other requirements are listed without a tier | `[grounded]` JD |
| Scope read | The users of this product are integration partners, the same group you've worked with for seven years from the vendor side. That makes it an unusually close first PM target for you | `[inferred]` from the JD's "integration partners" and "partner-facing API" against your 30+ REST API integrations |
| First-90-days / first-year outcomes | Not stated. The likely first-year measure is partner adoption of the API | `[inferred]` from "define and track adoption metrics" |
| Market calibration | Not run: the role-family search was refused (see Evidence status) | — |
| Unknowns | Pay; location and remote policy; who decides the roadmap; what the two squads currently own | — |
| Contradictions | None inside the JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience: product-shaped work | must_have | adjacent | medium | transferability | 7 years of requirements documents, scoping workshops and quarterly roadmap-input sessions for product. That is product work done from outside the product team. Limit: you fed the roadmap; you didn't decide it. Medium is the most this first pass allows without anything I can inspect | `[grounded]` your resume | see R7, R8; plan E1 |
| R1b | 3+ years PM experience: titled | must_have | absent | none | capability | You state you have never held a PM title. That is a fact, not something you've forgotten to mention, so no question can change it. `[generic]` A requirement marked must-have is often screened literally at the online-application stage | `[grounded]` your own statement; `[generic]` screening pattern | Closure path: get to a human (A1). Carry the rest as material risk. Never retitle past roles |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your company's REST APIs and coordinated custom builds with PMs. You've shipped *integrations on top of* an API, not the API product. Limit: nothing yet shows you owning an endpoint, versioning, or developer experience. A custom build that later became a standard product feature would move this row | `[grounded]` your resume | Question G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and reading OpenAPI specs are stated in exactly the JD's terms. No artifact yet, so expect a technical probe | `[grounded]` your resume | Upgrade menu: a sanitized integration architecture doc |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | You coordinated your own engineers, the client's engineers and PMs across 30+ integrations | `[grounded]` your resume | none |
| R4b | Stakeholder management: sales | must_have | unclear | none | discovery | Your resume doesn't mention sales. `[generic]` Implementation roles often hand off with sales, but nothing here says yours did | `[grounded]` resume silent; `[generic]` role pattern | Gap queue G3 |
| R5 | Agile delivery experience | must_have | unclear | low | discovery | Your resume doesn't mention a delivery method. Low rather than none because you did run delivery work with engineers on custom builds | `[grounded]` resume silent; `[inferred]` from the custom-build coordination | Gap queue G3 |
| R6 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly roadmap-input sessions with clients are the substance of this. The resume lists them but doesn't lead with them | `[grounded]` your resume | Plan E1 |
| R7 | Write specs, drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and coordinating custom builds carry over. Limit: that was project delivery for one client at a time, not running a backlog for standing teams | `[grounded]` your resume | Plan W1 |
| R8 | Own the API platform roadmap | important | adjacent | medium | transferability | Roadmap-input sessions put you on the supplying side of the roadmap, not the deciding side. Limit: no prioritization trade-offs owned yet | `[grounded]` your resume | Plan W1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Your resume has no metrics. The only lead is from memory: possibly an internal request-triage tool that support agents adopted. It is unconfirmed, so it can only be the basis for a question | `[grounded]` resume silent; lead from memory, unconfirmed | Question G2 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | UAT and go-live across 30+ integrations is launch coordination. Limit: those were client go-lives, not launches to a market with sales and support training | `[grounded]` your resume | Gap queue G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped API or platform products (R2, must_have) | transferability | Integrations built on your company's APIs; custom builds coordinated with PMs | R2 is a must-have at adjacent. Turning a custom build into a shipped product feature is the strongest bridge available | A client-specific endpoint or field that product later made generally available; a pattern in your playbook that became a standard feature; spec input you wrote that engineers built into the core API | A release note, changelog entry or doc page for the feature; your original requirements doc | `[grounded]` resume; `[inferred]` that this is the strongest bridge |
| G2 | Adoption metrics (R9, important) | discovery | Nothing confirmed; one lead from memory | It's the only possible evidence of something you built and measured yourself, which is close to the core of a PM's job | The triage tool, if it's real: who used it, how you knew they were using it; playbook usage across the team | Usage numbers, a screenshot, a message from a team lead | `[grounded]` resume silent; lead from memory |
| G3 | Sales coordination and agile delivery (R4b, R5, R10) | discovery | The resume doesn't mention sales, sprints, or launch training | Two listed requirements are unclear. Each is cheap to answer next turn | Pre-sales handoffs, deal-scoping calls with account execs; sprint planning with your engineers; training support staff at go-live | A handoff template; a sprint board | `[grounded]` resume silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not confirmed from any source I could attribute | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale or copied by an aggregator, or it may not be a real hiring employer. Not checked: the searches were refused, not empty | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Quartzline's own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (the JD names no pay) | The figure may fall below your floor, or the company may simply not publish salaries | `[inferred]` from the posting not stating it | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and remote policy not stated | unknown | — | (the JD names no location) | Could be office-based, hybrid, or remote | `[inferred]` from the posting not stating it | Where is this role based, and how many days in the office? | unresolved |
| RR4 | Defined mandate with named resources | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The role has a team and a stated measure of success | `[grounded]` JD | What does API adoption look like today, and what's the target? | noted |
| RR5 | Roadmap ownership alongside sales | unknown | — | "Own the roadmap … coordinate launches with sales" | `[generic]` At partner-facing B2B platforms, large-account requests can end up steering the roadmap | `[generic]` role-family pattern, not a claim about this company | When a big partner asks for something off-roadmap, who makes the call? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put a summary at the top of your resume, using only your own sentences: "Seven years leading 30+ REST API client integrations end to end, from scoping workshops to go-live; wrote the integration playbook the whole team uses; ran quarterly roadmap-input sessions collecting client feedback for product." | see R6, R1a | `[grounded]` each clause comes from your resume | resume_edits_pending_approval |
| E2 | Keep your real titles (Solutions Engineer / Implementation Lead) and never relabel them as PM. Let the work make the case | see R1b | `[grounded]` your own statement | pending your approval |
| W1 | Write a one-page sample: a spec, or an adoption-metrics proposal, for a partner-facing API feature drawn from a gap you saw in client integrations | see R7, R8, R9 | `[grounded]` R7, R8, R9 rows | pending your approval |
| A1 | Reach the hiring manager or a current employee before or alongside the online application, not the form alone | `[generic]` with a titled-years must-have, a cold application often stops at the screen; a person can weigh adjacent work | `[generic]` role-family pattern | pending your approval |
| Q1 | Ask the verification questions for RR1–RR5 word for word during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: the request-triage tool support agents may have adopted (from memory, unconfirmed; question G2). Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform Series B" and "Quartzline careers product manager platform APIs". Both were refused by permission. They would have confirmed the company exists, its stage and size, and that the posting is live: role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | Searched for how solutions engineers move into API platform PM roles. Refused by permission. It would have supplied the market calibration row and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to run |

---

If you'd like, I can save all of this as a `tuesday-dossier.md` you can carry into later steps.

**Upgrade menu**
- **Allow web search:** checks the company and posting (RR1, possibly lifting the cap on the decision) and adds a market calibration and pay band.
- **A link to the live posting or Quartzline's careers page:** settles RR1 directly.
- **Your limits on pay, location and remote work:** turns the unknown hard-gates line into real checks against RR2 and RR3.
- **A sanitized integration architecture doc or requirements doc:** raises R3, R6 and R7 to `high`.
- **An answer to G1:** may turn R2 from adjacent into direct.
- **The hiring manager's name:** tells us which story to lead with for that person.
- **A deeper research pass** (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches): just say so and it runs.

**Questions**

G1: Did any custom build or roadmap request of yours become a generally available feature of the API? What part was yours, and is there a release note or doc page for it?

G2: My notes from an earlier conversation mention an internal request-triage tool that support agents adopted. Is that real? If so, what did you build yourself, how many people used it, and how did you know they were using it?

Hard gates: What are your non-negotiables on pay, location or remote work, and visa or work authorization, if any?

For any of these, answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.