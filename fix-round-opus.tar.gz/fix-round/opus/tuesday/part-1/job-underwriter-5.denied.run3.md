Quick update: I've read the job-underwriter playbook. Now I'm checking that the Pellucid posting is still live before I write up the assessment.
# Should you apply? Senior Data Engineer at Pellucid Learning

## Decision snapshot

**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R7 (BigQuery as the warehouse) · unclear: R8 (Ingestion from our app and CRM), R9 (Data contracts our analysts depend on)

R7: you're moving between warehouses, and that's a real limit, but you have the skills; R8, R9: duties your background doesn't mention yet.

**Opportunity ledger.** The pay is posted at or above the middle of the market (RR2) and the job is described in concrete terms (RR5). Three things are still open: the equity terms (RR3), who the hiring manager is (RR4), and whether the posting is still live, which I couldn't check (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: you live in the US or can work from Denver; (2) RR1: the posting is confirmed live on Pellucid's own careers page; (3) R7: you describe your work honestly as Snowflake experience and never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states. Founded 2016 in Denver, 264 employees, Series C of $52M in February 2026 | `[grounded]` about page, as you pasted it |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from the app and the CRM, a dbt-modelled warehouse in BigQuery, and data contracts for the analysts | `[grounded]` JD |
| Requirements | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; remote within the US, or the Denver office | `[grounded]` JD |
| Scope read | One domain (reporting) from ingestion to contracts, with no direct reports mentioned. This is an individual-contributor senior role | `[inferred]` from the JD's mandate and its silence on managing people |
| Market calibration | The title and "5+ years" fall inside the report's Senior range of 5–8 years. The scope matches its typical senior remit: one domain's pipelines, no direct reports. The posted floor of $148k is $3k under the $151k median and above the $139k lower quartile. The posted top of $166k is above the $163.5k upper quartile. This band is the market's, not Pellucid's offer | `[generic]` Datawright 2026 Data Engineering Pay Report, US, n=2,310, Series B–D (from your recruiter, not checked independently); `[grounded]` JD for the posted range |
| Unknowns | Equity form and size; who the role reports to; whether the role defines the data contracts or maintains existing ones; how CRM ingestion is done today | n/a |
| Contradictions | None between the JD and the about page as pasted. I couldn't check either against the live site (RR1) | `[grounded]` pasted text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You didn't say where you're based, so the location term is unsettled | `[grounded]` JD; background silent on location | Closing question R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | "6 years of data engineering" is specific but self-reported and not yet probed. `medium` is the ceiling at first intake | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily": specific about frequency, not yet probed | `[grounded]` your background | none; a repo would raise it (upgrade menu) |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | "Built our dbt project on Snowflake, about 180 models." Snowflake is a cloud warehouse, and "built" says you owned it. Nothing inspectable yet | `[grounded]` your background | none; a sanitized dbt excerpt would raise it |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration" is a direct match. You didn't say whether you set Airflow up or used an existing instance, so I don't claim either | `[grounded]` your background | none |
| R6 | Experience with data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite": you originated it, and it's specific | `[grounded]` your background | none; the suite's config would raise it |
| R7 | BigQuery as the warehouse (from the JD's stack, not its requirements list) | important | adjacent | medium | transferability | The posting asks for "a cloud warehouse," and you meet that (R4). This row is about the warehouse they actually run. You've "never used BigQuery." What carries over is dbt modelling, SQL and Airflow. The limit is that BigQuery's SQL dialect, its bytes-scanned cost model, and its partitioning and clustering design work differently from Snowflake's | `[grounded]` your statement; `[generic]` that the dbt layer carries across warehouses while dialect and cost model don't | See G3 |
| R8 | Ingestion from our app and CRM | important | unclear | none | discovery | Your background covers modelling and orchestration but doesn't say whether you've built ingestion from a product database or a CRM | `[grounded]` background silent on ingestion sources | See G1 |
| R9 | Data contracts our analysts depend on | important | unclear | none | discovery | Your Great Expectations suite is quality testing. Whether you've agreed schemas or service levels with the people who use the data isn't stated | `[grounded]` background silent on contracts | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R8, important) | discovery | Airflow and dbt work, but no named data sources | Ingestion is the first item in the JD's mandate, so it's likely to be probed | Airflow jobs that load data from your payroll product's database; pulling a CRM (Salesforce, HubSpot) through its API or a connector tool; dealing with upstream schema changes from app teams | A sanitized DAG, an ingestion design note, a connector config | `[grounded]` background silence; `[inferred]` "likely probed" from where ingestion sits in the JD |
| G2 | Data contracts (R9, important) | discovery | A Great Expectations suite you set up; nothing about agreements with analysts | Contracts are named in the JD's one-line mandate | dbt model contracts or enforced schemas; expectations written to an analyst team's needs; agreeing freshness or schema guarantees with downstream users | A dbt `.yml` with contract config, a schema or SLA doc, a changelog of breaking-change notices | `[grounded]` background silence; `[inferred]` weight from the mandate line |
| G3 | BigQuery (R7, important) | transferability | About 180 dbt models on Snowflake; no BigQuery use | It's their production warehouse, so ramp-up time is the likeliest objection | Any warehouse migration or multi-warehouse dbt work; cost or performance tuning in Snowflake; SQL kept portable across dialects | A small dbt project running on a BigQuery sandbox (W1) | `[grounded]` your statement; `[generic]` that ramp-up is the likeliest objection when the warehouse is new to you |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting and employer not verified live | risk_signal | low | "Senior Data Engineer — Pellucid Learning" | The posting may be stale or already filled. I rated this `low`, not `medium`, because the text came from the company's own domain. Only the check failed, not the attribution | `[generic]` pattern for unverified postings, not a claim about this one | Is this role still open, and who is the hiring manager? | unresolved |
| RR2 | Pay posted at or above the market middle | positive_signal | — | "$148,000–$166,000 plus equity" | Posting the range openly, and placing it there, makes it less likely the offer comes in low for this level | `[grounded]` JD figure; `[generic]` band from the pasted report | Where in the $148k–$166k range would someone with six years land? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | Equity at a Series C company could be options or RSUs, of any size or vesting schedule | `[generic]` the forms equity takes at this stage | What form is the equity grant, how big is it, and what is the vesting schedule? | unresolved |
| RR4 | No hiring manager named | unknown | — | (posting names no one) | Unclear whether the role reports into analytics, platform or engineering, which shapes who owns the data contracts | `[inferred]` from the JD's silence, against the contracts mandate | Who does this role report to, and who owns the data contracts today? | unresolved |
| RR5 | Mandate and stack stated concretely | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The scope is defined and matches market norms for a senior IC role, with no bundled specializations | `[grounded]` JD; `[generic]` scope norm from the report | What would success look like for this role in the first 90 days? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with your own words: "Built our dbt project on Snowflake (about 180 models), with Airflow for orchestration; set up our Great Expectations test suite; Python and SQL daily." | R4, R5, R6 | `[grounded]` your background, verbs and figures kept as you gave them | pending your approval |
| E2 | Say it plainly: "My warehouse work is on Snowflake; I haven't used BigQuery yet." Never list BigQuery as a skill | R7 | `[grounded]` your statement | pending your approval |
| W1 | Optional: port a handful of models to a BigQuery sandbox and link the repo | Narrows R7 with something they can inspect | `[generic]` that a small portable sample is a common way to bridge a warehouse switch | pending your approval |
| A1 | Confirm R1 before you apply: are you US-based, or able to work from Denver? | R1 | `[grounded]` JD term | pending your approval |
| Q1 | Ask the verification questions from RR1 to RR5 word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

All the wording and actions above are proposals. None of it is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent one search ("Pellucid Learning online tutoring K-12 Denver") and one fetch (pellucidlearning.com/careers/senior-data-engineer) to check that your pasted posting and about page are current. This session's permissions refused both. They would have resolved RR1 and the contradictions row |
| 2. Role-family sweep | skipped | The Datawright report you pasted already gives the market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was nothing to search |

I can save this as a `tuesday-dossier.md` for later steps if you'd like.

**What more input would unlock:**
- **Where you're based, and any pay floor or other must-have terms:** settles R1 and lets me run the checks against your constraints.
- **Allow web search and fetch for this session:** lets me check RR1 live and fill in the contradictions row.
- **Answers to G1 and G2:** R8 and R9 move from `unclear`.
- **A sanitized repo excerpt** (dbt model `.yml` files, the Great Expectations config, an Airflow DAG): R3, R4, R5 and R6 can rise to `high`.
- **The BigQuery sample (W1):** shrinks R7's limit.
- **The hiring manager's name:** sharpens the scope read and tells you which story to lead with.
- **A deeper research pass on Pellucid** (funding and leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches, and it needs web permission): say the word.

**Questions:**

R1: Where are you based? Is the US-remote or Denver term fine for you, and is there a pay floor or other term this role has to meet?

G1: Have you built ingestion yourself, from your product's database, a CRM or an outside API? Which sources were they, and which parts were yours?

G2: Have you set schema, freshness or breaking-change agreements with analysts or other data users, beyond the Great Expectations tests? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.