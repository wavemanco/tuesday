Now the files needed for Step 1.
## Decision snapshot

**Yes, apply. Your experience matches what the role asks for. Before you do, check one thing: the ad you pasted says the job is fully remote, but Brindlemoor's live careers page says it's in the Leeds office four days a week (R1, RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (whether the job is fully remote or Leeds four days a week)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6a, R7 · adjacent: R8 (recommendations for underwriting *and product*) · unclear: R6b (monitoring rating models)
- `preferred`: direct: R9 · adjacent: R10 (pet-insurance knowledge)

What matters most: R6b, because model monitoring is half of the rating-model brief and it's the subject of the hiring manager's public talk (RR4); R10, because motor pricing carries over to pet but has limits you should name; R7 (`medium`), because you said you "ran" the tests, and you'll be asked whether you also designed them.

**Opportunity ledger.** The role is clearly described, but some terms are unsettled. The working pattern differs between your copy and the live posting (RR1). The salary isn't stated (RR2). The company's stage and size aren't established (RR3), and neither is the size of the team (RR5). One entry is positive: the role reports to a named Director of Pricing who has spoken publicly about the core of this job (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (whether the job is fully remote or Leeds four days a week); you haven't told me your constraints, so I can't check the role against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor confirms the working pattern and you can work it (R1, RR1); (2) you describe your background as motor pricing and never as pet experience (R10); (3) the budgeted salary meets your own minimum (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The role is live on its own careers site | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn the results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Line management | Neither source mentions any direct reports or managing people | `[grounded]` JD and careers page both silent |
| Scope read | "Own pricing analytics for our pet-insurance product" reads as the lead analyst on this product, possibly the only one | `[inferred]` from "own" and the lack of any mention of a team |
| Hiring manager footprint | Director of Pricing at Brindlemoor. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile, search result snippet only, not fetched |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base salary £58,400, middle half earning £52,100–£64,900 (n=612). This is the market range, not Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 pay survey; `[grounded]` the JD withholds salary |
| Unknowns | Salary; which working pattern is current; company stage and size; team size; success measures | — |
| Contradictions | Your pasted JD says "Fully remote (UK)". The live careers page says "Leeds office four days a week" | `[grounded]` both sources, careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Working pattern: "Fully remote (UK)" vs "Leeds office four days a week" | hard_gate | unclear | none | hard_gate | The two sources disagree on the term, and you haven't said what working pattern you need, so nothing is established on either side | `[grounded]` the two sources, and your silence on the point | RR1's question to Brindlemoor; R1 question below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior. It's specific, but nothing inspectable is in hand yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily, by your own account. Expect a technical probe | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book | `[grounded]` your background | Sanitized model documentation would raise this to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | A redacted review deck would raise this to high |
| R6a | Build rating models | important | direct | medium | none | This is the same evidence as R4 | `[grounded]` your background | none |
| R6b | Monitor rating models | important | unclear | low | discovery | "Maintained" may include monitoring (drift, actual vs expected, retraining triggers), but your background doesn't say. `[grounded]` the hiring manager's public talk is on exactly this topic | `[grounded]` your background is silent on it; talk title from profile | G1 |
| R7 | Design and read price tests | important | direct | medium | none | You "ran 14 price tests last year with the underwriting team". Ambiguity resolves downward: who designed them is not established. Expect a probe on design ownership | `[grounded]` your background | none |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | discovery | Recommendations to underwriting are well evidenced through the quarterly review. A product audience isn't mentioned | `[grounded]` your background | G2 |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance knowledge (the JD's product) | preferred | adjacent | medium | transferability | What carries over: personal-lines rating, GLMs, price testing. The limit: you've never worked on pet, whose rating factors and claims differ from motor. `[generic]` pet pricing typically turns on breed, age and vet costs rather than driver and vehicle factors | `[inferred]` requirement drawn from "our pet-insurance product"; `[grounded]` you've never worked on pet | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6b, important) | discovery | You built and maintained the young-driver GLM, but nothing yet on how its performance was tracked | Half of the rating-model brief, and the hiring manager's public topic, so whether it's true decides what story you lead with | Actual-vs-expected or loss-ratio tracking by segment; drift or stability checks on rating factors; deciding when the model needed a refit; monitoring a small segment where noise made the errors "loud" | A sanitized monitoring dashboard, an A-vs-E report, a refit or validation memo | `[grounded]` your background is silent on monitoring; `[grounded]` the talk topic |
| G2 | Recommendations to product (R8, important) | discovery | Underwriting is well covered; any product-side audience is unknown | The JD names both audiences | Price-test results feeding a product or proposition team; input to cover, excess or discount design; work with marketing or digital on the quote journey | A recommendation note, or a test readout sent to product | `[grounded]` your background names only underwriting |
| G3 | Pet-insurance knowledge (R10, preferred) | transferability | Motor pricing only | Preferred, so it won't block you, but it's the gap a reviewer will notice first | Young-driver work is a small, volatile segment, which is close to a small new book; personal-lines retail pricing; any regulatory pricing work that applies across UK general insurance lines | A short self-study note on pet rating factors, offered as a talking point and not a credential | `[inferred]` bridge from young-driver work; `[generic]` that domain change is the first thing a reviewer notices |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The working pattern contradicts itself across sources (R1) | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | Either your copy is stale or from another source, or the terms changed. One of the two is wrong | `[grounded]` both texts; `[inferred]` the reasons why | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | No salary in the JD or on the careers page | The figure may sit anywhere relative to the market range in Role reality | `[inferred]` from the missing figure, set against the `[generic]` range | What salary is budgeted for this role? | unresolved |
| RR3 | Company stage and size not established | unknown | — | "insurtech" | The careers page confirms the company and role exist. A name search found nothing more | `[grounded]` search results; `[generic]` new insurtechs often have a thin public footprint | How big is the pet book today, and how is the company funded? | unresolved |
| RR4 | Named reporting line to a hiring manager with a public record on the core work | positive_signal | — | "reports to the Director of Pricing" | The role has a clear manager whose expertise sits in this exact area | `[grounded]` careers page and the hiring manager's profile | What does good model monitoring look like on this book in year one? | noted |
| RR5 | Team size unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only pricing analyst on the product | `[inferred]` from "own" and no mention of a team | Who else works on pet pricing, and who reviews the models? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern before you spend time applying | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with "Built and maintained the GLM rating model for our young-driver book" and "Ran 14 price tests last year with the underwriting team", in your own words, keeping "ran" rather than "designed" until G1/R7 are confirmed | see R4, R7 | `[grounded]` your background | pending your approval |
| P2 | If G1 confirms monitoring work, make it the story you lead with when Odile Varga is the reader | see R6b, RR4 | `[grounded]` her talk title | pending your approval |
| P3 | Describe yourself as a motor personal-lines pricing analyst, never as having pet experience | see R10 | `[grounded]` you've never worked on pet | pending your approval |
| Q1 | Ask the RR1–RR5 verification questions word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the Contradictions row, RR1 and RR3 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary 2026". Fetched "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved Market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor". Result: "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. Moved the hiring manager footprint row, RR4 and P2 |

I can save all of this as a `tuesday-dossier.md` file whenever you want it.

## Upgrade menu

- Brindlemoor's answer on the working pattern: R1 and RR1 close, and the decision becomes `go` or `no_go` on that alone.
- Your own constraints (where you're based, how many office days you'd accept, your salary minimum): R1 can be graded and RR2 checked against your minimum.
- A sanitized monitoring dashboard or A-vs-E report: R6b resolves and P2 can go ahead.
- A redacted quarterly pricing review deck, a price-test readout, or model documentation: R4, R5 and R7 move toward `high`.
- The budgeted salary: RR2 closes against the market range.
- A deeper research pass on Brindlemoor: funding, leadership changes, hiring patterns, employee reports and recent news. Up to 5 more searches and 2 more fetches; say the word and it runs.

**R1:** If the role turns out to be in the Leeds office four days a week, can you work that? Where are you based?

**G1:** On the young-driver GLM, how did you track whether the model was still performing (A-vs-E, drift checks, refit decisions), and which parts were yours?

**G2:** Did any of your price-test results or recommendations go to a product or proposition team, not just underwriting? What changed as a result?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.