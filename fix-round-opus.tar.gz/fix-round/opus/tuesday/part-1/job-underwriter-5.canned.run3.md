Both checks are done. The posting and the pay report you pasted match what's published, so here's the assessment.

## Decision snapshot

**Yes, it looks worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7
- `important`: adjacent: R5b (a dbt-modelled warehouse in BigQuery) · unclear: R8 (ingestion from our app and CRM), R9 (the data contracts our analysts depend on)

R5b: a Snowflake-to-BigQuery bridge, with its limit named; R8, R9: nothing you've told me yet speaks to them.

**Opportunity ledger.** The role looks sound. The posting is live and the employer can be traced to its own site (RR2). The pay is stated and sits on or above the market band (RR1). The open items are things to verify, not warning signs: team shape (RR3), reporting line (RR4) and equity terms (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work remotely from the US or from Denver (R1); (2) you present BigQuery honestly as a new warehouse on a stack you know, not as experience you have (R5b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states. Founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page as you pasted it |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One domain (reporting data) from ingestion to the analyst-facing layer. Nothing mentions direct reports | `[inferred]` from the JD's mandate, and from its silence on reports and team |
| Market calibration | "Senior" usually means 5–8 years and ownership of one domain's pipelines with no reports, which matches this posting. The band is base median $151,000, IQR $139,000–$163,500. The posting's floor ($148k) is between Q1 and the median, its top ($166k) is above Q3, and its midpoint ($157k) is above the median (RR1) | `[generic]` Datawright 2026 report, US, n=2,310, Series B–D; `[grounded]` JD for the posting's figures |
| Unknowns | Team size and whether other data engineers exist; who the role reports to; equity form and amount; whether the posting's "Remote (US)" requires US work authorization | — |
| Contradictions | None. The pasted JD matches the live careers page | `[grounded]` search result for the careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US, so the gate isn't established yet | `[grounded]` JD terms; your background is silent on location | Closing question on R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years stated, within the 5+ asked. Self-reported background, so `medium` is the ceiling until something is inspected | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", stated and uninspected | `[grounded]` your background | Optional: a code sample raises to `high` |
| R4 | dbt | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models": specific and attributed to you | `[grounded]` your background | Optional: a sanitized dbt docs or lineage screenshot raises to `high` |
| R5a | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the JD's requirement line doesn't name a vendor | `[grounded]` JD requirement line and your background | none |
| R5b | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The bridge: dbt modelling, warehouse design and SQL carry over. The limit: "Never used BigQuery" means its cost model, partitioning and clustering, and SQL dialect are new to you. Tiered `important`, not `must_have`, because the requirement line asks for "a cloud warehouse" | `[grounded]` your own statement and the JD; `[generic]` that BigQuery's partitioning and pricing model differs from Snowflake's | See G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration", named in the JD and stated by you | `[grounded]` your background | Optional: a sanitized DAG |
| R7 | Experience with data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite": specific, and the setup is yours | `[grounded]` your background | Optional: a sanitized suite config or checkpoint |
| R8 | Ingestion from our app and CRM | important | unclear | low | discovery | Airflow orchestration is indirect context. Nothing says you built source ingestion from an application database or a CRM | `[grounded]` your background is silent on ingestion | See G2 |
| R9 | The data contracts our analysts depend on | important | unclear | low | discovery | The Great Expectations work is near this, but tests aren't contracts. Nothing says you defined schemas or SLAs that analysts or downstream teams relied on | `[grounded]` your background is silent; `[generic]` that "data contracts" usually means agreed schemas or guarantees between producers and consumers | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5b, important) | transferability | Strong dbt and Snowflake experience; no BigQuery at all | This is the one named stack item you lack, so it's the likeliest probe | dbt adapter or cross-warehouse work; cost and performance tuning in Snowflake (clustering, warehouse sizing); a weekend port of a few models to the BigQuery sandbox | A small public repo: a handful of dbt models running on the BigQuery free tier, with a README | `[grounded]` your statement; `[generic]` that a stack gap like this gets probed in screens |
| G2 | Ingestion from app and CRM (R8, important) | discovery | Orchestration yes; source ingestion unstated | It's a third of the mandate; one answer could move R8 to `direct` | Loading from the payroll app's production database (CDC, Fivetran or Airbyte, custom extracts); pulling Salesforce or HubSpot data via API or a connector; handling schema drift from a source system | A sanitized DAG, an architecture diagram, a connector config | `[grounded]` silence in your background; `[inferred]` from the JD that the payroll context likely involved app-side sources |
| G3 | Data contracts (R9, important) | discovery | Data-quality testing yes; contracts unstated | The JD names analysts depending on them, so this is a visible part of the role | dbt model contracts or enforced schemas; agreeing a schema or freshness SLA with an analytics or finance team; versioning a breaking change with downstream consumers | A schema.yml with contracts enabled, an SLA doc, a deprecation note | `[grounded]` silence in your background; `[generic]` the meaning of "data contracts" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, on or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The band brackets the market median, and its top is above Q3 for this seniority and stage | `[grounded]` JD figures; `[generic]` Datawright band | Where in the range do you expect to place someone with six years? | noted |
| RR2 | Posting live on the employer's own domain | positive_signal | — | "Senior Data Engineer — Pellucid Learning" | The employer exists as described and the role is open | `[grounded]` careers page search result, "Accepting applications" | — | noted |
| RR3 | Team shape unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Possibly a sole or first data engineer covering ingestion through contracts, or one member of a team | `[inferred]` from the JD's breadth against its silence on team | How many data engineers are there today, and which pieces would be mine alone? | unresolved |
| RR4 | No hiring manager named | unknown | — | (posting names none) | Reporting line could be analytics, engineering or a data lead | `[inferred]` from the posting's silence | Who would this role report to, and who else is in the loop? | unresolved |
| RR5 | Equity form unstated | unknown | — | "plus equity" | The form (options or RSUs), amount and vesting are open | `[grounded]` JD wording | What form is the equity, how much, and what are the vesting and exercise terms? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own words: "Built our dbt project on Snowflake — about 180 models" and "set up our Great Expectations test suite" | These cover R4 and R7 directly | `[grounded]` your background | pending your approval |
| P2 | Name BigQuery plainly as new to you, on a dbt and cloud-warehouse foundation; never imply you've used it | see R5b | `[grounded]` your statement | pending your approval |
| W1 | Optional: port a few dbt models to the BigQuery sandbox and link the repo | Narrows the R5b limit and gives R3 and R4 something inspectable | `[generic]` that a small work sample is a common way to bridge a stack gap | pending your approval |
| Q1 | Ask the verification questions for RR1, RR3, RR4 and RR5 verbatim in the recruiter screen | The register doubles as screen prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Checked the pasted posting: searched "Pellucid Learning senior data engineer careers", which returned "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), marked accepting applications. Moved RR2 and role reality's contradictions row. The about-page figures stand as you pasted them |
| 2. Role-family sweep | yes | Checked the pasted report: searched "Datawright 2026 Data Engineering Pay Report", which returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report), with figures matching your copy. Moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you'd like, I can turn this into a `tuesday-dossier.md` file you can keep and reuse in later steps.

## Upgrade menu

- Your location, work authorization and pay floor: R1 closes, and the pay comparison becomes about your floor instead of only the market.
- Answers to G2 and G3: R8 and R9 could move to `direct` or `adjacent`.
- Any one inspectable artifact, such as a sanitized dbt lineage screenshot, a Great Expectations config, a DAG or a small repo: the matching rows move from `medium` to `high`.
- The hiring manager's name: a scope read and which story to lead with for that reader.
- A deeper research pass on Pellucid Learning (leadership churn, data-team hiring patterns, employee reports, recent news), up to 5 more searches and 2 more fetches. Say the word and it runs.

## Questions

**R1:** Are you based in the US and able to work there without sponsorship? Or would you be working from the Denver office?

**G2:** At the payroll company, did you build the ingestion yourself, such as loading from the product's database or pulling CRM data? What did you use, and which part was yours?

**G3:** Have you ever set an agreed schema, freshness SLA or dbt model contract that an analytics or finance team relied on? Or handled a breaking change with downstream users?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.