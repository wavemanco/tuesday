I'm reading the posting now; the assessment will follow.
**Should you go for it? Yes, it's worth applying. Your core work is a direct match: Salesforce admin, CRM ownership, and pipeline and renewal reporting (R4, R8a, R9). The gaps are forecasting and billing (R6, R7, R8b). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week), R2 (£61,500–£67,000 plus share options)
- `must_have`: direct: R3a, R4, R5a, R8a, R9 · adjacent: R6 (Experience owning a forecast; quarterly forecast with the CFO) · unclear: R3b (At a B2B software company), R5b (Spreadsheet modelling), R7 (Working with finance on billing or revenue data) · absent: R8b (Own billing data)

R6: forecasting is a bridge with a clear limit; R7, R8b: billing data, which the posting names twice; R3b, R5b: not stated in your background, rather than missing.

**Opportunity ledger.** The employer is real, and the hiring manager the recruiter named matches a public profile (RR5). The salary is published and sits inside the market band (RR2). Still open: I couldn't find the role on Quillfield's own site (RR1), it's unclear who owns the forecast versus the CFO (RR3), and the role covers a lot with no success measures stated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week), R2 (£61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Bristol two-day pattern and the pay range both work for you (R1, R2); (2) you present forecasting and billing honestly as things you'll pick up, never as things you've done (R6, R7, R8b); (3) the recruiter confirms the posting is live (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A in April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` JD |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` JD |
| Compensation | £61,500–£67,000 plus share options | `[grounded]` JD |
| Reporting line | Probably to Tamsin Achebe, Head of Revenue Operations | `[grounded]` recruiter named her as hiring manager, and her public profile gives that title; `[inferred]` that the role reports to her |
| First-year outcomes | Not stated | `[grounded]` JD is silent |
| Scope read | A broad Lead remit: CRM admin, billing data, reporting, and a forecast run alongside the CFO, with no team or success measures mentioned | `[inferred]` from the JD's four ownership verbs against its silence on team and metrics |
| Market calibration | UK B2B software RevOps Lead base pay: median £64,200, interquartile range £57,800–£70,400. Quillfield's range sits around the median. This is a market band, not Quillfield's offer | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide, n=438, base pay only, UK-wide (not Bristol-specific); `[grounded]` JD range |
| Unknowns | Who signs off the forecast; size of the RevOps team; which billing system; share-option terms; success measures | — |
| Contradictions | None between the JD, the recruiter's naming and the company's About page. The role wasn't found on Quillfield's own site (RR1) | `[grounded]` search and careers-page fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't said where you live or what working pattern you need, so whether this gate is met isn't established | `[grounded]` JD; your message is silent on location | Closing question on R1/R2 |
| R2 | £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor given, so the range can't be checked against your minimum | `[grounded]` JD; your message is silent on pay | Closing question on R1/R2 |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team. Specific, but self-reported with nothing inspectable yet | `[grounded]` your background | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | You said "B2B payments company"; whether it sells software isn't stated. Lower band taken until it is | `[grounded]` your wording | Upgrade menu: your CV or a one-line company description |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. A certification is inspectable once a verification link is shared | `[grounded]` your background | Share the certification verification link to raise this to high |
| R5a | Strong SQL | must_have | direct | medium | none | You use SQL weekly. Specific, self-reported | `[grounded]` your background | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows heavy use, not modelling. Building a model (drivers, scenarios) is a different kind of work from daily reporting, so it isn't counted | `[grounded]` your wording | Upgrade menu: an example of a model you built |
| R6 | Experience owning a forecast; run the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is work next to forecasting. Limit: you've never owned the company forecast, because finance did. Whether the review produces a number you're accountable for is unknown | `[grounded]` your background, including "never owned the company forecast"; `[inferred]` that the pipeline review is forecast-adjacent | G1 |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | The billing half is ruled out by your own statement. Whether you've worked with finance on revenue data (renewal values, bookings) isn't stated | `[grounded]` your background, "never worked on billing data" | G2 |
| R8a | Own CRM data | must_have | direct | medium | none | Salesforce admin plus a rebuild of the pipeline and renewal dashboards built on it | `[grounded]` your background | none |
| R8b | Own billing data | must_have | absent | none | capability | You've said you've never worked on billing data. If you've touched payment or transaction data at your current employer, this reopens as discovery | `[grounded]` your statement | G5 closure path |
| R9 | Build the pipeline and renewal reporting sales and finance run on | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Finance as an audience isn't confirmed; the sales side is | `[grounded]` your background | Upgrade menu: a sanitized dashboard screenshot raises this to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | You run a monthly pipeline review with the sales director; finance owned the company forecast. Carries over: pipeline inspection and judging deal stages. Limit: you've never been accountable for a company-level number. Strengthener: any number you produced or called | The posting puts the forecast at the heart of the job ("run the quarterly revenue forecast with the CFO") | Calling a commit or best-case number in the review; a weighted-pipeline figure you calculated; reconciling your pipeline number with finance's forecast; renewal or churn projections from your renewal dashboard | A sanitized pipeline-review pack or forecast tab | `[grounded]` your background; `[generic]` that RevOps forecast interviews probe who owned the number |
| G2 | Finance on revenue data (R7, must_have) | discovery | Billing is ruled out; revenue-data work with finance isn't mentioned | "Billing or revenue" is an either/or requirement, so revenue-data work alone would meet it | Matching renewal values in Salesforce to finance's figures; supplying bookings or ARR data for finance's forecast; commission or quota data checked with finance | A reconciliation sheet, an email thread outline, a report spec | `[grounded]` JD wording and your statement |
| G3 | B2B software company (R3b, must_have) | discovery | "B2B payments company" | A literal screen may read "payments" and "software" differently | The company sells a platform, API or SaaS product | Your CV or the company's own description | `[grounded]` your wording; `[generic]` that screens read industry labels literally |
| G4 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use, with no model described | Modelling is a named skill, separate from SQL | A capacity, quota or renewal-rate model; a scenario sheet for the sales director | The model file, sanitized | `[grounded]` JD and your wording |
| G5 | Billing data ownership (R8b, must_have) | capability | No billing work, by your own statement | Billing is named twice in the posting, and Quillfield's product is invoicing software | Closure path: learn how invoice, credit-note and subscription data feed revenue reporting before the interviews, and name the gap yourself | Notes from that learning, if you want to show them | `[grounded]` your statement and quillfield.co.uk/about; `[generic]` the billing-to-revenue data path |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Quillfield's own site | unknown | — | "Revenue Operations Lead — Quillfield \| Tallyboard Jobs" | Quillfield may not host a careers page and may hire only through boards and recruiters, or the posting may be stale | `[grounded]` careers-page fetch returned no page, and a site search found nothing; `[generic]` that companies this size often hire only through boards | Is this role open now, and is Tallyboard where you're advertising it? | unresolved |
| RR2 | Salary published and within the market band | positive_signal | — | "£61,500–£67,000 plus share options" | The range brackets the £64,200 market median | `[grounded]` JD; `[generic]` Ledgerline band | What's the share-option grant and vesting schedule, and where in the range do you expect to land? | noted |
| RR3 | Forecast authority shared with the CFO, split unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build the forecast while the CFO owns the number, or the reverse | `[inferred]` from "with" | Who signs off the quarterly forecast number, and what part of it does this role own? | unresolved |
| RR4 | Broad mandate, no team or success measures stated | risk_signal | low | "You will own our CRM and billing data, build… and run…" | The role may be one person covering admin, data engineering and forecasting | `[inferred]` from the JD's silence on team and metrics; `[generic]` that roles bundling these often lack support | Who else works in revenue operations, and what would success look like at six months? | unresolved |
| RR5 | Hiring manager's public profile matches the recruiter's naming | positive_signal | — | Recruiter, as you reported: "Tamsin Achebe" | Consistent with a real, current hiring process | `[grounded]` profile: Head of Revenue Operations, Quillfield | How would this role split work with you as Head of Revenue Operations? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the pipeline and renewal dashboard rebuild and your Salesforce admin certification | see R9, R4, R8a. Tamsin's profile lists four years as a sales operations manager at a payments company, so this is work she has done herself | `[grounded]` your background and her public profile | pending your approval |
| P2 | State the forecast gap in your own words: you run the monthly pipeline review with the sales director, and finance owned the company forecast | see R6, G1. The honest version holds up when an interviewer probes it | `[grounded]` your own sentences | pending your approval |
| P3 | State the billing gap in your own words ("I've never worked on billing data"), alongside the G5 learning plan | see R8b, R7 | `[grounded]` your statement; `[generic]` closure path | pending your approval |
| P4 | Check R1/R2 against your location and floor before investing time | see R1, R2, RR2 | `[grounded]` JD | pending your approval |
| P5 | Confirm with the recruiter that the posting is live | see RR1 | `[grounded]` RR1 | pending your approval |
| P6 | Ask the verification questions from RR1–RR5 word for word during the interviews | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers" and found "About Quillfield" (quillfield.co.uk/about). Searched "quillfield.co.uk careers Revenue Operations Lead": no results. Fetched quillfield.co.uk/careers: no page. Fed: Organization row, Contradictions row, RR1 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol B2B SaaS 2026" and found "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Fed: Market calibration, RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and found "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Fed: Reporting line, RR5, P1 |

---

I can save this as a `tuesday-dossier.md` so the analysis carries into later steps, if you'd like.

**Upgrade menu**
- Your location and pay floor: R1 and R2 settle as met or failed.
- Your CV: R3b and R5b get read from your actual wording.
- Your Salesforce certification verification link: R4 rises to `high`.
- A sanitized pipeline or renewal dashboard screenshot: R9 rises to `high`.
- A pipeline-review pack showing any number you produced: the R6 case gets stronger.
- A deeper research pass on Quillfield (how the Series A is being used, leadership changes, hiring patterns, staff reviews, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1: In the monthly pipeline review, do you produce or call a number, such as a commit, a quarter-end projection or a weighted-pipeline figure? What happened to it after the meeting?

G2: Have you worked with finance on any revenue data, such as renewal values, bookings, ARR, commission data, or matching Salesforce figures to finance's?

R1/R2: Do two office days a week in Bristol and a £61,500–£67,000 base both work for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.