I'm reading the posting you linked, then I'll run a short check on Quillfield and the role before writing up the fit assessment.
**Yes, it's worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week)
- `must_have`: direct: R2a, R3, R4a, R7 · adjacent: R5 (experience owning a forecast) · unclear: R2b (at a B2B software company), R4b (spreadsheet modelling), R6 (working with finance on billing or revenue data)
- `important`: absent: R8 (own the billing data)

R5: you have real nearby experience, but you've never owned a forecast, and that's the line they'll test; R6: your answer to G1 decides whether this is nearby experience or a gap; R8: billing data is new to you, a ramp to plan for rather than a blocker.

**Opportunity ledger.** The pay is published and sits in the market range (RR1). The remit reaches into finance's territory, and the posting doesn't say who controls billing (RR2). Still open: whether the posting is live on Quillfield's own site (RR3), what success looks like (RR4) and what the options are worth (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) two days a week in Bristol works for you (R1); (2) G1 shows you've done revenue-data work that finance used, or you name it openly as a gap (R6); (3) you present the pipeline review as what it was, not as owning the forecast (R5); (4) the interview confirms who owns billing data and what this role can decide about it (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` About Quillfield page, from a search-result snippet |
| Mandate | Own the CRM and billing data; build the pipeline and renewal reporting sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` JD |
| Compensation | £61,500–£67,000 plus share options (number of options not stated) | `[grounded]` JD |
| Reporting line | Hiring manager Tamsin Achebe, Head of Revenue Operations. Her public profile lists four years as sales operations manager at Corvane Payments before this | `[grounded]` name from your recruiter; title and history from a public profile search-result snippet |
| Scope read | A broad remit: four responsibilities that cover both the sales side (CRM, pipeline) and the finance side (billing data, CFO forecast) | `[inferred]` from the JD's four responsibilities |
| First-year outcomes | None stated | `[grounded]` JD is silent |
| Market calibration | UK B2B software RevOps leads: median base £64,200, middle half £57,800–£70,400 (n=438, 2026; not Bristol-specific). That's a market range, not Quillfield's offer. The posted band sits inside it (RR1) | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` JD for the posted band |
| Unknowns | Who owns the billing system today; forecast accuracy expectations; size of the options; whether the role is on Quillfield's own careers page; your location | — |
| Contradictions | None between the JD and the About page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The JD states the term; you haven't said where you're based or what office pattern works for you | `[grounded]` JD; your message is silent | Question R1 below |
| R2a | 4+ years in revenue operations, sales operations or similar | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team, as you stated it. Specific, but nothing inspectable yet | `[grounded]` your message | none |
| R2b | …at a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether it sells software, or whether Quillfield will count it, isn't settled by what you wrote. Split from R2a because it's a different claim | `[grounded]` your message; `[inferred]` that screeners may read "software" literally | See G3 |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. A certification can be checked, but none has been inspected yet | `[grounded]` your message | Optional: a credential verification link would raise this to high |
| R4a | Strong SQL | must_have | direct | medium | none | "SQL weekly", stated specifically, not inspected | `[grounded]` your message | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows you use it, not that you build models | `[grounded]` your message | See G4 |
| R5 | Experience owning a forecast (the role runs the quarterly revenue forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, and you said you've never owned the company forecast: finance did. Adjacent, and the limit is ownership itself | `[grounded]` your message, including the limit you stated | See G2 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Billing is ruled out by your own statement. But the requirement says "billing **or** revenue data", and the renewal dashboards might count if finance used them or you fed their forecast. Your message doesn't say | `[grounded]` your message | See G1 |
| R7 | Build the pipeline and renewal reporting sales and finance run on | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them is G1's question, not this row's | `[grounded]` your message | Optional: sanitized dashboard screenshots |
| R8 | Own the CRM and billing data (the billing half) | important | absent | none | capability | You stated you've never worked on billing data. The CRM half is covered by R3 and R7 | `[grounded]` your message; `[generic]` that billing data is usually learned on the job from the billing system's own model | Closure path: before interviews, learn how subscription invoicing data is structured (invoices, credit notes, MRR movements), and present it as a ramp, not experience |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Finance on revenue data (R6, must_have) | discovery | Renewal dashboards built; no statement about finance using them or working with finance | The difference between adjacent and a must-have gap; it also sets up how you answer R5 | Finance reading your renewal dashboard for retention or churn numbers; reconciling CRM bookings against finance's numbers; sending pipeline or renewal figures into finance's forecast; agreeing a definition (ARR, churn) with finance | A sanitized dashboard screenshot, a reconciliation sheet, an email thread on a shared metric definition | `[grounded]` your message is silent on finance; `[inferred]` that this moves R6 |
| G2 | Owning a forecast (R5, must_have) | transferability | **Carries over:** you run the monthly pipeline review. **Limit:** you never owned the number or sat with the CFO on it. **Would strengthen it:** a forecast-style model you built, even an informal one | The role runs the CFO forecast quarterly, so this is the role's centre | Weighting pipeline by stage; a commit or best-case call you made in the pipeline review; checking past calls against what closed | A sanitized pipeline review deck, or a sample forecast model | `[grounded]` the limit you stated |
| G3 | B2B software employer (R2b, must_have) | discovery | "B2B payments company" | A literal screen may read "software" strictly | Your company sells a platform, API or SaaS product rather than processing services alone | The company's own product page | `[inferred]` screening risk |
| G4 | Spreadsheet modelling (R4b, must_have) | discovery | Daily Excel use | "Modelling" names a skill beyond reporting | Capacity or quota models; renewal or churn projections; scenario tabs | A sanitized workbook | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary published, inside the market range | positive_signal | — | "Salary £61,500–£67,000 plus share options" | Pay is open and in the market middle | `[grounded]` JD; `[generic]` Ledgerline range | Where in the band would someone without direct forecast ownership land? | noted |
| RR2 | Remit spans sales ops and finance ops | risk_signal | low | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The role may be accountable for billing data that finance or another system owner actually controls | `[inferred]` from the JD's pairing of CRM and billing ownership; `[generic]` billing data often sits with finance ops | Who owns the billing system today, and what can this role change in it without finance's sign-off? | unresolved |
| RR3 | Posting seen only on Tallyboard | unknown | — | "Tallyboard Jobs" | The role may be listed only through aggregators or the recruiter, or the listing may be stale | `[grounded]` one search of Quillfield's site returned nothing; `[generic]` aggregator listings sometimes outlive the role | Is this role still open, and is it listed on Quillfield's own careers page? | unresolved |
| RR4 | No success measures on a demanding mandate | unknown | — | "run the quarterly revenue forecast with the CFO" | Forecast accuracy expectations may be undefined, or set in the CFO's head | `[inferred]` from the JD's silence on outcomes | What would a strong first year look like, and is there a forecast accuracy target? | unresolved |
| RR5 | Share options unquantified | unknown | — | "plus share options" | Value can't be weighed against salary yet | `[grounded]` JD | How many options, at what strike price, and on what vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dashboard rebuild and the Salesforce certification | see R7, R3 | `[grounded]` your message | pending your approval |
| P2 | Describe the forecast work in your own words: "I run the monthly pipeline review with our sales director; finance owned the company forecast". Never describe it as owning the forecast | see R5 | `[grounded]` your own statement | pending your approval |
| P3 | Your payments-company sales ops background is shared ground with the hiring manager's own path; mention it as context, not as a claim about what she wants | see Role reality, Reporting line | `[grounded]` public profile snippet; `[inferred]` that it helps positioning | pending your approval |
| P4 | Confirm the two-day Bristol pattern works before applying | see R1 | `[grounded]` JD | pending your approval |
| P5 | Ask RR2–RR5's verification questions word for word in the interviews | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about) as a snippet, and "quillfield.co.uk careers Revenue Operations Lead", which returned nothing (the listing wasn't found on Quillfield's own site). Moved the Organization row and RR3 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide) as a snippet. Moved the market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe) as a snippet. Moved the Reporting line row and P3 |

I can save this as `tuesday-dossier.md` so later prep starts from it. Just ask.

**Upgrade menu**
- Where you're based and the office pattern you'll accept → R1 closes and the decision firms up.
- Your salary floor → set against RR1's band.
- An answer to G1 → R6 moves to adjacent or confirms a must-have gap.
- A sanitized pipeline review deck or forecast-style model → strengthens G2's case for R5.
- Your Salesforce credential verification link → R3 to high.
- A deeper research pass on Quillfield: leadership changes, hiring patterns, employee reports, recent news (up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1 — Can you work from Quillfield's Bristol office two days a week? If you have a salary floor, add it here too.

G1 — Did finance ever use your renewal dashboards, or did you send pipeline or renewal numbers into their forecast? What was yours, and what was theirs?

G2 — In your monthly pipeline review, do you make a call on what will close, such as commit, best case or weighted? Have you ever checked those calls against what actually closed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.