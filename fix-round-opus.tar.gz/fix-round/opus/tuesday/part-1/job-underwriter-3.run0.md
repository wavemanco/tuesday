Now the required references.
**No, this one isn't worth pursuing. Your instinct is right: R1 and R2 are both hard gates, and both fail. Status: `no_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay of at least $150k), R2 (Remote-only, from Portland)
- `must_have`: direct: R3, R4, R5, R6 · unclear: R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops)
- `important`: adjacent: R11 (Hands-on execution as a team of one), R13 (E-commerce enablement context) · unclear: R12 (Board-facing reporting)

R1, R2: two gates that no wording can fix; R3, R4, R5, R6: the core of the mandate lines up with your record, at `medium` until probed; R7, R8, R9, R10: channels your background, as you shared it, doesn't mention.

**Opportunity ledger.** Leaving your constraints aside, the role still looks over-bundled and under-resourced. It folds seven functions into a team of one (RR4) with no stated budget (RR7). It expects always-on hours (RR5) and says its success metrics will shift (RR6). The base looks thin for the mandate, though that's unconfirmed until a market check runs (RR2). The equity is unquantified (RR8), and I couldn't verify the employer (RR9). On the plus side: the role reports to the CEO with board access (RR10), and the posting says the company is profitable (RR11).

- **Hard gates:** failed: R1 (Base pay of at least $150k), R2 (Remote-only, from Portland).
- **Severe red flags:** RR1 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** Novaline would have to offer at least $150k base *and* fully remote work. The posting fixes both against you ("$70–85k", "5 days a week — no exceptions"). The only other route is you changing a non-negotiable.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline: e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting; not verified, since research couldn't run (RR9) |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin, 5 days, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" (equity not quantified) | `[grounded]` posting |
| First-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | A head-of-function title and an 8+-years leadership bar attached to an individual-contributor structure. It asks for leadership experience but gives you no one to lead | `[inferred]` from the 8+-years requirement against "team of one" |
| Unknowns | Growth budget; equity terms (percentage, vesting, strike); what "when it matters" means in practice; whether customers are merchants (B2B) or shoppers | — |
| Contradictions | None between documents (only the posting was provided) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of at least $150k (your hard constraint) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor, which is specific and confirmed. Fit fails because the posted top of band, $85k, is $65k below it | `[grounded]` posting and your intake statement | Only an employer change of terms resolves this; see RR1 |
| R2 | Remote-only, from Portland, no relocation (your hard constraint) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint. Fit fails because the posting requires on-site Austin work "5 days a week — no exceptions" | `[grounded]` posting and your intake statement | Only an employer change of terms resolves this; see RR3 |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | 9 years, as Growth Lead and then Head of Growth at two companies; self-reported, so capped at medium until probed | `[grounded]` your background | none |
| R4 | Own revenue growth end to end | must_have | direct | medium | none | Scaled one company from $8M to $40M ARR over three years with a budget you controlled; specific, but nothing inspectable yet | `[grounded]` your background | A board deck or growth model would raise it to high |
| R5 | Paid acquisition | must_have | direct | medium | none | You stated you owned paid | `[grounded]` your background | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You stated you owned lifecycle, and you're deep in Braze | `[grounded]` your background | none |
| R7 | SEO/content | must_have | unclear | none | discovery | Not mentioned in what you shared | `[grounded]` silence in your background | G1 |
| R8 | Brand and PR | must_have | unclear | none | discovery | Not mentioned | `[grounded]` silence in your background | G2 |
| R9 | Partnerships | must_have | unclear | none | discovery | Not mentioned | `[grounded]` silence in your background | G3 |
| R10 | Sales ops | must_have | unclear | none | discovery | Not mentioned. Your history is B2C subscription, and sales ops is usually a B2B function | `[grounded]` silence in your background; `[generic]` that sales ops is typically B2B | G4 |
| R11 | Hands-on execution as a team of one | important | adjacent | medium | transferability | You built and managed teams of 3–7, and your SQL/GA4/Braze depth suggests you can do the work yourself. Limit: nothing shows you running every channel solo | `[grounded]` your background; `[inferred]` hands-on capability from tool depth | G5 |
| R12 | Board-facing reporting (dotted line) | important | unclear | none | discovery | Not mentioned | `[grounded]` silence in your background | G6 |
| R13 | E-commerce enablement context | important | adjacent | medium | transferability | B2C subscription growth carries over to acquisition and retention mechanics. Limit: selling to merchants, if that's who the customers are, is a different motion | `[inferred]` requirement from "e-commerce enablement" plus "sales ops"; `[generic]` that B2B and B2C growth motions differ | G7 |

## Gap recovery queue

None of these can move the decision while R1 and R2 fail. They're kept for completeness, and they'd matter for similar roles.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | No mention | It's a named channel in the mandate | Owning organic acquisition targets; running a content calendar | An organic-traffic dashboard | `[grounded]` silence |
| G2 | Brand and PR (R8, must_have) | discovery | No mention | It's a named function in the mandate | Managing a PR agency; a rebrand launch | Press placements, a brand brief | `[grounded]` silence |
| G3 | Partnerships (R9, must_have) | discovery | No mention | It's a named function in the mandate | Affiliate or co-marketing deals, integration partners | A partner list with revenue attribution | `[grounded]` silence |
| G4 | Sales ops (R10, must_have) | discovery | No mention; B2C history | It's a named function in the mandate | CRM pipeline setup, a hand-off from growth to sales | A pipeline report | `[grounded]` silence |
| G5 | Team-of-one execution (R11, important) | transferability | A manager of teams with hands-on tool depth | Without a bench, you'd be doing all the execution yourself | Periods before you hired, or solo-run channels | Campaigns you built yourself | `[inferred]` from your stated tool depth |
| G6 | Board reporting (R12, important) | discovery | No mention | The role has a dotted line to the board | Presenting growth metrics to a board or investors | A board-deck excerpt | `[grounded]` silence |
| G7 | E-commerce enablement (R13, important) | transferability | B2C subscription growth | The customer base may be B2B | Any B2B or merchant-facing work | A case study | `[inferred]` from the posting's sector |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay conflicts with your floor (see R1) | red_flag | high | "$70–85k base" | Top of band is $65k below your $150k floor | `[grounded]` posting and your constraint | Is there any flexibility in base above the posted range? | confirmed |
| RR2 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required … $70–85k base" | The base may sit below what an 8+-year, full-function head role commands at market. Medium rather than high because the market check couldn't run | `[inferred]` from the posted years and mandate against the posted base | How did you benchmark this range for the title? | unresolved |
| RR3 | Full on-site work conflicts with remote-only (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | No remote path exists | `[grounded]` posting and your constraint | Is the on-site requirement truly fixed for this role? | confirmed |
| RR4 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops … a team of one" | Several full roles folded into one seat | `[inferred]` from the function list against the team size | Which of these functions matter most in year one, and when does headcount arrive? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be the norm rather than the exception | `[inferred]` from the posting's framing of it as identity | How often in the last quarter did "when it matters" happen? | unresolved |
| RR6 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You'd be accountable for revenue without a fixed definition of success | `[inferred]` from the posting's wording | What number would make year one a success? | unresolved |
| RR7 | Responsibility without stated resources | risk_signal | medium | "Own all revenue growth end to end" | No budget or spend authority is mentioned | `[inferred]` from the mandate against the posting's silence on budget | What growth budget does this role control? | unresolved |
| RR8 | Equity unquantified | unknown | — | "meaningful equity upside" | Equity may be offered in place of cash, on undisclosed terms | `[inferred]` from the posting's wording | What percentage, vesting schedule and strike price? | unresolved |
| RR9 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A…)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR10 | CEO reporting line with board access | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has real seniority of access | `[grounded]` posting | How often does this role present to the board? | noted |
| RR11 | Profitability stated | positive_signal | — | "profitable since day one" | The company may have runway that doesn't depend on fundraising | `[grounded]` posting, unverified | Can you share revenue scale or growth rate? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | See R1, R2 | `[grounded]` map | pending your approval |
| A2 | If a Novaline recruiter reaches out, state both terms before anything else, in your own words: "$150k base minimum, and I'm remote-only from Portland." Keep both conditions joined, not either-or | See RR1, RR3 | `[grounded]` your intake statement | pending your approval |
| Q1 | If you engage anyway, ask the verification questions for RR2 and RR4–RR9 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1, R2 claims (your stated constraints, intake message). Your background claims are self-reported leads and not yet probed.

Research tier: L1, searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth". The host refused it (search permission not granted). It would have confirmed or cleared RR9 and the organization row |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026". The host refused it. It would have set a market calibration line and confirmed or downgraded RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can write all this up as a `tuesday-dossier.md` if you want a saved copy.

## Upgrade menu

- **Allow web search**, then targets 1–2 rerun: RR9 clears or confirms, and RR2 gets a real market band. Neither changes `no_go`.
- **Proof for R7–R10 and R12** (an organic-traffic dashboard, press placements, a partner revenue list, a board-deck excerpt): those rows move off `unclear`. That's worth having ready for the next Head of Growth posting with your terms.
- **A deeper research pass on Novaline** (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs. It can't change this decision, because the gates fail on the posting's own terms.

There are no questions this turn. The decision already rests on your own stated constraints, so no answer could change it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.