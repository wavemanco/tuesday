Still reading the role-assessment checklist. Then I'll write your verdict.
**Yes, apply, but first confirm it's actually remote. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6 · unclear: R7 (monitor rating models)
- `important` — adjacent: R9 (pet-insurance product) · unclear: R8 (recommendations for … product)
- `preferred` — direct: R10

R7 — "maintained" may cover monitoring, but you haven't said so yet; R9 — the motor-to-pet bridge, with its limit named; R8 — no evidence yet that you've presented to a product team.

**Opportunity ledger.** The employer and the posting are real and live (RR3). The working pattern contradicts itself: your JD says fully remote and Brindlemoor's own careers page says Leeds four days a week (RR1). The salary isn't stated (RR2), and the JD doesn't say how much "own" covers (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found. RR1 is `severity: medium`.
- **Conditions for go:** (1) the working pattern is confirmed and you can live with it — R1, RR1; (2) pet insurance is framed as a transferable case, never as experience you have — R9; (3) R7 and R8 are confirmed before you lean on them in an application.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics for pet: build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (you named Odile Varga) | `[grounded]` careers page; your message |
| Line management | The JD doesn't ask for any. "Never managed anyone" doesn't match any requirement here | `[grounded]` JD lists no people-management requirement |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both sources, quoted |
| Hiring manager's public footprint | Director of Pricing at Brindlemoor. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result snippet (profile not fetched) |
| Scope read | This is an individual-contributor senior role. Its weight is in modelling, testing and influence, not in leading a team | `[inferred]` from the responsibilities list against the absence of any team or management language |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 (n=612). This is a market band, not Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey; `[grounded]` JD for the missing salary |
| Unknowns | Salary; the real working pattern; pricing team size; whether "own" includes model sign-off | — |
| Contradictions | Fully remote (JD) vs Leeds four days a week (careers page) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated a location constraint, so the band has nothing to grade. The fit is also unclear on the employer's side, because their two sources disagree (RR1). If the role is Leeds four days a week, it only works if you can commute there | `[grounded]` JD and careers page quoted; no constraint stated | Question G1; RR1's question to the recruiter |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, as you stated. Self-report with nothing inspected, which caps it at medium | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", stated, not inspected | `[grounded]` your background | Optional: a sanitized code sample would raise this to high |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book." Specific, but nothing inspected | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team." "Ran … with" doesn't say which part of the design was yours. Expect a probe on that | `[grounded]` your background; `[generic]` that interviews for this role probe who designed the test | Be ready to say what was yours and what was underwriting's |
| R7 | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include monitoring, but you haven't said so. Assuming it would be adding a practice you never stated | `[grounded]` your background is silent on monitoring | Question G2 |
| R8 | Turn results into recommendations for product | important | unclear | low | discovery | Underwriting is covered (R5). Nothing you've said shows work with a product team | `[grounded]` your background is silent on product | Question G3 |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Inferred from "our pet-insurance product". Your GLM, testing and review work carries over. Limit: you've never worked on pet, whose rating factors and claims drivers differ from motor's | `[inferred]` requirement from the JD's product focus; `[grounded]` that you've never worked on pet | See G4 |
| R10 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD and the careers page disagree, and you haven't said whether you need remote | If it's Leeds four days and you can't do that, the decision becomes `no_go` | — | The recruiter's written confirmation of the working pattern | `[grounded]` both sources quoted |
| G2 | Monitor rating models (R7, must_have) | discovery | You built and maintained the young-driver GLM. Nothing yet on how you tracked whether it was still performing | This is the only must-have below `direct`, and the hiring manager's published talk is on monitoring rating models | Actual-vs-expected tracking by factor or segment; drift or stability checks after a rate change; loss-ratio monitoring for the young-driver book; deciding when to refit or recalibrate | A sanitized monitoring dashboard or A-vs-E pack, or a refit decision memo | `[grounded]` your background and the talk title; `[inferred]` that this row matters more to this reader |
| G3 | Recommendations to product (R8, important) | discovery | Your audience so far is underwriting | Product is a named audience in the JD | Pricing input to a product change or a new cover option; test results that changed a product decision; working with a product owner on quote-journey or discount changes | A sanitized recommendation deck or a decision note | `[grounded]` JD names product; your background is silent on it |
| G4 | Pet-insurance knowledge (R9, important) | transferability | Motor only | The likeliest objection to a motor candidate | Carries over: GLM rating, price testing, underwriting reviews. Limit: you haven't worked with pet rating factors (breed, age) or vet-cost inflation. Strengthener: a short read of public pet-pricing material before interviews, framed as learning, not experience | — | `[grounded]` that you have no pet experience; `[generic]` the pet rating factors named and that this objection is the likeliest |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | One source is out of date, or the pattern changed after the JD you have was written. Either way you don't know which one is current | `[grounded]` both quoted; `[inferred]` the out-of-date-copy explanation | Is this role fully remote, or Leeds four days a week as your careers page says? | unresolved |
| RR2 | Salary not stated | unknown | — | (the JD gives no figure) | The figure may sit anywhere against the £52.1k–£64.9k band in role reality | `[inferred]` from the missing figure, against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Employer and posting verified live | positive_signal | — | "Accepting applications" | The role exists and is open | `[grounded]` careers page fetched | Who else works on pet pricing today? | noted |
| RR4 | "Own" with no team or sign-off stated | unknown | — | "Own pricing analytics for our pet-insurance product" | This could mean sole analyst with sign-off, or analysis that feeds someone else's sign-off | `[inferred]` from "own" against the JD's silence on team and authority | How many people work on pet pricing, and does this role sign off rate changes or recommend them? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter before investing time | RR1, R1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with three things, in your own words: "built and maintained the GLM rating model for our young-driver book"; "ran 14 price tests last year with the underwriting team"; "present the quarterly pricing review to the head of underwriting" | R4, R6, R5 | `[grounded]` your background, quoted | pending your approval |
| P2 | If G2 confirms model monitoring, put it first for this hiring manager | R7; her published talk topic | `[grounded]` the talk title; `[inferred]` that it's the best lead story for this reader | pending your approval |
| P3 | Frame pet as a domain you'd be moving into, never as one you know | R9 | `[grounded]` that you have no pet experience | pending your approval |
| Q1 | Ask the RR1, RR2 and RR4 questions word for word in the first call | Register | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Gave the working-pattern contradiction (RR1, R1), the live posting (RR3) and the reporting line |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary remote GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Gave the market calibration band and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga, snippet only). Gave the role-reality footprint row, the G2 priority and P2 |

I can write all of this up as a `tuesday-dossier.md` you can carry into later steps, if that's useful.

**Upgrade menu**
- Your location and working-pattern constraint → closes R1, and the decision firms up to `go` or `no_go`.
- An answer to G2 → R7 moves out of `unclear`, and P2 becomes usable.
- An answer to G3 → R8 resolves.
- A sanitized monitoring pack, test readout or code sample → the matching row rises to `high`.
- The recruiter's salary figure → RR2 closes, compared against the band.
- A deeper research pass on Brindlemoor (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Just say so and it runs.

**Questions**

G1 — Do you need this role to be fully remote, or could you do Leeds four days a week if that turns out to be the real pattern?

G2 — When you maintained the young-driver GLM, how did you check it was still performing (for example actual-vs-expected, drift checks, refit decisions), and which parts of that were yours?

G3 — Have any of your price-test results or pricing reviews gone to a product team, or changed a product decision, and what was your part?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.