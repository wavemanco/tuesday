Now the step-1 reference files.
Yes. Apply, once the checks below come back clean. My web searches were blocked, so this is based only on what you pasted.

## Decision snapshot

**Yes, go for it, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6a · unclear: R6b (design … price tests)
- `important`: direct: R8 · adjacent: R7 (recommendations for underwriting and product), R10 (pet-insurance product)
- `preferred`: direct: R9

R6b: was the test design yours? R10: motor is a credible bridge to pet, with its limit stated. R7: the underwriting side is covered, the product side isn't. R1: your inputs don't confirm this gate.

**Opportunity ledger.** I couldn't confirm the employer exists as described, because the searches were refused (RR1). The salary isn't stated (RR2), and it's unclear whether "own" means you'd be the only pricing analyst (RR3). On the plus side, the requirements line up with the responsibilities (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you're UK-based and eligible to work here (R1); (2) Brindlemoor and the live posting check out (RR1); (3) you present pet as a new domain your motor rating work carries over to, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not checked online (RR1) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing (hiring manager) | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Line management | None stated. The JD asks for no people management | `[grounded]` JD silence |
| Scope read | A senior individual-contributor pricing role. "Own" could mean a one-person pricing function | `[inferred]` from "own" and "senior" against the JD's silence on team size |
| Compensation | Not stated | `[grounded]` JD; see RR2 |
| Unknowns | Team size; salary; how much the role decides versus recommends; success measures | none |
| Contradictions | None found within the JD. It couldn't be checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK): UK-based, right to work | hard_gate | unclear | low | hard_gate | `[inferred]` "(UK)" read as a UK-residence term. Working at a UK insurer suggests you meet it but doesn't prove it, and you stated no location or authorisation | `[grounded]` JD; `[inferred]` gate reading | Closing question R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years against 4+ asked, the last 2 as senior. This is your own account with nothing to inspect yet, so `medium` | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily, by your account. `[generic]` Expect a technical exercise to probe it | `[grounded]` your background; `[generic]` probe | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific and on-target | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. This matches the JD almost word for word | `[grounded]` your background | none |
| R6a | Run and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | none |
| R6b | Design price tests | must_have | unclear | low | discovery | "Ran … with the underwriting team" doesn't say who designed the tests: you, underwriting, or a set template. The lower reading applies until you answer | `[grounded]` your wording | Closing question G1 |
| R7 | Recommendations for underwriting and product | important | adjacent | medium | discovery | The underwriting side is covered by R5. You mentioned no work with a product team | `[grounded]` your background and its silence on product | Closing question G3 |
| R8 | Build and monitor rating models | important | direct | medium | none | You built and maintained a rating model. "Maintained" is read as including monitoring, which is worth confirming in your own words | `[grounded]` your background | none |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pricing a pet-insurance product | important | adjacent | medium | transferability | You've never worked on pet. Your GLM and price-test work is on another personal-lines book. `[generic]` Pet rating uses different risk factors and claims patterns | `[inferred]` requirement from "our pet-insurance product"; `[generic]` domain difference | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Design price tests (R6b, must_have) | discovery | 14 tests run with underwriting; your part in designing them isn't stated | A `must_have` row at `unclear`; the JD says "design and read" | Setting the test cells or price changes; deciding sample sizes or how long a test ran; choosing the success metric; writing the test plan underwriting signed off | A sanitised test plan or a results write-up | `[grounded]` your wording; `[generic]` that interviews probe design ownership |
| G2 | Pet-insurance pricing (R10, important) | transferability | GLM build and price testing on young-driver motor | Carries over: GLM build and maintenance, test reading, presenting to underwriting. Doesn't carry over: pet-specific rating factors and claims behaviour. What would close the gap: a short note on how you'd approach a pet rating model | A new rating factor or segment you introduced; a book you priced with little data of its own | A one-page "how I'd approach pet rating" note, offered as a work sample | `[inferred]` bridge from your motor work; `[generic]` that domain is the likeliest objection |
| G3 | Product-side recommendations (R7, important) | discovery | Underwriting audience confirmed; no product audience mentioned | Half of R7's stated audience | A recommendation that changed a product feature, excess or cover level; work with a product owner on a launch or a renewal change | A deck or memo extract | `[grounded]` your silence on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have much online presence, or the posting may be old or copied from elsewhere. It may also not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; the searches were refused, not empty | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | (no salary in the posting) | The figure may sit below what a senior role usually pays, or the company may simply not publish salaries | `[inferred]` from the omission | What salary range is budgeted for this role? | unresolved |
| RR3 | Size of the pricing function | unknown | — | "Own pricing analytics for our pet-insurance product" | This may be the only pricing seat, with model building, monitoring, test design and recommendations all in one role | `[inferred]` from "own" against the JD's silence on team | How many people work on pet pricing today, and who would I work with day to day? | unresolved |
| RR4 | Requirements match the stated responsibilities | positive_signal | — | "build and monitor rating models, design and read price tests" | The role looks clearly specified, not a bundle of several roles | `[inferred]` from the JD's requirements against its responsibilities | What would a strong first year in this role look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Open with your two strongest facts, in your own words: "Built and maintained the GLM rating model for our young-driver book" and "Ran 14 price tests last year with the underwriting team" | See R4, R6a. Only say "designed" once G1 confirms it | `[grounded]` your background | pending your approval |
| P2 | Present pet honestly: "My rating and testing work is in motor; I haven't priced pet, and here's how the GLM and test work carries over" | See R10, G2 | `[grounded]` your statement that you've never worked on pet | pending your approval |
| P3 | Don't apologise for not managing people. If asked, say plainly you haven't line-managed anyone | The JD asks for none (role reality) | `[grounded]` JD silence; your statement | pending your approval |
| P4 | Check the employer and the live posting before you spend time on the application | See RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Ask the RR1–RR4 questions word for word in the recruiter screen or hiring-manager round | The register doubles as interview prep | `[grounded]` register | pending your approval |
| W1 | Optional work sample: a one-page note on how you'd approach a pet rating model | See G2 | `[inferred]` from the R10 bridge | pending your approval |

Each line above is proposed wording or a proposed step for you to approve, not something final.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Brindlemoor pet insurance insurtech" was refused (permission not granted). It would have confirmed the company and the live posting, and cleared RR1 |
| 2. Role-family sweep | unavailable | The search "senior pricing analyst pet insurance UK salary GLM" was refused. It would have added a market calibration line and a salary band to set against RR2 |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have informed the scope read and which story P1 leads with for this reader |

## Next steps

If you'd like, I can turn this into a saved `tuesday-dossier.md` you can bring back later.

**Upgrade menu**
- **Allow web search:** targets 1–3 run within the L1 budget I have left. That could clear RR1 and add a salary band and a read on the hiring manager.
- **A sanitised test plan or results deck:** raises R6a, and R6b if it shows your design, to `high`.
- **Your salary floor and location or right-to-work status:** settles R1 and lets me check RR2 against your number.
- **The posting's URL:** helps with RR1.
- **A deeper research pass on Brindlemoor** (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

R1: Are you based in the UK with the right to work here without sponsorship?

G1: For those 14 price tests, which parts were yours: choosing the price changes and test cells, setting the sample size and duration, picking the success metric, or reading the results?

G3: Has any of your pricing analysis gone to a product team, or changed a product feature, excess or cover level? What was your part?

For any of these, you can reply in text, paste a voice transcript, attach a document, drop a link, or say skip. If you decide to apply, mock-interview can prep you for the round with Odile Varga.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.