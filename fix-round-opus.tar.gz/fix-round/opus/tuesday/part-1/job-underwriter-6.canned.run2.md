Reading the posting now, then I'll do a quick check on the company and the role.
**Yes, it's worth applying, with a few conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, hybrid: two days a week in the office)
- `must_have` — direct: R2a, R3, R4a · adjacent: R5 (Experience owning a forecast) · unclear: R2b (At a B2B software company), R4b (Spreadsheet modelling), R6 (Working with finance on billing or revenue data)
- `important` — direct: R7

R5 — finance owned the forecast, so this is related experience, not a match; R6 — the open row most likely to change how you pitch yourself; R1 — unconfirmed only because you didn't say where you're based.

**Opportunity ledger.** The role looks sound. The pay is stated and sits close to the market median (RR2). The role is listed on a job board but I couldn't find it on Quillfield's own site (RR1). The scope covers CRM, billing data and the CFO forecast, with nothing said about a team (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid: two days a week in the office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) two office days a week in Bristol work for you (R1); (2) you present R5 honestly as related experience: you ran the pipeline review, not the forecast; (3) the recruiter confirms the role is still open (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded in Bristol in 2018, 96 employees, £11M Series A in April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` posting |
| Terms | Bristol, hybrid with two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield. Previously sales operations manager at Corvane Payments for four years | `[grounded]` search result snippet (linkedin.example/in/tamsin-achebe), matches what the recruiter told you |
| Scope read | This is RevOps plus part of a finance-ops role: billing data and a CFO-facing forecast go beyond CRM reporting | `[inferred]` from the mandate's billing and forecast duties |
| Market calibration | Ledgerline's 2026 UK figures for a revenue operations lead in B2B software (n=438): median base £64,200, middle half £57,800–£70,400. The posting's £61.5–67k is inside that range and around the median. This is a national figure, not Bristol-specific, and it isn't Quillfield's offer | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` posting, for the figure |
| Unknowns | Team size and who reports to this role; which billing system is used; value of the share options; whether the role is still open | — |
| Contradictions | None between the posting, the company's About page and what the recruiter told you | `[grounded]` posting, About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid: two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't stated your location or office limits, so there's nothing to grade yet. "UK team" doesn't settle it | `[grounded]` posting; your background is silent | Question R1 below |
| R2a | 4+ years in revenue ops, sales ops or a similar analytics role | must_have | direct | medium | none | 5 years in sales ops, the last 2 running revenue ops for the UK team. You stated it but nothing has been inspected, so it stays at `medium` | `[grounded]` your background | none |
| R2b | …at a B2B software company | must_have | unclear | low | discovery | You said "B2B payments company". Whether it sells software isn't stated, and the posting's word is "software" | `[grounded]` your wording against the posting's | Upgrade menu |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The credential can be checked, but I haven't seen it | `[grounded]` your background | Share the credential link to raise this to `high` |
| R4a | Strong SQL | must_have | direct | medium | none | You use SQL weekly | `[grounded]` your background | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | Using Excel daily is not the same as building models. Whether you've built driver-based or scenario models isn't stated | `[grounded]` your background | Upgrade menu |
| R5 | Experience owning a forecast (the role runs the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | What carries over: you run the monthly pipeline review with the sales director. The limit: you've never owned the company forecast, because finance did. Interviews for forecast-owning roles tend to test the step from pipeline review to a committed number | `[grounded]` your background; `[generic]` that interviews test that step | Gap queue G1 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Billing data is ruled out by your own statement. Revenue data shared with finance (for example, behind the renewal dashboards) is unconfirmed either way. Low, not none, because the renewal work is something concrete to ask about | `[grounded]` your background | Gap queue G2 |
| R7 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your company's pipeline and renewal dashboards. Whether finance used them isn't stated | `[grounded]` your background | A sanitized screenshot would raise this to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R5, must_have) | transferability | You run the monthly pipeline review. You've never owned the company forecast | It's a `must_have` row at `adjacent`, and the role puts you in front of the CFO with the number | Making the call on commit vs best-case deals in the review; tracking how pipeline coverage or stage conversion turned into closed revenue; producing a UK pipeline number that someone else then used | A sanitized pipeline-review pack or a coverage/conversion sheet | `[grounded]` your background; `[inferred]` that a stronger bridge here makes the case |
| G2 | Finance revenue data (R6, must_have) | discovery | You've never worked on billing data. Whether your renewal reporting involved finance is unknown | It's a `must_have` row, and the role owns billing data | Reconciling CRM bookings or renewals to finance's figures; feeding ARR, churn or renewal numbers to finance; commission or quota data agreed with finance | A reconciliation sheet or a renewal-to-finance report (sanitized) | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not found on Quillfield's own site | risk_signal | low | "Revenue Operations Lead — Quillfield \| Tallyboard Jobs" | Quillfield may not have a careers page, or the job-board copy may be out of date. The company itself checks out and the hiring manager matches, so the risk is low | `[generic]` common pattern with job-board listings at small companies; `[grounded]` careers page returned nothing and a search found no other listing | Is this role still open, and is the Tallyboard listing the current version? | unresolved |
| RR2 | Pay stated, within the market range | positive_signal | — | "£61,500–£67,000 plus share options" | The pay is set openly and in line with the market | `[grounded]` posting, against the `[generic]` Ledgerline range | What share-option grant comes with the role, and on what vesting? | noted |
| RR3 | Broad mandate with no team mentioned | unknown | — | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | You may be working alone across CRM, billing and forecasting | `[inferred]` from the scope of the mandate against the posting's silence on a team | Who would I work with on billing data and the forecast? Does anyone report to this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with these two lines, in your own words: "rebuilt our pipeline and renewal dashboards" and "I run the monthly pipeline review with our sales director" | See R7, R5 | `[grounded]` your background | pending your approval |
| P2 | Be upfront about the forecast: "I've run the monthly pipeline review with our sales director; I haven't owned the company forecast — finance did." | See R5. Saying it plainly yourself is safer than having it come out in an interview | `[grounded]` your own sentence | pending your approval |
| P3 | Mention the payments-industry context in your application | Tamsin Achebe's last role was sales ops at a payments company (role reality). That's a fact about her career, not a claim about what she's looking for | `[grounded]` search result snippet | pending your approval |
| P4 | Ask the recruiter to confirm the role is open before you write a tailored application | See RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Ask the RR2 and RR3 questions word for word at the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers: no page. Searched `Quillfield "Revenue Operations Lead" job Bristol`: no results. Moved the organization row and RR1 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved market calibration and RR2. This covered pay only, not typical scope |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. Moved the hiring-manager row and P3 |

If it would help, I can write this up as a `tuesday-dossier.md` file you can keep or bring to a later step.

**Upgrade menu**
- Your Salesforce credential link → R3 to `high`.
- A sanitized screenshot of the dashboards you rebuilt → R7 to `high`.
- Whether your current employer sells software or only processes payments → R2b resolves.
- A spreadsheet model you built, or a description of one → R4b resolves.
- Your pay floor and any location limits → R1 settles, and the £61.5–67k range gets checked against your floor.
- The recruiter confirming the role is open → RR1 closes.
- A deeper research pass on Quillfield (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1: Can you work from the Bristol office two days a week?

G2 (R6): Have you worked with finance on any revenue numbers, such as renewals, bookings, ARR or commission, or reconciled CRM figures to theirs? What did you own?

G1 (R5): In the monthly pipeline review, do you produce a number, such as a commit or a UK forecast, and have you tracked how it compared with what actually closed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.