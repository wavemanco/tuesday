Now the worked report (I need it for the shapes) — reading the first part.
## Decision snapshot

**Yes, it's worth going for, but as a stretch on forecasting and billing, not a clean match. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week), R2 (£61,500–£67,000 salary)
- `must_have`: direct: R3a, R4, R5a, R6 · adjacent: R8 (Experience owning a forecast) · unclear: R3b (At a B2B software company), R5b (Spreadsheet modelling), R9 (Working with finance on billing or revenue data) · absent: R10 (Own billing data)

R8: a real bridge from your pipeline review, but you've never owned the number; R9, R10: the billing side is where the posting goes furthest past your background.

**Opportunity ledger.** The role looks sound and open about its terms. The salary is published and sits in the market band (RR3). The scope is wide for one role (RR1), it's unclear who owns the forecast number (RR4), and I couldn't find the role on Quillfield's own site (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week), R2 (£61,500–£67,000 salary); candidate constraints not given, so I couldn't check the role against them
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol two days a week and the salary range work for you (R1, R2); (2) you describe the forecast experience as what it is: you ran the pipeline review that feeds the forecast, and finance owned the forecast itself (R8); (3) G2 shows you've worked with finance on revenue data, or you go in knowing billing is the gap you'll be asked about (R9, R10, RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Bristol, founded 2018, 96 employees, Series A (£11M) in April 2025 | `[grounded]` quillfield.co.uk/about, search snippet only (page not fetched) |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` JD |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` JD |
| Compensation | £61,500–£67,000 plus share options | `[grounded]` JD |
| Reporting line | Hiring manager Tamsin Achebe, Head of Revenue Operations; previously four years as a sales operations manager at Corvane Payments | `[grounded]` recruiter, via you; public profile search snippet |
| Scope read | One "Lead" title covering CRM admin, billing data, reporting for two departments and the forecast. That's a full RevOps remit, and plausible for a ~100-person Series A company | `[inferred]` from the JD's four responsibilities against the stated headcount |
| Market calibration | UK B2B software RevOps leads: median base £64,200, middle half £57,800–£70,400 (n=438). The posted range sits inside that band and spans the median. This is a market band, not Quillfield's offer | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide, search snippet; `[grounded]` JD range |
| Unknowns | Who owns the forecast number (CFO or this role); team size under the role; billing system; share-option terms | — |
| Contradictions | None between the posting and the company's own description | `[grounded]` posting against the about-page snippet |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days a week in office | hard_gate | unclear | none | hard_gate | You didn't say where you're based or what you can do on office days; the JD states the term | `[grounded]` JD; your background is silent | Closing question on R1 and R2 |
| R2 | £61,500–£67,000 salary | hard_gate | unclear | none | hard_gate | No pay floor stated, so I can't check it against the range | `[grounded]` JD; no floor given | Closing question on R1 and R2 |
| R3a | 4+ years in revenue or sales operations | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team. That's stated, but there's nothing yet to inspect | `[grounded]` your background | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether its product counts as software isn't established | `[grounded]` your background; `[generic]` many payments companies sell software platforms, but not all | See G5 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certification can be checked publicly but hasn't been inspected yet | `[grounded]` your background | Share the credential link to raise this to high |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly, as you stated. Depth hasn't been probed, so expect a technical question | `[grounded]` your background | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows use, not modelling: driver-based models, scenarios, forecast builds | `[grounded]` your background's wording | See G4 |
| R6 | Build pipeline and renewal reporting for sales and finance | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards, which matches the JD directly. Whether finance used them isn't stated | `[grounded]` your background | none |
| R8 | Experience owning a forecast; running the quarterly forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director, which is the main input to a forecast. You say you've never owned the company forecast; finance did | `[grounded]` your own statement | See G1 |
| R9 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data, but the JD says "billing *or* revenue data". Renewal dashboards may have used contract values or ARR (annual recurring revenue) from finance. That isn't established | `[grounded]` your statement and the JD's "or" | See G2 |
| R10 | Own the company's billing data | must_have | absent | none | capability | You've never worked on billing data. Your payments-company background is the one thing that could turn this into a discovery gap rather than a capability gap | `[grounded]` your own statement | Closure path in G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R8, must_have) | transferability | You run the monthly pipeline review that feeds the forecast. Finance owned the forecast itself | It's a named JD requirement and a CFO-facing responsibility, so it's the gap you're most likely to be questioned on | Commit and best-case calls you made in the review; tracking deal slippage or forecast accuracy; feeding numbers to finance's forecast and reconciling differences | A sanitized pipeline-review deck, or a screenshot of an accuracy tracker | `[grounded]` your statement; `[generic]` that CFO-facing forecast roles probe ownership of the number |
| G2 | Finance on revenue data (R9, must_have) | discovery | Renewal dashboards are stated; the data source and the finance link aren't | The JD's "or" means revenue data alone may meet this requirement | Pulling contract values or ARR from finance for renewals; reconciling CRM bookings against finance's figures; churn or expansion reporting finance used | A dashboard screenshot with data sources labelled | `[grounded]` the JD's wording |
| G3 | Own billing data (R10, must_have) | capability | No billing-data work stated | It's a core responsibility. The closure path is learning invoicing-to-revenue data flows and how the CRM syncs with a billing system before interviews | (closure path, not recall) | — | `[grounded]` your statement |
| G4 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use, with modelling depth unknown | Forecasting work usually relies on spreadsheet models | Capacity or quota models; renewal-rate scenarios; territory planning | A sanitized model | `[generic]` role-family pattern |
| G5 | B2B software employer (R3b, must_have) | discovery | B2B payments company | A literal screen could read the requirement narrowly | Whether your company sells a software platform | Company description | `[inferred]` from the JD's wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Wide remit for one Lead role | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting… and run the quarterly revenue forecast" | The role may be a one-person RevOps function covering admin, data and the forecast | `[inferred]` from four responsibilities against 96 staff | Who else works in RevOps, and who touches billing data today? | unresolved |
| RR2 | Posting not found on Quillfield's own site | risk_signal | low | Listed on Tallyboard Jobs | The company may not run a careers page, or the listing may be aggregated. A recruiter naming the real Head of RevOps makes it less likely to be stale | `[grounded]` /careers returned no page, site search found nothing; `[generic]` small companies often post only on job boards | Is this role open now, and does it report to Tamsin Achebe? | reduced |
| RR3 | Salary published, inside the market band | positive_signal | — | "£61,500–£67,000 plus share options" | The terms are transparent and pay sits at market | `[grounded]` JD; `[generic]` Ledgerline band | What share-option terms come with the offer? | noted |
| RR4 | Forecast ownership split unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The number may stay with the CFO and this role supplies the process, or the role may own it | `[inferred]` from "with the CFO" | Who signs off the forecast number, this role or the CFO? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the pipeline and renewal dashboard rebuild and the Salesforce admin certification | see R4, R6 | `[grounded]` your background | pending your approval |
| P2 | Describe forecasting exactly as it happened: "I run the monthly pipeline review with our sales director; finance owned the company forecast." Never write "forecast owner" | see R8 | `[grounded]` your own wording | pending your approval |
| P3 | Name billing as the thing you'd learn first, and back it with a concrete plan for the first 90 days | see R10, G3 | `[grounded]` your statement | pending your approval |
| P4 | Use payments examples without over-translating them: Tamsin Achebe also came to Quillfield from sales ops at a payments company | see role reality | `[grounded]` profile snippet; `[inferred]` that shared context makes your examples easier to follow | pending your approval |
| P5 | Ask RR1, RR2 and RR4 verbatim with the recruiter or in the first round | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers Revenue Operations Lead", which returned "About Quillfield" (quillfield.co.uk/about) as a snippet, and "quillfield.co.uk jobs revenue operations", which found nothing. Fetched quillfield.co.uk/careers: no page. This moved the organization row and RR2 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B SaaS 2026", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). This moved market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). This moved the reporting-line row and P4 |

I can put this into a `tuesday-dossier.md` to carry into later steps; just ask.

## Upgrade menu

- **Your location, office-day limits and pay floor:** settles R1 and R2, and with them the decision.
- **Answers to G1 and G2:** could move R8's bridge from medium toward high and R9 from unclear to direct.
- **Your Salesforce credential link:** raises R4 to high.
- **A sanitized pipeline-review deck or dashboard screenshot:** raises R6 and R8.
- **Your CV:** lets me check presentation gaps against the actual wording.
- **A deeper research pass on Quillfield** (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

**R1, R2:** Are two office days a week in Bristol and a £61,500–£67,000 base workable for you?

**G1:** In your monthly pipeline review, did you make the commit or best-case calls yourself, and did anyone track how those calls compared with what closed?

**G2:** Did your renewal dashboards use any figures from finance, such as contract values, ARR or invoiced amounts, and did you reconcile them against the CRM?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.