Now the Step 1 references.
Quick update: I've confirmed the posting is live. Next I'm checking the company facts, then I'll write up the assessment.
# Senior Data Engineer at Pellucid Learning: should Ines apply?

## Decision snapshot

**Yes, it looks worth applying to, as long as the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (dbt-modelled warehouse in BigQuery) · unclear: R10 (Ingestion from our app and CRM), R11 (Data contracts our analysts depend on)

R9: Snowflake is close to BigQuery, but the gap has a limit you should name. R10, R11: your background doesn't mention either one yet. R3–R8: each is `medium` only because nothing has been inspected yet.

**Opportunity ledger.** Two good signs: the stated pay is at or above the report's market band (RR1), and both the posting and the company facts match the live site (RR2). Three things are unknown: whether the warehouse already exists or still has to be built (RR3), what "run" means for on-call (RR4), and what the equity is (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work remotely from the US or from Denver (R1); (2) the band meets your pay floor (R2); (3) you describe R9 honestly as Snowflake experience, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states. Founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about page you pasted, matched by the live page |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Scope read | One domain (reporting) from ingestion through to what analysts use. No direct reports are mentioned | `[grounded]` JD; `[inferred]` "no reports" comes from the JD saying nothing about managing people |
| Market calibration | The report defines Senior as 5–8 years, owning one domain's pipelines, with no direct reports, which matches this posting. Its base pay for this level is a $151,000 median with an IQR of $139,000–$163,500. The posting's $148,000 floor is above that P25, and its $166,000 top is above the P75 | `[generic]` Datawright 2026 report (US, n=2,310, Series B–D); `[grounded]` JD for the posted band |
| Unknowns | Hiring manager and team size; whether the BigQuery/dbt warehouse exists yet; on-call expectations; equity terms; your location and pay floor | — |
| Contradictions | None between the text you pasted and the live careers and about pages | `[grounded]` two searches, listed in Evidence status |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you're authorized to work in the US, so the gate isn't settled | `[grounded]` JD term; your background is silent | Closing question on R1/R2 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The band is stated, but you haven't given a floor, so it can't be checked | `[grounded]` JD term; your background is silent | Closing question on R1/R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You said 6 years of data engineering, which is above the threshold. Self-reported, with nothing inspected yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You said "Python and SQL daily." Self-reported; expect a technical screen to test it | `[grounded]` your background; `[generic]` that this role family tests it live | none |
| R5 | dbt | must_have | direct | medium | none | You said you built your company's dbt project, about 180 models. Specific, but nothing inspected yet | `[grounded]` your background | A sanitized repo or dbt docs page would raise it (upgrade menu) |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the requirement says "a cloud warehouse", not BigQuery | `[grounded]` JD wording; your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You said you use Airflow for orchestration, which is the tool the JD names | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You said you set up your company's Great Expectations test suite | `[grounded]` your background | A description of the suite's coverage would raise it (upgrade menu) |
| R9 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | You run dbt on Snowflake, so the dbt work carries over. The limit: you've never used BigQuery, so its billing, partitioning/clustering and IAM model are untested. It's `important` rather than `must_have` because the requirements only ask for "a cloud warehouse" | `[grounded]` you said you've never used BigQuery; `[inferred]` tier taken from the responsibilities line; `[generic]` that BigQuery's cost model and partitioning are what changes from Snowflake | See G1 |
| R10 | Ingestion from our app and CRM | important | unclear | none | discovery | Your background covers transformation (dbt), orchestration and testing, but says nothing about where data came from or who built ingestion | `[grounded]` your background is silent on ingestion | See G2 |
| R11 | Data contracts our analysts depend on | important | unclear | low | discovery | A Great Expectations suite is indirect context: testing is close to contracts, but whether you defined schemas or SLAs with consumers isn't stated | `[grounded]` the GE suite you mentioned; `[inferred]` closeness of testing to contracts | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | dbt on Snowflake (about 180 models); no BigQuery use | It's the one named tool you haven't used. A stated bridge with its limit is stronger than leaving it unaddressed | Carries over: dbt project structure, testing, incremental models. Doesn't carry over: BigQuery pricing, partitioning/clustering, IAM | A small dbt project on BigQuery's free tier or a public dataset, in a repo | `[grounded]` your background; `[generic]` what differs between warehouses |
| G2 | App and CRM ingestion (R10, important) | discovery | Nothing about sources or ingestion tooling | Ingestion is the first of the three stated responsibilities | Loading data from a product database or event stream; pulling from a CRM or HRIS API; running Fivetran, Airbyte or custom Python loaders under Airflow | A DAG diagram or a sanitized loader description | `[grounded]` JD order; your background is silent |
| G3 | Data contracts (R11, important) | discovery | A GE test suite; nothing about agreements with consumers | It's the third stated responsibility and the one analysts depend on | Defining schemas or freshness SLAs with analysts; dbt model contracts or exposures; blocking upstream changes that would break reports | A sanitized contract spec, a dbt `contract:` config, or a GE expectation suite | `[grounded]` JD; your background; `[inferred]` testing as the closest evidence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay is stated and at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The band's floor is above the report's P25 and its top is above the P75 | `[grounded]` JD; `[generic]` Datawright band | Where in the band do candidates with 6 years usually land? | noted |
| RR2 | Posting is live and the company matches its own pages | positive_signal | — | "Accepting applications" | The employer exists as described and the role is open | `[grounded]` live careers and about pages | — | noted |
| RR3 | Unclear whether the warehouse already exists | unknown | — | "Build and run the pipelines … a dbt-modelled warehouse in BigQuery" | This could be an established dbt project or a build from scratch, which changes how much R9's gap matters | `[inferred]` from "build and run" | Is the BigQuery dbt project already in production, and roughly how many models does it have? | unresolved |
| RR4 | Operational load not stated | unknown | — | "Build and run" | "Run" may include on-call for pipeline failures | `[generic]` common in this role family; not stated here | Is there an on-call rotation for data pipelines, and how many people share it? | unresolved |
| RR5 | Equity unspecified | unknown | — | "plus equity" | The type, amount and vesting aren't stated | `[grounded]` JD wording | What form does the equity take, and what's the vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Open with the dbt project you built on Snowflake (about 180 models), Airflow, and the Great Expectations suite you set up, in your own words | Matches R5, R7, R8 | `[grounded]` your background | pending your approval |
| P2 | Say plainly that you haven't used BigQuery yet and present Snowflake as the related warehouse | R9 is `adjacent`. Claiming it as direct would fail the first probe | `[grounded]` R9 | pending your approval |
| W1 | Optional: build a small dbt-on-BigQuery repo before the technical round | Narrows G1's limit | `[generic]` a work sample is the usual way to close a tool gap | pending your approval |
| Q1 | Ask the verification questions from RR1, RR3, RR4 and RR5 at the recruiter screen | The answers settle the unknowns | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Checked the pasted material. Searched "Pellucid Learning senior data engineer careers", which returned "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), marked "Accepting applications" with matching text. Searched "Pellucid Learning Denver online tutoring Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), also matching. Moved: RR2 and the Contradictions row |
| 2. Role-family sweep | skipped | The Datawright report you pasted already sets the market calibration line and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can write all of this up as a `tuesday-dossier.md` for you to keep, if that's useful.

**Upgrade menu**
- Your location, work authorization and pay floor: R1 and R2 resolve, and the decision becomes `go` or `no_go`.
- Answers to G2 and G3: R10 and R11 move off `unclear`.
- A sanitized repo, a dbt docs page, or a description of the GE suite's coverage: R5 and R8 can rise to `high`.
- The hiring manager's name: sharpens the scope read and tells me which story to lead with.
- A deeper research pass on Pellucid (leadership churn, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and I'll run it.

**Questions**

R1/R2: Are you based in the US with work authorization, does remote-US or Denver work for you, and does $148,000–$166,000 base meet your floor?

G2: At the payroll company, did you build or own any ingestion, for example from the product database, an HRIS or CRM API, or a tool like Fivetran or Airbyte? What part was yours?

G3: Did you ever agree schemas, freshness or breaking-change rules with the analysts who used your models, beyond the GE tests themselves?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.