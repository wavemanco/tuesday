Still reading the job-underwriter playbook's reference files. Your Pellucid assessment comes right after.
**Yes, Ines: worth applying, on the three conditions below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote within the US, or the Denver office)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7
- `important`: adjacent: R5b (BigQuery as the warehouse) · unclear: R8 (Ingestion from the app and CRM), R9 (Data contracts analysts depend on)

R5b: you can cross over from Snowflake, but say plainly what's missing; R8, R9: nothing you gave me shows these yet; R4 (`medium`): specific but not yet inspectable.

**Opportunity ledger.** On paper the role is clear and the pay is fair: the band straddles the report's median (RR2), and the scope matches what the report says this title usually covers (RR3). It is still unverified, because my check of the live posting was refused (RR1). Also unstated: who you'd report to (RR4), how much "run" means operations (RR5), and what the equity is (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote within the US, or the Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Pellucid's own careers page (RR1); (2) you can work remotely from the US or from Denver (R1); (3) BigQuery is presented as new to you and adjacent to your Snowflake work, never as experience you have (R5b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` about page as you pasted it; not checked against the live site (RR1) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Stated requirements | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One domain (reporting), from ingestion through to what analysts use; no direct reports mentioned | `[inferred]` from the JD's mandate, which names no team to manage |
| Market calibration | Senior DE at Series B–D: base median $151,000, IQR $139,000–$163,500. "Senior" usually means 5–8 years and ownership of one domain's pipelines, no reports. The posting's low end is $3k under the median and its top end is $2.5k over the 75th percentile, so the band is never this employer's offer, only what to expect. Your 6 years fall inside the 5–8 range | `[generic]` Datawright 2026 Data Engineering Pay Report, US, n=2,310, as pasted from your recruiter; `[grounded]` JD for the posting's figures |
| Unknowns | Hiring manager and team size; whether "run" includes on-call; equity terms; which CRM; whether contracts exist yet or are to be built | — |
| Contradictions | None between the JD and the about page as pasted | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote within the US, or the Denver office | hard_gate | unclear | none | hard_gate | You didn't say where you're based or whether you can work in the US, so the gate isn't settled either way | `[grounded]` JD terms; your message is silent | Closing question R1 |
| R2 | 5+ years of data engineering | must_have | direct | medium | none | "6 years of data engineering at a B2B payroll company": specific, self-reported, no inspectable artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily". Daily use is stated, but "strong" is the JD's word, not yours, so expect a technical probe | `[grounded]` your background | none; a code sample would raise it |
| R4 | dbt | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models". Specific and owned, the strongest claim you made | `[grounded]` your background | none; a sanitized project-structure excerpt would raise it |
| R5a | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse", and Snowflake is one | `[grounded]` JD wording and your background | none |
| R5b | BigQuery as the warehouse | important | adjacent | medium | transferability | "Never used BigQuery" is your own statement. What carries over: dbt modelling and warehouse SQL. The limit: nothing BigQuery-specific (its cost model, partitioning, its SQL dialect) has been exercised | `[grounded]` your statement; `[generic]` that BigQuery-specific practice differs from Snowflake's in those areas | See G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration". Named, but no detail on what you owned in it | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite". Specific and owned | `[grounded]` your background | none |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background covers modelling, orchestration and testing, but doesn't say which sources you ingested or who built that ingestion | `[grounded]` silence in your background | Closing question G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | The GE suite is related, but nothing you wrote says you set agreements with the people consuming the data | `[inferred]` from the GE suite to a possible contracts practice; not asserted | Closing question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5b, important) | transferability | dbt on Snowflake at about 180 models, and no BigQuery | Their warehouse is BigQuery, so this is the gap most likely to be probed | Any dbt work across adapters; managing Snowflake cost or performance; a small personal dbt project on BigQuery | A public repo of a small dbt + BigQuery project | `[grounded]` your statement; `[generic]` that it's the likeliest probe |
| G2 | App and CRM ingestion (R8, important) | discovery | Nothing yet on where your data comes from | It's the first named part of the mandate | Pulling payroll-app event or database data into Snowflake; loading a CRM such as Salesforce or HubSpot; building or running Fivetran/Airbyte or custom Python loaders | A pipeline diagram, a sanitized DAG, a loader README | `[grounded]` silence in your background |
| G3 | Data contracts (R9, important) | discovery | GE tests exist; whether there were agreements with analysts is unknown | It's named in the JD, and a JD names this only when they care about it | Agreeing schemas or SLAs with analysts; dbt model contracts or exposures; tests that fail the build when an upstream change would break a dashboard | A contract spec, a dbt `contract:` config, a written data-quality SLA | `[grounded]` JD wording; `[inferred]` link to the GE work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources: my fetch of the posting and my search on the company were both refused | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The posting may be stale or copied from elsewhere. Text pasted from the company's own domain makes it much less likely to be fake | `[generic]` pattern for companies of this size, not a claim about this one | Is the Senior Data Engineer role still open, and who would I be interviewing with? | unresolved |
| RR2 | Pay stated, and the band straddles the market median | positive_signal | — | "$148,000–$166,000 plus equity" | The pay is published and in line with the report's market | `[grounded]` JD; `[generic]` pasted report's band | Where in the band do you expect to place someone with six years? | noted |
| RR3 | Scope matches the norm for the title | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | One domain with no reports, which matches the report's description of "Senior" | `[generic]` pasted report; `[grounded]` JD | Is reporting the only domain this role owns? | noted |
| RR4 | No hiring manager or team named | unknown | — | (the posting names no hiring manager) | Reporting line and team size can't be read from the posting | `[grounded]` JD's silence | Who would this role report to, and how many data engineers are on the team? | unresolved |
| RR5 | Operations load unstated | unknown | — | "Build and run the pipelines" | "Run" may mean an on-call rotation | `[inferred]` from the word "run" | Is there an on-call rotation for pipelines, and how often does it come round? | unresolved |
| RR6 | Equity unspecified | unknown | — | "plus equity" | Grant size, type and vesting are unstated | `[grounded]` JD's silence | What form does the equity take, how large is a typical grant at this level, and what's the vesting? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dbt project in your own words, "built our dbt project on Snowflake — about 180 models", keeping "about" | see R4, R5a | `[grounded]` your background | pending your approval |
| P2 | Put "set up our Great Expectations test suite" second, as your data-quality evidence | see R7, R9 | `[grounded]` your background | pending your approval |
| P3 | Name BigQuery plainly as new to you ("dbt on Snowflake; BigQuery not yet used in production") rather than leaving it out | see R5b | `[grounded]` your statement | pending your approval |
| W1 | Build a small personal dbt project on BigQuery and link it | see R5b, G1 | `[generic]` that a public repo narrows an adapter gap | pending your approval |
| A1 | Confirm the posting is live on Pellucid's own careers page before you write anything | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR2–RR6 questions verbatim at the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

This approval covers the whole plan, including the positioning wording in P1–P3, not just the table's format.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The fetch of pellucidlearning.com/careers/senior-data-engineer and the search "Pellucid Learning online tutoring K-12 Denver Series C" were both refused permission. They would have confirmed the posting is live and the company is as described, which would clear RR1 and the organization row |
| 2. Role-family sweep | skipped | The Datawright 2026 report you pasted already gives the band and scope for the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no name to search |

I can write all of this up as a `tuesday-dossier.md` file you can keep or reuse with the other modules, if you'd like.

**Upgrade menu**
- Allow web access, or tell me the posting is still live on their site → RR1 clears and condition 1 is met.
- Your location and US work status → R1 resolves.
- Answers to G2 and G3 → R8 and R9 move off `unclear`.
- Your pay floor → R1's "candidate constraints" flag closes, and the band gets checked against your number.
- A public dbt + BigQuery repo → R5b's limit narrows; any inspectable work sample → R4/R7 go to `high`.
- The hiring manager's name → a scope read and which story to lead with for that person.
- A deeper research pass on Pellucid (funding, leadership churn, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

R1: Are you based in the US and able to work there, either remotely or from Denver?

G2: What sources did you ingest at the payroll company (app databases, a CRM, third-party APIs), and did you build that ingestion yourself or receive the data already loaded?

G3: Did you ever agree on a schema, freshness or quality standard with analysts, written down or enforced in dbt or GE, so that upstream changes couldn't silently break their work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.