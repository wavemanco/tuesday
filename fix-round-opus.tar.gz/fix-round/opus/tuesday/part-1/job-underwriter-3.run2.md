Reading the required references.
## Decision snapshot

**No, it isn't worth pursuing, and the feeling that something is off is right. R1 and R2, both hard gates, fail · `no_go`**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin 5 days a week), R2 ($70–85k base)
- `must_have`: direct: R3, R4, R5, R7 · unclear: R6 (SEO/content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops)
- `important`: adjacent: R11 (A team of one to start) · unclear: R12 (Dotted line to the board)

R1, R2: both of your non-negotiables fail, and better wording can't fix either one; R3, R4, R5, R7: your record matches the core of the job; R6, R8, R9, R10: channels your background doesn't mention.

**Opportunity ledger.** Even setting your constraints aside, the role is badly built. It packs eight functions into one person with no stated budget (RR4), expects evenings and weekends (RR5), says success metrics "will evolve" (RR6), and pays a base that may be below market for what it asks (RR3, not yet checked). In its favour, it states its terms plainly (RR9), and profitability is a real strength (RR7).

- **Hard gates:** failed: R1 (On-site in Austin 5 days a week), R2 ($70–85k base)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** Novaline would need to offer a fully remote role (R1, RR2) *and* a base of at least $150k (R2, RR1). The posting says "no exceptions" on location and gives a range that tops out at $85k.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; not independently verified (see RR8) |
| Mandate | Own all revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Reporting | To the CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus unspecified equity | `[grounded]` posting |
| First-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | Eight functions owned alone, with board visibility. That is a department's mandate given to one person | `[inferred]` from the function list against "team of one"; `[generic]` that these functions are usually split across several roles |
| Market calibration | Not established. The role-family search was refused in this session, so I have no sourced band to compare the $70–85k against | — |
| Unknowns | Growth budget; equity size, vesting and valuation; whether customers are B2B merchants; what "sales ops" covers; whether hiring help is planned | — |
| Contradictions | None between sources (only the pasted posting was available). The posting's internal tensions are filed at RR3 and RR4 | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint (remote-only, staying in Portland), which is specific and confirmed. The gate fails because the posting rules out remote work by name | `[grounded]` posting and your stated constraint | Surface only; it resolves only if Novaline changes its terms |
| R2 | $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Your floor is $150k. The top of the posted range is $65k short of it. Equity doesn't count toward a base floor | `[grounded]` posting and your stated constraint | Surface only; it resolves only if Novaline changes its terms |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | 9 years in growth, as growth lead and then Head of Growth at two companies. This is self-report with nothing yet to inspect, so it stays at `medium` | `[grounded]` your message | none |
| R4 | Own all revenue growth end to end | must_have | direct | medium | none | Scaled one company from $8M to $40M ARR over three years, with a budget you controlled | `[grounded]` your message | none |
| R5 | Paid acquisition | must_have | direct | medium | none | You stated that you owned paid | `[grounded]` your message | none |
| R6 | SEO/content | must_have | unclear | low | discovery | Your message doesn't mention it either way | `[grounded]` your message is silent | G1 |
| R7 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and are "deep in" Braze | `[grounded]` your message | none |
| R8 | Brand and PR | must_have | unclear | low | discovery | Not mentioned | `[grounded]` your message is silent | G2 |
| R9 | Partnerships | must_have | unclear | low | discovery | Not mentioned | `[grounded]` your message is silent | G3 |
| R10 | Sales ops | must_have | unclear | low | discovery | Not mentioned. Your background is B2C subscription, where a sales function may not have existed | `[grounded]` your message is silent; `[generic]` that B2C subscription growth often runs without a sales team | G4 |
| R11 | Executing alone ("a team of one to start") | important | adjacent | medium | transferability | You built and managed teams of 3–7, and your SQL/GA4/Braze depth shows hands-on skill. Doing all eight functions yourself with no team isn't shown | `[grounded]` your message; `[inferred]` hands-on capability from tool depth | G5 |
| R12 | Reporting to the CEO with a dotted line to the board | important | unclear | low | discovery | Your reporting line in past roles isn't stated | `[grounded]` your message is silent | G6 |

## Gap recovery queue

These gaps can't change this decision, because R1 and R2 decide it. They are worth knowing for the next end-to-end growth role you look at.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Nothing either way | Roles with a full growth remit tend to list it | Owning organic acquisition targets; running a content calendar or an agency; SEO experiments in your experimentation program | An organic traffic dashboard or a content roadmap | `[grounded]` silence; `[generic]` that full-remit roles list it |
| G2 | Brand and PR (R8, must_have) | discovery | Nothing either way | Same as G1 | Launch campaigns; managing a PR agency; positioning work alongside growth | A launch brief or press coverage you drove | `[grounded]` silence; `[generic]` as G1 |
| G3 | Partnerships (R9, must_have) | discovery | Nothing either way | Same as G1 | Affiliate or co-marketing programs; channel or integration partners | A partner list with its revenue contribution | `[grounded]` silence; `[generic]` as G1 |
| G4 | Sales ops (R10, must_have) | discovery | Nothing; B2C background | Weighs more in B2B-leaning roles | CRM pipeline hygiene; lead routing to an inside-sales team; B2B or enterprise plans at a subscription company | A pipeline dashboard or routing setup | `[grounded]` silence; `[generic]` that B2B roles weight it |
| G5 | Solo execution (R11, important) | transferability | Team-builder with strong hands-on tools | Carries over: you can still do the work yourself. Limit: covering eight functions with nobody else isn't shown. Strengthener: a period before you hired, or one where you ran several channels alone | An early phase before your team of 3–7 existed | A timeline of when you hired, against the results | `[inferred]` bridge from your tool depth |
| G6 | Board exposure (R12, important) | discovery | Not stated | Board-facing growth roles probe this | Presenting growth numbers to a board or investors | A sanitized board slide | `[grounded]` silence; `[generic]` that such roles probe it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay far below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | Equity is offered to make up a base that is roughly half your floor | `[grounded]` posting figure against your constraint | Is there any flexibility in the base for this role, or is the range fixed? | confirmed |
| RR2 | On-site only, against your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The terms state this outright, so it isn't open to negotiation | `[grounded]` posting | Is "no exceptions" final for this role? | confirmed |
| RR3 | Possible mismatch between seniority and pay | risk_signal | medium | "8+ years growth leadership required" / "$70–85k" | The base may be below market for an 8+-year leadership hire reporting to the board. Unconfirmed, because the market search didn't run | `[inferred]` from the posting's demands against its own figure | How did you set the range for this role, and what is the equity in shares and valuation? | unresolved |
| RR4 | Several jobs bundled into one, without resources | risk_signal | medium | "Own all revenue growth end to end … You will be a team of one" | One person is accountable for eight functions with no stated budget or hiring plan | `[inferred]` from the function list against "team of one" and no mention of budget | What budget and hiring plan come with this role in year one? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work is presented as culture, not as an exception | `[grounded]` posting wording | How often in the last quarter did "when it matters" happen? | unresolved |
| RR6 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be accountable without a fixed definition of success | `[inferred]` from the mandate against the metric language | What would a successful first year look like, in numbers? | unresolved |
| RR7 | Profitable since day one | positive_signal | — | "profitable since day one" | The business has its own revenue, so there is less pressure to raise money to survive | `[grounded]` posting claim, unverified | What is current revenue, and how fast is it growing? | noted |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A…)" | The entity may be too new or small to have a public footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Terms stated up front | positive_signal | — | "$70–85k base" / "no exceptions" | The pay and location terms are clear, so nothing is hidden for later | `[grounded]` posting | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | R1, R2, RR1, RR2 | `[grounded]` map and register | pending your approval |
| A2 | If you contact them anyway, ask the RR1 and RR2 questions before spending any other effort | Those are the two answers that would have to change | `[grounded]` register | pending your approval |
| A3 | Use this posting's warning signs as a screen for other roles: eight functions in one person, "team of one", "evolving" metrics, after-hours culture | RR4, RR5, RR6 | `[inferred]` from this posting's patterns | pending your approval |

## Evidence status

Verified: R1, R2 claims (your own stated constraints). The R3–R12 claims are self-report from your message: leads, not proof.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin Head of Growth" was refused because web search permission wasn't granted. It would have settled RR8 and the Organization row |
| 2. Role-family sweep | unavailable | The search "Head of Growth Series A startup base salary 2026" was refused the same way. It would have set the market calibration row and confirmed or cleared RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given |

---

I can save this as a `tuesday-dossier.md` file whenever you want a copy.

**Upgrade menu**
- Allow web search → RR8 resolves (does Novaline exist as described?) and RR3 gets a sourced market band. The decision wouldn't change.
- A deeper research pass on Novaline (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs. It wouldn't change this decision either.
- Inspectable growth artifacts (an ARR or cohort dashboard, a channel-budget plan, Braze campaign results) → R3, R4, R5 and R7 move from `medium` to `high` for future roles.
- Answers on SEO/content, brand/PR, partnerships and sales ops → G1–G4 close for the next end-to-end growth role you consider.

No questions this turn. Nothing you could answer would move R1 or R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.