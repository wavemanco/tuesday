Quick update: I'm checking whether Quartzline and this posting exist as described, then I'll give you the full read.
**Not a waste of time, but a cold application is a long shot. R1a, the one must-have row you miss, is a title gap that wording can't close, so how you get in front of a person matters more than the resume. Status: `conditional_go`.**

I couldn't check the company or the market: both web searches were refused, so everything here comes from the posting and your resume.

## Decision snapshot

**Fit ledger.**

- `must_have`: adjacent: R1b (product work done under another title) · absent: R1a (3+ years with a PM title)
- `important`: direct: R3, R4a · adjacent: R2 (Shipped API or platform products), R6 (Own the roadmap), R7 (Run discovery with integration partners), R8 (Write specs and drive delivery), R10 (Coordinate launches with sales and support) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery), R9 (Define and track adoption metrics)

R1a: the gap you can't reword, so the route in decides it; R2, R6: be the first to say where these bridges stop; R9: where the triage-tool lead would land if it's real.

**Opportunity ledger.** Unverified more than worrying: the employer couldn't be checked (RR1), pay and location aren't stated (RR2, RR3), and success isn't defined yet (RR5). One entry points the other way: the engineering resources are named (RR4).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting check out, RR1; (2) the application reaches a person instead of only a résumé screen, A1, because of R1a; (3) R2 and R6 are framed as adjacent, never as "shipped APIs" or "owned a roadmap," P3; (4) pay and location are acceptable to you once known, RR2, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline: B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not verified (RR1) |
| Mandate | Own the partner API roadmap; run discovery with integration partners; write specs; drive delivery with two squads; define adoption metrics; coordinate launches | `[grounded]` JD |
| Requirement tiers | Only "3+ years product management experience" is marked must-have. The other four are listed without that mark, so I've treated them as important | `[grounded]` JD; `[inferred]` tiering from that mark |
| Gate terms | The JD states no location, work authorization, pay, travel or schedule terms | `[grounded]` the JD says nothing on these |
| Scope read | A full platform PM job (roadmap through launch) with delivery capacity named | `[inferred]` from the responsibility list |
| First-year outcomes | Not stated. "Define and track adoption metrics" suggests the metrics may not exist yet | `[inferred]` from the verb "define" |
| Market calibration | Not established. The role-family search was refused, and I don't use model memory for pay bands | — |
| Unknowns | Pay; location; reporting line; hiring manager; whether the partner API is live or still being built | — |
| Contradictions | None inside the JD; careers page not checked | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience, counted as years with a PM title | must_have | absent | none | capability | You say you've never held a PM title, which settles it. The only ways to close it are time in a PM-titled role or an employer who accepts R1b instead | `[grounded]` your statement | Carry as material risk; see A1, A2 |
| R1b | 3+ years PM experience, counted as product work done under another title | must_have | adjacent | medium | transferability | Seven years of requirements documents, roadmap-input sessions and coordination across teams is close to PM work. The limit: you fed product decisions; nothing shows you made the prioritization call. This is specific but untested self-report, so expect a probe | `[grounded]` resume; `[generic]` that PM hiring weighs who owned decisions | See G3; P1, P2 |
| R2 | Shipped API or platform products | important | adjacent | medium | transferability | 30+ client integrations of your company's REST APIs, end to end. That is the integrating side. Nothing shows you owned an API's design, versioning or roadmap | `[grounded]` resume | G1 |
| R3 | Technical fluency: reading API docs, discussing schemas | important | direct | medium | none | Postman, SQL, OpenAPI specs, integration architecture. Stated plainly; nothing inspected yet | `[grounded]` resume | none; expect a technical probe |
| R4a | Stakeholder management with engineering and customers | important | direct | medium | none | "Coordinated our engineers, the client's engineers, and product managers on custom builds" | `[grounded]` resume | none |
| R4b | Stakeholder management with sales | important | unclear | low | discovery | The resume doesn't mention sales | `[grounded]` resume says nothing | G5; not asked this turn |
| R5 | Experience with agile delivery | important | unclear | low | discovery | The resume doesn't mention a delivery method | `[grounded]` resume says nothing | G4; not asked this turn |
| R6 | Own the roadmap for the API platform | important | adjacent | medium | transferability | You ran quarterly roadmap-input sessions. The limit: that is input to a roadmap someone else owned | `[grounded]` resume | Frame as input (P3) |
| R7 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and feedback sessions with clients. The limit: scoping an existing product for one client is different work from deciding what to build for many partners | `[grounded]` resume; `[inferred]` the difference in kind of work | W1 |
| R8 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents, integration architecture, coordinating engineers. The limit: these were requirements for one client's build, not specs for a shared platform, and coordinating engineers isn't owning a squad's backlog | `[grounded]` resume; `[inferred]` spec vs. client-requirement distinction | W1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The resume shows no metrics. The playbook "the whole team uses" shows adoption but no measurement. An earlier conversation mentioned a triage tool support agents adopted; that is unconfirmed. Rated low, not none, because there is a real thread to pull | `[grounded]` resume; memory note is a lead only | G2 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | 30+ go-lives. The limit: single-client go-lives, not market launches with sales and support enablement | `[grounded]` resume; `[inferred]` go-live vs. launch distinction | P1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped API products (R2, important) | transferability | Implementation of APIs someone else designed | It's the strongest product-side claim you could add. A direct example would move R2 | A custom build that became a standard endpoint; a field you pushed into the schema; docs you rewrote that partners now use | Release notes, a changelog entry, a sanitized spec | `[grounded]` resume; `[inferred]` that this is the likeliest path to `direct` |
| G2 | Adoption metrics (R9, important) | discovery | Nothing measured; one unconfirmed lead about a triage tool | It's the only row where a single answer could add both something you built and how much it was used | The triage tool, if real; playbook usage; how integration time or ticket volume changed after your work | A dashboard screenshot, usage numbers, an internal announcement | `[grounded]` resume says nothing; the lead is unconfirmed |
| G3 | Titled PM years (R1a, must_have) | capability | Zero titled years, by your own account | It's the one listed must-have, and how literally it gets screened is out of your hands | — (closure path: an internal PM move, a PM-titled role with a lower bar, or a referral that gets R1b read) | — | `[grounded]` your statement |
| G4 | Agile delivery (R5, important) | discovery | Not mentioned | Easy to settle with one line, but unlikely to change the decision | Sprint ceremonies on custom builds; working from a backlog with your engineers | — | `[grounded]` resume says nothing |
| G5 | Working with sales (R4b, important) | discovery | Not mentioned | Needed for R10 launches | Pre-sales scoping; handing deals over to implementation | — | `[grounded]` resume says nothing |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from sources I could check | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have much online presence, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no pay line in the posting) | The figure is simply unpublished; how it compares to market is unknown | `[grounded]` posting says nothing on pay | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and working pattern not stated | unknown | — | (no location line in the posting) | Could be remote, hybrid or on-site | `[grounded]` posting says nothing on location | Where is this role based, and how many office days are expected? | unresolved |
| RR4 | Delivery resources named | positive_signal | — | "drive delivery with two engineering squads" | The role has real capacity to build, not just a mandate | `[inferred]` from the stated squad count | Do both squads work only on the API platform, or are they shared? | noted |
| RR5 | Success not yet defined | unknown | — | "define and track adoption metrics" | The metrics may not exist yet, so year-one success may be open | `[inferred]` from the verb "define" | What would make this role a success after twelve months? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Get the application to a person through a referral or a short note to the hiring manager, alongside or before the online form | See R1a | `[inferred]` from the JD marking only R1a must-have; `[generic]` that titled-years requirements are often screened literally | pending your approval |
| P1 | Opening line: "Seven years as a solutions engineer and implementation lead: I've led 30+ client integrations of our REST APIs end to end, from scoping workshops to go-live, coordinated our engineers, client engineers and product managers on custom builds, and ran the quarterly roadmap-input sessions that collected client feedback for product." | See R1b, R3, R4a, R6 | `[grounded]` every clause traces to your resume | pending your approval |
| P2 | Bring up the title gap yourself early: "I haven't held a PM title. Here's the product work I've done under another one." | See R1a | `[grounded]` your statement | pending your approval |
| P3 | Don't write "shipped API products" or "owned the roadmap" | See R2, R6 | `[grounded]` R2, R6 rows | pending your approval |
| W1 | Optional: a one-page spec for a partner-facing API change, written as the PM | Narrows the limits on R7 and R8 | `[inferred]` from those limits | pending your approval |
| A2 | In parallel, look at roles where titled years aren't a must-have: integrations or technical PM roles, or an internal PM move at your current company | Closure path for R1a | `[generic]` common route from solutions engineering into PM | pending your approval |
| Q1 | Ask the RR1–RR5 verification questions word for word in early calls | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a request-triage tool support agents adopted, from an earlier conversation; it's unconfirmed and only drives G2's question. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have cleared or confirmed RR1 and filled the contradictions row |
| 2. Role-family sweep | unavailable | The search was refused. It would have filled market calibration and given a pay band to compare against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you'd like, I can save this as `tuesday-dossier.md` so a later resume or interview session can pick it up.

## Upgrade menu

- Allow web search, or paste the live posting or careers-page link → RR1 clears or escalates, and market calibration gets a pay band.
- Your non-negotiables (pay floor, location, timing) → the hard-gates line becomes real checks instead of unknowns.
- An answer to G1 → R2 strengthens, or moves to `direct`.
- An answer to G2 → R9 moves off `unclear`, and R2 may gain an internal-product example.
- A sanitized requirements doc, the integration playbook or a summary from a roadmap-input session → R1b, R6, R7 and R8 move toward `high`. In this field the proof is a spec or a doc, not a title.
- The hiring manager's name → the scope read, and which story P1 leads with.
- A deeper research pass on Quartzline (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches). It needs web search allowed; say the word and it runs.

## Questions

**G1:** Did any custom build you coordinated become part of the standard API product, and if so, which part was yours: the requirement, the design, or the push to make it standard?

**G2:** An earlier conversation mentioned a request-triage tool that support agents adopted. Is that real, and if so, what was your part, and do you know how many people used it?

**Orientation:** What are your non-negotiables on pay, location and timing, and are you still weighing this or about to apply?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.