Building your prep pack now. Your inputs cover everything it needs, so there are no searches and no questions for you first. Writing it to a file next.
I've written your prep pack, Dara: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md. It has one section per round from the recruiter's email, plus shared sections up front: a fit check of your background against the JD, a build-out of the 20-minute case, and a summary of the strategy brief. The pack has 29 practice questions in total. I didn't need any searches, because your notes already covered the values, the interview structure and the strategy.

- **The question to practise most is C1, in your round with the Head of Member Services.** It's the obvious objection to you: so far you've worked with one branch, never in a contact centre, and never presented above regional level. The answer to rehearse has four steps:
  - State what's true in your own words.
  - Admit both gaps before you're pushed: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level."
  - Give a plan for closing each gap.
  - Come back to what you've actually done.
- **The values round needs stories you haven't given me yet.** Nothing in your background maps clearly to Members First, Plain Words, Neighbours Not Numbers or Own the Fix. For each value, the pack gives a guide to choosing a story. One real story per value is the biggest single improvement you could make.
- **The pack treats the 20-minute case as a graded assignment.** It sets out a six-step, 20-minute plan that uses the four values as decision rules. It also gives three positions you could take, each with the point you should concede, and the mistakes to avoid. One example: don't offer money as a goodwill gesture before you've found out what happened.
- **Some JD requirements need your input before you can answer confidently.** The pack's suggested answers deliberately avoid claiming:
  - that your complaints log covered "regulated" complaints;
  - that your spreadsheet tracks volumes and resolution times;
  - that it's built in Excel;
  - any digital work.

  Each of these has two honest versions, depending on what's true. A claims-to-avoid table lists the stretched versions to stay away from.
- **21 November 2026 is a Saturday.** It's worth a quick check with the recruiter.

The list at the end of the pack shows what each further input would improve.

If you'd like, I'll play your future manager and run C1 with you as a live practice, with follow-ups. I can also save a short file (`tuesday-dossier.md`) recording the gaps this prep found, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 21 November 2026, per the recruiter's email: Round 1, 30 minutes with the recruiter. Round 2, 45 minutes with the Head of Member Services (your future manager), mostly behavioural. Round 3, 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four values.
**Interviewers:** not yet assigned beyond their roles, so this pack has no interviewer read.
**Mode:** loop. One shared fit snapshot, a build section for the case, and the grounding brief come first, then one mini-pack per round.

---

## How to use this pack

Each question has two tags. The **persona** is how the question will be asked: who is asking, and in what tone. The **type** is what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's *published* values, by name |
| EXP | Whether what you say about your own work holds up when probed: what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | How you structure and reason through a live problem from the role |

**Provenance labels:** `[grounded]` means the row traces to something you or Ashgrove provided. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a pattern for this kind of role, with no claim about you or Ashgrove.

**Answer slots** are instructions for the interview, not questions for me. Each has two branches. If you did the thing, say how in your own words. If you didn't, say so plainly and go back to what you did do. Both branches are honest answers.

The guidance is scaffolding, not a script. Wherever it quotes you, those are your own words from your message, and the guidance claims nothing beyond them.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Use the quote at its own scope: "I handled the branch's formal complaints log." The pack's observation: your material covers one branch's log, not a process across branches. Answer slot: the JD's "end to end" makes a probe on the log's stages likely, from complaint received to complaint closed. If any of those steps was yours to decide, say which one and how you decided, in your own words. If the log was a record and the decisions sat with someone else, or there were no set stages, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | No wording can close this gap, and you have said so yourself. Words: "I haven't worked in a contact centre." Then say how you would learn it, framed as a plan and never as something in your past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The quote says you built the spreadsheet and your regional manager uses it. It doesn't say what the spreadsheet measures, or that you reported from it, and the bridge should not stretch that far. Answer slot: if it tracks volumes or resolution times, say which, and how each one is counted. If it tracks other things, say what, plainly. Describe no reporting you didn't do |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Use the quote at its own scope: "I trained new tellers on our escalation script." The trainees were tellers, not supervisors, and the script is "our" script, so the pack reads no authorship into it. Answer slot: the JD's coaching line makes a probe on how you trained likely. If you added anything of your own to the training beyond the script, say what. If you delivered the script as it stood, say so plainly and describe how you trained |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a member problem you passed to someone who then changed a digital or self-service process. Answer slot: if you ever passed member feedback about online or app banking to someone who acted on it, say what you passed on and what happened. If you never did, say so plainly and say how you would approach the work |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap here, but nothing has been inspected behind the line, so expect a probe. Lead with it in its own words: six years in retail banking, the last three as a branch supervisor. Leave the mapping to "customer operations" to the interviewer |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | "Formal" is not the same as regulated, and the pack won't stretch it. Answer slot: the JD's line makes a probe on rules likely, such as response deadlines, written final responses, or a member's right to refer the complaint onward. If the complaints in your log had to meet rules like those, say which rules and what you did to meet them. If you don't know which rules applied, or none did, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You have stated this gap yourself. Words: "I haven't presented to anyone above regional level." Then give a plan for getting there, framed as a plan. Your sentence doesn't say whether you have presented *at* regional level, so the banks handle that as an answer slot (C1, K2) and the pack assumes nothing |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The quote says "spreadsheet". It doesn't name Excel or say which features you used. Answer slot: if you built it in Excel, say so and name what you actually used to build it. If you used another tool, name that tool plainly |

---

## Graded deliverable — the 20-minute complaint-escalation case (Round 3)

The recruiter announced this case, and the panel scores it against the four values. Rehearse it as an assignment, not as one more question.

**Grounded facts to build on**

| Fact | Source |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" and "coach branch supervisors on escalations" | JD |
| Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix, in their published wording | Values page, pasted 12 November 2026 |
| Eight branches consolidate into five hubs over 2027. 40% of member service moves to digital channels by 2028 | 2026 strategy brief |
| F1: "I handled the branch's formal complaints log" | Fit snapshot |
| F4: "trained new tellers on our escalation script" | Fit snapshot |

**A 20-minute shape, using the values as decision rules.** Say the structure aloud before you start, then follow it.

1. **Clarify (about 3 minutes).** What happened, and how many times? What has the member already been told? Is there money at stake or a deadline running? Is the member vulnerable? Which branch or channel is involved? What response clock does Ashgrove's complaints policy set? Ask the panel that last one rather than guessing it.
2. **The member today (about 4 minutes): Members First, Always.** Who calls the member back, and when? What do you say, in plain words? What can you put right immediately?
3. **The supervisor (about 4 minutes): Own the Fix.** Whoever found the problem keeps hold of it, so decide whether the supervisor keeps the case with your support or you take it over. Say what you would coach them on afterwards.
4. **The record and the clock (about 3 minutes).** Log the complaint and meet the policy's deadlines. Here the case meets the regulated-complaints requirement (F7), so use the panel's answer from step 1 rather than naming rules from memory.
5. **The pattern (about 3 minutes).** Is this a one-off? Is it a digital journey failing, which you would take to the digital team? Is it a branch in transition to a hub? Say what it adds to the monthly report.
6. **Close (about 1 minute).** The member's outcome, in one plain sentence.

**Theses, each with its concession**

| Thesis | Mandatory concession |
|---|---|
| Fix things for the member first and the process second | Speed can skip the record and the deadline. Log in parallel, never afterwards |
| An escalation is a coaching moment for the supervisor, not a takeover. Own the Fix says the finder keeps hold of the problem | When a member has already been failed more than once, you take the case now and coach afterwards |
| Every escalation is a data point. Look for the pattern behind it | Pattern work does nothing for this member today, so it comes after step 2, never instead of it |

**Differentiation.** The consensus answer is "acknowledge, apologise, resolve", and every prepared candidate will give it. Two things set you apart. First, use the four values by name as the decision rules at each step. Second, connect the case to Ashgrove's live strategy: the hub transition and the digital shift. **The anti-pick, where saying no is the job:** don't offer goodwill money before you've clarified what happened. Don't promise the member an outcome you can't confirm. Respectfully challenge one premise of the case, for example whether the escalation route itself failed.

**Requested close:** none was named. Close on the member outcome anyway, because Members First is the value the case most obviously scores.

---

## Grounding brief

Use the brief's own words in the room, so you sound current.

| Item | What the source says | What it means across these rounds | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" — strategy brief | The JD's "self-service journeys" line belongs to this. Complaints data can show which digital journeys fail members (E1, B4) | [grounded] |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" — strategy brief | Both panel members are branch managers and will live through this. "Neighbours, Not Numbers" meets it head on (G4, E2). Reasoning over the brief, not a claim about how they feel | [inferred] |
| New product | "launch a small-business lending product in Q1 2027" — strategy brief | A new product means new complaint types. Worth one reverse question (Round 2) | [inferred] |
| Competition | "the main competitive pressure is app-only banks" — strategy brief | A member-owned branch network competing on service quality is the frame for "why a credit union" (A2) | [grounded] |
| Values | Four values, as pasted 12 November 2026 from ashgrovecu.org/about/values | The panel scores against them by name, so learn the four names exactly | [grounded] |
| Size and ownership | "member-owned, about 900 staff" — JD | "Senior leaders" at this size probably means the executive team. Your F8 gap is real here, and the pack doesn't soften it | [inferred] |

The brief dates from July 2026, so it's about four months old. Nothing in it reads as stale yet.

---

## Round 1 — Recruiter, 30 minutes

**Personas**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, motivation, logistics | High. A recruiter screen is mostly this, and the casual tone is still scored | A rehearsed 90-second arc built only from your quoted lines (A1). Treat casual questions about JD topics as scored |
| Skeptic (light) | Knockout checks against the JD's requirements: contact centre, regulated complaints, Excel | Medium. Recruiters screen against the listed requirements before passing you on | Short, plain answers on the gaps (A5, B1). Don't bluff a requirement the next two rounds will probe harder |

**Bank A — Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | 90 seconds, four beats, each in the quote's own words: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log. You trained new tellers on your escalation script. You built the monthly complaints spreadsheet your regional manager uses. Then one line, in your own words, on why this role is the next step | It opens every screen, and F1, F3, F4 and F6 all live in it. EXP because it sets the claims the later rounds will test |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Name one value by its exact name and one strategy item in the brief's words. For example, app-only banks are the main pressure, and member-owned service is the answer. Answer slot: if member ownership matters to you because of something in your own work, say what. If it's the role more than the ownership model, say that plainly. Both are fine | A predictable motivation check. CO because it scores whether you've done the homework |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Three items in the brief's words: 40% digital by 2028, eight branches into five hubs over 2027, small-business lending in Q1 2027. Then one link to the role: complaints are where those changes show up first for members. Stop there and ask what the team expects the role to do about the hub move | The brief came from the recruiter, so they'll expect you to have read it. CO |
| A4 | "Why are you looking to move now?" | EXP | [generic] | One honest, forward-looking reason in your own words, with no criticism of your current employer. If the reason is wanting to own complaints beyond one branch, say so, and don't dress it up | A standard consistency check. Your Round 2 answer must match this one. EXP because it tests your own story |
| A5 | "The role covers branches and the contact centre. What's your contact-centre experience?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Under 45 seconds. "I haven't worked in a contact centre." Then what you have done, at its scope: you handled the branch's formal complaints log. Then one sentence of plan: you'd start by sitting with the contact centre team to learn how their complaints come in. Don't apologise twice | F2 is the plainest knockout risk, and the recruiter will check it before passing you on. JD because the JD names the contact centre |

**Bank B — Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for regulated complaints experience. Tell me about that." | JD | [inferred] "I handled the branch's formal complaints log" | Say it in the quote's words: you handled the branch's formal complaints log. Answer slot: if those complaints had to meet set rules, such as deadlines or written responses, say which rules and what you did to meet them. If you don't know which rules applied, say so plainly and stay with the log. Never use the word "regulated" about your own log unless the first branch is true | F7 is a discovery gap on a listed requirement. JD |
| B2 | "What are you looking for on salary, and what's your notice period?" | JD | [generic] | Have a range and your actual notice period ready. Give the range; don't negotiate in this round | Logistics a recruiter always covers. Being unready costs more than any number |
| B3 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | You built the monthly complaints spreadsheet your regional manager uses. Answer slot: if you built it in Excel, say so and name what you actually used. If you used another tool, name it. No list of features you haven't used | F9. A recruiter-level check on a listed requirement. JD |
| B4 | "The role works with digital teams on self-service journeys. Any experience there?" | JD | [grounded] | Answer slot: if you ever passed member feedback about online or app banking to someone who acted on it, say what and what happened. If you never did, say so plainly, then give one sentence on how you'd approach the work, using the brief's 40% digital target | F5 is a requirement your material is silent on, so a rehearsed honest answer is better than an improvised one. JD |

**Reverse questions — Round 1**

| Question | Why it lands |
|---|---|
| "What would make someone clearly successful in this role after six months?" | Gives you the success criteria to use in Rounds 2 and 3 |
| "How does the contact centre sit relative to Member Services? Would I work directly with its team lead?" | Shows you've already spotted your F2 gap and are planning for it |
| "For the panel case, will I get the scenario on the day? Is there anything I should bring?" | Signals you're treating the graded part as graded |
| "Which complaints rules does Ashgrove work to, and is there a complaints policy I could read before the 21st?" | Fixes the F7 slot before the case, and reads as diligence |
| "Is this a new role, or is someone moving on?" | Tells you what the role is really for |

---

## Round 2 — Head of Member Services (your future manager), 45 minutes

**Personas**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gap between one branch and an end-to-end, multi-channel remit | High. A hiring manager is reducing their risk on you, and F1, F2 and F8 are the visible gaps | Rehearse C1 until it's boring. Hold only what your quotes carry, concede the stated gaps in their own words, then give a concrete plan |
| Values / Behavioral | "Tell me about a time" questions | High. The recruiter said this round is "mostly behavioural" | Pick stories ahead of time with the scaffolds below. "We" for context, "I" for your part |
| Case / Strategist | Short live problems on the strategy | Medium. Hiring managers test your thinking on their roadmap, but the panel holds the formal case, so this round will likely use it less | Clarify, objective, approach, metrics, risks. Use the brief's vocabulary |
| Data-Driven Prober | Questions about the spreadsheet and the monthly report | Medium. Monthly reporting is a core duty (F3), and you built the spreadsheet | Know what you can and can't say about how it counts things. Say plainly what you don't know |

**Bank C — Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role owns complaints across branches and the contact centre and reports to senior leaders. You've handled one branch's complaints log, you've never worked in a contact centre, and you haven't presented above regional level. Why are you ready?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" "Never worked in a contact centre" "I've never presented to anyone above regional level" | **This is the highest-ROI rehearsal in the pack.** Four moves. **1. Hold** what's true, in the quotes' words: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log, trained new tellers on your escalation script, and built the monthly complaints spreadsheet your regional manager uses. **2. Concede both gaps** before you're pushed: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." **3. Plan**, framed as future: in the first month, sit with the contact centre team. Ask to dry-run the first monthly report with them before it goes to senior leaders. **4. Return** to the hold. **Follow-ups.** First: "So what would you be weakest at on day one?" Pick one of the two gaps you've conceded and don't invent a third. Second: "How do I know one branch's log scales?" Don't claim scale. Answer slot: if any step of the log was yours to decide, say which. If not, say what you'd need to learn. Third: "Have you presented to your regional manager?" Answer slot: if you have, say what and how it went. If not, say so plainly | F1, F2 and F8 meet in this one objection, and your manager will ask it in some form. The deepest rehearsal is the exact concession, not more claims. JD because it scores the listed remit |
| C2 | "You'd coach branch supervisors on escalations. You've trained tellers. What changes when the people you're coaching are supervisors?" | JD | [grounded] "trained new tellers on our escalation script" "6 years in retail banking, the last 3 as a branch supervisor" | What you did, at its scope: you trained new tellers on your escalation script. You've been a branch supervisor for the last three years, so you know the job the people you'd coach are doing. Answer slot: if you added anything of your own to the teller training, say what. If you delivered the script as it stood, say so. Then the plan: how you'd approach peers differently from new starters. Claim no supervisor coaching | F4 is a transferability gap the JD names directly. JD |
| C3 | "You haven't worked in a contact centre. How would you learn its complaints handling fast enough to own it?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then a concrete plan, framed as future: sit with agents, listen to calls, learn how their complaints are logged, and find where cases pass between the contact centre and branches. Name one thing you'd ask the contact centre lead in week one | F2. The negative is your own words, so the question may say it. JD |

**Bank D — Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you could have passed a complaint on but saw it through yourself." | VAL | [generic] | Selection scaffold, Own the Fix: choose a case with a clear handover point you declined, what you did next, and how it ended for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (the branch's formal complaints log) or how you would handle it | The manager may preview the values the panel scores. Own the Fix fits the JD's "own … end to end". VAL |
| D2 | "Tell me about a time a member didn't understand something the first time. What did you do?" | VAL | [generic] | Selection scaffold, Plain Words: choose a moment where you changed how you explained something, and say what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | "Mostly behavioural" plus a published value. VAL |
| D3 | "Tell me about a time you disagreed with a manager about how a complaint should be handled." | VAL | [generic] | Selection scaffold: choose a case with a clear stake, a moment you didn't fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. Your future manager is asking, so a respectful, specific disagreement scores better than none | Tests whether you'll tell your manager hard things. VAL |

**Bank E — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Complaints from two branches jump the month after an app update. What do you do?" | CASE | [grounded] | Clarify first: same complaint types? Members of particular ages? Did volumes fall in other channels? Then: separate members who need help today from the pattern. Take specific evidence to the digital team. Watch resolution times. Tie it to the brief: the 40% digital target means this will keep happening | Strategy-grounded case on the digital shift. Also covers F5's JD line. CASE |
| E2 | "Eight branches become five hubs over 2027. What happens to complaints during the transition, and what would you watch?" | CASE | [grounded] | Structure: before, during, after. Watch volumes by town, complaint types (access, waiting, staff changes) and resolution time. Brief supervisors in the closing branches on escalations. Close with Neighbours, Not Numbers as the test | Uses the brief's consolidation line. Your manager will own the member side of it. CASE |

**Bank K — Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | The quote's beats: you built it, and your regional manager uses it. Answer slots, in your own words: what it tracks, and whether that includes volumes or resolution times. How each number is counted. Which part you'd defend least. What was yours beyond building it. "I don't know how that's counted" is an honest branch. Never claim you report from it unless you do | F3 and F9 both rest on this line, so it will be probed to its inputs. EXP |
| K2 | "What would you put on a one-page monthly complaints report for the executive team?" | JD | [generic] | Structure, framed as a plan: volume trend, resolution time against target, the top three root causes, one ask. In plain words. Answer slot: if you have presented anything to your regional manager, say what. If not, say so. No claim of senior presentations | F8 and the reporting line together. JD |

**Reverse questions — Round 2**

| Question | Why it lands |
|---|---|
| "What does good look like in the first monthly report you'd expect from me?" | Turns F3 into a shared definition before you start |
| "How does the contact centre's complaint handling differ from the branches' today?" | Takes F2 into the open, as diligence |
| "Where do you expect the hub move to show up first in complaints?" | Shows you've read the brief and think at their level |
| "Will the small-business lending launch come with its own complaints route?" | A Q1 2027 product means new complaint types, and few candidates will spot it |
| "How do you like bad news brought to you?" | Your manager's answer tells you how to work with them, and the question signals Own the Fix |

---

## Round 3 — Panel: two branch managers, 60 minutes (values round + 20-minute case)

**Personas**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Questions scored against each of the four values | Highest. The recruiter said the panel "score against the four values" | One prepared story per value (cheat sheet below), with the value named aloud |
| Case / Strategist | The 20-minute escalation case | Certain. The recruiter pre-declared it | The build section above. State the structure aloud |
| Peer Evaluator | "What would you need from us?", what happens when your report makes their branch look bad | High. The role coaches their supervisors and reports on their branches, so they'll work beside you | Reciprocity: what you bring them, not just what you need. Seam principles, not pretend knowledge |

**Values cheat sheet**

None of your quoted lines carries a story for these values, so each row is a selection scaffold. Bringing four real stories is the single best upgrade for this round.

| Value (official name) | Working meaning | Your mapped story | Asked at |
|---|---|---|---|
| Members First, Always | Decide from the member's side, even when it's harder for staff | Scaffold: a decision where the member's outcome won over convenience or habit, with what you decided and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | G1 |
| Plain Words | If it needs explaining twice, the wording was wrong | Scaffold: a time you rewrote or re-explained something so a member understood it. Nearest in your material: F4, "trained new tellers on our escalation script". Use it only as training, not as plain-words work for members. If no such time comes to mind, say so plainly | G2 |
| Neighbours, Not Numbers | Each branch belongs to its town | Scaffold: a time local knowledge of a member or a town changed what you did. If no such time comes to mind, say so plainly, then say how you'd keep it alive through the hub move | G3, G4 |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | Scaffold: a problem that wasn't yours that you kept hold of. Nearest in your material: F3, "I built the monthly complaints spreadsheet our regional manager uses". Answer slot: if you built it because something was missing, say what. If it was asked of you, say so. If no such time comes to mind, say so plainly | G5 |

**Bank G — Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided from the member's side when the easier option pointed the other way." | VAL | [generic] | Scaffold, Members First: a named member situation (anonymised), the easier option, what you chose and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. Name the value aloud once | The panel scores this value by name. VAL |
| G2 | "Explain how a complaint gets handled, as if I'm a member who's just been turned down for a loan." | VAL | [generic] | A live demonstration of Plain Words. Short sentences, no jargon, say what happens next and when, and end with what they can do if they're unhappy. Under 60 seconds. The test is the explanation itself, not a story | The value can be tested by doing it, and branch managers know what members actually hear. VAL |
| G3 | "Tell me about a time you treated a member as part of the community rather than a case number." | VAL | [generic] | Scaffold, Neighbours, Not Numbers: a specific member, the local detail that mattered, and what you did differently because of it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Branch managers live this value. VAL |
| G4 | "Ashgrove is consolidating eight branches into five hubs. How does Neighbours, Not Numbers survive that?" | CO | [grounded] | Acknowledge the tension plainly rather than spinning it. Then practical moves, framed as a plan: track complaints by town, not just by hub. Watch for members who stop coming in. Brief the closing branches' supervisors on escalations early. Don't claim to know how the move is going | Two branch managers facing the brief's consolidation. The question is likely and loaded. CO because it scores the strategy, with VAL delivery |
| G5 | "Tell me about a problem you found that wasn't yours, and kept hold of until it was solved." | VAL | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Scaffold, Own the Fix. You built the spreadsheet your regional manager uses. Answer slot: if you built it because something was missing, say what was missing and what you did. If it was asked of you, say so plainly, and choose another story with the scaffold. If none comes to mind, say so plainly | The value's own wording is the question. G5 is `[inferred]` because the link from F3 to the value is the pack's derivation. VAL |

**Bank H — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | The 20-minute case, for example: "A member has complained three times about the same issue. The branch supervisor has escalated to you. Walk us through it." | CASE | [generic] | Use the build section above: clarify, the member today, the supervisor, the record and the clock, the pattern, close. Say the structure first. Name each value at the step it decides. Ask what response clock the complaints policy sets rather than quoting rules from memory | The graded deliverable. Rehearse it out loud, timed, at least twice. CASE |
| H2 | "A supervisor fixed a complaint fast but outside the process. The member's happy. What do you do?" | CASE | [generic] | Name the tension: Members First against the record. Thank them, get it logged, find out why the process felt in the way, and coach rather than reprimand. Own the Fix: if the process is the problem, you keep hold of fixing it | A likely follow-on to the case. It tests coaching and the values together. CASE |

**Bank J — Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You'd be coaching our supervisors. What would you need from us, and what would you give us?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Reciprocity. You've been a branch supervisor for the last three years, so you know the seat. What you'd give: a monthly view of their branch's complaints, support on hard escalations, and a contact for the contact centre. What you'd need: time with their supervisors, and an early warning on big issues | The managers are pricing what you add to their load. JD because it scores the coaching duty |
| J2 | "When your monthly report makes one of our branches look bad, how will you handle that with the branch manager?" | JD | [generic] | Principles, framed as a plan: no surprises (the manager sees it before senior leaders do), context alongside the number, an agreed action, and credit when it improves. Answer slot: if you've had to share a number that made someone look bad, say how it went. If not, say so plainly | The seam between reporting and partnership. JD because it scores the reporting duty |
| J3 | "Your background is one branch. Why should managers of other branches trust your read of theirs?" | EXP | [grounded] "I handled the branch's formal complaints log" "6 years in retail banking, the last 3 as a branch supervisor" | Hold what's true: six years in retail banking, the last three as a branch supervisor, and you handled the branch's formal complaints log. Concede the scope: it was one branch. Then the plan: you'd start by asking them what you'd miss, and visit each branch before drawing conclusions | F1's objection in peer form. It will come back here even if Round 2 covered it. EXP |

**Reverse questions — Round 3**

| Question | Why it lands |
|---|---|
| "What's one escalation from your branch that went badly, and what would have helped?" | Starts the coaching relationship in the interview, and gives you real material |
| "What would you want from a monthly complaints report that you don't get today?" | Reciprocity. It shows the report is for them, not just about them |
| "How are your supervisors feeling about the hub move?" | Shows you see the Neighbours, Not Numbers tension. Ask it gently |
| "Where does the escalation route break down most often today?" | A practical question that branch managers can answer in detail |
| "What could a new person in this role do in the first month that would genuinely help your branches?" | The peer reciprocity question. It lands with people who'll work beside you |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches (F1) | C1, J3, H1 |
| …and the contact centre (F2) | A5, C1, C3 |
| Report monthly on volumes and resolution times (F3) | K1, K2, J2 |
| Coach branch supervisors on escalations (F4) | C2, J1, H2 |
| Work with digital teams on self-service journeys (F5) | B4, E1 |
| 4+ years in financial-services customer operations (F6) | A1 |
| Regulated complaints (F7) | B1, H1 |
| Confident presenting to senior leaders (F8) | C1, K2 |
| Comfortable with Excel reporting (F9) | B3, K1 |

---

## Prohibited claims

These are claims this pack will not coach, because they are stretched forms of what you told me, or things you've said aren't true. You'll be tempted to reach for them under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation is that it was one branch's log. Slots stay on the log's own steps |
| Has contact-centre experience | A negative you stated (F2) | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders, the executive team or a board | A negative you stated (F8) | "I haven't presented to anyone above regional level." No slot |
| Reports monthly on complaint volumes and resolution times, or built the region's complaints reporting | Inflated form of F3 (the verb and the scope both grow) | F3's quote: "I built the monthly complaints spreadsheet our regional manager uses." Slots ask only what it tracks |
| Has coached branch supervisors | Inflated form of F4 | F4's quote: "trained new tellers on our escalation script." Slots stay inside the teller training |
| Wrote or designed the escalation script | Inflated form of F4 (verb) | "trained new tellers on our escalation script". It is "our" script, and the pack reads no authorship into it |
| Has handled regulated complaints | Inflated form of F7 | F7's quote: "I handled the branch's formal complaints log." The slot asks what rules applied, in neutral terms |

Not listed, because your material is silent rather than stretched: digital or self-service work (F5) and Excel specifically (F9). These are answer slots instead.

---

## Sources

**Provided documents:** the JD text; Ashgrove's values, pasted 12 November 2026 from ashgrovecu.org/about/values; the recruiter's email describing the three rounds; the 2026 strategy brief summary (published July 2026, sent by the recruiter); your background, from your message.

**Searches and fetches sent:** none. Every L1 target was already answered by what you pasted.

No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted this morning fixes the cheat sheet and the G bank |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes all three rounds, the values scoring and the 20-minute case |
| 3. Ashgrove strategy / recent news | skipped | The July 2026 strategy brief, about four months old, supplies priorities and the competitive frame |
| 4. Interviewer name + Ashgrove | n/a | No names have been assigned, so there was no query to form |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD |

---

## Upgrade menu

- **One real story for each of the four values** → the cheat sheet and bank G become story-mapped `[grounded]` rows instead of scaffolds. This is the biggest gain for Round 3.
- **Your answers to the answer slots on F3, F5, F7 and F9** (what the spreadsheet tracks, any digital feedback, which complaint rules applied, which tool you used) → those rows and B1, B3, B4, K1 and G5 regenerate from your words.
- **Whether you've presented to your regional manager** → the C1 and K2 slots become stated lines.
- **The anonymised spreadsheet or the teller training material** → F3, F4 and F9 can move from `medium` towards `high`, because they are the artifacts a reporting role keeps.
- **Which complaints rules Ashgrove works to** (one email to the recruiter) → the case build and H1 can name the real response clock.
- **Interviewer names once assigned** → an interviewer read, persona weights from their public footprint, and a reverse question tied to each person's path.
- **How many prep hours you have before 21 November** → a prioritised prep triage schedule.
- **Confirm the date:** 21 November 2026 is a Saturday. Worth a one-line check with the recruiter.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → recent Ashgrove news, hub-move coverage and any published leadership context. The upgrade would add news since the July brief.
- **A dossier from an earlier job-fit assessment** → an evidence-derived highest-ROI objection and a confirmed list of claims to avoid, instead of the ones inferred here.
