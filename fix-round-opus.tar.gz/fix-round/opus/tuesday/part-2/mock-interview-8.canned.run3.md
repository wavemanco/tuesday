I've read the prep playbook and its rules. Now I'm building your pack around the three rounds on 21 November.
Dara, your prep pack for all three rounds on 21 November is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it only from what you sent: the job description, the values text, the recruiter's email, your strategy summary and your background. I didn't search the web, because your documents already covered everything a search would have found.

**What's in it:**
- **Fit table:** each requirement in the job description, set against your own words, with what to say about any gap.
- **One section per round:** the interviewer styles to expect, 8 to 10 practice questions with answer guidance, and five questions for you to ask them.
- **Values sheet:** one row for each of Ashgrove's four values, with how to pick a story for it.
- **Case prep:** a plan for the 20-minute complaint escalation case with the branch managers.
- **Claims to avoid:** a list of claims the pack deliberately won't coach you to make.

**What matters most:**
- **The question to rehearse first is B1:** "You haven't worked in a contact centre. How would you own complaints there from day one?" You said yourself you've never worked in a contact centre, and the role covers one. Your future manager will ask some version of this. The pack gives you the exact admission, a first-month plan and a way to hold your ground.
- **Never having presented above regional level** is the second gap you named. B2 covers it.
- **Three things only you can settle:**
  - whether the complaints in your branch's log were regulated ones, and which rules applied
  - what your monthly spreadsheet tracks
  - whether it's in Excel

  A sentence on each, outside a practice run, would firm up several answers.
- **The values sheet has no stories yet.** None of the four values is matched to a story, because nothing you've told me so far is one. Each row shows you how to choose one. Give me one real story per value and I'll match them in.

Say the word and I'll play the Head of Member Services and put B1 to you live, with follow-ups.
I can also save a `tuesday-dossier.md` file listing the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 21 November 2026, per the recruiter's email
- Round 1: 30 minutes with the recruiter
- Round 2: 45 minutes with the Head of Member Services, your future manager, "mostly behavioural"
- Round 3: 60 minutes with two branch managers, including "a 20-minute case on a complaint escalation". This is the values round, scored "against the four values"

**Interviewers:** no names assigned yet, so this pack has no interviewer read. The upgrade menu covers what names would add.

---

## How to use this pack

- **Personas** describe how a question is asked: who asks it and in what style. **Types** describe what the question scores.
- **Type key:**
  - **VAL:** whether your past behaviour shows Ashgrove's four published values
  - **EXP:** whether your own experience holds up when probed, and what was actually yours
  - **JD:** whether you can do the listed job, including the gaps
  - **CO:** Ashgrove's strategy, competition and direction
  - **CASE:** a live problem from the role, worked through out loud
- **Provenance labels:**
  - `[grounded]`: traceable to your message, the JD, the values text, the recruiter's email or the strategy points you gave
  - `[inferred]`: this pack's derivation, with the derivation named
  - `[generic]`: a role-family pattern that makes no claim about Ashgrove
- **Answer slots:** where the guidance says "Answer slot", the pack does not know the answer, and only you do. Both branches are honest. The second branch, "it wasn't like that", is a full answer and not a failure.
- **Guidance is scaffolding, not a script.** Say it in your own words.

---

## Fit snapshot

Every evidence quote below is a sentence from your message, exactly as you wrote it. All later sections draw on these quotes and on nothing else about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Six years against a four-year ask, in the quote's own terms. There is no CV behind it yet, so expect a probe on the earlier three years. Words: "Six years in retail banking, the last three as a branch supervisor." Answer slot: if you're asked what the first three years were, describe those roles in your own words |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your material says you handled the branch's formal complaints log. It does not say whether those complaints were regulated, or which part of each complaint was yours. Safe words: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on the rules behind that log likely. If the complaints in it came under rules you worked to, say which rules and what you did yourself, in your own words. If they didn't, or you're not sure, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | One branch's complaints log is next to a cross-branch process, not the same thing, so the words stay at one branch: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages around the log likely. If any stage of a complaint beyond keeping the log was yours to run, say which one and how, in your own words. If none was, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have said this yourself, and wording cannot close it. Words: "I haven't worked in a contact centre." Then say how you would learn it, as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote gives monthly, complaints, built by you, and used by your regional manager. It does not say what the spreadsheet measures. Safe words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it tracks volumes or resolution times, say which and how each is counted, in your own words. If it doesn't, say plainly what it does track |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote says spreadsheet, not Excel. Answer slot: if you built it in Excel, say so and name what you did in it yourself. If it was another tool, name that tool |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Training new tellers is not coaching supervisors. "Our" script does not say you wrote it. The second quote puts you in the supervisor role for three years, in its own words. Words: "I trained new tellers on our escalation script, and I've been a branch supervisor for three years." Answer slot: the JD's coaching line makes a probe on how you trained people likely. Say what training new tellers on the script involved, in your own words, and stay with the tellers |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Strong evidence would be a time you worked with a digital or online-banking team on how members serve themselves. Answer slot: if you have done this, say what it was and what part was yours. If you haven't, say so plainly, then say what you would bring a digital team from the complaints side first |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have said this yourself. Words: "I haven't presented to anyone above regional level." The sentence does not say you have presented at regional level, so this pack doesn't say it either. Answer slot: if you have presented to your regional manager or at regional level, say what and how, in your own words. If you haven't, say so. Then give a plan |

**What the snapshot means for 21 November:**
- F4 and F9 are the two gaps you named yourself. They will be the Skeptic's material.
- F2, F5 and F6 are discovery gaps: only your own answer settles them. One sentence from you on each would upgrade those rows (see the upgrade menu).

---

## Grounding brief

This comes from your summary of the strategy brief Ashgrove published in July 2026. This pack has not read the brief itself, so use these four points as Ashgrove's own words in your summary and add no figures to them.

| Point | Provenance | Where it touches this role |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] your summary of the July 2026 brief | Self-service journeys, the F8 JD line. Complaints data shows where the journeys fail. Used in B9 |
| Consolidate eight branches into five hubs over 2027 | [grounded] your summary of the July 2026 brief | The panel are branch managers. Complaint handling during the change is likely on their minds. Used in C6 |
| Launch a small-business lending product in Q1 2027 | [grounded] your summary of the July 2026 brief | A new product brings new complaint types. Good for a reverse question |
| Main competitive pressure is app-only banks | [grounded] your summary of the July 2026 brief | Member experience is where a credit union competes. Used in A7 |

**One caution:** do not take a side on the merits of consolidation with branch managers. The pack has no view of how they see it, and neither do you yet.

---

## Prohibited claims

These are the claims this pack will not coach, and why. They were built before the question banks, and the banks were written against them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the branch's complaints process | Inflated form of F3 | Use F3's quote at its own scope. The pack's observation is that your material says you handled the log, not that you owned the process. Slots stay inside the log |
| Handled regulated complaints | Inflated form of F2 | Use F2's quote at its own scope. F2's slot asks what rules governed the log, in your words, and asserts nothing |
| Coached supervisors, or wrote the escalation script | Inflated form of F7 | Use F7's quotes at their own scope: you trained new tellers on "our" script, and you have been a supervisor for three years |
| Reported complaint volumes and resolution times to the regional manager | Inflated form of F5 | Use F5's quote at its own scope: you built the spreadsheet and your regional manager uses it. What it measures, and whether you presented it, are F5's slot |
| Has worked in, or with, a contact centre | Negative you stated, F4 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders above regional level | Negative you stated, F9 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end, branches, F3 | A1, B3, B4, C7 |
| Own the complaints process, contact centre, F4 | A4, B1, B10 |
| Report monthly on volumes and resolution times, F5 | B5, B6, B8 |
| Coach branch supervisors on escalations, F7 | B7, C5, C8 |
| Work with digital teams on self-service journeys, F8 | B9 |
| 4+ years in financial-services customer operations, F1 | A1, A3 |
| Experience handling regulated complaints, F2 | A5, B3 |
| Confident presenting to senior leaders, F9 | B2 |
| Comfortable with Excel reporting, F6 | A6, B5 |

---

## Graded deliverable: the 20-minute complaint escalation case (Round 3)

**What is known:**
- `[grounded]` The recruiter's words: "a 20-minute case on a complaint escalation", run by "a panel of two branch managers", who "score against the four values".
- `[grounded]` The JD lines it most likely tests: "Own the member complaints process end to end" and "coach branch supervisors on escalations".
- `[grounded]` From your background, F3: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Bring this in only at its own scope, for example "on the branch complaints log, I saw…". Use it only if it genuinely bears on the case.

**Structure to say out loud.** This is `[generic]`, a case pattern rather than Ashgrove practice.
1. **Clarify** before solving:
   - What does the member want?
   - Has a formal complaint been logged?
   - What has already happened, and who holds it now?
   - Are there regulatory steps or deadlines?
2. **The member first:** what do they need today, and how will they hear it.
3. **Ownership:** who keeps hold of it.
4. **Root cause:** is this a one-off or a pattern?
5. **Close the loop:** with the member, with the supervisor, and in the monthly report.

**Map each step to a value as you go.** The panel scores against the values, so name them in passing, not as slogans:
- Members First, Always: start from the member's side of the counter
- Plain Words: what the member is actually told
- Neighbours, Not Numbers: the branch's place in its town
- Own the Fix: who keeps hold until it is solved

**Three theses to choose from.** Each comes with a concession you should say out loud.

| Thesis | Concession to say aloud |
|---|---|
| Fix it for the member first, then fix the process | Speed must not skip whatever regulated-complaint steps apply. Ask what those are in your clarifying questions rather than assuming them |
| The person who found the problem stays its owner, with you supporting them. This is Own the Fix taken literally | Some escalations do have to move up a level. Say where your line would sit and why |
| One escalation is a data point: check the complaints data for the same issue at other branches | In 20 minutes, one case is not a trend. Say you would check, and don't claim a pattern you haven't seen |

**How to stand out.** Most candidates resolve the member's complaint and stop. You stand out by:
- closing the loop back to the supervisor and into the monthly report, and
- saying the plain-words message to the member out loud.

**What to avoid:**
- Don't promise the member a specific outcome or payment before the facts are in.
- Don't blame the branch while two branch managers are scoring you. Talk about the process, not the people.

---

## Values cheat sheet (Round 3)

The value names and lines come from the text you copied on 12 November 2026 from ashgrovecu.org/about/values.

None of your quoted sentences yet carries a story for a specific value. Each row below is therefore a selection scaffold: how to pick a story. One story from you per value would turn these into mapped stories (see the upgrade menu).

| Value, official name | Working meaning | Your story |
|---|---|---|
| Members First, Always | Decide from the member's point of view, not the institution's | Selection scaffold: pick a time you made or pushed for a decision because of how it landed for the customer. It needs the customer's situation, the choice, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If it has to be explained twice, the first explanation was the problem | Selection scaffold: pick a time you rewrote or re-explained something so a customer or colleague understood it the first time. The nearest material is F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Use it only if the training involved making something clearer. If no such time comes to mind, say so plainly and say how you would handle it |
| Neighbours, Not Numbers | Each branch belongs to its town, and people are not metrics | Selection scaffold: pick a time local knowledge of a customer or community changed what you did. It needs the person, what you knew, and the choice it changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Selection scaffold: pick a problem you spotted and followed through to the end, rather than passing on. The nearest material is F5: "I built the monthly complaints spreadsheet our regional manager uses." It is your story here only if building it began with a problem you spotted. If it didn't, pick another. If no such time comes to mind, say so plainly and say how you would handle it |

---

# Round 1: Recruiter, 30 minutes

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly openers, motivation, logistics | High. This is the recruiter-screen prior, and 30 minutes leaves little room for depth | A pre-scripted 90-second arc. Treat casual questions as scored |
| Skeptic, light | Knockout checks against the JD requirements | Mid. Recruiters screen against the requirements list, and F4 and F9 sit on it | Give the plain acknowledgment in one breath, then the plan. Don't over-explain |
| Values/Behavioral | A first look at the values | Low. The values are scored in Round 3, but a recruiter may preview them | Have one value you can speak to briefly |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with three beats, each one your own sentence:<br>1. Six years in retail banking, the last three as a branch supervisor.<br>2. You handled the branch's formal complaints log and trained new tellers on the escalation script.<br>3. You built the monthly complaints spreadsheet your regional manager uses.<br>Answer slot: close with why this role, in your own words | The opener in every screen. F1, F3 and F5 are the rows that point at this job. EXP because it sets up everything later probed |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Tie your answer to one value by its exact name, for example Members First, Always or Neighbours, Not Numbers, and say why it matters to you. Answer slot: your own reason for wanting a member-owned organisation, in your words. If the honest reason is the role rather than the sector, say that | A motivation check. CO because it tests whether you know what Ashgrove says about itself |
| A3 | "Why move out of a branch now?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start from the three years as a supervisor. Answer slot: what drew you to complaints and member experience specifically, in your own words. If it's the next step rather than a pull, say so plainly | A Skeptic consistency check on F1. JD because it tests whether the move makes sense against the role |
| A4 | "This role covers the contact centre too. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't worked in a contact centre." Then give one line of plan: how you would learn its complaint flow in the first weeks. Stop there. The recruiter is checking, not drilling | F4 is a stated gap against a headline duty, so expect it as a knockout check. B1 rehearses the deep version |
| A5 | "The JD asks for regulated-complaints experience. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | "I handled the branch's formal complaints log." Answer slot: if those complaints came under rules you worked to, name the rules and what you did yourself. If they didn't, or you're unsure, say so plainly and stay with the log | F2 is a discovery gap, and the recruiter screens on listed requirements. The question takes its premise from the JD, and the guidance does not adopt it |
| A6 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it is in Excel, say so and name what you did in it yourself. If it's another tool, name it | F6 is a discovery gap. It is short to answer and easy to answer well |
| A7 | "What do you know about where Ashgrove's heading?" | CO | [grounded] | Pick one point from the grounding brief rather than reciting all four, for example the 40% digital goal and app-only banks as the main competition. Say in one line why complaints are where that shows first, and present it as your view | A homework check. CO because it tests strategy fluency |
| A8 | "Which of our values speaks to you most?" | VAL | [grounded] | Name one value exactly as Ashgrove writes it and give a short example, chosen with the values cheat-sheet scaffold. Keep it to 60 seconds. Round 3 goes deeper | It previews the values round. VAL because the values are scored |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does success look like in this role at six months?" | It gets you the measure to aim at for Rounds 2 and 3 |
| "Do you know yet who the two branch managers on the panel will be?" | Names would let you prepare for the panel specifically |
| "How is the 20-minute case set up: is it read on the day or sent ahead?" | It is process detail you can prepare around, and recruiters can answer it |
| "Is this a new role or a backfill?" | It tells you whether you are building the complaints process or inheriting one |
| "Is there anything in my background you'd expect the Head of Member Services to probe?" | It invites the recruiter to tell you the objection before Round 2 |

---

# Round 2: Head of Member Services, your future manager, 45 minutes, "mostly behavioural"

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time…" questions, expecting STAR-shaped answers | High. The recruiter said "mostly behavioural" | Prepare a story bank. Use "we" for context and "I" for your contribution |
| Skeptic | Gaps against the role this person will manage | High. The hiring-manager prior is to de-risk gaps, and F4 and F9 are the gaps you named | Rehearse the objection until it bores you. Plain acknowledgment, then a concrete plan |
| Data-Driven Prober | Your spreadsheet, and how numbers are counted | Mid. Monthly reporting is in the JD, and F5 is your nearest evidence | Know how each figure is counted, or say plainly that you don't |
| Case/Strategist | Problems on their actual agenda | Mid. Hiring managers test capability on live problems, but the round is mostly behavioural | Clarify first, structure next, then answer |
| Pressure | A time-boxed "why you" | Low. One question is enough to rehearse it | Hold your position, then concede |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked in a contact centre. How would you own complaints there from day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **This is the highest-ROI rehearsal in this pack.**<br>1. **Name the limit before you're pushed:** "I haven't worked in a contact centre."<br>2. **Give a first-month plan, said as a plan:**<br>- listen to calls<br>- sit with the contact-centre team leads<br>- read their complaint data next to the branches'<br>- map where complaints pass from one channel to the other<br>3. **Hold through two follow-ups** by going back to what you do carry: "I handled the branch's formal complaints log." Say it at branch scope, never as equivalent to contact-centre experience.<br>4. **If pushed a third time, concede exactly:** "That part I'd be learning, and I'd want your contact-centre leads' view early." | F4 is a stated gap against the JD's headline duty. Your future manager will ask it in some form. JD because it scores the stated responsibility, with Skeptic delivery |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick F9, since B1 already covers the contact centre: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and how. If not, say so. Then a plan: how you would prepare the first monthly report for senior leaders, and ask how they like information presented | F9 is the second stated gap. Naming a real weakness, with a plan, scores as self-awareness |
| B3 | "Tell me about a complaint you'd handle differently now." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one complaint from your time on the branch log. It needs what happened, what you did, and what you would change. Answer slot: if the complaint came under rules you followed, say what they required. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A behavioural probe on F2 and F3. VAL first because Own the Fix and Members First sit under it, with EXP as the content |
| B4 | "Tell me about a time you escalated something above your branch." | VAL | [generic] | Selection scaffold: it needs the issue, why it couldn't stay at the branch, who you took it to, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's escalation line asked in behavioural form. Its theme comes from the JD, but no quote carries an instance |
| B5 | "Walk me through the monthly complaints spreadsheet: what's in it, and how is each number counted?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with what the quote states: you built it, it's monthly, your regional manager uses it. Then answer these slots, each in your own words:<br>- how each figure is counted<br>- what it is sensitive to<br>- the assumption you'd defend least<br>- which part was yours<br>Answer slot: if it tracks volumes or resolution times, say how. If it doesn't, say what it does track. "I'm not sure how that figure is defined upstream" is an honest answer | F5 is your nearest evidence for the reporting duty, and a prober will go two levels deep. EXP because it tests what you built |
| B6 | "Your regional manager uses it. What for?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you know what decisions or conversations it feeds, say so in your own words. If you don't, say so plainly and stay with what it contains | The quote says "uses". This tests whether you know the impact. Don't fill in decisions you didn't see |
| B7 | "How did you train new tellers on the escalation script?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats are the ones the quote gives: new tellers, the escalation script, and you trained them. Tell it in your own words. Answer slot: if you shaped or changed the script, say how. If it was given to you, say so and describe how you taught it | F7's evidence, and the bridge to coaching supervisors. It also tests the "our script" attribution |
| B8 | "The monthly report shows resolution times rising at two branches. What do you do in your first week?" | CASE | [generic] | Structure:<br>1. Check the definition and data first.<br>2. Compare against other branches.<br>3. Talk to those branch supervisors before drawing conclusions.<br>4. Look at complaint types.<br>5. Set an action with the supervisor and track it in next month's report.<br>Map the steps to Own the Fix and Plain Words as you go | A live problem from the JD's reporting line. It asks about no past |
| B9 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints, and what would you want from the digital team?" | CO | [grounded] | Think out loud: new channels bring new failure points, and complaints are early warnings for digital journeys. Say what you would ask the digital team for and what you would give them. F8 answer slot: if you have worked with a digital team, say what and your part. If not, say so plainly and make this a plan | A strategy question from the brief you supplied, aimed at F8. CO with CASE delivery |
| B10 | "Sixty seconds: why you over someone who's run a contact-centre complaints team?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses."; "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause first.<br>1. **Hold on what you carry:** three years as a branch supervisor, the branch's formal complaints log, training tellers on the escalation script, and the monthly spreadsheet.<br>2. **Concede the contact centre plainly:** "I haven't worked in a contact centre."<br>3. **Hold again** on the branch side, which this role also covers.<br>Don't claim to be the better contact-centre hire | Pressure delivery of the B1 objection. It rehearses holding your position and then conceding. JD because it scores fit |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What's the biggest complaint theme you're seeing right now?" | It shows you'd start from their reality, and it tells you what to prepare for the case |
| "How do complaints reach senior leaders today, and where would this role present?" | It addresses F9 directly and shows you're thinking about the reporting audience |
| "How is complaint handling split between the branches and the contact centre today?" | It engages your F4 gap by asking rather than avoiding it |
| "How do you expect the digital shift to change complaint volumes?" | It ties the role to their 2028 goal |
| "What would make the first 90 days a success from your side?" | You get your future manager's own measure |

---

# Round 3: Panel of two branch managers, 60 minutes, values round with a 20-minute case

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Stories scored against the four values | High. The recruiter said the panel "score against the four values" | One story per value, chosen with the cheat sheet. Use the values' exact names |
| Case/Strategist | The 20-minute complaint-escalation case | High. The recruiter named it | Follow the deliverable section above |
| Peer Evaluator | "What would you need from us?", and where the role and their branches meet | Mid. You would coach their supervisors, which affects how their branches work | Frame it as reciprocity: suggest working principles rather than claiming to know the friction points |
| Skeptic | "Why should our supervisors listen to you?" | Low. It is likely to come up once | Hold on F7's quotes, then concede |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Use the cheat-sheet scaffold for Members First, Always. Use "I" for what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Its theme comes from the value's own wording, so expect close to this phrasing |
| C2 | "Tell me about a time something had to be explained more plainly because the first version didn't land." | VAL | [grounded] | Use the Plain Words scaffold. Answer slot: if training new tellers on the escalation script involved making it clearer, that may be the story. If it didn't, pick another. If no such time comes to mind, say so plainly and say how you would handle it | From the Plain Words line in the values text. F7 is the nearest row |
| C3 | "Tell me about a time you treated someone as a neighbour, not a number." | VAL | [grounded] | Use the Neighbours, Not Numbers scaffold. Be careful with branch managers: be specific about the person, not general about community | From the value's own wording. It matters to people who run branches |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] | Use the Own the Fix scaffold. Answer slot: if building the monthly spreadsheet began with a problem you spotted, it may be your story. If it didn't, pick another. If no such time comes to mind, say so plainly and say how you would handle it | From the value's wording, which is unusually specific: whoever finds the problem keeps it. F5 is the nearest row |
| C5 | "You'd be coaching our supervisors on escalations. What would you need from us, and what would you bring?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Reciprocity first. What you bring: you have been a branch supervisor for three years, and you trained new tellers on the escalation script. What you'd need: their view of which escalations reach them that shouldn't. Say it as a principle you'd work by, not a claim that you know their branches | The F7 transferability gap, asked collegially by the people whose supervisors you'd coach. Peer Evaluator delivery |
| C6 | "Over 2027, eight branches become five hubs. How do you stop complaints falling through the cracks during that?" | CO | [grounded] | Think out loud:<br>- members of closing branches may complain differently, or more<br>- watch the complaints data by branch through the change<br>- agree who owns a complaint when a branch merges<br>- keep messages to members plain<br>Don't judge the consolidation itself | From the strategy brief you supplied, and it lands directly on the panel's branches. CO with CASE delivery |
| C7 | "One of our supervisors thinks your escalation guidance is wrong for their branch. What do you do?" | CASE | [generic] | Structure:<br>1. Listen first: what is different about that branch?<br>2. Check the complaints data.<br>3. Separate what must be consistent, such as anything regulated, from what can flex locally.<br>4. Agree it with the supervisor and review it.<br>This touches Neighbours, Not Numbers | A disagreement between peers, set in the role. It asks about no past |
| C8 | "Our supervisors have done this for years. Why would they take coaching from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold: you have been a branch supervisor for three years yourself. Then the scope, exactly: "I've trained new tellers on our escalation script, and with your supervisors I'd start by listening to them." Hold again on the shared seat, and don't stretch the training beyond the tellers | Skeptic delivery of F7. It rehearses a confident but not defensive answer |
| C9 | "Members First and hitting resolution-time targets can pull against each other. Which wins?" | VAL | [generic] | Don't pick a slogan. Members First, Always is the stated value, so say how you would keep resolution-time data honest without rushing members, for example by tracking quality alongside speed. Say what you would do when the two really do conflict | It tests whether you can hold a value under tension. VAL first, with CASE delivery |
| C10 | The 20-minute case | CASE | [grounded] | See the deliverable section above | Named by the recruiter |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would actually help your supervisors?" | A reciprocity question for the people whose teams you'd coach |
| "Which escalations reach you that you think shouldn't?" | It shows you'd design coaching around their pain points |
| "How are members at your branches finding the move to hubs so far?" | It engages the consolidation without taking a position |
| "What does a really good escalation look like from where you sit?" | It shows you want to learn their standard, not impose one |
| "Where do you see Own the Fix working best in your branches today?" | It shows you take the values seriously as working practice, not slogans |

---

## Sources

**Provided documents:**
- The JD text
- The values text you copied on 12 November 2026 from ashgrovecu.org/about/values
- The recruiter's email describing the three rounds
- Your summary of Ashgrove's July 2026 strategy brief, which the recruiter sent you. This pack has not read the brief itself
- Your background, in your message

No searches or fetches were sent. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | You pasted the values text this morning, which fixes the values cheat sheet and the VAL themes |
| 2. Ashgrove interview process for member-experience roles | skipped | The recruiter's email sets out all three rounds, which fixes the loop and the persona weights |
| 3. Ashgrove strategy or recent news | skipped | The July 2026 brief is under six months old and already supplies the current priorities for the CO questions |
| 4. Interviewer name at Ashgrove | n/a | No names have been assigned, so there was nothing to search. There is no interviewer read |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, from the recruiter once assigned:** an interviewer read for each round, persona weights based on their public professional profiles, and a reverse question tied to each person's own career path.
- **Your CV:** every evidence cell gets inspectable backing, so confidence can rise from `medium` on F1, F3, F5 and F7. The earlier three years in F1 get their own rows.
- **One sentence each on what the complaints log covered and which rules applied:** upgrades F2, A5 and B3, possibly from discovery to a direct match.
- **One sentence on what the monthly spreadsheet tracks, and the tool:** upgrades F5, F6, A6, B5 and B6.
- **One real story per value, told outside a drill:** turns the four cheat-sheet scaffolds into mapped stories for C1 to C4.
- **Whether you have ever worked with a digital or online-banking team:** settles F8 and B9.
- **The full strategy brief text:** the grounding brief can quote Ashgrove's own wording instead of your summary.
- **Prep time available before 21 November:** adds a prioritised prep schedule.
- **Deeper research:** up to 6 more searches and 2 more fetches, taking several more minutes. It would look for role-family loop reports and recent organisational context, such as leadership changes. Most of what it would find is already covered by your documents.
- **A tuesday-dossier.md from an earlier fit assessment, if you have one:** evidence-derived objections and a guardrail list of claims not to make. It is not needed for this pack.
