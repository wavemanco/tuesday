Building Priya's mock-interview pack now. I've read the playbook. Next I'm running a few targeted searches for Northwind's values, its interview loop, and Dan's public profile.
I've built Priya's prep pack for her hour with Dan. It's set up as a peer conversation and draws only on what you gave me. The three web searches (Northwind's values, its interview process, Dan's public profile) were refused permission, so nothing in it comes from the web.

**How the questions are organized**
- There are 22 questions across seven interviewer personas, weighted for a peer interview with Dan.
- The two heaviest are:
  - **The data-driven prober**, because Dan calls himself "relentlessly data-driven".
  - **The peer evaluator**, because a peer cares where your work and his meet and what you'd need from each other.
- The pricing and packaging cases lean on his pricing background and on the bundling threat and the Compass copilot from your research note.
- Each question has a type tag (behavioral, work-experience, role/JD, company, live case), answer guidance, and a rationale for including and tagging it.
- A coverage table maps each JD requirement to the questions that cover it.

**The most important question to rehearse is D1.** Dan will very likely ask some version of "you haven't done sales-ops or quota-setting work." The pack gives Priya:
- an opening line that admits the gap plainly;
- her annual volume targets and partner revenue model, described no bigger than you described them;
- a ramp plan, with wording for the two follow-ups he's likely to push with.

**What the pack holds back on**
- **Overstated claims.** A "prohibited claims" table lists the over-claims she might reach for under pressure, such as "drove the $400M" or "designed partner motions."
- **Details you didn't give me.** Things like how the $400M was counted, or what part of the partner model was hers, are left as fill-in "answer slots" for Priya. The pack doesn't invent them.

The file is `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-1-denied-f74c3d15/Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. It ends with a list of inputs that would sharpen it, such as allowing web search, the full JD text, and Priya's resume.

If you like, I can play Dan as the skeptic on D1 for a live run-through.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for Priya to carry into later sessions.
I can also convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya · **Conversation:** a single 60-minute session with **Dan Kovac, Director of Sales Strategy**. He is a **peer**, and you would both report to the same VP.

Built from the coach's notes: the JD highlights, Priya's background, Dan's profile and the coach's research note. Web research was attempted and refused (see Sources), so nothing here comes from the web.

---

## How to use this pack

- **Personas** describe *how* a question arrives: Dan's register at that moment. **Types** describe *what* is being scored. Rehearse both. The same objection can come back as a friendly "help me understand" from a peer.
- **Type key**
  - **VAL**: behavioral or values. Past behavior shows the principle, not generic virtue.
  - **EXP**: work-experience deep-dive. Do the claims survive scrutiny, and what was actually Priya's?
  - **JD**: role-driven. Can she do the listed job, gaps included?
  - **CO**: company and strategy. Can she think at Northwind's altitude?
  - **CASE**: a live problem from the role. Structure and reasoning, out loud.
- **Fit-snapshot rows are F1–F7.** Question IDs go by persona: A, B, C, D, E, G, H. The letter F is skipped so question IDs never collide with fit rows.
- **Provenance labels:** `[grounded]` traces to the coach's notes. `[inferred]` is a derivation, which is named. `[generic]` is a role-family pattern that makes no claim about Northwind or Priya.
- **Answer slots** are instructions for the interview, not questions for you. Each has two honest branches: if she did it, she says how in her own words; if not, she says so plainly.
- **Guidance is scaffolding, not a script.** Every guidance cell can be spoken in about two minutes. Priya should put it in her own words and say only what she actually did.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm" — the coach's notes; "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows strategy consulting, product strategy and ops, and a proposal. It does not show ownership of a go-to-market strategy, and the words stay at that scope: "Two years in strategy consulting, then nine years in product strategy and ops at a large consumer-tech company, where I proposed a store-surface change that was credited with roughly $400M in ARR uplift." Answer slot: the JD's "own GTM strategy" line makes a probe on what she owned likely. If any part of a go-to-market plan was hers to set, she says which part and how she decided, in her own words. If none was, or there was no such step, she says so plainly and stays with the strategy-and-ops work and the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | The material says nothing either way about customer-lifecycle or whitespace analysis. Answer slot: the JD's whitespace line makes a probe likely. If she has found or sized an untapped segment or an expansion opportunity in any role, she says what it was and how she found it, in her own words. If she hasn't, she says so plainly and explains how she would read Northwind's installed base first |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but nothing inspected stands behind the line, and Dan is self-described "relentlessly data-driven", so expect a probe. Lead with the quote's own terms: skilled in SQL and Tableau. Answer slot: the JD's word "independent" makes a probe on a specific analysis likely. If she ran one end to end herself, she describes it in her own words. If her SQL/Tableau work mostly supported other people's analyses, she says so plainly |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material says a model used in negotiations, not the design of a partner motion. The words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD marks this "required", so a probe on design is near-certain. If any part of how a partnership was structured was hers to shape, she says which part and how, in her own words. If the model fed decisions others made, or there was no such step, she says so plainly and stays with the model and how it was used |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only the quote: "I set annual volume targets with cross-org consensus." Keep "volume targets". They are not quotas (see F7) |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Derivation: with Compass, an AI copilot, launching (your research note), "AI experience" here plausibly means AI product or GTM work, which daily tool use does not show. Answer slot: if any of that daily use is in her analysis or planning work, she says what for, in her own words. If it's general productivity use, she says so plainly and points forward to Compass |
| F7 | Not in the JD highlights. As a role-family pattern, a peer who runs sales strategy will expect fluency in sales planning such as quotas and territories | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A stated gap that wording cannot close. Words: "I haven't done classic sales-ops or quota-setting work." Then how she would learn it, said as a plan and never as a past. Never a claim to quota work, and F5's volume targets are never reworded into quotas |

**Requirement coverage**

| JD requirement | Fit row | Questions that cover it |
|---|---|---|
| own GTM strategy for two new product lines | F1 | C3, C1, C2, D1, E1, G1 |
| identify whitespace across land/adopt/expand/renew | F2 | C3, A5, C1 |
| run independent analysis in SQL and Tableau | F3 | A4, A5, B1 |
| partner-motion design experience required | F4 | D3, A2, C3, B4 |
| strong cross-functional influence | F5 | A3, B1, B2, B5 |
| AI experience a plus | F6 | G2, C2 |
| Sales-planning fluency, role-family and not in the JD | F7 | D1, E1, B5 |
| Northwind priorities and competitive threat, from your research note | — | C1, C2, B4, D2 |

---

## Reading the interviewer

| What we know | Source | Practical implication |
|---|---|---|
| Director of Sales Strategy, and Priya's **peer** under the same VP | your message | `[inferred]` He is weighing what Priya adds to his work, and what she costs it. Seam, credit and "what would you need from me" questions are likely. See bank B |
| Self-describes as "relentlessly data-driven" | your message, from his profile | `[inferred]` Every number gets probed down to its assumptions. The ~$400M figure in F1 is the biggest target. See A1 and E2 |
| "career spine is pricing and monetization roles" | your message | `[inferred]` Cases tilt toward pricing, packaging and unit economics, his native language. See C1 and C2 |
| "one early-stage-startup chapter" | your message | `[inferred]` Scrappiness probes and some skepticism about big-company pace are plausible. Concrete, hands-on detail lands better than org-scale framing |

**Mirror opportunities.**

- **Shared vocabulary:** monetization and revenue modelling. F4's evidence, "built a partner-level revenue model used in carrier negotiations", is the one quote that speaks his language. Use it at its own scope.
- **Shared career jump:** none offered. No fit row carries a counterpart to his startup chapter.

---

## Persona table

| Persona | How it shows up from Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Asks for denominators, how a number was counted, what she ran herself | **Highest.** It is a peer-round prior, and his "relentlessly data-driven" self-description pushes it up further | Know what you can and cannot say about how each number was counted. Name your weakest assumption first. Say "I don't know" plainly |
| B. Peer Evaluator | Seam, credit, "what would you need from me", disagreement with equals | **Highest.** This is the dominant prior for a peer round | Reciprocity: what she brings his team. Propose seam *principles*; don't pretend to know Northwind's org |
| C. Case/Strategist | Live GTM, pricing and packaging problems | **Mid.** The JD is a strategy role, and his pricing spine makes pricing cases likely | Clarify, objective, segment, approach, metrics, risks. Think aloud and challenge one premise |
| D. Skeptic | "Why consumer tech to B2B?" and "You haven't done X" | **Mid.** F7's stated gap sits squarely in his territory, and F4 is a required item that is only adjacent | Lead with the plain acknowledgment, follow with the quotes at their own scope, then a ramp plan |
| E. Pressure | Devil's advocate, a 60-second challenge, "how much was you?" | **Low.** A peer is unlikely to run a stress interview, but a data-driven peer may push hard on one number | Pause and restate the question. Hold through two follow-ups, then concede something specific |
| G. Conversational | The opener, and a casual "what are you doing with AI?" | **Low.** Usually a few minutes at the start, but casual questions about JD plus-skills are still scored | Use a 90-second arc. Treat the AI question as scored |
| H. Values/Behavioral | One or two "tell me about a time" questions | **Low.** No values-style round is detected (see Sources), but peers often ask a disagreement or truth-telling story | Pick stories in which the hard truth actually landed. Where the material shows none, say so |

---

## Question banks

### A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the ~$400M ARR figure on the store-surface change. How was it counted?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The beats are the ones the quote states: you proposed the change, and it was credited with roughly $400M in ARR uplift. Keep "proposed" and "credited" exactly. Then the defend-the-number slots, each in your own words: how the figure was counted, what it is sensitive to, which assumption behind it you'd defend least (name that one before he asks), and which part was yours. If you don't know how it was counted, say so plainly and return to what you proposed | F1's headline metric is the likeliest number to be taken apart by a self-described data-driven interviewer with a monetization background. EXP because it tests attribution and counting, not the role |
| A2 | "Tell me about the partner-level revenue model you built. How did it work, and how was it used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats from the quote: you built it, it was partner-level, and it was used in carrier negotiations. Answer slot: how the model worked and its weakest assumption, in your own words. On how it was used, say only what you saw of its use. If you don't know more than that, say so plainly and stay with what the model showed | F4 is the closest evidence to a *required* item, and it speaks Dan's monetization language, so he will want to look inside it. EXP because it verifies the claim rather than testing the requirement (D3 does that) |
| A3 | "Walk me through how you set the annual volume targets." | EXP | [grounded] "set annual volume targets with cross-org consensus" | The beats from the quote: you set them, annually, with cross-org consensus. Answer slot: how you set them, in your own words, and the assumption you'd defend least. If there was no formal method, or most of it was someone else's, say so plainly and name the part that was yours. Keep the word "volume". Don't let a follow-up turn them into quotas | Targets are Dan's home turf, and F5 is where he can compare Priya's practice with his own. EXP because it tests what she actually did, and it feeds the cross-functional requirement indirectly |
| A4 | "Tell me about an analysis you ran yourself, end to end, in SQL and Tableau." | JD, EXP | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick one analysis that was yours from query to dashboard to decision. It needs a business question, the data you pulled, what you found, and what changed because of it. If no analysis that was fully yours comes to mind, say so plainly, then give the nearest one and say which part was yours | The JD says "independent analysis" (F3), and Dan will test whether "skilled" means hands-on. JD-primary because it scores a listed requirement, with EXP delivery |
| A5 | "Suppose one of the new product lines is converting 30% below plan two quarters in. How do you diagnose it, and what's the first data you pull?" | CASE, JD | [generic] | Clarify first: what was the plan built on, which segments, which motion (direct or partner)? Then check the plan's assumptions before blaming execution, since a data-driven peer respects that order. Segment the funnel by lifecycle stage: land, adopt, expand. Name the first two queries or views you'd build. Rank your hypotheses and say what would confirm or kill each. Close with the decision you'd bring the VP in week two. No claim about your past is needed | A hypothetical built on the JD's land/adopt/expand line (F2) and its SQL/Tableau line (F3), in the form a Prober uses to watch you handle data. `[generic]` because the scenario is invented, not a Northwind fact |

### B. Peer Evaluator (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. I run sales strategy, and you'd own GTM for emerging products. Where's the seam, and what happens when we disagree?" | JD, CASE | [grounded] "skilled in SQL/Tableau" | Don't pretend to know Northwind's org. Ask what he owns today, then propose principles: one shared set of data definitions, emerging-product targets agreed with his team rather than layered on top of them, and disagreements taken to the VP jointly, with the data, rather than separately. Reciprocity: offer what you bring, in your own words. The quote supports "I'm skilled in SQL and Tableau, so I can do my own analysis rather than queue behind your team" | The classic peer stem, and the requirement it scores is "strong cross-functional influence" (F5). JD-primary for that reason; CASE because it asks for a design, not a memory |
| B2 | "Tell me about a time you disagreed with a peer on a number or a target. How did it resolve?" | EXP, VAL | [grounded] "set annual volume targets with cross-org consensus" | Candidate story: F5's volume targets. Answer slot: if reaching that consensus involved a disagreement with a peer, say what it was about, what you did, and how it ended, in your own words. If it didn't, or you weren't party to it, say so plainly and pick another time a disagreement with an equal ended with the relationship intact. If none comes to mind, say so and describe how you'd handle one with Dan | Disagreement with equals is what a peer is scoring. EXP-primary because it should be a real event, with VAL secondary because it tests disagreement style |
| B3 | "How do you handle credit when work spans teams? Take the store-surface change." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the precise words: you proposed it, and the uplift was credited to the change. Answer slot: whose work it took to ship and measure it, in your own words. If you don't know how credit was assigned, say so plainly. Then the principle, as a forward statement: how you would share credit with Dan's team on joint work | A peer prices what sharing work with you looks like, and F1's big number is the natural test case. EXP because it checks attribution |
| B4 | "If the VP asked us for a joint plan to take Compass into enterprise accounts, what would you need from me, and what would I get from you?" | CASE, CO | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | What you need: his account segmentation, pipeline and coverage view, and pricing guardrails. What he gets, at the quotes' scope: analysis you can run yourself in SQL and Tableau, and a partner lens. Say "I built a partner-level revenue model used in carrier negotiations", and offer it as a perspective, not as partner-design experience. Propose one shared success metric and a cadence | It combines two of Northwind's stated priorities from your research note (enterprise expansion and Compass) with the peer's reciprocity question. CASE delivery, with CO because it needs company context |
| B5 | "Sales will push back if emerging-product targets look like they come out of core quota. How do you get reps and sales leadership on board?" | JD, CASE | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | Say the limit before he asks: "I haven't done classic sales-ops or quota-setting work, so I'd design this with your team." Structure: learn how quota and comp work here today, find where new-product credit would conflict, then options to test with him, such as separate targets or agreed credit rules (generic patterns, not Northwind facts). The nearest story stays at its own scope: "I set annual volume targets with cross-org consensus" | Squarely on the seam with Dan's function. It scores cross-functional influence (F5) against the stated gap (F7), so JD-primary with CASE delivery |

### C. Case/Strategist (mid weight, pricing tilt)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The big platform vendor bundles a good-enough version of one of our new products. How do we respond: price, package, or position?" | CASE, CO | [grounded] | Clarify: which product, how much the bundle's buyers overlap with ours, and whether the bundled version is actually adopted (challenge that premise). The objective is the profitability priority, so don't race to zero. Segment into accounts where the bundle is enough and accounts that need depth. Options: package into an enterprise tier, value-based pricing on differentiated capability, a land offer that expands, partners who sell depth. Metrics: win rate against the bundle, discount depth, net retention. Risks: margin and channel conflict | Your research note names bundling as the main competitive threat, and Dan's pricing spine makes this his native case. CASE because it is live, CO because it requires Northwind's strategic frame |
| C2 | "How should we price and package Compass? Add-on, part of the enterprise tier, or usage-based? And how does that square with getting to profitability?" | CASE, CO | [grounded] | Structure: the value metric (what customers would pay per), cost to serve (AI inference costs can be material, as a generic pattern), willingness to pay by segment, and land-versus-expand effects. Name the tension openly: a bundled Compass helps adoption and the response to the competitor's bundle, while an add-on helps margin. Propose a test, not a verdict. Ask what he has seen in pricing data. No claim about your past | Compass and profitability are both stated priorities (your research note), and pricing is Dan's spine. It also touches "AI experience a plus" (F6) without needing her to claim any |
| C3 | "Sketch the GTM for a new product line: where we land, how we expand, and what the partner motion is. What do you need to know first?" | CASE, JD | [generic] | Clarify: the product, the ideal customer, and its overlap with the current enterprise base. The land wedge is the existing base, given the enterprise-expansion priority. Then adoption signals and expansion triggers, renewal risk, and the partner motion: who the partners are, whether they source or deliver deals, how they're paid, and the conflict rules with direct sales. Metrics for each stage. If anything from your own work applies, mention it in your own words at its real scope. If not, stay with the plan | The JD's core mandate in one question (F1, F2, F4). JD-primary because it scores the listed responsibilities, with CASE delivery. `[generic]` because the product is unnamed |

### D. Skeptic (mid weight). D1 is the highest-ROI prep in this pack

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting work, and this role sits right next to a sales org. What makes you confident you can set GTM for products an enterprise sales team has to sell?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI prep. Rehearse it until it's boring.** Open with the limit: "I haven't done classic sales-ops or quota-setting work." Then the two quotes, at their own scope: "I set annual volume targets with cross-org consensus, and I built a partner-level revenue model used in carrier negotiations." Then a ramp plan, as a plan: learn Northwind's quota and territory mechanics from Dan's team in the first weeks, and build emerging-product targets with them. Answer slot: if any of your consulting or consumer-tech work involved an enterprise sales motion, say which and what part was yours; if none did, say so plainly. **Follow-up 1**, "volume targets aren't quotas": agree. "Right, they were volume targets, not quotas." Don't defend the swap. **Follow-up 2**, "so you'd be learning my area on the job": concede specifically. "On quota mechanics, yes. That's why I'd build this with your team, not around it." Never claim quota work, and never call the model partner design | F7 is a stated gap in exactly Dan's territory, and F4 is only adjacent to a required item, so this will be asked in some form. A rehearsed, non-defensive answer changes the hour. JD because it scores whether she can do the listed job |
| D2 | "Why leave a large consumer-tech company for a B2B data-infrastructure company, and why now?" | CO, JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Answer slot: your real reasons, in your own words. The pack doesn't know them and won't supply them. Then tie the reasons to Northwind's stated priorities (enterprise expansion, Compass, profitability, from your research note) and to the JD's emerging-products scope. Keep the past at the quote's scope: nine years in product strategy and ops at a large consumer-tech company. Don't knock the old employer | The "why here, why now" Skeptic stem, made sharper by the consumer-to-B2B jump (F1). CO-primary because a good answer shows homework on Northwind, with JD secondary |
| D3 | "Partner-motion design is a requirement here. Walk me through a partner motion you've designed." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Don't accept the premise silently. "The closest I have is that I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of how a partnership was structured was yours to shape, say which part and how, in your own words. If none was, or there was no such step, say so plainly and stay with the model. Then pivot forward to how you'd design one here (see C3). Hold through follow-ups by returning to the model, never by widening it | The JD marks this "required" and F4 is adjacent, not direct. A premised question whose premise the quotes don't carry, so the guidance keeps a branch that lets the premise be false. JD because it scores a hard requirement |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run sales strategy at a B2B SaaS company?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Pause, then do it in 60 seconds. Concede first: "I haven't done classic sales-ops or quota-setting work." Then two facts at scope: "I'm skilled in SQL and Tableau, and I built a partner-level revenue model used in carrier negotiations." Close forward, on what you'd do for Northwind's emerging products. **Hold** through two pushes by returning to those facts. **Concede specifically:** "They'd ramp faster on your quota mechanics. That's real." Don't fold on the core claim to restore harmony | The time-boxed comparison stem, aimed at F7 and F4. Plausible from a direct, data-driven peer even outside a stress round. JD because it scores fit to the listed job |
| E2 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change, and it was credited with roughly $400M in ARR uplift." Return to "proposed" under each push and don't upgrade the verb. Answer slot: who else's work it took, and how the credit was assigned, in your own words. If you don't know, say so plainly. Don't undersell it either. "Proposed" is what you did, and it stands | The attribution stem on F1's headline number. Composure is being scored as much as content. EXP because it is an attribution check |

### G. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc: two years in strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. One headline at its own words: you proposed a store-surface change credited with roughly $400M in ARR uplift. Answer slot: why Northwind, why now, in your own words. Stop at 90 seconds and let him pick the thread. He will probably pull on the number (A1) | Nearly every conversation opens this way, and economy is scored even in a friendly register. EXP because it sets up every claim he will probe next (F1) |
| G2 | "What are you actually doing with AI tools these days?" | JD | [inferred] "uses AI tools daily" | Say what you do, in your own words. Answer slot: if any of it is in your analysis or planning, say what for. If it's general productivity use, say so plainly. Then turn it forward: what you'd want to learn about Compass's users and buyers. Don't present tool use as AI product experience | "AI experience a plus" (F6) asked casually. Plus-skills asked casually are still scored. JD because it scores a listed plus, `[inferred]` because F6 is low confidence |

### H. Values/Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Candidate story: the store-surface proposal. Answer slot: if proposing it meant telling leadership something they didn't want to hear, say what it was, how you raised it, and how it landed, in your own words. If it didn't, pick another time: it needs a named stake, a moment you didn't fold, and a working relationship intact afterwards. If none comes to mind, say so plainly and give the nearest thing your material carries | No Northwind values were in hand, so the theme comes from the persona stem. Truth-telling between peers is also what a seam partner wants to know. VAL because it scores behavior, not capability |
| H2 | "When have you put a customer, or a partner, ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision where an internal number was knowingly traded for a customer or partner outcome. Name the metric, what you chose, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The customer-over-metric stem, adapted with "partner" because the JD requires partner-motion work (F4). VAL because it scores a principle. `[generic]` because no quote carries such a story |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization, with a startup chapter in between. What from pricing work turned out most useful in sales strategy here?" | Tied to his own path (from your message). It turns the interview into a peer conversation and shows you read about *him* |
| R2 | "What could a new person in this seat do in their first month that would genuinely help your team?" | The reciprocity question. A peer is scoring whether you reduce his load or add to it |
| R3 | "Today, who sets targets for emerging products relative to your core plan, and how are the two reconciled?" | It surfaces the real seam before you have to design it, and it shows you take his turf seriously |
| R4 | "When we lose to the bundled platform offer, what does the data say the reason is: price, procurement convenience, or capability?" | It goes to the competitive threat in your research note and asks a data-driven pricing person for data |
| R5 | "Is Compass one of the two product lines this role owns? How is it expected to contribute to the profitability goal?" | It clarifies scope, which the JD highlights don't settle, and links two stated priorities |
| R6 | "Is there a partner motion today, or is this role building it from scratch?" | Partner-motion design is required. The answer tells Priya how much of D3 and C3 is the actual job |

---

## Prohibited claims

None of these claims gets coached. Each is listed with its basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led GTM strategy for a product line | Inflated form of F1 | F1's quotes at their own scope. The pack's observation: the material says strategy and ops work and a proposal, not GTM ownership. The slots in A5 and C3 stay inside that scope |
| Drove, delivered or generated the ~$400M ARR uplift | Inflated form of F1, on the verb axis | "proposed a store-surface change credited with a ~$400M ARR uplift", with "proposed" and "credited" kept |
| Designed a partner motion or ran a partner program | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations". The pack's observation: a model used in negotiations, not the design of a motion or her role in the negotiations |
| Has set quotas or done sales-ops planning, or the volume targets were quotas | Negative stated, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting work." F5 stays "volume targets". No slot |
| Drove or brokered the cross-org consensus | Inflated form of F5 | "set annual volume targets with cross-org consensus", at that scope. It doesn't say who built the consensus |
| Has built or launched AI products | Inflated form of F6 | "uses AI tools daily", at its own scope |

---

## Sources

**Provided documents:** the coach's message, including the role line, JD highlights, candidate background, Dan Kovac's profile summary and the research note on Northwind's priorities and competitive threat. No dossier was present.

**Searches sent:**

- `Northwind Data company values`: refused (permission not granted)
- `Northwind Data interview process GTM strategy`: refused (permission not granted)
- `Dan Kovac Northwind Data sales strategy`: refused (permission not granted)

**Loop:** the coach's words, "a single 60-minute conversation with Dan", establish the loop for this session: one session, run by a named peer. No archetype fallback was needed. That source names no values-style round, so none is detected and there is no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The only call was refused. It would have themed bank H with Northwind's published values by name |
| 2. `Northwind Data interview process` (GTM / strategy) | unavailable | The only call was refused. The loop is already established by your words, but this would have shown whether peer rounds usually include a case or a take-home |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the priorities and the competitive frame that C1, C2, B4, D2, R4 and R5 use. The note's date wasn't given (see upgrade menu) |
| 4. `Dan Kovac Northwind Data` | unavailable | The only call was refused. It would have added his published talks or posts to the interviewer read, and their themes as likely questions |
| 5. Representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied set the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** → targets 1, 2 and 4 run: Northwind's published values for bank H, loop-format norms, and Dan's public talks or posts for the interviewer read and R1.
- **Deeper research pass (L2)** → up to 6 more searches and 2 more fetches, several more minutes: a grounding brief (segment language, financial trajectory, the competitive set) that sharpens C1, C2 and D2, plus recent org context on what this role is really for.
- **The full JD text** → the posting's own words replace the highlights in F1–F6, and any mid-list tool, method or metric gets its own question.
- **Priya's resume** → the evidence cells become her own CV lines, and the scaffolds in B2, H1 and H2 can become story-mapped answers.
- **Priya's own answers to the answer slots** (how the ~$400M was counted and what part was hers, what in the partner model was hers, any enterprise-sales exposure, her reasons for the move) → A1, A2, B3, D1, D2, D3 and E2 go from slots to mapped stories.
- **An inspectable artifact** (a sanitized version of the partner-level revenue model, or a Tableau workbook she built) → F3 and F4 move from medium to high confidence.
- **The date of your research note** → confirms the strategy framing is current, ideally under six months old.
- **Recruiter guidance** → whether Dan's hour includes a case or deliverable, and any stated focus areas. Usually one email.
- **Prep time available** → a prioritized prep-triage schedule at the top of the pack.
- **A tuesday-dossier.md from job-underwriter** → user-verified evidence grades and an evidence-derived objection to rehearse. This pack is complete without one.
