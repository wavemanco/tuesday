Quick update: I've read the prep playbook. Now I'm running a few targeted searches on Saltmarsh Games and Tobias Wrenfield before I build your pack.
I've saved your prep pack as `Saltmarsh-Games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since that's the most likely reading of Tobias's title. My web searches on Saltmarsh and Tobias were refused because web search isn't enabled in this session. So the pack is built only from your message and the job description, and the questions that would need company facts are marked `[generic]`.

- **Your strongest material:** the content calendar you ran and the release checklist you wrote. Both match lines in the job description almost word for word.
- **The question to rehearse most (B1):** "Tell me about a time you got design, art, engineering and community to land one release." Coordinating those teams is a duty the job description names for every update, and your message only says you never led a team. The pack gives you an honest answer that holds up through follow-ups.
- **In-app purchases:** the job description doesn't mention them, but mobile live-ops interviewers often ask. The pack coaches a plain "I haven't worked on a game with in-app purchases," followed by a plan for how you'd learn it.
- **Play both Saltmarsh titles before Friday.** Without research, the pack can't name them for you.

Say the word and I'll play Tobias as the Skeptic on B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias going to be your manager, or is he more senior than that or part of a panel? And did the recruiter mention any focus areas or a task to prepare? The answer changes how every question set is weighted.
If you'd like company and interviewer research, enable web search and tell me. I can also run a deeper pass (up to 6 more searches and 2 more fetches, several more minutes).

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** one 60-minute interview on Friday. The pack treats Tobias as the hiring manager. Your note gives his title but not your relationship to him, so that is an assumption.

## How to use this pack

Personas describe how a question is asked: who is asking and in what style. Types describe what the question is scoring. A question can arrive as a friendly aside or as a hard challenge and still be scored against the same type.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows a value, by a specific decision you made |
| EXP | Whether the claims about your experience hold up, and what was actually yours |
| JD | Whether you can do the listed job, including the parts you have not done |
| CO | Your homework on the company: its titles, strategy and recent moves |
| CASE | How you structure and reason through a live problem from the role |

The guidance is scaffolding, not a script. Say it in your own words. Wherever a cell gives an **answer slot**, the pack does not know the answer. Fill it from what actually happened, or say plainly that it did not happen.

Question IDs run by persona: A to E, then G and H. The letter F is kept for the fit-snapshot rows (F1 to F9).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a weekly content-drop calendar for one title, not a live-events calendar for two, and your words should stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's lines on live events and two titles make two probes likely. One is whether any of your drops were time-limited events. The other is whether you planned across more than one title. If either was true, say which and how, in your own words. If neither was, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | Your material does not show whether you coordinated these disciplines. Your message speaks only to leading a team, and coordinating is a different thing. If leadership comes up, the words are: "I haven't led a team." Answer slot: the JD's coordination line makes a probe likely on releases that needed design, art, engineering and community to land together. If you coordinated any, pick one and say what part was yours, in your own words. If you did not, say so plainly and say how you would run one |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is not owning a post-event review, so the words stay at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe likely on whether you ever reviewed a single drop after it ran. If you did, say what you looked at and what came of it, in your own words. If you did not, say so plainly and stay with the monthly numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | There is no gap here, but nothing has been inspected behind the line, so expect a probe. Lead with the checklist in the quote's own terms: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran it with QA release by release, say how, in your own words. If you did not, say so and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [inferred] | discovery | Four years clears the length. Your material does not say whether the puzzle title was run as a live service. Words: "I spent 4 years as an associate producer at a puzzle-game studio." Answer slot: if the title was run as a live service, say in your own words what that meant day to day. If it was not, say so plainly and stay with the weekly content-drop calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | There is no gap. This is your strongest line, so say it whole: "I ran the weekly content-drop calendar for our main title for the last two years." Expect to be asked how. Tell it in your own words, using only what you actually did |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement in its own terms, and the prober will test it. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's retention line makes a probe likely on which measures were in those numbers and how they were counted. Say so in your own words. If someone else produced them, or you don't know how they were counted, say that plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist that QA still uses is a written document in use. The material does not show how it reads. Words: "I wrote the release checklist our QA team still uses." Answer slot: expect a request for other examples of your writing. If you have any, name them in your own words. If you don't, say so and stay with the checklist |
| F9 | Mobile live-events work often involves in-app purchase offers and event revenue. This is a common pattern for the role, not a line in this JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | The JD does not ask for this. It is listed because it often comes up in mobile live ops, and you have stated the gap yourself. Words: "I haven't worked on a game with in-app purchases." Then say how you would learn it, as a plan and never as a past. Add nothing to make the gap feel smaller |

## Persona table

The weights start from a hiring-manager round, because a Head of Live Operations interviewing for a Live Operations Producer is most likely the role's manager. Nothing else about Tobias was available: web search was refused (see Sources), so no interviewer signals adjust these weights. Your own words establish the round as a single 60-minute session with him, so the weights are not based on an archetype fallback.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the JD: plan a two-title calendar, diagnose a weak event, rescue a slipping update | High. Hiring managers test capability against the work they are hiring for, and 60 minutes leaves room for one or two cases | Clarify first, then state the objective, the segments, the approach, the metrics and the risks, in that order. Think aloud and challenge one premise per case |
| Skeptic | Quiet probing of the gaps: F2 coordination, F9 in-app purchases, F1 one title against two, F5 live service | High. The gaps in the fit snapshot are exactly what a hiring manager needs to de-risk | Rehearse B1 until it bores you. Bridge only from your quoted lines, say the limit plainly, and give a concrete ramp plan |
| Data-Driven Prober | Pushes on the retention numbers and the checklist: what was in them, how they were counted, what came of them | Medium. The JD names retention metrics and KPIs, and F3, F4 and F7 are the claims you will lead with | Know what you can and can't say about how the numbers were counted. Name your weakest assumption before he does |
| Conversational / Rapport | A friendly opener ("walk me through your journey"), what you are playing, why Saltmarsh | Medium. Almost every 60-minute hiring-manager round opens and closes in this register, and it is still scored | Have a 90-second arc ready (D1). Treat the casual questions as scored, and never waste the reverse-question slot |
| Pressure | Time-boxed challenges on the gaps: "why you over someone who has done this already" | Low. Nothing points to a stress format, but the gaps invite it | Pause, restate, and anchor in what you actually said. Hold through two follow-ups, then concede the specific limit |
| Peer Evaluator | Seam questions between the producer and design, art, engineering and community | Low. Tobias is not a peer, but the JD's coordination line makes him likely to ask how you would work across those teams | Propose working principles for the seams rather than pretending to know Saltmarsh's teams |
| Values / Behavioural | A "tell me about a time" or two | Low. No values round is detected (see Sources), but behavioural prompts turn up in most rounds | Pick stories from what actually happened. "We" for context, "I" for your part |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're running the live-events calendar for two titles. Sketch next quarter's plan. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first. Ask what each title's goal is for the quarter, the team capacity per discipline, fixed dates such as platform features and seasonal moments, and how the two audiences differ. Then structure it: a shared cadence or separate ones, how to avoid both titles peaking on the same week, buffers before each update, and which KPI each event is meant to move. Where your experience applies, keep it at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Let him draw the comparison himself | This is the JD's headline duty asked as a live problem, and F1 is where your evidence is one title rather than two. CASE delivery on JD content |
| A2 | "An event just ended and retention among participants is down on the last one. Diagnose it." | CASE | [generic] | Clarify the measure and the comparison first: the same cohort and window, and whether something else changed such as an update, a store feature or a calendar clash. Split it: did fewer players join, did joiners drop out mid-event, or did they churn after it? Then name the data you would pull for each split and the one hypothesis you would test first. Close with what the post-event review would record. The question needs no claim about your past, so the guidance makes none | It tests the JD's KPI and post-event-review line (F3, F7) as a reasoning task. `[generic]` because it is a diagnostic pattern, not a fact about Saltmarsh |
| A3 | "Two days before an update, engineering says the event's feature won't make it. Art has finished assets and community has drafted the announcement. What do you do?" | CASE | [generic] | Get the facts first: what exactly slips, by how long, and what still works. Lay out the options: ship the event without the feature, slip the date, or swap in other content. Judge each against player impact and team cost. Say who you would bring into the decision, and who makes the call if it isn't you. Tell community before players notice anything, and protect the art work for later reuse. Afterwards, record the cause for the post-event review. The question needs no claim about your past | This is the JD's coordination line (F2's requirement) as a decision. Hiring managers use slip scenarios to see whether a producer brings options and a recommendation rather than just reporting the problem |
| A4 | "What goes into a good post-event review? What would yours contain?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure it: the event's goal and its KPI target, the results against that target, what went well, what slipped and why, player and community feedback, and the actions with owners. Keep your experience at its scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you ever reviewed a single drop after it ran, say what you looked at, in your own words. If not, say so plainly and present this as how you would build one | F3 is a transferability row: presenting monthly numbers is a different thing from owning an event review. JD-tagged because ownership of the review is a stated duty |
| A5 | "You can track only three KPIs for a live event. Which three, and why?" | CASE | [generic] | Pick three that cover the funnel: participation (the share of active players who engage), progression or completion (how far they get), and retention after the event against a control or the last event. Say why each one matters and what you would give up by not tracking the others. If the event has a revenue side, say plainly that you would want to learn how Saltmarsh measures it. No claim about your past | It tests "own the KPIs it reports" and "comfortable with player-retention metrics" (F3, F7) by asking for a judgement. The revenue note keeps F9 honest without volunteering a claim |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates design, art, engineering and community on every update. Tell me about a time you got several disciplines to land one release." | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | **The highest-ROI prep in this pack.** Answer slot: if there were releases where you got several disciplines working to one date, pick one. Say what the release was, who was involved and what part was yours, in your own words. If there were none, say so plainly. Then give what your material does carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses." Follow with how you would run coordination here. The likely follow-up is "so you haven't led a team?" Answer: "I haven't led a team." Do not argue that coordinating is leading. Go back to the calendar and the checklist. Hold through two follow-ups by repeating what you did, never by adding to it | F2 is the widest gap against a duty the JD names for every update, so this objection will come in some form. JD-tagged because it scores a stated requirement head-on |
| B2 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Answer plainly and early: "I haven't worked on a game with in-app purchases." Don't apologise and don't hedge. Then give a ramp plan, said as a plan: how the team measures event revenue, which recent events you would study, and who you would sit with. Keep it to about 30 seconds and don't over-defend | F9 is a gap you stated yourself. Mobile live ops often has a revenue side, so expect the question. Tagged JD because it tests readiness for the role as a hiring manager sees it, even though this JD does not list it |
| B3 | "You've been an associate producer. Why are you ready to run the calendar for two titles?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Describe what you did and let him draw the conclusion: "I ran the weekly content-drop calendar for our main title for the last two years." Add that you wrote the release checklist your QA team still uses, and that you presented the monthly retention numbers to the studio head. Don't call any of it proof of readiness. Answer slot: if you have planned across more than one title, say how, in your own words. If you haven't, say so plainly and say what you would do in your first month to learn the second title | F1 and F5 frame the jump in title and scope. A Skeptic asks this to see whether you inflate your scope or describe it accurately |
| B4 | "Was your puzzle title run as a live-service game?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if it was run as a live service, say what that meant day to day, in your own words. If it was not, say so plainly and stay with what you did: "I ran the weekly content-drop calendar for our main title for the last two years." Don't call weekly drops "live ops" unless that is what your studio called them | F5 is the JD's "3+ years producing live-service games" line, and your material does not settle it. Rehearsing it stops you sliding into the JD's vocabulary |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Name a real weakness. Your message supplies one: "I haven't worked on a game with in-app purchases." Then give the ramp plan from B2. Don't pick a fake weakness or a disguised strength. Close with the duty you are surest of, in the quote's terms from F6 | This is the classic Skeptic stem, and it tests self-assessment. F9 is a stated gap, so the honest answer is already prepared |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers. Which measures were in them, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start with what the quote carries: you presented them to the studio head each month. Answer slot: say which retention measures were in them and how they were counted, in your own words. If someone else produced them, say who and that you presented them. If you don't know how they were counted, say "I don't know how they were counted." Name the assumption behind the numbers you would defend least before he does | F7 is the claim you will lead with on metrics, and a prober asks for the definitions. EXP because it tests what was yours |
| C2 | "Did those retention numbers ever change what went into the content calendar?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if a month's numbers changed what went on the calendar, say what changed and what part of the decision was yours, in your own words. If they never did, or the call was not yours, say so plainly and stay with what you did: you presented the numbers and ran the calendar | This links F3 and F6: the JD wants KPIs that feed decisions. The question allows that the link never existed, and the guidance does too |
| C3 | "Your release checklist — what's on it, and how do you know it works?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: say what is on the checklist and why each part is there, in your own words. On "how do you know it works": the quote carries that your QA team still uses it, so say that. If you tracked whether it caught problems, say how. If not, say so plainly rather than inventing a result | F4 is a concrete artifact and the obvious place to probe. A redacted copy would raise its confidence (see the upgrade menu) |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built from your four lines, in order. Four years as an associate producer at a puzzle-game studio. You ran the weekly content-drop calendar for the main title for the last two years. You wrote the release checklist your QA team still uses. You presented the monthly retention numbers to the studio head. Close with why live ops is the next step, in your own words. Use "associate producer", never a bigger title | Most 60-minute rounds open here, and it sets the frame for everything after. Every beat is one of your quoted lines |
| D2 | "What mobile live-ops games are you playing right now? Tell me about an event you thought was well run." | CO | [generic] | Selection scaffold: pick a game you have actually played recently and an event you took part in. Say what its goal seemed to be, what made it work, and one thing you would change. If you haven't played one recently, say so plainly and talk about an event you watched closely. Play both Saltmarsh titles before Friday so you can speak to them | This is the casual-register test of genuine interest, and it is scored. `[generic]` because research failed, so this pack cannot name the titles |
| D3 | "Why Saltmarsh, and why live ops?" | CO | [generic] | Selection scaffold: build it from things you actually know about Saltmarsh's two titles, from playing them, and from what drew you to the work. Don't invent facts about the company. If you know little beyond the posting, say what you have played and what you want to learn | It is a motivation check, and without research the pack has no company facts to offer you. The upgrade menu says how to fix that |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause and accept the premise plainly: "I haven't worked on a game with in-app purchases." Then hold on what is yours: you ran the weekly content-drop calendar for your main title for the last two years, and you wrote the release checklist your QA team still uses. Then give the ramp plan from B2. If he pushes twice, concede the specific limit, the revenue side, and don't fold on the calendar | This is F9 under time pressure. It tests hold-then-concede more than content |
| E2 | "That retention presentation — how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold on the quote: you presented them. Answer slot: say which part was yours and which part others produced, in your own words. If you presented numbers someone else built, say so plainly. That answer is credible, not weak | This is an attribution probe on F7. Rehearsing the precise answer makes the honest version easy to say |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community wants to announce the event date early, but engineering won't commit. How do you handle it?" | CASE | [generic] | Propose principles rather than claiming to know Saltmarsh's teams. Find out what engineering needs before it can commit and when it could. Agree an announcement window rather than a date. Give community a fallback message. Make the trade-off visible to whoever owns the call. No claim about your past | It is the JD's coordination line again (F2's requirement), this time at the seam between teams. It is also a way to show how you would handle B1's gap in practice |
| G2 | "When an update goes well, how do you handle credit across design, art, engineering and community?" | JD | [generic] | Selection scaffold: pick a time you shared credit for work that spanned people. Say what happened and what you did. If none comes to mind, say so plainly and describe how you would do it: name each discipline's contribution in the post-event review and in the team channel | It scores partnership fit on the JD's coordination duty. `[generic]` because your material carries no story for it |

### H. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you had to deliver an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if a month's retention numbers were bad news you had to present to the studio head, say what you presented and how, in your own words. If there was no such month, say so plainly, then give the nearest real instance you have, or how you would handle it | This is a common behavioural stem. F7 is the only place in your material where you report to leadership, so the pack checks it before anywhere else |
| H2 | "Tell me about something you wrote that another team relied on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F8: you wrote the release checklist, and your QA team still uses it. Tell it in your own words. Answer slot: if you know what made it usable, such as how it was structured or how you tested it with QA, say so. If not, stay with the fact that it is still in use | This covers the JD's "clear written communication" line (F8) with the one written artifact your material names |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A1, B3 |
| Coordinate design, art, engineering and community on each update | B1, A3, G1, G2 |
| Own the post-event review and the KPIs it reports | A4, A2, A5, C2 |
| Manage the release checklist with QA | C3 |
| 3+ years producing live-service games or apps | B4 |
| Experience running a content calendar | A1, C2, D1 |
| Comfortable with player-retention metrics | C1, E2, A5 |
| Clear written communication | H2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a post-event review look like here today, and who reads it?" | It goes straight to a duty you would own, and the answer tells you what the KPI bar is |
| R2 | "Do the two titles share one live-events calendar or run separate ones, and where do they clash?" | It shows you are already thinking about the two-title problem in A1, and the answer is useful to you |
| R3 | "Where do updates most often get stuck between design, art, engineering and community?" | It invites him to describe the real coordination problem, and it is your chance to show how you would handle it (B1) |
| R4 | "Which KPI do you care about most when an event wraps?" | It is short, it reveals his priorities, and it gives you a hook back to C1 |
| R5 | "Do events on these titles carry revenue goals, and how is that side owned today?" | It addresses F9 openly as diligence rather than defence, and you need the answer before accepting |
| R6 | "What would a strong first 90 days look like in this role?" | It shows you are thinking past the offer, and it tells you how he will measure you |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events, or a live-events calendar | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material describes a weekly content-drop calendar, not live events. The slots in A1 and B4 stay inside that calendar |
| Planned calendars across multiple titles | Inflated form of F1 | F1's quote: "our main title". The slot in F1 asks only whether planning crossed titles, with a branch for no |
| Owned post-event reviews or the retention KPIs | Inflated form of F3 and F7 | The quote at its own scope: "Presented the monthly retention numbers to the studio head." The slots in A4, C1 and E2 ask only what was yours |
| Managed releases or the QA process | Inflated form of F4 | The quote at its own scope: "Wrote the release checklist our QA team still uses." |
| Four years of live-service production | Inflated form of F5 | The quote at its own scope: "4 years as an associate producer at a puzzle-game studio." The slot in B4 decides whether "live service" applies |
| Producer or senior producer title | Inflated form of F5's quote | "associate producer", as you wrote it |
| Has led a team | A negative you stated, F2 | "I haven't led a team." No slot |
| Has worked on in-app purchases, monetisation or event revenue | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." Then a ramp plan, said as a plan. No slot |

## Sources

**Provided documents:** the job description and your background, both pasted in your message.

**Searches sent** (all four were refused, because web search permission was not granted in this session):

- `Saltmarsh Games values`: refused
- `Saltmarsh Games interview process producer`: refused
- `Saltmarsh Games mobile studio news 2026`: refused
- `Tobias Wrenfield Saltmarsh Games`: refused

No fetches were sent.

**Loop:** your own words establish one 60-minute session with Tobias Wrenfield. No source names a values-style round, so none is detected and there is no values cheat sheet.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Refused. It could have themed VAL questions with Saltmarsh's published values. The H bank uses generic stems instead |
| 2. `Saltmarsh Games interview process` | unavailable | Refused. It could have shown whether other rounds follow, including a values round. Your own words still establish this session |
| 3. `Saltmarsh Games` strategy and recent news | unavailable | Refused. It would have grounded D2, D3 and a strategy CASE question in Saltmarsh's titles and recent moves. Those questions are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Refused. It would have supplied an interviewer read, adjusted the persona weights, and tied a reverse question to his career path |
| 5. Representative Live Operations Producer JD | skipped | You supplied the JD, which already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirm your relationship to Tobias (future manager or not) → the persona weights are confirmed or recomputed, and banks are reweighted if he is a skip-level or a panel lead
- Allow web search in this session → targets 1 to 4 run: Saltmarsh's values, its interview loop, the two titles and recent news, and Tobias's public professional footprint. D2 and D3 would become `[grounded]`, an interviewer read would be added, and R-questions would be tailored to him
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief on Saltmarsh's titles, deeper material on Tobias's talks or writing, and reports on the interview loop. Only on your say-so, and only once search is allowed
- The names of the two titles you would be working on → A1, D2 and D3 can be written around them
- Any recruiter or HR prep email → coverage of declared focus areas, and a build section for any pre-declared exercise or presentation
- Your CV → more quoted lines, which could turn the answer slots in B1, B4 and G2 into story-mapped guidance
- A redacted copy of your release checklist → raises F4 and F8 from an unseen line to an inspected artifact, and C3 and H2 can quote it
- A sample of the retention deck you presented → raises F3 and F7, and C1 and E2 gain real definitions
- Your answers, outside a drill, to the slots on coordination (F2), live service (F5) and retention measures (F7) → those rows, plus B1, B4 and C1, become story-mapped
- How many hours you have before Friday → a prioritised prep schedule at the top of the pack
- A tuesday-dossier.md from an underwriting pass on this role → an evidence-derived top objection and a confirmed prohibited list. This pack is complete without one
