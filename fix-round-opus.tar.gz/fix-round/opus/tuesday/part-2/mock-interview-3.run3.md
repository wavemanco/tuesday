Quick update: I've read the prep playbook. Next I'm researching Stripe's published principles, how its interviews are run, and a sample Product Ops JD, then I'll build your pack.
I've built your prep pack for the Stripe final round. It's generic for now: I had no job description, résumé or interviewer names, and the web searches I tried (Stripe's principles, its interview process, a sample job description, recent strategy) were blocked by your permission settings. So the pack says nothing specific about Stripe or about your background. Where your own stories should go, it tells you how to pick one instead.

**What's in it**
- **22 practice questions** across seven interviewer styles. The heaviest are live operations problems (launch readiness, finding why a metric dropped, sorting out competing priorities) and "tell me about a time" questions.
- **The question to practise first** is "Which part of this role would you be weakest at on day one?" It can come up in any final round, and since I can't see your résumé, you're the one who has to pick the honest answer ahead of time.
- **A self-assessment worksheet** covering seven common Product Ops requirements. Each row says what strong evidence looks like and how to choose the story you'd tell.
- **Six questions for you to ask them**, each with a note on why it works.
- **Interviewer mix:** I don't know how many sessions your final has or who runs them, so I weighted them on how large tech companies usually run finals. That's my assumption, not Stripe's documented process.

Files are in `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-3-denied-3ee6ac3c/`:
- Stripe_product-operations-manager_interview_pack.md

If you like, I'll play the skeptical interviewer and ask you the day-one weakness question live, with follow-ups.
I can also save a `tuesday-dossier.md` file that records the gaps this prep turns up, so you can carry it into later sessions.
I can convert the pack to a Word document too.

1. How many sessions does your final have, and is each one with your future manager, a peer, a skip-level or someone from another team? Did the recruiter mention focus areas or anything to prepare, like a case or a presentation?
2. Can you paste the job description and your résumé? If you'd rather not, I'll keep improving the generic version.
3. Do you want me to run the web searches? It would be up to 6 searches and 2 page reads, so the principles, process and strategy parts come from Stripe's own pages rather than general patterns.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview pack: Product Operations Manager, Stripe (final round)

Interviewer: not named. Relationship: not stated. Built for a final round of unknown shape, with persona weights blended across the sessions a final usually holds.

## How to use this pack

Personas describe **how** a question is asked. Types describe **what** is being scored. Each question has both.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's published values, not generic virtue |
| EXP | Whether your claims hold up under scrutiny, and what was actually you |
| JD | Whether you can do the job as listed, gaps included |
| CO | Homework depth: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to something you gave me or research cited in Sources. `[inferred]` is a named derivation. `[generic]` is a role-family pattern that says nothing specific about Stripe or about you.

**Read this first.** I had no job description, no résumé and no research for this pack: the web searches were blocked (see Sources). So every requirement below is a role-family pattern, every row about your past is a **selection scaffold** (how to pick your own story), and nothing in the pack says anything about Stripe's values, process or strategy. The guidance is scaffolding, not a script. Fill it with what you actually did.

## Fit snapshot (self-assessment worksheet)

With no résumé, this is a worksheet. For each row, pick the story you would tell, and check it against the "strong evidence" bar.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running launch readiness across functions: getting product, support, sales, legal and others ready for a launch (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is one launch where you can name the functions involved, what "ready" meant, and what you personally ran. Pick a launch you coordinated across at least two teams. It needs a deadline, a moment where something was not ready, and what you did about it. If no such launch comes to mind, say so plainly, then give the nearest thing your work does carry, or how you would run one |
| F2 | Building feedback loops that bring customer and field-team input to product teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a channel you set up or ran, and one product decision you can trace back to it. Pick a time feedback you collected reached a product team and changed something. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would build the loop |
| F3 | Defining and tracking operational metrics, with enough data fluency to pull and question numbers yourself (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a metric you defined or tracked, how it was counted, and what it changed. Pick one figure you can explain end to end, including the assumption you would defend least. If you can't explain how a figure was counted, say so rather than guess. If no such figure comes to mind, say so plainly and describe how you would set one up |
| F4 | Influencing teams you don't manage (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a named disagreement with a team that didn't report to you, what you did, and how it ended, relationship included. Pick a time you moved a team without authority over it. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would approach it |
| F5 | Designing processes and scaling them: programs, documentation, tooling (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a process you built or changed, who used it, and what happened after. Pick one you can describe before and after. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would design one |
| F6 | Prioritising and explaining trade-offs to leadership (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a time you recommended what not to do, and how leadership responded. Pick a trade-off you put in front of someone senior. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would frame one |
| F7 | Clear written communication: briefs, launch docs, decision memos (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a document you wrote that a decision or launch relied on. Pick one you could describe section by section. If none comes to mind, say so plainly and describe how you would write one |

No row here is a hard gate. Location, work authorisation and similar terms aren't in your material. If your JD lists one, it will appear when you add the JD.

## Persona table

No source tells me how your final is structured. "Final round" alone doesn't say how many sessions it has or who runs them. So the weights below rest on the **big-tech structured archetype**: a pattern I chose because Stripe is a large tech employer. It is not Stripe's documented process. The archetype tilts toward Values/Behavioral and Case, and because the sessions are unknown, the other personas are blended in.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live operations problems: plan a launch, diagnose a drop, sequence competing asks | High. The archetype tilts Case up, and a manager in a final usually tests whether you can do the job live | Clarify, then objective, segments, approach, metrics, risks. Think aloud, and challenge one premise politely per case |
| Values / Behavioral (bank B) | "Tell me about a time…" scenarios, STAR-shaped, often from someone outside the function | High. The archetype puts a values-style round somewhere in the loop | Prepare one real story per theme, with "we" for the context and "I" for your part. Where you have no story, say so instead of building one |
| Skeptic (bank C) | Quiet probing of fit and motivation: why this role, why now, where you'd be weakest | Medium. Finals often include someone whose job is to find the gap | Rehearse the weakest-area answer until it's boring. Bridge only from work you actually did, and give a concrete plan for learning the rest |
| Data-Driven Prober (bank D) | Asks how a number was counted, what it depends on, and which assumption is weakest | Medium. Product Ops usually owns metrics, so expect someone to test your numbers | For every number on your résumé, know how it was counted, or say plainly that you don't know. Name your weakest assumption before they do |
| Peer Evaluator (bank E) | Seams between teams, "what would you need from me", who gets the credit | Medium. Ops roles sit between teams, and a peer interview is common in a final | Lead with what you'd bring their team. Propose principles for the seam rather than pretending to know it |
| Pressure (bank F) | Interruptions, time limits, "how much of that was actually you" | Low to medium. It isn't a typical archetype round, but any session can turn this way | Pause and restate the question. Hold your position through two follow-ups, then concede anything uncertain specifically |
| Conversational (bank G) | Friendly openers, the career-journey question, the "any questions?" slot | Low to medium. It appears at the start of most sessions and is still scored | Have a 90-second career arc ready. Treat casual questions as scored |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're launching a new product feature in several countries on the same date. Sketch the readiness plan. What do you need to know first?" | CASE | [generic] | Clarify first: what "launched" means, which countries, and which teams have to be ready. Then structure: a readiness checklist by function, one owner per item, a go/no-go review before the date, and a plan for a country that isn't ready. End with how you'd know it went well, such as support volume or adoption in week one. No claim about your past is needed, so make none | F1's requirement asked as a live problem. CASE because it scores structure, and the question presupposes nothing about you |
| A2 | "Adoption of a feature we launched last month dropped 20% week over week. Diagnose it." | CASE | [generic] | First ask how adoption is counted and whether the drop is real: a tracking change, seasonality, one big customer. Then segment by country, customer size and channel. Form a hypothesis and say how you'd test it. Close with who you'd bring in, and what you'd tell leadership today before you know the answer | F3's requirement in live form, using the Case persona's stem. It tests whether you question the number before explaining it |
| A3 | "Design how feedback from sales and support reaches product teams, and how we'd know it was acted on." | CASE | [generic] | Cover intake (where feedback comes from), triage (how it's deduplicated and sized), routing (who owns each theme), the loop back (telling the source what happened), and a metric that shows the loop works. Name one way it fails, such as loudest-customer bias, and how you'd guard against it | F2's requirement as a design problem. CASE because the scoring is the system's structure |
| A4 | "Three product teams each say their launch is the top priority for the same month, and support can only absorb one. How do you sequence?" | CASE | [generic] | Clarify the goal and what "absorb" means. Set criteria aloud, such as customer impact, risk, dependencies and reversibility. Score the three against them, recommend one order, and say what you'd tell the two teams that wait. A clear recommendation with stated trade-offs beats a framework without an answer | F6's requirement as a live trade-off. It shows whether you'll make a call |
| A5 | "A launch-review process everyone relies on is now slowing launches down. How do you decide whether to fix it or kill it?" | CASE | [generic] | Ask what the process protects against and how often it actually catches something. Measure its cost in time and its benefit in issues caught. Options: keep it, slim it down, make it risk-tiered, or remove it. Say how you'd test the change on a few launches before rolling it out | F5's requirement as a decision. CASE because it scores reasoning about process design rather than a past |

### B. Values / Behavioral

Stripe's published values weren't in hand (the search was blocked), so these themes come from standard behavioral prompts, not from Stripe's own principles.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they didn't want to hear. It needs a named stake, the moment you said it, and what happened next. Choose one where the truth actually landed. Use "we" for context and "I" for what you said and did. If no such time comes to mind, say so plainly, then give the nearest thing your work does carry, or how you would handle it | The archetype puts a values-style round in the loop, and this theme is the most common behavioral stem. VAL because it scores behaviour, not skill |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a metric pointed one way and the customer's interest pointed another. Say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your work carries, or how you would decide | Product Ops sits between customer signal and internal targets, so this tension is likely. VAL because it tests a value under trade-off |
| B3 | "Tell me about a time you disagreed with a peer on another team. How did it end?" | VAL | [generic] | Pick a disagreement with someone you didn't manage. It needs the substance of the disagreement, what you did, and the relationship afterwards. Show firmness and tact together. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would handle it | F4's requirement, asked behaviorally. VAL primary, EXP secondary, because it scores conduct as well as what happened |
| B4 | "Tell me about a time data you brought changed a decision someone senior had already made." | VAL | [generic] | Pick a time your analysis or evidence reversed or reshaped a decision that had already been made. It needs the original decision, what you brought, and the outcome, including if it only partly changed. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would approach it | A variant of B1 that tests F3 and F6 together. VAL because the courage to push back is what's scored |

### C. Skeptic

**C1 is the highest-ROI prep in this pack.** It's the one objection every final round can raise, and without your résumé I can't see your biggest gap, so you have to name it yourself, in advance.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick the one requirement from F1 to F7 (or the real JD) where your story is thinnest. Name it in one sentence, in your own words, before softening it. Then give the nearest thing you have actually done and a concrete 30/60/90-day plan to close it. Hold through two follow-ups by going back to that plan. Don't add experience you don't have, and don't swap in a fake weakness. If the follow-up is "so you've never done X?", answer only what's true | The Skeptic's core stem, and where a final most often lands. JD because it scores self-assessment against the listed job. The deepest rehearsal, because it's aimed exactly where your material is thinnest |
| C2 | "Why leave where you are, why Stripe, and why now?" | JD | [generic] | Three short beats, consistent with each other. Build the "why Stripe" from things you have read on Stripe's own site, not general praise. If you haven't read anything specific, say what draws you to the role rather than inventing a company fact | Motivation consistency is what the Skeptic scores. JD because it tests fit for this role, CO as a secondary type |
| C3 | "Why Product Operations rather than product management?" | JD | [generic] | Say what you want to do more of: systems, launches, the operating rhythm, or whatever is true for you. Don't frame Ops as a step toward PM unless that's honestly your plan, because the interviewer may hear it as a flight risk | A common seam for this title. It checks whether you understand the role you're interviewing for |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Take one number on your résumé and walk me through how it was counted." | EXP | [generic] | Pick your headline figure. Say how it was counted, what it depends on, and which part was yours, all in your own words. If you don't know how it was counted, say so plainly, which is better than a method you can't defend. If your résumé carries no figure, say so and describe the metric you tracked most closely | The Prober's core stem. Every headline number gets this question. EXP because it tests attribution and precision |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption yourself, in your own words, before they do. It turns a gotcha into credibility. If you don't know the assumptions, say so and say what you'd check | The follow-up to D1, always paired with it. EXP because it scores honesty about your own evidence |
| D3 | "A team tells you launch-readiness scores improved 30% after a new process. What would you ask before believing it?" | CASE | [generic] | Ask how the score is defined, whether the definition changed, the baseline period, sample size, what else changed at the same time, and whether outcomes like incidents and support tickets moved too. Name the one question you'd ask first and why | F3's requirement as a live sceptic's problem. CASE because it presupposes nothing about you |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their team. Propose principles: one owner per decision, a clear escalation path, and written agreements on handoffs. Then say how you'd raise a disagreement, early, privately, with data. If you have a real story about a seam, use it; if not, keep to principles | The Peer stem, asked as a live problem. It scores partnership fit |
| E2 | "What would you need from my team in your first month?" | CASE | [generic] | Lead with reciprocity: what you'd bring them before what you'd ask. Then make one or two concrete asks, such as a walkthrough of their launch calendar or a named contact. Keep it short | Peer interviewers price the hire's cost to their own team. It tests whether you'd lighten or add to their load |
| E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a project shared across teams and say how credit was handled and what your part was. Use "we" for the project and "I" for your part. If none comes to mind, say so plainly and describe how you would handle it | The Peer stem on credit. VAL because it scores conduct, EXP secondary |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give two or three beats only: something you'd bring that an insider might not, said only if your work carries it, and how quickly you'd ramp. Don't run long and don't attack insiders. If the honest answer is that an insider knows the systems better, concede it and say what you'd offer instead | The Pressure stem. It scores composure under a time limit. JD because it's fit for this role |
| F2 | "That result you just described — how much of it was actually you?" | EXP | [generic] | Hold what's true: say exactly which part was yours, in your own words. Concede the team's part without shrinking your own. Hold through two follow-ups, and if the honest answer is "less than it sounded", say that plainly. That's the point of rehearsing it | The Pressure stem on attribution. It can follow any story from banks B to E. EXP because it scores attribution honesty |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, two or three turns, and why this role is the next logical step. Each turn should be something you can expand on if asked. Rehearse it aloud and time it | The Conversational stem, and it opens most sessions. EXP because it's the frame every later question hangs on |
| G2 | "What's something in operations tooling or automation you've been playing with lately?" | EXP | [generic] | Name something you have actually used or tried, and what you learned from it. If nothing comes to mind, say so plainly and name what you'd like to explore and why. A casual-sounding question that is still scored | The Conversational stem on hot topics, themed to ops tooling since there's no JD. It checks genuine interest |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness across functions | A1, C1 |
| F2 Feedback loops to product | A3 |
| F3 Operational metrics and data fluency | A2, D1, D2, D3, B4 |
| F4 Influence without authority | B3, E1 |
| F5 Process design and scaling | A5 |
| F6 Prioritisation and trade-offs to leadership | A4, B4 |
| F7 Written communication | none, because a written-communication skill is usually shown in a work sample or take-home, not asked as a question. If your recruiter mentions a written exercise, it gets its own section |

## Reverse questions

Role-generic, because no interviewer was named.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make the first six months in this role a clear success, in your eyes?" | It gets their actual scorecard and shows you're thinking about outcomes |
| R2 | "Where does Product Ops sit relative to product and engineering here, and where's the seam you most want this hire to fix?" | It shows you understand the role is about seams, and the answer tells you what the job really is |
| R3 | "What's a launch that went less well than you'd hoped, and what changed afterwards?" | It invites a real story and shows you'll learn from misses rather than hide them |
| R4 | "How does this team decide what not to do?" | It signals judgement about prioritisation, the core of the role |
| R5 | "What do the teams you support ask Product Ops for most, and what do they need most? Are those the same?" | It shows you'll listen to internal customers, and the gap is where the role adds value |
| R6 | "Is there anything in my background you'd like me to say more about before we finish?" | It gives you a last chance to answer an unspoken objection while you're still in the room |

## Prohibited claims

No entries. I can only list a claim once I hold a sentence of yours that it would stretch, or a gap you've told me about, and I hold neither. That's not a clean bill of health: when you add your résumé, any lines that could be inflated under pressure will be listed here, with the honest form of each.

## Sources

Provided: your message ("Final-round interview at Stripe for a Product Operations Manager role"). No dossier was present.

Searches sent:

- `Stripe operating principles`: refused
- `Stripe interview process final round onsite operations`: refused
- `Stripe "Product Operations Manager" job description`: refused
- `Stripe 2026 strategy news annual letter`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values / operating principles | unavailable | Refused. It would have enabled a values cheat sheet with Stripe's principles by their official names, and themed bank B on them |
| 2. Stripe interview process for operations roles | unavailable | Refused. It would have replaced the archetype fallback with Stripe's named rounds and set the persona weights from them |
| 3. Stripe strategy / recent news | unavailable | Refused. It would have grounded at least one CO or CASE question in Stripe's current priorities, and supplied material for C2 |
| 4. Interviewer name at Stripe | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Refused. It would have turned F1 to F7 from `[generic]` patterns into quoted `[inferred]` requirements |

## Upgrade menu

- Your résumé → the worksheet becomes a real fit snapshot. The scaffolds in F1 to F7 and banks B to G become stories mapped to your own lines, D1 and D2 target your actual numbers, and the prohibited list gets its entries
- The job description → F1 to F7 become `[grounded]` quoted requirements, any listed requirement this pack missed gets a question, and C1 targets the real list
- Who runs each session of your final (manager, peer, skip-level, cross-functional) → persona weights from your actual loop, and a mini-pack per session if there are several
- The recruiter's prep email → coverage of any announced case, presentation or written exercise as a graded deliverable section, plus the focus areas they named
- Interviewer names → a reading of their public professional profiles, retuned persona weights, and a reverse question tied to their own career path
- Web research allowed (up to 6 searches and 2 page fetches) → Stripe's published principles as a values cheat sheet, its documented interview process, and a strategy-grounded CO question
- A deeper research pass after that (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief with recent org context and loop reports from other candidates, for stronger CO and CASE questions
- A tuesday-dossier.md from an earlier job-underwriter session → verified evidence, a named top objection, and claims to avoid; useful, never required
