Quick update: I've read the prep playbook. Next I'm running a few targeted searches on Kelverton Rail and the panel, then I'll build your pack.
Web search was refused, so I'm building the pack only from your message and the recruiter's email. Anything about Kelverton itself is labelled generic.
I've built your prep pack: **KelvertonRail_senior-partnerships-manager_interview_pack.md**, in the working folder.

It's built around the panel as the recruiter described it. Deepa is weighted as your future manager (strategy cases and probing on gaps) and Ross as the commercial pressure. It includes a build section for the 15-minute POV that ends on what it means for the operators themselves, and a four-hour plan for your weekend.

**Web research was blocked in this session.** Nothing in the pack comes from Kelverton's website, news or the panellists' profiles, and those parts are marked generic. I also haven't seen the market report, so wherever the POV needs it there's a slot for you to fill.

The question to rehearse most is **B1**: "You've never carried a quota and never sold into rail. Why should I believe you can deliver revenue here?" The pack has you name both limits before Ross does. Then you stand on what you actually did: the ISV channel from 6 partners to 40, and roughly £4M of influenced revenue.

One thing to check before Tuesday: don't add your 9 years in partnerships to the 5 years in consulting out loud. Say them the way your CV does.

If you want to practise, I can play Ross on B1 and follow up on what you actually say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, so you can use it in later sessions.
I can also turn the thesis you pick into a 12–13 minute talk track. It's the one part of the interview with a set brief, so it's worth having out loud, not just in notes.
If you'd like the pack as a Word document, I'll convert it.

Can you paste the job description, or should I keep going without it? With it, the three generic requirements become quoted ones, and any location or travel requirements show up.

Do you want to allow web search so I can research Kelverton and the panel? If so, I can also do a deeper pass of up to 6 more searches and 2 page reads, which takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: KelvertonRail_senior-partnerships-manager_interview_pack.md -----
# Interview pack — Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel, Tuesday. 15-minute POV (no slides), then Q&A.
**Panel:** Deepa, VP Partnerships (your future manager) and Ross, Commercial Director ("Ross will push on commercials", per the recruiter).
**Built from:** your message and the recruiter's email as you quoted it. No JD text. The internal market report is in your hands, not mine, so wherever the pack needs it there is a slot for you to fill. Web research was refused in this session, so nothing here comes from Kelverton's public footprint.

---

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. A single question can come from Deepa as a quiet probe or from Ross as a time-boxed challenge, so rehearse both the content and the register.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values they care about |
| EXP | Whether your stated claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the job as described, gaps included |
| CO | Homework depth: their market, their strategy, their report |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to your message or the recruiter's email. `[inferred]` is derived from those sources, with the derivation named. `[generic]` is a role-family pattern with no claim about Kelverton.

The guidance gives you scaffolding, not a script. Where it says **answer slot**, the pack doesn't know the answer. Fill it with what actually happened, or say plainly that it didn't happen.

---

## Prep triage — your four hours

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Pick one thesis, fill the report slots, and talk the POV through out loud. Time it to 12–13 minutes | Section: POV build |
| 2 | 40 min | Rehearse B1, the quota and rail objection, out loud, through both follow-ups, twice | B1 |
| 3 | 30 min | Work out what you can and can't say about how the £4M and the 40 were counted | D1, D2, F3 |
| 4 | 30 min | Do a second full run of the POV, recorded. Cut whatever ran long, and make sure the operator close survives the cut | POV build, close |
| 5 | 25 min | Do the cases out loud, two minutes each | A1–A5, D3 |
| 6 | 20 min | Choose three reverse questions, one for each panellist and one for both | Reverse questions |
| 7 | 20 min | Run through the Skeptic bank | C1–C4 |

Everything else in the pack is insurance.

---

## Fit snapshot

The requirements come from the recruiter's words. Where no JD exists, they're role-family requirements written as plain prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material describes an ISV channel at a payments company, not operator partnerships in rail. The words stay at that scope: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: "where you'd take our operator partnerships" makes a probe on how the channel grew likely. If the growth from 6 to 40 came from choices you made, say which ones and how you decided, in your own words. If steering it wasn't yours, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material describes bus and light rail network planning in consulting, not train operating companies. The words: "I spent five years in transport consulting, on bus and light rail network planning." If you use your own phrase "from the other side", expect "which side?" next. Answer slot: the recruiter's close makes a probe on what operators care about likely. If your planning work showed you what operators care about, say what, and from which side of the table you saw it, in your own words. If it didn't, say so plainly and take the operators' priorities from the report, saying that's where they came from |
| F3 | "Ross will push on commercials" — recruiter | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | Influenced revenue is commercial evidence, but it isn't direct sales. You stated the limit yourself, so you can say it: "Roughly £4M of influenced revenue. I've never carried a direct quota." Answer slot on the figure: how the £4M was counted, what it's sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. "I don't know exactly how it was counted" is an honest branch |
| F4 | Building and scaling a partner ecosystem, a standard requirement for senior partnership roles | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | There's no gap in the wording, but the line has nothing inspected behind it, so expect a probe on the 40. Lead with the quote's own terms: you ran the channel, from 6 partners to 40. The figure raises the defend-the-number slots (see D2) |
| F5 | Experience selling into the rail sector, common in roles that sell to rail operators | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | No wording closes this gap, and you've said so. Words: "I haven't sold into rail specifically." Follow that with how you would learn the sector, said as a plan and never as a past. Don't add anything to make the gap feel smaller |
| F6 | Direct revenue accountability (a quota or target), common in senior commercial roles. Whether this role carries one isn't established | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | Words: "I've never carried a direct quota. My revenue has been influenced revenue." Whether Kelverton will want one is a reverse question (R3), not a guess. Any willingness to carry a target is a statement about the future and has to be said as one |

**Ambiguity to resolve downward:** your message says "9 years in partnerships" and "Before that, 5 years in transport consulting". Don't add them up out loud, and don't fold the consulting years into the partnerships years. Use the arithmetic your CV uses.

---

## Graded deliverable — the 15-minute POV

The recruiter set out the brief in three parts. It's a POV on "where you'd take our operator partnerships over the next 18 months". There are no slides. And "Please land on what it means for the operators themselves." Ross's push on commercials will start the moment you stop, so plant the commercial hooks inside the POV.

### What you're building on

| Fact | Source | Provenance |
|---|---|---|
| 18-month horizon, operator partnerships, close on what it means for operators | Recruiter's email | [grounded] |
| Your channel history: F1, "took it from 6 partners to 40, roughly £4M of influenced revenue." | F1 | [grounded] |
| Your view of operators: F2, "bus and light rail network planning, so I know the operator world from the other side" | F2 | [grounded] |
| Your limits: F5 and F6, "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | F5, F6 | [grounded] |
| The strategy team's report. Answer slot: you pick the one finding the panel will expect to hear, and the one you'll depart from | Your copy | Fill in |

**The report is shared material.** Deepa and Ross have it, and so does every other finalist. Reciting it scores as homework. Departing from it with reasons scores as judgment. Use it in three moves:

1. **One consensus item** from the report, to show you've read it. Say it in their language.
2. **One divergence**, where you'd weight things differently from the report, and why. This is the 30 seconds that separates you.
3. **One anti-pick**, something you would deliberately not do in the 18 months.

If the report covers a change in how operators are owned, contracted or funded, check that your POV says what that change does to partnering. A panel will notice if the biggest structural item in its own report is missing.

### Shape for 12–13 minutes (leave about 2 for a first question)

| Minutes | Beat | Note |
|---|---|---|
| 1 | **How I'm reading "operator partnerships."** State your assumption out loud. It could mean partnering with operators themselves (design partners, reference operators), with the vendors and integrators around them, or both | You don't know which, and the brief allows both. Naming the fork reads as clarifying before structuring |
| 2 | **Where I think you are now.** The consensus item from the report | Slot: the report's own finding |
| 6 | **The 18 months in three phases:** 0–6, 6–12, 12–18. One thesis, with what you'd do, what you'd measure and what you'd stop | Pick a thesis from the table below |
| 1–2 | **How this gets paid for.** How each phase would be measured commercially, as a hook for Ross | See D3 for the commercial-model vocabulary |
| 2–3 | **What it means for operators.** The close the recruiter asked for | See "The close" below |

### Thesis options (pick one, keep one as your answer to "what else did you consider?")

| Thesis | The argument | Mandatory concession | Provenance |
|---|---|---|---|
| T1 Depth before breadth | A small number of operators as deep design partners and references in the first 6–12 months, then widen. Each deep partnership becomes the proof the next operator needs | Headline partner count grows more slowly. If the report or the board wants coverage fast, this thesis is out of step, so say you know that | [generic] |
| T2 Partner around the operator | Prioritise the vendors and systems an operator's scheduling has to work with, so the operator gets fewer seams and faster time to value | It costs engineering capacity, and Kelverton may already have some of these partnerships. Ask, don't assume | [generic] |
| T3 Operators in the roadmap | A structured operator advisory or co-development programme, so operators shape what gets built | There's a risk of drifting into bespoke work for whoever is loudest, and procurement rules may limit what an operator can formally commit to | [generic] |

**Differentiation against your own history.** F1 is a channel that went "from 6 partners to 40", so the obvious expectation is that you'll pitch partner count. If you pick T1, you choose depth and say why, which shows the choice is judgment rather than reflex. Say what you'd measure instead of count.

**Anti-pick options** `[generic]`: a partner-count KPI as the headline measure; a reseller channel before the direct operator relationships are proven; any partnership that adds a seam for the operator rather than removing one. Pick one and give the reason in operator terms.

### The close — what it means for operators

Make every point something an operator would notice, not something Kelverton would. The choices below are generic until you fill them from the report:

- Fewer integration seams and handoffs for their planning teams.
- Faster time from contract to working timetable.
- A real voice in what gets built next.
- One line on what operators should not have to do because of your plan.

Answer slot (F2): if your bus and light rail planning years showed you what operators actually struggle with, put one concrete thing here in your own words and say which side of the table you saw it from. If they didn't, use the operator priorities the report names and say that's where they came from.

---

## Reading the panel

There's no public footprint here because research was refused. Everything below comes from the recruiter's email.

| Panellist | What the recruiter said | Practical implication | Provenance |
|---|---|---|---|
| Deepa | "VP Partnerships, your future manager" | She is buying capability and de-risking gaps. Expect the Case/Strategist and Skeptic registers, and expect the POV to be read as "would I want this person's plan on my team?" | [grounded] |
| Ross | "Commercial Director" and "Ross will push on commercials" | Expect numbers, revenue attribution, and the seam between partnerships and his commercial team. The influenced-versus-direct distinction (F3, F6) is where he will press | [grounded] |

With search permission, I could add each panellist's career path and a reverse question tied to it (see the upgrade menu).

---

## Persona weights

The recruiter's email sets the loop: one 60-minute panel, two named panellists, a POV and then Q&A. So these weights rest on what she told you, not on an archetype.

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Deepa extends the POV: "what would you stop", "which operators first" | **High.** Hiring-manager prior, plus a POV that invites follow-on cases | Clarify, then objective, then approach, then metrics, then risks. Think aloud. Challenge one premise per case, respectfully |
| Pressure | Ross time-boxes and plays devil's advocate on revenue | **High.** The recruiter said he "will push on commercials", and that, plus the executive prior, means pressure | Pause, restate the question, hold through two follow-ups, then concede only what's real |
| Skeptic | Deepa probes the rail gap and how your experience transfers | **High.** Hiring-manager prior, and F2, F5 and F6 are visible gaps | Make the predictable objection boring through rehearsal. Bridge only from what you've stated |
| Data-Driven Prober | Ross asks how the £4M and the 40 were counted | **Mid.** The commercial push makes your two figures likely targets | Know what you can and can't say about how each figure was counted, and say plainly when you don't know |
| Peer Evaluator | Ross as owner of the commercial team, asking where partnerships and sales meet | **Low.** He's senior, not a peer, but the seam is his | Propose principles for the seam rather than pretending to know it. Frame around what you give his team, not only what you need |
| Conversational | Opening chat, "walk us through your journey" | **Low.** It's a short session with a set structure | Use a scripted 90-second arc. Casual questions are still scored |
| Values/Behavioral | One or two scenario probes | **Low.** No values round was named | Pick stories where the hard truth actually landed |

---

## Question banks

### A — Case/Strategist (Deepa leads, Ross joins)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've told us where you'd go. What would you stop doing, or never start?" | CASE | [generic] | Give your anti-pick from the POV, the reason in operator terms, and what it frees up. If they push back, keep the anti-pick and concede the cost: "That means slower partner count in year one, and I'd accept that." | It's the natural first follow-up to any POV, and the role's real job includes saying no. CASE because it's a live judgment, not a record |
| A2 | "An operator wants to work with us but says procurement won't let them commit to anything exclusive. What do you do?" | CASE | [generic] | Separate what you need (a reference, co-design input, early feedback) from what exclusivity would have given you. Propose a lighter structure that fits their rules, such as a named design-partner arrangement or a pilot with published outcomes. Say what you'd check with their procurement team first. Close on what the operator gets | It tests whether your plan survives an operator's own constraints, which is the recruiter's close turned into a case |
| A3 | "Which three operators would you go to first, and why those?" | CASE | [generic] | Give criteria before names: existing relationship, product fit, reference value to other operators, and appetite for change. Slot: if the report segments operators, use its segments and say so. Don't name operators you can't justify. "I'd want to see your pipeline data first, but my criteria would be…" is a strong answer | It's where a POV meets a list, and the place a candidate without rail experience is most tempted to guess. Criteria score better than names here |
| A4 | "How would you decide whether a partner is worth the engineering time to integrate?" | CASE | [generic] | Cover four things. What it does for the operator: fewer seams, time saved. Demand: how many operators ask for it. Cost: build and support. What happens if you don't build it. Then say what you'd want engineering to tell you before committing | Partnerships compete for product capacity, and Deepa will want to know you price that. It ties to T2 |
| A5 | "What would your first 90 days look like?" | CASE | [generic] | Listen, then pick, then prove. Meet operators and the commercial team, map existing partnerships against the report, pick the thesis, and land one early, visible step. Set out what you'd show Deepa at day 90. Stay inside the recruiter's 18-month frame | It's a standard hiring-manager close and checks that the 18-month POV has a realistic start |

### B — Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a quota and you've never sold into rail. Why should I believe you can deliver revenue here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | **The highest-ROI rehearsal in this pack.** Say the limit before he finishes the sentence. **Concede plainly:** "I haven't carried a direct quota, and I haven't sold into rail specifically." **Hold on what you stated:** "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40, with roughly £4M of influenced revenue." **Then look forward, as a plan:** say how you'd want partnership revenue measured here and, if you're willing to carry a number, say so. **Follow-up 1, "Influenced is soft, anyone can claim influence":** answer slot. Say how the £4M was counted, in your own words. If you don't know exactly, say so, and say what it did and didn't include. **Follow-up 2, "So what number would you sign up to?":** don't invent one. Say what you'd need to know first, such as the base, the partner mix and sales-cycle length, and say when you'd commit to a number. Don't fold on the core claim to ease the moment | F3, F5 and F6 together are this candidate's most predictable objection, and Ross has been flagged as pushing on commercials. Both negatives in the question come from your own words, so it can be asked exactly like this. JD, because it scores revenue accountability |
| B2 | "Sixty seconds. Why you over someone who's sold rail software for ten years?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Pause, then give three sentences. One: the channel you ran, 6 partners to 40. Two: five years of bus and light rail network planning in consulting. Three: "I haven't sold into rail specifically", plus what you'd do in the first months to close that. Don't claim you beat rail experience. Say what you bring and let them weigh it | This tests composure on F5. JD, because it scores fit against the role |
| B3 | "That 6 to 40. How much of that was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say which parts of the growth were yours, such as recruiting, choosing or enabling partners, and which were the team's or the product's, in your own words. Use "we" for context and "I" for your contribution. If some of the growth came from things outside your control, say so plainly. It makes the rest more believable | A pressure-stem probe on F1 and F4's headline figure. EXP, because it scores attribution |
| B4 | "Your POV sounds sensible, but where's the money in month six?" | CASE | [generic] | Hold that partnership revenue usually lags. Then name what you'd show at month six instead: signed design partners, pipeline that partners touched, time to first value for a pilot operator. Concede if your plan has no revenue in the first six months, and say when it does | It stress-tests the commercial hook in your POV. CASE, because it's a live defence of your own plan |

### C — Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your transport work was bus and light rail. What carries over to heavy-rail operators, and what doesn't?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot, both halves in your own words: what from bus and light rail network planning you'd expect to carry over, and what you'd expect to be different for train operating companies. Leading with what doesn't carry over is the stronger move, and it's an honest answer, not a confession. Don't claim heavy-rail knowledge the quote doesn't carry | F2's limit is visible to any reader of your background. EXP, because it scores what the consulting years actually were |
| C2 | "Tell us about the consulting years. What did you see of operators?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Use the beats the quote states: five years, transport consulting, bus and light rail network planning. Answer slot: if you worked alongside operators' own staff, say on what and what they cared about. If your clients sat on a different side, say whose and what you saw of operators from there. Either way, name the side. "From the other side" will draw "which side?" | This is the source for your POV close. EXP, because a vague answer here weakens the close |
| C3 | "Payments partners and rail operators are very different. Which part of your old playbook would you throw away here?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: if you ran the ISV channel with practices you'd now drop for operators, name one and why, in your own words. If there was no fixed playbook, say so and name what you'd expect to work differently with operators. Showing you know what not to carry over scores higher than claiming it all transfers | F1's transferability limit, seen from the hiring manager's side. JD, because it scores whether you can do this job |
| C4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one of the gaps you've stated, rail or the direct quota, and own it: "I haven't sold into rail specifically." Then give the plan, as a plan. Don't choose a fake weakness. Deepa will hear it and stop trusting your other answers | It's a Skeptic stem, and F5 and F6 make it more likely. Give a real answer, not a deflection |

### D — Data-Driven Prober (Ross, commercials)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Keep "roughly" and "influenced". Answer slots, each in your own words: how it was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours. Name that weakest assumption before he does. If you don't know how it was counted, say so plainly. Don't build a method live | It's the CV's headline revenue figure and the most likely target. EXP, because it's a defend-the-number question |
| D2 | "Forty partners. How many of those actually produced revenue?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: if you know how many were active or produced revenue, say so. If you don't, say so, and say what you'd look at to find out. Don't estimate live unless you call it an estimate | The partner count is F4's figure, and Ross will want the real denominator. EXP |
| D3 | "How would you structure the commercials of a partnership, with an operator or with a vendor who sells to operators?" | CASE | [generic] | Start from who owns the customer relationship and who carries support. Then go through the options: a referral fee, resale margin, revenue share, co-sell against a shared target, or a technical integration with no money changing hands. Pick based on what each one does to the operator's experience and to Ross's team, and say what you'd test first. Don't claim any of these from your own past unless you've said so | Ross's home ground, and the clearest place to show commercial thinking without claiming a quota. CASE |

### E — Peer Evaluator (Ross, the seam with his team)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and my sales team will both want credit for the same operator deal. How do you handle that?" | CASE | [generic] | Propose principles: agree rules of engagement before the deal, not during it. Separate sourced revenue from influenced revenue and report both. Escalate early. Answer slot: if you had a working rule for this with the payments company's sales team, say what it was. If you didn't, say so and propose one | A Peer-stem question on credit across teams, and Ross owns the other side of the seam. CASE |
| E2 | "What would you need from my team in your first month, and what would you give back?" | CASE | [generic] | Need: their view of the operator accounts, and where partners have helped or hurt deals. Give back: partner-sourced leads, and fewer surprises in their accounts. Keep it specific, and make reciprocity the frame | It's a reciprocity probe, and it tests whether you'd add to or reduce his team's load |

### F — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk us through your journey. Why partnerships, why rail, why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Keep it to a 90-second arc. Start with the consulting years and the network planning, then the partnerships years, ending with the ISV channel. Answer slot: why rail, and why now, in your own words. Use the years as your CV states them, and don't add the consulting years to the partnerships years | It's a standard opener and it's scored. EXP, because it's your history told aloud |
| F2 | "What did you make of the report our strategy team put together?" | CO | [generic] | Give one finding you agree with and one you'd weight differently, with your reason. Don't recite it, and don't trash it, because people in the room may have contributed to it | It's a casual question on a hot topic, and it's scored. CO |

### G — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you told a partner, or your own leadership, something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you didn't fold, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It's a persona stem. Partnership roles involve telling partners no, and A1's anti-pick needs the same spine |
| G2 | "When did you put a partner's or customer's interest ahead of an internal number?" | VAL | [generic] | Selection scaffold: pick a decision where the number cost you something real and the partner or customer benefited. Say what you gave up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It's a persona stem that matches the recruiter's "what it means for the operators themselves" |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| POV on operator partnerships over 18 months (recruiter) | POV build, A1, A3, A5, B4 |
| Land on what it means for operators (recruiter) | POV close, A2, C2, G2 |
| Commercials, Ross's push (recruiter) | B1, B4, D1, D2, D3, E1 |
| Building a partner ecosystem (generic) | A4, B3, C3, D2 |
| Rail-sector knowledge (generic) | B2, C1, C2, C4 |
| Direct revenue accountability (generic) | B1, D1, reverse R3 |
| Working across the commercial team (generic) | E1, E2 |

---

## Reverse questions

| # | Question | To | Why it lands |
|---|---|---|---|
| R1 | "When you say operator partnerships, do you mean partnering with the operators themselves, with the partners who help you serve them, or both, and has that changed recently?" | Both | It settles the fork your POV opens on, and it shows you noticed the ambiguity rather than guessing |
| R2 | "Twelve months in, what would make you say this hire was clearly the right call, and what would you look at first?" | Deepa | It gets her success criteria in her own words, and it's a manager question, not a candidate one |
| R3 | "How is partnership revenue counted against commercial targets today: sourced, influenced or attached? And does this role carry a number?" | Ross | It answers F6 directly and shows you aren't hiding from the quota question. You also need to know before accepting |
| R4 | "Which part of the strategy team's report do the two of you see differently?" | Both | It shows you read the report critically, and it often opens up the real debate inside the company |
| R5 | "Where have operator partnerships stalled here before, and what got in the way?" | Deepa | It surfaces past failures your plan has to avoid, and it treats her as the person with the history |
| R6 | "Where does the seam between partnerships and your team cause the most friction today?" | Ross | It's a reciprocity framing that follows up E1 and signals you'd reduce his load, not add to it |

---

## Prohibited claims — what this pack won't coach

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried or hit a quota, or "owned" or "closed" £4M of revenue | A negative you stated, F3 and F6 | "I've never carried a direct quota. My revenue has been influenced revenue." Then "roughly £4M of influenced revenue", with both qualifiers kept |
| Has sold into rail | A negative you stated, F5 | "I haven't sold into rail specifically." |
| Has worked with train operating companies, or knows heavy-rail operators | An inflated form of F2 | F2's quote at its own scope. As the pack's own observation: your material says bus and light rail network planning in consulting. C1's and C2's slots stay inside that |
| Personally signed or recruited the 34 new partners | An inflated form of F1, on the attribution axis | F1's quote at its own scope: you ran the channel, and it went from 6 partners to 40. B3's slot asks which parts were yours |
| Fourteen years of partnerships experience | An inflated form of the years in F1 and F2, adding the two together | Say the years as your CV states them. The pack's observation is that your message doesn't say whether the 9 include the 5 |

---

## Sources

- **Provided:** your message (background), and the recruiter's email as you quoted it in your message.
- **Not in hand:** the internal market report. You've read it and I haven't, so every report-dependent cell is a slot for you to fill.
- **No dossier** was present.

**Searches sent:**

| Query | Outcome |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail scheduling software train operating companies strategy | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Senior Partnerships Manager rail software UK job description train operators | refused |

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Search refused. It would have themed G1 and G2 with Kelverton's own values. No values cheat sheet either way, because no values round was named |
| 2. Kelverton Rail interview process | skipped | The recruiter's email already sets the session: one 60-minute panel, with named panellists, a POV and Q&A. The persona weights follow it |
| 3. Kelverton Rail strategy and recent news | unavailable | Search refused. It would have grounded the POV's thesis options, A3 and F2 in Kelverton's current priorities, and moved CO questions off `[generic]` |
| 4. Deepa and Ross, Kelverton Rail | unavailable | The search for Deepa was refused, and none was sent for Ross. It would have added career paths to the panel read and a reverse question tied to each panellist's path |
| 5. Representative Senior Partnerships Manager JD | unavailable | Search refused. It would have replaced the role-family rows F4, F5 and F6 with quoted `[inferred]` requirements |

---

## Upgrade menu

- **The JD text** → F4, F5 and F6 move from role-family prose to quoted requirements, I add JD-tagged questions for any mid-list requirement, and any gate (location, travel, right to work) gets its own row.
- **Key points from the market report, pasted** (headline numbers, named priorities, operator segments, only what you're comfortable sharing) → the POV's consensus item, divergence and anti-pick get specific, A3 and F2 become report-grounded, and the operator close gets real priorities.
- **Search permission** → targets 1, 3, 4 and 5 run: Kelverton's own values for G1 and G2, current strategy for the POV and the CO questions, the panellists' public career paths, and a representative JD.
- **Deeper research pass (L2)** → up to 6 more searches and 2 more fetches, which takes several more minutes. It adds a strategy brief, the panellists' talks and writing, and recent organisational context.
- **Your answers to the slots in F1, F2 and F3** (how the 6-to-40 growth happened, which side of the table you saw operators from, how the £4M was counted) → B1, B3, C2, D1 and the POV close become story-mapped instead of slot-led.
- **Your CV** → evidence cells quote your CV's lines, and the years question in the ambiguity note settles.
- **A tuesday-dossier.md from a job-underwriter pass** → verified evidence and an underwriter-named objection. Not needed for this pack.
