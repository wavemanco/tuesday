Web search was declined, so I'll build the pack only from what's in this conversation. I'll label anything specific to Stripe as generic and won't fill gaps from memory. Writing the pack now.
Your prep pack is saved as `Stripe_product-operations-manager_interview_pack.md`. I had no job description, CV or interviewer details, and web search was declined, so I built it on three assumptions:

- **Typical Product Ops requirements.** The eight requirements it covers are standard for the role, not taken from Stripe's posting.
- **No facts about Stripe.** I didn't fill in Stripe's values, interview structure or strategy from memory.
- **Equal weight on all seven interviewer styles.** Every style gets three practice questions, 21 in total.

Each question comes with a guide to choosing a story from your own experience, plus an honest fallback if you don't have one. The pack marks B1, "Which part of this role would you be weakest at on day one?", as the most valuable one to practise.

Say the word and I'll play the Skeptic on B1 as a live mock interview, with follow-ups that react to your answers.
I can also save a `tuesday-dossier.md` file recording the gaps this prep turns up, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who will you meet in the final round (your future manager, peers, people from other teams, a senior leader), and did the recruiter mention focus areas or anything to prepare, like a presentation or case? That changes how the questions are weighted.
2. Can you paste the job description and your CV? They turn the generic guides into answers built on your own experience. I'm happy to keep going without them.
3. Do you want to allow web search? Up to 6 searches would bring in Stripe's published principles, interview structure and current strategy, with sources.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer(s): not known. Relationship: not known. Built without a job description, a CV, or web research (search was declined), so every requirement and question here is a role-family pattern labeled `[generic]`, and nothing in it asserts a fact about Stripe's values, loop or strategy.

## How to use this pack

- **Personas** describe how a question will be asked (who's asking, in what register). **Types** describe what it is scoring.
- Type key:
  - **VAL**: behavioral or values alignment, meaning past behavior that shows the company's published values.
  - **EXP**: work-experience deep-dive, meaning what you actually did and whether your claims hold up.
  - **JD**: role-driven, meaning whether you can do the listed job, gaps included.
  - **CO**: company and strategy knowledge, meaning homework depth and whether you can think at the company's altitude.
  - **CASE**: a live problem from the role, scored on structure and reasoning.
- Guidance is scaffolding, not a script. Every guidance cell here is a **selection scaffold**: it tells you what a strong story needs so you can pick one from your own history. Each ends with an honest branch for when you have no such story. Once you send your CV, these become story-mapped answers built on your own sentences.

## Fit snapshot (worksheet)

No background is in hand, so this is a self-assessment worksheet. These are typical Product Operations requirements, written as plain prose with no source, which is why there are no quotation marks. For each row, find one story of your own that meets the "strong evidence" bar before the interview.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Getting new products and features operationally ready to launch across engineering, support, sales and risk teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a launch where you can name what had to be ready, who owned each piece, and what you personally coordinated. Pick a launch or rollout where you were the connective tissue between teams. It needs a named deadline, at least two functions, and a specific thing you did that would not have happened otherwise. If no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designing repeatable processes and playbooks that hold up as volume grows (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a process you designed or changed, the problem it fixed, and how you knew it worked. Pick one where something manual or broken became repeatable. It needs a before, an after, and the part that was yours. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would design one |
| F3 | Using data to define metrics, diagnose problems and track outcomes (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: an analysis you ran yourself, the question it answered, and the decision it changed. Pick one where you can say how the numbers were counted and which assumption you would defend least. If none comes to mind, say so plainly, then describe how you would approach the analysis |
| F4 | Bringing customer and user feedback back into product decisions (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a feedback loop you ran or fed, and one product change you can trace to it. Pick a time customer signal reached a product team through you. If none comes to mind, say so plainly, then describe how you would build such a loop |
| F5 | Influencing cross-functional partners without formal authority (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a disagreement with a peer team, what each side wanted, and how it resolved. Pick one where you didn't own the decision but moved it. It needs a named stake and an intact relationship at the end. If none comes to mind, say so plainly, then describe how you would handle it |
| F6 | Prioritizing and running programs under ambiguity (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a time you had more work than capacity and chose what waited, with the reasoning. Pick one with a real trade-off and a consequence you can name. If none comes to mind, say so plainly, then describe how you would prioritize |
| F7 | Clear written communication of plans, trade-offs and decisions (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a document you wrote that changed a decision or aligned a group. Pick one you could describe in two sentences: what it argued and what happened next. If none comes to mind, say so plainly, then describe how you would write one |
| F8 | Awareness of risk, compliance and reliability constraints on financial products (role-family pattern for payments roles) | none given | none | [generic] | discovery | Strong evidence: a time a risk, compliance or reliability constraint shaped how you shipped or ran something. Pick one where you can name the constraint and what you changed because of it. If none comes to mind, say so plainly, then describe how you would learn the constraints fast |

## Persona table

No loop source establishes how Stripe's final round is structured. "Final round" alone says nothing about its sessions, and research was declined. So the weights fall back to the **Generic archetype: flat weights**. That is a pattern, not Stripe's documented process, and it is noticeably weaker than a pack keyed to known interviewers.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live ops problems: plan a launch, diagnose a metric drop | Medium. Flat weight because the relationship is unknown, but it is the most common hiring-manager style for operations roles | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of fit: why ops, why here, why now, the weakest area | Medium. Flat weight; final rounds commonly de-risk the candidate's biggest gap | Rehearse the most predictable objection (B1) until it's boring; bridge only from work you actually did; give a concrete ramp plan |
| Values / Behavioral | "Tell me about a time…" scenarios, often from someone outside the function | Medium. Flat weight; no Stripe values page in hand, so these are themed by generic stems | "We" for context, "I" for contribution; pick stories where the hard truth actually landed |
| Data-Driven Prober | Asks how numbers were counted, two levels deeper | Medium. Flat weight; operations roles carry metric claims | Know how each number you cite was counted, and say plainly when you don't know; name your weakest assumption first |
| Peer Evaluator | Seams between teams, "what would you need from me" | Medium. Flat weight; product ops sits between several teams | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Pressure / Stress | Interrupts, time-boxes, "how much of that was you" | Medium. Flat weight; composure is tested in most finals in some form | Pause, restate, anchor in what you actually did, hold through two follow-ups, then concede specifically |
| Conversational / Rapport | Friendly openers, the biography question, reverse questions | Medium. Flat weight; casual questions are still scored | Pre-script a 90-second arc; treat casual questions as scored; never say "I think you've covered everything" |

## Question banks

Weights are flat, so every persona gets three questions (21 in total). **B1 is the highest-ROI prep in this pack.** Some version of "where are you weakest for this role" comes up in almost every final round, and a calm, specific, non-defensive answer changes how the rest of the interview goes.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're launching a new product to merchants in a new country in eight weeks. You own operational readiness. What do you do first?" | CASE | [generic] | Clarify first: who the users are, what "ready" means, and what's fixed (date, scope). Then work-streams: support (docs, macros, escalation paths), sales and success enablement, risk and compliance sign-off, reporting, and a launch go/no-go checklist with owners. Name the one thing most likely to slip and how you'd catch it early. Close with the metrics you'd watch in week one. No claim about your past is needed | Tests F1 live; CASE because it scores structure on a role problem, not your record |
| A2 | "Support tickets for one product jumped 30% month over month. Diagnose it." | CASE | [generic] | Don't jump to a cause. First check whether the jump is real: a counting change, a new channel, a volume shift. Then segment by ticket category, customer segment, region and release date, and see where the jump concentrates. Form one or two hypotheses (a recent release, a policy change, a broken flow) and say what data would confirm each. End with a near-term fix for customers plus the root-cause loop into the product team | Tests F3 and F4 together; the denominator check is what separates strong answers |
| A3 | "You have three teams asking for your time next quarter and capacity for one. How do you decide?" | CASE | [generic] | Name your criteria aloud: customer impact, revenue or risk exposure, reversibility, and dependencies. Score the three asks visibly. Say who you'd align with before deciding and how you'd tell the two teams you didn't pick, with what they get instead. No claim about your past is needed | Tests F6 as a decision, not a record; CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI rehearsal.** Use the F1 to F8 worksheet to pick a real gap, not a disguised strength ("I care too much" fails). Shape: name it plainly in one sentence; give the nearest adjacent thing you actually did, at its true size; then a concrete 30-day ramp (who you'd learn from, what you'd read, what you'd ship small first). Hold through two follow-ups by returning to the ramp plan, never by shrinking the gap. If the interviewer pushes on whether it's disqualifying, concede what's true and restate the plan | Every final round de-risks something, and the candidate who names their own gap first controls the framing; JD because it scores against the role's requirements |
| B2 | "Why product operations, and why now?" | JD | [generic] | Pick the moment or pattern in your own career that pulled you toward ops work: a time you fixed how something ran, rather than what it was. Two or three sentences of past, one of what you want next, one tying it to this role. If there's no single moment, say so and describe the pattern honestly | Motivation consistency is what Skeptics test; the answer must survive "and before that?" |
| B3 | "Why Stripe, specifically, and not another fintech?" | CO | [generic] | Build this from your own reading before the interview: one thing about Stripe's products or users that you've checked yourself, one reason it matters to you, one way this role connects to it. Avoid anything you can't source; an interviewer will know if a fact is wrong or stale. If you can't name something specific yet, that is the first thing to fix in your prep | CO because it scores homework; generic because no research ran, so the pack cannot supply facts about Stripe |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they didn't want to hear. It needs a named stake, the moment you said it, and what happened next, even if it didn't land. Say "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Persona stem; ops roles constantly surface uncomfortable data upward |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision where the customer-right answer cost something measurable internally. It needs the trade-off, your part in the call, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Persona stem; ties to F4 |
| C3 | "Tell me about a time something you owned failed." | VAL | [generic] | Pick a real miss that was yours, not a team's or a vendor's. Shape: what happened, your part, what you changed afterward. Don't soften the miss. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry | Tests ownership and candor; a common behavioral theme in final rounds |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a metric you defined. How was it counted?" | EXP | [generic] | Pick a metric you set up or owned. Be ready to say, in your own words, how it was counted, what it was sensitive to, the assumption you'd defend least, and which part was yours. "I don't know how that was counted" is an honest answer if it's true. If you never defined one, say so and describe a metric you used and how you'd have counted it | Tests F3; every figure you mention in the loop will draw this probe |
| D2 | "Walk me through an analysis you did yourself, end to end." | EXP | [generic] | Pick one where you touched the data yourself: the question, the data source, the method, the answer, and the decision it changed. If your analyses were done by others and you used the output, say so plainly and describe how you used it | Separates doing from consuming analysis; EXP because it tests what was actually yours |
| D3 | "How would you know if a process you built was working?" | JD | [generic] | Name a leading metric, a lagging one, and a qualitative signal (what support or partner teams tell you). Say what result would make you change or retire the process. No claim about your past is needed | Tests F2 and F3 together as a forward-looking design |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Don't pretend to know their team's seam. Propose principles instead: who owns the decision, who's consulted, how you escalate, and a default of writing the disagreement down. Then ask what's worked for them | Persona stem; tests F5 without needing a story |
| E2 | "Tell me about a disagreement with a peer team you didn't have authority over." | VAL | [generic] | Pick one with a real stake, both sides' positions stated fairly, what you did, and where the relationship ended up. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Tests F5 with a record; spine and tact together |
| E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | A short principle, then one example if you have one: name the other team's contribution specifically and publicly. If you have no example, the principle alone is fine | Persona stem; peers weigh whether you'll add to or reduce their load |

### P. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then three beats: what you bring from outside (one thing, real), how fast you'd ramp (B1's plan), and what you'd ask for from the team. Don't run down internal candidates. Stop at sixty seconds | Persona stem; composure under a time-box |
| P2 | "That result you just described: how much of it was actually you?" | EXP | [generic] | Rehearse this against whichever story you use most. Shape: hold your actual part, stated precisely, through two follow-ups; then concede specifically what others did. Never inflate to restore harmony, and never shrink what was really yours | Persona stem; the probe exists to catch inflation, so candor is the winning move |
| P3 | "I'm not convinced you've operated at the scale this role needs." | JD | [generic] | Don't argue scale you haven't had. Restate the doubt, give the largest scale you actually worked at in plain numbers you can defend, then say what changes at bigger scale and how you'd handle it. Hold, then concede specifically | Devil's-advocate move; tests hold-then-concede |

### G. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A pre-scripted 90-second arc: where you started, two turns that matter for this role, and why this role is the next step. Write it from your own CV and time it aloud | Persona stem; scored even though it feels casual |
| G2 | "What's a tool or workflow you've been playing with lately?" | JD | [generic] | Name something real you've actually used, what you tried, and one thing you'd change about how teams use it. If nothing comes to mind, say what you'd like to learn | Casual questions about hot role topics are still scored |
| G3 | "Any questions for me?" | CO | [generic] | Pick two or three from the reverse questions below, tuned to who you're talking to. Never "I think you've covered everything" | Rapport interviewers weight this slot heavily as a preparation signal |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | A1, B1 |
| F2 Process design | D3, A1 |
| F3 Data and metrics | A2, D1, D2, D3 |
| F4 Customer feedback loops | A2, C2 |
| F5 Cross-functional influence | E1, E2, E3 |
| F6 Prioritization | A3 |
| F7 Written communication | none, and why: no question targets it directly because there is no source showing how heavily this loop weights writing. Prepare one example of a document you wrote using F7's scaffold |
| F8 Risk and compliance awareness | A1 (risk sign-off), P3 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does great look like in this role at six months, and what has gotten in the way for people before?" | Shows you're thinking about delivery, and surfaces the real job behind the posting |
| "Which teams does product ops partner with most closely here, and where is the seam hardest today?" | Signals you understand the role lives between teams; tailor it to a peer interviewer |
| "What's one process the team wishes it had built earlier?" | Invites a concrete story and gives you a live problem to react to |
| "How does customer feedback reach the product team today, and what gets lost on the way?" | Ties to F4 and shows product instinct, not just ops |
| "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question; best with a peer |
| "How is this final round's feedback weighed, and is there anything I can clarify from earlier rounds?" | Lets you fix a weak earlier answer; best used with the last interviewer of the day |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| No entries yet | No sentences of yours are in hand, so there is nothing for an inflated form to stretch and no stated negative to give back | Once you send your CV, this list fills with the stretched versions of your real lines that the pack will not coach |

## Sources

- Provided documents: none. Only your message: final round, Stripe, Product Operations Manager.
- Searches sent:
  - "Stripe operating principles official": refused
  - "Stripe interview process product operations final round onsite": refused
  - "Stripe strategy news 2026": refused
  - "Stripe "Product Operations" job posting responsibilities": refused
- No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. It would have supplied Stripe's published principles by name, a values cheat sheet, and VAL questions mapped to them |
| 2. Stripe interview process, product operations | unavailable | Search refused. It would have named the final round's sessions and replaced the flat Generic weights |
| 3. Stripe strategy / recent news | unavailable | Search refused. It would have grounded B3 and at least one CO or CASE question in current strategy |
| 4. Interviewer name + Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. It would have turned F1 to F8 into quoted `[inferred]` requirements |

## Upgrade menu

- The job description text → F1 to F8 become quoted `[grounded]` requirements, and JD-tagged questions target its exact lines, including any gate such as location or work authorization
- Your CV → the worksheet becomes a real fit snapshot, every scaffold becomes a story mapped to your own sentences, B1 targets your actual biggest gap, and the prohibited list fills in
- Who you're meeting, and their relationship to the role (manager, peer, cross-functional, skip-level) → persona weights recomputed from flat
- The recruiter's prep email (focus areas, any presentation, case or take-home) → a build section per graded deliverable, and the final round's actual session structure
- If your final is several back-to-back sessions, the schedule → one mini-pack per session with its own weights and reverse questions
- Interviewer names → an interviewer read from their public professional footprint and a reverse question tied to their path
- Web search allowed (L1, up to 6 searches and 2 fetches) → Stripe's published principles, loop structure and current strategy, sourced; an optional deeper pass (up to 6 more searches and 2 more fetches, several more minutes) adds a strategy brief
- Prep time available → a prioritized prep schedule
- A tuesday-dossier.md from an earlier fit assessment → the highest-ROI objection drawn from evidence rather than inferred, and a prohibited-claims guardrail from verified claims
