I'm reading the interview-prep playbook's reference files, and then I'll build your Kelverton panel pack.
I've built your prep pack for Tuesday and saved it as `kelverton-rail_senior-partnerships-manager_interview_pack.md`.

**What it's built on:** the recruiter's email and the background in your message. I had no job description and none of the market report's content. All six web searches were refused, so nothing in the pack comes from research.

**What's in it:**
- **A schedule for your four hours.** About 90 minutes building the POV, then out-loud rehearsal of the hardest questions, then two timed run-throughs.
- **A plan for the 15-minute POV.**
  - Your first decision is what "operator partnerships" means. It could mean operators as partners, or third parties who reach operators. Your ISV channel was the second kind, so name your reading in the first minute.
  - The pack gives a minute-by-minute outline, three thesis options each with a downside you say out loud, and a close on what it means for operators.
  - Mention commercials before Ross asks.
- **The question you're most likely to face (B1):** "You've never carried a direct quota. Why trust you with a number?" Lead with the honest version: "I've never carried a direct quota; my number has been influenced revenue: roughly £4M." The pack rehearses it through two follow-ups.
- **Watch the wording on your own numbers.**
  - Keep "roughly" and "influenced" on the £4M.
  - Don't put "a year" on it unless that's true.
  - Say you *took* the channel from 6 partners to 40, not that you built it.
  - Your consulting was "bus and light rail… from the other side", not inside train operators.
  - The pack lists these limits in one place.

Say the word and I'll play Ross pressing you on B1 in a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Can you paste the job description, and your CV if it's handy? I can also work without them. Paste it and the generic rows get replaced with the role's actual requirements.
Do you want to allow web search and have me rerun the research? That would add Kelverton's values and strategy and Deepa's and Ross's public profiles.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel

**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute spoken POV with no slides, then Q&A, with Ross pushing on commercials.
**Built from:** the recruiter's email and the background in your message. I had no job description, no CV, and none of the market report's content. Every web search was refused in this session, so nothing here comes from research.

---

## 1. How to use this pack

- **Personas** describe *how* a question gets asked: who asks it and in what register. **Types** describe *what* it scores.
- Type key:
  - **VAL**: behaviour against values. No published values were available, so these are generic.
  - **EXP**: deep-dive on your experience. Do your claims hold up, and which part was actually you?
  - **JD**: can you do the stated job, gaps included?
  - **CO**: company and market knowledge, thinking at Kelverton's altitude.
  - **CASE**: a live problem from the role, scored on structure.
- Guidance is scaffolding, not a script. An **answer slot** marks a place where only you know the answer. Fill it in your own words, or say plainly that the step didn't exist.
- Question IDs go by persona: A, B, C, D, E, G, H. There is no F, so they never collide with the fit-snapshot rows F1 to F6.

## 2. Prep triage: about four hours over the weekend

| Order | Block | Time | What | Pack reference |
|---|---|---|---|---|
| 1 | Sat, session 1 | 90 min | Build the POV. Choose your reading of "operator partnerships", pick a thesis, take one consensus item and one divergence from the market report, write the operator close. Then say it out loud once, with a timer | Section 4 |
| 2 | Sat, session 2 | 45 min | The highest-ROI rehearsal: B1, the quota objection, out loud through all three follow-up levels. Then C1, defending the £4M. Fill in C1's answer slots with what you actually know about how the figure was counted | B1, C1 |
| 3 | Sun, session 3 | 60 min | Two timed POV run-throughs, aiming for 13–14 minutes so Q&A starts on time. Then B2, D1 and D2 out loud | Section 4, B2, D1, D2 |
| 4 | Sun, session 4 | 30 min | Skim the structures for A1–A4 and C4. Pick three reverse questions, one of them aimed at Ross | Banks A and C, section 9 |
| — | Buffer | 15 min | Slippage | — |

Everything else in this pack is insurance.

## 3. Fit snapshot

The requirements come from the recruiter's email where she wrote them, and from role-family patterns where she didn't. There is no job description behind any of them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material shows you running and growing an ISV channel in payments. It doesn't show operator partnerships in rail, so the words stay at the quote's scope: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: "operator partnerships" makes a "what carries over?" probe likely. If you can name what from running that channel you'd reuse here, say it in your own words. If you're unsure what transfers, say so plainly and name what you'd want to learn first |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material puts you in bus and light rail network planning, on the consulting side. It doesn't cover train operating companies. Keep your own phrase, "from the other side", because it is accurate. Answer slot: the recruiter's close makes a probe on what operators care about likely. If a specific operator concern came up in your consulting work, name it in your own words. If none did, say so and say what you'd ask operators first |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue"; "only influenced revenue" — your message | medium | [grounded] | transferability | The figure is influenced revenue, not closed revenue, and "roughly" stays in. Your message doesn't say what period the £4M covers. Don't attach "a year" unless that's true. Answer slot: commercials makes a probe on how the figure was counted, what it's sensitive to, the assumption you'd defend least, and which part was yours. Answer each in your own words. "I don't know exactly how it was counted" is an honest answer |
| F4 | Owning a direct commercial number. A role-family pattern for senior partnerships roles, not something the recruiter stated | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | You stated this gap and wording can't close it. Words: "I've never carried a direct quota; my number has been influenced revenue." Then say how you would work to a direct number here, as a plan, never as a past. Add nothing to make the gap feel smaller |
| F5 | Selling into the rail sector. A role-family pattern, not stated by the recruiter | "Never sold into rail specifically" — your message | none | [grounded] | capability | You stated this one too. Words: "I haven't sold into rail specifically." F2's quote can come next at its own scope (consulting, bus and light rail, the other side). It doesn't close this gap and mustn't be stretched to |
| F6 | Seniority implied by the title "Senior Partnerships Manager" — your message | "9 years in partnerships" — your message | medium | [grounded] | none | No gap. Expect a probe, because a stated tenure has nothing inspectable behind it. The words are "nine years in partnerships" |

## 4. Graded deliverable: the 15-minute POV

The recruiter named the close: *what it means for the operators themselves*. Ross will push on commercials, so the POV should get to the money before he does.

### Grounded facts to build on

- **F1:** "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"
- **F2:** "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- **F4:** "never carried a direct quota, only influenced revenue"

Nothing about Kelverton's own position comes from this pack, because research was refused and the report's content isn't in hand. Your Kelverton facts come from the market report, and you credit them to it out loud.

### The first decision: what "operator partnerships" means

| # | Point | Provenance |
|---|---|---|
| P1 | The phrase reads two ways. Operators can be the partners themselves: design partners, references, joint roadmaps. Or the partners can be third parties who reach operators: integrators, adjacent system vendors. Your F1 channel is the second shape. Name your reading in the first minute, say why, and acknowledge the other one. If you leave it unnamed, Deepa will name it for you in Q&A | [generic] |
| P2 | If the market report settles which reading Kelverton means, use its framing, credited to the report | [generic] |

### Spine, timed

| Time | Beat | Provenance |
|---|---|---|
| 0:00–1:00 | Your reading of "operator partnerships" (P1), and the one-sentence thesis | [generic] |
| 1:00–3:00 | Where things stand: one consensus item from the market report, credited to it. This shows you've done the homework, and you don't recite the rest | [generic] |
| 3:00–10:00 | Three moves phased over 18 months (0–6, 6–12, 12–18), each with what it costs and how you'd know it worked | [generic] |
| 10:00–13:00 | What it means for operators: one operator-side benefit per move, plus one honest cost to them. Lens: F2's "from the other side", at its own scope | [generic] |
| 13:00–14:30 | Commercials, said before Ross asks: how you'd count partnership value. Be candid about influenced versus direct (F4's words) | [generic] |
| 14:30–15:00 | What you'd want to learn in your first weeks before committing to the plan | [generic] |

### Thesis options: pick one. Each carries a concession you must say out loud

| # | Thesis | Mandatory concession | What it means for operators | Provenance |
|---|---|---|---|---|
| T1 | **Depth before breadth.** Work with a few operators as design partners for 18 months instead of broadening the set | It's slower to scale, it concentrates revenue in those partners, and it risks bespoke work | Operators get influence on the roadmap and earlier access. Their cost is staff time | [generic] |
| T2 | **Ecosystem reach.** Partner with the integrators and adjacent systems operators already run, so the scheduling software slots in. This is the shape closest to F1's "running the ISV channel", and the pack's observation is that it's a different industry and a different buyer | Kelverton depends on third parties, with possible channel conflict and margin shared away | Operators get less integration work of their own. Their cost is another vendor relationship to manage | [generic] |
| T3 | **Partnerships with commercial terms.** Every operator partnership carries explicit terms: references, co-investment, renewal commitments | Operators may resist the terms, and the buying constraints on operators are unverified here, so check the report | Operators get predictable terms and visible reciprocity. Their cost is less flexibility | [generic] |

### Differentiation from the consensus answer

| Move | What to do | Provenance |
|---|---|---|
| Consensus item | Take one finding from the market report, name it as the report's, and agree with it. The panel circulated that report, and reciting it scores as homework | [generic] |
| Divergence | Pick one place your thesis departs from the report or goes further, and give the reason in one sentence | [generic] |
| Anti-pick | Say what you would *not* chase: for example, partner count as the 18-month headline metric. The pack's observation is that your own headline in F1 is a partner count ("from 6 partners to 40"). If you use this anti-pick, expect the panel to notice. The honest line keeps F1's quote at its scope, then says what you'd measure here instead | [generic] |

## 5. Persona table

The recruiter's email establishes this session as one 60-minute panel: a POV, then Q&A. The weights rest on that, not on an archetype. I found nothing about the interviewers beyond their roles and the recruiter's note.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Deepa and Ross pull your POV into live problems: choose, prioritise, measure | Highest. Deepa is the hiring manager, and the POV invites "now do it" follow-ups | Clarify, then objective, approach, metrics, risks. Think aloud. Challenge one premise per case, politely |
| B. Skeptic | Quiet probing of F4 and F5, the gaps you stated | High. A hiring manager derisks gaps, and these two are visible in your background | Rehearse the objection until it's boring. Plain acknowledgment, the quote at its scope, then a ramp plan |
| C. Data-Driven Prober | Ross on the £4M and the 40: inputs, denominators, splits | High. The recruiter said Ross "will push on commercials" | Know what you can and can't say about how each number was counted, and name your weakest assumption first |
| D. Pressure | Time-boxed or devil's-advocate challenges, probably from Ross | Mid. "Push" suggests it. A Commercial Director is near the executive end of the panel | Pause, restate, hold through two follow-ups, then concede the specific uncertainty |
| E. Conversational | The opener and casual asides about the report | Low, but the opener is scored | A pre-scripted 90-second arc |
| G. Values/Behavioral | Scenario probes | Low. No values round was detected and no published values were available | Selection scaffolds with honest branches |
| H. Peer Evaluator | Where partnerships meets Ross's commercial team, and who gets credit | Low to mid. Two functions are sitting on one panel | Propose principles for the seam rather than guessing where it sits |

## 6. Question banks

**Highest-ROI prep in this pack: B1.** The quota objection will arrive in some form, from Ross or from Deepa.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Of everything you've just said, what's the one move you'd make in your first 90 days, and what would you need to know first?" | CASE | [generic] | Name the move. Name two things you'd need to learn first and who you'd learn them from. Say what "worked" would look like at day 90 for an operator and for Kelverton, and the main risk. No claim about your past is needed | It's the natural first follow-up to an 18-month POV, and it tests whether you can prioritise. CASE because it's a live problem in the role |
| A2 | "Broaden the number of operators we partner with, or go deep with two or three — which, and why?" | CASE | [generic] | State your choice in one sentence, give the condition under which you'd flip it, and say what each option means for operators and for revenue. Concede the other option's strongest point | This tests the core trade-off behind T1. CASE delivery, with JD content from the recruiter's "operator partnerships" (F1's requirement) |
| A3 | "An operator wants a bespoke feature as the price of being a reference partner. What do you do?" | CASE | [generic] | Clarify what the feature is, whether other operators would want it, and its cost. Then options: decline, generalise it into the roadmap, or trade it for explicit terms. Name who you'd bring in, which is product and Ross's team, and what you'd record | It's a commercial trade-off of the kind the recruiter said Ross will push on (F3's requirement). It presupposes nothing about your past |
| A4 | "How would you know at month 18 that operator partnerships are working?" | CASE | [generic] | Give two or three measures: one operator-side, one commercial, one leading indicator. Say why partner count alone isn't enough, which ties to your anti-pick. Say how often you'd review them | Every POV gets asked about measurement. It also sets up the anti-pick in section 4 and pre-empts C4 |
| A5 | "What in our market report would you push back on?" | CO | [generic] | Selection scaffold: one finding you'd question, why, and what evidence would change your mind. Credit the report by name. If nothing in it strikes you as wrong, say so plainly, then name the assumption you'd most want to test | The panel circulated the report, so a divergence from it scores as judgment where recital scores as homework. CO because it tests altitude |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. Why should we trust you with a commercial number?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | **Highest-ROI rehearsal.** Open with the plain acknowledgment, without apologising: "I've never carried a direct quota; my number has been influenced revenue: roughly £4M." Answer slot: Ross's commercials focus makes a probe on deal terms likely. If you worked on pricing or terms with partners, say what and how in your own words. If that wasn't yours, say so plainly and return to the influenced revenue. Then the plan, said as a plan: how you'd want the number counted here, and what you'd need to own one. Follow-up 1, "So who actually closed?": answer at the quote's scope. Follow-up 2, "Would you take a quota?": answer with your real preference. Hold through both, and concede only what F4 states | F4 is the most visible gap, and a Commercial Director is the likeliest person to press it. Deepest rehearsal because it will be asked. JD because it scores the commercial ownership of a senior role |
| B2 | "You haven't sold into rail. What makes you think you can partner with train operators?" | JD | [grounded] "Never sold into rail specifically"; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Open with: "I haven't sold into rail specifically." Then the consulting years at the quote's scope: bus and light rail network planning, from the other side. Keep "the other side". Don't upgrade it to having worked inside operators. Then a ramp plan: who you'd talk to first and what you'd read. Stop there | F5 is stated and obvious. F2 is the only adjacent material, and it's where you'll be tempted to stretch. JD because it scores sector fit |
| B3 | "Why leave payments for rail-tech, and why now?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "last 4 at a payments company running the ISV channel" | Your sequence can be stated from the quotes: transport consulting, then four years running the ISV channel. Answer slot: the reasons are yours, and your message doesn't state them. Give the real ones in your own words. Don't adopt a "returning to transport" story unless that's actually why | Motivation consistency is a standard Skeptic probe. The career sequence is quotable, but the motive isn't, so it's a slot |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one of the two gaps you stated. Use its plain acknowledgment from F4 or F5 and pair it with a concrete 90-day plan. Calibrated candor beats a disguised strength | This is a persona stem, and F4 and F5 give you honest material to answer it with. It doubles as a check on whether your story stays consistent with B1 |

### C. Data-Driven Prober (likely Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Keep "roughly" and "influenced". Answer slots, in your own words: how the figure was counted, what it's sensitive to, the assumption behind it you'd defend least (say that one before he finds it), and which part was yours. If you don't know how it was counted, say so plainly. Don't attach a period to the figure unless you know it | F3 is a headline metric and Ross is pushing on commercials, so it's a defend-the-number question. EXP because it tests attribution |
| C2 | "Of the 40 partners, how much of that revenue came from how many?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: this is the sensitivity of the figure to its partner mix. If you know the split, give it in your own words. If you don't, say so plainly and stay with the quote | Denominator probes follow headline numbers. F1 and F3 together invite it |
| C3 | "What did it cost to sign and support a partner, against what they brought in?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: Ross's commercials push raises partner economics. If you tracked cost per partner, say how, in your own words. If there was no such tracking, or it wasn't yours, say so plainly and return to the growth and the influenced figure | This is unit economics, the Commercial Director's native language. The premise isn't in your quote, so the slot allows that it's false |
| C4 | "If we gave you a partnerships budget, how would you decide what an operator partnership is worth to us?" | CASE | [generic] | Structure: the value to Kelverton (revenue, references, product learning), the cost (people, discounts, bespoke work), the time horizon, and the threshold at which you'd walk away. Ask one clarifying question first | It takes F3's requirement forward into the role. CASE because it's a live problem, and it presupposes nothing about your past |

### D. Pressure (likely Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's sold into rail for ten years?" | JD | [grounded] "Never sold into rail specifically"; "9 years in partnerships"; "took it from 6 partners to 40" | Pause and don't rush. Concede first: "I haven't sold into rail specifically." Then hold on what the quotes carry: nine years in partnerships, and a channel you took from 6 to 40. End on one line about what you'd bring to the POV's plan. Hold through two pushes. Don't fold on the partnership record, and don't claim rail knowledge you didn't state | F5 under time pressure. It scores composure and the hold-then-concede structure |
| D2 | "That 6 to 40 — how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40" | "Took it" is your phrase, so stand on it. Answer slot: which part was yours. Say who else was involved, in your own words. If the starting 6 existed before you, say so, and never imply you started from zero. Hold, then concede exactly what wasn't yours | An attribution probe on F1's headline. EXP because it scores what was actually you |
| D3 | "This all sounds expensive. Cut it to the one thing you'd fund." | CASE | [generic] | Pause. Name the one move, why it pays back first, and what you'd drop. Don't defend all three moves | It tests composure on your own POV. A live problem with no past claim |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "9 years in partnerships"; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc in order: transport consulting on bus and light rail planning, then four years running the ISV channel from 6 to 40 partners and roughly £4M influenced, then one line on why this role (your words, see B3). Say "influenced". Don't upgrade it to sold or closed | Openers are scored for economy. This one fixes your framing before the gaps come up |
| E2 | "What did you make of the market report?" | CO | [generic] | It's casual, but treat it as scored. One thing you agreed with, one thing you'd question, both credited to the report. Keep it under a minute | The panel's own document, asked lightly. It's an easy place to recite, and reciting is the miss |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you put a partner's interest ahead of an internal metric." | VAL | [generic] | Selection scaffold: it needs a named stake, a metric you knowingly gave up, and an outcome you can state honestly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | This is a persona stem, and the recruiter's operator close makes it relevant. No published values were available, so it's generic |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: what the truth was, who heard it, what changed, and an intact relationship afterwards. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A persona stem that commonly comes up for senior hires. Generic |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where's the seam between partnerships and the commercial team, and what happens when we disagree on a deal?" | CASE | [generic] | Propose principles rather than guessing at the org chart: who owns the operator relationship, who owns terms, how a disagreement gets escalated, how both teams get credit. Ask Ross how it works today | Ross and Deepa sit on adjacent functions, so the seam is live. CASE because it's a design problem in the role |
| H2 | "How do you handle credit when work spans partnerships and sales?" | EXP | [grounded] "only influenced revenue" | Your number has been influenced revenue, so this is close to home. Answer slot: if you agreed how influence was credited with a sales team, say how, in your own words. If there was no such arrangement, say so plainly, then say how you'd want it set up here | It's a persona stem, and F3's "influenced" makes it pointed. It links to the reverse question for Ross |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 operator partnerships, 18 months | Section 4, A1, A2, A4, D2, C2 |
| F2 what it means for operators | Section 4, A2, A3, B2 |
| F3 commercials | B1, C1, C3, C4, A3, H2 |
| F4 direct number | B1, B4 |
| F5 rail selling | B2, B4, D1 |
| F6 seniority | E1, D1 |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Ross: "How do you want partnerships' contribution counted here: influenced, sourced, or a direct number?" | It meets F4 head-on as diligence rather than defence, and it tells you what you'd actually be measured on |
| R2 | To Deepa: "In what I presented, what would you push back on first?" | It invites the challenge while you're still in the room and shows you can be coached |
| R3 | To Deepa: "What would make the first 18 months of this role a success in your eyes?" | It tests your POV against her real expectations and comes from your future manager |
| R4 | "Is there a revenue target attached to this role, and if so, how was it set?" | It resolves the biggest open question about the role, and the answer is yours to weigh before accepting |
| R5 | To either: "Where do operators feel the most friction working with Kelverton today?" | It keeps the operator focus the recruiter asked for and gives you material if there's a later round |
| R6 | To Ross: "When partnerships and your team disagree on a deal, how does it get resolved today?" | It's a reciprocity question on the seam (H1), and it shows you're thinking about his team's load |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried, hit or beat a quota | You stated the negative (F4) | The plain acknowledgment: "I've never carried a direct quota; my number has been influenced revenue." |
| Generated, closed or sold £4M | An inflated form of F3. Contradicted by "only influenced revenue" | F3's quote: "roughly £4M of influenced revenue". "Roughly" and "influenced" both stay |
| £4M a year, or any period attached to the £4M | An inflated form of F3. Your message states no period, and ambiguity resolves downward | The quote with no period, unless you know the period |
| Has sold into rail, or has rail-sector experience | You stated the negative (F5) | The plain acknowledgment: "I haven't sold into rail specifically." |
| Knows train operators from the inside, or worked for or with TOCs | An inflated form of F2, widening both the scope (bus and light rail to rail) and the relationship (consulting side to operator side) | F2's quote at its own scope. The pack's observation: your material says bus and light rail planning, from the other side |
| Built the ISV channel from scratch | An inflated form of F1. Your material says 6 partners at the start | F1's quote: "took it from 6 partners to 40" |
| Presenting the market report's findings as your own analysis | A claim the report contradicts, since it's Kelverton's own document | Credit the report by name every time you use it |

## 9. Sources

- **Provided:** your message, including the recruiter's email quoted in it. The market report was named but not shared with me, so none of its content is used.
- **Searches sent, all refused** by this session's permissions:
  - "Kelverton Rail values": refused
  - "Kelverton Rail interview process partnerships": refused
  - "Kelverton Rail scheduling software train operating companies news 2026": refused
  - "Deepa VP Partnerships Kelverton Rail": refused
  - "Ross Commercial Director Kelverton Rail": refused
  - "\"Senior Partnerships Manager\" rail software job description train operating companies": refused
- **Fetches:** none.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The call was refused. It would have themed G1 and G2 on published values. No values section exists without it |
| 2. Kelverton Rail interview process | unavailable | The call was refused. The recruiter's email already establishes Tuesday's session. This search would have shown the wider loop and whether a values round exists |
| 3. Kelverton Rail strategy and recent news | unavailable | The call was refused. It would have moved A5, E2 and the POV theses from generic to grounded |
| 4. Deepa / Ross at Kelverton Rail | unavailable | Both calls were refused. They would have added an interviewer read, adjusted the persona weights, and given a reverse question tied to each person's career path |
| 5. Representative Senior Partnerships Manager JD | unavailable | The call was refused. It would have moved the F4–F6 requirements from generic patterns to quoted, inferred requirements |

## 10. Upgrade menu

- **The job description text:** quoted requirements replace the generic rows F4–F6, and the coverage table gets checked against Kelverton's own list.
- **The market report's key findings, pasted or summarised in your words (it's an internal document, so that's your call):** adds a grounding-brief section, and turns A5, E2 and the POV's consensus and divergence rows from scaffolds into specifics.
- **Web search allowed in this session:** Kelverton's values, strategy and news, plus Deepa's and Ross's public professional profiles. That adds an interviewer read, tailored reverse questions, and grounded CO questions.
- **A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and it needs search allowed):** a strategy brief and recent org context for the POV.
- **Your CV:** more of your own sentences to quote, so the scaffolds in B3, G1 and G2 can become story-mapped answers.
- **What you know about how the £4M was counted, and the partner split:** C1, C2 and C3 become story-mapped instead of slots.
- **A tuesday-dossier.md from job-underwriter:** the top objection would be derived from evidence you'd confirmed, rather than inferred here, and each weak area would come with an agreed strategy.
