Read the prep playbook; now running a quick research pass on Saltmarsh Games and Tobias Wrenfield before building your pack.
Your prep pack for Friday is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. The web searches I tried were blocked by this session's permissions, so it's built only from the JD and your background, and it doesn't cover Saltmarsh's values, their interview process or Tobias's career.

- **Assumption:** I treated this as a hiring-manager conversation, since he heads the team you'd join. If that's wrong, the persona weights change.
- **Tonight's list:** your interview is tomorrow, so the pack opens with a short list for this evening, starting with the question worth the most practice.
- **Highest-ROI question (B1), "Have you run events on a game with in-app purchases?":** the job description doesn't mention it, but at a mobile studio it's the likeliest probe. The pack rehearses a plain "No, I haven't" first, then what you have done, then how you'd learn it.
- **Inflation risks:** these are listed as claims the pack won't coach: one title becoming two, presenting retention numbers becoming owning the KPIs, writing the checklist becoming managing QA, and "associate" disappearing from your title.

If you allow web search, I'll rerun the research and add Saltmarsh's values, their interview process and a read on Tobias. The upgrade menu at the end of the pack covers what else would improve it.

Say the word and I'll play the Skeptic on B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and is this your only round? Did the recruiter mention any case exercise or written task? Either answer changes how the pack is weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Your message didn't say how he relates to the role, so this pack assumes **a hiring-manager conversation**, which is likely for the head of the team this role sits in. If that's wrong, the persona weights change.
**Format:** 60 minutes, Friday.
**Research:** none ran. All four web searches were refused by this session's permissions (see Sources), so nothing here comes from Saltmarsh's own pages. Anything about the company is either a quote from the JD you pasted or labelled `[generic]`.

---

## How to use this pack

Two axes. **Personas** describe *how* a question is asked: the style and pressure of the person asking. **Types** describe *what* is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's values (generic here, since no values page was read) |
| EXP | Whether the claims about your experience hold up, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy (none in this pack, because no research ran) |
| CASE | A live problem from the role, solved out loud |

Provenance labels: `[grounded]` means traceable to your message or the JD. `[inferred]` means derived, with the derivation named. `[generic]` means a role-family pattern with no claim about Saltmarsh.

**The guidance is scaffolding, not a script.** Where a cell quotes your own sentence, that sentence is the limit of what the answer claims. Where it says *Answer slot*, the pack doesn't know the answer. Answer from what actually happened, and if it didn't happen, say so.

---

## Prep triage: tonight, before Friday

Your interview is tomorrow, so this is sized to one evening. In order:

1. **B1, out loud, three times.** This is the highest-ROI prep in the pack. Get the first sentence boring and steady.
2. **D1, your 90-second journey.** It opens most hiring-manager conversations and sets up everything after it.
3. **A1 and A2.** The two cases closest to the core of the JD: building the calendar and diagnosing an event.
4. **A4.** Sketch a post-event review outline on paper. It covers both "own the post-event review" and "clear written communication".
5. **C1.** Be ready to say what your retention numbers measured, and where they came from.
6. **Pick three reverse questions** from section 11 and write them down.
7. **If you can, play both Saltmarsh titles tonight,** even for 20 minutes each. It feeds D2 and every case question with something real.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Adjacent, and two steps short. Your material covers one title, and it calls them content drops, not live events. Words at their own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "plan and run" makes a probe on the planning side likely. If choosing what went into the drops, or when, was yours, say which parts and how you decided, in your own words. If it wasn't, say so plainly and stay with running the calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show cross-team coordination either way. Answer slot: if running the content-drop calendar meant working with design, art, engineering or community on a drop, say which teams and what you did with them, in your own words. If it didn't, say so plainly and say how you'd approach it |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a post-event review, but it isn't the same thing. Words at their own scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you also prepared those numbers or chose what went into them, say which, in your own words. If someone else built them, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Close, but writing a checklist and managing it each release are different jobs. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran it with QA on releases, say how, in your own words. If running it was QA's, say so plainly and stay with having written it. A redacted copy would raise this row's confidence |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | low | [inferred] | discovery | The years clear the bar, which is not a gate (it's graded like any other requirement). What your material doesn't say is whether the game was live-service, or mobile. Answer slot: if the title was live-service, say so and in what sense, in your own words. Same for mobile. If either isn't true, say so plainly and stay with the four years and the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. It's your own statement with nothing inspected behind it, though, so expect a probe. Lead with it as you said it: weekly, main title, last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Your quote reaches the requirement. Expect a probe on what the numbers measured. That probe is C1's answer slot. Don't name metrics you didn't use |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist a team still uses is one piece of written work. This role's writing (post-event reviews, update coordination) is wider than that. Answer slot: if you wrote other recurring documents in the role, name them, in your own words. If not, say so plainly and stay with the checklist |
| F9 | Monetized live events: event offers, in-app purchase economics. Not in the JD; a role-family pattern for mobile live ops | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap that wording can't close, and you've said so yourself. Words: "I haven't worked on a game with in-app purchases." Then how you'd learn it, said as a plan and never as past experience. Don't add anything to make it sound smaller |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A1, A5, B5 |
| Coordinate design, art, engineering and community (F2) | A3, B2, B4, G1, G2 |
| Own the post-event review and its KPIs (F3) | A2, A4, C3 |
| Manage the release checklist with QA (F4) | E1, A3 |
| 3+ years producing live-service games or apps (F5) | B3, D1 |
| Running a content calendar (F6) | A1, B2 |
| Player-retention metrics (F7) | C1, C2, C3 |
| Clear written communication (F8) | A4 |
| Monetized events, not in the JD (F9) | B1, E2 |

---

## Persona table

No source tells us how Saltmarsh runs this interview, so the loop falls back to the **Generic** archetype (screen, then hiring manager, then panel). That archetype gives flat weights, which means these weights rest on a pattern and on the assumed hiring-manager relationship, not on Saltmarsh's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | "Plan this calendar", "this event underperformed, why?" | High, 5 questions. The hiring-manager prior is case-heavy, and the JD is almost entirely operational problems | Clarify, then objective, then structure, then approach, then metrics, then risks. Think aloud. Challenge one premise respectfully |
| Skeptic (B) | Quiet probes on the two-titles step-up, the cross-team scope and monetization | High, 5 questions. The hiring-manager prior, plus a fit snapshot with three transferability rows and one capability row | Rehearse B1 until it's boring. Bridges only from your own quoted sentences. Say limits plainly. Give a concrete ramp plan |
| Data-Driven Prober (C) | "What did those retention numbers measure?" | Medium, 3 questions. The JD names retention metrics and KPI ownership, and you say you presented retention numbers | Know what you can and can't say about how the numbers were built. Say plainly when you don't know |
| Conversational (D) | The friendly opener and "why us" | Medium, 3 questions. Almost every 60-minute conversation opens this way, and it's still scored | Have a prepared 90-second arc. Treat casual questions about live ops as scored |
| Pressure (E) | "How much of that was actually you?" and time-boxed comparisons | Low, 2 questions. Not the hiring-manager default, but the associate title invites attribution probes | Pause, then anchor in what you actually said. Hold through two follow-ups, then concede only what's real |
| Peer Evaluator (G) | Where the seams are between community and engineering, and who gets credit | Low, 2 questions. The JD's four-team coordination line makes seam questions likely even from a manager | Propose principles for the seams rather than pretending to know Saltmarsh's |
| Values / Behavioral (H) | "Tell me about a time…" | Low, 2 questions. No values round was detected and no values page was read, so these are `[generic]` | Pick specific stories. Use "we" for context and "I" for your contribution |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You'd be running live events for two titles. Sketch how you'd build next quarter's calendar. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: each title's audience and current cadence, last quarter's event results, fixed dates (seasonal moments, platform or store features), and which teams the two titles share. Then the objective for each title, the structure (tentpole events against recurring beats, no collisions on shared art or engineering weeks), lead times working back from release including QA, how you'd judge each event, and the risks. One line from your own experience if it helps: "I ran the weekly content-drop calendar for our main title for the last two years." Don't describe how that calendar was built unless you're answering from memory | The JD's first line, and F1 is where your evidence is adjacent rather than direct. CASE because it's a live plan, and JD because it scores the headline responsibility |
| A2 | "An event's day-one participation is 20% below the last comparable one. Diagnose it." | CASE | [generic] | Rule out measurement first: did tracking or a definition change? Then segment it: which title, platform, region, new against returning players. Then exposure: was the entry point visible, did notifications go out? Then the content: difficulty, reward value, length. Then external factors: a competing event, an outage, a store change. End by separating what you'd change mid-event from what goes into the review. Say which hypothesis you'd test first and why | Feeds the JD's "own the post-event review". `[generic]` because it's a pattern problem with no claim about Saltmarsh's data |
| A3 | "Art tells you the event's key assets will land four days late. Release is in nine days. What do you do?" | CASE | [generic] | Facts first: which assets, what's partially done, what can ship without them. Options: descope, reuse existing art, move the date, or swap this event with a later one on the calendar. Protect QA's time, because squeezing QA is the hidden cost. Be clear who makes the call and who you tell, including community if the date moves. The question needs no claim about your past, so don't make one | Tests the JD's coordination line (F2) and release discipline (F4) as a decision, not as a record |
| A4 | "The event closed yesterday. Talk me through the review you'd send the studio this morning." | CASE | [generic] | Headline result in one sentence. KPIs against the targets set before launch. What worked, what didn't. Player sentiment from community. Incidents and bugs. Decisions for the next event, each with an owner. Keep it to a page. Say that the targets have to be agreed before the event, or the review has nothing to measure against | Covers "own the post-event review" (F3) and "clear written communication" (F8) together. CASE delivery on JD content |
| A5 | "An event on each title needs the same engineering week. How do you decide?" | CASE | [generic] | Compare expected KPI impact, how reversible a slip is for each, dependencies such as marketing beats or store features, and whether one event can be cut down. If it's a priority call above your level, name who decides and bring them a recommendation rather than a question | The two-titles part of F1 is the step up from your material. This tests whether you can trade off across titles |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you run events on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "Presented the monthly retention numbers to the studio head."; "I ran the weekly content-drop calendar for our main title for the last two years." | **The highest-ROI rehearsal in this pack.** Answer first, plainly, with no throat-clearing: "No. I haven't worked on a game with in-app purchases." Then what you have done, from your own sentences only: the weekly content-drop calendar on your main title for the last two years, and presenting the monthly retention numbers to the studio head. Then the ramp, said as a plan: read the last few post-event reviews, sit with whoever owns the event economy, and learn how offers are scheduled against the calendar. **Follow-up 1**, "Isn't that a big gap for mobile live ops?": concede it's real and don't shrink it. Hold that the calendar and the retention reporting are what you've done. **Follow-up 2**, "How fast could you close it?": give the plan again with no invented timeline. Never suggest that the puzzle game had anything resembling purchases | F9 is the gap you named yourself, and it's the one no wording closes. The JD doesn't mention monetization, but `[generic]` mobile live-ops roles commonly tie events to revenue, so it's the likeliest probe. EXP because it tests what you've actually done |
| B2 | "This role coordinates design, art, engineering and community on every update. Tell me about a time you got several teams to land one date." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | If there's a story, it's from the calendar: weekly drops, your main title, the last two years. Answer slot: the JD's coordination line makes this probe likely. If a particular drop involved working across design, art, engineering or community, pick it and say who was involved and what you did, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | F2 has no evidence either way. Rehearse it so the honest answer is ready before the probe. JD because it scores a stated responsibility |
| B3 | "Your title was associate producer. What did you own, and what did you support?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | Name the three things in your own words: you ran the weekly content-drop calendar, you wrote the release checklist QA still uses, and you presented the monthly retention numbers to the studio head. Answer slot: where a decision in any of these was someone else's (what went into the drops, for example), say whose, plainly. The interviewer will trust the rest more for it | The associate title invites an attribution probe, and F1, F3 and F4 all rest on this split. EXP because it tests what was actually yours |
| B4 | "You've never led a team. How will you get four teams moving on every update?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't led a team." Then the role as the posting describes it, which is coordinating design, art, engineering and community on each update. Then the slot from B2: if you've coordinated across teams, say so in your own words. If not, say how you'd approach it (a shared calendar, clear dates, agreed owners). Never call anything you did leadership in an informal sense | A negative you stated yourself, so it may come up. The JD asks for coordination, not line management. JD because it scores F2 |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick a real one. Your material points to two candidates: running across two titles (yours was "our main title") and owning a post-event review (F3). Answer slot: choose the one that's honestly true, say why in your own words, and pair it with what you'd do in the first month. Don't pick a fake weakness | A standard Skeptic stem. F1 and F3 are the honest answers to it |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to the studio head. What did they measure, and where did they come from?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start from the quote: monthly retention numbers, presented to the studio head. Answer slot, in your own words: how the numbers were counted, what they were sensitive to, the assumption behind them you'd defend least, and which part was yours. If you didn't build them, say so plainly ("I presented them; X built them") and say what you did with them | F7 is your strongest metric line, which makes it the likeliest target for a prober. EXP because it tests attribution |
| C2 | "Tell me about a time a retention number changed what went into your content calendar." | EXP | [grounded] "Presented the monthly retention numbers to the studio head."; "I ran the weekly content-drop calendar for our main title for the last two years." | Pick an instance where a number led to a calendar decision. A good answer needs the number, the decision, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd use a retention number to plan | Connects F6 and F7, which is the exact loop the JD describes. It's an open prompt, so it supplies no event |
| C3 | "How would you tell whether an event worked?" | CASE | [generic] | Define success before launch: participation, completion, retention against a comparable baseline cohort, and player sentiment. Then name your weakest assumption yourself: that the baseline period is genuinely comparable (seasonality, other events). Saying it first earns credibility | The JD's "KPIs it reports" (F3). CASE because it's reasoning, not record |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | Ninety seconds: four years as an associate producer at a puzzle-game studio. For the last two you ran the weekly content-drop calendar for the main title. You wrote the release checklist QA still uses, and you presented the monthly retention numbers to the studio head. Answer slot: why this role, now, in your own words. Stop there and let him pick a thread | Opens most hiring-manager conversations and sets the frame for B1 to B5. EXP because every clause will be probed later |
| D2 | "Why live ops, and why Saltmarsh?" | CO | [generic] | Answer slot: your own reasons for moving toward live ops. For Saltmarsh, name something you saw in their games; if you play both titles tonight, use that. Don't cite company facts you haven't read, because no research ran for this pack | Casual but scored. CO in theory, generic here because nothing about Saltmarsh was read |
| D3 | "What's a live event in another game you thought was really well run?" | JD | [generic] | Pick one you actually played. Say what made it work in operational terms: cadence, clarity of rewards, how it brought players back. Thirty seconds is enough | A common rapport question that quietly tests taste. JD because live events are the job |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the quote: you wrote it, and QA still uses it. Answer slot: if other people contributed sections or revisions, name them plainly. If running it on releases was QA's job rather than yours, say so. Through two follow-ups, return to what the quote says. Concede anything that wasn't yours, and don't fold on having written it | F4 is the closest match to a JD line, so it's the one to defend precisely. EXP, delivered under pressure |
| E2 | "Sixty seconds: why you over someone who's already run monetized events across two titles?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years." | Don't argue with the premise. Concede: "I haven't worked on a game with in-app purchases." Hold what you've done: the weekly content-drop calendar on your main title for two years. Then one sentence of why you, in your own words. Stop at sixty seconds | B1 under a stopwatch. It tests composure as much as content |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community hears about an event bug before engineering does. Where's the seam, and what do you do in the first hour?" | CASE | [generic] | Get the report to engineering with what's known, decide with them whether the event keeps running, and agree one message community can post. Then propose a principle for the seam: one channel for live-event issues, with a named owner during every event | The JD's four-team line (F2) seen from the seam. `[generic]` because nothing is known about Saltmarsh's setup |
| G2 | "An update lands well and four teams built it. How do you handle credit?" | JD | [generic] | Name the teams specifically in the review, credit the people who unblocked things, and keep your own part to what you did. An open prompt, so if a real example comes to mind, use it; if not, say how you'd do it | Collegial packaging of the coordination question (F2) |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Pick an instance. It needs a named stake, the moment you said it, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A common behavioural stem. `[generic]` because no Saltmarsh values were read |
| H2 | "Tell me about a release that went wrong and what you changed afterwards." | VAL | [generic] | Pick an instance where something you worked on went wrong. Say what happened, your part in it, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Release discipline sits behind the JD's QA line (F4). Asked as a story, not a record |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a good post-event review look like here? Is there one that changed the next event?" | It's the deliverable you'd own (F3), and his answer tells you which KPIs actually matter, monetization included |
| "Are the two titles planned on one calendar or two, and where do they collide today?" | It shows you've read the two-titles line and thought about shared teams (F1) |
| "Which KPIs does the review report, and who sets the targets?" | It finds out whether events here are judged on revenue as well as retention, without you having to guess (F9) |
| "As Head of Live Operations, what would you most want this person to have taken off your plate by month three?" | It ties to his role, and the answer is your 90-day plan |
| "Is the release checklist with QA something this role inherits or builds?" | It connects to the thing you've already done (F4) without overselling it |
| "How does community feed into event planning before launch, not just after?" | It shows you see community as an input, which is the seam G1 tests |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated: "Never led a team, and never worked on a game with in-app purchases." | "I haven't led a team." |
| Has worked on a game with in-app purchases or monetized events | A negative you stated, the same sentence (F9) | "I haven't worked on a game with in-app purchases." |
| Ran live events or a calendar across multiple titles | Inflated form of F1 | F1's quote at its own scope. The pack's own observation is that your material says "our main title", which is one title. A1 and B5 stay inside it |
| Owned the post-event review or the retention KPIs | Inflated form of F3 and F7 | F3's quote at its own scope: you presented the monthly retention numbers. C1's slot asks only what they measured and which part was yours |
| Managed the release process or the QA team | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist QA still uses. E1's slot asks only who else contributed and who ran it |
| A producer or lead-producer title | Inflated form of "4 years as an associate producer at a puzzle-game studio." | The title as you gave it: associate producer |

---

## Sources

- **Provided:** your message, which contained the JD text and your background.
- **Searches sent, all refused by this session's permissions:**
  - `Saltmarsh Games values`: refused
  - `Saltmarsh Games interview process live operations producer`: refused
  - `Saltmarsh Games mobile studio news 2026`: refused
  - `Tobias Wrenfield Saltmarsh Games`: refused
- No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Refused. It would have supplied the values cheat sheet and grounded H1 and H2 in named values |
| 2. `Saltmarsh Games interview process` | unavailable | Refused. It would have replaced the Generic archetype with Saltmarsh's actual rounds and reweighted the personas |
| 3. `Saltmarsh Games` strategy / recent news | unavailable | Refused. It would have supplied a CO question on current priorities and made D2 specific |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Refused. It would have supplied an interviewer read and a reverse question tied to his career path |
| 5. representative Live Operations Producer JD | skipped | The JD you pasted already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your relationship to Tobias, and the round type** (is he your future manager, and is this the only round?): reweights every bank, and might add a peer or panel bank
- **The recruiter's prep note, if any** (focus areas, any case exercise or written task): adds a build section for any declared deliverable. Usually one email
- **Allowing web search in this session:** reruns targets 1 to 4 and adds the values cheat sheet, Saltmarsh's actual loop, a company-strategy question, and an interviewer read with a reverse question from his public career path
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes), only if search is allowed: a strategy brief on Saltmarsh's titles and recent moves, which turns A1 and A5 into title-specific cases
- **The names of the two titles:** lets A1, A2 and A5 use real event examples
- **Your answers to the slots in F1, F2, F3, F5 and F8:** each answer you give here, outside a drill, goes into the fit snapshot as your own words and upgrades B2, B3, C1 and E1
- **A redacted copy of the release checklist:** an inspectable artifact that would raise F4 and F8 from medium to high confidence
- **A tuesday-dossier.md from the job-underwriter module:** would carry verified evidence and an evidence-derived top objection, where this pack inferred B1
