Your prep pack is saved as `stripe_product-operations-manager_interview_pack.md`. I built it from your message alone, with no job description, no CV and no web research, because every web search was blocked in this session. That makes it a worksheet version: 20 practice questions, each telling you how to choose a story rather than which story to tell, plus a fit snapshot for you to fill in. Persona weights are flat because I couldn't find out how Stripe runs its final round.

Say the word and I'll play the Skeptic on A1, which the pack names as the most valuable thing to rehearse.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final: how many sessions, and is each person your future manager, a peer, a skip-level or someone from another team? Also, did the recruiter name focus areas or ask you to bring a case, presentation or take-home? The answers change how heavily each type of interviewer is weighted, and any prepared assignment gets its own section.
2. Can you paste the job description and your CV, or a short summary of your background? If you'd rather not, the pack still works as is. With them, each practice question gets built around your own experience.
3. Would you like to allow web search so I can look up Stripe's published operating principles, its interview process and its recent strategy? That adds a principles cheat sheet and questions about Stripe itself.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — final-round prep pack

Final round. Interviewer names and their relationship to the role are not known yet. This first version was built from your message alone: no job description, no CV, and no web research (every search was refused in this session; see Sources).

## How to use this pack

Two axes. **Personas** describe how a question is asked: who is asking, and in what style. **Types** describe what is being scored.

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values, not generic virtue |
| EXP | Whether your own experience stands up to scrutiny, and what was actually you |
| JD | Whether you can do the job as listed, gaps included |
| CO | Homework depth: the company's strategy, competition and recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. This version has nothing about your background to work from, so every guidance cell tells you how to **choose** a story, not which story to tell. Each one ends with an honest branch for when no such story exists. Question IDs run A to H. The letter F is skipped so question IDs never collide with the fit-snapshot rows F1 to F7.

Because nothing about you is in the pack yet, use it in this order: fill in the fit snapshot below from your own experience, then rehearse the banks out loud.

## Fit snapshot (self-assessment worksheet)

No job description was supplied and research could not run. The requirements below are therefore typical of product operations roles in general. They are not taken from Stripe's posting, so they are plain prose labelled `[generic]`. Every evidence cell reads `none given` because no background was shared. Fill in each row with a sentence you would stand behind in the room.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Partnering across product, engineering, support and go-to-market teams, typical of product operations roles | none given | none | [generic] | discovery | Strong evidence looks like a named cross-team piece of work, the teams involved, what was yours, and how a disagreement got resolved. Selection scaffold: pick a time you got work done that needed teams who didn't report to you. It needs a named outcome and your part in it. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F2 | Getting products and features operationally ready to launch, typical of product operations roles | none given | none | [generic] | discovery | Strong evidence looks like a specific launch, what readiness meant there, and which part of it was yours. Selection scaffold: pick a launch or rollout you were part of. It needs what had to be ready, who depended on it, and what you did. If no such launch comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would approach one |
| F3 | Turning customer and frontline feedback into input the product team can act on, typical of product operations roles | none given | none | [generic] | discovery | Strong evidence looks like a feedback source, how it was gathered or sorted, and what changed because of it. Selection scaffold: pick a time feedback from users or frontline teams reached a decision-maker through you. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would set it up |
| F4 | Designing processes and scaling operational workflows, typical of product operations roles | none given | none | [generic] | discovery | Strong evidence looks like a before and after for one process, and what part of the change was yours. Selection scaffold: pick a process you changed or built. It needs the problem it solved and how you knew it worked. If no such process comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would approach it |
| F5 | Defining and tracking operational and product health metrics, typical of product operations roles | none given | none | [generic] | discovery | Strong evidence looks like a metric you used, how it was counted, and a decision it changed. Selection scaffold: pick a number you tracked or reported. It needs to be one you can explain how it was counted, or you say plainly that you don't know. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would choose one |
| F6 | Driving multi-team projects to a deadline, typical of product operations roles | none given | none | [generic] | discovery | Strong evidence looks like a project, the deadline, what slipped or held, and what you did about it. Selection scaffold: pick a project where you were responsible for keeping several people moving. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would run one |
| F7 | Clear written communication and documentation, typical of product operations roles | none given | none | [generic] | discovery | Strong evidence looks like a document others used: who read it and what it let them do. Selection scaffold: pick something you wrote that changed what other people did. If nothing comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would write it |

## Persona table

No source tells me how Stripe runs this final round, and "final round" alone doesn't establish it. The weights therefore use the **generic archetype**: flat weights. They rest on a general pattern, not on Stripe's documented process. Every persona is covered so you never meet a style for the first time in the room. Depth differs slightly: the Case persona gets four questions because live problems are the one type that can be rehearsed fully without your background. Values gets two because no values round was established and Stripe's published principles could not be read.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of gaps and motivation: why here, why now | Flat weight. Unknown relationship, so no prior raises or lowers it. It holds the pack's highest-ROI question (A1) | Rehearse the weakest-day-one answer until it's boring. Bridges come only from things you actually did, and where there are none, say the limit plainly and give a concrete ramp plan |
| Case / Strategist | Live product-ops problems: plan this, diagnose that | Flat weight, same reason. Four questions, since cases need no background | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise per case, respectfully |
| Data-Driven Prober | Asks for inputs, denominators, how a number was counted | Flat weight, same reason | Know what you can and can't say about how each of your numbers was counted. Name the weakest assumption before they do |
| Pressure | Interrupts, time-boxes, questions how much was you | Flat weight, same reason | Pause, restate, anchor in what you actually did. Hold through two follow-ups before conceding anything real |
| Peer Evaluator | Seams between teams, credit, what you'd need from them | Flat weight, same reason. Product operations sits between teams, so seam questions fit the role family | Talk about what you bring their team, not only what you need. Propose principles for the seam rather than pretending to know it |
| Conversational | Friendly openers that are still scored | Flat weight, same reason | A pre-built 90-second arc for "walk me through the journey". Treat casual questions as scored |
| Values / Behavioral | STAR stories against published values | Flat weight, but two questions only. No values round established, and the principles page couldn't be read | "We" for context, "I" for your part. Pick stories where the hard truth actually landed, and where none did, say so |

## Question banks

**Highest-ROI prep in this pack: A1.** Whoever you meet, some version of "where are you weakest for this role" is likely. With no background to read, the pack can't yet tell which gap an interviewer will aim at, so A1 rehearses the honest shape of the answer. Send your CV and this item is rebuilt around your real thinnest row.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick one requirement from the fit snapshot where your experience is genuinely thinnest. Not a disguised strength. Say it in one sentence. Then give your first-30-days plan to close it, said as a plan and never as a past. Rehearse two follow-ups. "Why that one?": one sentence on why it's the thinnest. "What's the closest thing you've done?": answer slot. If you've done something adjacent, name it in your own words and its limit. If you haven't, say so plainly and go back to the plan. Hold the plan through both follow-ups and add nothing to it | The most predictable objection to any candidate, and the one where a defensive answer costs most. JD because it scores your honest read of the listed job |
| A2 | "How would you handle the parts of this role you haven't done before?" | JD | [generic] | Name one or two concretely rather than saying "I learn fast". For each, say who you'd learn from, what you'd read or shadow, and how you'd know you were up to speed. Don't claim experience you haven't got in order to make a gap sound smaller | Skeptic stem, worded without assuming any specific gap. The pack doesn't know yours. JD because it scores readiness for the listed work |
| A3 | "Why leave where you are, why Stripe, and why now?" | CO | [generic] | Three beats, each in your own words. Why leave: what you want next, not what you're escaping. Why Stripe: something you've read or used yourself. The pack could not research Stripe, so this beat must come from your own homework, and you should know where you read it. Why now: what makes this the right moment for you. Keep it under 90 seconds | The Skeptic's motivation probe. CO content in Skeptic delivery, because a vague "why Stripe" is the clearest sign of thin homework |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We're launching a new feature in a few weeks. Sketch the launch-readiness plan. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, what changes for them, which internal teams are affected, what counts as a good launch. Then the workstreams: support readiness, documentation, internal enablement, the metrics to watch, a rollback or escalation path. Close with the top risk and how you'd spot it early. This asks about no past, so the guidance makes no claim about yours | Tests F2 and F6 as a live problem. CASE because it scores structure, not a record |
| B2 | "A product's weekly active usage dropped 20% last month. Diagnose it." | CASE | [generic] | First, is the drop real: did tracking or the definition change? Then segment: which users, regions or entry points, and when it started. Then line it up against what changed: releases, pricing, outages, seasonality. Name the two hypotheses you'd test first and the data that would separate them. Say what you'd tell stakeholders while you investigate | Tests F5. CASE because the scoring is in the order of reasoning |
| B3 | "Support, sales and product each tell you a different top problem for the same product. How do you decide what product hears first?" | CASE | [generic] | Get each problem stated in comparable terms: who it affects, how often, what it costs, and how it's evidenced. Look for overlap before ranking. Set out the criteria you'd rank on, then how you'd tell the two teams that didn't win, and how you'd revisit the call | Tests F3 and F1. CASE because it is a prioritisation problem set in the role |
| B4 | "A manual review workflow built for 50 requests a week now gets 500. What do you do?" | CASE | [generic] | Stabilise first: triage rules, what can wait. Then find where time goes, separate what needs judgement from what is repeatable, and decide what to automate, what to cut and what to staff. Name the metric that tells you it's working and the failure you'd watch for after the change | Tests F4. CASE because it scores how you scale a process, live |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs the stake, what you said, how it landed, and what happened after. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Values persona stem. VAL because it scores behaviour, not opinion. Not mapped to Stripe's principles, which could not be read |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where what was right for a user cost a number you or your team were measured on. It needs the trade-off, your part in the decision, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would weigh it | Values persona stem, and it fits F3's customer-feedback work. VAL for the same reason as C1 |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a result you'd put a number on. Walk me through how that number was counted." | EXP | [generic] | Selection scaffold: choose a figure you can actually explain. Answer slot, in your own words: how it was counted, what it is sensitive to, and which part of it was yours. If you don't know how it was counted, say so plainly. That is an honest answer. If you have no figure, say so and describe the result in plain terms | Prober stem. EXP because it tests whether your own numbers survive scrutiny |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Answer slot: name that assumption yourself, in your own words, before they push. If you can't name one, say so plainly, then say what you would check first | Prober follow-up stem. Naming your own weakest assumption turns a gotcha into credibility. EXP for the same reason as D1 |
| D3 | "How would you know whether a process you set up is working?" | CASE | [generic] | Name an outcome metric and one guardrail metric. Say how each is counted, the baseline you'd compare against, and how soon you'd expect movement. Name the one thing that would make you roll the process back | Tests F5 and F4. CASE because it asks about a hypothetical process, not your past one |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then two or three reasons drawn only from what you've actually done that maps to the role. Name them from your own fit-snapshot rows once you've filled them in. Concede what an internal candidate has, the context, then say what you bring. Stop on time | Pressure stem. JD because it scores fit against the listed job under a time limit |
| E2 | "That result you just mentioned: how much of it was actually you?" | EXP | [generic] | Hold, then concede. Restate your part precisely: what you did, what others did. Hold that through two follow-ups. If they push, concede the specific part that wasn't yours rather than shrinking or inflating everything. The share you claim is only what you did | Pressure stem. EXP because it scores attribution honesty |
| E3 | "Thirty seconds: the single biggest risk in the launch plan you just gave me." | CASE | [generic] | One risk, why it's the biggest, the early signal, the mitigation. Don't list five. Hold your pick if they challenge it, and concede only if they give you a reason | Time-boxed follow-up to B1. Tests F2 and F6 under pressure. CASE because it is a live problem |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Don't pretend to know their seam. Propose principles: who decides what, how disagreements escalate, and what you'd write down early. Then offer what you'd bring their team. Ask what currently breaks at the seam | Peer stem. Product ops sits between teams (F1). JD content, CASE delivery |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a cross-team piece of work where credit was shared. Say how you described your part and theirs. If no such time comes to mind, say so plainly, then say how you would handle it | Peer stem. EXP because it tests attribution habits |
| G3 | "You're changing a process three teams rely on. How do you tell them?" | CASE | [generic] | Who needs to know what, and when. A short written change note covering what changes, why, what to do differently and who to ask. A feedback window before it's final. A check after it lands | Tests F7 and F1 as a live problem. CASE because it asks about no past |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc you've built yourself: where you started, the two or three moves that matter for this role, and why product operations at Stripe is the next one. Only roles and moves you actually made, in your words | Conversational stem. Asked casually and still scored. EXP because it sets up every later probe |
| H2 | "What are you actually playing with in your work these days?" | EXP | [generic] | Selection scaffold: something you're genuinely trying or learning: a tool, a method, a problem. Say what you've tried and what you've learned so far. If nothing comes to mind, say so plainly and name what you'd like to explore | Conversational stem. Interest is scored even in a casual register. EXP because it asks about your current work |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Cross-team partnership | B3, G1, G3 |
| F2 Launch readiness | B1, E3 |
| F3 Feedback into product | B3, C2 |
| F4 Process design and scaling | B4, D3 |
| F5 Metrics | B2, D1, D2, D3 |
| F6 Multi-team project delivery | B1, E3 |
| F7 Written communication | G3 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What would a great first six months look like for this role?" | Shows you're thinking about outcomes, and gives you the yardstick you'd be measured by |
| "Which teams does this role work with most, and where does that work break down today?" | Shows you're thinking about the seams the role sits between (F1) |
| "How does feedback from users and frontline teams reach product decisions today?" | Asks about F3, the core of product operations work, in their own terms |
| "What's one process here you'd most like someone to fix?" | Invites a concrete problem you can respond to live |
| "How do you tell whether product operations is working well here?" | Shows you care how the role is measured, and links to F5 |
| "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for any peer you meet |

## Prohibited claims

No entries in this version. The list holds stretched versions of things you've told me, and things you've said you haven't done. Nothing about your background has been shared yet, so there's nothing to stretch and no stated gaps. Once your CV or background arrives, this list is built from it before any guidance is rewritten.

## Sources

Provided documents: your message only.

Searches sent (all refused, nothing returned):

- `Stripe operating principles official`: refused
- `Stripe interview process final round onsite operations`: refused
- `Stripe strategy news 2026`: refused
- `Stripe "Product Operations Manager" job`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | The search was refused. It would have supplied Stripe's published principles by name, to theme the values questions, and a cheat sheet if a values round is established |
| 2. `Stripe interview process product operations` | unavailable | The search was refused. It would have shown how the final round is structured, which would replace the flat persona weights |
| 3. `Stripe strategy` / recent news | unavailable | The search was refused. It would have added CO and CASE questions grounded in current strategy |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was nothing to search for |
| 5. representative `Product Operations Manager` JD | unavailable | The search was refused. It would have replaced the seven `[generic]` requirements with quoted `[inferred]` ones |

## Upgrade menu

- The job description text → the seven `[generic]` fit rows become quoted `[grounded]` requirements, each with JD-tagged questions checked against the posting's own list
- Your CV or a summary of your background → the worksheet becomes a real evidence map, scaffolds become stories mapped to your own lines, A1 is rebuilt around your actual thinnest row, and the prohibited list gets real entries
- Who you're meeting and their relationship to the role → persona weights recomputed from relationship instead of flat. If your final is several sessions, send the schedule for a mini-pack per session
- Interviewer names → a section on reading each interviewer from their public professional footprint, plus a reverse question tied to their own path
- The recruiter's prep email → coverage of stated focus areas, and a build section for any case, presentation or take-home they announced
- Web search allowed in this session → the research pass above: Stripe's published principles, loop structure and current strategy, with CO questions that aren't generic
- A deeper research pass, on request → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief and differentiator drills
- How much prep time you have → a prioritised prep schedule sized to it
- A tuesday-dossier.md, if you have one → the highest-ROI objection taken from verified evidence rather than a generic pattern, and a prohibited-claims guardrail. Not needed for the pack to work
