Reading done; now running the default light research pass on Quartzline before building your pack.
Your prep pack is saved as `Quartzline_product-manager-platform-apis_interview_pack.md`. It's built for Thursday's 45-minute conversation with the hiring manager and draws on your dossier. The web searches I tried were refused, so the case questions are general to the role rather than specific to Quartzline.

The most important thing to practise is A1, the objection your dossier named: "you've never held the PM title or owned a roadmap." The answer is in four steps:
1. **Concede first:** you haven't held the PM title or owned a roadmap.
2. **Give the adjacent evidence as it stands:** the 30+ client integrations of the vendor's REST APIs you led, and the quarterly roadmap-input sessions you ran.
3. **Name the limit yourself:** you fed evidence to product; you didn't own the roadmap.
4. **Close with a plan** for how you'd ramp up.

The dossier says "seven years of integration leadership", but none of your confirmed evidence states that, so the pack doesn't use it. Only say it in the interview if it's accurate.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also update your tuesday-dossier.md with what this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday. Name not known.
**Built from:** your `tuesday-dossier.md` (v1.1, generated 2026-08-14). Web research was attempted and refused, so nothing in this pack comes from Quartzline's public pages. See Sources.

## How to use this pack

- **Personas** describe *how* a question arrives: who's asking, and in what style. **Types** describe *what* it scores.
- Type key:
  - **VAL**: behavioral or values alignment
  - **EXP**: deep-dive on your stated experience
  - **JD**: the stated requirements and responsibilities
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role
- **Provenance** tells you how far a row can be trusted. `[grounded]` traces to your dossier. `[inferred]` is this pack's own derivation, and the row says what it's derived from. `[generic]` is a role-family pattern with no claim about Quartzline.
- **Guidance is scaffolding, not a script.** Each "answer slot" is an instruction for the interview itself. Answer it truthfully, whichever way the truth goes.
- **Evidence labels VE1 to VE3** are the three `verified_candidate_evidence` entries in your dossier, in the order it lists them.
- **Question IDs** skip the letter F, so they can't be confused with fit-snapshot rows F1 to F6.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | low | [inferred] | transferability | The dossier allows a bridge here, positioned as adjacent and never as PM experience. Derivation: the dossier grades this row low with a bridge strategy. The words stay at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product." Give the limit before you're asked for it. The plain acknowledgment comes from the dossier's `prohibited_claims` field: "I haven't held a product manager title or role." VE3 is confirmed but has little inspectable proof, so expect a probe on it and give its limit yourself: you fed evidence to product |
| F2 | "Own the roadmap for the partner-facing API platform" — JD responsibility (dossier R1 sub-claim) | none given | none | [grounded] | capability | The dossier lists this under `uncertain_or_weak_areas` as `acknowledge_gap`, and two `prohibited_claims` items cover it. Words: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then say how you would ramp, as a plan, never as something you've done. No bridge, no answer slot, and nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — JD (dossier R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | transferability | Your material shows client integrations of the vendor's REST APIs, taken through to go-live. It doesn't show an API or platform product shipped, and the words stay at the quote's scope. Answer slot: this requirement makes a probe on those integrations likely. If any of the named stages (scoping, requirements, architecture, UAT, go-live) were yours to decide, say which ones and how you decided, in your own words. If none were, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Wrote the internal integration playbook her team uses" — dossier VE2 | low | [inferred] | discovery | Derivation: VE1's "architecture" and the playbook touch technical work, but neither shows API docs or schemas. Answer slot: if you worked from, or wrote, API docs or schemas during those integrations, say which and how, in your own words. If you didn't, say so plainly and describe how you'd get fluent in this platform's docs |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | medium | [inferred] | discovery | Derivation: the quotes show clients and product. Engineering and sales don't appear in your material. Answer slot: if you worked with engineering or sales on those integrations, say who, and what part of that work was yours, in your own words. If you didn't, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — JD (dossier R5, preferred) | none given | low | [inferred] | discovery | The dossier's strategy here is `clarify`, and no verified entry speaks to agile itself. Derivation: the dossier's grading. Answer slot: the JD's "Agile delivery experience" line is the likely probe. If you've delivered in an agile way, say how, in your own words. If you never worked that way, say so plainly. Then: "Here's what I'd want to confirm about how your squads define it" |

## Persona table

The loop rests on your own words: one 45-minute conversation with the hiring manager. So the weights start from the hiring-manager prior and are adjusted by the dossier.

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of F1 and F2: the PM title, the roadmap, the squads | High. The hiring-manager prior, plus your dossier named this objection as the likeliest | Rehearse A1 until it bores you. Concede first, then give the adjacent case at the quotes' scope, then a ramp plan |
| Case / Strategist | Live problems drawn from the four listed responsibilities | High. The hiring-manager prior. The role's four responsibilities are natural case material | Clarify, objective, segments, approach, metrics, risks. Think aloud and challenge one premise per case |
| Data-Driven Prober | Your "30+" figure, and VE3 (confirmed, but with little inspectable proof) | Medium. A headline number and a medium-confidence entry are where probes land | Know what you can and can't say about how the 30+ was counted. Name your weakest assumption before they do |
| Conversational | The opener and the motivation question, plus agile asked casually | Medium. Almost any 45-minute conversation opens this way, and casual questions are still scored | A 90-second arc built only from VE1 to VE3, plus why this role, in your own words |
| Pressure | Time-boxed "why you" and "how much was you" | Low. Not the hiring-manager default, but the F1 gap invites it | Hold through two follow-ups, then concede the specific thing, never the core claim |
| Values / Behavioral | Generic behavioral stems | Low. Your description names no values round, and no published values are in hand | Use the selection scaffolds, each ending in its honest branch |
| Peer Evaluator | The squad-lead seam, in collegial packaging | Low. The interviewer isn't a peer, but the two squads are the role's closest partners | Offer seam principles and reciprocity rather than pretending to know the seam |

## Question banks

**Highest-ROI prep in this pack: A1.** Your dossier named this objection.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role", "Having owned a product roadmap" | (1) Concede first, plainly: "That's right. I haven't held a product manager title or role, and I haven't owned a product roadmap." (2) Then the adjacent case at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live. I also ran quarterly roadmap-input sessions feeding client evidence to product." (3) Name the limit yourself: "I fed that evidence to product. I didn't own the roadmap it went into." (4) Close with a ramp plan, said as a plan: what you'd learn first, and from whom. Say why you want this role in your own words. Follow-ups: if they press "so why not the PM?", don't argue that you're equivalent. Hold to what the two quotes say, and concede exactly what you'd have to learn. Hold through two follow-ups by going back to the quotes, never by adding to them | F1 and F2 are the role's must-have gap and the dossier's named objection, so some form of this is coming. JD because it scores R1 directly. Both negatives in the question are sourced in `prohibited_claims`, so it is asked as written |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas`: owning a roadmap and prioritization authority, `acknowledge_gap`; `prohibited_claims`: "Having set prioritization for an engineering squad" | Choose F2. Naming the real gap beats inventing a safe one: "Owning the roadmap and setting priorities with the squads. I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then give your plan for the first months, and turn it into a question about decision rights (RQ1). Don't soften the gap with a bridge | F2 is the dossier's `acknowledge_gap` area. Calibrated candor on it is what the Skeptic scores. JD because it maps the gap onto the stated role |
| A3 | "You'd be driving delivery with two squads whose leads have strong opinions. Have you set priorities for an engineering team before?" | JD | [grounded] `prohibited_claims`: "Having set prioritization for an engineering squad" | "I haven't set prioritization for an engineering squad." Then describe how you would approach it, in future tense: agree with the leads who decides what, make the evidence behind each call visible, and say how you'd handle a disagreement. End with RQ1, because the answer is also something you need to know | The responsibility "drive delivery with two engineering squads" plus the dossier's open authority question make this likely. JD because it scores a listed responsibility |
| A4 | "Tell me about your work with API or platform products." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3. The beats the quote states are: you led them; 30+; end-to-end; client integrations of the vendor's REST APIs; and the stages scoping, requirements, architecture, UAT, go-live. Tell it in your own words. Answer slot: if any of those stages were yours to decide, say which and how you decided. If none were, say so plainly and describe how you led the integrations | F3 is the second must-have, and your evidence for it sits beside the requirement rather than on it. JD because it scores R2 |
| A5 | "How do you manage stakeholders across engineering, sales and customers?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Start with what the quotes carry: clients, through the integrations you led, and product, through the quarterly sessions. VE3 is confirmed but has little inspectable proof, so say plainly what the sessions were, and nothing more. Answer slot: if you worked with engineering or sales on those integrations, say who and what your part was. If you didn't, say so plainly and stay with clients and product | F5's evidence covers two of the three named groups. `[inferred]` because the mapping is this pack's derivation. JD because it scores R4 |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Say you're three months in. Sketch how you'd build the next two quarters of the partner API roadmap. What do you need to know first?" | CASE | [generic] | Clarify first: who decides what (RQ1), what adoption looks like today (RQ2), and what partners are asking for. Then the objective, partner segments, how you'd choose between candidate bets, the metrics, and the risks. The question asks nothing about your past, so the guidance claims nothing | JD content, CASE delivery: it's the role's first responsibility. `[generic]` because research was refused and nothing here is specific to Quartzline |
| B2 | "How would you run discovery with integration partners for a new API capability?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure it: which partners you'd talk to, what you'd ask, what evidence would change a priority, and how findings reach the squads. If you mention your own work, give only what the quote says, "I ran quarterly roadmap-input sessions feeding client evidence to product", and call it the nearest thing you've done. Don't call it discovery | A listed responsibility, and VE3 is the nearest quote. The prohibited list keeps that quote at its own scope |
| B3 | "A squad lead says your spec can't be built this quarter. What do you do?" | CASE | [generic] | Ask what makes it unbuildable (scope, dependency or capacity). Separate what partners need from how it's built. Offer a smaller slice. Agree who makes the call, and record the trade-off. Future tense throughout, with no claims about your past | Tests the "write specs and drive delivery" responsibility and the unresolved authority question as a decision rather than a record |
| B4 | "How would you define and track adoption for a partner-facing API, and what would you do if it looked flat?" | CASE | [generic] | Clarify what counts as adoption before measuring it: partners live, calls, active integrations, time to first call. Choose a primary measure and a few guardrails. Then diagnose by segment and funnel stage. Ask what they measure today (RQ2), since the dossier found no baseline | The adoption-metrics responsibility, plus the dossier's open risk about how adoption is measured. A live problem with no claim about your past |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you count the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, every part in your own words: how the figure was counted (what made something one integration), what it's sensitive to, which assumption behind it you'd defend least (say that one before they ask), and which part was yours. "I don't know exactly how it was counted" is an honest answer. Don't stretch the number to sound bigger | The defend-the-number rule for the one figure in your material. EXP because it tests what was actually yours |
| C2 | "Tell me about the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on VE2. The beats it states are that you wrote it and that your team uses it. Describe what it covers in your own words. The dossier marks it as inspectable, so it's the one item you could offer to show. Answer slot: the JD's "API docs, schemas" line makes a probe likely. If the playbook deals with API docs or schemas, say how. If it doesn't, say so plainly and stay with what it does cover | VE2 is your highest-confidence, inspectable item, and probers go for artifacts. EXP because it tests authorship |
| C3 | "How do you get fluent in a new API, its docs and its schemas?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you worked from, or wrote, API docs or schemas during those integrations, say which and how, in your own words. If you didn't, say so plainly and describe how you would learn this platform's docs: what you'd read first, and whom you'd ask | F4 is a discovery gap on R3. `[inferred]` because the link from integrations to docs is this pack's derivation |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, the three quotes: the integrations you led, the playbook you wrote, and the sessions you ran. Then why this role now, in your own words. Supply any dates, employers or titles yourself, because this pack has none confirmed | It opens most conversations and it is scored. EXP because it's your history in brief |
| D2 | "What draws you to product, and to platform APIs specifically?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Motivation is yours to state. Choose a reason you actually hold. If the sessions are part of it, use the quote at its scope and don't imply you owned the result. Keep it under a minute | The motivation-consistency check that follows A1's gap |
| D3 | "What's your experience with agile delivery?" | JD | [inferred] | The dossier's strategy here is `clarify`. Answer slot: if you've delivered in an agile way, say how, in your own words. If you never worked that way, say so plainly. Then: "Here's what I'd want to confirm about how your squads define it." Treat it as scored, even if it's asked casually | F6. R5 is preferred, not required, so it's likelier to come up as a casual aside. `[inferred]` from the dossier's grading |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role" | Pause, then a compressed A1. Concede ("I haven't held a product manager title or role"), give the two quotes, then one line on what you'd need to learn. If interrupted, finish the sentence you were on, then return to the quotes. Hold through two pushes. Concede the gap again, never your evidence | A1's objection, time-boxed. It rehearses composure on F1 |
| E2 | "Thirty-plus integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "led": it's the quote's own verb. Answer slot: say which part of the work was yours, in your own words. If others did parts of it, name that plainly. Concede the specific parts that weren't yours without giving up "led" | The figure in VE1 raises the "which part was yours" probe. EXP because it tests attribution |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Choose a time with a named stake, a moment where you didn't back down, and an outcome you can actually state. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common behavioral stem. No published values are in hand, so it's untargeted. None of your quotes carries this story |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Choose a time with a specific customer, a specific metric, and a decision you can say was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Partner-facing roles invite this stem. No quote carries it, so it's a scaffold |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You and the two squad leads will share a lot of ground. Where's the seam, and what happens when you disagree?" | CASE | [generic] | Offer seam principles, not a seam you can't know: the problem and its evidence on your side, how it's built on theirs, and an agreed tiebreak. Add reciprocity: what you'd bring them, such as partner evidence and clear specs. Then RQ1 | The squad-authority unknown, in collegial packaging. A live question with no claim about your past |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold. Choose a time when shared work got credited, and say what you did about it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing probes travel with seam questions. No quote carries this story |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, E1, D1 |
| R1 sub-claim: owning a roadmap and prioritization authority | A1, A2, A3 |
| R2: shipped API or platform products | A4, C1, E2 |
| R3: technical fluency with API docs and schemas | C3, C2 |
| R4: stakeholder management across engineering, sales and customers | A5 |
| R5: agile delivery experience | D3 |
| Own the roadmap (responsibility) | B1 |
| Run discovery with integration partners (responsibility) | B2 |
| Write specs and drive delivery with two squads (responsibility) | B3, A3, H1 |
| Define and track adoption metrics (responsibility) | B4 |
| Company strategy (CO) | none. Research was refused, so a CO question would have rested on nothing |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Your dossier's condition depends on it. It reads as diligence and tells you whether the role has real authority. It's also the honest close to A2, A3 and H1 |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier found no stated baseline. The answer shows whether you'd inherit a measure or have to build one, and it sets up B4 |
| RQ3 | "What would make the first six months in this role a clear success, from where you sit?" | It turns A1's ramp plan into the manager's own terms |
| RQ4 | "Where do integration partners feel the platform is weakest today?" | It shows you think from the partner's side, and it gives you material for any case that follows |
| RQ5 | "How does feedback from partners and from sales reach the roadmap today?" | It's the stakeholder question R4 names, asked as diligence, and it connects to the sessions in VE3 without overclaiming them |
| RQ6 | "What's the biggest call this role will have to make in its first year?" | It tests whether there's a real decision to own, which is the core of the conditional go |

## Prohibited claims

This pack won't coach the claims below. The dossier's three entries are absolute. The other two were added locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | "I haven't held a product manager title or role," plus VE1 and VE3 at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area | "I haven't owned a product roadmap." No bridge and no slot. A ramp plan, said as a plan |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3, added locally | F3's quote at its own scope. This pack's observation, not words for you: the material shows integrations, not a shipped product. A4's slot stays within VE1's stages |
| Ran product discovery with partners | Inflated form of VE3 (F1 and F5), added locally | VE3's quote at its own scope. B2 calls it the nearest thing you've done and never calls it discovery |

## Sources

**Provided documents.** `tuesday-dossier.md`, envelope version 1.1, generated 2026-08-14. Sections consumed:

- `role_profile` supplied the requirements and responsibilities (the JD tier).
- `handoff_to_mock_interview` supplied all seven fields: VE1 to VE3, the strategies for the weak areas, the A1 objection, the risks and employer questions behind RQ1 and RQ2, and the prohibited claims.
- `decision` was read for context only.
- No `evidence_map`, `risk_register` or `evidence_state` was present. Confidence and gap types for F3 to F5 are this pack's own grading.
- The decision line says "seven years of integration leadership". No verified entry states that, so the pack doesn't use it.

**Searches sent:**

- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline partner API platform news 2026": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have themed G1 and G2 with Quartzline's own value names |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. Your own words already establish this session, so persona weights don't depend on it. It would have shown any other rounds |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have added a CO question and grounded B1 to B4 in current strategy, which stay `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given. There's no interviewer read |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Allow web search, or paste Quartzline's values page and a recent news item** → targets 1 to 3 run, a CO question is added, and B1 to B4 move from `[generic]` toward Quartzline's real priorities.
- **Deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, the interviewer's public talks and writing, and loop reports.
- **The hiring manager's name** → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to their own career path.
- **The recruiter's prep email** → any stated focus areas, plus a build section for any pre-declared deliverable.
- **Your answers to the answer slots, told to me outside a drill** → F3 to F6 and rows A4, A5, C1, C3 and D3 gain quoted evidence.
- **Your raw CV, or a sentence confirming "seven years"** → D1's arc can carry dates and titles, and F1's bridge can use them.
- **How much prep time you have** → a prioritized prep schedule.
