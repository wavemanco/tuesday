Building your panel prep pack now. Next I'm running a few targeted searches on Kelverton Rail and the two panellists.
I've built your prep pack for Tuesday. Web search was blocked (all six searches were refused), so the pack works only from the recruiter's email and your background. Anything about Kelverton, its market or Deepa and Ross beyond what the recruiter said is marked as generic.

**Your 4 hours, in order:**
1. **Saturday, 30 min:** reread the market report and note three things: the point everyone will agree with, the point you'd challenge, and the operator pain points it names.
2. **Saturday, 75 min:** build the 15-minute POV on one page and say it aloud twice against a timer.
3. **Sunday, 45 min:** rehearse your answer to the most predictable objection (question B1).
4. **Sunday, 40 min:** the commercials block for Ross, starting with your own facts behind the £4M.
5. **Sunday, 50 min:** one full timed run with interruptions, then pick your questions for the panel.

**Main recommendations:**
- **The POV:** build it around fewer, deeper partnerships, each tied to a result operators can see in their own numbers. That way the operator benefit the recruiter asked for and Ross's commercial test are the same point. Say the trade-off out loud: partner count grows slowly.
- **Say what you wouldn't do.** Coming from a channel you took from 6 partners to 40, saying you wouldn't chase partner count here shows judgment, as long as you give the reason.
- **Highest-ROI prep:** "You haven't sold into rail and haven't carried a quota. Why should we believe the payments playbook transfers?" Admit both gaps first, in your own words, before they've finished asking. Then state only what you've actually done: running the ISV channel from 6 to 40 partners with roughly £4M of influenced revenue, and five years of bus and light rail network planning. Then give a 90-day plan for learning how operators buy.
- **Decide before Tuesday whether you'd take a direct revenue number.** Ross will likely ask.
- **Pin down the £4M:** whether it's a four-year total or a yearly figure, how it was counted, and which part was yours. Keep "roughly" and "influenced" whenever you say it. If you're unsure whether it's annual, treat it as the total.
- **Define "operator partnerships" in your first minute.** It could mean partnerships with operators, or partners who help Kelverton reach operators. A one-line email to the recruiter would settle it before Tuesday.

The pack also has 22 practice questions grouped by interviewer style, a list of claims it deliberately won't coach (like "sold into rail" or "generated £4M"), and questions to ask the panel.

If you like, I'll play Ross and run B1 with live follow-ups, or run the full 15-minute POV with interruptions.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two questions:
1. Do you have the job description? If so, paste it and the generic rows become grounded in it. If not, I'll go ahead without one.
2. Can you allow web search so I can rerun the Kelverton and panel searches? If yes, do you also want the deeper pass (up to 6 more searches and 2 page fetches, several minutes) on Kelverton's strategy and competitors and the panellists' public talks?

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-5-denied-81c3fbf9:
- KelvertonRail_senior-partnerships-manager_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: KelvertonRail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel. 15-minute no-slides POV, then Q&A.
**Panel:** Deepa, VP Partnerships (your future manager). Ross, Commercial Director ("Ross will push on commercials").
**Built from:** the recruiter's email as you quoted it, and your background as you wrote it in your message. There was no JD. Web research was attempted and every call was refused (see Sources), so anything about Kelverton, its market or its panel that the recruiter didn't say is labelled `[generic]`.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who asks it and in what register. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: past behaviour against values
  - **EXP**: whether your stated experience survives scrutiny
  - **JD**: whether you can do the stated job, gaps included
  - **CO**: company and market homework
  - **CASE**: a live problem from the role
- **Provenance:**
  - `[grounded]` traces to the recruiter's email or your own words.
  - `[inferred]` is derived, and the derivation is named.
  - `[generic]` is a role-family pattern with no claim about Kelverton.
- **Answer slots** are instructions for the interview. Where your material doesn't say something, the pack gives you two honest branches and you fill one in with your own facts. They are not questions to answer here.
- The guidance is scaffolding, not a script. Every block of suggested wording is **proposed language, pending your approval**. Say it in your own words or don't say it.

## Prep triage: 4 hours

| Order | Time | Do this | Section / IDs |
|---|---|---|---|
| 1 | 30 min (Sat) | Reread the market report looking for three things: the one point everyone in the room will agree with, the one you'd challenge, and the operator pain points it names. Write each in a sentence. | Section 5, "Differentiation" |
| 2 | 75 min (Sat) | Build the POV on one page using the 15-minute outline. Say it aloud twice against a timer and cut until it lands at 13–14 minutes. | Section 5 |
| 3 | 45 min (Sun) | Rehearse B1 out loud through all three follow-ups. This is the highest-ROI prep in the pack. | B1, then B3 |
| 4 | 40 min (Sun) | Ross block. First settle your own facts behind the £4M (the C1 slots), then rehearse C1, C2, D1 and C3. | Bank C, Bank D |
| 5 | 30 min (Sun) | Full run: POV plus three interruptions (D3, A2, C4). Do it as a drill with me if you can. | Section 5, D3, A2, C4 |
| 6 | 20 min (Sun) | Pick three reverse questions. Decide your stance on taking a direct number before you're asked. | Reverse questions, B1 follow-up 3 |

Everything else in this pack is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material shows a channel you ran at a payments company. It doesn't show operator partnerships in rail, so keep your words at that scope: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: an 18-month brief makes a probe on how you planned that growth likely. If a multi-quarter plan for the channel was yours to write, say what it set out and what changed, in your own words. If there was no such plan, or it wasn't yours, say so plainly and stay with what the channel became |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | This is adjacent, not the same. Your material says bus and light rail network planning. Train operators, and the side of the table that buys software, aren't in it. Words: "I spent five years in transport consulting on bus and light rail network planning, so I know the operator world from the other side." Answer slot: the recruiter's close makes a probe on what operators actually need likely. If your consulting put you in front of operators' own planning or scheduling problems, say which kind and what you saw, in your own words. If it didn't, or your clients were authorities rather than operators, say so plainly and stay with the network-planning work |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure is influenced revenue, and roughly. Your material doesn't show how it was counted or what commercial terms sat behind it. Keep both qualifiers when you say it: "roughly £4M of influenced revenue." Answer slot: the four defend-the-number slots: how it was counted (a four-year total or a yearly figure; if you're unsure, use the total, which claims less), what it is sensitive to, the assumption behind it you'd defend least, and which part was yours. Second slot: "commercials" makes a probe on partner deal terms likely. If you set or negotiated partner commission, margin or pricing terms, say which, in your own words. If you didn't, say so plainly and return to the influenced figure |
| F4 | Carrying a direct revenue number. This is a common expectation for senior partnerships roles, with no Kelverton source behind it | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap you've stated yourself, and wording can't close it. Words: "I haven't carried a direct quota; my number has been influenced revenue." Then say how you'd take one on, as a plan and never as something you've done. Add nothing to make the gap feel smaller |
| F5 | Selling into rail and knowing train operators as buyers. This is a role-family expectation, drawn from your own description of Kelverton's market | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap you've stated. Words: "I haven't sold into rail specifically." Then the ramp plan, said as a plan. Never imply rail selling through the consulting years |
| F6 | Building and scaling a partner channel (role-family) | "took it from 6 partners to 40" — your message | medium | [generic] | none | No gap. It's a line with nothing inspected behind it, so expect a probe. Lead with the count in your own terms. A channel that started at 6 wasn't started from zero, so don't let it drift into "built from scratch" |
| F7 | Seniority in partnerships (role-family) | "9 years in partnerships" — your message — and "last 4 at a payments company running the ISV channel" — your message; "Before that, 5 years in transport consulting" — your message | medium | [generic] | none | No gap in seniority. Your 4 and 5 add up to the 9, so an interviewer may ask how the consulting years counted as partnerships. Answer slot: if part of the consulting work was partnership work, say what it was, in your own words. If it wasn't, say plainly that the nine years are four in partnerships and five in consulting next to it |

## Graded deliverable: the 15-minute POV

*Proposed structure and wording, pending your approval.*

**What the recruiter asked for (the grading sheet)**

| Brief element | Source | Provenance |
|---|---|---|
| "a short POV on where you'd take our operator partnerships over the next 18 months" | Recruiter's email | [grounded] |
| "no slides needed, just talk us through it" | Recruiter's email | [grounded] |
| "Please land on what it means for the operators themselves" | Recruiter's email | [grounded] |
| "Ross will push on commercials" means the POV should pre-empt the money question rather than wait for it | Recruiter's email, with the pack's reading of it | [inferred] |
| Deepa and Ross have the market report, since "their strategy team circulated" it, so reciting it scores as homework and nothing more | Your message, with the pack's reading of it | [inferred] |

**What you can say about yourself in it.** Only these rows, at their own scope:
- F1: "running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"
- F2: "bus and light rail network planning, so I know the operator world from the other side"

Use one sentence each, once, as context and not as proof. The POV is about Kelverton's next 18 months, not your last four years.

**Define the term in your first minute.** "Operator partnerships" could mean partnerships *with* operators, or partners who help Kelverton reach operators. Say which one you're talking about, and why, in a sentence. If the report or the recruiter settles it before Tuesday, use their meaning.

**Thesis options.** Pick one as the spine. Each carries a concession you say out loud.

| Thesis | The 18-month move | What it means for operators | Mandatory concession | Provenance |
|---|---|---|---|---|
| T1: Fewer, deeper partnerships, each tied to an operator outcome | Months 0–6: pick a small set of partners and name, for each one, the operator outcome it should move. Months 6–12: prove it with one or two operators. Months 12–18: package what worked and scale it | One accountable route to a result they can see in their own numbers, rather than another integration to manage | Partner count grows slowly, and Ross may read that as less pipeline. Say it before he does, then say what you'd measure instead | [generic] |
| T2: Partners that join Kelverton to the rest of the operator's planning workflow | Prioritise partners whose systems sit next to scheduling in the operator's day, so data moves without manual re-keying | Less swivel-chair work for planners, and fewer places for a timetable change to go wrong | Integration partnerships take engineering capacity away from the product roadmap, and you don't yet know how Kelverton's roadmap is loaded | [generic] |
| T3: Go to market through the people already inside operators | Co-sell or referral arrangements with firms that already advise or integrate for operators | Advice and delivery from people they already trust, with Kelverton behind them | You give up some control of the customer relationship and some margin. Say you'd protect against that through deal terms rather than pretending the risk isn't there | [generic] |

**Recommendation:** T1 as the spine, with one T2 or T3 move inside it. T1 is the only option where the operator benefit and Ross's commercial test are the same sentence: an outcome per partner, measured.

**Differentiation against the report (the consensus answer)**

| Move | How to do it | Provenance |
|---|---|---|
| One consensus point, to prove you've read it | Slot: the one report point everyone in the room agrees with. Name it in a sentence and attribute it to the report, then move on | [grounded] |
| One divergence, with reasons | Slot: the report point you'd challenge or reorder, and your reason in one sentence. If you agree with all of it, name the assumption you'd most want tested in the first 90 days | [grounded] |
| The anti-pick | Say what you would *not* do: chase partner count as the goal. Coming from someone whose last channel went 6 to 40 (F1's quote), this reads as judgment, but only if you say why. That why is a different market, not a bigger version of the last one | [inferred] |

**15-minute outline**

| Clock | Beat |
|---|---|
| 0:00–1:30 | What you mean by "operator partnerships", and the one assumption you're working from |
| 1:30–3:30 | Where things stand: the report's consensus point, and your divergence |
| 3:30–9:30 | The thesis, as three moves across 0–6, 6–12 and 12–18 months |
| 9:30–12:00 | Commercials, said before Ross asks: how partners would be paid, what you'd count, and what you'd want as the measure at month 18 |
| 12:00–14:30 | The close the recruiter asked for: what changes for an operator in 18 months, in their terms. Slot: the operator pain points the report names |
| 14:30–15:00 | The one risk, and what you'd want to learn in your first 90 days |

## Reading the interviewers

| Interviewer | What's established | Source | Provenance | What it means for you |
|---|---|---|---|---|
| Deepa | VP Partnerships, your future manager | Recruiter's email | [grounded] | She's buying capability and de-risking the gaps, so expect follow-ups on the POV's plan and on F4 and F5. Treat the 18 months as a plan she'd have to defend upward |
| Ross | Commercial Director; "Ross will push on commercials" | Recruiter's email | [grounded] | Expect a number in every answer and a denominator behind every number. Have F3's facts settled before Tuesday. Never estimate in the room what you could have checked at home |
| Both | Public career pattern, talks and writing | Not established: search was refused | [generic] | No interviewer-specific mirror or reverse question is offered. The upgrade menu says what surnames or profiles would add |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | POV follow-ups from both panellists | high. Hiring-manager and executive priors both lead with it, and the POV is a case by design | Clarify, then objective, approach, metrics and risks. Think aloud and challenge one premise respectfully |
| Skeptic | Deepa probing the rail and quota gaps | high. Hiring-manager prior, plus two gaps you've stated (F4, F5) | Rehearse B1 until it's boring. Concede first, then hold only what your quotes carry, then give a ramp plan |
| Data-Driven Prober | Ross on the £4M and the 40 | high. The recruiter's own words ("push on commercials") and a headline figure (F3) | Know how each number was counted, or say plainly that you don't. Name your weakest assumption before he does |
| Pressure | Ross interrupting the POV or time-boxing | mid. Executive prior and "push", though no stress style was stated | Pause, restate the question, hold through two follow-ups, then concede something specific |
| Conversational | The opening minutes, and "what did you make of the report?" | low. A short slot in a 60-minute panel, but still scored | A 90-second arc, and treat the casual report question as scored |
| Peer Evaluator | Deepa on the seam with direct sales | low. She's your manager, not a peer, but the partner-versus-AE seam is hers to manage | Propose seam principles rather than pretending to know the seam |
| Values / Behavioral | One "tell me about a time" | low. The recruiter's description of the session names no values round | Story selection with an honest branch |

## Question banks

*All guidance is proposed language, pending your approval.*

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If you could only do one thing from that POV in the first 90 days, what would it be?" | CASE | [grounded] | Pick the first move of your spine thesis and say why it comes before the others: what it unlocks, and what you'd know at day 90 that you don't know now. One move, not three | The brief says "over the next 18 months", so a prioritisation probe follows almost automatically. CASE because it scores sequencing live |
| A2 | "What does an operator actually get from this that they can't get by buying our software directly?" | CASE | [grounded] | Three beats: the operator's problem in their own terms, what the partner adds that Kelverton alone can't, and where the operator would see it in their numbers. Slot: use the report's operator pain points. The question needs no claim about your past, so the guidance makes none | It's the recruiter's own requested close, asked as a challenge. CO content, CASE delivery |
| A3 | "Which partners would you prioritise — and which would you turn away?" | CASE | [generic] | Give two or three selection criteria, such as the operator outcome the partner moves, the integration cost, and the commercial model. Then make one anti-pick with its reason. Saying no is part of the job | Partnerships leaders get judged on what they decline. Tests F1's requirement as a decision |
| A4 | "How will we know at month 18 whether this worked?" | CASE | [grounded] | Split leading from lagging measures. Leading: partners live, operators engaged. Lagging: an operator outcome, and revenue attributed to partners. Say how attribution would be agreed with sales before it's disputed. Don't name targets you can't derive | It scores the plan's accountability, and Ross will be listening for revenue |
| A5 | "What in the strategy team's report would you disagree with?" | CO | [grounded] | Selection scaffold: pick one point from the report and give your reason in a sentence, then say what evidence would change your mind. If you agree with all of it, say so plainly and name the assumption you'd most want tested | The report came from their own strategy team, so disagreeing with it is the differentiation test. CO because it scores homework depth |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail, and you haven't carried a quota. Why should we believe the payments playbook transfers?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **Highest-ROI rehearsal in the pack.** (1) Concede first, plainly: "I haven't sold into rail specifically, and I haven't carried a direct quota. My number has been influenced revenue." (2) Hold only what your quotes carry: "For four years I ran the ISV channel at a payments company and took it from 6 partners to 40, with roughly £4M of influenced revenue. Before that I spent five years in transport consulting on bus and light rail network planning." Stop there and let them draw the inference. Don't call it proof. (3) Name the limit before they do: bus and light rail aren't heavy rail, and influenced isn't closed. (4) Give a ramp plan, said as a plan: who you'd sit with and what you'd learn about how operators buy in your first 90 days. **Follow-up 1, "So we'd be paying you to learn":** hold the plan and concede the time cost honestly. **Follow-up 2, "What would you get wrong first?":** answer slot: name the one thing you expect to misjudge, from your own read of the report, and how you'd find out early. **Follow-up 3, "Would you take a direct number?":** answer slot: decide before Tuesday whether you would and on what basis, then say it plainly. Never "I've effectively carried a number" | F4 and F5 are your two stated gaps, and both sit exactly where "push on commercials" lands. This objection arrives in some form. JD because it scores the role's core requirements |
| B2 | "Why rail, and why now?" | VAL | [generic] | Selection scaffold: your reason in your own words. It needs a pull toward this role, not just a push away from the last one. Answer slot: if the consulting years are part of why, say so in your own words. If they aren't, don't borrow them as a reason | The Skeptic's standard motivation probe, aimed at a sector switch. VAL because it scores motivation consistency |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one of the two gaps you've stated, not a disguised strength: "I haven't sold into rail specifically," or "I haven't carried a direct quota." Then give one concrete step from your ramp plan | A persona stem the panel may use as a shorter B1. Pick in advance which gap you'd name |
| B4 | "You know operators from the consulting side. What does that tell you about how they buy software?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Keep to the quote: bus and light rail, network planning. Answer slot: if you saw clients choose or use planning or scheduling software, say what you saw, in your own words. If you didn't, say so plainly. Advising on networks and buying software are different seats, and saying that out loud earns credibility | F2 is the bridge most likely to be over-read, by you or by them. EXP because it tests what the consulting work actually was |

### C. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the £4M. How was it counted?" | EXP | [grounded] "roughly £4M of influenced revenue" | Settle these before Tuesday, then answer in your own words. Answer slots: how it was counted, including whether it's a four-year total or a yearly figure; what it's sensitive to; the assumption behind it you'd defend least, said before he asks; and which part was yours. Keep "roughly" and "influenced" in the sentence. If you don't know how finance counted it, say exactly that, then say what you do know. The pack supplies no attribution method | The defend-the-number question for F3's headline figure. Ross's register exactly |
| C2 | "Of the 40 partners, how many actually moved revenue?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you know the split, give it. If you don't, say so plainly rather than rounding up. Then give what you'd count first in a new channel | The denominator probe on F6. A prober asks for it within a minute of hearing "40" |
| C3 | "How would you structure the commercials of an operator partnership — who pays whom?" | CASE | [generic] | Lay out the main models: referral fee, resale margin, co-sell with shared credit, revenue share. For each, say who's motivated to do what, and which suits a market with few, large buyers. Answer slot: if you set or negotiated such terms in the ISV channel, say which, in your own words. If not, say so plainly and reason through the models live | It's the recruiter's "commercials", asked as a design problem. The slot keeps F3's discovery gap honest |
| C4 | "What would you put on your number for year one, and how did you get there?" | CASE | [grounded] "never carried a direct quota, only influenced revenue" | Don't invent a figure. Name the inputs you'd need: the operator base, average deal size, partner-influenced share today, and sales cycle length. Build the number aloud from them as a hypothesis. Then name the assumption you'd defend least. If he presses for a figure, say what you'd need to see first | It tests F4's gap as a live exercise rather than a confession |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Influenced revenue is soft. How much of that would have happened without you?" | EXP | [grounded] "roughly £4M of influenced revenue" "never carried a direct quota, only influenced revenue" | Pause first. Hold the figure as you stated it, qualifiers intact. Concede what "influenced" means: others closed it. Answer slot: what part was yours, in your own words. If you can't separate it, say so plainly. Hold through two follow-ups. Never trade "influenced" up to "drove" to end the pressure | The hold-then-concede test on F3, and the likeliest Pressure line in a commercials push |
| D2 | "Sixty seconds: why you over someone who's sold to train operators for ten years?" | JD | [grounded] "Never sold into rail specifically" "took it from 6 partners to 40" | Concede first that they'd know the buyers better than you. Then F1's quote at its scope, then your POV's thesis in a sentence: what you'd build, not what you've done in rail. Stay inside 60 seconds | A time-boxed version of B1. Practise the short form separately |
| D3 | Mid-POV interruption: "That sounds generic. What's the number in month 18?" | CASE | [generic] | Don't lose your place and don't invent a forecast. Name what you'd measure and the inputs you'd need, give a hypothesis framed as one with its weakest assumption, then go back to the outline at the beat you left | Executives often test composure by interrupting a prepared talk. Rehearse it in the full run |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc in this order: consulting (five years, bus and light rail network planning), then the payments ISV channel (four years, 6 to 40 partners, roughly £4M influenced), then why this role. Answer slot: give the why in your own words | Every panel opens with it. Script the arc so the POV starts from momentum |
| E2 | "What did you make of the report?" | CO | [grounded] | Treat it as scored. Give the consensus point in a sentence, your divergence in a sentence, and stop. Selection scaffold: the two points you prepared in triage step 1 | A casual question about their own document, scored as homework |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Partnerships and direct sales both want the same operator accounts. Where's the seam?" | CASE | [generic] | Propose principles rather than claiming to know Kelverton's seam: who owns the operator relationship, when a partner is brought in, and how credit is agreed before the deal rather than after. Ask how it works today | Deepa manages this seam. CASE because it scores a working design |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time credit for a partner-touched deal was contested. It needs a named stake, what you did, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the principle you'd propose | A persona stem with sharp relevance when your number is influenced revenue |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, the truth, how you delivered it, and what happened. Choose one where the truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries | A standard stem. No published values were in hand to theme it |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a customer or partner, the metric you let slip, and why. If no such time comes to mind, say so plainly and say how you'd weigh it in this role | It echoes the recruiter's operator-benefit close, so a story here reinforces the POV |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1: the 18-month POV | A1, A3, A4, D3, plus section 5 |
| F2: what it means for operators | A2, B4, H2, plus section 5 |
| F3: commercials | C1, C3, C4, D1 |
| F4: direct number | B1, B3, C4 |
| F5: selling into rail | B1, B3, D2 |
| F6: channel scaling | C2, A3 |
| F7: seniority | E1 |

## Reverse questions

| Question | To | Why it lands |
|---|---|---|
| "When you say operator partnerships, who's on the other side: operators themselves, or the companies that reach them?" | Deepa | Better settled with the recruiter before Tuesday. If it isn't, asking it straight after the POV shows you noticed the ambiguity rather than guessing |
| "How does Kelverton count partner-influenced revenue today, and is there a number attached to this role?" | Ross | Speaks his language and settles F4's risk from your side |
| "Which part of the strategy team's report do you two weight differently?" | Both | Turns a homework check into a real discussion between them |
| "What would make you say, at month 12, that this hire was the right one?" | Deepa | Gets your scorecard from your future manager directly |
| "Where do partnerships and direct sales overlap on operator accounts now, and how is that resolved?" | Deepa | Shows you're thinking about G1's seam before it bites |
| "What do operators tell you is the hardest part of working with Kelverton today?" | Either | Ties back to the recruiter's operator close and gives you material for your first 90 days |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a quota or owned a revenue target | A negative you stated (F4) | "I haven't carried a direct quota; my number has been influenced revenue." |
| Has sold into rail, or knows train operators as buyers | A negative you stated (F5) | "I haven't sold into rail specifically." |
| Generated, closed or sourced £4M | Inflated form of F3 and F1's quote | "roughly £4M of influenced revenue." The pack's observation: your material says influenced, and roughly |
| £4M a year | Inflated reading of F3's quote | Unless you know it's annual, treat it as the total, which is the reading that claims less |
| Built the ISV channel from scratch | Inflated form of F6's quote | "took it from 6 partners to 40." The pack's observation: the channel started at 6 |
| 40 active or revenue-producing partners | Inflated form of F6's quote | "took it from 6 partners to 40." C2's slot stays inside that count |
| Heavy-rail or train-operator expertise from consulting | Inflated form of F2's quote | "bus and light rail network planning, so I know the operator world from the other side." The pack's observation: bus and light rail, not heavy rail |
| Nine years of partnerships work, if the consulting years weren't partnership work | Inflated reading of F7's quotes | F7's quotes side by side: four years running the ISV channel, five in transport consulting. F7's slot decides how you describe them |

## Sources

**Provided documents**
- The recruiter's email, as you quoted it.
- Your background, as you wrote it.
- The strategy team's market report: you've read it, but its contents weren't given to this pack, so nothing in the pack rests on it. Every reference to it is a slot for your own read.

**Searches.** All six were refused because web search permission wasn't granted:
1. "Kelverton Rail values": refused
2. "Kelverton Rail interview process partnerships": refused
3. "Kelverton Rail scheduling software train operating companies news 2026": refused
4. "Deepa VP Partnerships Kelverton Rail": refused
5. "Ross Commercial Director Kelverton Rail": refused
6. "\"Senior Partnerships Manager\" rail software UK job description": refused

**Fetches:** none.

No dossier was consumed.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The search was refused. It would have themed H1 and H2. No values cheat sheet either way, because the recruiter's description of the session names no values round |
| 2. Kelverton Rail interview process | unavailable | The search was refused. It would have moved nothing: the recruiter's email already establishes the session |
| 3. Kelverton Rail strategy and recent news | unavailable | The search was refused. It would have grounded the thesis table and the CO questions in Kelverton's current moves. They stay `[generic]` or rest on your read of the report |
| 4. Deepa and Ross at Kelverton Rail | unavailable | The search was refused. It would have given the interviewer read career patterns, persona adjustments and a path-tied reverse question |
| 5. Representative Senior Partnerships Manager JD | unavailable | The search was refused. It would have moved F4–F7 from `[generic]` to `[inferred]` and added JD-tagged questions for the mid-list requirements |

## Upgrade menu

- **The market report's headline points, pasted, or the document itself:** your consensus point, divergence and anti-pick become specific, the operator close gets real pain points, and A2, A5 and E2 go from scaffolds to mapped answers.
- **The JD text:** F4–F7 become `[grounded]`, and every listed requirement gets a JD-tagged question.
- **A one-line reply from the recruiter on what "operator partnerships" covers:** the POV's first minute is settled rather than hedged.
- **Web search permission:** targets 1–5 rerun. A deeper pass is also available on consent: up to 6 more searches and 2 more fetches, several more minutes, covering Kelverton's strategy and competitors, the panellists' talks and writing, loop reports, and recent org changes.
- **Deepa's and Ross's surnames or public profiles:** an interviewer read with career patterns, adjusted persona weights, and a reverse question tied to each one's path.
- **Your own answers to the C1, C2, B4 and F7 slots** (how the £4M was counted, how many of the 40 produced revenue, who your consulting clients were, how the nine years split): F3, F6 and F7 and questions C1, C2, D1, B4 and E1 move from slots to story-mapped guidance.
- **A partner-influenced pipeline report or deal sheet from the ISV channel, kept for your own reference only:** F1, F3 and F6 could move from `medium` to `high`. This is what inspectable proof looks like in partnerships.
- **A `tuesday-dossier.md` from a job-underwriter pass:** an evidence-derived highest-ROI objection and a prohibited-claims list you've confirmed, in place of the ones built here.
