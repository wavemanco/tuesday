I've read the prep playbook; next I'll research Stripe (its published operating principles, how its interviews work, current strategy, and a sample Product Ops JD), then build your pack.
I've saved your prep pack as `stripe_product-operations-manager_interview_pack.md`. It's built only from your message: Stripe, Product Operations Manager, final round. My web searches were blocked by permissions, so the pack contains nothing about Stripe's values, interview process or strategy. Everything in it is a general Product Ops pattern, not Stripe-specific, and it says so on every row.

What's in it:
- **A fit worksheet.** It lists seven typical Product Ops requirements (launch readiness, feedback loops, metrics, process design, influence, writing, prioritisation). Each one says what strong evidence looks like and how to pick a real story for it.
- **21 practice questions.** They cover seven interviewer styles. The one to practise most is **A1**, "Which part of this role would you be weakest at on day one?"
- **Six questions to ask your interviewers**, plus a list of what would make the pack more specific to you.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in the final round (the hiring manager, peers, a skip-level, a cross-functional panel), and did the recruiter mention focus areas or anything to prepare, like a presentation? The answer changes how the questions are weighted.
Can you paste the job description and your CV, or a few lines on your background? If you'd rather not, the pack still works as a worksheet; with them, your own examples replace the generic ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not known. Relationship: not known. Built for a single final-round session with flat persona weights, from no job description, no CV and no research (every search was refused). Every row below is therefore `[generic]` or a worksheet you fill in, and the upgrade menu at the end says what turns each part `[grounded]`.

## How to use this pack

Two axes. **Personas** describe *how* a question arrives: who is asking, in what register. **Types** describe *what* is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's published values, not generic virtue |
| EXP | Whether your own experience survives scrutiny, including what was actually you |
| JD | Whether you can do the role's stated job, gaps included |
| CO | Company and strategy homework, and whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Because this pack holds none of your own sentences, no cell tells you what you did. Where a question asks about your past, the guidance tells you how to *choose* a story and what it needs, and every scaffold ends with an honest branch for when no such story exists. Fill the fit snapshot in first: the stories you pick there are the ones you rehearse against every bank.

## Fit snapshot (worksheet)

No JD and no CV were supplied, so the requirements are role-family patterns for Product Operations, written as plain prose and labelled `[generic]`. They are not Stripe's stated requirements. Fill the evidence column with your own real examples before rehearsing.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running launch readiness for a product across product, engineering, support and go-to-market teams — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a named launch, the teams involved, what readiness meant, and the part of it that was yours. Pick a launch or rollout you were actually inside; it needs more than one team and a moment where something was not ready. If you have none, say so plainly, then give the nearest coordination work you did, or how you would run one |
| F2 | Turning customer and field feedback into product input — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like where the feedback came from, how you sorted it, who received it, and what changed or did not. Pick a time feedback you handled reached a product decision-maker. If none comes to mind, say so plainly, then give the nearest thing you did with customer input, or how you would build that loop |
| F3 | Defining and tracking operational metrics, with enough data fluency to question them — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a metric you reported, how it was counted, and the assumption behind it you would defend least. Pick one figure you personally reported or built. If you have none, say so plainly, then say what you would measure first in this role and why |
| F4 | Designing or scaling a cross-functional process or tool that removed manual work — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like the before state, what you changed, who adopted it, and what you know about the result. Pick a process change you made or ran yourself. If none comes to mind, say so plainly, then give the nearest process work your experience does carry, or how you would approach one |
| F5 | Influencing stakeholders without authority — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a named disagreement, the people on each side, what you did, and how the relationship stood afterwards. Pick a time you moved someone you did not manage. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it |
| F6 | Clear written communication: launch briefs, process docs, decision memos — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a document you wrote that others acted on. Pick one you could describe in two sentences: what it was for and what happened next. If you have none, say so plainly, then say how you would write one for this role |
| F7 | Prioritising competing requests and escalations under ambiguity — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like the competing asks, the rule you used to choose, and who you told no. Pick a week where you could not do everything. If none comes to mind, say so plainly, then walk through how you would decide |

## Persona table

No loop source establishes how this final round is structured: "final round" names a round, not its sessions. The weights below therefore rest on the **Generic archetype** fallback (screen, hiring manager, panel), whose rule is flat weights, said plainly. They are not Stripe's documented process. All seven personas carry 3 questions each, so you meet every style here before you meet it live. If you learn who you are meeting, the weights change (see the upgrade menu).

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of gaps; "why this, why here, why now" | Flat. Relationship unknown, so no prior raises it; listed first because it holds the highest-ROI question | Rehearse the most predictable objection until it is boring; bridge only from things you actually did; where there is nothing, say so and give a ramp plan |
| B. Case / Strategist | Live problems from the role: plan this, diagnose that | Flat. Same reasoning | Clarify, objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| C. Values / Behavioral | Scenario probes, STAR-shaped stories, often from outside the function | Flat. Stripe's published values were not retrieved, so these questions use generic themes, not Stripe's own principles | "We" for context, "I" for your contribution; choose stories where the hard truth actually landed, and if none did, say so rather than supplying the ending |
| D. Data-Driven Prober | Asks how numbers were counted; follows up two levels deeper | Flat. Same reasoning | Know what you can and cannot say about how each figure was counted; name your weakest assumption first; say plainly when you do not know |
| E. Pressure / Stress | Interrupts, time-boxes, plays devil's advocate | Flat. Same reasoning | Pause, restate, anchor in what you actually said, hold through two follow-ups before conceding anything real |
| G. Peer Evaluator | Seam-splitting between adjacent teams; credit-sharing; "what would you need from me" | Flat. Same reasoning | Reciprocity framing; propose seam principles rather than pretending to know the seam; disagreement stories with spine and tact |
| H. Conversational / Rapport | Friendly, chatty; feels unscored and isn't | Flat. Same reasoning | A rehearsed 90-second arc for "walk me through it"; treat casual questions as scored; never waive the reverse-question slot |

Bank letters skip F so question IDs never collide with fit-snapshot rows.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI rehearsal in this pack.** Pick one requirement from the snapshot, or from the real JD once you have it, where your evidence is thinnest. One sentence naming it plainly. One sentence on the nearest thing you have actually done, only if something real exists. Then a concrete ramp plan for the first 60 days, said as a plan, never as a past. Hold: if pushed "is that really your weakest?", stay with your answer rather than swapping it for a flattering one. Concession wording: "Yes, that's a real gap, and here is how I'd close it." If you genuinely cannot name one, say which requirement you would most want to learn about from the team, and why | This objection arrives in some form in nearly every final round, and a rehearsed, non-defensive answer changes how the rest is heard. JD because it scores the role's requirements directly. Deepest rehearsal here means the most follow-up levels and exact concession wording, never more content |
| A2 | "Why Product Operations, rather than product management or program management?" | JD | [generic] | Say what draws you to the operations side of product in your own words: the work you want to do day to day. If something you actually did pointed you here, name it from your filled-in snapshot; if nothing did, say what you have learned about the role and why it fits how you like to work. Avoid framing it as a step toward a PM title unless that is true and you are willing to defend it | A motivation-consistency probe the Skeptic uses to test whether the candidate understands the role's boundaries; JD because it tests understanding of the job as stated |
| A3 | "I don't see launch coordination in your background — how would you handle it in this role?" | JD | [generic] | Use this shape only if the premise is true for you. If you have adjacent work, describe exactly what it was, at its real scope, from your F1 row. If you have none, say so plainly. Then a plan: who you would meet first, what readiness checklist you would want to see, and how you would learn from the last launch. Swap "launch coordination" for whichever F-row is thinnest for you | Rehearses the persona stem for a missing competency; JD because it scores the role's requirement against a gap |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A new product launches in six weeks in several countries. Sketch the launch-readiness plan. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, what "launched" means, which countries, what is fixed and what can move. Objective: a launch the support and sales teams can stand behind on day one. Structure by workstream: product readiness, support content and training, go-to-market, legal and compliance by country, internal comms. Name a go/no-go checkpoint and who owns each call. Metrics: readiness checklist completion before, early tickets and adoption after. Risks: one country's requirements slipping. Challenge one premise, for example whether all countries must launch together | A live problem central to the role (F1's requirement); CASE because it scores structure, not a fact about you |
| B2 | "Support tickets about one feature rose 20% in a month. Diagnose it." | CASE | [generic] | Clarify: rate or count, which segment, what changed that month. Split the hypotheses: more users of the feature, a product change or bug, a docs or UI confusion, a reporting change in how tickets are tagged. Say which you would check first and why: the cheapest one that rules out the most. Then who you would loop in and what you would send to product. End with how you would know it is fixed | The persona's "metric moved 20%" stem applied to feedback loops (F2); CASE because it scores diagnosis |
| B3 | "Product, support and sales each send you a different top-priority request this week. How do you decide?" | CASE | [generic] | State a rule before you apply it, for example customer impact, then reversibility, then effort. Walk the three requests through it out loud. Say who you tell no to, how, and what they get instead. Name the escalation path if two leaders disagree with your call | Tests F7 and F5 as a decision rather than a record; CASE because nothing about your past is presupposed |

### C. Values / Behavioral

Stripe's published values were not retrieved, so these questions use generic themes. Once you read Stripe's own values page, map a story from your snapshot to each value by name.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time it actually happened: it needs a named stake, the person you told, what you said, and what happened after, including if it did not land. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A standard values stem, and a likely one for an operations role that has to surface bad news about launches; VAL because it scores behaviour against values |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a real trade-off: what the metric was, what the customer needed, what you chose, and what it cost. If you never faced that trade-off, say so plainly, then describe how you would make that call | Customer-versus-metric trade-offs sit at the centre of feedback-loop work (F2); VAL because it tests behaviour, not knowledge |
| C3 | "A senior stakeholder asks you to skip a launch checklist step to hit a date. What do you do?" | CASE | [generic] | Ask what the step protects against first. Separate what can be safely deferred from what cannot. Offer an alternative: a narrower launch, a dated follow-up, or an explicit risk sign-off by the person asking. Say how you escalate if you still disagree, and how you keep the relationship intact | A values theme asked as a live decision, so it presupposes nothing about your past; CASE because it scores reasoning |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you've reported in your work. Walk me through how that number was counted." | EXP | [generic] | Choose one figure from your F3 row that you personally reported. Then, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of the work was yours. "I don't know exactly how it was counted" is an honest answer. If you have never reported a figure, say so plainly and say what you would measure first in this role | The Prober's core stem; EXP because it tests whether your own numbers survive scrutiny |
| D2 | "What operational metrics would you track for Product Ops, and which would you defend least?" | JD | [generic] | Group them: launch health (on-time readiness, early tickets), feedback loop (time from report to product decision), process efficiency (manual hours removed). Pick two or three, not ten. Then name the one you would defend least and why, before they ask | Tests F3's requirement as a design question; JD because it scores the role's stated work |
| D3 | "A dashboard shows adoption of a new feature up 30%, but support contacts are up too. What do you ask before you report it?" | CASE | [generic] | Denominators first: new users versus existing, contacts per user. Time window and any tracking change. Whether the contacts are about the new feature. Then what you would report and what caveat you would attach | A two-level-deep data probe set as a live problem; CASE because it presupposes nothing about you |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That result — how much of it was actually you?" | EXP | [generic] | Arrives after any story you tell. Restate what the team did in one clause, then exactly what was yours, at its real size. Hold that through two follow-ups. If part of what you described was someone else's, concede it specifically and stay with your own share. Never grow your role to restore the mood | The stress stem that tests attribution honesty; EXP because it scores what was actually yours |
| E2 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then three beats in under a minute: what you bring from outside, one example from your snapshot that shows it, and what you will do in the first month. Concede the obvious: an internal candidate knows the systems; say how you would close that | Time-boxed composure test; JD because it scores your fit to the role |
| E3 | "Your plan for B1 is too slow. Convince me or change it." | CASE | [generic] | Hold first: restate your reason for the pace. If they bring a fact you did not have, concede it explicitly and adjust one part of the plan, not the whole thing. Name what you would cut and the risk you would accept | Practises hold-then-concede on a case answer; CASE because it scores reasoning under pressure |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | CASE | [generic] | Do not claim to know the seam. Propose principles: who owns the decision versus who is consulted, how you escalate, how often you sync. Then how you would disagree: privately first, with data, with a deadline for deciding | Tests F5 as partnership fit; CASE because it is a live design question |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick a real shared project from your snapshot: who did what, how you named others' parts, and how you described your own. If no example comes to mind, say so plainly and say how you would handle it | The Peer's credit-sharing stem; EXP because it scores how you describe your own past contribution |
| G3 | "What would you need from me in your first 90 days, and what would you bring my team?" | JD | [generic] | Lead with what you bring, then what you need: context on recent launches, the feedback channels they trust, one recurring meeting. Keep it specific and short | Reciprocity check; JD because it scores how you would do the job alongside peers |

### H. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So — walk me through the journey." | EXP | [generic] | A rehearsed 90-second arc built only from your filled-in snapshot: where you started, the turn that led toward operations work, what you are best at now, and why this role next. Time it out loud | The biography opener that is scored even when it feels casual; EXP because it is your own history |
| H2 | "Why Stripe, and why now?" | CO | [generic] | Build it from what you have read on Stripe's own pages, not from this pack: one thing about the company that matters to you, one way the role fits it, and why now in your own path. Read Stripe's site and recent announcements before the interview so you sound current | Asked in nearly every final round; CO because it scores homework. Generic because no research ran |
| H3 | "What do you think a company at our scale needs most from Product Ops?" | CO | [generic] | Answer with a view, not a list: one or two needs you would expect, such as consistent launches across many products or fast routing of customer feedback, and why. Then ask what they see as the biggest gap today | Tests whether you can think at the company's level; CO because it scores altitude, generic because no Stripe strategy was retrieved |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | B1, A3, E3, C3 |
| F2 Feedback into product | B2, C2 |
| F3 Operational metrics | D1, D2, D3 |
| F4 Process and tooling | B3, G1 |
| F5 Influence without authority | B3, G1, G3, C1 |
| F6 Written communication | none: a spoken bank cannot rehearse writing; if your final includes a written exercise, the recruiter's note would add a build section for it |
| F7 Prioritisation and escalations | B3, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Where does Product Ops sit relative to product managers and program managers here, and where does the seam cause friction?" | Shows you understand the role's boundaries, and tells you what you would actually own |
| R2 | "What does a great first six months look like in this role, and what would make you say it hasn't worked?" | Gets the real scorecard, which no JD states fully |
| R3 | "Which recent launch went least smoothly, and what changed afterwards?" | Signals you think in post-mortems, and reveals whether the team learns |
| R4 | "How does customer feedback reach product decisions today, and where does it get lost?" | Goes straight to the problem the role is likely hired to fix, and invites the interviewer to describe it |
| R5 | "What would you want a new person to take off your plate in their first month?" | The reciprocity question; it turns the interview toward what you would contribute |
| R6 | "What's the next step after this round, and when should I expect to hear?" | Practical, and it closes the loop on timing without sounding anxious |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No sentence of yours is in this pack, so there is nothing to inflate and no stated negative to hold. Requirements your material is silent on are not listed here: they are the scaffolds above | Once you add your CV or describe your experience, this list fills with the stretched versions of your own sentences, and each answer is held to its quote |

## Sources

Provided documents: none. The only input was your message: company (Stripe), role (Product Operations Manager), round (final round).

Searches sent, all refused by this host's permissions:

- "Stripe operating principles": refused
- "Stripe interview process final round onsite operations": refused
- "Stripe Product Operations Manager job description": refused
- "Stripe 2026 news strategy stablecoins agentic commerce": refused

No page fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. Would have given Stripe's principles by name, a values cheat sheet, and VAL questions mapped to them; C1 and C2 stay generic |
| 2. Stripe interview process, product operations | unavailable | Search refused. Would have named the final round's sessions and set persona weights; the Generic archetype with flat weights stands in |
| 3. Stripe strategy and recent news | unavailable | Search refused. Would have grounded H2 and H3 and at least one CASE question in Stripe's current priorities |
| 4. Interviewer name at Stripe | n/a | No name was given, so there was no query to form; no interviewer read |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. Would have replaced the `[generic]` fit-snapshot rows with quoted, `[inferred]` requirements |

## Upgrade menu

- The real JD text → F1 to F7 become the posting's own quoted requirements, `[grounded]`, and every JD question is checked against its list
- Your CV, or a few sentences on your experience → the fit snapshot stops being a worksheet: your own sentences fill the evidence column, the Skeptic bank targets your real thinnest row, and the prohibited list fills in
- Who you are meeting and their relationship to the role → persona weights read from the relationship instead of flat ones, and reverse questions tuned to them
- An interviewer's name → a public-footprint read and a reverse question tied to their own path
- If your final is several sessions, the schedule → one mini-pack per session with its own weights and bank
- The recruiter's prep email → coverage of any pre-declared deliverable, such as a presentation or written exercise, with its own build section
- Web research allowed → Stripe's principles by name, a values cheat sheet, its documented process, and current strategy for the CO and CASE questions; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) adds a strategy brief and loop reports
- A tuesday-dossier.md from underwriting this role → evidence-derived highest-ROI objection and a prohibited-claims guardrail; the pack is complete without one
