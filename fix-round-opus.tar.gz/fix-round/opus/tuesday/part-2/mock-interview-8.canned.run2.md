I've built your prep pack for the three rounds on 21 November, with a separate section for each round. Interviewers haven't been named yet, so each round is prepared around the interviewer's role (recruiter, your future manager, two branch managers).

**What matters most in the nine days:**
- **The question to rehearse hardest is C1, in Round 2 with your future manager.** It goes roughly: "You handled your branch's complaints log, and you haven't worked in a contact centre. This role covers branches and the contact centre. Why are you ready?" The pack gives you a four-part answer and the two likely follow-ups.
- **The two gaps you named yourself get plain wording, not cover.** Those are the contact centre and presenting above regional level. Say "I haven't worked in a contact centre" and "I've never presented to anyone above regional level", then give a plan for each. Trying to stretch your way around either one will come apart under a follow-up question.
- **The 20-minute case has a timed structure.** It runs from clarifying the complaint through to closing the loop, and each step is tied to one of Ashgrove's four values. That matters because the panel scores against the values.
- **Some answers depend on facts only you know.** Before the 21st, pin down three things: what your monthly spreadsheet actually tracks, whether it's in Excel, and whether the branch's complaints log came under a regulator's rules. The interviewers are likely to ask about all three.
- **Watch the wording on what you've done.** The pack lists phrases to avoid, like "I wrote the escalation script" when it was "our escalation script", or "coached supervisors" when you trained new tellers.

I didn't run any web searches. Everything comes from the job description, values, recruiter email, strategy points and background you gave me. One gap: the case build uses a generic complaint-handling clock. Refresh the real deadlines and the member's referral rights for Ashgrove's regulator before the day.

Files are in the working directory:
- ashgrove-credit-union_member-experience-lead_interview_pack.md

Say the word and I'll play your future manager on C1, the question the pack names as its highest-ROI prep. Or I can run the panel's 20-minute case with you.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 21 November 2026, as your recruiter set them out:

1. Recruiter, 30 minutes
2. Head of Member Services (your future manager), 45 minutes, "mostly behavioural"
3. A panel of two branch managers, 60 minutes, including "a 20-minute case on a complaint escalation". The panel is also the values round: "they score against the four values"

**Mode:** loop. One shared fit snapshot, then a mini-pack for each round. Interviewer names haven't been assigned yet, so each round's personas are based on the interviewer's role.

---

## How to use this pack

- **Personas** describe how a question is asked: who is asking, and in what style. **Types** describe what the answer is scored on.
- **Guidance is scaffolding, not a script.** Every suggested line is a proposal waiting for your approval. Put it into your own words, and drop anything that isn't true for you.
- **An answer slot** is an instruction for the interview, not a question for you now. It names a follow-up the interviewer is likely to ask and gives you two honest branches. Either branch is a good answer.
- **Provenance labels:** `[grounded]` means it traces to something you or the employer gave me. `[inferred]` means it's derived, and the row names the derivation. `[generic]` means a common pattern for this kind of role, with no claim about Ashgrove or about you.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether your stated experience holds up under scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know Ashgrove's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

---

## Prep triage: nine days, 12 to 21 November

1. **Days 1–2: C1**, the highest-ROI question in the pack. Rehearse it aloud until it's boring, including both follow-ups.
2. **Days 2–4: the case build** (section below). Run it twice against a 20-minute timer, out loud.
3. **Days 3–5: the values cheat sheet** (Round 3). Each value has a scaffold. Find one real story per value, or settle on your honest branch.
4. **Day 4: your answer slots.** Work out, for yourself, what the complaints spreadsheet tracks and in what tool (F3, F9), and whether the formal complaints log came under a regulator's rules (F7). These are facts you already know, so get them straight before someone asks.
5. **Day 5: refresh the complaint-handling rules Ashgrove works under.** That means the regulator, the response deadlines and the member's referral rights. The case build uses a generic clock until you have them.
6. **Day 6: Round 1 short answers** (A1, A4–A7). Your 90-second arc should fit in 90 seconds.
7. **Days 7–8: drills.** One on C1 and one on the case. Pick two reverse questions per round.
8. **Day 9: rest.**

Everything else in the pack is insurance.

---

## The fit snapshot

Your sentences, quoted exactly from your message. Everything this pack says about your past comes from these four:

- **Q1** "6 years in retail banking, the last 3 as a branch supervisor."
- **Q2** "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- **Q3** "I built the monthly complaints spreadsheet our regional manager uses."
- **Q4** "Never worked in a contact centre, and I've never presented to anyone above regional level."

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branches half) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes the branch's formal complaints log, not a process across branches, and your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: "end to end" makes a probe on what handling the log involved likely. If parts of a complaint's handling beyond the log were yours to decide, say which and how, in your own words. If there was no such step, or it wasn't yours, say so plainly and stay with the log you handled |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact centre half) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this gap yourself, and no wording closes it. Say: "I haven't worked in a contact centre." Then say how you'd learn it, as a plan and never as a past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote is about monthly complaint reporting, but it doesn't show what the spreadsheet counts or who reports from it. Your words stay at the quote: you built it, and your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect "what does it track?" If it tracks either, say how, in your own words. If it tracks neither, say so plainly and say what it does track |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes training new tellers on "our" escalation script. That isn't coaching supervisors, and it doesn't say you wrote the script. Say: "I trained new tellers on our escalation script." Answer slot: if you coached anyone beyond new tellers on escalations, say who and how. If you didn't, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital work either way. Strong evidence here would be a member-facing change you worked on with a digital or app team, and the part that was yours. Answer slot: if you've done that, say what it was and which part was yours. If you haven't, say so plainly and say how you'd use complaint data to help a digital team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Say it in its own words, "Six years in retail banking, the last three as a branch supervisor", and let them map it onto the requirement. Don't relabel it as "customer operations" |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | A "formal complaints log" is close to this requirement, but it doesn't show which rules the complaints were handled under. Answer slot: if the log was kept to a regulator's complaint rules, say which rules and what part was yours. If you don't know, or it wasn't, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this gap yourself. Say: "I've never presented to anyone above regional level." Then describe how you'd prepare, as a plan. Answer slot: if you have presented at regional level, say what and to whom, in your own words. If you haven't, leave regional level out. Your sentence doesn't say you have |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says "spreadsheet", not which tool. Answer slot: if it's in Excel, say so and what you did in it. If it's another tool, name it plainly and keep the claim to the spreadsheet you built |

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter said there will be "a 20-minute case on a complaint escalation" and that the panel scores "against the four values". You haven't been given the scenario, so this build is a structure, not an answer.

**Facts to build on:**

| Fact | Source | Provenance |
|---|---|---|
| The role will "coach branch supervisors on escalations" and "Own the member complaints process end to end across branches and the contact centre" | JD | [grounded] |
| "Members First, Always — we decide from the member's side of the counter." "Own the Fix — whoever finds the problem keeps hold of it until it is solved." "Plain Words — if a member needs it explained twice, we wrote it wrong." "Neighbours, Not Numbers — every branch is part of its town." | Values page text you pasted | [grounded] |
| If they ask whether you've done this kind of work: F1 / F4, "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your message | [grounded] |
| Regulated-complaint deadlines and referral rights | Not in your materials. Use the rules you already know, stated as such, or describe a clock without numbers | [generic] |

**A 20-minute structure (think aloud throughout):**

| Minutes | Move | Value it serves |
|---|---|---|
| 0–3 | Clarify. What is the complaint, and how long has it been open? Which channels has the member used? What has the branch already said or promised? Is it a formal complaint under the rules? Any sign the member is in a vulnerable situation? | Members First |
| 3–7 | The member first: contact them, acknowledge the complaint, and tell them in plain words what happens next and by when | Members First, Plain Words |
| 7–12 | Investigate and decide. Gather the facts, the policy and the regulatory clock. Name one owner who keeps hold until it's solved | Own the Fix |
| 12–16 | Coach the branch supervisor: debrief what happened and agree what changes. Don't take over the branch by default | Neighbours, Not Numbers |
| 16–20 | Close the loop: final response to the member, the log entry, the root cause, whether it's a trend for the monthly report, and whether a digital journey needs fixing | Own the Fix, Plain Words |

**Theses, each with its mandatory concession:**

| Thesis | Concession you say aloud | Provenance |
|---|---|---|
| One named owner from first contact to close | Handoffs sometimes happen (absence, a specialist team). Say how the handoff keeps hold rather than dropping it | [grounded] on the Own the Fix text |
| Repair things with the member before you debate the policy | You can't promise an outcome before you have the facts, and acknowledging the complaint is not admitting fault | [grounded] on the Members First text |
| Every escalation is both a coaching moment and a data point | One case isn't a trend. Don't redesign a process around a single complaint | [grounded] on the JD's coaching and reporting lines |

**Differentiation:** the consensus answer is "apologise, investigate, resolve, follow up", and every prepared candidate will give it. Cover it in one breath, then go further. Say who keeps hold of the complaint, how the supervisor gets coached rather than overruled, and how the case feeds the monthly report and the digital team.

**Anti-pick:** two things to avoid. Don't offer a goodwill payment or blame the branch before you have the facts. And don't take the case away from the branch automatically. Two branch managers are scoring you.

---

## Grounding brief

Based on the four points you summarised from the July 2026 strategy brief. I haven't seen the brief itself.

| Item | What it says | Provenance | Where it can show up |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] strategy brief, per your message | G1, D2 and the JD's self-service line |
| Branch consolidation | Eight branches become five hubs over 2027 | [grounded] strategy brief, per your message | J3, K2 and reverse questions. Both panel members are branch managers |
| New product | A small-business lending product launches in Q1 2027 | [grounded] strategy brief, per your message | Reverse question R2-6 |
| Competition | The main competitive pressure is app-only banks | [grounded] strategy brief, per your message | G1 |
| Vocabulary | Say "member", not "customer". Also use "hubs", "self-service journeys" and "digital channels" | [grounded] JD, values text and brief | Everywhere |
| Tension: consolidation and Neighbours, Not Numbers | Closing branches into hubs sits close to "every branch is part of its town". Expect the panel to probe how you'd handle complaints about the change | [inferred] from the brief and the values text together | J3, K2 |
| Tension: digital shift and complaint routes | Moving 40% of service to digital likely changes where complaints arrive | [inferred] from the brief's 40% target and the JD's self-service line | G1, D2 |

---

# Round 1: Recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, motivation and logistics | High. A recruiter screen's default register, and the recruiter already knows the loop | Pre-script a 90-second arc. Treat casual questions on JD topics as scored |
| Skeptic (light) | Knockout checks on the JD's listed requirements | Medium. Recruiters screen for the hard requirements before passing a candidate on to the manager | Short, plain answers on the stated gaps (F2, F8). Don't defend at length here |

### Question banks — Round 1

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in three beats, each at its quote's own scope. Six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log and trained new tellers on our escalation script. You built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words (A2) | F6, F1, F4 and F3 together are the background the recruiter screens against; EXP because it sets the record the later rounds will probe |
| A2 | "What draws you to Ashgrove, and to member experience specifically?" | CO | [grounded] | Name one value by its exact name and one strategy point from the grounding brief, then give your real reason in your own words. Don't recite all four values. This answer makes no claim about your past | Motivation is the recruiter's consistency check across rounds; CO because homework on values and strategy separates candidates |
| A3 | "Why a member-owned credit union, after retail banking?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Keep to the fact in the quote, retail banking, and give your reason in your own words. Don't criticise your current employer. Answer slot: if member ownership itself is part of the reason, say what about it. If it isn't, say so plainly and give the reason that is real | F6's quote is the premise; a sector move invites a motivation probe |
| A4 | "The JD asks for 4+ years in financial-services customer operations — how does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the quote's words: "Six years in retail banking, the last three as a branch supervisor." Stop there and let them map it. Answer slot: if they ask what those years involved day to day, say so in your own words | F6 is a no-gap row, so a short answer is the strong one; JD because it's a listed requirement |
| A5 | "The monthly reporting here is in Excel — how comfortable are you there?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the quote: you built it, and your regional manager uses it. Answer slot: the JD names Excel, so expect "is that in Excel?" If it is, say so and what you do in it. If it's another tool, name it plainly and keep the claim to the spreadsheet you built | F9 and F3 both rest on this quote; it's a likely knockout check |

**Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A6 | "The role covers the contact centre too — have you worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain and short: "I haven't worked in a contact centre." Then one sentence of plan, such as how you'd spend early weeks with contact-centre colleagues. Say it as a plan, never as a past. Don't pad it. The full answer belongs in Round 2 (C1) | F2 is a stated gap the recruiter will screen on; JD because it's in the first line of the role |
| A7 | "Have you presented to senior leadership before?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and to whom. If you haven't, say so. Don't turn "our regional manager uses" (your spreadsheet) into "I present it to" | F8 is a stated gap; the JD lists it as a requirement |
| A8 | "What are you looking for on salary, and what's your notice period?" | JD | [generic] | Have a number and your notice period ready before the call. That's all this question needs | Recruiter screens commonly close on logistics; the pack can't supply these facts |

### Reverse questions — Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "For the 20-minute case, will I get the scenario beforehand or on the day, and is it spoken or written?" | It shapes your case prep and shows you take the graded part seriously |
| R1-2 | "Does the panel score each of the four values separately?" | It tells you whether every value needs its own story |
| R1-3 | "Will interviewer names be shared before the 21st?" | It upgrades this pack (see upgrade menu) and is a normal thing to ask |
| R1-4 | "Does the role cover the contact centre from day one, or is that phased?" | It addresses your F2 gap without asking for allowance |
| R1-5 | "What happens after the 21st, and when should I expect to hear?" | It covers logistics and signals you're organised |

---

# Round 2: Head of Member Services, your future manager (45 minutes, "mostly behavioural")

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scope jump: one branch's log against a cross-channel process | Highest. A hiring manager is de-risking gaps, and F1, F2 and F8 are the visible ones | Rehearse C1 until it's boring. Hold on your quotes, concede the stated gaps exactly, and give a ramp plan |
| Values / Behavioral | "Tell me about a time…" prompts | High. The recruiter said "mostly behavioural" | STAR shape. Use "we" for context and "I" for your contribution. Use the honest branch where you have no story |
| Data-Driven Prober | Questions on the spreadsheet and what it counts | Medium. The JD's monthly reporting line, and Q3 is your only number-adjacent claim | Know what the spreadsheet counts. Say plainly if you don't know something |
| Case / Strategist | Live problems on the digital shift and your first 90 days | Lower. "Mostly behavioural" leaves less room, but a manager still tests the roadmap | Clarify, then structure, then answer. Use Ashgrove's own vocabulary |

### Question banks — Round 2

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You handled your branch's complaints log, and you haven't worked in a contact centre. This role owns complaints end to end across branches and the contact centre. Why are you ready for that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | **The highest-ROI prep in this pack.** Beat 1, your facts at their own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script. I built the monthly complaints spreadsheet our regional manager uses." Beat 2, name the limit before they press: "I haven't worked in a contact centre." Beat 3, answer slot: if parts of a complaint's handling beyond the log were yours to decide, say which and how. If none were, say so plainly and stay with the log and the training. Beat 4, a ramp plan said as a plan: e.g. time in the contact centre, mapping how a complaint moves through each channel, reading the existing complaint data. **Follow-up 1:** "A branch log isn't a process across eight branches." Hold by returning to what you did, never by adding to it, and concede that the scope is bigger. **Follow-up 2:** "So what would you do in week one in the contact centre?" Give the plan, concretely | F1, F2 and F3 meet here, and the JD's first line presses on all three; JD because it scores the headline responsibility |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose one of your two stated gaps and say it plainly: the contact centre, or presenting above regional level. Then give the plan. Don't offer a disguised strength | F2 and F8 give you a true answer; the question tests self-assessment |
| C3 | "How would you present monthly complaint trends to the senior leadership team?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Structure: one headline, what changed and why, what it means for members, and the decision you need from them. Plain words, which is a value. If they ask whether you've done this: "I've never presented to anyone above regional level." Then say how you'd prepare | F8 is the gap, but the question is a live problem; CASE content, JD requirement |
| C4 | "Why a branch supervisor over someone who has run a contact-centre complaints team?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold, then concede. Hold on what the quotes carry: six years in retail banking, the last three as a branch supervisor, and the complaints log and teller training. Concede exactly: "I haven't worked in a contact centre." Don't fold on the branch experience to restore harmony, and don't claim the other candidate's experience | F6, F1 and F2 set against a likely competitor profile; pressure in a Skeptic's register |

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a member complaint escalated beyond the first response." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick a complaint you dealt with yourself. The story needs what the member wanted, what you did, what was yours and what was someone else's, and how it closed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the formal complaints log you handled, or how you would handle one | The JD's escalation line and the recruiter's case theme; F1's quote names the log but no single case |
| D2 | "Tell me about a time you trained someone and it changed how they handled a member." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: you trained new tellers on our escalation script. Tell the beats the quote states in your own words. Answer slot: the JD's "coach branch supervisors" makes a probe on coaching anyone more senior likely. If you did, say who and how. If you didn't, say so plainly and stay with the tellers | F4 is the bridge to the coaching requirement; VAL because it's behavioural |
| D3 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot, on the Own the Fix text: if the spreadsheet started because you spotted a problem, say what the problem was and where it ended up. If you were asked to build it, say so plainly and choose another story. If none comes to mind, say so, and give the nearest thing your material carries or how you would handle it | Own the Fix is a raising source; F3's quote is the nearest material but doesn't say why it was built |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built — what does it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built it, and your regional manager uses it. Answer slot: what it counts, in your own words. The JD names volumes and resolution times. If it tracks either, say how. If it doesn't, say so and say what it does track. Name the measure in it you'd defend least before they ask. If you don't know how something in it is counted, say so | F3 and F9 rest on this quote, and it's the closest thing you have to the JD's reporting duty |
| E2 | "Complaint volumes rose 20% last month. What do you look at first?" | CASE | [generic] | Clarify: did the definition or the logging change? Then segment by channel, branch and complaint type. Separate volume from resolution time. Check whether a new digital journey moved complaints rather than created them. End with the action and how you'd report it | The JD's monthly reporting line, asked as a live diagnosis; no claim about your past |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "We're moving 40% of member service to digital by 2028, and app-only banks are the pressure. How should complaints change?" | CO | [grounded] | Clarify where complaints arrive today. Then cover: one log across all channels, a way to complain inside the app, complaint data fed back to the digital teams, and plain words in self-service journeys. Risk to name: members who don't use digital channels. Makes no claim about your past | The strategy brief and the JD's digital line; CO because it tests strategy fluency |
| G2 | "What would you do in your first 90 days?" | CASE | [grounded] | Listen first: branches, the contact centre, the existing complaint data. Then baseline volumes and resolution times, map the escalation routes, and pick one fix to deliver. Say it as a plan. It makes no claim about your past | A manager's standard roadmap probe; JD responsibilities supply the structure |

### Reverse questions — Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What does the monthly complaints report look like today, and what do you wish it told you?" | It invites them to describe the job's core output, and your F3 spreadsheet is a natural follow-on |
| R2-2 | "Where do complaints get stuck today: in branches, in the contact centre, or between them?" | It shows you think end to end, the JD's own phrase |
| R2-3 | "Who sees the monthly report, and would I present it myself?" | It tells you how big the F8 gap really is, without arguing it |
| R2-4 | "How will the 2027 hub consolidation change who handles complaints locally?" | It shows strategy fluency on the change closest to this role |
| R2-5 | "What would tell you, six months in, that this hire worked?" | It makes their success criteria explicit |
| R2-6 | "Will the small-business lending product in Q1 2027 come with its own complaint routes?" | A new product brings new complaint types, and few candidates will connect the two |

---

# Round 3: Panel of two branch managers (60 minutes, including the 20-minute case; the values round)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One prompt or more per value, scored against the four values | Highest. The recruiter said the panel "score against the four values" | The values cheat sheet below. One real story per value, or the honest branch |
| Case / Strategist | The 20-minute case, plus follow-ups that twist it | High. Announced by the recruiter | The case build above. Think aloud and clarify first |
| Peer Evaluator | "You'd be coaching my supervisors — where's the line?" | Medium. Branch managers own the supervisors the JD says you'd coach | Reciprocity: what you bring their branch. Propose principles for the boundary, not a turf claim |
| Pressure | Time-boxed "why you" and attribution probes | Lower, but panels often have one tougher member | Hold, then concede. Pause before answering |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's point of view, not the branch's | Selection scaffold: a time you chose what was right for the member when it was harder for the branch. It needs the member's need, your choice, and the cost you accepted. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script.") or how you would handle it |
| Plain Words | If you have to explain it twice, rewrite it | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if you made the script easier for the tellers to follow, say how. If you didn't, say so and use the scaffold: a time you explained something so a member understood it first time. If none, say so plainly |
| Neighbours, Not Numbers | Each branch belongs to its town, so treat it as more than a figure on a report | Selection scaffold: a time a member's local situation mattered more than the standard answer. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because you spotted a problem, say what the problem was and how it ended. If you were asked to build it, say so and use the scaffold: a problem you found and saw through. If none, say so plainly |

### Question banks — Round 3

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter, even when it was harder for the branch." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use the cheat sheet's Members First scaffold. STAR shape: "we" for the branch context, "I" for your decision. If no story fits, use the honest branch, not an invented one | The Members First text supplies the theme; F1's quote is the nearest material |
| H2 | "Tell me about a time you explained something so a member got it first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use the cheat sheet's Plain Words row, including its answer slot on the script. Keep the script as "our escalation script", never "my" | The Plain Words text supplies the theme; F4's quote is nearby |
| H3 | "Tell me about a time a member's local situation mattered more than the standard answer." | VAL | [generic] | Use the cheat sheet's Neighbours, Not Numbers scaffold, honest branch included. This value has no story in your material | The Neighbours, Not Numbers text supplies the theme; no fit-snapshot row carries it |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Use the cheat sheet's Own the Fix row and its answer slot. If you tell D3's story in Round 2, it's fine to reuse it here | The Own the Fix text supplies the theme; F3 is the nearest quote |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member has complained twice at a branch, rejected the response, and says they'll go to the regulator. Walk us through it." | CASE | [generic] | Use the case build's 20-minute structure. Clarify first, put the member first, name one owner, coach the supervisor, close the loop. Say the concession on each thesis aloud. Tie each move to a value by name, briefly | The recruiter announced a complaint-escalation case; the scenario here is a stand-in, labelled generic |
| J2 | "Twist: the branch supervisor already promised the member a refund outside policy. Now what?" | CASE | [generic] | Separate the member's position from the supervisor's mistake. Deal with the member honestly, decide who can authorise the refund, then coach the supervisor privately. Don't blame them in front of the member. Covers the JD's coaching line | The JD's "coach branch supervisors on escalations" makes this follow-up likely |
| J3 | "Twist: the member says service got worse because their branch is becoming a hub." | CASE | [inferred] | Acknowledge it in plain words. Find out what actually went wrong for this member. Log it as a complaint about the change, if that's what it is, so the trend is visible. Stay neutral on the consolidation decision itself. Makes no claim about your past | Inferred from the brief's eight-to-five consolidation together with Neighbours, Not Numbers; both panel members are branch managers |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You'd be coaching my supervisors on escalations. How do you do that without stepping on how I run my branch?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | You can say: "For the last three years I've been a branch supervisor." Let them draw the inference. Then propose principles for the boundary: you coach on escalations, the manager runs the branch; you agree the approach with the manager first; you bring data back to them. Reciprocity: say what their branch gets from this | F6's quote is the relevant fact; the JD's coaching line puts you inside their branches |
| K2 | "When complaints are a branch's fault, how do you report it without it turning into a league table?" | CASE | [grounded] | Report trends and causes, not rankings. Share a branch's data with its manager first. Pair every figure with what's being done about it. This is Neighbours, Not Numbers applied to the JD's monthly report | A branch manager's real worry about the reporting duty; tests values and judgement together |
| K3 | "What would you need from branch managers to make the monthly report useful?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Reciprocity. Ask what they'd want from it, then say what you'd need: consistent logging, context on outliers, a named contact. If useful, mention you built the monthly complaints spreadsheet your regional manager uses. Don't extend that to "the region uses" | F3's quote is the honest link; peers score whether you'll add to or reduce their workload |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you over someone from the contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause, then hold on what Q1 carries, six years in retail banking with the last three as a branch supervisor, and add one line on why branch experience matters to this panel. Concede plainly: "I haven't worked in a contact centre." Hold through two follow-ups. Don't fold on the branch experience | F6 and F2; pressure because it's time-boxed |
| L2 | "That spreadsheet — how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "I built it." Answer slot: if others contributed, say who did what. If it was yours alone, say so. Keep "our regional manager uses" exactly as it is: one user, said as one | F3 is your one ownership claim, which makes it a natural target for an attribution probe |

### Reverse questions — Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What do your supervisors find hardest about escalations today?" | It's about the exact people you'd coach, and it signals you'll listen first |
| R3-2 | "What could someone in this role do in their first month that would genuinely help your branch?" | The reciprocity question. Branch managers are your partners here |
| R3-3 | "When a member complains about a branch now, how does it reach you, and what would you change?" | It shows you want their view of the process, not just head office's |
| R3-4 | "How are your branches preparing for the move to hubs, and where could complaints handling help?" | It acknowledges the change they're living through, carefully |
| R3-5 | "Which of the four values gets tested hardest in complaints?" | You're asking about values in the values round, and it invites their own stories |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | A6, C1, C4, D1, G2, J1, L1 |
| "report monthly on complaint volumes and resolution times" | A5, C3, E1, E2, K2, K3 |
| "coach branch supervisors on escalations" | D2, J2, K1 |
| "work with digital teams on self-service journeys" | G1, E2 |
| "4+ years in financial-services customer operations" | A1, A4 |
| "experience handling regulated complaints" | J1, D1. The F7 answer slot goes into both |
| "confident presenting to senior leaders" | A7, C2, C3 |
| "comfortable with Excel reporting" | A5, E1 |

Each of the four values: H1–H4, plus D3.

---

## Prohibited claims

Claims this pack won't coach. They're the ones that are tempting under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process (across branches) | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." Your material describes one branch's log, not a process |
| Has worked in a contact centre | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote: "I trained new tellers on our escalation script." Your material says new tellers |
| Wrote or designed the escalation script | Inflated form of F4 | It's "our escalation script". Say it that way |
| Has presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." |
| Presents the spreadsheet to the regional manager | Inflated form of F3 | F3's quote: "our regional manager uses" it. "Uses" is not "I present it to" |
| Reports on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The E1 slot asks only what the spreadsheet tracks |
| Has handled regulated complaints | Inflated form of F7 | F7's quote: "the branch's formal complaints log". The slot asks which rules applied |
| Built the spreadsheet in Excel | Inflated form of F9 | F9's quote says "spreadsheet". The A5 slot asks which tool |
| Six years in customer operations | Inflated form of F6 (JD vocabulary) | F6's quote: "six years in retail banking, the last three as a branch supervisor" |

---

## Sources

**Provided documents:**

- The JD, pasted.
- The values text, pasted. You copied it on 12 November 2026 from ashgrovecu.org/about/values. I didn't fetch the page.
- The recruiter's email describing the three rounds, pasted.
- Your summary of the four points in Ashgrove's July 2026 strategy brief. The brief itself wasn't provided.
- Your background, from your message.

No dossier was present.

**Searches and fetches:** none were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted, copied this morning, fixes the cheat sheet and the H bank |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email sets out the loop: three rounds, who runs each and what each holds. The persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief is under six months old and supplies the priorities in the grounding brief and the CO questions |
| 4. Interviewer names | n/a | No names have been assigned, so there was no query to form |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → a section on reading each interviewer, persona weights per panel member, and a reverse question tied to each person's path.
- **Your answers to the answer slots** (what the spreadsheet tracks and in what tool, whether the log came under a regulator's rules, an escalation story, and whether you've worked with a digital team) → F3, F5, F7 and F9 become sharper rows, and A5, D1, E1, H1 and the case build's facts become story-mapped instead of scaffolded.
- **Your CV** → more quoted sentences to draw on, and some values scaffolds (H1, H3) may become mapped stories.
- **The full strategy brief, not just four points** → quoted figures and vocabulary in the grounding brief, and sharper G1 and J3.
- **The country and regulator Ashgrove's complaints come under** → the case build's generic clock becomes the real deadlines and referral rights.
- **The case format, from the recruiter** (scenario in advance or on the day, spoken or written) → a case build tuned to the format. Usually one email.
- **Deep research** → up to 6 more searches and 2 more fetches, several more minutes. It adds recent Ashgrove news and organisational context, plus reports from candidates who've interviewed there, to the grounding brief.
- **A tuesday-dossier.md from an earlier fit review** → confirmed evidence and a named objection to rehearse. Not needed; this pack is complete without one.
- **Hours per day you can prep** → a triage sized to your actual time.
