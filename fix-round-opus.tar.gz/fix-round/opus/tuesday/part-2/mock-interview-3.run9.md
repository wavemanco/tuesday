I've built your prep pack and saved it as `Stripe_product-operations-manager_interview_pack.md`. It assumes your final round could be any of several interview styles, because I don't know who you're meeting.

The pack is generic for now. You haven't given me a job description, a CV or interviewer names yet, and this session didn't have permission for web search. So it has none of Stripe's published operating principles, its actual interview loop, or its current strategy. It doesn't invent them either.

What's in it:
- **Requirements worksheet:** eight typical Product Ops requirements, each with what strong evidence looks like and how to pick your own story for it.
- **Practice questions:** 22 questions across seven interviewer styles, weighted toward case questions and behavioral questions.
- **Questions to ask them:** six, each with why it works.
- **What would sharpen it:** a closing list of what each missing input would change.

**Most worth rehearsing:** C1, "Which part of this role would you be weakest at on day one?" Until I've seen your background, that's the objection I'd prepare for first.

If you want, I'll play the skeptical interviewer on C1 for a live practice run.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry it into later sessions.
And I can convert the pack to a Word document if that's easier.

1. Who are you meeting in the final round (hiring manager, peers, a skip-level, someone from another team), and did the recruiter mention focus areas or a case or presentation to prepare? The answer changes how every question bank is weighted.
2. Can you paste the job description and your CV? Either one turns the worksheet into a real fit assessment. If you'd rather not, the pack still works as it is.
3. Do you want to allow web search for this session? With it, I'd rerun the four Stripe searches and add their principles by name, the interview structure and current strategy.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. **Interviewer(s):** not known. **Relationship:** not known.

Built from one input, your message naming the company, the role and the round. No job description, no CV and no interviewer names were given, and the web searches this pack tried were refused by this session's permissions. So every row below is labeled `[generic]`: it's useful rehearsal for the role family, but it says nothing specific about Stripe. The upgrade menu at the end shows what each missing input would change.

---

## How to use this pack

- **Personas** describe how a question gets asked: who is asking, and in what style. **Types** describe what's being scored. Rehearse both. The same question sounds different from a friendly interviewer than from one with a stopwatch.
- **Type key:**
  - **VAL**: behavioral or values alignment. Does your past behavior show the company's published values?
  - **EXP**: work-experience deep-dive. Do your claims hold up when someone asks what you actually did?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. How deep is your homework, and can you think at the company's level?
  - **CASE**: a live problem from the role. How you structure it and reason through it out loud.
- **Provenance labels:** `[grounded]` traces to something you gave me or to cited research. `[inferred]` is derived from a representative source. `[generic]` is a role-family pattern with no claim about this company or about you. Everything here is `[generic]` for the reasons above.
- **Guidance is scaffolding, not a script.** I don't have your background, so most guidance cells tell you how to *pick* a story and what it needs. They don't tell you what happened. Every story you tell should be something you did, in your own words.
- Question IDs go by persona letter. **F is skipped** so question IDs never collide with the fit-snapshot rows F1–F8.

---

## Fit snapshot

This is the worksheet version, because I have no background material from you. The requirements are typical of product operations roles in general, written without a source. They are not quoted from Stripe's posting. Fill in the evidence column for yourself before the interview. Paste your CV and the JD, and I'll turn this into a graded snapshot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running launch and operational readiness for new products or features across several teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a specific launch where you can say which readiness work was yours: training, support documentation, escalation paths, go or no-go criteria. Selection scaffold: pick a launch you were part of where you can name what you did and what was in place on day one. If no launch comes to mind, say so plainly. Then give the nearest thing your experience does carry, or how you would run one |
| F2 | Turning feedback from users and customer-facing teams into input the product team acts on (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a loop you can describe end to end: where the feedback came from, how it was sorted, who received it, and what changed. Selection scaffold: pick a time you moved user or frontline feedback to someone who could act on it. It needs a named source and a named recipient. If no such time comes to mind, say so plainly. Then give the nearest thing your experience does carry, or how you would build that loop |
| F3 | Designing processes that scale, turning manual work into repeatable process or tooling (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a before and after you can state, with your part in it named. Selection scaffold: pick a process you changed, where you can say what it was before, what it became, and which part of the change was yours. If no such change comes to mind, say so plainly. Then give the nearest thing your experience does carry, or how you would approach one |
| F4 | Defining, tracking and explaining operational metrics (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain: how it was counted, what moves it, and which assumption behind it is weakest. Selection scaffold: pick a number you reported or tracked that you can explain at that depth. If you don't know how a figure was counted, saying so is an honest answer. If no such number comes to mind, say so plainly, and say what you would measure first in this role |
| F5 | Working across teams and influencing people who don't report to you (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a moment where people outside your reporting line changed course, and you can say what you did to get there. Selection scaffold: pick a time you needed another team to do something they hadn't planned to do. It needs a named stake and an outcome you can state. If no such time comes to mind, say so plainly. Then give the nearest thing your experience does carry, or how you would handle it |
| F6 | Prioritizing and making tradeoffs under constraint (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a choice you made between two good options, with the reason and the cost named. Selection scaffold: pick a time you had to say no, or not yet, to something reasonable. If no such time comes to mind, say so plainly, and walk through how you would decide |
| F7 | Explaining plans and tradeoffs clearly in writing and out loud (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a document or message you wrote that changed a decision. Selection scaffold: pick a written plan, proposal or update you authored and can describe. If none comes to mind, say so plainly, and show this skill in how you answer instead |
| F8 | Familiarity with payments, fintech, or the company's product area (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is direct work in the domain, or a specific way you've used or studied the product. Selection scaffold: pick what you actually know about this domain and say where you learned it. If it's new to you, say so plainly and describe how you would ramp up, as a plan and never as something already done |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 launch readiness | A1, E3 |
| F2 feedback loops | A3 |
| F3 scaling process | A4 |
| F4 operational metrics | A2, D1, D2, D3 |
| F5 cross-team influence | A5, B3, G1, G2, G3 |
| F6 prioritization | A3, A5, E3 |
| F7 communication | B1, E1, H1 |
| F8 domain familiarity | C2, C3 |

There are no JD requirements to check this against. With the real JD, every requirement it lists gets its own row and at least one JD-tagged question.

---

## Persona table

**How the weights were set.** No source in hand describes Stripe's final round. "Final round" alone says nothing about how many sessions there are or who runs them. So these weights fall back to a pattern, the big-tech structured archetype, which tilts Case and Values questions up. **This pattern is not Stripe's documented process.** Who you're meeting also isn't known, so the remaining personas are weighted flat. That makes this pack noticeably weaker than one keyed to your actual interviewers.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: plan a launch, diagnose a metric, fix a process | Highest. The fallback archetype tilts Case up, and operations roles in general are tested on live problems | Clarify, then objective, segmentation, approach, metrics, risks. Think out loud. Challenge one premise per case, politely |
| B. Values / Behavioral | Scenario probes that ask for structured stories, often from someone outside the function | Mid, raised by the fallback archetype. Stripe's published principles weren't retrieved, so this bank can't be mapped to them by name | Use "we" for context and "I" for your contribution. Choose stories where a hard truth actually landed. Where you have none, say so instead of supplying an ending |
| C. Skeptic | Quiet probing of gaps, motivation, and why here, why now | Mid. Flat weight, because your background isn't known | Rehearse C1 until it's boring. Build bridges only from things you actually did, and state limits plainly |
| D. Data-Driven Prober | Asks for denominators and assumptions, and goes two levels deeper | Mid. Flat weight. Metrics are core to operations roles in general | Know what you can and can't say about how each of your numbers was counted. Name your weakest assumption before they do |
| E. Pressure | Interrupts, time-boxes, pushes back on attribution | Mid. Flat weight | Pause, restate the question, hold through two follow-ups, then concede only what is really uncertain |
| G. Peer Evaluator | Seams between teams, "what would you need from me," credit | Mid. Flat weight. Operations roles sit between teams, so a peer conversation is plausible | Describe what you bring to their team as well as what you need from it. Propose principles for the seam rather than pretending to know it |
| H. Conversational | Friendly openers and biography questions. Still scored | Low, but it opens most conversations | A pre-built 90-second arc. Treat casual questions as scored |

---

## Question banks

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're launching a new product to users in a new country in eight weeks. Sketch the operational readiness plan. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, what's different about the country (regulation, language, payment methods), what support and risk teams exist, and what "ready" means. Set the objective, then work backwards from launch: readiness criteria, owners, training and documentation, escalation paths, a go or no-go checkpoint, and what you'll watch in week one. Name one risk that worries you most and how you'd stop it from blocking the launch. The question needs no claim about your past, so the guidance makes none | F1 is the core of most product operations roles, and launch planning is the classic live case. CASE because it scores structure on a problem from the role |
| A2 | "User-reported issues for one product rose 20% month over month. Diagnose it." | CASE | [generic] | Before you diagnose, check the measure. Did the count change, a form, a tagging rule, or the user base? Then segment: by issue type, user segment, region, channel, and the release timeline. Form one or two hypotheses, say what data would confirm or kill each, and say who you'd pull in. Close with the short-term fix versus the root-cause fix, and how you'd know it worked | F4 under live conditions, and a test of whether you question the metric before trusting it. CASE because it's a diagnosis problem, not a recall question |
| A3 | "Sales, support and the product team each tell you a different top pain point. How do you decide what reaches the roadmap?" | CASE | [generic] | Separate volume from severity from strategic weight. Ask what evidence sits behind each claim: ticket counts, revenue at stake, user quotes. Propose a simple, visible way to rank them that the three teams can see and argue with. Say how you'd close the loop with whoever's item doesn't make the cut | Tests F2 and F6 together, the job of turning noise into a decision. CASE because the answer is a reasoning structure |
| A4 | "A manual review process that worked at 100 cases a week now faces 2,000. What do you do?" | CASE | [generic] | Stabilize first: what's the backlog costing, and is anything harmful slipping through? Then break the cases into types. Some can be automated or ruled out, some need simpler review, and some need expert attention. Decide where tooling, staffing or policy changes fit, and set a quality metric so speed doesn't hide errors | F3 at scale, a common operations case. CASE because it scores how you break down a problem |
| A5 | "Two product teams both want your help this quarter, and you can only do one well. How do you choose, and how do you tell the other team?" | CASE | [generic] | State your criteria out loud: impact on users, risk, deadlines that can't move, and whether the other team has a workaround. Make the call. Then say how you'd tell the second team, what you'd offer them instead, and when you'd revisit the decision | F5 and F6. Saying no to a peer team is a real part of operations roles. CASE because it's a live tradeoff |

### B. Values / Behavioral

Stripe's published principles weren't retrieved, so none of these is mapped to a principle by name. The themes come from general behavioral interviewing patterns.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, what you said and how, and what happened after, even if the truth didn't land. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly. Then give the nearest thing your experience does carry, or how you would handle it | A staple behavioral theme, and it touches F7. VAL because it scores behavior, not skill |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where what was right for a user cost something measurable inside the company. Name the tradeoff and your part in it. If no such time comes to mind, say so plainly. Then give the nearest thing your experience does carry, or how you would weigh it | A common customer-versus-metric probe, and operations roles often sit on exactly that line. VAL because it tests a judgment pattern |
| B3 | "Tell me about work that spanned teams. How was credit handled?" | VAL | [generic] | Selection scaffold: pick cross-team work where you can say clearly what was yours and what was others'. The strong answer gives credit precisely and doesn't inflate your share. If no such example comes to mind, say so plainly. Then give the nearest thing your experience does carry, or how you would handle credit | F5. Also a check on attribution honesty, which the Pressure bank tests again in E2. VAL because it scores behavior around others |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **The highest-ROI rehearsal in this pack**, until your CV lets me name your actual likeliest objection. Selection scaffold: pick one real gap from the requirements F1–F8, the one you'd honestly rate lowest. Name it in one sentence, without hedging and without a "strength in disguise." Then give your plan for closing it, stated as a plan, never as something already done. Expect two follow-ups: "How would we know you'd closed it?" and "Isn't that core to the role?" Hold on the plan, then concede plainly what you don't know yet. Never swap in a fake weakness. Interviewers recognize it | This objection arrives in some form in almost every final round, and a calm, specific answer changes the room. JD because it scores self-assessment against the role |
| C2 | "Why Stripe, and why product operations, now?" | CO | [generic] | Three parts: why this function, why this company, why now. For "why this company," use only what you've seen or read yourself, and be ready to say where. This pack has no researched Stripe facts to give you, so it supplies none. For "why now," tie it to your own path in your own words | Motivation consistency is what the Skeptic tests. CO because the company half scores homework |
| C3 | "How would you get up to speed on payments-specific operations in this role?" | JD | [generic] | Selection scaffold: say what you already know about payments and where you learned it. If it's new to you, say so plainly. Then give a ramp plan as a plan: who you'd learn from, what you'd read, which processes you'd shadow, and how you'd check your understanding | F8. A domain-ramp question is likely whenever the domain is specialized. JD because it scores a stated or implied requirement |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick an operational metric you've reported on, and walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a number you can actually explain. Cover how it was counted, what it's sensitive to, and which part of it was yours, each in your own words. If you don't know how a figure was counted, saying so is honest and better than guessing. If no such number comes to mind, say so plainly, and say what you'd measure first in this role | F4. Probers go straight to how a number was counted. EXP because it tests what you actually know about your own work |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption yourself, before they find it, in your own words. Then say what you'd do to test it. If you don't know the assumptions, say so plainly | The weakest-assumption move turns a gotcha into credibility. EXP because it's a follow-up on your own figure |
| D3 | "You're asked to prove that product operations is making a difference. What do you measure, and what's the weakest part of that measure?" | CASE | [generic] | Propose two or three measures: an outcome (for example, user issues resolved or launch quality), an efficiency measure, and a stakeholder signal. Name what each can't tell you, and the weakest part of attributing changes to operations work at all | F4 as a live problem, and a natural prober question for any operations hire. CASE because it asks for a measurement design, not a memory |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give three beats in under a minute: what you'd bring, a perspective someone from outside adds, and how fast you'd ramp. Every claim must be something you can back with your own examples. Don't argue down the internal candidate | Tests composure and economy, which is F7 under a time limit. JD because it scores fit to the role |
| E2 | "That result you just described: how much of it was actually you?" | EXP | [generic] | Hold, then concede. State your part precisely and give the team's part as it actually was. If pushed twice, keep the same answer and concede only what is truly uncertain. Never grow your share to end the pressure | Attribution probes exist to catch inflation. The rehearsed answer is candor. EXP because it tests the claim you just made |
| E3 | "Two minutes: a launch is tomorrow, and the support team isn't trained. Ship or slip?" | CASE | [generic] | Ask one clarifying question: what's the user harm if support can't answer? Then make a call, with the condition that would reverse it, the mitigation (for example, limited rollout, an escalation path, a temporary FAQ), and who decides. Hold the call through a push-back, and change it only for a new fact | F1 and F6 under time pressure. CASE because it scores a decision under a constraint |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Propose principles instead: who decides what, how disagreements get escalated, and a regular check-in. Then ask what's worked for them so far | F5. A peer is checking whether you'll add to their load or reduce it. CASE because it asks for a working model |
| G2 | "What would you need from me, and what would I get from you?" | CASE | [generic] | Answer both halves, starting with what you'd give their team. Keep the "need" side short and specific | Reciprocity is what a peer is really scoring. CASE because it's a live proposal, not a history |
| G3 | "Tell me about a time you disagreed with someone on another team. How did it get resolved?" | VAL | [generic] | Selection scaffold: pick a disagreement with a peer, not a manager. It needs what each side wanted, what you did, and the state of the relationship afterwards. If no such time comes to mind, say so plainly. Then give the nearest thing your experience does carry, or how you would handle it | F5. Disagreement with equals is the peer's core worry. VAL because it scores behavior |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, two or three turns that led toward operations, and why this role is the next step. Each turn should be something you can expand if asked. End by handing the conversation back | Almost every conversation opens this way, and it's scored for economy (F7). EXP because it's your history, told briefly |
| H2 | "What got you interested in product operations as a function?" | VAL | [generic] | One real reason in your own words, plus one example of the kind of work that pulls you in. Keep it short | Sounds casual but tests genuine interest. VAL because it scores motivation |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a great first 90 days look like in this role?" | It shows you're already thinking about delivery, and the answer tells you what you'll be judged on |
| "Where does product operations sit relative to product, support and sales here, and which seam do you most want this hire to fix?" | It gets you the real job beneath the title and signals you understand where operations work sits |
| "What's a process the team still runs manually that you'd like to see scaled?" | It's concrete, it points at F3, and it often reveals the team's biggest pain |
| "How does the team know whether product operations is working?" | It mirrors D3, and the answer tells you how your success will be measured |
| "What's the biggest launch or change on the horizon that this role would touch?" | It shows forward interest and tells you what you'd walk into |
| "What could someone new do in their first month that would genuinely help your team?" | A reciprocity question. It lands especially well with a peer interviewer |

---

## Prohibited claims

Nothing is listed, because your material contains no sentences about your experience. With nothing quoted, there's nothing this pack could inflate, and there are no stated gaps to protect. Once you share a CV, this section will list the stretched versions of your own lines that the pack refuses to coach, each with the honest form of the claim. Until then, the pack's rule is the same as always: no story, number, title or result goes into your answers unless it's something you did.

---

## Sources

- **Provided:** your message, naming the company (Stripe), the role (Product Operations Manager) and the round (final round).
- **Searches sent:**
  - "Stripe operating principles official": refused by session permissions
  - "Stripe interview process final round onsite Product Operations": refused by session permissions
  - "Stripe strategy news 2026": refused by session permissions
  - "Stripe "Product Operations Manager" job description": refused by session permissions
- **Fetches:** none sent.
- **Dossier:** none present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` / operating principles | unavailable | Refused. Would have supplied Stripe's principles by name, a values cheat sheet, and one VAL question per principle in bank B |
| 2. `Stripe interview process` for product operations | unavailable | Refused. Would have replaced the big-tech archetype fallback with Stripe's documented rounds, and set persona weights from them |
| 3. `Stripe strategy` / recent news | unavailable | Refused. Would have grounded at least one CO or CASE question in current strategy, and given C2 facts to build on |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Refused. Would have turned the `[generic]` requirements F1–F8 into quoted `[inferred]` ones from a real posting |

---

## Upgrade menu

- **The JD text** → requirements F1–F8 are replaced by the posting's own lines, quoted and `[grounded]`, and every requirement gets a JD-tagged question
- **Your CV or a background summary** → the worksheet becomes a graded fit snapshot, selection scaffolds become story-mapped guidance from your own sentences, the prohibited list gets built, and C1 is replaced by the objection your background actually invites
- **Who you're meeting and their relationship to the role** (hiring manager, peer, skip-level, cross-functional) → persona weights from real priors instead of flat weights and an archetype fallback
- **The recruiter's guidance** (focus areas, and any announced case, presentation or take-home) → a dedicated build section for each graded deliverable
- **If your final round is several sessions, the schedule** → one mini-pack per session, each with its own weights, bank and reverse questions
- **Interviewer names** → an interviewer read from their public professional footprint, and a reverse question tied to their own career path
- **Web search allowed for this session** → the four refused searches rerun: Stripe's principles by name with a values cheat sheet, the documented loop, strategy-grounded CO and CASE questions, and a representative JD
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes, only if you want it) → a grounding brief on Stripe's current strategy and vocabulary, plus differentiator questions built from it
- **How much prep time you have** → a prioritized prep schedule sized to it
- **A tuesday-dossier.md, if you have one** → an evidence-derived highest-ROI objection, a binding list of claims not to make, and an answer strategy per weak area
- **Your own answers to the selection scaffolds, told to me outside a drill** → rows F1–F8 move from `none` to graded evidence, and the guidance in A–H regenerates from your words
