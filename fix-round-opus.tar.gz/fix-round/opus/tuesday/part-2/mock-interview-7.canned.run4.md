Quick update: I've read the prep-pack rules and I'm about to run a few searches on Saltmarsh Games and Tobias Wrenfield before I build your pack.
I've built your prep pack. One thing to know first: today is Thursday, so your interview is **tomorrow**.

The most useful finding is that Saltmarsh's careers page describes this exact hour, which it calls the "Outage Hour". It opens with a live-incident tabletop on a simulated outage during a live event, then moves to a conversation about their three values: **Players Before Plans**, **Ship the Patch Not the Promise** and **Leave the Build Greener**. There's no take-home. So the pack puts the heaviest weight on the tabletop (A1, A2, D1) and on one story per value (B1 to B3).

What else the pack covers:

- **The objection to rehearse most (C1).** You ran the content-drop calendar for your main title; this role runs live events across two titles and four teams. The pack gives you a way to hold your ground without overstating what you did.
- **The season pass (C2, A5).** Saltmarsh's news page says both titles move to a season pass on one shared calendar from February 2027 ("Project Larkspur"). You told me you've never worked on a game with in-app purchases, so the pack has you say that plainly and then give a learning plan.
- **Tobias (R1, R2, B4).** He was previously a QA lead and gave a GDC 2026 talk, "Patch Notes Are a Promise", arguing that a live team is judged by how often its patch notes describe what actually shipped. I only read the talk's abstract, not the talk. Your release checklist is the natural common ground with him.
- **What not to claim.** Your checklist line is your strongest. Keep the verb "wrote", not "managed". Never having led a team is a separate question from coordinating teams, and the pack keeps them apart.

If you only have tonight, the pack opens with a five-step plan for the evening.

Files are in:
- saltmarsh-games_live-operations-producer_interview_pack.md

Say the word and I'll play the Skeptic on C1, the question the pack names as its highest-ROI prep, or run the A1 outage tabletop live.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations (hiring manager)
**Session:** one 60-minute interview, Friday. Saltmarsh's careers page describes it as the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home.

---

## How to use this pack

- **Personas** describe how a question is asked: who is asking, and in what style. **Types** describe what is being scored.
- Type key:
  - **VAL**: values alignment, scored against Saltmarsh's three published values
  - **EXP**: experience deep-dive. Do your stated claims survive scrutiny, and what was actually you
  - **JD**: can you do the job as the posting lists it, gaps included
  - **CO**: company knowledge, here mainly Project Larkspur
  - **CASE**: a live problem from the role, talked through out loud
- Provenance labels: `[grounded]` traces to your message, the JD or a source in Sources. `[inferred]` is this pack's own derivation. `[generic]` is a general pattern for the role family, with no claim about Saltmarsh or about you.
- An **answer slot** marks a place where the interviewer is likely to probe something your material doesn't settle. Each slot has two branches. Answer whichever one is true, in your own words.
- The guidance is scaffolding, not a script.

## Prep triage: one evening

Your interview is tomorrow. If you only have tonight, do these in order:

1. **Say A1 out loud, with a timer.** The tabletop is the documented first half of the hour. Practise the clarify, stabilise, communicate, decide, review structure until you can do it without notes. Then do A2 and D1 as the interruptions.
2. **C1, the highest-ROI question in this pack.** Rehearse the hold and the concession until they sound boring.
3. **B1 to B3, one per value.** The values conversation is the documented second half.
4. **Read the prohibited list (section 13)** so you know which inflated phrasings to catch yourself on.
5. **Choose three reverse questions**, including R1 or R2.

Everything else in the pack is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a weekly content-drop calendar for your main title. The JD asks for live events across two titles, so keep your words at their own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "plan and run" makes a probe on planning likely. If deciding what went on the calendar, and when, was yours to do, say how you decided, in your own words. If it was set by someone else, or there was no such planning step, say so plainly and stay with running the calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap here. But this is a single stated line with nothing behind it to inspect, so expect a probe. Lead with the quote's own terms: you ran it, it was weekly, it was for your main title, and you did it for two years |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show whether you coordinated with these disciplines. Note that never having led a team is about leading, not coordinating, so don't let one answer stand in for the other. Answer slot: if getting a content drop out involved working with design, art, engineering or community people, say which ones and what your part was, in your own words. If it didn't, say so plainly and say how you would approach it |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers. That isn't a post-event review or owning KPIs, so keep your words there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "own" makes a probe on who chose and interpreted the numbers likely. If choosing what went in, or explaining what the numbers meant, was yours, say which, in your own words. If someone else produced them and your part was presenting them, say so plainly and stay with that |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | This quote already reaches the requirement. Keep the verb "wrote": "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage" makes a probe on releases likely. If you ran the checklist with QA on releases, say how, in your own words. If writing it was your part and QA ran it, say so plainly |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Four years meets the length. Your material doesn't say whether the puzzle game was live-service. Answer slot: if your title kept receiving updates for players after launch, say so in your own words. If it didn't, say so plainly and stay with the four years and the calendar |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | Presenting retention numbers touches this requirement but doesn't show how far your work with them went. Answer slot: if you worked with the numbers before presenting them, for example reading them or explaining a change, say what you did in your own words. If not, say so plainly and stay with presenting them monthly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A checklist that a QA team still uses is written material other people work from. Say it in those terms: "I wrote the release checklist our QA team still uses." |

**Requirement coverage:**

| Requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two titles | A3, A5, C1 |
| Coordinate design, art, engineering and community | H1, H2, C3 |
| Own the post-event review and its KPIs | A4, E2 |
| Manage the release checklist with QA | A2, B3, D2 |
| 3+ years producing live-service games or apps | G1 |
| Experience running a content calendar | C1, B1 |
| Comfortable with player-retention metrics | E2, E1, A4 |
| Clear written communication | D1, B4 |

## Reading the interviewer

Everything below comes from one search result: the abstract of his GDC 2026 talk. The talk itself was not read. All of it is public professional footprint.

| Signal | Implication for Friday | Provenance |
|---|---|---|
| Tobias Wrenfield is Head of Live Operations at Saltmarsh Games and was previously a QA lead at a console studio | Release discipline is his home ground. Anything you say about the checklist will be heard by someone who has run checklists, so be exact about what you wrote and what QA did with it (D2, F5) | [grounded] |
| His GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by how often its patch notes describe what actually shipped | Expect a question on whether announcements match the build (B4). It echoes the value Ship the Patch Not the Promise | [grounded] |
| Mirror opportunity: shared vocabulary, not a shared career jump | F5: "Wrote the release checklist our QA team still uses." Talking about QA and release checklists is common ground. His move was QA to live ops and yours is associate producer to live ops producer. Those are different jumps, so don't present them as the same | [inferred] |

## Persona table

| Persona | How it shows up on Friday | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event, worked live | Highest, 5 questions. A hiring-manager round leans this way, and the careers page puts a live-incident tabletop in the hour | Clarify, set the objective, segment, choose an approach, pick metrics, name risks. Think aloud and challenge one premise respectfully |
| Values / Behavioral | The second half of the hour, mapped to the three published values | High, 4 questions. The careers page names a values conversation in this same interview | Use one story per value where a sentence from your message carries one. Otherwise use the selection scaffold and its honest branch |
| Skeptic | Probing the gap between one title's weekly drops and two titles' live events, plus the season pass | Medium, 3 questions. Hiring managers de-risk gaps, and F1, F3 and F4 are the gaps | Rehearse C1 until it's boring. Build bridges only from what you stated, and say limits plainly |
| Pressure | Time-boxed interruptions during the tabletop | Low to medium, 2 questions. A simulated outage invites time-boxing, though nothing published says the round is a stress format | Pause, restate the question, hold through two follow-ups, then concede something specific |
| Data-Driven Prober | Asks how the retention numbers were counted | Low to medium, 2 questions. The JD names retention metrics and F4 and F7 are thin. Nothing published describes him as analytics-led | Know what you can and can't say about how the numbers were counted, and say plainly where you don't know |
| Conversational | The opening minutes | Low, 2 questions. Any 60-minute hiring-manager hour opens this way, which is a general pattern, not documented for Saltmarsh | Have a 90-second arc ready. Casual questions are still scored |
| Peer Evaluator | Questions about coordinating with other teams | Low, 2 questions. There's one interviewer, but F3's coordination requirement raises seam questions | Frame what you would bring to each team. Propose principles for the seams rather than claiming to know them |

## Question banks

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event on one of our titles. The event server goes down and players can't claim rewards. Talk me through the next hour." | CASE | [grounded] | Clarify first: what exactly is down, which title, roughly how many players are affected, and who is already on it. Then stabilise: get engineering on-call working and agree a single owner for the incident. Communicate early, and only what is known: what's broken, that it's being worked on, and when the next update is. Then decide on the event (extend, pause, or compensate), name the trade-off, and say who makes the call. Keep a timeline as you go because it feeds the post-event review. Close with what you would review afterwards. This question asks nothing about your past, so the guidance makes no claim about it | The careers page documents this format as the first half of the hour, so some version of it is certain. CASE because it scores live structure. `[grounded]` because the format comes from that page. The scenario details are this pack's example |
| A2 | "The fix is ready, but QA needs four hours to test the hotfix and the event ends in two. What do you do?" | CASE | [generic] | Name the tension out loud. Shipping untested risks the build. Holding the fix lets the event end broken. Lay out the options: extend the event so testing can finish, ship a narrower fix that QA can clear faster, or ship and accept the risk. Say what you'd need to know to choose. Saltmarsh's values point towards players before the plan and towards not skipping the checklist, so say how you would honour both. No claim about your past | A likely follow-up from a former QA lead (see Reading the interviewer). It tests the release-checklist requirement under time pressure |
| A3 | "Plan the next quarter of events across two titles. What do you need to know first?" | JD | [generic] | Ask before you build: each title's player base and what each needs, team capacity across design, art and engineering, fixed dates, and what last quarter's reviews showed. Then structure: anchor events, how the two titles avoid colliding, buffer for slips, and the KPIs each event should move. No claim about your past | Scores the two-title calendar requirement directly (F1's requirement), delivered as a case. JD content, CASE delivery |
| A4 | "An event shipped, and day-7 retention for players who joined during it came in below the last event. Walk me through the post-event review." | JD | [generic] | Check the comparison before reacting: same length, same season, same kind of event. Segment new players from returning ones, and by title and acquisition source. Look for confounds such as an outage, a competing launch or a store feature. Say which assumption in the comparison you would defend least. End with what the review reports and who acts on it. No claim about your past | Covers owning the post-event review and the retention-metrics requirement (F4's and F7's requirements) as a live problem. JD content, CASE delivery |
| A5 | "From February both titles move to a season pass on one shared calendar. What's the first thing you'd want to get right?" | CO | [grounded] | Show you know about Project Larkspur. Then pick one priority and defend it: for example, the shared calendar's cadence and who decides when the two titles compete for a slot, or how events and the season pass reinforce each other rather than cannibalise. Say what you would want to learn first. No claim about your past | Larkspur, from Saltmarsh's own news post, is the strategy context this role works in. This is the CO question most candidates won't have prepared |

### B — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and what players needed pulled in different directions." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold for Players Before Plans. Pick an occasion from the calendar you ran when a drop was moved, changed or held because of players. A good story needs four things: what the plan said, what players showed, what was done, and which part of that was yours. If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry, which is running the weekly calendar for your main title, or say how you would handle it | Maps the published value "when the calendar and the players disagree, the players win" to F1's evidence. VAL because the value is the scoring sheet |
| B2 | "When have you had to keep an announcement to what was actually built?" | VAL | [grounded] | Selection scaffold for Ship the Patch Not the Promise. Pick a time something was announced, or about to be, and what was built didn't match. A good story needs what was going to be said, what you did, and what went out. If no such time comes to mind, say so plainly, then say how you would handle it | Comes from the value "we announce what is built, not what is hoped". No sentence in your message carries a story for it, so the guidance is a scaffold |
| B3 | "Our value is Leave the Build Greener. What have you left better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F5. The beats are the ones your sentence states: you wrote the release checklist, and your QA team still uses it. Tell them in your own words. Answer slot: the value says every release leaves the checklist better than it found it. If you revised the checklist after releases, say what changed and why. If it wasn't revised, or the revising wasn't yours, say so plainly and stay with writing it and its continued use | This is the value your material maps to most directly, so make it your strongest values answer. VAL |
| B4 | "How do you make sure what we announce matches what shipped?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Lay out a process: draft the notes from the build, not the plan. Check them against release sign-off. Cut anything that didn't ship. Name who signs off that the notes match the build. Answer slot: if your checklist had a step that checked announcements against the build, say how it worked, in your own words. If it didn't, say so plainly and describe the step you would add | His talk abstract and the value Ship the Patch Not the Promise point at the same thing. VAL scored, and it also covers written communication (F8's requirement) |

### C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You ran the content-drop calendar for your main title. This role runs live events across two titles and coordinates four teams. Why are you ready?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **This is the highest-ROI rehearsal in the pack.** Hold only what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Name the limit before he does: "That was our main title's calendar. This role has two titles and live events." Then say how you would close the gap, as a plan for this role and never as something you've already done. On the first follow-up ("how much of that calendar was your call?"), use F1's answer slot: if planning it was yours, say how you decided. If it wasn't, or there was no such step, say so plainly. On the second follow-up ("and the four teams?"), use F3's answer slot: if you worked with design, art, engineering or community on drops, say which and what your part was. If not, say so plainly and give your approach. Hold by going back to the quote, never by adding to it | F1 and F3 are where this role presses hardest, so this objection will come in some form. JD because it scores the stated requirement. It gets the deepest rehearsal because this is exactly where your material is thinnest |
| C2 | "Both titles are moving to a season pass. Have you worked on a monetised game?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly: "I haven't worked on a game with in-app purchases." Don't soften it, and don't add exposure you didn't mention. Then give a plan, stated as a plan: what you would want to learn about the season pass first and who at Saltmarsh you would learn it from | Larkspur makes this gap easy to see. You stated the negative, so the pack can give it back to you word for word. CO because the probe comes from strategy, not from the JD |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Name one real gap. The cleanest is the season pass, because you stated it: "I haven't worked on a game with in-app purchases." Follow it with your plan. If leading comes up, say "I haven't led a team." Coordinating four disciplines is a separate question, and F3's answer slot covers it. Don't pick a fake weakness | A standard Skeptic stem. Your stated negatives give it an honest answer. JD because it scores self-assessment against the posting |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Stop. Sixty seconds. Community channels are furious. What's your first public message?" | JD | [generic] | Pause, then say it in three parts: what we know, what we're doing, and when the next update comes. Promise no fix time and no compensation that hasn't been decided. That is Ship the Patch Not the Promise applied to an outage. If he pushes for a promise, hold through two follow-ups, then concede specifically, for example "I'd commit to an update time, not a fix time." No claim about your past | Tests clear written communication under the time box the tabletop invites. JD content, CASE delivery |
| D2 | "That checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it, and our QA team still uses it." Answer slot: if others contributed sections or reviewed it, say who and which part was yours. If you wrote it alone, say so plainly. Hold through two follow-ups and concede only what is true | F5 is your strongest line, so a former QA lead is likely to test its attribution. EXP |

### E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Those monthly retention numbers you presented — how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot, in your own words: how they were counted, what they were sensitive to, the assumption behind them you would defend least, and which part of the work was yours. "I don't know how it was counted" is an honest branch. If that's the truth, say it plainly and stay with presenting them monthly to the studio head | F4 and F7 rest on this line, and the JD names retention metrics, so the defend-the-number probe is likely. EXP |
| E2 | "What would you put on one page after every event?" | JD | [generic] | Pick a short list and defend it. For example: retention by cohort compared with a fair baseline, participation and completion, any incident and its impact, community sentiment, and, once the season pass is live, pass engagement. Name the one you trust least and why. No claim about your past | Covers owning the post-event review's KPIs and retention comfort (F4's and F7's requirements) without depending on your history. JD |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built from these four sentences, at their own scope: four years as an associate producer at a puzzle-game studio, two years running the weekly content-drop calendar for your main title, the release checklist you wrote that QA still uses, and the monthly retention numbers you presented to the studio head. Answer slot: the JD's "live-service" line makes a probe likely. If your title kept receiving updates for players after launch, say so in your own words. If not, say so plainly. End with why this role is the next step | Scores the 3+ years live-service requirement (F6) in a casual register. JD content, EXP delivery |
| G2 | "Why live ops, and why Saltmarsh?" | CO | [grounded] | Give your real reasons in your own words. For the Saltmarsh half, show you have read the values page and know about Project Larkspur, and say which of them actually draws you and why. No claim about your past | Motivation is scored even when it's asked casually. CO because the Saltmarsh half tests homework |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Engineering says Thursday's update won't be ready. Art is done, and community has already announced it. What happens?" | CASE | [generic] | Clarify what's late and by how much. Options are to slip, to descope, or to ship what's built. Say who needs to agree, how community corrects the announcement, and how you would keep it from happening next time. No claim about your past | Tests coordinating design, art, engineering and community (F3's requirement) as a live problem. CASE |
| H2 | "When an update goes well, how do you handle credit across design, art, engineering and community?" | EXP | [generic] | Selection scaffold: pick a time a release or drop landed well and say how credit was shared and what your part was. Use "we" for the context and "I" for your own contribution. If no such time comes to mind, say so plainly, then say how you would handle it | A peer-style credit question, made likely by the coordination requirement. EXP because it asks for a past instance |

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and what players need conflict, players come first | F1: "I ran the weekly content-drop calendar for our main title for the last two years." This gives you the setting, not a story. Use B1's selection scaffold: pick an occasion when a drop moved for players. If none comes to mind, say so plainly, then give the calendar you ran, or how you would handle it |
| Ship the Patch Not the Promise | Only announce what's built | No sentence in your message carries a story for this one. Use B2's selection scaffold. If no such time comes to mind, say so plainly, then say how you would handle it |
| Leave the Build Greener | Every release should leave the code and the checklist better than it found them | F5: "Wrote the release checklist our QA team still uses." This is your most direct match, and B3 rehearses it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued that a live team is judged by how often its patch notes describe what actually shipped. How do you track that here?" | It ties to his own published theme and shows you researched him, not just the company |
| R2 | "You came to live ops from QA. How has that shaped the way the release checklist runs here?" | It ties to his path and opens the topic where F5 is your strongest line |
| R3 | "With Larkspur moving both titles to one calendar in February, what does this role own before the switch, and what after?" | It shows strategy homework and asks what success looks like |
| R4 | "What does a post-event review look like here today, and which KPI do you argue about most?" | It shows you are already thinking about the part of the role you'd own |
| R5 | "When the calendar and the players disagree, who makes the call to move an event?" | It puts the first value into practice and shows how decisions get made |
| R6 | "Six months in, what would tell you this hire was the right one?" | It invites him to state his own bar, which you can then answer to |

## Prohibited claims

This pack won't coach the following claims. Each one is either a stretched version of something you said or something you said wasn't true.

| Not coached | Basis | Honest form |
|---|---|---|
| Planned or ran live events across two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Your material covers your main title's weekly drops. Neither C1 nor F1's answer slot goes beyond that calendar |
| Owned post-event reviews or KPIs | Inflated form of F4 | F4's quote at its own scope: "Presented the monthly retention numbers to the studio head." Your material says presented. E1's slot asks only how they were counted and which part was yours |
| Managed releases, or ran QA | Inflated form of F5 | F5's quote at its own scope: "Wrote the release checklist our QA team still uses." Your material says wrote |
| Has led a team | A negative you stated | "I haven't led a team." No answer slot |
| Has worked on a game with in-app purchases or monetisation | A negative you stated | "I haven't worked on a game with in-app purchases." No answer slot |

## Sources

- Provided by you: the JD text and your background, both from your message.
- Search: "Saltmarsh Games values" → saltmarshgames.com/values
- Search: "Saltmarsh Games interview process producer" → saltmarshgames.com/careers/interviewing
- Search: "Saltmarsh Games mobile studio news" → saltmarshgames.com/news/project-larkspur. Only the search snippet was read; the page was not fetched.
- Search: "Tobias Wrenfield Saltmarsh Games" → talks.gdconf.example/2026/patch-notes-are-a-promise. Only the search snippet was read; the page was not fetched.
- Fetch: saltmarshgames.com/values → the three values with their definitions
- Fetch: saltmarshgames.com/careers/interviewing → the loop: a recruiter call, then the 60-minute Outage Hour (tabletop, then values conversation), no take-home
- No dossier was used.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The values cheat sheet and B1 to B4: three values, by official name |
| 2. Saltmarsh Games interview process | yes | Established the loop as one 60-minute hiring-manager session with a tabletop then values. Case and Values are weighted up, and a values round is detected |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur, which drives A5, C2, G2 and R3 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | The interviewer read, B4, R1 and R2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Deeper research.** Up to 6 more searches and 2 more fetches, several more minutes. It would read Tobias's talk in full rather than its abstract and read the Larkspur post itself. That sharpens A5, B4 and R1, and adds a grounding brief.
- **Recruiter's prep notes or call notes** → any focus areas they named for the Outage Hour, folded into A1 and the persona weights.
- **Your answers to the answer slots in F1, F3, F4, F6 and F7** → each becomes quoted evidence, and C1, E1, G1 and B1 move from scaffolds to story-mapped answers.
- **The release checklist or a past calendar, if you can share them** → the inspectable artifact that would raise F2 and F5 from medium to high.
- **A tuesday-dossier.md from an earlier fit review** → evidence-derived objections and a prohibited list checked against verified claims. This pack works without one.
