Femi, I've read the prep rules. Next I'm looking up public information on Saltmarsh Games and Tobias Wrenfield, and then I'll build your pack.
Femi, your prep pack is ready: saltmarsh-games_live-operations-producer_interview_pack.md. I've assumed Tobias is your hiring manager, since Saltmarsh's careers page says this 60-minute interview is with the hiring manager.

**What the interview will look like.** Saltmarsh's careers page describes it as the "Outage Hour":
- **First half:** a live-incident tabletop exercise on a simulated outage during a live event.
- **Second half:** a conversation about their three values: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener.
- There's no take-home task.

**The question to rehearse most (C1).** Saltmarsh announced in September that both its titles are moving to a season pass from February. Expect Tobias to put that next to the fact that you've never worked on a game with in-app purchases.
- **Your strongest point:** the weekly content-drop calendar you've run for the last two years.
- **Concede early and plainly:** "I haven't worked on a game with in-app purchases."
- **Then give a plan for how you'd learn it**, and don't describe that plan as past experience.

**A good fit with your interviewer.** Tobias was a QA lead before he ran live operations, and he gave a GDC talk called "Patch Notes Are a Promise." The release checklist you wrote, which your QA team still uses, is your best common ground with him. Expect him to probe how much of it was yours (questions E2 and A3).

**Prep tonight.** The pack has a short schedule for this evening, since Friday is tomorrow.

If you'd like a live practice run, say the word and I'll play the Skeptic on C1.
I can also save a tuesday-dossier.md recording the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interview:** Friday 13 November 2026, 60 minutes
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Treated as the hiring manager, because Saltmarsh's interviewing page says the 60-minute interview is with the hiring manager.
- **Format:** Saltmarsh calls this interview the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home. Source: saltmarshgames.com/careers/interviewing.

## How to use this pack

Each question has two labels. **Personas** describe how a question is asked: the interviewer's style and register. **Types** describe what the answer is scored on:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Saltmarsh's own published values |
| EXP | Whether what you said about your work holds up when probed, and what was actually yours |
| JD | Whether you can do the job as the posting lists it, including the gaps |
| CO | Whether you have done your homework on Saltmarsh's strategy and recent moves |
| CASE | How you structure a live problem from the role |

The answer guidance is scaffolding, not a script. Every claim about your past rests on one of the five sentences in your message, quoted. Where your material doesn't cover something, the guidance gives an **answer slot** instead: an instruction for the interview with two honest branches. Fill it from what you actually did, or say plainly that you didn't do it.

## Prep triage (tonight)

This assumes you have one evening.

1. **C1, the highest-ROI rehearsal in the pack.** You have never worked on in-app purchases, and Saltmarsh is moving to a season pass. Say the concession out loud until it sounds calm. About 30 minutes.
2. **The A bank, especially A1 and A2.** This is the tabletop half of the hour. Practise saying your structure aloud: clarify, triage, people, players, record. About 40 minutes.
3. **The values cheat sheet and B1 to B4.** This is the values half of the hour. Pick your stories tonight, not in the room. About 30 minutes.
4. **D1.** Know exactly what you can say about how the retention numbers you presented were counted, and who counted them. About 15 minutes.
5. **Reverse questions.** Pick three. About 10 minutes.

Everything else in the pack is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a weekly content-drop calendar for one main title. It does not describe live events across two titles, so keep the words at the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: "two of our mobile titles" in the JD makes a question about scope likely. If you worked on calendars for your studio's other titles, say which ones and how. If you didn't, say so plainly and stay with the main title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Running a calendar does not show which teams you coordinated, so don't stretch the bridge. Answer slot: the JD names design, art, engineering and community. If you worked with any of them on a drop, say which teams and what passed between you, in your own words. If you didn't, say so plainly and say how you would set up that coordination |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is not the same as owning a post-event review, so keep the words at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: "own the post-event review" in the JD makes a probe likely. If you ever wrote up how a content drop performed, say what you reported. If you didn't, say so plainly and say what you would report |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | There's no gap here, but nothing stands behind this line except your word, so expect a probe on it. Tobias came up through QA, so this probe is especially likely. Lead in the quote's own terms: you wrote it, and QA still uses it. A specific record you can name beats any adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Four years as an associate producer covers the length. Your material doesn't say whether the game was run as a live service. Answer slot: if the main title was updated live for players, say so in your own words. If it wasn't, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | There's no gap here. This is your strongest line, so use it in its own terms: weekly, the main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | There's no gap here, but the line says you presented the numbers, not how they were produced. D1 rehearses the probe on how they were counted |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist QA still uses is one piece of writing, and the JD asks about writing in general. Words: "I wrote the release checklist our QA team still uses." A4 is where you show your writing live |

## Reading the interviewer

Everything here comes from Tobias's public professional footprint only.

| Item | Detail | Provenance |
|---|---|---|
| Career pattern | Head of Live Operations at Saltmarsh Games. Previously a QA lead at a console studio | [grounded] GDC 2026 talk listing, see Sources |
| Public theme | GDC 2026 talk, "Patch Notes Are a Promise". The listing summarises his argument: a live team is judged by how often its patch notes describe what actually shipped | [grounded] GDC 2026 talk listing |
| Implication 1 | The release checklist (F4) will probably get a serious, detailed probe from someone who knows QA work closely. Rehearse E2 and A3 | [inferred] from his QA background |
| Implication 2 | Answers that promise more than you did will cut against the exact thing his talk argues for. The honest concession in C1 fits his stated standard | [inferred] from the talk's argument and the value Ship the Patch Not the Promise |
| Implication 3 | In the tabletop, say how you would decide what to tell players during the outage. Telling players only what is confirmed matches both his talk and the published value | [inferred] from the talk and the values page |
| Shared vocabulary | The release checklist and working with QA. This draws on F4: "Wrote the release checklist our QA team still uses." It is shared ground, not a shared career jump. Don't present it as one | [grounded] F4 and the talk listing |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The live-incident tabletop: a simulated outage during a live event | Highest, 5 questions. The hiring-manager prior favours Case, and Saltmarsh's own interviewing page makes the tabletop half of the hour | Clarify first, then triage, then people, then players, then record. Think aloud and challenge one premise respectfully |
| Values / Behavioral | The values conversation, mapped to Saltmarsh's three published values | High, 4 questions. The interviewing page names a values conversation in this hour | Use one story per value where your quotes carry one. Otherwise use a selection scaffold, and say so honestly when nothing fits |
| Skeptic | Probes on the gaps: in-app purchases and a season pass, two titles, coordinating teams | Mid, 3 questions. The hiring-manager prior favours Skeptic, and C1's gap is the obvious target | Rehearse C1 until it bores you. Bridge only from your quoted sentences, and say the limit plainly |
| Data-Driven Prober | How the retention numbers were counted, and which KPIs belong in a post-event review | Mid, 3 questions. The JD's KPI and retention lines, plus an interviewer with a QA background | Know what you can and can't say about how the numbers were produced, and say "I don't know" where that is true |
| Pressure | Time-boxed challenges during the simulated outage | Low, 2 questions. Outage simulations tend to come with a clock. Nothing published says Tobias interviews this way | Pause, restate the question, and hold your position through two follow-ups before conceding anything real |
| Conversational | Opening chat: your story so far, and why Saltmarsh | Low, 2 questions. Almost every hiring-manager hour opens this way, and it is still scored | Use a pre-built 90-second arc taken from your five sentences |
| Peer Evaluator | Coordination tension with design, art and engineering | Low, 2 questions. Tobias isn't a peer, but the JD's coordination line will come up in a collegial register | Work out the principles for where each team's job ends before the interview. Reciprocity: say what you would bring the other teams |

## Question banks

### A. Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event. Players report that event rewards aren't arriving, and the community channel is filling up. Walk me through your first fifteen minutes." | CASE | [inferred] | Start by clarifying. Which title? All players or a segment? Since when? Can it be reproduced? Then triage severity. Pull in engineering on call, ask QA to reproduce, and ask community for a holding message that says only what is confirmed. Decide whether to pause, extend or leave the event running. Keep a timeline as you go, because it feeds the post-event review. This question needs no claim about your past, so the guidance makes none | This mirrors the published Outage Hour format, which is why it is labelled inferred rather than generic. Expect something close to it. Its CASE type tests structure under a live problem |
| A2 | "Engineering has a fix, but QA has only run half the checklist. The event ends in six hours. Do you ship?" | CASE, JD | [inferred] | Don't answer yes or no first. Ask what the unrun half covers, how much risk the fix carries against how much the bug is costing, whether a partial or server-side change is possible, and who makes the final call. Then commit to a recommendation and give the condition that would change it. Say what players would be told, keeping to what is actually shipping | This is the tabletop's natural follow-up. It touches the JD's release-checklist line and the value Ship the Patch Not the Promise |
| A3 | "The outage is fixed. What changes on the release checklist?" | CASE, JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure: what the incident exposed, which step would have caught it, what to add or tighten, and agreeing the change with QA. You can say you wrote the checklist your QA team still uses. Answer slot: the value Leave the Build Greener says each release leaves the checklist better. If you changed your checklist after a release, say what changed and why, in your own words. If you didn't, say so plainly and say what you would add here | F4 is your strongest match to an interviewer with a QA background. This question invites it inside the tabletop |
| A4 | "The outage cost the event its final weekend. Give me the first three lines of the post-event review." | CASE, JD | [generic] | Line one: what happened, and when. Line two: impact on the measures you would check, such as participation and retention against the previous event. Say you would confirm Saltmarsh's own KPI definitions first. Line three: what changes before the next event. Keep each line short. The question scores your writing as much as your content. No claim about your past | This covers F3 and F8 live. It is generic because it uses a role-family pattern, not Saltmarsh's actual review template |
| A5 | "From February both titles share one events calendar. An outage on one title lands in the middle of a shared event. What do you do differently from a single-title outage?" | CASE, CO | [grounded] | Clarify whether the shared event's rewards or progress depend on both titles. Decide whether to pause the event for both or for one. Separate the player messaging for each title's community. Plan calendar slack so a fix on one title doesn't push back the other. No claim about your past | This is the differentiator question. It uses the published Project Larkspur plan (see Sources), which most candidates won't bring into the tabletop |

### B. Values / Behavioral (the values conversation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Context from the quote: the calendar was yours, weekly, for the main title. Selection scaffold: pick a time a planned drop moved or changed because of what players did or said. A good story needs what the plan was, the player signal, what was decided, and which part of the decision was yours. If no such time comes to mind, say so plainly. Then give the nearest thing your material carries, or how you would handle it | This is the published value Players Before Plans. F6 is the calendar it would rest on, but no quote carries an actual disagreement, so the guidance is a scaffold |
| B2 | "Tell me about a time you had to say something wasn't ready." | VAL | [grounded] | Selection scaffold for Ship the Patch Not the Promise. A good story needs a named stake, who wanted it announced or shipped, what you said, and what happened afterwards. If no such time comes to mind, say so plainly. Then give the nearest thing your material carries, or how you would handle it | This value comes from the published values page. None of your sentences carries this story, so the guidance is a scaffold |
| B3 | "Leave the Build Greener: what have you left better than you found it?" | VAL, EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story map using only the beats the quote states: you wrote the release checklist, and QA still uses it. Tell it in your own words. Answer slot: the value speaks of leaving the checklist better each release. If you revised it after releases, say what you changed and why. If you didn't, say so plainly and stay with writing it and its continued use | This is your most direct values match, through F4. EXP is secondary because a prober will ask what was yours |
| B4 | "Tell me about a time what was announced to players didn't match what shipped." | VAL | [grounded] | Selection scaffold. A good story needs what was said, what actually shipped, how the gap was found, and what you did about it. If no such time comes to mind, say so plainly. Then say how you would keep announcements tied to the build, as a plan | This uses the value Ship the Patch Not the Promise ("we announce what is built, not what is hoped"), and it is the theme of Tobias's talk |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never worked on a game with in-app purchases, and Larkspur moves both titles to a season pass. Why should I hire you for this?" | JD, CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." ; "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI rehearsal in this pack.** Hold with what you have: "For the last two years I ran the weekly content-drop calendar for our main title." Concede plainly and early: "I haven't worked on a game with in-app purchases." Then give a ramp plan, stated as a plan and never as past experience: what you would learn first, such as how the season pass is structured, which events feed it, and how its KPIs are read, and whom you would learn it from. Follow-up 1, "So you'd be learning on our players?": hold the calendar line and repeat the plan. Follow-up 2, "Others have done it already": agree that they have, and don't shrink the gap. Never call a season pass "just another calendar" | You stated this negative yourself, and the published Larkspur plan puts monetization at the centre of the next year. This objection will come in some form. JD and CO because it joins the role to the strategy |
| C2 | "The role covers two titles. Your calendar was for your main title. What changes when it's two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Stay at the quote's scope: the main title, weekly, two years. Answer slot: the JD says two titles. If you worked on other titles' calendars, say how. If you didn't, say so plainly and stay with the main title. Then give a plan: shared dependencies, conflicting dates, and one view of both titles for every team | This covers the scope limit in F1. JD because it scores the stated requirement |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Pick a part where the limit is real and say where your experience stops, in your own words. The pack sees F2 (coordinating teams) and F3 (owning the review) as the thinnest areas. Use a slot's honest branch, not a confession you haven't made. Then give the closest thing you did, quoted, and your plan for the first month | This is a standard Skeptic stem. Rehearsing it stops you from naming a gap that isn't real, or one the interviewer would never have found |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | You presented them monthly to the studio head. That is the quote, so state it plainly. Answer slot: the JD's retention line makes these probes likely. Which retention measures were they, how were they counted, and did you produce them or present someone else's? Answer each in your own words. "I don't know exactly how that was calculated" is an honest branch, and so is "the analytics team produced them". Name the assumption behind the numbers you would defend least, if you know one | F7 is a line nothing has been inspected behind, and a prober will dig two levels into it. EXP because it tests attribution |
| D2 | "What KPIs would you put on a post-event review?" | JD, CASE | [generic] | Structure: participation, completion, retention against a baseline or the previous event, the monetization impact relevant to the season pass (learn their definitions first), and incident impact. Answer slot: the JD says you would own this review. If you have written up how a content drop performed, say what you reported. If you haven't, say so plainly and stay with the structure | This covers F3. It is generic because it uses a role-family KPI pattern, not Saltmarsh's actual dashboard |
| D3 | "Tell me about a time the numbers you presented told a story nobody wanted to hear." | EXP, VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Context from the quote: monthly retention numbers, to the studio head. Selection scaffold: a good story needs what the numbers showed, how you presented it, and what happened. If no such time comes to mind, say so plainly. Then say how you would present a bad month | This adapts the "unpopular truth to leadership" persona stem to F7 |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who has already run live ops on a monetized game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." ; "Wrote the release checklist our QA team still uses." ; "Presented the monthly retention numbers to the studio head." | Pause, then give three beats from the three quotes: the calendar, the checklist and the retention numbers, each in its own terms. If they push on monetization, use C1's concession. Hold the three beats through two follow-ups and don't add to them | This is C1 under a clock. The pressure is the format, not new content |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the sentence's own claim: you wrote it. Answer slot: if others contributed steps or reviewed it, say which parts were yours, in your own words. If none were theirs, say so plainly. Never claim it covers more than it does | F4, from an interviewer with a QA background. This is the attribution probe it invites |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "So, walk me through the journey." | EXP, JD | [grounded] "4 years as an associate producer at a puzzle-game studio." ; "I ran the weekly content-drop calendar for our main title for the last two years." ; "Wrote the release checklist our QA team still uses." ; "Presented the monthly retention numbers to the studio head." | Build a 90-second arc from these four sentences, in order, with nothing added. Answer slot: the JD asks for live-service work. If the main title was updated live for players, say so. If it wasn't, say so plainly. Close with your reason for this move, in your own words | The opening is scored. It covers F5 and F6. The ID is F1q so it isn't confused with fit row F1 |
| F2q | "What drew you to Saltmarsh?" | CO | [grounded] | Answer slot: give your actual reasons, in your own words. You can mention things you read for this interview where they are genuinely part of your reason: Project Larkspur, the three values, Tobias's talk | A rapport question that still scores homework. Grounded on the published sources in Sources |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design wants another week for an event. The calendar says it ships Thursday. How do you handle it?" | CASE, JD | [generic] | Clarify what the extra week buys and what slipping costs, including dependencies, community promises and the other title. Look for a middle option, such as shipping a reduced version or moving a later slot. Decide who makes the call, and record it. Players Before Plans gives you the tie-breaker. No claim about your past | This covers F2 as a live problem |
| G2 | "Tell me about working with art, engineering or community on a content drop." | JD, EXP | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years." | Context from the quote: the calendar was yours. Answer slot: if you worked with any of those teams on a drop, say which teams and what passed between you, in your own words. If you didn't, say so plainly and say how you would set up that coordination | This is F2's discovery gap, rehearsed so the honest answer is ready |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Live-events calendar for two titles (F1) | C2, A5 |
| Coordinate design, art, engineering, community (F2) | G1, G2, A1 |
| Own the post-event review and KPIs (F3) | A4, D2 |
| Release checklist with QA (F4) | A2, A3, E2, B3 |
| 3+ years live-service (F5) | F1q |
| Content calendar (F6) | C2, B1 |
| Player-retention metrics (F7) | D1, D3 |
| Clear written communication (F8) | A4 |

## Values cheat sheet

The values below come from saltmarshgames.com/values, and the values conversation is documented on the interviewing page.

| Value (official name) | Working meaning | Your story |
|---|---|---|
| Players Before Plans | When the calendar and player behaviour conflict, follow the players | Selection scaffold (B1): a drop that moved because of players. If none comes to mind, say so plainly and give how you would handle it |
| Ship the Patch Not the Promise | Tell players only what is built | Selection scaffold (B2, B4): a time you said something wasn't ready. If none comes to mind, say so plainly and give how you would handle it |
| Leave the Build Greener | Each release leaves code and checklist better | F4: "Wrote the release checklist our QA team still uses." B3's slot covers whether you revised it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came into live ops from QA. What from QA do you look for in a live-ops producer?" | It is tied to his public career path and turns the checklist conversation into a conversation between peers |
| R2 | "Your GDC talk judged a live team by how often its patch notes match what shipped. How does Saltmarsh track that today?" | It shows you researched him, not just the company, and it opens the release-checklist discussion |
| R3 | "When the two titles move to one shared calendar in February, does this role own the whole calendar or one title's part of it?" | It uses the published Larkspur plan, and the answer tells you what the job will actually be |
| R4 | "What does a post-event review look like here now, and which KPIs does it report?" | It goes straight to the KPI line you would own and shows you are already thinking about the work |
| R5 | "Who owns the release checklist today, and what would you want changed in the first quarter?" | It brings your strongest line back into the room and asks about his priorities |
| R6 | "What would a successful first 90 days look like for this producer?" | It asks for the actual scorecard, which you need before accepting an offer |

## Prohibited claims

This pack will not coach the following claims.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events, or a calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says one weekly content-drop calendar for the main title. C2's slot stays inside that |
| Owned post-event reviews or retention KPIs | Inflated form of F3 | F3's quote at its own scope. D2's slot asks only what you reported |
| Built or calculated the retention numbers | Inflated form of F7 | F7's quote at its own scope. D1's slot asks who produced them |
| Managed QA or the release process | Inflated form of F4 | F4's quote: you wrote the checklist and QA still uses it. E2's slot asks which parts were yours |
| Has led a team | A negative you stated | "I haven't led a team." No slot |
| Has worked on in-app purchases, monetization or a season pass | A negative you stated | "I haven't worked on a game with in-app purchases." No slot |

## Sources

- **Provided:** the JD text and your background, both in your message.
- **Search** "Saltmarsh Games values" returned https://saltmarshgames.com/values
- **Search** "Saltmarsh Games interview process producer" returned https://saltmarshgames.com/careers/interviewing
- **Search** "Saltmarsh Games mobile studio news 2026" returned https://saltmarshgames.com/news/project-larkspur (September 2026: two titles move to a season pass with one shared events calendar from February 2027, and per-title event teams are replaced by a single live-ops group)
- **Search** "Tobias Wrenfield Saltmarsh Games Head of Live Operations" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise
- **Fetch** https://saltmarshgames.com/values returned the three values with their definitions
- **Fetch** https://saltmarshgames.com/careers/interviewing returned the Outage Hour format
- No dossier was used.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and B1 to B4: three values by official name |
| 2. Saltmarsh Games interview process | yes | Established the session as the Outage Hour (tabletop plus values), which set Case and Values as the top personas and triggered detection of a values round |
| 3. Saltmarsh Games strategy and news | yes | Project Larkspur moved A5, C1, F2q and R3 |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer read, R1, R2, and the probe weighting on F4 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Confirm Tobias is your future manager, and send any recruiter notes on the Outage Hour.** Persona weights would rest on your own facts rather than on the interviewing page, and any focus areas could get their own questions.
- **Your CV.** More quoted evidence beyond the five sentences in your message, and story maps in place of scaffolds for B1, B2, B4 and D3.
- **Your answers to the slots in F2, F3 and F5.** Whether you worked with design, art, engineering or community, whether you ever wrote up a drop's performance, and whether the title was live-service. Rows F2, F3 and F5 would move from slots to quoted evidence, along with G2, D2 and F1q.
- **An artifact you can show:** the release checklist itself, or a retention deck you presented, with anything confidential removed. F4 or F7 would move from medium to high confidence.
- **Deep research:** up to 6 more searches and 2 more fetches, several more minutes. It would cover a Saltmarsh strategy brief, the content of Tobias's talk, reports on the loop for this role family, and recent changes in the organisation. The CO and CASE questions would gain sharper detail.
- **A tuesday-dossier.md from job-underwriter.** It would add evidence you have already verified, a constraint on how each weak area is coached, and a prohibited list checked against your corrections.
