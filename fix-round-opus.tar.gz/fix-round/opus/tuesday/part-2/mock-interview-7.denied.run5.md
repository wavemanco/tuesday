I've read the prep playbook. Next I'm running a few targeted web searches on Saltmarsh Games and Tobias Wrenfield, then I'll build your pack.
Femi, your prep pack is ready: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-denied-a93494d2/SaltmarshGames_live-operations-producer_interview_pack.md`

I couldn't research Saltmarsh or Tobias. All four web searches were blocked because search permission isn't granted in this session. So the pack uses only the JD and your background. I've assumed Tobias would be your manager, and the questions about Saltmarsh's own games are generic.

What's in it:
- **The question to rehearse most (B1):** "This role coordinates four teams across two titles, and you haven't led a team. Why would this work?" The suggested answer starts by saying plainly that you haven't led a team. Then it sticks to what you told me: you ran the weekly content-drop calendar for two years.
- **How you match the JD:** each JD line sits next to your own words. Three lines need care, because your notes don't fully reach them:
  - "plan and run" the events calendar across two titles
  - managing the checklist with QA, which is more than writing it
  - "own the post-event review"
- **22 practice questions** with suggested answers, plus reverse questions to ask him.
- **What not to claim:** leading a team, in-app purchase experience, managing releases, or having analysed the retention numbers rather than presented them.
- **One thing to do tonight:** play both of Saltmarsh's games. It's the cheapest fix for the research gap.

Say the word and I'll play Tobias as the skeptic on B1.
I can also save a `tuesday-dossier.md` file recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Is Tobias going to be your manager, and did the recruiter mention any format or anything to prepare? The answer changes which questions get the most weight. And do you want to allow web search so I can rerun the four blocked searches?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: SaltmarshGames_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. I've assumed he's the hiring manager for this role. Your message doesn't say, so the persona weights below rest on that assumption.
**Format:** one 60-minute session (your message)

---

## How to use this pack

- **Personas** describe how a question is asked: who is asking and in what style. **Types** describe what is being scored.
- Type key:
  - **VAL**: behavioral or values alignment. Does your past behavior show the qualities they care about?
  - **EXP**: work-experience deep-dive. Do the claims you make about your past hold up, and what did you actually do?
  - **JD**: role-driven. Can you do the job as listed, gaps included?
  - **CO**: company knowledge. Have you done your homework on Saltmarsh and its titles?
  - **CASE**: a live problem from the role, reasoned through out loud.
- Each question's Provenance cell quotes the sentences from your message that its guidance relies on. If the guidance says something about your past that its quote doesn't, the pack made a mistake. Trust the quote.
- An **answer slot** is a decision you make in the interview: if the thing happened, say how in your own words; if it didn't, or it wasn't yours, say so plainly. Both answers are honest, and both pass.
- The guidance is scaffolding, not a script.
- Fit-snapshot rows are numbered F1 to F8. Question banks are lettered A, B, C, D, E, G and H. F is skipped so a bank never gets confused with a fit row.

---

## Prep triage: sized for one evening, since Friday is tomorrow

1. **B1**, the highest-ROI prep in this pack: coordinating four disciplines across two titles when you haven't led a team. Say your answer out loud three times, follow-ups included.
2. **Play both of Saltmarsh's titles tonight** (D3, D2). Note one current event in each and one thing you'd ask about it. Nothing else in this pack is as cheap or as visible.
3. **B2 and E2**, the in-app purchase gap. Rehearse the plain acknowledgment and your first-month plan until you can say them without hedging.
4. **A2 and A3**, a live event that underperforms and a post-event review. The JD's "own the post-event review" line makes some version of these likely.
5. **C1**, your retention presentations. Decide tonight which branch of the answer slot is true for you.
6. Choose three reverse questions.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a content-drop calendar for one title, not a live-events calendar across two, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: "Plan and run" makes a probe on planning likely. If deciding what went on the calendar was yours, say how you decided, in your own words. If it was set for you, or there was no such decision, say so plainly and stay with running it. Talk about two titles as a plan, never as a past |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Nothing backs this line except your own statement, though, so expect a probe. Lead with it in the quote's own terms: weekly, the main title, the last two years |
| F3 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist, not that you managed it with QA on each release: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran it with QA on releases, say how, in your own words. If that was someone else's job, or no such step existed, say so plainly and stay with having written it |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | Your material says you presented the numbers. It doesn't show whether you produced or analysed them. Answer slot: the JD's retention line makes a probe on which metrics, and how they were counted, likely. If you prepared or analysed them, say which ones and how, in your own words. If someone else produced them, or you don't know how they were counted, say so plainly and describe the presenting you did |
| F5 | "own the post-event review and the KPIs it reports" — JD | none given | none | [grounded] | discovery | Strong evidence would be a review you wrote after an event or update: what it measured, who read it, and what changed because of it. Answer slot: if you have written or contributed to anything like that, say what and how, in your own words. If you haven't, say so plainly and set out how you would run one (A3) |
| F6 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show whether running the calendar meant coordinating other disciplines. Coordinating is not the same thing as leading a team, which you've said you haven't done. Answer slot: if your calendar work meant getting design, art, engineering or community people to deliver, say who and how, in your own words. If it didn't, say so plainly and stay with the calendar |
| F7 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The years are there. Your material doesn't say whether the puzzle title was run as a live service. This is a length-of-experience requirement, not a gate. Answer slot: if the game was run as a live service, say what made it one, in your own words. If it wasn't, say so plainly and stay with the four years and the weekly drops |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Your writing is already in use: you wrote the release checklist, and QA still uses it. Say it in those terms |

**Gaps you stated** (not JD requirements, but likely to be raised): "Never led a team, and never worked on a game with in-app purchases." — your message. The plain acknowledgments are: "I haven't led a team." and "I haven't worked on a game with in-app purchases."

---

## Persona table

| Persona | How it shows up | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Plan this calendar", "diagnose this dip", "design the review" | **High (5 questions).** Hiring-manager prior: he's buying the ability to run his calendar. The JD's verbs (plan, coordinate, own, manage) are all live-problem material | Clarify, then objective, approach, metrics, risks. Think aloud. Challenge one premise per case, politely |
| Skeptic | Quiet probing on the two gaps you named, and on one title versus two | **High (5 questions).** Hiring-manager prior, plus two stated gaps that sit right next to the JD's coordination and KPI lines | Rehearse B1 until it's boring. Give the plain acknowledgment first, then only what your quotes carry, then a plan |
| Data-Driven Prober | "Which retention metrics? Counted how?" | **Medium (3 questions).** The JD names retention metrics, and your background has a retention line that invites follow-up | Know which branch of C1's slot is true. Say "I don't know how it was counted" if that's the truth |
| Conversational | The opener, "what are you playing", the reverse-question slot | **Medium (3 questions).** A 60-minute single session almost always opens and closes this way, and casual questions are still scored | A 90-second arc built from your four sentences. Have something concrete to say about their titles |
| Pressure | "How much of that was actually you?", sixty-second challenges | **Low (2 questions).** No signal for it, but attribution probes on the checklist line are cheap for him to run | Pause. Hold through two follow-ups. Concede exactly where your quote stops |
| Values / Behavioral | "Tell me about a time…" | **Low (2 questions).** No values round is known, and no published values could be checked | Use a story only where one of your sentences carries it. Otherwise pick an instance using the scaffold |
| Peer Evaluator | Seams with community and engineering | **Low (2 questions).** Not a peer round, but the JD's cross-team line makes collaboration scenarios likely in collegial packaging | Propose principles for the seam instead of pretending to know it |

---

## Question banks

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles, one live-events calendar. How would you plan the next quarter?" | CASE | [generic] | Clarify first: each title's audience and cadence, which teams the titles share, what's already committed, and which KPIs events are judged on. Then structure it: fixed beats per title, no collisions on shared art and engineering time, a buffer for hotfixes, and review checkpoints after each event. Finish with your biggest risk and how you'd watch for it. The question needs no claim about your past, so the guidance makes none | The JD's first line (F1's requirement), asked as a live plan. This is a hiring manager's most natural case. CASE because structure is scored, not history |
| A2 | "An event went live yesterday and day-1 participation is half what we expected. Walk me through the next 24 hours." | CASE | [generic] | Verify, then segment, then decide, then communicate. First, is it real, or a tracking or config problem? Second, did the event reach everyone: client version, rollout, the announcement? Third, which segments are short: platform, region, new or returning players? Then decide whether to fix, extend or leave it, and tell the team and the community team what's happening. Log everything for the post-event review. Say which assumption you'd test first and why | Tests the "run" half of F1's requirement and feeds F5's. CASE because it's diagnosis under time pressure |
| A3 | "Design the post-event review for a two-week event. What's in it, who reads it, which KPIs?" | JD | [generic] | KPIs agreed before the event, not after. Goal versus result. Participation, completion, and how participants' retention compares with non-participants'. What broke operationally, including checklist misses. Community sentiment. Then decisions, each with an owner and a date. Keep it short enough that people actually read it, because the JD also asks for clear writing. Makes no claim about your past | F5 has no evidence, so this is where you show you could own it. JD content with CASE delivery |
| A4 | "Design, art and engineering each tell you they can't hit the date for the next update. What do you do?" | CASE | [generic] | Find the real constraint: is it one team blocking the others, or all three? Lay out options: cut scope, move the date, swap in a lighter event, reuse assets. Get the decision from whoever owns it, and tell the community team before players notice. Makes no claim about your past | F6's requirement as a live problem. It also gives him a no-history way to see how you'd coordinate, which matters given B1 |
| A5 | "If an event includes paid offers, what changes in how you plan and review it?" | CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then reason it through: bring in whoever owns the economy and pricing early, add QA coverage for purchase flows, check store and platform rules, add revenue-side KPIs to the review, and protect player trust. Ask how Saltmarsh handles it today. Asking is a strength here, not a weakness | Your stated gap meets a common mobile pattern. The question is conditional, so it assumes nothing about Saltmarsh's titles. CASE because you reason forward, not back |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates design, art, engineering and community on every update, across two titles. You haven't led a team. Why would this work?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | **The highest-ROI rehearsal in this pack.** Concede first, plainly: "I haven't led a team." Then hold only what your quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's coordination line makes a probe likely on whether running that calendar meant getting other disciplines to deliver. If it did, say who and how, in your own words. If it didn't, or that wasn't yours, say so plainly and stay with the calendar. Then give your plan for doing it here, said as a plan, never as a past. Follow-up 1, "but who did you actually coordinate?": return to the slot and don't add to it. Follow-up 2, "two titles is double": concede it's a step up, because one title is what you've run, and give one concrete way you'd keep two calendars from colliding (A1) | F6 is silent and the team-leadership gap is one you stated, right beside the JD's coordination line, so some version of this objection is near-certain. JD because it scores the stated responsibility |
| B2 | "You haven't worked on a game with in-app purchases. What would you do in your first month to close that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment, with no softening: "I haven't worked on a game with in-app purchases." Then a ramp plan, said as a plan: read past post-event reviews, sit with whoever owns monetization, study the store and offers in both titles, and ask for one event to shadow before owning one. Concede that it's a real gap. Don't bluff the vocabulary | A gap you stated, which a Head of Live Ops at a mobile studio will likely test. JD because the KPIs in "the KPIs it reports" may include revenue. Reverse question R3 is where you find out |
| B3 | "Was your puzzle game actually a live-service game?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Lead with what your sentences carry: four years as an associate producer at a puzzle-game studio, and the weekly content-drop calendar for the main title for the last two years. Answer slot: if the game was run as a live service, say what made it one, in your own words. If it wasn't, say so plainly, then let the weekly drops speak for themselves. Don't call the game live-service unless it was | F7 is the JD's headline requirement, and your material leaves the label open. JD because it scores the stated qualification |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick a real one. The in-app purchase gap is the honest choice: "I haven't worked on a game with in-app purchases." Then the B2 plan, in one sentence. Don't offer a disguised strength, because a hiring manager notices | A classic Skeptic stem. Rehearsing it stops you reaching for a non-answer under pressure |
| B5 | "Why leave the puzzle studio, and why live ops now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Your reasons aren't in your material, so this is a selection scaffold. Pick one real pull toward this role, such as two titles, owning the review and its KPIs, or coordinating every discipline. If something is pushing you out of your current studio, keep it to one neutral sentence. If no clear pull comes to mind, say plainly what you're looking for next and connect it to one line of the JD | Motivation consistency is standard Skeptic territory. JD because the answer should point at the role's actual duties |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to your studio head. Which metrics, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beats your sentence states: monthly, retention numbers, presented to the studio head. Answer slot: if you prepared or analysed the numbers, say which metrics and how they were counted, in your own words, then name the assumption behind them you'd defend least. If someone else produced them, say so plainly. If you don't know how they were counted, say that too, and describe what you did with them when you presented | F4 is the evidence for the retention requirement and the obvious place to probe. EXP because it tests what was actually yours |
| C2 | "Tell me about a time a retention number changed what went on the content calendar." | EXP | [generic] | An open prompt. Pick an instance only if one exists. It needs the number, the change it caused, and what happened afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (your calendar and your retention presentations), or how you would connect the two here | The JD pairs a content calendar with retention metrics, and F2 and F4 sit on either side of that pairing. Your material doesn't link them, so this is a scaffold, not a story map |
| C3 | "Day-7 retention for players who joined during an event is lower than for players who didn't. What do you make of it?" | CASE | [generic] | Don't call it bad yet. Clarify the definition and the denominator. Ask whether the event pulled in different kinds of players, compare like-for-like cohorts, then say what you'd check next and which assumption you're least sure of | Retention reasoning without relying on your past (F4's requirement). CASE because the reasoning is scored |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in four beats, one per sentence: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist you wrote that QA still uses; the monthly retention numbers you presented to the studio head. Close with why this role, in your own words (B5). Describe what you did and let him draw the conclusions | Nearly every session opens here. It sets the scope he'll probe for the next hour, so keep it to exactly what you did |
| D2 | "What mobile games are you playing at the moment? Any live events you've liked?" | CO | [generic] | Be genuine and specific: one game, one event, and what about its design or rhythm worked and why. If you've played Saltmarsh's titles by then, an observation about one of their current events is the best answer | Casual questions in the Conversational register are still scored. CO because it signals homework and taste |
| D3 | "What do you know about our two titles?" | CO | [generic] | Research for this pack couldn't run, so this pack knows nothing about them. Play both tonight. Bring one specific observation about each, such as event cadence, what's live now, or how events are surfaced to players, plus one genuine question. Don't guess at facts you haven't seen | No research could be done on this company, so this is the biggest homework gap, and it's cheap to close by playing. CO by definition |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Writing a checklist isn't managing releases. How much of release management was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Pause. Hold on your quote: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage the release checklist with QA" makes this probe likely. If you also ran it with QA on releases, say how, in your own words. If you didn't, or no such step existed, say so plainly and stay with having written it. Hold through two follow-ups by going back to the quote, never by adding to it. Concede exactly where the quote stops | F3 is a transferability row, and the gap between writing and managing is an easy pressure target. EXP because it scores attribution |
| E2 | "Sixty seconds: why you over someone who's run events on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Concede first, briefly: "I haven't worked on a game with in-app purchases." Then three sentences, one per quote: the weekly content-drop calendar for the main title for the last two years, the release checklist you wrote that QA still uses, and the monthly retention numbers you presented to the studio head. Then stop. Don't call them proof of anything. Let him draw the inference | Your stated gap and your strongest lines, side by side under a time box. JD because it scores your fit against the listed job |

### G — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | An open prompt, so this is a selection scaffold. You need a named stake, the moment you said it, and a working relationship that survived. If one of your retention presentations carried bad news, that could be the story, but only if it did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | A standard behavioral stem. Your material has a leadership-facing line (F4) but doesn't say any truth was unpopular, so this is a scaffold, not a story |
| G2 | "Tell me about something you wrote that changed how another team worked." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped from your sentence: you wrote the checklist, and QA still uses it. Answer slot: if you know how it came to be adopted, or what it replaced, say so in your own words. If you don't, or it simply became the default, say so plainly and stay with the fact that it's still in use | F8 is your written-communication evidence and the JD asks for "clear written communication". VAL in shape, JD in content |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "The community team finds out about an event change at the last minute and players are angry. What happens next, and how do you stop it happening again?" | CASE | [generic] | First, the next hour: get community the facts and a line they can post. Then the fix: build a communication step into the release checklist so community hears about changes as early as engineering does. Make it a principle you propose for the seam, not a claim about how Saltmarsh works | The JD lists the community team among the four you coordinate (F6's requirement). Peer-style seam question, CASE delivery |
| H2 | "The engineering lead tells you next month's calendar is unrealistic. How do you handle that conversation?" | CASE | [generic] | Ask what specifically is unrealistic before defending anything. Separate fixed dates from movable ones, trade scope for time in the open, and agree who makes the final call. Show spine and tact together. Makes no claim about your past | Disagreement between peers over the calendar is the core seam in this role. CASE because it's a live scenario |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, B1 |
| "coordinate design, art, engineering and community teams on each update" | B1, A4, H1, H2 |
| "own the post-event review and the KPIs it reports" | A3, A5, B2 |
| "manage the release checklist with QA" | E1, G2 |
| "3+ years producing live-service games or apps" | B3, D1 |
| "experience running a content calendar" | D1, C2, E2 |
| "comfortable with player-retention metrics" | C1, C2, C3 |
| "clear written communication" | G2, A3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here today, and who reads it?" | It goes straight at something the JD says you'll own, and the answer tells you how high the bar is |
| R2 | "Are the two titles planned on one shared calendar or separately, and where do they collide today?" | It shows you're already thinking about A1's problem, and it gives you real detail to use if there's a later round |
| R3 | "Which KPIs is an event judged on? Is revenue part of what this role reports?" | It tells you how much the in-app purchase gap matters here, and it reads as diligence, not nerves |
| R4 | "How is the release checklist owned today, between production and QA?" | It connects your strongest artifact (F3) to how they work, without overclaiming |
| R5 | "What would you want this person to have taken off your plate in the first 90 days?" | It's addressed to him as the person running live ops, and the answer is your onboarding plan |
| R6 | "What's the one thing about running live ops here that people outside the team tend to underestimate?" | It invites his own view of the work, which tends to turn the last ten minutes into a conversation |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events, or a live-events calendar, across titles | Inflated form of F1 | F1's quote at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." The pack's observation is that your material describes one title's content-drop calendar. B1's slot stays inside that calendar |
| Managed releases, or ran the release checklist with QA | Inflated form of F3 | F3's quote at its own scope: "I wrote the release checklist our QA team still uses." The pack's observation is that your material says you wrote it. E1's slot stays inside that |
| Analysed, built or owned the retention metrics | Inflated form of F4 | F4's quote at its own scope: "I presented the monthly retention numbers to the studio head." C1's slot asks only which metrics they were and how they were counted |
| Has led a team | Negative you stated | The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases, or on monetized events | Negative you stated | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |

---

## Sources

**Provided documents:** your message (the JD text, and your background in your own words).

**Searches sent:**
- `Saltmarsh Games mobile studio values`: refused (web search permission not granted)
- `Saltmarsh Games interview process producer`: refused
- `Saltmarsh Games news 2026`: refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: refused

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Refused. It would have supplied value names for a values cheat sheet and themes for the G bank. The G bank uses generic behavioral stems instead |
| 2. `Saltmarsh Games interview process` | unavailable | Refused. It would have shown whether more rounds follow. This session's structure comes from your own words: one 60-minute session with Tobias |
| 3. `Saltmarsh Games` recent news | unavailable | Refused. It would have grounded at least one CO or CASE question in the titles and current priorities. A1 to A5 and D3 are generic as a result |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Refused. It would have supplied an interviewer read, persona adjustments, and a reverse question tied to his path. Personas fall back to hiring-manager priors |
| 5. representative Live Operations Producer JD | skipped | You supplied the JD, which already sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Confirming whether Tobias would be your manager** (and any recruiter note on format or a presentation): persona weights read from the real relationship, plus a build section if anything is due on the day
- **Allowing web search** (targets 1 to 4 above): an interviewer read, CO and CASE questions grounded in Saltmarsh's actual titles and news, and values for the G bank if they're published
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes, only if you want it): a strategy brief on Saltmarsh's titles and market position, and any public talks or writing by Tobias
- **The names of the two titles**: D3, A1 and R2 rewritten around them
- **Your CV**: wider evidence for F5 and F6, and the four D1 beats checked against your written record
- **A redacted excerpt of the release checklist** (your own work, safe to show): F3 and F8 move from medium to high confidence, and E1 gets an artifact to point to
- **Your answers to the answer slots in F1, F3, F4, F5, F6 and F7** (outside a drill): those rows, and B1, B3, C1 and E1, become story-mapped instead of slotted
- **A tuesday-dossier.md from an underwriting pass**: an evidence-derived highest-ROI objection and a confirmed prohibited list, in place of the ones this pack inferred
