The prep pack is finished and saved. I'm sending it now.
Dara, your prep pack is ready: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-8-denied-e8d3927f/AshgroveCreditUnion_member-experience-lead_interview_pack.md`

It's built as three short packs, one for each round on 21 November, all drawing on one shared "fit snapshot". That's a table matching each line of the job description to what you've told me about your experience. I didn't run any web searches. The job description, values, recruiter email and your strategy summary already covered everything a search would have found.

**What's in it:**
- **The question to practise most:** B4. Your future manager may say something like "you haven't worked in a contact centre or presented above regional level, so why take the risk?" The pack works through it step by step:
  - name both gaps yourself before you're asked;
  - stand on what you've actually done: the complaints log, training new tellers, the monthly spreadsheet;
  - say how you'd learn the rest, as a plan for the future.
- **The 20-minute case:** a structure for the time, three angles you could take (each with the weakness you should admit up front), and how to close on the panel's four values. It also flags one thing to avoid: settling an upset member's complaint by pointing them to the app or to the new hubs.
- **Values round:** your four sentences don't describe a specific occasion, so each value comes with a guide for picking a real story, not a ready-made one. Choose your four stories before the 21st.
- **Interview questions:** 29 in total, with suggested answers. There are also reverse questions for each round (questions for you to ask them) and a list of claims the pack won't coach. For example, "formal complaints log" mustn't turn into "regulated complaints", and "trained new tellers" mustn't turn into "coached supervisors".
- **Gaps in your material:** a few answers include a placeholder where your material is silent. Examples are what your spreadsheet tracks, whether it's Excel, and whether the log fell under complaint rules. Each one gives you two honest ways to answer. If you tell me the facts, those answers become your own stories.

If you'd like a practice run, I can play your future manager and put B4 to you live, with follow-up questions. I can also save a `tuesday-dossier.md` file listing the gaps this prep turned up, so you can bring them into later sessions. If you'd like the pack as a Word document, I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AshgroveCreditUnion_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of interviews:** 21 November 2026, three rounds on one day
**Round 1:** 30 minutes with the recruiter
**Round 2:** 45 minutes with the Head of Member Services (your future manager), mostly behavioural
**Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation. This is also the values round, scored against the four values
**Interviewer names:** not assigned yet, so this pack has no interviewer read

This is a loop pack. One fit snapshot is shared across all three rounds, followed by a short pack for each round with its own persona weights, questions and reverse questions.

---

## How to use this pack

- **Personas** describe *how* a question is asked: friendly, sceptical, case-style, and so on. **Types** describe *what is being scored*.
- Type tags:
  - **VAL**: behavioural or values. Does your past behaviour show *Ashgrove's* four published values?
  - **EXP**: experience deep-dive. Does what you said about your work hold up, and what was actually yours?
  - **JD**: job description. Can you do the job as listed, gaps included?
  - **CO**: company and strategy. Have you done the homework on Ashgrove's plans and pressures?
  - **CASE**: a live problem. Structure and reasoning on a situation from the actual role.
- **Provenance labels:** `[grounded]` means traceable to something you or Ashgrove supplied. `[inferred]` means derived by this pack, with the derivation named. `[generic]` means a common pattern for roles like this, with no claim about Ashgrove or about you.
- **An answer slot** marks a place where the interviewer is likely to probe something your material doesn't show. It always has two honest branches. Answer it from your own experience in the interview. It is not a question for me.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

Every sentence this pack uses about your past comes from the four sentences in your message, quoted below. Nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material shows one branch's formal complaints log. It does not show a process across branches, and your words should stay at that scope: "At my branch I handled the formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If any part of how complaints moved through your branch was yours to decide, say which part and how, in your own words. If handling the log meant keeping it rather than deciding outcomes, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | No wording closes this gap, and you have said so yourself. Words: "I haven't worked in a contact centre." Then describe how you would learn it, said as a plan and never as something in your past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The spreadsheet is monthly and covers complaints. Your material doesn't show whether it counts volumes, resolution times or both. Words that stay inside your sentence: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it tracks volumes, resolution times or both, say what it counts and how, in your own words. If it tracks something else, say what, and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message, "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | This is adjacent work, with a different audience (new tellers, not supervisors) and a different act (training on a script, not coaching judgement). Words: "I trained new tellers on our escalation script, and for the last three years I've been a branch supervisor." Answer slot: the JD's coaching line makes a probe about supervisors likely. If you have helped another supervisor with an escalation, say what you did, in your own words. If you haven't, say so plainly and stay with the tellers you trained |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a specific change to how members serve themselves that you helped shape, test or feed back on. Answer slot: if you have worked with a digital team or on a self-service change, say what it was and which part was yours, in your own words. If you haven't, say so plainly and say how you would start working with one |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Say it in your own terms, "Six years in retail banking, the last three as a branch supervisor", and let the interviewer match it to the requirement. Don't relabel your history in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | "Formal" is not the same as "regulated", and your material doesn't say which rules, if any, the log fell under. Answer slot: the JD's regulated-complaints line makes a probe likely. If the complaints on your branch's log came under regulatory rules, say which rules and what handling them involved for you, in your own words. If they didn't, or you don't know which rules applied, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then describe how you would prepare, said as a plan. Note that your sentence sets a ceiling, not a floor. It doesn't say you have presented at regional level, so this pack doesn't say it either |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says "spreadsheet", not "Excel". Answer slot: if you built it in Excel, say so and what it does, in your own words. If you built it in another tool, name it and stay with what the spreadsheet does |

### Requirement coverage

| JD requirement | Fit row | Questions that rehearse it |
|---|---|---|
| Own the complaints process end to end across branches | F1 | B6, D3 |
| Across branches and the contact centre | F2 | B1, B4 |
| Report monthly on complaint volumes and resolution times | F3 | E1, D1 |
| Coach branch supervisors on escalations | F4 | B7, B8, G1, G2 |
| Work with digital teams on self-service journeys | F5 | D2, plus the answer slot in B5 |
| 4+ years in financial-services customer operations | F6 | A1 |
| Experience handling regulated complaints | F7 | B2 |
| Confident presenting to senior leaders | F8 | B3, B4, C3 |
| Comfortable with Excel reporting | F9 | A5, E1 |

---

## Grounding brief

This section comes from your summary of the July 2026 strategy brief. I haven't seen the brief itself, only your summary.

| Item | What it says | Why it matters on 21 November | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | This is the JD's self-service line (F5) in strategic form. Expect it in D2, and use the phrase "digital channels" | [grounded] |
| Branch consolidation | Eight branches become five hubs over 2027 | Two branch managers are on your panel. "Neighbours, Not Numbers" and a consolidation question (D4) sit right next to each other. Say "hubs", the brief's word | [grounded] |
| New product | Small-business lending launches in Q1 2027 | This is new territory for complaints. It's worth one reverse question, and you shouldn't claim to know how its complaints will look | [grounded] |
| Competitive frame | App-only banks are the main competitive pressure | This is the backdrop for "why a credit union" (A2). Don't criticise digital itself, because Ashgrove is pushing into it | [grounded] |
| Vocabulary | The JD and values say "member", "member service" and "branches" | Say "members", not "customers". It's a small thing, but the values are written from "the member's side of the counter" | [grounded] |
| Reading of the two moves together | Fewer branches plus more digital service is a period when member complaints commonly rise and change shape | Use this as a hypothesis to test in D1, D2 and D4, never as a fact about Ashgrove | [generic] |
| Freshness | The brief dates from July 2026, about four months ago | Before the 21st, check whether anything in it has moved since. Ask the recruiter if unsure | [grounded] |

---

## Graded deliverable: the 20-minute complaint-escalation case

What the recruiter said: *"a panel of two branch managers, including a 20-minute case on a complaint escalation. The panel is also the values round — they score against the four values."*

You don't know the case in advance, so build the structure, not an answer.

**Facts you can build on.** Your own experience enters only through these sentences (F1, F4): "I handled the branch's formal complaints log and trained new tellers on our escalation script." Use them, if at all, at that scope, for example: "At my branch I handled the formal complaints log, so the first thing I'd want to see is what's been logged so far."

**A 20-minute shape** `[generic]`:

1. **Clarify (2–3 min).** What has the member been told so far, and through which channel: branch, contact centre, or both? Has it been escalated before? What rules and timelines apply to this complaint at Ashgrove? What outcome does the member want?
2. **The member right now (3 min).** What you would do today so the member isn't left waiting. This is the "Members First, Always" beat.
3. **The facts and the decision (5 min).** What you'd check, who you'd talk to, and the decision you'd make, said out loud with the reason.
4. **The supervisor (3 min).** How the branch supervisor involved learns from it. This is the JD's coaching line.
5. **The cause (3 min).** Whether this is a one-off or a pattern, and who keeps hold of the fix ("Own the Fix").
6. **Close (2 min).** What you'd tell the member, in plain words, and one line on which value each decision served.

**Theses to choose from.** Each one comes with the concession you should make before they push on it:

| Thesis | Mandatory concession | Values it scores on | Provenance |
|---|---|---|---|
| Settle it for the member first, then keep hold of the cause until it's fixed | Moving fast can skip the root cause. Also, you'd need to confirm Ashgrove's own complaint rules and timelines before committing to an outcome, so say that during clarifying | Members First, Always and Own the Fix | [grounded] |
| Treat the escalation as a coaching moment for the supervisor, not a takeover | Some escalations need you to step in directly, for example when the member is still being harmed or the supervisor is part of the complaint. Say where that line is for you | Own the Fix, plus the JD's coaching line | [grounded] |
| Close in plain words, and feed the case into the monthly numbers | One case is an anecdote. The pattern lives in the monthly volumes and resolution times, so don't over-generalise from one member | Plain Words, plus the JD's reporting line | [grounded] |

**How to stand out.** The consensus answer that most candidates give is: apologise, investigate, resolve, follow up. Give that in one breath to show the basics, then go further. Say what you'd ask first, make an actual decision, and close the loop into the supervisor's coaching and the monthly report. **The anti-pick:** don't resolve the escalation by steering an upset member to the app, or by telling them "it'll be better when we become a hub". Those are Ashgrove's plans, not this member's fix, and a panel scoring "Neighbours, Not Numbers" will notice.

**Requested close.** The panel scores against the four values, so end by naming, in one line each, which value each of your decisions served. Use the values' own names.

**Practice prompts** `[generic]`. These are invented situations for rehearsal, not predictions of the case:

- A member says the branch told them one thing and the contact centre told them another, and now wants to escalate. (This is also where F2 will press, so practise saying "I haven't worked in a contact centre" without breaking stride.)
- A long-standing member is furious about a fee and has complained twice with no reply.
- A supervisor escalates a complaint to you that you think they should have resolved themselves.

---

## Round 1: Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers, background, motivation, logistics | High. This is the standard prior for a recruiter screen, and nothing in the email suggests otherwise | Have a 90-second background arc ready (A1). Treat casual questions on JD topics like Excel as scored |
| Skeptic, light | Quick checks on the stated requirements: contact centre, regulated complaints, presenting | Medium. Recruiters often screen against the JD's listed requirements, and you have two gaps you've stated yourself (F2, F8) | Name each gap in one sentence, add one sentence of plan, and move on. The full version waits for Round 2 |

### Question bank: Conversational (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your background." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Use three beats, each one a sentence you gave: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Then close with why this role, in your own words. The pack has no sentence from you on motivation, so it gives you none. Keep it to about 90 seconds and let them choose what to dig into | F6 is the 4+ years requirement, and this is where a recruiter checks it, so it's tagged JD for the content and conversational in delivery. F1, F3 and F4 are the rest of the arc |
| A2 | "Why Ashgrove — and why a credit union?" | CO | [grounded] | Name one value by its exact name, or one point from the strategy brief, and say in your own words why it matters to you. Keep it about Ashgrove, not about leaving where you are | CO because it tests homework. The values and brief are supplied, so the raw material is real |
| A3 | "Why are you looking to move now?" | VAL | [generic] | Give one honest, forward-looking reason with no criticism of your current employer. If your reason is about wanting wider scope, the JD's "end to end across branches" line is the natural link, as something you want, not something you've done | A standard motivation check. VAL because what's scored is consistency of motive. Generic because the pack has nothing from you on it |
| A4 | "Where are you on salary expectations and notice period?" | JD | [generic] | Have a range and your notice period ready before the call. The pack has neither from you | Recruiter screens commonly close on terms. JD because it's about the job's terms. It's here so it doesn't catch you cold |
| A5 | "How are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer with the spreadsheet in your sentence's own terms: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD's Excel line makes the tool question likely. If you built it in Excel, say so and what it does, in your own words. If it's another tool, name it and stay with what it does | F9 is a listed requirement, asked casually, which is exactly when it gets undersold or oversold |

### Question bank: Skeptic, light (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. What's your contact-centre experience?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it first, plainly: "I haven't worked in a contact centre." Then give one sentence of plan, said as future, for example how you'd want to learn the way complaints arrive there in your first weeks. Stop there. Don't fill the silence | F2 is a gap you stated yourself, and it sits in the JD's first line. The short version here, the full version in B4 |
| B2 | "Tell me about your experience handling regulated complaints." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with what your sentence says: you handled the branch's formal complaints log. Answer slot: if the complaints on that log came under regulatory rules, say which rules and what handling them involved for you, in your own words. If they didn't, or you don't know which rules applied, say so plainly and stay with the log you handled. Don't swap "formal" for "regulated" unless the first branch is true | F7 is a listed requirement, and the easiest place in the pack to stretch one word into a bigger claim |
| B3 | "This role presents to senior leaders. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't presented to anyone above regional level." Then one sentence on how you'd prepare for the first one, said as a plan. Keep it calm and short | F8 is a stated gap against a listed requirement. Rehearsing the one-line version keeps it from becoming a confession |

### Reverse questions: Round 1

| Question | Why it lands |
|---|---|
| "How is the 20-minute case set up? Is anything shared beforehand, and is it a written scenario or role-played?" | It's process diligence, and the answer changes how you prepare the graded deliverable |
| "Which complaint rules does this role work under?" | It shows you know complaints are regulated without claiming expertise you haven't stated. The answer feeds B2 and the case |
| "When will the interviewers be confirmed, and could you share their names?" | It's a reasonable ask, and names turn on an interviewer read for Rounds 2 and 3 |
| "Is this a new role or a replacement?" | The answer tells you whether you'll be building the complaints process or inheriting one, and that shapes every Round 2 answer |
| "Who would sit around this role: who reports in, and who does it work with day to day?" | It clarifies the contact-centre relationship (F2) before your future manager asks about it |

---

## Round 2: Head of Member Services, 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of gaps: contact centre, senior presenting, one branch versus many | High. The hiring-manager prior is Case plus Skeptic, and F2 and F8 are gaps you stated that sit in the JD's headline duties | Rehearse B4 until it's boring. Name the limit before it's asked. Hold on your quotes, then give a plan |
| Values / Behavioural | "Tell me about a time…" stories | High. The recruiter said this round is "mostly behavioural", which lifts this persona above the usual hiring-manager prior | Pick stories using the scaffolds. Use "we" for context and "I" for your part. Where no story comes to mind, say so rather than inventing one |
| Case / Strategist | Short live problems on reporting and digital | Medium. It's a hiring-manager prior, pulled down by "mostly behavioural" | Clarify, then structure, then answer, using the brief's vocabulary |
| Data-Driven Prober | The spreadsheet and the training: how it worked and how you know | Medium. The spreadsheet is your one concrete artefact (F3), and a manager who will own the monthly report is likely to ask about it | Know what you can and can't say about what it counts. Say "I don't know" where you don't |
| Pressure | Follow-ups that press after you've answered | Low, though it may show up in B4's follow-ups | Pause, restate, hold through two follow-ups, then concede specifically |

### Question bank: Skeptic (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "You haven't worked in a contact centre, and you haven't presented above regional level. This role owns complaints across both and reports to senior leaders. Why would I take that risk?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | **This is the highest-ROI prep in the pack.** Name the limit first: "Two things in this role would be new to me. I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then hold on what your sentences carry: you handled the branch's formal complaints log, trained new tellers on the escalation script, and built the monthly complaints spreadsheet your regional manager uses. Then give the ramp, said as a plan: how you'd learn the contact centre's side of complaints, and how you'd prepare the first report for senior leaders. Follow-ups are below the table | F2 and F8 are the two gaps you stated, and both sit in the JD's headline duties, so this objection will arrive in some form. JD because it scores the stated requirements head-on |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of the two gaps you've stated, the contact centre or presenting above regional level, say it in your own sentence, and give the plan. Pick one, not both. Answer slot: if working with digital teams on self-service would be truer for you, you can name it instead: say plainly that you haven't, if you haven't, and how you'd start. If you have, that's a strength, so say what it was | F2 and F8 are real and stated. F5 is silent in your material. A real weakness with a plan beats a disguised strength |
| B6 | "Your complaints work was at one branch. How would you own the process across all of them?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Accept the premise, because it's your sentence: "At my branch I handled the formal complaints log." Then give the plan: what you'd want to learn first across branches, such as how each one logs complaints, where they hand to the contact centre, and what the monthly numbers show. Answer slot (F1): if any part of how complaints moved through your branch was yours to decide, say which part. If not, stay with the log | F1 is the JD's first responsibility, and the gap between one branch's log and an end-to-end process is where a careful manager probes |
| B7 | "How would you coach a branch supervisor who's been doing the job longer than you have?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Two things are yours to say: for the last three years you've been a branch supervisor, and you trained new tellers on the escalation script. Say out loud that tellers and supervisors are different audiences. Then give the plan: ask before telling, work on a real escalation together, agree what good looks like. Answer slot (F4): if you've helped another supervisor with an escalation, say what you did. If not, stay with the tellers | F4 is an adjacent bridge. CASE because the question is a live problem, though the Skeptic delivers it |

**B4 deep rehearsal.** Practise this ladder out loud.

1. **Opening:** the answer in the table. Say the limit first. Don't wait to be asked.
2. **Follow-up: "So what would you actually do in your first month on the contact-centre side?"** Plan only, said as future: who you'd sit with, what you'd want to see (how complaints are logged there, how they reach branches), and when you'd come back with a view. Nothing about your past.
3. **Follow-up: "Wouldn't someone from our contact centre start ahead of you?"** Concede specifically and hold the core: "On the contact centre's side, yes, they'd start ahead of me. At my branch I handled the formal complaints log and trained new tellers on our escalation script, and I'd bring that."
4. **Follow-up: "And the senior leaders? You'd be in front of them in your first few months."** "I haven't presented to anyone above regional level." Then the preparation plan. Don't soften the sentence into "not much".
5. **What not to do:** don't answer the gap by stretching the log into a process, the tellers into supervisors, or the spreadsheet into regional reporting. All three are on the prohibited list for that reason.

### Question bank: Values / Behavioural (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you had to give a member or colleague an answer they didn't want to hear." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pick a time with a clear message, a person who didn't want it, how you said it, and where the relationship ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the branch's formal complaints log you handled, or how you would handle it | The theme comes from "Plain Words" and "Members First". A standard behavioural opener for a complaints role. VAL because it scores how you behave, not what you know |
| C2 | "Tell me about a time you disagreed with how a complaint was handled." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pick a time with a named disagreement, your view and why, what you did about it, and the outcome for the member. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The theme comes from the JD's complaints ownership and "Own the Fix". It tests spine as well as tact |
| C3 | "Tell me about a time you raised a problem with someone more senior." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Pick a time with the problem, the person, how you framed it, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the monthly complaints spreadsheet your regional manager uses, or how you would raise it. Don't turn the spreadsheet into a presentation | The theme comes from the JD's senior-leader line. F8 means this is the nearest honest ground, and F3 is the nearest artefact |

### Question bank: Case / Strategist (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Say complaint resolution times have risen three months running. How would you work out why?" | CASE | [generic] | Clarify first: how resolution time is counted, and whether it's branches, the contact centre or both. Then split it: by channel, branch, complaint type, and whether volume rose too. Form two or three hypotheses, check them with the supervisors, decide on a fix, and report back. Name the weakest assumption out loud, for example that the data is logged the same way everywhere | It comes from the JD's monthly reporting line. It's a live problem that presupposes nothing about your past |
| D2 | "We're moving 40% of member service to digital channels by 2028. What does that mean for complaints, and what would you want from the digital teams?" | CO | [grounded] | Make one thesis and one concession. Thesis: complaints will follow members into the new journeys, so you'd want complaint data broken down by journey and a route for branch and contact-centre feedback into the digital teams. Concession: you haven't seen Ashgrove's complaint data, so this is a hypothesis to test. Mention the members who won't move to digital, which is where "Neighbours, Not Numbers" comes in | This is the brief's headline target, and the only place F5 gets rehearsed. CO because it scores strategic homework |

### Question bank: Data-Driven Prober (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through that monthly complaints spreadsheet. What does it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats from your sentence: you built it, it's monthly, and your regional manager uses it. Answer slot (F3): if it tracks volumes, resolution times or both, say what it counts and how, in your own words. If something in it is counted in a way you don't know, say so plainly. Your material has no figures, so the pack supplies none | F3 and F9 both rest on this one artefact, and your future manager will own the monthly report the JD describes |
| E2 | "When you trained new tellers on the escalation script, how did you know it had worked?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: the JD's coaching line makes "did it work?" likely. If you checked, say how, in your own words. If there was no check, say so plainly, say what you'd look for now, and come back to the fact that you trained new tellers on the script | F4 is the bridge to coaching. A prober tests whether it went beyond delivery |

### Reverse questions: Round 2

| Question | Why it lands |
|---|---|
| "What would you need to see in the first monthly complaints report to know this role was working?" | It asks your future manager to define success in the JD's own terms, and it tells you what to build first |
| "How do complaints move between branches and the contact centre today, and where do they get stuck?" | It goes at F2 head-on, showing you're curious about the gap rather than hiding it |
| "As the eight branches become five hubs over 2027, what do you expect to happen to complaints?" | It uses the brief's own numbers, so it shows you've read it and are thinking about the role's busiest year |
| "How far along is the self-service work with the digital teams?" | It tells you whether the JD's digital line means joining work in progress or starting it |
| "Where would you want me to lean on you in my first 90 days?" | It follows on naturally from B4 and treats the gaps as a plan you'd share |
| "Which senior leaders would see the monthly report, and how do they like to receive it?" | It's practical preparation for F8, and it shows you're thinking ahead to the presenting |

---

## Round 3: Panel of two branch managers, 60 minutes, including a 20-minute case. This is the values round

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One question per value, scored against the four values | High. The recruiter said the panel is "the values round" and scores "against the four values" | Use the values cheat sheet below. Make one decision per story, and name the value at the end |
| Case / Strategist | The 20-minute escalation case | High. The recruiter announced it | Follow the graded deliverable section: clarify, member, decide, supervisor, cause, close |
| Peer Evaluator | "What will you need from my branch?", disagreements about their supervisors | Medium. This is an inference: the JD has this role coaching branch supervisors, who presumably work for branch managers, so the panel is pricing what you'd add to their load | Frame what you'd bring them, not only what you'd need. Propose principles rather than pretending to know their process |
| Skeptic | "Why would our supervisors listen to you?" | Medium. The same inference about coaching their supervisors (F4) | Hold on what's yours, and give the plan |
| Conversational | Openers about you and your branch | Low. The opening minutes only | Keep it short. Your own words |

### Values cheat sheet

The value names and wording are quoted from what you copied from ashgrovecu.org/about/values on 12 November 2026.

| Value (official name) | Working meaning | Your mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's point of view, not the organisation's convenience | Selection scaffold: a time when what was easiest for the branch and what was right for the member differed, and you chose the member. It needs the decision, what it cost, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, F1's "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or how you'd handle it | C4 |
| Plain Words | If it needs explaining twice, the wording is at fault, not the member | Selection scaffold: a time you rewrote or re-explained something so it landed first time. It needs the before, what you changed, and how you knew it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, F4's "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or how you'd do it | C5 |
| Neighbours, Not Numbers | Each branch belongs to its town, and members aren't a metric | Selection scaffold: a time your branch's place in its town changed what you did. It needs a specific person or situation, what you did differently because of it, and why. If no such time comes to mind, say so plainly, then say how you'd keep this value alive through the move to hubs | C6, D4 |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved, with no handing off | Selection scaffold: a time you found a problem and stayed with it to the end. It needs how you found it, what you kept hold of, and how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, F1's "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or how you'd handle it | C7 |

None of your four sentences describes a specific occasion, so every value gets a scaffold rather than a story. Pick your stories before the 21st, and they become yours to tell.

### Question bank: Values / Behavioural (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C4 | "Tell us about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use the Members First scaffold above. Make one decision, name the trade-off, and give the member's outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the branch's formal complaints log you handled, or how you would decide | The value's own wording becomes the question. VAL, scored by name |
| C5 | "Tell us about a time you changed how something was explained so a member got it the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use the Plain Words scaffold. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the escalation script you trained new tellers on, or how you'd rewrite something. Don't claim you rewrote the script unless you did | "Plain Words" is scored here. F4 is the nearest material, at its own scope |
| C6 | "Tell us about a time your branch's place in its town shaped how you handled something." | VAL | [grounded] | Use the Neighbours scaffold. It needs a specific person or situation, not a slogan. If no such time comes to mind, say so plainly, then say how you'd keep this value alive as branches become hubs | "Neighbours, Not Numbers" scored in front of two branch managers, with consolidation in the background |
| C7 | "Tell us about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use the Own the Fix scaffold. Spell out the part where you kept hold of it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the branch's formal complaints log you handled, or how you'd handle it | "Own the Fix" is the value closest to the JD's "end to end" line (F1) |

### Question bank: Case / Strategist (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D3 | "Here's a complaint escalation. Take us through how you'd handle it." | CASE | [grounded] | Use the 20-minute shape and theses in the graded deliverable section. Clarify first, then the member, the decision, the supervisor, the cause, and a values close | The announced case. Grounded because the recruiter set it |
| D4 | "A long-standing member is angry their branch is becoming part of a hub and wants to complain. What do you do?" | CASE | [grounded] | Listen first, and log it as a complaint. Explain plainly what will change for them and what won't. Be honest that you can't reverse the decision, and pass their feedback back up. Don't defend the strategy at them. Concession: some members will stay unhappy, and saying so is part of Plain Words | Eight branches becoming five hubs, in front of two branch managers. It tests "Neighbours, Not Numbers" and "Plain Words" together |

### Question bank: Peer Evaluator (G)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When an escalation leaves one of our branches, what will you need from me and my supervisors?" | JD | [generic] | Give and take. What you'd bring them: a clear owner, the outcome reported back to the branch, and coaching on the next one. What you'd need: the facts, the member's own words, and what's been said so far. Offer it as a principle to agree together, since you don't know their process yet | The JD's coaching line, seen from the branch managers' side (F4). Tagged JD for content |
| G2 | "Say you and I disagreed about how one of my supervisors handled an escalation. How does that conversation go?" | CASE | [generic] | Talk to the manager privately first, and start with the facts. Keep two outcomes separate: what's right for the member, and what helps the supervisor improve. Agree what each of you will say to the supervisor. Show spine and tact together | A partnership-fit probe, posed as a live problem |

### Question bank: Skeptic (B) and Conversational (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B8 | "We both run branches. Why would our supervisors take coaching from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold on what's yours: for the last three years you've been a branch supervisor, and you trained new tellers on the escalation script. Then give the plan: earn it by working through real escalations with them rather than lecturing. Answer slot (F4): if you've helped another supervisor with an escalation, say what you did. If not, say so plainly and stay with the tellers | F4 again, from the people whose teams you'd coach |
| A6 | "Tell us about your branch. What's the town like?" | VAL | [generic] | Your own words. The pack knows nothing about your branch. Link it to "Neighbours, Not Numbers" only if it's true | A warm opener that's still scored. It sets up C6 |

### Reverse questions: Round 3

| Question | Why it lands |
|---|---|
| "When an escalation leaves your branch today, what happens to it, and what do you hear back?" | It shows the panel you'll start from their reality, and it's the seam G1 is about |
| "What would genuinely help your supervisors in my first month?" | It's the reciprocity question: asking what you'd give before what you'd take |
| "Which of the four values is hardest to live up to in a complaint?" | You're asking the people scoring the values how the values feel from their side |
| "How are members in your towns responding to the plans for hubs?" | It's "Neighbours, Not Numbers" in practice, put to the people closest to it |
| "What do your supervisors find hardest about escalations right now?" | It's the problem the JD hires you to coach on, and it tells you where to begin |

---

## Prohibited claims

This pack won't coach any of the following, and here is why. If any of these come out of your mouth in the interview, a follow-up question will find the gap.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process across branches | An inflated form of F1 | F1's quote at its own scope. Your material shows one branch's log, not a process. The slots in B6 and F1 stay inside the log |
| Has contact-centre experience | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F8 | "I haven't presented to anyone above regional level." No slot |
| Has coached supervisors on escalations | An inflated form of F4 | F4's quote at its own scope: new tellers, the escalation script. The slots in B7 and B8 stay inside the training you did |
| Has handled regulated complaints | An inflated form of F7, with "formal" widened to "regulated" | F7's quote at its own scope. The slot asks only which rules, if any, your branch's log fell under |
| Produced the region's complaints reporting, or reports on volumes and resolution times | An inflated form of F3 | F3's quote at its own scope: a spreadsheet you built that your regional manager uses. The slot asks only what it counts |
| Built Excel reports | An inflated form of F9, with "spreadsheet" widened to "Excel" | F9's quote at its own scope. The slot asks which tool |
| Any figure: complaint counts, resolution times, team size, number of tellers trained | Inflated forms of F1, F3, F4 and F6. None of your sentences carries a number | Your quotes as they stand. If you have real figures, they are yours to give, in your own words, and the pack supplies none |

---

## Sources

**Documents you provided:**
- The job description, pasted.
- Ashgrove's values, as you copied them from ashgrovecu.org/about/values on 12 November 2026. The page itself was not fetched.
- The recruiter's email describing the three rounds, pasted.
- Your summary of Ashgrove's July 2026 strategy brief. I haven't read the brief itself.
- Your background, from your message.

**Searches and fetches sent:** none.

**Dossier:** no `tuesday-dossier.md` was present, so the pack was built from your raw inputs.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | You pasted the four values, with names and wording, from the official page this morning, which fixes the values cheat sheet and the C bank |
| 2. Ashgrove Credit Union interview process | skipped | The recruiter's email sets out all three rounds, so the loop structure and persona weights follow it |
| 3. Ashgrove Credit Union strategy and recent news | skipped | The July 2026 brief is under six months old and supplies the grounding brief, D2 and D4 |
| 4. Interviewer names at Ashgrove | n/a | No names have been assigned, so there was nothing to search. The interviewer read is absent, and the upgrade menu says what names would unlock |
| 5. A representative Member Experience Lead JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned →** an interviewer read for Rounds 2 and 3, persona weights read from their public professional profiles, and a reverse question tied to each one's career path.
- **How many prep hours you have before 21 November →** a prioritised prep schedule. At the moment the pack says only that B4 comes first.
- **Your answers to the answer slots →** each becomes your own quoted sentence, and the row regenerates as a story rather than a slot. What the spreadsheet tracks and what it's built in upgrades F3, F9, E1 and A5. Whether the log fell under regulatory rules upgrades F7 and B2. Any work with digital teams upgrades F5, B5 and D2. Any time you helped another supervisor upgrades F4, B7 and B8. Whether you have presented at regional level upgrades F8.
- **One real story per value →** the four scaffolds in the values cheat sheet, and C1 to C7, become story-mapped answers you can rehearse word for word in your own voice.
- **The full strategy brief, rather than your summary →** exact vocabulary and headline figures in the grounding brief, and sharper D2 and D4.
- **From the recruiter, in one email →** how the 20-minute case is delivered and which complaint rules the role works under. Both sharpen the graded deliverable and B2.
- **Deep research, if you want it →** up to 6 more searches and 2 more fetches, adding several minutes. It covers recent Ashgrove news since July, leadership and organisational context, and candidate reports of Ashgrove's interviews. It would update the grounding brief and the CO questions.
- **A `tuesday-dossier.md` from a job-underwriting pass →** an evidence-derived highest-ROI objection and a prohibited-claims list confirmed by you rather than inferred here. This is optional, not a prerequisite.
