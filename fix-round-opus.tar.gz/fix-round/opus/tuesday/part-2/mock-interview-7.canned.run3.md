Reading done; now running quick research on Saltmarsh Games and the interviewer before building your pack.
Your prep pack is ready. One thing up front: today is Thursday, so your Friday interview is tomorrow.

**How the hour will run.** Saltmarsh's careers page says this is their "Outage Hour", a single 60-minute interview with the hiring manager. The first half is a tabletop exercise on a simulated outage during a live event. The second half is a values conversation. There's no take-home. I've assumed Tobias is the hiring manager.

**What I found on Saltmarsh and Tobias:**
- **Values:** the company publishes three: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener.
- **Strategy:** in September 2026 they announced that both titles move to a season pass, with one shared events calendar and a single live-ops group from February 2027. A season pass is paid content, so your lack of in-app purchase experience matters more than the job ad suggests.
- **Tobias:** he used to be a QA lead, and gave a GDC 2026 talk arguing a live team is judged by how often its patch notes describe what actually shipped. That theme fits the release checklist you wrote and QA still uses, which is your strongest evidence. It also means he'll probe that checklist closely.

The season-pass news and the talk come from search-result snippets; I didn't open either page.

**Most likely objection (question C1).** Expect a version of: "You ran the calendar for one title and haven't led a team — this role is two titles and four disciplines." The pack gives you a hold, a plain acknowledgment and a ramp plan for it.

**What's in it:**
- 22 questions grouped by interviewer style, starting with five outage-tabletop questions
- a table matching each job-ad requirement to your evidence
- a values cheat sheet
- six questions to ask Tobias
- a list of claims the pack won't coach, such as "led a team"

If you want, I'll play Tobias and run you through C1 live, then give feedback against the pack's own guidance. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-canned-aff9fe5b:
- saltmarsh-games_live-operations-producer_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The pack treats him as the hiring manager, because Saltmarsh's careers page says the 60-minute interview is with the hiring manager.
**Format:** Saltmarsh's "Outage Hour", one 60-minute interview: a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home. Source: saltmarshgames.com/careers/interviewing.
**When:** Friday, which is tomorrow.

---

## How to use this pack

- **Personas** describe *how* a question is asked: who's asking, and in what register.
- **Types** describe *what* is being scored:
  - **VAL**: whether your past behaviour shows Saltmarsh's published values
  - **EXP**: whether your own claims hold up under scrutiny, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: whether you know Saltmarsh's strategy and recent moves
  - **CASE**: how you structure a live problem from the role
- **Provenance labels:** `[grounded]` means it traces to your message, the JD, or a source listed under Sources. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` is a role-family pattern with no claim about Saltmarsh or about you.
- **Answer slots** are places where the pack doesn't know the fact. Each one gives you two honest branches. Fill it from memory, or say plainly that it didn't happen. Never fill it with something that sounds right.
- The guidance is scaffolding, not a script. Rehearse the beats in your own words.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material covers weekly content drops for one main title. The JD asks for live events across two titles. Keep the words at your scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events line makes a probe on events likely. If any of those drops were time-limited events, say which and what running them involved, in your own words. If none were, say so plainly and stay with the weekly drops |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | Running a calendar touches coordination but doesn't show which disciplines you worked with. Answer slot: if design, art, engineering or community had to deliver for a drop to land, say who and what you did to keep it on the calendar, in your own words. If that wasn't part of how you ran it, say so plainly and describe what running the calendar did involve. Note that the JD says coordinate, not manage. This is a reading of the JD, and it says nothing about your past |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting numbers isn't the same as owning a review. Keep the words at your scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you compiled those numbers or chose what went in, say which, in your own words. If someone else produced them, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap. It's still a claim with nothing inspected behind it, so expect a probe, especially from an interviewer who used to be a QA lead. Lead with the quote's own terms: you wrote it, and QA still uses it. A named artifact in daily use beats an adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | The material shows four years as an associate producer and two years of weekly drops. It doesn't show whether the title was live for all four. Answer slot: if the game was live-service for the whole four years, say so. If it wasn't, say which years were and stay with those. Always say "associate producer", never "producer" |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. The quote meets the requirement directly. Say it in the quote's own terms: weekly, main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap at the level of comfort. Expect a probe on how the numbers were counted (D1). Know which retention measures they were, or say plainly that you don't know how they were counted |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The checklist is a written document a team still works from. Say that in the quote's own terms: "I wrote the release checklist our QA team still uses." Add nothing to it |

---

## Reading the interviewer

Source: one search-result listing for his GDC 2026 talk. The talk itself wasn't fetched, so only what the listing states is used here.

| Item | What the source shows | Practical implication |
|---|---|---|
| Career pattern | Head of Live Operations at Saltmarsh. Previously a QA lead at a console studio | He knows release checklists from the QA side. Expect close, specific follow-ups on F4, and don't stretch it (E2, G2) |
| Published theme | Talk "Patch Notes Are a Promise". His argument is that a live team is judged by how often its patch notes describe what actually shipped | His argument matches the value "Ship the Patch Not the Promise". In the tabletop, expect "what do you tell players?" to matter as much as the fix (A3, G1) |
| Mirror opportunity, shared vocabulary | Release accuracy, meaning what's announced against what's built | You can pair his theme with F4's quote, "Wrote the release checklist our QA team still uses". Describe the checklist and let him draw the connection. He hasn't made a career jump similar to yours, so the pack offers no shared-jump angle |

---

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop: a simulated outage during a live event | Highest. Hiring-manager prior, and the careers page names the tabletop as half the hour | Clarify, then contain, then communicate, then fix, then review. Think aloud, and challenge one premise respectfully |
| Values / Behavioral | The values conversation in the second half | High. The careers page documents it, and the values page names three values | One story or an honest scaffold per value, below. Use "we" for context and "I" for contribution |
| Skeptic | Gap probes: one main title, no team leadership, no in-app purchase experience, during a season-pass move | High. Hiring-manager prior. C1 is the highest-ROI prep in this pack | Rehearse C1 until it's boring. Hold on the quotes, give the plain acknowledgments, then a ramp plan |
| Data-Driven Prober | Retention numbers and post-event KPIs | Mid. The JD owns the KPIs, and F7 is your only metric line | Know how the numbers were counted, or say you don't |
| Pressure | Time pressure inside the tabletop, plus "how much was you" | Low to mid. Outage scenarios run on a clock | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational | Opener and close | Low to mid. Every 60-minute conversation opens and closes | A 90-second arc built only from your quotes |
| Peer Evaluator | Cross-team seams: community versus engineering, QA on release day | Low. No peer round is documented, but the JD is a coordination role | Reciprocity framing: what you bring each team, not only what you need from them |

---

## Question banks

### A. Case / Strategist: the Outage Hour tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event and event rewards have stopped granting for some players. Walk me through your first fifteen minutes." | CASE | [grounded] | Structure it aloud. 1) Clarify: which title, which players or platforms, since when, and is it still happening? 2) Contain: does the event keep running, pause, or extend? Say what you'd need to know to decide. 3) Pull in the right people: engineering on-call, QA to reproduce, community for player messaging. 4) Communicate: first player-facing note says what's known, not what's hoped. 5) Set the next check-in time. The question needs no claim about your past, so the guidance makes none | This is the documented tabletop format on the careers page, so some version of it is near-certain. CASE because it scores structure under a live incident |
| A2 | "Engineering says the fix needs a client update that won't clear store review before the event ends. Now what?" | CASE | [generic] | Separate the fix from the player outcome. What can change without a client update? Can the event window or rewards be adjusted? What make-good is fair to the affected players, and how do you know who they are? Name the trade-off you're choosing and why. Tie it to "Players Before Plans": when the calendar and the players disagree, the players win | A typical tabletop escalation. `[generic]` because it's a pattern for outage scenarios, not a fact about Saltmarsh's pipeline |
| A3 | "Community wants an ETA and engineering won't commit to one. Draft the post." | JD | [grounded] | Say the post out loud in three parts: what's affected, what's being done, and when the next update comes. Give the next update time, not a fix time. Commit only to what's built, which mirrors "Ship the Patch Not the Promise". The question needs no claim about your past | Tests the JD's "clear written communication" in CASE delivery, and the theme of Tobias's GDC talk. JD primary because it scores a stated requirement |
| A4 | "Both titles will share one events calendar. How do you build it so a slip on one doesn't break the other?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Structure: shared constraints (art, engineering and QA capacity, store submission windows), collision rules, buffers, one source of truth, a regular review. Answer slot: the JD's calendar line makes a probe on slips likely. If your weekly calendar ever had to absorb a slipped drop, say what you did, in your own words. If it never did, or that wasn't yours to handle, say so plainly and stay with how you ran it | Saltmarsh announced one shared events calendar for both titles (Sources), and F1 is where the two-title scale presses. JD primary, CO secondary |
| A5 | "Post-event review: retention dipped during the event. Diagnose it." | CASE | [generic] | Check the data before the story: was tracking intact, and did an outage overlap the dip? Segment by title, platform, new versus returning players, and event participants versus non-participants. Compare against the same window before the event. Name the cause you'd test first and why. Makes no claim about your past | The JD's post-event review and KPIs line (F3, F7) live as a problem. `[generic]` because it's a diagnostic pattern |

### B. Values / Behavioral: the values conversation

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the plan said one thing and the players said another." | VAL | [grounded] | Selection scaffold for "Players Before Plans". Pick a time a scheduled drop or plan changed because of player response, with a named stake, a decision, and what happened after. If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it | The value is published, and the values round is documented. Nothing in F1 to F8 carries this story, so it's a scaffold |
| B2 | "When have you had to tell people something wasn't going to ship as announced?" | VAL | [grounded] | Selection scaffold for "Ship the Patch Not the Promise". It needs who you told, what you said, and what you did instead of overpromising. If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it | The value plus Tobias's published theme make this likely. No quote carries the story |
| B3 | "Walk me through the release checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote it, and QA still uses it. Those are the beats the quote states, so tell them in your own words. Answer slot: "Leave the Build Greener" makes a probe on improvement likely. If the checklist replaced something or changed since you wrote it, say what and why. If there was nothing before it and it hasn't changed, say so plainly and describe what it covers | Your strongest values match. Saltmarsh's value text names the checklist itself. EXP secondary, so expect follow-ups on detail |
| B4 | "Other than that checklist, when have you left a process better than you found it?" | VAL | [grounded] | Selection scaffold for "Leave the Build Greener". It needs what was there before, what you changed, and who still benefits. If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it | Every published value gets coverage, and this one may be asked twice |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You ran the calendar for your main title, and you haven't led a team. This role runs events for two titles across design, art, engineering and community. Why are you ready?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years", "Never led a team, and never worked on a game with in-app purchases" | **Highest-ROI prep in this pack.** Hold on the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Plain acknowledgment, said calmly: "I haven't led a team." Answer slot: the JD's coordinate line makes a probe on cross-discipline work likely. If design, art, engineering or community had to deliver for your drops, say who and how you kept them on the calendar. If not, say so plainly and stay with the calendar. Close with a ramp plan, said as a plan and never as a past. Follow-up 1 ("so you've never managed anyone?"): don't soften it, return to the calendar. Follow-up 2 ("two titles is double the load"): concede it's a step up, and name what you'd do first to learn both calendars | F1 and F2 are where the JD presses hardest, and the team-leadership negative is one you stated. Some form of this objection is near-certain. JD because it scores the headline requirements |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [inferred] | Pick a real one. F3, owning the post-event review, or the two-title scale in F1 are the honest candidates. Name it, then give a concrete plan for your first weeks. Don't pick a fake weakness | Standard Skeptic stem. `[inferred]` because the pick is the pack's reading of F1 and F3 |
| C3 | "Both titles are moving to a season pass. You haven't worked on a game with in-app purchases. How would you get up to speed?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, not a past: how events feed the pass, which numbers you'd learn from the existing team first, and who you'd sit with. Don't claim familiarity you don't have | The JD doesn't list IAP, but Saltmarsh's season-pass announcement (Sources) makes this probe likely. CO because it tests whether you've read the announcement |
| C4 | "Why leave a puzzle studio for this?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Answer slot: your own reasons, in your own words. If something about Saltmarsh's published values or the shared-calendar move drew you, say what. If your reasons are about the role rather than the company, say that plainly. Don't borrow motives that sound good | A motivation-consistency check from F5. The reasons aren't in the material, so they're an answer slot |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The monthly retention numbers you presented to the studio head: how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F7: you presented them, monthly, to the studio head. Answer slots, each in your own words: how they were counted, what they were sensitive to, the assumption behind them you'd defend least, and which part was yours. "I don't know exactly how they were counted" is an honest branch. Say it before he finds it | F7 is your only metric line, so a prober will go there. EXP because it tests attribution |
| D2 | "What should a post-event review here report, and who acts on it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Structure: participation, completion, retention around the event compared with a baseline, incidents, and what changes next time. The measures are a role-family pattern, so frame them as a proposal. Answer slot: if your retention presentations led to decisions, say one in your own words. If you don't know what came of them, say so plainly | Covers the JD's post-event review and KPIs (F3, F7). JD because it scores a stated responsibility |
| D3 | "How did you know whether a weekly drop worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if drops were measured, say how and by whom, in your own words. If they weren't measured, or that wasn't yours, say so plainly and describe how you ran the calendar | F6 is solid, but a prober will ask how success was judged. The quote doesn't say it was measured |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already a live-ops producer?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | Pause. Then four beats from the quotes: four years as an associate producer, two years running the weekly content-drop calendar, the release checklist QA still uses, and the monthly retention numbers to the studio head. Don't claim the title you don't have. If he pushes, hold on those four. Concede that you haven't had the producer title, not that the work doesn't count | F5 under a time box, likely inside a clock-driven hour. JD because it scores the years requirement |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: you wrote it. Answer slot: if others contributed sections or later edits, say which parts were theirs. If it was yours alone, say so plainly. Hold through two follow-ups by returning to what you wrote, and concede only specifics that are true | F4 is your strongest line, and Tobias is a former QA lead, so attribution is where he's most likely to press |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | 90 seconds, built only from the quotes: the studio and the associate producer role, the calendar, the checklist, the retention numbers. End on why this role, using your C4 answer. Don't add anything | The biography opener is near-universal. It's scored for economy |
| F2 | "Did anything stand out in our recent announcements?" | CO | [grounded] | Saltmarsh has announced a move of its two titles to a season pass, with one shared events calendar and one live-ops group. Say it in your own words, then ask one real question about it (see the reverse questions). Don't fake depth on the season pass, which C3 covers | A casual-register CO probe. Research found the announcement (Sources) |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community wants to announce the next event's dates and engineering won't confirm. You're in the middle. What do you do?" | CASE | [grounded] | Find out what engineering can commit to and by when. Agree with community what can honestly be said now. Set a date for the decision, not the event. Reciprocity: what each side gets from you. "Ship the Patch Not the Promise" is the tiebreak. Makes no claim about your past | Covers the JD's coordination line (F2) through a seam scenario, plus the published value |
| G2 | "What would QA need from you on release day?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Lead with F4's quote. Answer slot: if your checklist set out what producers owe QA on release day, say what it asked for. If it didn't cover that, say so plainly and say what you'd want to agree with QA here | Covers the JD's "manage the release checklist with QA", with a former QA lead listening |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | C1, A4, E1 |
| Coordinate design, art, engineering and community (F2) | C1, G1, A1 |
| Own the post-event review and its KPIs (F3) | D2, A5 |
| Manage the release checklist with QA (F4) | G2, B3, E2 |
| 3+ years producing live-service games or apps (F5) | E1, F1, C4 |
| Experience running a content calendar (F6) | A4, D3 |
| Comfortable with player-retention metrics (F7) | D1, D2, A5 |
| Clear written communication (F8) | A3, B3 |

---

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries this, so it's a selection scaffold. Pick a time a planned drop changed because of players. If none comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it (B1) |
| Ship the Patch Not the Promise | Announce what's built, not what's hoped | No quoted sentence carries this, so it's a selection scaffold. Pick a time you said something wasn't ready. If none comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it (B2) |
| Leave the Build Greener | Every release leaves the code and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses" (B3) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How do you measure that on your team?" | It's tied to his own published work, and it shows you researched him. It also tells you how you'd be judged |
| R2 | "With both titles moving to one shared calendar and a single live-ops group, does this role run both titles' events, or part of a shared calendar?" | The JD says two titles and the announcement says one group. You need to know which job you're taking |
| R3 | "What did the last post-event review change?" | Shows you see the review as a decision tool. Tells you whether reviews get acted on |
| R4 | "Where does the release checklist break down today?" | Plays to your strongest evidence, and it's an invitation to Leave the Build Greener |
| R5 | "What does success look like for this role at the end of the first season pass?" | Puts a clear goal on a role that's changing |
| R6 | "You moved from QA lead to running live ops. What did QA teach you that you still use?" | Ties to his career path and turns the conversation into a peer exchange |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated: "Never led a team, and never worked on a game with in-app purchases" | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases or a season pass | A negative you stated: "Never led a team, and never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar, or calendars for multiple titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material says weekly content drops for the main title. A4's slot stays inside that calendar |
| Owned post-event reviews or retention KPIs | Inflated form of F3 | F3's quote at its own scope. The pack's observation: the material says you presented them. D1 and D2's slots ask only about those numbers |
| Managed or led QA | Inflated form of F4 | F4's quote: you wrote the checklist QA uses. Nothing more |
| Four years as a producer | Inflated form of F5 | "4 years as an associate producer". Keep the title |

---

## Sources

Provided: your message (background and JD text).

| Call | Query or URL | What came back |
|---|---|---|
| Search | Saltmarsh Games values | saltmarshgames.com/values |
| Fetch | saltmarshgames.com/values | The three values and their definitions, as used in the cheat sheet |
| Search | Saltmarsh Games interview process producer | saltmarshgames.com/careers/interviewing |
| Fetch | saltmarshgames.com/careers/interviewing | The loop: recruiter call, then the 60-minute Outage Hour with the hiring manager (tabletop, then values conversation), no take-home |
| Search | Saltmarsh Games mobile studio news | saltmarshgames.com/news/project-larkspur, from search-result text only, not fetched: September 2026, Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, and a single live-ops group replaces per-title event teams |
| Search | Tobias Wrenfield Saltmarsh Games | talks.gdconf.example/2026/patch-notes-are-a-promise, from search-result text only, not fetched: GDC 2026 talk, Head of Live Operations, previously a QA lead at a console studio |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and bank B: three values by name |
| 2. Saltmarsh Games interview process | yes | Loop established: one session with the hiring manager, tabletop plus values. Case and Values weighted top. Values round detected |
| 3. Saltmarsh Games strategy / recent news | yes | The season-pass and shared-calendar announcement: A4, C3, F2, R2 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Reading the interviewer, R1, R6, the emphasis on E2 and G2 |
| 5. Representative role JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- How many hours you have before Friday → a prioritised prep schedule tied to question IDs
- Your answers to the answer slots in C1, D1 and F5 (which disciplines your drops depended on, how the retention numbers were counted, which years the game was live) → F2, F5 and F7 rows grounded, and stronger holds in C1, D1 and E1
- A redacted copy of the release checklist you wrote → F4 and F8 raised toward `high`. It's the one artifact a producer can show, and it's worth having ready
- Confirmation that Tobias is the hiring manager, or anything from your recruiter call → persona weights checked, and any stated focus areas covered
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): read the full Larkspur announcement and Tobias's talk → a grounding brief, sharper CO questions, and his recurring themes as likely questions
- A tuesday-dossier.md from an underwriting session → an evidence-derived highest-ROI objection and a prohibited-claims list confirmed with you, instead of built here
