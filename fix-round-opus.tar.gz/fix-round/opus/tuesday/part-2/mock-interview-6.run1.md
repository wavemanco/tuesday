Reading done; now running the default research pass on Larkfield Systems before writing your three-round pack.
I've written one prep pack covering all three rounds, saved as `Larkfield-Systems_engineering-manager_interview_pack.md`. I built it only from your message and the role text. Web search wasn't allowed in this session, so I couldn't look up anything about Larkfield itself, and the company-specific parts are generic.

**How it's organised:**
- **Shared fit section:** each line of the role matched against what you told me, with the gaps marked. The clear match is hiring. The gaps you named yourself are hardware roadmaps and managing managers. Your material doesn't yet show anything on growing engineers, partnering with product, or device experience.
- **Tuesday (Director):** 11 questions. They lean on probing your gaps and on live problems from their team.
- **Thursday (panel):** 12 questions. They lean on how you'd work with the staff engineers and the PM, plus deep probing of your reliability and hiring stories.
- **Monday (VP):** 8 questions. They lean on leadership philosophy and values, with one pointed challenge.
- **Most important question to rehearse:** "Two squads and eleven engineers, and you've led a team of six." It comes up in all three rounds, as A1, H1 and L1. Concede the gap first, then give two things you've done in your own words, then your plan. Your answer needs to match across all three rounds.
- **Claims to avoid:** the pack lists claims it won't coach, such as turning "about 40 interviews" into hires, or "pushed a reliability quarter through" into doing the engineering yourself.

**Gap:** without Larkfield's published values, there's no values cheat sheet for Monday.

Say the word and I'll play the Director on A1, with real follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep found, for you to carry into later sessions. If you'd like the pack as a Word document, I'll convert it.

1. Can you paste the full job posting and your CV? The pack works without them, but they'd fill in the gaps on growing engineers, partnering with product, and device experience, or confirm them.
2. My web searches were blocked by permissions. If you allow web search, should I run the standard research (Larkfield's values, interview process, recent news)? That would add a values cheat sheet for Monday.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop. Three scheduled rounds share one fit snapshot. Each round has its own persona weights, question bank and reverse questions.

| Round | When | Who | Length |
|---|---|---|---|
| 1 | Tuesday | Hiring manager: Director of Engineering, your would-be boss | 45 min |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min |
| 3 | The following Monday | VP Engineering: "values and leadership philosophy" (recruiter's words) | 30 min |

Interviewer names weren't given, so this pack has no "reading the interviewer" section. The web searches for company research were refused in this session (see Sources), so everything about Larkfield beyond your message is labelled `[generic]`.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: the style, the pressure, the follow-ups. **Types** describe *what* is being scored. Rehearse both. The same objection will come back in each round in a different tone.
- **Type key:**
  - **VAL**: values and behaviour. Does what you've done show the values they care about?
  - **EXP**: experience deep-dive. Does your account hold up, and what was actually yours?
  - **JD**: role-driven. Can you do the job as described, gaps included?
  - **CO**: company and strategy. How much homework have you done, and can you think at the company's level?
  - **CASE**: a live problem set in this role, worked through out loud.
- **Provenance labels:** `[grounded]` means it traces to your message or the role text. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a pattern for this kind of role, with no claim about Larkfield.
- **Answer slots.** In the guidance, an answer slot marks a place where your material doesn't say what happened. It gives two honest branches. Answer from what really happened, or say plainly it wasn't so.
- Treat the guidance as scaffolding, not a script. Say it in your own words.
- **Highest-ROI prep in the whole pack: A1.** "Two squads and eleven engineers, and you've led a team of six." It will come up in all three rounds in some form, and A1, H1 and L1 rehearse it at three pressure levels. Your answer has to match across all three.

---

## Shared fit snapshot

All requirements are quoted from the role text you pasted. All evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material shows one team of six over three years, not two squads, and the words stay at that scope: "For three years I've led a team of six." Answer slot: the two-squad line makes a probe on running more than one team likely. If you have ever split people, priorities or work across more than one team or workstream, say what and how, in your own words. If not, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" — role text (delivery) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | discovery | The quote shows a priority call you pushed through. It doesn't show how delivery was owned day to day. Its own words: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the delivery line makes a probe on how you plan and track delivery likely. If that was yours, say how you ran it, in your own words. If someone else set it, or there was no such process, say so plainly and return to the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" — role text (hiring) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap. It's a self-report with nothing inspected behind it, though, so expect a probe. Lead with the loop in the quote's own terms: you run the hiring loop for backend roles, about 40 interviews last year. The number counts interviews, so keep it attached to interviews |
| F4 | "own delivery, hiring and growth for 11 engineers" — role text (growth) | none given | none | [grounded] | discovery | Strong evidence here usually names an engineer (anonymised is fine), what they were working toward, what you did, and what changed. Answer slot: the growth line makes this a near-certain probe. If, as a lead, you have helped an engineer on your team grow, say what you did and what changed, in your own words. If no such case comes to mind, say so plainly and say how you would approach growth for eleven people |
| F5 | "partner with hardware and product on roadmap" — role text (product) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | Pushing a quarter through against roadmap pressure is not the same as partnering on a roadmap, so don't stretch the bridge. Answer slot: if a product partner was part of that decision, say how the conversation went and what was agreed, in your own words. If not, say so plainly and say how you would run that conversation here |
| F6 | "partner with hardware and product on roadmap" — role text (hardware) | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | You've stated this gap, and no wording closes it. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Your sentence is about *owning* such a roadmap. Answer slot: if you have ever worked alongside a hardware team in any form, say what it was. If not, say so plainly |
| F7 | "building device-management services" — role text, at an "industrial IoT" company | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Your material shows payments, and it doesn't show whether any of your work touched device management or connected hardware. Answer slot: if any of it did, say what, in your own words. If none did, say so plainly and say what you would learn first |
| F8 | Leading through squad or tech leads, common in two-squad manager roles (role-family pattern, not in the role text) | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | You've stated this gap. Words: "I haven't managed managers." The role text doesn't say whether the squads have leads, so ask (reverse question R1-2) before you assume the gap matters here. Then the plan, said as a plan |

**Requirement coverage**

| Requirement | Questions |
|---|---|
| F1: lead two squads | A1, H1, L1 |
| F2: own delivery | B1, B3, D2 |
| F3: own hiring | B4, C2, E2, D4 |
| F4: own growth | A5, J3 |
| F5: partner with product | B2, D3, L2 |
| F6: partner with hardware | A2, B3 |
| F7: device management / industrial IoT | A3, E3, H1 |
| F8: leading through leads | A1 (follow-up 2), L1 |
| Headline figure: 60% on-call drop | C1, H2, E1 |
| Headline figure: about 40 interviews | C2 |

---

## Round 1: Tuesday, hiring manager (45 min)

**What this round is:** your would-be boss, deciding whether you can run this team and how risky the gaps are. In 45 minutes, expect 7–9 questions to actually get asked.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scope jump (F1), the hardware gap (F6) and "why leave payments" | High. A hiring manager is paying to reduce risk on gaps, and F1, F6 and F8 are the visible ones | Rehearse A1 until it's boring. Concede the gap before you're pushed, then give the plan. Calm candour beats bluffing a skill your boss has |
| Case / Strategist | Live problems from their own world: inheriting the squads, hardware–product conflicts | High. The usual starting weight for a hiring manager. They test how you'd run *their* team | Clarify, state the objective, structure, approach, metrics, risks. Think out loud. Ask what they'd need to know |
| Data-Driven Prober | "How was the 60% counted?" | Medium. Two figures in your story attract a probe from anyone who listens closely | Know what you can and can't say about each figure. "I don't know how it was counted" is an honest answer |

### Question bank, Skeptic (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role is two squads and eleven engineers. You've led a team of six. Why are you ready for that jump?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | **Highest-ROI rehearsal in the pack.** Name the limit before they do: "For three years I've led a team of six. This would be two squads and eleven people, so it's a step up." Then give two things you did, in their own words: you run the hiring loop for backend roles, about 40 interviews last year, and you pushed a reliability quarter through against roadmap pressure, after which your team's on-call burden dropped 60%. Let the interviewer draw the inference. Don't say what these prove. Then give the plan: what you'd do first with two squads, as a plan. Answer slot (F1): if you have ever split work or priorities across more than one team or workstream, say what and how. If not, say so plainly. **Follow-up 1**, "what changes at eleven?": give your view of what changes, framed as a view, not a past. **Follow-up 2**, "have you managed managers?": "I haven't managed managers," then ask whether these squads have leads. **Follow-up 3**, "so why take the risk?": go back to the same two quotes, without adding to them, and to the plan | F1 and F8 are the largest visible gaps, and a hiring manager is paying to reduce risk on exactly that. JD because it scores the role's scope directly. It's deepest because it comes back as H1 and L1 |
| A2 | "Partnering with hardware is a big part of this job. What's your experience there?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Plain acknowledgment first: "I haven't owned a hardware-adjacent roadmap." Answer slot (F6): if you have worked alongside a hardware team in any form, say what it was, in your own words. If not, say so plainly. Then the ramp plan, as questions you would ask the hardware lead in your first weeks: how their release cycle works, where it meets these services, and what has gone wrong before. Don't guess Larkfield's answers | F6 is a gap you stated, and the role text names hardware partnering directly. JD because it scores a listed responsibility |
| A3 | "Why move from payments to industrial IoT, and why now?" | CO | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your real reason, in two or three sentences. Only you know it, so the pack doesn't supply one. The only fact the pack holds is that you're at a payments company. Don't make claims about the IoT market or Larkfield's position that you can't source. If you want a company-specific line, it needs research this pack doesn't have (see the upgrade menu). Keep this answer the same for K2-style asides on Monday | F7 makes "why the domain change" predictable. CO because it tests homework and motivation at company level. Labelled `[grounded]` only for the one fact used |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pick a real one. The hardware roadmap is the cleanest: "I haven't owned a hardware-adjacent roadmap." Then one sentence on how you'd close it. Don't offer a disguised strength. Don't name a second weakness unless asked | A Skeptic stem. F6 gives it a true answer, and a true answer here reads as self-awareness |
| A5 | "How do you grow engineers? Give me an example." | JD | [grounded] | Selection scaffold (F4): pick a time you helped one engineer on your team grow. It needs a starting point, something you did, and something that changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle growth for eleven people. Don't describe a growth programme you didn't run | F4 has no evidence yet, and growth is one of the three things the role says you own. JD because it scores a listed responsibility |

### Question bank, Case / Strategist (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit two squads. One is shipping features, the other is buried in incidents. What do you do in the first 30 days?" | CASE | [generic] | Clarify first: what "buried" means in numbers, who is on call, what's been promised and to whom. Objective: stabilise without stopping delivery. Approach: listen and look at the data in weeks one and two, agree on one or two bets with your manager and product, then commit and communicate. Metrics: incident count, on-call load, delivery against commitments. Risks: burning out the incident squad, losing product's trust. The question needs no claim about your past, so the guidance makes none | Tests the delivery ownership in F2 as a live decision. `[generic]` because the scenario is a pattern, not a fact about Larkfield |
| B2 | "Tell me about a time you protected engineering work against roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2: there was roadmap pressure, you pushed a reliability quarter through, and on-call burden dropped 60% afterwards. Tell those beats in your own words. Answer slot: the role's roadmap-partnering line makes a probe on who you had to convince likely. If you can say who it was and how you got agreement, say it in your own words. If there was no such negotiation, say so plainly and stay with what happened | This is your strongest story, and it touches F2 and F5. EXP because the follow-ups will test which parts were yours |
| B3 | "Hardware wants to slip a release six weeks. Product wants the device-management feature that depends on it on the original date. What do you do?" | CASE | [generic] | Clarify: is the dependency hard or soft, what's driving the date, and can part of it ship without the hardware change? Get hardware and product into one conversation rather than relaying between them. Lay out two or three options with their costs. Recommend one, and say who decides. The question needs no claim about your past, so the guidance makes none | F6 is the gap, so a live hardware–product conflict is the fairest test the Director can set. CASE because it's scored on structure |
| B4 | "Next year you'd be backfilling and growing these squads. How would you plan the hiring?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Structure: what roles and levels the roadmap needs, sequencing, the loop, and the interviewer pool. What you bring, in its own words: you run the hiring loop for backend roles, about 40 interviews last year. Answer slot: if you have changed how that loop is designed, say what and why. If the design was set by others, say so plainly and describe how you run it. Never turn interviews into hires | F3 is your clearest match, so let it work in a forward-looking case. CASE primary, JD content |

### Question bank, Data-Driven Prober (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "That 60% drop in on-call burden: how was it counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four things, each in your own words: how the figure was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours. Name that weakest assumption before they do. If you don't know how it was counted, say so plainly. The pack doesn't supply a baseline or a method | Defend-the-number rule: this is your headline figure. EXP because it tests attribution |
| C2 | "About 40 interviews last year: what does that number include?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say what the 40 counts, in your own words: interviews you conducted, or interviews the loop ran. Say which part was yours. Keep it attached to interviews, never hires. If you're not sure of the exact count, "about 40" is already your honest wording | Second headline figure. A prober will ask what's behind it. EXP for attribution |

### Reverse questions, Tuesday

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What would success look like for this role at six months and at twelve?" | Gives you their scorecard for the next two rounds |
| R1-2 | "Do the two squads have tech leads or squad leads today, and would this role manage through them?" | Tells you whether F8 matters here, and shows you're thinking about the team's structure |
| R1-3 | "How is the roadmap set between hardware, product and these squads today, and where does it break?" | Goes straight at F6, from curiosity rather than defensiveness |
| R1-4 | "What's the biggest delivery risk these squads carry right now?" | Shows you'd start by reducing risk. The answer is good material for the panel |
| R1-5 | "How do you like your managers to bring you bad news?" | Your would-be boss. It shows you're already thinking about the working relationship |
| R1-6 | "A year from now, what would make you say this hire didn't work?" | Brings their unspoken objection into the open while you can still answer it |

---

## Round 2: Thursday, panel (60 min)

**What this round is:** two staff engineers and a product manager, each judging whether you'd make their work easier or harder. The objections from Tuesday come back in friendlier packaging. In 60 minutes, expect 10–12 questions to actually get asked.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Where your calls end and theirs begin; "what do you need from us"; product–engineering conflict | High. All three members are partners you'd work with, not reports or bosses. A panel blends each member's top personas, and this one is shared by all three | Offer reciprocity: what you'd bring them, not just what you'd need. Propose principles for the boundary rather than pretending to know it |
| Data-Driven Prober | Staff engineers going two levels deep on the reliability quarter and the hiring loop | High. Technical peers test depth, and your two figures are the obvious targets | Know what you can and can't say. Be exact about what was yours |
| Values / Behavioral | The PM asking about disagreements and hard truths | Medium. A cross-functional member brings this register | Stories where the hard truth actually got through. Where your material shows no ending, say so |
| Pressure | One panellist pushing on attribution or the domain switch | Low to medium. Panels often have one sharper voice | Pause, restate, hold through two follow-ups, then concede only what's real |

### Question bank, Peer Evaluator (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "As our EM, where's the line between your calls and the staff engineers' calls on technical direction?" | JD | [generic] | Propose a principle rather than claim to know their line. For example: staff engineers own technical direction; you own priorities, people and delivery trade-offs; anything that crosses both gets discussed in the open. Then ask how it works today. The question needs no claim about your past, so the guidance makes none | The staff engineers' first question about any new EM. JD because it scores how you'd lead the squads |
| D2 | (PM) "We disagree about what goes into next quarter. Walk me through how you'd work it with me." | CASE | [generic] | Clarify what each side is optimising for. Put both sets of costs on the table. Look for a split or a sequence that works. Agree who makes the final call and how it's communicated. Close with how you'd keep the trade-off visible afterwards. No claim about your past | F2 and F5 as a live scenario. CASE delivery, JD content |
| D3 | (PM) "Tell me about a time you and a product partner disagreed about the roadmap." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | If this story fits, map it on F5: roadmap pressure, and the reliability quarter you pushed through. Answer slot: if a product partner was on the other side of that pressure, say how the disagreement went and what was agreed, in your own words. If not, say so plainly, and either pick another time or say how you'd handle it | F5 is a discovery row, and a PM on the panel makes this the likeliest place it gets tested. EXP because it tests what happened |
| D4 | "What would you need from us in your first quarter, and what would we get from you?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Reciprocity first. One thing you'd bring, in the quote's terms: you run a hiring loop for backend roles, about 40 interviews last year, so hiring is somewhere you could take load off them. One thing you'd need: their read on where the services hurt. Don't promise outcomes for their systems | Peer stem. F3 gives you real value to offer |
| D5 | "How do you handle credit when work spans teams?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Use your own story as the demonstration. The quote says *you* pushed the quarter through and *your team's* on-call burden dropped. Say exactly that: "I pushed for the quarter; the team did the work," but only if that matches what happened. Answer slot: if you can name who did what, do it. If you're unsure, say so plainly | A Peer stem. How you talk about your own story is the evidence they score |

### Question bank, Data-Driven Prober (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "On the reliability quarter: what actually changed technically, and which of those calls were yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: say what changed technically, in your own words. If the technical choices were the engineers', say so plainly and name your part as the quote has it: you pushed the quarter through against roadmap pressure. Don't describe technical work you didn't do or decide | Staff engineers will check whether the story has technical depth behind it. EXP for attribution |
| E2 | "Walk us through your hiring loop. What signal does each stage get, and how do you know it works?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Describe the loop you run, stage by stage, in your own words. Answer slot: if you designed or calibrated stages, say which ones and why. If the loop was set by others, say so plainly. If you have ever checked whether it works, say how. If not, say so plainly and say what you would check | F3 is your strongest row. Staff engineers who interview will probe it as fellow practitioners |
| E3 | "A bad over-the-air update bricks a slice of devices in the field. You're the EM for the device-management service. What do you do in the first hour, and in the first week?" | CASE | [generic] | First hour: stop the rollout, establish scope, name an incident lead, communicate early to hardware, product and support. First week: recovery path for the affected devices, a blameless review, and the fix to the release process, owned and dated. Ask what tools exist for rollback before assuming any. No claim about your past | F7 is a discovery row, so a domain incident is the fair test. `[generic]` because it's a pattern, not Larkfield's setup |

### Question bank, Values / Behavioral (G)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | (PM) "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Possibly the reliability quarter: you pushed it through against roadmap pressure. Answer slot: if leadership was the source of that pressure, say what you told them and how it landed, in your own words. If it wasn't, say so plainly and pick another time. If none comes to mind, say how you would handle it | A Values stem. Your one story with tension in it may fit, but only if leadership was the audience |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer impact, a metric you let slip, and a reason you could defend. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A Values stem. Nothing in your material carries this yet, so the honest branch matters |

### Question bank, Pressure (H)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate who already knows our devices?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, then three beats, each in its quote's words: three years leading a team of six; you run the hiring loop for backend roles, about 40 interviews last year; you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60%. On device knowledge, answer slot (F7): if any of your work touched devices or connected hardware, say what. If none did, say so plainly and say what you'd learn first. Keep it consistent with A1 | A1 in a sharper tone. JD because it scores fit to the role |
| H2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold what the quote says: you pushed the quarter through, and the burden dropped afterwards. Concede specifically: the work was the team's, if it was. Answer slot: name your part and theirs, in your own words. If you're unsure how much of the drop came from the quarter, say so. Hold through two follow-ups and don't fold on the part that was yours | A Pressure stem on your headline figure. Tests hold-then-concede |

### Reverse questions, Thursday

| # | Question | Why it lands |
|---|---|---|
| R2-1 | (to the staff engineers) "What could a new EM do in the first month that would genuinely help your work?" | A reciprocity question. It turns the evaluation into a working conversation |
| R2-2 | (to the PM) "Where does the product–engineering handoff hurt most today?" | Gives the PM a reason to picture working with you |
| R2-3 | "When a staff engineer and the EM disagree, how does it usually get resolved here?" | Tests the D1 boundary against how things actually work |
| R2-4 | "What does on-call look like for these services today?" | Real interest, given your reliability story. Ask it. Don't promise a number |
| R2-5 | "How much notice do these services get when hardware changes?" | Closes part of F6 with the people who live it |

---

## Round 3: Monday, VP Engineering (30 min)

**What this round is:** the recruiter calls it "values and leadership philosophy". Thirty minutes is short, so expect 5–6 questions to actually get asked. Keep each answer under two minutes.

A values-style round is detected here because of the recruiter's description. Larkfield's published values aren't in hand (the search was refused), so the values cheat sheet is dropped. See the upgrade menu.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Philosophy questions and behavioural stories | High. The recruiter named this round's focus | Two or three beliefs, each tied to something you actually did. "We" for context, "I" for your part |
| Conversational | "Walk me through the journey." Chatty, but still scored | Medium. A short executive slot often opens this way | A pre-built 90-second arc. Treat every casual question as scored |
| Pressure | One pointed challenge on the scope jump | Medium. Executives test composure with time-boxed answers | Same answer as A1, shorter. Hold, then concede what's real |

### Question bank, Values / Behavioral (J)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "In two minutes, what's your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles — about 40 interviews last year" | Two or three beliefs that you actually hold. The pack doesn't supply them. Tie each one to a fact, in its quote's words: you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after it; you run the hiring loop for backend roles. Say the belief, then the fact, and stop. Don't claim the fact proves the belief | The recruiter's words name exactly this. VAL because it scores philosophy against behaviour |
| J2 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Possibly the reliability quarter. Answer slot: if the roadmap pressure came from someone senior, say who (their role, not their name), what you held, and how the relationship ended up, in your own words. If it didn't come from someone senior, say so plainly and pick another time, or say how you would handle it | Your one story with tension in it. The answer slot keeps you from implying a senior conflict you haven't described |
| J3 | "How do you balance growing people against delivering this quarter?" | VAL | [grounded] | A view, not a story: how you'd decide, and what you'd protect. If you give an example, it comes from F4's answer slot. If F4 has none, give the view alone | F4 is empty, and growth is a stated responsibility. A VP on a philosophy brief will want to hear your view on it |
| J4 | "Tell me about a decision you made as a lead that you'd make differently now." | VAL | [grounded] | Selection scaffold: a real decision, what you'd change, and what you learned. It needs a specific choice, not a trait. If no such decision comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A leadership-philosophy round tests whether you reflect on your own decisions |

### Question bank, Conversational (K)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc, each beat in its quote's words: nine years in engineering, the last three as lead of a team of six, at a payments company now; you run the hiring loop for backend roles; you pushed through a reliability quarter. End on why this role, using A3's answer | A Conversational stem, and probably the opener. EXP because it sets up what follows |
| K2 | "What would the engineers on your team say about you as a lead?" | VAL | [grounded] | Only what they've actually said to you. If you've had feedback, paraphrase it honestly. If you haven't had direct feedback, say so plainly and say what you'd hope they'd say, framed as a hope | The recruiter's "leadership philosophy" brief. Asked casually, scored seriously |

### Question bank, Pressure (L)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "You've never managed managers. Why should I bet a two-squad org on you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pause. Concede first: "I haven't managed managers." Then the scope: "For three years I've led a team of six." Then A1's plan, shortened to 30 seconds. Hold through two follow-ups by going back to those two facts and the plan. Don't add to them | The negative comes from your own sentence, so a VP can say it this bluntly. Same core as A1. Your three rounds must match |
| L2 | "You pushed reliability against the roadmap. Isn't that just engineering overriding product?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold: say why you pushed it, in your own words. Answer slot (F5): if product was part of the decision, say how it was agreed. If it wasn't, say so plainly and say what you'd do differently in a partnership model. Don't claim an agreement you haven't described | The obvious executive challenge to your best story. Tests hold-then-concede |

### Reverse questions, Monday

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What do your best engineering managers here do that others don't?" | Asks for their values in practice. Most useful since you don't have the published values page |
| R3-2 | "What's a recent leadership decision you'd want a new EM to understand?" | Executive-level context |
| R3-3 | "How do you think about EMs who come from a different domain?" | Raises F7 on your terms, at the right level |
| R3-4 | "Where do you see device management going for Larkfield over the next couple of years?" | Invites their strategy, which this pack couldn't research |
| R3-5 | "What does growth look like for an EM here? Is managing managers part of that path?" | Honest about F8, and shows ambition without overclaiming |

---

## Prohibited claims

These are the claims this pack won't coach, and why. They apply to every round.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers, or led through leads | A negative you stated (F8) | "I haven't managed managers." |
| Has owned or run a hardware or IoT roadmap | A negative you stated (F6) | "I haven't owned a hardware-adjacent roadmap." |
| Has led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope: three years as lead of a team of six. The limit is the pack's observation: the material says one team of six, not two squads |
| Hired about 40 engineers, or ran hiring for the whole org | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop for backend roles, about 40 interviews last year. The figure counts interviews |
| Personally cut on-call by 60%, or did the reliability engineering | Inflated form of F2 | F2's quote at its own scope: on-call burden dropped 60% after you pushed a reliability quarter through. What was yours beyond pushing it is the slot in E1 and H2 |
| Owned the team's roadmap, or partnered with product on it | Inflated form of F2 and F5 | The quote at its own scope: you pushed a reliability quarter through against roadmap pressure. The partnering is the slot in D3 and L2 |

---

## Sources

- **Provided:** your message (role text, the three rounds, the recruiter's description of Monday, your background).
- **Loop:** the loop is established by your own description of the three rounds: who runs each one and how long. Persona weights follow those rounds, not an archetype.
- **Searches sent:**
  - `Larkfield Systems industrial IoT values`: refused (permission not granted)
  - `Larkfield Systems interview process engineering manager`: refused (permission not granted)
  - `Larkfield Systems industrial IoT news 2026`: refused (permission not granted)
- **Fetches sent:** none.
- No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Refused. Would have supplied the values cheat sheet for Monday and value-mapped VAL questions |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Refused. Would have checked the panel's and VP round's documented format; your description already establishes the loop |
| 3. Larkfield strategy / recent news | unavailable | Refused. Would have grounded the CO and CASE questions (A3, B3, E3, R3-4) in current priorities instead of `[generic]` |
| 4. Interviewer names at Larkfield | n/a | No names were given. The interviewer read is absent |
| 5. Representative EM JD | skipped | The role text you pasted fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full job posting text:** requirements beyond the one-line summary become fit-snapshot rows, each with a JD-tagged question.
- **Your CV:** more evidence cells than the four sentences in your message. F4, F5 and F7 may move out of `discovery`.
- **Web search allowed (L1):** Larkfield's published values, which restores a values cheat sheet for Monday with each value mapped to a story. Also a check of the loop and current news, so A3, B3, E3 and R3-4 stop being `[generic]`.
- **Deep research (L2):** up to 6 more searches and 2 more fetches, several more minutes. Adds a strategy brief and recent org context for the VP round. Run only if you want it.
- **Interviewer names:** a reading-the-interviewer section per round, persona weights from their public footprint, and a reverse question tied to each person's career path.
- **Recruiter's notes on the panel:** coverage areas, and a build section if any exercise or presentation is expected.
- **Your answers to the slots on F4 (growth), F5 (product partnering) and F7 (device experience):** those rows, and A5, D3, J3, H1 and L2, become story-mapped instead of scaffolds.
- **Prep time you have each day:** a prioritised schedule for the two weeks.
- **A `tuesday-dossier.md` from an underwriting pass:** verified evidence and a named top objection, used instead of the ones this pack inferred. Not needed for this pack.
