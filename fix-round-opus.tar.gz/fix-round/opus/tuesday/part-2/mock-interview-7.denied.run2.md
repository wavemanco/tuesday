Quick update: I've read the prep playbook and I'm now running a few targeted searches on Saltmarsh Games and Tobias Wrenfield before I build your pack.
I've written your prep pack and saved it as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-denied-901c1546/saltmarsh-games_live-operations-producer_interview_pack.md`. I assumed Tobias is your hiring manager, since that's likely for a Head of Live Ops but you didn't say so.

**Research didn't run.** All four web searches were blocked because search permission wasn't granted. So the pack doesn't know Saltmarsh's two games, its values or anything public about Tobias. Before Friday, find out which two games the role covers, play them, and note one live event in each. That's item 2 of tonight's prep plan.

**What's in it:**
- **Prep plan for tonight and Friday morning.**
- **Your background matched against each JD requirement.** Your strongest matches are running the content calendar, writing the release checklist and presenting the retention numbers. The thinner spots are planning for two games instead of one, coordinating design, art, engineering and community, and owning the post-event review.
- **23 practice questions with answer guidance**, all built only from what you told me. For the gaps, the pack doesn't invent experience. It gives you honest wording for either answer, so you have words whether or not you did the thing.
- **Six questions to ask Tobias.**
- **A list of claims not to make,** such as having led a team or worked on in-app purchases.

**The one to rehearse most is B1:** "What have you done that shows you can coordinate design, art, engineering and community?" Expect the follow-up "Have you led a team?" The honest answer is "I haven't led a team." The role as written asks you to coordinate teams, not manage people, so don't let the two get merged.

If you'd like to practise, I can play Tobias on B1 and push back with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Will Tobias be your manager if you get the role, and did the recruiter mention what the hour will cover or anything to prepare? The answer changes which question styles the pack expects most.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interview:** Friday 13 November, 60 minutes, with Tobias Wrenfield, Head of Live Operations
**Relationship assumed:** hiring manager. The title makes that likely, but your message didn't say so. If Tobias isn't the person you'd report to, the persona weights below change.
**Research:** none. All four web searches were refused (permission not granted), so nothing here comes from Saltmarsh's website, its games or Tobias's public profile. Everything about the company is in your JD, or it's labelled as a pattern.

---

## How to use this pack

Two separate ideas organise this pack. **Personas** describe *how* a question gets asked: who is asking, and in what style. **Types** describe *what* the question is scoring. Guidance is scaffolding, not a script. Say it in your own words.

| Type | What it's scoring |
|---|---|
| VAL | Whether your past behaviour matches the company's published values |
| EXP | Whether what you've said about your work holds up, and what was actually yours |
| JD | Whether you can do the job as written, gaps included |
| CO | Whether you've done your homework on the company and its games |
| CASE | How you structure a live problem from this role |

Provenance labels: **grounded** = traceable to your message or the JD; **inferred** = derived by this pack, with the derivation named; **generic** = a pattern for the role, not a claim about Saltmarsh or you.

Question IDs: A = Case/Strategist, B = Skeptic, C = Data-Driven Prober, D = Conversational, E = Pressure, G = Peer, H = Values. (F is kept for fit-snapshot rows, so F-numbers always mean your evidence.)

An **answer slot** is an instruction for the interview, not a question for me. It names what Tobias may probe and gives you two honest branches, so whatever the truth is, you have words for it.

---

## Prep triage — tonight and Friday morning

This assumes you have tonight and a little of Friday morning.

1. **B1 out loud, three times** (20 min). This is the highest-ROI rehearsal in the pack. Time it. Practise the "I haven't led a team" line until it sounds boring.
2. **Learn Saltmarsh's two titles yourself** (45 min). The search for them was refused, so this pack can't name them. Find out which two titles the role covers, play them, and note one live event in each. This feeds A1, A5, C3 and D3, and it's the cheapest way to sound current.
3. **A1 and A4 out loud** (20 min). The calendar plan and the post-event review are the two cases a Head of Live Ops is most likely to set.
4. **C1** (10 min). Before Friday, check what your monthly retention numbers actually measured and how they were counted. If you can't find out, practise saying you don't know.
5. **B4 and E1** (10 min). The in-app purchase line, said once, plainly.
6. **Pick three reverse questions** (5 min).

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | The four years clear the bar. What your material doesn't say is whether the main title was run as a live service. Words: "Four years as an associate producer at a puzzle-game studio." Answer slot: the JD's live-service line makes this probe likely. If the main title was run as a live service, say so in your own words. If it wasn't, say so plainly and stay with the weekly content-drop calendar you ran |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title. It doesn't say live events or two titles, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "live-events" and "two of our mobile titles" make both probes likely. If any of those drops were time-limited events, say what they were in your own words; if none were, say so plainly. If you worked on another title's calendar, say so; if you didn't, say so plainly and stay with the main title |
| F3 | "two of our mobile titles" (platform) — JD | none given | none | [grounded] | discovery | Strong evidence here is simply the platform your main title shipped on. Answer slot: "mobile titles" in the JD makes a platform question likely. If the main title was on mobile, say so. If it wasn't, say so plainly and name its platform |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | The calendar quote touches this without showing whether coordinating those teams was part of it. Leading a team is a different thing from coordinating teams, and the JD asks for coordination. Don't let a probe merge the two, and don't claim either one. Answer slot: if those weekly drops needed input from design, art, engineering or community, say which teams and what your part was, in your own words. If they didn't, or that coordination belonged to someone else, say so plainly and stay with running the calendar. If you're asked about leading: "I haven't led a team." |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers. It doesn't mention a post-event review, or say the numbers were yours to own. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran any review after a content drop, say what it covered in your own words. If there was no such review, or it wasn't yours, say so plainly and come back to the monthly presentation |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but it's a single line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you wrote it, and QA still uses it. Answer slot: the JD says "manage", so expect a question about what happens to the checklist from release to release. If keeping it current or running it with QA was yours, say how in your own words. If that passed to others after you wrote it, say so plainly and stay with having written it |
| F7 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | This is your closest match to the JD. Lead with it in its own words: weekly, main title, last two years |
| F8 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement. Expect a prober on it. Answer slot: which measures those numbers were, how they were counted, and which part of producing them was yours, each in your own words. "I don't know how they were counted" is an honest answer if it's true |
| F9 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The checklist is written work that a team still relies on. Rewording only that: "I wrote the release checklist, and our QA team still uses it." Describe it and let Tobias draw the conclusion about your writing |
| F10 | Experience with monetised live events, common in mobile live ops. This is a role-family pattern, not in the JD and not a claim about Saltmarsh | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | The JD doesn't mention in-app purchases. This row is here because you raised it and because mobile live events are often tied to monetisation. Words: "I haven't worked on a game with in-app purchases." Then say how you'd learn it, as a plan and never as a past. Add nothing to make the gap feel smaller |

---

## Persona table

The session is established by your message: one 60-minute interview run by Tobias Wrenfield. Whether more rounds follow is unknown. Weights start from the hiring-manager prior (Case/Strategist plus Skeptic). Nothing about Tobias could be researched, so no interviewer signals adjust them.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Here's a calendar problem. Walk me through it." | High. A Head of Live Ops hiring a producer is buying calendar and event judgment, and the JD is mostly verbs (plan, run, coordinate, own) | Clarify, then objective, then structure, then metrics, then risks. Think aloud and question one premise per case |
| Skeptic | Quiet probing of F2, F4 and F5: one title vs two, a calendar vs coordinating four teams, presenting vs owning | High. Hiring managers de-risk gaps, and your gaps sit exactly on the JD's ownership verbs | B1 rehearsed until boring. Bridges only from what you said, with the limit stated plainly |
| Data-Driven Prober | "Which retention measure? How was it counted?" | Medium. The JD names retention metrics and KPIs, and F8 is the one number-shaped claim you've made | Know what you can and can't say about how the numbers were counted |
| Conversational | Friendly opener, "walk me through your journey", "what are you playing?" | Medium. Most 60-minute HM rounds open and close in this register, and it's still scored | A 90-second arc. Treat the "what are you playing" question as scored |
| Pressure | Time-boxed "why you over someone with monetisation experience" | Low to medium. Not the HM default, but F10 invites it | Pause, anchor on what you actually did, hold through two follow-ups, then concede the real gap plainly |
| Peer Evaluator | Collaboration and seam scenarios between design and community | Low as a persona, but the JD's coordination line brings its content into an HM round | Propose working principles, not invented history |
| Values / Behavioral | "Tell me about a time…" | Low. No values-style round was detected, and Saltmarsh's values couldn't be checked | Use the selection scaffolds. Where nothing fits, say so |

---

## Question banks

### A — Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit the live-events calendar for both titles next month. How do you build the first quarter?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first: what's already committed, each title's audience and cadence, team capacity per discipline, and which KPIs events are judged on. Then structure: fixed anchors first, a cadence per title, dependencies by discipline, buffer, and a review point after each event. One anchor line from your own history, in its own words: "For the last two years I ran the weekly content-drop calendar for our main title." Then go back to the plan, and don't stretch that line to two titles | The JD's first responsibility, asked live. CASE, because it scores structure. F7 gives you a real anchor and F2 marks its limit |
| A2 | "An event goes live and day-one participation is well below forecast. Talk me through the first 48 hours." | CASE | [generic] | Rule out a tracking or entry-point bug first. Then segment: new vs returning players, platform, region. Check whether players can find the event, and check community sentiment. Then decide whether to tune, extend or let it run, and say who you'd pull in and what you'd record for the review. The question needs no claim about your past, so the guidance makes none | A standard live-ops diagnosis drill. It tests the "own the KPIs" line under time pressure. Generic, because it's a pattern, not Saltmarsh's process |
| A3 | "Two days before an update, art tells you the event assets will be a week late. What do you do?" | CASE | [generic] | Clarify what's late and why. List the options: descope, swap event order, ship a reduced version, or slip. Pick using criteria (what's been promised to players, dependent teams, risk to the release checklist). Then say who you tell, in what order, community included | It tests the coordination line (F4's requirement) as a decision, not a record, so your history isn't needed |
| A4 | "How would you structure a post-event review, and what KPIs go in it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Your starting point, at its own scope: "I presented the monthly retention numbers to the studio head." Then the structure, said as a plan: the goal vs the result, participation, the effect on retention, where players dropped out, community sentiment, operational misses, and decisions for next time. Answer slot: if you ran any review after a content drop, say what it covered; if not, or it wasn't yours, say so plainly and stay with the monthly presentation | F5 is the thinnest bridge on an ownership verb, so the plan has to carry the answer. JD, because it scores a stated responsibility |
| A5 | "Both titles want the same art and engineering time for the same month. How do you decide?" | CASE | [generic] | Criteria: commitments already made to players, expected effect on each title's KPIs, reversibility, and the cost of slipping each. Show the trade-off in writing to both sides, and know when it goes up to Tobias. No past claim | Two titles is the part of the JD that's new to you (F2), asked as a live problem. Generic, because you don't know Saltmarsh's prioritisation rules. That's a good reverse question |

### B — Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates design, art, engineering and community on every update. What have you done that shows you can do that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team" | **The highest-ROI rehearsal in this pack.** Hold only what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if those drops needed input from design, art, engineering or community, say which teams and what your part was; if they didn't, or it wasn't yours, say so plainly. **Follow-up 1:** "Who did you actually work with?" Same slot, no new names. **Follow-up 2:** "Have you led a team?" Say: "I haven't led a team." Then point out that the role as written asks you to coordinate, and give how you'd run coordination in your first 90 days, as a plan. **Follow-up 3:** "So why are you ready?" Go back to the calendar quote, and don't add anything to it | F4 is where the JD's biggest verb meets your thinnest evidence, and "Never led a team" is the follow-up you know is coming. Some form of this will be asked. JD, because it scores a stated responsibility |
| B2 | "You've been an associate producer. This is a producer role. What changes for you?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Keep the title exactly as it was: "four years as an associate producer." Name the calendar as the thing you ran. Then answer the actual question as a plan: what you expect to own here that you'll be learning (two titles, the review), and how you'd get there. Don't upgrade the title and don't describe what you did as producer-level | The step up in title is visible from F1 alone. JD, because the requirement is "producing" |
| B3 | "Tell me about your main title. Was it a live-service game, and was it on mobile?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Name the title and the calendar you ran in the quote's terms. Answer slot (F1, F3): if it was run as a live service, say so; if it wasn't, say so plainly. If it was on mobile, say so; if it wasn't, say so plainly and name the platform. Either answer is fine. A vague one isn't | F1 and F3 are both silent on this, and it's a five-second check Tobias will make. Answer it cleanly |
| B4 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Stop there for a beat, without apologising or padding. If asked how you'd close it, give a plan: learn how events and monetisation connect on these titles from whoever owns it, review past event results, and ask which numbers they're judged on. Never describe monetised work you haven't done | F10 isn't in the JD, but it's common in mobile live ops and you flagged it. EXP, because it checks your history directly |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Pick a real one. The pack's reading is that F2 (two titles) and F5 (owning the review) are where your material is thinnest. If you choose the review, anchor at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: if owning a post-event review would be new, say so plainly; if you've done one, say what it covered. Then the plan. Don't pick a fake weakness | It's a standard Skeptic stem, and a rehearsed honest answer to it builds credibility for B1 |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers. Which measures were they, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot, each part in your own words: which measures they were, how they were counted, what they're sensitive to, the assumption behind them you'd defend least, and which part of producing them was yours. If you don't know how they were counted, say so plainly: "I presented them; I don't know exactly how they were counted." That's better than a method you can't repeat | F8 is your one metric-shaped claim, and a Head of Live Ops will go two levels down on it. EXP, because it tests what was yours |
| C2 | "Tell me about a time retention numbers changed what went into a content calendar." | EXP | [grounded] | Open prompt, so choose the instance. A good one names the number you saw, what you changed, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the monthly presentation, or the calendar you ran) or how you'd handle it | It links the JD's metrics line to its calendar line, which is the core of the job. Grounded on the JD's theme, with no claim about your past |
| C3 | "One event runs on both titles. It lifts retention on one and not the other. How do you work out why?" | CASE | [generic] | Check the measurement is the same on both titles. Compare audiences, entry points, reward relevance, timing against each title's other content, and comms. Form a hypothesis, test it on the next event, and write it into the review | Two-title analysis, asked as a live problem. Generic, because it's a pattern |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc, four beats, each in its quote's own terms: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title over the last two years; the release checklist QA still uses; presenting monthly retention numbers to the studio head. Close with why this role, in your own words. Don't add titles or team sizes | Almost certainly the opener, and it frames the hour. Every beat is one of your four sentences, so nothing collapses under follow-up |
| D2 | "Why live operations, and why now?" | EXP | [generic] | Open prompt. A strong answer names what you want to do more of and why this role offers it. If you can't connect it to something specific yet, say what draws you to live ops in plain terms rather than reaching for a line | Motivation consistency, asked casually |
| D3 | "What live-service mobile games are you playing, and what's one event you thought was well run?" | CO | [generic] | Name a game you actually play and an event you actually saw. Say why it worked (cadence, clarity of rewards, comms) and one thing you'd change. If you've played Saltmarsh's titles by then (triage item 2), have one observation ready. Never name an event you didn't see | The homework signal. It's generic because research couldn't run, so your own play tonight is what grounds it |
| D4 | "How do you write an update brief so four teams read it the same way?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Anchor: "I wrote the release checklist, and our QA team still uses it." Then the principles, as a plan: one owner and date per item, a definition of done, what changed since the last version, and a single source of truth. Don't call the checklist proof of anything. Describe it and stop | Covers "clear written communication" (F9) with the only written artefact your material names. JD, because it's a listed requirement |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live ops on a monetised mobile game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "never worked on a game with in-app purchases" | Pause, then hold: the calendar you ran for two years and the checklist QA still uses, in those words. Concede once, specifically: "I haven't worked on a game with in-app purchases." Then give your plan to close that gap. Hold the calendar and checklist through two follow-ups. Don't fold on them to make the moment easier, and don't argue the gap away | F10 invites this framing. Pressure scores composure, and the hold-then-concede structure is the rehearsal |
| E2 | "Walk me through that release checklist. How much of it was actually you?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote it, and QA still uses it." Answer slot: if others shaped parts of it, say who and what, in your own words; if it was yours start to finish, say so. Answer slot (F6): if keeping it current with QA was yours, say how; if it passed to others, say so plainly and stay with having written it | F6 is a strong line, which makes it a magnet for an attribution probe. JD, because "manage the release checklist with QA" is listed |

### G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community says players are angry about an event's rewards. Design says the rewards are right. You're in the middle. What do you do?" | CASE | [generic] | Get the facts: what players are actually saying, how widespread it is, and what the data shows. Get both leads in one room with the same facts. Set criteria for changing course vs holding. Agree what's said to players and when. Make sure it's in the post-event review | Coordination with community, which the JD names, asked as a conflict. Generic, with no past claim |
| G2 | "How do you handle credit when an update spans four teams?" | VAL | [generic] | Open prompt. Use "we" for context and "I" for your contribution. If you're asked for an example and none comes to mind, say so plainly, then explain how you'd handle it | A collegial stem that still checks attribution honesty |

### H — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: it needs a named stake, the moment you said it, and what happened to the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A persona stem. Saltmarsh's values couldn't be checked, so it's generic |
| H2 | "Tell me about a time a planned content drop had to change at the last minute." | VAL | [grounded] | Selection scaffold: what changed, what you decided, who you told, and what you'd do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Themed by the JD's calendar line. Grounded on the JD, with no claim about your past |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A1, A5, B3, C3 |
| Coordinate design, art, engineering and community on each update | B1, A3, G1 |
| Own the post-event review and its KPIs | A4, B5, A2 |
| Manage the release checklist with QA | E2, A3 |
| 3+ years producing live-service games or apps | B2, B3, D1 |
| Experience running a content calendar | A1, H2 |
| Comfortable with player-retention metrics | C1, C2, A4 |
| Clear written communication | D4 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here, and who reads it?" | It goes straight at the responsibility you'd be growing into (F5) and shows you take ownership of it seriously |
| R2 | "Are the two titles' calendars planned together today, or separately?" | It shows you're already thinking about the two-title part of the job, and the answer tells you how hard it is |
| R3 | "How do live events connect to monetisation on these titles, and who owns that side?" | You learn the F10 territory on your terms, as diligence rather than confession |
| R4 | "Where's the hardest coordination seam right now: art, engineering or community?" | It's a producer's question, and it tells you where your first month goes |
| R5 | "What would you want this person to have changed after 90 days?" | It gives you the real scorecard for the role |
| R6 | "How is your live ops team set up, and where would this role sit between you and the discipline leads?" | It clarifies who you'd be coordinating, which is B1's territory. Without Tobias's public profile, no question about his own career path can be offered |

---

## Prohibited claims

Built from the fit snapshot before the banks were written. No guidance in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team, or led cross-functional teams | A negative you stated, F4 | "I haven't led a team." Then the F4 slot, inside the calendar you ran |
| Has worked on in-app purchases or monetised events | A negative you stated, F10 | "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar across multiple titles | Inflated form of F2 | F2's quote at its own scope. The pack's observation: your material says weekly content drops for one title |
| Owned post-event reviews, or owned the retention KPIs | Inflated form of F5 and F8 | F5's quote at its own scope: you presented the monthly retention numbers. A4's and C1's slots stay inside that |
| Managed QA, or owned the release process | Inflated form of F6 | F6's quote at its own scope: you wrote the checklist QA still uses. E2's slot stays inside the checklist |
| Producer or senior-producer experience | Inflated form of F1 | F1's quote at its own scope: four years as an associate producer |

---

## Sources

**Provided documents:** the JD text and your background, both from your message.

**Searches sent:**

- `Saltmarsh Games values`: refused (web search permission not granted)
- `Saltmarsh Games interview process producer`: refused
- `Saltmarsh Games mobile studio news 2026`: refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: refused

No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused. It would have themed the H bank on Saltmarsh's published values by name |
| 2. Saltmarsh Games interview process | unavailable | Refused. It wouldn't change Friday's session, which your message establishes, but would have shown whether more rounds follow and what they hold |
| 3. Saltmarsh Games strategy / recent news | unavailable | Refused. It would have named the two titles and recent events, grounding D3 and the A-bank cases in Saltmarsh's actual games |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Refused. It would have added an interviewer read, adjusted persona weights and a reverse question tied to his own path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search, then ask me to rerun** → targets 1–4 above: Saltmarsh's values, loop, titles and recent news, plus Tobias's public profile. That adds an interviewer read, a tailored reverse question, and CO questions on the real games
- **A deeper research pass** → up to 6 more searches and 2 more fetches, several more minutes: a company strategy brief, Tobias's talks or posts, loop reports for this role, and recent org context
- **The names of the two titles** → A1, A5, C3 and D3 rewritten around them, even without search
- **Your answers to the answer slots on F1, F2, F3, F4 and F5** → those rows can move off discovery or transferability, and B1, B3 and A4 become story-mapped rather than slotted
- **Any recruiter note on focus areas or something to prepare** → a build section for any declared deliverable, and reweighted personas
- **Whether more rounds follow Friday** → per-round mini-packs with their own weights
- **The release checklist or a retention deck, redacted** → F6, F8 and F9 can rise from medium to high confidence, because those are the documents this field actually keeps
- **A tuesday-dossier.md** (none present) → an evidence-derived highest-ROI objection and a verified prohibited list in place of the locally built ones
