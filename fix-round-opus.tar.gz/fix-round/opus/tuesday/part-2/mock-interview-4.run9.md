I've saved your prep pack as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-4-denied-3126f659/Quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the 45-minute hiring-manager conversation from your note, with 22 questions in 7 banks. Your dossier supplied the role's requirements, your verified lines, the objection to rehearse and the claims to avoid.

- **Date:** today is Thursday 12 November, so I've assumed you mean next Thursday. If the interview is today, practise A1 (the underwriter's objection: why hire someone without the PM title or a roadmap), A3, B2 and reverse questions 1–2, and treat the rest as insurance.
- **Research:** permission for my three web searches was refused, so I have nothing on Quartzline's values, interview process or recent news. "Why Quartzline" and the case questions are generic until that's filled in.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also update your tuesday-dossier.md with what this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes (from your note). Interviewer name not given.
**Built from:** your `tuesday-dossier.md` (v1.1, 2026-08-14). Web research was attempted and refused, so company-specific content is labelled `[generic]`.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who is asking and in what style. **Types** describe *what is being scored*.
- Type key:
  - **VAL**: behavioural and values alignment
  - **EXP**: work-experience deep-dive, testing what was actually yours
  - **JD**: role-driven, testing whether you can do the listed job, gaps included
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, solved out loud
- Provenance labels: `[grounded]` traces to your dossier, `[inferred]` is this pack's own reading of the fit, `[generic]` is a role-family pattern with no Quartzline-specific claim.
- An **answer slot** is an instruction for the interview, not a question for you to answer here. Both of its branches are honest answers.
- The guidance is scaffolding, not a script. Every suggested line in this pack is proposed wording, pending your approval. Change anything that isn't how you would say it.

---

## Fit snapshot

Proposed wording, pending your approval. The three verified lines quoted below are the only material about your past that this pack draws on.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must-have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | low | [inferred] | transferability | The underwriter's condition is that this is positioned as adjacent and never as PM experience. Plain acknowledgment, sourced to `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title or role." Then the adjacent work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: the JD's "3+ years" makes a probe on how long you've done this work likely. Give your own figure for the integration work, as your CV states it. The dossier's summary prose mentions a year count that no verified entry carries, so this pack does not supply one. `[inferred]` because mapping integration work onto the PM requirement is the underwriter's and this pack's reading |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier responsibilities, with the R1 sub-claim the dossier grades | none given | none | [grounded] | capability | No bridge. The underwriter looked and found none (`acknowledge_gap`). Words, sourced to `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past. The F5 sessions are not a bridge here: the pack's observation is that input to a roadmap is not ownership of one |
| F3 | "Shipped API or platform products" — dossier R2, must-have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | high | [grounded] | transferability | Your material says integrations of the vendor's REST APIs, led end to end. It does not say a product you shipped, and the words stay at that scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: R2 makes a probe on which decisions in those integrations were yours likely. If any architecture or go-live decision was yours to make, say which one and how you decided, in your own words. If none was, say so plainly and stay with how you led them |
| F4 | "Technical fluency: API docs, schemas" — dossier R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | discovery | The integrations touch this, but your material doesn't show whether working with API docs or schemas was part of your work. Answer slot: R3 makes a probe on docs and schemas likely. If you worked with either in those integrations, say how, in your own words. If you didn't, say so plainly and return to the integration stages you led. `[inferred]` because the link from integration stages to R3 is this pack's reading |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4, important | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | transferability | Your material reaches clients and product. It does not show engineering or sales. Words at scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." The dossier marks this as confirmed, with limited inspectable proof, so expect a probe and volunteer the limit before it's pulled out of you. Answer slot: R4 makes a probe on engineering and sales likely. If either was part of your integrations or sessions, say who they were and how you worked with them. If not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy here is `clarify`, and no verified entry speaks to this requirement. Answer slot: "Agile delivery experience" is what the probe scores. If you've worked in Agile delivery, say how, in your own words. If you haven't worked that way, say so plainly. Then the honest turn: "here's what I'd want to confirm about how your squads define it" |
| F7 | "Run discovery with integration partners" — dossier responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | high | [inferred] | transferability | Scoping and requirements on client integrations sit next to partner discovery, but they are not the same kind of work. The words stay at the quote's scope: scoping and requirements as stages of the integrations you led. Answer slot: this line makes a probe on how you found out what clients needed likely. If your scoping went beyond the integration itself, say how, in your own words. If it didn't, say so plainly and stay with the scoping you led |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier responsibilities | "Wrote the internal integration playbook her team uses" — dossier verified evidence 2; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | high | [inferred] | transferability | A playbook is written work, but it is a different kind of document from a product spec. The squad-prioritization half of this line belongs to F2. Words: "I wrote the internal integration playbook my team uses." Answer slot: this line makes a probe on documents that engineers build from likely. If the requirements stage of your integrations produced such documents, say what they held, in your own words. If not, say so plainly and stay with the playbook |
| F9 | "Define and track adoption metrics" — dossier responsibilities | none given | none | [grounded] | discovery | Your material says nothing about measuring adoption. Answer slot: if you tracked how clients used the APIs after go-live, say what you counted and how, in your own words. If you didn't, say so plainly and say what you would measure first. The dossier lists Quartzline's own baseline as unknown, and reverse question 2 asks about it |

---

## Persona table

Your note establishes this session: a 45-minute conversation with the hiring manager. The weights below rest on that, not on a guessed loop. No values-style round is detected, because your note names none.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the PM-title gap and of roadmap ownership | **High, 5 questions.** The hiring-manager prior puts Skeptic and Case on top, and the underwriter named this candidate's objection directly (F1, F2) | Rehearse A1 until it's boring. Concede first, bridge only from the quoted lines, then give a ramp plan |
| Case / Strategist | Live problems on adoption, prioritization and the first 90 days | **High, 4 questions.** The hiring-manager prior, plus a JD built around roadmap and metrics | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise |
| Data-Driven Prober | "Walk me through one", "how did you count 30+" | **Mid, 4 questions.** Your strongest evidence carries a figure (30+) and an inspectable artifact, and both invite depth. A fourth question covers R3 | Know what you can and can't say about how the figure was counted. Offer to walk through one integration end to end |
| Conversational | The opener and "why Quartzline" | **Mid, 3 questions.** A 45-minute conversation usually opens casually, and casual questions are still scored | A rehearsed 90-second arc (D1). Treat casual JD topics as scored |
| Pressure | A time-boxed version of the objection, and "how much was you" | **Low, 2 questions.** Not the hiring-manager prior, but the objection invites it | Pause, restate, hold through two follow-ups, concede only what's real |
| Peer Evaluator | The hiring manager voicing the squad leads' side | **Low, 2 questions.** The two-squad seam is the dossier's top open risk | Propose seam principles. Don't pretend to know the seam |
| Values / Behavioural | Generic behavioural stems | **Low, 2 questions.** No values round detected. Included so you don't meet the style for the first time live | Selection scaffolds with an honest branch |

---

## Question banks

Proposed wording, pending your approval.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Ran quarterly roadmap-input sessions feeding client evidence to product" | **The highest-ROI rehearsal in this pack. The underwriter named this objection.** Beat 1, concede first and don't pad it (sourced to `prohibited_claims: "Having held a product manager title or role"` and `prohibited_claims: "Having owned a product roadmap"`): "That's right — I haven't held a product manager title or role, and I haven't owned a product roadmap." Beat 2, the adjacent work at its own scope: the 30+ end-to-end client integrations of the vendor's REST APIs you led (scoping, requirements, architecture, UAT, go-live), and the quarterly roadmap-input sessions you ran, feeding client evidence to product. Say that the sessions are the thinner evidence before they find that out. Beat 3, a ramp plan in future tense: what you'd learn first (which decisions are yours and which are the squad leads', how adoption is measured today) and how you'd learn it. Let them draw the conclusion, and don't tell them what your work proves. Follow-up 1 ("integration work is delivery, not product"): hold by going back to what you led, never by adding to it, and concede the difference in the same plain words as Beat 1. Follow-up 2 ("so what would you do in month one?"): go to Beat 3, never to a claimed past | The dossier's `likely_interviewer_objections` names it, and F1 and F2 are where the must-have presses hardest. JD because it scores R1 directly, delivered in the Skeptic's style. The negatives in the question are kept because the dossier's `prohibited_claims` source them |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Name F2 directly. Don't pick a safe weakness. Words sourced to the `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" and its `prohibited_claims` entries: "Owning the roadmap and setting priorities for the squads — I haven't owned a product roadmap or set prioritization for an engineering squad." Then the ramp, as a plan: sit with each squad lead, learn how priority calls get made today, and make one small, visible call early with your manager's backing. Calibrated candour beats a weakness that is really a disguised strength | F2 is the one `acknowledge_gap` area, and a hiring manager de-risking a gap asks this in some form. JD because it is scored against the listed role |
| A3 | "The JD asks for shipped API or platform products. What in your background speaks to that?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Don't call the integrations products, and don't present the vendor's APIs as yours. Answer slot: expect a probe on which decisions were yours. If any architecture or go-live decision in those integrations was yours to make, say which one and how you decided, in your own words. If none was, say so plainly and stay with how you led them | F3 is a must-have answered by adjacent evidence. This is the second-hardest press after A1 |
| A4 | "Why product management, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection scaffold. Give your reason in your own words. It needs a real pull toward this work, not just a push away from your current role. The nearest thing your material carries is the sessions you ran, feeding client evidence to product. If that is where the pull came from, say so in your own words. If it isn't, don't force it, and give the reason that is true. Keep it under a minute, because a long "why now" reads as defensive | Skeptic stem ("why leave, why here, why now"). F1's transition makes motivation the first thing a hiring manager tests |
| A5 | "How have you worked in Agile delivery inside a product org?" | JD | [grounded] | Clarify strategy, per the dossier. Answer slot: "Agile delivery experience" is what this probe scores. If you've worked in Agile delivery, say how, in your own words. If you haven't worked that way, say so plainly. Then: "here's what I'd want to confirm about how your squads define it", and ask how the two squads plan and ship. For you, not to say aloud: R5 is marked preferred, not must-have | F6, the dossier's `clarify` area. The question presupposes a practice that only the JD raises, so the slot's second branch lets that premise be false |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Say partner adoption of the API platform stalls. Diagnose it — what do you need to know first?" | CASE | [generic] | Clarify first: how adoption is measured today. The dossier lists that as unknown, so asking is the right first move, not a dodge. Segment: which partners, new or existing. Walk a funnel from first access to production use and find where it breaks. Form hypotheses (docs, onboarding, missing endpoints, commercial terms) and say how you'd test each cheaply. Close with the metric you'd watch and one risk. The question needs no claim about your past, so the guidance makes none | The hiring-manager prior is live problems on the real roadmap, and F9 is a discovery gap, so this is where you show judgement without a past claim. `[generic]` because research couldn't run |
| B2 | "Sketch your first 90 days owning this roadmap. What do you need to know first?" | CASE | [generic] | Clarify: decision rights against the two squad leads, the current adoption baseline, and what partners are asking for. Structure: listen (squads, sales, a handful of partners), then baseline (what is measured today), then one small visible decision with your manager, then a first roadmap draft reviewed with the squad leads. Name the risk of moving before you understand what the squads have already committed to. Future tense throughout. This is where F2 is answered with a plan, not a past | F2 is the gap, so a plan is the honest answer, and the hiring manager will want to hear one. CASE |
| B3 | "Two integration partners want conflicting changes to the same endpoint, and both squads are full. How do you decide?" | CASE | [generic] | Clarify what each change unlocks, for how many partners, any commitments made, and whether it is breaking or additive. Options: version it, sequence it, decline one, or find a shared change. State your criteria before you choose. Name who you'd bring in (the squad leads, each partner's sales owner). Say how you'd tell the partner who has to wait | Live prioritization and partner discovery (F2, F7). Also scores R4 |
| B4 | "How would you define adoption metrics for a partner-facing API platform?" | CASE | [generic] | Structure: what "adopted" means as stages (activation, active use, depth, retention), leading and lagging measures, partner-level and call-level views, and a guardrail metric (errors, latency, support load). Say you'd want today's baseline before committing to targets. Name the weakest assumption in your own metric set before they do | Covers the adoption-metrics responsibility (F9) as a live problem |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through one of the client integrations you led, end to end." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one integration you know cold and take it through the stages the quote names (scoping, requirements, architecture, UAT, go-live), in your own words. "Led" is the quote's verb, so keep it. Use "we" for the team and "I" for what you did. Answer slot: the partner-discovery line makes a probe on scoping likely. If your scoping went beyond the integration itself, say how. If it didn't, say so plainly and stay with how you led the stages | This is your strongest inspectable evidence (F3, F7). EXP because it tests what was actually yours |
| C2 | "You say 30+ integrations. How did you count that, and which were fully yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words: how it was counted, what it is sensitive to (what counts as one integration), the assumption behind it you'd defend least, and which part was yours. The pack supplies none of these. "I'd want to check the exact count" is an honest branch. Keep 30+ attached to client integrations | The headline figure is a magnet for a prober |
| C3 | "Tell me about the integration playbook you wrote. What's in it, and how does your team use it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the quote states are that you wrote it and your team uses it. What's in it, and how they use it, are yours to say in your own words, because the pack doesn't know the contents. The dossier records the playbook as inspectable. If you can show a redacted page, offering to is the strongest version of this answer. Answer slot: the spec-writing line makes a probe on documents engineers build from likely. If your integrations' requirements stage produced such documents, say what they held. If not, say so plainly and stay with the playbook | The one inspectable artifact you have (F8) |
| C4 | "When you start with a new API, how do you get up to speed on its docs and schemas?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: R3 is what this probe scores. If reading API docs or schemas was part of the integrations you led, say how you did it, in your own words. If it wasn't, say so plainly and return to the stages you led. Don't fake depth: a prober goes one level down | Covers R3 (F4). The premise is the JD's, and the slot lets it be false |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Wrote the internal integration playbook her team uses" "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built on the three lines, in your own words: the 30+ end-to-end client integrations you led, the playbook you wrote that your team uses, and the quarterly roadmap-input sessions you ran, feeding client evidence to product. Answer slot: the JD's "3+ years" makes a probe on duration likely, so give your tenure as your CV states it. End with one sentence of your own on why this role. Use no title you didn't hold | Almost certainly the opener. Casual, and still scored |
| D2 | "What drew you to Quartzline?" | CO | [generic] | Selection scaffold. Name one specific thing you've read about or seen of Quartzline's partner API platform, in your own words, and say why it connects to the work you want. Research couldn't run, so this pack has no Quartzline facts to give you. Don't borrow a claim you can't source. If nothing specific comes to mind, say plainly what about the role drew you | CO coverage. Stays `[generic]` until research or your own reading fills it |
| D3 | "How do you like to work with engineers?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: R4 names engineering. If engineers were part of the architecture or UAT stages of the integrations you led, say how you worked with them, in your own words. If they weren't, say so plainly and describe who you did work with in those stages | R4 asked casually (F5) |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Ran quarterly roadmap-input sessions feeding client evidence to product" | A1, compressed. One sentence conceding the gap (the same sourced acknowledgment as A1), then the 30+ end-to-end client integrations you led and the input sessions you ran, then one line of ramp plan. Pause and restate before answering, and don't rush to fill the minute. If pushed, you have already conceded the title, so you never concede the work you did | The F1 objection, time-boxed |
| E2 | "Those quarterly roadmap-input sessions — how much of that was actually you, and what did product do with it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold what the quote carries: "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer the limit before it's pulled out of you: say plainly what you can and can't point to as evidence of the sessions. Answer slot: if you know of specific items product took from those sessions, name them in your own words. If you don't know what product did with them, say so plainly and stay with what you ran. Never move from input to ownership. `prohibited_claims: "Having owned a product roadmap"` draws that line. Hold through two follow-ups, and concede uncertainty about outcomes, never about running the sessions | F5's evidence is medium, and the dossier says to expect this probe |

### F — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our two squad leads have strong views on priorities. Where's the seam between you and them, and what happens when you disagree?" | CASE | [generic] | Propose principles rather than pretending to know the seam. For example: the PM owns what partners need and why, the squads own how and how much, and disagreements go to evidence first, then to whoever the organisation says decides. Then turn it into reverse question 1. Claim no past prioritization authority (F2) | The dossier's top open risk. A hiring manager may voice the squad leads' side |
| F2 | "Sales has promised a partner something the squads haven't planned. What do you do?" | CASE | [generic] | Clarify what was promised, to whom, by when, and what's at stake commercially. Talk to the sales owner before the partner. Size the cost with the squad leads. Options: deliver it, scope it down, or reset expectations. Decide on stated criteria. Close the loop with sales on how future asks come in | R4 as a live problem, covering engineering, sales and customers at once |

### G — Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. It needs a named stake, a moment you didn't soften the message, and what happened afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No values round is detected. This is a persona stem, so the style isn't new to you live |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. It needs the customer, the metric you didn't optimise for, and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. It suits a partner-facing role |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 — 3+ years product management experience | A1, A2, A4, E1, D1 |
| R2 — Shipped API or platform products | A3, C1 |
| R3 — Technical fluency: API docs, schemas | C4 |
| R4 — Stakeholder management across engineering, sales, customers | D3, F2, E2, B3 |
| R5 — Agile delivery experience | A5 |
| Own the roadmap for the partner-facing API platform | A1, A2, B2, F1 |
| Run discovery with integration partners | C1, B3 |
| Write specs and drive delivery with two engineering squads | C3, B2, F1 |
| Define and track adoption metrics | B1, B4 |

---

## Reverse questions

| # | Question | Why it lands | Source |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | It tests the dossier's risk that decision authority against the two squad leads is stated in the JD but not shown. The answer tells you what kind of role this really is | [grounded] dossier `questions_for_employer` |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | It tests the dossier's risk that adoption metrics are a stated responsibility with no baseline given. It also shows you think in measures before targets | [grounded] dossier `questions_for_employer` |
| 3 | "What would you need to see in the first 90 days to know this hire worked?" | It gives you the real bar in the hiring manager's own words | [generic] |
| 4 | "How do partner requests reach the squads today, and who decides which ones get looked at?" | It shows you're already thinking about intake, and it approaches reverse question 1 from the side | [generic] |
| 5 | "Where do the squads and product most often disagree, and how does that usually get resolved?" | It tests how real the decision rights are in practice, not on paper | [generic] |
| 6 | "What's the hardest part of this role that the job description doesn't say?" | It invites candour, and the answer often tells you more than the JD | [generic] |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier `prohibited_claims` | Plain acknowledgment: "I haven't held a product manager title or role." Then F1's quotes at their own scope, positioned as adjacent |
| Having owned a product roadmap | dossier `prohibited_claims`, and the `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | "I haven't owned a product roadmap." Then a ramp plan. The roadmap-input sessions stay input, never ownership |
| Having set prioritization for an engineering squad | dossier `prohibited_claims`, and the same `acknowledge_gap` area | "I haven't set prioritization for an engineering squad." Then a plan for learning the squads' decision rights |
| Shipped an API or platform product | Inflated form of F3, built by this pack | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says integrations of the vendor's APIs, not a product shipped. A3's slot stays inside the integrations |
| Decided which roadmap items came out of the input sessions | Inflated form of F5, built by this pack | F5's quote at its own scope. The pack's observation: the material says sessions feeding evidence to product, not decisions. E2's slot asks only what you know product did with them |
| Ran product discovery with partners | Inflated form of F7, built by this pack | F7's quote at its own scope: scoping and requirements as stages of integrations you led. C1's slot stays inside scoping |
| Wrote product specs for engineering squads | Inflated form of F8, built by this pack | F8's quotes at their own scope: the playbook you wrote, and the requirements stage of integrations you led. C3's slot stays inside those |

---

## Sources

**Provided documents:** `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter on 2026-08-14 (about three months before this pack).

- **Dossier consumed.** Sections supplied:
  - `role_profile`: requirements R1–R5, responsibilities and unknowns. It stands in for the JD.
  - `decision`: context only.
  - `handoff_to_mock_interview`: verified evidence, weak areas with strategies, the named objection, risks, employer questions and prohibited claims.
- **Not in this dossier:** `evidence_map`, `evidence_state` and `risk_register`, so the fit snapshot quotes `verified_candidate_evidence` directly.
- **Rows resting on your confirmed evidence:** F1, F3, F5, F7 and F8, and every bank row that quotes them. Everything labelled `[generic]` is this pack's pattern.

**Searches sent:**

- `Quartzline company values` — refused (permission not granted)
- `Quartzline interview process product manager` — refused (permission not granted)
- `Quartzline partner API platform news 2026` — refused (permission not granted)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The call was refused. It would have given Quartzline's published values to theme G1 and G2. It would not have added a values cheat sheet, because your note names no values round |
| 2. `Quartzline interview process product manager` | unavailable | The call was refused. Your note already establishes this session, so it would have moved only what the pack expects from later rounds |
| 3. `Quartzline` strategy and recent news | unavailable | The call was refused. It would have grounded D2 and the B bank in Quartzline's current priorities instead of `[generic]` patterns |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already supplies the requirements and responsibilities |

---

## Upgrade menu

- Web search allowed, or Quartzline's values page and a recent news item pasted in → D2 and B1–B4 grounded in Quartzline's current priorities, and G1–G2 themed by their published values
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; needs search permission) → a strategy brief and recent org context for sharper CASE questions
- The hiring manager's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their career path
- Any recruiter guidance (focus areas, a prepared exercise) → a build section for any graded deliverable, and adjusted coverage
- Your own answers to the slots in F4, F6, F7, F8 and F9, given here outside a drill → those rows quote your words and move off `discovery` or `transferability` where the answer supports it
- Your raw CV → your tenure figure in your own words for F1 and D1, and possible quotes for F4, F8 and F9
