No dossier present. Reading the needed references.
I've built your prep pack for all three rounds on 21 November, based on the recruiter's email. I ran no web searches because your JD, values text, recruiter email and strategy summary already covered everything the pack needed.

The pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-opus-tuesday-part-2-rooms-case-8-canned-ea1b0a62/01111287-68f7-4ff3-a7aa-e77bd3a4771c/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`

**What's in it**
- **Your experience against the JD:** each requirement is set next to your own words, with the gap named and how to talk about it honestly.
- **Questions for each round:**
  - Recruiter: 9 questions.
  - Head of Member Services: 11 questions, mostly behavioural.
  - Branch-manager panel: 9 questions, with one story or prompt for each of the four values.
- **The 20-minute case:** a structure for the time, three positions you could take (each with its weak point), and how to stand out from the obvious answer.
- **Questions to ask them:** five for each round.

**Where you'll be pushed hardest**
- **The contact centre (question D1, highest priority).** The job's first line covers the contact centre and you've never worked in one. The pack has you say so before you're asked twice, then describe what you do have and how you'd learn the rest.
- **Presenting to senior leaders.** You've said you've never presented above regional level. The pack keeps that plain and adds how you'd prepare.
- **Regulated complaints.** Your background mentions a formal complaints log but not whether a regulator's rules applied. Have your honest answer ready.
- **Monthly reporting.** Your background doesn't say whether your spreadsheet tracks volumes or resolution times. Have your honest answer ready for that too.

If you tell me those details in our conversation, I'll rebuild the affected answers around them. There's also a short list of claims the pack won't coach, like saying you "ran" or "owned" the complaints process. Each would fall apart on the first follow-up question.

Say the word and I'll play the sceptical manager on D1.
I can also save a `tuesday-dossier.md` file listing the gaps this prep found, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 21 November 2026, per the recruiter's email
- Round 1: 30 minutes with the recruiter
- Round 2: 45 minutes with the Head of Member Services, your future manager, "mostly behavioural"
- Round 3: 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation. This is the values round, scored against the four values

**Interviewer names:** not assigned yet. Personas are weighted from round type and the recruiter's description.

**Mode:** loop. One shared fit snapshot, grounding brief, prohibited list and sources section, plus a mini-pack for each round.

---

## How to use this pack

- **Personas** describe how a question is asked: the interviewer's style and register. **Types** describe what is being scored.
- Type key:
  - **VAL**: does your past behaviour show *Ashgrove's* published values, not generic virtue
  - **EXP**: does what you said about your experience hold up, and what was actually yours
  - **JD**: can you do the job as listed, including the gaps
  - **CO**: do you know Ashgrove's strategy and can you think at its level
  - **CASE**: structure and reasoning on a live problem from the role
- **Provenance labels:**
  - `[grounded]` traces to something you or Ashgrove supplied
  - `[inferred]` is this pack's derivation
  - `[generic]` is a role-family pattern with no claim about you or Ashgrove
- An **answer slot** is a part of an answer only you can fill. It gives two honest branches: if you did it, say how in your own words; if you didn't, or there was no such thing, say so plainly. Either branch is a good answer.
- The guidance is scaffolding, not a script. Say it your way.

---

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap: six years clears the four. Say it in your own terms, retail banking and branch supervisor for the last three years, rather than relabelling it "customer operations". Let the interviewer make that match. Answer slot: the JD's 4+ years line makes a probe on the earlier three years likely. If those years were in customer-facing roles, name them in your own words; if not, say so plainly and stay with the supervisor years |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says formal complaints log. It does not say whether those complaints came under a regulator's rules, so the bridge must not assume they did. Words at the quote's scope: "I handled the branch's formal complaints log." Answer slot: the JD's "regulated complaints" makes a probe on the rules behind the log likely. If the log was kept to a regulator's complaint rules, say which ones and what your part in meeting them was, in your own words; if it wasn't, or you don't know which rules applied, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Adjacent work, not the same work: your material says one branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If it involved decisions about the complaints in it, say which decisions were yours and how you made them, in your own words; if it didn't, say so plainly and describe what handling the log involved |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Wording cannot close this gap, and you have said so yourself. Words: "I've never worked in a contact centre." Then say how you would learn it, framed as a plan and never as a past: for example, time alongside contact-centre staff and their complaint records in your first weeks. Never claim contact-centre work, and add nothing to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says you built the spreadsheet and your regional manager uses it. It does not say what it counts, or who reports from it. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's volumes-and-resolution-times line makes a probe on what the sheet tracks likely. If it tracks volumes, resolution times or both, say which and how they are counted, in your own words; if it tracks neither, say so plainly and say what it does track |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | "Spreadsheet" is not "Excel", so the bridge does not assume the tool. Answer slot: the JD's Excel line makes a probe on the tool likely. If you built it in Excel, say so and describe what you did in it, in your own words; if you built it in another tool, name that tool plainly |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" and "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Adjacent work: your material says you trained new tellers, not supervisors, and on a script. Words: "I trained new tellers on our escalation script." Your supervisor years are a fact about the role you've held, not coaching experience, so say them that way. Answer slot: the JD's coaching line makes a probe on helping a peer likely. If you have ever helped another supervisor through an escalation, say when and what you did, in your own words; if not, say so plainly and stay with the teller training |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You have stated this gap. Words: "I've never presented to anyone above regional level." Your material does not say whether you have presented at regional level. The spreadsheet quote in F5 says your regional manager uses the sheet, not that you presented it, so don't stretch it. Answer slot: the JD's presenting line makes a probe on any presenting likely. If you have presented at regional level, say to whom and on what, in your own words; if not, say so plainly. Then say how you would prepare for a first senior presentation, framed as a plan |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. Strong evidence would be a named journey, your part in it, and what changed. Answer slot: if you have worked with a digital team or on a self-service process, say what it was and what your part was, in your own words; if not, say so plainly and say how you would bring what complaints show to a digital team |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A3, B1, D1, D3, J1, J3 |
| Report monthly on complaint volumes and resolution times | C3, G1 |
| Coach branch supervisors on escalations | C2, J2, K2 |
| Work with digital teams on self-service journeys | E1 |
| 4+ years in financial-services customer operations | A1, A4 |
| Experience handling regulated complaints | G2 |
| Confident presenting to senior leaders | B2, D2 |
| Comfortable with Excel reporting | B3 |

---

## Grounding brief (shared)

Built from the July 2026 strategy brief as you relayed it, plus the JD and values. Use Ashgrove's vocabulary when you talk about Ashgrove. Keep your own bank's vocabulary when you talk about your past.

| Item | What your inputs say | Where it can come up | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" — strategy brief, as you relayed it | E1; any self-service question; the F9 gap | [grounded] |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" — strategy brief, as you relayed it | E2, J3; the panel is two branch managers, so this is live for them. That link is this pack's reading | [inferred] |
| New product | "launch a small-business lending product in Q1 2027" — strategy brief, as you relayed it | A new product can bring new kinds of complaint. That is this pack's reading, worth one line in E1 or E2 at most | [inferred] |
| Competition | "the main competitive pressure is app-only banks" — strategy brief, as you relayed it | E1. Use it as context for why digital journeys matter, not as a claim about members | [grounded] |
| Vocabulary | The JD and values say "member", "Member Services", "self-service journeys", "hubs" | Say "members" for Ashgrove's people. Your bank's were customers, and saying so is accurate | [grounded] |
| Ownership | "member-owned, about 900 staff" — JD | A2 | [grounded] |

The brief is about four months old (July 2026), so it is current. Nothing in your inputs looks stale.

---

# Round 1: Recruiter, 30 minutes

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly openers, background, motivation, logistics | High: a recruiter screen is a conversational round by prior, and the recruiter runs it | A rehearsed 90-second background arc; treat every casual question as scored |
| Skeptic, light | Gentle checks on JD lines the background doesn't show | Medium: recruiters screen against the requirements list, and F4 and F8 are visible gaps | Plain acknowledgment, one sentence of what you do have, a plan, then stop talking |
| Others | — | Low: no case or values scoring is announced for this round | — |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | 90 seconds in three beats. One: six years in retail banking, the last three as a branch supervisor. Two: the complaints work, which is the formal complaints log you handled, the escalation script you trained new tellers on, and the monthly complaints spreadsheet you built that your regional manager uses. Say each at its own verb: handled, trained, built. Three: why this role, in your own words. Tie it to a JD line, such as owning complaints end to end, without claiming you have done that | F1, F2, F5 and F7 are your strongest rows, and the arc is the frame every later answer hangs on. EXP because the recruiter checks it against your CV |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Use two Ashgrove-specific anchors from your inputs: it is member-owned, and one value by name, such as Members First, Always ("we decide from the member's side of the counter"). Then your own reason, in your own words. Don't claim credit-union experience, since your material says retail banking | A generic answer here reads as a mass application. CO because it scores homework on this employer |
| A3 | "Tell me about your complaints work at the branch." | EXP | [grounded] "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" | Two facts, each at its own scope: you handled the branch's formal complaints log, and you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If it involved decisions about complaints, say which decisions were yours, in your own words; if not, say so plainly and describe what handling the log involved | F2, F3 and F5 carry the role's core, so a recruiter will want them in plain terms. EXP because the question checks what was yours |
| A4 | "The role asks for 4+ years in financial-services customer operations. How does your experience line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | One sentence: six years in retail banking, the last three as a branch supervisor. Let the recruiter do the matching. Answer slot: if the earlier three years were in customer-facing roles, name them; if not, say so plainly and stay with the supervisor years. Don't say "six years in customer operations" | Recruiters screen the requirements list literally, and F1 is the row it lands on. JD because it scores a stated requirement |
| A5 | "What are your salary expectations, and what's your notice period?" | JD | [generic] | Give a range you have researched and a notice period you know to be true. Answer plainly and briefly. If you need to check your contract, say so | Logistics are scored in a recruiter screen, so a vague answer costs you. `[generic]` because nothing in your inputs states pay or notice |

### Bank B: Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Lead with the plain acknowledgment, unprompted and early: "I've never worked in a contact centre." Then one sentence of what you do have, at its scope: "I handled the branch's formal complaints log." Then a one-line plan for learning the contact-centre side. Stop there; don't over-explain. This is the light version of D1 | F4 is the gap most visible from the JD's first line, so the recruiter may test it first. JD because it scores the end-to-end requirement |
| B2 | "You'd be presenting to senior leaders. Have you done much of that?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and on what, in your own words; if not, say so plainly. Then one line on how you would prepare, framed as a plan | F8 is a stated gap, and a calm answer here makes the recruiter's note neutral rather than a flag. JD because it scores a stated requirement |
| B3 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it is in Excel, say so and describe what you did in it, in your own words; if it is another tool, name it. Don't list functions you didn't use | F6 is a quick tick-box question, so give a precise answer. JD because it scores a stated requirement |
| B4 | "Why move on from branch supervision now?" | EXP | [grounded] "the last 3 as a branch supervisor" | Give your real reasons, in your own words, framed toward this role rather than away from your current one. Selection scaffold: one reason tied to a JD line, such as owning complaints beyond one branch, and one tied to Ashgrove. If your reason is simpler than that, say the simple version honestly | A motivation check every recruiter runs. EXP because it tests the consistency of your story |

### Reverse questions: Round 1

| Question | Why it lands |
|---|---|
| "How is the panel's 20-minute case run? Do I get the scenario on the day or beforehand, and is it a discussion or a role-play?" | The recruiter knows the format, and it changes how you prepare for J1 |
| "What does the Head of Member Services see as this role's first-year priority?" | It previews Round 2 and shows you're thinking past the offer |
| "Is this a new role or a backfill?" | It tells you whether you're building the complaints process or inheriting one, which reshapes D3 |
| "Do both panel members score all four values, or does each take some?" | It sharpens your values prep, and it's a fair process question |
| "What's the timeline for a decision after the 21st?" | Logistics. Recruiters expect it, and it closes the call cleanly |

---

# Round 2: Head of Member Services (your future manager), 45 minutes

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" questions, expecting specific stories | High: the recruiter says this round is "mostly behavioural" | "We" for context, "I" for your part; choose stories where your part is clear; where no story fits, say so and give the nearest one |
| Skeptic | Quiet probing of the contact-centre, presenting and scale gaps | High: a hiring manager de-risks gaps by prior, and F3, F4 and F8 are the gaps | Rehearse D1 until it's boring; name the limit before it's found; follow it with a concrete plan |
| Case / Strategist | Questions on the strategy: digital shift, hubs | Medium: hiring managers usually test live problems, but this round is mostly behavioural, so fewer than usual | Clarify first, structure second; use Ashgrove's terms |
| Data-Driven Prober | What the spreadsheet tracks, and how | Low to medium: monthly reporting is in the JD and your spreadsheet is the evidence | Know exactly what the sheet holds, and say plainly where you don't know how something was counted |

### Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a complaint escalated at your branch. What did you do?" | EXP | [grounded] "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | Selection scaffold: pick one escalation where your own part is clear. It needs the member's problem, what you did, and how it ended. Context you can state: you handled the branch's formal complaints log and trained new tellers on the escalation script. If no single escalation comes to mind, say so plainly, then describe how escalations went through the script you trained tellers on, or how you would handle one | Escalations are the JD's coaching theme, and your material names the script but no specific escalation. EXP because it tests what you actually did |
| C2 | "Tell me about a time you taught someone to handle a difficult conversation with a customer." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7, using the beats the quote states: new tellers, the escalation script, your training. Tell those in your own words. Answer slot: the JD's coaching line makes a probe on follow-up likely. If you followed up with tellers after training, say how, in your own words; if there was no follow-up, or it wasn't yours, say so plainly and stay with the training | F7 is your bridge to coaching supervisors. VAL because a manager is scoring how you develop people |
| C3 | "Tell me about something you built that other people rely on." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5. The beats the quote states: you built it, it is monthly, it covers complaints, and your regional manager uses it. Answer slot: the JD's monthly-reporting line makes a probe on what it tracks likely. Say what it holds in your own words; if it doesn't hold volumes or resolution times, say so plainly. Answer slot: if you built it because you spotted a problem, say what the problem was; if you were asked to build it, say so | F5 is the nearest evidence to the reporting requirement. EXP because a manager will check what was yours |
| C4 | "Tell me about a time you found a problem nobody had asked you to fix." | VAL | [grounded] | Selection scaffold on Own the Fix ("whoever finds the problem keeps hold of it until it is solved"). It needs a problem you found yourself, how you kept hold of it, and whether it got solved. If C3's spreadsheet came from a problem you found, it may be this story. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | This round's interviewer will likely sit in on the values too, so expect at least one value-shaped question. VAL because it maps to a published value |

### Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across branches *and* the contact centre. I don't see contact-centre work in your background. How would you own a part you haven't worked in?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | **The highest-ROI rehearsal in this pack.** Concede first, before you're asked twice: "I've never worked in a contact centre." Then what you do have, at its scope: "I handled the branch's formal complaints log." Then a plan, framed as a plan: time alongside contact-centre staff, their complaint records read next to the branches', and their supervisors asked where escalations get stuck. Follow-up 1, "how would you know what good looks like there?": hold on the plan, and say you'd learn it from the people doing it rather than claim to know it. Follow-up 2, "wouldn't a contact-centre person be safer?": don't argue the gap away. Say plainly that it's a real gap, and that you'd close it by the plan. Never say "complaints are complaints wherever they arrive", which shrinks a gap you have stated | F4 is your stated gap, and it sits on the JD's very first line, so it will be asked in some form. JD because it scores the headline requirement; Skeptic register because a future manager is pricing the risk |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" "Never worked in a contact centre" | Pick one real gap, not a disguised strength. F8 is a good pick for this question, because D1 already covers F4: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom; if not, say so plainly. Then name one concrete step you'd take before your first senior presentation | A hiring manager's standard honesty check, and both gaps are stated, so there's no reason to dodge. JD because it scores self-assessment against the listed job |
| D3 | "You've handled one branch's complaints log. What makes you ready to own the process across all of them?" | JD | [grounded] "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" | Hold only what the quotes carry: you handled the branch's formal complaints log, and you built the monthly complaints spreadsheet your regional manager uses. Don't claim the sheet covers other branches unless it does. Answer slot: if it does, say which branches and how, in your own words; if not, say so plainly. Then a plan for the first 90 days, framed as a plan: see how each branch and the contact centre log complaints today before changing anything | F3 is the scale gap. Hold through follow-ups by returning to the quotes, never by adding to them. JD because it scores the end-to-end requirement |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're moving 40% of member service to digital by 2028, and this role works with digital teams on self-service journeys. What would you bring to that?" | JD | [grounded] | No claim about your past is needed, and F9 has none to give. Structure it: (1) complaints show where a journey breaks, so you'd give digital teams what complaints show, monthly; (2) agree with them which journeys to look at first; (3) keep a clear human route for members who can't or won't use the app; (4) measure whether complaints about a journey fall after it changes. You can mention the app-only competition as context. Answer slot: if you have worked with a digital team, say so in your own words; if not, say so plainly | F9 is silent, so this answer has to be a plan. JD because it scores the digital requirement, CASE delivery because it's live reasoning on the brief |
| E2 | "Eight branches become five hubs during 2027. What would you watch in complaints while that happens?" | CO | [grounded] | Clarify first: which branches change, and when. Then: complaint volumes by branch before, during and after the change; complaints about access and travel; whether escalations rise at receiving hubs; and how clearly members were told, which is Plain Words. Close with who you'd tell, and how fast | A strategy item your future manager is living with. CO because it scores whether you can think at Ashgrove's level |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through what your monthly complaints spreadsheet tracks." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it holds, in your own words, column by column if you can. Answer slot: if it tracks volumes or resolution times, say how each is counted, what would make the count wrong, and which part of it you'd defend least; if you don't know how something was counted, say so plainly. Don't describe a measure it doesn't hold | F5 is the evidence for the reporting requirement, and a manager will check it survives detail. EXP because it tests what you built |
| G2 | "Tell me about handling regulated complaints." | JD | [grounded] "I handled the branch's formal complaints log" | Say the quote at its scope: "I handled the branch's formal complaints log." Answer slot: if the log was kept to a regulator's complaint rules, say which rules and what your part in meeting them was, in your own words; if it wasn't, or you don't know which rules applied, say so plainly and stay with the log | F2's thin bridge, rehearsed so the honest answer is ready before the probe. The question's premise is the JD's, and the guidance does not adopt it |

### Reverse questions: Round 2

| Question | Why it lands |
|---|---|
| "Today, do branches and the contact centre log complaints in one place or separately?" | It tells you where the end-to-end process starts, and it shows you're already thinking about D1's seam |
| "Who reads the monthly complaints report now, and what's a decision it has changed?" | It shows how reporting is used, and it tells you what F5's reporting would need to do |
| "Which digital team would this role work with most, and on which journey first?" | It turns the F9 gap into a working question about the job |
| "Six months in, what would tell you this hire was right?" | A future manager's own success test is the best prep for the job itself |
| "How do you expect the move to hubs to show up in complaints, and what part would you want this role to play?" | It shows you read the brief, and it's your manager's live problem |

---

# Round 3: Panel of two branch managers, 60 minutes (values round + 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One or more questions per value, scored | Highest: the recruiter says the panel "score against the four values" | One prepared story or honest scaffold per value (cheat sheet below); land the value's own words lightly |
| Case / Strategist | The 20-minute complaint-escalation case | High: the recruiter announced it | Clarify, structure, think aloud; use the build section below |
| Peer Evaluator | Where your role meets theirs; coaching their supervisors | Medium: the panel are branch managers, and the JD has this role coaching their supervisors, so they'll price what you add to or take from their teams | Seam principles rather than pretending to know the seam; what you'd give them, not only what you'd need |
| Pressure | Push-back inside the case ("the member won't accept that") | Low: nothing announced, but case follow-ups often push | Pause, restate, hold the member-first position through two follow-ups, then concede specifics |

### Graded deliverable: the 20-minute complaint-escalation case

**Grounded facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| "a 20-minute case on a complaint escalation" | Recruiter's email | [grounded] |
| "they score against the four values" | Recruiter's email | [grounded] |
| "Own the member complaints process end to end" and "coach branch supervisors on escalations" | JD | [grounded] |
| F7: "trained new tellers on our escalation script" | Your message | [grounded] |
| F2: "I handled the branch's formal complaints log" | Your message | [grounded] |

The case asks about a live problem, not your past, so you don't need to claim anything. If you do draw on your past, use only F7's or F2's words above.

**Structure for 20 minutes**

| Minutes | Step | Value it lands | Provenance |
|---|---|---|---|
| 0–2 | Say your structure out loud. Ask two or three clarifying questions: what does the member want; what has happened so far; are any time limits or required steps in play for this complaint | — | [generic] |
| 2–5 | The member first: who contacts them, today, with a named owner and what happens next. Say what happens next, not the outcome | Members First, Always | [generic] |
| 5–9 | Facts: what the branch record shows, who was involved, where the first handling stopped working | Own the Fix | [generic] |
| 9–13 | Resolve and respond: the decision, and the response in words the member won't need explained twice | Plain Words | [generic] |
| 13–17 | Fix the cause: if it's local, fix it with the branch supervisor, coached; if every branch does it, it's a process change you own | Own the Fix, Neighbours, Not Numbers | [generic] |
| 17–20 | Close: what you'd record, how it shows up in the monthly report, what you'd coach the supervisor on next time | Own the Fix | [generic] |

**Theses, each with its concession**

| Thesis | Mandatory concession | Provenance |
|---|---|---|
| Contact the member before the investigation is finished: a named owner and a next step, the same day | Speaking before you have the facts risks promising what you can't deliver, so promise only the next step | [generic] |
| The written response is the test: if the member would need it explained twice, rewrite it | A regulated complaint response may have content it must include, and plain words can't drop that. Ask the panel what must be in it | [generic] |
| Fix the cause where it lives: the branch supervisor fixes a local cause with you coaching them, so it doesn't vanish into a central team | If the same fault is in every branch, a local fix isn't enough. Then it's a process change you'd own across branches | [generic] |

**Differentiation.** The consensus answer is apologise, investigate, resolve, close. Diverge from it by treating the escalation as two problems: this member, and *why it escalated at all*, meaning where the first handling stopped working. Then close on coaching the supervisor. That is the JD's coaching line, and the step most candidates skip.

**Anti-pick.** Don't offer compensation or promise an outcome before you have the facts. Don't take the complaint away from the branch by default; say when you would and when you wouldn't.

**Close.** The panel scores the four values, so name a value only where it actually drives a step. Name each once, briefly; four slogans recited at the end score worse.

### Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold for Members First, Always. It needs a decision, not just good service, where the customer's side won over something easier for the bank or for you. Say "customer" for your bank's people; that's accurate. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the formal complaints log you handled, or how you would handle it | The first value, and the one the case also scores. VAL because it maps to a published value |
| H2 | "Tell me about a time you explained something so someone got it first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7, using the beats the quote states: new tellers, the escalation script, your training. Answer slot: Plain Words ("if a member needs it explained twice, we wrote it wrong") makes a probe on changing the wording likely. If you changed how the script or your training was worded so it didn't need explaining twice, and that was yours, say what changed; if not, say so plainly and describe the training | F7 is the nearest story for Plain Words. VAL because it maps to a published value |
| H3 | "Tell me about a time your branch's place in its town changed how you handled something." | VAL | [grounded] "the last 3 as a branch supervisor" | Selection scaffold for Neighbours, Not Numbers. It needs a local fact about the branch's town or its people that changed what you did. If no such time comes to mind, say so plainly, then say how you'd keep a branch's local knowledge in play as branches become hubs | Two branch managers will weigh this value heavily, and the hubs plan makes it live. VAL because it maps to a published value |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Own the Fix. Answer slot: if you built the spreadsheet because you found a problem, say what the problem was and how you kept hold of it until it was solved, in your own words; if you were asked to build it, or it didn't come from a problem, say so plainly and pick another story. It needs a problem you found, a time you could have handed it off, and an outcome | The value closest to the role's own mandate. VAL because it maps to a published value |

### Bank J: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Here's a complaint that has escalated. You have 20 minutes. Talk us through what you'd do." | CASE | [generic] | Use the build section above: say the structure first, clarify, member first, facts, resolve in plain words, fix the cause, close with the report and the coaching. Check the time at about 10 minutes. When pushed ("the member won't accept that"), pause, restate, and hold on the member-first step through two follow-ups before conceding specifics | The announced graded case. `[generic]` because the scenario arrives on the day |
| J2 | "One of my supervisors escalates a complaint to you that they think is unreasonable, and the member wants it taken further. What do you do?" | CASE | [generic] | Separate the two things: the member's complaint, which gets a fair look whatever the supervisor thinks, and the supervisor, who gets coached rather than overruled in front of the member. Say how you'd keep the branch manager informed | A likely variant from two branch managers, testing the coaching line. CASE because it's a live problem |
| J3 | "A branch is becoming part of a hub, and members are complaining that they've lost their local branch. How do you handle it?" | CO | [grounded] | Clarify what's changing and when. Members first: reply in plain words about what stays and what moves. Neighbours, Not Numbers: what of the branch's local role can the hub keep. Own the Fix: feed the pattern to whoever runs the consolidation, and track it monthly | Grounded in "consolidate eight branches into five hubs over 2027". CO because it scores whether you can think about Ashgrove's real strategy |

### Bank K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You'd own complaints across our branches. Where does your job end and mine begin?" | JD | [generic] | Propose principles, not a seam you can't know yet: the branch keeps the member relationship and the first fix; you own the process, the record and the cross-branch pattern; complaints that need a decision above the branch come to you. Then ask what they'd want. Reciprocity: what you'd give them, such as a monthly picture of their own branch's complaints | Branch managers are pricing whether you add to or take from their teams. JD because it scores the end-to-end requirement |
| K2 | "How would you coach one of my supervisors without undermining me?" | JD | [grounded] "the last 3 as a branch supervisor" | You can state that you've been a branch supervisor for the last three years. Say it as a fact about your role, not as a claim about being coached. Plan: agree the coaching with the branch manager first, coach on real escalations, and tell the manager what you saw | F7's requirement, asked by the people whose supervisors you'd coach. JD because it scores the coaching requirement |

### Values cheat sheet

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's point of view | F2: "I handled the branch's formal complaints log". This is context, not a story. Selection scaffold: a decision where the customer's side won. If none comes to mind, say so plainly and give the nearest thing, or how you'd handle it (H1) |
| Plain Words | Needing to explain something twice is the writer's fault | F7: "trained new tellers on our escalation script". Story-mapped. Answer slot on whether the wording changed and whether that was yours (H2) |
| Neighbours, Not Numbers | Each branch belongs to its town | F1: "the last 3 as a branch supervisor". Context only. Selection scaffold: a local fact that changed what you did. If none comes to mind, say so plainly and give how you'd keep local knowledge through the move to hubs (H3) |
| Own the Fix | Whoever finds a problem keeps it until it's solved | F5: "I built the monthly complaints spreadsheet our regional manager uses". Answer slot on whether it came from a problem you found. If not, pick another story with the scaffold (H4) |

### Reverse questions: Round 3

| Question | Why it lands |
|---|---|
| "What would you want from a complaints lead that you don't get today?" | Reciprocity: it tells two future stakeholders you're there to reduce their load |
| "When an escalation goes wrong at your branch now, where does it usually go wrong?" | It's the real version of the case, and their answer is your first-90-days plan |
| "How do your supervisors handle escalations today: a script, their own judgment, or a call to you?" | It's directly about the coaching line, and it lets you compare with your own script experience |
| "As branches become hubs, what do you most want to protect about your branch's place in its town?" | It's Neighbours, Not Numbers turned into a question, about something live for them |
| "What does a good month for complaints look like at your branch?" | It tells you what they'd measure you by, and it's an easy question for them to answer well |

---

## Prohibited claims (shared)

These are the claims this pack will not coach, because each one fails on the first follow-up.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process, at one branch or across several | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is this pack's observation, not words for you: the material says a log, not a process |
| Resolved the branch's complaints | Inflated form of F2 (handling a log changes kind) | F2's quote: "I handled the branch's formal complaints log." F3's slot stays inside what handling the log involved |
| Reported monthly to leadership on complaint volumes and resolution times | Inflated form of F5 | F5's quote: "I built the monthly complaints spreadsheet our regional manager uses." G1's slot asks only what the sheet tracks |
| Wrote or designed the escalation script | Inflated form of F7 (verb drift: "our" script, not yours) | F7's quote: "trained new tellers on our escalation script" |
| Coached branch supervisors | Inflated form of F7 | F7's quote at its scope, about tellers |
| Six years as a supervisor, or six years in customer operations | Inflated form of F1 | F1's quote: "6 years in retail banking, the last 3 as a branch supervisor" |
| Has contact-centre experience | A negative you stated, F4 | "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F8 | "I've never presented to anyone above regional level." No slot on senior presenting |

---

## Sources (shared)

**Provided documents**
- Job description, pasted.
- Values text, pasted. You copied it on 12 November 2026 from ashgrovecu.org/about/values; the page itself was not fetched.
- Recruiter's email on the process, pasted.
- The July 2026 strategy brief, as you relayed it in four points. The brief's own text is not in hand.
- Your background, from your message.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted this morning fixes the cheat sheet and the H bank |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email fixes all three rounds, the case and the values scoring |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief, under six months old, fixes the grounding brief and E1, E2 and J3 |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names have been assigned, so there was no query to form. The interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Interviewer names, once assigned → a public-footprint read of each interviewer, persona weights per panel member, and one reverse question per round tied to that person's path
- The full strategy brief text → the grounding brief in Ashgrove's own headline numbers and phrasing, not your four-point summary
- A blank or anonymised copy of your monthly complaints spreadsheet's layout, with no member data → F5 and F6 move from `medium` toward `high`, because the layout is the inspectable proof in this field, and G1 becomes a walkthrough
- Your CV → F1's earlier three years get named, and the pack can check that your spoken arc matches what the panel has read
- Your answers to the answer slots in F1, F2, F3, F5, F6, F7, F8 and F9 → those rows and the questions drawing on them (A1, A3, A4, B2, B3, C2, C3, D2, D3, E1, G1, G2, H2, H4) regenerate as story-mapped guidance
- The case format from the recruiter (scenario in advance or on the day; discussion or role-play) → the build section and J1 retuned to the real format
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → recent Ashgrove news on the hubs and the lending launch, plus any candidate reports on its interviews, labelled by source quality
- A tuesday-dossier.md from job-underwriter → the highest-ROI objection derived from evidence you confirmed, rather than inferred here, plus a prohibited list checked against your own corrections. Not needed for this pack
