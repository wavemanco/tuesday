Quick update: I've read the mock-interview playbook and its rules. Next I'll run a small, capped research pass on Northwind's values, interview loop, and Dan's public profile, then build the pack.
I've built Priya's prep pack for the 60-minute peer conversation with Dan, saved as `northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. I couldn't do any outside research because the web searches weren't permitted, so the pack uses only your notes. The parts about Northwind's strategy come from your research note.

**What's in it:**
- **21 questions across seven interviewer personas,** weighted for Dan. A peer round with a self-described "relentlessly data-driven" interviewer puts the persona who probes every number on top. His pricing and monetization background tilts the case questions toward packaging and bundling, and his startup chapter adds a probe on working with fewer resources.
- **Each question is tagged by type** (behavioral, work experience, role requirements, company strategy, live case). Each row has answer guidance, the exact words from your notes it relies on, and a rationale for including and categorizing it.
- **Highest-priority rehearsal is D1:** "consumer tech and no sales-ops or quota-setting — why you for enterprise GTM?" Dan's function sits right next to that gap.
- **Partner-motion design is the one requirement the JD marks "required".** Her closest evidence is the partner-level revenue model, and the pack keeps her wording at that scope rather than calling it a partner program.
- **The ~$400M uplift gets several questions on how it was counted and how much was hers.** The pack keeps her verbs: she "proposed" the change and it was "credited". Where it can't know a fact, such as how the number was counted, it leaves a gap for her to fill from what actually happened.
- **The rest of the pack:** a requirement-coverage table, six questions for Priya to ask Dan (two tied to his background, one about how she could help his team), and a list of claims she shouldn't make.

**What I left out:** there's no values cheat sheet, because there's no values round in this session and no values page in hand. There's no prep schedule because prep time wasn't given.

If you want, I'll play Dan on D1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Session:** one 60-minute conversation with **Dan Kovac, Director of Sales Strategy**. He would be a **peer**, reporting to the same VP.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who is asking, and in what register. **Types** describe *what* is being scored. Each question carries both.
- **Guidance is scaffolding, not a script.** Rehearse the beats out loud in your own words. Where a cell says **answer slot**, the pack doesn't know the fact. Answer from what actually happened. If the thing never happened or wasn't yours, say so plainly. That is a complete answer.
- **Provenance** shows where each row comes from. `[grounded]` means it traces to the coach's notes or the research note supplied. `[inferred]` means it is this pack's own derivation, and the derivation is named. `[generic]` means it is a role-family pattern with no claim about Priya or Northwind.
- Question IDs go by persona. The letter **F** is skipped so it can't be confused with the fit-snapshot rows F1–F7.

| Type tag | What it scores |
|---|---|
| **VAL** | Behavioral or values alignment: past behavior against stated values or working style |
| **EXP** | Work-experience deep-dive: whether the claims survive scrutiny, and what was actually hers |
| **JD** | Role and JD: can she do the listed job, gaps included |
| **CO** | Company and strategy: Northwind's priorities, competition, altitude |
| **CASE** | A live problem from the actual role, structured and reasoned out loud |

---

## Fit snapshot

The requirements come from the JD highlights supplied. Evidence is quoted exactly from the coach's notes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material shows product strategy and ops at a consumer-tech company and a change you proposed. It doesn't show owning go-to-market for a new B2B product line. The words stay at the quotes' scope: "Nine years in product strategy and ops at a large consumer-tech company. I proposed a store-surface change that was credited with about a $400M ARR uplift." Answer slot: the JD's "own GTM strategy" line makes a probe on launches likely. If a launch's go-to-market plan was yours to set, say which one and what you decided, in your own words. If none was, say so plainly and stay with the product-strategy work you did |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD | none given | none | [grounded] | discovery | Your material says nothing about lifecycle or whitespace analysis. Strong evidence would be a time you found an under-served segment or pocket in data and a plan changed because of it. Answer slot: if you have done analysis that found where customers or partners were under-penetrated, say what you looked at and what changed, in your own words. If you haven't, say so plainly and walk through how you would cut Northwind's base by land, adopt, expand and renew (C3) |
| F3 | "run independent analysis in SQL and Tableau" — JD | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. But this is a stated skill with nothing inspected behind it, and a self-described data-driven interviewer will probe it. Lead with the skill in the quote's own terms. Answer slot: the JD's word "independent" makes "did you write the queries yourself" likely. If you did, say on what. If an analyst team did that part, say so plainly |
| F4 | "partner-motion design experience required" — JD | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a partner-level revenue model, not the design of a partner motion. The words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on whether you designed how partners go to market likely. If any part of how those carrier partnerships were structured was yours, say which, in your own words. If none was, or there was no such structure, say so plainly and stay with the model you built |
| F5 | "strong cross-functional influence" — JD | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only the quote: "I set the annual volume targets, with cross-org consensus." Add nothing to it |
| F6 | "AI experience a plus" — JD | "uses AI tools daily" — the coach's notes | low | [inferred] | transferability | Daily tool use sits next to the JD's "AI experience" but doesn't reach it. Inferred because the bridge from tool use to AI experience is this pack's derivation. Words: "I use AI tools daily." Answer slot: if you use them in analysis or strategy work, say on what, in your own words. If not, say so and stay with daily use |
| F7 | Sales-ops and quota-setting mechanics, adjacent to the interviewer's sales-strategy function. A role-family pattern, not in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | No wording closes this gap, and it is already stated. Words: "I haven't done classic sales-ops or quota-setting." Then how you would learn it, said as a plan and never as a past. Never present the annual volume targets (F5) as quotas, and add nothing to make the gap feel smaller |

---

## Reading the interviewer

Everything here comes from the profile summary in the coach's notes. A web search for Dan's public footprint was refused (see Sources), so none of his talks or posts are reflected.

| Signal | Implication for this session | Provenance |
|---|---|---|
| Self-describes as "relentlessly data-driven" | Data-Driven Prober goes up to top weight. Every figure will be probed back to its assumptions, starting with the ~$400M (A1, A2, E2) | [grounded] |
| Career spine is "pricing and monetization roles" | Tilt the cases toward pricing, packaging and unit economics (C1, C2). Expect revenue-model vocabulary | [grounded] |
| "one early-stage-startup chapter" | Builder stories land well. Expect a scrappiness probe and some skepticism about big-company pace (D3) | [grounded] |
| Peer, same VP | Partnership fit gets scored: the seam, credit, whether the hire adds to his load or lightens it (bank B) | [grounded] |
| Director of Sales Strategy | This function tends to sit closest to sales-ops and quota mechanics, which is F7's gap. Go for calibrated candor here. Bluffing a competency the interviewer's own function owns fails fast | [generic] |
| Mirror opportunity: shared vocabulary | His pricing and monetization path pairs with F4's "built a partner-level revenue model used in carrier negotiations". Talk inputs, outputs and decisions in revenue-model terms. No shared career jump is offered, because nothing in Priya's material corresponds to his startup chapter | [grounded] |

---

## Persona table

The relationship prior for a peer round is Peer Evaluator plus Data-Driven Prober. Dan's signals then adjust it. The coach's notes establish the loop for this session (one 60-minute conversation with a peer), so no archetype fallback is used.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| A. Data-Driven Prober | "How was that counted?" Two levels below every number | **Highest.** The peer prior plus the "relentlessly data-driven" self-description | Know what you can and can't say about how each number was counted. Name your weakest assumption first. Offer to walk through an analysis you ran yourself | 5 |
| B. Peer Evaluator | The seam between Sales Strategy and Emerging Products, credit, "what do you need from me" | **High.** The dominant prior for a peer with the same VP | Reciprocity: what you bring his team. Propose seam *principles*, not the seam | 4 |
| C. Case / Strategist | Live pricing, packaging and bundling problems | **Mid.** The pricing career tilts the cases and the research note supplies the topics | Clarify, objective, segment, approach, metrics, risks. Use his vocabulary. Challenge one premise | 3 |
| D. Skeptic | Consumer to B2B, no sales-ops, "why you" | **Mid.** F1, F4 and F7 are the gaps, and the startup chapter brings the scrappiness probe | Rehearse D1 until it's boring. Acknowledge first, then the quotes at their scope, then the ramp plan | 3 |
| E. Pressure | Time-boxed "why you", "how much was you" | **Low.** Peers rarely run stress-style, but a data-driven peer may press on attribution | Pause and restate. Hold through two follow-ups. Concede specifically | 2 |
| G. Conversational | Opening "walk me through", casual AI chat | **Low.** The opener is likely, and the AI plus is asked casually but still scored | A 90-second arc. Treat casual AI questions as scored | 2 |
| H. Values / Behavioral | Influence and hard-truth stories | **Low.** No values round in this session and no values page in hand | "We" for context, "I" for contribution | 2 |

---

## Question banks

**Highest-ROI prep in this pack: D1.** Dan will ask it in some form.

### A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift on the store-surface change was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F1: the change you proposed, and that it was credited with about $400M ARR uplift. Keep both of the quote's verbs, "proposed" and "credited". Then the defend-the-number slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you'd defend least, named before Dan names it; and which part was yours. If you don't know how it was counted, say so plainly and return to what you proposed and why. Never describe a counting method you couldn't repeat under a second question | F1 holds the only headline figure, and Dan's self-description makes it the first probe. EXP because it scores whether the number survives and who owns it |
| A2 | "ARR is a subscription metric. What did it actually measure in a store context?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot on how it was counted: if you know what the ARR label measured in that business, say it in your own words. If the label belonged to finance and you don't know its definition, say so plainly and return to the change you proposed. Don't improvise a definition | A monetization specialist at a B2B SaaS company will notice an ARR figure from a consumer store surface. EXP because it tests whether the figure in F1 holds up under its own definition |
| A3 | "Walk me through the partner-level revenue model you built: inputs, outputs, and how it got used." | EXP, JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, with three beats the quote states: you built it, it was partner-level, and it was used in carrier negotiations. Answer slot on inputs and structure: if you can describe them end to end, do it in your own words and offer to sketch it on the spot. If parts were inherited or someone else's, say which. Answer slot on use: if you were part of the negotiations, say in what role. If you weren't, say so plainly: the model was used in them | F4 is the closest evidence to the one requirement marked "required", and a prober pushes from "built" to "used how". EXP first because it scores what was hers. JD second because it feeds partner-motion design |
| A4 | "Give me one analysis you ran yourself in SQL and Tableau: the question, the data, what changed." | JD, EXP | [grounded] "skilled in SQL/Tableau" | Lead with F3 in the quote's terms. Selection scaffold: pick an analysis with a question you chose, data you pulled yourself, a view you built, and a decision that moved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD says "independent", and F3 is a stated skill with nothing inspected behind it. JD first because it scores the listed requirement directly |
| A5 | "How did you set the annual volume targets, and how did you know they were right?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: you set annual volume targets, with cross-org consensus. Answer slot on method: if there was one, describe it in your own words. If the method was someone else's, or there wasn't a formal one, say so plainly. Answer slot on outcome: if you tracked actuals against the targets, say how they landed. If you didn't or don't know, say so. Never call them quotas (Prohibited claims) | F5 is where Dan's sales-strategy lens first meets F7's gap, so target-setting gets probed from the quota side. EXP because it tests the claim, not the requirement |

### B. Peer Evaluator (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We'd both report to the same VP. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose principles and invite correction rather than claiming to know the seam. As a hypothesis: Emerging Products owns the GTM thesis for the two new lines, and Sales Strategy owns how it lands in the core sales system. On disagreement: agree on the data first, write down the decision rule, and go to the VP only last and together. If useful, point to F5 in its own words: "I set the annual volume targets, with cross-org consensus." Close with what you'd bring his team | Seam-splitting is the core peer-evaluator probe, and the JD asks for "strong cross-functional influence". JD because it scores that requirement in a peer register |
| B2 | "Tell me about a time you disagreed with a peer at your level and the data didn't settle it." | EXP | [generic] | Selection scaffold: pick a disagreement with an equal, not a boss. It needs a real stake, a moment you held your view, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement style with equals is what a peer scores, and nothing in Priya's material carries a story here, hence the scaffold. EXP because it is about her past, and no published values were in hand to make it VAL |
| B3 | "What would you need from my team in your first 90 days, and what would you give us back?" | JD | [grounded] "skilled in SQL/Tableau"; "No classic sales-ops or quota-setting experience." | Ask: data access, a seat in the planning calendar, and a walkthrough of how targets get set at Northwind. Here F7's acknowledgment fits naturally: "I haven't done classic sales-ops or quota-setting, so I'd want to learn your planning process from you." Give: analysis in SQL and Tableau that you run yourself, so you aren't queuing on his analysts | A reciprocity probe that turns F7's gap into collaboration and F3's skill into value for his team. JD because it scores how she'd operate in the role |
| B4 | "Say a partner brings in an enterprise deal for one of the new products. Who gets credit, your team or mine?" | CASE, JD | [generic] | Principles, not turf. Agree attribution rules before the partner motion launches, not after the first deal. Define partner-sourced versus partner-influenced together. Put both teams on one shared dashboard. Then hold the line that credit disputes get settled by the rule, not by the deal | Credit-sharing is a standard peer probe, and the JD requires partner-motion design. CASE delivery because it's a live hypothetical. JD content because partner attribution is part of designing the motion |

### C. Case / Strategist (mid weight, tilted to pricing)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles something that overlaps one of our new lines at near-zero price. How do we respond, in GTM and in pricing?" | CASE, CO | [grounded] | Clarify: which line, which segment, and is the bundled version good enough for whom. Objective: Northwind's profitability priority rules out a price war. Segment: customers already on that vendor's platform versus not, and land versus expand. Options: differentiate where the bundle is weakest; package the line with the core product or Compass; use a partner motion the bundler can't easily copy. Metrics: win rate against the bundle, discount depth, retention in exposed accounts. Challenge one premise: whether to contest every segment at all. Name the segment you'd concede | The research note names bundling by a larger platform vendor as the main threat and profitability as a priority. CASE because it's a live problem. CO because it scores whether she can think at Northwind's altitude |
| C2 | "How would you package and price Compass, the AI copilot: standalone, add-on, or bundled, given the push to profitability?" | CASE, CO | [grounded] | Clarify: who buys, who uses, and what it costs to serve. Options and trade-offs: an add-on protects margin, bundling drives adoption, standalone tests willingness to pay. Tie it to enterprise expansion by treating Compass as an expand lever. Metrics: attach rate, expansion revenue, gross margin on the AI line. Name the assumption you're least sure of. Speak his language on unit economics rather than claiming pricing experience you haven't stated | Compass, enterprise expansion and profitability are the research note's three priorities, and Dan's career is pricing. CASE and CO for the same reasons as C1. It also covers the JD's AI plus from the strategy side |
| C3 | "Sketch how you'd find whitespace for one new product line across land, adopt, expand and renew. What data, what cuts, what's the first query?" | CASE, JD | [generic] | Clarify how Northwind defines each stage. Data: product usage, CRM opportunities, billing. Cuts by segment and by install base of the core product. Land: fit accounts without the line. Adopt: bought but low usage. Expand: heavy usage or adjacent teams. Renew: risk signals. First query: penetration of the new line across the core install base, by segment. Output: a ranked whitespace view in Tableau. This also answers F2's slot if you have no past example | F2 is the JD requirement with no evidence, so a live case is the honest place to show it. CASE delivery, JD content. Generic because it is a pattern for the problem, not a claim about Northwind's data |

### D. Skeptic (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background is consumer tech, and you haven't done sales-ops or quota-setting. Why are you the right person to build GTM for enterprise data-infrastructure products?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Acknowledge first, exactly: "That's right, I haven't done classic sales-ops or quota-setting." Then what the material carries, at its own scope: "I spent nine years in product strategy and ops at a large consumer-tech company, after two in strategy consulting. I built a partner-level revenue model used in carrier negotiations, and I set annual volume targets with cross-org consensus." Let Dan draw the inference, and don't say it's "basically the same thing". Then the ramp, as a plan: learn Northwind's planning and target process from his team, run your own whitespace cut, bring a first partner-motion hypothesis. **Follow-up 1**, "enterprise buying is different": hold without claiming B2B experience. Answer slot: if working on the carrier model taught you how carriers made decisions, say what, in your own words. If you weren't close to that, say so plainly. **Follow-up 2**, "so who sets the targets for these lines?": propose that Sales Strategy owns them and you supply the analysis. Concede specifically: "The sales-planning mechanics are a real ramp for me, and that's where I'd lean on your team." Never call the volume targets quotas, or the revenue model a partner program | F1, F4 and F7 meet in this one question, and a sales-strategy peer is the person likeliest to ask it. JD because it scores whether she can do the listed job despite the stated gap |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations" | Name one real weakness, not a disguised strength. The one already stated is F7: "I haven't done classic sales-ops or quota-setting." If you'd rather name a JD line, choose honestly between the thinnest rows (F2, F4) in your own words. For F4, stay with the quote: "I built a partner-level revenue model used in carrier negotiations." Let Dan see the distance from there to motion design without narrating it as a confession. End with the specific ramp for whichever you name | A standard skeptic stem, and F2, F4 and F7 give it real targets. JD because it scores self-assessment against the listed requirements |
| D3 | "Northwind is about 3,000 people and pushing to profitability. How would you operate in an emerging-products team that may not have dedicated analysts or ops behind it?" | JD, CO | [grounded] "skilled in SQL/Tableau" | Open with F3: you can run your own SQL and Tableau analysis instead of waiting in a queue. Selection scaffold for the past: pick a time you moved something forward without the full machine behind you. It needs a constraint, what you did yourself, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Dan's startup chapter makes a scrappiness probe likely, and profitability comes from the research note. JD first because it is about how she'd do the job. CO because it uses Northwind's context |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who's already run partner programs at a SaaS company?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau"; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Pause, then restate the question. Three beats, from the quotes only: nine years in product strategy and ops after two in consulting; the partner-level revenue model used in carrier negotiations; and SQL and Tableau you run yourself. Hold through two follow-ups by returning to these, never by adding to them. Concede specifically: "Someone who's run SaaS partner programs knows that playbook sooner." Don't fold on the analytical case | F4's gap is the obvious attack line, and the "required" marker on partner-motion invites it. JD because it scores fit to the requirement under time pressure |
| E2 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change, and it was credited with about $400M ARR uplift." Answer slot: if your part went past the proposal, say exactly what it was, in your own words. If your part was the proposal, say that plainly. It's a complete answer. On a second push ("so others did the work?"), hold the proposal as yours and concede the execution share specifically. Never fold on having proposed it | A persona stem aimed straight at F1's headline figure. EXP because it is pure attribution honesty |

### G. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey: consulting, consumer tech, and now this." | EXP, CO | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with beats from the quote: two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company. Answer slot: why move to B2B emerging products now, in your own words. Close on why Northwind specifically, tied to one research-note priority: enterprise expansion, Compass or profitability | The likely opener. A casual register is still scored on economy and on motivation. EXP for the history. CO for the "why Northwind" close |
| G2 | "What are you actually playing with in AI these days?" | JD, CO | [inferred] "uses AI tools daily" | Casual but scored, since this is the JD's AI plus. Words: "I use AI tools daily." Answer slot: which tools and on what work, in your own words. If you don't use them in analysis, say so and stay with daily use. Then turn it outward with a genuine question about how Compass changes the sales motion. Never imply you've built or launched AI products | F6 is low-confidence, hence inferred. The derivation is from daily tool use to the JD's "AI experience". JD because the plus is a listed requirement. CO because of the Compass turn |

### H. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you got teams you didn't manage to agree on something." | JD, VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: you set annual volume targets, with cross-org consensus. Those are the beats the quote states. Answer slot: how the consensus was reached. If there was resistance, say what it was and what you did, in your own words. If it came easily, say so. "We" for context, "I" for your part | The JD names "strong cross-functional influence" and F5 is its evidence. JD first because a listed requirement themes it. VAL delivery because it's a behavioral story |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time when the message was unwelcome, you said it anyway, and it landed or changed something. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Don't supply an ending the story didn't have | A persona stem. A data-driven peer will want to see that she follows evidence upward. VAL because it scores behavior. Generic because no Northwind values page was in hand |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own GTM strategy for two new product lines (F1) | D1, D3, C1, C2 |
| Whitespace across land/adopt/expand/renew (F2) | C3 |
| Independent analysis in SQL and Tableau (F3) | A4, B3, D3 |
| Partner-motion design, required (F4) | A3, B4, E1, D2 |
| Strong cross-functional influence (F5) | H1, B1, A5 |
| AI experience, a plus (F6) | G2, C2 |
| Company priorities and competitive threat (research note) | C1, C2, G1 |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "You've spent your career in pricing and monetization. Where's the Compass packaging debate still genuinely open?" | Ties to his path and pulls him into his own expertise |
| R2 | "You've had an early-stage startup chapter. What from that would you want an emerging-products team here to borrow?" | Ties to his path and frames the scrappiness question as one you're already asking |
| R3 | "What could I do in my first month that would genuinely help your team?" | The peer reciprocity question. It signals you'd reduce his load |
| R4 | "When the larger platform vendor bundles against us, where does Sales Strategy feel it first: win rates, discounting, or renewals?" | Shows the homework, and it's a data question he'll enjoy answering |
| R5 | "How does the VP split GTM work between Sales Strategy and Emerging Products today, and where has that seam been fuzzy?" | Gets real seam information before you'd need it, and asks it collegially |
| R6 | "What data would I be able to query directly from day one, and where's it weakest?" | Speaks to his data-driven self-description and to the JD's "independent" analysis |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has done sales-ops or set quotas, or presents the annual volume targets as quotas | Negative stated in the coach's notes, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting." F5's quote stays at its own scope: annual volume targets |
| Designed a partner motion or partner program, or led the carrier negotiations | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation, not words for Priya: the material says a model used in negotiations, not a motion design or a seat at the table. A3's slot stays inside the model |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F1 | F1's quote at its own scope: proposed, and credited. A1 and E2's slots ask only which part was hers |
| Owned enterprise or B2B GTM strategy | Inflated form of F1 | F1's quotes at their scope: product strategy and ops at a consumer-tech company |
| Has AI product or AI GTM experience | Inflated form of F6 | F6's quote: "I use AI tools daily." G2's slot asks only which tools and on what |

---

## Sources

**Provided documents:** the coach's notes in this conversation. They supplied the role and JD highlights, Priya's background, the interviewer's profile summary, and a research note (three priorities and the main competitive threat).

**Searches sent:**
- `"Northwind Data" company values`: refused (the web-search permission wasn't granted)
- `"Northwind Data" interview process GTM strategy`: refused
- `"Dan Kovac" Northwind Data sales strategy`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Search refused. It would have themed H1 and H2 on Northwind's own value names. No values-style round is in this session, so no cheat sheet was needed |
| 2. Northwind Data interview process, GTM strategy | unavailable | Search refused. It would have shown the rest of the loop. This session's weights rest on the coach's notes, which establish one 60-minute peer conversation |
| 3. Northwind Data strategy and recent news | skipped | The research note in the coach's notes supplies the priorities and the competitive threat behind C1, C2 and G1 |
| 4. Dan Kovac, Northwind Data | unavailable | Search refused. It would have added his talks or posts to the interviewer read and possibly a reverse question |
| 5. Representative JD for the title | skipped | The JD highlights supplied set the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text:** any mid-list requirements, named tools or methods get their own fit rows and questions. The pack currently rests on six highlights.
- **Priya's own answers to the answer slots:** how the ~$400M was counted and what her part was, how the revenue model was structured and used, whether any lifecycle analysis exists. These upgrade A1, A2, A3, A5, E2, D1 and F2 from slots to story-mapped guidance.
- **An inspectable artifact:** a sanitized strategy memo, model or Tableau dashboard she built would raise F3 and F4 from medium to high, and gives A3 and A4 something to walk through.
- **The recruiter's prep email:** focus areas for Dan's conversation, any pre-declared deliverable, and the rest of the loop.
- **Web search permission:** retries targets 1, 2 and 4: Northwind's value names, its loop structure, and Dan's public talks or posts.
- **Deep research pass (L2):** up to 6 more searches and 2 more fetches, several more minutes. Adds a fuller strategy brief, bundling and competitor detail, and recent org context to sharpen C1 and C2.
- **Prep time available:** adds a prioritized prep-triage schedule.
- **The schedule of other rounds, if any:** per-round mini-packs with their own persona weights.
- **A tuesday-dossier.md from an earlier fit assessment:** would replace this pack's inferred highest-ROI objection with an evidence-derived one, and bring verified evidence and a prohibited-claims list from that assessment.
