I've read the prep playbook and am now running a few quick searches on Saltmarsh Games and Tobias Wrenfield before I build your pack.
Web search was blocked by permissions, so I'm building the pack from your JD and background only.
I've built your prep pack: 22 practice questions across seven interviewer styles, with answer guidance for each. It's saved as saltmarsh-games_live-operations-producer_interview_pack.md.

- **Assumption:** I treated Tobias as your future manager, since you didn't say.
- **No research:** web search was blocked in this session. Nothing in the pack comes from Saltmarsh's site, its news or Tobias's public profile.
- **Your strongest match:** two years running the weekly content-drop calendar lines up directly with the JD's "experience running a content calendar."
- **Most important question to practise (B1):** going from associate producer to coordinating design, art, engineering and community on two titles.
- **Second most important (B2):** in-app purchases. Since you've said you haven't worked on a game with them, the pack coaches a plain "no" followed by how you'd get up to speed.
- **Biggest easy win for B4:** if you haven't played Saltmarsh's two games, play them tonight.

If you'd like, I'll play the sceptical interviewer on B1 and push back on your answers.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias your future manager, and did the recruiter mention any focus areas or an exercise (for example, an event plan)? Either answer changes which question types the pack prioritises.
2. Do you want to allow web search? That would add Saltmarsh's values, news and Tobias's public background to the pack.
3. How many hours do you have before Friday? I'll add a prioritised prep schedule to fit.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Format:** one 60-minute interview, Friday
- **Relationship (assumed):** hiring manager. You didn't say so, but the Head of Live Operations is the likeliest manager for this role. If that's wrong, the persona weights below change.
- **Research:** none. Web search was blocked by permissions in this session, so nothing here comes from Saltmarsh's website, news, or Tobias's public profile. Everything about the company is labelled `[generic]`.

---

## How to use this pack

Two separate things describe each question:

- **Personas** describe *how* a question gets asked: friendly, probing, time-pressured, sceptical.
- **Types** describe *what* is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values they care about |
| EXP | Whether your stated experience holds up, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | How well you know the company and its games |
| CASE | How you structure a live problem from the role |

**Labels.** `[grounded]` means the guidance traces to your own words or the JD. `[inferred]` means it is the pack's reasoning from those. `[generic]` means it is a common pattern for this kind of role, with no claim about Saltmarsh.

**Answer slots.** Where the JD is likely to probe something your material doesn't show, the guidance gives you an *answer slot*: if you did it, say how in your own words; if you didn't, or it wasn't yours, say so plainly and go back to what you did do. Both answers are honest. Neither one is the "right" answer.

Question IDs go by persona: A Case, B Skeptic, C Prober, D Conversational, E Pressure, G Peer, H Values. The letter F is skipped so it doesn't clash with the fit-snapshot rows (F1–F8).

The guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material covers a weekly content-drop calendar on one main title. The JD asks for a live-events calendar across two titles. Keep your words at their own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "live-events" and "two of our mobile titles" make probes on events and on juggling titles likely. If your drops included events, or you dealt with other titles' schedules, say what and what part was yours, in your own words. If not, say so plainly and stay with the calendar you ran. How you'd handle two titles is a plan, never something you've done |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show whether you worked with these teams to get updates out. The JD asks for coordination, not line management. Answer slot: if you worked with design, art, engineering or community to get drops out, say which teams, what you did with them and what was yours, in your own words. If you didn't, or it wasn't yours, say so plainly and go back to the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly retention numbers is close to owning a post-event review, but it isn't the same thing. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "post-event review" makes this probe likely. If you looked at how drops performed afterwards, say how and what part was yours. If there was no such review, or it wasn't yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist is not the same as running it release by release. Words: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage" makes a probe on day-to-day use likely. If you ran it with QA on each release, or kept it up to date, say how in your own words. If that was someone else's job, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Four years is more than the three asked for. What your material doesn't say is whether the title was run as a live service. Answer slot: if it was, say in your own words what that meant day to day. If it wasn't, say so plainly and describe the weekly content drops in your own terms |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap here. This is your strongest match. Lead with it in your own words: you ran it, it was weekly, and you did it for two years. There's nothing to inspect behind it, so expect follow-up questions on how it worked |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap. Expect to be asked which numbers they were. Name the metrics yourself, in your own words. If you didn't produce or calculate them, say who did |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | The checklist is a written document people still use, which is relevant here. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote other regular documents (update notes, retention write-ups), name them in your own words. If not, stay with the checklist. The interview itself and any follow-up email will also show this skill |

Requirements with no quoted evidence (F2) and requirements quoted at a narrower scope (F1, F3, F4) give the Skeptic and Case banks their material.

---

## Persona table

The loop comes from your own words: one 60-minute session with Tobias. No values round is documented, and without research there's no published values list, so this pack has no values cheat sheet.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | "Plan next quarter's events for two titles", "an event underperformed, run the review" | High. A hiring manager is buying the ability to do the job, and every JD line is a live problem. No interviewer signals were available to adjust this | Clarify, then objective, then approach, then metrics, then risks. Think out loud. Anything you bring from your own past must be in the words of your F-row quotes |
| Skeptic (B) | Quiet probes on the step from associate producer to producer, one title versus two, and in-app purchases | High. A hiring manager wants to reduce risk on gaps, and F1 and F2 are visible gaps. In-app purchases is a gap you stated yourself (see the prohibited list) | Rehearse B1 until it's boring. Say plainly what you haven't done, then give a ramp plan said as a plan |
| Data-Driven Prober (C) | "Which retention numbers? How were they counted?" | Medium. The JD names retention metrics and KPIs | Know what you can and can't say about how each number was counted. "I don't know how it was calculated" is an honest answer |
| Conversational (D) | Friendly openers such as "walk me through your journey" | Medium. Most 60-minute manager interviews open warm. That's when scoring begins | Have a 90-second arc built only from your quotes. Treat casual questions as scored |
| Pressure (E) | Time-boxed "why you" and "how much was actually you" | Low to medium. Not the usual manager register, but it can happen in a 60-minute slot | Pause, then hold your position through two follow-ups, then concede only what's real |
| Peer Evaluator (G) | Seams between design, art, engineering and community | Low to medium. Tobias isn't a peer, but the JD's coordination line will come up in this framing | Propose working principles. Don't claim to know how their teams split the work |
| Values / Behavioral (H) | "Tell me about a time you…" | Low. No values round is documented | Pick a story from your own material, or say plainly that none comes to mind |

---

## Question banks

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're taking over the live-events calendar for two titles. How would you plan the next quarter? What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with what you'd ask: each title's players and current cadence, what recent events returned, team capacity, fixed dates such as platform features or holidays, and where the two titles share people. Then cover the goal for each title, how you'd lay the calendar out and where the titles collide, when work locks, and how each event feeds the review. You can anchor once in your quote's own words: "For the last two years I ran the weekly content-drop calendar for our main title." Everything about two titles is a plan | This is the JD's headline line (F1, F6). It's a CASE question because it scores structure on the real job. It's the most natural way for a hiring manager to test F1's scope gap without accusing you of anything |
| A2 | "An event just ended and the numbers came in below what we expected. How do you run the post-event review?" | CASE | [generic] | Structure it: what the event was supposed to achieve, and was that agreed beforehand; which KPIs, against which baseline; break it down by player group, platform and version; possible causes (content, timing, technical issues, how it was announced); what you'd change next time; and how you'd write it up and who reads it. The question asks nothing about your past, so the guidance claims nothing | The JD's "own the post-event review" line (F3) asked as a decision rather than a record. `[generic]` because it's a common pattern, not Saltmarsh's process |
| A3 | "Day-7 retention dropped after our last update. Diagnose it." | CASE | [generic] | First check that the measurement didn't change. Then: which player groups, which platforms and app versions, crash or load problems, what changed in content or difficulty, event timing, and anything outside the game. Say what you'd look at first and why. Then give a hypothesis and how you'd test it | Tests the JD's "player-retention metrics" requirement (F7) live, beyond presenting numbers |
| A4 | "Both titles want the same art team in the same two weeks. How do you decide?" | CASE | [generic] | Clarify the goal and deadline for each, what slips if either waits, whether the work can be split or made smaller, and who makes the final call. Bring the trade-off to that person with your recommendation and say how you'd tell both teams. It's a plan; it claims nothing about your past | The JD's "two of our mobile titles" plus "coordinate…art" (F1, F2). Most likely a pain point in a two-title role |
| A5 | "QA finds a critical bug the day before an event goes live. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Assess severity and how many players it hits. Options: fix, cut the feature, delay, or ship with a known issue plus a message to players. Who decides, how community is told, and what the checklist should catch next time. If it fits, mention the checklist once in its own words: "I wrote the release checklist our QA team still uses." Don't describe a launch-day bug you didn't handle | The JD's release-checklist line (F4) under live pressure. CASE because it scores judgement, not history |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your title has been associate producer. This role coordinates design, art, engineering and community on every update, across two titles. Why are you ready for that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI prep in this pack.** Hold only what your quotes carry: "I've been an associate producer for four years, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: the JD's coordination line makes this probe certain. If you worked with any of those four teams to get drops out, say which teams and what part was yours, in your own words. If not, say so plainly and stay with the calendar. If they ask about leading: "I haven't led a team." Then say how you'd approach coordinating four disciplines across two titles, as a plan. Follow-up 1 is usually "give me an example", and the slot answers it. Follow-up 2 is usually "what if a team pushes back?": answer with the plan, don't add to your past. Never stretch "ran the calendar" into "led the teams" | The largest visible gap is the step up in title and scope (F1, F2, F5). A hiring manager will ask this in some form. JD because it scores the stated coordination requirement |
| B2 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Answer plainly and first: "No, I haven't worked on a game with in-app purchases." Don't apologise or minimise it. Then mention what you have done, in your own words: "I presented the monthly retention numbers to the studio head." Then, as a plan, how you'd get up to speed, for example learning how their events and offers fit together. Don't claim knowledge of monetisation | Second-deepest rehearsal. Mobile live operations is often tied to in-app offers `[generic]`, which is a common pattern and not a claim about Saltmarsh. You stated this gap yourself, so a straight answer beats a dodge |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick a real one. F1's two-title scope and F2's coordination are the honest candidates. Name it, say what you'd do in the first 30–60 days to close it (as a plan), and end on something your material does show, in its own words. If another weakness feels truer, use that one instead | A standard Skeptic stem. The danger is a fake weakness. F1 and F2 give you real ones you can talk about honestly |
| B4 | "Why move on from a puzzle-game studio, and why Saltmarsh?" | CO | [grounded] "4 years as an associate producer at a puzzle-game studio." | Your reasons, in your own words. Answer slot for "why Saltmarsh": name something specific you know about their games or how they run them, in your own words. If you haven't played their two titles, play them tonight; that's the single best preparation for this question. Don't recite company facts you haven't checked | It checks whether your motivation is consistent. CO because "why here" needs company knowledge, and this pack has none (research was blocked) |
| B5 | "Was the puzzle game you worked on run as a live service?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: the JD's "live-service games or apps" makes this likely. If it was, say in your own words what that meant day to day. If it wasn't, say so plainly and describe the weekly content drops in your own words | F5's open question. The years requirement is met on count; the probe is about what kind of game it was |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention numbers did you present to the studio head each month?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the metrics in your own words. Answer slot: say how they were counted, what they're sensitive to, and which assumption behind them you'd defend least, before Tobias asks. Also say which part was yours (pulling, analysing, presenting). Any of these can honestly be "I don't know how it was calculated; the data team produced it" | F7. The JD names retention metrics, so this question is a near-certainty. It tests whether you know your own numbers |
| C2 | "When you presented retention, did anything change because of it?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if a decision followed a presentation, say what it was and what part was yours, in your own words. If none did, or you don't know, say so plainly and stay with the monthly presentation | Connects F7 to F3's ownership. The prober is checking whether presenting led to action |
| C3 | "How do you know an event worked?" | JD | [generic] | Agree the success metric before launch, set the baseline and comparison, watch the first days for problems, then report whether it met the goal and what it cost to make. The question asks nothing about your past | The JD's "KPIs it reports" (F3). JD because it scores the stated ownership requirement |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built from these four facts in your own words: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for the main title; writing the release checklist QA still uses; presenting the monthly retention numbers to the studio head. Then why this role, in your own words. Use only these beats | Almost certainly the opener. These four quotes map to F5, F6, F4 and F7, so the arc covers most of the JD |
| D2 | "What mobile games are you playing at the moment, and what do you think of their live events?" | CO | [generic] | Your real answer. Name one event you thought worked and one that didn't, and why, in player terms. If you can name one of Saltmarsh's own titles honestly, do | A casual question that's still scored. It tests genuine interest in live operations |
| D3 | "Tell me about the release checklist. How did that come about?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | You wrote it, and QA still uses it. Answer slot: why you wrote it, what's in it, and how it's used now, in your own words. If you ran it with QA on each release, say so. If someone else did, say so plainly | F4 and F8. "Still uses" invites the follow-up, and the JD's "manage" makes a probe on day-to-day use likely |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate who already knows our games?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause. Concede the real point: they know the games and you'd have to learn them. Then hold on what your quotes carry: two years running a weekly content calendar, and a release checklist QA still uses. Hold through two follow-ups by repeating those, not by adding to them | Tests composure. The hold has to rest on F6 and F4, because anything bigger breaks on the second follow-up |
| E2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Your words say you wrote it, so hold that. Answer slot: if QA or anyone else shaped it, say plainly who and how. Precise credit-sharing reads as strength | A standard attribution probe on your most concrete claim (F4) |

### G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Engineering says the update needs two more days, and community has already announced the event date. What do you do?" | CASE | [generic] | Get the facts: what's late and why, whether a smaller scope can ship on time, and how bad the delay is for players. Bring options and a recommendation to whoever decides. Agree the message with community quickly. Afterwards, change the point at which dates are announced. A plan; it claims nothing about your past | The JD's coordination line (F2) at the engineering–community seam |
| G2 | "How do you keep design, art, engineering and community informed on an update without drowning them in meetings?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | A plan: one written source of truth for each update, a short regular status note, and meetings only for decisions. If it fits: "I wrote the release checklist our QA team still uses." Answer slot: if you used other written updates, name them in your own words. If not, stay with the checklist | Covers F2 and F8. Written communication is easiest to show through the documents you've written |

### H — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a time when a named decision was at stake, you said the hard thing, and the working relationship survived. If the retention presentations to the studio head ever included bad news, that may be your story; tell it only if it happened, in your own words. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A common behavioural stem. There are no published values to map to, so this is a selection guide, not a mapped story |
| H2 | "When did you put players ahead of an internal metric?" | VAL | [generic] | Choose a time when a player-facing choice cost a number in the short term and you argued for players. It needs a stake and an outcome. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Live operations constantly trades player goodwill against KPIs `[generic]`. A selection guide because no quote carries this story |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A1, A4, B1, B3 |
| Coordinate design, art, engineering and community (F2) | B1, A4, G1, G2 |
| Own the post-event review and its KPIs (F3) | A2, C2, C3 |
| Manage the release checklist with QA (F4) | A5, D3, E2 |
| 3+ years producing live-service games or apps (F5) | B5, D1 |
| Experience running a content calendar (F6) | A1, D1, E1 |
| Comfortable with player-retention metrics (F7) | A3, C1, C2 |
| Clear written communication (F8) | G2, D3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first quarter look like for this role on each title?" | It shows you're thinking about the results you'd deliver, and the answer tells you what you'll be measured on |
| R2 | "Are the two titles' calendars planned together or separately today, and where do they collide?" | Goes straight at F1's scope and at A4. It reads as someone already doing the job |
| R3 | "Which KPIs does the post-event review report, and who acts on it?" | Shows you know a review is only worth something if someone acts on it (F3) |
| R4 | "How does the release checklist work with QA today, and what would you want changed?" | Plays to your strongest concrete experience (F4) without bragging |
| R5 | "How much, if any, of event planning here involves in-app offers, and how does someone new to that get up to speed?" | Raises your stated gap (B2) yourself, as diligence. The answer tells you how big the gap really is |
| R6 | "What drew you to live operations, and what's kept you here?" | Turns the end of the interview into a conversation with Tobias himself. No profile was researched, so keep it open |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." | "I haven't led a team." Coordinating is a separate question (the F2 answer slot) |
| Has worked on a game with in-app purchases or on monetised events | Negative you stated, same sentence | "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar across multiple titles | Inflated version of F1 | F1's quote at its own scope. The pack's observation: your material says the weekly content-drop calendar for the main title. B1's and A1's slots stay inside that calendar |
| Owned post-event reviews or KPI reporting | Inflated version of F3 ("presented" stretched into "owned") | F3's quote at its own scope. C2's slot asks only what followed the presentations |
| Managed the release process with QA | Inflated version of F4 ("wrote" stretched into "managed") | F4's quote at its own scope. D3's slot asks only how the checklist is used |

---

## Sources

- **Provided:** the JD and your background, both pasted in your message.
- **Searches sent, all refused by the session's permissions:** "Saltmarsh Games values"; "Saltmarsh Games interview process producer"; "Saltmarsh Games mobile studio news 2026"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations".
- **Loop:** established from your own words (one 60-minute session with Tobias).
- **Dossier:** none present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused. It would have set whether a values cheat sheet exists and themed the H bank |
| 2. Saltmarsh Games interview process, producer | unavailable | Refused. It would have confirmed or adjusted the persona weights. Your own words still establish the session |
| 3. Saltmarsh Games strategy and recent news | unavailable | Refused. It would have grounded a CO or CASE question in their current titles; B4 and D2 are generic without it |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Refused. It would have added an interviewer read, adjusted the persona weights, and given a reverse question tied to his career |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** → Saltmarsh's values, interview process, recent news and Tobias's public profile. That adds an interviewer read, persona weights tuned to him, a strategy question grounded in their games, and R6 tied to his actual career.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a fuller company brief for B4, D2 and the case questions.
- **Confirm that Tobias is your future manager** → firms up the persona weights. If he's a skip-level or a peer, the banks are reweighted.
- **The recruiter's prep email, if there was one** → their stated focus areas, plus a build section for any exercise they announced (for example, an event plan).
- **The names of the two Saltmarsh titles you'd work on** → A1, A4 and D2 set on the real games.
- **Your answers to the answer slots:** whether you worked with design, art, engineering or community on drops (F2, B1, G1); whether the game was run as a live service (F5, B5); which retention metrics you presented (F7, C1); whether you ran the checklist with QA on each release (F4, D3). Each answer turns a slot into a mapped story.
- **A redacted copy of the release checklist, or a sample retention deck** → raises F4, F7 and F8 from medium to high confidence, and gives you concrete details to describe.
- **How many hours you have before Friday** → adds a prioritised prep schedule.
- **A tuesday-dossier.md from an earlier assessment of this role** → would replace this pack's inferred highest-ROI objection with one drawn from confirmed evidence. Not needed for this pack.
