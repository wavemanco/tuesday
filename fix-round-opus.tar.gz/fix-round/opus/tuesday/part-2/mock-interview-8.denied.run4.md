No dossier present. Reading the required references.
Dara, I've written a prep pack for all three rounds on 21 November. Each round has its own questions, plus sections that apply to the whole day.

**The question to rehearse most is B2:** "You've handled one branch's complaints log. This role owns complaints across every branch and the contact centre. What makes you ready for that?" It's the biggest distance between your background and the first line of the JD, so it will come up in some form. The pack walks it through three follow-ups. You state your strengths, admit before they ask that it's been one branch and you haven't worked in a contact centre, then give a plan for closing that.

What else is in it:
- **Your fit against the JD.** Each requirement is checked against your own sentences.
  - **Covered:** your six years in retail banking cover the 4+ years requirement.
  - **Not shown:** your background doesn't show whether your complaints were "regulated", whether your spreadsheet tracks volumes and resolution times, whether it's Excel, or any digital work. For each, the pack gives you an honest way to answer either way.
  - **Gaps you told me about:** the contact centre, and presenting above regional level. The pack keeps your exact words for these and adds a plan for each.
- **The 20-minute case.** How to split the time, which clarifying questions to ask first, and three approaches, each paired with the downside you should admit. It also lists three moves to avoid with two branch managers in the room, such as promising compensation before the facts are in.
- **The four values.** None of your four sentences contains a story for a value yet. So for each one the pack tells you what kind of story to pick and gives you an honest fallback. Telling me real stories would turn these into prepared answers.
- **Claims to avoid.** Seven easy exaggerations under pressure, such as saying you wrote the escalation script or that you managed a branch. Two branch managers will notice the difference between supervisor and manager.

**Before the 21st, find out which complaint rules Ashgrove works under**, and which ones applied to your current bank's log. Nothing you've given me says which country or regulator applies, so the pack gives no deadlines. One email to the recruiter would settle it.

I didn't run any web searches. Your pasted values, the recruiter's email and the strategy summary already covered everything the pack needed.

Files are in the working directory:
- ashgrove-credit-union_member-experience-lead_interview_pack.md

If you like, I'll play your future manager on B2, the most important question in the pack.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of interviews:** 21 November 2026, three rounds on one day
**Round 1:** Recruiter, 30 minutes
**Round 2:** Head of Member Services (your future manager), 45 minutes, "mostly behavioural"
**Round 3:** Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. This is the values round, scored against the four values.
**Interviewer names:** not assigned yet

**Mode:** loop. The fit snapshot, the case build, the strategy brief, the prohibited list and the sources are shared. After them, each round gets its own mini-pack with persona weights, a question bank and reverse questions.

---

## How to use this pack

- **Personas** describe how a question is asked: friendly, sceptical, time-boxed, case-style. **Types** describe what gets scored. Rehearse both. The same question sounds different from the recruiter than it does from a branch manager.
- **Type key:**
  - **VAL**: behavioural or values. Does your past behaviour show *Ashgrove's* four published values?
  - **EXP**: experience deep-dive. Does what you said survive close questioning, and what was actually yours?
  - **JD**: the job description. Can you do the listed job, including the parts you haven't done?
  - **CO**: company and strategy. Have you done your homework on where Ashgrove is going?
  - **CASE**: a live problem from the role, worked through out loud.
- **Provenance labels:** `[grounded]` means it traces to something you or the recruiter supplied. `[inferred]` means it is this pack's own derivation, and the row names what it was derived from. `[generic]` means a pattern for roles like this one, with no claim about Ashgrove or you.
- **Guidance is scaffolding, not a script.** Every claim about your past stands on one of four sentences from your message, and those sentences are quoted in the fit snapshot. Where the pack needs something your sentences don't say, it gives you an **answer slot**. That is an instruction for the interview with two honest branches: say what you actually did, in your own words, or say plainly that it wasn't yours or didn't happen.
- **Highest-ROI prep in this pack: B2.** "You've handled one branch's complaints log; this role owns it across every branch and the contact centre." Some version of this objection will come up. B2 rehearses it to three follow-ups.

---

## Fit snapshot (shared)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | No gap. Say it in your own terms: "Six years in retail banking, the last three as a branch supervisor." Don't relabel it as "customer operations". Let the interviewer make that mapping. Expect a light probe on what branch work covered. |
| F2 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material describes one branch's formal complaints log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on the log's stages likely, from a complaint arriving to it being closed. If any of those stages were yours to decide, say which and how, in your own words. If handling the log meant recording rather than deciding, or a stage wasn't yours, say so plainly and stay with the log you handled. |
| F3 | "…and the contact centre" (JD, same line as F2) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You've stated this gap, and wording can't close it. Your words: "I haven't worked in a contact centre." Follow with how you would learn it, said as a plan and never as a past. Don't add anything that makes the gap feel smaller. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | The sentence makes it monthly, about complaints, and built by you. It doesn't show whether the spreadsheet tracks volumes and resolution times, and it says the regional manager *uses* it, not that you report from it. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counts volumes or resolution times, say what it counts and how, in your own words. If it doesn't, say so plainly and say what it does track. |
| F5 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." and "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | transferability | Adjacent work with a named limit: you trained new tellers, not supervisors, and on "our" escalation script, which says nothing about who wrote it. Words: "I trained new tellers on our escalation script, and I've been a branch supervisor for the last three years." Answer slot: if how you trained the tellers was yours to decide (what you covered, how you checked it had landed), say how in your own words. If you delivered training someone else designed, say so plainly. Coaching supervisors is then a plan (B7, C7), never a past. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material doesn't mention digital or self-service work either way. Strong evidence would look like this: complaint patterns passed to a digital team, members helped onto self-service in branch, or feedback given on an online journey. Answer slot: if any of your work touched digital or self-service channels, say what, in your own words. If none did, say so plainly and say how you would start, e.g. by bringing complaint data to the digital team. |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | discovery | "Formal" is in your sentence. Whether those complaints fell under a regulator's complaint rules is not. Answer slot: if the log was kept under a regulator's complaint-handling rules, name them and the part you handled, in your own words. If you're not sure which rules applied, say so plainly and describe how the formal log worked. Know which regime Ashgrove works under before 21 November (upgrade menu). |
| F8 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You've stated this gap. Your words: "I've never presented to anyone above regional level." Your sentence doesn't say you have presented *at* regional level, so don't imply it. Follow with how you would prepare, said as a plan. The interview day itself, the case especially, is live evidence of how you present. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | Your material says "spreadsheet", not which tool. Answer slot: if you built it in Excel, say so and describe what it does in your own words (formulas, pivots, charts, whatever is true). If you used another tool, name it plainly. |

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter announced it, so it is graded. You don't know the scenario yet. This section prepares the approach, not an answer.

**Facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| "60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation" | Recruiter's email | [grounded] |
| "The panel is also the values round — they score against the four values." | Recruiter's email | [grounded] |
| The role is to "Own the member complaints process end to end across branches and the contact centre" | JD | [grounded] |
| The case will probably be scored against the values as well as on structure, because the same panel scores values | Derived from the two recruiter lines above | [inferred] |
| About you: F2's evidence, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", and F5's second quote, "6 years in retail banking, the last 3 as a branch supervisor." | Fit snapshot F2, F5 | [grounded] |

**A shape for 20 minutes** `[generic]`
- About 2 minutes: clarify.
- About 3 minutes: frame the objective and who's involved.
- About 10 minutes: work it.
- About 3 minutes: recommendation.
- About 2 minutes: what you'd change so it doesn't happen again.

Say the structure out loud before you use it.

**Clarifying questions worth asking first** `[generic]`
- Which channel did it come in through: branch, contact centre or digital?
- What has the member already been told, and by whom?
- What deadlines apply under the complaint rules Ashgrove works to?
- Are there signs the member is vulnerable?
- What can a branch decide without escalating?
- Has this happened before?

Ask two or three, not all of them.

**Three defensible theses, each with its concession**

| Thesis | Value it carries | Mandatory concession |
|---|---|---|
| T1. Fix it for this member, then fix it for the next one. Two tracks: resolve the case, and log the root cause so it shows up in the monthly reporting. | Members First, Always; Own the Fix | In 20 minutes the panel may only want the member track. Give the second track one line, and say that one case isn't a trend. |
| T2. One named owner from first contact to final response, even when the complaint crosses branch and contact centre. | Own the Fix | A single owner can become a bottleneck or lack the authority to settle it, so you need a clear handover rule. You haven't worked in a contact centre, so ask how its handoffs work today rather than assume. |
| T3. The final response should be written so the member never has to ask twice. | Plain Words | Regulated responses can need set wording. Plain words go around that wording, not instead of it. |

**Differentiation.** The consensus answer is "apologise, investigate, resolve, follow up", and every prepared candidate gives it. To go beyond it:
- Name who owns the complaint at each handoff.
- Name what you'd record and where it goes in the monthly report.
- Use a value by name once or twice where it actually decides something. Don't recite all four.

**Anti-picks.** Say no out loud to each of these:
- Promising compensation or an outcome before the facts are in.
- Letting a branch handle it informally outside the formal process to make it go away.
- Blaming the contact centre or the branch in front of two branch managers.

**Requested close:** none named by the recruiter. End on the recommendation and the one process change.

---

## Grounding brief (shared): the July 2026 strategy brief

From your summary of the brief the recruiter sent. It's four months old, so it's current. If you have the brief itself, use its exact phrases in the room.

| Strategy item | Source | Provenance | What it likely means for this role | Used in |
|---|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Your summary of the July 2026 strategy brief | [grounded] | Complaints will shift channel. Expect new complaint types: digital journeys that fail, and members who can't or won't move online. Reporting by channel becomes necessary. This is the JD's "self-service journeys" line. | [inferred] B9, C9 |
| Consolidate eight branches into five hubs over 2027 | Your summary of the brief | [grounded] | Your Round 3 panel are branch managers living through this. Closure-related complaints are likely, and so is tension with "Neighbours, Not Numbers". Don't speculate about which branches. | [inferred] C5, R3 reverse questions |
| Launch a small-business lending product in Q1 2027 | Your summary of the brief | [grounded] | A new product brings new complaint types early on. A good reverse question is whether the process is ready for them. | [inferred] R2 reverse questions |
| Main competitive pressure: app-only banks | Your summary of the brief | [grounded] | How a complaint is handled can be a reason a member stays, and the human, local side is what app-only banks don't have. | [inferred] C9 |

---

## Round 1: Recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly, "walk me through your background", logistics | High. A recruiter screen's default register, and 30 minutes is short. | A pre-built 90-second arc (A1). Treat casual questions about JD topics as scored. |
| Skeptic (light) | Quick knockout checks against the JD's requirements | Medium. Recruiters check stated requirements, and F3, F7 and F8 are the ones your material doesn't settle. | Plain acknowledgments where you've stated a gap, answer slots where you haven't. Short, not defensive. |
| Case / Strategist | One "what do you know about us" check | Low to medium. The recruiter sent you the strategy brief, so a check that you read it is plausible. | Two strategy moves, one line each, tied to the role (A7). |
| Prober, Pressure, Values, Peer | Rare here | Low. These are covered in Rounds 2 and 3. | No separate prep needed for this round. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP, JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Rehearse a 90-second arc with four beats, each from your own sentences: (1) six years in retail banking, the last three as a branch supervisor; (2) you handled the branch's formal complaints log; (3) you trained new tellers on the escalation script; (4) you built the monthly complaints spreadsheet the regional manager uses. Then one sentence on why this role, in your own words. Don't stretch "the branch's log" into a wider process. | It opens almost every screen, and it also checks F1's years requirement. EXP because it tests what was yours; JD because it covers F1. |
| A2 | "Why Ashgrove, and why a member experience role now?" | VAL | [grounded] | Answer slot: give the reason that is actually yours. If one of the four values or one strategy move (grounding brief) is part of why you applied, name it and say why it matters to you, in your own words. If your reason is something else, such as growth or a step up from branch level, say that plainly. A real reason beats a recited value. | Motivation-consistency checks start here and come back in Round 2. VAL because it tests fit with the published values. |
| A3 | "The role covers the contact centre too. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain and short: "I haven't worked in a contact centre." Then what you do bring, from F2's quote: you handled the branch's formal complaints log. Then one line of plan, e.g. "I'd want to sit with the contact centre team early on to learn how their complaints come in." Don't apologise twice. | F3 is a gap you've stated, and the recruiter may check it as a knockout. A rehearsed calm answer keeps it from becoming one. |
| A4 | "The JD asks for experience handling regulated complaints. Tell me about yours." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with the quote: you handled the branch's formal complaints log. Answer slot (F7): if that log was kept under a regulator's complaint rules, name them and say what part you handled, in your own words. If you're not sure which rules applied, say so plainly and describe how the formal log worked. Don't name a regime you didn't work under. | F7 is a listed requirement your material leaves open, and a recruiter can tick it only if you say it clearly. |
| A5 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the quote: you built the monthly complaints spreadsheet your regional manager uses. Answer slot (F9): if it's in Excel, say so and name what you actually use in it. If it's another tool, name it. Don't list features you haven't used. | F9 is an explicit requirement, and F9's evidence is your one artifact for it. JD because it's a stated requirement. |
| A6 | "What are your salary expectations, and what's your notice period?" | JD | [generic] | Have a researched range and your real notice period ready. Give a range, not one number, and say you're open to the full package. The pack supplies no figures. | Recruiter screens routinely include logistics, and treating them as unscored is the classic recruiter-round mistake. `[generic]` because nothing in your inputs names pay or notice. |
| A7 | "What do you know about where Ashgrove is heading over the next couple of years?" | CO | [grounded] | Two moves from the brief, one line each, linked to the role: "Moving 40% of service to digital by 2028 changes where complaints come from. The eight-to-five hub consolidation in 2027 changes who handles them locally." Hold the other two (small-business lending, app-only competition) in reserve. | The recruiter sent the brief, so having read it is a cheap signal. CO because it scores homework. |
| A8 | "This role presents monthly to senior leaders. What's your experience there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I've never presented to anyone above regional level." Then a plan, said as a plan: how you'd prepare a monthly pack (lead with the numbers and what you're asking for, keep it to a page, rehearse it first). The full version is B5. | F8 is a stated gap. The light version here keeps the recruiter from flagging it as a surprise for the manager round. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What would the Head of Member Services most want this person to have done in the first six months?" | It sets up Round 2 and tells you which gap to lead with. |
| "Do you know yet who the two branch managers on the panel will be, and which branches they run?" | Names unlock your interviewer read, and the branches matter given the hub plans. |
| "Is the 20-minute case given on the day, or is there anything to read beforehand?" | It's a graded deliverable, so ask about its format directly. |
| "Where does this role sit in relation to the contact centre: same team, dotted line, or separate?" | It tells you how much of F3 is day-one territory. |
| "What's the timeline for a decision after the 21st?" | Standard logistics, and recruiters expect it. |

---

## Round 2: Head of Member Services, your future manager (45 minutes, "mostly behavioural")

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of scope: one branch compared with the whole organisation, contact centre, senior presenting | High. A hiring manager is buying down risk, and F2, F3 and F8 are where the risk sits. | Rehearse B2 until it's boring. Name the limit before you're asked. Plans said as plans. |
| Values / Behavioral | "Tell me about a time…" questions | High. The recruiter said "mostly behavioural". | Pick stories in advance. "We" for context, "I" for your part. Honest branch where nothing comes to mind. |
| Case / Strategist | "How would you…" questions on reporting and coaching | Medium. The hiring-manager prior, toned down by "mostly behavioural". | Clarify, structure, then answer. Use Ashgrove's vocabulary: members, hubs, Own the Fix. |
| Data-Driven Prober | "Walk me through that spreadsheet" | Medium. F4 and F9 rest on one artifact, and a manager who owns the monthly report will ask about it. | Know exactly what it counts and what it doesn't. Say plainly what you don't know. |
| Pressure | One time-boxed or sharper follow-up | Low. Nothing in the inputs suggests a stress format. | The hold-then-concede in B2 covers it. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a complaint escalated beyond what the front line could resolve. What did you do?" | VAL, EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: choose one real complaint with a member, the point where it went beyond the front line, what you yourself did, and how it ended. Your nearest material is the formal log you handled. If no single case comes to mind, say so plainly, then describe how escalations reached the log, or how you would handle one. Don't build a composite case. | Escalations are the JD's core, and a behavioural round will ask for a specific one. The quote supplies the setting, not the story. |
| B2 | **Highest-ROI.** "You've handled one branch's complaints log. This role owns complaints across every branch and the contact centre. What makes you ready for that?" | JD, VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." "6 years in retail banking, the last 3 as a branch supervisor." | **Open with the hold:** "For the last three years I've been a branch supervisor. I handled the branch's formal complaints log and trained new tellers on our escalation script." **Name the limit before they do:** "It's been one branch, and I haven't worked in a contact centre." **Then a plan, said as a plan:** first weeks listening in the contact centre and in a few branches, reading the current log and reporting, agreeing one standard for escalations. **Follow-up 1:** "So what do you know about contact-centre complaints?" Don't claim anything. Say what you'd want to learn first, and from whom. **Follow-up 2:** "Why not hire someone who's run a contact-centre complaints team?" Concede it specifically: "They'd know the contact centre better than I do on day one." Then hold with only what you've said: branch supervisor, the formal log, training tellers, the monthly spreadsheet. **Follow-up 3:** "What would you get wrong?" Answer slot: name a real risk you see, in your own words, e.g. assuming the contact centre works like a branch. Don't fold to restore harmony, and don't add a single thing to the hold. | F2 and F3 together are the biggest distance between your material and the JD's first line, so this objection will come up in some form. It gets the most follow-up depth in the pack. JD for the requirement; VAL because Own the Fix is the frame they'll judge the plan by. |
| B3 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | What the quote carries: you built it, it's monthly, it's about complaints, and your regional manager uses it. Answer slots: what it counts (F4), what tool it's in (F9), and what the regional manager uses it for. For each, if you know, say so in your own words; if you don't, say so plainly. Don't describe it as a report you present (prohibited list). | It's your one artifact for two JD requirements (F4, F9), and a manager who will own the monthly report will probe it. EXP because it tests what was yours. |
| B4 | "How would you report complaint volumes and resolution times to the leadership team each month?" | CASE, JD | [generic] | Structure it out loud: (1) volumes by channel (branch, contact centre, digital) and by category; (2) resolution times against whatever target Ashgrove sets, plus how many cases are ageing; (3) top root causes; (4) what you're changing and who owns each action. One page, plain words, the number first and the ask second. The pack names no Ashgrove targets because none were supplied. | F4's requirement asked as a live problem, so it needs no claim about your past. |
| B5 | "You'll be presenting to senior leaders. What's your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I've never presented to anyone above regional level." Pause, and don't fill the silence with qualifiers. Then a plan: send a pre-read, lead with the one thing that changed this month and what you need from them, rehearse with your manager the first few times, ask for feedback after each. Hold: don't upgrade the quote under a follow-up. | F8 is a stated gap and a listed requirement, and your future manager is the person who'll put you in front of senior leaders. |
| B6 | "Tell me about a time you trained someone on handling an escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5. The beats the quote states: new tellers, and the branch's escalation script, which you trained them on. Answer slot: if how you ran the training was yours to decide (what you covered, how you checked it landed), say how in your own words. If you delivered someone else's material, say so plainly and describe how you trained them. Say "our script". Don't say you wrote it. | F5 is the evidence for the coaching requirement, and the script's origin is the first thing a prober will check. EXP because it tests attribution. |
| B7 | "How would you coach a branch supervisor who keeps escalating complaints their branch could resolve?" | CASE, JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Lead with the seat: "I've been a branch supervisor for the last three years." Then as a plan: look at their cases together first; find the cause (unclear authority limits, confidence, or the script itself); agree what the branch can settle; sit in on the next few; follow up. Coaching peers is plan, not past. | The JD's coaching line asked as a live problem. Your supervisor years (F5) are the one fact that makes you credible to supervisors. CASE delivery, JD content. |
| B8 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold for Own the Fix: a problem you noticed, the moment you could have handed it on, what you did instead, and how it ended. One place to look is the spreadsheet in your quote. Answer slot: if you built it because something was missing, say what was missing and what you did; if you were asked to build it, say so plainly and pick another story. If no such time comes to mind, say so plainly and give the nearest thing you have. | The value's own words ("whoever finds the problem keeps hold of it until it is solved"), likely here and certain in Round 3. |
| B9 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints, and how would you work with the digital team?" | JD, CO | [grounded] | Grounding brief, row 1: complaints change channel; new types appear (journeys that fail, members left behind); reporting has to split by channel; complaint themes go to the digital team as evidence for fixes. Answer slot (F6): if any of your work touched digital or self-service, say what in your own words; if none did, say so plainly and say how you'd start. | Covers the JD's self-service line (F6) and the brief's headline target. JD because it's a stated duty; CO because it's strategy. |
| B10 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of the two gaps you've stated, not an invented weakness: "I haven't worked in a contact centre," or "I've never presented to anyone above regional level." Then the plan in one sentence. Answer it straight. A fake weakness reads as evasive to a future manager. | The standard sceptic question. You already have two honest answers from F3 and F8, so use them. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What would a great first year in this role look like to you?" | Your future manager's own definition of success is the most useful thing you can leave with. |
| "How do complaints reach this role from the contact centre today, and where do they get stuck?" | It names F3 head-on as curiosity rather than weakness. |
| "When the small-business lending product launches in Q1 2027, will its complaints come through this process?" | It shows you read the brief and are thinking about readiness. |
| "How will the move to five hubs change who handles complaints locally?" | It connects the consolidation to the role's day job. |
| "How do you like to receive reporting: numbers first, story first, how often?" | It addresses F8 as practice, and tells you how they work. |

---

## Round 3: Panel of two branch managers (60 minutes, 20-minute case, values round)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Story questions, one per value | High. The recruiter: "they score against the four values". | Values cheat sheet below. One prepared story or an honest scaffold per value. |
| Case / Strategist | The 20-minute escalation case, plus "how would you…" | High. A third of the round is a declared case. | The case build section above: clarify, frame, two tracks, close on one process change. |
| Peer Evaluator | "What would you need from us?" and "Our supervisors, your coaching" | Medium. The role coaches the supervisors who work for branch managers, so your seam with them is real (inferred from the JD's coaching line). | Offer before you ask, and set out seam principles rather than pretending to know the seam. |
| Skeptic | "Why would our supervisors listen to you?" | Medium. Two managers whose teams you'd be coaching. | Your supervisor years (F5), said plainly. Coach alongside, not over. |
| Conversational | The opening few minutes | Low. | A shorter version of A1. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold for Members First, Always: a real decision where the member's view changed what you did, ideally where the easier internal option was to do something else. It needs the member, the choice, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you'd decide. | The value's own phrasing, so the panel may use it nearly word for word. |
| C2 | "Tell me about a time you explained something so it landed the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Plain Words. One place to look is training tellers on the escalation script. Answer slot: if putting the script into plainer words was part of how you trained them, say what you changed and why, in your own words; if it wasn't, say so plainly and pick another moment. If none comes to mind, say so. | Plain Words is a published value. F5 is your nearest material, but it doesn't carry the story on its own, hence the slot. |
| C3 | "Tell me about a time knowing your local community changed how you handled a member." | VAL | [grounded] | Selection scaffold for Neighbours, Not Numbers: a member, something local you knew, and what it changed. If no such time comes to mind, say so plainly, then say how you'd keep local knowledge alive inside a hub. | The value is about branches as part of their towns, which matters more to this panel than any other. |
| C4 | "Tell me about a problem you found that wasn't strictly yours, and what you did with it." | VAL | [grounded] | Selection scaffold for Own the Fix: the problem, whose it was, the point where you could have passed it on, what you did, and whether it got solved. If no such time comes to mind, say so plainly and give the nearest thing you have. Use a different story from B8 if you have one. The panel may not hear what you said to your manager, but repeating a story across rounds is fine. | The value's own words. Both rounds are likely to probe it. |
| C5 | "With eight branches becoming five hubs, how would you handle complaints from members whose branch is closing?" | CASE, CO, VAL | [grounded] | Acknowledge the loss first, in plain words. Give one consistent explanation across branches, the contact centre and digital. Log consolidation complaints as their own category so leadership sees the volume. Keep a named local contact through the change. Hold that the member's experience should drive how the transition is run, without arguing with the plan itself. Don't speculate about which branches close. | It's the brief's consolidation line set against two values, Members First and Neighbours, Not Numbers, in front of branch managers who are living through it. |
| C6 | "You'd be coaching our supervisors on escalations. What would you need from us, and what happens when we disagree about how a complaint was handled?" | JD, VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start with what you'd give them: quicker answers on escalations, and patterns from the data about their branch. Then what you'd need: access to their supervisors, and a say in the standard. Seam principle: the branch manager runs the branch's people, and you hold the complaints standard and process. Disagreements get settled on the member outcome and the rules, privately, not in front of the team. You can add "I've been a branch supervisor for the last three years," so you know the seat. | The Peer Evaluator's core question, and it covers the JD's coaching line from the branch side. |
| C7 | "Why would our supervisors take escalation coaching from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | "I've been a branch supervisor for the last three years, so I know what an escalation looks like from their side of the counter." Then as a plan: coach alongside them on real cases, not from a slide deck. Don't claim you've coached supervisors before (prohibited list). | Two branch managers will check whether you'd add load to their teams or take it off. F5's limit is exactly where this lands. |
| C8 | "Our branches already know how to handle complaints. What would you change?" | CASE | [generic] | Don't come in with a list of fixes. Plan: start with the data and with listening (repeat complaints, ageing cases, where escalations stall, branch by branch), then pick one or two changes together. Concede that branches are closest to members. Hold that one standard across branches and the contact centre still matters. | A sceptic's question in a peer's tone. It tests whether you'd arrive with answers or with questions. |
| C9 | "Members can switch to an app-only bank in five minutes. Why would they bring a complaint to us rather than just leave?" | CO, VAL | [grounded] | Grounding brief, row 4: a complaint handled quickly, in plain words, by someone who knows the town is a reason to stay, and it's the one thing an app-only bank can't copy. Tie it to Members First once. Add the digital side: a complaint made in the app should be as easy to resolve as one made in branch. | It's the brief's competitive frame, likely from managers defending the branch's value. |
| C10 | "Explain our complaints process to me as if I'm a member who's upset." | CASE, VAL | [generic] | Plain Words, live: short sentences, what happens next, who will contact them, roughly when, and what they can do if they're still unhappy. Don't invent Ashgrove's timelines. Say "we'll tell you exactly when". Keep it under a minute. | Plain Words tested as a performance rather than a story. `[generic]` because the pack doesn't know Ashgrove's process. |

### Values cheat sheet

Official value names and the definitions you pasted. The working meanings are paraphrases.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's view, not the institution's convenience | Selection scaffold (C1): a decision where the member's view changed what you did. If none comes to mind, say so plainly and give the nearest thing you have, or how you'd decide. |
| Plain Words | If a member needs it explained twice, the explanation failed | F2 and F5 evidence: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot (C2): if training on the script involved putting it into plainer words, say what you changed. If not, say so plainly and pick another moment, or say none comes to mind. |
| Neighbours, Not Numbers | Each branch belongs to its town, so treat members as neighbours | Selection scaffold (C3): something local you knew that changed how you handled a member. If none comes to mind, say so plainly and say how you'd keep local knowledge inside a hub. |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | F4 and F9 evidence: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot (B8, C4): if you built it because something was missing, say what was missing and what you did. If you were asked to build it, say so plainly and pick another story, or say none comes to mind. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What complaint do your branches see most that you wish were handled differently?" | It hands them the floor and gives you real case material. |
| "Where does an escalation from your branch go today, and where does it stall?" | It shows you'd start from their reality (C8's plan). |
| "What would a supervisor in your branch want from this role in the first month?" | A reciprocity question for peers. It addresses the load concern directly. |
| "How have members in your towns reacted to the hub plans so far?" | Neighbours, Not Numbers, asked with care rather than assumed. |
| "How do you see the small-business lending launch showing up at your counters?" | It connects the brief to their day job and shows you read it. |

---

## Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own the complaints process end to end across branches | F2 | A1, B2 |
| …and the contact centre | F3 | A3, B2, B10 |
| Report monthly on complaint volumes and resolution times | F4 | B3, B4 |
| Coach branch supervisors on escalations | F5 | B6, B7, C6, C7 |
| Work with digital teams on self-service journeys | F6 | B9 |
| 4+ years in financial-services customer operations | F1 | A1 |
| Experience handling regulated complaints | F7 | A4 |
| Confident presenting to senior leaders | F8 | A8, B5, B10 |
| Comfortable with Excel reporting | F9 | A5, B3 |
| The recruiter's 20-minute escalation case | none | The graded deliverable section |
| The four values (recruiter: panel scores against them) | none | C1 to C4, C5, C9, C10, B8, and the values cheat sheet |

---

## Prohibited claims

What this pack will not coach, and why. These are the stretches that come easily under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process end to end, or across branches | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation, not words for you: your material describes one branch's log, not a process across branches. F2's slot stays inside the log. |
| Has worked in, or handled complaints for, a contact centre | A negative you stated (F3) | "I haven't worked in a contact centre." No slot. |
| Has presented to senior leaders, or at regional level | A negative you stated (F8). Your sentence doesn't say you presented at regional level either. | "I've never presented to anyone above regional level." No slot. |
| Has coached supervisors or managers on escalations | Inflated form of F5 | F5's quote at its own scope: "I trained new tellers on our escalation script." The pack's observation: your material says tellers, not supervisors. Coaching supervisors appears only as a plan (B7, C6, C7). |
| Wrote or designed the escalation script | Inflated form of F5 ("our escalation script") | The quote: "trained new tellers on our escalation script." The pack's observation: your material says you trained people on it, not who wrote it. |
| Presents or reports the monthly complaints figures to the regional manager | Inflated form of F4 | F4's quote: "I built the monthly complaints spreadsheet our regional manager uses." The pack's observation: your material says you built it and the regional manager uses it. F4's slot asks only what it counts. |
| Managed a branch | Inflated form of F1 | F1's quote: "6 years in retail banking, the last 3 as a branch supervisor." The pack's observation: your material says supervisor, and two branch managers will notice the difference. |

---

## Sources

**Provided documents, all pasted by you and none fetched:**
- The JD text.
- Ashgrove's four values, which you copied on 12 November 2026 from ashgrovecu.org/about/values. The page was not fetched, because the pasted text is already in hand.
- The recruiter's email on the process.
- Your summary of Ashgrove's July 2026 strategy brief. I didn't see the brief itself.
- Your background.

**Searches and fetches sent:** none. Your inputs fixed every output each research target feeds. No dossier was present, so none was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted this morning gives the four official names and definitions, which fixes the cheat sheet and the VAL banks. |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes all three rounds: who runs each, how long, the case, and the values scoring. That fixes the persona weights and the loop structure. |
| 3. Ashgrove strategy or recent news | skipped | The July 2026 strategy brief is under six months old and already covers the priorities and the competitive frame that feed the CO questions. |
| 4. Interviewer name, Ashgrove | n/a | No names have been assigned yet, so there was no query to form. The interviewer read is absent. |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD, and it fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- **Interviewer names** for Round 2 and the two Round 3 branch managers → an interviewer read for each, panel personas assigned per member, and at least one reverse question tied to each person's own career path.
- **Which complaint rules Ashgrove works under, and which ones governed your current bank's formal log** (one email to the recruiter, or your own knowledge) → F7 and A4 get a named regime, and case thesis T1 can cite real deadlines instead of "whatever Ashgrove's rules require".
- **Your answers to the answer slots in F2, F4, F5, F6, F7 and F9, said outside a drill** → those rows get your own words in the evidence column, and A4, A5, B3, B6 and B9 become story-mapped instead of slot-shaped.
- **A redacted copy or screenshot of the monthly complaints spreadsheet**, the inspectable artifact for complaints reporting → F4 and F9 can move from medium to high confidence, and B3 becomes a walkthrough you can rehearse line by line.
- **Whether you have presented at regional level** → if you have, F8 gets a real story at its true scope. If you haven't, nothing changes and the plain acknowledgment stands.
- **A real story for each of the four values**, told to me outside a drill → the cheat sheet's scaffolds become mapped stories, and C1 to C4 and B8 become story-mapped.
- **The strategy brief itself, not your summary** → the grounding brief can quote Ashgrove's own phrasing, which is what to mirror in Rounds 2 and 3.
- **How much prep time you have before 21 November** → a prioritised prep schedule, a few things done well in order, tied to question IDs.
- **Deeper research**: up to 6 more searches and 2 more fetches, several more minutes → once interviewer names exist, their public professional footprint, plus recent Ashgrove news and any published credit-union loop reports. Run only if you want it.
- **A `tuesday-dossier.md` from an earlier underwriting pass**, if you ever make one → an evidence-derived highest-ROI objection and a prohibited list checked against claims you confirmed. This pack is complete without it.
