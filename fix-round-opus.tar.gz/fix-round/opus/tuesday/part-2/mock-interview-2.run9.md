I've read the prep playbook and its rules. Next I'm running a few quick searches on Atlas Freight, then I'll build your prep pack.
I've saved your prep pack as `AtlasFreight_operations-manager_interview_pack.md`. You didn't say who you're meeting or what kind of round it is, so I built it without assuming either, and every interviewer style gets equal weight. I also couldn't research Atlas Freight: my three web searches were blocked because web search isn't permitted in this session. So far the pack draws only on the job posting and what you told me.

**What the pack covers:**
- **Where you match:** your green belt matches "Lean/Six Sigma a plus" directly. Your 40% mis-pick cut and two peak-season surge plans are your strongest stories.
- **Your gaps:** three supervisors today against twelve in the role, and one site against four. The posting asks for "5+ years operations leadership", and your 7 years in ops doesn't say how many involved leading people. You haven't used Power BI, and on-time and cost-per-shipment aren't covered by anything you've told me yet.
- **The question most worth rehearsing:** "You lead three supervisors today, this role leads twelve across four sites — why shouldn't that worry me?" It's question A1 in the pack. Practise naming the gap yourself, then giving a 30-day plan. Don't make your experience sound bigger than it is.
- **The rest:** 21 practice questions with answer guidance, a table showing which questions cover each line of the posting, 6 questions for you to ask them, and a list of claims not to make (for example, that you've worked multiple sites or used Power BI).

Where your material doesn't cover something, the guidance gives two honest options instead of putting words in your mouth. Example: "if you've had more than three supervisors, say when; if not, say so plainly."

**Next steps:**
- If you'd like to practise, I can play the skeptical interviewer on A1 and push back on your answers live.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting, and in what kind of round: a recruiter, your future manager, a peer, someone more senior, or a panel? Include anything the recruiter said about the format, focus areas or something to prepare. This changes which questions the pack puts first.
2. If you allow web search, I can rerun the Atlas Freight searches (up to six) for their values, interview process and recent news. Do you want me to?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees, per the JD)
**Interviewer:** unknown, and so is the round type. Persona weights below are flat; see the persona table.

## How to use this pack

Two things organize every question:

- **Personas** describe how a question is asked: the interviewer's style.
- **Types** describe what is being scored:
  - **VAL**: behavioural and values. Do your past actions show the behaviour they want?
  - **EXP**: work-experience deep-dive. Do your stated results hold up, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Have you done your homework on Atlas Freight?
  - **CASE**: a live problem from the role, solved out loud.

The guidance is scaffolding, not a script. Every line about your past comes from your own words in your message, quoted. Where your material doesn't say something, the pack gives you an **answer slot**: an instruction for the interview with two honest branches (if you did it, say how; if you didn't, say so plainly). Rehearse the slots out loud before the interview, so you aren't working out your honest answer in the room.

Provenance labels: `[grounded]` = traceable to your message or the JD; `[inferred]` = derived, with the derivation named; `[generic]` = a common pattern for this kind of role, with no claim about Atlas Freight or you.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message; "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material says one site's peak plan and warehouse and distribution ops. It does not say four sites, or terminal operations, which are different work from a warehouse. Keep the words at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's "terminal operations across 4 sites" makes a probe on multi-site and terminal work likely. If any of your work covered more than one site, or terminal or cross-dock flow, say which and what your part was, in your own words. If none did, say so plainly and stay with the site you ran |
| F2 | "drive on-time performance" — JD | none given | none | [grounded] | discovery | Your material doesn't show on-time performance as a measure you've worked on. Answer slot: if you've tracked or been accountable for on-time or service-level numbers, say which number, how it was measured and what you did with it, in your own words. If you haven't, say so plainly and move to how you'd measure it here (B2, C3) |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material doesn't show a cost measure you've worked on. Answer slot: if you've owned or reported a cost, labour or productivity figure, say which and what moved it, in your own words. If you haven't, say so plainly and walk through how you would approach it (B3) |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors today; the role is twelve. Keep the words at that scope: "I'm a senior shift manager over three supervisors." Answer slot: the JD's "team of 12 supervisors" makes a probe on a larger span likely. If you've ever had more than three supervisors reporting to you, say when and for how long. If you haven't, say so plainly, stay with the three, and give your plan for twelve as a plan |
| F5 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years in ops is not the same claim as seven years of operations leadership, and your material doesn't say how many of the seven involved leading people. This is graded as fit, not as a gate, but a "required" line is likely to be checked literally. Answer slot: give the number of years you've led people, with the titles, as it actually is. Don't round it up |
| F6 | "build reporting in Excel/Power BI" — JD (Excel part) | "solid Excel" — your message | medium | [grounded] | discovery | "Solid Excel" reaches the tool. It doesn't show reporting you've built for others. Answer slot: if you've built Excel reports or trackers that other people used, say what they tracked and who read them. If you haven't, say so plainly and say what you do use Excel for |
| F7 | "build reporting in Excel/Power BI" — JD (Power BI part) | "never used Power BI" — your message | none | [grounded] | capability | A gap you've stated, and no wording closes it. Words: "I haven't used Power BI." Then how you'd learn it, said as a plan and never as a past. If you've started learning it by interview day, say exactly how far you've got. Nothing more |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | none | No gap. Lead with the certification in its own words: "I'm green belt certified." Have the issuer and year ready, since it's a certificate they may ask to see. Your material doesn't say whether the pick-path redesign was run as a green-belt or Lean project. Answer slot: if it was, say which method steps you used. If it wasn't, keep the two facts separate |

## Persona table

The round type is unknown, so the pack falls back to a generic loop pattern (screen, then hiring manager, then panel). That pattern gives no tilt, so the **weights are flat**: each persona gets three questions. This is noticeably weaker than a pack built for a known round, and telling me who you're meeting will reweight it.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of span (3 to 12 supervisors), sites (1 to 4) and leadership years | Even. No round type was given, but A1 is the question any interviewer in any round is most likely to ask in some form, because F1, F4 and F5 are the widest gaps | Rehearse A1 until it's boring. Name the limit before they do, then give the plan |
| B. Case / Strategist | Live problems: first 30 days, an on-time drop, cost-per-shipment | Even. The hiring manager usually runs these, and the JD's outcome lines (on-time, cost) are exactly what cases come from | Clarify, objective, structure, approach, metrics, risks. Think aloud |
| C. Data-Driven Prober | Goes after the 40%, and after how you'd measure four terminals | Even. Your one headline number is a magnet for this style | Know how the 40% was counted, or say plainly you don't. Name the weakest assumption first |
| D. Pressure | Time-boxed "why you", "how much was actually you" | Even. Common in panels and skip-level rounds, and unknown here | Pause, restate, hold through two follow-ups, concede specifically |
| E. Conversational | Friendly openers, the green belt asked casually | Even. Typical of recruiter screens and openings | A 90-second arc. Treat casual questions as scored |
| F. Values / Behavioural | "Tell me about a time…" stories | Even. No values-style round was detected (no loop source, and the generic pattern doesn't assume one), but behavioural questions are common at this level | Pick stories in advance using the scaffolds. "We" for context, "I" for your part |
| G. Peer Evaluator | Other site leads, dispatch or sales on seams and credit | Even. Likely if there's a panel | Talk about what you'd bring them as well as what you need. Propose principles for the seam rather than claiming to know it |

## Question banks

**Highest-ROI prep in this pack: A1.** It will come in some form. Rehearse it out loud more than anything else.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today. This role leads twelve, across four sites. Walk me through why that jump shouldn't worry me." | JD, EXP | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | Hold only what your quotes carry: "I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Name the scale yourself before they push: "Twelve across four sites is a bigger span than I run today." Answer slot: if you've ever had more than three supervisors, or more than one site, reporting to you, say when and how, in your own words. If you haven't, say so plainly and stay with the three. Then the plan, said as a plan: the first 30 days (meet every supervisor, learn each site's numbers and how they're counted, one shared daily view). On follow-ups 1 and 2, go back to the three and the plan. Never enlarge them | F4 and F1 are the widest distance between your material and the JD, so this objection arrives somewhere in the loop. JD because it scores the stated span; EXP because it tests what you actually run today |
| A2 | "The posting asks for five-plus years of operations leadership. How many of your years have been leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say the seven years in your own terms, "seven years in warehouse and distribution ops", and don't let "ops" quietly become "operations leadership". Answer slot: give the number of years you've led people and the titles, as it is. If it's under five, say the number plainly, don't round it, and then describe what you run now as a senior shift manager over three supervisors | F5. A "required" line is likely checked literally, so a straight number beats a vague one. JD because it's a stated qualification |
| A3 | "We build our reporting in Excel and Power BI. Where are you with that?" | JD | [grounded] "solid Excel, never used Power BI" | Two parts, in order. Excel: "solid Excel". Answer slot: if you've built reports others used, say what they tracked and who read them; if you haven't, say what you do use Excel for. Power BI, as a plain statement: "I haven't used Power BI." Then a learning plan, said as a plan. If you've started a course by interview day, say exactly how far you've got. Never "I've played with it" unless you have | F6 and F7. A named tool mentioned once in a JD is a typical free miss. JD because it's a listed responsibility |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's your first week: four terminals, twelve supervisors. What do you need to know first, and what do you do in your first 30 days?" | CASE, JD | [generic] | Clarify first: what's going well, what's not, and what leadership expects by day 90. Then structure: a baseline per site on on-time and cost-per-shipment, and how each is counted; one-to-ones with all twelve supervisors; walking each terminal at shift change; one shared daily report; one early improvement picked with the supervisors. Close with risks: changing too much too soon, and treating four sites as identical. No claim about your past is needed | Built from the JD's first three lines. CASE delivery, JD content; `[generic]` because it's a pattern, not knowledge of Atlas's terminals |
| B2 | "On-time performance at one terminal dropped ten points last month. Diagnose it." | CASE | [generic] | Clarify: on-time against what (pickup, departure, delivery), when it started, whether it's one terminal or all, and whether the way it's measured changed. Hypotheses: volume, staffing or absence, dock and equipment, linehaul or carrier timing, data. Say what you'd check first and why, then the fix and how you'd know it worked | The JD's on-time line. F2 shows no on-time experience, so a clean structure is the honest way to score here |
| B3 | "How would you take cost-per-shipment down without hurting on-time?" | CASE, JD | [generic] | Name the tension out loud. Pin down the measure: what's in the cost (labour, overtime, linehaul, claims, re-handling) and what counts as a shipment. Levers: labour matched to volume, fewer touches and errors, dock flow, overtime control. Guardrail: on-time tracked alongside it. Pilot at one site, then roll out. Ask how they count it today | The JD's cost line. F3 shows no cost experience, so structure is the evidence. JD because it scores a stated outcome |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats your sentence states: the mis-pick rate, 40%, and redesigning the pick path. Answer slots, each in your own words: how the rate was counted (what counted as a mis-pick, over what period, before against after); what it's sensitive to; the assumption behind it you'd defend least, said before they ask; and which part was yours. If you don't know how it was counted, say so plainly. Keep it a mis-pick rate. Don't turn it into a cost or on-time claim | Your one headline number, so it will be probed. EXP because it tests whether the figure holds up |
| C2 | "What did redesigning the pick path actually involve, and what was yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start with what you changed and the result, using "we" for context and "I" for your part. Answer slot: the JD's "Lean/Six Sigma a plus" makes a question about method likely. If you used a Lean or Six Sigma method on it, say which steps and how. If you didn't, say so plainly and describe what you changed. Answer slot: if parts of it were other people's, name them plainly | F8. Interviewers tend to ask whether the story behind the number is really yours. EXP because it tests attribution |
| C3 | "How would you know, every morning, whether each of four terminals had a good day?" | CASE, JD | [generic] | Pick three to five measures: on-time, cost-per-shipment, and leading indicators such as volume against plan, labour hours against plan, and exceptions or claims. Define each precisely, and show it in one daily view (Excel now, Power BI as you learn it). Say who looks at it and what level triggers action | The JD's reporting line, plus F6 and F7. A good answer shows you think in measures even where the tool is new to you |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Pause, then three beats in about 60 seconds: seven years in warehouse and distribution ops; the 40% mis-pick cut from redesigning the pick path; running the site's peak-season surge plan two years running. Concede plainly: an internal candidate knows the terminals, and you'd have to learn them. Never criticise the internal candidate | Tests composure under time pressure. JD because it's really "can you do this job" |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause. Hold the sentence. Answer slot: say which parts were yours, in your own words; if a part was someone else's, name it plainly. Hold through two follow-ups, concede what others did specifically, and never let go of what you did just to ease the moment | C1's number under stress. Rehearsing it makes the honest answer quick |
| D3 | "Your peak-season surge plan, two years running. What would you change if you ran it a third time?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The plan, run twice, by you, as your sentence says. Answer slot: if something in it didn't work, say what and what you did about it. If nothing stands out, say so and say what you'd test next time. Don't make up a crisis to make the story land | F1's best evidence, pressure-tested. EXP because it probes the plan behind the line |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc: seven years in warehouse and distribution ops, now a senior shift manager over three supervisors, two proof points (the mis-pick cut, the peak plan two years running), then why this role. Answer slot: say what draws you to terminal operations and a bigger span, truthfully, in your own words | Almost certainly the opener. The casual tone hides that it's scored on economy |
| E2 | "I see Lean/Six Sigma on there. What got you into the green belt?" | EXP, JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: if you've applied it to a project at work, say which one and what you did. If you haven't, say so plainly and say where you'd use it at Atlas. Don't link it to the pick-path redesign unless that's how it happened | F8. A JD plus-skill asked casually is still scored |
| E3 | "What do you know about us?" | CO | [grounded] | Start from the JD's own facts: regional logistics, 800 employees, four sites. Before the interview, spend 20 minutes on their website and recent news, and bring one specific thing you found and actually read. Never guess at facts about the company | Research couldn't run (see Sources), so this is the only CO question the pack can ground. CO because it scores homework |

### F. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you said it anyway, and an outcome (it landed, or what you learned). STAR shape. If no such time comes to mind, say so plainly, then give the nearest thing your experience does have, or how you would handle it | A persona stem. Nothing in your material carries this story, so it's a scaffold |
| F-2 | "Tell me about a time a supervisor on your team wasn't performing." | VAL, JD | [generic] | Selection scaffold: what you noticed, the conversation, the support or plan, the outcome, and what you'd do the same or differently. Keep the person anonymous. If no such time comes to mind, say so plainly, then give the nearest thing your experience does have, or how you would handle it | The theme comes from the JD's "lead a team of 12 supervisors". Leading leaders is the core of the job |
| F-3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the metric, the customer need, the call you made, and how you explained it upward. If no such time comes to mind, say so plainly, then give the nearest thing your experience does have, or how you would handle it | A persona stem. On-time and cost targets often pull against each other, which makes this a natural probe |

(F-1 to F-3 are the Values bank, written with a hyphen so they aren't confused with fit-snapshot rows F1 to F8.)

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sales promises a customer a time your terminal can't make. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles for the seam: agree capacity rules up front, escalate early with options, and look at misses together. Show spine and tact in the same answer | Collaboration across functions. `[generic]` because Atlas's structure isn't known |
| G2 | "How do you handle credit when a result spans teams, like your mis-pick work?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | "We" for context, "I" for your part. Answer slot: say who else was involved and what was theirs. If it was yours alone, say so plainly | Same attribution question as C2 and D2, asked kindly. Rehearse one honest version for all three |
| G3 | "What would you need from the other site and function leads in your first month, and what would you bring them?" | CASE | [generic] | Need: their read on each terminal, the history of the numbers, and the informal rules. Bring: one shared daily view, quick follow-up on cross-site issues, and help at peak. Offer the help without claiming expertise you haven't shown | Reciprocity check. Peers care what the hire adds to their workload |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, B1, C3, D1 |
| drive on-time performance | B2, C3, B3 |
| cost-per-shipment down | B3, C3 |
| lead a team of 12 supervisors | A1, B1, F-2 |
| build reporting in Excel/Power BI | A3, C3 |
| 5+ years operations leadership required | A2 |
| Lean/Six Sigma a plus | E2, C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time measured here, and where are the four terminals against target today?" | Shows you think in definitions, and tells you how big the job really is |
| R2 | "What goes into cost-per-shipment as you count it?" | Diligence, and it reveals which levers the role really controls |
| R3 | "How are the twelve supervisors spread across the sites, and how long have they been in role?" | Shows you're already thinking about the team, and tells you about your span |
| R4 | "What reporting exists today in Excel and Power BI, and who maintains it?" | Shows you're realistic about the tool gap, and tells you whether you'd be building from scratch |
| R5 | "Is Lean/Six Sigma used here today, or is it something you'd want this role to bring?" | Ties to your green belt without overselling it |
| R6 | "What would make the first 90 days a success, in your eyes?" | Shows you're focused on outcomes, and gives you the scorecard |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run multi-site or terminal operations | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says one site's peak plan in warehouse and distribution ops. The slot in F1 and A1 stays inside your own experience |
| Has led a team at the twelve-supervisor scale | Inflated form of F4 | "I'm a senior shift manager over three supervisors." The pack's observation: three, not twelve |
| Has seven years of operations leadership | Inflated form of F5 | "Seven years in warehouse and distribution ops." The leadership-years number comes only from your own answer to A2's slot |
| Has used or built in Power BI | A negative you stated, F7 | "I haven't used Power BI." No slot |
| The mis-pick cut reduced cost-per-shipment or improved on-time | Inflated form of F8's mis-pick quote | "I cut the mis-pick rate 40% by redesigning the pick path." The pack's observation: the sentence names a mis-pick rate only |
| The pick-path redesign was a green-belt or Six Sigma project | Inflated form linking F8's two quotes | The two quotes kept separate. The C2 and E2 slots let you answer either way |
| Builds Excel reporting for others | Inflated form of F6 | "Solid Excel." The F6 slot decides the rest, in your words |

## Sources

- **Provided:** the JD text and your background, both from your message. No dossier was present.
- **Searches sent:**
  - `"Atlas Freight" regional logistics company values`: refused (web search permission not granted in this session)
  - `"Atlas Freight" operations manager interview process`: refused
  - `"Atlas Freight" terminals news 2026`: refused
- No pages were fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | The search was refused. It would have provided the official values for a cheat sheet and value-themed VAL questions. The values bank stays scaffolded and `[generic]` |
| 2. Atlas Freight interview process, operations role family | unavailable | The search was refused. It would have provided the real loop, and with it real persona weights; the weights are flat instead |
| 3. Atlas Freight strategy and recent news | unavailable | The search was refused. It would have grounded a CO or CASE question in current strategy; E3 relies on the JD and your own homework instead |
| 4. Interviewer name | n/a | No name was given, so there was no query to form |
| 5. Representative Operations Manager JD | skipped | Your pasted JD fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting and the round type (manager, peer, skip-level, panel, recruiter) → persona weights go from flat to real, and the banks get reordered
- The interviewer's name → an interviewer read, and a reverse question tied to their own career path
- Any recruiter guidance (focus areas, a case or presentation to prepare) → a build section for each announced deliverable
- Web search allowed → Atlas Freight's values, interview process and recent news; a values cheat sheet if a values-style round shows up; one CO or CASE question grounded in their current priorities
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → strategy and organisation context for sharper case questions
- Your full CV → more evidence quotes, so F2, F3 and F6 might stop being empty or thin
- Your answers to the slots (years leading people, any on-time or cost measures you've owned, Excel reports you've built) → F2, F3, F5 and F6 become quoted evidence, and A2, A3, B2 and B3 become story-mapped
- Your green belt certificate details, and a KPI report you've built → F8 and F6 can rise to `high` confidence, because those are the documents this field can actually show
- Your prep time before the interview → a prioritised prep schedule
- A tuesday-dossier.md from underwriting this role → the main objection backed by evidence rather than inferred, plus a binding list of claims not to make
