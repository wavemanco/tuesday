Many references needed. Read them in parallel.
I've built your prep pack and saved it as `Quartzline_product-manager-platform-apis_interview_pack.md`. It's for the 45-minute call with the hiring manager and uses only your dossier. I tried three web searches (company values, interview process, recent news) but this session wasn't allowed to search, so nothing in the pack about Quartzline itself comes from research. Those rows are marked as general role patterns.

**What to rehearse most:** question A1, the objection your dossier named: *"You have never held the PM title or owned a roadmap — why should we hire you…"* The answer has four parts:
1. Admit the gap plainly first.
2. Give the adjacent case using only your verified sentences about the 30+ integrations and the roadmap-input sessions.
3. Mention up front that there's little to show from those sessions.
4. Finish with a 90-day plan.

It includes a ladder of likely follow-ups (C3, A2, D2). If you only have time for a little, rehearse A1 and D2.

**Two things I deliberately left out of your mouth:**
- **The "seven years" from the dossier summary.** It's the underwriter's summary line, not one of your verified sentences, so the pack never states a tenure for you. E1 has a spot where you give your own dates.
- **Anything that makes the roadmap-input sessions sound like owning the roadmap.** Your dossier marks that as a gap to admit, not one to bridge.

**Dates to check:**
- Today is Thursday, 12 November. If the interview is today, A1 and D2 are the whole plan.
- Your dossier is from 14 August. If you have the current posting, check it against the requirements the pack uses.

I can play the Skeptic and run A1 with you live, with follow-ups that react to what you actually say.
I can also update `tuesday-dossier.md` with the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview Prep Pack — Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager (name not given). One session, your future manager.
**Built on:** your `tuesday-dossier.md` (job-underwriter, v1.1, generated 2026-08-14, decision `conditional_go`). Live research was attempted and refused by this host, so nothing here about Quartzline itself comes from outside your dossier.

---

## How to use this pack

- **Personas** are *how* a question arrives (style, register). **Types** are *what* is being scored.
- Type key:
  - **VAL** — behavioral/values: does your past behavior show the value being asked about
  - **EXP** — experience deep-dive: do your stated claims survive scrutiny, and what was actually you
  - **JD** — role-driven: can you do the listed job, including its gaps
  - **CO** — company knowledge: homework depth on Quartzline
  - **CASE** — live problem from the role: structure and reasoning, delivered aloud
- **Provenance labels:** `[grounded]` traces to your dossier; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about you or Quartzline.
- **Guidance is scaffolding, not a script.** Say it in your own words. An **answer slot** is a place where only you know the answer: it gives two honest branches and never a fact for you to say.
- **Your three verified sentences** (from the dossier's `verified_candidate_evidence`), referred to below as VE1–VE3. Every claim this pack makes about your past is one of these, word for word:
  - **VE1** — "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (high confidence; the integration playbook was provided)
  - **VE2** — "Wrote the internal integration playbook her team uses" (high confidence; inspectable)
  - **VE3** — "Ran quarterly roadmap-input sessions feeding client evidence to product" (medium confidence: confirmed, limited inspectable proof — expect a probe)
- The dossier's summary line mentions years of integration leadership. That is the underwriter's summary, not one of your verified sentences, so this pack never puts a tenure in your mouth. Where tenure helps, you get an answer slot.
- Question IDs: A, B, C, D, E, G, H by persona (F is used for fit-snapshot rows, so no bank is lettered F).

---

## Fit snapshot

Requirements come from the dossier's `role_profile`, which stands in for the JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | low | [inferred] | transferability | The dossier's strategy is `bridge`: adjacent, never PM experience. Derivation: VE1 and VE3 sit next to product work and are not the PM job. Words: first the plain acknowledgment, from `prohibited_claims: "Having held a product manager title or role"`, "I haven't held the PM title." Then the adjacent case in the quotes' own terms: "I led 30-plus end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live, and I ran quarterly roadmap-input sessions feeding client evidence to product." Limit to keep: adjacent, not equivalent. Let the interviewer draw the conclusion. Don't tell them what the work proves |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as `acknowledge_gap` ("Owning a roadmap and prioritization authority"). No bridge, and VE3 is not used here, because input to a roadmap is not ownership of one. Words, from `prohibited_claims: "Having owned a product roadmap"`: "I haven't owned a roadmap." Then a ramp plan, said as a plan and never as a past: how you would learn this platform's decisions, partners and constraints in the first 90 days |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | transferability | My observation, not words for you: your material covers integrations *of* the vendor's APIs, not shipping an API product. Words stay at VE1's scope: client integrations, led end to end, to go-live. Answer slot: R2's "shipped" makes a probe on what went live likely. Say in your own words what was live at go-live and who used it. If you can't say it cleanly, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Wrote the internal integration playbook her team uses" — dossier VE2 | high | [grounded] | discovery | The quotes cover REST API integrations and the playbook, but they don't show docs and schemas work directly. Answer slot: if you read or wrote API docs or schemas in that work, say which and what you did with them, in your own words. If not, say so plainly and point to the playbook you wrote. The playbook is inspectable, so offer to show it |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | medium | [grounded] | discovery | VE1 covers clients and VE3 covers product. Your material says nothing about engineering or sales. VE3 is medium, so offer its limit before you're asked: you ran the sessions, and there's little to show from them. Answer slot: if you worked with engineering or sales in this work, say with whom and what part was yours. If not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [inferred] | discovery | The dossier's strategy is `clarify` ("Agile delivery inside a product org"). None of your verified sentences covers it. Answer slot: expect "agile delivery experience" as the probe. If you've worked that way, say how, in your own words. If you never worked in sprints or a product-org cadence, say so plainly. Either way, close with what you'd want to confirm about how this team defines its delivery cadence |

---

## Persona table

The loop is set by your own words: one 45-minute conversation with the hiring manager. These weights come from that, not from a guessed Quartzline process. No interviewer profile was given, so nothing is adjusted for them.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet pressure on F1 and F2: no PM title, no roadmap | **High (5).** A hiring manager is reducing risk, and the dossier named this objection | Rehearse A1 until it bores you. Concede plainly first, then give the adjacent case from VE1 and VE3, then a ramp plan |
| Case/Strategist (B) | Live problems from the role: adoption metrics, squad tradeoffs, partner discovery, specs | **High (5).** Hiring managers check whether you can do their actual job | Clarify, then objective, segment, approach, metrics, risks. Think out loud. Cases ask nothing about your past, so you don't need to stretch it |
| Data-Driven Prober (C) | "30+", the playbook, the sessions, agile | **Mid (4).** VE1 has a headline number, and VE3 is the medium-confidence seam | Know how the 30+ was counted, or say you don't. Volunteer VE3's limit before it's dug out |
| Pressure (D) | Time-boxed "why you" and "that's not PM" challenges | **Mid (3).** Likely in short bursts around the F1 gap | Pause, restate, hold on VE1 through two follow-ups, and concede the title plainly |
| Conversational (E) | The opener, "why here", what you're tinkering with | **Mid (3).** The first five minutes of any HM call, and still scored | A 90-second arc built only from VE1 to VE3 plus your own dates |
| Values/Behavioral (G) | One or two behavioral probes | **Low (2).** No values round was named and Quartzline's values weren't researched | Selection scaffolds with honest branches |
| Peer Evaluator (H) | "How will you work with my squad leads and sales?" | **Low (2).** The squad-authority question is a known unknown, and a manager may test that seam | Offer principles for the seam rather than pretending to know it. Turn it into reverse question R1 |

---

## Question banks

### A — Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"` | **The highest-ROI rehearsal in this pack. The underwriter named this objection.** (1) Concede first, cleanly: "That's right. I haven't held the PM title and I haven't owned a roadmap." (2) The adjacent case, in the quotes' words: "I led 30-plus end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live, and I ran quarterly roadmap-input sessions feeding client evidence to product." (3) Volunteer the limit on the sessions before you're asked: there's little to show from them. (4) The ramp plan, as a plan: what you'd learn first about these partners, these squads and how adoption is measured. (5) Stop. Don't argue that the work *is* PM experience, and don't call it proof of anything. Let them weigh it. **Follow-up ladder:** "So what did those sessions change?" goes to C3's slot. "Have you prioritized for a squad?" goes to A2's acknowledgment. "Isn't that just integration management?" goes to D2. Each time, return to VE1 and add nothing to it | F1 and F2 are the two biggest gaps, and this question hits both. JD, because it scores R1 directly. Both negatives in it come from the dossier's prohibited claims, so it's asked as the underwriter wrote it |
| A2 | "Have you ever set priorities for an engineering squad?" | JD | [grounded] `prohibited_claims: "Having set prioritization for an engineering squad"`; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Plain acknowledgment: "No, I haven't set priorities for an engineering squad." Then VE1 in its own words. Answer slot: the JD's "drive delivery with two engineering squads" makes this likely. If the integrations you led involved working with engineers, say what part of that was yours, in your own words. If not, say so plainly and stay with the integrations. Close with how you'd plan to earn the squads' trust, as a plan | F2 sits beside the two-squad responsibility. This is the second follow-up to A1, rehearsed separately so the "no" comes out calm |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas: "Owning a roadmap and prioritization authority (R1 sub-claim)"`; `prohibited_claims: "Having owned a product roadmap"` | Name F2 yourself: "Owning the roadmap. I haven't owned one." Naming the weakness before they find it reads as self-awareness. Then the ramp plan: who you'd meet in the first 30 days, what you'd baseline, and when you'd propose your first prioritization call. Answer slot for F6: if agile delivery inside a product org is new to you, say so as a second, smaller item. If it isn't, leave it out | The Skeptic stem, aimed at F2. Picking the true weakness beats a humblebrag |
| A4 | "Why move from integrations into product management now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Motivation is yours, so this is an answer slot: say in your own words what's pulling you toward the role. The pack can't supply that. If VE3 is part of the reason, it's the natural anchor: you ran sessions feeding client evidence to product. Don't say more about them than that. Keep it about wanting the role, not escaping your current one | Motivation consistency is what the Skeptic scores. F1 makes "why now" inevitable |
| A5 | "You've led integrations of a vendor's APIs. What don't you know yet about owning an API platform?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start from VE1, at its scope. Then name real unknowns as things to learn, not things you've done. Topics from the platform side of the problem: versioning and deprecation, pricing or access tiers, internal API consumers, and how adoption is instrumented. Pick the two you genuinely know least and say how you'd close each | F3 is a must-have with a transferability gap. Naming what you don't know ahead of time defuses "shipped API products" |

### B — Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Adoption of the partner APIs is yours to define and track. How would you define it, and what would you look at first?" | CASE | [generic] | Clarify first: who counts as a partner, and what counts as adopted (keys issued? live traffic? retained usage?). Then a funnel: signed up, first successful call, production traffic, sustained volume, expansion to more endpoints. Segment by partner tier and by endpoint. Add one guardrail metric such as error rate or time to first call. Close by asking what the baseline is today. That's reverse question R2, asked naturally | Responsibility "Define and track adoption metrics". The dossier lists the current baseline as unknown, so the question is likely and your follow-up question is earned |
| B2 | "Two squads, one quarter, three partner asks that each need most of a squad. Walk me through how you decide." | CASE | [generic] | Clarify: are the asks contractual, revenue-tied, or strategic? What does each unlock in adoption? What's the engineering cost and risk? Make the tradeoff explicit, recommend one, and say who you'd align with before committing: the squad leads, sales, the partner. Then ask how decision rights split between this role and the squad leads. That's R1 | Responsibility "drive delivery with two engineering squads", plus the dossier's open question on authority. CASE, so it presupposes nothing about your past |
| B3 | "A large partner says our docs are why their integration is late. Diagnose it." | CASE | [generic] | Separate the symptom from the cause: is it the docs, the API design, onboarding, support, or the partner's own capacity? What would you ask the partner, what would you look at (support tickets, time to first call, where the integration stalled), and what would you fix this week versus this quarter? Answer slot: if one of the integrations you led stalled in a comparable way, you may use it, saying only what happened and what your part was. If none did, solve it as a live problem | R3 (docs, schemas), delivered as a live problem |
| B4 | "Plan your first 60 days of discovery with our integration partners. What do you need to know first?" | CASE | [generic] | Clarify the goal: roadmap input, churn risk, or adoption blockers. Pick a partner sample across tiers, including one unhappy partner. Prepare an interview guide. Pair qualitative findings with usage data. Have a synthesis cadence and a readout to the squads. End with the decisions the discovery should inform | Responsibility "Run discovery with integration partners" |
| B5 | "Outline the spec you'd write for a new partner-facing endpoint." | CASE | [generic] | Problem and partner need, who uses it and how, success metric, the endpoint and its schema, auth, errors, rate limits, versioning and deprecation, docs and sample requests, rollout and beta partners, open questions for engineering. Keep it a structure, not a story about specs you've written | Responsibility "Write specs and drive delivery", plus R2 and R3. Tests whether you think like the owner of an API, not a consumer of one |

### C — Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30-plus was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say "30-plus", the number as written, never more. Answer slots, each in your own words: how it was counted; what it's sensitive to; the assumption behind it you'd defend least, named before they find it; and which part was yours. If you don't know exactly how it was counted, say so plainly. That's an honest answer | Defend-the-number rule: VE1's figure is the headline in your material |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Keep the scope: you wrote it, and your team uses it. Don't widen it past your team. Describe what's in it in your own words, and offer to share it, since it's inspectable. Answer slot: if it changed how your team runs integrations, say what changed. If you can't point to a change, say what it's for and stop there | VE2 is high-confidence and inspectable, the strongest artifact you have. Also covers F4 |
| C3 | "Tell me about the roadmap-input sessions. What came of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Volunteer the limit first: you ran them quarterly to feed client evidence to product, and there's little to show from them. Answer slot: if any evidence you fed led to something product did, and you know what, say it in your own words. If you don't know, or nothing traceable came of it, say so plainly and describe what the sessions were. Never describe them as setting the roadmap | VE3 is medium confidence, and the dossier says to expect a probe. F2 means this is the seam a prober opens |
| C4 | "How have you worked in sprints or an agile cadence with a product team?" | JD | [inferred] | The `clarify` strategy applies (F6). Answer slot: the probe is "agile delivery experience". If you've worked that way, say how, in your own words. If you never worked in sprints or a product-org cadence, say so plainly. Then ask what you'd want to confirm about how this team runs delivery: sprint length, who owns the backlog, how the squads plan | R5 needs its own JD question. Derivation: R5 is preferred, the dossier marks it as discovery, and none of your sentences covers it |

### D — Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who's already a PM here?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims: "Having held a product manager title or role"` | Pause and restate. Concede in one line: "They'd have the title. I haven't held it." Hold on VE1: 30-plus end-to-end client integrations of the vendor's REST APIs, to go-live. Then add your ramp plan. Hold through two follow-ups. If pressed, concede uncertainty specifically ("I'd be learning the roadmap side here"), and don't fold on VE1 | F1 under a time box. Hold-then-concede practice |
| D2 | "Honestly, that's integration management, not product management. Convince me otherwise." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims: "Having held a product manager title or role"` | Don't try to convince them it's PM. That's the line the dossier draws. Concede: "You're right, it isn't the PM job." Hold: "It's the work right next to it: I led 30-plus client integrations of the vendor's REST APIs end to end." Then ask what they'd most want to see from you to close that gap. That question turns the challenge into a conversation | The likeliest rewording of A1. Rehearsing the concession keeps you from over-claiming under pressure |
| D3 | "Thirty integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say "we" for the team and "I" for what you did. VE1 says you led them. Answer slot: say which of scoping, requirements, architecture, UAT and go-live were yours to do or decide, in your own words. If others did parts of it, say so plainly. Credit given precisely beats credit claimed | The Pressure stem on attribution, aimed at the one figure in your material |

### E — Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: where you are, the three things in your quotes (the integrations, the playbook, the sessions), and why this role is next. Answer slot: give dates and tenure as they appear on your CV. This pack doesn't hold them. End on the role, not on your history | The opener is scored. All three of your sentences belong in it |
| E2 | "What are you playing with in API design or docs these days?" | JD | [inferred] | Answer slot: if you're actually exploring something (an API spec format, a docs tool, a public API you admire), say what and why, in your own words. If not, say so and name one public API whose docs you'd learn from, and why | R3 asked casually. Derivation: casual questions about a JD skill are still scored |
| E3 | "Why Quartzline?" | CO | [generic] | Answer slot: what genuinely draws you to this company and this platform, in your own words. This pack holds no researched facts about Quartzline, so don't quote any you haven't checked yourself. Tie your answer to the role's partner-facing scope | Every HM round asks it. `[generic]` because research couldn't run |

### G — Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, where you said the hard thing and it actually landed, and where the relationship survived. Say "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Persona stem. Without researched values, it's themed only by the persona |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, the metric it cost, and the customer outcome. If none of your integrations involved a moment like that, say so plainly and describe how you'd weigh it | A partner-facing role makes this a natural probe |

### H — Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "My two squad leads have strong roadmap views. Where's the seam between you and them, and what happens when you disagree?" | JD | [generic] | Offer principles for the seam, not pretended knowledge of it: the PM owns the problem and the priority, the leads own the how and the estimates, disagreements surface with data, and escalation is rare and explicit. Then ask how it actually works here. That's R1. Don't describe a past squad relationship your material doesn't show | R4, plus the dossier's open question on squad authority. A manager may test this seam directly |
| H2 | "Sales promised a partner something that isn't on the roadmap. What do you do?" | CASE | [generic] | Clarify what was promised and by when. Talk to the sales rep before the partner. Size the ask against the roadmap. Give a clear answer and an alternative. Agree a process so it doesn't recur. You stay the honest broker | R4's sales side, which none of your sentences covers (F5), asked as a live problem |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 — 3+ years product management experience | A1, A3, A4, D1, D2 |
| R1 sub-claim — owning a roadmap and prioritization | A1, A2, A3, C3 |
| R2 — Shipped API or platform products | A5, B5, C1, D3 |
| R3 — Technical fluency: API docs, schemas | B3, B5, C2, E2 |
| R4 — Stakeholder management across engineering, sales, customers | A2, H1, H2, C3 |
| R5 — Agile delivery experience | C4, A3 |
| Responsibility — adoption metrics | B1 |
| Responsibility — partner discovery | B4 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier. Its risk is that the authority the JD claims isn't backed up anywhere. It reads as diligence, and you need the answer before accepting |
| R2 | "How is partner API adoption measured today, and what's the current baseline?" | From the dossier. The adoption responsibility has no stated baseline, which tells you whether you'd inherit instrumentation or build it |
| R3 | "What would a great first six months in this role look like to you?" | Puts their success criteria on the table, and gives your ramp plan something to aim at |
| R4 | "Which partner relationship is hardest right now, and why?" | Shows you're thinking about partners on day one, and grounds B4 in their reality |
| R5 | "How do requests from sales and from partners reach the roadmap today?" | Probes the R4 seam and the authority question from another angle |
| R6 | "Is this role new, or is someone moving on, and what did the team learn from that?" | Tells you whether you'd inherit a roadmap or a vacuum |

---

## Prohibited claims

What this pack won't coach. The first three come from your dossier and are absolute.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | Plain acknowledgment: "I haven't held the PM title." Then VE1 and VE3 as adjacent work |
| Having owned a product roadmap | Dossier `prohibited_claims`, and `acknowledge_gap` area | Plain acknowledgment: "I haven't owned a roadmap." Then a ramp plan. No bridge from VE3 |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | Plain acknowledgment: "I haven't set priorities for an engineering squad." No slot |
| Shipped an API product | Inflated form of F3 | VE1 at its own scope. My observation, not your words: your material says integrations *of* the vendor's APIs |
| Wrote product specs | Inflated form of VE1's "requirements" | VE1's word, "requirements", at its scope. B5 is a live outline, not a past claim |
| Playbook adopted beyond your team | Inflated form of VE2 | VE2 at its scope: "the internal integration playbook my team uses" |
| Roadmap-input sessions shaped or decided the roadmap | Inflated form of VE3 | VE3 at its scope: ran quarterly sessions feeding client evidence to product. C3's slot asks only what came of them |

---

## Sources

- **Dossier consumed:** `tuesday-dossier.md`, envelope v1.1 (within the 1.x this pack reads), generated 2026-08-14, about three months before this pack. Sections used: `handoff_to_mock_interview` (verified evidence VE1–VE3, weak areas and their allowed strategies, the A1 objection, risks and employer questions for R1 and R2, prohibited claims) and `role_profile` (requirements R1–R5 and responsibilities, which stand in for the JD). `decision` was read as context only. No `evidence_map` was included, so fit-snapshot grading for rows the handoff doesn't cover (F3, F4, F5) is this pack's own.
- **Searches sent:** "Quartzline company values" (refused); "Quartzline interview process product manager" (refused); "Quartzline partner API platform news 2026" (refused). No fetches.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Refused. Would have themed G1 and G2 on published values, and decided whether a values cheat sheet applies anywhere in the loop |
| 2. `Quartzline interview process product management` | unavailable | Refused. Your own words already set this session (one 45-minute HM conversation), so it could only have shown whether a values-style round sits elsewhere in the loop |
| 3. `Quartzline strategy` / recent news | unavailable | Refused. Would have added a CO or CASE question grounded in Quartzline's current platform strategy, and made E3 specific |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no search to run. No interviewer read |
| 5. Representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Permission to search, or a deeper pass (up to 6 more searches and 2 more fetches, several more minutes)** → Quartzline's published values to theme G1 and G2, a CO/CASE question on current platform strategy, and a specific answer to E3 (targets 1–3).
- **The hiring manager's name** → an interviewer read from their public professional footprint, adjusted persona weights, and a reverse question tied to their path.
- **The recruiter's prep email, or any stated focus areas** → coverage of anything they flagged, plus a build section for any deliverable announced in advance.
- **The current JD text** → confirms the August `role_profile` still matches the posting before Thursday.
- **Your answers to the slots in C1, C3 and E1** (how the 30+ was counted, what came of the sessions, your dates) → those rows and F1 become story-mapped instead of slotted.
- **An engineering or sales story from your integration work** → F5 and A2 gain a quoted story in place of a slot.
- **Whether you've worked in sprints or an agile cadence** → F6 and C4 resolve one way or the other.
- **A readout, agenda or summary from one roadmap-input session** → raises VE3 from medium toward high, and C3's limit shrinks.
- **How much prep time you have** → a prioritized prep schedule.
- **Any later rounds on the calendar** → per-round mini-packs with their own weights.
