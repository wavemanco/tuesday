Quick update: I've read the prep playbook. Now I'm running a small research pass on Saltmarsh Games and Tobias Wrenfield before I build the pack.
I've saved your prep pack for Friday's interview as `saltmarsh-games_live-operations-producer_interview_pack.md`.

**What the interview will actually be.** Saltmarsh's careers page calls this round "the Outage Hour": one 60-minute interview with the hiring manager, in two halves.
- **First half:** a live-incident tabletop, where you talk through how you'd handle a simulated outage during a live event.
- **Second half:** a values conversation built around their three published values: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener.
- **No take-home.**

The pack assumes Tobias is that hiring manager, so most of the questions are tabletop problems and values questions.

**Two things worth knowing going in:**
- **Tobias came to live ops from QA.** A GDC 2026 talk listing says he was a QA lead before Head of Live Operations, and his talk was called "Patch Notes Are a Promise". Your release checklist is your strongest match to both him and the "Leave the Build Greener" value. Expect him to dig into it in real depth.
- **Saltmarsh announced Project Larkspur in September.** From February 2027, two of its titles, Tidepool Tactics and Lantern Row, move to a season pass and one shared events calendar. That gives you a strategy question most candidates won't have prepared (A4). It also explains why your "never worked on a game with in-app purchases" may come up (C4).

**The rehearsal that matters most is C1:** "This role coordinates design, art, engineering and community on every update. Tell me how that worked on your content drops." Nothing you've told me shows who you worked with on each drop. The pack keeps "coordinated teams" and "led a team" apart, so you don't trade one for the other under pressure.

The pack has 22 practice questions. It also has a short plan for tonight, a table matching each JD line to what you've told me, a values cheat sheet, six questions for you to ask Tobias, and a list of claims you shouldn't make in the room. I read Saltmarsh's values and interviewing pages in full, but only the search previews of the Larkspur news and Tobias's talk.

If you want a practice run, I'll play the Skeptic on C1, the question the pack marks as the highest-value rehearsal.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** one 60-minute interview, Friday 13 November 2026. Saltmarsh's careers page calls this round "the Outage Hour": "a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." The pack assumes Tobias is that hiring manager.

---

## How to use this pack

Two axes. **Personas** describe *how* a question is asked: who is asking, and in what style. **Types** describe *what* is being scored:

- **VAL**: values. Does your past behaviour show Saltmarsh's three published values?
- **EXP**: experience deep-dive. Does what you said about your past hold up, and which part was yours?
- **JD**: the job description. Can you do the listed job, gaps included?
- **CO**: company knowledge. Do you know what Saltmarsh is doing right now?
- **CASE**: live problem. How you structure and reason through a problem from the role, out loud.

The guidance is scaffolding, not a script. Where a cell says **Answer slot**, the pack does not know the answer. You fill it in the interview from what actually happened, or you say plainly that it didn't happen.

Every row carries a provenance label: `[grounded]` traces to your message, the JD or a Saltmarsh page in Sources; `[inferred]` is the pack's own derivation, named; `[generic]` is a common pattern for this kind of role with no claim about Saltmarsh or you.

---

## Prep triage: the interview is tomorrow

In order, for one evening:

1. **C1 out loud, twice.** This is the highest-ROI rehearsal in the pack: the coordination objection, held at the scope of what you said.
2. **The tabletop, timed.** Run A1, then E2 straight after it, aloud. Get the clarify, contain, communicate, review order into your mouth.
3. **The three value names, exactly.** Players Before Plans; Ship the Patch Not the Promise; Leave the Build Greener. Then B3 (your checklist story) and pick your B1 story.
4. **D1.** Know what you can and cannot say about how the retention numbers you presented were counted.
5. **Reverse questions.** Pick three from the list below. If you can find the abstract for Tobias's GDC 2026 talk, read it before using RQ1.
6. **If you have twenty minutes:** play Tidepool Tactics and Lantern Row, the two titles Saltmarsh's Project Larkspur announcement names. This feeds A4 and R2.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title; the JD says a live-events calendar for two. Your words stay at your scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "plan and run" makes a probe on planning likely. If deciding what went into the calendar, and when, was yours, say how you decided, in your own words; if it wasn't, or there was no such step, say so plainly and describe how you ran it |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show who you worked with on each drop. Your "Never led a team" is a different statement from this one, and the pack keeps them apart: coordinating is not leading, so don't trade one for the other in either direction. Answer slot: if running the calendar meant working with design, art, engineering or community on each drop, say which teams and what you did with them, in your own words; if it didn't, or that sat with someone else, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Presenting monthly retention numbers is not owning a post-event review, and the bridge is not stretched: "I presented the monthly retention numbers to the studio head." Answer slot: if you ever reviewed a content drop after it went out, say what you looked at and who saw it, in your own words; if there was no such review, or it wasn't yours, say so plainly and say what you would put in one, as A3 rehearses |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist is next to managing it with QA on each release, but it is not the same thing, and your words stay with what you did: "I wrote the release checklist our QA team still uses." Answer slot: if running it with QA on each release was also yours, say how, in your own words; if it wasn't, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Four years clears the length. What your material does not show is whether the main title was a game players kept playing while the drops landed. Keep your title exact: associate producer. Answer slot: if the weekly drops went to a game players already had and kept playing, say so in your own words; if not, say so plainly and describe what the drops were |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. It is one line with nothing to show behind it yet, so expect a probe. Lead with it in its own terms: weekly, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in wording, but expect the probe D1 rehearses. Answer slot: the JD's retention line makes a question on how those numbers were counted likely. If you know, say how, in your own words; if you don't, say plainly that you don't know how they were counted and stay with what you presented and to whom |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist your QA team still uses is one piece of writing that is still in use, not the whole of written communication, and the words stay at that scope. The writing you do live tomorrow, E2's player post and A3's review outline, is the evidence the interview itself can see |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A4, A5, B1, C1 |
| Coordinate design, art, engineering and community (F2) | C1, A1, P1, P2 |
| Own the post-event review and its KPIs (F3) | A3, D2, C2 |
| Manage the release checklist with QA (F4) | D3, A2, B3 |
| 3+ years producing live-service games or apps (F5) | C3, R1 |
| Running a content calendar (F6) | C1, B1 |
| Player-retention metrics (F7) | D1, D2, C4 |
| Clear written communication (F8) | E2, B4 |

---

## Reading the interviewer

From one search result only. The talk itself was not read; see Sources.

- **Career pattern:** the GDC 2026 listing gives Tobias as Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio.
- **Public theme:** his GDC 2026 talk, "Patch Notes Are a Promise". The listing summarises its argument as: "a live team is judged by how often its patch notes describe what actually shipped." That matches Saltmarsh's published value "Ship the Patch Not the Promise".

Practical implications:

1. **Player-facing honesty is likely scored in the tabletop.** When you draft a player message (E2, A1), say only what is known, and give the time of the next update rather than a fix time you haven't been given.
2. **QA is his home ground.** F4 and A2 will meet someone who has run QA. Describe your checklist exactly as it is and don't improvise QA practice you haven't done. He would notice.
3. **Don't cite his talk unless you've read at least its abstract.** Quoting a summary you got second-hand, to the person who gave the talk, is a risk with no upside.

Mirror opportunities: no shared career jump is offered, because no fit-snapshot row carries one. Shared vocabulary does exist: the checklist. In F4's words, "I wrote the release checklist our QA team still uses." That sits naturally next to the QA background and next to "Leave the Build Greener".

---

## Persona table

The loop is set by Saltmarsh's own careers page, so these weights rest on this company's documented round, not on a general pattern.

| Persona | How it shows up tomorrow | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The live-incident tabletop: a simulated outage during a live event | Highest. The careers page names the tabletop as the first half of the hour, and hiring-manager rounds lean this way anyway | Clarify, then contain, then communicate, then review. Think aloud; state what you would need to know before deciding |
| Values / Behavioral | The values conversation, mapped to three published values | High. The careers page names a values conversation as the second half | One story or a chosen scaffold per value, by its exact name; "we" for context, "I" for your part |
| Skeptic | Gap probes: coordinating four disciplines, two titles at once, the step from associate | High. Hiring managers buy capability and de-risk gaps, and F1, F2 and F3 are where the material is thinnest | Rehearse C1 until it's boring. Hold at the scope of your quotes, concede plainly, give a ramp plan as a plan |
| Data-Driven Prober | "Which retention numbers, counted how?" | Medium. The JD names retention metrics and KPI ownership, and you told me you presented retention numbers | Know what you can and cannot say about how those numbers were counted; say "I don't know" where that's the truth |
| Pressure | Time-boxed interruptions inside the tabletop | Low to medium. A simulated outage invites "players are posting, now what?" pressure | Pause, restate, answer the smallest true thing first |
| Conversational | The opener, and casual asides | Low. One hour with two named halves leaves little room, but the opener is still scored | A 90-second arc, rehearsed |
| Peer Evaluator | Cross-team seams inside the tabletop or the values half | Low. The interviewer is not a peer, but the JD's four-discipline coordination produces seam questions | Propose seam principles; don't pretend to know Saltmarsh's seams |

---

## Question banks

### A — Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend live event and event rewards have stopped granting for a chunk of players. Walk me through your first thirty minutes." | CASE | [inferred] | Clarify first: which title, how many players, is it still spreading, which platforms. Contain: get engineering looking, ask whether the event can be paused or extended, keep QA close to any fix. Communicate: a first player post saying what's known and when the next update comes, nothing promised that isn't confirmed. Review: start a timeline now, because the post-event review needs it later. Say each step aloud as you choose it. The question needs no claim about your past, so the guidance makes none | The careers page describes the tabletop as "a simulated outage during a live event"; the specific scenario is this pack's derivation from that line, so `[inferred]`. CASE because it scores structure live |
| A2 | "Engineering has a fix ready but QA hasn't finished testing it, and the event ends in four hours. Do you ship it?" | CASE | [inferred] | Don't give a one-word answer; name what decides it: how bad the player impact is, what the fix touches, what QA can check in the time, whether it can be rolled back, and whether extending the event buys the time instead. Say who makes the final call and what you'd want written down. No claim about your past is needed | The JD's QA-checklist line plus the tabletop format make a ship-or-hold call likely, and Tobias's QA background makes it likely to be probed hard. CASE delivery on JD content (F4's requirement) |
| A3 | "The outage is fixed. What goes in your post-event review, and what do players hear?" | CASE | [grounded] | Structure: timeline; player impact, counted; cause, from engineering; what players were told and when; compensation decision; what changes on the release checklist so it doesn't recur; which KPIs moved. Then the player-facing summary: shorter, plain, no blame. No claim about your past is needed | Rests on the JD's "own the post-event review and the KPIs it reports" (F3's requirement), which your material doesn't show, so rehearsing the structure matters. CASE on JD content |
| A4 | "From February, Tidepool Tactics and Lantern Row share one events calendar. What are the first risks you'd plan for?" | CO | [grounded] | Clarify: are the two titles' audiences overlapping, and what is fixed by the season pass. Then risks: two titles' events colliding for shared engineering and QA time, community messaging that has to stay per title, and a calendar that now has one owner group instead of two teams. If season-pass economics come up, answer from your quotes and say plainly where your experience stops; C4 rehearses that line | Saltmarsh's September 2026 Project Larkspur announcement moves both titles to "one shared events calendar from February 2027". This is the strategy question most candidates can't touch. CO content, CASE delivery |
| A5 | "Two events on the shared calendar both need the same engineering week. How do you decide?" | CASE | [grounded] | Clarify what each event is for and what slipping costs players. Use "Players Before Plans" by name: when the calendar and the players disagree, the players win. Then the mechanics: who you'd bring together, what you'd put in front of them, and how the decision gets written down and told to both teams. No claim about your past is needed | Follows directly from the JD's two-title calendar (F1's requirement) and Larkspur's single calendar; the value gives you a stated tie-breaker. CASE |

### B — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | A selection scaffold. Your sentence gives you the calendar, not a disagreement, so pick one if it exists: a time something on the weekly content-drop calendar changed because of what players were doing or saying. It needs what was planned, what players showed, what changed, and your part in it. If no such time comes to mind, say so plainly, then give the nearest thing you have: how you'd handle it on Saltmarsh's calendar | The value's own wording sets the theme. F1 and F6 give the calendar, and the story itself has to come from you. VAL |
| B2 | "Ship the Patch Not the Promise: when have you held back from announcing something that wasn't built yet?" | VAL | [grounded] | A selection scaffold. Pick a time an announcement waited for the build, or was cut back to what existed. It needs what was about to be said, why you held it, and what happened after. If no such time comes to mind, say so plainly, then say how you would decide what goes in a player announcement. No claim about your past is supplied | The value's wording sets the theme, and it is the one closest to Tobias's public theme. Nothing in your material speaks to it yet, so it is a scaffold. VAL |
| B3 | "Leave the Build Greener: tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the release checklist, and your QA team still uses it. Those are the beats your sentence gives; tell them in your own words. Answer slot: the value says "every release leaves the codebase and the checklist better than it found them", so expect a probe on what came before. If your checklist replaced or improved an earlier one, say what changed; if there was nothing before it, say so plainly and describe what yours covers | Your strongest single match to a published value, so lead the values half with it if the order is yours. VAL |
| B4 | "How would you make sure what we tell players about an event matches what actually shipped?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Structure first: one source of truth for what's in the build, a sign-off step before any announcement, and the announcement written from that list rather than from the plan. Answer slot: if the release checklist you wrote has a step like this, say what it is, in your own words; if it doesn't, say so plainly and say where you'd add one | "Ship the Patch Not the Promise" raises it, and it tests the JD's written-communication line (F8's requirement). VAL theme, JD content |

### C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role coordinates design, art, engineering and community on every update. Tell me how that worked on your content drops." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Never led a team, and never worked on a game with in-app purchases." | **The highest-ROI rehearsal in this pack.** Hold only what your sentence carries: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if running it meant working with design, art, engineering or community on each drop, say which teams and what you did with them, in your own words; if it didn't, or that sat with someone else, say so plainly and describe what running the calendar involved. Follow-up 1 ("so who did you manage?"): if it comes, the words are yours: "I haven't led a team." Don't soften it, and don't relabel coordination as leadership. Follow-up 2 ("then why can you do this?"): return to the calendar, then give a ramp plan as a plan, never as a past: who you'd meet in week one on each discipline, and what you'd ask them. Name the limit before it's asked for | F2 is silent and F1 is narrower than the JD, so this objection arrives in some form. Your stated negative about leading is exactly where it would land. JD because it scores the stated requirement head-on |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Choose honestly; don't offer a fake weakness. The pack's reading is that your material is thinnest on F3 (the post-event review) and F2 (coordination). If one of those is genuinely your weakest, name it, say what you do have, and give the plan. For F3, that is "I presented the monthly retention numbers to the studio head," then how you'd build the review A3 rehearses. If something else is weaker, name that instead | A standard Skeptic stem with a real answer here. Rehearsing it stops you naming a gap the interviewer hadn't noticed, or dodging one they had. JD |
| C3 | "Four years as an associate producer. Why is this the step up now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | The why is yours to give, so this is a slot for your real reason. Anchor in your sentences: four years as an associate producer, and the last two running the weekly content-drop calendar. Then why Saltmarsh, from things you can point to: the shared events calendar Larkspur announces, and a value you actually agree with. Keep the title exact | The JD's "3+ years producing live-service games" (F5's requirement) and the step from associate invite a motivation probe. JD |
| C4 | "You haven't worked on a game with in-app purchases, and Larkspur moves both titles to a season pass. How will you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "Presented the monthly retention numbers to the studio head." | Plain acknowledgment, your own words: "I haven't worked on a game with in-app purchases." Then what you do have, at its scope: "I presented the monthly retention numbers to the studio head." Then the plan, said as a plan: who you'd learn from in the live-ops group, which numbers you'd want to understand first, and studying the season pass from the player's side. Don't link retention to monetisation as if you'd done that work | You said it plainly, and Larkspur puts a season pass on both titles from February, so a Skeptic can raise it. Rehearsed once, it stays a short answer. JD on a company-driven requirement |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. Which numbers, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7: the numbers were monthly, they were retention, and you presented them to the studio head. Answer slots, each in your own words: which retention numbers they were; how they were counted, or "I don't know how they were counted" if that's the truth; which part was yours, whether gathering, analysing, presenting or something else; and the assumption behind them you'd defend least. Volunteer the limit before you're asked | The JD's retention line (F7) and KPI ownership (F3) make this the likeliest deep probe on your record. EXP because it tests what was actually yours |
| D2 | "Pick a content drop. How would you tell whether it worked?" | CASE | [inferred] | Hypothetical, so structure it: decide before the drop what "worked" means and which number shows it; compare against a fair period before; separate the drop from other things happening at the same time; say what you'd do if the numbers disagree with what players are saying. No claim about your past is needed | Tests the JD's KPI ownership (F3's requirement) as reasoning, which your material doesn't show as a record. CASE on JD content |
| D3 | "Walk me through the release checklist you wrote. Why does QA still use it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and your QA team still uses it. What's on it is yours to describe. Answer slot: the JD's "manage the release checklist with QA" makes a probe on who runs it each release likely. If that was also you, say how; if it wasn't, say so plainly and stay with writing it. The why is yours too; give the real reason and don't guess | F4 is your closest match to a JD line, and it meets Tobias's QA background, so expect real depth. EXP |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has already run live events on a monetised game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Never led a team, and never worked on a game with in-app purchases." | Pause, then hold on what you said: two years running the weekly content-drop calendar, and the release checklist your QA team still uses. Concede plainly and specifically: "I haven't worked on a game with in-app purchases." Then stop; don't fill the silence with things you haven't done. Hold that position through two more pushes | Hold-then-concede against the comparison a Skeptic would make, compressed. JD |
| E2 | "Stop. Players are already posting about the broken rewards. What do you post right now, word for word?" | CASE | [grounded] | Say it as a post: we know rewards aren't granting for some players; we're working on it; the event's rewards will be honoured (only if you've decided that in the tabletop); next update at a stated time. No fix time you haven't been given. Short sentences | "Ship the Patch Not the Promise" and the JD's written-communication line, delivered under time pressure inside the tabletop. CASE delivery, JD content (F8's requirement) |

### R — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | 90 seconds, four beats, in your words: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for the main title; writing the release checklist your QA team still uses; presenting the monthly retention numbers to the studio head. Close on why live ops at Saltmarsh. Keep the title exact | The opener is scored for economy and sets the frame the Skeptic works inside. EXP |
| R2 | "What live events in mobile games have you enjoyed lately?" | CO | [generic] | Name events you actually played and one thing each did well or badly for players. If you've played Tidepool Tactics or Lantern Row, say what you saw; if you haven't, don't pretend you have | A casual question on a hot topic is still scored. `[generic]` because no Saltmarsh fact is asserted |

### P — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Community wants to announce the next event on Monday. Engineering won't commit until Wednesday. What do you do?" | CASE | [grounded] | Use "Ship the Patch Not the Promise" by name: announce what is built. Options: announce Wednesday, or announce Monday without dates engineering hasn't committed to. Bring both into one conversation, decide, write it down. No claim about your past is needed | The JD's four-discipline coordination (F2's requirement) as a live seam, with a published value as the tie-breaker. CASE |
| P2 | "When an update spans design, art and engineering, how do you handle credit?" | JD | [generic] | A selection scaffold: pick a time credit for a shipped drop was shared out, and what your part was. If no such time comes to mind, say so plainly, then say how you'd do it: credit by name in the update notes and the review | The persona stem applied to the JD's coordination line, which your material doesn't show, so it is a scaffold. JD |

---

## Values cheat sheet

From Saltmarsh's official values page (Sources). Use the names exactly.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and what players need conflict, players win | F1: "I ran the weekly content-drop calendar for our main title for the last two years." That gives you the calendar, not a conflict. Selection scaffold: a time a planned drop changed because of players. If none comes to mind, say so plainly and say how you'd handle it (B1, A5) |
| Ship the Patch Not the Promise | Announce only what's built | Selection scaffold: a time an announcement waited for the build, or was cut back to what existed. If none comes to mind, say so plainly and say how you'd decide what goes in an announcement (B2, P1, E2) |
| Leave the Build Greener | Each release leaves the code and the checklist better | F4: "Wrote the release checklist our QA team still uses." (B3) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "You moved into live operations from QA. What did that change about how you run releases here?" | Tied to his own path. It turns the QA background into a conversation, and the answer tells you how the checklist really works on this team |
| RQ2 | "With per-title event teams retiring under Larkspur, where does this producer role sit in the single live-ops group?" | Shows you read the September announcement. You need the answer: it decides who you coordinate with |
| RQ3 | "What does a good post-event review look like here, and who reads it?" | Goes straight at F3, your thinnest row, as curiosity rather than defence, and tells you what you'd be measured on |
| RQ4 | "Which KPIs does the review report today, and does that change with the season pass?" | Shows you're thinking about February already, and the answer tells you which retention numbers matter here |
| RQ5 | "What was the last real incident during an event, and what changed on the checklist afterwards?" | Ties the tabletop to "Leave the Build Greener", and shows you care how the team learns from incidents |
| RQ6 | Only if you've read the abstract: "Your GDC talk argues patch notes are a promise. How does this role keep that promise across two titles?" | Mirrors his own public theme. Only ask it if you read the abstract |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar, or one across multiple titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title. F1's slot stays inside that calendar |
| Owned the post-event review, or owned the retention KPIs | Inflated form of F3 and F7 | "I presented the monthly retention numbers to the studio head," at its own scope. The material says presented, not owned. D1's slots ask only what you can say about those numbers |
| Managed the release checklist with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses," at its own scope. D3's slot stays inside the checklist you wrote |
| Held the title of producer | Inflated form of F5's first quote | "4 years as an associate producer," with the title kept exact |
| Led a team | A negative you stated | "I haven't led a team." No slot |
| Worked on in-app purchases or monetisation | A negative you stated | "I haven't worked on a game with in-app purchases." No slot |

---

## Sources

**Provided:** the JD text and your background, both in your message.

**Searches sent:**

1. `Saltmarsh Games values` → https://saltmarshgames.com/values
2. `Saltmarsh Games interview process producer` → https://saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile studio news 2026` → https://saltmarshgames.com/news/project-larkspur (Project Larkspur, September 2026; read from the search snippet only)
4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` → https://talks.gdconf.example/2026/patch-notes-are-a-promise (talk listing; read from the search snippet only)

**Fetches:** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet; B1–B4, A5, P1 themed on the three published values by name |
| 2. `Saltmarsh Games interview process` | yes | The loop: one 60-minute hiring-manager interview, a tabletop then a values conversation. Sets the persona weights, makes the A bank the largest, and detects the values round |
| 3. `Saltmarsh Games` strategy / recent news | yes | Project Larkspur: A4, A5, C4, RQ2, RQ4. Only the snippet was read; the page was not fetched |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, RQ1, RQ6, and the QA emphasis in A2 and D3. Only the listing snippet was read; the talk itself was not |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Deeper research (L2):** up to 6 more searches and 2 more fetches, several more minutes. It would read the full Larkspur announcement and Tobias's talk rather than snippets, and check what events the two titles are running now, which sharpens A4, the interviewer read and RQ6
- **Anything the recruiter told you about the Outage Hour**, for example which title the tabletop uses → the A bank tuned to that title
- **Your CV** → evidence cells checked against your exact lines, with dates and the studio name
- **Answers to the answer slots in F1, F2, F3, F4, F5 and F7** → tell me outside a drill and those rows, plus C1, D1 and D3, regenerate on your real answers
- **A release checklist, content calendar or retention deck you're allowed to show** → F4, F6 and F7 could move from medium to high confidence. Producers can usually show these, but check what your current studio permits first
- **A `tuesday-dossier.md` from an underwriting pass** → the objection would be evidence-derived rather than inferred, and the prohibited list checked against confirmed evidence; the pack is complete without one
