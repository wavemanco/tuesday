I've saved your prep pack as `Stripe_product-operations-manager_interview_pack.md`. It's general prep for product operations roles, not specific to Stripe. All four web searches I tried were blocked by the permission prompt, and you haven't shared a job description or CV yet. So it contains no facts about Stripe and no claims about your experience.

What's in it:
- **A fit worksheet:** eight typical product ops requirements, each with a note on what a strong story looks like so you can pick one from your own work.
- **22 practice questions:** grouped by the interviewer style they test, from live case problems to "how much of that was actually you?"
- **Reverse questions:** six to ask your interviewers.

The persona weights assume a typical structured big-tech final. That's my assumption, not Stripe's documented process.

If you want to practice now, I can play the skeptical interviewer on C1 ("Which part of this role would you be weakest at on day one?"). The pack names it as the most valuable thing to rehearse.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Who will you meet in the final round (your future manager, peers, a skip-level, cross-functional partners), and did the recruiter mention focus areas or a case or presentation to prepare? The answer changes how the pack weights each interviewer style.
2. Can you paste the job description and your CV, or a few sentences about your last two roles? Without them the pack stays a worksheet; with them it becomes coaching built on your own stories.
3. Do you want to allow web search so I can add Stripe's published principles, its interview loop and its current strategy? Otherwise I'll keep working only from what you give me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final-round prep pack

- **Role:** Product Operations Manager, Stripe
- **Round:** final round (your words). This pack doesn't know how many sessions it has or who runs them.
- **Interviewers:** not known
- **Built from:** your one-line message only. There was no job description and no CV, and the web searches I tried were refused (see Sources). So every row below is a pattern for this kind of role and is labeled `[generic]`. Nothing in this pack is a fact about Stripe.

## How to use this pack

- **Personas** describe how a question gets asked: who is asking and in what style. **Types** describe what the answer is scored on. Rehearse both. A question you know cold can still throw you if it arrives in a style you haven't practiced.
- **Type key:**
  - **VAL**: behavioral and values. Does your past behavior show the company's published values?
  - **EXP**: deep dive on your work experience. Do your claims hold up under scrutiny, and what did you actually do?
  - **JD**: the role's stated requirements. Can you do the job as listed, gaps included?
  - **CO**: company and strategy knowledge. How deep is your homework, and can you think at the company's level?
  - **CASE**: a live problem from the role. How do you structure and reason through it out loud?
- **Provenance labels:** `[grounded]` means the row traces to something you provided or to cited research. `[inferred]` means it was derived from a representative source. `[generic]` means it's a role-family pattern with no claim about this company or about you. Every row here is `[generic]`.
- **Because no CV was given, the guidance helps you choose stories. It doesn't map stories for you.** Each scaffold says what a strong story needs, and you pick one from your own work. Every scaffold ends with an honest fallback for when no story fits. Use it rather than stretching a story.
- **Guidance is scaffolding, not a script.** Answer in your own words, and aim for 90 to 120 seconds per answer.

## Fit snapshot (worksheet)

There's no JD, so these requirements are typical for product operations roles. They are written as plain prose, not quotes, and they aren't Stripe's list. There's no CV either, so every evidence cell is empty. Use each row as a worksheet: before the interview, write the one story from your own work that fills it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Turning feedback from customers and frontline teams into input for product decisions (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like this: where the signal came from, how you packaged it for a product team, and what changed afterwards, or what didn't. Pick a time you carried customer or frontline signal to the people who build the product. The story needs a named source, a format, and an outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Getting the support, sales, risk and other teams ready for a product launch (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like this: a launch, the teams that had to be ready, how readiness was defined, and what broke. Pick a launch or rollout you were part of, and be exact about which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Designing processes that keep working as volume grows, and writing them down (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like this: a process before and after, who used it, and how you knew it worked. Pick a process you built or changed. It needs a before state, a change, and a sign that it held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Defining and analyzing operational metrics, and working with data directly (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like this: a metric, how it was counted, and a decision that changed because of it. Pick a figure you can explain end to end: how it was counted, what it is sensitive to, and which part of it was yours. If you can't explain how a figure was counted, say so plainly or pick a different one |
| F5 | Influencing product, engineering, legal and support without formal authority (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like this: a person or team who disagreed, what you brought them, and where they ended up. Pick a time you moved a decision you didn't own. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritizing and making tradeoffs when the situation is ambiguous (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like this: competing demands, the criteria you used, and what you said no to. Pick a time you had to choose between two legitimate asks. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Communicating clearly with senior stakeholders, in writing and in meetings (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like this: a document or message, who it was for, and what it changed. Pick one piece of writing or one meeting where your framing moved a senior audience. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F8 | Knowing the company's products and customers (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like this: what you've used, read or built against, in your own words. Only talk about Stripe products you have actually used or read about yourself. This pack supplies no Stripe facts. If you haven't used them, say so plainly and say what you would learn first |

## Persona table

**How the weights were set.** "Final round" doesn't say how many sessions there are or who runs them, so no source establishes this loop. The weights below assume a fallback pattern: the structured loop that large tech companies often run (recruiter, then hiring manager, then skills or case, then behavioral or values, then a hiring committee). That pattern is not Stripe's documented process. It pushes Case and Values/Behavioral up. Every final-round relationship is possible (manager, peer, skip-level, cross-functional), so the other personas are blended in below them. If you know who you're meeting, the weights change (see the upgrade menu).

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: plan a launch, diagnose a spike in tickets | High. The fallback pattern puts skills and case work in later rounds, and hiring-manager and skip-level sessions lean this way too | Clarify, then state the objective, segment the problem, give your approach, name the metrics, name the risks. Think out loud and challenge one premise per case |
| B. Values / Behavioral | Story prompts, often from someone outside product ops, scored against published values | High. The fallback pattern includes a values or behavioral round. Stripe's own principles couldn't be researched, so this bank is themed by persona patterns, not by Stripe's values | Use "we" for context and "I" for your contribution. Choose stories where the hard truth actually landed. If none did, say so rather than supplying an ending |
| C. Skeptic | Quiet probing of gaps and motivation: why here, why now, and where you're weakest | Medium. A hiring manager in a final round is removing risk | Rehearse the most predictable objection until it bores you. Name the limit yourself, then give a concrete ramp plan |
| D. Data-Driven Prober | Asks how each number was counted, goes two levels deep | Medium. Metrics are core to product ops, and technical or bar-raiser-style sessions lean this way | Know how each figure you mention was counted. Name the assumption you'd defend least before they ask. Say plainly when you don't know |
| E. Peer Evaluator | Where the seams between teams are, how you disagree, how credit is shared | Medium. Product ops sits between teams, so a peer from product or support is a likely interviewer | Talk about what you'd bring their team, not only what you'd need. Propose principles for the seam rather than pretending to know where it is |
| F. Pressure | Time limits, interruptions, "how much of that was you?" | Low. Possible in a skip-level or bar-raiser session | Pause, then restate the question. Hold your position through two follow-ups, then concede specifics |
| G. Conversational | A friendly opener and the reverse-question slot | Low as a whole session, but it opens most sessions, and it is still scored | A rehearsed 90-second arc. Never answer the reverse-question slot with "I think you've covered everything" |

## Question banks

The highest-ROI prep in this pack is **C1**. A "where are you weakest" question arrives in some form in almost every final. A calm, specific, non-defensive answer changes how the rest of the conversation goes. Without your CV, the pack can't name your actual gap. You can, so pick it before the interview.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're launching a new product to merchants in three new countries next quarter, and you own operational readiness. What do you need to know first, and what's your plan?" | CASE | [generic] | Clarify first: who the users are, what changes for support, risk and sales, who signs off on compliance, and how firm the date is. Objective: a written definition of "ready on launch day". Segment by function and by country. Approach: a readiness checklist with named owners, go/no-go criteria, and a dry run. Metrics: first-week ticket volume and resolution time, the rate of issues with the launch, adoption. Risks: localization, regulatory sign-off, support staffing. Challenge one premise, such as whether all three countries should launch at once. The question asks nothing about your past, so the guidance claims nothing | Tests F2 and F6 as a live problem. CASE because it is scored on structure, not on knowing the answer |
| A2 | "Support tickets about one feature doubled in two weeks. Diagnose it." | CASE | [generic] | Define it first: doubled in absolute terms or as a share, and did ticket tagging change. Segment by customer segment, region, channel and release date. Hypotheses: a release, a change to the docs, a tagging artifact, seasonality, one large customer. Say what data you'd pull first, then contain or fix, then how you'd close the loop with product | Tests F1 and F4. The tagging-artifact hypothesis is the move that separates operators from analysts |
| A3 | "Product and Support disagree on whether a known bug deserves a fix this quarter. You're in the middle. How do you resolve it?" | CASE | [generic] | Quantify the impact: users affected, cost of the tickets, revenue at risk, whether a workaround exists. Put the tradeoff in both teams' terms. Agree on who decides, and write down the decision and when it gets reviewed. Say what you'd do if the answer is "not this quarter" | Tests F5 and F6. It's a seam problem, so it may come from a peer too |
| A4 | "Design how frontline feedback gets into product roadmaps. What would you build in your first 90 days?" | CASE | [generic] | Inventory the existing sources. Agree on a shared taxonomy. Decide intake and cadence. Close the loop back to the people who raised the feedback. Measure the system itself, for example the share of roadmap items linked to feedback and the time to a response. Name the risk: the loudest customers dominate | Tests F1 and F3, and it's arguably the core of the role. CASE because it asks for a design |
| A5 | "Pick one metric that would tell you an operational process is working, and tell me how it could mislead you." | CASE | [generic] | Name the metric and its denominator. Say how it could be gamed or could drift, and pair it with a counter-metric. This is the weakest-assumption move done in advance | Tests F4. It's a Prober-style question delivered as a case |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they didn't want to hear. The story needs the audience, the truth, how you framed it, and what happened next. Choose one where it landed. If none did, say that plainly rather than supplying an ending. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F7. The theme is the Values persona's stem, not Stripe's values, which weren't researched |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a customer's need and a number you were measured on pulled in different directions. The story needs the metric, the customer, the choice, and its cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F1 and F4 together. Ops roles carry metrics, so this tension is native to the role |
| B3 | "Say a process you built is hitting its targets but you learn it's causing a bad customer experience. What do you do?" | VAL | [generic] | A hypothetical, so answer with an approach: confirm the signal, size the harm, tell the owner of the targets, propose a change, and accept that the number may dip. It asks nothing about your past | Tests F3 as a values question. VAL content, CASE delivery |
| B4 | "How do you decide when to tell a senior stakeholder their plan won't work, and how do you say it?" | VAL | [generic] | Your criteria: how big the stakes are, how confident you are, and whether you can bring an alternative. Then the delivery: in private first, evidence before opinion, a proposed path forward. If B1's story fits, you can point to it | Tests F7 as an approach. It pairs with B1 so you have both the story and the principle |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI rehearsal.** Choose one row from F1 to F8 where your own evidence is thinnest, and pick a real one, not a disguised strength. Say it in one plain sentence. Then give the nearest thing your experience actually carries, at its true size. Then give a concrete 30/60/90-day ramp plan. Expect follow-ups. If they ask "Why should we take that risk?", hold by pointing to the ramp plan and what you bring elsewhere, and don't retract the weakness. If they ask "What would your last manager say?", stay consistent with what you just said. Name the limit before they ask for it. If no gap comes to mind, that's the answer to rehearse least, so pick the one you'd least like to be tested on | The most predictable objection in a final round. Skeptic delivery, JD scoring, because it is measured against the role's requirements |
| C2 | "Why Stripe, why this role, and why now?" | JD | [generic] | Three short parts. Why now: from your own career. Why this role: from the work in F1 to F8. Why Stripe: only what you have read or used yourself, because this pack holds no Stripe facts. Don't recite a mission statement you haven't read | Tests motivation consistency and F8. Usually asked by the hiring manager or a skip-level |
| C3 | "Product operations means different things at different companies. What does it mean to you, and where does it stop?" | JD | [generic] | Your definition in one line. Then the boundaries with product management, support operations and program management, and what you would hand off. It asks your view, not your past | Checks you know where the role's edges are. This is where people slip into describing the PM job |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you'd put on your résumé from your last role. Walk me through how it was counted." | EXP | [generic] | Choose a figure in advance. Be ready to say, in your own words, how it was counted, what it is sensitive to, and which part of it was yours. If you can't say how a figure was counted, say so plainly or choose a different one. The pack supplies no method | Tests F4. Every figure you mention invites this. EXP because it checks attribution |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | The follow-up to D1. Name the assumption yourself, in your own words, before they find it. If you don't know the assumptions, say so | The weakest-assumption move. Volunteering it builds credibility rather than costing it |
| D3 | "A dashboard says a process is healthy, but the frontline team says it's broken. Which do you believe, and what do you check first?" | CASE | [generic] | Believe neither yet. Check how the dashboard defines its measure, whether the data is fresh, and what it leaves out. Sample real cases. Ask the frontline team for three concrete examples. Reconcile the two, then fix the metric or the process | Tests F1 and F4. Prober register on a live problem |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Don't pretend to know the seam. Propose principles: who owns intake, who owns the decision, how things escalate, and what gets written down. Then your norm for disagreeing: in private, early, with data | Tests F5. This is the Peer persona's core question |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Your principle first: name contributors specifically, in public. If you use a story, pick a time credit was shared or contested, and be exact about which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F5. A peer is pricing whether you'd take their credit |
| E3 | "What would you need from my team in your first month, and what would you give back?" | JD | [generic] | Keep the asks small and specific, such as access, context and one recurring meeting. Make the gives concrete, such as a feedback digest or launch checklists. Lead with what you'd give | Reciprocity framing. Shows whether you'd lighten their load or add to it |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause. Give a one-line thesis, two pieces of evidence from your own record, and a close. Concede what is true: an internal candidate knows the systems. Hold that you bring something different, and say what it is in your own words | Tests composure under a time limit. It often comes late in a final |
| F2 | "That result: how much of it was actually you?" | EXP | [generic] | Can follow any story you tell. Hold, then concede: say exactly which part was yours, credit the team's part by name, and don't inflate it. Hold through two follow-ups, then concede any uncertainty specifically. Prepare each story's honest split in advance | Attribution probes exist to catch inflation. Candor you've rehearsed is the counter |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the one or two turns that led to product ops, and why this role is the next step. Cover only roles and facts that are on your CV | Opens most sessions and is still scored for how economically you tell it |
| G2 | "What drew you to product operations rather than product management?" | JD | [generic] | Your actual reason, in a sentence or two, about the work you prefer. Don't frame it as a fallback | Asked casually, scored seriously. Pairs with C3 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 feedback into product | A2, A4, B2, D3 |
| F2 launch readiness | A1 |
| F3 processes that scale | A4, B3 |
| F4 metrics and data | A5, B2, D1, D2, D3 |
| F5 influence without authority | A3, E1, E2, E3 |
| F6 prioritization under ambiguity | A1, A3 |
| F7 communicating with senior stakeholders | B1, B4 |
| F8 product and customer knowledge | C2 |
| Company strategy (CO) | none. Research was refused, so a strategy question would have rested on memory. See the upgrade menu |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does product operations own here that it didn't a year ago, and what should it own next?" | Shows you think about where the role is heading, and tells you whether the role is growing |
| R2 | "Where does the line between product ops and the PMs sit today, and where does it get contested?" | Shows you know the role's edges (C3), and tells you about the seam before you join |
| R3 | "Six months in, what would make you say this hire was clearly right?" | Gets the real success criteria in the interviewer's own words |
| R4 | "Which channel from customers to product works worst today?" | A practitioner's question. It tells you where your first project probably is |
| R5 | "What's the hardest launch the team has run recently, and what would you do differently?" | Invites a story, and shows how the team learns from what went wrong |
| R6 | "What could someone new do in the first month that would genuinely help your team?" | The reciprocity question. Use it with a peer interviewer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| none listed | This pack holds none of your sentences, so there is no stretched version of them to list and no negative you stated | The list gets built against your own words once you share a CV or describe your work. Until then, every scaffold's honest fallback is the guardrail |

## Sources

- **Provided documents:** your message ("final-round interview at Stripe for a Product Operations Manager role"). Nothing else was provided.
- **Searches sent:**
  - "Stripe operating principles": refused
  - "Stripe interview process final round onsite operations role": refused
  - "Stripe strategy 2026 news stablecoins agentic commerce": refused
  - "Stripe "Product Operations Manager" job description": refused
- **Fetches:** none sent
- **Dossier:** none present
- **Loop:** no loop source establishes it. The persona weights rest on the large-tech structured fallback pattern, as the persona table says.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Refused. It would have given Stripe's published principles by name, themed bank B by them, and, if a values round is documented, added a values cheat sheet |
| 2. Stripe interview process, product operations | unavailable | Refused. It would have replaced the fallback pattern with Stripe's named rounds and reset the persona weights |
| 3. Stripe strategy and recent news | unavailable | Refused. It would have added at least one CO question grounded in current strategy |
| 4. Interviewer name at Stripe | n/a | No name was given, so there was no query to form. There's no interviewer read, and the reverse questions are written for the role, not a person |
| 5. Representative Product Operations Manager JD | unavailable | Refused. It would have replaced the role-family requirements in F1 to F8 with quoted `[inferred]` ones |

## Upgrade menu

- **The JD text:** F1 to F8 become quoted `[grounded]` requirements, the JD-tagged questions are aimed at the real list, and the coverage table is checked against it.
- **Your CV, or a few sentences about your last two roles:** the worksheet becomes a real fit snapshot, the scaffolds become guidance mapped to your own stories, C1 is aimed at your actual thinnest area, and the prohibited list is built from your own words.
- **Who you're meeting (manager, peers, skip-level, cross-functional):** the persona weights are recomputed from real relationships, not a fallback pattern.
- **If your final is several sessions, the schedule:** a mini-pack per session, each with its own weights and reverse questions.
- **The recruiter's prep email:** stated focus areas, plus a build section for any case, presentation or take-home they announced.
- **Interviewer names:** a read on each interviewer from their public profile, and a reverse question tied to each one's path.
- **Web search allowed (L1):** Stripe's published principles by name, its loop from its own material, and a current-strategy CO question.
- **A deeper research pass (L2), up to 6 more searches and 2 more fetches, several more minutes:** a strategy brief, a grounding-brief section, and sharper differentiator cases.
- **How much prep time you have:** a prioritized prep schedule sized to it.
- **A tuesday-dossier.md from an earlier underwriting session:** verified evidence and a named objection to rehearse. It is not needed for this pack.
