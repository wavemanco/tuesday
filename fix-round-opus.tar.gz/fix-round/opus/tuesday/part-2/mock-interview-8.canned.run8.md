No dossier found, so I'm building the pack from what you gave me. Writing it now.
Dara, I've built your prep pack for all three rounds on 21 November. It's saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-8-canned-630e9132/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

It's built from only what you sent me. I didn't run any web searches, because the values text, the recruiter's email and the July brief already cover what research would have found.

What's in it:

- **A fit table.** Each requirement in the job description sits next to your own words. Two gaps are ones you named yourself: the contact centre, and presenting to senior leaders. Several others are places where your material is silent rather than lacking, such as whether your complaints log counted as "regulated" and what your spreadsheet tracks. For those, the pack gives you two honest ways to answer and doesn't guess.
- **28 practice questions** split across the recruiter, the Head of Member Services and the branch-manager panel.
- **A build-out of the 20-minute escalation case.** You get a six-step structure, three positions to choose from (each with the concession to say aloud), and a close that names which of the four values each step served, since that's what the panel scores.
- **A values cheat sheet.** None of your sentences so far carries a story for any of the four values, so each one has guidance on picking a real story yourself, or saying plainly there isn't one.
- **A list of claims not to make.** For example, that you wrote the escalation script or coached supervisors, when what you told me is that you trained new tellers on it.

The question most worth rehearsing out loud is D1, in the round with the Head of Member Services. It's the "one branch's log, no contact centre, nothing above regional level — why are you ready?" objection. The prep is to hold on what you've actually done, say both gaps plainly before you're pushed, and give a 90-day plan.

If you'd like a practice run, I can play the Head of Member Services and ask you D1, with real follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep turned up, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 21 November 2026, per the recruiter's email
1. Recruiter, 30 minutes
2. Head of Member Services (your future manager), 45 minutes, "mostly behavioural"
3. Panel of two branch managers, 60 minutes, with a 20-minute complaint-escalation case. This is the values round, scored against the four values.

**Interviewers:** only roles are known so far. No names have been assigned, so this pack has no interviewer read.

---

## How to use this pack

- **Personas** describe *how* a question is asked: friendly, sceptical, probing, case-led, values-led, peer-to-peer. **Types** describe *what* is being scored.
- **Type key:**
  - **VAL**: behaviour that matches Ashgrove's *published* values
  - **EXP**: whether what you say about your past holds up, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: company and strategy knowledge
  - **CASE**: working through a live problem from the role
- **Question IDs** are lettered by persona and unique across the pack: A–B (round 1), C–E and G (round 2), H, J and K (round 3). F1–F9 are fit-snapshot rows, not questions.
- **Provenance labels:** `[grounded]` = traceable to something you or the recruiter supplied. `[inferred]` = this pack's derivation, with the derivation named. `[generic]` = a pattern for the role family, with no claim about Ashgrove or about you.
- **Answer slot** = a place where the pack doesn't know what you did, so it doesn't guess. It tells you what the interviewer is likely to probe and gives two honest ways to answer it. Fill it from your own memory, or say plainly that it wasn't yours.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Highest-ROI prep in the pack: D1.** It's the objection most likely to come up in some form, and the one most worth rehearsing out loud.

---

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material covers one branch's log, not a process spanning branches and the contact centre. Your words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe likely on what sat beyond the log. If any part of how complaints were handled at your branch, beyond keeping the log, was yours to set or change, say which part and how you decided, in your own words. If none was, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | This is a gap that wording can't close, and you've said so yourself. Words: "I haven't worked in a contact centre." Then say how you'd learn it, as a plan and never as a past. Don't add anything to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote gets you to a monthly complaints spreadsheet. It doesn't show whether the sheet tracks volumes and resolution times, or who reports from it. That gap is this pack's reading. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counts volumes or resolution times, say how they're counted, in your own words. If it doesn't, say what it does track. Don't turn "uses" into "I reported to" |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote says spreadsheet. It doesn't say Excel, or what you built into it. Answer slot: if it's in Excel, say so and describe what you built in your own words. If it's another tool, name the tool and say so plainly |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script," and "for the last three years I've been a branch supervisor." The limit, which is the pack's observation: the people you trained were tellers, not supervisors, and the training was on an existing script. Answer slot: the JD's coaching line makes a probe likely on coaching beyond the script. If you've helped someone through an escalation the script didn't cover, say what happened and which part was yours. If not, say so plainly and stay with the training |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show this either way. Answer slot: the JD makes a probe likely. If you've worked with a digital or app team, or fed what you saw at the counter into an online or self-service process, say what you did and which part was yours. If not, say so plainly and say how you'd start: what you'd bring from the branch side and who you'd go to first |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The quote meets the requirement in different words. Say it in your own terms: six years in retail banking, the last three as a branch supervisor. Let the interviewer map that onto "customer operations"; don't relabel your history in the JD's vocabulary |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | "Formal" doesn't show "regulated". That's the pack's reading, and the evidence may well exist. Answer slot: if the complaints in that log came under regulatory rules, say which rules and what they meant for how you handled the log, in your own words. If they didn't, or you're not sure which rules applied, say so plainly and stay with the log you handled |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | This is a negative you stated, so your words are your own: "I've never presented to anyone above regional level." Then a plan, said as a plan. Answer slot: if you have presented to your regional manager, say what and how it went, in your own words. If not, say so. Don't read your sentence as a claim that you presented at regional level unless you did |

### Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own the complaints process end to end across branches and the contact centre | F1, F2 | A4, B1, D1, J1 |
| Report monthly on complaint volumes and resolution times | F3 | E1, E2 |
| Coach branch supervisors on escalations | F5 | C2, D3, K2 |
| Work with digital teams on self-service journeys | F6 | G1, J2 |
| 4+ years in financial-services customer operations | F7 | A1, B1 |
| Experience handling regulated complaints | F8 | B2, C1, J1 |
| Confident presenting to senior leaders | F9 | C4, D1, D2 |
| Comfortable with Excel reporting | F4 | A5, E1 |

---

## Graded deliverable: the 20-minute complaint-escalation case (round 3)

The recruiter announced it, so it's graded. The panel is "also the values round — they score against the four values", which means your case answer is scored on values as well as structure.

**Grounded facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| The role owns complaints "end to end across branches and the contact centre" and reports "monthly on complaint volumes and resolution times" | JD | [grounded] |
| The four values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Values page text you pasted | [grounded] |
| 40% of member service moving to digital by 2028; eight branches into five hubs over 2027; app-only banks as the main competitive pressure | 2026 strategy brief | [grounded] |
| Your one-line credibility anchor, F1: "I handled the branch's formal complaints log" | Fit snapshot F1 | [grounded] |
| Your second anchor, if coaching comes up, F5: "trained new tellers on our escalation script" | Fit snapshot F5 | [grounded] |

**A 20-minute shape** `[generic]`, as a pattern rather than Ashgrove's method:
1. **Clarify (2 min).** What happened, which channel it came in through, what the member wants, how long it's been open, and which rules and deadlines apply. Ask that last one; don't assert it.
2. **Member first (3 min).** Make contact, give a plain-words acknowledgement, and tell them what happens next and when.
3. **Own it (3 min).** One named owner from now until it closes, even when the complaint crosses from a branch to the contact centre.
4. **Resolve (5 min).** Get the facts, decide, and send a final response in plain words. If it went wrong for the member, say so.
5. **Fix the cause (4 min).** Log it so the monthly report shows the pattern. If the cause sits in a process or a digital journey, take it to the team that owns it.
6. **Close on the values (2 min).** One sentence per value on how the plan reflected it.

**Theses to choose from (each with its concession)**

| Thesis | Concession you say aloud |
|---|---|
| T1. Fix the member's problem first, then fix the cause | Sometimes you need the facts before you can promise anything, so first contact is about what happens next, not the answer |
| T2. One named owner from first contact to close, across branch and contact centre (Own the Fix) | A single owner can become a bottleneck, so the plan needs a handover rule for when that person is away |
| T3. Every escalation is a data point. Log it so the monthly report shows the pattern | Reporting must never slow down the member's fix, and the log is no substitute for talking to the member |

**Differentiation.** The consensus answer is apologise, investigate, resolve, follow up, and every prepared candidate gives it. You stand out in three ways:
- ask about the rules and deadlines in the first two minutes
- treat the escalation as a coaching moment for the branch supervisor, not a takeover
- close by naming which value each step served, because that's what the panel scores

**Anti-pick.** Don't promise compensation or an outcome before the facts are in. Don't take the case away from the branch so completely that the supervisor learns nothing from it.

---

## Grounding brief (from the strategy brief and values you supplied)

| Item | What it says | Source | Provenance | Where it shows up |
|---|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | Strategy brief, July 2026 | [grounded] | A3, G1, J2 |
| Branch consolidation | Eight branches into five hubs over 2027 | Strategy brief, July 2026 | [grounded] | A3, G2, K1, H3 |
| New product | Small-business lending product in Q1 2027 | Strategy brief, July 2026 | [grounded] | A3 (if time) |
| Competition | Main pressure is app-only banks | Strategy brief, July 2026 | [grounded] | J2 |
| Ownership | "member-owned, about 900 staff" | JD | [grounded] | A2 |
| Vocabulary | "members", "self-service journeys", "hubs", "the member's side of the counter" | JD, brief, values | [grounded] | Every round. Say "members", not "customers" |
| Freshness | The brief is four months old, and anything after July isn't covered here | Strategy brief date | [grounded] | Ask rather than assert if something seems to have moved |

---

# Round 1: Recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly openers: background, why Ashgrove | High. This is the recruiter-screen prior, and 30 minutes leaves room for little else | A 90-second arc rehearsed out loud. Treat casual questions as scored |
| B. Skeptic (light) | Knockout checks in a friendly tone: contact centre, regulated complaints, the step up | Medium. Recruiters check the JD's must-haves before passing you on | Plain answers, one-line plans, no padding |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc built only on these sentences: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close on why this role, in your own words. The pack doesn't know your reason, so don't borrow one from the JD | F7, F1, F5 and F3 are your strongest rows, and this question is where the recruiter first hears them. EXP because everything after it gets checked against it |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses." | Your reason belongs to you; none of your sentences says what it is. Structure: one thing you can name from what Ashgrove published (member-owned, or a value by name such as "Members First, Always"), then one link to work you've told me about: the complaints log, the spreadsheet. If part of your reason is practical, such as scope or progression, say so plainly | Motivation gets tested in every round, so it should match across all three. CO because it rewards having read their material |
| A3 | "What do you know about where we're heading?" | CO | [grounded] | Two items from the brief the recruiter sent, each tied to the job: 40% of service moving to digital by 2028 (complaints will come in through the app as well as the counter, which matches the JD's self-service line), and eight branches into five hubs over 2027 (complaints handling has to hold steady while branches change). Mention small-business lending and app-only banks only if there's time. Say the brief is where you read it | The brief came from the recruiter, so not using it would be visible. CO because it tests homework |
| A4 | "The role covers the contact centre too. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre" | Plain answer first: "I haven't worked in a contact centre." Then one sentence of plan: how you'd learn it in your first weeks, for example by sitting in on calls and following a complaint from the phone through to close. Don't add "but I've worked closely with…" unless it's true and you can name it | F2 is a stated gap the recruiter can check in one question. JD because the contact centre is in the role's first line |
| A5 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the quote: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD names Excel, so expect "in Excel?" If it is, say so and describe what you built into it, in your own words. If it's another tool, name it. Don't list features you haven't used | F4 is a must-have on the JD and easy to screen on. `[inferred]` because the link from spreadsheet to Excel is this pack's |
| B1 | "This would take you from one branch to a role across all the branches and the contact centre. Is that a jump you're ready for?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "Never worked in a contact centre" | A 60-second version of D1. Hold: "Six years in retail banking, the last three as a branch supervisor, and I handled the branch's formal complaints log." Concede plainly: "I haven't worked in a contact centre." Then one sentence on why you think the step makes sense, in your own words, and a one-line plan | F1 and F2 together are the obvious screening concern. JD because it scores the role's scope |
| B2 | "Have you handled regulated complaints?" | JD | [inferred] "I handled the branch's formal complaints log" | Quote first: you handled the branch's formal complaints log. Answer slot: the JD says "regulated complaints", so this probe is likely. If the complaints in that log came under regulatory rules, say which rules and what they meant for how you handled it, in your own words. If they didn't, or you're not sure which rules applied, say so plainly and stay with the log. Don't swap "formal" for "regulated" unless that's what it was | F8 is a listed requirement and a classic knockout check. `[inferred]` because the gap between "formal" and "regulated" is this pack's reading |
| B3 | "Why leave your supervisor role now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Your reason, in your own words; none of your sentences says what it is. Keep it forward-facing (what this role offers that yours doesn't) and make it match what you'll tell the Head of Member Services. If part of it is a push away from your current job, one neutral sentence is enough | Why leave, why here, why now: the sceptic's standard question. EXP because it tests whether your account stays consistent |

### Reverse questions

| Question | Why it lands |
|---|---|
| "For the 20-minute case, will I get the complaint details in the room, or beforehand?" | It shapes how you prepare the graded deliverable, and it shows you're taking the case seriously |
| "How does the panel use the four values when scoring? Is it one score per value, or overall?" | It tells you how to close the case, and it's process diligence |
| "Once the interviewers are assigned, could you share their names?" | It unlocks the interviewer read in this pack's upgrade menu |
| "What made the role open now?" | It tells you whether you're filling a vacancy or a new remit, and that changes your answer to D1 |
| "What's the timeline after 21 November?" | It's logistics the recruiter expects to be asked about, and leaving it out reads as passive |

---

# Round 2: Head of Member Services, your future manager (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C. Values / Behavioural | "Tell me about a time…" questions on complaints, coaching and senior stakeholders | High. The recruiter said "mostly behavioural", which overrides the usual case-heavy prior for a hiring manager | Stories only where your sentences carry them. Otherwise pick a real one from memory, or say plainly there isn't one |
| D. Skeptic | Quiet probing of F1, F2 and F9: scope, contact centre, presenting | High. A manager is reducing their risk on the gaps in the role they'll be accountable for | Rehearse D1 until it's boring. Concede plainly and give a plan |
| E. Data-Driven Prober | What the monthly spreadsheet counts, and how | Medium. Monthly reporting is a core duty, and your spreadsheet is the obvious thing to probe | Know what it counts. Name the weakest part of the count yourself |
| G. Case / Strategist | The strategy questions: digital shift, hubs | Low to medium. The usual hiring-manager prior, scaled down by "mostly behavioural" | Clarify, structure, use their vocabulary |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across the branches and the contact centre and reports to senior leaders. You've handled one branch's log, you haven't worked in a contact centre, and you haven't presented above regional level. Why are you ready?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses."; "Never worked in a contact centre"; "I've never presented to anyone above regional level." | **This is the highest-ROI rehearsal in the pack.** Hold only what your sentences carry: "Six years in retail banking, the last three as a branch supervisor. I handled the branch's formal complaints log, trained new tellers on our escalation script, and built the monthly complaints spreadsheet our regional manager uses." Concede before they push: "I haven't worked in a contact centre, and I've never presented to anyone above regional level." Then a plan, said as a plan: in the first 90 days, learn how complaints flow through the contact centre from the inside, and take the first senior monthly report through a dry run with your manager. Follow-up 1, "So the contact centre is completely new?": "Yes." Then the plan again, with no padding. Follow-up 2, "Why not hire someone who's done this at scale?": don't argue the premise. Go back to what you did and to the plan, and add no scope you didn't state. The concession is a limit, not a confession, so say it at normal pace | F1, F2 and F9 are the three widest gaps, and your future manager owns the risk of each. JD because it scores the role's stated scope. Deepest rehearsal because it will come up in some form |
| D2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level."; "Never worked in a contact centre" | Pick a real one you've already named. Presenting to senior leaders: "I've never presented to anyone above regional level." Then what you'd do about it, as a plan: for example, ask for a dry run before the first senior review, and ask to see recent packs. If they ask for a second, give the contact centre. Don't offer a strength in disguise | F9 and F2 give you honest answers ready-made. JD because the weakest-part question is about the listed duties |
| C1 | "Tell me about a complaint that escalated beyond the counter, and what you did." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Your sentence says you handled the log, not which complaints were yours, so choose the instance yourself: one complaint you dealt with directly, with the member's issue, what you did, and how it closed. Use "I" for your part and "we" for the branch. If no complaint was yours to deal with directly, say so plainly and describe how you handled the log | F1 and F8 both point here, and the JD's escalation line raises it. VAL delivery because it's a behavioural round, EXP content |
| C2 | "Tell me about a time you helped someone handle an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F5. The beats are the ones the sentence states: new tellers, trained, on the escalation script. Tell it in your own words. Answer slot: the JD's coaching line makes a probe likely on help that went beyond the script. If you helped someone through an escalation the script didn't cover, say what happened and which part was yours. If not, say so plainly and stay with the training. Don't imply you wrote the script | F5 is your nearest evidence for the coaching duty. JD because coaching supervisors is a listed responsibility |
| D3 | "You'd be coaching supervisors. What makes you able to coach your peers?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | What your sentences carry: you've been a branch supervisor for the last three years, and you trained new tellers on the escalation script. The limit, which is the pack's observation: the people you trained were tellers. Answer slot: if you've helped another supervisor with an escalation, say what you did and how, in your own words. If not, say so plainly and say how you'd approach it, for example by starting from their real cases rather than the script | F5 is a transferability gap the manager will press on. JD because the question scores the coaching requirement |
| C4 | "Tell me about a time you told someone more senior something they didn't want to hear." | VAL | [grounded] "I've never presented to anyone above regional level." | Selection scaffold: the senior person could be your branch or regional manager. You need a real stake, what you said, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it. Don't turn it into a presentation story; F9 stands | It's a standard behavioural stem, and it's the softest route into the senior-leaders requirement (F9). VAL because it tests behaviour, not a claim |
| C3 | "When did you put a member ahead of an internal target?" | VAL | [generic] | Selection scaffold: you need a named target or rule, the member's situation, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it. If you can, keep a different story for H1 in round 3 | It's a standard behavioural stem that matches "Members First, Always". `[generic]` because the stem is a role-family pattern |
| E1 | "Talk me through your monthly complaints spreadsheet. What does it track, and how is it counted?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Describe what it tracks, in your own words. Your sentence says you built it and your regional manager uses it, nothing more. Answer slot: the JD's "volumes and resolution times" makes two probes likely. If it counts volumes, say how a complaint gets counted. If it records resolution times, say when the clock starts and stops. If either isn't in it, say so plainly. Then name, before they find it, the part of the count you'd defend least. If you don't know how a figure was counted, say that | F3 and F4 both rest on this one sentence, and the reporting duty makes it an obvious probe. EXP because it tests what the spreadsheet really is |
| E2 | "Complaint volumes jump 20% in a month. What do you check first?" | CASE | [generic] | Clarify: all channels or one, one branch or all? Check the count before the cause: did the way complaints get logged change? Then split by branch, contact centre, digital and complaint type; check whether resolution times moved too; look for a single trigger, such as an outage or a fee change. Then act and report. With digital and hub changes under way, those are the first hypotheses to test, not to assume | The reporting duty (F3) as a live problem. CASE because it scores structure, not your record |
| G1 | "We're moving 40% of member service to digital by 2028. What does that do to complaints, and what would you do about it?" | CO | [grounded] | Clarify which journeys move first. Hypothesis: complaints shift channel and type, towards journeys that fail and members who don't want to move. Approach: track complaints by channel from the start, take the worst-performing self-service journey to the digital team, test the screens for plain words, and keep a route to a person. If they ask about your own digital experience, use F6's answer slot | Grounded in the strategy brief. CO content, CASE delivery. It covers the JD's digital line (F6) without asking about your past |
| G2 | "Over 2027 we're consolidating eight branches into five hubs. How do you keep complaints handling steady through that?" | CO | [grounded] | Clarify the timeline and which towns are affected. Risk points: members losing their branch, travel, staff moving. Approach: watch complaints in each affected town before, during and after the change; a named owner at each hub; plain-words notices; brief supervisors on the escalations to expect. Concession: some complaints will be about the decision itself, which you can't fix, so handle those honestly | Grounded in the brief. CO content, CASE delivery. It's also live for the round-3 panel |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What would you want this role to have changed six months in?" | It gives you their definition of success in their own words |
| "Who sees the monthly complaints report today, and who would I be presenting to?" | Diligence on F9: you learn the audience you'd be preparing for |
| "How do complaints move between the branches and the contact centre now?" | It tells you where end-to-end ownership currently breaks, which is F1's real scope |
| "Which self-service journeys generate the most complaints at the moment?" | It ties your work to the 2028 digital target and to the digital teams |
| "What support is there for someone stepping up to senior-level reporting?" | It raises the F9 plan as a forward question, not a defensive one |

---

# Round 3: Panel of two branch managers, values round (60 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| H. Values / Behavioural | One probe per value, scored | High. The recruiter said the panel "score against the four values" | Map each value with the cheat sheet below, and be honest where you have no story |
| J. Case / Strategist | The 20-minute escalation case | High. The recruiter announced it | The graded-deliverable section above |
| K. Peer Evaluator | Seams between this role and their branches: coaching their supervisors, hubs | Medium. This role coaches their supervisors and works across their branches, so the panel will weigh what you add to their load | Offer something in return, propose working principles for the seam, and don't pretend to know it already |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a decision you made from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a decision where the member's interest and the easier or internal route pulled apart. You need what the member needed, what you decided, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it. Use a different story from C3 if you can, to show range | "Members First, Always" in its own wording. `[grounded]` on the values text. None of your sentences carries a story here, so it's a scaffold |
| H2 | "If a member needs it explained twice, we wrote it wrong. Tell me about a time you made something plainer." | VAL | [grounded] "trained new tellers on our escalation script" | The nearest thing your material carries is the training, at its own scope: you trained new tellers on the escalation script. Answer slot: the value makes a probe likely. If, while training, you changed how the script was explained so it landed, say what you changed, in your own words. If not, say so plainly and pick another instance: a time you explained something to a member more simply, ending honestly if none comes to mind | "Plain Words" in its own wording. F5 is the only row near it |
| H3 | "Every branch is part of its town. Tell me about a time that shaped how you handled something." | VAL | [grounded] | Selection scaffold: you need the local context, what you did differently because of it, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it. Be ready for "how does that square with closing branches?" Don't defend or criticise the decision; say how complaints handling keeps each town in view (G2's approach) | "Neighbours, Not Numbers", and consolidation makes it pointed for branch managers |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: the value makes a probe likely. If you built the monthly complaints spreadsheet because of a problem you found, say what the problem was and whether it got solved, in your own words. If it wasn't built for that, or you don't know why it was needed, say so plainly and pick another instance: the problem, how you found it, what you did when it got hard, and how it ended. If it isn't solved, say that | "Own the Fix". F3 is the only sentence that might carry it, so it sits in a slot, not a story |
| J1 | "Here's an escalated complaint. Take us through how you'd handle it." | CASE | [grounded] "I handled the branch's formal complaints log" | Follow the six-beat shape in the graded-deliverable section: clarify (including which rules and deadlines apply), member first, one owner, resolve, fix the cause, close on the values. One credibility line at most: "I handled the branch's formal complaints log." Pick one of T1–T3 and say its concession aloud | The announced, graded case. Covers F1 and F8 live |
| J2 | Mid-case: "The member says they're moving to an app-only bank. What changes?" | CASE | [grounded] | The member's issue still comes first; don't make keeping them the goal. Acknowledge it plainly, resolve, and log it as a signal for the monthly report, since app-only banks are the brief's main competitive pressure. Don't promise anything you couldn't authorise | A likely twist that tests the strategy brief live. CASE with CO content |
| K1 | "Some branches are moving into hubs next year. How would you work with branch managers like us on complaints through that?" | CO | [grounded] | Offer something in return: what you'd bring them (a monthly view of their own branch's complaints, a named contact) and what you'd ask of them. Then a working principle for the seam: their teams and their towns, your process. You don't know which branches are affected, so don't guess | Grounded in the brief. CO content, peer delivery. It's live for exactly these interviewers |
| K2 | "You'd be coaching our supervisors. Where's the line between your job and ours?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Working principle: they manage their people; you own the complaints process and coach on escalations with them, not around them, and you agree how you'll share what you see. Your part, from your sentences: "For the last three years I've been a branch supervisor," and you trained new tellers on the escalation script. Answer slot: if you've coached another supervisor, say how. If not, say so plainly and say how you'd start | F5 as seen from the people whose supervisors you'd coach. JD content, peer delivery |
| K3 | "What do you do when a branch manager disagrees with how a complaint should be closed?" | VAL | [generic] | Selection scaffold: if you've disagreed with a manager about a complaint, give the stake, what you said, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it. The principle to land: decide from the member's side, say it plainly, escalate together, and make sure nobody drops the complaint while you disagree | A standard peer-evaluator stem about disagreement. It's where Own the Fix and Members First meet |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from where the member stands, not from internal convenience | No sentence of yours carries a story here. Selection scaffold: a decision where the member's interest won over the easy route, ending honestly if none comes to mind | H1, C3 |
| Plain Words | If something needs explaining twice, the writing failed, not the member | Nearest is F5, "trained new tellers on our escalation script", at its own scope. The story itself is an answer slot | H2 |
| Neighbours, Not Numbers | Each branch belongs to its town; members aren't figures | No sentence carries a story. Selection scaffold, ending honestly if none comes to mind | H3 |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | Possibly F3, "I built the monthly complaints spreadsheet our regional manager uses.", but only if it was built to fix a problem you found. That's an answer slot | H4 |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What's an escalation from your branch you'd have wanted this role to handle differently?" | It gets their real pain point, and it treats them as the users of the role |
| "How do your supervisors handle escalations today, and what would help them?" | It's a question about what you can give back, and it starts the coaching relationship |
| "How are you thinking about complaints for members in the branches moving into hubs?" | It shows you've read the brief and care about their towns |
| "What could someone new do in the first month that would genuinely help your branches?" | It's the standard question for peers: what you'd add, not just what you'd need |
| "How does Neighbours, Not Numbers show up when a complaint comes in through the app rather than a branch?" | It links a value to the digital shift, which is the role's real tension |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process (beyond the log) | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material covers the log, not the process. F1's answer slot stays inside the branch |
| Has worked in a contact centre | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders, executives or a board | A negative you stated, F9 | "I've never presented to anyone above regional level." |
| Coached supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "trained new tellers on our escalation script." The slot asks only about escalations beyond the script |
| Wrote or designed the escalation script | Inflated form of F5 ("our escalation script") | "I trained new tellers on our escalation script." |
| Reported monthly to the regional manager, or produced the region's complaints reporting | Inflated form of F3 ("our regional manager uses") | "I built the monthly complaints spreadsheet our regional manager uses." |

---

## Sources

**Provided documents**
- The JD, pasted
- The values text, pasted. You copied it from ashgrovecu.org/about/values on 12 November 2026. The page wasn't fetched.
- The recruiter's email on the process, pasted. This is the source that establishes the three-round loop.
- Your summary of the 2026 strategy brief Ashgrove published in July 2026, which the recruiter sent you
- Your background, from your message
- No dossier was present.

**Searches and fetches:** none sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you copied this morning already fixes the cheat sheet and H1–H4 |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email establishes all three rounds and their formats, which fixes the persona weights and the graded-deliverable section |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief is under six months old and fixes the CO questions and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names have been assigned, so there's no query to form. There's no interviewer read; the upgrade menu says what names would unlock |
| 5. Representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned:** an interviewer read for each round, persona weights per panel member from their public professional footprint, and a reverse question tied to each person's path.
- **Your real stories for the scaffolds (H1, H3, C1, C3, C4, K3):** told to me outside a drill, they become quotes, and those rows switch from scaffold to story-mapped.
- **Your answers to the slots in F3, F4, F6 and F8** (what the spreadsheet counts, which tool, any digital work, which rules applied to the log): those rows get regraded, and A5, B2, E1 and G1 get sharper.
- **An inspectable version of the spreadsheet,** a template you rebuild with dummy data and no member information, and only if your current employer would be comfortable with it: this is the artifact that could raise F3 and F4 from medium.
- **How much prep time you have before 21 November:** a prioritised prep schedule, tied to question IDs.
- **The strategy brief's full text,** rather than a summary: the grounding brief can quote Ashgrove's exact language, and G1, G2 and J2 can use their vocabulary.
- **A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes):** Ashgrove news since July, any published candidate guides, and recent org context. It would sharpen G1, G2, J2 and K1. Say the word and it runs.
- **A `tuesday-dossier.md` from an underwriting pass on this role:** it would replace this pack's inferred objection and locally built prohibited list with evidence-checked ones. It isn't needed; the pack is complete without it.
