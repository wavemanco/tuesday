Building your Stripe final-round prep pack now; running a few targeted searches (Stripe's values, interview loop, recent strategy, a Product Ops JD) first.
I've saved your prep pack as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-3-denied-cc31a901/stripe_product-operations-manager_interview_pack.md`.

It's general for now. I didn't have the job description or your background. The web searches for Stripe's values, interview process, recent strategy and a sample job description were all denied, so nothing in the pack is a fact about Stripe. I treated the final round as one combined session.

- **Fit table:** six typical Product Operations requirements for you to match your own examples to.
- **21 practice questions:** mostly live operations problems and probing questions.
- **Highest priority:** B1, "Which part of this role would you be weakest at on day one?", with the follow-ups to rehearse.
- **Questions to ask them:** six, each with why it works.

Say the word and I'll play the skeptical interviewer on B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you know how the final round is split up: who you're meeting and in what role (hiring manager, peers, a senior leader)? And has the recruiter mentioned anything to prepare, like a case or presentation?
Could you paste the job description and your CV, or a few lines about your background? I'll build without them if not, but they'd let me match each answer to your own experience.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final-round prep pack

Round: final round. The sessions and interviewers aren't known yet. Built from your one-line message: no job description, no CV, and the web research was refused, so nothing in here is a fact about Stripe.

## How to use this pack

- **Personas** describe *how* a question gets asked: the interviewer's style and register.
- **Types** describe *what* is being scored:
  - **VAL**: whether your past behaviour shows the company's published values
  - **EXP**: whether what you say you did holds up under probing, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: company and strategy knowledge, and whether you can think at the company's altitude
  - **CASE**: a live problem from the role, scored on structure and reasoning
- **Provenance labels:** `[grounded]` traces to something you gave me or to cited research. `[inferred]` is derived from a representative source. `[generic]` is a role-family pattern that says nothing specific about Stripe or about you. This run had no inputs to ground anything on, so every row is `[generic]`.
- The guidance is scaffolding, not a script. I don't have your history, so every behavioural answer below is a *selection scaffold*: it tells you what kind of story to pick, and it ends with an honest branch for when you don't have one.

## Fit snapshot

This is the worksheet version, because I don't have your background yet. The requirements are typical Product Operations responsibilities, not Stripe's posting. For each row, fill in your own sentence before the interview.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launch readiness across product, engineering, support and go-to-market teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence: a launch you coordinated, the teams involved, how you judged it ready, and what happened after it shipped. Selection scaffold: pick a launch or rollout where you owned the readiness work. It needs a named set of teams, a go/no-go moment, and an outcome you can state. If none comes to mind, say so plainly, then give the nearest thing you actually did, or how you would run one |
| F2 | Building feedback loops that carry customer, support and sales signal back into product decisions (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence: a recurring mechanism you set up or ran, where the signal came from, and one product decision it changed. Selection scaffold: pick a time user signal you gathered or organised reached a product team and changed something. It needs the source, the route it took, and the decision. If none comes to mind, say so plainly, then give the nearest thing you actually did, or how you would build it |
| F3 | Defining and tracking operational metrics and reporting them to leadership (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence: a metric you defined or reported, how it was counted, and a decision it informed. Selection scaffold: pick a number you know end to end, meaning its source, its denominator and its weak spot. If you only reported a number someone else defined, say that plainly. If none comes to mind, say so, then give the nearest thing you actually did, or how you would set one up |
| F4 | Designing and scaling operational processes and internal tooling as volume grows (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence: a process before and after your change, what broke, and what the change did. Selection scaffold: pick a process you redesigned or set up yourself. It needs the problem, your change, and a result you can state honestly. If none comes to mind, say so plainly, then give the nearest thing you actually did, or how you would approach it |
| F5 | Managing stakeholders across functions without formal authority (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence: a disagreement between teams you helped resolve, what each side wanted, and where it landed. Selection scaffold: pick a time you had to get another team to change course without being able to direct them. It needs a named stake and an intact working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing you actually did, or how you would handle it |
| F6 | Communicating trade-offs, status and bad news to senior leaders (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence: a time you told leadership something they didn't want to hear, and what they did with it. Selection scaffold: pick a moment where the message cost you something to deliver. If none comes to mind, say so plainly, then give the nearest thing you actually did, or how you would handle it |

## Persona table

No source tells me how Stripe's final round is structured, so the weights below rest on a pattern, not on Stripe's documented process. The fallback is the **generic** archetype (screen, then hiring manager, then panel). A final round with an unknown schedule is treated as one blended session, not as separate rounds.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live operations problems: plan a launch, diagnose a metric, design a process | High. A hiring manager is very likely somewhere in a final round, and the hiring-manager prior puts case work first | Clarify, then objective, then segment, then approach, then metrics, then risks. Say the structure out loud before you use it, and challenge one premise politely in each case |
| Skeptic | Quiet probing: weakest area, motivation, "why here, why now" | High. It's the hiring-manager prior's second persona, and a final round is where remaining doubts get tested | Rehearse B1 until it's boring. State limits plainly and give a concrete ramp plan |
| Data-Driven Prober | Asks for denominators, counting methods and assumptions behind any number you mention | Medium. Product ops is metrics-heavy (role-family pattern), so any figure you give will be pushed | Only quote numbers whose counting you know, and name the weakest assumption before they do |
| Peer Evaluator | A future partner team asks about the seam, disagreement and credit | Medium. Final rounds commonly include a peer or partner-team conversation (pattern, unconfirmed here) | Propose seam principles rather than pretending to know the seam, and frame what you bring their team |
| Values / Behavioral | STAR-style stories about candour and customer focus | Low to medium. No values round is established, and Stripe's published values aren't in hand, so these stay generic | "We" for context, "I" for your contribution. Pick stories where the hard truth actually landed |
| Pressure | Time-boxed questions, "how much was actually you" | Low. Composure checks can turn up in any session | Pause, restate the question, hold your position through two follow-ups, then concede specifically |
| Conversational | A friendly opener about your journey, or casual tooling chat | Low weight but near-certain to happen. Opening minutes are still scored | Have a pre-built 90-second arc, and treat casual questions as scored |

## Question banks

### A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're shipping a new feature to existing users next quarter. Sketch the launch-readiness plan. What do you need to know first?" | CASE | [generic] | Clarify first: who is affected, what changes for them, and who signs off. Define "ready" as a short checklist with an owner per item. Workstreams: support enablement, user comms, internal docs and tooling, rollback plan. Set a go/no-go checkpoint. Name two or three launch metrics, such as adoption, ticket volume and error rate, and the threshold that would pause the rollout. Close with the biggest risk and how you'd watch it. No claim about your past is needed | Tests F1 as a live problem. CASE because it scores structure, not history. `[generic]` because it's a pattern for the role, not Stripe's launch process |
| A2 | "Support tickets about one feature jumped 20% this month. Diagnose it." | CASE | [generic] | First, clarify the metric: is it an absolute count or per active user, and did ticket tagging or the definition change? Segment by user type, channel, region and release date. Form hypotheses: a recent release, confusing docs, user growth, a tagging artefact. Test the cheapest one first. State your weakest assumption out loud. Finish with the decision and how you'd close the loop with the product team | This is the persona's metric-diagnosis stem applied to F2 and F3. CASE because the reasoning is live |
| A3 | "Product, sales and support all want ops capacity next quarter. How do you decide what gets done?" | CASE, JD | [generic] | Make the intake visible. State your criteria before ranking, for example user impact, risk, effort and fit with team goals. Show the trade-off explicitly, and say no with reasons and an alternative. Agree a review cadence so the ranking can change. Mention how you'd tell leadership what was deprioritised | Covers F4, F5 and F6 in one prioritisation problem. JD content, CASE delivery |
| A4 | "Design a way for the product team to hear what users struggle with every week, without reading every ticket." | CASE, JD | [generic] | Sources: support, sales, account teams, community. Use a lightweight tagging taxonomy and a weekly digest with the top themes, volume and example quotes. Give each theme an owner and a status. Measure whether themes lead to decisions. Mention the failure mode: a digest nobody acts on | The F2 requirement as a design problem |
| A5 | "A manual review step breaks every time volume doubles. How would you redesign it, and what do you need to know first?" | CASE | [generic] | Clarify: what the step protects against, its current volume and error rate, and who owns it. Options in order: remove the step, simplify it, automate the easy share, route exceptions. Pilot the change before rolling it out widely. Track throughput, error rate and the cost of mistakes. Name the risk of automating the wrong part | F4 as a live problem; uses the persona's "what do you need to know first" stem |

### B: Skeptic

**B1 is the highest-ROI prep in this pack.** It's inferred from the persona and the role, not from your background, because I don't have your background yet. Some version of it gets asked in most final rounds, and a calm, rehearsed answer changes the room.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD, EXP | [generic] | Pick one real area from F1 to F6 where your experience is thinnest. Don't pick a disguised strength. Say it plainly in one sentence, then give a concrete 30-to-60-day plan, said as a plan rather than as something you've already done. Follow-ups to rehearse: "Why that one?" (keep to the same area), "Isn't that core to the job?" (concede that it matters and repeat the plan, without claiming experience you lack), "What if we need it in week two?" (say who you'd lean on and what you'd do first). Hold the same answer through all three; don't trade it for a safer one. If you truly can't name one, say which area you'd want to confirm expectations on | It's the persona's own stem, and the predictable final-round objection. JD because it scores the role's requirements; EXP because the honest answer depends on what you've actually done |
| B2 | "Why product operations, why Stripe, and why now?" | EXP, CO | [generic] | Three true beats: what draws you to the work, what specifically draws you to this company, and what changed for you now. The "why Stripe" beat has to come from your own reading of Stripe's materials. This pack has no Stripe facts to give you. If you don't have a specific company reason yet, say what you want to learn about the role, rather than inventing one | The Skeptic's "why leave, why here, why now" probe. CO because the middle beat tests your homework |
| B3 | "This role sits between product, engineering and go-to-market. How would you handle the parts of that you haven't done before?" | JD | [generic] | Selection scaffold on F5: name which seams are new to you and which aren't, using only what you've actually done. For the new ones, give how you'd learn them: who you'd meet first and which early win you'd go after. If none of it is new, say so plainly and give one example of a seam you've worked across | The persona's "how would you handle X in this role" stem, with X as F5 |
| B4 | "How would you handle the metrics side of this role: defining what ops tracks and reporting it upward?" | JD | [generic] | Selection scaffold on F3: if you've defined or reported a metric, say which and how, in your own words. If you've only used metrics others defined, say so plainly and describe how you'd choose the first three to track and how you'd present them | The same stem, with X as F3 |

### C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick a number you've reported on in a past role. Walk me through how it was counted." | EXP | [generic] | Choose a figure whose counting you actually know: where it came from, its denominator, the time window, what it's sensitive to, and which part was yours. If you only know the headline and not how it was counted, say that plainly; that's an honest answer, and a better one than a reconstructed method | The persona's stem, as an open prompt, testing F3 |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they push: the assumption you trust least, why, and what you'd check to firm it up. If you don't know what assumptions sit behind the figure, say so | The persona's second stem. It turns a gotcha into a credibility gain |
| C3 | "A launch is called a success because adoption hit target. What would you check before agreeing?" | CASE | [generic] | Check whether the target was set before launch, how "adoption" is defined, whether there's a comparison group or baseline, whether tickets or churn went up alongside it, and which users drove it. End with what would change your mind | Live F1 and F3 problem; prober style in a case wrapper |

### D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Don't pretend to know the seam. Ask which team they're on, then propose principles: one owner per decision, disagreements raised early with data, and escalation as a shared choice rather than a weapon. If you have a disagreement story, tell it with both spine and tact; if not, say how you'd handle the first one | The persona's stem; tests F5 partnership fit |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a cross-team piece of work and say plainly which part was yours and which was others'. If no example comes to mind, say how you would handle it: name contributors in the update, and let the outcome speak | The persona's second stem; it rehearses the "I" versus "we" split |
| D3 | "What would you need from me in your first month, and what would I get from you?" | JD | [generic] | Reciprocity first: what you'd bring their team, such as a clearer intake or faster feedback. Then a small, specific ask: context, one recurring meeting, a named contact | The persona's "what would you need from me" pattern |

### E: Values / Behavioral

Stripe's published values weren't fetched, so these test generic behaviour, not Stripe's own principles.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold on F6: pick a time with a named stake, a moment you didn't soften the message, and a working relationship that survived. "We" for context, "I" for what you said and did. If no such time comes to mind, say so plainly, then give the nearest thing you actually did, or how you would handle it | The persona's stem; F6 |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold on F2: it needs the metric, the customer impact, and your decision. If no such time comes to mind, say so plainly, then give the nearest thing you actually did, or how you'd weigh it | The persona's stem; F2 |

### F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give two or three reasons drawn only from what you've actually done, plus one honest concession: an internal candidate knows the systems, and here's how you'd close that gap. Stop at sixty seconds | The persona's stem; tests composure |
| F2 | "That result you just described: how much of it was actually you?" | EXP | [generic] | Rehearse the split for every story you plan to tell: what the team did, and what you did yourself. If pushed twice, hold the same split; don't grow it or shrink it to ease the tension | The persona's stem; the attribution-honesty probe |

### G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the two or three moves that matter for this role, and why this role is the next step. Only include moves you'd happily be probed on | The persona's stem; a near-certain opener |
| G2 | "What are you actually playing with in ops tooling or automation these days?" | JD | [generic] | Name something real you've used or tried, and what it did for you. If nothing comes to mind, say what you'd like to explore and why. Treat it as scored | The persona's stem, with F4's tooling theme |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | A1, C3 |
| F2 Feedback loops | A2, A4, E2 |
| F3 Operational metrics | A2, B4, C1, C2, C3 |
| F4 Process and tooling at scale | A3, A5, G2 |
| F5 Cross-functional stakeholders | A3, B3, D1, D2, D3 |
| F6 Communicating to leadership | A3, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a great first six months in this role look like, and how would you know?" | Shows you think in outcomes, and gets you the success criteria |
| R2 | "Which teams does product ops serve most here, and where is that seam hardest today?" | Turns D1's question around, and tells you what the job really is |
| R3 | "What's one process the team has outgrown that you'd want this hire to tackle first?" | Invites a concrete problem you can respond to on the spot |
| R4 | "How does the team decide what product ops says no to?" | Signals judgement about capacity, not just willingness |
| R5 | "What did the last person in this role find hardest? Or, if the role is new, what prompted creating it?" | Gets at real context behind the posting |
| R6 | "Is there anything in my background you'd like me to say more about before we finish?" | Draws out any remaining objection while you can still answer it |

## Prohibited claims

None listed. This list normally holds stretched versions of things you said, or things you said you haven't done. You haven't given me any material yet, so there's nothing it could hold. That's different from a pack that checked your material and found nothing to inflate. Once you add a CV or background, this section gets built from it before any bank is rewritten.

## Sources

- Provided: your message ("Final-round interview at Stripe for a Product Operations Manager role").
- Search "Stripe operating principles values": refused.
- Search "Stripe interview process final round onsite operations": refused.
- Search "Stripe strategy news 2026": refused.
- Search "Stripe "Product Operations" manager job description": refused.
- No dossier present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. Would have supplied Stripe's published values by name, to theme E1 and E2 and feed a values cheat sheet if a values round were established |
| 2. Stripe interview process for operations roles | unavailable | Search refused. Would have shown the final round's sessions, replacing the generic-archetype persona weights |
| 3. Stripe strategy and recent news | unavailable | Search refused. Would have grounded B2's "why Stripe" beat and at least one CO or CASE question in current priorities |
| 4. Interviewer name at Stripe | n/a | No name given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. Would have turned F1 to F6 into quoted `[inferred]` requirements |

## Upgrade menu

- The job description text: the six `[generic]` fit rows become `[grounded]` requirements quoted from Stripe's posting. JD-tagged questions get re-anchored, and any eligibility terms (location, work authorisation) get checked.
- Your CV, or a few lines on your background: the worksheet becomes a real fit snapshot. B1, C1, D2, E1, E2 and G1 change from selection scaffolds to story-mapped guidance, and the prohibited-claims list gets built.
- The final-round schedule and your interviewers' names or roles: per-session mini-packs with their own persona weights, an interviewer read from public profiles, and a reverse question tied to each interviewer's path.
- The recruiter's prep email: coverage of any pre-declared case, presentation or exercise, as its own build section.
- Allowing web search: Stripe's published values by name, its documented loop, and current strategy for B2 and the CO and CASE questions. After that, an optional deeper pass (up to 6 more searches and 2 more fetches, several more minutes) for a strategy brief and recent org context.
- Your available prep time: a prioritised schedule telling you what to rehearse first.
- A tuesday-dossier.md from an earlier underwriting pass, if you ever make one: an evidence-derived highest-ROI objection and a prohibited-claims guardrail. Not needed for this pack.
