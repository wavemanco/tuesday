Status: I've read the interview-prep playbook and its rules. Now I'm writing your pack, with one section per round on 21 November.
I've built your prep pack for all three rounds on 21 November, in one file with a section per round.

**The highest-ROI prep is B1, in Round 2.** Expect your future manager to ask some version of: "Your complaints experience is one branch's log, you haven't worked in a contact centre, and this role owns complaints across branches and the contact centre. Why you?" The pack has a hold-then-concede answer for it:

- **Hold:** your six years in retail banking, the last three as a branch supervisor, and the branch's formal complaints log you handled.
- **Concede:** "I haven't worked in a contact centre."
- **Then:** a plan for how you'd learn it.
- **Two likely follow-ups:** guidance for each.

**Other things worth knowing before you open it:**

- **Your two stated gaps get plain answers.** For the contact centre and for presenting above regional level, the pack gives you a straight acknowledgment and a plan. It never coaches a workaround, because the Skeptic will test any stretch.
- **Some gaps are only silences in what you told me.** You didn't say whether the complaints in your log were regulated, whether the spreadsheet is in Excel, whether it tracks resolution times, or about any digital work. Those questions have answer slots: say it if it's true, and use the honest line if it isn't. Your answers would also sharpen the pack.
- **Round 3 is set up as the values round.** The panel section has a cheat sheet with one story per value, and a 20-minute structure for the complaint-escalation case:
  - three theses, each with the concession you should say out loud;
  - a way to stand out from the standard answer: the handover between branch and contact centre, which the 2027 move to hubs could widen;
  - one thing not to do: promise compensation before you know what authority applies.
- **No values stories are written for you.** Nothing you told me already contains a story for any of the four values. The cheat sheet sets out what each story needs and points to your nearest material. Choose your four stories before the 21st.
- **The case has no regulatory deadlines in it.** I don't know which regulator Ashgrove answers to, so I didn't name any rules. If you add the jurisdiction, I can put them in.
- **I didn't search the web.** Your pasted values, the recruiter's email and the July strategy brief already covered everything a search would have found.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-8-denied-3364fb01:
- ashgrove-credit-union_member-experience-lead_interview_pack.md

If you'd like to rehearse, I'll play your future manager as the Skeptic on B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of loop:** 21 November 2026, three rounds on one day (loop mode)
**Round 1:** 30 minutes with the recruiter
**Round 2:** 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural
**Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case. This is the values round, scored against the four values
**Interviewer names:** not yet assigned

---

## How to use this pack

Two axes run through every question:

- **Personas** describe how a question is asked: the friendly recruiter, the Skeptic probing your gaps, the values interviewer wanting a story, the peer asking what you'll need from them.
- **Types** describe what is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's four published values, not generic virtue |
| EXP | Whether what you say about your background holds up, and what was actually yours |
| JD | Whether you can do the job as written, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | How you structure and reason through a live problem from the role |

Each question row has a **Provenance** column:

- `[grounded]`: traceable to what you, the JD, the recruiter or Ashgrove's own text said
- `[inferred]`: this pack's reasoning from that material
- `[generic]`: a common pattern for this kind of role, with no claim about Ashgrove or about you

Where guidance draws on your past, the Provenance cell quotes the exact sentences from your message it rests on. Where your material doesn't cover something, the guidance gives you an **answer slot**: what to say if it happened, and an honest line to use if it didn't. The guidance is scaffolding, not a script. Say it in your own words.

The pack is shared first (fit snapshot, grounding brief, coverage), then split by round. The values cheat sheet and the case build sit in Round 3, because that's where they're scored.

---

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message, and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material covers one branch's log, not a process across branches, and your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on the steps likely. If any step of how your branch's complaints were handled was yours to set or change, say which and how, in your own words. If none was, say so plainly and stay with handling the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You've stated this gap, and wording can't close it. Words: "I haven't worked in a contact centre." Then say how you would learn it, as a plan and never as a past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote is monthly and about complaints, but it doesn't say what the spreadsheet counts. Answer slot: if it tracks volumes, resolution times or both, say which and how a complaint gets counted, in your own words. If it tracks neither, say so plainly and describe what it does track |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Training new tellers on a script is adjacent to coaching supervisors, not the same thing. Your words stay at the quotes' scope: "As a branch supervisor, I trained new tellers on our escalation script." Answer slot: if you ever helped another supervisor with an escalation, say what you did, in your own words. If not, say so plainly and stay with training tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't mention digital or self-service work. Answer slot: if you've worked on any online or app change, or fed branch feedback into one, say what and what part was yours, in your own words. If not, say so plainly and say how you'd use complaint data to help a digital team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. Lead with the quote as it stands: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | "Formal" doesn't show whether those complaints were regulated. Answer slot: if they came under a regulator's rules, say which rules and what they required of you, in your own words. If they didn't, or you aren't sure, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You've stated this gap. Words: "I haven't presented to anyone above regional level." Then say how you'd prepare for your first senior-leader session, as a plan and never as a past. Don't read your sentence as a claim that you presented at regional level. It doesn't say that |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel. Answer slot: if it's built in Excel, say so and name the features you used, in your own words. If it's built in another tool, name that tool plainly |

The biggest gaps are F2 (contact centre) and F8 (senior presenting), which you stated yourself, and F1 (one branch's log against an organisation-wide process). The Skeptic will press F1 and F2 together. That pairing is this pack's highest-ROI prep: **B1**.

---

## Grounding brief

Built from the July 2026 strategy brief the recruiter sent and from the JD. Learn the vocabulary and sound current.

| Fact or vocabulary | Source | Provenance | How to use it |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Strategy brief, July 2026, via the recruiter | [grounded] | Your hook for the JD's self-service line (F5). Complaint data can show a digital team where a journey fails |
| Consolidate eight branches into five hubs over 2027 | Strategy brief, July 2026 | [grounded] | Your Round 3 panel are branch managers in a network that is changing. Raise it with care, and don't presume anything about their own branches |
| Launch a small-business lending product in Q1 2027 | Strategy brief, July 2026 | [grounded] | A new product brings a new kind of complaint. This is good material for C10 |
| Main competitive pressure is app-only banks | Strategy brief, July 2026 | [grounded] | A complaint handled well in a branch or by phone is something an app-only rival can't offer. Use that framing for "why branches still matter" |
| Member-owned, about 900 staff | JD | [grounded] | Say "members", never "customers". It also echoes "Members First, Always" |
| Vocabulary: member complaints process, contact centre, escalations, self-service journeys, hubs, Member Services | JD, recruiter email, strategy brief | [grounded] | Use their words for their organisation. Use your own words for your own past (see the prohibited list) |
| The brief is four months old | Strategy brief date | [inferred] | If an interviewer gives newer figures or names, follow theirs and don't correct them |

---

## Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| Own the complaints process end to end across branches | F1 | A3, B1, C7, C11 |
| ...and the contact centre | F2 | A4, B1, C7 |
| Report monthly on volumes and resolution times | F3 | B4, B11, B12, C8 |
| Coach branch supervisors on escalations | F4 | B3, C5, C6 |
| Work with digital teams on self-service journeys | F5 | B9 |
| 4+ years in financial-services customer operations | F6 | A1, C12 |
| Experience handling regulated complaints | F7 | A3, the Round 3 case build |
| Confident presenting to senior leaders | F8 | A5, B2, B4 |
| Comfortable with Excel reporting | F9 | A6, B11 |

---

# Round 1 — Recruiter, 30 minutes

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | "Walk me through your background", "why Ashgrove?" | High. This is a recruiter screen, and 30 minutes leaves room only for the story, motivation and the basics | Have a 90-second arc ready. Treat the casual questions as scored |
| Skeptic (light) | Quick checks on the JD's listed requirements: contact centre, senior presenting, Excel | Medium. Recruiters screen against the requirement list, and two of your rows are stated gaps | Give the plain line and then the plan. Short answers here, with depth saved for Round 2 |
| Case / Strategist | The odd "what do you know about our plans?" | Low. A 30-minute screen rarely holds a case, but strategy awareness is cheap to show | Have the three strategy moves ready in one sentence |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc that uses only these beats: six years in retail banking, the last three as a branch supervisor. Within that, you handled the branch's formal complaints log, trained new tellers on the escalation script, and built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words | F6 covers the experience requirement, and F1, F3 and F4 are the pieces this role builds on. EXP because the recruiter is checking that your story matches the role |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Name one value by its exact name and say what it means to you. Then name one strategy move from the grounding brief. Answer slot: give your own reason for wanting a member-owned organisation. If your reason is mainly the role and not the credit-union model, say that plainly | Recruiters screen for motivation consistency. CO because the strong answer uses Ashgrove's own words |
| A3 | "Tell me about your experience with complaints." | JD | [grounded] "I handled the branch's formal complaints log" | Lead with the log in the quote's own terms. Answer slot: the JD asks for "regulated complaints", so expect that word. If the log's complaints came under a regulator's rules, say which and what that meant for you. If not, or you aren't sure, say so plainly and stay with the log | F1 and F7 are the JD's headline requirement. JD because it maps straight onto the requirement list |
| A4 | "The role covers the contact centre too. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then one sentence of plan, for example how you'd spend early weeks with contact-centre staff and their escalated complaints. Stop there. Don't add a near-substitute your material doesn't carry | F2 is a gap you stated. The recruiter will likely tick it off, and a clean answer stops it becoming a red flag before Round 2 |
| A5 | "This role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | "I haven't presented to anyone above regional level." Then what your material does carry: you built the monthly complaints spreadsheet your regional manager uses. Then say how you'd prepare. Don't say you presented the spreadsheet. The quote says your manager uses it | F8 is a stated gap. F3's quote is the nearest real material. JD because it scores a listed requirement |
| A6 | "Are you comfortable with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if the spreadsheet is in Excel, say so and name the features you used, in your own words. If it's in another tool, name that tool plainly and say how comfortable you are moving to Excel | F9 is a discovery row. The recruiter may only need a yes, but have the honest detail ready |
| A7 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Three moves in one breath: 40% of member service digital by 2028, eight branches into five hubs over 2027, and small-business lending in Q1 2027. Add the competitive pressure from app-only banks. Then one sentence on what each means for complaints | The brief came from the recruiter, so they'll notice if you used it. CO is the homework signal |
| A8 | "Why move from branch supervision into a central role now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer slot: your reason, in your own words. Anchor it in the quote, three years as a branch supervisor, and in what this role adds. Keep it forward-looking, not a complaint about your current job | A light Skeptic check on motivation. A consistent answer here makes B1 easier in Round 2 |

### Reverse questions

| Question | Why it lands |
|---|---|
| "Is the 20-minute case given in advance, or live on the day?" | It changes how you prepare, and recruiters usually answer it |
| "What does the Head of Member Services most need from this hire in the first six months?" | It gives you Round 2's agenda before Round 2 starts |
| "How is the role's time split between branches and the contact centre today?" | It touches your F2 gap through a question rather than a defence |
| "How does the panel's values scoring work? Is it one score per value?" | It shows you take the values round seriously and helps you pace your stories |
| "When will the interviewers be confirmed, and could you share their names?" | Names let you prepare per person. It's a routine ask |

---

# Round 2 — Head of Member Services, 45 minutes, mostly behavioural

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Why can you do this, given…?", "where are you weakest?" | High. As a hiring manager they're buying reduced risk, and F1, F2 and F8 are visible gaps | Rehearse B1 until it's boring. Hold on what you said, concede the stated gaps plainly, and give a plan |
| Values / Behavioural | "Tell me about a time…" | High. The recruiter said "mostly behavioural" | Pick stories ahead of time with the values cheat sheet. Use "we" for context and "I" for your part |
| Case / Strategist | "What would you do about…?", a first-90-days question | Medium. Hiring managers test their own roadmap, and the digital target is on it | Clarify, then structure, then answer, using their vocabulary |
| Data-Driven Prober | "Walk me through that spreadsheet" | Low-to-medium. F3 is your one reporting artefact, and the JD asks for monthly reporting | Know what the spreadsheet counts and say plainly what it doesn't |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your complaints experience is one branch's log, and you haven't worked in a contact centre. This role owns complaints end to end across branches and the contact centre. Why should I believe you can do it?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" | **This pack's highest-ROI rehearsal.** Name the limit before you're asked. Hold: "Six years in retail banking, the last three as a branch supervisor, and I handled the branch's formal complaints log." Concede: "I haven't worked in a contact centre." Then a plan, said as a plan: how you'd learn how a complaint travels from branch to contact centre and back. Answer slot: if any step of your branch's complaints handling was yours to set or change, say which. If none was, say so plainly and stay with the log. Follow-up 1, "The contact centre's volumes are much bigger": don't guess their numbers. Say you don't know them yet and what you'd want to see first. Follow-up 2, "So what would you actually do in week one?": the plan, concretely. Never stretch the log into "complaints across the region" | F1 and F2 together are the most predictable objection to you for this role, so it will come in some form. JD because it scores the headline requirement head-on. Deepest rehearsal because a calm, non-defensive answer here changes the interview |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" | Pick a real one, F8: "I haven't presented to anyone above regional level." Then how you'd close it: for example, asking to sit in on a senior session before presenting, and rehearsing your first monthly report with your manager. Don't offer a fake weakness. A prepared Skeptic notices | F8 is a stated gap, and offering it yourself scores as self-awareness. JD because it maps to a listed requirement |
| B3 | "Coaching supervisors isn't the same as training tellers. What's the difference, and how would you handle it?" | JD | [grounded] "trained new tellers on our escalation script"; "the last 3 as a branch supervisor" | The quotes' scope first: as a branch supervisor, you trained new tellers on the escalation script. In your own words, say how coaching a peer-level supervisor differs from training a new teller. Answer slot: if you ever helped another supervisor with an escalation, say what you did. If not, say so plainly. Then say how you'd approach coaching supervisors, given that you've held that role for three years | F4 is a transferability row, and the gap between "trained tellers" and "coach supervisors" is visible from the JD. JD because it scores the coaching line |
| B4 | "Your spreadsheet serves a regional manager. Here, monthly reporting goes to senior leaders. What changes?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses"; "I've never presented to anyone above regional level" | Start from the quote: you built it, and your regional manager uses it. Concede F8 plainly. Then, in your own words, what you'd expect senior leaders to need that a regional manager might not, as a plan. Answer slot: if the spreadsheet tracks volumes or resolution times, say which. If not, say so | F3 and F8 meet here, which makes it the reporting version of B1. JD because it scores two requirements at once |
| B5 | "Tell me about a time you handled a complaint where the member was right and the process was wrong." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, themed on "Members First, Always". Pick an instance from the log with a named member impact, a moment you decided from the member's side, and a result. Use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | Your manager will screen for the values the panel scores later. F1 is where such a story would live, if it exists |
| B6 | "Tell me about a time you found a problem and kept hold of it until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold, themed on "Own the Fix". It needs a problem you found, a stretch where it would have been easy to hand off, and a result. Answer slot: if the spreadsheet was built to fix a problem, say what problem in your own words. If it wasn't, pick another story. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | Own the Fix is close to this job description. F3 is the nearest artefact, but the quote doesn't say why it was built, so the pack doesn't supply a reason |
| B7 | "Tell me about an escalation that went badly. What did you change afterwards?" | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold, themed on the JD's escalations line. It needs what went wrong, what was yours, what changed, and what you learned. Answer slot: if what you learned changed how you trained tellers, say how. If not, say so. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | Escalations are the coaching mandate. F4 is the nearest material. The story is what earns trust |
| B8 | "Tell me about a time you explained something to a member that they didn't want to hear." | VAL | [generic] | Selection scaffold, themed on "Plain Words". It needs a hard message, the plain words you used, and whether the member understood the first time. If no such time comes to mind, say so plainly, then say how you'd handle it | It tests Plain Words in a setting from the job. [generic] because the guidance makes no claim about your past |
| B9 | "We want 40% of member service through digital channels by 2028. What does that mean for complaints?" | CO | [grounded] | Clarify first: which journeys move first? Then two hypotheses, said as hypotheses: some complaints will move channel, and new ones will come from the digital journeys themselves. Complaint data can show the digital team where a journey fails. Concede that some members won't move, and that's a Members First question. Answer slot (F5): if you've worked on any online or app change, say what. If not, say so and stay with what complaint data can offer | The strategy brief is the manager's roadmap. F5 is a discovery row. CO content with CASE delivery |
| B10 | "What would you look at in your first 90 days?" | CASE | [grounded] | Structure: map how a complaint moves today across branches and the contact centre, read recent monthly reports, meet branch supervisors and contact-centre leads, and spot the two or three biggest delays. Then one quick win and one longer fix. Mention the 2027 hub changes as a reason to fix ownership rules early | The JD's "own end to end" and the strategy brief, made concrete. CASE because it's a plan, not a record |
| B11 | "Walk me through the monthly complaints spreadsheet. What does it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | You built it, and your regional manager uses it. Those are the beats the quote carries. Answer slot: what it counts and how a complaint gets counted, in your own words, and which part of it your manager relies on most. If there's something it doesn't track, such as resolution times, say so before you're asked. If it's not in Excel, name the tool | F3 and F9 rest on this one artefact, so a Prober will go two levels deep. EXP because it tests what's really there |
| B12 | "How would you know whether a complaint was resolved well, not just closed?" | JD | [generic] | Separate closed from resolved: the member's view of the outcome, whether it came back, and how long it took. Say which you'd measure first and why. Answer slot: if your spreadsheet tracks any of these, say which. If none, say so | The JD names resolution times, and this tests whether you see past the number. [generic] because the measures are a pattern, not Ashgrove's practice |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What does 'end to end' mean for this role today? Where does the complaints process break most often?" | It invites them to tell you the real problem, and it's your first-90-days agenda |
| "How will the hub consolidation change where complaints are handled?" | It shows you've read the brief and are thinking about the 2027 transition |
| "Who reads the monthly report today, and what decisions does it drive?" | It tells you your senior-leader audience (F8) and what good looks like |
| "How closely does this role work with the digital teams on the 2028 target?" | It ties the JD's self-service line to their strategy |
| "What would make you say, a year from now, that this hire worked?" | A manager's success criteria, asked directly. Hiring managers tend to respect this one |

---

# Round 3 — Panel of two branch managers, 60 minutes, values round with a 20-minute case

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "Tell me about a time…" mapped to the four values | High. The recruiter said the panel scores against the four values | One prepared story per value (cheat sheet below). Name the value in your answer only if it fits naturally |
| Peer Evaluator | "What would you need from me?", "who owns it when it crosses from my branch?" | Medium. You'd coach their supervisors and report on their branches, so they're weighing what you'd add to or take from their work | Lead with what you bring them. Propose principles for the seams rather than pretending to know them |
| Case / Strategist | The 20-minute escalation case, plus hub and lending questions | Medium, and graded. The case is pre-declared | Use the case build below. Clarify, then structure, think aloud, and tie it to the values |
| Skeptic | "Why would you understand my branch?" | Low-to-medium. Branch managers may test whether one branch's experience transfers to theirs | Hold on the quotes and concede what you don't know about Ashgrove's branches |

### Values cheat sheet

Values are quoted from the text you copied from Ashgrove's values page on 12 November 2026.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, nearest row F1: "I handled the branch's formal complaints log." Pick a complaint where you took the member's view against convenience, and say what you decided and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it. Questions: C1, B5 |
| Plain Words | If a member needs something explained twice, the writing was wrong | Selection scaffold, nearest row F4: "trained new tellers on our escalation script." Answer slot: if you changed how something was worded or explained so it landed the first time, say what. If not, say so. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it. Questions: C2, B8 |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold, nearest row F6: "6 years in retail banking, the last 3 as a branch supervisor." Pick a time you treated a member as a person in your community rather than a case number. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it. Questions: C3, C8 |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | Selection scaffold, nearest row F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because you found a problem, say what problem. If not, choose another story. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it. Questions: C4, B6 |

Pick your four stories before 21 November. Don't reuse the same story for two values with the same panel.

### Graded deliverable: the 20-minute complaint-escalation case

The case content hasn't been shared, so this is a structure to bring to any escalation.

**Grounded facts to build on**

| Fact | Source |
|---|---|
| The role owns complaints "end to end across branches and the contact centre" | JD |
| "experience handling regulated complaints" | JD |
| Own the Fix: "whoever finds the problem keeps hold of it until it is solved" | Ashgrove values |
| Plain Words, Members First, Neighbours Not Numbers | Ashgrove values |
| Eight branches become five hubs over 2027, and 40% of service goes digital by 2028 | Strategy brief, July 2026 |
| F1: "I handled the branch's formal complaints log" | Your message |
| F4: "trained new tellers on our escalation script" | Your message |

**A 20-minute shape**

| Minutes | Move | Values it shows |
|---|---|---|
| 0–4 | Clarify: who the member is, what happened, what they've been told, what they want, how long it has been open, which channel it came through, whether it's a regulated complaint with time limits, any sign of vulnerability, and what authority the branch has | Members First |
| 4–12 | Decide and act: name one owner, contact the member in plain words, fix what can be fixed now, and say what you'd check against Ashgrove's complaints policy and the regulator's rules before promising anything | Own the Fix, Plain Words |
| 12–17 | Prevent: find the root cause, decide whether the supervisor or the script needs coaching, log it for the monthly report, and decide whether a digital journey is involved | Own the Fix |
| 17–20 | Close: what the member hears, what the branch learns, and what changes | Neighbours, Not Numbers |

**Three defensible theses, each with its concession**

| Thesis | Concession you must say |
|---|---|
| The first decision in an escalation is who keeps hold of it. One named owner from first contact to resolution | One owner can become a bottleneck. You need clear handover rules between branch and contact centre, especially while branches move to hubs |
| Fix it for the member first, then fix the process | A quick fix for one member can set a precedent or treat members unequally. Check it against the policy before you offer it |
| Every escalation is data for the monthly report and for the digital team | Branch managers care about the member in front of them, not a dashboard. Numbers must never override Neighbours, Not Numbers |

**Differentiation:** the expected answer is "apologise, listen, resolve, follow up". Use it, and add one thing most candidates won't: the handover seam between branch and contact centre, and how the 2027 hubs could widen it.

**Anti-pick:** don't promise compensation or a policy exception in the case without knowing what authority applies. Say what you'd check and who decides.

**No close was named by the recruiter.** End on what the member experiences, because the panel scores against the values.

Your past, as used in the case: only F1 and F4 at their quotes' scope. Present the case as how you'd handle it, not as a story of what you did.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a decision you made from the member's side of the counter, even though it was harder for the branch." | VAL | [grounded] "I handled the branch's formal complaints log" | Scaffold, Members First: the member's situation, the harder path you chose, why, and the result. Use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | It uses the value's own words, which is likely in a values-scored round. F1 is the nearest material |
| C2 | "If a member needs it explained twice, we wrote it wrong. Tell me about something you re-explained or rewrote so members understood it the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold, Plain Words. Answer slot: if you changed how the escalation script was explained or worded, say what and why. If not, say so plainly and pick another story. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | Plain Words matters for both complaints and coaching. F4 is the nearest material |
| C3 | "Tell me about a time you treated a member as a neighbour, not a number." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Scaffold, Neighbours Not Numbers: a named member situation, what knowing the community changed, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | Branch managers will care most about this value. F6 places you in branches for six years |
| C4 | "Tell me about a problem you found that wasn't strictly yours, and how you kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Scaffold, Own the Fix: the problem, why it wasn't strictly yours, what you did to keep hold of it, and the outcome. Answer slot: if the spreadsheet came from a problem you found, say what. If not, pick another story. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | Own the Fix is the value closest to the job. F3 is the nearest artefact, and its reason isn't in your material |
| C5 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Scaffold: a named stake, the hard truth, how you said it, and whether the relationship held. If no such time comes to mind, say so plainly, then say how you'd handle it | Coaching supervisors and reporting on branches means hard messages to people like this panel. [generic] because it's a common values prompt |
| C6 | "You'd be coaching my supervisors on escalations. What would you need from me, and what happens when we disagree about how one was handled?" | JD | [grounded] "the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Reciprocity first: what you'd bring their branch. You've been a branch supervisor for three years and trained tellers on an escalation script. Then what you'd need from them. On disagreement, propose a principle, such as agreeing the facts and the member outcome before deciding who's right. Answer slot: if you've disagreed with a manager about an escalation, say how it went. If not, say so | F4 seen from the panel's side. Peer delivery, JD content |
| C7 | "A complaint starts in my branch and ends up with the contact centre. Who owns it?" | CASE | [grounded] | Own the Fix gives the principle: whoever finds the problem keeps hold of it. Then the practical point: a named owner, a clear handover rule, and the member told who's dealing with it. Concede that you haven't worked in a contact centre and would want to see how they handle it today | F1 and F2 at the seam. CASE because it's a live problem from the role |
| C8 | "How would you report complaints about my branch without it feeling like a league table?" | VAL | [generic] | Neighbours Not Numbers: report themes and causes as well as counts, share findings with the branch before senior leaders see them, and set each branch's numbers in its own context | F3's reporting, seen from the branch managers' side. VAL because it tests whether numbers override the value |
| C9 | "The move to five hubs happens over 2027. What complaint risks do you see during the change?" | CO | [grounded] | Hypotheses, said as hypotheses: members confused about where to go, longer journeys, complaints about the change itself, and handovers between sites. Then what you'd watch in the monthly report. Be sensitive here: the panel works in the network that's changing | Strategy-grounded and close to the panel's own work. CO content with CASE delivery |
| C10 | "We launch small-business lending in Q1 2027. How would you get the complaints process ready?" | CO | [grounded] | Clarify first: who the members are and which channel they'll use. Then a plan: complaint categories for the new product, training for the staff who'll field them, an early-warning view in the monthly report, and the regulated-complaint rules checked for business members. Concede it's a new area for you as well | The strategy brief names the launch. A ready plan shows you think ahead |
| C11 | "You've only seen complaints from one branch. Why would you understand mine?" | EXP | [grounded] "I handled the branch's formal complaints log"; "6 years in retail banking, the last 3 as a branch supervisor" | Hold on the quotes: six years in retail banking, the last three as a branch supervisor, and you handled the branch's formal complaints log. Concede that you don't know their branch, then say how you'd learn it, for example by spending time there and reading their complaints. Don't stretch the log beyond one branch | B1's objection in a collegial form. EXP because it tests what your experience really covers |
| C12 | "Sixty seconds: why you over an internal candidate from one of our branches?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Pause, then three beats from the quotes, then one concession: an internal candidate knows Ashgrove and you'd have to learn it. Then what you bring. Don't run down the internal candidate. Stay within 60 seconds | A Pressure stem. Branch managers may know internal applicants. EXP because it tests your story under a time limit |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What could a new Member Experience Lead do in their first month that would genuinely help your branches?" | Reciprocity with the people you'd serve. Peers weigh this heavily |
| "Where do escalations from your branches get stuck today?" | It lets them describe the real problem, and it's practical |
| "How are your teams preparing for the move to hubs, and how could complaints handling help?" | It shows strategy awareness with care for them |
| "What do your supervisors find hardest about escalations?" | It goes straight to the coaching mandate (F4) |
| "Which of the four values do you see most clearly in your branch day to day?" | It shows you take the values seriously, and the answer tells you about the culture |

---

## Prohibited claims

This pack won't coach the following claims. Each is listed with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process end to end, or across branches or the region | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack observes that your material covers one branch's log, not an organisation-wide process. The slot in B1 stays inside your branch's handling |
| Has worked in or with a contact centre | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has coached supervisors, or managed other supervisors' escalations | Inflated form of F4 | F4's quotes at their own scope: as a branch supervisor, you trained new tellers on the escalation script. The slot in B3 asks only whether you ever helped another supervisor |
| Has presented to senior leaders, executives or a board | A negative you stated, F8 | "I haven't presented to anyone above regional level." No slot |
| Presented the spreadsheet, or built the region's complaints reporting | Inflated form of F3 | F3's quote at its own scope: you built the monthly complaints spreadsheet your regional manager uses. The pack observes that it's one manager's tool, not regional reporting, and that the quote says your manager uses it, not that you presented it |
| Has six years of complaints experience, or handled the log for three years | Inflated combination of F6 and F1 | The quotes stay separate: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log. Your material doesn't say for how long you handled the log |

---

## Sources

**Provided documents**

- The JD, pasted
- Ashgrove's values, pasted. You copied them from ashgrovecu.org/about/values on 12 November 2026, and they weren't re-fetched
- The recruiter's email describing the three rounds, pasted
- The July 2026 strategy brief, as summarised by you
- Your background, from your message

**Searches and fetches:** none sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted already supplies all four names and definitions for the cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes all three rounds, including the values-scored panel and the 20-minute case |
| 3. Ashgrove strategy or recent news | skipped | The July 2026 strategy brief is under six months old and already supplies the CO questions and the grounding brief |
| 4. Interviewer name at Ashgrove | n/a | No names were given yet, so there was nothing to search for. The interviewer read is left out |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Which regulator and jurisdiction govern Ashgrove's complaints** (or the rules you worked under) → the case build and A3 can name the actual deadlines and steps, and F7 can move from an answer slot to story-mapped guidance
- **Your answers to the answer slots** (what the spreadsheet counts and what tool it's in, whether the log's complaints were regulated, any digital work, any help given to other supervisors) → F3, F5, F7, F9 and F4 become story-mapped, and A3, A6, B3, B9, B11, C4 and C6 are regenerated
- **Interviewer names, once assigned** → a section on reading each interviewer, persona weights per panel member, and a reverse question tied to each person's path
- **The case format from the recruiter** (in advance or live, written or spoken) → a case build tuned to the format, plus a timed drill
- **How many prep hours you have before 21 November** → a prioritised prep schedule tied to question IDs
- **The full strategy brief text** rather than a summary → a grounding brief with the brief's exact numbers and wording
- **A deeper research pass, L2** (up to 6 more searches and 2 more fetches, several more minutes) → any Ashgrove news since July and any public talks by Member Services leaders. This is modest value, because the brief already covers strategy
- **A tuesday-dossier.md from job-underwriter** → evidence-checked grading and a named top objection, which would sharpen B1. The pack is complete without it
