I've read the prep playbook. Next I'm running a few searches on Larkfield, then I'll build the pack for all three rounds.
I've written one prep pack covering all three rounds, saved as `larkfield-systems_engineering-manager_interview_pack.md`. I built it from your message alone. The three web searches for Larkfield's values, interview process and recent news were refused because this session doesn't have search permission. That means nothing in the pack comes from research on Larkfield. The values cheat sheet for Monday is left out, and the industry questions are marked as generic.

The pack starts with one table comparing the role's requirements to your background, shared by all three rounds. Then each round gets its own set of 8–10 questions, and each round has its own reverse questions to ask them. The highest-value thing to rehearse is B1: "team lead of six, never managed managers, now two squads and eleven engineers — why are you ready?" Some version of it will probably come up in every round. H1 is the 60-second version for Monday.

Two things to watch in how you describe yourself:
- **"Team lead of 6" isn't the same as "managed 6."** Your message doesn't say whether those six reported to you, and this role owns "growth for 11 engineers," so expect someone to ask. Answer it honestly either way.
- **Your reliability quarter is the only story in your message.** That's why so many answers lean on it. Your CV would let the pack spread the load across more stories.

Say the word and I'll play the Skeptic on B1 with live follow-ups.
I can also save a `tuesday-dossier.md` file recording the gaps this prep turned up, so you can bring it to later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste your CV, and the full job posting if the one-line description isn't all of it? I'll go ahead without them if not.
2. Did the recruiter say anything about the format of Thursday's panel, such as a system-design segment, a case or a presentation? If so, I'd add a section to prepare that piece.
3. If you allow web search, should I re-run the research? It would add Larkfield's real values for Monday and ground the strategy questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** three scheduled rounds (loop). One shared fit snapshot, then a mini-pack for each round.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1. Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2. The Thursday after | Two staff engineers and a product manager | 60 min | Panel of peers plus a cross-functional partner |
| 3. The following Monday | VP Engineering | 30 min | Skip-level. The recruiter called it "values and leadership philosophy" |

No interviewer names were given, so there's no read on any individual interviewer. Web search was blocked in this session, so nothing here comes from research on Larkfield (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question gets asked: the style, the pressure, the register. **Types** describe *what* gets scored. Rehearse both. The same question asked as a friendly aside and asked as a time-boxed challenge needs two different deliveries.
- **The guidance is scaffolding, not a script.** Every claim about your past rests on one of the four sentences you wrote, quoted in that row's Provenance cell. Where the pack can't tell what you did, it gives you an **answer slot**: two honest branches, and you fill one in your own words. "That wasn't mine" and "there was no such step" are both full answers.
- **Provenance labels:** `[grounded]` traces to your message or the role text you gave. `[inferred]` is the pack's own derivation, and the derivation is named. `[generic]` is a role-family pattern with no claim about Larkfield or about you.
- **Your material holds one story.** Most of the story-mapped rows draw on your reliability-quarter sentence, because it's the only story your message contains. The upgrade menu says what a CV would add.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the values and leadership philosophy the round is about |
| EXP | Experience deep-dive | Whether your claims survive scrutiny, and what was actually yours |
| JD | Role-driven | Whether you can do the stated job, gaps included |
| CO | Company & strategy | Whether you can think at Larkfield's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the actual role |

---

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role text in your message. Evidence is quoted from your message, exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says team lead of six, not two squads of eleven, and the words stay at that scope: "Three years as a team lead of six." It doesn't say whether the six reported to you. Answer slot: "own delivery, hiring and growth for 11 engineers" makes a probe on whether you had line-management responsibility likely. If you did, say which parts were yours, in your own words. If you didn't, or that sat with someone else, say so plainly and describe how you led the team |
| F2 | "Lead two squads building device-management services" — role text in your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I haven't managed managers." The role text doesn't say whether the two squads have their own leads, so whether this gap matters is reverse question T-R1. Don't assume it either way. Then say how you'd learn it, framed as a plan and never as something you've done |
| F3 | "own delivery, hiring and growth for 11 engineers" (delivery) — role text in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material says you pushed a reliability quarter through. It doesn't say you owned delivery, and the words stay there: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Keep "after". The sentence doesn't say "because". Answer slot: "own delivery" makes a probe on how your team's work was planned and tracked likely. If any of that was yours, say what, in your own words. If it wasn't, or there was no such process, say so plainly and stay with the reliability quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" (hiring) — role text in your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running the loop reaches part of owning hiring. Words: "I run our hiring loop for backend roles — about 40 interviews last year." The 40 counts interviews, never hires. Answer slot: "own … hiring" makes a probe on hire/no-hire decisions, headcount and offers likely. If any of those were yours, say which, in your own words. If none were, say so plainly and stay with the loop and the interviews |
| F5 | "own delivery, hiring and growth for 11 engineers" (growth) — role text in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | Being team lead doesn't show whether growing engineers was part of your job, and your material says nothing either way. Answer slot: if growing people on your team was part of your role, say what you did for a specific person, in your own words. If it wasn't yours, say so plainly and say how you'd approach it for eleven engineers |
| F6 | "partner with hardware and product on roadmap" (hardware) — role text in your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I haven't owned a hardware-adjacent roadmap." Your sentence covers owning such a roadmap. The role asks for partnering with hardware, which your sentence doesn't cover. Answer slot: if you've worked alongside a hardware or firmware team in any role, say what that was and what part was yours. If you haven't, say so plainly and go to how you'd learn it |
| F7 | "partner with hardware and product on roadmap" (product) — role text in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote shows roadmap pressure. It doesn't show where the pressure came from or how you worked with product. Answer slot: if a product partner was part of the reliability-quarter conversation, say how that went and what your part was. If not, or there was no PM in it, say so plainly and stay with what you pushed through |
| F8 | "industrial IoT, ~600 people" and "device-management services" — role text in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | none | [grounded] | discovery | Your material says payments and doesn't speak to devices or IoT either way. Answer slot: if any of your work touched devices, fleets or embedded systems, say what it was and what was yours. If none did, say so plainly and say how you'd get fluent in the domain |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads (F1, F2) | A1, A3, B1, B4, H1 |
| Device-management services, industrial IoT (F8) | A1, E3, F2, I1 |
| Own delivery (F3) | A2, A4, I2 |
| Own hiring (F4) | C2, G4 |
| Own growth for 11 engineers (F5) | G3, I2 |
| Partner with hardware on roadmap (F6) | A2, B2, F2 |
| Partner with product on roadmap (F7) | D3, F1, F3 |

**Highest-ROI prep in the pack: B1.** Expect some version of "six to eleven, no managers of managers, no hardware: why are you ready?" in every round. B1 rehearses it in depth, and H1 is the 60-second version for Monday.

---

## Round 1 — Tuesday: Director of Engineering (45 min, hiring manager)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "You've got two squads. What do you do first?" Live problems from the role | High. The prior for a hiring manager: this is your would-be boss, testing whether you can run their org | Clarify, then objective, then approach, then metrics, then risks. Say the structure aloud and challenge one premise per case |
| Skeptic | Quiet probing of F1, F2 and F6: the step from six to eleven, managing managers, hardware | High. Also part of the hiring-manager prior: the person who signs off is the one who has to justify the risk | Rehearse B1 until it bores you. Name the limit before they do, using only the words F2 and F6 give, then offer a plan |
| Conversational | Opening "walk me through your background" | Low. Openers are still scored | 90-second arc built only from the beats your sentences state (C1) |

### Question bank

**A — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit two squads, 11 engineers, building device-management services. What do you do in your first 90 days?" | CASE | [grounded] | Clarify first: how the squads are shaped and whether they have leads, what's shipping and what's stuck, the on-call load, where hardware dependencies sit. Then the objective (keep delivery stable while you learn), then the approach (1:1s with all eleven, time with hardware and product partners, one small early commitment you can keep), then how you'd know it's working. The question asks about no past, so the guidance makes no claim about yours | The likeliest opener for a hiring manager, built from the role text. CASE because it scores structure. Your answer to "do the squads have leads" also decides how much F2 matters |
| A2 | "Hardware tells you a firmware change slips six weeks. Your squad's release depends on it, and product wants the date held. Walk me through it." | CASE | [generic] | Clarify what actually depends on the firmware and what can ship without it. Lay out two or three options with their costs. Name who makes the call and when the people affected hear about it. Close with what you'd change so the next slip shows up earlier. Treat it as reasoning, not experience. Nothing here claims you've done it | Tests F6 and F3 as a decision rather than a record. `[generic]` because the scenario is a pattern for the problem, not a fact about Larkfield |
| A3 | "How would you split your time across two squads?" | JD | [generic] | A plan, not a history: how you'd find out what each squad needs from you, how you'd keep 1:1s and decisions from bottlenecking on you, what you'd delegate and to whom (this depends on T-R1), and what you'd watch to see whether one squad is getting less of you. If asked whether you've done this before, give F2's words and return to the plan | Two squads is the first line of the role text, and F1 is where your material sits below it. JD because it scores the stated requirement |
| A4 | "Tell me about the reliability quarter. How did you get it through?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3, using only the quote's beats: your team's on-call burden, the roadmap pressure, you pushed a reliability quarter through, and the burden dropped 60% after. Tell it in your own words. Answer slot: "own delivery" and "partner with … product" make a probe on how you made the case, to whom, and what it cost the roadmap likely. If you made the case to specific people, say who and how. If there was no such negotiation, or it wasn't yours, say so plainly and stay with what the quote carries | F3 holds your strongest single sentence for this role, so expect the director to go here. EXP because it tests what was actually yours |

**B — Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've been a team lead of six and you've never managed managers. This is two squads and 11 engineers. Why are you ready?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | **The highest-ROI rehearsal in the pack.** Hold only what the quotes carry: "Three years as a team lead of six, and I haven't managed managers." Say the limit before they press. Then ask back whether the squads have leads, because that decides which gap is real. Then a plan, said as a plan: what you'd learn first and from whom. **Follow-up 1, "what makes you think it transfers?":** answer slot. If you know what from leading six you'd carry over, say it in your own words. If you're not sure yet, say so and go back to the plan. **Follow-up 2, "what goes wrong first?":** name one realistic risk in the plan, such as spreading yourself thin across two squads, and how you'd catch it. Concede specifically ("the manager-of-managers part is new to me") and never fold to "maybe I'm not ready." Don't upgrade "team lead" to "managed" | F1 and F2 are the widest gap between your material and the role, and the hiring manager carries that risk. JD because it scores the stated scope. Deepest rehearsal because some version will come up in all three rounds |
| B2 | "You haven't owned a hardware-adjacent roadmap. How do you get up to speed here?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment from F6: "I haven't owned a hardware-adjacent roadmap." Then F6's answer slot: if you've worked alongside a hardware or firmware team in any role, say what and your part. If you haven't, say so. Then the ramp, said as a plan: how you'd learn the hardware team's release rhythm, who you'd ask, and what you'd want to see in your first planning cycle | F6 is a gap you named and the role lists, so it's predictable. JD because the requirement is in the role text |
| B3 | "Why leave payments for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Your real reasons, in your own words. The pack doesn't know them and supplies none. A strong answer names something specific in this role (two squads, device management, the hardware partnership) and says why it fits where you are now. Lead with what pulls you toward Larkfield, not with what you're leaving | A standard Skeptic motivation check, made sharper by F8. JD because it tests fit to the stated role |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick a gap you actually stated: F2's or F6's words, one of them, said plainly. Then what you'd do about it in the first quarter. Don't offer a disguised strength, and don't pick a weakness your material doesn't carry | A Skeptic stem the director may use to test self-assessment. Using F2 or F6 keeps the answer consistent with B1 and B2 |

**C — Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc made only of the quoted beats: nine years in engineering, three as team lead of six, at a payments company now. You run the hiring loop for backend roles, about 40 interviews last year. Your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. End with one sentence on why this role, from B3. Fill the middle in your own words | The opener is scored. F1, F4 and F3 are the three beats your material carries |
| C2 | "Tell me about the hiring loop you run." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-mapped on F4: you run the loop, for backend roles, about 40 interviews last year. Keep the 40 on interviews. Answer slot: "own … hiring" makes a probe on whether you designed the loop, made hire/no-hire calls, or closed offers likely. If any were yours, say which, in your own words. If none were, or there was no such step, say so plainly and stay with running the loop and the interviews. If asked how the 40 was counted, say it in your own words, or say it's an estimate | F4 is your closest evidence for a role that owns hiring, so a hiring manager will want detail. EXP because it tests scope |

### Reverse questions: Tuesday

| # | Question | Why it lands |
|---|---|---|
| T-R1 | "Do the two squads have their own leads today, or would all eleven report to me directly?" | It decides whether F2 matters at all, and it shows you're already thinking about structure |
| T-R2 | "Where is delivery going well for each squad right now, and where is it stuck?" | It goes straight to the "own delivery" mandate and tells you what you'd inherit |
| T-R3 | "How do the hardware and software roadmaps get reconciled today, and where does that break down?" | It meets F6 head-on, as curiosity rather than defense |
| T-R4 | "Six months in, what would tell you this hire was the right call?" | You get your would-be boss's success criteria in their own words |
| T-R5 | "How much of next year's hiring is backfill and how much is growth?" | It connects to F4 and sizes the hiring part of the job |
| T-R6 | "What support do managers in your org get when they take on a bigger scope?" | It's an honest question given F2, and it asks how they develop managers |

---

## Round 2 — the Thursday after: panel, two staff engineers and a PM (60 min)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | "Where's the line between your call and ours?" Collaboration scenarios, credit-sharing probes | High. The panel rule blends each member's top two personas. This is top-two for both staff engineers (peer prior), and the PM is a roadmap partner per the role text | Lead with reciprocity: what you bring them, not just what you need. Propose principles for the seam rather than claiming to know it already |
| Data-Driven Prober | "How was that 60% counted?" | Mid. The second persona in the peer prior, so it comes with both staff engineers | Know what you can and can't say about the figure, and say plainly where you don't know |
| Values / Behavioral | Story prompts from the PM about disagreement and partnership | Mid. The cross-functional prior applied to the PM | "We" for context, "I" for contribution. Use only stories your material carries, or say there's none |

### Question bank

**D — Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where do you see the line between an EM's call and a staff engineer's call on technical direction?" | CASE | [generic] | Offer principles, not a claim about how Larkfield draws the line. For example: staff engineers own technical direction, the EM owns people, priorities and delivery commitments, and disagreements surface early and get settled in the open. Then ask how they draw it today. The question asks about no past, so the guidance claims none | Staff engineers will check whether you'd step on their turf. `[generic]` because it's a pattern for the seam, not a fact about this team |
| D2 | "Tell me about a time you disagreed with a senior engineer on a technical decision." | VAL | [generic] | No sentence in your material carries this story, so choose one: it needs a real disagreement, what you each argued, how it got decided, and a working relationship that held. Say what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A Peer Evaluator stem on disagreement between equals. VAL because it scores how you behave, not technical content |
| D3 | "If I'm the PM holding the roadmap and you want a reliability quarter, what does that conversation look like?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | What the quote carries: you pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% after. Answer slot: "partner with … product on roadmap" makes a probe on whether a PM was part of that likely. If one was, say how it went and your part. If not, or there was no PM, say so plainly. Then how you'd run it here, as a plan: bring the cost in terms product cares about, offer a trade, agree how you'd measure it | F7's discovery gap rehearsed in front of the PM who'd be your partner. JD because product partnership is in the role text |
| D4 | "What would you need from us in your first month, and what would we get from you?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Give both halves. What you need: their read on the hardest technical risks, and how decisions get made now. What you'd offer: protecting their time, unblocking cross-team dependencies, and on the hiring side, what F4's quote carries: you run a hiring loop for backend roles, about 40 interviews last year | The reciprocity question in its usual form. Grounding one offer in F4 makes it concrete without stretching it |

**E — Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "On-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend the number in your own words, slot by slot. How it was counted: say what was measured, or say plainly you don't know. What it's sensitive to: say what could move it. The assumption you'd defend least: name it before they do. Which part was yours: the quote says you pushed the quarter through, so say what else, if anything, was yours. The pack supplies no method or baseline. "I don't know exactly how it was counted" is an honest answer. Keep "after", not "because" | Your one headline metric (F3), and staff engineers will probe it. EXP because it tests attribution |
| E2 | "What was actually in the reliability quarter? What did the team work on?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The quote carries that there was a reliability quarter and that you pushed it through. It doesn't say what was in it. Answer slot: say what the work was and which parts you chose versus the team, in your own words. If you don't remember the detail, or the choices weren't yours, say so plainly and stay with pushing it through | Staff engineers will test whether you know the technical substance behind F3. EXP because it separates your part from the team's |
| E3 | "Device-management services are a different world from payments. Have you worked on anything like it?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | F8's answer slot: if any of your work touched devices, fleets or embedded systems, say what and what was yours. If none did, say so plainly, then how you'd get fluent: who you'd learn from and what you'd read in the codebase first. Don't claim payments experience "translates" as if that were proof. Describe what you've done and let them draw the inference | F8 is the domain gap, and staff engineers will feel it most directly. JD because the role text names the domain |

**F — Values / Behavioral (likely from the PM)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you pushed back on the roadmap." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3 and F7. The beats are the quote's: roadmap pressure, you pushed a reliability quarter through, your team's on-call burden dropped 60% after. Answer slot: the role's product partnership makes a probe on who held the roadmap and how the relationship came out likely. If you know, say it in your own words. If there was no product partner in it, say so plainly | Roadmap partnership is in the role text, and F3 is the one story that touches it. VAL because the PM is scoring how you behave, not the result |
| F2 | "A batch of devices is failing updates in the field. Hardware says it's software, your squad says it's firmware. What do you do?" | CASE | [generic] | Stabilize first: contain the impact and decide who talks to customers. Then a joint investigation with one shared timeline instead of two competing theories. Agree how the blame question gets set aside until there's data. Afterwards, a review both teams own. No claim about your past | Tests F6 and F8 as a live problem in front of a partner. `[generic]` because it's a pattern scenario, not a fact about Larkfield |
| F3 | "How do you keep product in the loop on what engineering is carrying: tech debt, reliability, on-call?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Describe a rhythm you'd set up here, as a plan: visible costs, regular check-ins, trade-offs on the table early. The one past beat you can use is the quote's: you pushed a reliability quarter through against roadmap pressure. Answer slot: if you had a regular way of surfacing that load to product, say what it was. If not, say so plainly | F7 from the PM's angle. JD because partnering with product is a stated requirement |

### Reverse questions: Thursday

| # | Question | Why it lands |
|---|---|---|
| Th-R1 | "What could a new EM do in the first month that would genuinely help your work?" | The reciprocity question. Peers weight it heavily, and the answer is your onboarding plan |
| Th-R2 | To the staff engineers: "Where does technical direction get decided today, between staff engineers and EMs?" | It follows up D1 with their real answer |
| Th-R3 | To the PM: "When hardware and software dates collide, who has the last word, and how does it get decided?" | It's the F6 seam, asked of the person who lives in it |
| Th-R4 | "What's the on-call load like for these squads right now?" | It ties to your F3 story without you having to bring it up |
| Th-R5 | "What about how the squads work today would you want a new EM to keep?" | It signals you won't arrive and rearrange everything |

---

## Round 3 — the following Monday: VP Engineering (30 min, "values and leadership philosophy")

A values-style round is detected here, because the recruiter's description names it. The values cheat sheet is left out because Larkfield's published values weren't in hand: search was blocked. The questions below are themed on the recruiter's words, not on named Larkfield values.

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?" Story prompts | High. The recruiter's own description of the round, which outranks the skip-level prior | Two or three principles you actually hold, each tied to a story your material carries, or to "I haven't had to do that yet" |
| Pressure | Time-boxed challenges on F2 and the 60% | Mid. The skip-level prior: 30 minutes leaves little time for slow answers | Pause, anchor in what your sentences say, hold through two follow-ups |
| Case / Strategist | Industry-level questions | Low here. The skip-level prior, cut back because the recruiter framed the round around values | Hypotheses and questions, framed openly as coming from outside the domain |

### Question bank

**G — Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | Two or three principles you actually believe, in your own words, each tied to one beat your material carries. For example, a principle about the team's long-term health, tied to F3's quote: you pushed a reliability quarter through against roadmap pressure. A principle about hiring, tied to F4's: you run the hiring loop for backend roles. Choose the principles yourself. The pack doesn't know them. About 90 seconds | The recruiter named this as the round's subject. VAL because it scores whether the philosophy matches behavior |
| G2 | "Tell me about a time you made an unpopular call and stuck with it." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3. The beats are the quote's: roadmap pressure, you pushed the reliability quarter through, and the on-call burden dropped 60% after. Answer slot: the round's "leadership philosophy" theme makes a probe on who disagreed and what it cost likely. If you know, say it in your own words. If it wasn't really a contested call, say so plainly and tell it as it was | A Values stem, and F3 is your one story with pressure in it. VAL because the VP scores judgment and spine |
| G3 | "Tell me about a time you helped someone on your team grow." | VAL | [generic] | No sentence in your material carries this, which is F5's gap, so choose a story: a specific person, what you did, and what changed for them. If growing people wasn't part of your role, or no such time comes to mind, say so plainly, then say how you'd approach growth for eleven engineers | "Growth for 11 engineers" is in the role text, and a leadership-philosophy round will likely touch it. VAL because it scores behavior |
| G4 | "Tell me about a hiring call that went wrong. What did you change afterward?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | What the quote carries: you run the loop, about 40 interviews last year. Answer slot: if a hiring call, or the loop itself, went wrong and you changed something, say what, in your own words. If none comes to mind, or the change wasn't yours, say so plainly and say what you'd watch for in a loop | Hiring is in the role text, and F4 is where a VP can test whether you learn from it. VAL because it scores reflection |

**H — Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an EM who has already managed managers?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | B1 in 60 seconds. Pause. Name the limit first: "I haven't managed managers." Then what you do carry: three years as team lead of six. Then one sentence of plan. Hold that position through two follow-ups. Concede the specific gap and never the core claim | The time-boxed version of the B1 objection, the way a skip-level would ask it. JD because it scores the stated scope |
| H2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold what the quote says: it was your team's on-call burden, and you pushed the quarter through. Say which part was yours beyond that, in your own words. If you don't know how much the quarter itself caused the drop, say so. Keep "after", not "because" | A Pressure stem aimed at F3, your headline figure. EXP because it tests attribution |

**I — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "From where you sit, what's hardest about building software for industrial IoT?" | CO | [generic] | Research didn't run, so this stays generic. Offer two or three hypotheses as hypotheses, say plainly you're coming from payments (F8's quote), and turn one into a question back to the VP. Don't present Larkfield facts you haven't read | A CO question at the VP's level of altitude. `[generic]` is the honest cost of no research |
| I2 | "A year from now, how would I know your two squads are healthy?" | CASE | [generic] | A small set of signals across delivery (predictable releases), reliability (on-call load), people (retention, growth conversations happening) and hiring (roles filled well). For each, say how you'd check it. A plan, with no claim about your past | Ties F3, F4 and F5 together as one leadership question. CASE because it scores structure |

### Reverse questions: Monday

| # | Question | Why it lands |
|---|---|---|
| M-R1 | "How would you describe the leadership philosophy you want from the managers in your org?" | It mirrors the round's own subject back to the VP |
| M-R2 | "What's a recent decision in your org you'd point to as your values in action?" | You get the values in practice, and something to connect your G2 story to |
| M-R3 | "Where does engineering feel the most tension with hardware timelines?" | It raises F6 at the VP's altitude |
| M-R4 | "What do the managers who do well here have in common?" | It tells you what you'd be measured against |
| M-R5 | "A year from now, what would you want to be true about this role?" | It closes the loop on I2 from their side |

---

## Prohibited claims

What this pack won't coach, and why. These hold in all three rounds and in any drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed a team of six, or had six direct reports | Inflated form of F1 | F1's quote at its own scope: "Three years as a team lead of six." The material says team lead and doesn't say whether the six reported to you. F1's slot stays inside the team you led |
| Has managed managers | A negative you stated, F2 | "I haven't managed managers." No slot |
| Owned a hardware-adjacent roadmap | A negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." F6's slot covers partnering only |
| The reliability quarter caused the 60% drop | Inflated form of F3 (logical form: "after" becoming "because") | F3's quote as written: "…dropped 60% after I pushed a reliability quarter through…" |
| Owned delivery, or owned the roadmap | Inflated form of F3 | F3's quote at its own scope. The material says you pushed one quarter through. F3's slot stays with how your team's work was planned |
| Made hiring decisions, or "40 hires" | Inflated form of F4 (and the number slid from interviews to hires) | F4's quote: "I run our hiring loop for backend roles — about 40 interviews last year." The 40 stays on interviews |

---

## Sources

- **Provided:** the role text, the three round descriptions (including the recruiter's "values and leadership philosophy"), and your background, all from your message. No dossier was present.
- **Searches sent:** "Larkfield Systems industrial IoT values" was refused. "Larkfield Systems interview process engineering manager" was refused. "Larkfield Systems device management IoT news 2026" was refused. This session doesn't have web-search permission.
- **Fetches:** none sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | The search was refused. It would have supplied the values cheat sheet for Monday and themed G1 to G4 on Larkfield's own value names |
| 2. Larkfield Systems interview process, engineering manager | unavailable | The search was refused. Your message already establishes the loop, so it would only have added format detail, such as whether the panel includes a system-design segment |
| 3. Larkfield Systems strategy / recent news | unavailable | The search was refused. It would have moved I1, A2 and F2 from `[generic]` to grounded, and added a CO question on Larkfield's current priorities |
| 4. Interviewer names at Larkfield | n/a | No names were given, so there was no query to form. Without names there's no interviewer read and no reverse questions tied to anyone's career path |
| 5. Representative Engineering Manager JD | skipped | The role text in your message fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** → the values cheat sheet for Monday with Larkfield's real value names, panel format detail for Thursday, and A2, F2 and I1 grounded in Larkfield's current strategy
- **A deeper research pass, once search is allowed: up to 6 more searches and 2 more fetches, several more minutes** → a strategy brief, recent org context, and loop reports for this role family
- **The full job posting**, if the one-liner isn't all of it → more requirement rows, with any mid-list items (a tech stack, on-call expectations, location) covered by questions
- **Your CV** → more stories than the one in your message. F3, F5, F7 and F8 could become story-mapped, and D2 and G3 could stop being selection scaffolds
- **Interviewer names** (the director, the two staff engineers, the PM, the VP) → a read on each one's public career path, personas assigned to each panel member, and reverse questions tied to their paths
- **Anything the recruiter said about Thursday's format** (system design, a case, a presentation) → a build section for any announced deliverable
- **Your answers to the answer slots** (whether the six reported to you, what your hiring role covered, whether a PM was in the reliability-quarter conversation) → F1, F4, F5 and F7 upgraded, and B1, C2, D3 and G3 story-mapped
- **How many hours you have to prep** → a prioritized triage schedule across the three rounds
- **A tuesday-dossier.md from an earlier assessment of this role, if you have one** → verified evidence, an objection derived from evidence rather than inferred, and a strategy for each weak area. The pack doesn't need one
