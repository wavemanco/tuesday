Reading the interview-prep playbook's templates now, then I'll build your pack.
I've saved your prep pack as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. Web search was refused in this session, so nothing in it about Kelverton's market, strategy or about Deepa and Ross comes from research. The pack is built from your message and the recruiter's email only.

**The 15-minute POV (Section 3)**
- **Running order:** about 13 minutes, so you have slack.
- **Three positions to argue:** fewer, deeper partners first; measuring partnerships by the operator's outcome alongside Kelverton's revenue; and a repeatable partner programme. Each comes with the concession you should say out loud.
- **Using the report:** The pack hasn't seen it, so each position has a gap for its claims. Name one point you agree with, one you'd push on, and one kind of partner you'd say no to. Deepa and Ross circulated it, so reciting it won't stand out.
- **Ending on operators:** The close covers what the plan means for operators, put as outcomes you'd test with them in your first 90 days.

**Highest-value question to rehearse (B1)**
Expect something like "You've never sold into rail and never carried a quota. Why should we trust you?" Admit both in your own words first. Then give the ISV channel at its real size: 6 to 40 partners and roughly £4M of influenced revenue. Then your plan for learning rail. Ross's questions on the £4M (C1) and the 6-to-40 (C2) come next.

**Watch these phrasings**
- **"From the other side":** keep it as consulting on bus and light rail network planning. Don't let it turn into having worked inside an operator or in heavy rail.
- **The £4M:** keep it as influenced revenue. Your note doesn't say whether it's over the four years or per year. If you're unsure, use the smaller reading.

The pack also schedules your 4 hours and includes 21 questions across both panellists and six questions for you to ask them.

Next:
- I can play Deepa on B1 or Ross on C1 as a live practice run.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document.

Two questions:
1. Is there a job description you can paste? Without one, four of the role requirements are general assumptions about this kind of role. I'll go ahead without it if there isn't one.
2. Do you want me to retry the web searches if you approve them, or keep the pack to your own material?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

**Round:** Second round, 60 minutes, Tuesday. A 15-minute spoken POV (no slides), then Q&A.
**Panel:** "Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)", from the recruiter's email.
**Recruiter's brief, quoted:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."

## 1. How to use this pack

Personas describe **how** a question is asked. Types describe **what** is being scored. The guidance gives you a structure to work from. It is not a script, so say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the values the company publishes |
| EXP | Whether your stated record holds up, and what was actually yours |
| JD | Whether you can do the stated job, gaps included |
| CO | Company and market knowledge: whether you can think at the company's level |
| CASE | A live problem from the role, worked through out loud |

Provenance labels: `[grounded]` means it comes from your message or the recruiter's email. `[inferred]` means it is derived, and the derivation is named. `[generic]` means it is a role-family pattern that makes no claim about Kelverton. Web research was refused in this session (see Sources), so **everything about Kelverton's market, strategy and people is `[generic]`**, except what the recruiter wrote.

## 2. Prep triage (4 hours)

| Block | Time | What to do | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV. Fill its report slots from the market report, then say it aloud against a timer three times, aiming for 13 minutes | Section 3 |
| 2 | 45 min | Rehearse the highest-ROI question, then defend both numbers | B1, C1, C2 |
| 3 | 35 min | Ross's commercial cases, said aloud with the assumptions named | A2, C3, C4, D2 |
| 4 | 25 min | The operator close and the first-90-days answer | Section 3 close, A1 |
| 5 | 20 min | Read the prohibited list, then pick 3 reverse questions | Sections 8 and 9 |
| 6 | 20 min | A live drill of B1 or C1 | Ask me |
| 7 | 20 min | Buffer, then one last timed run of the POV | Section 3 |

Everything else in this pack is insurance.

## 3. Graded deliverable: the 15-minute operator-partnerships POV

### What you can build on

| Source | What it gives you |
|---|---|
| F6: "9 years in partnerships" | Your tenure, said plainly |
| F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | The channel you ran and how far it grew, at its own scope: a payments ISV channel, with influenced revenue |
| F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your transport background, at its own scope: consulting, network planning, bus and light rail |
| F7: "the market report their strategy team circulated internally last quarter, which I've read" | Kelverton's own framing. This pack has not seen the report, so every thesis below has a slot for its claims |
| Recruiter | "no slides needed, just talk us through it"; "land on what it means for the operators themselves" |

### Suggested running order (about 13 minutes, leaving 2 minutes of slack)

| Minutes | Beat | Notes |
|---|---|---|
| 0–1 | Frame | Who you are in one sentence from F1 and F2, then the single idea of the POV |
| 1–3 | What I read | One point from the report you agree with and one you would push on, named by the report's own words |
| 3–10 | Three moves across 0–6, 6–12 and 12–18 months | One thesis per window, from the table below, each with its concession said out loud |
| 10–12 | What it means for operators | The close the recruiter asked for. Say it in operator terms, not partner terms |
| 12–13 | How I'd know it's working, and what I'd need | Two or three measures, with one commercial measure for Ross |

### Thesis options (pick 2 or 3)

These are positions for you to argue, not facts about Kelverton. Each one has a slot for the report.

| # | Thesis | Mandatory concession | Report slot | Provenance |
|---|---|---|---|---|
| T1 | Fewer, deeper partners before more of them. In the first six months, concentrate on the few partner categories closest to the scheduling workflow, where an operator feels the integration every day | Partner count will look flat for two quarters, and you are trading breadth for depth on a hunch until operators confirm it | Name which partner categories the report points to, and use its words | [generic] |
| T2 | Measure partnerships by the operator's outcome and Kelverton's revenue together, defining the operator-side measure with operators | Attribution gets harder, and an operator outcome on its own will not satisfy a Commercial Director. Say that before Ross does, and pair the outcome with a revenue measure | Use any operator pain point or metric the report names | [generic] |
| T3 | Turn partnering into a repeatable programme: clear tiers, a certification bar and a shared roadmap rhythm, so that partner number 15 costs less than partner number 5 | It needs product and engineering time that Partnerships does not control, and the 18 months depends on getting it | Note anything the report says about the platform's openness or integration backlog | [generic] |

**Optional framing for T3, pending your approval.** "At the payments company I ran the ISV channel and took it from 6 partners to 40." That is F1 at its own scope. Let the panel draw any inference about Kelverton from it. Do not say the channel "proves" anything.

### Differentiating from the consensus

- **The trap.** Deepa and Ross wrote or circulated the report, and any other prepared candidate has read it too. If you recite it, you score as someone who did their homework. If you depart from it with reasons, you score as someone with judgement.
- **One consensus point.** Use one point from the report to show you are grounded in it.
- **One divergence.** Pick a point where you would sequence differently from the report, and say why.
- **One anti-pick.** Name a partner category or deal type you would say **no** to in the first 18 months, and why. In a partnerships role, saying no is part of the job.

### The close: what it means for operators

Present these as outcomes you expect and would test with operators in your first 90 days. Do not present them as known facts, because the pack has no operator data. Each is `[generic]`:

- **Fewer integrations for operators to manage themselves.**
- **One accountable party when a partner's piece breaks.**
- **Faster changes when the operator's plan changes.**

End with one line on how you would check these with two or three operators early.

**F2 scope rule for the close.** You can refer to your consulting years as "five years in transport consulting on bus and light rail network planning." Do not say you have worked inside an operator or in heavy rail (Section 8).

## 4. Fit snapshot

No JD was supplied. Rows F1 to F3 rest on the recruiter's own words. Rows F4 to F7 are role-family requirements written without a source.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The channel is a payments ISV channel, not operator partnerships, and there is nothing inspected behind it. Words at its own scope: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the 18-month framing makes a probe on how you planned that growth likely. If you set a plan or sequence for it, say how in your own words. If there was no such plan, or it wasn't yours, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material places this on the consulting side, in network planning, for bus and light rail. It does not cover train operating companies or work inside an operator. Words: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: the recruiter's operator line makes a probe on your dealings with operators likely. If operators were your clients or counterparts, say which part of that was yours, in your own words. If they weren't, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials." — recruiter | "roughly £4M of influenced revenue" — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | The figure is influenced revenue, not revenue you closed. Your material does not say whether it is over four years or per year, so read it the smaller way, as over four years, unless you know otherwise. Defend-the-number slots, all in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know exactly how it was counted" is an honest answer |
| F4 | Carrying a direct revenue number, a common expectation in senior commercial partnership roles | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap you have stated yourself, and wording cannot close it. Words: "I haven't carried a direct quota. My number has been influenced revenue." Then what you would sign up to here, said as a plan and never as a past (C3) |
| F5 | Selling into rail and train operating companies, a common expectation for rail-tech partnership roles | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap you have stated yourself. Words: "I haven't sold into rail." Then a ramp plan, said as a plan: the operators and partners you would talk to first, and what you would ask them |
| F6 | Building and scaling a partner programme, a role-family requirement | "9 years in partnerships" — your message; "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap, but there is nothing inspected behind it, so expect a probe. Lead with the channel in the quote's own terms: you ran it, and it went from 6 partners to 40 |
| F7 | Command of Kelverton's market, a role-family requirement made live by the report the recruiter attached | "the market report their strategy team circulated internally last quarter, which I've read" — your message | medium | [grounded] | discovery | Your material shows you read it, but this pack has not seen it, so it cannot test what you would say. Answer slot: when asked what you made of it, name one claim you agree with and one you would test, in your own words. If there is nothing you would push on, say so and say what you would want to check first |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1, the 18-month POV | Section 3, A1, A4, D2 |
| F2, what it means for operators | Section 3 close, A3, B3 |
| F3, commercials | A2, C1, C2, C3, C4, D1 |
| F4, a direct number | B1, C3 |
| F5, selling into rail | B1, D1 |
| F6, scaling a programme | B2, C2, D3, E1 |
| F7, market command | E2, Section 3 |

## 5. Persona table

The loop rests on the recruiter's email: one 60-minute panel with two named members, a 15-minute POV, then Q&A. It names no values-style round, so the values cheat sheet is left out.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa testing the POV's logic, and Ross testing how it makes money | High. A future manager is buying capability and the POV invites cases. Ross is a senior commercial leader, where the prior is strategy-heavy cases | Clarify, then state the objective, then segment, then the approach, then the metrics, then the risks. Think out loud. Challenge one premise per case, politely |
| Skeptic | Deepa on the rail gap and on motivation | High. A hiring manager has to de-risk the gaps, and F4 and F5 are the visible ones | Rehearse B1 until it's boring. Concede the stated gaps in your own words, keep bridges to what your quotes carry, and add a ramp plan |
| Data-Driven Prober | Ross on the £4M and the 6-to-40 | High. The recruiter said "Ross will push on commercials", and your two figures are the obvious targets | Know what you can and cannot say about how each figure was counted. Name the weakest assumption before he does |
| Pressure | Ross time-boxing and playing devil's advocate on the POV | Medium. "Push" suggests deliberate challenge, and the senior-commercial prior adds pressure | Pause and restate the question. Hold a challenged position through two follow-ups before conceding anything specific |
| Conversational | The opening minutes, and the report asked about casually | Medium. Panels usually warm up, and casual questions are still scored | Use a 90-second arc for "walk me through it" (E1) |
| Values / Behavioural | Partner-conflict and hard-message stories | Low. No values round was named, but a manager may still ask behavioural questions | Use the selection scaffolds in H1 and H2 |
| Peer Evaluator | Deepa asking how you would work with sales and with her | Low. She is your manager, not a peer, but seam questions about sales and partners are common in partnerships roles | Answer with principles for the seam, not claims to know where it sits |

## 6. Question banks

**Highest-ROI prep in this pack: B1.** The two gaps you named yourself, rail and quota, are where this panel will press hardest.

### A. Case / Strategist (Deepa and Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've told us where you'd take this. What would you actually do in your first 90 days?" | CASE | [generic] | Structure: who you would listen to first (operators, current partners, sales), how you would sort the current partners by value, which two or three bets you would commit to, and the measures you would agree with Deepa. This is a plan, so it makes no claim about your past | The natural follow-on to any 18-month POV, and an honest home for the F5 ramp. CASE because it is a live plan |
| A2 | "Pick one partnership from your plan. How does it make us money, and when?" | CASE, CO | [generic] | Name the revenue mechanism (referral, resale, co-sell, revenue share or implementation), the time to first revenue, and what it costs Kelverton to support. Then say the assumption you would defend least. Use the report's numbers if it has any, and otherwise say you are reasoning from structure | This is exactly what "Ross will push on commercials" means. CASE in delivery, CO in content |
| A3 | "An operator tells us a partner's integration broke their timetable change. Who owns that?" | CASE | [generic] | Clarify what broke and when. Fix it for the operator today. Then agree accountability with the partner, then make a lasting change to the programme (certification, a support agreement). Close on the operator's experience, not on who was at fault | Tests the operator lens the recruiter asked for, under live conditions. CASE because it asks about no past |
| A4 | "How would you decide which partners we stop investing in?" | CASE | [generic] | Criteria: operator usage, revenue, support cost and strategic fit. Then how you would wind down without hurting operators who rely on the integration | Tests whether your POV can say no, which mirrors the anti-pick in Section 3 |

### B. Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail and you've never carried a quota. Why should we trust you with this?" | JD, EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | **Highest-ROI rehearsal.** Concede first, plainly, in your own words: "I haven't sold into rail, and I haven't carried a direct quota. My number has been influenced revenue." Then the channel at its own scope: "I ran the ISV channel at a payments company and took it from 6 partners to 40." Then the ramp, as a plan (A1). Follow-up 1, "So what makes you think you can?": go back to the channel, not adjectives. Follow-up 2, "Influenced is soft": agree it isn't closed revenue, and say what you would sign up to here (C3). Hold, and never add to the quotes | F4 and F5 are the gaps you stated yourself and the obvious objection to a candidate new to rail. JD because it scores the role's commercial and domain asks; EXP because it tests what was yours |
| B2 | "Payments ISVs and train operators are very different. What actually transfers?" | JD | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say what each part of your background was, at its own scope, and let them draw the inference. Answer slot: the POV brief makes a probe on how you would run a partner programme here likely. If there is a part of how you ran the ISV channel that you would reuse, name it and say how you did it, in your own words. If you would start differently here, say so plainly and stay with the channel you ran | The bridge between F1 and F2 is the core of your case. Telling them what your work "proves" is a claim they will test, so let them make the link |
| B3 | "You said you know operators from the other side. Have you worked with train operators?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Start with the quote's scope: transport consulting, network planning, bus and light rail. Answer slot: if any of that work had operators as clients or counterparts, say which part was yours, in your own words. If it involved no train operating companies, say so plainly and stay with bus and light rail | F2's phrase invites exactly this probe, and being vague here would undo B1 |
| B4 | "Why leave payments for rail-tech, and why now?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your motivation is yours to state, and the pack has none of it. Selection scaffold: give a reason in your own words that ties to something you actually said, such as the transport years. If the reason is something else, say that instead. Do not borrow a reason that sounds good | The standard Skeptic question on motivation. F2 is the only material that touches it |

### C. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say "roughly £4M of influenced revenue", and say whether that is over the four years or per year. If you are unsure, use the smaller reading. Answer slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least (name that one before he asks), and which part was yours. If you don't know how it was counted, say so plainly. Never supply an attribution model you can't repeat under a second question | Your headline figure, and a commercial director's first target. EXP because it tests attribution |
| C2 | "6 to 40 partners. How many of the 40 actually moved revenue?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you know how revenue was spread across the 40, say so in your own words. If you don't, or nobody tracked it, say so plainly and stay with the growth from 6 to 40. Don't estimate a split on the spot | Partner counts invite a question about concentration, and an honest "I don't have that split" beats a guess |
| C3 | "Influenced revenue is soft. What hard number would you sign up to here?" | CASE, JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Concede in your own words: your number has been influenced revenue. Then the live part: the measure you would propose here (partner-sourced pipeline, partner-attached win rate, or revenue through partner tiers), why you chose it, and the level you would want to agree with Deepa after 90 days of data. Name a starting level only if you can say what it rests on | F4 under commercial pressure. Your past stays at the quote, and the forward commitment is the CASE part |
| C4 | "What does a partner cost us, and what's the payback?" | CASE | [generic] | Structure: what it costs to sign and enable a partner, ongoing support and engineering load, any revenue share, then payback as revenue over cost across a time window. Say the assumption you are least sure of | Ross's natural language. A live problem with no claim about your past |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's sold to train operators for ten years?" | JD | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause. One sentence of concession ("I haven't sold into rail"), then the channel and the transport years at their own scope, then one line on the POV's operator focus. Stop inside 60 seconds | B1 in pressure form. Timed answers reward the version you rehearsed |
| D2 | "Your plan assumes partners will co-sell. Most won't. What then?" | CASE | [generic] | Hold: say what in the plan doesn't depend on co-selling, such as referral or integration value. Then concede specifically: which thesis weakens and how you would find out early. Hold through two follow-ups. Don't drop the POV to make the room comfortable | Tests whether your POV survives challenge. CASE because it is about the plan, not your past |
| D3 | "That growth from 6 to 40. How much of it was actually you?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | "I ran the ISV channel." Answer slot: if others recruited or managed partners, say who did what and which parts were yours, in your own words. If it was mostly you, say which parts. Use "we" for the team and "I" for what you did | The standard attribution probe on F6. Answering it honestly is what makes your numbers credible |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc: transport consulting on bus and light rail network planning, then the payments ISV channel from 6 to 40 partners and roughly £4M of influenced revenue, then why Kelverton, in your own words. Stop there and let them pick a thread | Almost certainly the opener. A tight arc saves your 15 minutes for the POV |
| E2 | "What did you make of the report we sent?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Answer slot: one point you agree with and one you would test, named in the report's own words. If nothing stands out to push on, say so and say what you would want to check first. Don't quote figures you can't find again on the page | F7. They wrote it, so they will notice whether you engaged with it or recited it |

### G. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time a partner relationship went wrong." | VAL, EXP | [generic] | Selection scaffold: pick a partner relationship with a named problem, something you did yourself, and where things stood at the end. If no such time comes to mind, say so plainly, then give the nearest example your experience does carry, or how you would handle it | A common partnerships question, themed by the recruiter's operator-partnerships brief. None of your quotes carries a story here, so this is a scaffold |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you didn't fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest example you have, or how you would handle it | A Values persona question. Low weight, but it keeps you from meeting the style for the first time live |

### H. Peer Evaluator (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A partner and one of our sales reps both claim the same operator deal. What do you do?" | CASE | [generic] | Propose principles: who registered it first, who brought the operator, how credit is split, and how the rule gets written down so it doesn't recur. Then say you would want to learn the current rule before changing it | The conflict between partners and sales is the classic seam in a partnerships role. A live problem |
| H2 | "What would you need from me in your first month?" | CASE | [generic] | Reciprocity first: what you would bring her (a partner map and a 90-day plan). Then what you need: introductions to two or three operators, access to partner data, and a regular check-in | A manager's version of the peer question. It shows how you would work with her |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which part of the report do you two disagree on, if any?" | It shows you read the report as a working document, and asks two senior people to think out loud |
| R2 | "Ross, how is partnerships' commercial contribution measured today, and what would you want it to be in 18 months?" | It answers F3 and F4 for you and turns his push into shared design |
| R3 | "Deepa, what does a great first six months look like to you in this role?" | Your future manager sets the bar. Ask it directly |
| R4 | "Which operators would you want me talking to in the first 90 days?" | It ties the ramp plan (F5) to their relationships, and shows you will close the rail gap by listening |
| R5 | "Where has a partnership disappointed an operator before, and what changed?" | It tests the operator lens they asked for, and tells you how they handle failure |
| R6 | "What decision is this role expected to make that nobody's making now?" | It tells you what the role is really for |

## 8. Prohibited claims

These are claims this pack will not coach. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota, or closed or generated £4M | Negative you stated (F4), and an inflated form of F3 | "I haven't carried a direct quota. My number has been influenced revenue." The figure stays "roughly £4M of influenced revenue" |
| Has sold into rail or to train operators | Negative you stated (F5) | "I haven't sold into rail." |
| £4M a year | An inflated reading of F3. Your material does not say per year | The figure as you stated it. If you know the period, say it; if you don't, use the smaller reading |
| Built or founded the ISV channel | Inflated form of F1's "running the ISV channel" | F1's quote at its own scope: you ran it, and took it from 6 partners to 40 |
| Worked inside operators, or in heavy rail | Inflated form of F2. It changes which side you stood on, and its scope | F2's quote at its own scope: transport consulting, network planning, bus and light rail. The material says consulting, not operator-side. B3's slot stays inside that |
| Knows what Kelverton's operators need | Inflated form of F2, combined with silence on Kelverton | Put operator benefits forward as outcomes you expect and would test (Section 3 close) |

## 9. Sources

**Provided material:**
- The recruiter's email, as quoted in your message.
- Your background, as described in your message.
- The market report is with you and was not shared here, so this pack has not read it.
- No dossier was present.

**Searches sent:** five. Every one was refused because web search permission was not granted, so none returned anything:
- "Kelverton Rail values"
- "Kelverton Rail interview process partnerships"
- "Kelverton Rail scheduling software train operating companies news"
- "Deepa VP Partnerships Kelverton Rail"
- "Senior Partnerships Manager rail software job description UK"

No fetches were made.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The search was refused. It would have themed G1 and G2 with published values. No values round was named, so the cheat sheet would still be left out |
| 2. Kelverton Rail interview process | unavailable | The search was refused. The recruiter's email establishes this session anyway, so the persona weights rest on it |
| 3. Kelverton Rail strategy and recent news | unavailable | The search was refused. It would have grounded the POV theses, A2 and E2 in current strategy, so they are left `[generic]` |
| 4. Deepa, Kelverton Rail | unavailable | The search was refused, and no call was sent for Ross. It would have added an interviewer read, persona weights read from public profiles, and a reverse question tied to their careers |
| 5. Representative Senior Partnerships Manager JD | unavailable | The search was refused. It would have turned F4 to F7 into `[inferred]` requirements with quoted lines |

## 10. Upgrade menu

- **Approve web search.** Targets 1 to 5 run: an interviewer read for Deepa and Ross, CO questions on Kelverton's current strategy, and quoted lines for rows F4 to F7.
- **Paste the report's key claims, or a page of it.** T1 to T3, the anti-pick and E2 become `[grounded]` on Kelverton's own framing, and the POV's report slots get filled.
- **The JD text.** F4 to F7 become `[grounded]`, and every listed requirement is checked against the banks.
- **Your answers to the slots in F1 to F3** (how the growth was planned, whether operators were your clients, how the £4M was counted and over what period). C1, C2, B3 and D3 become fully story-mapped.
- **Deeper research.** Up to 6 more searches and 2 more fetches, which takes several more minutes. It covers Kelverton's strategy, Deepa's and Ross's public talks or writing, loop reports and recent changes at the company. This needs web search approved first.
- **A tuesday-dossier.md from an underwriting pass.** It would add evidence-derived objections and a prohibited list you had confirmed, in place of the ones this pack inferred.
