Building your prep pack now. Next I'm running a few targeted searches on Saltmarsh Games and Tobias Wrenfield.
I've written your prep pack for Friday. It's 22 practice questions, each with suggested answers, built from the job description and what you told me. I couldn't research Saltmarsh Games or Tobias Wrenfield because web search wasn't allowed in this session. So there's nothing on the company's values, their interview format, recent news, or Tobias's background, and none of it is guessed. The pack assumes Tobias would be your manager, since you didn't say.

- **What to practise most: question B1.** It's the hard one: "You've never led a team. How will you get design, art, engineering and community moving together on every update?" Your answer opens by saying it plainly: "I haven't led a team." Then it sticks to what you actually did: two years running the weekly content-drop calendar, and writing the release checklist QA still uses.
- **Your strongest point** is running the content calendar, which the job asks for directly.
- **Where you'll get pushed:**
  - The job is live events for two games; you ran weekly content drops for one.
  - The job asks you to own the post-event review and its numbers; you presented the retention numbers.
  - The job asks you to manage the release checklist with QA; you wrote it.
- **Spots only you can fill in.** Some suggested answers leave a gap where only you know the truth, like whether your content drops included time-limited events. Each gives two honest ways to answer: you did it and say how, or you didn't and say so.
- **Claims the pack won't coach.** There's a short list of things to avoid saying, like "four years as a producer" (keep "associate") or any claim to in-app purchase experience.
- **For tonight**, the pack opens with a prep plan for one evening. One item on it is finding out which two games this role covers and playing them.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-denied-5fbddd5b:
- Saltmarsh-Games_live-operations-producer_interview_pack.md

If you want a practice run, I'll play the skeptical interviewer on B1 and push back on your answers.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and did the recruiter mention a format or a task (for example, planning a calendar or writing up a review)? The answer changes which questions the pack prioritises.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations (from your message)
**Format:** 60 minutes, Friday
**Relationship:** assumed to be your hiring manager. A Head of Live Operations interviewing for a Live Operations Producer is the likeliest reading, but your message didn't say. If he isn't your future manager, the persona weights below change.
**Research:** none ran. Web search was not permitted in this session, so everything about Saltmarsh's values, interview process, strategy and Tobias's background is missing, not guessed (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question gets asked: a calm case, a quiet skeptic, a number-prober.
- **Types** describe *what* is being scored:
  - **JD**: can you do the job as listed, gaps included
  - **EXP**: does what you said about your past hold up, and what was actually yours
  - **CASE**: a live problem from the role, solved out loud
  - **CO**: company and strategy knowledge
  - **VAL**: behaviour that matches the company's published values
- **Provenance**: `[grounded]` means it traces to your message or the JD. `[inferred]` means it is derived from them, with the derivation named. `[generic]` means a common pattern for this role family, with no claim about Saltmarsh.
- **Answer slots** mark the places where only you know the answer. Each one has two honest branches: either you did it, and you say how in your own words, or you didn't, and you say so plainly. Both are fine.
- The guidance is scaffolding, not a script. Each answer should take 90–120 seconds to say out loud.

---

## Prep triage: one evening (today is Thursday, the interview is Friday)

1. **B1, the highest-ROI question in this pack.** Say it out loud three times, and run it as a drill if you can. About 30 minutes.
2. **Learn your five sentences** from the fit snapshot (F1 to F9 draw on them) word for word. Every answer you give should stand on them or on an answer slot. About 15 minutes.
3. **Work through the answer slots in B1, B3, C1, C2, A5 and E2.** Decide which branch is true for each and how you would say it. About 30 minutes.
4. **Find out which two titles this role covers, and play both** if you can (D3, A1). About 45 minutes.
5. **Rehearse A1 and A2 out loud**, using the case structure in the persona table. About 20 minutes.
6. **Pick three reverse questions.** About 5 minutes.

Everything else in this pack is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows a weekly content-drop calendar for one title, not a live-events calendar for two, and your words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events line makes a probe likely on whether your drops included time-limited events. If some did, say what kind and how you ran them, in your own words. If none did, say so plainly and stay with the drops you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. This is your strongest row. Lead with the sentence as it stands: weekly, your main title, two years. Since it's a statement with nothing inspected behind it, expect a probe on how the calendar worked |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [grounded] | discovery | Your sentence is about leading a team, and coordinating isn't the same thing. Your material neither shows nor rules out coordination. If someone asks about leadership, the words are yours: "I haven't led a team." Answer slot: if running the calendar meant working with any of design, art, engineering or community, say which and how, in your own words. If it didn't, say so plainly and stay with the calendar and the checklist |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned a review or its KPIs. Your words: "I presented the monthly retention numbers to the studio head." Answer slot: if any part of preparing or interpreting those numbers was yours, say which part. If your part was the presenting, say so plainly and stay with that |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist is adjacent to managing it with QA, and still short of it. Your words: "I wrote the release checklist our QA team still uses." Answer slot: if you ran releases against it with QA, say how, in your own words. If your part was writing it, say so plainly and stay with that |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are there, and the title was associate producer: keep the word "associate". Your material doesn't say whether the main title was run as a live-service game. Answer slot: if it was, describe what made it one in your own words. If it wasn't, say so plainly and stay with the weekly drops |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap. Your sentence names retention numbers and a senior audience. Expect a prober to ask how those numbers were counted (C1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | When writing comes up, use this sentence. Your checklist is written work, and the sentence says the team still uses it. Don't add anything to it |
| F9 | Mobile live-ops roles commonly involve in-app purchase events and revenue KPIs; the JD doesn't say so | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap you stated yourself, so you can say it back: "I haven't worked on a game with in-app purchases." After that, explain how you would learn it, as a plan and never as a past. This row is a role-family pattern, not a Saltmarsh fact. The JD doesn't mention monetisation, so the reverse question R6 is where you find out whether it matters |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A1, B2, B3 |
| Coordinate design, art, engineering and community (F3) | B1, A3, G1, G2 |
| Own the post-event review and its KPIs (F4) | A4, A2, C2 |
| Manage the release checklist with QA (F5) | A5, E2, H2 |
| 3+ years producing live-service games or apps (F6) | D1, B3, E1 |
| Experience running a content calendar (F2) | A1, B2, D1 |
| Comfortable with player-retention metrics (F7) | C1, C3, A2 |
| Clear written communication (F8) | Partly A4, where the review is a written document. Otherwise none, because a spoken interview can't directly test writing. The upgrade menu says what would |

---

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | "Plan the quarter", "retention dropped, diagnose it" | High. Hiring-manager prior, with Tobias as the assumed manager. No loop source exists, so the fallback is the generic archetype, which adds no tilt of its own | Clarify, then objective, segmentation, approach, metrics, risks. Think out loud, and respectfully challenge one premise per case |
| B. Skeptic | Quiet probing of F3, F1, F9: team, two titles, monetisation | High. Hiring-manager prior, plus the fit snapshot has three real gaps for it to find | Rehearse B1 until it's boring. Bridge only from your five sentences, say limits plainly, then give a concrete plan |
| C. Data-Driven Prober | "How were those retention numbers counted?" | Mid. F7 and F4 put retention on the table, and a live-ops lead is likely to push on it | Know what you can and can't say about how the numbers were made. "I didn't build them" is an acceptable answer if true |
| D. Conversational | "Walk me through your journey", "what are you playing?" | Mid. Most 60-minute hiring-manager rounds open this way. Generic pattern | Have a prepared 90-second arc (D1). Treat casual questions about games as scored |
| E. Pressure | "Sixty seconds: why you?" | Low. Nothing points to a stress format, but a gap-heavy profile invites one push | Pause, anchor in your sentences, hold through two follow-ups, then concede specifically |
| G. Peer Evaluator | "What would you need from engineering?" | Low. Not a peer round, but the JD's coordination line brings these questions into it | Use reciprocity: what you give each team, not only what you need from them |
| H. Values / Behavioral | "Tell me about a time…" | Low. No values round detected, and Saltmarsh's values weren't researched | Have one honest story ready per prompt, or say plainly that you don't have one |

Weights are flat apart from the hiring-manager prior, because no source on Saltmarsh's actual interview process was read.

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch next quarter's live-events calendar across our two titles. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: who plays each title, current update cadence, team capacity, and which KPIs the review reports. Then structure it: a rhythm per title, where shared teams create collisions, the lead times each discipline needs, the QA checklist gates before every release, and what you'd measure. You may anchor once, in your own words: for the last two years you ran the weekly content-drop calendar for your main title. Don't describe how that calendar was built beyond what you actually did | This is the core of the JD's first line, asked as a live problem. F2 gives you a true anchor. CASE because what gets scored is the structure |
| A2 | "Day-7 retention dipped after our last event. Diagnose it." | CASE | [generic] | Confirm the definition and the comparison window. Segment by new versus returning players, title, platform and region. Check the timing against the event, then hypotheses: difficulty, reward value, a bug, a clashing event, a calendar gap. Say what you'd check with engineering and QA first, and what goes into the review. Name the assumption you're least sure of | Retention plus review sits at the centre of F4 and F7. The question makes no claim about your past |
| A3 | "Two days before an update ships, art says a key asset will be a week late. What do you do?" | CASE | [generic] | Clarify what depends on the asset and whether a fallback exists. Options: ship without it, swap it, slip the update, or re-sequence the calendar. Say who you would bring together (design, engineering, community for player messaging, QA for re-testing) and how you'd decide | Coordination is the JD's second line and the F3 gap. A CASE lets you show the skill without claiming a past |
| A4 | "What makes a good post-event review, and which KPIs would you report?" | CASE | [generic] | A proposal, not a history: participation, completion, retention around the event window, sentiment from community, bugs and incidents, and what changes next time. It's a written document, so mention keeping it short and decision-focused. End by asking which KPIs Saltmarsh reports today | The JD's "own the post-event review" line (F4). Also the closest the interview gets to testing writing (F8) |
| A5 | "How would you run the release checklist with QA across two titles on different cadences?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Anchor in your words: you wrote the release checklist your QA team still uses. Then a plan: one shared core plus title-specific gates, who signs off, and how it stays current. Answer slot: the JD says "manage the release checklist with QA", so expect a probe on how you ran it day to day. If you ran releases against it with QA, say how. If your part was writing it, say so plainly and stay with that | F5 is adjacent, not a match. JD because it scores a listed duty directly |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. How will you get design, art, engineering and community moving together on every update?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses." | **The highest-ROI rehearsal in this pack.** Name the limit before he does: "I haven't led a team." Then give only what your sentences carry: for the last two years you ran the weekly content-drop calendar for your main title, and you wrote the release checklist your QA team still uses. Answer slot: the JD's coordination line makes it likely he'll ask whether that calendar involved those disciplines. If it did, say which teams and how you worked with them, in your own words. If it didn't, say so plainly and stay with the calendar and checklist. Then your plan, framed as a plan: learn each team's lead times, put the dependencies on the calendar, and agree the checklist gates. Hold through two follow-ups by returning to these facts, never by adding to them. If he presses on authority, concede plainly that you haven't managed people | F3 is the biggest gap against a headline JD line, and you stated the negative yourself, so the question will come in some form. JD because it scores the coordination requirement |
| B2 | "We run two titles. You've run a calendar for one. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Keep the premise at its own scope: your main title, two years. Then think out loud: shared teams, clashing events, deciding which title gets scarce art or engineering time, and keeping two players' calendars from fighting each other. Answer slot: if you had any part in other titles' calendars, say what it was. If you didn't, say so plainly and stay with the main title | F1's scope gap, one title against two. JD because "two of our mobile titles" is in the first line |
| B3 | "Weekly content drops aren't live events. Why should I believe you can run the second?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Don't argue that they're the same. Say what you ran, in those words. Answer slot: if any of your drops were time-limited events, describe one, in your own words. If none were, say so plainly and say what you would need to learn first, then ask how Saltmarsh defines a live event | F1 and F6 both depend on whether your title counted as live-service, and the material doesn't say |
| B4 | "You've never worked on a game with in-app purchases. How would you get up to speed if our events involve them?" | EXP | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a short plan: learn from whoever owns monetisation and analytics, study the titles' stores and past events, and ask which revenue measures the review reports. Don't bridge from retention to revenue: they're different measures | F9 is a stated capability gap at a mobile studio, so it's likely to come up even though the JD is silent. The question's "if" keeps Saltmarsh's events unassumed |
| B5 | "Why leave a puzzle studio for this, and why now?" | EXP | [generic] | Answer slot: your real reasons, in your own words. A good shape is to name which JD lines you want more of, perhaps live events, two titles or owning the review, and why. Don't criticise your current studio | Motivation consistency is the Skeptic's standard check. There's no sentence of yours to map, so it's a scaffold |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot, four parts, each in your own words: how the numbers were counted, what they were sensitive to, the assumption behind them you'd defend least, and which part was yours. "I didn't build the numbers, I presented them" is an honest answer if true, and so is "I don't know how they were counted" | F7's sentence invites exactly this probe. EXP because it tests what was actually yours |
| C2 | "What did you do with the retention numbers beyond presenting them?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start from your sentence. Answer slot: the JD's "own the post-event review and the KPIs it reports" makes this probe likely. If you analysed the numbers or recommended changes from them, say how. If your part was presenting, say so plainly and describe how you would own the review here | F4 is where presenting meets owning. JD because it scores that duty |
| C3 | "After an event goes live, which metric do you watch first, and why?" | CASE | [generic] | Pick one and defend it, for example early participation as a leading signal and retention for the window after. Then name the assumption you're least sure of. Say which you'd ask the team to confirm | Tests whether you're comfortable with retention metrics (F7) without asking about your past |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc made of those four sentences, in your own words: four years as an associate producer at a puzzle-game studio; for the last two, running the weekly content-drop calendar for your main title; writing the release checklist your QA team still uses; presenting the monthly retention numbers to the studio head. Close on why this role is the next step (B5's slot). Keep "associate" | The likely opener. It's scored even though it feels casual, and it sets up F2, F5 and F7 |
| D2 | "What mobile games are you playing right now, and what do you think of their live events?" | CO | [generic] | Answer slot: name games you actually play, and say one thing a live event in one of them did well or badly. Don't name a game you haven't played | A casual question on the JD's central topic is still scored |
| D3 | "What do you know about our games?" | CO | [generic] | Answer slot: what you've found out and played before Friday. If you couldn't find out which two titles this role covers, say so and ask him. Don't bluff | Company knowledge. No research ran, so this depends on your own preparation (triage step 4) |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live ops at a mobile studio?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Never led a team" | Pause. Hold on what's true: two years running your main title's weekly content-drop calendar, and a release checklist your QA team still uses. If he pushes on gaps, concede specifically ("I haven't led a team"), then go back to the two facts. Don't argue that you're equivalent to someone more senior | Combines F2, F5 and F3 under time pressure. JD because it's a fit challenge |
| E2 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it, and the QA team still uses it. Answer slot: if others reviewed or added to it, say who did what. If it was yours alone, say so. Keep it short | F5 is your sharpest artifact claim, which makes it the obvious attribution target |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Two days into an event, community says players hate it and design wants to keep it running. What do you do?" | CASE | [generic] | Get facts first: how many players and which signal. Bring design and community together, consider options (tweak, extend, pull, message players), decide who makes the call, and record it for the review | Tests coordination (F3) and the community seam with no claim about your past |
| G2 | "What would you need from engineering on each update, and what would you give them back?" | JD | [generic] | Needs: estimates, early warning on risk, and a build in time for QA. Gives: a stable calendar, clear priorities, a checklist that catches problems early, and fewer surprise requests. Keep it about the role, not your past | A reciprocity question on the JD's coordination line |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a real time: it needs a named stake, the message, how it landed, and an intact relationship afterwards. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral prompt. No values round was detected and Saltmarsh's values weren't read, so this is generic |
| H2 | "Tell me about a time a release went wrong." | VAL | [generic] | Pick a real one: what broke, what you did, and what changed afterwards, perhaps to the checklist. Don't invent a failure to fit. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's release-checklist line makes this a natural prompt. VAL because what it scores is how you behave |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here, and who reads it?" | Shows you're already thinking about the duty you'd own, and tells you what "own the KPIs" really means |
| R2 | "Are the two titles planned on one calendar or two today, and where do they collide?" | Goes straight to the hardest part of the role, and is diligence for you |
| R3 | "Which KPIs does the review report now, and which would you like it to?" | Invites him to describe his priorities, which you can mirror back later in the interview |
| R4 | "How does the producer work with community on each update?" | Community is the one discipline in the JD that's easy to forget, so asking signals you read it closely |
| R5 | "What would make the first 90 days a success, from your side?" | Gives you his actual bar, and reads as confident rather than anxious |
| R6 | "How much of the events calendar involves in-app purchases, and who owns that side?" | Settles whether F9 actually matters for this role, and shows you're aware of the gap without dwelling on it |
| R7 | "What's changed most about how live ops runs here since you took on the role?" | Turns the conversation to his own path. Use it only if the timing feels natural |

---

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events, or a live-events calendar | Inflated form of F1 | F1's quote at its own scope. The material says a weekly content-drop calendar, not live events. B3's slot stays inside the drops |
| Ran calendars for more than one title | Inflated form of F1 | F1's quote: "our main title". B2's slot asks only what part you had |
| Led or managed a team | A negative you stated (F3) | "I haven't led a team." |
| Owned post-event reviews or the KPIs | Inflated form of F4 | F4's quote: you presented the monthly retention numbers. C2's slot asks only which part of preparing them was yours |
| Analysed retention or drove retention improvements | Inflated form of F7 | F7's quote at its own scope. C1's slot asks only how the numbers were counted and which part was yours |
| Managed the release process or QA | Inflated form of F5 | F5's quote: you wrote the checklist your QA team still uses. A5's slot stays inside that |
| "Four years as a producer" | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio." Keep "associate" |
| Experience with in-app purchases or monetisation | A negative you stated (F9) | "I haven't worked on a game with in-app purchases." |

---

## Sources

**Provided:** your message (the JD text, the interviewer's name and title, and your background). No dossier was present.

**Searches sent, all refused:** web search permission was not granted in this session.
- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process producer": refused
- "Saltmarsh Games mobile studio news 2026": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | The values cheat sheet, if a values round exists, and VAL themes. Bank H stays generic |
| 2. Saltmarsh Games interview process | unavailable | Persona weights. They rest on the hiring-manager prior and a generic fallback instead |
| 3. Saltmarsh Games strategy and recent news | unavailable | A grounded CO or CASE question about the two titles. D3 and A1 stay generic |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The interviewer read, signal-based weights, and a reverse question tied to his path. That section is absent and R7 is generic |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied already fixes the fit snapshot and the JD questions |

---

## Upgrade menu

- **Allow web search** → targets 1 to 4 run: published values (and a values cheat sheet if a values round exists), the interview format, recent news for a grounded CO question, and Tobias's public professional background for an interviewer read and a tailored reverse question. A deeper pass is also available on request: up to 6 more searches and 2 more fetches, several more minutes.
- **Whether Tobias is your future manager, and any recruiter note on format** → the persona weights get recomputed. A pre-announced task (a calendar plan or a review write-up) would get its own build section.
- **The names of the two titles** → D3 and A1 move from generic to grounded.
- **Your answers to the slots in B1, B3, C1, C2, A5 and E2, told to me outside a drill** → F1, F3, F4, F5 and F6 can be regraded, and those rows' guidance rebuilt on your own words.
- **The release checklist or a calendar document, if your current studio lets you share one** → F5 and F8 can rise from medium to high, and you'd have a concrete written-communication example.
- **A job-underwriter dossier** → verified evidence and an objection derived from that evidence, instead of one inferred here. Never required.
