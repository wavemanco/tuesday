I'm building your prep pack now. Next I'm checking public sources for Atlas Freight's values, how it runs interviews, and recent news.
I've saved your prep pack as `atlas-freight_operations-manager_interview_pack.md`. You didn't say who you're meeting or which round it is, so it covers the whole interview process with all seven interviewer styles weighted equally. That's broader and less targeted than a pack built for a known round. My web searches on Atlas Freight were blocked by permissions, so nothing in the pack is researched about the company. The questions about why you want to join Atlas stay generic.

**The highest-value prep is question A1:** "Today you're over three supervisors. This role is twelve across four terminals. Why are you ready?" It's the objection your background makes most likely, and the pack rehearses it most deeply.

**Two gaps to prepare honestly:**
- **Power BI:** you've said you've never used it, so the pack coaches you to say that plainly and follow with a concrete plan for learning it.
- **"5+ years operations leadership":** your seven years are in operations, but you didn't say how many were spent leading people. An interviewer may check this literally, so know your number (question A4).

I can play the Skeptic interviewer on A1 with you whenever you're ready. I can also save a `tuesday-dossier.md` file recording the gaps this prep found, for you to bring to later sessions. If you'd like the pack as a Word document, I can convert it.

1. Who are you meeting, and what round is this: a recruiter screen, the hiring manager, a panel or a final round? If the recruiter mentioned focus areas or anything to prepare, like a presentation, include that too. Your answer changes how every set of questions is weighted.
2. Do you want me to look up Atlas Freight online? If you allow web search, I'll run the standard pass (their values, interview process and recent news). I can add a deeper pass if you want one: up to 6 more searches and 2 page fetches, a few more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, regional logistics, 4 terminal sites, team of 12 supervisors
**Company:** Atlas Freight (800 employees, per the posting)
**Interviewer:** unknown, and so is the round. This pack covers the whole loop with flat persona weights, which makes it weaker than a pack built for a known round. The upgrade menu says what would sharpen it.

---

## How to use this pack

Two axes organize everything:

- **Personas** describe how a question will be asked (who's asking, in what style). Each persona gets its own bank, lettered A, B, C, D, E, G, H. The letter F is skipped so bank IDs never clash with fit-snapshot rows F1–F8.
- **Types** describe what's being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour matches the company's *published* values (none in hand for Atlas, so no VAL questions here) |
| EXP | Whether your stated experience survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Homework on the company: strategy, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Every suggested wording in this pack is proposed and pending your approval: say it in your own words, and say only what you actually did. An **answer slot** is an instruction for the interview, not a question for me. It names a likely probe and gives you two honest branches.

---

## Fit snapshot

Your evidence is quoted exactly from your message. Proposed wording in the right-hand column is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Adjacent work, not the requirement itself. Your material describes warehouse and distribution ops and one site's surge plan; it does not mention terminal operations or several sites. Words at their own scope: "I've spent seven years in warehouse and distribution ops. I'm currently a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: "across 4 sites" and "terminal" make two probes likely. If any of your work spanned more than one site, or was in a terminal or cross-dock operation, say which and what part was yours, in your own words. If none was, say so plainly and stay with warehouse and distribution |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Running a surge plan touches on-time delivery but doesn't show it was measured or moved. Don't stretch it. Answer slot: if on-time or another service measure was tracked for your shift or during the surge plan, say what was counted and what happened to it. If none was, or it wasn't yours, say so plainly and say how you'd define on-time here |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material says nothing on cost. Answer slot: if you've owned or been measured on a cost figure (labour hours, overtime, cost per unit), say which, how it was counted and what you did about it. If you haven't, say so plainly and walk through how you'd find the cost levers here (B2) |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Same kind of work at a smaller scale: three supervisors, not twelve. Words: "I'm currently a senior shift manager over three supervisors." Answer slot: if you've had more people reporting to you at any point, or covered another manager's team, say when and how many. If not, say so plainly and stay with the three |
| F5 | "build reporting in Excel/Power BI" (the Excel half) — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" doesn't show whether you've built reporting that others use. Answer slot: if you've built trackers or reports in Excel that your supervisors or manager relied on, say what they tracked and who used them. If not, say so plainly and say what you'd build first (B4) |
| F6 | "build reporting in Excel/Power BI" (the Power BI half) — JD | "never used Power BI" — your message | none | [grounded] | capability | You've stated this gap, and wording can't close it. Words: "I haven't used Power BI." Then how you'd learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap look smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [grounded] | discovery | Seven years in ops isn't seven years leading, and your material doesn't say how many were in a leadership role. A years requirement is often screened literally, so expect it to come up. Answer slot: say how many of your seven years you held a supervisory or management role, in your own words. If it's fewer than five, say so plainly and say what you led in that time |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. The certification answers the "plus" directly, but nothing has been checked behind it, so expect a probe. Lead with it as stated: "I'm green belt certified." Your certificate is the inspectable proof here |

---

## Persona table

Weights are flat, and here is why. The round and interviewer are unknown, and the research that might have shown Atlas Freight's interview process was blocked, so no source establishes the loop. The pack falls back to the generic archetype (screen, then hiring manager, then panel). That is a pattern, not Atlas Freight's documented process. Every persona gets 3–4 questions so none of them is new to you on the day.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the gaps: scale, terminal vs warehouse, Power BI, years of leadership | Equal weight (flat). Holds the highest-ROI question because F1, F4, F6 and F7 give a skeptic four seams | Rehearse A1 until it's boring. Hold only what the quotes carry, name the limit before it's asked for, then give a plan |
| B. Case / Strategist | Live problems: diagnose an on-time drop, cut cost per shipment, a 90-day plan | Equal weight (flat). The JD's headline outcomes (on-time, cost per shipment) are natural case material for a hiring manager | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud |
| C. Data-Driven Prober | Goes line by line: how the 40% was counted, what changed in the pick path | Equal weight (flat). Your one headline figure is a magnet for this persona | Know how the figure was counted, or say plainly you don't. Name the weakest assumption before they do |
| D. Pressure | Time-boxed, devil's advocate: "how much of that was you?" | Equal weight (flat) | Pause, restate the question, anchor in what you stated. Hold through two follow-ups, then concede something specific and real |
| E. Conversational | Friendly openers that are still scored: your journey, "why us", Lean asked casually | Equal weight (flat). Common in screens | A 90-second biography built only from your quotes. Treat casual questions on JD topics as scored |
| G. Values / Behavioral | "Tell me about a time…" stories, STAR format | Equal weight (flat). No values round has been detected and Atlas's values aren't in hand, so these are behavioural stories, not values mapping | Pick real stories. "We" for context, "I" for what you did. If no story comes to mind, say so |
| H. Peer Evaluator | Other site leads: seams between sites, disagreement, credit | Equal weight (flat). Panels often include a peer, but that's a pattern, not a fact about Atlas | Reciprocity: what you'd bring them, not just what you'd need. Propose principles for how the seams work rather than pretending to know their seams |

---

## Question banks

**Highest-ROI prep in this pack: A1.** It's the single most predictable objection to your background. Proposed wording below is pending your approval.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Today you're over three supervisors. This role is twelve supervisors across four terminals. Why are you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | **Highest-ROI rehearsal.** Hold only what the quotes carry: "I'm currently a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Name the limit before they do, as a fact about the role: going from three supervisors to twelve across four sites is a real step. Then a plan, said as a plan and never as a past: how you'd learn four terminals and twelve supervisors in 90 days (B3). Answer slot: "across 4 sites" makes a multi-site probe likely. If any of your work spanned more than one site, say which and what part was yours. If none did, say so plainly and return to the site you run. Follow-up 1, "three is a long way from twelve": don't argue and don't add; return to the three supervisors and the surge plan. Follow-up 2, "what breaks first at twelve?": answer as a plan and name the one thing you'd have to learn fastest | F1 and F4 are where the role's scale presses hardest, so this objection will come in some form. JD because it scores the stated team and site scope |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "solid Excel" | Pick the gap you stated rather than a fake weakness: "I haven't used Power BI." Add what you do have, at its own scope: your Excel is solid. Then the plan, in your own words: how you'd learn it and by when. Don't claim you'll pick it up in a weekend unless you can show how | F6 is the one gap you've stated, so it's the honest answer to this stem, and naming it first takes it off the Skeptic's list. F5 sits beside it |
| A3 | "Your background is warehouse and distribution. Why should that carry over to terminal operations?" | JD | [grounded] "7 years in warehouse and distribution ops" | Words at their own scope: "I've spent seven years in warehouse and distribution ops." Answer slot: if any of it was terminal or cross-dock work, say where and what you did. If none was, say so plainly and stay with warehouse and distribution. Then ask what you'd most want to learn about their terminals, said as a question or a plan. Describe what you did and let them judge whether it carries over; don't claim it does | F1 is a transferability row. This probe tests whether you overstate how closely your work matches theirs. JD because "terminal operations" is the posting's own scope |
| A4 | "The posting asks for five-plus years of operations leadership. How many of your seven years were in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give the number of leadership years and the roles, in your own words. If it's five or more, say so and name the roles. If it's fewer, say so plainly, say what you led in that time, and point to the three supervisors you're currently over. Never round seven years in ops up to seven years of leadership | F7 is a requirement the JD marks as required, and your material doesn't settle it. A skeptic or screener will check it literally |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Say on-time performance at one of the four terminals dropped ten points over a month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: how on-time is measured here, which lanes or customers, when it started. Segment: inbound vs outbound, dock vs pickup and delivery, by shift. Hypotheses: staffing and absence, volume spike, equipment, a carrier or linehaul handoff, process change. Separate containment (this week) from root cause. Close with the metric you'd watch daily and when you'd report back. No claim about your past is needed | A live problem from the JD's "drive on-time performance" (F2's requirement), asked as a decision rather than a record |
| B2 | "Cost per shipment is up across the network. Where do you look first?" | CASE | [generic] | Clarify which costs this role controls before answering. Split the measure: numerator (labour, overtime, equipment, claims and rework) over denominator (shipments). Compare across the four sites to find the outlier, then go to labour productivity and overtime, rework and damage, and volume or density changes. Say what you'd fix first and what you'd hand to whoever owns the rest | The JD's "cost-per-shipment down" (F3's requirement). Your material has no cost evidence, so a strong live structure is the best available answer |
| B3 | "It's your first 90 days with twelve supervisors across four sites. What's your plan?" | CASE | [generic] | Weeks 1–4: visit each site, meet each supervisor one to one, learn how each terminal runs and what the numbers are. Weeks 5–8: one standard daily view of on-time and cost per site, one regular rhythm with the supervisors. Weeks 9–12: pick one improvement with a clear measure. Say it as a plan, not a record. If you refer to your past, use only your quoted words | Covers F1 and F4 as forward plans, which is the honest place to meet a scale gap. A1 points here |
| B4 | "What reporting would you want in front of you every morning for four terminals, and how would you build it?" | CASE | [generic] | Name the handful of measures (on-time, shipments, cost per shipment, labour hours, exceptions) by site and by day. Say where the data would come from, and what you'd build in Excel now while you learn Power BI. Answer slot: if you've built a report like this before, say what it tracked and who used it. If you haven't, say so plainly and walk through how you'd build it | The JD's "build reporting in Excel/Power BI" (F5 and F6). JD content delivered as a CASE |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats your sentence states: the mis-pick rate, cut 40%, by redesigning the pick path. Then the four slots any figure raises, each in your own words. How it was counted: which periods were compared and what counted as a mis-pick. What it's sensitive to. The assumption behind it you'd defend least, named before they ask. Which part was yours. "I don't know exactly how it was counted" is an honest answer; a method you can't repeat under a second question is worse | Your one headline figure gets the defend-the-number question. Probers target quantified claims first |
| C2 | "What did you actually change in the pick path, and how do you know it was the pick path and not something else?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The redesign is yours to describe: say what changed, in your own words, and keep "I" for what you did and "we" for the team. On attribution, answer slot: if something else changed in the same period (staffing, volume, systems), say so and say how you'd separate it out. If you don't know, say that plainly. The weakest assumption is the strongest move here | The same figure's attribution seam, two levels deeper, which is where probers go |
| C3 | "How do you measure on-time performance today, and where does it stand?" | JD | [grounded] | Answer slot: the JD's "drive on-time performance" makes this probe likely. If your shift or site tracks an on-time or service measure, say what's counted and where it stands. If it doesn't, or it isn't yours to track, say so plainly and say how you'd define it here (B1) | F2 is a discovery row. The question assumes you track on-time, and your second branch lets that assumption be false |
| C4 | "Walk me through how you ran the peak-season surge plan." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats your sentence states: the site's surge plan, which you ran, two years running. Tell those in your own words. Answer slot: the JD's "Own daily terminal operations" makes a probe on ownership likely. If any part of the plan was yours to set, say which and how you decided. If it was set for you, say so plainly and describe how you ran it. Answer slot: if on-time or cost was tracked during peak, say what was counted. If not, say so | F1 and F2 both draw on this sentence, and "ran" is the verb a prober will test |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal supervisor who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, then three beats, each one a quote: seven years in warehouse and distribution ops; you ran the site's peak-season surge plan two years running; you're green belt certified. Concede the real point: an internal candidate knows their terminals and you'd have to learn them. Don't claim terminal knowledge. Finish inside the minute | A time-boxed composure test. The concession is part of what's scored. JD because it compares you against the role's scope (F1) |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: the cut, by redesigning the pick path, as you stated it. Answer slot: say exactly which part was yours and who else was involved, in your own words. If others did parts of it, naming them makes you more credible, not less. Hold through two follow-ups by returning to your part, never by enlarging it, and concede anything that wasn't yours specifically | The attribution stem aimed at your headline figure. Tests whether you fold or inflate under pressure |
| D3 | "This role builds reporting in Power BI and you've never used it. Why shouldn't that rule you out?" | JD | [grounded] "never used Power BI"; "solid Excel" | Don't flinch and don't spin: "I haven't used Power BI." Then what you have: your Excel is solid. Then a concrete learning plan with a date, in your own words. Hold through a second push ("we need it now") by restating the plan, and concede honestly that the first weeks would take some ramp-up | F6 is a stated capability gap. A pressure interviewer will press it, and a calm, specific plan is the only good answer |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc, built only from these: seven years in warehouse and distribution ops; senior shift manager over three supervisors; cut the mis-pick rate 40% by redesigning the pick path; ran the site's peak-season surge plan two years running; green belt certified. Close with why this role, now, in your own words | Casual openers are still scored. A rehearsed, accurate arc keeps you from improvising claims |
| E2 | "What drew you to Atlas Freight?" | CO | [generic] | Use only what you've read yourself: the posting, and their own website if you check it before the day. The posting's lines are safe ground: four sites, on-time performance, cost per shipment, building reporting. This pack holds no researched facts about Atlas Freight, so don't repeat anything you can't point to | The homework question. It stays generic because research couldn't run (see Sources) |
| E3 | "Are you doing anything with Lean these days?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: the JD's "Lean/Six Sigma a plus" makes a follow-up likely. If you've applied green-belt methods on the job, name where and what you did, in your own words. If you haven't, say so plainly and say where you'd start applying them here | F8, a JD "plus" asked casually, the way a rapport-builder asks it |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to hold a supervisor accountable for performance." | JD | [generic] | Pick a real instance: it needs a named problem, what you said and did, and what changed afterwards. Use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your experience does have, or how you would handle it | The JD's "lead a team of 12 supervisors" (F4) asked behaviourally. JD-tagged because no published values are in hand to make it VAL |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Pick a time with a real stake, where you said it anyway and the relationship held. Make sure the truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing, or how you would handle it | A standard behavioural stem. A manager of supervisors will be expected to carry bad news upward |
| G3 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | Pick a decision where a customer's need cost a number you were measured on, and say why you made the trade. If no such time comes to mind, say so plainly, then give the nearest thing, or how you'd weigh it in this role | On-time performance and cost per shipment can pull against each other, and this stem tests how you weigh them |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "When a supervisor at another site disagrees with how you want something run, what happens?" | CASE | [generic] | Propose a principle, not a war story: listen first, agree on the measure, test it at one site, decide on the data. Say where you'd hold firm (safety, service) and where you'd let sites differ | Running four sites means running the seams between them. CASE because it asks how you'd handle a situation, not about your past |
| H2 | "How do you handle credit when an improvement spans shifts or teams?" | EXP | [generic] | Pick a real instance where several people contributed, and say how you shared the credit. If no such time comes to mind, say so plainly and describe how you'd handle it. If you use the pick-path story, keep to C2's wording about who did what | A standard peer stem on credit-sharing. It also cross-checks D2 |
| H3 | "What would you need from the other site leads in your first month, and what would you bring them?" | CASE | [generic] | Reciprocity both ways: what you'd ask of them (their numbers, their problem sites, how they want to hear from you) and what you'd offer (one shared view of on-time and cost, help at peak). Offer it as a plan, not a record | Peers are weighing whether the hire adds to their load or lightens it |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites (F1) | A1, A3, B3, C4 |
| Drive on-time performance (F2) | B1, C3, C4 |
| Cost-per-shipment down (F3) | B2 |
| Lead a team of 12 supervisors (F4) | A1, B3, G1 |
| Build reporting in Excel (F5) | B4, A2 |
| Build reporting in Power BI (F6) | A2, D3, B4 |
| 5+ years operations leadership required (F7) | A4 |
| Lean/Six Sigma a plus (F8) | E3 |

---

## Reverse questions

Have at least five ready. Never say "I think you've covered everything." With no interviewer known, these are written for the role, not the person.

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured across the four terminals today, and where does each site stand against target?" | It shows you think in the JD's measure, and the answer tells you where the problems are |
| R2 | "Which drivers of cost per shipment does this role actually control, and which sit with someone else?" | It tests what the mandate really covers before you're held to the number |
| R3 | "How are the twelve supervisors spread across the four sites, and how long have they been in their roles?" | It feeds straight into your 90-day plan (B3) and shows you're already thinking about the team |
| R4 | "What reporting exists today in Excel or Power BI, and who built it?" | It tells you where reporting starts and what Power BI support exists, and it raises your gap on your own terms |
| R5 | "What does success look like at 90 days and at one year?" | It gets their scoring sheet out in the open |
| R6 | "Why is the role open?" | It tells you whether you'd be stepping into growth, a turnaround or a vacancy |
| R7 | "Where does continuous improvement or Lean show up in how the terminals run today?" | It connects your green belt (F8) to their reality without overclaiming |

---

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written. Honest forms are proposed wording, pending your approval.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run terminal operations, or operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says warehouse and distribution ops and "the site's" plan, not terminals or several sites. The slots in A1 and A3 stay inside that |
| Has led a team on the scale of twelve supervisors | Inflated form of F4 | "I'm currently a senior shift manager over three supervisors." The step to twelve is described as a plan (B3), never as a past |
| Has seven years of operations leadership | Inflated form of F7, which widens "7 years in warehouse and distribution ops" | That quote at its own scope. A4's slot asks only how many of those years were in leadership |
| Has built reporting or dashboards in Excel | Inflated form of F5 ("solid Excel") | "Solid Excel", at its own scope. B4's slot asks only what you've built, with a branch for none |
| Has used or built in Power BI | A gap you stated, F6 | "I haven't used Power BI." No slot |
| Designed or built the peak-season surge plan | Inflated form of F1 and F2's quote ("ran the site's peak-season surge plan") | "I ran the site's peak-season surge plan two years running." C4's slot asks only which parts were yours to set |
| The surge plan improved on-time performance or cost | Inflated form of the same quote | The quote at its own scope. The slots ask only what was tracked, with a branch for nothing |
| Ran the pick-path redesign as a Lean or Six Sigma project | Inflated form of F8's neighbour ("cut mis-pick rate 40% by redesigning the pick path") | The quote at its own scope, and "I'm green belt certified" kept as a separate fact. Your material doesn't link the two |

---

## Sources

**Provided documents:** your message, which held the JD text and your background. Every evidence quote above comes from it.

**Searches sent:**

- `"Atlas Freight" regional logistics values mission`: refused (no web-search permission)
- `"Atlas Freight" interview process operations manager`: refused (no web-search permission)
- `"Atlas Freight" terminals news 2026`: refused (no web-search permission)

No fetches were sent. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The one call was refused. Would have supplied official value names to theme behavioural questions, and the cheat sheet if a values round were detected |
| 2. `Atlas Freight interview process operations manager` | unavailable | The one call was refused. Would have named the actual rounds, so persona weights could follow them instead of the generic fallback |
| 3. `Atlas Freight` strategy / recent news | unavailable | The one call was refused. Would have grounded E2 and given at least one CO or CASE question in current company context |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative Operations Manager JD | skipped | You supplied the JD, which fixes the fit snapshot and every JD-tagged question |

Loop: no source establishes it, so the pack uses the generic archetype (screen, then hiring manager, then panel), with flat weights. No values-style round is detected.

---

## Upgrade menu

- Which round this is and who you're meeting → persona weights reweighted, with the top persona getting 4–5 questions and an extra bank where it matters
- The recruiter's prep email or process notes → any pre-declared deliverable (a presentation, a case) gets its own build section, and the loop gets mapped
- The interviewer's name → a section on reading the interviewer, persona weights from their public footprint, and a reverse question tied to their career
- Atlas Freight's About or values page pasted in → official value names for behavioural questions, and grounded company material for E2 and a CO question
- How many hours you have before the interview → a prioritized prep schedule, with everything else marked as insurance
- Your answers to the answer slots, especially how many of your seven years were in leadership, whether on-time or cost was ever tracked on your watch, and what you've built in Excel → rows F2, F3, F5 and F7 regenerated with your own words quoted, and A4, B4, C3 and C4 rebuilt on them
- Your resume → more of your own sentences in the evidence column, and possibly evidence for F1–F3 that your message didn't mention
- Your green belt certificate and any before/after mis-pick data → F8 and the C1 and C2 figures move from claims you've confirmed to evidence someone can check
- A `tuesday-dossier.md` from a job-underwriter pass → your evidence verified ahead of time, the main objection derived from that evidence rather than inferred, and an agreed list of claims to keep out of your answers. Useful, never required
