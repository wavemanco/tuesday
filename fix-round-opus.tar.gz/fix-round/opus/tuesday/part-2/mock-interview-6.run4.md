Reading done — I'm running the default research pass on Larkfield Systems (values, interview loop, recent news) before building your three-round pack.
I've saved your prep pack as `larkfield-systems_engineering-manager_interview_pack.md`. It covers all three rounds together: one shared table matching the role's requirements to your background, then a separate set of questions and reverse questions for Tuesday, Thursday and Monday.

The pack is built only from your message. My web searches for Larkfield's values, interview process and recent news were blocked by this session's permissions. So Monday's round has no values cheat sheet, and the company-strategy questions are general patterns rather than Larkfield facts.

The single most important thing to rehearse is **A1**: the "no hardware in your background" question. You named that gap yourself, so your would-be boss on Tuesday is likely to raise it, and the panel's PM may come back to it on Thursday.

Say the word and I'll play the Director on A1, with real follow-ups, then give you feedback.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can bring it to later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full Larkfield posting and your CV, or should I keep working from what you've told me? Either one adds questions and fills in thin spots in the pack.
Would you allow web search, or paste Larkfield's values page, so I can build Monday's values cheat sheet and base the strategy questions on Larkfield itself?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack — Engineering Manager, Larkfield Systems

**Candidate:** Yusuf · **Mode:** loop, three scheduled rounds

| Round | When | Who | Relationship | Length |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | Hiring manager, your would-be boss | 45 min |
| 2 | The Thursday after | Two staff engineers and a product manager | Panel: technical peers and a cross-functional partner | 60 min |
| 3 | The following Monday | VP Engineering | Skip-level, "values and leadership philosophy" (the recruiter's words) | 30 min |

Interviewer names are not known, so there is no interviewer read. Web research was attempted and refused by this session's permissions, so nothing in this pack about Larkfield comes from Larkfield's own pages (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking, and in what style. **Types** describe *what is being scored*.
- **Type key:**
  - **VAL**: behaviour and values. Does your past behaviour show the values they care about?
  - **EXP**: experience deep-dive. Does what you said survive scrutiny, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, including its gaps?
  - **CO**: company and strategy. Can you think at the company's altitude?
  - **CASE**: live problem. Structure and reasoning on a problem from the role.
- **Provenance:** `[grounded]` means traceable to what you gave me. `[inferred]` means derived, and the derivation is named. `[generic]` means a role-family pattern with no claim about Larkfield.
- **Answer slot:** an instruction for the interview, not a question for me. It names a likely probe and gives two honest branches. Answer whichever one is true.
- The guidance is scaffolding, not a script. Every sentence about your past is built from four things you told me, quoted below. If a cell seems to say more than you did, the cell is wrong, not you.
- The shared fit snapshot comes first, then one mini-pack per round, then the shared prohibited list, sources and upgrade menu.

---

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role text in your message ("JD"). The evidence is your own four sentences, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says you led one team of six, not two squads of eleven, and the words stay at that scope: "For three years I've been team lead of a team of six." Answer slot: "two squads" and "11 engineers" make a probe on running more than one team likely. If you have coordinated work across more than one team, say how, in your own words. If you haven't, say so plainly, stay with the team of six, and describe how you'd run two squads as a plan, not as something you've done |
| F2 | "own delivery ... for 11 engineers" — JD | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | This sentence covers one quarter's priority call and what followed it. It doesn't cover owning delivery across a roadmap. Words: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after." Answer slot: "own delivery" makes a probe on how your team's delivery was planned and tracked likely. If that was yours, say how, in your own words. If it sat with someone else, or there was no such process, say so plainly and come back to the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring) — JD | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | Running the backend hiring loop is next to owning hiring for your own squads, but it is not the same thing. Your material doesn't say who made the hire decisions or set headcount. Words: "I run our hiring loop for backend roles — about 40 interviews last year." The 40 counts interviews, never hires or candidates. Answer slot: if hire or no-hire calls were yours to make, say which ones and how you decided. If they weren't, say so plainly and stay with running the loop |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Being team lead touches growth but doesn't show it. Your material doesn't say whether the six reported to you, or what growth work was yours. Answer slot: "growth for 11 engineers" makes a probe on how you've grown people likely. If growing the engineers on your team was part of your role, say what you did and for whom, in your own words. If it sat with a manager above you, or didn't happen, say so plainly and describe how you'd approach it for eleven people, as a plan |
| F5 | "partner with hardware ... on roadmap" — JD | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap you stated, and wording won't close it. Words: "I've never owned a hardware-adjacent roadmap." Then how you'd learn it, said as a plan and never as a past. The pack's own observation: your sentence is about *owning* a roadmap and the JD says *partner*. Don't shrink the acknowledgment, and don't widen it into a claim about hardware work your material never mentions |
| F6 | "partner with ... product on roadmap" — JD | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | This sentence involves a roadmap, but it doesn't show a partnership with product. Your material doesn't say where the roadmap pressure came from. Answer slot: if product people were part of the reliability-quarter decision, say what part you played in that conversation, in your own words. If they weren't, or the pressure came from somewhere else, say so plainly and stay with what you pushed through |
| F7 | "building device-management services" and "industrial IoT" — JD | none given | none | [grounded] | discovery | Your material doesn't show device-management or IoT work, and it doesn't say there was none either. Answer slot: if you've built or run services that manage devices or anything close to it, say what, in your own words. If you haven't, say so plainly, stay with "9 years engineering … currently at a payments company", and describe how you'd learn the domain, as a plan |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Lead two squads" (F1) | A3, B2, J4 |
| "building device-management services" and "industrial IoT" (F7) | A4, B1, E3, H1, H2, L1 |
| "own delivery" (F2) | B1, B2, H1, L2 |
| hiring (F3) | B3, C2, N3, M1 |
| growth (F4) | B4, J3 |
| "partner with hardware ... on roadmap" (F5) | A1, A2, B1, N4 |
| "partner with ... product on roadmap" (F6) | N2, G2, H1 |

**Highest-ROI prep in the pack: A1**, the hardware-roadmap objection. It rests on the one gap you named yourself (F5) and the role's own partnership line. Your would-be boss is likely to raise it on Tuesday, and the panel's PM may raise it again in collegial form (N4, G2).

---

## Round 1 — Tuesday: Director of Engineering, hiring manager (45 min)

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the step up from team lead to EM, of hardware partnership, and of why you're leaving payments | High. A hiring manager is de-risking gaps, and F1, F5 and F7 are the visible ones | Rehearse A1 until it's boring. Bridge only from your four sentences, say the limit plainly, then give a ramp plan |
| Case / Strategist | Live problems from the role: a hardware slip, two squads under strain, where to put headcount | High. A hiring manager is buying capability and expects problems from their actual roadmap | Clarify, then objective, options, stakeholders, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober | Pulls on the 60% and on the 40 | Medium. Those are the only numbers you gave, so they are magnet targets | Know what you can and can't say about how each figure was counted, and name your weakest assumption first |
| Conversational | The opener, and "what do you want from a manager" | Low, but scored. It's your first meeting with your would-be boss | A 90-second arc built only from your own sentences |

### Bank A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see hardware in your background. How would you handle partnering with our hardware team on the roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | **Highest-ROI rehearsal.** Lead with the limit before they push: "I've never owned a hardware-adjacent roadmap." Then the plan, said as a plan: what you'd learn first (where hardware timelines lock, which software dates depend on them, who decides trade-offs) and how you'd learn it in the first 90 days. Follow-up 1, "So why take the risk?": hold without adding. Name what you've told me at its own scope, team lead of six for three years and the reliability quarter, and let them draw the inference. Follow-up 2, "Have you worked with hardware teams at all?": answer slot. If you have worked alongside hardware teams in any form, say what, in your own words. If not, say so plainly and come back to the plan. Never let the concession grow into "but it's basically the same" | F5 is a gap you stated, against a line in the role, so some form of this question is near-certain. JD because it scores the stated partnership requirement |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pick one real answer and don't dodge with a strength in disguise. The honest pick is the one you've already named: "I've never owned a hardware-adjacent roadmap." Then one sentence on what you'd do about it, as a plan. Leave managing managers out unless they ask: the role text doesn't mention it | Skeptic stem aimed at F5. Rehearsing it stops a nervous candidate from listing three weaknesses. JD because it scores self-assessment against the listed role |
| A3 | "This is two squads and eleven engineers. You've been team lead of six. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Accept the premise as stated: "For three years I've been team lead of a team of six." Then what you expect to change, as a plan: less hands-on work, more structure through the people who lead each squad, how you'd split your time. Answer slot: if you've coordinated work across more than one team, say how. If not, say so plainly and stay with the team of six | F1's scale gap is the most visible step in this move. JD because it scores the headline responsibility |
| A4 | "Why leave payments for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Three short beats. Why leave: without criticising your current employer. Why here: name what in the role draws you, using the role's own words ("device-management services", "partner with hardware and product"). Why now: your reasons. Answer slot: the reasons are yours, so say them in your own words. This pack can't supply your motivation, and nothing here should sound borrowed. If the domain is new to you, say so plainly rather than implying a background in it | Motivation consistency is a Skeptic staple, and F7 is silent on the domain. JD because it tests fit with the role as described |

### Bank B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose a hardware revision slips six weeks and one squad's release depends on it. What do you do this week?" | CASE | [generic] | Clarify first: what exactly is blocked, and what can be decoupled. Then the objective (protect the commitment or reset it honestly), the options (re-sequence work, ship the parts that don't depend on hardware, stub against a spec), who you talk to and in what order (hardware lead, PM, your boss), and what you'd write down. No claim about your past is needed, so make none | A live problem from F5's partnership line and F2's delivery line, asked as a decision. `[generic]` because it's a pattern for the problem, not a fact about Larkfield |
| B2 | "You inherit two squads. One is buried in operational load and the other is behind on roadmap. What are your first 90 days?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure: listen and measure before acting, then decide, then communicate. You can cite your own case, but only in its own words: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after." Don't add how you persuaded anyone, or who agreed. Then say how you'd treat this situation differently, since here there are two squads with opposite problems | F1 and F2 combined into a problem the hiring manager can see you reason through. CASE delivery, with JD content (leading two squads, owning delivery) |
| B3 | "You have headcount for three hires across the two squads. How do you decide where they go, and how do you run the process?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Placement first: where the constraint is, what each squad needs in a year, not just today. Process second: here you can say "I run our hiring loop for backend roles — about 40 interviews last year." Answer slot: if you've set what a role needed, or made the final call, say so in your own words. If not, say so plainly and describe how you'd do it | F3 is your strongest adjacent evidence, and this question lets you use it without claiming more. JD content (hiring), CASE delivery |
| B4 | "One of your engineers wants a path to staff. How do you grow them?" | CASE | [generic] | Structure: what staff means at this company (ask, don't assume), the gap between where they are and that bar, the stretch work that closes it, how you'd give feedback, and who else needs to see the work. The question needs no claim about your past, so make none. If they ask whether you've done it before, F4's answer slot applies | F4 is the thinnest evidence row, so a forward-looking answer protects you. CASE because it's set in the role |

### Bank C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "That 60% drop in on-call burden. How was it counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot, in your own words: how the figure was measured, what it is sensitive to (the period compared, anything else that changed at the same time), the assumption behind it you'd defend least, and which part was yours. Say the weakest assumption before they find it. "I don't know exactly how it was counted" is an honest branch. If that's true, say it and say what you do know. Keep the wording: it "dropped 60% after", not "I cut it by 60%" | The headline metric. Defend-the-number coverage. EXP because it tests what was actually measured and actually yours |
| C2 | "About 40 interviews last year. What did running the loop actually involve?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Be exact about the 40. Your sentence could mean interviews you ran or interviews the loop ran, so say which. Answer slot: say what running the loop meant, in your own words, and which parts were yours to decide. If some parts sat with others, or didn't exist, say so plainly | F3's figure is the second magnet target, and its unclear scope is where a prober will push. EXP for attribution |

### Bank D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" and "I run our hiring loop for backend roles — about 40 interviews last year" | A 90-second arc that uses only these beats: nine years in engineering, three of them as team lead of six, now at a payments company, and you run the backend hiring loop. End on why this role, one sentence. Answer slot: fill the middle with what actually happened, in your own words. Don't let the arc imply scope the beats don't carry | The opener sets the frame for the whole 45 minutes. EXP because a hiring manager listens for attribution even when it's casual |
| D2 | "What do you want from me as a manager?" | VAL | [generic] | This is about you, not your past: say how you like to work with a boss (cadence, what you want to hear early, how you like disagreement raised). Keep it short and specific, then turn it into a question back to them (see reverse question 5) | Working-relationship fit with your direct boss is scored even in a casual register. VAL because it's about how you operate |

### Reverse questions — Round 1

| Question | Why it lands |
|---|---|
| "What would make the first six months a clear success, in your eyes?" | Gets the real scorecard from the person who will hold it |
| "How are the two squads set up today? Does each have a lead?" | Tests the F1 step up without assuming a structure, and tells you what support you'd have |
| "How do roadmap decisions get made between hardware, product and engineering here?" | Shows you've taken the partnership line seriously, and gets you the real process before the panel |
| "What's the biggest delivery risk the squads carry right now?" | Turns the interview toward the job, and gives you material for Thursday |
| "How do you like to work with your EMs: cadence, and what you want to hear early?" | Pairs with D2 and shows you're already thinking about the working relationship |
| "Is this a new role or a backfill, and what should the next person do differently?" | Reveals the history you'd inherit without asking for gossip |

---

## Round 2 — The Thursday after: panel of two staff engineers and a PM (60 min)

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Where the EM's calls end and the staff engineers' begin, what you'd need from them, how product and engineering settle trade-offs | High. All three are pricing what you'd add to or take from their own work | Reciprocity: say what you'd bring, not just what you need. Propose principles for the seam rather than pretending to know it |
| Data-Driven Prober | Staff engineers going two levels deep on the reliability quarter | High. Your one technical-leadership story will be read closely by engineers | Know what was broken and how it was found, in your own words. Name the weakest assumption first |
| Values / Behavioral | The PM asking for stories: pushing back, saying no to product | Medium. A cross-functional interviewer usually scores behaviour | Map to your quoted sentence where it carries the story; otherwise pick a story using the criteria given, with an honest branch |
| Case / Strategist | Feature versus reliability trade-offs, and a field incident | Medium. A natural shared problem for the PM and the engineers | Clarify, then structure, then decide. Bring all three perspectives into the answer |
| Pressure | Devil's advocate on the 60% | Low here. More likely on Monday | Hold then concede, as in K2 |

### Bank E — Data-Driven Prober (staff engineers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "On that reliability quarter: what was actually broken, and how did you know?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: say what the problems were and how they were identified, in your own words. If you diagnosed them, say how. If someone else did, say who, and what part was yours: you pushed the quarter through, which is what your sentence says. Engineers will ask for the technical detail, so have it ready or say plainly where your knowledge stops | F2's story is the main technical-leadership evidence, and staff engineers will test its depth. EXP for attribution |
| E2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The weakest-assumption move, in your own words: name it before they do. If you don't know how the figure was counted, say so plainly. That beats a confident method you can't defend under a second question. Keep "dropped 60% after" | Defend-the-number coverage from a different angle than C1, because a second interviewer won't have heard your Tuesday answer. EXP |
| E3 | "How hands-on do you expect to be with the device-management services?" | CASE | [generic] | Your intent, honestly: what you'd stay close to (architecture reviews, incidents), what you'd hand to the squads, and how you'd learn the domain fast, as a plan (F7). Don't claim device-management depth. Ask what they'd want from you | Engineers want to know whether you'll help or get in their way. CASE because it's about how you'd run the role |

### Bank N — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| N1 | "Where do you draw the line between an EM's call and a staff engineer's?" | CASE | [generic] | Propose a principle, not a turf map: technical direction with the staff engineers, people and delivery trade-offs with you, and disagreements surfaced early and decided in the open. Then ask how it works here today. No claim about your past needed | The core seam for this panel. CASE because it's about running the role, and Peer because it splits the seam |
| N2 | "When product wants a feature and engineering wants a reliability quarter, how do we settle it?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Lead with a principle (make the cost of the operational load visible, then decide together). Then your case in its own words: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after." Answer slot: if product people were part of that decision, say what part you played. If not, say so plainly. Don't describe a negotiation your sentence doesn't contain | F6's thin product evidence meets F2's strongest story, asked collegially by the PM. CASE delivery, with JD content (the product partnership) |
| N3 | "What would you need from us in your first month, and what would you bring us?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Reciprocity first: what you'd bring. You can offer the hiring loop in its own words: "I run our hiring loop for backend roles — about 40 interviews last year." Then what you'd need from them: context on the services, the hardware seam, the worst on-call pain. Short and concrete | Peers are pricing your effect on their workload. JD because hiring is a listed responsibility, and F3 is your strongest contribution |
| N4 | "How do you handle credit when work spans teams, say a fix that needed hardware as well?" | VAL | [generic] | Your approach: name the contributors explicitly, in public, and keep the "we" for context and the "I" for your own part. Answer slot: if you have a story about credit across teams, tell it in your own words. If none comes to mind, say so plainly and describe how you'd handle it. Don't imply hardware collaboration (F5) | Peer stem about credit, pointed at the hardware seam. VAL because it scores how you behave with partners |

### Bank G — Values / Behavioral (PM)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2, using only the beats the sentence states: the reliability quarter, which you pushed through, against roadmap pressure, and the on-call burden dropped 60% after. Answer slot: the question asks whether the truth went to leadership. If it did, say who heard it and what you said, in your own words. If the pressure came from elsewhere, say so plainly and tell it as the story it was. Don't add a confrontation, a meeting or a reaction you didn't describe | A Values stem, and your one quoted story under pressure. VAL because it scores behaviour |
| G2 | "Tell me about a time you said no to a product request." | VAL | [generic] | Pick a story that has a named request, your reason, what you offered instead, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the reliability quarter, in its own words) or how you would handle it | The role's product-partnership line (F6) from the PM's side. A selection scaffold because no sentence of yours carries a "no" to product |

### Bank H — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Suppose we have one quarter: a customer-requested fleet feature, or paying down reliability debt in device updates. Walk us through the call." | CASE | [generic] | Clarify: what the customer is committed to, what the reliability debt costs per week, and who carries it. Options include splitting the quarter. Decide, say what would change your mind, and say how you'd explain it to both sides. Invite the PM's and the engineers' views out loud | Product and engineering seam as a live problem (F2, F6, F7). `[generic]` because the scenario is a pattern, not Larkfield's backlog |
| H2 | "Devices in the field start failing on a Saturday. Walk us through the first hour and the following week." | CASE | [generic] | First hour: triage, who is paged, communication, containment. The week after: a blameless review, fixes, and what you'd change in the process. If you bring on-call from your own work, keep to F2's words. Ask about hardware-side escalation rather than assuming it | Tests operational leadership in the device domain (F7) without assuming you know it. CASE |

### Reverse questions — Round 2

| Question | Why it lands |
|---|---|
| "What could a new EM do in their first month that would genuinely help your work?" | The reciprocity question. It turns evaluators into collaborators |
| "Where does the seam between the squads and the hardware team cause the most friction today?" | Shows you're walking toward the F5 gap rather than away from it, and gives you real material |
| (To the PM) "How do product and engineering decide what goes into a quarter today?" | Gets the real process behind "partner with product on roadmap" |
| "What's the on-call picture for the device-management services right now?" | Signals where you'd look first, without claiming domain knowledge |
| "What does a great EM and staff engineer partnership look like from your side?" | Lets them define the seam you'd be working across |

---

## Round 3 — The following Monday: VP Engineering, "values and leadership philosophy" (30 min)

Larkfield's published values aren't in hand (the search was refused), so this round has no values cheat sheet. Bank J is themed on the recruiter's own description of the round, not on named values.

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Leadership philosophy, held positions, people decisions | High. The recruiter named the round "values and leadership philosophy" | Short principles, each attached to one of your quoted facts. "We" for context, "I" for your own part |
| Pressure | Time-boxed "why you", and "how much was actually you" | Medium. Skip-level prior: composure under brevity in 30 minutes | Pause, restate, anchor in what you stated, hold through two follow-ups, then concede what's real |
| Case / Strategist | Where engineering leverage is, and which metric to report | Medium. A skip-level tests altitude | Clarify first. Don't assert facts about Larkfield. Ask |
| Conversational | Reflections on hiring, and changing your mind | Low, but scored | Keep it brief and true |

### Bank J — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy, in a couple of minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" and "I run our hiring loop for backend roles — about 40 interviews last year" | Two or three principles, in your own words. The principles are yours to name, so this pack doesn't name them for you. Attach one fact to each, at its own scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after"; "I run our hiring loop for backend roles — about 40 interviews last year." Describe what you did and let the VP draw the inference. Don't say what it proves | The recruiter's own description of the round makes this near-certain. VAL |
| J2 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2, using only its stated beats: you pushed the reliability quarter through, against roadmap pressure, and on-call dropped 60% after. Answer slot: if the pressure came from someone senior, say who in role terms and what you said, in your own words. If it didn't, say so plainly and tell it as it was. End with the relationship afterwards only if you know how it was | Skip-levels test spine. F2 is the one quoted story with pressure in it. VAL |
| J3 | "Tell me about a hard people decision you made as a lead." | VAL | [generic] | Pick a story with a named stake, a decision that was yours, how you communicated it, and what you'd do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your material doesn't show people decisions (F4), so don't build one from the shape of a good story | "Leadership philosophy" raises people decisions, and F4 is thin, so rehearse the honest branch. VAL |
| J4 | "Have you managed managers? How do you think about that step?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Plain acknowledgment first: "I've never managed managers." Then your thinking about the step, as a plan: what changes when you lead through leads, and what you'd want to learn. The role text doesn't say this role includes managers, so don't assume it does. If it comes up, ask | A VP often probes the growth path. You stated this negative, so it's ready to be said cleanly. VAL because it's about leadership self-awareness |

### Bank K — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" and "I run our hiring loop for backend roles — about 40 interviews last year" and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, then three facts at their own scope: team lead of six for three years, you run the backend hiring loop (about 40 interviews last year), and the reliability quarter you pushed through. One sentence of honest contrast: an internal candidate knows the domain and the hardware, and you'd say so and say how you'd close that gap. Stop at sixty seconds | A Pressure stem. It tests composure and economy across F1, F3 and F2. JD because it compares you against the role |
| K2 | "That on-call result. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold, then concede. Hold: "I pushed the reliability quarter through." That's your sentence. Follow-up 1: keep holding, and say the burden was "my team's" and dropped 60% "after". Follow-up 2: concede specifically. Answer slot: which part of the work was the team's, in your own words. If you don't know how much of the drop the quarter caused, say so plainly. Never fold on the part you did state | A Pressure stem, aimed at the one metric. EXP for attribution |

### Bank L — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Where do you think engineering leverage is in an industrial IoT company our size?" | CO | [generic] | Clarify before answering. You don't have Larkfield's strategy, so don't invent it. Offer a hypothesis framed as one, about how the cost of shipping and operating device software scales across a fleet, then ask what they see. Use the role's own words ("device-management services") | The skip-level altitude test. `[generic]` because research didn't run, and an honest "here's my hypothesis, what's true here?" beats a confident fabrication. CO |
| L2 | "If you could report one engineering metric to me for your two squads, which would it be and why?" | CASE | [generic] | Pick one, say what it misses, and pair it with a guardrail metric. Don't name Larkfield's current metrics. If you mention on-call, keep to F2's words | Tests judgement about what matters (F2). CASE |

### Bank M — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "You run a lot of interviews. What have you learned from it?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Answer slot: one or two lessons, in your own words, each tied to something that happened in the loop. If you can't point to an instance, say the lesson as a belief, not as a finding. Keep the 40 attached to interviews | F3 framed casually, but it's scored for reflection. EXP |
| M2 | "What's something you've changed your mind about as a lead?" | VAL | [generic] | Pick something specific: what you used to think, what changed it, and what you do now. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A "leadership philosophy" probe in a casual register. VAL |

### Reverse questions — Round 3

| Question | Why it lands |
|---|---|
| "What leadership behaviour do you most want to see more of in your EMs?" | Gets the values scorecard in the VP's own words, since you don't have the published ones |
| "How do you know an EM is doing well at six and twelve months?" | Shows you think in outcomes, and tells you how you'd be judged |
| "Where do you feel the tension between hardware pace and software pace most?" | Engages the F5 seam at the VP's altitude without claiming hardware experience |
| "Which value here do you see lived most clearly, and which is hardest to live?" | Invites candour, and fills the values gap honestly |
| "What have you changed your mind about in how you lead?" | Reciprocates M2 and makes it a conversation |

---

## Prohibited claims (shared)

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated (F5's evidence sentence) | "I've never managed managers." No slot |
| Has owned or led a hardware-adjacent roadmap | A negative you stated, F5 | "I've never owned a hardware-adjacent roadmap." No slot |
| Led two squads, or eleven engineers | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says team lead of six |
| Line-managed the six | Inflated form of F1 and F4 | F1's quote at its own scope. The pack's observation: your material says "team lead" and doesn't say whether the six reported to you |
| Cut on-call by 60% single-handedly | Inflated form of F2 | F2's quote at its own scope: "dropped 60% after I pushed a reliability quarter through". K2's slot asks only which part was the team's |
| Owned delivery across the roadmap | Inflated form of F2 | F2's quote at its own scope. The pack's observation: it describes one quarter's priority call |
| Negotiated the roadmap with product | Inflated form of F2 and F6 | F2's quote at its own scope. N2's and G1's slots ask only what part you played, if product was involved |
| Owned hiring decisions for backend roles | Inflated form of F3 | F3's quote at its own scope: "I run our hiring loop for backend roles". The slot asks which calls, if any, were yours |
| 40 hires, or 40 candidates | Inflated form of F3: the number moved to a different noun | "about 40 interviews last year", and the 40 stays attached to interviews |

Device-management or IoT experience isn't listed: your material is silent on it (F7). That's an answer slot, not something this pack refused.

---

## Sources

- **Provided:** your message, which gave the role text, the three-round schedule with interviewer roles, the recruiter's description of round 3, and your background (four sentences, quoted in the fit snapshot).
- **Searches sent:**
  - `Larkfield Systems values`: refused (WebSearch permission not granted in this session)
  - `Larkfield Systems interview process engineering manager`: refused
  - `Larkfield Systems industrial IoT news`: refused
- **Fetches:** none.
- **Dossier:** none present. The pack is built from your message alone.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Refused. It would have supplied the official value names for a Monday values cheat sheet and themed bank J on them |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Refused. Your message already sets the three rounds, so it would only have added any documented case or panel formats to the persona weights |
| 3. `Larkfield Systems` strategy / recent news | unavailable | Refused. It would have grounded L1 and H1 in Larkfield's current priorities instead of `[generic]` patterns |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names given, so there was no query to form. There's no interviewer read, and the reverse questions are role-generic |
| 5. representative Engineering Manager JD | skipped | The role text you supplied fixes the fit snapshot rows and the JD-tagged questions |

---

## Upgrade menu

- **Full Larkfield posting text** → every listed requirement, not just the one-line summary, gets a fit-snapshot row and a JD question; mid-list items stop being free misses
- **Your CV** → evidence cells quote CV lines as well as your message; F4, F6 and F7 may move off `discovery`
- **Web search allowed, or Larkfield's values page pasted** → a values cheat sheet for Monday with the official value names, bank J mapped to them, and targets 1 to 3 rerun
- **Interviewer names (Director, the staff engineers, PM, VP)** → an interviewer read for each round, persona weights from their public footprint, and at least one reverse question tied to each person's path
- **The recruiter's notes on each round** → coverage of any pre-declared deliverable (a system-design exercise, a presentation), and the panel's real format
- **Telling me, outside a drill, your answers to the slots: how the 60% was counted, what running the loop involved, any growth work, any product or hardware collaboration** → F2, F3, F4, F6 and F7 regraded, and C1, C2, E1, E2, N2, G1 and K2 story-mapped instead of slotted
- **Deeper research (L2): up to 6 more searches and 2 more fetches, several more minutes, once search is allowed** → a strategy brief behind the CO and CASE questions, and recent org context for the VP round
- **Prep time per round** → a prioritised schedule for each round, tied to question IDs
- **A `tuesday-dossier.md` from underwriting this role** → an evidence-derived highest-ROI objection and a prohibited-claims list confirmed with you, instead of built here
