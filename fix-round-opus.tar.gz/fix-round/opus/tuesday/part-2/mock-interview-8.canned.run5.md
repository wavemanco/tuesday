I've saved your prep pack and I'm making one last wording fix before handing it over.
Dara, I've saved your prep pack as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. It's organised by round, following the recruiter's email: one fit table shared by all three rounds, then a section each for Round 1 (recruiter), Round 2 (your would-be manager) and Round 3 (the panel). Round 3 includes a 20-minute plan for the case and a cheat sheet for the four values. I used only what you pasted and ran no web searches, because your material already covered everything a search would have found. You didn't send a CV, so the pack is built from the background in your message.

- **Practise this first:** question C1 in Round 2, where your manager says "your complaints experience is one branch's log; this role owns the process across every branch and the contact centre." The pack scripts how to hold your ground and when to admit the limit.
- **Three gaps you've told me about**, each with an honest answer to say out loud:
  - "I haven't worked in a contact centre."
  - "I haven't presented above regional level."
  - Training new tellers isn't the same as coaching supervisors.
- **Things only you know.** Where your message doesn't say, the pack gives you two honest options instead of making something up:
  - what your spreadsheet actually tracks
  - which complaint rules your log ran under
  - any work you've done with digital teams

I can play your manager on C1, follow-ups included, if you'd like to rehearse it.
I can also save a tuesday-dossier.md recording the gaps this prep turned up, so you can carry them into later sessions.
If you'd like the pack as a Word document, I can convert it.

Could you paste your CV? Its lines would replace several of the "fill this in yourself" points with your own wording. If you'd rather not, the pack works as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview prep

**Candidate:** Dara · **Loop date:** 21 November 2026 · **Pack built:** 12 November 2026

| Round | Who | Length | What the recruiter said it holds |
|---|---|---|---|
| 1 | The recruiter | 30 min | A conversation with the recruiter |
| 2 | Head of Member Services, who would be your manager | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | "a 20-minute case on a complaint escalation". "The panel is also the values round — they score against the four values." |

No interviewers have been named yet, so this pack has no interviewer read. It was built from the background in your message because no CV was supplied.

---

## How to use this pack

- **Personas** describe how a question is asked: who is asking and in what style. **Types** describe what is being scored.
- **Type key:**
  - VAL: does what you have done show Ashgrove's four published values?
  - EXP: does your experience hold up when someone asks what was actually yours?
  - JD: can you do the jobs and meet the requirements the posting lists?
  - CO: do you know Ashgrove's strategy and pressures, and can you think at its level?
  - CASE: a live problem from the role, solved out loud.
- **Provenance labels:**
  - `[grounded]` means the row traces to something you or Ashgrove supplied.
  - `[inferred]` means it is a reasonable step from something supplied, and the step is named.
  - `[generic]` means it is a pattern for roles like this one and says nothing specific about Ashgrove or you.
- **Answer slots** are the places where the pack does not know a fact about your past, so it does not supply one. Fill each slot in the interview from what really happened. Every slot has an honest second branch: "that wasn't a thing" or "that wasn't mine" is a complete answer.
- Guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage: 9 days to 21 November

1. **First, C1.** This is the "one branch's log, now the whole process" objection. Rehearse it until it bores you, follow-ups included. It is the highest-return prep in the pack.
2. **The 20-minute case** (Round 3 build section). Run the structure twice against a timer, using made-up complaints.
3. **One story per value**, H1–H4 and the values cheat sheet. The panel scores you against all four, so a missing value costs marks.
4. **Fill the answer slots in F3, F4, F6 and F8 privately, from memory.** Decide now what is true, so you aren't deciding it live.
5. **The three plain acknowledgments** (F2, F9 and the prohibited list). Say each out loud once, calmly.
6. **A 90-second biography** (A1) and your reverse questions for each round.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material shows one branch's log, not a process across branches, and your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe likely on what handling the log involved. If some steps of a complaint's path were yours to decide, say which ones and how you decided, in your own words. If handling it meant keeping the record while others decided, or there were no such steps, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You have stated this gap, and no wording can close it. Your words: "I haven't worked in a contact centre." Then say how you would learn that side, as a plan and never as something in your past. Do not claim contact-centre work, and add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The spreadsheet is monthly and about complaints, but your material does not say what it counts. Answer slot: if it tracks volumes, resolution times or both, say which, and how a month's figures got into it, in your own words. If it tracks other things, say what it tracks and stay there. Never describe a measure it does not hold |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says spreadsheet but not which tool. Answer slot: if you built it in Excel, say so, and describe what you did in it in your own words. If you used another tool, name it plainly |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your words: "I trained new tellers on our escalation script," and you were a branch supervisor for the last three years. Your material describes training tellers on a script, which is not coaching supervisors. Let the interviewer connect the two. Answer slot: the JD's coaching line makes a probe likely on how you trained. Describe how in your own words. If there was nothing beyond walking new tellers through the script, say so plainly and stay with that |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show any digital or self-service work. Answer slot: if you have worked with a digital team, or on a self-service change your branch went through, say what it was and which part was yours. If you haven't, say so plainly, then say how you would start working with a digital team, as a plan |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Expect a probe because nothing sits behind the line yet. Lead in the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | "Formal" does not say which rules governed the log. Answer slot: the JD's regulated-complaints line makes a probe likely on the rules your log ran under. If you know them, name them and what they asked of you in practice, in your own words. If you don't know, or that was handled above the branch, say so plainly and stay with the log. Never name a regulation you did not work under |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated this gap. Your words: "I haven't presented above regional level." Then give a plan for building that skill, said as a plan. Your 45-minute and 60-minute rounds will be watched as presentations in their own right, which is the pack's reading of the loop and not a claim about you |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches | C1, B2, E3, the Round 3 case |
| The contact-centre side of that process | B1, C1 follow-ups, L2 |
| Report monthly on complaint volumes and resolution times | G1, E1, K2 |
| Coach branch supervisors on escalations | D4, J1, K1, K3, the Round 3 case |
| Work with digital teams on self-service journeys | E2 |
| 4+ years in financial-services customer operations | A3 |
| Experience handling regulated complaints | B3, G2 |
| Confident presenting to senior leaders | C3, C2 |
| Comfortable with Excel reporting | A4, G1 |

---

## Grounding brief: what Ashgrove has said about itself

This section draws on the 2026 strategy brief as you summarised it, plus the JD and the values text. It holds no figures beyond those.

| Fact | Why it matters in this loop | Provenance |
|---|---|---|
| Member-owned, about 900 staff | Use "members", never "customers", because the JD and every value use "member" | [grounded] JD |
| "move 40% of member service to digital channels by 2028" | The JD's "self-service journeys" line connects to this, so a digital question (E2) is likely from your future manager | [grounded] strategy brief, your summary |
| "consolidate eight branches into five hubs over 2027" | Your panel is two branch managers, so consolidation sits right next to "Neighbours, Not Numbers" (L1). Don't assume how they feel about it. Ask, or stay neutral | [grounded] strategy brief, your summary |
| "launch a small-business lending product in Q1 2027" | A new product means new kinds of complaints for whoever owns the process. It makes a good reverse question in Round 2 | [grounded] strategy brief, your summary |
| "the main competitive pressure is app-only banks" | How complaints are handled is one place a member-owned lender can differ from an app. It works as a framing line in A2 and E2, as a thought and not as a fact about either | [inferred] from the brief's competitive line |

---

# Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers: your journey, why Ashgrove, logistics | High. A recruiter screen's usual lead persona `[generic]`, and the recruiter runs this round `[grounded]` | Use a pre-built 90-second arc (A1). Treat casual questions about JD topics as scored |
| Skeptic, light | Quick checks on what's missing: contact centre, regulated complaints, step up in level | Medium. Recruiters screen against the JD's listed requirements `[generic]` | Give short honest answers that point to Rounds 2 and 3 for depth. Never bluff a knockout item |

### Question bank

**Conversational / Rapport**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with four beats, each one a thing you have said: six years in retail banking with the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. End with why you want this role now, in your own words. Stop when you finish and don't fill the silence | It opens almost every screen, and F7, F1, F5 and F3 all draw on it. EXP because it sets the claims every later round will test |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Use Ashgrove's own words: member-owned, and "we decide from the member's side of the counter." Give your reason in your own words. One optional thought: the strategy brief names app-only banks as the main pressure, and how complaints are handled is one place a member-owned lender can be different. Offer it as a thought, not a claim. Don't claim credit-union experience your material does not show | The question needs no claim about your past. CO because it scores your homework on the values and strategy you were given |
| A3 | "The role asks for four-plus years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Answer in the quote's own terms: six years in retail banking, the last three as a branch supervisor. Stop there and let the recruiter ask for more | F7 meets the requirement. It is a likely knockout tick-box, so keep it short |
| A4 | "How comfortable are you in Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it is in Excel, say so, and say what you did in it in your own words. If it is another tool, name it plainly. Don't list Excel features you haven't used | F4 is a discovery row. A casual question like this is still scored against the JD's Excel line |
| A5 | "What notice do you need, and what are you looking for on salary?" | JD | [generic] | Have your notice period and salary range ready before the call, as facts you have checked. If you're not ready to name a figure, ask the recruiter for the role's band | Recruiter screens routinely include logistics and knockout checks. `[generic]` because nothing here comes from Ashgrove's material |

**Skeptic, light**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" | Plain and calm: "I haven't worked in a contact centre." Then one sentence of plan, such as what you would do in your first weeks to learn it. Don't add anything to shrink the gap, and don't apologise | F2 is a gap you stated. If you answer it cleanly here, it is a non-event by Round 2 |
| B2 | "This would be a step up from branch supervisor. Why now?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" | Short version of C1: three years as a branch supervisor, and the branch's formal complaints log was yours to handle. Give your reason for wanting the wider remit in your own words. Save the depth for Round 2 | F1's scope gap, previewed. The recruiter may pass your answer on to the hiring manager |
| B3 | "Have you handled regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | "I handled the branch's formal complaints log." Answer slot: if you know which rules that log ran under, name them briefly. If you don't, say so plainly and stay with the log | F8 is a discovery row, and this is a likely tick-box question. Answer briefly, because G2 is where it gets probed properly |

### Reverse questions

| Question | Why it lands |
|---|---|
| "Will the case be given on the day, or is anything shared in advance, and will it include Ashgrove's complaint-handling rules?" | It sharpens your Round 3 build, and asking reads as preparation |
| "Will I know the panel's names before the day?" | The recruiter's email says names haven't been assigned yet. Names would let you prepare for each person |
| "Is the role based at a particular site, given the plan to consolidate into five hubs?" | Location is a real unknown for you, and the question shows you've read the brief |
| "How is the role's time split between branches and the contact centre?" | It tells you how much of F2's gap is day-one work |
| "Does anyone report into this role, or is it a solo role working across teams?" | Neither the JD nor the email says, and it changes what "own end to end" means |
| "What happens after 21 November, and when would I hear?" | Basic, but it is the recruiter's lane, and it saves you a follow-up email |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scope step-up, the contact centre and senior presenting | High. A hiring manager is reducing their risk on gaps `[generic]`, and F1, F2 and F9 are the gaps | Rehearse C1 until it's boring. Bridge only from your stated quotes. Where a gap is real, say it plainly and give a plan |
| Values / Behavioral | "Tell me about a time…" stories | High. The recruiter called this round "mostly behavioural" `[grounded]` | Have one story per theme, with "we" for context and "I" for your part. Where you have no story, say so rather than make one up |
| Case / Strategist | Problems from the manager's own roadmap: digital shift, monthly reporting | Medium. Usually high for a hiring manager `[generic]`, but lowered by "mostly behavioural" `[grounded]` | Clarify, then set the objective, then structure the problem, then name a metric and a risk. Use Ashgrove's words |
| Data-Driven Prober | Digs into the spreadsheet and the log | Low-medium. A manager hiring someone for monthly reporting will test the one reporting artefact you have mentioned `[inferred]` from F3 | Know exactly what the spreadsheet holds and what it doesn't. Say "I don't know" where you don't |

### Question bank

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your complaints experience is one branch's log. This role owns the process across every branch and the contact centre. What makes you ready for that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre" "I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** *Hold, about 40 seconds:* three years as a branch supervisor; you handled the branch's formal complaints log, trained new tellers on the escalation script, and built the monthly complaints spreadsheet your regional manager uses. *Name the limit before they do:* "That's one branch, and I haven't worked in a contact centre." *Answer slot:* if any steps of a complaint's path were yours to decide, say which. If the log was a record others decided on, say so plainly and stay with it. *Plan, said as a plan:* what you would do first to see how complaints move between branches and the contact centre. *Follow-up 1, "But across every branch?":* go back to the log you handled, at its own scope ("what I handled was the branch's log"), and repeat the plan. Add nothing. *Follow-up 2, "And senior leaders?":* "I've never presented to anyone above regional level." Then your plan. Don't fold on the core: what you did is real. Describe it and let the interviewer draw the link to the role | F1, F2 and F9 together are the most predictable objection to this candidate, and your future manager owns that risk. JD because it scores the role's headline line. It gets the deepest rehearsal because it will arrive in some form |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level." "Never worked in a contact centre" | Pick one real gap and own it. For example: "I've never presented to anyone above regional level." Then give the plan in one or two sentences. Don't offer a disguised strength, and don't list both gaps unless asked | Skeptic stem. F9 and F2 are gaps you stated, so a candid answer here costs nothing and buys trust |
| C3 | "This role reports monthly to senior leaders. Tell me about presenting." | JD | [grounded] "I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | "I've never presented to anyone above regional level." Answer slot: if you have presented anything at regional level, to your regional manager or at a regional meeting, say what and how it went, in your own words. If not, say so plainly. The spreadsheet your regional manager uses is something you built, not something you presented, so keep the two apart. End on what you would do to get ready for the first senior report | F9 is a stated capability gap and the JD names presenting, so a probe is certain. The slot keeps F3 from being stretched into presenting |

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a complaint escalated past what you could resolve." | VAL | [generic] | Pick a complaint you passed up, or one that was taken out of your hands. It needs the member's situation (no names), what you did before it went up, who it went to, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's escalations line raises this theme. `[generic]` because no quoted sentence carries a specific escalation story |
| D2 | "Tell me about a complaint that went wrong on your watch." | VAL | [generic] | Pick one where something was missed or slow and you were part of it. It needs what went wrong, your share of it in "I" terms, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Don't pick a fake failure | The manager is testing honest self-assessment, and the role owns resolution times. It also tests "Own the Fix" ahead of the panel |
| D3 | "Tell me about a time you told someone more senior something they didn't want to hear." | VAL | [generic] | Pick a time you raised something unwelcome with someone above you, such as a branch manager or your regional manager. It needs the stake, what you said, and a working relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Values persona stem. The role means reporting complaint data upward, and that data is sometimes unwelcome |
| D4 | "How did you train new tellers on the escalation script?" | EXP | [grounded] "trained new tellers on our escalation script" | You trained new tellers on the escalation script. Describe how in your own words. Answer slot: the JD's coaching line makes a probe likely on whether you checked how trainees used the script afterwards. If you did, say how. If there was no such step, say so plainly and stay with how you trained. Call it "our escalation script", the branch's, unless you wrote it yourself | F5 is the bridge to coaching supervisors. EXP because the probe is about what the training actually was |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Complaints at one branch doubled last month. What do you look at first?" | CASE | [inferred] | Clarify first: same definition, same counting, same month last year? Then split the jump by complaint reason, product and channel. Then ask what changed: staff, opening hours, or one of Ashgrove's own moves, such as a digital rollout or a consolidation step. Name the metric you would watch and the risk of overreacting to a single month | Monthly volumes are the JD's reporting line. `[inferred]` because the causes it suggests come from the strategy brief. It asks about no past |
| E2 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] | Think out loud with both sides. Digital can mean fewer queue complaints and new kinds of complaint: journeys that fail, and members who don't want to go digital. Use "Members First": who is on the wrong side of the counter when service moves online? Use "Plain Words": if self-service needs explaining twice, the journey is wrong. Answer slot from F6: if you have worked with a digital team or on a self-service change, say what. If not, say so plainly and say how you would work with one. You can mention app-only banks as the pressure behind the target, as a thought | The JD's self-service line plus the brief's 40% target. CO because it scores strategy fluency at the manager's level. It is the one JD-tagged route to F6 |
| E3 | "What would your first ninety days look like?" | CASE | [generic] | Give a plan built from the JD's own lines. Learn the process end to end, including the contact centre (F2's plan). Read the existing monthly report before changing it. Meet branch supervisors before you coach them. Agree with your manager what the first senior report should show. Say "I'd want to learn" where you would | A standard hiring-manager question. It is also where your F2 and F9 plans can be offered rather than extracted |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet. What goes into it, and how does your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built it, it is monthly, and your regional manager uses it. Answer slot: say what it counts and how a month's figures get in, in your own words. If you know what your regional manager uses it for, say so. If you don't, say so plainly. Don't claim decisions were made from it unless you saw them made. If asked which part you would defend least, name it in your own words, or say plainly that you don't know | F3 and F4 are the only evidence for the reporting lines, so this question tests them. EXP because it is about what was really yours |
| G2 | "Take me through how a formal complaint moved through your log, and what rules shaped it." | JD | [grounded] "I handled the branch's formal complaints log" | Walk through a complaint from arrival to close, describing only steps you saw or did. Answer slot: if you know the rules it ran under, name them and what they asked of you. If you don't, or that sat above the branch, say so plainly. Never name a regulation you didn't work under | F8 is a discovery row against the JD's regulated-complaints line. Your manager will know the rulebook, so honesty beats guessing |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What would you want the first monthly report to tell you that today's doesn't?" | It shows you as the person who will own the report, and the answer tells you what "good" means to your manager |
| "Where do complaints get stuck today, between branches and the contact centre?" | It goes straight at the seam you'd own, and at F2, your gap |
| "How will the five-hub consolidation in 2027 change where complaints come from?" | It shows you've read the brief, and asks about a real risk in your first year |
| "When small-business lending launches in Q1 2027, will its complaints come into this process from day one?" | A new product means new kinds of complaint. Asking shows you're thinking ahead |
| "Who are the senior leaders the report goes to, and how do they use it?" | It is an honest way into F9, and tells you who you will be presenting to |
| "Is there an escalation framework for supervisors today, or would I be building one?" | It sets the size of the coaching remit, which the JD leaves open |

---

# Round 3: Panel of two branch managers (60 minutes, including a 20-minute case; scored against the four values)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Each value, asked as "tell me about a time…" | Highest. "they score against the four values" `[grounded]` recruiter | One story per value (cheat sheet below). Name the value once and let the story carry it |
| Case / Strategist | The 20-minute complaint escalation case | Certain. "a 20-minute case on a complaint escalation" `[grounded]` recruiter | The build section below. Clarify, then deal with the member, then fix, then coach, then close |
| Peer Evaluator | Who does what: when the Lead coaches their supervisors, and when they disagree | Medium-high. Branch managers' supervisors are the people the JD says you would coach `[inferred]` from the JD | Offer something back as well as asking. Propose working principles rather than pretending to know the dividing line |
| Pressure | A challenge on consolidation, or "why you over someone with contact-centre time" | Low-medium. Panels with a values brief may still push `[generic]`, and consolidation touches their branches `[grounded]` brief | Pause, restate the question, hold through two follow-ups, then concede specifically |

### Graded deliverable: the 20-minute complaint escalation case

**What the case can draw on:**

| Fact | Source | Provenance |
|---|---|---|
| The Lead owns complaints "end to end across branches and the contact centre" and will "coach branch supervisors on escalations" | JD | [grounded] |
| Complaints are "regulated", but which regime applies isn't in your material, so ask if the case doesn't say | JD | [grounded] |
| The four values are the scoring sheet | Recruiter | [grounded] |
| Branches are consolidating, digital is growing, and small-business lending is launching | Strategy brief, your summary | [grounded] |
| F1: "I handled the branch's formal complaints log" | Fit snapshot F1 | [grounded] |
| F5: "trained new tellers on our escalation script" | Fit snapshot F5 | [grounded] |

**A 20-minute structure:**

| Minutes | Step | Which value it shows |
|---|---|---|
| 0–2 | Clarify: what happened, what the member wants, what's been done, which channel(s) it touched, and whether a rule sets a deadline | Plain Words: you check you have understood before you act |
| 2–5 | The member now: what they need today, whether anyone is vulnerable or harm is ongoing | Members First, Always |
| 5–10 | Resolve: who decides, what the options are, and what you would not promise yet | Own the Fix |
| 10–14 | Root cause: is this one complaint, or a pattern at this branch or across channels? How it gets logged so the monthly report shows it | Own the Fix |
| 14–17 | The supervisor: what you would coach, and how, so the next one doesn't escalate | Neighbours, Not Numbers |
| 17–19 | The reply to the member, in plain words, read aloud as one or two sentences | Plain Words |
| 19–20 | Close: the member's outcome in one sentence, then which value each step served | All four |

**Theses to choose from. Each comes with its concession, and the concession is required:**

| Thesis | Concession |
|---|---|
| Fix the member's problem first, then fix the process | If a regulated deadline or a fairness issue applies, the formal steps run alongside the fix, and you don't skip them to move faster |
| An escalation is a coaching moment for the supervisor, not a takeover | If the member is vulnerable or harm is ongoing, you take it over now and coach afterwards |
| Close the loop in the data, so the root cause shows up in the monthly report | One complaint is not a trend. Don't redesign the process because of one case |

**Differentiation:**

- **The consensus answer** is to apologise, resolve and follow up. Every prepared candidate gives it. Give it in two minutes, then go further.
- **Where to diverge:** look for the hand-off point. Ask whether this complaint touched both a branch and the contact centre, because a complaint passed between channels is where ownership tends to drop. Then use the value's own words: "whoever finds the problem keeps hold of it until it is solved."
- **The anti-pick:** say what you would not do. Don't promise a goodwill payment or a policy exception before you have the facts and the rules. Don't close the complaint fast to protect a resolution-time figure if the member's problem isn't actually fixed. That is Members First over a metric.
- **Your own experience:** only at its own scope. "I handled the branch's formal complaints log" (F1) is enough to anchor one sentence. Don't use the case to imply cross-branch or contact-centre work.

**The close:** the recruiter didn't name one. Because the panel scores the values, close on the member's outcome in plain words, then one line naming the values you used.

### Question bank

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [generic] | Pick a time you made a call on what the member needed rather than what was easiest for the branch. It needs the situation (no names), the choice, what it cost the branch, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | "Members First, Always" in Ashgrove's own wording. `[generic]` because no quoted sentence carries this story yet |
| H2 | "Tell me about a time something needed explaining twice, and what you changed." | VAL | [grounded] "trained new tellers on our escalation script" | Possible map: training new tellers on the escalation script. Answer slot: the value says "if a member needs it explained twice, we wrote it wrong". If a trainee or a member needed something explained twice and you changed how you put it, say what you changed, in your own words. If that didn't happen, say so plainly and pick another time from your branch work, or describe how you trained | "Plain Words". F5 is the nearest quoted material, and the slot stops the pack inventing the moment the story turns on |
| H3 | "Tell me about a time your branch's town shaped how you handled a member." | VAL | [generic] | Pick something local: a member, an event or a community fact that changed what you did. It needs the local detail, your choice, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | "Neighbours, Not Numbers": "every branch is part of its town". Two branch managers will listen closely to this one |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Possible map: the monthly complaints spreadsheet you built, which your regional manager uses. Answer slot: the value is about finding a problem. If you built it because something was missing or not working, say what that was and how you kept at it, in your own words. If it was simply asked of you, say so plainly and pick another time you kept hold of a problem, or say how you would | "Own the Fix". F3 is the only quoted artefact that could carry this story, and the slot keeps the pack from supplying the problem |

**Case / Strategist (warm-up before the case)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "How would you coach a supervisor who escalates everything, and one who escalates nothing?" | CASE | [generic] | Treat the two as opposite risks. Over-escalating is slow for the member, and under-escalating means risk stays hidden. Clarify what "should escalate" means at Ashgrove, look at what the log shows for that supervisor, coach on judgment rather than the script, then check back. Give a plan, not a past | The JD's coaching line, asked as a live problem. It asks about no past |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "When you coach my supervisors on escalations, where does your job end and mine begin?" | CASE | [generic] | Offer principles rather than a fixed line. They manage their supervisors, and you coach on complaints and escalations. You tell them what you are seeing before anyone else hears it. Disagreements go to a conversation, not to a report. Then ask what they would want from you | Peer stem, adapted to the JD's coaching line. Scored on whether you know where your remit ends |
| K2 | "What would you need from branch managers to make the monthly report useful, and what would we get back?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Make it two-way: what you need, such as consistent logging, and what they get back, such as their branch's picture each month. You can mention that you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if branches fed it or got anything back from it, say how. If not, say so plainly | The JD's reporting line, asked as reciprocity. F3 is relevant but should stay at its own scope |
| K3 | "You were a supervisor. What did escalation look like from your side?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "trained new tellers on our escalation script" | You were a branch supervisor for the last three years and trained new tellers on the escalation script. Answer slot: the JD's escalations line makes a probe likely on how escalations reached you and what you passed on. Describe it in your own words. If you rarely escalated, or escalation sat with someone else, say so plainly | F5 and F7. Branch managers will compare your answer with what they know of their own supervisors |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Eight branches are becoming five hubs. Isn't 'Neighbours, Not Numbers' just words now?" | CO | [grounded] | Pause and restate the question. Don't argue against the strategy and don't side against it. Hold: the value can be applied through how complaints are handled during the change. Give examples as a plan: watch complaints from the affected towns, and make sure every member knows where to go. Concede specifically: you don't know the local detail of each branch yet, and you'd want their view. Hold through two follow-ups | The brief's consolidation line set against a published value. The panel are branch managers, so CO and VAL meet here |
| L2 | "Sixty seconds: why you over someone who's run a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "Never worked in a contact centre" | Pause. "I haven't worked in a contact centre." Then hold on what you have: three years as a branch supervisor, and the branch's formal complaints log. Branches are what this panel runs. Don't knock the other candidate. If pushed a second time, concede the gap again and give your plan. Don't fold on what you did | F2 is the gap and F1 and F7 are the hold. A pressure stem. It is the panel's version of C1 |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story | Questions |
|---|---|---|---|
| Members First, Always | Decide by what the member experiences, not by what is convenient internally | Selection scaffold: a call you made on the member's side, with what it cost. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | H1, E2, the case |
| Plain Words | If something needs explaining twice, the writing is at fault, not the member | F5: "trained new tellers on our escalation script". The "explained twice" moment is an answer slot (H2) | H2, the case |
| Neighbours, Not Numbers | Each branch belongs to its town, so treat it that way | Selection scaffold: a local detail that changed what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | H3, L1 |
| Own the Fix | Whoever finds a problem keeps it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses." Whether it fixed a problem is an answer slot (H4) | H4, D2, the case |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would genuinely help your branches?" | A reciprocity question for the people whose supervisors you would coach |
| "When a complaint escalates at your branch today, where does it go, and what's frustrating about that?" | It gets the real process from the people who live with it |
| "What do your supervisors find hardest about escalations?" | It sets up your coaching work, and you have done the supervisor job yourself |
| "How are complaints being handled through the consolidation, and what would you want from this role during it?" | It respects their position and asks for their view rather than offering yours |
| "What would make the monthly report worth your time to read?" | It makes the report a two-way thing, and it is the Plain Words value applied to your own output |

---

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation of the limit is that your material shows one branch's log. C1's slot stays inside that log |
| Any contact-centre experience | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Coached or trained branch supervisors | Inflated form of F5 | F5's quote: "trained new tellers on our escalation script." Your material shows tellers, not supervisors |
| Wrote or designed the escalation script | Inflated form of F5. "our escalation script" says whose script it was, not who wrote it | F5's quote at its own scope. D4 calls it the branch's script |
| Owned or presented the region's complaints reporting | Inflated form of F3. "built… our regional manager uses" says you built it and they use it | F3's quote: "I built the monthly complaints spreadsheet our regional manager uses." C3 keeps building and presenting apart |
| Analysed complaint trends or root causes from the spreadsheet | Inflated form of F3. Building a spreadsheet is a different kind of work from analysing trends | F3's quote at its own scope. G1's slot asks only what it counts |
| Expertise in complaints regulation | Inflated form of F8 | F8's quote: "I handled the branch's formal complaints log." G2's slot stays inside the log |
| Presented to senior leaders, the executive team or the board | A negative you stated, F9 | "I haven't presented above regional level." No slot beyond C3's regional one |

---

## Sources

**Provided documents:**

- The Member Experience Lead JD, pasted in your message.
- Ashgrove's four values, pasted in your message and copied 12 November 2026 from ashgrovecu.org/about/values. The page was not fetched.
- The recruiter's email describing the three rounds, pasted.
- Ashgrove's 2026 strategy brief (July 2026), as you summarised it. The brief itself was not in hand.
- Your background, in your message.

No tuesday-dossier.md was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | Your pasted values text fixes the cheat sheet and H1–H4 by name and wording |
| 2. Ashgrove Credit Union interview process, member services | skipped | The recruiter's email establishes all three rounds, including the case and values scoring, so persona weights follow it |
| 3. Ashgrove Credit Union strategy / recent news | skipped | Your summary of the July 2026 brief, about four months old, supplies the priorities and the competitive frame behind E2, L1 and the grounding brief |
| 4. Interviewer name + Ashgrove Credit Union | n/a | No names have been assigned, so there was no query to form. The interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your CV:** more of your own sentences to quote. F3, F4, F6 and F8 could move out of discovery, and A1 and C1 would get a fuller hold.
- **Your private answers to the slots in F3, F6, F8 and C3** (what the spreadsheet counts, any digital work, the rules your log ran under, any regional presenting), told to me outside a drill. Those rows would become story-mapped instead of slotted, and G1, G2, E2 and C3 would be rewritten around them.
- **The interviewers' names once they're assigned:** a read of each person's public professional footprint, persona weights per panel member, and at least one reverse question tied to each person's own career path.
- **The full strategy brief, not just your summary:** a fuller grounding brief, sharper E2 and L1 questions, and any figures the brief itself gives.
- **One email to the recruiter about the case format** (given on the day or in advance, written or spoken, and whether Ashgrove's complaint rules are included). The case build could be cut to fit the real format.
- **Hours you can give prep each day:** the triage resized to your real time.
- **A deeper research pass**, up to 6 more searches and 2 more fetches, taking several more minutes. It would look for recent Ashgrove news and anything the Head of Member Services has published. With your brief in hand and no names assigned, it would probably move little. Say if you want it.
- **A tuesday-dossier.md from a job-underwriter pass:** the highest-ROI objection taken from evidence you confirmed rather than inferred by this pack, plus a prohibited-claims list you checked yourself. This pack doesn't need one.
