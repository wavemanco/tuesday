Reading the dossier-handoff and schema files first.
I've saved your prep pack as `quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the one 45-minute hiring-manager conversation, from your dossier.

**What it's built on:**
- **Requirements:** the dossier's role profile stands in for the job description.
- **Your words:** every line written for you to say comes from the dossier's three verified-evidence sentences.
- **No research:** my three web searches were refused by this session's permissions. So nothing in the pack about Quartzline itself comes from outside the dossier; those parts are general role patterns, marked as such.

**Your one hard objection:** the pack gives the deepest rehearsal to A1, the question your underwriting named: "You've never been a PM or owned a roadmap — why you?" The answer follows the dossier's conditions:
- Admit the title and the roadmap first.
- Then make the case from your 30+ integrations and the roadmap-input sessions, as work next to product management, never as PM experience.
- Finish with a plan for how you'd get up to speed.

**The dossier is three months old.** It's dated 14 August. It gives no length of time for your integration work, so the pack doesn't either. You'll say your tenure in your own words (rows F1 and D1).

**If "Thursday" means today:** today is Thursday 12 November. If so, do A1, A2, B1–B3 and reverse questions 1–2, and treat the rest as backup.

Say the word and I'll play the Skeptic on A1 as a live practice run.
I can also update your `tuesday-dossier.md` with what this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, Thursday. Interviewer name not given.
**Built from:** your `tuesday-dossier.md` (job-underwriter, version 1.1, dated 2026-08-14). Web research was attempted and refused by this session's permissions, so everything about Quartzline beyond the dossier is `[generic]`. See Sources.

## How to use this pack

Two axes. **Personas** say how a question will be asked: the tone, the pressure, the follow-ups. **Types** say what is being scored:

- **VAL**: past behaviour against stated values
- **EXP**: whether your own claims hold up under scrutiny, and which parts were actually you
- **JD**: whether you can do the job as described, gaps included
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role, solved out loud

Guidance is scaffolding, not a script. Every sentence offered as *your* words is one of the dossier's verified-evidence sentences, quoted in the row's Provenance cell. Where the pack doesn't know something about your past, it leaves an **answer slot**: an instruction for the interview with two honest branches. Fill it from memory or say the plain thing. Never fill it from the pack.

Question IDs go by persona: A, B, C, D, E, G, H. The letter F is skipped because F1–F9 are the fit-snapshot rows.

**Highest-ROI prep in this pack: A1.** The underwriter named it. Rehearse it until it's boring.

A 45-minute hiring-manager conversation will reach perhaps 6–10 of these questions. Do A1, A2, B1–B3 and the reverse questions first. Everything else is insurance.

## Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is quoted from `handoff_to_mock_interview.verified_candidate_evidence`. The confidence notes the dossier attached to each entry sit in the Confidence column and the bridge, not in the quote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | low | [grounded] | transferability | The dossier's strategy is bridge, and its condition is that this is positioned as adjacent, never as PM experience. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live, and I ran quarterly roadmap-input sessions feeding client evidence to product." Then name the limit: this is work next to product management, not the PM job. The dossier summary mentions years of integration leadership, but no verified entry gives a tenure. Answer slot: R1's "3+ years" makes a question about duration likely. Give your own tenure in your own words. If you aren't sure of the exact figure, say so rather than rounding up |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area, and `prohibited_claims` lists "Having owned a product roadmap". Words: "I haven't owned a product roadmap." Follow it with how you would get up to speed, said as a plan and never as something you've done. No bridge and no slot: the underwriter already looked |
| F3 | "Shipped API or platform products" — dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | high | [grounded] | transferability | Your material describes client integrations of the vendor's APIs taken to go-live. It does not describe shipping the API product, and the quote already carries that limit in "the vendor's REST APIs". Keep the quote whole, because those words are the honest boundary. Answer slot: R2 makes a probe on what you built versus what you integrated likely. If any part of an integration was something you specified or built, say what, in your own words. If not, say so and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified evidence 2 | low | [inferred] | discovery | Integration architecture on REST APIs touches this requirement, but your material doesn't show docs or schema work directly. The inference is the pack's, not yours. Answer slot: if you worked from API docs or schemas on those integrations, or wrote about them in the playbook, say how, in your own words. If not, say so plainly and describe the integration stages you led |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | discovery | The quotes reach clients and product. They don't show engineering or sales. The sessions are confirmed, but with little inspectable proof, so expect a probe. Answer slot: if you worked with engineering or sales on those integrations, say who and what was at stake, in your own words. If not, say so and stay with clients and product |
| F6 | "Agile delivery experience" — dossier R5, preferred | none given | low | [inferred] | discovery | The dossier says clarify. No verified entry speaks to agile itself. Answer slot: R5 makes "how have you worked in agile?" likely. If you worked in sprints or a similar cadence, say how, in your own words. If you never worked that way, say so plainly, then: "Here's what I'd want to confirm about how your squads run it" |
| F7 | "Run discovery with integration partners" — dossier responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | transferability | Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Your material calls them input sessions, not product discovery, so describe them as what they were. This entry is confirmed with limited inspectable proof, so volunteer the limit first. Answer slot: if you have notes or a deck from a session you could describe, say so. If not, say so plainly |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | high | [grounded] | transferability | The quote names requirements and go-live as stages of integrations you led. It doesn't say product specs or squads. `prohibited_claims` lists "Having set prioritization for an engineering squad". Answer slot: if you wrote requirements that engineers built from, say how that worked, in your own words. If that stage was someone else's, say so and stay with the integrations |
| F9 | "Define and track adoption metrics" — dossier responsibilities | none given | none | [grounded] | discovery | Your material is silent here. Silence is not a stated absence. Answer slot: if you tracked any adoption or usage numbers on your integrations, say which, in your own words. If you didn't, say so plainly and say what you would measure first |

## Persona weights

The loop is established by your own words: one 45-minute conversation with the hiring manager. Weights start from the hiring-manager prior (Case/Strategist and Skeptic dominant) and are adjusted by the dossier. No values-style round is detected, so the values cheat sheet is omitted.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | "You've never been a PM," asked quietly and then cross-examined | High. The underwriter named this objection, and F1 and F2 are the pack's biggest gaps | Concede the title and the roadmap first, bridge with the quotes and their limit, then give a ramp plan. A1 is the rehearsal |
| Case / Strategist (B) | Live problems from this role: adoption, roadmap, squads, partners | High. A hiring manager wants to see the job done live, and live problems ask nothing about your past, so they're your fairest ground | Clarify, then objective, segments, approach, metrics, risks. Think out loud. Ask about decision rights before assuming you have them |
| Data-Driven Prober (C) | "30+," "end-to-end," the playbook, taken apart | Medium. Your strongest evidence carries a number, and the number will get probed | Know how you counted, say where you don't know, and name your weakest assumption first |
| Conversational (D) | "Walk me through your journey," a favourite API, any questions | Medium. Most hiring-manager conversations open this way, and casual questions are still scored | A 90-second arc built only from your quotes. Treat casual technical questions as scored |
| Pressure (E) | Time-boxed "why you," "how much was actually you" | Low to medium. It's not this round's default, but the objection invites it | Pause, restate the question, hold through two follow-ups, concede exactly |
| Peer Evaluator (G) | Squad-lead seams and engineering pushback | Low. The interviewer isn't a peer, but the squad-authority question is live and the hiring manager may voice the squad leads' view | Propose principles for the seam rather than claiming you already know where it sits |
| Values / Behavioral (H) | Generic behavioural stems | Low. No values round is documented and no values page was read | Selection scaffolds with honest branches |

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role", "Having owned a product roadmap" | **Highest-ROI rehearsal, named by the underwriter.** (1) Concede first and plainly: "That's right. I haven't held a PM title, and I haven't owned a roadmap." (2) Bridge with the limit included: "What I've done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live, and run quarterly roadmap-input sessions feeding client evidence to product." (3) Say it is adjacent work, not the same job, and stop there. Don't argue that it's equivalent. (4) Give a ramp plan as a plan: learn the current roadmap and who decides what, sit in on partner conversations early, take on one scoped decision with the squad leads. (5) The sessions are confirmed but have little on paper behind them, so expect "what came of them?" Answer slot: if you know of something you raised that product acted on, say what, in your own words. If you don't know what product did with it, say so. Hold through two follow-ups by going back to (2). Never add to it | F1 and F2 are where the role presses hardest, and the dossier names this objection. Both negatives in the question come from `prohibited_claims`, so it is asked as written. JD because it scores R1 directly |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas` acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it before they do: "Owning a roadmap and setting priorities. I haven't owned a roadmap." Then the plan: how you'd learn the decision framework, who you'd calibrate with, and what you'd want settled in month one. Then turn it into a question: "Which roadmap decisions would be mine alone here?" That's reverse question 1. Don't name a fake weakness, and don't bridge this one | F2 is the one capability gap, and admitting it on your own terms beats having it extracted. JD because it scores a stated responsibility |
| A3 | "I don't see agile delivery inside a product org in your background — how would you work with the squads' sprint rhythm here?" | JD | [inferred] | Clarify strategy (F6), so ask before claiming: "How do your squads run it? Sprints, kanban, something else?" Answer slot: if you've worked in sprints or a similar cadence, say how, in your own words. If you never worked that way, say so plainly, then "Here's what I'd want to confirm about how you define it." Nothing about your past goes into the answer beyond the slot | R5 is preferred, not required, and the dossier marks it clarify. `[inferred]` because no verified entry speaks to it |
| A4 | "This role ships API products. What's the closest you've come to shipping one?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Use the quote, whole: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." "The vendor's" is the honest boundary, so keep it in. Answer slot: if you specified or built any part of what shipped, say what, in your own words. If not, say so and stay with the integrations. Let the interviewer draw the conclusion | F3 is a must-have answered by adjacent work, and the gap between "integrated" and "shipped" is the next place a skeptic presses after A1 |
| A5 | "Why move from integrations into product management, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection scaffold. Your material doesn't give a motive, so this has to come from you. Pick the real reason, specific enough to be believable and short enough for 60 seconds. If the roadmap-input sessions are where the pull started, say so in your own words. If they aren't, don't borrow them. If no single moment comes to mind, say so plainly and give the reason anyway | A persona stem every career-change candidate gets. F7's quote is offered only as a possible anchor, not as a motive |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has been flat for two quarters. Diagnose it. What do you need to know first?" | CASE, JD | [generic] | Clarify: how is adoption measured now (calls, active keys, partners in production)? Segment partners by stage: signed, first call, in production, expanding. Find where the funnel stalls, then form hypotheses for that stage: onboarding and docs friction, auth, missing endpoints, the partner's own priorities. Say what you'd measure, what you'd ask five partners, and what you'd try first. Close with risks. The question asks nothing about your past, so the guidance claims nothing | Comes from "Define and track adoption metrics" (F9). The dossier says the current baseline is unknown, so ask that before diagnosing. `[generic]` because no Quartzline data was researched |
| B2 | "It's your first 90 days. How do you build the roadmap for the partner-facing API platform?" | CASE, JD | [generic] | A plan, never a past. Days 1–30: listen (partners, squad leads, sales, current metrics, existing commitments). Days 31–60: draft problem statements and a prioritisation frame, and check decision rights. Days 61–90: a first roadmap with explicit trade-offs, reviewed with the squads. State one premise you'd challenge. Never say "as I did before" | F2's gap means this case has to show method, since it can't show a track record. JD because it is the role's first responsibility |
| B3 | "Two squad leads disagree: one wants a big partner's custom endpoint, the other wants versioning work for everyone. How do you decide?" | CASE | [generic] | Clarify first: who decides here, and what has been promised? Criteria: number of partners affected, revenue and strategic weight, cost of delay, technical debt, precedent. Make the trade-off explicit, decide or escalate per the decision rights, and tell partners and sales what was decided. Ask who owns the call rather than assuming you do | Comes from "two engineering squads" (F8) and the dossier's open question about squad authority |
| B4 | "Sales has promised a partner a feature that isn't on the roadmap. What do you do?" | CASE, JD | [generic] | Find out the facts: what was promised, to whom, and the date. Find the partner's real need behind the feature. Options: meet the need another way, a scoped commitment, or a clear no with a path. Agree with sales how commitments get made from now on. Keep sales on side while you hold the roadmap | R4 names sales, and F5 shows no sales evidence, so this case is where you show the skill without claiming the history |
| B5 | "How would you run discovery with our integration partners?" | CASE, JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Plan: who to talk to (new, struggling and expanding partners), what to ask (jobs, workarounds, the moment they nearly gave up), how often, and how findings reach the roadmap. Optional anchor: "I ran quarterly roadmap-input sessions feeding client evidence to product." Say it as input you fed to product, not as discovery you owned. This entry has limited proof behind it, so answer slot: if you can describe how one session ran, do so in your own words. If not, say so plainly and stay with the plan | F7 is the closest verified entry to this responsibility, and its medium caveat means the probe will come. CASE delivery on a JD responsibility |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30+ integrations. Walk me through how that number is counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, in your own words: how the 30+ was counted, what it is sensitive to, which assumption behind it you'd defend least, and which of them were yours to lead. Name the weakest assumption before they do. If you don't know exactly how it was counted, say so. Never round up | The headline figure in F1 and F3, and the most likely number to be probed |
| C2 | "Pick one integration and walk me through it, scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3. The beats are the quote's stages: scoping, requirements, architecture, UAT, go-live, and the verb "led." Pick one integration you can talk about in detail and tell it in your own words. Answer slot: R3 makes a probe on API docs and schemas likely. If you worked from them on this one, say how. If not, say so and move on to the stages | Tests whether "end-to-end" survives detail. It also covers R3 (F4) through the slot |
| C3 | "Tell me about the playbook. What's in it, and how do you know the team uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | "I wrote the internal integration playbook my team uses." The pack doesn't know what's in it, so describe the contents in your own words. This is your one inspectable artifact, so if you can share a section without breaking client confidentiality, say you can walk them through it. Answer slot: if asked how you know it's used, say what you've seen, in your own words | F4's high-confidence entry. A hiring manager reading the role as spec-writing will want to see how you write |

### D. Conversational (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: the integrations, the playbook, the roadmap-input sessions, then why this role. Answer slot: give your tenure and employers in your own words. No PM title, and no "basically a PM." End on the role, not on a defence | The opener most hiring-manager conversations use, and the first test of F1's positioning |
| D2 | "What's an API whose docs you think are really well done, and why?" | JD | [generic] | Treat it as scored. Name one you actually know, then say what makes it good: quick start, error clarity, schema reference, versioning policy. If none comes to mind, say so plainly and say what you look for in docs | A casual route into R3 (F4). JD because it scores the stated requirement |
| D3 | "Why Quartzline?" | CO | [generic] | Research didn't run, so stay with what you know: the role's own line, "Own the roadmap for the partner-facing API platform," and your own reason for wanting a partner-facing API platform. Don't state facts about Quartzline you haven't checked | CO with nothing researched. `[generic]` until values or strategy research runs (see the upgrade menu) |
| D4 | "Any questions for me?" | CO | [generic] | Never "I think you've covered everything." Ask reverse questions 1 and 2 at minimum | Casual-sounding but scored. Rapport-style interviewers weight it |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done this exact job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having held a product manager title or role" | A1 compressed. Pause, then: "I haven't held a PM title. What I bring is having led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Say the work is adjacent, give one sentence of ramp plan, and stop. Don't talk down the other candidate | Same objection under time pressure. The hold is the quote, nothing more |
| E2 | "Those 30+ integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | "Led" is the quote's verb. Hold it, and give credit where it's due. Answer slot: say which parts were yours and which were the team's, in your own words. If any integrations in the 30+ weren't ones you led, say so and give the number that was | Precise attribution, rehearsed. F1 and F3 rest on this quote |

### G. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "The squad leads make a lot of delivery calls today. Where's the seam between you and them, and what happens when you disagree?" | JD | [generic] | Propose principles for the seam: the PM owns the problem and its priority, the squads own how it gets built, and trade-offs are made openly with a named escalation path. Then ask how it actually works today. Never claim you've set squad priorities | The dossier's open risk on decision authority, from the hiring manager's side. Ties to reverse question 1 |
| G2 | "Tell me about a time engineering pushed back on what you asked them to deliver." | EXP | [generic] | Selection scaffold. R4 names engineering. Pick a time with a real disagreement, what you did, and how the relationship came out. If no such time comes to mind, say so plainly, then say how you'd handle it | Covers the engineering side of R4, where F5 shows nothing |

### H. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, what you said, whether it landed, and the relationship afterwards. Say "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | A generic behavioural stem. No values round or values page is in hand |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the customer, the metric, the call you made, and the cost. If no such time comes to mind, say so plainly | A partner-facing role makes this theme likely even outside a values round |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1, 3+ years PM (F1) | A1, E1, D1 |
| Roadmap ownership (F2) | A1, A2, B2 |
| R2, shipped API products (F3) | A4, C2 |
| R3, API docs and schemas (F4) | D2, C2 |
| R4, stakeholders across engineering, sales, customers (F5) | B4, G2 |
| R5, agile (F6) | A3 |
| Partner discovery (F7) | B5 |
| Specs and squads (F8) | B3, G1 |
| Adoption metrics (F9) | B1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Comes from the dossier. Decision authority is asserted in the JD but not evidenced, and the answer tells you whether this is the job described |
| 2 | "How is partner API adoption measured today, and what's the current baseline?" | Comes from the dossier. Adoption is listed as a responsibility with no baseline given, so you learn whether you'd inherit a metric or have to build one |
| 3 | "What would make the first six months a clear success, in your eyes?" | Makes the hiring manager define the bar you'd be measured against |
| 4 | "Where do partners get stuck most often today?" | Shows you think about the partner first, and its answer feeds any case they set you |
| 5 | "How do sales commitments to partners reach the roadmap now?" | Tests the R4 seam from their side and shows you know where API roadmaps come under pressure |
| 6 | "What made you open this role now?" | Tells you whether it's a backfill, new scope or a reset, which affects how much authority comes with it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | "I haven't held a PM title." Then F1's quotes, positioned as adjacent work |
| Having owned a product roadmap | Dossier `prohibited_claims` and acknowledge_gap area | "I haven't owned a product roadmap." Then a ramp plan. No slot and no bridge |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." In B3 and G1, ask about decision rights rather than claiming them |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope: integrations of the vendor's REST APIs. The limit is the pack's observation, not words for you. A4's slot stays inside the integrations |
| Ran product discovery with partners | Inflated form of F7 | F7's quote at its own scope: roadmap-input sessions feeding client evidence to product |
| Wrote product specs for engineering squads | Inflated form of F8 | F8's quote at its own scope: requirements as a stage of integrations you led |

## Sources

- **Dossier consumed:** `tuesday-dossier.md`, version 1.1 (a major version this skill knows), generated 2026-08-14, about three months ago. It supplied `role_profile` (in place of the JD), `handoff_to_mock_interview` (verified evidence, weak areas and strategies, the A1 objection, risks, employer questions, prohibited claims) and `decision` (context only). It has no `evidence_map`, `evidence_state` or `risk_register`, so the snapshot's grading for R2–R4 and the responsibilities is this pack's own.
- **Searches sent, all refused by session permissions:** "Quartzline company values" (refused), "Quartzline interview process product manager" (refused), "Quartzline partner API platform news 2026" (refused).

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Refused. Would have themed the VAL questions with the published values and given D3 something specific |
| 2. `Quartzline interview process product manager` | unavailable | Refused. Your own words already establish this session, so the weights stand. It would have shown whether a values round exists elsewhere in the loop |
| 3. `Quartzline strategy` / recent news | unavailable | Refused. Would have grounded one CO or CASE question in current strategy. B1–B5 and D3 stay `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given. There is no interviewer read, and the reverse questions are role-specific rather than person-specific |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the snapshot and the JD-tagged questions |

## Upgrade menu

- **Allow web search for this session** → targets 1–3 run: published values for H1–H2 and D3, and one CO or CASE question grounded in Quartzline's current strategy
- **Deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and a grounding section, so the B bank uses Quartzline's own vocabulary
- **The hiring manager's name** → an interviewer read, adjusted persona weights and a reverse question tied to their own career path
- **The recruiter's prep notes** (focus areas, anything you're asked to prepare) → coverage of any pre-declared deliverable and weights based on their emphasis
- **How much prep time you have before Thursday** → a prep-triage schedule at the top of the pack
- **Your tenure and employers in your own words** → fills the F1 and D1 slots with quoted words instead of slots
- **Notes or a deck from one roadmap-input session** → the artifact that would raise F7 and F5 from medium, and fill B5's slot
- **A section of the integration playbook you can share** → C3 and F4 rest on its actual contents
- **The original JD text** → requirement quotes become the posting's own words rather than the dossier's summary
- **Any adoption or usage numbers you tracked, or a plain "none"** → F9 and B1 move from slot to quote
