I'm checking public info on Saltmarsh Games and Tobias Wrenfield before I build your pack.
Femi, your prep pack for tomorrow's interview with Tobias is ready: [SaltmarshGames_live-operations-producer_interview_pack.md](/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-denied-c125cc94/SaltmarshGames_live-operations-producer_interview_pack.md)

I built it on the assumption that Tobias would be your manager. The web searches I tried were blocked, so nothing in it comes from research on Saltmarsh or on Tobias. It uses only your JD and background, and anything generic is labelled as generic.

**What's in it:**
- **Fit check:** each requirement in the job description, set against your own words. Your strongest evidence is the content calendar, the QA checklist and the retention numbers. The gaps are running two titles at once, coordinating the four teams, owning post-event reviews, and in-app purchases.
- **22 practice questions:** each comes with guidance on how to answer.
- **What to practise most:** question B1, "You've been an associate producer… why are you ready for this now?" It includes how to hold your position, what to concede, and a plan for your first months.
- **Six questions to ask Tobias.**
- **What not to claim:** for example, that you led a team, owned the KPIs, or worked on in-app purchases. Each comes with an honest way to say it instead.

If you want to rehearse, I'll play the Skeptic on B1 live and give you feedback afterwards.
I can also save a file recording the gaps this prep turned up, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Two questions:
1. Is Tobias the person you'd report to, and did the recruiter mention any focus areas or anything to prepare, such as a calendar plan or a presentation?
2. Do you want to allow web search so I can check Saltmarsh's values, interview format, recent news and Tobias's public work profile? I can also run a deeper pass if you like: up to 6 more searches and 2 page reads, taking several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: SaltmarshGames_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. This pack assumes he is the hiring manager (your note gives his title but not your reporting line).
**Format:** one 60-minute interview, Friday.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who is asking, and in what style. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behavioural or values fit. Does your past behaviour show the company's values?
  - **EXP**: experience deep-dive. Does what you said about your work survive close questioning, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Have you done your homework on Saltmarsh, and can you think at its level?
  - **CASE**: a live problem from the actual role, worked through out loud.
- Provenance labels: **[grounded]** = traceable to the JD or to your own message. **[inferred]** = this pack's derivation, with the reasoning named. **[generic]** = a pattern for this kind of role, making no claim about Saltmarsh.
- **Answer slots** are instructions for what you say in the interview. They are not questions for me. Each one has two honest branches, and either branch is a good answer.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a weekly content-drop calendar for your main title. It doesn't describe a live-events calendar across two titles, so your words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "two of our mobile titles" makes a probe on handling more than one title likely. If you scheduled across more than one title, say how, in your own words. If you didn't, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team" — your message | low | [inferred] | discovery | Your material doesn't show which teams the calendar involved, or how. The JD asks you to coordinate, not to lead, and the two are different. Answer slot: if running the calendar meant working with design, art, engineering or community to get drops out, name the teams and say how you kept them on schedule, in your own words. If it didn't, or someone else did that part, say so plainly and stay with the calendar. If you're asked about leading: "I haven't led a team." |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is reporting. That sits next to owning an event's review and choosing its KPIs, but it doesn't show either one. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you prepared those numbers yourself, or wrote a review after a drop or release, say what it covered, in your own words. If not, say so plainly and describe how you would build the review |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist is very close to this requirement. Running it with QA release after release is the part the quote doesn't cover. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran it with QA on releases, say how. If QA ran it after you wrote it, say so and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Four years clears three. Your material doesn't say the puzzle title ran as a live service for all four. Answer slot: if it did, describe what live operation looked like there, in your own words. If part of that time it didn't, say which part and stay with the calendar you ran for the last two years |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: weekly, your main title, the last two years. Nothing has been inspected behind it, so expect a probe |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches this requirement. Expect the Prober. Answer slot: name the retention measures in those numbers, in your own words, and say whether you calculated them or presented numbers someone else prepared. If you don't know how they were counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist QA still uses is written work that has lasted. The JD's post-event review is the written work they are more likely to probe. Answer slot: if you wrote other documents teams relied on, name them. If not, stay with the checklist |
| F9 | Monetized events and offers: a common pattern for mobile live ops, not stated in this JD | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | The JD doesn't mention monetization, so this row rests on a pattern, not on a Saltmarsh requirement. Words: "I haven't worked on a game with in-app purchases." Then say how you would learn it, framed as a plan and never as something you've done |

---

## Persona table

The loop comes from your own words: one 60-minute session with Tobias. His title, Head of Live Operations, points to a hiring-manager round, so the hiring-manager defaults apply (Case/Strategist and Skeptic dominant). No interviewer signals adjust them, because the web searches were blocked. If he turns out to be a peer or a skip-level, these weights change.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | "Plan this calendar", "this event underperformed: diagnose it" | High. A hiring manager is buying capability, and every JD duty can become a live problem | Clarify, then objective, then structure, then metrics, then risks. Think out loud. Respectfully challenge one premise per case |
| Skeptic (B) | Quiet probing of the gaps: associate-level title, one title against two, no team led, no in-app purchases | High. A hiring manager is reducing risk, and F1, F2 and F9 are visible gaps | Rehearse B1 until it bores you. Hold only what your quotes carry, concede specifically, then give a ramp plan |
| Data-Driven Prober (C) | "Which retention metrics? How were they counted?" | Medium. The JD names KPIs and retention, and F3 and F7 are your metrics evidence | Know what you can and can't say about how those numbers were made, and say plainly when you don't know |
| Conversational (D) | "Walk me through your journey", "what are you playing?" | Medium. Almost every 60-minute round opens this way | A prepared 90-second arc. Casual questions are still scored |
| Peer Evaluator (E) | Seams with community and other disciplines | Low to medium. The JD's coordination line invites it, even from a manager | Talk about seam principles, and what you bring to each team as well as what you need from it |
| Pressure (G) | "Sixty seconds: why you?" "How much was actually you?" | Low. Nothing suggests a stress style, but it costs little to rehearse | Pause, restate the question, hold through two follow-ups, then concede what's real |
| Values / Behavioural (H) | "Tell me about a time…" | Low. No values round is documented, and Saltmarsh's published values couldn't be checked | One or two true stories, ready to go |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How would you plan a quarter of live events across two titles? What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Anchor once in the quote: for the last two years you ran the weekly content-drop calendar for your main title. Then work the case. Clarify first: each title's audience, its current cadence, team capacity, and the KPIs each title is held to. Set the objective per title. Sequence the events so the two titles don't compete for the same art and engineering time in the same week. Build in a buffer before each release. Name the risks: slipped assets, last-minute scope, live bugs. Close with how each event gets reviewed | F1 and F6 cover the calendar half of the role, and the two-title scale is the new part. CASE because a hiring manager will want to see you plan, not just recount |
| A2 | "An event goes live and engagement is well below the last one. Diagnose it." | CASE | [generic] | Check the data before the event: is tracking firing, are you comparing the same segment and timing? Then check delivery: did everything ship as planned, and are there bugs or store issues? Then context: competing events, seasonality, difficulty or reward changes, community sentiment. Separate "fix now during the event" from "learn in the post-event review". Say what you would *not* conclude from one event | Tests the post-event review and KPI duty (F3) as a live problem. Generic because it's a standard diagnostic pattern, not Saltmarsh's data |
| A3 | "Three weeks out, art tells you the key event assets will be a week late. What do you do?" | CASE | [generic] | Find out what exactly is late and why. Ask what can still ship on time. Options: cut scope, swap in reused assets, move the date, or reorder the calendar. Bring the trade-off to whoever owns the decision, with a recommendation. Tell design, engineering, QA and community what changes. Make no claim about your past here, because the question doesn't need one | The JD's coordination line (F2) as a decision rather than a record. It keeps F2's evidence gap out of the answer |
| A4 | "Design wants to add a change after checklist sign-off, and QA says no. What happens?" | CASE | [generic] | Ask what the change fixes and what it risks. Ask what QA would need in order to re-verify, and what holding it to the next update would cost. Know who decides the release, and make the call or escalate with a recommendation. Record the decision against the checklist | The JD's "manage the release checklist with QA" (F4) as a live judgment call |
| A5 | "What would your post-event review contain, and which KPIs would it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start from goals set *before* the event, then: participation, retention around the event window, completion, player sentiment from community, incidents and bugs, and delivery against plan. Cover what worked, what didn't, and the actions, each with an owner. One reporting anchor, at its own scope: you presented the monthly retention numbers to the studio head. Answer slot: if you've written or contributed to a review after a drop or release, say what it covered. If not, say so plainly and present this as the template you'd use | The JD's ownership line for the review and its KPIs, against F3's adjacent evidence. JD because it scores a stated duty |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've been an associate producer. This role owns the calendar for two titles and coordinates four disciplines on every update. Why are you ready for that now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team" | **The highest-ROI rehearsal in this pack.** Hold on what you did, in three sentences: you ran the weekly content-drop calendar for your main title for the last two years; you wrote the release checklist your QA team still uses; you presented the monthly retention numbers to the studio head. Describe those three and let him draw the conclusion. Don't call them proof. Answer slot on two titles: if you scheduled across more than one, say how; if not, say so plainly. Answer slot on coordination: if the calendar meant getting design, art, engineering or community to deliver, name the teams and how; if not, say so plainly and stay with the calendar. If leading comes up: "I haven't led a team." Then the ramp, framed as a plan: learn both titles' cadences, meet each discipline lead, shadow one full event cycle. Follow-up 1, "one title isn't two": concede it plainly and return to the calendar you ran. Follow-up 2, "so who did the coordinating?": answer the slot honestly, either branch | The step from associate role to owner, along with F1, F2 and F3, is the gap a Head of Live Ops is most likely to press. JD because it scores the role's ownership scope directly |
| B2 | "Have you led or managed a team?" | EXP | [grounded] "Never led a team" "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first, with no hedge: "I haven't led a team." Then the calendar, at its scope. Don't recast running the calendar as leading. The JD asks for coordination, so you don't need to stretch | Your stated negative (F2) will surface, and a calm two-sentence answer beats a defensive one. EXP because it tests attribution honesty |
| B3 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then the plan: review recent events' offer performance, sit with whoever owns monetization, and learn each title's economy before scheduling anything with an offer in it. Don't present retention reporting as monetization experience | F9 is not in the JD, but it's a common pattern for mobile live ops, so the question may come anyway. Its likelihood is generic and its answer rests on your stated negative |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Pick one real gap, not a disguised strength. Candidates from your own material: running two titles' calendars at once (F1's slot), or owning a post-event review and its KPIs end to end (F3's slot). Name it, say what you have that's nearest (one of these two quotes, at its scope), and give a 30-day plan | A standard Skeptic stem that scores self-assessment. JD because it maps onto stated duties |
| B5 | "Why leave a puzzle studio for this role, and why now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Selection scaffold: your real reasons in your own words. A strong answer names what this role has that your current one doesn't (the JD's two titles and its ownership of the review are the obvious hooks) and avoids criticising your current studio. If you don't know yet why Saltmarsh in particular, say what drew you to the posting instead | The motivation check every Skeptic runs. Tagged JD because the honest pull is the JD's scope |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Those monthly retention numbers: which metrics, and how were they calculated?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot, in your own words: which retention measures they were; whether you calculated them or presented numbers someone else prepared; what they were sensitive to; and the assumption behind them you'd defend least. If you don't know how they were counted, say so plainly. That is a credible answer, and a guessed method is not | F7 is your retention evidence and the first thing a metrics-minded interviewer will test. EXP because it checks what was actually yours |
| C2 | "What changed after one of those presentations?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if a decision changed because of the numbers, say what changed and what part was yours. If you can't point to one, say so plainly and describe what the numbers were used for, as far as you know | Tests whether F3's reporting connects to action, which is what the review this role owns is for |
| C3 | "How would you tell whether an event caused a retention bump or just coincided with one?" | CASE | [generic] | Compare against a baseline: the same period before, players who didn't take part, a holdout if the setup allows one. Check for seasonality and anything else that shipped in the same window. Say what you would and wouldn't claim, and how confident you'd be | The JD's KPI line (F3, F7) as reasoning, not record |
| C4 | "Was your puzzle title a live-service game the whole four years? What did live operations look like there?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if it ran as a live service throughout, describe it in your own words. If part of the time it didn't, say which part plainly and stay with the weekly content-drop calendar you ran for the last two years | F5's open question. The JD's "3+ years producing live-service games" is a headline requirement |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc: four years as associate producer at a puzzle-game studio; for the last two, you ran the weekly content-drop calendar for your main title; you wrote the release checklist your QA team still uses; you presented the monthly retention numbers to the studio head. End on why this role is the next step, in your words | The opener nearly every round has. EXP because each beat will be followed up |
| D2 | "What are you playing at the moment?" | CO | [generic] | Pick a live-service mobile game you actually play. Say one thing you noticed about how it runs events. If you've played Saltmarsh's titles, use one of them, and only if you have | Casual but scored. Generic because the pack couldn't research Saltmarsh's titles |
| D3 | "Tell me about that release checklist." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Beats from the quote: you wrote it, and QA still uses it. Answer slot: describe what's in it, in your own words. If you also ran it with QA on releases, say how; if QA ran it after you wrote it, say so and stay with having written it | F4 and F8, and probably your strongest single line, so expect warm follow-ups |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Mid-event, community is hearing that players are angry about difficulty. Where's the line between you and community, and what do you do?" | CASE | [generic] | Community owns the player conversation and you own the decision path. Get the evidence (volume, which players, data), bring in design, decide whether to hotfix, tune or hold, agree the message with community, and log it for the review | The JD names community among the teams you coordinate. This tests how you handle that hand-off |
| E2 | "Tell me about a time you disagreed with someone in another discipline about the schedule." | VAL | [grounded] | Selection scaffold: a real disagreement over timing, scope or readiness, with a named stake, what you said, and how the working relationship ended up. If no such time comes to mind, say so plainly, then give the nearest thing from your calendar work, or how you would handle it | The JD's coordination line, asked as a behavioural question. The theme comes from the JD and no story is assumed |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has already run events on a monetized title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "never worked on a game with in-app purchases" | Pause. Concede first: "I haven't worked on a game with in-app purchases." Then hold on two facts: two years running the weekly content-drop calendar for your main title, and the release checklist QA still uses. Close with the ramp plan from B3. If pushed twice, don't add anything; repeat the plan | Combines F9 with time pressure. Hold-then-concede on what your quotes carry |
| G2 | "That content calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: "I ran it." Answer slot: which parts you decided (dates, sequencing, what went in) and which were handed to you. If others chose the content and you scheduled it, say so plainly. That is still running a calendar | The attribution probe aimed at F1 and F6, the core of your case |

### H. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you told leadership something they didn't want to hear." | VAL | [generic] | Selection scaffold: a real moment, a named stake, what you said, and whether it landed. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem. Saltmarsh's values could not be checked, so it isn't mapped to them |
| H2 | "Tell me about a release that went wrong." | VAL | [grounded] | Selection scaffold: what broke, what you did in the moment, and what changed afterwards. If no release went wrong on your watch, say so plainly, then describe how you'd run the first hour of one | The theme comes from the JD's release line. No incident is assumed |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A1, B1, B4, G2 |
| Coordinate design, art, engineering and community on each update | A3, B1, E1, E2 |
| Own the post-event review and its KPIs | A5, A2, C2, C3 |
| Manage the release checklist with QA | A4, D3, H2 |
| 3+ years producing live-service games or apps | C4, B5, D1 |
| Experience running a content calendar | A1, G2, D1 |
| Comfortable with player-retention metrics | C1, C2, C3 |
| Clear written communication | A5, D3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your role as Head of Live Ops, what would you want this person to have taken off your plate by month three?" | Tied to his own role. It shows you're thinking about his load, and it tells you what success means |
| R2 | "How do the two titles' calendars interact today: shared art and engineering, or separate teams?" | Goes straight at the part of the role that's new to you (F1), framed as diligence |
| R3 | "What does a good post-event review look like here, and who reads it?" | Shows you take the review seriously, and tells you which KPIs you'd own (F3) |
| R4 | "How does monetization fit into event planning on these titles, if at all, and who owns it?" | Gets an honest read on how much F9 matters, without presupposing anything |
| R5 | "Where does the release process with QA break down most often today?" | Points at your strongest line (F4) and invites a problem-solving conversation |
| R6 | "What's the next stage after this conversation?" | Practical, and it surfaces any exercise or panel you'd need to prep for |

---

## Prohibited claims

The pack won't coach these, so don't say them under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material says the main title's weekly content-drop calendar |
| Led a team, or managed people | Negative you stated, F2 | "I haven't led a team." |
| Owned post-event reviews or chose the KPIs | Inflated form of F3 | F3's quote at its own scope. The material says you presented the monthly retention numbers. A5's and C1's slots stay inside that |
| Built or calculated the retention analysis | Inflated form of F7 | F7's quote at its own scope. C1's slot asks whether you calculated them, and either branch is fine |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist QA still uses |
| Four years producing live-service games | Inflated form of F5 | F5's quote at its own scope. C4's slot covers which years were live |
| A producer title above associate | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." |
| Experience with in-app purchases or monetized events | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." |

---

## Sources

- Provided: the JD text and your background, both from your message.
- Searches sent (all four refused, because web search permission wasn't granted):
  - `Saltmarsh Games values`: refused
  - `Saltmarsh Games interview process producer`: refused
  - `Saltmarsh Games mobile studio news 2026`: refused
  - `Tobias Wrenfield Saltmarsh Games`: refused
- No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Search refused. It would have themed the values questions (H) and decided whether a values cheat sheet exists |
| 2. `Saltmarsh Games interview process producer` | unavailable | Search refused. The loop rests on your words (one 60-minute session); it would have added any later rounds or a case format |
| 3. `Saltmarsh Games` strategy and recent news | unavailable | Search refused. It would have grounded a CO question in their titles and recent moves; D2 is generic instead |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Search refused. It would have produced an interviewer read, adjusted the persona weights and tailored R1 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Whether Tobias is your future manager → persona weights confirmed or recomputed, and banks reordered if he's a peer or skip-level
- The recruiter's prep notes (focus areas, or any exercise such as a calendar plan or a presentation) → a build section for each graded deliverable
- Web search permission → Saltmarsh's values, interview format and recent news, an interviewer read for Tobias, and a CO question grounded in their titles. A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) can follow on request
- Your prep hours before Friday → a prioritised prep schedule sized to that time
- Your answers to the slots in F1, F2, F3, F5 and F7 (more than one title; which teams; whether you calculated the retention numbers; whether the title was live-service throughout) → those rows, and B1, C1 and C4, become story-mapped answers
- A redacted copy of the release checklist, or one of the retention decks → F4 and F7 move from medium toward high, and D3 and C1 get concrete detail you can point to
- A tuesday-dossier.md from an underwriting pass would add an evidence-checked objection and binding strategies per gap. This pack is complete without one
