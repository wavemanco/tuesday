No dossier present. Reading the files the playbook names.
I've built your prep pack for Friday. It's saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-canned-d89c07b3/saltmarsh-games_live-operations-producer_interview_pack.md`.

- **The format:** Saltmarsh's careers page describes this round as "the Outage Hour". It's one 60-minute interview with the hiring manager: first you work through a simulated outage during a live event, then there's a values conversation. There's no take-home. You said your hour is with Tobias, so the pack treats him as the hiring manager running both halves.
- **The question to rehearse most** is C1: "two titles, four disciplines, you've run one title's calendar and never led a team." The guidance has you say "I haven't led a team" up front, then hold on the weekly content-drop calendar you ran for two years.
- **Your strongest match with Saltmarsh** is the release checklist. One of their three published values is "Leave the Build Greener", which says every release should leave the checklist better than it found it. And from what I found, Tobias was previously a QA lead.
- **No in-app purchases:** In September Saltmarsh announced it's moving both titles to a season pass with one shared events calendar from February 2027. Expect monetisation to come up. C2 gives you an honest answer that doesn't stretch your retention work to cover it.
- **The interview is tomorrow.** The pack opens with a five-step plan for tonight. Everything after that is insurance.

I only saw search previews for the Project Larkspur announcement and for Tobias's GDC 2026 talk, *Patch Notes Are a Promise*. I couldn't open either page. The talk listing was also on an unusual web address. Check both quickly before you mention them to him.

If you'd like a practice run, I can play Tobias as the Skeptic on C1, or run the outage exercise live.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** the Outage Hour, Friday, 60 minutes. Saltmarsh's interviewing page says every loop is a recruiter call, then "the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation." You said your 60 minutes are with Tobias, so this pack treats him as the hiring manager running both halves. "There is no take-home."

---

## How to use this pack

Two axes. **Personas** describe *how* a question is asked: who's asking and in what register. **Types** describe *what* is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether what you've done shows Saltmarsh's *published* values |
| EXP | Whether your stated experience holds up under detail, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know where the company is heading |
| CASE | How you structure a live problem from the actual role |

The guidance is scaffolding, not a script. Say it in your own words, and only say what you actually did. Each guidance cell uses only the sentences you gave me. Where the role will push past those sentences, the cell gives you an **answer slot** instead: two honest branches, and both are good answers.

---

## Prep triage: the interview is tomorrow

1. **C1, aloud, three times.** It's the highest-ROI question in this pack (two titles, four disciplines, never led a team). Time each run at under two minutes.
2. **The tabletop structure (A1, A2).** Learn the order *clarify → stabilise → communicate → decide → record* until you can say it without thinking. The first half of the hour is a live case.
3. **The values cheat sheet (section below).** One story or honest branch for each of the three values. Your strongest one is B3, the checklist.
4. **D1.** Be ready to say which retention numbers you presented and what part of them was yours.
5. **Pick three reverse questions.** Make one of them R2, the one about Tobias's own path.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, not a live-events calendar across two titles, and your words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's planning line makes a probe on how the calendar was planned likely. If what went into each week was yours to decide, say how you decided, in your own words. If it was set for you, or there was no such step, say so plainly and describe how you ran it. Two titles is a plan you describe, never a past you claim |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show who worked on each content drop or how the work reached players. Answer slot: the JD's coordination line makes this probe near-certain. If running the calendar meant working with design, art, engineering or community to land a drop, say which teams and what you did with them, in your own words. If it didn't, or that work sat with someone else, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is not owning a post-event review, and the bridge shouldn't be stretched. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if any of those presentations covered how a particular drop or event performed, say what they covered. If none did, say so plainly and say what you would put in a post-event review |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | You wrote it and QA still uses it. Your material doesn't say whether you ran it release by release. Words: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage" makes a probe on the ongoing part likely. If you ran it with QA each release, or revised it, say how, in your own words. If that was QA's job once it was written, say so plainly and stay with writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | The four years and the weekly drops are in your material. It doesn't say whether the game was run as a live service, so that call is this pack's reading, not yours. Answer slot: if the main title was a live-service game, say so and what made it one, in your own words. If you wouldn't call it that, say so plainly and describe the weekly drops. Your title is "associate producer", every time |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Expect a probe anyway, because there's nothing to inspect behind it. Lead with the quote in its own terms: weekly, the main title, two years. A named thing you ran beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in what the JD asks. Your quote puts retention numbers in front of the studio head every month. The probe will be on the numbers themselves (D1). Know which measures they were and say plainly what part of them was yours |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | transferability | A checklist a team still uses is adjacent evidence of clear writing, not a writing sample, and it is the only written thing in your material. In the tabletop, your written communication will be judged live (A2, A4): short, plain, and only what's known. Bring your own writing example only if you have one |

---

## Reading the interviewer

From public professional sources only (see Sources):

- **Career pattern:** Head of Live Operations at Saltmarsh, previously a QA lead at a console studio.
- **Published theme:** a GDC 2026 talk, *Patch Notes Are a Promise*, arguing that a live team is judged by how often its patch notes describe what actually shipped. That matches Saltmarsh's published value "Ship the Patch Not the Promise".

What follows from that:

1. **Expect the accuracy theme in the tabletop.** When you draft player-facing comms in A2, say what's known, what isn't, and when you'll update. Don't give an ETA you can't stand behind.
2. **The release checklist is your strongest common ground.** Someone from QA will listen closely to F4. The mirror opportunity is vocabulary rather than career path: F4's quote, "Wrote the release checklist our QA team still uses." Say it as is, and let him ask about it.
3. **Expect probes on whether the checklist actually gets followed.** His background suggests he'll care whether a process is used, not just written. That's E2's and G2's territory.
4. **No shared career jump is offered.** QA lead to Head of Live Ops isn't the move you're making, so the pack doesn't pretend it is. R2 asks him about it instead.

---

## Persona weights

The loop is established by Saltmarsh's interviewing page: one 60-minute session with the hiring manager, a live-incident tabletop and then a values conversation. The weights follow from that, from hiring-manager priors (Case/Strategist plus Skeptic), and from Tobias's published theme.

| Persona | How it shows up Friday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The whole first half: a simulated outage during a live event | Highest. The page names the tabletop, and hiring managers buy capability through live problems | Clarify → stabilise → communicate → decide → record, thinking aloud. Challenge one premise respectfully |
| B. Values / Behavioral | The second half: the values conversation | High. Documented by the loop source. Three published values, so expect one question on each | One story or honest branch per value (cheat sheet). "We" for context, "I" for your part |
| C. Skeptic | Woven through both halves: one title versus two, coordination, monetisation ahead of the season pass | High. Hiring-manager prior, and F1, F2 and the in-app-purchase line are visible gaps | Rehearse C1 until it's boring. Bridge only from what you said, name the limit plainly, then give a ramp plan |
| D. Data-Driven Prober | KPI and retention follow-ups, in the tabletop debrief and on F7 | Medium. The JD names KPIs and retention metrics | Know what you can and can't say about how your numbers were counted |
| E. Pressure | The tabletop clock: "you have ninety seconds", "the studio head wants a number" | Medium-low. A simulated outage builds in time pressure | Pause, restate, hold what you know, concede what you don't |
| F. Conversational | Opening minutes, "walk me through your journey" | Low, but still scored | A 90-second arc built only on what you've said |
| G. Peer Evaluator | Cross-team scenarios inside the tabletop: art, design, community and QA at odds | Low as a persona (he's the manager, not a peer), but the JD's coordination line makes the content likely | Propose principles for the seam. Don't claim to know Saltmarsh's teams |

---

## Question banks

### A. Case / Strategist: the Outage Hour tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're 36 hours into a weekend event on one of our titles and the reward service goes down. Players can't claim. Walk me through your first 30 minutes." | CASE | [inferred] | Clarify first: which title, which players, since when, what exactly fails (claiming only, or progress too)? Stabilise: who in engineering is on point, and can the event clock pause so players don't lose time? Communicate: a short player-facing note that says only what's known, plus an internal channel. Decide: whether a make-good is needed, decided once scope is known rather than promised now. Record: start the incident log the post-event review will need. Say the structure out loud before filling it in. The question needs no claim about your past, so the guidance makes none | The interviewing page names a live-incident tabletop on an outage during a live event. The specific scenario is this pack's illustration of that format, so it's [inferred]. CASE because it scores structure under a live problem |
| A2 | "Engineering says the fix is two hours. Community wants to post an ETA now. What goes out, and who signs off?" | CASE, JD | [grounded] | Hold to "we announce what is built, not what is hoped" (Saltmarsh's value). Post what's confirmed: the issue, that it's being worked on, and when the next update will come. Not the two-hour ETA as a promise. Name who signs off: you propose the wording, and the owner Saltmarsh designates approves it (ask who that is, rather than assuming). Write the actual three-line note aloud; it's the written-communication requirement tested live | Grounded on the published value and Tobias's talk theme. JD content (F8, written communication), CASE delivery |
| A3 | "The outage ate two days of a seven-day event. Do you extend, compensate, or both, and what does that do to the rest of the calendar?" | CASE, JD | [inferred] | Name the trade-off: extending protects players' chance to finish but pushes the next event. Compensating keeps the calendar but may not feel fair to players mid-progress. Reason from "when the calendar and the players disagree, the players win", then say what it costs downstream and who you'd tell. Ask whether the second title's calendar is affected too. The guidance makes no claim about your past | Tests F1's requirement as a decision. [inferred] because the scenario is this pack's. Ties to Players Before Plans |
| A4 | "The event's over. What's the headline of your post-event review, and which KPIs go in it?" | CASE, JD | [generic] | Structure: what was planned versus what shipped; what happened to players (participation, completion, and retention for players who took part, compared with those who didn't); the outage's timeline and its effect; what the release checklist should change. Keep the headline to one sentence a busy reader can act on. This is a plan for the problem, not a claim about reviews you've run | F3's requirement asked as a live task. [generic] because the KPI set is a role-family pattern, not a Saltmarsh fact |
| A5 | "From February both titles share one events calendar under a season pass. What breaks first, and what would you put in place before it does?" | CO, CASE | [grounded] | Show you know about Project Larkspur: two titles, one shared calendar, a season pass, a single live-ops group. Structure: collisions (two titles competing for the same weekend and the same art and engineering time), dependencies (season-pass beats that both titles must hit), and review (one post-event format across both). Propose one guardrail per risk. This is reasoning, not a record. If monetisation comes up, C2 is the honest answer | Grounded in Saltmarsh's Project Larkspur announcement (Sources). The CO question most candidates won't have researched |

### B. Values / Behavioral: the values conversation

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. The calendar you ran is the natural place to look. Pick a time a planned drop moved, changed or was pulled because of what players did or said. It needs what players were doing, what the plan said, and what changed, with your part in it said exactly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Players Before Plans, by its own wording. No sentence you gave carries this story, so it's a scaffold, not a story map |
| B2 | "Tell me about a time something was announced before it was ready." | VAL | [grounded] | Selection scaffold. Pick a time an announcement, date or note got ahead of what was built. It needs what was said, what was actually ready, and what you did about the gap. If no such time comes to mind, say so plainly, then say how you'd stop it happening: announce what's built, date what's confirmed | Ship the Patch Not the Promise, and Tobias's talk theme. No candidate claim made, so the label stands alone |
| B3 | "Every release should leave the checklist better than it found it. What have you done to a release process?" | VAL, EXP | [grounded] "Wrote the release checklist our QA team still uses." | Your strongest values story. Story-mapped on F4, with two beats the quote states: you wrote the release checklist, and your QA team still uses it. Tell those in your own words. Answer slot: the value is about improving the checklist release after release, so expect a probe on that. If you revised it after a release, say what changed and why. If you didn't, or it hasn't changed, say so plainly and stay with writing it and its continued use | Leave the Build Greener names the checklist itself. F4 is the closest match between your material and Saltmarsh's published values |
| B4 | "When have you had to tell someone senior something they didn't want to hear?" | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. You presented to the studio head every month, so that's a natural place to look. If one of those presentations, or anything else, carried news that wasn't welcome, say what it was, how you said it, and what happened next. It needs a real stake and the relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing, or how you'd handle it | Persona stem that fits Ship the Patch (announcing only what's true). F7's quote gives you a senior audience; it doesn't give you a story, so this is a scaffold |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This is two titles and four disciplines. You've run one title's calendar, and you've never led a team. Why are you ready?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "4 years as an associate producer at a puzzle-game studio." "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI prep in this pack.** Agree first, without apology: "I haven't led a team." Then hold on what your material carries: "For the last two years I ran the weekly content-drop calendar for our main title", across four years as an associate producer. Answer slot: the JD's coordination line means the follow-up will be "who did you work with to land each drop?" If design, art, engineering or community were part of that, say which and what you did with them, in your own words. If not, say so plainly and stay with the calendar. Then the ramp, said as a plan: how you'd learn the second title's rhythm and the four teams in your first weeks. **Follow-up 1:** "So it's one game?" Hold: one main title, two years, weekly. **Follow-up 2:** "Why should I take that risk?" Concede the scale is new, hold the calendar, end on the plan. Never stretch the quote to fit two titles | F1, F2 and your stated "never led a team" are the visible gap. A hiring manager will ask some version of this. JD because it scores the stated requirement |
| C2 | "From February it's a season pass. What's your experience with in-app purchases?" | JD, CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment, said once and calmly: "I haven't worked on a game with in-app purchases." Then a plan, never a past: what you'd want to learn first about how the season pass and the shared calendar interact, and whom you'd learn it from. Don't reach for retention to cover monetisation. They're different kinds of work, and a bridge here is what a skeptic tests | Project Larkspur makes monetisation a near-certain topic, and you've stated the gap yourself. Rehearsing the honest version beats improvising one |
| C3 | "Was your puzzle game a live-service game?" | JD | [inferred] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: F5's requirement makes this likely. If the main title was a live-service game, say so and what made it one, in your own words. If you wouldn't call it that, say so plainly and describe the weekly content-drop calendar you ran for two years. Either branch is honest. Keep your title as "associate producer" | F5's discovery gap. [inferred] because "live service" is the JD's frame, not yours |
| C4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose a real one. The one your material supports saying is the in-app-purchase line: "I haven't worked on a game with in-app purchases." Follow it with what you'd do in the first month. If another part of the JD feels weaker to you, name it in your own words, with a plan. Don't pick a fake weakness | Skeptic stem. Calibrated candour scores better than bluffing in front of someone who owns the function |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The monthly retention numbers you presented: which measures were they, and how were they counted?" | EXP, JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: the JD's retention line makes this the first probe on F7. Name the measures in your own words. If you know how they were counted, say how. Name the assumption behind them you'd defend least, if you know one. Say exactly what part was yours: preparing, analysing or presenting. If the numbers came to you already counted, say so plainly and stay with presenting them. "I don't know how that was counted" is an honest branch | Defending the numbers is the prober's job. F7 is your only retention evidence, so it gets probed hardest |
| D2 | "If you owned the post-event review here, which three KPIs would you report for a weekend event, and why those three?" | JD, CASE | [generic] | Pick three and give the reason for each. For example: participation (did players show up?), completion (was it tuned right?), and retention for players who took part versus those who didn't (did it matter afterwards?). Name the weakest assumption in each, such as what counts as "participated". This is a plan, not a record | F3's KPI ownership, asked as reasoning. [generic] because the KPI set is a role-family pattern |
| D3 | "Did a retention number you presented ever change what went on the calendar?" | EXP, JD | [grounded] "Presented the monthly retention numbers to the studio head." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: the JD links KPIs to the review, so expect this. If a number changed a decision about the calendar, say what changed and what part was yours, in your own words. If it didn't, or that link wasn't made where you worked, say so plainly and say how you'd make it here | F3 and F7 together: the bridge between reporting numbers and acting on them |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ninety seconds. The outage is still live and the studio head wants to know how many players are affected. You don't have the number. What do you say?" | CASE | [generic] | Don't invent a number. Say what you know, what you don't, and when you'll know it: "I don't have a confirmed count. Here's what we know, and I'll have a number by" and name a specific time. Then hold through the push: "Just give me a ballpark." Give a range only if you can say what it's based on. Otherwise hold, and concede only that the count is pending | Tabletop time pressure. It tests the Ship the Patch Not the Promise reflex under stress |
| E2 | "That checklist QA still uses: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote the release checklist our QA team still uses." Answer slot: if anyone contributed to it, or it built on an earlier version, say so and say which part was yours. If it was yours from start to finish, say so plainly. Hold through a second push by returning to the quote, never by adding to it | Persona stem. F4 is your best line in front of a QA-background interviewer, so it's the one most worth defending precisely |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc using only these four beats: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist your QA team still uses; the monthly retention numbers you presented to the studio head. Answer slot: why live ops and why Saltmarsh, now. Say it in your own words. If the season-pass move or the values page drew you, say so | Biography opener. Casual, still scored |
| F2q | "What are you playing at the moment? Any live event you've seen go badly?" | CO | [generic] | Have one real example ready. Describe it from what players saw, and say what you'd have done differently. Keep it under a minute, and don't criticise a Saltmarsh title | Rapport question that's really scoring how you think about live events |

### G. Peer Evaluator (cross-team content)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Art says the event banner won't be ready for Thursday. Design won't move the date. You're in the middle. What happens?" | CASE, JD | [generic] | Clarify the real constraint (is it the banner, or the whole beat?). Lay out options: a placeholder asset, a slimmer beat, or moving the date. Name who decides and by when. Close the loop with community. Propose a principle (decide early, in one place, with the trade-offs visible) rather than claiming to know Saltmarsh's teams. The guidance makes no claim about your past | F2's coordination requirement, asked as a live problem |
| G2 | "The checklist says no and the calendar says go. How do you handle that with QA?" | CASE, JD | [grounded] "Wrote the release checklist our QA team still uses." | Reason it through: what the checklist item protects, what slipping costs players, and who has the call. Lean on "every release leaves the codebase and the checklist better than it found them": if the item was wrong, fix the checklist; if it was right, the date moves. Answer slot: if this happened with the checklist you wrote, say what happened and what part was yours. If it didn't, say so plainly and answer it as a plan | F4's requirement plus Leave the Build Greener. Likely to land with a QA-background interviewer |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A3, A5, C1 |
| Coordinate design, art, engineering and community (F2) | C1, G1 |
| Own the post-event review and its KPIs (F3) | A4, D2, D3 |
| Manage the release checklist with QA (F4) | B3, E2, G2 |
| 3+ years producing live-service games or apps (F5) | C3 |
| Experience running a content calendar (F6) | C1, B1 |
| Comfortable with player-retention metrics (F7) | D1, D3 |
| Clear written communication (F8) | A2, A4 |

---

## Values cheat sheet

From Saltmarsh's published values page (Sources). The names are official, so use them exactly.

| Value | What it means | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F1, from "I ran the weekly content-drop calendar for our main title for the last two years." as the place to look. Selection scaffold: a time a planned drop changed because of what players did. If none comes to mind, say so plainly, then give the nearest thing or how you'd handle it (B1) |
| Ship the Patch Not the Promise | Announce only what's built, not what's hoped | No quote carries a story. Selection scaffold: a time an announcement got ahead of what was ready, and what you did. If none comes to mind, say so plainly and describe how you'd prevent it (B2, A2) |
| Leave the Build Greener | Every release should leave the code and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Your strongest mapping. Whether you revised it later is an answer slot (B3) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When both titles move to one calendar in February, what's the first thing you'd want this role to have settled?" | Shows you've read the Project Larkspur announcement, and tells you what the job really is in month one |
| R2 | "You came to live ops from QA. What from QA do you most want your producers to carry?" | Tied to his own path. It turns the interview into a peer conversation and tells you how he'll judge you |
| R3 | "What does a good post-event review look like here, and who reads it?" | You'll own this. Asking shows you're thinking about who it's for, not just the template |
| R4 | "How do you track whether what you announce matches what shipped?" | His talk's theme and a published value, asked as a working question rather than flattery |
| R5 | "Is there anything from the tabletop you'd want me to go deeper on?" | Invites correction while you can still answer it, and shows composure |
| R6 | "What would make someone in this role a clear success at 90 days?" | Gets the real bar, which the JD can't give you |

---

## Prohibited claims: what this pack won't coach

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated: "Never led a team, and never worked on a game with in-app purchases." | "I haven't led a team." No slot |
| Has worked on in-app purchases, monetisation or a season pass | A negative you stated, same sentence | "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar across multiple titles | Inflated form of F1 | F1's quote at its own scope: one main title, weekly content drops, two years. The limit is this pack's observation; the two-title part is a plan, never a past |
| Owned post-event reviews or the KPIs they report | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers to the studio head. D3's slot stays inside those presentations |
| Managed the release process or QA | Inflated form of F4 | F4's quote: you wrote the release checklist your QA team still uses. B3's and E2's slots stay inside the checklist |
| Producer (rather than associate producer) | Inflated form of "4 years as an associate producer at a puzzle-game studio." | "Associate producer", every time |

---

## Sources

**Provided:** the job description and your background, both pasted in your message. No CV file.

**Searches and fetches:**

| Call | Query or URL | What came back |
|---|---|---|
| Search | `Saltmarsh Games values` | https://saltmarshgames.com/values |
| Fetch | https://saltmarshgames.com/values | The three values and their one-line definitions |
| Search | `Saltmarsh Games interview process producer` | https://saltmarshgames.com/careers/interviewing |
| Fetch | https://saltmarshgames.com/careers/interviewing | Loop structure: recruiter call, then the Outage Hour (60 minutes with the hiring manager, a tabletop, then values); no take-home |
| Search | `Saltmarsh Games mobile studio news 2026` | https://saltmarshgames.com/news/project-larkspur (search snippet only, not fetched): September 2026; both titles (Tidepool Tactics and Lantern Row) move to a season pass with one shared events calendar from February 2027; per-title event teams retired in favour of one live-ops group |
| Search | `Tobias Wrenfield Saltmarsh Games` | https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only, not fetched): GDC 2026 talk; Head of Live Operations; previously a QA lead at a console studio |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet; banks B1–B3; A2 and G2 framing |
| 2. Saltmarsh Games interview process | yes | Established the loop (one 60-minute session: tabletop, then values). Bank A and the persona weights follow it |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur: A5, C2, R1 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read, R2, R4, and the accuracy theme in A2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your CV** → each evidence cell can quote a CV line, and any role or achievement missing from your message becomes material for B1, B2 and B4.
- **Your own answers to the answer slots** (who you worked with on each drop, whether the game was live-service, which retention measures you presented, whether you revised the checklist) → F2, F3, F4, F5 and F7 move from slots to story-mapped answers, and C1, C3, D1, D3 and B3 get firmer holds.
- **Anything the recruiter told you about the Outage Hour** (the scenario's title, who plays which role, whether you write anything) → tabletop guidance tuned to the real format.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → reads Tobias's talk and the Larkspur announcement in full, and adds a grounding brief on the two titles.
- **A tuesday-dossier.md from an earlier fit assessment** → the top objection would come from verified evidence rather than this pack's reading, with fixed constraints on what each weak area may claim.
