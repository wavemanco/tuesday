Building your prep pack from the dossier now. I'm running a few company searches first: values, interview process, strategy.
I've built your prep pack for the 45-minute hiring-manager conversation. It's saved as `Quartzline_product-manager-platform-apis_interview_pack.md`. It's built from your dossier and the three statements about your experience that you confirmed in it.

The web searches about Quartzline (values, interview process, recent news) were blocked by permissions. So the pack has nothing company-specific yet, and the case questions use general wording rather than Quartzline's own terms.

**What to rehearse first:**
- **A1 (most important).** This is the objection your dossier predicted: you've never held a PM title or owned a roadmap. Admit that first. Then describe your integration record in your confirmed words. Then give your 90-day plan, which is B4.
- **A2 and A4.** On owning a roadmap and setting priorities for engineering squads, give a plain "I haven't done that" with no bridge. The dossier marked these as gaps to acknowledge, not to talk around.
- **B1–B5.** These are live problems from the role. Your record doesn't carry roadmap ownership, so this is where you can show how you'd think about it.

Today is Thursday the 12th. If the interview is today, rehearse just A1 and B4.

Want me to play the hiring manager on A1 and push back on your answers?
I can also add what this prep uncovered to your tuesday-dossier.md, so it carries into later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager (from your message). Interviewer not named.
**Built from:** your `tuesday-dossier.md` (v1.1, dated 2026-08-14). No web research made it into this pack, because the searches were refused (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question gets asked (who's asking, in what style). **Types** describe *what* it's scored on.
- Type key:
  - **JD**: can you do the job as listed, gaps included
  - **EXP**: do your past claims hold up under scrutiny, and what was actually yours
  - **CASE**: a live problem from the role, scored on structure and reasoning
  - **VAL**: whether your past behaviour matches the company's values
  - **CO**: company and strategy knowledge (none in this pack, because research didn't run)
- **Fit-snapshot rows are F1–F9. Question IDs are A–H by persona.** Questions point to the snapshot row they draw on.
- **Answer slots** are instructions for what to say in the interview. You don't need to reply to them here. Each one has two honest branches. Pick the one that's true.
- Guidance is scaffolding, not a script. Say it in your own words. Nothing about your past goes in unless it's one of your three confirmed sentences or your own answer to a slot.

---

## Fit snapshot

Your three confirmed sentences from the dossier (`handoff_to_mock_interview.verified_candidate_evidence`) are quoted exactly as written. The dossier's confidence notes on them are recorded in the Confidence column, not in the quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD, dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | Bridge, framed the way the dossier frames it: this is adjacent work and never PM experience. State the limit first, sourced from prohibited_claims: "Having held a product manager title or role". The words: "I haven't held a product manager title." Then the quotes at their own scope: "I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live, and I wrote the internal integration playbook my team uses." Describe the work and let the interviewer draw the conclusion. Never call it product management |
| F2 | "Own the roadmap for the partner-facing API platform" (JD, dossier role_profile responsibilities) | none given | none | [grounded] | capability | The dossier records this as a gap with no credible evidence (uncertain_or_weak_areas, acknowledge_gap), so there's no bridge. The words come from prohibited_claims: "Having owned a product roadmap". Say: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as something you've done: how you'd learn this roadmap, its partners and its squads in the first weeks (B4) |
| F3 | "Shipped API or platform products" (JD, dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | Your material covers client integrations of the vendor's REST APIs. It doesn't cover shipping an API product. Keep the words at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, covering scoping through UAT and go-live." Answer slot: the JD's shipped-products line makes a probe on go-live likely. Say what part of go-live was yours, in your own words. If a step wasn't yours, say so plainly and go back to the integrations you led |
| F4 | "Technical fluency: API docs, schemas" (JD, dossier role_profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote touches this requirement (REST API integrations, architecture included) but doesn't say whether you worked from API docs or schemas. Answer slot: the JD's docs-and-schemas line makes a probe here likely. If you read or wrote API docs or schemas on those integrations, say which and how, in your own words. If you didn't, say so plainly and go back to the integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" (JD, dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote touches customers (client integrations). It says nothing about engineering or sales. Answer slot: if those integrations had you working with engineering or sales, say who and on what, in your own words. If they didn't, say so plainly and stay with the client side |
| F6 | "Run discovery with integration partners" (JD, dossier role_profile responsibilities) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Confirmed, but with limited inspectable proof, so expect a probe. Raise the limit yourself before you're asked: say plainly what you can and can't show from these sessions. Keep the words at the quote's scope: "Every quarter I ran roadmap-input sessions that fed client evidence to product." Feeding evidence to product is not the same as running discovery, so don't stretch it. Answer slot: the JD's discovery line makes a probe on how that evidence was gathered likely. If you gathered it yourself, say how, in your own words. If you didn't, say so plainly and stay with the sessions |
| F7 | "Agile delivery experience" (JD, dossier role_profile R5) | none given | low | [grounded] | discovery | The dossier sets the strategy for this one as clarify. None of your confirmed sentences speaks to agile. Answer slot: the JD's agile line makes this probe likely. If you've worked in agile delivery, say how it ran and what your part was, in your own words. If you never worked that way, say so plainly. Either way, end with: "Here's what I'd want to confirm about how you run delivery here" |
| F8 | "Write specs and drive delivery with two engineering squads" (JD, dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | Leading the requirements stage of integrations is next to writing specs, but it isn't the same thing. Driving two squads also brushes a prohibited claim (prioritization for a squad). Keep the words at the quote's scope. Answer slot: the JD's spec line makes a probe on what the requirements stage produced likely. If it produced documents engineers built from, say what they covered, in your own words. If it didn't, say so plainly and stay with the integrations |
| F9 | "Define and track adoption metrics" (JD, dossier role_profile responsibilities) | none given | none | [grounded] | discovery | Your material doesn't show metrics work. Answer slot: if you defined or tracked any measure on the integrations, say what was counted, in your own words. If you didn't, say so plainly, then say what you would measure first for a partner API (B3) |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years PM experience (must-have) | A1, A4, E1 |
| R2: Shipped API or platform products (must-have) | A3 |
| R3: Technical fluency, API docs and schemas | C2 (slot), D3 |
| R4: Stakeholder management across engineering, sales, customers | G2, B5 |
| R5: Agile delivery | C4 |
| Own the roadmap | A1, A2, B2, B4 |
| Run discovery with integration partners | C3 |
| Write specs and drive delivery with two squads | B2, C2 (slot), G1 |
| Define and track adoption metrics | B1, B3, A4 |

---

## Persona table

| Persona | How it shows up in this round | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the title and roadmap gap | Highest. Hiring-manager rounds lean Case and Skeptic by default, and the dossier names a specific objection aimed at F1 and F2 | Rehearse A1 until it bores you. Concede first, then bring only your quoted record, then the ramp plan |
| Case / Strategist (B) | Live problems from the job: adoption, prioritization, partner conflicts | High. A hiring manager is buying capability and will test it on their own roadmap | Clarify, set the objective, segment, approach, metrics, risks. Think aloud. Push back on one premise per case, politely |
| Data-Driven Prober (C) | Digs into the "30+" figure and the roadmap-input sessions | Medium. A headline number (F1) and a medium-confidence claim (F6) are exactly what probing targets | Know how the figure was counted, or say you don't. Raise the F6 limit yourself before it's dug out |
| Conversational (D) | Friendly openers: your journey, your playbook | Medium. You described the round as a conversation, and casual questions still get scored | A 90-second arc built only from your three sentences |
| Pressure (E) | "That's not product work" challenges | Low to medium. A natural follow-up to the main objection | Hold through two follow-ups, then concede the specific point. Never upgrade the claim to win the exchange |
| Peer Evaluator (G) | The seam with the two squad leads | Low. No peer is in the room, but the squad-lead authority question (an open risk in the dossier) shows up here | Propose principles for the seam rather than claiming to know where it is. Turn it into reverse question 1 |
| Values / Behavioral (H) | A behavioural "tell me about a time" question or two | Low. No values-style round was detected, and Quartzline's published values weren't in hand | Pick real stories using the selection criteria, and keep the honest branch available |

---

## Question banks

### A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | **The highest-ROI rehearsal in this pack. The dossier names this objection.** Three beats in under 90 seconds. (1) Concede first and plainly: "You're right. I haven't held a product manager title, and I haven't owned a roadmap." (2) Then what you have done, at the quotes' scope: "I've led 30+ end-to-end client integrations of the vendor's REST APIs, through scoping, requirements, architecture, UAT and go-live, and I wrote the internal integration playbook my team uses." Stop there and let them draw the connection. (3) The ramp, said as a plan (B4). First follow-up ("So it isn't product work?"): hold. "No, it's integration work, and that's what I'm offering." Second follow-up ("The other candidate has owned a roadmap"): concede that exact point ("They have, and I haven't") and don't fold on the integration record. Then ask reverse question 1 | F1 and F2 are the must-have gaps, and the dossier named this as the likeliest objection. It's JD because it scores R1 directly. Every negative in the wording has a dossier source, so it's rehearsed exactly as written |
| A2 | "This PM sets priorities for two engineering squads. Have you done that?" | JD | [grounded] prohibited_claims: "Having set prioritization for an engineering squad"; uncertain_or_weak_areas: acknowledge_gap | "No. I haven't set prioritization for an engineering squad." Then how you'd approach it, as a plan: who you'd talk to first, how you'd make the trade-offs visible, and what you'd want to know about where your authority ends and the squad leads' begins. Don't add "but I did something similar". The dossier found nothing to bridge to here | F2 is the gap the dossier says to acknowledge rather than bridge, and a hiring manager hiring for two squads will test it. It's JD because it scores a stated responsibility |
| A3 | "What API or platform product have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Don't accept the premise and don't fight it. Answer at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, covering scoping through UAT and go-live." Answer slot: say what part of go-live was yours, in your own words. If a step wasn't yours, say so plainly and go back to the integrations you led. Never describe them as products you shipped | F3 is R2, a must-have where the evidence is adjacent. It's JD because the question is the requirement itself |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap" | Give a real one: roadmap ownership. "Owning the roadmap. I haven't owned a product roadmap." Then one line of the B4 plan. Don't offer a fake weakness. Only name adoption metrics as well if your honest answer to F9's slot is that you haven't tracked any | It's the Skeptic's standard stem, and F2 gives it a true answer. It's JD because it asks you to grade yourself against the listed job |
| A5 | "Why product management, and why now?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your reasons, in your own words. The material doesn't contain your motivation. If the roadmap-input sessions are part of the reason, that's the sentence you can stand on: "I ran quarterly roadmap-input sessions feeding client evidence to product." Say plainly what you can and can't show from them. If your reason is something else, say that instead. Never use "I've basically been doing PM work" | This is the "why now" probe, and F6 is the only quote that touches product. It's EXP because it tests whether your story holds together; secondarily JD |

### B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Say partner adoption of the API stalls a year in. How would you work out why?" | CASE | [generic] | Clarify first: what counts as adoption here (keys issued, first successful call, production traffic, retention)? Then segment: new versus existing partners, and where in onboarding they stall. Hypotheses: onboarding friction, docs, missing endpoints, commercial terms. Name the data you'd pull first and one cheap test. Then ask how they measure it today (reverse question 2). No claim about your past is needed, so don't make one | From the JD's adoption-metrics line (F9's requirement), asked as a live problem. Generic because it's a pattern for the problem, not a fact about Quartzline |
| B2 | "Two squads, one quarter, three partner requests that conflict. How do you decide what goes on the roadmap?" | CASE | [generic] | Clarify goals and who decides (this connects to reverse question 1). Set criteria: partner impact, fit with the platform, effort, strategic bets. Lay out the trade-off openly with the squad leads, decide or escalate according to the authority you have, tell the partners who lose out, and revisit next quarter. Frame it as how you would do it, not how you have done it (A2, F2) | From the JD's roadmap and two-squads lines. It tests prioritization as reasoning, which is where you can score despite F2 |
| B3 | "How would you define adoption metrics for a partner-facing API?" | CASE | [generic] | A funnel: activated, first successful call, production traffic, retained or expanding. Add a speed measure (time to first call) and guardrails (error rates, support tickets). Choose one headline metric and explain why. Name the metric you'd trust least, and why, before they ask. Say you'd first learn today's baseline | From the JD's adoption-metrics line (F9). JD content delivered as a case. It's your best chance to show thinking where your material shows no metrics work |
| B4 | "What would your first 90 days look like?" | CASE | [generic] | Learn: partners, squads, the current roadmap, the adoption baseline. Listen: one-to-ones with squad leads, sales and key partners. One small visible win. By around day 90, a proposed roadmap direction with decision rights agreed. This is the ramp plan A1, A2 and A4 refer to, so keep it identical across all of them | The ramp plan is the second half of every answer about the F2 gap, so rehearse it once and reuse it |
| B5 | "A big partner wants a custom endpoint. The squad leads say it breaks the platform model, and sales says the deal depends on it. What do you do?" | CASE | [generic] | Find the underlying need. Check whether other partners share it. Options: a general-purpose endpoint, configuration, a partner-specific workaround, or no. Get engineering and sales looking at one trade-off together, then decide or escalate according to your authority, and close the loop with the partner. Present the "no" as protecting the platform | Covers R4 (engineering, sales and customers in one problem) as a live case. It's CASE first and JD second |

### C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Thirty-plus integrations. How are you counting that?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, in your own words: how the 30+ was counted, what it's sensitive to, which assumption behind it you'd defend least, and which part was yours. "I don't know exactly how it was counted" is an honest answer. Don't round it up, and don't give any count beyond the one in the quote | The headline figure in F1, and probers target headline figures. EXP because it tests the claim directly |
| C2 | "Walk me through one of those integrations end to end." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one integration and tell it through the stages the quote names: scoping, requirements, architecture, UAT, go-live. Use your own words for what happened at each. Answer slot (the JD's docs-and-schemas line): if you read or wrote API docs or schemas on it, say which and how; if not, say so plainly and continue the walkthrough. Answer slot (the JD's spec line): if the requirements stage produced a document engineers built from, say what it covered; if not, say so plainly | F1 is your strongest evidence, and F4 and F8 depend on it. EXP because it tests what was actually yours |
| C3 | "Tell me about those quarterly roadmap-input sessions." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats from the quote: you ran them, they were quarterly, and they fed client evidence to product. Raise the limit yourself early by saying plainly what you can and can't show from them. Answer slot (the JD's discovery line): if you gathered that client evidence yourself, say how, in your own words; if not, say so plainly and stay with the sessions | F6 is medium confidence, and the dossier expects a probe on it. EXP because it tests attribution |
| C4 | "What's your experience with agile delivery?" | JD | [grounded] | The dossier sets the strategy as clarify. Answer slot: if you've worked in agile delivery, say how it ran and what your part was, in your own words. If you never worked that way, say so plainly. Then: "Here's what I'd want to confirm about how you run delivery here," and ask about sprint cadence, who owns the backlog, and how partner requests enter it | This is F7, and the JD lists it as preferred. JD because it scores a listed requirement |

### D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in your own words, built only on these three: the integrations, the playbook, and the roadmap-input sessions. End on why this role (A5). Tenure, titles and employer names come from you, not from this pack. Present it as adjacent work and never use the PM label | The usual opener. It sets up how the rest of the conversation sees you, so the F1 framing has to hold from the first minute |
| D2 | "You wrote an integration playbook. What's in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats from the quote: you wrote it, and your team uses it. What's in it is yours to describe. The dossier notes the playbook was provided as inspectable proof. If you can share a version without breaking confidentiality, offer to | F1's most inspectable evidence, and a concrete artifact is stronger than adjectives. EXP because it's your own work |
| D3 | "What are you playing with in API tooling these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick something you're genuinely using or reading about. If nothing comes to mind, say so plainly and go back to the integrations you led. Don't name a tool you haven't used | F4's technical-fluency requirement, asked casually. Casual questions are still scored |

### E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That's integration work, not product work. Convince me." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | Don't take the bait. "It is integration work. I'm not claiming it was product management." Then the quote in one sentence, then your reason for wanting the role (A5). Hold through two follow-ups by repeating the record, never by inflating it | Tests the dossier's main condition, that your experience is positioned as adjacent and never as PM experience, under pressure. JD because it's R1 again |
| E2 | "Thirty-plus integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The quote says "led", so keep that verb and don't upgrade it. Answer slot: say which parts of the integrations were yours and which were the team's, in your own words. If some stages were other people's, say so plainly. Use "we" for the team and "I" for what you led | The attribution stress test on F1's figure. EXP because it's about attribution honesty |

### G: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "The squad leads own a lot here. Where's the seam between you and them, and what happens when you disagree?" | CASE | [generic] | Propose principles rather than claiming to know the seam: PM owns the problem, the partner evidence and the priorities (whatever authority the role actually carries); squad leads own the how and the estimates. In a disagreement, make the trade-off explicit, decide by agreed criteria, and escalate cleanly. Then ask reverse question 1 | The dossier's open risk about decision authority will come up here. CASE because it's a live working problem, not a question about your past |
| G2 | "Tell me about working across engineering, sales and customers." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The quote covers the customer side: client integrations, end to end. Answer slot: if those integrations had you working with engineering or sales, say who and on what, in your own words. If not, say so plainly and stay with the client side | This is F5 (R4). JD because it scores a listed requirement |

### H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you didn't back down, and a working relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does support, or how you would handle it | A standard behavioural stem. Generic because Quartzline's values weren't in hand |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a real customer, a real metric you let slip, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does support, or how you would handle it | Partner-facing roles tend to get this stem. Generic for the same reason as H1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier. The job description says the PM owns the roadmap but doesn't show it, and you need to know whether you'd actually own what you're being hired to own. It also comes across as diligence, not doubt |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier. Adoption metrics are listed as a responsibility but no baseline is given, so this tells you whether you'd inherit a measure or have to build one |
| R3 | "What does a strong first six months look like for this PM?" | Gives you their definition of success to test against your B4 plan |
| R4 | "How do partner requests reach the roadmap today?" | Shows you think in terms of process, and tells you where discovery currently happens |
| R5 | "What's the hardest trade-off the two squads are facing right now?" | Shows you the real roadmap tension, and invites a short live case you can think through |
| R6 | "For someone coming from integration work rather than a PM seat, where would you expect the ramp to be steepest?" | Invites the objection out into the open while you're still in the room to answer it, and it's candid in the way A1 asks you to be |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | prohibited_claims: "Having held a product manager title or role". Say: "I haven't held a product manager title." Then F1's quotes at their own scope |
| Having owned a product roadmap | Dossier prohibited_claims; uncertain_or_weak_areas acknowledge_gap | prohibited_claims: "Having owned a product roadmap". Say: "I haven't owned a product roadmap." No answer slot and no bridge. A ramp plan only (B4) |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | prohibited_claims: "Having set prioritization for an engineering squad". Say: "I haven't set prioritization for an engineering squad." No answer slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not something for you to say about yourself: the material shows client integrations, not shipping a product. A3's slot stays on go-live |
| Ran product discovery with partners | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: feeding client evidence to product is not running discovery. C3's slot stays on how the evidence was gathered |
| Calling the integration work "product management" | Inflated form of F1, and the dossier's main condition | Describe the integrations in the quote's own words and let the interviewer draw the conclusion |

---

## Sources

- **Provided:** `tuesday-dossier.md`, envelope v1.1, generated 2026-08-14 by job-underwriter. The dossier supplied `role_profile` (the JD equivalent: requirements R1–R5, responsibilities, unknowns), `decision` (context only), and `handoff_to_mock_interview` (verified evidence, weak areas with their allowed strategies, the A1 objection, risks, employer questions, prohibited claims). The dossier has no `evidence_map`, so the fit grades for F3–F6, F8 and F9 are this pack's own, worked out from your three confirmed sentences. F1, F2 and F7 use the dossier's grades. The dossier is about three months old.
- **The round:** your message ("a 45-minute conversation with the hiring manager"). This is a loop source, and it establishes the session, so persona weights use the hiring-manager priors, not an archetype fallback. No values-style round was detected.
- **Searches sent:**
  - `Quartzline company values`: refused
  - `Quartzline interview process product manager`: refused
  - `Quartzline partner API platform news 2026`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have provided official value names for a values check and themes for VAL questions. H1 and H2 stay generic |
| 2. `Quartzline interview process` (product) | unavailable | The search was refused. It would have checked whether a values or case round comes later in the loop. Not needed for this session, whose format your message establishes |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have provided a CO question grounded in current strategy. Without it, the Case bank is generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there's no interviewer read |
| 5. Representative JD | skipped | The dossier's role_profile supplies the requirements |

---

## Upgrade menu

- **Allow web search, or paste Quartzline's careers/values page and a recent news item.** This would add a CO question on current strategy, Case questions (B1–B5) phrased in Quartzline's own vocabulary, and real values themes for H1–H2.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) for a strategy brief and recent organisational context. Only if you want it.
- **The hiring manager's name.** This would add an interviewer read, persona weights based on their public career, and a reverse question tied to their path.
- **The recruiter's prep email**, if there is one. It would cover any stated focus areas or a pre-announced exercise.
- **How much prep time you have before the interview.** This would add a prioritised prep schedule.
- **Your own answers to the answer slots, told to me here outside a drill.** These would regrade F3–F9 and the questions that draw on them (A3, C2, C3, C4, G2, A4). F4, F5 and F9 have the most room to move.
- **The CV behind your confirmed claims.** This would let your tenure, titles and employer names be quoted in D1 rather than left for you to fill in.
