Quick update: I'm loading the interview-prep playbook and its rules. Next I'll do some targeted research on Stripe, then build you a full prep pack.
I've built your prep pack, but it's generic, not Stripe-specific. All four web searches I tried (for Stripe's values, its interview process, its current strategy and a sample job posting) were blocked by permissions. I also had no job description or resume from you. So nothing in the pack comes from Stripe's own pages, and I've labelled every question as generic.

**What's in it:**
- **22 practice questions**, grouped by interviewer style: case, skeptic, behavioral, numbers-focused, peer, pressure and conversational.
- **Answer guidance for each question.** It describes what kind of story to pick and what it needs, and ends with an honest fallback if you don't have one. It doesn't script answers about experience I haven't seen.
- **The question to rehearse most: B1**, "Which part of this role would you be weakest at on day one?" It comes with three likely follow-ups and how to hold your answer through them.
- **A worksheet of eight typical Product Ops requirements.** Write one true sentence per row about something you've actually done; that becomes your story bank.
- **Seven questions for you to ask the interviewers**, plus a list of what each missing input would add to the pack.

**What I assumed:** I don't know how many sessions your final round has or who runs them. I weighted it like a typical large tech company's final, which leans on case and behavioral questions. That's a common pattern, not a description of how Stripe runs its finals.

If you allow web search, I can pull Stripe's published values and current strategy, and re-theme the behavioral and "why Stripe" questions around them.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is in your final round: how many sessions, and is each one with your future manager, a peer, a skip-level or someone cross-functional? Has your recruiter mentioned any focus areas, or a case or presentation to prepare? The answer would let me split this into one mini-pack per session.

Could you paste the job description and your resume, or say skip? With them, the worksheet becomes a real fit analysis and every answer is built on your actual experience.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-3-denied-db81a832:
- Stripe_product-operations-manager_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager at Stripe, final round

- **Company:** Stripe
- **Role:** Product Operations Manager
- **Round:** final round. Who you will meet, and how many sessions there are, is not known yet
- **Built from:** your message only. No job description, no resume, and no web research: every search was refused, so nothing in this pack comes from Stripe's own pages (see Sources)

---

## How to use this pack

Two axes organize everything:

- **Personas** are *how* a question is asked: the interviewer's style and register.
- **Types** are *what* is being scored.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behavior shows the company's published values, not generic virtue |
| EXP | Whether the claims on your resume hold up when probed, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge: whether you can think at the company's level |
| CASE | A live problem from the role, scored on structure and reasoning |

Provenance labels: `[grounded]` traces to something you provided or to cited research. `[inferred]` is derived from a representative source. `[generic]` is a role-family pattern with no claim about Stripe or about you. **This pack has no materials, so every row is `[generic]`.** It is still useful rehearsal, but nothing in it is a fact about Stripe's process or strategy.

**The guidance is scaffolding, not a script.** Most cells here are *selection scaffolds*: they tell you what kind of story to pick and what it needs. You supply the story from your own experience, in your own words. If you have no such story, every scaffold ends in an honest branch, so use it.

---

## Fit snapshot (self-assessment worksheet)

Without a JD or resume, this is a worksheet. The requirements are typical product-operations responsibilities written from no source. They are not quoted from any Stripe posting. Before your interview, fill in the evidence column for yourself: write one true sentence per row about something you did. Those sentences become your story bank for everything below.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Turning feedback from customers and frontline teams into prioritized input for product teams (typical role-family requirement, no source) | none given | none | [generic] | discovery | Strong evidence: a feedback loop you ran or contributed to, plus something that changed in a product because of it. Pick a time feedback you gathered or routed reached a product decision. It needs a named source of the feedback, what you did with it, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your experience does include, or how you would set the loop up |
| F2 | Launch readiness: preparing support, sales, risk and other teams for a new product or feature (typical role-family requirement, no source) | none given | none | [generic] | discovery | Strong evidence: a launch you helped prepare, with your part named. Pick a launch or rollout you worked on. It needs what was launching, which teams had to be ready, and what part was yours. If none comes to mind, say so plainly, then give the nearest coordination work you have done, or walk through how you would run one |
| F3 | Defining and tracking operational metrics, often with SQL or dashboard comfort (typical role-family requirement, no source) | none given | none | [generic] | discovery | Strong evidence: a metric you defined or tracked, how it was counted, and a decision it informed. Pick a number you tracked and can explain end to end. If you cannot say how it was counted, that is a fine thing to say. If none comes to mind, say so plainly and describe how you would choose one |
| F4 | Designing and scaling repeatable processes, tooling and documentation (typical role-family requirement, no source) | none given | none | [generic] | discovery | Strong evidence: a process you built or changed, with its before and after. Pick one. It needs the problem, what you changed and who used it afterward. If none comes to mind, say so plainly, then give the nearest thing you did, or how you would approach one |
| F5 | Influencing product, engineering and go-to-market teams without direct authority (typical role-family requirement, no source) | none given | none | [generic] | discovery | Strong evidence: a time you moved a team you did not manage. Pick one. It needs the team, what you wanted and how it ended, including if it ended only partly your way. If none comes to mind, say so plainly and give the nearest example |
| F6 | Clear written and spoken communication for cross-functional and senior audiences (typical role-family requirement, no source) | none given | none | [generic] | discovery | Strong evidence: a document or update you wrote that others acted on. Pick one you could describe in a sentence. If none comes to mind, say so plainly and describe how you would write for this audience |
| F7 | Prioritizing across competing requests in ambiguous situations (typical role-family requirement, no source) | none given | none | [generic] | discovery | Strong evidence: a time you had more requests than capacity and chose. Pick one. It needs what competed, how you decided, and who you told no. If none comes to mind, say so plainly and walk through how you would decide |
| F8 | Familiarity with payments or financial products, often listed as a plus (typical role-family requirement, no source) | none given | none | [generic] | discovery | Strong evidence: domain exposure you can name. If you have some, pick the most relevant piece and say where it came from. If you have none, say so plainly and give a concrete learning plan, stated as a plan |

---

## Persona table

**How the weights were set.** "Final round" names a round but does not say how many sessions it has or who runs them, so it does not establish the loop. The weights below rest on a **fallback archetype, big-tech structured** (recruiter, then hiring manager, then skills or case, then behavioral or values, then a committee). Values/Behavioral and Case get the most weight. This archetype is a pattern for large, established tech companies. It is **not** a documented description of how Stripe runs its final round. Because finals are often several back-to-back sessions with different relationships, the weights are blended across personas rather than tuned to one interviewer. Recalibrate as soon as you know your schedule.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live problems from the role: plan a launch, diagnose a spike, prioritize | High. The archetype tilts Case up, and a hiring manager in a final usually tests capability on live problems | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Respectfully challenge one premise per case |
| Skeptic (bank B) | Quiet probing of gaps, plus why leave, why here, why now | High. Final rounds exist to de-risk the hire, and with no resume in this pack the likeliest objection is inferred from the role, not from your history | Rehearse the most predictable objection until it is boring. Build bridges only from things you actually did, and state the limit plainly where you have none. Give a concrete ramp plan |
| Values / Behavioral (bank C) | STAR-shaped scenario probes, often from someone outside product ops | High. The archetype puts a values or behavioral round somewhere in the loop. Stripe's published values are not in hand, so these questions use standard behavioral themes and are not mapped to Stripe's values | "We" for context, "I" for your contribution. Choose stories where the hard truth actually landed. Where none did, say so rather than supplying the ending |
| Data-Driven Prober (bank D) | Reads your resume line by line and asks how each number was counted | Medium. Ops roles are metric-heavy, and any number on your resume is a target | Know what you can and cannot say about how each number was counted. Name the weakest assumption before they do. Say plainly when you do not know |
| Peer Evaluator (bank E) | A PM, support lead or fellow ops person probing seams and credit | Medium. Product ops sits between teams, so a peer is a plausible final-round interviewer | Reciprocity framing. Propose principles for the seam instead of pretending to know where it is |
| Pressure / Stress (bank F) | Interrupts, time-boxes, questions motives | Low to medium. It is not a typical archetype tilt, but any interviewer can time-box a question | Pause, restate the question, anchor in what you actually did. Hold through two follow-ups, then concede specifically |
| Conversational (bank G) | A friendly opener or closer that feels unscored | Medium in frequency, low in depth. Nearly every session opens this way | A pre-scripted 90-second arc. Treat casual questions as scored. Always have reverse questions ready |

---

## Question banks

IDs are letter-by-persona so drills can reference them. **Highest-ROI prep in this pack: B1.**

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're launching a new merchant-facing feature to a first group of users next quarter. Sketch the operational readiness plan. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, what can go wrong for them, who answers when it does, and what success looks like. Then the plan: which teams need to be ready (support, sales, risk or compliance, documentation), what each needs (training, escalation path, macros, FAQs), the go or no-go criteria, and the feedback loop for the first weeks after launch. Close with two or three launch-health metrics and the risk you would watch most. The question needs no claim about your past, so the guidance makes none | Covers F2, F4 and F6. It is the most typical live problem for this role family. CASE because it scores structure, not a record |
| A2 | "Support contacts about one product jumped 20% week over week. Diagnose it." | CASE | [generic] | Check that it is real first: did tagging, routing or the denominator change? Then segment by contact reason, customer segment, geography and channel. Lay the timeline against releases, incidents and pricing or policy changes. Form one hypothesis, say how you would test it, then cover fix, prevent and who you would tell. Say the structure aloud before filling it in | Covers F3. Taken from the Case persona's diagnosis stem. Tests whether you check the measurement before chasing the cause |
| A3 | "Three product teams each say their request to your team is the top priority. How do you decide?" | CASE | [generic] | Clarify what each request is for and what happens if it waits. Name your criteria (customer impact, risk, effort, deadline, strategic alignment) and who arbitrates if the criteria tie. Say how you would tell the teams whose request waits, and when you would revisit | Covers F5 and F7. Prioritization under competing asks is the everyday reality of product ops in this role family |
| A4 | "Product managers say they never see the feedback frontline teams collect. Design the system that fixes that." | CASE | [generic] | Clarify where feedback lives today and what PMs actually need from it. Then the design: intake (one place, a light taxonomy), synthesis (who reads it and how often), routing (to which PM, in what format), and closing the loop back to frontline teams. Name one metric that shows it is working and one way it could fail, such as volume without signal | Covers F1 and F4. The feedback loop is central to product ops in this role family |
| A5 | "What would you put on a dashboard for the operational health of a product, and which number would you look at first?" | CASE | [generic] | Group the metrics: volume (contacts, cases), quality (resolution, repeat contacts), speed (time to resolve), customer outcome (satisfaction, churn signals), and leading versus lagging. Pick one to look at first and say why. Then name the weakest assumption behind that metric, in your own words, before they ask | Covers F3. JD content in CASE delivery. Rehearses the weakest-assumption move on a metric you chose yourself |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI rehearsal in this pack.** Pick one requirement from F1 to F8 where your own evidence is thinnest, ideally a real one rather than a disguised strength. Name it in one sentence, in your own words, and then stop. Next, say what you have already done toward it, only if something true exists. If nothing does, skip that beat rather than inventing one. Then give a concrete ramp plan, stated as a plan rather than a past: who you would learn from, what you would read or shadow, and by when. **Follow-ups to rehearse:** (1) "How long until it isn't a weakness?" Give a timeline you believe and say what it depends on. (2) "What if we needed it in week one?" Keep the plan, and add what support you would ask for. (3) "Isn't that the core of the job?" Hold your position that the gap is learnable, and concede plainly what you do not yet know. Never fold into "actually I'm fine at it" | This question arrives in some form at almost every final. A rehearsed, non-defensive answer turns the biggest risk into a credibility gain. It is inferred from the role, not from your history, so recalibrate it once you have filled in the fit snapshot |
| B2 | "Why leave, why here, why now?" | CO | [generic] | Three short parts, each drawn from your own true reasons. Why leave: forward-looking, with nothing negative about your current employer. Why here: use only facts about Stripe that you have verified yourself from its own pages or from people you have spoken to. This pack holds none, so do not borrow claims from memory or forums. Why now: what in your path makes this the right next step. Aim for 60 to 90 seconds | The Skeptic's core motivation-consistency probe. CO because "why here" scores homework, and here the homework has to be yours |
| B3 | "Product ops means different things at different companies. What's your definition, and what wouldn't you do?" | JD | [generic] | Give a one-sentence definition you believe. Then two or three things product ops does in your view, and one or two it should not own, with the reason, such as owning a roadmap or replacing PM judgment. Ask, or offer to hear, how this team draws the line | Covers F7. It tests clear thinking about the role's boundaries. It asks for a view rather than a record, so it presupposes nothing about your past |
| B4 | "How much payments or financial-products exposure have you had, and how would you get up to speed on what you haven't seen?" | JD | [generic] | If you have exposure, name the most relevant piece and where it came from, in your own words, at its real size. If you have none, say so plainly. Either way, end with a concrete learning plan: which internal docs, which teams to shadow, which concepts first. Do not reach for jargon to sound fluent | Covers F8, the role-family plus-skill most likely to be probed at a payments company |

### C. Values / Behavioral

Stripe's published values are not in hand, so these are not mapped to them. With the values page, each would be re-themed to a named value.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they did not want to hear. It needs a named stake, how you said it, and what happened, including if it did not land. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle it | A standard values-round stem. Covers F6 |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a customer need and a number you were measured on pulled in different directions. It needs the customer, the metric, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would decide | A standard values-round stem. Product ops sits exactly at the meeting point of customer and metric |
| C3 | "Tell me about a time you and another team disagreed about how work should be split, and how it ended." | VAL | [generic] | Pick a real disagreement with a team you did not manage. It needs what each side wanted, what you did, and how it ended, including a partial or lost outcome told straight. The relationship afterward matters as much as the result. If no such time comes to mind, say so plainly and give the nearest example | Themed from the Peer persona's seam-and-disagreement stem. Covers F5 |

### D. Data-Driven Prober

These are premised on a number from your own resume. Pick one before your interview.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick the number on your resume you're proudest of. Walk me through how it was counted." | EXP | [generic] | Say how it was counted, in your own words: what was measured, over what period, from what source. If you do not know how it was counted, say so plainly. That is an honest answer, and a better one than a method you cannot defend. If your resume has no such number, say so and describe a result in words | Every headline number on a resume is a target for a prober. Covers F3 |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it yourself, in your own words, before they find it, and say why it is the weakest. If you do not know what it rests on, say so plainly | The weakest-assumption move turns a gotcha into a credibility gain. The prober's second-level follow-up |
| D3 | "What's that number measured against, and what part of it was yours?" | EXP | [generic] | Say what it is compared to, if you know, and exactly which part was yours, at its real size. "We" for the team's result, "I" for your piece. If you do not know the comparison, or the result was mostly the team's, say so plainly | Tests the denominator and attribution, the two places resume numbers most often break |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam. Propose principles: one owner per decision, a shared definition of done, disagreements raised early and in writing, and escalation as a last resort, used together. Then ask them where the seam rubs today | A Peer persona stem. Covers F4 and F5. Product ops lives on seams |
| E2 | "How do you handle credit when work spans teams?" | JD | [generic] | Say your principle in a sentence, then give an example only if a true one comes to mind. If none does, say how you would do it. Keep "I" for your part and name the others' parts | A Peer persona stem. Covers F5. It tests whether you add to or subtract from a peer's standing |
| E3 | "What would you need from me in your first month?" | JD | [generic] | Name two or three concrete things, such as context, introductions or access to data. Then flip it: what you would bring their team in the same month | Peers price what a hire costs them. Reciprocity framing answers the real question |

### F. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give two or three reasons drawn from your own real experience, in your own words. Concede in one clause what an internal candidate has that you do not, such as context. Do not knock the internal candidate. If interrupted, finish your sentence calmly, then answer the interruption | A Pressure persona stem. Tests composure and a held position under a time-box |
| F2 | "That result, how much of it was actually you?" | EXP | [generic] | Asked about whatever story you just told. Hold: restate exactly what your part was. If pushed twice, concede specifically ("the X was the team's; the Y was mine") and never fold on the part that was really yours. If it was mostly the team's, saying so plainly is the strong answer | A Pressure persona stem. Rehearses the hold-then-concede structure |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc you have written and practiced: where you started, two or three turning points, and why they lead to this role. Make each beat something you actually did. End on the bridge to product ops, without asserting what your past proves | Opens most sessions. It is scored on economy and clarity even when the register is casual |
| G2 | "What are you actually playing with these days in tools for operations work?" | JD | [generic] | Name something real you have used or are learning, and one honest observation about it. If nothing comes to mind, say what you are curious about and why. Do not name-drop tools you have not used | A Conversational persona stem. Casual questions about the role's hot topics are still scored |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Feedback into product | A4 |
| F2 Launch readiness | A1 |
| F3 Operational metrics | A2, A5, D1, D2, D3 |
| F4 Process and tooling | A1, A4, E1 |
| F5 Influence without authority | A3, C3, E1, E2 |
| F6 Communication | A1, C1 |
| F7 Prioritization | A3, B3 |
| F8 Payments domain | B4 |
| Stripe strategy (CO or CASE) | none. Research did not run, so no question rests on Stripe's current strategy. B2's "why here" is the only CO item, and it relies on facts you verify yourself |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does product ops own here that it might not own somewhere else?" | It shows you know the role varies, and the answer tells you what you are really being hired for |
| R2 | "What would a great first 90 days look like in this role?" | It signals you are thinking about impact, and the answer is your rubric if you get the job |
| R3 | "Where does the friction sit today between product, ops and the frontline teams?" | It shows seam awareness, and it invites the interviewer to share real problems instead of a pitch |
| R4 | "Can you tell me about a recent launch where operations made the difference, or where it was missing?" | It grounds the conversation in a real example and shows you think about outcomes |
| R5 | "How does the team decide what product ops says no to?" | It shows judgment about scope, which is the hardest part of this role family |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer interviewer. It reframes you as someone who adds capacity |
| R7 | "What's the thing you'd most want the person in this role to fix?" | It is direct and lets them hand you the problem they care about most |

---

## Prohibited claims

There are **no entries**. You have shared no resume, no job description and no account of your experience, so no sentence of yours exists that this pack could stretch, and no stated gap exists to guard. That is different from a pack that found something to inflate and declined to.

What will apply as soon as you share material:

- No claim stretches beyond a sentence you actually wrote or said: not in scope, verb, kind, or who you were in the transaction.
- No invented metric, team size, launch or outcome.
- No borrowing of Stripe's or the posting's vocabulary to describe your own past.

---

## Sources

- **Provided:** your message ("final-round interview at Stripe for a Product Operations Manager role")
- **Searches sent:**
  - `Stripe operating principles`: refused
  - `Stripe interview process product operations onsite`: refused
  - `Stripe 2026 annual letter strategy stablecoins agentic commerce`: refused
  - `Stripe "Product Operations" job posting responsibilities`: refused
- **Fetches sent:** none

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | The search was refused. It would have supplied Stripe's published values by name, re-themed bank C to them, and, together with a documented values round, unlocked a values cheat sheet |
| 2. `Stripe interview process product operations` | unavailable | The search was refused. It would have tried to name the final round's sessions and replaced the fallback archetype's persona weights |
| 3. `Stripe strategy` / recent news | unavailable | The search was refused. It would have supplied current priorities for a strategy-grounded CO or CASE question and real material for B2's "why here" |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form. There is no interviewer read |
| 5. representative `Product Operations Manager` JD | unavailable | The search was refused. It would have replaced the `[generic]` requirements F1 to F8 with quoted, `[inferred]` ones |

---

## Upgrade menu

- **The actual job description text** → F1 to F8 replaced by the posting's own requirements, quoted and `[grounded]`. Every requirement gets a JD-tagged question, and the scaffolds can rest on answer slots tied to the posting's lines
- **Your resume** → the fit snapshot stops being a worksheet. Each row gets your own sentences, banks A to G get story-mapped guidance on your real experience, D1 to D3 target your actual numbers, and B1 becomes evidence-derived instead of inferred. The prohibited list gets real entries
- **Your final-round schedule: how many sessions, and who runs each (manager, peer, skip-level, cross-functional)** → per-session mini-packs with their own persona weights and reverse questions, instead of one blended pack. If your final is several sessions, send the schedule
- **Interviewer names** → a reading-the-interviewer section from their public professional footprint, tuned persona weights, and one reverse question tied to each interviewer's own career path
- **Recruiter guidance (focus areas, or any declared case, presentation or take-home)** → a build section for each graded deliverable. This is usually one email to your recruiter
- **Allowing web search** → Stripe's published values by name (bank C re-themed, plus a values cheat sheet if a values round is documented), any public description of the loop, and current strategy for a grounded CO question. All five accounting rows above would move
- **A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), once search is allowed** → a grounding brief on Stripe's current priorities, competitive frame and recent moves, which feeds differentiator questions such as "why Stripe over a competitor, in 60 seconds"
- **How much prep time you have** → a prioritized prep-triage schedule sized to it
- **One true sentence per fit-snapshot row, from you** → those rows and every question drawing on them (A1 to A5, C1 to C3, D1 to D3, E2, F2, G1) move from scaffolds to story-mapped guidance
- **A sanitized artifact of your work, such as a launch plan, process doc or dashboard you built** → evidence confidence can rise above medium on the rows it supports
- **A tuesday-dossier.md from an earlier evaluation of this role, if you have one** → verified evidence, an evidence-derived highest-ROI objection, and a prohibited-claims guardrail carried in automatically
