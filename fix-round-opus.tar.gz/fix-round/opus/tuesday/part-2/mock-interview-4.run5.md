Reading the dossier against the interview-prep playbook is done. Next I'm running a short research pass on Quartzline, then I'll build the pack.
I've built your prep pack for Thursday's 45-minute hiring-manager conversation, and it's saved as `quartzline_product-manager-platform-apis_interview_pack.md`. It has 21 practice questions with answer guidance, plus a fit table, reverse questions and a list of claims to avoid. It's built only from your dossier: all three web searches I tried were refused, so there's nothing on Quartzline's values, interview process or recent news.

The pack is built around the objection your dossier predicted: "you've never held the PM title or owned a roadmap." That's question A1 and the most valuable thing to rehearse. The answer has three parts:
1. **Concede plainly:** you haven't held the PM title and haven't owned a roadmap.
2. **Bridge with what you've done:** you led 30-plus client integrations from scoping to go-live, and you wrote the playbook your team uses. Call it adjacent work and never call it PM experience.
3. **Close on a ramp plan:** how you'd get up to speed in the first months.

A few points to watch:
- **Keep the roadmap-input sessions out of the roadmap answer.** Your dossier says to simply acknowledge the roadmap gap, not bridge it. Using those sessions there turns input you gave product into an ownership claim. They have their own question (A5), and there you should mention the thin paper trail before you're asked.
- **Watch the scope of your own lines.** Say "30-plus" or "at least 30", not "more than 30". Your playbook is the one "my team uses", not one the company uses. "Seven years" appears in the dossier's summary but not in your verified evidence, so the pack leaves your years and titles for you to say.
- **Your dossier is from August 14.** Check the live posting still matches before Thursday.
- **Today is Thursday the 12th.** If the interview is today rather than next week, rehearse A1 and the reverse questions R1 and R2 first.

I didn't need to ask you anything to build this. The end of the pack lists what more input would add, such as the hiring manager's name, recruiter notes, your CV or permission to search the web.

Say the word and I'll play the skeptical hiring manager on A1 with live follow-ups.
I can also update your `tuesday-dossier.md` with the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, Thursday. The hiring manager would be your future manager. Their name wasn't given.
**Built from:** your underwriting dossier (`tuesday-dossier.md`, version 1.1, dated 2026-08-14). No web research: every search was refused this run (see Sources).

---

## How to use this pack

**Personas** describe *how* a question gets asked: who is asking and in what style. **Types** describe *what* is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows values, ideally the company's published ones |
| EXP | Whether your stated experience holds up under scrutiny, and what was actually yours |
| JD | Whether you can do the job as written, gaps included |
| CO | Company and strategy knowledge (none in this pack: research didn't run) |
| CASE | Structure and reasoning on a live problem from the role |

The guidance is scaffolding, not a script. Say it in your own words. Each Provenance cell shows the exact sentences from your dossier that a row rests on, so you can see how far the evidence goes. Anything past those sentences is an **answer slot**: you fill it from your own memory, or you say plainly that it wasn't yours or never happened.

The three sentences everything rests on, as your dossier records them (`verified_candidate_evidence`):

- **V1:** "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (high confidence, inspectable: the integration playbook was provided)
- **V2:** "Wrote the internal integration playbook her team uses" (high confidence, inspectable)
- **V3:** "Ran quarterly roadmap-input sessions feeding client evidence to product" (medium confidence: confirmed, with limited inspectable proof, so expect a probe)

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | transferability | Bridge allowed, with its limit named: the dossier's condition is that this is positioned as adjacent and never as PM experience. Open with the acknowledgment backed by `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title." Then V1 at its own scope: "I've led 30-plus end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live." The limit is the pack's observation, not words for you: the material shows integration leadership, not PM work. Answer slot: the JD's "Run discovery with integration partners" line makes a probe on scoping likely. If scoping or requirements decisions were yours to make, say which ones and how you decided, in your own words. If none were, say so plainly and stay with the integrations you led |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibility; R1 sub-claim) | none given | none | [grounded] | capability | The dossier records this as an `acknowledge_gap` area. The words come from `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap, and I haven't set an engineering squad's priorities." After that comes a ramp plan, said as a plan and never as a past. No bridge here: the V3 roadmap-input sessions are never offered as an answer to this. No answer slot either |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | V1 reaches client integrations of the vendor's APIs, taken through go-live. It doesn't reach shipping an API product, and the words stay at V1's scope: "I led 30-plus end-to-end client integrations of the vendor's REST APIs, through to go-live." Answer slot: R2 makes a probe on what actually shipped likely. Say what went live at go-live and which part of it was yours to decide, in your own words. If none of it was yours to decide, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | The quotes mention REST APIs, architecture and a playbook. They don't show work with API docs or schemas. Answer slot: R3 makes a probe on docs and schemas likely. If you worked from the vendor's API docs or schemas during scoping or architecture, say how, in your own words. If you didn't, say so plainly. B4 tests this live either way |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [inferred] | discovery | The quotes show clients (V1) and client evidence going to product (V3). Engineering and sales aren't in them. V3 is confirmed but has limited inspectable proof, so mention that limit yourself before a prober finds it: describe the sessions rather than pointing to an artifact. Answer slot: R4 makes a probe on engineering and sales likely. If you worked with the vendor's engineering or sales teams on those integrations, say how and what was yours, in your own words. If you didn't, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | The dossier marks this `clarify`, and no verified entry speaks to agile itself, so nothing is quoted. Answer slot: the JD's "Agile delivery experience" makes the probe likely. If your integrations ran in sprints or another agile cadence, say how that worked and what part was yours, in your own words. If you never worked that way, say so plainly. Then: "Here's what I'd want to confirm about how this team defines agile delivery" |
| F7 | "Define and track adoption metrics" — JD (dossier role_profile responsibility) | none given | none | [grounded] | discovery | The material says nothing on this. Answer slot: if you tracked any measure of how clients used an integration after go-live, say what was counted, in your own words. If you didn't, say so plainly and say what you would measure first. The dossier also flags that no current baseline is stated, which is reverse question R2 |
| F8 | "Run discovery with integration partners" — JD (dossier role_profile responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | V1's scoping and requirements are client-integration scoping. That isn't platform discovery with partners, and the words stay there. Answer slot: the JD's discovery line makes a probe likely. If scoping turned up needs beyond the integration at hand, say what you did with them, in your own words. If it didn't, or nothing was done with them, say so plainly and stay with the scoping |
| F9 | "Write specs and drive delivery with two engineering squads" — JD (dossier role_profile responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook her team uses" — dossier V2 | high | [grounded] | transferability | Requirements on client integrations, plus a playbook your team uses, are close to specs for squads but not the same thing. Words at their own scope: V1, then "I wrote the internal integration playbook my team uses." Answer slot: the spec line makes a probe likely. If engineers built from requirements you wrote, say how that worked, in your own words. If they didn't, say so plainly and stay with the integrations and the playbook. Never say anything about setting a squad's priorities |

---

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet pressure on the PM-title gap and roadmap ownership | Highest. Hiring-manager rounds put Case/Strategist and Skeptic on top. The dossier names an objection aimed straight at F1 and F2, so Skeptic moves up | Rehearse A1 until it's boring. Concede plainly where the dossier says to, bridge only through V1 at its own scope, and close on a concrete ramp plan |
| Case / Strategist (bank B, 4) | Live problems on partner discovery, adoption and squad trade-offs | High. A hiring manager buying capability tests it live. That matters even more here, because F4 and F7 can't be shown from your past | Clarify, then objective, segmentation, approach, metrics and risks. Think aloud and challenge one premise per case. These questions need no claims about your past |
| Data-Driven Prober (bank C, 3) | Pulls on "30+", "end-to-end" and the playbook | Medium. V1 carries a number, and a hiring manager who read the material closely will test it | Know what you can and can't say about how 30+ was counted. Name your weakest assumption first, and offer the playbook if you're allowed to share it |
| Conversational (bank D, 3) | The opener, "why APIs", the casual sales question | Medium. Most 45-minute conversations open and close in this register, and it's still scored | A pre-built 90-second arc from V1 to V3, and answers that treat casual R4 questions as scored |
| Pressure (bank E, 2) | "How much was actually you?" and a time-boxed A1 | Low to medium. Not a hiring-manager prior, but the A1 objection invites a time-boxed version | Pause, restate, anchor in V1's own verb ("led"), and hold through two follow-ups |
| Peer Evaluator (bank G, 2) | The seam with the two squad leads, and sprint rhythm | Low to medium. Two squads appear in the JD, and the dossier flags authority versus squad leads as unresolved | Offer seam principles rather than pretending to know the seam. Ask about decision rights |
| Values / Behavioral (bank H, 2) | Generic behavioural prompts | Low. Your note establishes the session as a hiring-manager conversation, and no values-style round is documented. Quartzline's published values couldn't be researched | Story-selection scaffolds with honest branches. No values cheat sheet, since no values round is detected |

Bank letters skip F so they don't clash with fit-snapshot rows F1 to F9.

---

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"`; `prohibited_claims: "Having set prioritization for an engineering squad"`; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | **The highest-ROI rehearsal in this pack. Your underwriter named this objection.** Three beats, under 90 seconds. (1) Concede first and plainly: "You're right — I haven't held the PM title, and I haven't owned a roadmap." (2) Bridge with V1 and V2 at their own scope, and call it adjacent: "What I have done is lead 30-plus end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through go-live, and I wrote the integration playbook my team uses." Let them draw the inference. Never call it PM experience. (3) A ramp plan, said as a plan: how you'd learn this platform, its partners and its decision rights in your first months, in your own words. **Follow-up 1:** "So what trade-off have you actually owned?" Hold the concession: "I haven't set an engineering squad's priorities." Don't reach for V3 here, because the roadmap area is acknowledge-only. Go back to the ramp plan. **Follow-up 2:** "Then why not the three-year PM?" Don't argue against the other candidate. Restate V1 in one line, concede that the ramp is real, and say how you'd shorten it | The dossier's `likely_interviewer_objections` item, asked as written: both negatives in it are backed by `prohibited_claims` items, so they're kept. It's aimed at F1 and F2, the must-have gaps. JD because it scores R1 directly |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] `prohibited_claims: "Having owned a product roadmap"`; `prohibited_claims: "Having set prioritization for an engineering squad"` | Name F2 straight away: "Owning the roadmap. I haven't owned a product roadmap or set a squad's priorities." Then the ramp plan in two or three concrete steps, said as a plan. End by turning it outward: "Which roadmap decisions would be mine alone here?" (reverse question R1). No bridge. This is an acknowledge-only area, and an answer that pivots to "but I've done something like it" is the bluff it's meant to catch | A standard Skeptic stem that a hiring manager uses to test self-assessment. F2 is where an honest answer is already decided, so rehearse it to sound settled rather than confessional |
| A3 | "Which API or platform products have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Don't adopt the premise and don't argue with it. Answer with V1 at its own scope: "What I've done is lead 30-plus end-to-end client integrations of the vendor's REST APIs, through to go-live." Answer slot: say what went live and which part of it was yours to decide, in your own words. If none of it was yours to decide, say so plainly and stay with the integrations you led | R2 is a must-have. The question presupposes a shipped product, which F3 doesn't carry, so the guidance holds V1's scope |
| A4 | "I don't see adoption metrics in your background — how would you handle that part of the role?" | JD | [grounded] | Answer slot (F7): if you tracked any measure of how clients used an integration after go-live, say what was counted, in your own words. If you didn't, say so plainly. Then the forward half, as an approach rather than a past: what you'd define first (for example, partners making a first successful call, partners in production, time to first call), and the fact that you'd want today's baseline before setting a target. Finish with reverse question R2 | The JD names adoption metrics as a responsibility, and the material is silent (F7). A hiring manager who owns that metric will look at the gap |
| A5 | "Tell me about the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on V3. The beats are the ones the quote states: quarterly, you ran them, client evidence, fed to product. Tell them in your own words. The dossier rates this medium (limited inspectable proof), so mention the limit yourself early: describe how the sessions ran rather than pointing to a document. Answer slot: R4's stakeholder line makes "what did product do with it?" likely. If you know of a change that traced back to the input, say what it was and what part you played. If you don't, or nothing changed, say so plainly and stay with what the sessions were. These were input to product. Never present them as setting the roadmap | V3 is the closest your material gets to product work. That makes it where a Skeptic presses, and where the inflated reading in the prohibited list is most tempting. EXP because it tests what was yours |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner tells you our API is hard to integrate with. How would you run discovery with them in your first month?" | CASE | [generic] | Clarify first: which partner, what they were trying to build, and what "hard" meant to them. Objective: find where the friction is, not fix it on the spot. Segment the friction: access and auth, docs, data model, errors, support. Approach: sit in on a build or walk through their integration, read their tickets, compare with one partner who succeeded. Metric: time to first successful call. Risk: one loud partner standing in for all of them. The question asks nothing about your past, so the guidance claims nothing | "Run discovery with integration partners" is a core responsibility (F8). A hiring manager will test it live because the transfer from client scoping is the question |
| B2 | "Adoption of a new endpoint is flat six weeks after launch. Diagnose it." | CASE | [generic] | Clarify the definition of adoption and the baseline it's flat against. Walk the funnel: awareness, access, first call, production use. Segment by partner type and find the step where they stall. Check the usual suspects at each step (docs, auth, breaking changes, missing use case). Name the weakest assumption in your own diagnosis before they do. Close with what you'd measure next week | Covers "Define and track adoption metrics" (F7) as a live problem, where your reasoning can show what your history doesn't |
| B3 | "Two squad leads disagree about next quarter: one wants partner-requested endpoints, the other wants reliability work. What do you do?" | CASE | [generic] | Start by clarifying decision rights: who makes this call here, you or the leads? That's the dossier's open question, and asking it is the strongest move. Then criteria: partner evidence, cost of delay, risk if reliability slips. Propose a sequence and the evidence behind it, and say how you'd bring both leads to it. Present it as how you would approach it. The question asks nothing about your past, and the guidance makes no claim about setting priorities | Tests "Write specs and drive delivery with two engineering squads" (F9) and the authority question at once. CASE because it's a live role problem |
| B4 | "Here's one of our endpoint docs. What would you check before a partner builds on it?" | CASE | [generic] | Structure it as a checklist you talk through: auth and access, versioning and deprecation policy, request and response schemas with worked examples, error codes and what each one tells the partner, rate limits, pagination, idempotency for writes, and a sandbox. Then say which of these you'd test first and why. If they hand you a real doc, read it out loud as you go | R3 (F4) can't be shown from your quotes, so a live walkthrough is where fluency gets shown. JD content, CASE delivery |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30-plus integrations — how was that counted, and what does end-to-end mean in that number?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The stages are the ones V1 lists: scoping, requirements, architecture, UAT, go-live. Answer slots, each in your own words: how the 30-plus was counted; what the number is sensitive to; the assumption behind it you'd defend least, named before they ask; and which part was yours. If you don't know exactly how it was counted, say so. That's an honest answer. Say "30-plus" or "at least 30", never "more than 30" | V1 is the headline figure, and a prober tests every one. EXP because it checks attribution |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on V2. The beats: you wrote it, it's internal, your team uses it. Describe what's in it, in your own words. Keep the scope at your team. The quote doesn't support wider adoption. It's inspectable, so offer to show a section only if you're allowed to share it | V2 is your second strongest inspectable item, and it's adjacent to "Write specs" (F9) |
| C3 | "On a typical integration, which scoping and requirements decisions were yours, and which belonged to the client or the vendor's product team?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start from V1's verb: you led the integrations. Answer slot: the JD's discovery and spec lines make this likely. If specific decisions were yours, name them and how you made them, in your own words. If they weren't yours, say so plainly and describe what leading meant day to day | Separates leading from deciding on F8 and F9. That's the seam a hiring manager probes before giving someone a roadmap |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: what you do now (V1), what you built for your team (V2), where you've been feeding product (V3, as input), and why this role is next. Your employers, titles and years, in your own words. The pack doesn't supply them, because your dossier's verified sentences don't. Don't use the word "PM" for any past role | Nearly every 45-minute conversation opens like this. The arc puts V1 to V3 in the order that answers A1 before it's asked |
| D2 | "What drew you to platform APIs specifically?" | JD | [generic] | Give your real reason, in your own words, and tie it to something in the role: partner-facing APIs, adoption, discovery. If the honest answer is the move toward product, say so directly. A casual tone doesn't mean it's unscored | Motivation is checked casually in hiring-manager rounds. JD because it's scored against the role's domain |
| D3 | "How do you usually work with sales?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot (F5): if you worked with the vendor's sales team on those integrations, say how and what was yours, in your own words. If you didn't, say so plainly, stay with the client side you led, and say how you'd work with sales here | R4 names sales, and F5 shows nothing for it. A casual question on a JD line is still scored |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Those 30-plus integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, then hold V1's verb: you led them. Answer slot: say who else worked on which stages and what the team's share was, in your own words, specifically. Hold through two follow-ups. Concede only what's true, and concede it precisely. Don't drop "led" to calm things down, and don't inflate it to win | The pressure version of C1, aimed at attribution. Rehearsing it calmly is the point |
| E2 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] `prohibited_claims: "Having held a product manager title or role"`; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | A1 compressed: one sentence conceding the title ("I haven't held the PM title"), one sentence of V1 at its own scope, one sentence of ramp plan. Stop at 60 seconds | A time-boxed A1 tests composure. Rehearse both lengths |

### G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "This role works alongside two squad leads — where's the seam between you and them, and what happens when you disagree?" | CASE | [generic] | Don't pretend to know their seam. Propose principles: you bring partner evidence and the why, they bring how and how long, and disagreements get settled on evidence with one clear decider. Then ask who that decider is (reverse question R1). If asked for a past disagreement, pick a time you disagreed with someone technical and the relationship survived. If none comes to mind, say so plainly and describe how you'd handle it | The dossier flags authority versus the squad leads as unevidenced. The hiring manager may test how you'd handle it before telling you |
| G2 | "How do you like to work inside a squad's sprint rhythm?" | JD | [grounded] | Answer slot (F6): if your integrations ran in sprints or another agile cadence, say how and what part was yours, in your own words. If you never worked that way, say so plainly. Then: "Here's what I'd want to confirm about how your squads define agile delivery," and ask it | R5 is preferred and marked `clarify` in the dossier. This is its JD question |

### H — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you held your position, and a relationship that was intact at the end. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A common behavioural stem. With no values round detected and no researched values, it's here so the register isn't new on the day |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time where a customer's need and an internal target pulled apart and you chose the customer, with the cost stated. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A partner-facing role makes customer-first stories relevant. Scaffold only, because no quote carries one |

---

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 "3+ years product management experience" | A1, A2, E2 |
| R2 "Shipped API or platform products" | A3 |
| R3 "Technical fluency: API docs, schemas" | B4 |
| R4 "Stakeholder management across engineering, sales, customers" | A5, D3, G1 |
| R5 "Agile delivery experience" | G2 |
| "Own the roadmap for the partner-facing API platform" | A1, A2 |
| "Run discovery with integration partners" | B1, C3 |
| "Write specs and drive delivery with two engineering squads" | B3, C3, G1 |
| "Define and track adoption metrics" | A4, B2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier's `questions_for_employer`. The JD states decision authority but nothing shows it. You need the answer before accepting, and asking reads as diligence rather than worry |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier. Adoption is a named responsibility with no stated baseline, and whether you inherit a number or have to build one changes the job |
| R3 | "Could you walk me through a recent roadmap call — who made it, and how?" | Tests the authority risk with an actual example rather than the org chart's answer |
| R4 | "If adoption were going well six months after you joined, what would you be looking at?" | Tests the baseline risk from the other side: what the manager will actually judge you on |
| R5 | "How is work divided between the two squads today?" | The JD names two squads. Their split shapes how you'd write specs and where the seams in G1 sit |
| R6 | "What's the first problem you'd want this hire to take off your plate?" | Gets the real job behind the JD, and gives you a hook for a closing line tied to it |

---

## Prohibited claims

What this pack won't coach, and why. Every guidance cell above is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` (F1) | "I haven't held a product manager title." Then V1 at its own scope |
| Having owned a product roadmap | Dossier `prohibited_claims` and `acknowledge_gap` area (F2) | "I haven't owned a product roadmap." Then a ramp plan. No slot. V3 is never offered as roadmap ownership |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` (F2, F9) | "I haven't set an engineering squad's priorities." No slot |
| Integration leadership described as PM experience | Dossier decision condition: "never as PM experience" | V1 at its own scope, called adjacent. Leave the inference to the interviewer |
| Shipped an API or platform product | Inflated form of F3 | V1 at its own scope. The limit is the pack's observation: the material shows client integrations of the vendor's APIs through go-live, not a shipped API product. A3's slot stays inside those go-lives |
| Wrote product specs for engineering squads | Inflated form of F9 | V1's "requirements" and V2 at their own scope. C3's slot stays inside them |
| The playbook adopted beyond your team | Inflated form of V2's scope (F9) | V2 at its own scope: your team uses it |
| Roadmap-input sessions as roadmap decisions | Inflated form of V3 (F5) | V3 at its own scope: you ran sessions that fed client evidence to product. A5's slot asks only what product did with that input |

---

## Sources

**Provided documents:** `tuesday-dossier.md`, version 1.1, generated 2026-08-14. Consumed: `role_profile` (stands in for the JD: requirements R1 to R5, responsibilities, unknowns), `decision` (context and the positioning condition), and `handoff_to_mock_interview` (the verified evidence V1 to V3, weak areas with strategies, the objection behind A1, risks and employer questions behind R1 to R4, and `prohibited_claims`). The envelope carries no `evidence_map`, `evidence_state` or `risk_register`, so where the handoff doesn't grade a row, the fit-snapshot grading is this pack's own. The dossier is three months old, so its role profile reflects the posting as of August.

**Searches sent:**
- `Quartzline company values` — refused
- `Quartzline interview process product manager` — refused
- `Quartzline partner API platform news 2026` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have named published values, which could theme VAL questions. No values cheat sheet is included, because no values round is detected |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. Your own note establishes this session (a 45-minute conversation with the hiring manager), so persona weights rest on it. It would have shown whether a values round sits elsewhere in the loop |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded one CO or CASE question in current strategy. Bank B stays `[generic]` instead |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements, which fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** (all three searches were refused this run) → Quartzline's published values and loop structure, plus one CO or CASE question grounded in current strategy in place of a generic case
- **The hiring manager's name** → an interviewer read, persona weights based on their public footprint, and a reverse question tied to their career path
- **The recruiter's prep notes** → stated focus areas. Any pre-declared deliverable (a presentation, a take-home) gets its own build section
- **How much prep time you have before Thursday** → a prep triage: the few things to do first, in order, tied to question IDs
- **The current posting text** → confirms the August role profile still matches, and re-checks F1 to F9 against it
- **Your answers to the answer slots in F4 to F9, told to me outside a drill** → those rows quote your words, and A3, A4, C1, C3, D3 and G2 regenerate on them
- **Your CV** → D1's arc gets your employers, titles and dates in your own words, and C1's count gets its source
- **A deeper research pass** (only once search is allowed): up to 6 more searches and 2 more fetches, several more minutes → a strategy brief, recent org context and reports on how this kind of role is interviewed
