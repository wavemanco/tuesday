Reading the last prep reference, then I'll write your pack. You're interviewing for three rounds, there's no research to run, and you've already given me everything I need.
Dara, your prep pack is ready: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-8-canned-7a3bd383/Ashgrove-Credit-Union_member-experience-lead_interview_pack.md`

It has one section for each of your three rounds on 21 November. I didn't search the web: you'd already sent the values, the round structure and a recent strategy brief.

- **The question to rehearse most is C1, in Round 2.** It's "What prepares you to own complaints end to end, across every branch and the contact centre?" The pack's answer sticks to what you actually told me: you handled one branch's formal complaints log and spent three years as a supervisor. You say plainly that you've never worked in a contact centre, then give a plan. Two follow-ups are rehearsed.
- **The panel's 20-minute case has its own section.** It includes a 20-minute structure, three possible lead arguments that each come with a concession, and one thing to avoid: making "move the member to the app" the fix. Two branch managers going through a year of branch consolidation are the ones scoring "Neighbours, Not Numbers".
- **The four values don't have stories yet, just guides for picking one.** Nothing you've told me so far is a story that shows one of the values. If you send me one real story per value, I'll write each answer around it.
- **21 November 2026 is a Saturday.** I've added confirming the times to your questions for the recruiter.

If you'd like a practice run, I'll play your future manager and ask C1 with follow-ups.
I can also save a `tuesday-dossier.md` file listing the gaps this prep found, so you can carry them into later sessions.
I can convert the pack to a Word document too.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Format:** loop mode. All three rounds are on 21 November 2026.

| Round | Length | Who | What it holds (from the recruiter's email) |
|---|---|---|---|
| 1 | 30 min | The recruiter | A conversation |
| 2 | 45 min | Head of Member Services, your future manager | "mostly behavioural" |
| 3 | 60 min | Panel of two branch managers | "a 20-minute case on a complaint escalation"; "the values round — they score against the four values" |

Interviewers' names haven't been assigned yet, so this pack has no interviewer read.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- The guidance is scaffolding, not a script. Rehearse the beats, then say them in your own words.
- **F1 to F9** are rows of the fit snapshot. Question IDs use bank letters (A, B, C, D, E, G, H, J, K, L). F is skipped so a question ID is never confused with a fit row.
- **Provenance labels:**
  - `[grounded]` traces to something you or Ashgrove provided.
  - `[inferred]` is this pack's derivation, and the derivation is named.
  - `[generic]` is a common pattern for this kind of role, with no claim about Ashgrove or you.
- An **answer slot** is an instruction for the interview, not a question for me. It names what an interviewer is likely to probe. It always has two honest branches: "if you did this, say how" and "if not, say so plainly".

| Tag | Scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your stated experience survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know Ashgrove's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

---

## Shared: Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material describes one branch's formal log, not a process across branches. Your words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on what handling the log covered likely. If any decisions on those complaints were yours, say which ones and how you made them, in your own words. If handling the log meant keeping the record while the decisions sat with someone else, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You have stated this gap and wording cannot close it. Your words: "I've never worked in a contact centre." Then say how you would learn it, as a plan and never as a past, for example by asking to sit with the contact centre on live complaints in your first weeks. Never claim contact-centre work, and add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The spreadsheet is monthly and about complaints, so it touches the requirement. Your material doesn't show what it counts. It also shows that you built it and the regional manager uses it, not that you reported from it. Answer slot: if it tracks volumes and resolution times, say so, and say where its figures come from if you know. If it tracks other things, say what it tracks, plainly. If you don't know how a figure is counted, say that |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your material doesn't name the tool. Answer slot: if you built it in Excel, say so and describe what you did in it, in your own words. If you used another tool, name it plainly |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Your material shows you trained new tellers. This role coaches supervisors, which is a different audience. Your words stay at your scope: "I trained new tellers on our escalation script." The supervisor role is one you have held for three years, said in your quote's own terms. Answer slot: the JD's coaching line makes a probe on how you trained likely. If the way you trained them was yours to shape, say how, in your own words. If you taught the script as it was given, say so plainly and stay with that |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show this either way. Answer slot: if you have worked with a digital or online team, or passed complaint patterns to one, say what happened and which part was yours. If you haven't, say so plainly, then describe how complaints could inform self-service journeys, as a plan rather than a past |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | There's no gap here, but it rests on one line with nothing behind it, so expect a probe. Say it in your own terms ("six years in retail banking, the last three as a branch supervisor") and let the interviewer map it to the JD |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | "Formal" is not the same as "regulated", and your material doesn't show which rules those complaints fell under. Answer slot: if the complaints were handled to regulatory rules you worked to, name the rules and what they required of you, in your own words. If you don't know which rules applied, or the regulatory side sat with someone else, say so plainly and stay with the log |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You have stated this gap. Your words: "I've never presented to anyone above regional level." Then describe how you would prepare for the first senior audience, as a plan and never as a past. Your material doesn't say whether you have presented at regional level, so this pack assumes neither way |

**No gate rows.** Every requirement in the JD is experience, not an eligibility term.

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Own complaints end to end, across branches and the contact centre (F1, F2) | B1, C1, H4, J1 |
| Monthly reporting on volumes and resolution times (F3) | G1, G2, K3 |
| Excel reporting (F4) | A4, G1 |
| Coach branch supervisors on escalations (F5) | D3, E3, K2 |
| Digital self-service journeys (F6) | E1, K1 |
| 4+ years in financial-services customer operations (F7) | A1, L1 |
| Regulated complaints (F8) | G3, J1 |
| Presenting to senior leaders (F9) | B3, C2, C3 |

---

## Shared: Prohibited claims

This pack will not coach any of the claims below, and no cell in it does.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material describes the branch's log, not a multi-branch process. C1's slot stays inside the log |
| Has contact-centre experience | A negative you stated, F2 | "I've never worked in a contact centre." No slot |
| Has presented to senior leaders, executives or a board | A negative you stated, F9 | "I've never presented to anyone above regional level." No slot |
| Reports or presents complaints data to the regional manager | Inflated form of F3. Building a spreadsheet that someone else uses is different work from reporting it | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." G1's slot asks only what it counts |
| Wrote or designed the escalation script | Inflated form of F5. "Trained on" does not mean "authored" | F5's quote: "trained new tellers on our escalation script" |
| Has coached supervisors | Inflated form of F5. The audience widens from tellers to supervisors | F5's quote at its own scope. The slot stays with how you trained tellers |
| Managed or ran a branch | Inflated form of F7. A supervisor is not a manager, and your panel will be branch managers | F7's quote: "the last 3 as a branch supervisor" |

---

## Shared: Grounding brief

These facts come from Ashgrove's July 2026 strategy brief, as you summarised it, and from the JD and values page you pasted.

| Fact or reading | Provenance | Use it for |
|---|---|---|
| Ashgrove aims to move 40% of member service to digital channels by 2028 | [grounded] strategy brief | E1. The JD's self-service line (F6) is this target at work level |
| Eight branches become five hubs over 2027 | [grounded] strategy brief | K1, the Neighbours value, and the reverse questions |
| A small-business lending product launches in Q1 2027 | [grounded] strategy brief | Round 2 reverse question 5 |
| App-only banks are the main competitive pressure | [grounded] strategy brief | A2, E1. Member experience is where a member-owned institution competes |
| Member-owned, about 900 staff | [grounded] JD | A2 |
| Your panel is two branch managers who will score "Neighbours, Not Numbers" during a year of branch consolidation. Digital shift and hub moves are likely to be close to home for them | [inferred] from the recruiter's email and the strategy brief | Don't present digital or hubs as the answer to a member's complaint unless the member chose that channel. Show that the branch keeps hold of its member |
| A new lending product is likely to bring new kinds of complaint in 2027 | [inferred] from the strategy brief and the JD | A reverse question, not a claim. Don't assert it as a fact about Ashgrove |

---

## Shared: Graded deliverable, the 20-minute complaint escalation case (Round 3)

Source: the recruiter's email says "a 20-minute case on a complaint escalation", with a panel where "they score against the four values". You don't yet know whether the case is given in advance (Round 1 reverse question 2 asks).

### A 20-minute shape

| Minutes | Move | Provenance |
|---|---|---|
| 0–3 | Clarify before solving. Ask who the member is, what happened, which channel it came through, what has been promised so far, and which regulatory timelines and internal policy apply. Ask about the rules; don't assert them | [generic] |
| 3–7 | The member first. Who contacts the member today, what they are told in plain words, and who stays their single named contact | [grounded] values: Members First, Plain Words |
| 7–12 | The fix. Who owns resolving it, what the branch keeps and what is escalated, how the escalation hands over without the member losing their contact | [grounded] values: Own the Fix; JD coaching line |
| 12–16 | The pattern. Log it so the monthly report shows whether it repeats, then ask whether it is a branch issue, a process issue or a self-service journey issue | [grounded] JD reporting and digital lines |
| 16–20 | Close. Recap in one plain sentence per value, then say what you would check first on day one | [grounded] values: four named values |

### Theses (pick one to lead with)

| Thesis | Concession you must say out loud | Provenance |
|---|---|---|
| T1. An escalation is the member's problem first and a process problem second: resolve and communicate before you analyse | Fixing this one case fast can leave the root cause in place. Say when you would come back to it | [grounded] values: Members First, Own the Fix |
| T2. Escalating should never mean letting go. The person who found the problem keeps the member relationship while the specialist resolves it | It can blur accountability, so name one owner of the outcome | [grounded] value: Own the Fix |
| T3. Every escalation is data. It goes into the monthly volumes and resolution times, and repeat causes go to the digital teams or to supervisor coaching | Don't let recording slow the member's reply | [grounded] JD reporting, coaching and digital lines |

### Your own experience in the case

You can name it only at its quoted scope:

- F1: "I handled the branch's formal complaints log"
- F5: "trained new tellers on our escalation script"

Nothing else about your past goes into the case unless you have told it to me outside a drill.

### Differentiation

| Move | Provenance |
|---|---|
| The common answer is "apologise, investigate, resolve". Differentiate by naming each value at the step where it bites, using Ashgrove's own value names | [generic] |
| The anti-pick: don't make "move the member to the app" the fix. Offer self-service only as the member's choice, or as a fix to the journey that caused the complaint | [inferred] from the grounding brief's panel reading |
| Challenge one premise of the case respectfully, for example who should own the member contact | [generic] |

---

# Round 1: Recruiter (30 min)

## Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly walk through your background and why Ashgrove | High. A recruiter screen is a conversation, and the email names this round as 30 minutes with them | A 90-second arc built only from your quoted sentences. Treat every casual question as scored |
| Skeptic, light | Knockout checks against JD lines | Medium. Recruiter screens check requirements, and F2 and F9 are gaps you stated against JD lines | Plain acknowledgments rehearsed until they sound calm, each followed by a plan |

## Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Three beats, each one a quote: six years in retail banking, the last three as a branch supervisor; the formal complaints log and training new tellers on the escalation script; the monthly complaints spreadsheet the regional manager uses. Answer slot: end with why this move, in your own words. Stop at 90 seconds | The biography question opens almost every screen, and F7, F1, F5 and F3 are your strongest rows. EXP because it sets what the later rounds will probe |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Use Ashgrove's own facts: member-owned, the four values by name, and the strategy (digital shift, hubs, competition from app-only banks). Answer slot: your own reason for wanting a member-owned employer, in your own words. Pick one value that is genuinely why, and say why | A motivation check where homework shows. CO because the grounding brief gives you facts most candidates won't have |
| A3 | "What's your understanding of the role?" | JD | [grounded] "I handled the branch's formal complaints log" | Say the JD back in four plain parts: complaints across branches and the contact centre, monthly reporting, coaching supervisors, digital journeys. Tie one part to your quote at its scope | Shows you read the JD, and leads naturally into the gaps in F1 and F2. JD because it is the listed job |
| A4 | "How comfortable are you with Excel?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Lead with the quote. Answer slot: if the spreadsheet is in Excel, say what you did in it, in your own words. If it isn't, name the tool. Never name a feature you didn't use | F4 is a listed requirement your material leaves open. A casual question about a JD requirement is still scored |
| A5 | "What are your salary expectations and notice period?" | JD | [generic] | Have a range and your notice period ready before the call. If you're unsure, ask what the band is | A standard screening item. `[generic]` because nothing provided says Ashgrove will ask it |

## Bank B: Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre too. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" | "I've never worked in a contact centre." Pause, then give the plan: what you would want to learn first and how, said as a plan. Don't apologise twice | F2 is a stated gap on the role's headline line, so a recruiter may screen on it. Rehearse it here so it is calm by Round 2 |
| B2 | "This is a step up from supervisor. Why now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | State the quote, then give your reason in your own words. That reason is an answer slot: only you know it | Recruiters check that your motivation is consistent before passing you on. EXP because it tests your own story |
| B3 | "Have you presented to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | "I've never presented to anyone above regional level." One sentence on how you would prepare. The deep version is C3 | F9 is a JD requirement you stated a gap against. This is the light first pass |

## Reverse questions, Round 1

| Question | Why it lands |
|---|---|
| 1. Is this role new, or is it replacing someone? | It tells you whether you'd be building or inheriting, and the recruiter can usually answer |
| 2. Is the 20-minute case given in advance or on the day, and will there be materials? | It shapes how you prepare the shared case section |
| 3. Could you confirm the times for each round on 21 November? | 21 November 2026 is a Saturday, so it's worth confirming |
| 4. Roughly how does the role split its time between branches and the contact centre? | It sizes the F2 gap honestly |
| 5. What's the timeline after the 21st? | A practical close |

---

# Round 2: Head of Member Services, your future manager (45 min)

## Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of gaps against the JD | High. Hiring managers de-risk gaps, and F1, F2 and F9 sit on headline JD lines | Rehearse C1 until it's boring: hold on your quotes, concede the stated gaps, give a plan |
| Values/Behavioral | "Tell me about a time…" | High. The recruiter calls this round "mostly behavioural" | Behavioural stories in which "we" gives context and "I" gives your contribution |
| Case/Strategist | Live problems from the role and the strategy | Medium. Hiring managers usually ask some, but "mostly behavioural" lowers it | Clarify, then structure, then answer, using Ashgrove's vocabulary |
| Data-Driven Prober | Questions about the spreadsheet and how things are measured | Medium. F3 and the JD's monthly reporting line invite it | Say what the sheet counts and what you don't know |
| Pressure | Interruptions and pushback | Low. Rehearsed through C1's follow-ups | Pause, restate, hold, then concede specifically |

## Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role owns complaints end to end, across every branch and the contact centre. What in your background prepares you for that?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" | **The highest-ROI prep in this pack.** Hold only what your quotes carry: "I handled the branch's formal complaints log, and for three years I was a branch supervisor." Then name the limit before it is asked for: "I've never worked in a contact centre." Then give the plan, as a plan. Answer slot: if any decisions on complaints in the log were yours, say which, in your own words. If not, say so and stay with the log. **Follow-up 1:** "That's one branch." Hold the quote, and don't widen it to branches plural. Concede the scale, then name what you'd learn first across branches. **Follow-up 2:** "So the contact centre is new to you?" "Yes." Then the plan again, shorter. Never fold to "I'm probably not ready" | F1 and F2 together are the role's headline gap, so this objection will come in some form. JD because it scores the headline requirement directly |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" | Pick a real gap you stated. F9 is the cleanest: "I've never presented to anyone above regional level." Then one concrete preparation step, as a plan. Don't pick a fake weakness | It is a direct Skeptic stem, and a calibrated answer here earns trust for C1 |
| C3 | "You'd be presenting complaint trends to senior leaders. What's your experience presenting?" | JD | [grounded] "I've never presented to anyone above regional level" | "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level or below, say to whom and what, in your own words. If you haven't presented at all, say so plainly. Then your plan for a first senior report: one page, three numbers, one ask. Say it as a plan | F9 is a JD requirement your manager will own, so expect a probe on it. JD because it scores the listed requirement |
| C4 | "Why move from branch work to a central role, especially with branches consolidating?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | State the quote. Answer slot: your reason, in your own words. Show you know the hubs plan without passing judgement on it | It is a motivation check sharpened by the strategy. CO because it tests whether you understand the consolidation |

## Bank D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you kept hold of a complaint until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one complaint. It needs what went wrong, what you did, how you knew it was solved, and who else was involved. A complaint from the formal log is the natural pool. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | Own the Fix echoes the JD's "end to end", so your manager may test it here as well as the panel in Round 3. VAL because it maps to a published value |
| D2 | "Tell me about a time a member didn't understand something the first time." | VAL | [generic] | Selection scaffold: it needs what was unclear, how you re-explained it, and how you knew it landed. If none comes to mind, say so plainly, then say how you would handle it | Plain Words is Ashgrove's own value. `[generic]` because no quote carries a story yet |
| D3 | "Tell me about a time training someone didn't land the first time." | EXP | [grounded] "trained new tellers on our escalation script" | If a teller-training moment fits, tell it in your own words: what didn't land, what you changed, what happened. If none comes to mind, say so plainly and describe how you trained, at the quote's scope | It is the bridge from F5 to coaching supervisors. EXP because it tests what you actually did |

## Bank E: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We want 40% of member service on digital channels by 2028. Where should complaints fit in that?" | CO | [grounded] | Structure: complaints as a signal of where digital journeys fail; which journeys to fix first; keeping a human route for complaints. Name the pressure from app-only banks. This needs no claim about your past. If you want to bring in experience, it goes in F6's slot | The question is built on the strategy brief and the JD's digital line. CO first, CASE in delivery |
| E2 | "A supervisor escalates a complaint to you that's already past the reply date the member was given. What do you do in the first 24 hours?" | CASE | [generic] | Contact the member first, in plain words. Then find out why it was late. Check what the regulatory timelines require; ask, don't assert. Then record it for the monthly report | A live role problem that previews Round 3's case. `[generic]` because it is a problem pattern, not an Ashgrove fact |
| E3 | "One supervisor escalates things they could resolve themselves. How would you coach them?" | CASE | [generic] | Structure: understand why first (confidence, policy, workload), agree what stays in branch, follow up on the next one. This needs no claim about your past | It tests the JD's coaching line live, which matters because F5 doesn't yet reach supervisors |

## Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Lead with the quote. Answer slot: say what it counts and where its figures come from, in your own words. If you don't know how a figure is counted, say so. Name the weakest part of it before they do, in your own words | F3 is your closest evidence for the reporting requirement and the likeliest thing to be probed. EXP because it tests what was yours |
| G2 | "How would you know the complaints process is getting better?" | JD | [grounded] | Use the JD's own measures, volumes and resolution times. Then name a weakness of each, for example that volume can fall because members stop complaining. Ask what Ashgrove tracks today | It is the JD's reporting line asked forward. JD because it scores the stated responsibility |
| G3 | "Which rules governed the complaints in your log?" | JD | [inferred] "I handled the branch's formal complaints log" | Answer slot: if you worked to regulatory rules, name them and what they required of you, in your own words. If you don't know, or the regulatory side sat with someone else, say so plainly and stay with the log. Never name a rule you didn't work to | F8 is a hard requirement your material doesn't settle. JD because it is listed |

## Reverse questions, Round 2

| Question | Why it lands |
|---|---|
| 1. What do the monthly complaint reports look like today, and who reads them? | It shows you're thinking about F3 and F9 from day one |
| 2. Where do complaints get stuck between branches and the contact centre today? | It turns the F1 and F2 gap into curiosity |
| 3. What would success look like at six months? | Your manager owns the answer |
| 4. How will moving to five hubs change where complaints arrive? | It shows you have read the strategy |
| 5. When small-business lending launches in Q1 2027, will its complaints sit with this role? | A real scope question from the brief |
| 6. How does this role work with the digital teams on the 40% target? | It connects the JD to the strategy |

---

# Round 3: Panel of two branch managers (60 min, the values round plus the 20-minute case)

## Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | One question or more per value, scored against the four values | High. The recruiter says "they score against the four values" | One prepared story per value, using the cheat sheet below |
| Case/Strategist | The 20-minute escalation case | High. The recruiter declared it | The shared graded-deliverable section |
| Peer Evaluator | "What would you need from us?", plus the seam between central and branch | Medium. Their supervisors are the people this role coaches, and their branches are where its process runs | Reciprocity: what you'd bring their branches, and principles for where the seam sits |
| Conversational | The opening and the close | Low. A two-person panel usually opens with a warm-up | A short version of A1 |

## Values cheat sheet

Values are from ashgrovecu.org/about/values, pasted by you and copied on 12 November 2026.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side, not the institution's | Selection scaffold. Pick a time the member's view changed what you did. It needs the situation, your decision and why. If none comes to mind, say so plainly, then give the nearest thing your material carries (F1, "I handled the branch's formal complaints log") or how you'd handle it |
| Plain Words | Unclear wording is the writer's fault, not the member's | Selection scaffold. Pick a time you re-explained or rewrote something because it didn't land. Teaching new tellers is the natural pool (F5, "trained new tellers on our escalation script"). If none comes to mind, say so plainly and say how you'd handle it |
| Neighbours, Not Numbers | Each branch belongs to its town | Selection scaffold. Pick a time local knowledge of your branch's members shaped what you did. If none comes to mind, say so plainly and say how you'd keep that during the move to hubs |
| Own the Fix | Whoever finds a problem keeps it until it's solved | Selection scaffold. Pick a problem you found and saw through to the end. The log (F1) or the spreadsheet (F3, "I built the monthly complaints spreadsheet our regional manager uses") are natural pools, but only if a real instance exists. If none comes to mind, say so plainly and say how you'd handle it |

## Bank H: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Use the Members First scaffold. Say "we" for the context and "I" for your decision. End with the outcome for the member | This uses the published value's own words, so it's a likely scored item. `[generic]` until you tell me a story |
| H2 | "Tell me about a time you had to explain something twice." | VAL | [grounded] "trained new tellers on our escalation script" | Use the Plain Words scaffold. If a training moment fits, tell it in your own words. If none does, say so plainly and use the nearest thing your material carries | This mirrors the value's own wording. F5 is the likeliest pool |
| H3 | "Tell me about a time knowing your community changed how you handled something." | VAL | [generic] | Use the Neighbours scaffold. Keep the member anonymous | A branch manager scoring this value will listen for real local texture |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Use the Own the Fix scaffold. Answer slot: if an instance from the log fits, tell it, with what was yours. If none does, say so plainly | This is the value closest to the JD's "end to end" (F1) |

## Bank J: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Here's a complaint escalated from one of our branches. Talk us through how you'd handle it." | CASE | [grounded] | Follow the shared graded-deliverable section: the 20-minute shape, one thesis with its concession, the anti-pick | The recruiter declared this deliverable, so it is graded. CASE because it is a live problem |
| J2 | "The member wants to deal with their branch, not a central team. What do you do?" | CASE | [generic] | Honour the request where you can. The branch keeps the contact while the fix happens centrally. Explain the reason in plain words | It tests Neighbours and Own the Fix together. `[generic]` because it is a likely follow-up pattern, not a known part of this case |

## Bank K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Branches are moving into hubs. How do you keep complaints handling local?" | CO | [grounded] | Principles, not a prescription: a named contact for the member, local context recorded on the complaint, and hub staff who know the towns. Ask how they see it. Don't pass judgement on the plan | It comes from the strategy brief and matters to these interviewers in particular (see the grounding brief's panel reading) |
| K2 | "If you're coaching my supervisors on escalations, what would you need from me, and what happens when we disagree?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Reciprocity first: what you'd bring their branch. Then what you'd need. Then a principle for disagreement: the member outcome decides, and you talk before escalating. You have held the supervisor role, so say that in your quote's own terms. Never claim you managed a branch | It is the JD's coaching line from the receiving side. It's a Peer Evaluator stem |
| K3 | "How do we know the complaints report won't be used against our branches?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The F3 quote as context, at its scope. Then a principle: the report shows patterns to fix, not branches to blame. That is Neighbours, Not Numbers | It tests the reporting line (F3) against the value, and branch managers have a stake in the answer |

## Bank L: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Six years in retail banking. What's kept you in it?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer slot: your reason, in your own words, in about 60 seconds | A warm-up that is still scored. It covers F7 |
| L2 | "What does a good complaint outcome look like to you?" | VAL | [generic] | Answer from the member's side, in plain words. One sentence each on resolution, explanation and the member staying | A short values check, framed by Members First |

## Reverse questions, Round 3

| Question | Why it lands |
|---|---|
| 1. When a complaint arrives in your branch today, what happens in the first hour? | It is their ground, and it gives you texture for J1 |
| 2. What would make a central complaints lead genuinely useful to your branch? | Reciprocity, which is what a Peer Evaluator listens for |
| 3. Is there an escalation you wish had gone differently, and what would have helped? | It shows Own the Fix in how you ask |
| 4. How are your members responding to the plans for hubs? | It asks about the members, not the politics |
| 5. Which of the four values is hardest to live on a busy day in branch? | It invites candour and shows you take the values seriously |

---

## Sources

**Provided documents** (all in your message of 12 November 2026):

- The JD
- The values text, copied that morning from ashgrovecu.org/about/values. That URL is named as the source of the pasted text, so it was not fetched.
- The recruiter's email
- Your summary of the July 2026 strategy brief
- Your background

**Searches and fetches:** none were sent.

**Dossier:** none was present. Nothing in this pack comes from one.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you pasted this morning fix the cheat sheet and banks D and H |
| 2. Ashgrove interview process | skipped | The recruiter's email sets the three rounds and the panel case, which fix the persona weights |
| 3. Ashgrove strategy / recent news | skipped | The July 2026 brief is under six months old and supplies the CO questions and the grounding brief |
| 4. Interviewer names | n/a | No names have been assigned yet, so there is no interviewer read |
| 5. Representative JD | skipped | You supplied the JD |

---

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for each round, persona weights from their public professional footprint, and a reverse question tied to each person's career path.
- **One real story per value, told to me in a message (not in a drill)** → the four cheat-sheet scaffolds and banks D and H become mapped stories.
- **Answers to the F3, F4, F6 and F8 slots** (what the spreadsheet counts, which tool, any digital work, which rules applied) → those rows are regraded, and G1, G3, A4 and E1 become story-mapped.
- **Your CV** → more quotable sentences, so more rows can be story-mapped instead of scaffolded.
- **How much prep time you have before the 21st** → a prioritised prep schedule.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → recent Ashgrove news since July and any organisational changes that shape the role.
- **A `tuesday-dossier.md` from an earlier fit assessment** → an evidence-derived lead objection and prohibited list. This pack is complete without one.
