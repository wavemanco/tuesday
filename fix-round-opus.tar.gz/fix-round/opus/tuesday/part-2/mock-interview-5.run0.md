Quick update: I've read the prep playbook and I'm now doing a small amount of company and interviewer research before I build your pack.
I've built your prep pack and saved it as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-5-denied-943f8502/Kelverton-Rail_senior-partnerships-manager_interview_pack.md`. It's built around the recruiter's own wording, because you don't have a JD and every web search I tried was blocked by permissions. Nothing in it comes from research, and anything that would need it is labelled as generic.

What's in it:

- **A four-hour plan.** It starts with 20 minutes in the market report filling four gaps in the POV, then 70 minutes building the POV and saying it aloud twice, timed.
- **A 15-minute POV outline**, broken into timed sections:
  - It opens with how you define "operator partnerships". That definition carries the whole talk, and Kelverton's own meaning is still unknown.
  - Three strategy options, each with a weakness you should say out loud.
  - A rule for the report: its authors are your panel, so use one finding to show you've done the reading and one to show where you'd bet differently. Don't recite it back to them.
  - One thing you'd deliberately not do in the first 18 months.
  - It closes on what changes for operators, as the recruiter asked.
- **The question to rehearse hardest is A2:** Ross asking why he'd hand you a commercial number when you've never carried a quota. Say that plainly first, keep "roughly" and "influenced" on the £4M every time, then explain how you'd want to be measured here. Practise it with two follow-ups.
- **21 practice questions**, weighted towards Ross on commercials and Deepa on the gaps: no rail sales, and an ISV channel rather than operator relationships.
- **One thing to settle before Tuesday:** your four years at the payments company plus five in consulting make nine. If the consulting years are part of your "9 years in partnerships", say so when you tell your story. The panel will do the sum.
- **A list of claims not to make**, for example that you generated £4M (it was influenced) or that you have mainline rail experience.

Say the word and I'll play Ross on A2 with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the job description? It would turn the generic requirement rows into Kelverton's own wording and show up any location, travel or right-to-work terms. I'll work without it if you'd rather.
2. If you allow web search, should I rerun the basic searches (Kelverton's values, recent news, and Deepa's and Ross's public profiles) and add a deeper pass? The deeper pass is up to 6 more searches and 2 more page reads, and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, 60-minute panel. **Deepa** (VP Partnerships, your future manager) and **Ross** (Commercial Director).
**Format, from the recruiter's email:** first 15 minutes, a POV with no slides on "where you'd take our operator partnerships over the next 18 months"; "land on what it means for the operators themselves"; then Q&A, and "Ross will push on commercials".
**Built without a JD.** The requirements come from the recruiter's words where she gave them, and from role-family patterns everywhere else, labelled `[generic]`. Every web search was blocked by permissions, so nothing in this pack comes from research (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question gets asked: Ross pressing, Deepa probing a gap, a friendly opener. **Types** describe *what* is being scored:
  - **VAL**: whether your past behaviour shows a value.
  - **EXP**: whether your own claims hold up under questioning, and what was actually you.
  - **JD**: whether you can do the stated job, gaps included.
  - **CO**: company and market homework, here mainly the market report.
  - **CASE**: a live problem from the role, worked through in front of them.
- **Provenance labels:** `[grounded]` traces to something you wrote me or the recruiter's email. `[inferred]` is a derivation, and the derivation is named. `[generic]` is a role-family pattern that makes no claim about Kelverton.
- **The guidance is scaffolding, not a script.** Wherever it says *answer slot*, the words have to come from you. The pack does not know the answer, and an answer you can't stand behind under a second question is worse than none.

---

## Prep triage: your four hours

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 20 min | Re-read the market report with one job: fill the four POV slots (one finding you agree with, one where you'd bet differently, the operator problems it names, the anti-pick) | Section "Graded deliverable" |
| 2 | 70 min | Build the 15-minute POV and say it out loud **twice, timed**. Cut whatever pushes you past 14 minutes | Graded deliverable |
| 3 | 45 min | Rehearse **A2** (the quota objection), the highest-ROI prep in this pack, and then **A1** (defending the £4M) | Bank A |
| 4 | 30 min | Deepa's gap questions: **C1, C4, C2** | Bank C |
| 5 | 30 min | The rest of Ross: **A3, A5, D1, D2** | Banks A and D |
| 6 | 15 min | **E1**, your 90-second arc. Settle the 9-years arithmetic first (E1 explains why) | Bank E |
| 7 | 10 min | Pick three reverse questions, one for each interviewer plus R6 | Reverse questions |
| 8 | 20 min | One live drill on A2 or the POV opening | Offered with this pack |

Everything else in this pack is insurance: read it once, don't rehearse it.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material describes an ISV channel at a payments company. It does not describe operator partnerships, and your words should stay there: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the recruiter's 18-month framing makes a probe on how you planned a channel over time likely. If setting the channel's plan or priorities was yours, say how you did it, in your own words. If there was no such plan, or it wasn't yours, say so plainly and stay with the channel you ran |
| F2 | "land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says consulting on bus and light rail network planning. It doesn't say mainline rail, and it doesn't say working inside an operator. Words: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: the recruiter's "operators themselves" makes a probe on your direct operator exposure likely. If your clients included operators, say what kind and what you did for them, in your own words. If they didn't, say who the work was for and stay with the planning work. "From the other side" will invite "which side?", so be ready to say it plainly |
| F3 | "Ross will push on commercials" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure is influenced revenue, and it stays "roughly" and "influenced" every time you say it. Your material doesn't show whether partner commercial terms were part of your job. Answer slot: Ross's push makes a probe on partner deal terms likely. If you negotiated or set them, say what and how, in your own words. If you didn't, or it wasn't yours, say so plainly and return to the channel and the influenced figure |
| F4 | A senior partnerships role often answers for a revenue number, direct or attributed — role-family pattern | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap that wording can't close, and you've said so yourself. Words: "I've never carried a direct quota; my number has been influenced revenue." After that, say how you'd want to be measured here, as a plan, never as a past. Nothing added to make the gap feel smaller |
| F5 | Selling into the UK rail market — role-family pattern | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | Words: "I haven't sold into rail." Then how you'd close the gap in the first 90 days, said as a plan. F2's planning work is adjacent, but it isn't rail selling, so don't let it stand in for rail selling |
| F6 | Building and scaling a partner programme — role-family pattern | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap. It's a stated line with nothing inspected behind it, though, so expect the attribution probe (A3). Lead with the quote's own terms: you ran the ISV channel and took it from 6 partners to 40 |
| F7 | Seniority for a "Senior" partnerships title — role-family pattern | "9 years in partnerships" — your message | medium | [grounded] | none | No gap. One thing to settle before Tuesday, though: your four years at the payments company plus five in consulting make nine. If the consulting years are part of the nine, say so when you tell the arc. The panel will do the arithmetic, and the smaller reading is the safe one (E1) |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 the 18-month POV | Graded deliverable, B1, B2, B5 |
| F2 what it means for operators | Graded deliverable close, B4, C2 |
| F3 commercials | A1, A4, A5, D2, V1 |
| F4 a revenue number | A2, A5 |
| F5 selling into rail | C1, E2 |
| F6 building a partner programme | A3, C4 |
| F7 seniority | E1, C3 |

---

## Graded deliverable: the 15-minute POV

*Proposed structure and language, pending your approval.*

**What you can build on, and nothing more:**
- The ask, in the recruiter's words: "where you'd take our operator partnerships over the next 18 months" and "land on what it means for the operators themselves". `[grounded]`
- Your channel experience, F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue". `[grounded]`
- Your operator-side experience, F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." `[grounded]`
- The market report. **Its authors are the people you're presenting to.** It is the consensus answer, so use it to show you've done the homework, not as your argument. Every slot below that needs a fact about Kelverton or the market gets filled from the report, never from general knowledge. `[grounded]` on the fact that you have it. Its contents aren't in this pack.

**Timed structure (14 minutes, plus 1 of buffer)**

| Minutes | Beat | What goes in it |
|---|---|---|
| 0–1 | Frame and definition | Say how you're reading "operator partnerships": operators as customers you partner with, third parties you partner with *to serve* operators, or both. Pick one, say it out loud, and invite Deepa to correct you. This is the premise the rest stands on, and you don't know Kelverton's own usage `[generic]` |
| 1–3 | Where things stand | Slot: the one finding in the report you agree with most, credited to the report. One finding only. This is the consensus item |
| 3–10 | Three moves over 18 months | Your chosen thesis below, laid out as 0–6, 6–12 and 12–18 months. Each move gets: what you'd do, what you'd need from Ross's team, and how you'd know it's working |
| 10–13 | What it means for operators | The requested close. Slot: the two operator problems the report names, each turned into a concrete change for an operator. If the report names none, say what you'd ask operators in your first 90 days instead of guessing |
| 13–14 | The commercial hook and the anti-pick | One sentence on how you'd want this measured, and that you'd agree the counting rule with commercial up front (it heads off A2 and A5). Then the one thing you would *not* do |

**Thesis options. Pick one to lead with and use a second as support. Each comes with a concession you must say out loud.** `[generic]` throughout: these are strategy shapes, not claims about Kelverton's current partnerships.

| Thesis | The case | Mandatory concession |
|---|---|---|
| T1. Build an ecosystem around the operator's workflow | Bring in partners whose products operators already run next to scheduling, so operators deal with fewer handoffs between systems. This is the thesis nearest F1, and you can say only what F1's quote says about it: you ran an ISV channel | Integration partners don't sell scheduling directly. The value shows up as retention and influence, which is the softest kind of number and exactly where Ross will push. Name that before he does |
| T2. Fewer, deeper operator partnerships | A small set of operators as design or reference partners who shape the product and act as proof for the rest of the market | It's slow. It concentrates risk in a few relationships. Operators may have limited capacity to co-develop. And it can bend the roadmap toward one operator's needs |
| T3. Partnerships as a commercial lever | Joint offers or bundles with partners that open deals or expand existing accounts | It risks channel conflict with Ross's team and costs margin. It also needs a counting rule agreed before launch, not after |

**Differentiation strategy**
- **Consensus item:** one finding from the report that you agree with, credited to the report (slot, beat 1–3).
- **Divergence:** one finding where you'd sequence or bet differently, with your reason. Slot: fill it from the report. If nothing in the report strikes you as wrong, diverge on *sequencing* rather than on substance.
- **Anti-pick:** one thing you'd deliberately not do in the first 18 months. One candidate is "I wouldn't set a partner-count target". That's a view about this role, and you can state it as a view. Don't present it as a lesson from your channel unless that's something you actually concluded. Slot: if the report shows the operator buyer base is concentrated, a broad reseller channel is the stronger anti-pick.

**Opening line, pending your approval:** "I'm going to read 'operator partnerships' as ___ (your definition). Tell me if that's wrong and I'll adjust as I go." Put it in your own words before Tuesday.

---

## Persona table

The recruiter's email establishes this session: two named interviewers, a POV and a Q&A. The weights below follow it. They are not an archetype guess.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Pressure, with Data-Driven Prober folded in (Ross) | Interrupts the POV's numbers, asks how £4M was counted, challenges "influenced" | **High.** The recruiter named it: "Ross will push on commercials". A Commercial Director with that brief probes figures as well as pushing, so the Prober's questions sit in the same bank | Pause and restate the question. Hold what F3's and F4's quotes carry through two follow-ups. Concede specifically and never upgrade the figure |
| Case/Strategist (Deepa, and Ross on commercials) | Follow-ups on the POV: what you'd cut, how you'd measure it, your first 90 days | **High.** She's the hiring manager, whose prior is Case plus Skeptic, and the round opens with a strategy deliverable | Clarify, then objective, approach, metrics and risks. Use the report's vocabulary. Challenge one premise per answer, respectfully |
| Skeptic (Deepa) | Quiet probing of F4 and F5: no rail, no quota, ISV rather than operators | **Medium-high.** Hiring-manager prior, and F4 and F5 are the gaps a future manager has to derisk | Rehearse C1 and C4 until they bore you. Bridge only from F1 and F2's quotes. Give a concrete ramp plan |
| Peer Evaluator (Ross, the sales seam) | "Where do partnerships and my team overlap?", credit for deals | **Medium.** `[generic]`: partnerships and commercial teams usually touch the same customers, and the recruiter's brief puts Ross on commercials | Talk about what you'd bring his team, not just what you need from it. Propose principles for the seam rather than pretending you know where it sits |
| Conversational | "Walk me through your background" at the handover from the POV | **Low.** It's a second round with a fixed format, but an opener is still likely | A prepared 90-second arc (E1) |
| Values/Behavioral | One "tell me about a time" in the Q&A | **Low.** The recruiter's description names no values round | Selection scaffolds (V1, V2) |

---

## Question banks

*Guidance cells are proposed language, pending your approval.*

### A. Pressure and Prober (Ross): commercials

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You said roughly £4M of influenced revenue. Walk me through how that was counted." | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the figure exactly as you gave it: roughly £4M, influenced, from the ISV channel. Keep "roughly" and "influenced" every time. Answer slot, in your own words: how it was counted, what it's sensitive to, which assumption behind it you'd defend least, and which part was yours. Say the weakest assumption before Ross finds it. If you don't know how it was counted, say so plainly. Never swap "influenced" for "generated", "closed" or "drove" | F3's figure is the only number you've given, and Ross has been briefed to push on commercials. EXP because it tests attribution, delivered under pressure |
| A2 | "You've never carried a quota. Why would I hand you a commercial number?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Concede first, plainly: "I've never carried a direct quota; my number has been influenced revenue." Hold on what the quotes carry: you ran the ISV channel and took it from 6 partners to 40, with roughly £4M influenced. Then go forward, as a plan: how you'd want to be measured here, and that you'd agree the counting rule with Ross before the year starts. Follow-up 1, "influenced is soft": don't upgrade it. Go back to A1's answer about how it was counted. Follow-up 2, "so would you take a number?": answer slot, say plainly whether you'd accept one in this role and on what terms. That's your call to make, and either answer is honest. Concede uncertainty specifically, never by folding: you haven't been held to a direct number, so the early quarters are where they'd find out | F4 is the gap a Commercial Director briefed to push will find first, so this question will come in some form. JD-type because it scores whether you can carry the commercial side of the role |
| A3 | "Six partners to forty — how much of that was actually you?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Start with the quote's own words: you were running the ISV channel, and it went from 6 partners to 40. Answer slot, in your own words: who else worked on it, which parts were yours (recruiting partners, onboarding, the programme itself, whatever is true), and what wasn't yours. If the team was just you, say so; if it wasn't, say who else was involved. "We" for context, "I" for what was yours | F6's headline growth figure, and attribution is the probe a quoted number attracts. EXP because it scores candour about your share |
| A4 | "An operator will be a reference customer if we discount. Do you take it?" | CASE | [generic] | Clarify first: what "reference" means here (calls, a case study, site visits) and for how long. Then structure it: what the reference is worth to the pipeline, what you'd trade instead of price (scope, timing, rights to use the story), what guardrails stop it becoming a precedent, and the fact that the sign-off sits with commercial. End on a recommendation. This question needs no claim about your past, so the guidance makes none | A live commercial trade-off of the kind Ross is briefed to push on. CASE because you're working it through live, not recalling it |
| A5 | "Eighteen months from now, what does partnerships put on my board slide?" | CASE | [generic] | Don't invent a number. Name the measure you'd use (for example influenced pipeline, retention among partnered operators, or attach rate), how it would be counted, and that the counting would be agreed with commercial. Then say you'd set the target after seeing Kelverton's baseline in your first 90 days, because you don't have it and won't guess it. Tie it back to the POV's commercial hook | Takes your 18-month POV (F1) into Ross's terms (F3 and F4). CASE delivery with JD content |

### B. Case/Strategist (Deepa): following up the POV

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What do you actually do in your first 90 days?" | CASE | [generic] | Three parts. First, listen: talk to operators and to Ross's team, and map the partnerships that exist today. Second, agree how partnership impact gets counted. Third, choose one of the POV's moves to prove by day 90. Name what you'd need from Deepa | The natural first follow-up to an 18-month plan (F1). CASE because it tests sequencing |
| B2 | "Half the budget. Which of your three moves goes?" | CASE | [generic] | Choose one and give the reason. Say what you'd lose by cutting it and what you'd watch to know whether that was the wrong call. Not choosing is the only wrong answer | Tests whether the POV was prioritised or just listed (F1) |
| B3 | "You've read our market report. Where do you disagree with it?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Give one agreement and one divergence, both from the POV's slots, with your reasoning. Don't recite the report back to them, and don't "correct" it at its authors; offer the divergence as a different bet. If you don't disagree with anything, say so and diverge on sequencing | The recruiter sent the report, so someone will ask what you made of it. CO because it scores homework and judgement |
| B4 | "Operators are our customers. What does partnership with a customer even mean?" | CASE | [generic] | Give your definition from the POV's opening and defend it with what it would change for an operator. Then name its limit: a customer partnership can blur into discounting or bespoke work, and you'd guard against that | Tests the POV's central premise and the required operator close (F2) |
| B5 | "How do you know in month nine that it's working?" | CASE | [generic] | One leading indicator (partner or operator activity), one lagging indicator (commercial outcome), and one indicator of operator benefit. For each, say what would make you change course | The measurement step behind the 18-month plan (F1), and Deepa will want it before Ross asks |

### C. Skeptic (Deepa): the gaps

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail. What will you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Plain words: "I haven't sold into rail." Then name the specific thing you'd be weakest at, which is your call to name honestly. Then a ramp plan with dates, as a plan: who you'd learn from, which operators you'd want to visit, what you'd read. Don't use F2's consulting work to shrink the gap. You can mention it only as context for how fast you'd learn | F5 is the most visible gap in your background. Naming it before you're asked shows calibration |
| C2 | "Your operator knowledge comes from consulting on bus and light rail. How much of it carries over to train operating companies?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Keep to the quote's scope: five years, transport consulting, bus and light rail network planning. Answer slot, in your own words: who the clients were and what part of their world you saw. Then say which parts you'd expect to carry over and which you'd expect not to. If none of your clients were operators, say so plainly. Never call it mainline rail experience or experience inside an operator | F2's evidence sits on an adjacent mode and on the consulting side, so it's the bridge the panel will test. EXP because it tests scope |
| C3 | "Why leave payments for rail, and why now?" | JD | [generic] | Selection scaffold: give two reasons that are true for you, one about the work and one about Kelverton specifically, and keep them consistent with what you told the recruiter. If the honest answer includes a push factor, say it neutrally. If no Kelverton-specific reason comes to mind, say what drew you to the role instead of inventing one | The standard motivation probe for a sector switch (F5, F7). Your material gives no reasons, so this is a scaffold, not a story |
| C4 | "Running 40 ISV partners is channel management. Operator partnerships sound closer to key-account work. Isn't this a different job?" | JD | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Concede what's different and don't argue it away. Hold on what the quote carries: you ran the ISV channel and took it from 6 partners to 40. Answer slot: if any of the channel work meant managing a few partners closely rather than many lightly, say which part, in your own words. If none did, say so and say how you'd approach that difference | F6 shows a channel. F1 is where that falls short of the role, and a future manager will test that seam |

### D. Peer Evaluator (Ross): the seam with sales

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Partnerships and my team both talk to operators. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles, not a map you can't know yet: who owns the commercial relationship, when partnerships brings sales in, and how disputes get settled quickly. Then say what you'd bring his team | The seam a Commercial Director lives on. Feeds into A5 |
| D2 | "How do you handle credit when a partner-sourced deal closes through sales?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | The quote carries only the fact that your figure was influenced revenue. Answer slot: if your channel had a rule for crediting partner-influenced deals, say what it was and what part you played in it, in your own words. If there was no such rule, or it wasn't yours, say so plainly and say how you'd propose one here. Either way, give a principle for agreeing credit before the deal closes, not after | F3's influenced figure is exactly the credit question in another form |
| D3 | "What would you need from my team in your first quarter?" | CASE | [generic] | Two concrete asks and one thing you'd give back in the same quarter | A reciprocity test. Shows you'd lighten his team's load, not add to it |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Before we start, walk me through your journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" "9 years in partnerships" | Ninety seconds, in order: consulting on bus and light rail network planning, then running the ISV channel at a payments company, then why Kelverton (from C3). Answer slot: say how the nine years add up, whether the five consulting years count among them or come on top. Use the smaller reading unless the larger one is true | F7: the arithmetic is the first thing a careful listener checks. EXP because the arc gets probed |
| E2 | "So what's caught your eye about rail since you started looking at us?" | CO | [generic] | Selection scaffold: one thing from the market report and one question you're genuinely curious about. If nothing specific comes to mind, say what you'd want to learn first. It's casual in tone but still scored | Casual questions on the role's hot topic are still scored. Touches F5 |

### V. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time a partner wanted terms that didn't work for your company." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a position you held, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | The theme comes from the recruiter's "commercials" (F3). Your material holds no story for it, so this is a scaffold |
| V2 | "Tell me about a time you told leadership something they didn't want to hear." | VAL | [generic] | Selection scaffold: a time the hard truth actually got through, with what you said and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A standard behavioural stem. The divergence in your POV invites it |

---

## Reverse questions

Your material has no public profile for either interviewer, so these are tied to their roles, not their career paths.

| # | To | Question | Why it lands |
|---|---|---|---|
| R1 | Deepa | "What does 'operator partnership' mean here today, and what would you want it to mean in 18 months?" | It tests your POV's premise in front of the person who owns it, and the answer shapes your first quarter |
| R2 | Ross | "How is partner-influenced revenue counted between your team and partnerships today?" | It shows you take the commercial seam seriously, and it tells you how you'll be judged |
| R3 | Both | "Which finding in the market report gets the most debate internally?" | It treats the report as a live argument rather than a set text, and it's diligence for you |
| R4 | Deepa | "What would make the first six months a clear success for you?" | It surfaces her real bar before you accept |
| R5 | Ross | "Where do you see the seam between partnerships and your team?" | A reciprocity question that answers D1 from his side |
| R6 | Both | "Will this role carry a number, and if so, how is it set?" | It's the question behind F4. Knowing the answer matters more to you than to them |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried, hit or owned a sales quota | A negative you stated, F4 | "I've never carried a direct quota; my number has been influenced revenue." |
| Has sold into rail | A negative you stated, F5 | "I haven't sold into rail." |
| Generated, closed or drove £4M | Inflated form of F3 | F3's quote at its own scope: roughly £4M of influenced revenue. Your material says influenced, not generated. A1's slot asks only how it was counted |
| Personally built or recruited all 40 partners | Inflated form of F6 | F6's quote at its own scope: running the ISV channel, which went from 6 partners to 40. A3's slot asks which part was yours |
| Mainline or heavy-rail experience | Inflated form of F2 | F2's quote: bus and light rail network planning, in transport consulting. C2's slot stays inside that work |
| Worked inside or for train operators | Inflated form of F2 ("from the other side") | F2's quote at its own scope. Your material says consulting, not working inside an operator. C2's slot asks who the clients were |
| Has run operator or key-account partnerships | Inflated form of F1 | F1's quote: an ISV channel at a payments company. C4's slot stays inside the channel |
| Fourteen years of experience | Inflated form of F7 | "9 years in partnerships", with E1's slot settling whether consulting is part of it |

---

## Sources

**Provided:** your message, including the recruiter's email quoted in it. The market report was attached to your email, not shared with me; its contents are not used anywhere in this pack. No dossier.

**Searches sent, all refused by host permissions:**
- "Kelverton Rail values": refused
- "Kelverton Rail scheduling software train operating companies news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager rail software job description UK": refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The search was refused. It would have given the value names that theme V1 and V2. No cheat sheet in either case, because no values round is detected |
| 2. Kelverton Rail interview process, partnerships | skipped | The recruiter's email already fixes the session: a panel with two named interviewers, a 15-minute POV, then Q&A with a commercial push. The persona weights follow it |
| 3. Kelverton Rail strategy and recent news | unavailable | The search was refused. It would have grounded B3, E2 and the POV theses in current company facts. The report you hold covers this, as the upgrade menu notes |
| 4. Deepa and Ross at Kelverton Rail | unavailable | Both searches were refused. They would have given a panel read, adjusted persona weights, and reverse questions tied to each interviewer's path |
| 5. A representative Senior Partnerships Manager JD | unavailable | The search was refused. It would have moved F4 to F7 from `[generic]` to `[inferred]` and added JD-tagged questions |

---

## Upgrade menu

- **The JD text** → F4 to F7 become quoted requirements, any eligibility terms (location, travel, right to work) show up as rows, and the coverage table checks against the real list.
- **The report's headline points, whatever you're comfortable pasting** → the POV's four slots get filled with you, B3 and E2 become grounded, and the theses can be ranked against Kelverton's own findings.
- **Web search enabled** → the five refused targets run: Kelverton's values, recent news, a representative JD, and Deepa's and Ross's public professional profiles for a panel read and path-tied reverse questions.
- **One email to the recruiter: what does Kelverton mean by "operator partnerships", and is there a partner programme today?** → the POV's opening definition stops being a guess, and B4 and R1 sharpen.
- **Your answers to the slots in A1, A3, C2 and E1, told to me outside a drill** → they become quoted evidence, and F1, F2, F3, F6 and F7 regenerate with stronger bridges.
- **A tuesday-dossier.md from an underwriting pass** → evidence-graded objections and a prohibited list built from claims you've confirmed. Useful, not needed.
