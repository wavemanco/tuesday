I'm checking public sources on Atlas Freight first (values, interview process, recent news), then I'll build your prep pack.
I've saved your prep pack as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-2-denied-239f140e/atlas-freight_operations-manager_interview_pack.md`. It has 22 practice questions with suggested answers, all built from your background and the job description.

**What it's missing:** I couldn't look anything up about Atlas Freight, because web search permission was refused. So there's nothing on their values, how they run interviews or recent news. You also don't know who's interviewing you, so every interviewer style gets equal weight.

**Where you're strong:**
- 7 years in warehouse and distribution ops.
- The 40% cut in the mis-pick rate.
- Running the peak-season surge plan two years in a row.
- The green belt, which covers the Lean/Six Sigma "plus".

**The biggest risk is the jump from 3 supervisors to 12, and from one site to four.** That's question B1, the best use of your prep time.

**Other gaps to prepare for:**
- **Power BI:** you've never used it. Say so plainly and give a learning plan. If you start learning before the interview, you can say that too.
- **"5+ years leadership required":** your 7 years is in operations generally. Know exactly how many of those years you've been a supervisor or manager, and don't round up.
- **No numbers on on-time performance or cost per shipment:** be ready to say how you'd go after these.

**The pack also covers:**
- Prepared answers on how the 40% was counted and how much of it was you.
- Questions to ask them.
- A list of claims not to make, like saying you ran the site when what you ran was its surge plan.

If you want, I'll play the skeptical interviewer and run B1 with you live, with real follow-ups.
I can also save a `tuesday-dossier.md` file listing the gaps this prep turned up, so you can bring it to later sessions.
If you'd like the pack as a Word document, I can convert it.

Two questions:
1. Do you know who you're meeting: a recruiter, your future manager, a panel, or several rounds? Has the recruiter sent anything about format, like a presentation or a case? Either answer changes how the questions are weighted.
2. Do you want me to research Atlas Freight? It needs web search permission. The standard pass is up to 6 searches and 2 page reads: their values, interview process and recent news. A deeper pass adds up to 6 more searches and 2 more page reads, takes several minutes, and covers strategy, other candidates' interview reports and recent changes at the company.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, 4 terminal sites, 12 supervisors
**Company:** Atlas Freight (regional logistics, 800 employees, per the JD you pasted)
**Interviewer:** unknown. The round type is unknown too, so this is a full-loop pack with flat persona weights. That makes it weaker than a pack built for a known round, and the upgrade menu says what fixes that.

---

## How to use this pack

- **Personas** describe *how* a question is asked. **Types** describe *what* is being scored.
- **Type tags:**
  - **VAL**: behavioral. Does your past behavior show the values they care about?
  - **EXP**: experience deep-dive. Do your claims survive scrutiny, and what was actually you?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Have you done your homework on them?
  - **CASE**: live problem. How do you structure and reason through a problem from the role?
- **IDs:** F1–F9 are fit-snapshot rows. Questions use letters by persona: A, B, C, D, E, G, H. The letter F is skipped so question IDs never collide with fit rows.
- **Provenance labels:** `[grounded]` means traceable to what you gave me. `[inferred]` means derived from it, with the derivation named. `[generic]` means a common pattern for this kind of role, with no claim about you or Atlas.
- **Answer slots** are instructions for what you'll say in the interview. They're not questions for me. Each one has two honest branches, and either one is a good answer.
- **Guidance is scaffolding, not a script.** Every suggested wording here is pending your approval. Change anything that isn't how you'd say it, and cut anything that isn't true.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution, not terminal, and the words stay there: "I've spent seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's terminal line makes a probe on terminal or cross-dock work likely. If any of your work has been in a terminal or cross-dock setting, say what it was and what part was yours. If none has, say so plainly and stay with the warehouse and distribution work you did |
| F2 | "across 4 sites" — JD | none given | none | [grounded] | discovery | Your material does not show work across more than one site. Answer slot: the JD's four-site line makes a probe on multi-site work likely. If you have coordinated with, covered for, or worked across other sites, say when and what was yours. If you haven't, say so plainly and stay with the work you've described |
| F3 | "drive on-time performance" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A mis-pick rate measures accuracy, not on-time performance, so don't stretch the bridge. Answer slot: if you tracked on-time, cutoff or late-shipment figures at your site, say which ones and how they moved, in your own words. If you didn't, say so plainly and say how you'd learn Atlas's definition first. Link the mis-pick result to on-time performance only if you saw that effect counted |
| F4 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material does not show a cost figure. Answer slot: if you have owned or reported any cost figure for your site, say which one and what you did with it. If you haven't, say so plainly and describe how you would break cost per shipment down in your first weeks, as a plan |
| F5 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors, not twelve, and the words stay there: "Today I'm a senior shift manager over three supervisors." Answer slot: the JD's twelve-supervisor line makes a probe on how you lead supervisors likely. Say how you lead the three, in your own words, and leave out anything you don't actually do. Taking the span to twelve is a plan, and you say it as one |
| F6 | "build reporting in Excel/Power BI" — JD, the Excel half | "solid Excel, never used Power BI" — your message | low | [inferred] | discovery | Being solid in Excel is a skill. It doesn't show you've built reports. Answer slot: if you've built reports or trackers in Excel that other people read, say what they tracked and who used them. If you haven't, say so plainly and stay with what you do in Excel |
| F7 | "build reporting in Excel/Power BI" — JD, the Power BI half | "solid Excel, never used Power BI" — your message | none | [grounded] | capability | You've said this gap yourself, and wording can't close it. Words: "I haven't used Power BI." Then say how you'd learn it, as a plan and never as something you've done. Don't add anything to make the gap feel smaller |
| F8 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops is a different claim from seven years leading. This is a length-of-experience line, not a gate, but a "required" years line may be screened literally, so know your number. Answer slot: count the years you've held a supervisor or manager role. If it's five or more, give the number. If it's fewer, give the number plainly and don't round up |
| F9 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. It's a certification with nothing inspected behind it, so expect a light probe. Lead with it in your own words: "I'm green belt certified." Answer slot: if you're asked when you certified or what you've applied it to, answer in your own words. If you haven't applied it to a project, say so plainly |

---

## Persona table

No loop source establishes Atlas's interview process: the research calls were refused, and you don't know who you're meeting. So these weights fall back to the **generic archetype** (screen, then hiring manager, then panel), with flat weights. They rest on a pattern, not on Atlas's actual process. That archetype has no values-style round, so the pack has no values cheat sheet.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the job: a terminal's on-time performance slips, cost rises, reporting needs designing | Equal weight. The round is unknown, and a hiring manager for an ops role usually brings live problems | Clarify, then objective, segment, approach, metrics, risks. Think aloud. Respectfully challenge one premise per case |
| Skeptic | Quiet probing of the gaps: the span of 3 vs 12, one site vs four, warehouse vs terminal, years of leadership | Equal weight, but it holds four questions because the highest-ROI question (B1) sits here | Rehearse B1 until it's boring. Build bridges only from your quoted sentences, name the limit yourself, and give a concrete ramp plan |
| Data-Driven Prober | Goes after the 40%, the surge plan's results and how on-time performance is measured | Equal weight. Your one headline figure is the obvious target | Know what you can and can't say about how the 40% was counted, and say plainly where you don't know |
| Pressure / Stress | Time-boxed answers, "how much of that was you", "why isn't that a dealbreaker" | Equal weight, with no signal either way | Pause, restate the question, anchor in what you actually said, and hold through two follow-ups before you concede anything real |
| Values / Behavioral | "Tell me about a time…" stories on leading supervisors, giving bad news upward, and change that met pushback | Equal weight. Atlas's values weren't researched, so these are themed on the JD | Use "we" for context and "I" for your part. Pick stories where something actually changed |
| Conversational | Friendly openers: your journey, why you're leaving, what you're doing with Lean | Equal weight. Nearly every loop has one, and it's still scored | Have a 90-second arc ready. Treat casual questions about the JD's plus-skill as scored |
| Peer Evaluator | Another ops or site manager pricing what you add or cost their site | Equal weight. Panels for multi-site roles often include a peer | Talk reciprocity: say what you bring their site. Propose principles for the seams between sites rather than pretending to know them |

---

## Question banks

Every persona is equal weight, so each gets three questions, except the Skeptic, who gets four.

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You start Monday. On-time performance at one of the four terminals has been slipping for three weeks. Walk me through your first 48 hours." | CASE | [generic] | Clarify first: how on-time is measured here, which lanes, shifts or customers are affected, and whether it's inbound, outbound or both. Then segment and form two or three hypotheses you'd test with data. Separate a quick containment step from root cause. Name the one metric you'd watch daily and who you'd talk to on the floor. Nothing here needs a claim about your past, so don't make one | This tests F1 and F3's requirements as a decision rather than a record. CASE because it's a live problem, and `[generic]` because it's a pattern for the problem, not a fact about Atlas |
| A2 | "Cost per shipment is up across the network. Where do you look first?" | CASE | [generic] | Start by asking how Atlas counts cost per shipment: which costs are in the numerator, and which shipments are in the denominator. Then break it into the parts a terminal manager can move, such as labor and overtime, re-handling, damage or claims, and the volume or mix underneath. Then pick where you'd start and why. It's a structure, not a claim about your past | This is F4's requirement, which your material doesn't reach, so the case is where you can show reasoning without a record. CASE delivery on JD content |
| A3 | "What daily reporting would you want across four sites, and how would you build it?" | JD | [grounded] "solid Excel, never used Power BI" | Content first: a short list of measures you'd review daily (on-time, cost per shipment, plus one or two leading indicators), who owns each one and what triggers a conversation. On the build: you're "solid" in Excel, so say you'd start there. Say plainly, "I haven't used Power BI," and give your plan to learn it, as a plan. Answer slot: if you've built Excel trackers that other people read, say what they tracked. If you haven't, say so plainly | This covers F6 and F7. JD because it scores the stated reporting requirement head-on |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You lead three supervisors today. This role is twelve, across four sites. Why should I believe you can make that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "7 years in warehouse and distribution ops" | **The highest-ROI rehearsal in this pack.** Name the limit before they press: "Today I'm a senior shift manager over three supervisors." Then say what the quotes carry: seven years in warehouse and distribution ops, and the site's peak-season surge plan, which you ran two years running. Answer slot: if you've coordinated across sites or led beyond your own shift, say when and what part was yours. If you haven't, say so plainly and stay with the three supervisors and the surge plan. Then give your ramp plan as a plan: how you'd learn four sites and twelve supervisors in the first 90 days. Hold through two follow-ups by coming back to what you've done, never by adding to it. Concede only what the quote says: "Today my span is three supervisors" | F5 and F2 are the widest gaps between your material and the JD, so this objection will come in some form. JD because it scores the role's span directly |
| B2 | "You've got seven years in ops. How many of those were in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Start with the quote: seven years in warehouse and distribution ops, currently a senior shift manager over three supervisors. Answer slot: give the number of years you've held a supervisor or manager role, in your own words. If it's five or more, say it cleanly. If it's fewer, say the number plainly and don't round up. Then point to what the quotes carry | F8's requirement is marked "required", so the number may be checked. Know it cold and say it exactly. JD because the requirement is stated |
| B3 | "Your background is warehouse and distribution. Terminal operations is different. What carries over, and what doesn't?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | What carries over is what the quotes say: seven years in warehouse and distribution ops, the 40% mis-pick cut from the pick-path redesign, and the surge plan two years running. Answer slot: if any of your work has been in a terminal or cross-dock setting, say what it was. If none has, say so plainly and name the first things you'd want to learn about running a terminal, as a plan. Don't describe terminal work as if you've done it | This is F1's transferability gap. The question invites you to claim the difference away, and the honest answer is stronger |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Pick the one you actually believe. The gap you've already named is Power BI: "I haven't used Power BI." Follow it with a concrete learning plan, as a plan. If you start a Power BI tutorial before the interview, you can say so truthfully. If you haven't started one, don't say you have. Don't pick a fake weakness | F7 is the one gap you stated yourself, which makes it the safest honest answer. JD because it asks you to grade yourself against the posting |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 40% mis-pick reduction. How was it counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats are the ones the quote states: the mis-pick rate, cut 40%, by redesigning the pick path. Tell them in your own words. Answer slots, each in your own words: how the 40% was counted (what period, and what counted as a mis-pick); what the figure is sensitive to; which assumption behind it you'd defend least, said before they ask; and which part was yours. "I don't know how it was counted" is an honest answer to any of them. Never give a method you can't repeat under a second question | This is your headline metric, and probers target it first. EXP because it tests whether the figure survives scrutiny |
| C2 | "How do you measure on-time performance, and what would you want to know about how we measure it?" | JD | [generic] | Answer slot: if you've tracked on-time, cutoff or late-shipment figures, say which ones and how, in your own words. If you haven't, say so plainly. Then turn it into definition questions you'd ask Atlas: on-time against what date or appointment, what counts as late, and which causes the terminal controls. Asking how something is counted is itself the skill being scored | This covers F3's requirement, which your material doesn't reach. JD because on-time performance is a headline responsibility |
| C3 | "The peak-season surge plan you ran two years running: how did you know whether it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats are the ones the quote states: the site's peak-season surge plan, which you ran two years running. Answer slot: the JD's on-time and cost lines make a probe on results likely. If you have figures for either peak, say what they were and how they were counted. If you don't, or if no figures were kept, say so plainly and describe what the plan covered, in your own words | This is F1's strongest quote, so it will be probed. EXP because the question is about what the quote doesn't yet show |

### D — Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, then use the four quotes as your sixty seconds: seven years in warehouse and distribution ops, the 40% mis-pick cut from the pick-path redesign, the site's surge plan two years running, and green belt certified. Concede the internal candidate's knowledge of the terminals without arguing it, and never knock them. End on what you'd do in your first month, as a plan | This is a time-boxed composure test on the B1 objection. JD because it asks you to make the case against the role |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold, then concede. Restate the quote's facts. Answer slot: say which part of the redesign and the result was yours, and who else was involved, in your own words. If others did parts of it, name the parts plainly. Hold through two follow-ups on what was yours, and concede specifically where it was shared. Don't fold on the parts that were yours just to ease the moment | This is the attribution probe on your headline metric, under pressure. EXP because it scores what was actually you |
| D3 | "You've never used Power BI, and this role builds reporting in it. Why isn't that a dealbreaker?" | JD | [grounded] "solid Excel, never used Power BI" | Hold: "I haven't used Power BI. I'm solid in Excel." Give a concrete, time-bound learning plan, said as a plan. If you've started learning by the interview, say so truthfully. Through follow-ups, keep coming back to the plan and to Excel. Concede that it's a real gap, specifically, and don't argue that it doesn't matter | F7 is a stated gap. The negative in the question comes from your own sentence, so it's fair game. JD because the tool is named in the requirement |

### E — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered bad news about performance to your own manager." | VAL | [generic] | Selection scaffold: pick a time you told someone above you something they didn't want to hear about results. It needs a named issue, what you said and how, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Owning on-time and cost numbers across four sites means reporting bad weeks upward. VAL because it scores behavior, not knowledge |
| E2 | "Tell me about a time one of your supervisors was underperforming. What did you do?" | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Pick from your three supervisors. Selection scaffold: it needs a clear performance gap, what you did and when, and an outcome, whether it improved or not. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's twelve-supervisor line (F5) makes this near-certain. VAL delivery on JD content |
| E3 | "Tell me about a time you changed how a team worked and people pushed back." | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The pick-path redesign is your obvious candidate, but only if it fits. Answer slot: if there was pushback on the redesign, say what it was and how you handled it. If there wasn't, say so plainly and choose another change you led, or give how you would handle pushback | The JD's Lean/Six Sigma line (F9) and "drive" language imply process change. VAL because it scores how you bring people along |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built from the five quotes, in this order: seven years in warehouse and distribution ops; senior shift manager over three supervisors now; the 40% mis-pick cut from redesigning the pick path; the site's surge plan, which you ran two years running; green belt certified. Answer slot: then say why this role and why Atlas, in your own words. That part is yours, and the pack has nothing to put there | This is the near-universal opener. It's scored for economy, so a scripted arc is worth more than any single answer. EXP because it lays out your record |
| G2 | "What are you actually doing with Lean or Six Sigma these days?" | EXP | [grounded] "green belt certified" | Start with "I'm green belt certified." Answer slot: if you've applied it to a project, the pick-path redesign included, say what you used and what changed. If you haven't, or the redesign didn't use it, say so plainly and keep the two separate | The JD's plus-skill (F9), asked casually. EXP because it checks what's behind the certification |
| G3 | "Why are you looking to move on from your current role?" | VAL | [generic] | Answer slot: your real reasons, in your own words, framed toward what this role offers rather than away from your current employer. Keep it under 45 seconds and never knock where you are now | The "why leave, why now" check comes up in casual registers. VAL because it scores motivation consistency |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "If you and I both ran terminals in this network, where would you expect the seams between us to be, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know Atlas's seams. Propose principles instead: agreed handoff standards between sites, shared definitions for on-time and cost, a fast way to escalate a disagreement, and talking it out before escalating. Ask what the friction points are today | This covers F2's multi-site requirement, from the peer's side. CASE because it's a live working problem |
| H2 | "How do you handle credit when work spans shifts or teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Use "we" for context and "I" for your part. Answer slot: for the pick-path redesign or the surge plan, say who else was involved and what part was yours, in your own words. If you did it alone, say so plainly | A peer is pricing whether you'll share or take credit. VAL because it scores working behavior |
| H3 | "What would you need from your supervisors in your first month, and what would they get from you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Answer slot: say how you work with your three supervisors today, in your own words, and leave out anything you don't actually do. Then give your first-month plan for twelve, as a plan: what you'd ask of them, and what you'd give them, such as clear priorities, quick decisions and cover when they need it | F5's span question, asked as reciprocity. JD because it scores leading the stated team |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations (F1) | A1, B3, C3 |
| Across 4 sites (F2) | B1, H1 |
| Drive on-time performance (F3) | A1, C2 |
| Cost-per-shipment down (F4) | A2 |
| Lead a team of 12 supervisors (F5) | B1, E2, H3 |
| Build reporting in Excel (F6) | A3 |
| Build reporting in Power BI (F7) | A3, B4, D3 |
| 5+ years operations leadership required (F8) | B2 |
| Lean/Six Sigma a plus (F9) | G2, E3 |
| Your 40% headline figure | C1, D2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does Atlas define on-time performance at the terminals, and where is it today against target?" | It shows you think in definitions before numbers, and the answer tells you how big the job is |
| R2 | "How is cost per shipment calculated, and which parts of it does this role actually control?" | It separates what you'll be judged on from what you can move, and it's something you genuinely need to know |
| R3 | "How are the twelve supervisors spread across the four sites, and how much of my week would you expect me to spend at each one?" | It shows you're already thinking about span and presence. The answer also sizes the jump from three |
| R4 | "What reporting exists today in Excel or Power BI, who maintains it, and is there analyst or training support?" | It shows you're facing the Power BI gap honestly, and it tells you how steep the ramp is |
| R5 | "What would make you say, ninety days in, that this hire was the right call?" | It invites them to state the real scorecard, which you can then answer to in follow-ups |
| R6 | "What's the biggest difference between the four sites right now?" | It signals multi-site thinking, and the answer tells you where the first problem is |

---

## Prohibited claims

These are claims this pack won't coach, built from the fit snapshot before the question banks were written. Each one is a wording you might reach for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the site, or owned its daily operations | Inflated form of F1's quote "ran the site's peak-season surge plan two years running" | F1's quote at its own scope: you ran the plan, which isn't the same as running the site. B1, B3 and C3 stay inside that |
| Has led a supervisor team larger than three | Inflated form of F5's quote "currently a senior shift manager over 3 supervisors" | F5's quote at its own scope. The span you've shown is three supervisors. B1's concession is "Today my span is three supervisors", and H3's slot stays with the three |
| Has seven years of operations leadership | Inflated form of F8's quote "7 years in warehouse and distribution ops" | F8's quote at its own scope. B2's slot asks only how many of those years were in a supervisor or manager role |
| The 40% mis-pick cut as an on-time or cost result | Inflated form of F3's quote "cut mis-pick rate 40% by redesigning the pick path" | F3's quote at its own scope: a mis-pick rate, cut 40%, through the pick path. C1's slots ask only how the figure was counted and what was yours |
| Has used Power BI | Negative you stated, F7 | Use the plain acknowledgment F7 gives: "I haven't used Power BI." There's no slot for it |

---

## Sources

**Provided documents:** the job description text you pasted (Operations Manager, Atlas Freight), and your background as you described it in your message.

**Searches sent:** 3. All three were refused because web search permission wasn't granted in this session, so nothing came back.

- `"Atlas Freight" logistics company values mission`: refused
- `"Atlas Freight" operations manager interview process`: refused
- `"Atlas Freight" regional logistics terminals news 2026`: refused

No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have moved a values cheat sheet, if a values-style round were detected, and VAL questions themed on Atlas's published values instead of the JD |
| 2. `Atlas Freight interview process operations` | unavailable | The search was refused. It would have moved persona weights, from flat to the actual named rounds, and shown whether a values round exists |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have moved a CO question on Atlas's current situation and made A1 and A2 company-specific |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Who you're meeting and what kind of round it is** → real persona weights instead of flat ones, with the 22 questions re-sized toward the personas you'll actually face. If there are several rounds, you'd get a mini-pack for each
- **The interviewer's name** → a "reading the interviewer" section and a reverse question tied to their own career path
- **Web search permission** → Atlas's published values, if any (VAL questions, plus a cheat sheet if a values round shows up), its documented interview steps (persona weights), and recent news (a grounded CO question). That's the standard pass. A deeper pass adds up to 6 more searches and 2 fetches, takes several minutes, and covers strategy, loop reports and recent org changes
- **Any recruiter prep email or note** → coverage of anything they pre-announced, such as a presentation or a case, with its own build section
- **Your resume** → more of your own sentences for the fit snapshot. F2, F4 and F6 could move off "none given", and the scaffolds in E1 and E2 could become mapped stories
- **Your answers to the slots in F2, F3, F4, F6 and F8** → those rows, and B1, B2, C2, A2 and A3, regenerate with your words instead of slots
- **Your green belt certificate details (issuer, year)** → F9's confidence could rise from medium, since the certificate is the inspectable artifact here
- **How much prep time you have** → a prioritized prep schedule sized to it
- **A `tuesday-dossier.md` from an earlier underwriting of this role** → an evidence-derived top objection and a prohibited list built on confirmed evidence. This pack is complete without one
