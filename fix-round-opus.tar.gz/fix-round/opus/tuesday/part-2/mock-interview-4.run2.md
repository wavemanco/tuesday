Lots of reference files. Reading them in parallel.
Your prep pack is built, and I'm fixing one ID clash before handing it over.
Your prep pack is saved as `quartzline_product-manager-platform-apis_interview_pack.md`. It's set up for a 45-minute conversation with the hiring manager, as you described it, and every answer is built from what your dossier says you've confirmed.

**What to rehearse first**
- **A1** is your dossier's objection: you've never held the PM title or owned a roadmap, so why you over a PM with three years in the job. The answer works in three steps:
  - Say plainly that you haven't held the title or owned a roadmap.
  - Give the integrations, the playbook and the roadmap-input sessions in exactly the terms your dossier confirms, and say outright that this is next to the job, not the job.
  - Finish with a plan for your first months, which leads into your question about who decides what.
- **B1 and B2** are the live problems a hiring manager is likely to set: taking over the roadmap, and how to measure whether partners are adopting the API.
- **Q1 and Q2** are the dossier's two open questions for them: who makes roadmap decisions versus the two squad leads, and how adoption is measured today.

**Missing from the pack:** web search permission wasn't granted, so I couldn't look up Quartzline's values, how they run interviews, or their current strategy. The company-specific and case questions are general practice for this kind of role, not based on Quartzline's own material.

Today is Thursday 12 November. If the interview is today rather than next week, practise A1, B1 and the reverse questions, and treat everything else as backup.

I can play the Skeptic and put A1 to you as a live practice round, with follow-ups that react to what you say.
I can also update `tuesday-dossier.md` with what this prep turned up: the objections and the requirements where you had no story yet.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager (your words). Interviewer's name not given.
**Built on:** your `tuesday-dossier.md` (v1.1, 2026-08-14, decision `conditional_go`). The dossier's two conditions shape everything below: the bridge is positioned as adjacent and never as PM experience, and the squad-authority question gets asked in the room.

---

## How to use this pack

- **Personas** are how a question gets asked: the register, the pressure, the follow-ups. **Types** are what the question is scoring.
- Type key:
  - **VAL**: whether your past behaviour shows the values they've published
  - **EXP**: whether your stated experience holds up under scrutiny, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: how much homework you've done on the company's strategy and market
  - **CASE**: a live problem from the role, solved out loud
- **Provenance labels**: `[grounded]` traces to your dossier or to the requirements as supplied. `[inferred]` is derived, and the derivation is named. `[generic]` is a role-family pattern that makes no claim about Quartzline.
- **Answer slot**: an instruction for the interview itself, never a question for you to answer here. It names what the interviewer will likely probe and gives two honest branches. Either branch is a good answer.
- Guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

Evidence quotes come from the dossier's `verified_candidate_evidence`, labelled VE1 to VE3 in the order the dossier lists them. Requirement text comes from the dossier's `role_profile`, which stands in for the JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must-have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | low | [inferred] | transferability | Derivation: the dossier grades this requirement low and allows only a bridge. The bridge is positioned as adjacent and never as PM experience, and the words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The plain acknowledgment comes from prohibited_claims: "Having held a product manager title or role", so the words are: "I haven't held a product manager title." Never count integration years as PM years |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibility | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)". The words: "I haven't owned a product roadmap." After that comes a ramp plan, spoken as a plan and never as a past. No bridge here, not even from VE3. The underwriter looked and found nothing |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must-have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | transferability | Your material says integrations of the vendor's APIs, not the API product itself, and the words stay there. Answer slot: the shipped-products line makes a probe on the integrations' stages likely. If decisions in any of those stages were yours, say which and how you decided, in your own words. If none were, say so plainly and stay with leading the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1, "Wrote the internal integration playbook her team uses" — dossier VE2 | high | [grounded] | discovery | The quotes touch REST APIs and architecture but don't show work with docs or schemas specifically. Answer slot: expect a probe on reading or writing API docs and schemas. If you worked with them in those integrations or in the playbook, say how, in your own words. If you didn't, say so plainly and stay with the integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | discovery | The client side is in the quote. Engineering and sales are not. Answer slot: expect a probe on who else you had to bring along. If engineering or sales people were part of those integrations, say who and what you did with them, in your own words. If they weren't, say so plainly and stay with the clients |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | medium | [grounded] | discovery | The dossier says this was confirmed, with limited inspectable proof, so expect a probe. Volunteer that limit before it gets pulled out of you. The quote puts product on the receiving end of your input, and the words keep it there: input fed to product, not decisions made |
| F7 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [inferred] | discovery | Derivation: the dossier's clarify area, "Agile delivery inside a product org (R5)". No verified entry speaks to it. Answer slot: the requirement's own wording, agile delivery, is the likely probe. If you worked that way, say how, in your own words. If you never did, say so plainly, and say what you'd want to confirm about how they define it |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibility | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | transferability | Requirements for an integration are a different document from a product spec, and the words stay at the integration. Answer slot: if you wrote those integrations' requirements yourself, describe what they covered, in your own words. If someone else wrote them, say so and stay with leading the integration. Never claim you set a squad's priorities |
| F9 | "Run discovery with integration partners" — dossier role_profile responsibility | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | medium | [grounded] | transferability | Gathering client evidence for product is adjacent to running partner discovery, not the same thing, and the dossier expects a probe. The words: "I ran quarterly roadmap-input sessions feeding client evidence to product." How the sessions ran is an answer slot. If asked, say how in your own words. If there's little on paper from them, say so |
| F10 | "Define and track adoption metrics" — dossier role_profile responsibility | none given | none | [grounded] | discovery | Your material doesn't show metric work. Answer slot: if you tracked anything about how clients used the APIs after go-live, say what was counted, in your own words. If you didn't, say so plainly and answer B2 as a plan |

---

## Persona table

The loop for this session comes from your own words: one 45-minute conversation with the hiring manager. No values-style round is named, so none is assumed.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent questions about the missing PM title and roadmap ownership | **High.** A hiring manager is de-risking gaps, and the dossier names this exact objection. F1 and F2 are the widest gaps in the snapshot | Concede plainly first, then give the adjacent work at its own scope, then the ramp plan. Rehearse A1 until it's boring |
| Case / Strategist | Live problems from the JD: inheriting the roadmap, defining adoption, partner conflicts | **High.** The hiring-manager prior, plus four JD responsibilities that work as live problems | Clarify, then objective, segments, approach, metrics, risks. Think out loud. Ask what's yours to decide before you decide it |
| Data-Driven Prober | "How was the 30+ counted?", plus docs and schemas | **Mid.** VE1 carries the only headline number, and R3 invites depth checks | Know how the figure was counted, or say you don't. Name your weakest assumption before they do |
| Conversational | The opener, the "walk me through" and the close | **Mid.** A 45-minute conversation format, and casual questions here are still scored | A 90-second arc built only from VE1 to VE3. Never say "I think you've covered everything" |
| Peer Evaluator | The hiring manager asking, collegially, how you'd work with the two squad leads | **Low.** No peer in the room, but the squad-authority question is a live dossier risk | Propose principles for the seam rather than pretending to know where it sits |
| Pressure | A time-boxed version of the objection, "how much was actually you" | **Low.** Not a hiring-manager default, but the objection may arrive sharp | Pause, restate, hold through two follow-ups, concede specifically |
| Values / Behavioral | Generic behavioural prompts | **Low.** No values round named, and Quartzline's published values could not be researched | Selection scaffolds with honest branches |

---

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD, EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", "Wrote the internal integration playbook her team uses", "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)"; prohibited_claims: "Having set prioritization for an engineering squad" | **The highest-ROI rehearsal in this pack. Your dossier's underwriter named this objection.** (1) Concede first and plainly: "I haven't held a product manager title, and I haven't owned a roadmap." (2) Give the adjacent work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I wrote the internal integration playbook my team uses. And I ran quarterly roadmap-input sessions feeding client evidence to product." Then volunteer VE3's limit. Answer slot: if there's something from those sessions you could describe concretely, say what. If there's little on paper, say so. (3) Position it: "That's adjacent to this job, not the same job." Don't tell them what your work proves; let them draw that. (4) Why you: answer slot. Say in your own words why you want this move. (5) The ramp plan, spoken as a plan: learn which decisions are yours and which are the squad leads', get the adoption baseline, sit in on partner conversations. That leads naturally into reverse question Q1. **Follow-up 1:** "So who decided what went on the roadmap?" Your input went to product. Answer slot: if you know what product did with it, say so in your own words. If you don't, say you don't know. **Follow-up 2:** "Have you ever prioritised for engineers?" Say: "No, I haven't set prioritization for an engineering squad." Then go back to the integrations. **Follow-up 3:** "Then why not the PM?" Hold. Don't argue their years down; grant them. Return to beats 2 and 5 | Named by the dossier and aimed at F1 and F2, the widest gaps. Every negative in it is sourced to a dossier field, so it is asked as written. JD because it scores R1; EXP because the hold rests on what was actually yours |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it before they do: "Owning the roadmap. I haven't owned a product roadmap." Then the ramp plan, as a plan: what you'd learn first, from whom, and by when. No bridge here, and don't pick a fake weakness to dodge the real one | F2 is a capability gap the dossier recorded. Pre-empting it is the honest move and the strongest one. JD because it scores the role's core responsibility |
| A3 | "Tell me about the API or platform products you've shipped." | JD, EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer with what you led, in the quote's terms: integrations of the vendor's REST APIs, end to end, through go-live. Answer slot: if decisions in any of those stages were yours, say which and how you decided, in your own words. If none were, say so plainly and stay with leading the integrations. Don't drift into describing the vendor's product as yours | F3 is a must-have bridged by adjacent work. The question presupposes shipped products, which is the JD's premise and not your quote's, so the guidance doesn't adopt it |
| A4 | "Why move from integrations into product management now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: say in your own words what's pulling you toward the move. If those roadmap-input sessions are part of it, say how. If they aren't, leave them out and say what is. Keep it forward-looking. A motive that sounds rehearsed reads worse than a plain one | The Skeptic's "why now" probe, sharpened by F1. JD because motive consistency is scored against the role |
| A5 | "Tell me how you've worked in agile delivery." | JD | [inferred] | Clarify strategy, per the dossier. No verified entry speaks to agile, so nothing about your past goes in except through the slot. Answer slot: if you worked that way, say how, in your own words. If you never did, say so plainly, then: "Here's what I'd want to confirm about how you run it." | F7 is a preferred requirement graded low. A rehearsed honest answer stops a minor gap turning into a credibility gap. `[inferred]` because it rests on the dossier's grading |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit the partner API roadmap. What do you do in your first 90 days?" | CASE, JD | [generic] | Clarify first: which calls are yours and which are the squad leads'. That's the dossier's open risk, so asking it here is diligence, not stalling. Then: the objective, the partner segments, current adoption, what's already committed, and how you'd sequence listening before changing anything. Present it as a plan. Don't frame any of it as something you've done before | This is F2's responsibility asked as a live problem, so no past claim is needed. `[generic]` because the method is a role-family pattern |
| B2 | "How would you define and track adoption for a partner-facing API?" | CASE, JD | [generic] | Structure it: start with the baseline, and ask what's measured today. Then a funnel from access to first call to production traffic to sustained use. Leading versus lagging signals. Segment by partner type. Then what you'd do when a stage stalls. Say "I'd want to know your baseline first" rather than inventing one | F10 has no evidence, so this is answered as a plan. The dossier flags that no baseline is stated. `[generic]` because it's a method, not a claim about Quartzline |
| B3 | "Two integration partners want conflicting changes to the same endpoint, and both squads are full. Walk me through it." | CASE | [generic] | Clarify the stakes for each partner, what each change breaks, and who decides capacity. Options: sequence, version, find a shared shape, or decline one. Name how you'd bring the squad leads in. A hypothetical needs no past, so don't add "like I did" | Tests prioritisation reasoning live without touching F2's or F8's limits |
| B4 | "Plan the discovery you'd run with integration partners for the next roadmap cycle." | CASE, JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | You can mention the quote as it stands: "I ran quarterly roadmap-input sessions feeding client evidence to product." Then build the plan as a plan: who you'd talk to, what you'd ask, and how findings reach the roadmap. Answer slot: if they ask how your sessions ran, say how in your own words. If there's little on paper, say so. Never describe the sessions as setting the roadmap | F9 is adjacent, medium confidence, and the dossier expects a probe on it. CASE delivery on JD content |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 30-plus. How was that counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slots, in your own words: how the figure was counted, what it's sensitive to, the assumption behind it you'd defend least (name it before they do), and which part was yours. If you don't know exactly how it was counted, say so plainly. Keep the number attached to its noun: integrations, end to end | VE1 is the only headline figure, and probers go for it. EXP because it tests the claim itself |
| C2 | "When you scope an integration, how do you work with a partner-facing API's docs and schemas?" | EXP, JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if docs and schemas were part of how you scoped those integrations, say how, in your own words. If they weren't, say so plainly and describe how you did scope them. If the playbook is shareable, offering to walk through it is stronger than describing it | F4 is a discovery gap. The question presupposes doc and schema work the quote doesn't state, so the slot allows that it never happened |
| C3 | "Who uses the playbook, and what changed because of it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Start from the quote: you wrote it and your team uses it. Answer slot: if you know what changed because of it, say what, in your own words. If you don't, say so plainly and stay with what the playbook is for | VE2 is high confidence and inspectable, a solid card. The outcome probe is the seam, so it's rehearsed as a slot |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", "Wrote the internal integration playbook her team uses", "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each one a quote: the integrations, the playbook, the roadmap-input sessions. Then why this role. Answer slot: your timeline and employers, in your own words. This pack doesn't hold them, so don't borrow a number of years from anywhere else | The guaranteed opener in a conversation format. Lands F1's positioning early, in your terms |
| D2 | "What's an API you've enjoyed integrating with, and why?" | JD | [generic] | Selection scaffold: pick one you can talk about specifically, with what made its docs, schemas or behaviour easy or hard for a client. If none comes to mind, say so plainly and talk about what makes an API easy to integrate in general | A casual-register probe of R3 (F4). Scored even when it feels like chat |
| D3 | "What questions do you have for me?" | CO | [grounded] | Use the reverse questions below. Lead with Q1 and Q2, which are the dossier's open risks. Never "I think you've covered everything" | Rapport-style closes weight this heavily. The dossier makes these questions load-bearing |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The two squad leads have strong views on their backlogs. How would you work with them?" | JD, CASE | [generic] | Propose principles for the seam: who owns what, how disagreements get decided, and what you bring them (partner evidence, clear specs, early warning). Ask how it works today. Don't claim you've done this before | Aimed at F8 and the dossier's squad-authority risk, asked as a plan. Keeps clear of the prohibited prioritisation claim |
| E2 | "Sales promises a partner something that isn't on the roadmap. What do you do?" | CASE, JD | [generic] | Structure it: what was promised, what it costs, who decides, and how you close the loop with sales and the partner. Answer slot: if you've been in a spot like this during integrations, tell it in your own words. If you haven't, say so and answer as a plan | Covers the sales side of R4 (F5), which the evidence doesn't show |

### P. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | Pause. A compressed A1: "I haven't held a product manager title. I led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live." Then one line on the ramp plan. Hold through two pushes by returning to the integrations. Concede the three years specifically, and don't fold on the integrations | The same objection as A1, time-boxed. Tests composure on F1 |
| P2 | "Those 30-plus integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "led", because that's your verb. Answer slot: say which parts were yours and which were the team's, in your own words. If some stages were mostly others' work, say so plainly. Precise credit-sharing reads as strength | The attribution probe on VE1 (F3). Honest precision is the rehearsal |

### V. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, the hard message, how it landed, and the relationship afterwards. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem. Quartzline's values couldn't be researched, so this is generic rehearsal |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the customer, the metric, the trade-off and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A partner-facing role makes the customer-first stem likely. Generic for the same reason as V1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years product management experience | A1, A4, P1, D1 |
| R1 sub-claim: owning a roadmap (responsibility) | A1, A2, B1 |
| R2 Shipped API or platform products | A3, C1, P2 |
| R3 Technical fluency: API docs, schemas | C2, D2 |
| R4 Stakeholder management across engineering, sales, customers | E1, E2, B4 |
| R5 Agile delivery experience | A5 |
| Run discovery with integration partners | B4 |
| Write specs and drive delivery with two engineering squads | E1, B3 |
| Define and track adoption metrics | B2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| Q1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier. The JD asserts authority it doesn't evidence. It reads as diligence, and the answer tells you whether "own the roadmap" is real |
| Q2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier. Adoption is a named responsibility with no stated baseline. The answer tells you what you'd be judged on |
| Q3 | "Where do partner requests come in today, and who triages them?" | Shows you're thinking about the sales and engineering seams R4 names, and maps the politics you'd step into |
| Q4 | "What would make you say, six months in, that this hire was the right call?" | Gets the real success criteria out, and lets you check them against your ramp plan |
| Q5 | "What's the biggest thing the partner platform needs that it doesn't have yet?" | Invites the hiring manager's own view of the roadmap, which is the problem you'd inherit |
| Q6 | "How do the squads and partners hear about roadmap changes today?" | Probes the delivery and communication side of the role without claiming you've run it |

---

## Prohibited claims

This pack won't coach any of these, in any cell or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | VE1's quote at its own scope, plus the plain acknowledgment: "I haven't held a product manager title." |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap area | "I haven't owned a product roadmap." Then a ramp plan, as a plan. No slot, no bridge |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set prioritization for an engineering squad." |
| Integration leadership presented as PM experience | Inflated form of F1, and the dossier's positioning condition | VE1's quote at its own scope. The limit is the pack's own observation: adjacent, not the same job |
| Shaped or decided the roadmap through the input sessions | Inflated form of F6 and F9 | VE3's quote at its own scope: input fed to product. The material shows the input, not what was decided |
| Shipped the vendor's API product | Inflated form of F3 | VE1's quote at its own scope. The material says integrations of the vendor's APIs, not the product itself. A3's slot stays inside the integration stages |
| Wrote product specs for engineering squads | Inflated form of F8 | VE1's quote at its own scope. The material says integration requirements, not product specs |

---

## Sources

- **Dossier consumed:** `tuesday-dossier.md` v1.1, generated 2026-08-14 by job-underwriter. It supplied:
  - `role_profile`: stands in for the JD; requirements R1 to R5 and the responsibilities
  - `handoff_to_mock_interview`: verified evidence VE1 to VE3, weak areas with their allowed strategies, the A1 objection, the reverse-question seeds and the prohibited claims
  - `decision`: context only
  - Not present in what you pasted: `evidence_map`, `evidence_state`, `risk_register`
- **Your message:** the round type and length.
- **Searches sent, all refused** (web search permission wasn't granted):
  - "Quartzline company values"
  - "Quartzline interview process product manager"
  - "Quartzline API platform partners news 2026"

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search refused. Would have themed V1 and V2 with Quartzline's published values. The cheat sheet stays out either way, because no values round is named |
| 2. `Quartzline interview process product manager` | unavailable | Search refused. Could have shown whether hiring-manager conversations include a case, which would reweight bank B |
| 3. `Quartzline strategy` / recent news | unavailable | Search refused. Would have grounded B1 to B4 and D3 in current priorities. Without it, the CO and CASE rows stay `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was nothing to search. There's no interviewer read |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Web search permission** → targets 1 to 3 run: Quartzline's values theme bank V, the documented loop checks the persona weights, and current strategy turns B1 to B4 from `[generic]` into grounded questions.
- **The interviewer's name** → a reading-the-interviewer section, persona weights based on their public footprint, and a reverse question tied to their own path.
- **The recruiter's prep email** → coverage of any case or presentation they've announced for this conversation.
- **Your answers to the answer slots, said outside a drill** → they become quoted evidence. That upgrades F3, F4, F5, F7, F8 and F10, plus A3, A4, A5, C1, C2, C3, D1 and E2.
- **The integration playbook's text** → C2 and C3 could quote what it actually covers, and F4 could move off `discovery` if it shows docs or schemas work.
- **Anything you can show from the roadmap-input sessions** (an agenda, notes, a summary you sent product) → could raise VE3 from medium, and firms up F6, F9 and B4.
- **The dossier's evidence_map, evidence_state and risk_register sections** → per-requirement grading for R2 to R4, and any rejected inferences added to the prohibited list.
- **Deep research (L2)**, once search is allowed: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief, role-family loop reports and recent org context.
