Quick update: I've read the prep playbook. Next I'm running a few targeted searches on Saltmarsh Games and Tobias Wrenfield, then I'll build your pack.
I've built your prep pack and saved it as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-denied-67d3f14f/saltmarsh-games_live-operations-producer_interview_pack.md`. It assumes Tobias would be your manager, since you didn't say.

**No research went into it.** All four web searches were blocked because search permission wasn't granted. Nothing in the pack about Saltmarsh's values, games, interview process or Tobias comes from research; those parts are marked as general patterns. Tomorrow is Friday, so the most useful homework tonight is playing their games yourself (step 2 of the pack's plan for tonight).

What's in it:
- **The question most worth rehearsing (A1):** "You've run the calendar for one title; this role runs two titles and four teams." That's the biggest jump from your background to the JD.
- **22 practice questions** across seven interviewer styles, each tied to your own sentences. Where your background doesn't say something (for example, who worked with you on each drop, or whether you prepared the retention numbers or only presented them), the pack gives you two honest answers to choose between rather than making one up.
- **A table checking every JD requirement against your background**, a list of which questions cover each requirement, a ~3-hour plan for tonight, and six questions to ask Tobias.
- **Claims the pack won't coach**, such as "led a team", "ran live events" or "owned the KPIs". It gives you an honest line for each instead, including "I haven't worked on a game with in-app purchases" if monetisation comes up.

Say the word and I'll play the Skeptic on A1, the question the pack ranks as most worth rehearsing.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Will Tobias be your manager, and did the recruiter mention focus areas or anything to prepare? Either answer changes which questions get the most weight.
Do you want to allow web search so I can add Saltmarsh's values, their games and Tobias's public profile?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** one 60-minute interview, Friday. You didn't say whether Tobias would be your manager, so this pack treats it as a **hiring-manager round**. If that's wrong, the persona weights change.
**Research:** none ran. All four web searches were refused (see Sources), so nothing here about Saltmarsh's values, process, games or Tobias comes from research. Anything company-specific is marked `[generic]`.

---

## How to use this pack

- **Personas** describe how a question gets asked: who is asking and in what tone. **Types** describe what's being scored. The same question can come warm or hostile, so practise both.
- **Guidance is scaffolding, not a script.** Say it in your own words. Every claim about your past points to one of your own sentences, quoted in the Provenance column. If a beat isn't in your sentences, it's written as an **answer slot**: a fork you answer truthfully in the room, whichever branch is true.
- Provenance labels: `[grounded]` traces to something you told me or the JD. `[inferred]` is derived, and the source is named. `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

| Type | What it scores |
|---|---|
| VAL | Behavioural / values: whether past behaviour shows the company's published values |
| EXP | Experience deep-dive: whether your stated work holds up, and what was actually yours |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company knowledge: homework on their games and strategy |
| CASE | Live problem: structure and reasoning on a problem from the role |

Question IDs: A Skeptic, B Case/Strategist, C Data-Driven Prober, D Conversational, E Pressure, G Values/Behavioral, H Peer. Letter F is left out so it can't be confused with fit-snapshot rows F1–F8.

---

## Prep triage: tonight

The interview is tomorrow. This assumes roughly one evening, about three hours.

1. **A1 out loud, three times** (30 min). It's the highest-ROI question in the pack. Practise the hold, the limit you name before he does, and the plan.
2. **Play Saltmarsh's games** (45 min). Research couldn't run, so this is your only company homework. It feeds B5, D2 and D3. Note how often events run and how players hear about them.
3. **Decide your honest branch on the answer slots** in F2, F3, F5 and F7, then rehearse C1 and A4 (30 min). Know which branch is true for you before you walk in.
4. **Case structures B1 and B2 aloud** (30 min). Clarify first, then structure, then answer.
5. **D1 timed to 90 seconds** (15 min).
6. **Pick three reverse questions** (10 min).

Everything else is insurance.

---

## Fit snapshot

Requirements are the JD's own words. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes one calendar, of weekly content drops, for your main title. The JD says live events across two titles. Keep the words at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title line makes a probe on handling more than one title likely. If your calendar ever had to work around another title or around shared people, say how, in your own words. If it didn't, say so plainly and describe how you'd plan two titles, framed as a plan |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show who you worked with on each drop. Answer slot: the JD's coordination line makes this probe close to certain. If any drops involved design, art, engineering or community people, say who and what you did to keep the drop on track, in your own words. If they didn't, or that was someone else's job, say so plainly and return to the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is close to owning a post-event review, but it doesn't reach it. Keep the words at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you prepared those numbers or wrote up what they meant, say which parts, in your own words. If someone else produced them, say so plainly and stay with presenting them. How you'd run a post-event review is said as a plan |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | The quote shows you wrote the checklist and QA still uses it. It doesn't show whether you worked through it with QA on each release. Lead with the quote's own terms: "I wrote the release checklist our QA team still uses." Answer slot: if you worked through it with QA on releases, or revised it, say how, in your own words. If you didn't, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Four years producing clears the length. Your material doesn't say whether the title ran as a live service. Answer slot: if the game was run as a live service, say so in your own words and point to the weekly calendar. If it wasn't, say so plainly and stay with the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. It's a self-report with nothing inspected behind it, so expect a probe. Lead with the quote: you ran the weekly content-drop calendar for your main title for the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | Presenting the numbers touches the requirement but doesn't show how far into them you went. Answer slot: if you worked with how retention was defined or counted, say how, in your own words. If you presented numbers someone else prepared, say so plainly and say what you'd want to understand first |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist QA still uses is one written document, and it's real evidence. The JD's post-event review is a different kind of writing. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote other documents your team relied on, name them in your own words. If the checklist is the main one, say so and stay with it |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| F1 Live-events calendar, two titles | A1, B1, A2 |
| F2 Coordinate design, art, engineering, community | A1, A5, B3, H1 |
| F3 Own the post-event review and its KPIs | A4, B4, C3 |
| F4 Release checklist with QA | H2, B3 |
| F5 3+ years live-service | A3, D1 |
| F6 Content calendar | A1, E1, A5 |
| F7 Player-retention metrics | B2, C1, C2 |
| F8 Clear written communication | G2, B4 |

---

## Persona table

The weights come from the hiring-manager prior. Your own description establishes the round: one 60-minute session with Tobias. That description names no values round, so none is assumed. No research on Tobias ran, so no interviewer signals adjust the weights.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the scope jump: one title to two, a calendar to live events, no team led | High. Hiring managers de-risk gaps, and F1, F2 and F3 are the visible ones | Rehearse A1 until it's boring. Hold only what your quotes carry, name the limit first, then give a plan |
| Case / Strategist (B) | "Plan our next quarter", "retention dropped, diagnose it" | High. The hiring-manager prior. The JD is operational, so expect live problems from it | Clarify, then objective, segments, approach, metrics, risks. Think aloud. Challenge one premise |
| Data-Driven Prober (C) | Two levels down on the retention numbers you presented | Medium. "comfortable with player-retention metrics" invites it, and F7 is thin | Know what you can and can't say about how the numbers were counted. "I don't know" is allowed, and so is saying who did know |
| Conversational (D) | Warm opener, "what are you playing", "why us" | Medium. Most 60-minute rounds open this way, and the casual questions are still scored | A 90-second arc (D1). Real games you actually play |
| Pressure (E) | "How much of that was actually you?" | Low-medium. An associate title next to "I ran" invites an attribution probe | Pause, restate, anchor in your quote, hold through two follow-ups |
| Values / Behavioral (G) | STAR-style "tell me about a time" | Low. No values round detected and no published values in hand | Selection scaffolds, each with an honest branch |
| Peer (H) | Seam questions with community and QA | Low. Tobias isn't a peer, but the JD lists four partner teams plus QA | Propose principles for the seam, plus what you'd give each team |

---

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've run the calendar for one title. This role runs two titles and coordinates design, art, engineering and community on every update. Why are you ready for that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team" | **Highest-ROI rehearsal in this pack.** Hold only what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Name the limit before he does: the calendar was for your main title. Then give your plan for two titles, framed as a plan and never as a past: how you'd sequence them, where they'd compete for the same people, and what you'd learn in the first weeks. Answer slot: expect a follow-up on who you worked with. If drops involved design, art, engineering or community people, say who and what you did, in your own words. If they didn't, say so plainly and return to the calendar. If leading a team comes up: "I haven't led a team." Then say how you'd coordinate, as a plan. Hold through two follow-ups by returning to the calendar, never by adding to it | F1 and F2 are where the role's scope presses hardest, so this objection will come in some form. JD because it scores the two-title and coordination lines directly. Skeptic delivery |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Name one real item from the JD's own list, not a disguised strength. The honest option your material supports is the two-title scope: your calendar was for your main title. If the coordination line is truer for you, name that instead. Say it plainly, then give a two-sentence ramp plan, framed as a plan. Don't pick a weakness you'd then have to argue your way out of | A standard Skeptic stem. F1 and F2 are the honest answers. JD because the weakness should come from the JD's list |
| A3 | "How much of your four years was live-service work?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." | Start from the quotes: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for your main title. Answer slot: if the game was run as a live service, say so in your own words. If it wasn't, say so plainly and let the weekly calendar stand as what it was. Don't relabel the drops as "live events" | F5's requirement names "live-service", and a hiring manager may check that word literally. JD because it's a stated qualification |
| A4 | "Which KPIs would you expect a post-event review here to report, and which of them have you worked with?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." "never worked on a game with in-app purchases" | Two halves. What you've worked with: "I presented the monthly retention numbers to the studio head." Answer slot: if you worked with other measures, name them in your own words. If retention was the one, say so. What you'd expect here: say you'd want to confirm what each title's review tracks, then name candidates as a plan, such as event participation, retention around the event, and whatever the event was meant to move. If monetisation comes up: "I haven't worked on a game with in-app purchases." Then say how you'd learn it, as a plan. Never name a metric as one you tracked unless you did | F3 and F7 together. The KPI line in the JD makes this likely. The in-app line is there so the honest answer is ready, not so you volunteer it |
| A5 | "Tell me about a time a content drop was at risk of slipping." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. Look across the weeks of the calendar you ran for one where a drop was at risk. The story needs what was at risk, what you did, and how it ended. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is running the weekly calendar, or say how you'd handle it | Tests F2 and F6 through a story. EXP because it checks what was actually yours |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the next quarter of live events across our two titles. What do you need to know first?" | CASE | [generic] | Clarify first: each title's players and what its events are meant to move, team capacity across design, art, engineering and community, dates already committed, and how reviews feed the next plan. Then structure: a cadence per title, where the two titles compete for the same people, buffer for slips, the QA checklist as a gate, and review points. Close with metrics and the top two risks. Challenge one premise, for example whether both titles need the same cadence. Keep it whiteboard-sized | The JD's headline responsibility asked live. `[generic]` because it's a pattern, not a fact about Saltmarsh |
| B2 | "Seven-day retention after our last event came in below the event before. Diagnose it." | CASE | [generic] | First check the data: same definition, same cohort, no tracking or release change. Then segment: new against returning players, platform, region, install source. Then compare what changed: event design, length, difficulty, timing, a release bug, a competing event. Rank your hypotheses, say what you'd check first and who you'd ask, and say what you'd report and when. Name the weakest assumption in your own diagnosis before he does | The JD's retention line plus a Case stem. Tests F7 live, where your evidence is thin |
| B3 | "An engineering fix slips three days before an update, and the event is already announced to players. What do you do?" | CASE | [generic] | Impact first: what breaks for players without the fix. Options: ship without it, delay, or split the update. Who decides, and by when. What community tells players, and when. What the QA checklist has to re-cover. Log it for the post-event review. Make a recommendation, not just a list | Covers F2 and F4 in one live problem. CASE because no past is presupposed |
| B4 | "Walk me through how you'd run a post-event review here." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Framed as a plan: the goal against the result, the KPIs, what went wrong in production, player feedback through community, and the one or two decisions it should drive for the next event. Keep it short enough that people read it, and say who it goes to. If asked what you've done: "I presented the monthly retention numbers to the studio head." Then F3's answer slot, whichever branch is true | F3 is a "transferability" row. This rehearses the plan so the past doesn't get stretched to fill it. Also covers F8, because the review is a written document |
| B5 | "What do you know about our games?" | CO | [generic] | Research couldn't run for this pack, so do it yourself tonight: install and play their titles, and note how often events run and how players hear about them. Say what you saw as what you saw. If you're not sure which two titles the role covers, say you'd want to confirm. Never claim a game you haven't played | CO coverage. `[generic]` because no company facts were researched |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. What did they measure?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend the number, in your own words, on four slots. How it was counted: which retention measure, over what window. What it's sensitive to. The assumption behind it you'd defend least, named before he asks. Which part was yours: pulling it, preparing it or presenting it. "I don't know how it was counted" is an honest branch. If that's true, say who did know | F7's evidence, probed to its assumptions. EXP because it tests what was yours |
| C2 | "What happened after you presented those numbers to the studio head?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if a decision or change followed and you had a part in it, say what it was and which part was yours, in your own words. If nothing followed, or you don't know, say so plainly and stay with presenting them. Never credit the numbers with a change you can't name | A Prober follows a number to its consequence. F3 and F7 |
| C3 | "How did you know whether a weekly drop worked?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if drops were measured, say what was measured and how, in your own words. If there was no such step, or it wasn't yours, say so plainly and say what you'd measure first here | Links F6 to F3's KPI ownership. JD content, EXP delivery |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, exactly as stated. Four years as an associate producer at a puzzle-game studio. For the last two, you ran the weekly content-drop calendar for your main title. You wrote the release checklist your QA team still uses. You presented the monthly retention numbers to the studio head. Then one sentence, in your own words, on why this role. Add no fifth beat | The near-certain opener, and it's scored. It also covers F5 |
| D2 | "What mobile games are you playing right now, and what do you think of their events?" | CO | [generic] | Only games you actually play. Give one specific observation about an event: what worked, or what you'd change. If you play few, say so and talk about what you noticed in Saltmarsh's games tonight | A casual question with real signal for a Live Ops role |
| D3 | "Why leave, and why Saltmarsh?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | Your reasons in your own words. Why leave: point forward (what you want next), not backward. Why here: something specific from playing their games and from the JD's scope. If you don't yet have a specific "why here", say what drew you to the role and what you want to learn about the team | Motivation consistency, asked warmly. A generic "why here" is an easy miss |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You were an associate producer. How much of that calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, then restate. Anchor: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if others decided what went into drops or approved dates, say which parts were yours and which were theirs. If the calendar was yours end to end, say so plainly. Hold through two follow-ups. Don't upgrade "ran" to "owned" or "led" under pressure | An attribution probe aimed at F6. A rehearsed, precise answer turns it into a credibility gain |
| E2 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Three beats and stop at sixty seconds. The calendar, in the quote's words. The checklist QA still uses. Then what you'd bring in your first months, framed as a plan. Don't run down the internal candidate | Composure under a time box. JD because the beats map to F6 and F4 |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you told leadership something they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. The story needs a real stake, the moment you said it, and how the relationship stood afterwards. Your presentations to the studio head are one place to look, if any month's numbers were unwelcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or say how you'd handle it | A persona stem. No published values in hand, so this is generic behavioural |
| G2 | "Tell me about something you wrote that other people relied on." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped: you wrote the release checklist, and your QA team still uses it. Those are the beats. Answer slot: the JD's written-communication line makes a probe on how you wrote it likely. If you wrote it with QA's input or revised it over time, say how, in your own words. If you didn't, say so plainly and stay with the checklist | F8's evidence turned into a story. VAL delivery, JD content |

### H. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Community hears about event changes last. How would you fix that?" | CASE | [generic] | Propose principles for the seam: one shared calendar everyone reads, a fixed point when community is told about changes, a short change log, and community sign-off as a line in the release checklist. Ask what community needs from you, not only what you need from them | The JD names community among the teams on every update. Covers F2 |
| H2 | "QA tells you the release checklist is slowing them down before each update. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Listen first. Find which steps cost time and which catch real problems. Propose a change, try it on one release, and keep the steps that protect players. If you mention your own past, use the quote's words: you wrote the release checklist your QA team still uses. Then F4's answer slot, whichever branch is true | F4 asked live. The quote earns you credibility here, so don't stretch it into "managed QA" |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a strong post-event review look like here, and who reads it?" | You'd own it (F3). Asking shows you see it as a decision tool, not a report |
| "How do the two titles share design, art and engineering people across the calendar?" | Goes straight at the scope jump in F1 and F2, and tells you what the job really is |
| "Which KPIs does each title's post-event review report today?" | Fills the research gap and shows you're comfortable with metrics (F7) |
| "What would you want this producer to have changed by the end of their first three months?" | Gets his actual success criteria, so you can echo them in your close |
| "How does the community team come into planning an event?" | The partner the JD names last is the easiest one to forget. Asking shows you won't |
| "What does the release process with QA look like today, and where would you most like it tightened?" | Your checklist story (F4) becomes a conversation instead of a claim |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated: "Never led a team" | "I haven't led a team." Then how you'd coordinate, framed as a plan |
| Has worked on a game with in-app purchases, or has monetisation experience | A negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then how you'd learn it, framed as a plan |
| Ran the live-events calendar for two or more titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material describes one calendar, for your main title |
| Ran live events (calling the weekly drops by the JD's term) | Inflated form of F1 and F6: borrowing the JD's vocabulary | Your own words: "the weekly content-drop calendar" |
| Owned the post-event review or the KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. C1's and C2's slots stay inside what you presented |
| Analysed, improved or drove retention | Inflated form of F7 | F7's quote at its own scope. The answer slots ask only how the numbers were counted and what was yours |
| Managed QA or ran releases | Inflated form of F4 | F4's quote: you wrote the release checklist your QA team still uses |

---

## Sources

- **Provided:** your message, which included the JD text and your background. No dossier was present.
- **Searches sent, all refused** (web search permission not granted in this session):
  - `Saltmarsh Games mobile game studio values`: refused
  - `Saltmarsh Games interview process producer`: refused
  - `Saltmarsh Games news 2026`: refused
  - `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: refused
- **Fetches:** none.
- **Loop:** your own description establishes the loop as one 60-minute session with Tobias. It names no values round, so none is detected and no values cheat sheet is built.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. It would have themed G1 and G2 on Saltmarsh's published values. No cheat sheet in either case, because no values round was detected |
| 2. `Saltmarsh Games interview process` | unavailable | Every call was refused. It would have checked whether more rounds follow Friday's, which changes nothing in this session's weights |
| 3. `Saltmarsh Games` strategy / recent news | unavailable | Every call was refused. It would have turned B5 and D2 into grounded CO questions and added a strategy case on their actual titles |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Every call was refused. It would have added an interviewer read, adjusted the persona weights from his public footprint, and tied a reverse question to his path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

---

## Upgrade menu

- **Whether Tobias would be your manager, a skip-level or someone else** → the persona weights get recomputed. A skip-level round, for example, adds Pressure and strategy depth.
- **Recruiter guidance** (focus areas, anything to prepare or present) → a build section for any pre-declared deliverable, and coverage tuned to what they said. Usually one email.
- **Web search allowed** (targets 1–4) → Saltmarsh's values by name, their titles and recent moves for B5 and D2, and Tobias's public professional footprint for an interviewer read and a tailored reverse question.
- **A deeper research pass**, up to 6 more searches and 2 more fetches and several more minutes → a company strategy brief and recent studio context for a stronger CO bank. Run only if you want it.
- **The names of the two titles the role covers** → B1, B5 and D2 become specific to those games.
- **Your truthful branch on the F2 slot** (who worked on each drop) → A1, A5, B3 and H1 become story-mapped instead of slotted.
- **Your truthful branch on the F3 and F7 slots** (whether you prepared the retention numbers, and how they were counted) → C1, C2, A4 and B4 become story-mapped.
- **Your truthful branch on the F5 slot** (whether the puzzle title ran as a live service) → A3 and D1 get a firmer answer.
- **The checklist itself, or a redacted copy** → F4 and F8 rise to `high` confidence, because they'd rest on an inspectable document.
- **A `tuesday-dossier.md` from an underwriting pass** → the highest-ROI objection derived from verified evidence rather than inferred, and binding strategy constraints on each weak area.
