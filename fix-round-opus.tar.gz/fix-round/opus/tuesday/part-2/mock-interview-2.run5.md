Quick update: I've read the prep playbook and am now doing a short round of research on Atlas Freight (values, interview process, recent news). After that I'll build your pack.
I've saved your prep pack as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-2-denied-455748a9/Atlas-Freight_operations-manager_interview_pack.md`. I don't know who you're meeting, so it covers a full interview process with every interviewer style weighted equally. None of it comes from research on Atlas Freight: my three web searches were blocked because search permission wasn't granted. Everything about the company comes only from the job description you pasted.

**What's in it:**
- **Fit table:** each job requirement next to your own words, with where you're strong and where the gaps are.
- **21 practice questions** across seven interviewer styles. Each has answer guidance built only from what you told me.
- **Claims to avoid:** a list of overstatements the pack won't coach, like "led a team of 12" or "cut cost per shipment."
- **Six questions to ask them.**

**The question to rehearse most: A1.** You're over 3 supervisors today, and this job leads 12 across four sites. That will come up in some form. The pack gives you a way to stand on what you actually do now, then give a plan for 12 without stretching your past.

**Have your own answers ready for these, because the pack can't supply them:**
- How many of your 7 years were in roles leading people. The job description says 5+ years is required, so they may check it literally.
- How the 40% mis-pick drop was measured.
- What you tracked while running the peak-season surge plan.

Say the word and I'll play the skeptic on A1 and push back on your answers live.
I can also save a `tuesday-dossier.md` file recording the gaps this prep exposed, for you to bring into later sessions.
If you'd like the pack as a Word document, I can convert it.

What kind of interview is this, and who's running it: your future manager, a panel, HR, or a peer? Did the recruiter mention any case, presentation or site visit? The answer changes how every section is weighted.

Do you want me to research Atlas Freight? If you allow web search, I'll run the three searches on their values, interview process and recent news. I can also do a deeper pass with up to 6 more searches and 2 page reads, which takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees). Interviewer: not known. Round type: not known.

Because the round and the interviewer are unknown, this is a full-loop pack with equal persona weights. It is noticeably weaker than a pack built for a known round. Tell me who you're meeting and the weights and banks get rebuilt around that person.

## How to use this pack

Personas describe how a question is asked: the interviewer's style and register. Types describe what the answer is scored on. Rehearse both, because the same question about leading 12 supervisors comes across very differently from a friendly hiring manager than from a skeptic.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values the company publishes, not generic virtue |
| EXP | Whether your stated experience survives scrutiny: what you actually did, and how much of it was you |
| JD | Whether you can do the job as listed, including where you have gaps |
| CO | Homework on the company: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

The guidance is scaffolding, not a script. Each guidance cell is built only from sentences you wrote to me, and those sentences are quoted in the Provenance column next to it. Where your material doesn't say something, the cell has an **answer slot** instead. A slot is an instruction for the interview. Answer it from what actually happened, and if the thing it asks about never happened, say so plainly.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution, not terminal or multi-site operations, and the words should stay at that scope: "I've spent 7 years in warehouse and distribution ops." Answer slot: the JD's terminal line makes a probe likely on what your operations covered. Say what your warehouse and distribution work involved day to day, in your own words, and stay inside it. Describe what you would learn first about running terminals as a plan, never as a past |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Running a surge plan touches on-time delivery but doesn't show whether you measured or moved it. Answer slot: if you tracked measures while running the surge plan, say which ones and what they showed, in your own words. If you tracked none, say so plainly and describe what you ran. Keep the verb as "ran" |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | A measured improvement on an adjacent metric. The 40% stays attached to mis-pick rate: "I cut the mis-pick rate 40% by redesigning the pick path." Your material says nothing about cost, so the bridge makes no cost claim. When asked about cost-per-shipment, treat it as a plan for the new role |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Twelve is four times the span you have today, and that span is the honest starting point: "Today I'm a senior shift manager over 3 supervisors." Answer slot: say how you work with those 3 supervisors (how their priorities get set, how you follow up), in your own words. If parts of that aren't yours to set, say so plainly. Describe scaling to 12 as a plan |
| F5 | "build reporting in Excel/Power BI" (Excel half) — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a self-assessment that doesn't show what you've built with it. Answer slot: the JD's "build reporting" line makes a probe likely. If you've built reports in Excel, say which ones, for whom and what they tracked, in your own words. If you haven't, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" (Power BI half) — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap you have stated yourself, and wording can't close it. Words: "I haven't used Power BI." Then give your plan to learn it, said as a plan. If you start learning before the interview, say exactly what you did and nothing more |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops doesn't show how many of those years were in leadership roles, and a titled years requirement is likely to be checked literally. Answer slot: count the years you've held roles leading people and say the number, in your own words. If it's under five, say the number plainly and what the rest of the time was |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. Your quote reaches the requirement directly: "I'm green belt certified." Nothing behind it has been inspected, so expect a probe on how you've used it (see G2) |

## Persona table

No loop source establishes Atlas Freight's interview process: my searches were refused (see Sources), and you haven't said which round this is. The weights therefore fall back to the generic archetype (screen, then hiring manager, then panel), with flat weights. The weights rest on that pattern, not on Atlas Freight's documented process.

| Persona | How it shows up here | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the jump from 3 supervisors to 12 and from warehouse to terminals | Equal weight under the flat fallback. In practice this objection comes up in any round, because F4 and F1 are this role's two widest gaps | Rehearse A1 until it bores you. Hold only what your quotes carry, then give a ramp plan |
| Case / Strategist | Live problems on on-time performance, cost-per-shipment and multi-site reporting | Equal weight. A hiring manager for a role with named metrics usually tests them live. That is a pattern for this kind of round, not a fact about Atlas | Clarify, then objective, segmentation, approach, metrics and risks. Think out loud |
| Data-Driven Prober | Goes straight for the 40% | Equal weight. Your only stated figure is a magnet | Know what you can and can't say about how the 40% was counted. Name your weakest assumption before they do |
| Pressure | Time-boxed "why you" and "how much was you" | Equal weight | Pause, restate the question, anchor in what you stated, and hold through two follow-ups |
| Values / Behavioral | STAR-style stories on people and change | Equal weight. No published values were found, so these questions are themed from the JD and common stems | "We" for context, "I" for your contribution. Only tell stories that actually happened |
| Conversational | Friendly opener and a casual question about the green belt | Equal weight | A pre-built 90-second arc. Treat casual questions as scored |
| Peer Evaluator | A fellow manager or site lead asking about seams and credit | Equal weight. Panels for a role over 4 sites often include peers, but that's a pattern, not a fact about Atlas | Frame it as reciprocity. Propose principles for the seams rather than pretending to know them |

## Question banks

With flat weights each persona gets three questions. The order puts first the banks that hold the role's widest gaps. Question IDs skip F so they don't clash with the fit-snapshot rows.

**Highest-ROI prep in this pack: A1.** The jump from 3 supervisors to 12 is the most predictable objection to your candidacy. It will come up in some form, so rehearse it deepest.

### A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're over 3 supervisors today. This role leads 12 across four sites. Why are you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Highest-ROI rehearsal. Hold only what the quote carries: "Today I'm a senior shift manager over 3 supervisors." Answer slot: say how you work with those 3 (how their priorities get set, how you follow up), in your own words. If parts of that aren't yours to set, say so plainly. Then give the plan for 12 as a plan: what you'd do in the first 30 days at each site, and how you'd keep one standard across four. Name the limit before they do: twelve is four times your current span. Follow-up 1, "But that's four times the span": hold, return to how you work with the 3 today, and don't add to it. Follow-up 2, "So what breaks first?": concede specifically. Name the part of the plan you're least sure of, and why | F4 is the widest gap against a headline requirement, so this objection will come up. JD because it scores the stated span directly |
| A2 | "Your background is warehouse and distribution. This is terminal operations. What don't you know yet?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote: "I've spent 7 years in warehouse and distribution ops." Answer slot: say what that work covered day to day, in your own words, and stay inside it. Then answer the question as asked: name two or three things you'd need to learn about running terminals, and how you'd learn them in the first month (walking each site, sitting with the supervisors, reading the current reports). Calibrated candor beats bluffing here, because this interviewer probably knows terminals well | F1's transferability gap. JD because it tests the core scope line |
| A3 | "The role builds reporting in Power BI. How would you get there?" | JD | [grounded] "solid Excel, never used Power BI" | Say it plainly: "I haven't used Power BI." Then: "I'm solid in Excel." Then a short, specific learning plan, said as a plan. If you've started learning by interview day, say exactly what you did, no more. Don't apologise twice | F6 is a stated capability gap. Rehearsing it turns a gotcha into a candor signal |

### B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of four terminals dropped five points last month. Diagnose it." | CASE, JD | [generic] | Clarify first: how on-time is defined and measured, and over what period. Then segment: by shift, by lane or customer, by dock stage (inbound, handling, outbound), and by whether volume changed. Form a hypothesis, then name the data that would confirm it, the first action, how you'd know it worked, and the risk of fixing the wrong thing. Challenge one premise, for example whether the measurement itself changed. Makes no claim about your past | Tests the JD's on-time line (F2) as a live problem. [generic] because the scenario is a pattern, not an Atlas fact |
| B2 | "Take 5% out of cost-per-shipment in a year. Where do you look first?" | CASE, JD | [generic] | Break cost per shipment into its drivers: labor hours per shipment, overtime, rehandling and claims, equipment and dock utilization, and the volume in the denominator. Say which you'd measure first and why, and what you wouldn't cut because it would hurt on-time. Close with how you'd report progress. If you use an example from your own work, use only what you actually did, and keep the 40% attached to mis-picks | Covers F3's requirement. Answering as a plan keeps clear of the prohibited cost claim |
| B3 | "You inherit four sites that each report differently. What goes in the first daily report, and in what tool?" | JD, CASE | [grounded] "solid Excel, never used Power BI" | A handful of metrics, one definition across all four sites: on-time and cost-per-shipment from the JD, plus volume and labor. Build in Excel first, since "I'm solid in Excel", and move to Power BI while learning it: "I haven't used Power BI." Say who reads the report and what decision it drives each morning | Covers the reporting requirement (F5, F6) as a build problem rather than a tool quiz |

### C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 40%. How was mis-pick rate counted, before and after?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The claim, word for word: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: how the figure was counted and over what periods, in your own words. If you don't know how it was counted, say so plainly. That's an honest answer, and a better one than an invented method | Every headline figure gets a defend-the-number question. F3 is the only figure in your material |
| C2 | "How do you know it was the pick path, and not something else, that moved the number?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: what the figure is sensitive to, and the assumption behind it you'd defend least. Name it yourself before they do, in your own words. If you don't know, say so, and say what you'd check. Don't supply a baseline or control you didn't have | The weakest-assumption move. Naming it first turns a gotcha into credibility |
| C3 | "What did you track while running the peak-season surge plan?" | JD, EXP | [grounded] "ran the site's peak-season surge plan two years running" | Keep the verb: "I ran the site's peak-season surge plan two years running." Answer slot: if you tracked measures while running it, say which and what they showed, in your own words. If none, say so plainly and describe what you ran | F2's discovery row. The JD's on-time line makes measures likely to be probed. JD first because that's the requirement it scores |

### D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal supervisor who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" | Pause, then three beats: 7 years in warehouse and distribution ops; cutting mis-picks 40% by redesigning the pick path; running the site's peak-season surge plan two years running. Then one sentence on what you'd bring to the role, said as an intention. Say nothing about the internal candidate, and finish inside sixty seconds | Tests composure on a fit question. Only the quoted material is used, so nothing collapses on the follow-up |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold what you stated: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: which part was yours, in your own words. If others did parts of it, name their parts plainly. Hold through two follow-ups. Concede only what's true, and specifically | Attribution probe on F3. Rehearsed candor is the point |
| D3 | "The JD says five-plus years of operations leadership. How many of your seven were actually leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Don't round up. Answer slot: count the years you've held roles leading people and say the number, in your own words. If it's under five, say the number plainly, then say what the rest of the time was. Today you're "a senior shift manager over 3 supervisors." Hold the number through follow-ups. Don't argue the requirement | F7 is the JD's only "required" line, and a titled years requirement is likely to be checked literally |

### E: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supervisor on your team wasn't performing. What did you do?" | VAL, JD | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick a real case with one of the supervisors you're over. It needs a specific gap, what you said and did, and where it ended. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | Themed by the JD's supervisor line (F4). VAL delivery, JD content |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a real moment with a named stake, what you said, and whether it landed. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | A common behavioral stem. No published Atlas values were found to theme it more precisely |
| E3 | "Tell me about a time you changed a process on the floor. How did the team take it?" | VAL, EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped: the pick-path redesign and the 40% cut in mis-pick rate, which are the beats your sentence states. Tell them in your own words. Answer slot: the question asks how the team took it. If there was pushback, say what it was and what you did. If there wasn't, say so plainly and describe the redesign | Themed by the JD's Lean line. F3 is the story your material carries |

### G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc using only these: 7 years in warehouse and distribution ops; senior shift manager over 3 supervisors today; the 40% mis-pick cut from the pick-path redesign; the site's peak-season surge plan, run two years running; green belt certified. End on why this role, in your own words | The biography question is scored. A pre-built arc keeps it economical and true |
| G2 | "Green belt: what have you actually done with it?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: if you've applied it on the job, say where and how, in your own words. If you haven't, say so plainly and say what the certification covered | F8 is the JD's plus-skill, and these get asked casually but are still scored |
| G3 | "What do you know about Atlas Freight?" | CO | [generic] | Say only what you've read yourself on their site or in their own materials, and name where you read it. Don't guess at their strategy. Close with a question that shows curiosity (see reverse questions) | Research couldn't run, so this stays generic. Your own reading before the interview is the fix |

### H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You'd sit between the site supervisors and the other managers here. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than pretending to know their seams: shared definitions of the metrics, one escalation path, disagreeing in private and aligning in public. Ask what the seam looks like today | Tests partnership fit without presupposing anything about your past |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: a real piece of shared work where you named others' parts. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | A common peer stem |
| H3 | "What would you need from the 12 supervisors in your first month, and what would they get from you?" | CASE, JD | [generic] | Reciprocity framing: what you'd ask of them (their view of each site's biggest problem, current numbers) and what you'd give them (clear priorities, one report, fast decisions). Said as a plan | Covers F4 and F1 from the peer side |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| F1 terminal operations across 4 sites | A2, H3 |
| F2 on-time performance | B1, C3 |
| F3 cost-per-shipment | B2 |
| F4 12 supervisors | A1, E1, H3 |
| F5 reporting in Excel | B3 |
| F6 Power BI | A3, B3 |
| F7 5+ years operations leadership (required) | D3 |
| F8 Lean/Six Sigma | G2, E3 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is on-time performance measured today, and how does it compare across the four sites?" | It shows you think in the JD's own metric, and the answer tells you what you'd be inheriting |
| "What's moving cost-per-shipment most right now?" | It signals you're already looking for the first lever, and it gives you material for any case that follows |
| "How are the 12 supervisors spread across the sites, and what's the strongest and weakest part of that team?" | It goes straight at your biggest gap (F4) with curiosity rather than defensiveness |
| "What reporting exists today, and how far along is Power BI?" | It's practical, and it tells you how large the F6 gap really is in this job |
| "What would make the first 90 days a clear success for this role?" | It invites them to describe the job as they'll judge it, which you can mirror in the rest of the interview |
| "Why is this role open now?" | The answer explains whether you're building, fixing or replacing, which changes what you should emphasise |

## Prohibited claims

These are claims this pack won't coach. They're the ones candidates tend to reach for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Leads, or has led, a supervisor team at the JD's scale | Inflated form of F4 | F4's quote at its own scope: "Today I'm a senior shift manager over 3 supervisors." The material says 3 supervisors. A1's slot stays inside how you work with those 3 |
| Has run terminal or multi-site operations | Inflated form of F1 and of "ran the site's peak-season surge plan two years running" | F1's quote at its own scope. The material says warehouse and distribution, and "the site's". A2's slot stays inside what that work covered |
| Cut cost-per-shipment through the pick-path redesign | Inflated form of F3 | "I cut the mis-pick rate 40% by redesigning the pick path." The material says nothing about cost. B2 is answered as a plan |
| Improved on-time performance with the surge plan | Inflated form of F2 | "I ran the site's peak-season surge plan two years running." C3's slot asks only what was tracked |
| Designed or built the surge plan | Inflated verb in F2's quote | The quote's verb is "ran". Keep it |
| Has 5+ years (or 7) of operations leadership | Inflated form of F7 | "7 years in warehouse and distribution ops." The material doesn't show how many of those were leadership years. D3's slot asks for the count |
| Has used, or built reporting in, Power BI | A negative you stated, F6 | "I haven't used Power BI." No slot |
| Holds a belt above green, or is a Lean/Six Sigma lead | Inflated form of F8 | "I'm green belt certified." |

## Sources

Provided material: your message (the JD text and your background).

Searches sent, all refused by the host (no search permission granted):

- `"Atlas Freight" regional logistics company values`: refused
- `"Atlas Freight" interview process operations manager`: refused
- `"Atlas Freight" terminals news 2026`: refused

No fetches were sent. Nothing in this pack about Atlas Freight comes from research or from memory. Every Atlas-specific statement comes from the JD text you pasted.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Refused. It would have themed the Values bank with published values and could have supported a values cheat sheet |
| 2. `Atlas Freight interview process operations manager` | unavailable | Refused. It would have replaced the flat generic-archetype weights with Atlas's documented rounds |
| 3. `Atlas Freight` strategy / recent news | unavailable | Refused. It would have grounded G3 and given at least one CO or CASE question in Atlas's current priorities |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you're meeting (future manager, panel, HR, peer) → persona weights rebuilt from flat, with the top persona's bank deepened to 4–5 questions
- The interviewer's name → an interviewer read from their public profile, persona weights adjusted to them, and a reverse question tied to their own path
- The recruiter's prep email → coverage of any announced case, presentation or site walk, each with its own build section
- Search permission for this session → targets 1–3 above, run within the L1 caps: G3 grounded, Values bank themed with Atlas's published values, loop-based weights
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, needs search permission) → a strategy brief for differentiator CASE and CO questions, and recent org context
- Your CV text → evidence rows quoted from your actual CV lines instead of your summary, and a defend-the-number question for every figure on it
- Your answers to the answer slots, told to me outside a drill → how many of your 7 years were in leadership (upgrades F7, D3), what you tracked during the surge plan (F2, C3), how the 40% was counted (F3, C1, C2, D2), what Excel reports you've built (F5, B3)
- The before-and-after mis-pick report from the pick-path redesign, or your green belt certificate → F3 or F8 raised from medium toward high, since these are the artifacts an operations role actually keeps
- A tuesday-dossier.md from the job-underwriter module → an evidence-verified highest-ROI objection and a prohibited list checked against confirmed facts, rather than one built here from your message
