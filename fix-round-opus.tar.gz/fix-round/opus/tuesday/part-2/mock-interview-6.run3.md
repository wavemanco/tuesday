Quick update: I've read the prep playbook, and next I'm doing a little research on Larkfield Systems (values, interview process, recent news) before I write your three round packs.
I've written a prep pack covering all three rounds. One section is shared: how each job requirement matches your background, and the claims not to make. Then each round has its own question bank with answer guidance, plus questions for you to ask them.

**What it's built on:**
- **Your message only.** That's the one-line role description and the four sentences about your background, quoted exactly.
- **No research on Larkfield.** My three web searches were blocked by a permission setting. So nothing about the company's values, strategy or interview process is in the pack, and the company-specific questions are marked as general patterns.

**How the rounds come out:**
- **Tuesday, with the Director:** mostly gap-probing and live problems from the job.
- **Thursday, the panel:** the staff engineers will dig into the 60% figure and the hiring loop. The PM will push on how you'd work together.
- **Monday, the VP:** leans on values and leadership philosophy, as the recruiter said.

**Two things to know before rehearsing:**
- **The question most worth practising is A1:** "You've led one team of six; this is two squads and eleven engineers. Why are you ready?" It's the most predictable objection, and it comes back on Monday as L1. The plan is to state "I've never managed managers" yourself, before they ask.
- **Keep the 60% sentence exactly as you wrote it.** Your team's on-call dropped 60% *after* the reliability quarter. Don't let it become "I cut on-call by 60%." Several questions across the rounds test exactly that.

If you'd like a mock interview, I can play the Director on A1 now, with live follow-ups.
I can also save a `tuesday-dossier.md` that records the gaps this prep turned up, for later sessions.
I can convert the pack to Word if you want.

Three questions, each of which would reshape the pack:
1. Can you paste the full job description and your CV? Right now everything rests on four sentences, and more material means fewer generic answer templates.
2. Did the recruiter share anything else, such as interviewer names, focus areas, or something to prepare for the panel?
3. Do you want to allow web search so I can pull Larkfield's published values and recent news? That would add a values cheat sheet for Monday and company-specific questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack — Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop — three scheduled rounds, one shared fit snapshot, one mini-pack per round
**Rounds, from your message:**

| Round | Format | Interviewer(s) and relationship |
|---|---|---|
| Tuesday | 45 min, one-to-one | Director of Engineering, your would-be manager |
| Thursday after | 60 min, panel | Two staff engineers and a product manager |
| Following Monday | 30 min, one-to-one | VP Engineering, described by the recruiter as "values and leadership philosophy" |

Interviewer names are not known, so there is no interviewer read and persona weights rest on each round's relationship.

---

## How to use this pack

- **Personas** describe how a question is asked: the Skeptic probes gaps quietly, the Pressure interviewer time-boxes and pushes, the Prober asks for denominators, and so on.
- **Types** describe what is being scored:
  - **JD** — can you do the listed job, gaps included
  - **EXP** — does your own experience hold up under scrutiny, and what was actually yours
  - **CASE** — structure and reasoning on a live problem from the role
  - **VAL** — behaviour that shows values and leadership philosophy
  - **CO** — company and strategy knowledge
- **Provenance** shows how much to trust each row. `[grounded]` means it traces to something you wrote me. `[inferred]` means the pack derived it. `[generic]` means it is a pattern for the role with no claim about Larkfield.
- **Answer slots** mark places where the interviewer will probably probe something your material doesn't cover. Each one has two honest branches. Answer whichever is true, in your own words.
- Guidance is scaffolding, not a script. Everything here about your past rests on four sentences you wrote me, quoted in the fit snapshot. If a cell seems to say more than those sentences do, trust the sentences.

---

# Shared sections

## Fit snapshot

The requirements are quoted from the role description you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads or eleven engineers, and the words stay there: "For three years I've been team lead of a team of six." If asked about leading leads, use the plain acknowledgment you gave: "I've never managed managers." Answer slot: the JD's "two squads" makes a probe on running more than one team likely. If you have led or coordinated work across more than one team, say what and how, in your own words. If you haven't, say so plainly and stay with the team of six. |
| F2 | "building device-management services" — JD | none given | none | [grounded] | discovery | Your material names a payments company and says nothing about devices. That is the pack's observation, not words for you. Answer slot: the JD's device-management line makes a domain probe likely. If any of your engineering work has touched devices or hardware-connected systems, say what it was and which part was yours. If none has, say so plainly, return to your nine years in engineering, and say what you would learn first. |
| F3 | "own delivery" — JD | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote shows a priority call you pushed through. It doesn't show ownership of a delivery plan. The words stay at the quote's scope, and "after" stays "after", never "because": "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after it." Answer slot: "own delivery" makes a probe on how you plan and track a team's delivery likely. If that planning and tracking was yours, say how, in your own words. If it sat with someone else, or there was no such process, say so plainly and stay with the reliability quarter. |
| F4 | "own delivery, hiring and growth for 11 engineers" (hiring) — JD | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | Running the loop for backend roles is adjacent to owning a team's hiring. The quote doesn't say which decisions in that loop were yours. Words: "I run our hiring loop for backend roles — about 40 interviews last year." Keep the "about", and keep the 40 attached to interviews, not hires. Answer slot: "own … hiring" makes a probe on decisions likely. If the final call on candidates, or another decision in the loop, was yours, say which and how. If it wasn't, say so plainly and stay with running the loop. |
| F5 | "own delivery, hiring and growth for 11 engineers" (growth) — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Being team lead of six touches the requirement but doesn't show whether those engineers' growth was your job. Answer slot: if developing the people on your team was part of your role, say what you did for one person, in your own words. If it sat with a manager above you, say so plainly and say how you would run it for eleven. |
| F6 | "partner with hardware … on roadmap" — JD | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | This is a gap you stated, so no wording can close it. Words: "I've never owned a hardware-adjacent roadmap." Follow it with how you would learn, said as a plan and never as a past. Your sentence is about owning a roadmap. The material says nothing either way about working alongside hardware teams, and the pack adds nothing there. |
| F7 | "partner with … product on roadmap" — JD | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote says "against roadmap pressure". It doesn't say who applied the pressure or how it was settled. Answer slot: the JD's product-partnership line makes a probe likely on who was on the other side of that pressure. If it was product, say how you and they worked it through, in your own words. If it came from elsewhere, or there was no negotiation, say so plainly and stay with what you pushed through. |

**Most likely objection, across all three rounds:** F1. One team of six moving to two squads and eleven engineers, alongside your stated "never managed managers". It gets the deepest rehearsal, as A1 on Tuesday, and comes back as L1 on Monday. **This is the highest-ROI prep in the pack.** F6 is second, rehearsed in A2 and E4.

## Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| "Lead two squads" | F1 | A1, A4, B1, G1, L1 |
| "building device-management services" | F2 | B2, D3, K1 |
| "own delivery" | F3 | A3, B1, B3, D1, D2, G2, K2 |
| "hiring … for 11 engineers" | F4 | B4, D4, J3 |
| "growth for 11 engineers" | F5 | B3, J4 |
| "partner with hardware … on roadmap" | F6 | A2, B2, E4 |
| "partner with … product on roadmap" | F7 | E2, H1, J2 |
| "industrial IoT, ~600 people" (company context, not a requirement) | — | C1 and K1 touch it. No dedicated question, because nothing about Larkfield was researched (see Sources) |

## Prohibited claims

This pack will not coach these claims, and you shouldn't say them under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers or led leads | A negative you stated (F1) | "I've never managed managers." No slot. |
| Has owned a hardware-adjacent roadmap | A negative you stated (F6) | "I've never owned a hardware-adjacent roadmap." No slot. |
| Has led two teams, or eleven engineers | Inflated form of F1 | F1's quote at its own scope. The material says one team of six. A1's slot asks only whether you coordinated across more than one team. |
| Was line manager of six engineers | Inflated form of F1 ("team lead" turned into people manager) | F1's quote at its own scope: "team lead of 6". The material doesn't say whether reporting lines were yours. F5's slot asks only what you did for the people on your team. |
| The reliability quarter cut on-call by 60% (causal), or "I cut on-call by 60%" | Inflated form of F3 (logical form: "after" turned into "because"; verb: "my team's burden dropped" turned into "I cut") | F3's quote exactly: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." A3's slots ask how it was counted and which part was yours. |
| Owned hiring, made the hiring decisions, or "hired about 40 engineers" | Inflated form of F4 (verb; the number moved from interviews to hires) | F4's quote exactly: "I run our hiring loop for backend roles — about 40 interviews last year." B4's slot asks only which decisions in the loop were yours. |
| Owned delivery or a delivery plan | Inflated form of F3 | F3's quote at its own scope. The material shows a priority call, not a delivery process. |

Device-management experience and people-growth work are not listed, because your material is silent on them rather than stretched. They are answer slots (F2 and F5).

---

# Round 1 — Tuesday: Hiring manager (Director of Engineering), 45 min

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probes on the step up from six to eleven, on hardware, and on "why now" | High, 4 questions. The hiring-manager prior is Case and Skeptic, and a would-be boss carries the cost of a mis-hire personally. F1 and F6 are exactly what they need to de-risk | Rehearse A1 until it bores you. Name the limit before it's asked for, then a concrete ramp plan. Calm candour beats bluffing a competency the Director owns |
| Case / Strategist | Live problems from their roadmap: two squads, reliability against commitments, hardware slips | High, 4 questions. Same prior: they are buying capability and want to see how you think about their actual job | Clarify, then objective, approach, metrics and risks. Think aloud. Challenge one premise respectfully per case |
| Conversational | Openers: "walk me through your journey", "why Larkfield" | Low, 2 questions. A 45-minute slot still opens with rapport, and that part is scored | A pre-scripted 90-second arc. Treat casual questions as scored |
| Pressure, Prober, Values, Peer | Minor here | Not banked for Tuesday. They are covered on Thursday and Monday, so you won't meet them for the first time live | — |

## Question bank

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led one team of six. This is two squads and eleven engineers. Why are you ready for that?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | **Highest-ROI rehearsal in the pack.** Hold only what the quote carries: "For three years I've been team lead of a team of six." Name the limit before they do: "I've never managed managers, and eleven across two squads is a real step from six." Answer slot: "two squads" makes a probe on multi-team work likely. If you have led or coordinated across more than one team, say what and how, in your own words. If you haven't, say so plainly. Then give your plan for the first 90 days with two squads, said as a plan. Expect two follow-ups, probably "So you've never managed a lead?" and "How do I know you won't drown?". Hold by returning to the team of six and the plan, never by adding to them. Concede the size of the step and keep the claim intact | F1 is the biggest gap a would-be boss will price, and it will come up in some form. JD because it scores the headline requirement directly. Deepest rehearsal because the honest answer has to be ready before the probe arrives |
| A2 | "I don't see hardware in your background. How would you partner with our hardware team on a roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Plain acknowledgment first, in your words: "I've never owned a hardware-adjacent roadmap." Then a plan, said as what you would do: who you would meet first, what you would ask about how hardware and software releases line up, and how you would make sequencing decisions visible to both sides. Don't imply hardware experience you didn't state. Answer slot: if you have ever worked alongside a hardware or firmware team, say what it was and what your part was. If not, the acknowledgment and the plan are the whole answer | F6 is a gap you stated and the JD names, so it will be probed. The interviewer's negative is sourced from your own sentence. JD type |
| A3 | "Your team's on-call burden dropped 60%. How was that counted, and how much of it came from the reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say the sentence as you wrote it, keeping "after". Then the four defend-the-number slots, each in your own words: how the 60% was counted; what it is sensitive to; the assumption behind it you would defend least, named before they ask; and which part was yours. Your sentence says you pushed the quarter through. If you don't know exactly how the figure was counted, saying so is an honest answer. The pack supplies no method or baseline | F3 holds your one headline metric, and every metric gets a defend-the-number question. EXP because it tests attribution and counting, not the outcome |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Choose one of the gaps you actually stated rather than a strength dressed up as a weakness. Either fits: "I've never owned a hardware-adjacent roadmap," or "I've never managed managers." Give one sentence on what you would do about it in the first quarter, as a plan. Stop there. Don't stack a second weakness, and don't immediately offset it | A standard Skeptic stem. F1 and F6 give you an honest answer already, which is exactly why a disguised strength would land badly |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Both squads have committed roadmap work, and on-call on one of them is climbing. Walk me through your first month." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Clarify first: what is driving the pages, what was committed and to whom, and whether the squads share services. Then the objective, the options (ring-fenced capacity, a time-boxed reliability push, re-sequencing commitments), who you would tell and how you would measure. You can mention the precedent in your own sentence's words: "I've done a version of this before. I pushed a reliability quarter through against roadmap pressure." Don't describe how that quarter was planned unless you are describing what actually happened. Close with the risks of your own plan | F3's requirement asked as a live problem. Your one quoted story fits it, which is why it is worth having ready. CASE delivery on JD content |
| B2 | "Hardware's firmware slips six weeks, and a customer commitment depends on our device-management release. What do you do?" | CASE | [generic] | Structure it: what exactly is blocked and what isn't; whether the software side can ship independently or behind a flag; who must hear first (product, the customer owner, your Director) and with what options; and what you would change so the next slip shows up earlier. It needs no claim about your past, so the guidance makes none. Ask one clarifying question before you start | F6 and F2's territory asked as a decision rather than a record. A boss can test your judgement here without your having the history. `[generic]` because nothing about Larkfield's actual dependencies was researched |
| B3 | "You inherit eleven engineers you didn't hire. What are your first 30, 60 and 90 days?" | CASE | [generic] | Structure it across the JD's three verbs: delivery (what is in flight, what is at risk), hiring (open roles, the loop as it stands) and growth (one-to-ones with all eleven, what each wants next). Say what you would not change in the first 30 days. A plan, no claims about your past | Covers F3, F4 and F5 together. A very common hiring-manager CASE for a manager role |
| B4 | "We need to hire three engineers next half. How would you run that?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from what you do now, in the quote's words: you run the hiring loop for backend roles, about 40 interviews last year. Keep the "about". Answer slot: "own … hiring" makes a probe on decisions likely. If the final call on candidates, or another part of the loop, was yours to decide, say which and how. If it wasn't, say so plainly and stay with running the loop. Then the plan for three hires, as a plan: what you would want from the role definition, the loop and calibration | F4 is your strongest adjacent evidence for a named JD verb, and a boss will check how far it reaches. JD type, with an EXP undertone |

### C — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey, and why Larkfield?" | CO | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc from the quote: nine years in engineering, three as team lead of a team of six, at a payments company now. The "why Larkfield" half is yours to supply: your real reason, in your own words. The pack has no researched facts about Larkfield to offer you (see Sources), so prepare one specific point from your own reading of their site, and say it only if you have actually read it | Every hiring-manager round opens this way, and it is scored for economy and motivation. CO because "why here" tests homework, which is thin until research runs |
| C2 | "What do you need from a manager to do your best work?" | VAL | [generic] | Answer honestly with two or three preferences, such as how often you want to meet, how you like disagreement handled, and what autonomy you want on hiring and priorities. No claim about your past is needed. This is also your chance to test fit with your would-be boss, so listen to their answer | Likely from a would-be boss, and it is a two-way fit signal. VAL because it reads your working style |

## Reverse questions — Tuesday

| Question | Why it lands |
|---|---|
| "Do the two squads have tech leads today, or would I be the only lead across all eleven?" | It shows how big the F1 step really is, and asking it shows you have already thought about the structure |
| "What would make you say, six months in, that this hire was clearly right?" | It gets the Director's actual scorecard, which none of your prep can supply |
| "How are hardware and software roadmaps sequenced today, and where does that break?" | It is aimed straight at F6 and turns your gap into curiosity about their real problem |
| "What's the reliability and on-call picture for these services right now?" | It connects to the one story you have, without retelling it |
| "How do you support someone stepping up from leading one team to leading two?" | It names the step honestly and tests whether they will coach it |
| "Why is this role open?" | Diligence: a backfill, growth and a reorg each mean a different first year |

---

# Round 2 — Thursday: Panel (two staff engineers and a product manager), 60 min

## Persona table

Weights blend each member's two leading personas. The staff engineers are read as senior engineers who would work in or beside your squads, so their personas are peer and technical depth. The PM is cross-functional. Whether the staff engineers would sit in your squads isn't known. If you find out, tell me, because it shifts the peer weighting.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Staff engineers going two levels into the reliability quarter, the 60% and the hiring loop | High, 4 questions. The technical-depth prior is Prober plus Pressure, and your only metric is the obvious target | Know what you can and can't say about how the figure was counted. Name your weakest assumption first. Say "I don't know" plainly where that's true |
| Peer Evaluator | Seams: staff engineer and EM on technical direction, PM and EM on roadmap, "what would you need from me" | High, 4 questions. All three panellists are pricing what you add to, or cost, their own work | Reciprocity framing. Propose principles for the seam rather than pretending to know it. Show spine and tact together |
| Pressure | Time-boxed "why you" and "how much was actually you" | Medium-low, 2 questions. The second half of the technical-depth prior, and panels often have one member who pushes | Pause, restate the question, anchor in what you actually said, and hold for two follow-ups before conceding |
| Values / Behavioral | The PM's "tell me about a time you disagreed with product" | Low, 2 questions. The cross-functional prior, softened by the PM's one seat out of three | STAR shape: "we" for context, "I" for your contribution. Where your material has no story, say so rather than invent an ending |

## Question bank

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Take us through the reliability quarter. What was in it, and how was the work chosen?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Use only the beats the sentence states: a reliability quarter, you pushed it through, it was against roadmap pressure, and your team's on-call burden dropped 60% afterwards. What was in the quarter is yours to tell from memory, in your own words. Answer slot: staff engineers will probe how the work was chosen. If you chose it or set the method, say how. If the team or someone else chose it, say so plainly and say what your part was in getting it through | F3 is the story staff engineers will test hardest. EXP because they are checking what was really yours |
| D2 | "Sixty percent of what? Pages, hours, incidents? Over what window?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The deeper defend-the-number version of A3, and staff engineers will want the denominator. In your own words: what was counted, over what period, and what else changed in that period that could have contributed. Volunteer the assumption you would defend least before they find it. If you don't know the exact measure, say "I don't know exactly how it was counted". The pack names no metric for you | Prober stem on F3's figure. The second level of follow-up is where unrehearsed numbers fall apart |
| D3 | "How would you think about reliability for services that manage devices out in the field?" | CASE | [generic] | Structure, not experience. Name what you would want to learn first: how devices connect, how versions are rolled out and rolled back, what "down" means for a customer, and how on-call works today. Ask them what hurts most. If F2's answer slot has a true first branch for you, say it here in your own words. If not, the plain line is that this would be new domain for you and these are the questions you would start with | F2 asked as a live problem. Staff engineers will test whether you would add to their load or ease it. `[generic]` because it rests on the domain pattern, not on Larkfield's systems |
| D4 | "You run the hiring loop. What does it actually test, and how do you know it predicts anything?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from the sentence: you run the loop for backend roles, about 40 interviews last year. Say in your own words what the loop tests. Answer slot: the Prober will ask about calibration or predictive checks. If you checked how hires performed against interview scores, say how. If no such check existed, say so plainly and say what you would want to know. Keep the 40 as interviews | F4 under a Prober's lens. Staff engineers often sit on loops and will care whether yours is rigorous |

### E — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the line between a staff engineer's call and yours on technical direction?" | JD | [generic] | Propose principles for the seam rather than claiming to know theirs: technical direction leads with them, and you own trade-offs against delivery, people and priorities; disagreements surface early and get decided in the open; you back their calls in front of others. Then ask how it works today | The core seam for this panel. Peer Evaluator stem. JD, because leading squads with staff engineers in them is the job |
| E2 | "Product wants a feature and your engineers want reliability work. How do we decide together?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Lead with how you would want to decide with this PM: shared data on cost to customers, an explicit capacity split, and a written decision. Then the precedent in your own sentence's words. Answer slot: the JD's product-partnership line makes a probe on who was on the other side likely. If it was product, say how you worked it through together. If the pressure came from elsewhere, or there was no negotiation, say so plainly. Don't paint the PM's side as the obstacle | F7 is the PM's natural probe. The quote is adjacent evidence, and the slot keeps it at its own scope |
| E3 | "What would you need from us in your first month, and what would you bring us?" | VAL | [generic] | Answer both halves, the reciprocity one first. What you bring: a plan you can state, and an honest list of what you would protect for them. What you need: candid context on the services, the hardware relationship, and where the last year hurt. No claims about your past are needed | A reciprocity question for peers. It scores whether you reduce their load. VAL because it reads partnership style |
| E4 | "Our roadmap and hardware's don't line up. How do you want to work with me on that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | If it comes up, use the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then propose how you would work with the PM: joint planning with the hardware leads, a dependency map you both keep, and agreeing in advance who tells customers what when something slips. A plan, not a past | F6 again, from the PM's seat and in collegial packaging. Rehearsing it twice keeps the acknowledgment steady |

### G — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a staff engineer we could promote internally?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause and restate the question. Then three facts from your sentences: nine years in engineering, three as team lead of six; you run the hiring loop for backend roles, about 40 interviews last year; you pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% after. Make no comparison with the internal candidate, because you know nothing about them. Close on what you would bring as a plan. Stay inside 60 seconds | A Pressure stem a staff engineer might genuinely mean. It tests composure and compression across F1, F4 and F3 |
| G2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold first, using the sentence: it was your team's on-call burden, and what you did was push the reliability quarter through against roadmap pressure. Answer slot: if you also did part of the engineering work, say which part. If the team did it, say so plainly. Concede specifically: the drop came after the quarter, and you can't claim all of it. Hold that position through two follow-ups, and don't give up "I pushed it through" just to restore harmony | Pressure stem on F3. Hold-then-concede is the skill being scored |

### H — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you disagreed with a product decision." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | If the roadmap pressure in your sentence came from product, this is your story: the beats are the ones the sentence states, told in your own words, with "we" for context and "I" for your contribution. If it didn't come from product, pick another time you disagreed with a product call. It needs a named decision, what you said, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | Raised by the JD's "partner with … product" and by a PM sitting on the panel. Behavioural format, F7's territory |
| H2 | "Tell me about a time you had to deliver an unpopular message to a partner team or to leadership." | VAL | [generic] | A selection scaffold. Pick a time with a clear stake, a moment you didn't soften the message out of existence, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Values persona stem. A PM will look for the hard truth landing. Nothing in your four sentences supplies one, so this is scaffolded |

## Reverse questions — Thursday

| Question | Why it lands |
|---|---|
| "What could a new manager do in their first month that would genuinely help you?" (to the staff engineers) | Reciprocity. It shows you are pricing their load, not only yours |
| "Where's the hardest technical problem in device management right now, and where could an EM make it easier rather than harder?" | It invites their real problem and acknowledges the domain is theirs |
| "How do product and hardware decide sequencing today, and where does it hurt?" (to the PM) | It goes straight at F6 and F7, and the answer tells you what the job really is |
| "How do on-call and incidents work across the two squads today?" | It ties to the reliability story without retelling it, and staff engineers usually have strong views |
| "How do staff engineers and the EM split technical decisions here, in practice?" | It follows up E1 with their reality rather than your principles |
| "What do you want from whoever takes this role that you're not getting today?" | It surfaces unmet needs without presuming anything about a previous manager |

---

# Round 3 — Monday: VP Engineering, 30 min, "values and leadership philosophy"

## Persona table

The recruiter's own words name this as a values round, so a values-style round is detected for Monday. The values cheat sheet the pack would normally add is dropped, because Larkfield's published values are not in hand (see Sources and the Upgrade menu).

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?", "tell me about a time…" | High, 4 questions. The recruiter named the focus, which outweighs the executive prior | Have two or three principles you genuinely hold, each tied to a story your material carries. Where none does, say so and use a scaffold |
| Case / Strategist | Altitude: where the platform should go, trade-offs across headcount and investment | Low, 2 questions. The executive prior, shrunk by the 30-minute values framing | State the objective first, then the trade-off and what you would watch. Keep answers short |
| Pressure | A skip-level "why bet on you?" | Low, 2 questions. The executive prior's other half. F1's objection returns at altitude | Hold-then-concede, kept short |

## Question bank

### J — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles — about 40 interviews last year" | Name two or three principles you would actually stand behind. The pack doesn't choose them for you. Tie each one to something real. A principle about when to spend capacity on system health can rest on your sentence: you pushed a reliability quarter through against roadmap pressure. A principle about hiring can rest on running the hiring loop for backend roles. For any principle neither sentence carries, say how you apply it rather than inventing a story. Stop at two minutes | The recruiter's stated focus, asked directly. VAL because a values round scores whether the philosophy shows up in behaviour, not slogans |
| J2 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your sentence has the right shape: a position pushed through against roadmap pressure. Answer slot: the question asks about someone senior. If the pressure came from someone senior to you, say who, by role, and how you held the position, in your own words. If it didn't, or the pressure was diffuse, say so plainly and tell it as what it was. Make sure the relationship outcome is in the answer, and if you don't know it, don't supply one | Values persona stem. F3 and F7's story is the natural candidate, and the slot keeps it from being upgraded into a confrontation it may not have been |
| J3 | "Tell me about a hiring decision you got wrong, or nearly did." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Your sentence gives you the context: you run the hiring loop for backend roles. Pick a real case that has a decision, what you missed or nearly missed, and what you changed afterwards. If you can't recall one, say so plainly and say what you watch for, or how you would handle it | The JD's "own … hiring" raises it. A VP probing judgement will prefer a mistake to a success. F4's context, scaffolded for the story itself |
| J4 | "Tell me about a time you helped someone on your team grow." | VAL | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | F5's answer slot applies. If developing people on your team was part of your role as team lead, pick one person: where they started, what you did, and where they got to, in your own words. If that sat with a manager above you, say so plainly, then give the nearest thing you did, or how you would run growth for eleven | The JD's "growth for 11 engineers" raises it, and a VP's leadership round will test it. `[inferred]` because the material doesn't show whether this was your job |

### K — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Where should a device-management platform team be in two years?" | CO | [generic] | Clarify first by asking what customers need most from it today. Then structure: reliability, how fast changes reach the fleet, and how easily hardware and product can build on it. Say plainly that you would form a real view only after learning their systems. The pack holds no researched Larkfield strategy (see Sources), so don't cite specifics you haven't read yourself | A VP tests altitude. `[generic]` because it couldn't be grounded in Larkfield's strategy, so it is the clearest upgrade if research runs |
| K2 | "You have eleven engineers and budget for either two more hires or one quarter of platform investment. Which?" | CASE | [generic] | State the objective, then what you would need to know (on-call load, roadmap commitments, how long hiring takes). Pick one and give the condition that would change your mind. A trade-off answer, with no claim about your past | Tests whether you reason as a manager of investments, not only of people. Covers F3 and F4 at altitude |

### L — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Why should I bet on someone who has never managed managers for a role this size?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A short version of A1. Agree with the fact plainly: "I've never managed managers." Hold what your sentence carries: three years as team lead of a team of six. Give one line of plan for the step to two squads. Hold through one push, concede the step is real, and don't add history to close the gap | F1's objection returns at skip-level, and it's sourced from your own stated negative. Rehearsing it twice is the point |
| L2 | "What would your current team say is your biggest weakness as a lead?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pick a real one you have heard or can stand behind. Don't put words in your team's mouth: if they haven't told you, say "I'd guess…" and say why. Give one thing you are doing about it. If nothing comes to mind, say so plainly and name the area you watch most | A Pressure-style composure probe in values packaging. The premise rests on your being team lead of six (F1) |

## Reverse questions — Monday

| Question | Why it lands |
|---|---|
| "Which of Larkfield's values do you see tested hardest in device management?" | It shows you take the values seriously and gets the VP's own reading, which the pack couldn't research |
| "How does engineering leadership weigh reliability work against roadmap commitments here?" | It ties to the one story you have and tests whether it would be backed |
| "How do you grow engineering managers here, and what support would someone stepping up from one team get?" | It's honest about F1 and makes it a question about their system |
| "What separates the managers who thrive here from those who struggle?" | Leadership-philosophy reciprocity, and it gives you their bar in their words |
| "Where is the hardware–software partnership heading in the next year?" | F6 at altitude: diligence on the hardest seam of the job |

---

# Sources

**Provided documents:** your message. It contained the role description (quoted as the JD), the three-round schedule with interviewer roles and lengths, the recruiter's "values and leadership philosophy" framing, and four sentences of background (quoted in the fit snapshot). No dossier was present, and no CV.

**Searches sent:**

| Query | Result |
|---|---|
| Larkfield Systems values | refused (web search permission not granted) |
| Larkfield Systems interview process engineering manager | refused (web search permission not granted) |
| Larkfield Systems industrial IoT news 2026 | refused (web search permission not granted) |

No fetches were sent.

**Loop source:** your own words establish the loop: three rounds, with who runs each and how long. The recruiter's "values and leadership philosophy" documents a values-style round on Monday. Persona weights rest on those words, not on an archetype.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | The search was refused. It would have supplied the official value names for a Monday values cheat sheet and themed the J bank by value |
| 2. Larkfield Systems interview process, engineering manager | unavailable | The search was refused. Your own words already fix the rounds and persona weights, so it would have added only round formats and any case style |
| 3. Larkfield Systems strategy and recent news | unavailable | The search was refused. It would have grounded C1 and K1 and added a CO or CASE question on current strategy |
| 4. Interviewer name and company | n/a | No interviewer names were given, so there was no query to form. The interviewer read is absent |
| 5. Representative Engineering Manager JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Allow web search, or paste Larkfield's values or careers page → a Monday values cheat sheet with each value by its official name, mapped to your stories. J1 to J4 become themed by value
- Allow web search for strategy and news → C1 and K1 move from `[generic]` to grounded, and one strategy-grounded CASE question is added
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and, with names, the interviewers' public talks and writing
- Interviewer names (the Director, the two staff engineers, the PM, the VP) → an interviewer read per round, per-member persona assignment on Thursday, and at least one reverse question tied to each person's career path
- The full JD text → any requirements beyond the one-line description become fit rows and are checked in the coverage table
- Your CV → more evidence quotes, so more questions are story-mapped instead of scaffolded. Most affected: H2, J3, J4, L2
- Whether "team lead of 6" included line management of those six → F1 and F5 can be re-graded, and A1, B3 and J4 regenerated
- Any work alongside a hardware or firmware team → F6 gains a second row and A2 and E4 gain a story
- Who applied the roadmap pressure behind the reliability quarter, and how the 60% was counted → F3 and F7 firm up. A3, D1, D2, E2, G2, H1 and J2 regenerate
- Which decisions in the hiring loop were yours → F4 is re-graded. B4, D4 and J3 regenerate
- Anything the recruiter said about focus areas or a deliverable (for example a presentation at the panel) → a graded-deliverable build section
- How much prep time you have before Tuesday → a prioritised prep schedule
- A tuesday-dossier.md from an underwriting pass → evidence-derived objections and a prohibited-claims list checked against confirmed evidence. Not needed for this pack
