I'm setting up your interview prep pack. Next I'll run a few quick web searches on Saltmarsh Games and Tobias Wrenfield.
Your prep pack is ready: **/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-canned-3d126f82/saltmarsh-games_live-operations-producer_interview_pack.md**

I built it around the format on Saltmarsh's careers page. They call it the "Outage Hour": one 60-minute interview with the hiring manager. It opens with a tabletop exercise on a simulated outage during a live event, then moves to a conversation about their values. So the pack weights those two halves most heavily.

What the research changed:
- **Project Larkspur:** in September 2026 Saltmarsh announced that both of its games move to a season pass and one shared events calendar from February. The pack prepares you for questions about that, including the in-app purchase gap you mentioned.
- **Tobias's background:** he was a QA lead before this role, and his GDC 2026 talk argues that patch notes should describe only what actually shipped. Expect close questions about your release checklist and about how accurately you'd communicate with players.

The question most worth rehearsing is **C1**, which the pack marks as its highest-priority prep: "you ran one title's calendar, and this role runs two titles across four teams." The pack gives you an honest answer you can hold under follow-ups.

Say the word and I'll play the Skeptic on C1, or run the outage tabletop (A1) live.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to use in later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The pack treats him as the hiring manager. Saltmarsh's careers page says its one 60-minute interview is run by the hiring manager, and your interview is 60 minutes with him.
**Format:** Saltmarsh's careers page calls this round "the Outage Hour": "a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." Plan for both halves.

---

## How to use this pack

Read each question on two levels. The **persona** is how the question gets asked: the style and the pressure. The **type** is what's being scored. Each question is tagged with one or more of these five types:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Saltmarsh's published values |
| EXP | Whether what you say about your experience holds up when probed, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Saltmarsh's current strategy and can think at its level |
| CASE | How you structure and reason through a live problem from the role |

Every row has a **Provenance** label. `[grounded]` means it traces to something you told me or to a page cited in Sources. `[inferred]` means it's derived, and the row says from what. `[generic]` means it's a pattern for the role family, with no claim about Saltmarsh.

The answer guidance is scaffolding, not a script. An **answer slot** is a place where only you know the truth. It gives you two honest branches. Pick the true one in the interview and say it in your own words.

---

## Fit snapshot

Each row sets a requirement against your words, quoted exactly from your message. That's the only material the pack uses about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material covers one title's weekly content drops. It doesn't cover two titles' live events, and your words should stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "plan" makes a probe on who decided what went into each drop likely. If that planning was yours, say how you decided, in your own words. If it sat with someone else, or there was no such step, say so plainly and stay with running the calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show which teams you worked with on drops. Your note that you've never led a team is about leading, not coordinating, so keep the two apart. Answer slot: if running drops meant working with any of design, art, engineering or community, name which ones and what you did with them, in your own words. If it didn't, say so plainly and describe how you'd learn those relationships in your first month |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly retention numbers is next to this requirement, not the same thing. Your material says you presented the numbers. It doesn't say you owned a review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you prepared or chose those numbers yourself, say which parts, in your own words. If someone else produced them and you presented, say so plainly |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. This is a single line you told me, with nothing behind it I could inspect, so expect a probe. Lead with it in its own terms: you wrote it, and QA still uses it. Answer slot: the JD's "manage" makes a probe on upkeep likely. If you've revised it since writing it, say how. If you haven't, or someone else maintains it, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your four years are as a producer, and two of them include weekly content drops. Your material doesn't say whether the game was live-service for all four years. Answer slot: if it was, say so and say what live work filled the earlier years, in your own words. If the live content work was the last two years, say so plainly |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Your sentence says it in the JD's own terms. Lead with the cadence and the duration: weekly, for two years. Expect a probe on what a week looked like (D3) |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap. Presenting retention numbers to the studio head every month speaks directly to this. Expect a probe on how they were counted (D1). Answer slot: if you know how they were counted, say so in your own words. If you don't, say plainly that you don't know how the figure was counted |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Your checklist is written work that's still in use. That's what this line asks about, from a different angle. Words: "The release checklist I wrote is still what our QA team uses." Saying a patch note aloud (A5) is the live test |

---

## Reading the interviewer

Public professional footprint only, from one search result. See Sources.

- **Career pattern:** Head of Live Operations at Saltmarsh. Before that he was a QA lead at a console studio. `[grounded]`
- **Self-described stance:** he gave a GDC 2026 talk, "Patch Notes Are a Promise". It argues that a live team is judged by how often its patch notes describe what actually shipped. `[grounded]`

What this means in practice:

1. **Expect real depth on the release checklist.** A former QA lead will ask what's on it and how it gets used (D2, E2). Know your own checklist.
2. **In the tabletop, accurate player communication is a scored beat, not a side note.** His talk and the value "Ship the Patch Not the Promise" say the same thing: say only what's built (A2, A5).
3. **Precision beats polish with him.** An inflated claim is exactly what his talk's theme is built to catch, so the hold-then-concede rehearsals matter most here.
4. **Shared vocabulary, not a shared career jump.** Your F4 sentence, "Wrote the release checklist our QA team still uses.", is in his native language. Mention it once, plainly, and don't lean on it.

---

## Persona table

| Persona | How it shows up in this hour | Likelihood and the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | The tabletop: a simulated outage during a live event, worked live | **Highest, 5 questions.** It's half of the documented Outage Hour, and the hiring-manager prior puts it on top anyway | Clarify, objective, sequence, communicate, review. Think aloud. Use Saltmarsh's value names where they genuinely apply |
| Values / Behavioral (bank B) | The second half: a values conversation | **High, 4 questions.** The careers page names it, and Saltmarsh publishes three values by name | One story or scaffold per value. "We" for context, "I" for your part. Where your material has no ending, don't supply one |
| Skeptic (bank C) | Quiet probing of scope: one title versus two, coordination, monetisation | **High, 4 questions.** Hiring-manager prior. F1 and F2 are where your material is thinnest against the JD | Rehearse C1 until it's boring. Bridge only from your stated sentences, and name the limit before he does |
| Data-Driven Prober (bank D) | "How were those numbers counted?" "What's on the checklist?" | **Mid, 3 questions.** Raised by his QA background and the JD's retention line. Your F4 and F7 sentences are the magnets | Know what you can and can't say about each item. "I don't know how that was counted" is an honest answer |
| Pressure / Stress (bank E) | Time-boxed or "how much was actually you" moments, possibly inside the outage simulation | **Low, 2 questions.** A simulated outage is pressure by design, but nothing suggests an adversarial interviewer | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational (bank G) | The opener and "why Saltmarsh" | **Low, 2 questions.** A single hour leaves little room for small talk, but the opener still gets scored | A pre-built 90-second arc |
| Peer Evaluator | Not expected | Not included. This is a single hiring-manager interview with no peer round in the documented loop | None needed |

---

## Question banks

### A. Case / Strategist: the outage tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're mid-way through a weekend event on one of our titles and the event server goes down. Players can't claim rewards. Walk me through your first 30 minutes." | CASE | [grounded] | Clarify first: which title, all players or some, are rewards lost or just delayed, does engineering already know. Then the objective: restore the event and keep players' trust. Sequence: get an incident owner and the engineering lead on one call. Ask QA what changed in the last release. Have community post a holding message saying only what's known, with no ETA you don't have. Decide what happens to the event clock, whether you pause it, extend it or compensate, and say why, with players first. Start a timeline for the review. Saltmarsh's own value names fit here, "Players Before Plans" and "Ship the Patch Not the Promise", so use them where they apply. The question makes no claim about your past, so neither does the answer | This is the documented core of the Outage Hour, so it will be asked in some form. CASE because it scores structure on a live problem from the role |
| A2 | "Engineering says the fix is ready, but QA hasn't finished regression. Community wants to post 'fixed within the hour'. What do you do?" | CASE, JD | [grounded] | Separate the two decisions. Release: weigh the risk of shipping without the full pass against keeping the event broken, and say who makes that call. Communication: the post describes what's built and verified, not what's hoped, so "a fix is in testing" beats a deadline you don't control. Then say what triggers the next update to players | A likely follow-up that tests the JD's QA line and the value "Ship the Patch Not the Promise" together. It's also the theme of his talk. JD content, CASE delivery |
| A3 | "The event's over. How do you run the post-event review, and which KPIs go in it?" | CASE, JD | [generic] | Structure: the timeline of the incident, the impact on players, how the event performed against plan, which retention measures you'd want for the players affected and why, what went well, and actions with owners and dates. Close with what changes in the release checklist. That's "Leave the Build Greener" in practice. Frame all of it as how you would run it. If he asks whether you've run one, that's D1's ground | Scores the JD's "own the post-event review and the KPIs it reports" (F3) as a plan rather than a record, which is where F3's evidence leaves you. `[generic]` because the KPI list is a pattern for the role, not Saltmarsh's actual review |
| A4 | "From February both of our titles share one events calendar. How would you plan a shared calendar for two different games?" | CO, CASE | [grounded] | Say what you know and where you read it: the September 2026 Project Larkspur announcement. Then clarify. How much do the two games' audiences overlap? What's each title's natural cadence? Which teams are shared? Structure: one calendar of record, big moments kept from colliding across titles, design, art, engineering and community capacity planned across both, and a QA checkpoint per release. Ask what's changed since the announcement rather than assuming | The one strategy question research supports. Most candidates won't have read the announcement. CO first, because it scores homework, delivered as a case |
| A5 | "The fix is live. Give me the patch note, out loud, right now." | CASE, JD | [grounded] | Say what happened, what's fixed, what players get, and anything not yet fixed. Short, plain, nothing promised beyond what shipped. Then stop | Tests "clear written communication" (F8) live, and it's the literal subject of his GDC talk. JD content, CASE delivery |

### B. Values / Behavioral: Saltmarsh's three values

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Leave the Build Greener: tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats are the ones your sentence states: you wrote the release checklist, and QA still uses it. Tell them in your own words. Answer slot: the value says every release leaves "the checklist better than it found" it, so expect a probe on upkeep. If you've revised the checklist after releases, say what changed and why. If you haven't, or someone else maintains it, say so plainly and stay with having written it | The closest match in this pack between a value and one of your sentences. VAL because it scores the published value by name |
| B2 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. Pick a time during the two years you ran the weekly content-drop calendar when something players did or said didn't match what was planned. It needs a planned drop, the player signal, and what changed, with which part was your call. If no such time comes to mind, say so plainly, then talk about running the weekly calendar itself, or how you'd handle that disagreement here | F6's calendar is the nearest material, but your sentence carries no disagreement, so this is a scaffold, not a story. VAL because the question quotes the value's own wording |
| B3 | "Ship the Patch Not the Promise: when have you had to say something wasn't ready?" | VAL | [grounded] | Selection scaffold. Pick a time you told someone, a lead, the team or players, that something wasn't ready to announce or ship. It needs what was expected, what you said, and what happened next. If no such time comes to mind, say so plainly, then say how you'd handle it, using the A2 reasoning | None of your sentences carries this story, so the guidance claims nothing about your past. The value is also the theme of his talk, so it's likely |
| B4 | "Tell me about a time the numbers told you something the plan didn't." | VAL, EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7, at its scope: you presented the monthly retention numbers to the studio head. Answer slot: if a month's numbers led to a change in the content plan, say what changed and what part of it was yours. If no change came from them, or the decision wasn't yours, say so plainly and describe what you presented | Players Before Plans meets the JD's retention line (F7). VAL first because the value frames it. EXP because it tests what was actually yours |

### C. Skeptic: scope and gaps

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role runs the events calendar for two titles and coordinates design, art, engineering and community on every update. You ran the weekly calendar for one title. Why are you ready for this?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **The highest-ROI rehearsal in this pack.** Hold only on what your sentence carries: "For the last two years I ran the weekly content-drop calendar for our main title." Name the limit before he does. That's one title's weekly drops, and this role is two titles' events. Answer slot: if running drops meant working with design, art, engineering or community, name which ones and what you did with them. If it didn't, say so plainly. Then give a first-month plan: learn each title's cadence, meet each discipline's lead, and run one event alongside someone before owning one. Follow-up 1, "So, one title?": "Yes. One title, weekly, for two years." Follow-up 2, pushing on coordination: return to the answer slot's true branch, and never add a team you didn't work with. The honest branch is a limit, not a confession | F1 and F2 are where the JD pushes hardest against your material, and Larkspur makes two titles central to the job, so this objection will come in some form. JD because it scores the stated requirements directly |
| C2 | "Have you led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment from your own words: "I haven't led a team." Then point to what the JD asks for, which is coordination, and follow F2's answer slot. If you worked with other teams on drops, say which and how. If you didn't, say so. Don't redefine coordination as leadership | A predictable Skeptic check on an associate title. Your sentence gives a sourced, honest answer. JD because the role coordinates four disciplines |
| C3 | "From February, both games move to a season pass. What's your experience with in-app purchases?" | CO, JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: how you'd learn the season-pass economy before your first event, who you'd go to on design and monetisation, and which player-side signals you'd watch. Don't reach for anything to make the gap feel smaller | Larkspur's move to a season pass puts monetisation in the job from February, and your sentence says it's new to you. CO because it rests on the announcement. JD because it shapes the calendar work |
| C4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose a real one. In-app purchases is the one your own words support: "I haven't worked on a game with in-app purchases." Then the C3 plan. Don't name a fake weakness, and don't pick one your material doesn't support | A standard Skeptic stem. Rehearsing it means you pick on purpose, not under pressure |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP, JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start from your sentence: you presented the monthly retention numbers to the studio head. Answer slot: if you know which retention measures they were and how they were counted, say so in your own words, and name the assumption behind them you'd defend least. If someone else produced them and you don't know how they were counted, say exactly that. "I presented them; analytics built them" is a complete honest answer if it's true | F7 and F3 make this the likeliest metric probe. The JD's "comfortable with player-retention metrics" raises it. EXP because it tests what was yours |
| D2 | "Talk me through the release checklist you wrote. What's on it, and what does it catch?" | EXP, JD | [grounded] "Wrote the release checklist our QA team still uses." | Beats from your sentence: you wrote it, and QA still uses it. Answer slot: name what's on it, in your own words. If you can recall a release where an item on it caught something, describe it. If you can't, say so plainly and describe what it covers | F4 is your strongest row, and a former QA lead will test it hardest. Go in knowing your own checklist |
| D3 | "How did you run the weekly content-drop calendar? What did a week look like?" | EXP, JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "4 years as an associate producer at a puzzle-game studio." | Beats from your sentences: weekly, your main title, the last two years. Walk through a week in your own words. Answer slot: the JD's "plan and run" raises who decided each drop's contents. If that was you, say how. If it wasn't, say so plainly. The JD's "3+ years producing live-service games" raises the earlier two years. If the game was live-service throughout, say what you worked on then. If the live work was the last two years, say so | Covers F1, F5 and F6 in one walkthrough. EXP because it tests what was actually yours, JD because it maps to three requirements |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's run live events on a monetised game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head."; "Never led a team, and never worked on a game with in-app purchases." | Pause, then three beats in your own words: two years running the weekly content-drop calendar, the release checklist QA still uses, and the monthly retention numbers you presented to the studio head. Concede first, plainly, so it doesn't land as a gotcha: "I haven't worked on a game with in-app purchases." Don't claim you'd beat that candidate. Say what you bring and stop | A time-boxed version of C1 and C3 together. JD because it's a fit comparison |
| E2 | "That checklist QA still uses. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it." Answer slot: if others added to it or reviewed it, say who and what, in your own words. If not, say so plainly. Hold through two follow-ups, and concede only what's actually true about others' contributions | A standard attribution probe on your strongest line, likely from a former QA lead. EXP because it tests what was yours |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc built from your four sentences, in this order: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the last two years, the release checklist QA still uses, and the monthly retention numbers. End with why this role, in your own words | The opener sets the frame for the rest of the hour. EXP because every beat is checkable |
| G2 | "Why live ops, and why Saltmarsh?" | CO | [grounded] | Your reasons, in your own words. If the Larkspur announcement, the values page or his talk drew you, name which one and why. Don't recite a page | Casual in tone but scored, and research makes a specific answer possible. CO because it tests homework |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A4, C1, D3 |
| Coordinate design, art, engineering and community (F2) | A1, C1, C2 |
| Own the post-event review and its KPIs (F3) | A3, D1 |
| Manage the release checklist with QA (F4) | A2, B1, D2, E2 |
| 3+ years producing live-service games or apps (F5) | D3 |
| Experience running a content calendar (F6) | D3, B2 |
| Comfortable with player-retention metrics (F7) | D1, B4 |
| Clear written communication (F8) | A5 |

---

## Values cheat sheet

The values are from Saltmarsh's values page, fetched. The careers page names a values conversation as part of this hour.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the event calendar and player behaviour conflict, players win | Selection scaffold (B2). Draw on F6, "I ran the weekly content-drop calendar for our main title for the last two years.", and pick a time a planned drop met a player signal it didn't expect. If no such time comes to mind, say so plainly, then give the calendar itself, or how you'd handle it |
| Ship the Patch Not the Promise | Announce only what's actually built | Selection scaffold (B3). None of your sentences carries this. Pick a time you said something wasn't ready. If none comes to mind, say so plainly and use the A2 reasoning |
| Leave the Build Greener | Every release improves the code and the checklist | F4: "Wrote the release checklist our QA team still uses." (B1) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How does Saltmarsh measure that today?" | Tied to his own public work. It shows you researched him, and it invites him to talk about his core theme |
| R2 | "Coming from QA, what's the one release-checklist step you'd never let a producer skip?" | Tied to his career path, and it connects to your checklist without you having to sell it |
| R3 | "With Larkspur moving to one live-ops group, how will this role divide its time between Tidepool Tactics and Lantern Row?" | Shows you read the announcement and are thinking about the job as it'll exist in February |
| R4 | "What does the post-event review look like today, and who reads it?" | The JD names it as yours to own. Asking shows you're taking ownership seriously |
| R5 | "What would make February's first shared calendar a success in your eyes?" | Gets his success criteria, which you can echo back in the close |
| R6 | "When did Players Before Plans last change a plan here?" | Shows you take the values as working rules, not slogans |

---

## Prohibited claims

This pack won't coach the claims below. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated | "I haven't led a team." |
| Has worked on a monetised or in-app-purchase game | A negative you stated | "I haven't worked on a game with in-app purchases." |
| Has run live-events calendars for two or more titles | Inflated form of F1 | F1's sentence at its own scope. The pack's observation, not words for you: your material covers one title's weekly content drops. The C1 and D3 answer slots stay inside that calendar |
| Owned post-event reviews and their KPIs | Inflated form of F3 | F3's sentence at its own scope: you presented the monthly retention numbers to the studio head. The D1 answer slot asks only about those numbers |
| Analysed or built the retention numbers | Inflated form of F7 | F7's sentence at its own scope. D1's slot allows "someone else produced them" |
| Manages the release checklist with QA on an ongoing basis | Inflated form of F4 | F4's sentence at its own scope: you wrote it, and QA still uses it. B1's slot asks only whether you've revised it |

---

## Sources

**Provided:** the job description and your background, both pasted in your message.

**Searches and fetches:**

| Call | Query or URL | What came back |
|---|---|---|
| Search | Saltmarsh Games values | https://saltmarshgames.com/values |
| Search | Saltmarsh Games interview process producer | https://saltmarshgames.com/careers/interviewing |
| Search | Saltmarsh Games mobile studio news 2026 | https://saltmarshgames.com/news/project-larkspur (search snippet only; page not fetched) |
| Search | Tobias Wrenfield Saltmarsh Games Head of Live Operations | https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; page not fetched) |
| Fetch | https://saltmarshgames.com/values | The three values and their one-line definitions |
| Fetch | https://saltmarshgames.com/careers/interviewing | The Outage Hour format |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and bank B, three values by name |
| 2. Saltmarsh Games interview process | yes | Established the loop: one 60-minute hiring-manager session with a tabletop and a values conversation. That set the persona weights and the A bank |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur (September 2026), from the search snippet only. It drives A4, C3, R3 and G2 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read, R1, R2, and the patch-note emphasis in A2 and A5, from the search snippet only |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

No dossier was used.

---

## Upgrade menu

- **How many hours you have before Friday** → a prioritised prep schedule sized to that time
- **Your answers to the answer slots** (which teams you worked with on drops, who produced the retention numbers, whether you've revised the checklist, what the earlier two years involved) → F2, F3, F5 and F7, plus C1, D1, D3 and B1, move from answer slots to stories built on your own words
- **The release checklist itself, with anything confidential removed** → the one artifact that would let F4 and F8 move from medium toward high confidence, and it would sharpen D2
- **A deeper research pass**, up to 6 more searches and 2 more fetches, several more minutes → fetch the full Larkspur announcement and Tobias's talk page, so A4, C3 and R1 can quote them directly, and add a grounding brief on Saltmarsh's two titles
- **Any note from the recruiter** → confirms the Outage Hour format applies to your interview and adds any stated focus areas
- **Your CV** → more sentences to draw on, so selection scaffolds like B2 and B3 can become stories built on your own words
- **A tuesday-dossier.md from an earlier fit assessment** → verified evidence and an objection list derived from evidence rather than inferred. This pack is complete without one
