Still prepping — I've read the interview-prep playbook and its rules. Next I'll check what's publicly findable about Atlas Freight, then build your pack.
I've built your prep pack: atlas-freight_operations-manager_interview_pack.md. You didn't say who you're meeting, so it assumes an unknown round and gives every interviewer style equal weight. My three web searches about Atlas Freight were blocked at the permission prompt, so nothing in the pack comes from research on the company.

**What matters most for next week:**
- **The question to rehearse most is A1:** "You're over three supervisors today. This role leads twelve across four sites. What makes you ready?" Some version of it is almost certain. Answer from what you actually did: three supervisors and the surge plan two years running. Then say how you'd run twelve as a plan for this job, not as something you've already done.
- **Power BI (A2):** you've never used it, so say that plainly and come with a specific plan to learn it. Owning the gap works better than skirting it.
- **The 40% mis-pick cut (C1, C2, D2):** expect to be asked how it was counted and which part was yours. Don't stretch it into a claim about on-time performance or cost unless you measured that.
- **"5+ years leadership required" (E3):** this line is probably checked literally. Know exactly how many of your 7 years were spent leading people.

The pack has 22 practice questions with answer notes, 6 questions for you to ask them, and a list of claims it won't coach you to make.

If you want a live practice run, I can play the skeptical interviewer on A1.
I can also save a tuesday-dossier.md that records the gaps this prep found, so you can bring them to later sessions.
If you'd like the pack as a Word document, I can convert it.

Who are you meeting: your future manager, HR, a panel, or someone from the sites? And did the recruiter mention anything to prepare, like a presentation or a case? The answer changes the weighting of every question bank.

Do you want me to rerun the company research if you allow web search (up to 6 searches and 2 page reads)? I can also go deeper: up to 6 more searches and 2 more page reads, which takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack — Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not known — round type and relationship not given
**Built on:** the JD lines you pasted and the background in your message. No interviewer, no recruiter guidance, no company research (the searches were blocked; see Sources).

---

## How to use this pack

Two axes. **Personas** are *how* a question gets asked (a friendly chat, a time-boxed challenge, a quiet probe). **Types** are *what* is being scored:

| Tag | What it scores |
|---|---|
| VAL | Behaviour and values: past behaviour that shows how you work |
| EXP | Deep-dive on your experience: whether what you said holds up, and what was actually yours |
| JD | The listed job: can you do what the posting asks, including where you have gaps |
| CO | Company knowledge: homework on Atlas Freight itself |
| CASE | Live problem: structure and reasoning on a scenario from the role |

Every row has a **Provenance** label: `[grounded]` = traceable to your message or the JD; `[inferred]` = derived, with the derivation named; `[generic]` = a pattern for this kind of role, no claim about you or Atlas.

An **answer slot** is a place where the pack does not know the fact and will not guess. It gives you two honest branches: if you did it, say how in your own words; if you didn't, say so plainly.

Guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

Each evidence quote is a sentence from your message, exactly as you wrote it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material shows warehouse and distribution ops and one improvement you made, not terminal operations or a four-site scope, and the words stay there: "Seven years in warehouse and distribution ops; I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's "terminal operations" makes a probe on terminal work likely. If any of your distribution work was terminal work, say which and what you did, in your own words; if none was, say so plainly and stay with the warehouse and distribution work you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD (on-time half) | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The surge plan touches on-time performance without showing whether it was measured against it. Answer slot: if on-time was a measure for the surge plan or your shift, say how it was measured and what happened to it, in your own words; if it was not, say so plainly and say how you would approach on-time here |
| F3 | "drive on-time performance and cost-per-shipment down" — JD (cost half) | none given | none | [grounded] | discovery | Your material says nothing about cost. Answer slot: if you have been responsible for any cost measure, say which and what you did with it, in your own words; if you have not, say so plainly and say how you would learn what drives cost per shipment here |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors, not twelve, and the words stay there: "I'm a senior shift manager over three supervisors." The step from three to twelve is said as a plan for this role, never as a past |
| F5 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel, never used Power BI" — your message | low | [inferred] | discovery | "Solid Excel" touches reporting without showing whether you build reports. Answer slot: if you build reports in Excel, say which ones and who uses them, in your own words; if you don't, say so plainly and say what you do use Excel for |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI half) | "solid Excel, never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years in ops does not say how many of them were in leadership roles. Answer slot: say how many of those years you led people, and in which roles, in your own words; if it is fewer than five, say so plainly and stay with what you led. A "required" years line is likely read literally, so it is better said by you than found by them |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe. Lead with it in its own terms: "I'm green belt certified." Answer slot: the JD's Lean/Six Sigma line makes a project probe likely. If you have applied the methods to a piece of work, say which and what you did, in your own words; if you have not, say so plainly and stay with the certification |

---

## Persona table

No loop source establishes this interview: the round, the interviewer and Atlas's process are all unknown, and the company search could not run. So the weights below fall back to the **Generic archetype** (screen → hiring manager → panel), which means **flat weights**. This is noticeably weaker than a pack keyed to a known interviewer: if you learn who you are meeting, the weights change.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the scale step (F4), the Power BI gap (F6) and terminal vs warehouse (F1) | Flat prior, raised slightly: the fit snapshot's biggest gaps feed this persona, and the highest-ROI question sits here. 4 questions | Rehearse A1 until it is boring; hold only on what your quotes carry; give a plan for the gap, never a past |
| Case / Strategist (B) | Live problems on the JD's own levers: on-time, cost per shipment, running 12 supervisors | Flat prior; a hiring manager for this role would likely test these, but the round is unknown. 3 questions | Clarify → objective → segment → approach → metrics → risks; think aloud |
| Data-Driven Prober (C) | Picks up the 40% and asks how it was counted | Flat prior; your one headline number is a magnet for this persona. 3 questions | Know what you can and cannot say about how the 40% was counted; name the weakest assumption you know of first |
| Pressure (D) | Time-boxed "why you" and "how much was you" | Flat prior. 3 questions | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Conversational (E) | "Walk me through the journey"; casual questions about Lean | Flat prior; common as an opener in most rounds, and still scored. 3 questions | A rehearsed 90-second arc; treat casual questions on JD topics as scored |
| Values / Behavioral (G) | "Tell me about a time…" prompts | Flat prior; no published Atlas values were found, so these are themed by the JD and standard prompts. 3 questions | Pick real stories; "we" for context, "I" for what was yours |
| Peer (H) | Someone from operations or a neighbouring team asking what you would need and give | Flat prior. 3 questions | Reciprocity: what you bring them, not just what you need |

Question IDs skip F so they never collide with fit-snapshot rows.

---

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're over three supervisors today. This role leads twelve across four sites. What makes you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | **The highest-ROI rehearsal in this pack.** Hold only on what the quotes carry: "Today I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Name the scale step yourself before they push: twelve is a step up from the three you lead today. Answer slot: if any decisions in the surge plan were yours to make, say which and how you decided, in your own words; if the plan was set for you, say so plainly and describe how you ran it. Then the step to twelve as a plan, not a past: how you would get to know each supervisor and each site's numbers in the first weeks. Hold through two follow-ups by returning to what you ran, never by adding to it | F4 and F1 are where this role presses hardest on your background, so this objection arrives in some form whoever you meet. JD because it scores the listed team and site scope |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Answer it straight: "I've never used Power BI." Then the plan, said as a plan: what you would learn first and by when. If you start learning before the interview, you may say what you have actually done so far, and only that. Don't pick a fake weakness; F6 is the real one and they can see it | F6 is a named JD tool you have stated you lack; naming it first turns a gotcha into candour. JD because it scores a listed requirement |
| A3 | "This is terminal operations. Your background is warehouse and distribution. What's different, and what carries over?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote: seven years in warehouse and distribution ops. Answer slot: if any of your distribution work was terminal work, say which and what you did, in your own words; if none was, say so plainly. For "what's different", give your own understanding; where you are unsure, say what you would want to learn in your first weeks rather than guessing | F1 is a transferability gap, and the JD names terminal operations, so an interviewer is likely to test whether you know the difference. JD because it scores the headline responsibility |
| A4 | "Why leave a senior shift manager role, and why Atlas Freight?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Your real reason, in your words, then the JD lines you actually want (the four-site scope, the reporting, the supervisor team). For "why Atlas", use only what you have learned about them yourself; this pack has no company research to give you. If you know little, say what drew you to the posting and what you want to learn | Motivation consistency is the Skeptic's standing probe; JD because the honest answer ties to the posting's own scope |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance across the four sites has slipped. Diagnose it." | CASE, JD | [generic] | Clarify first: how on-time is defined and measured here, which sites, since when. Then segment: by site, shift, customer and cause. Form two or three hypotheses, name the data you would pull to test each, separate quick containment from root cause, and say which metric you would watch weekly. The question needs no claim about your past, so the guidance makes none | The JD's on-time line (F2's requirement) as a live problem. CASE delivery on JD content; `[generic]` because it is a pattern, not a fact about Atlas |
| B2 | "How would you take cost-per-shipment down without hurting on-time?" | CASE, JD | [generic] | Clarify what cost per shipment includes here. Break it into its parts, find the biggest controllable one, set an on-time guardrail before cutting anything, pilot at one site, measure both numbers, then roll out. Name the trade-off out loud | Tests F3's requirement as reasoning, since your material carries no cost evidence. The tension between the two JD metrics is the point of the question |
| B3 | "Your first 90 days with twelve supervisors and four sites — what's the plan?" | CASE, JD | [generic] | Structure by phase: listen and learn (each supervisor, each site, the current numbers), then pick one or two problems with the team, then set the reporting rhythm. Say what you would measure at 90 days. Keep it as a plan; no claims about the past | Gives F4 and F1 a forward-looking answer; CASE because it is scored on structure |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-picks 40%. Walk me through how that was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats the quote states: the mis-pick rate, 40%, the pick-path redesign. Then, in your own words: how the 40% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of the work was yours. Name the weakest assumption before they do. If you don't know how it was counted, say so plainly; that is an honest answer. The pack does not supply a baseline or a method for you | Your one headline number; probers go straight to it. EXP because it tests whether the claim survives scrutiny |
| C2 | "Did that pick-path change move anything besides accuracy?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold to the quote: the mis-pick rate, 40%. Answer slot: if anything else about the change was measured, say what was measured and how, in your own words; if nothing else was, say so plainly and stay with the mis-pick rate | The JD's on-time and cost lines make this follow-up likely, and it is where the 40% is most tempting to stretch (see Prohibited claims). EXP because it tests attribution |
| C3 | "What reports do you build today in Excel, and what decisions do they drive?" | JD, EXP | [inferred] "solid Excel, never used Power BI" | Answer slot: if you build reports, say which ones, who reads them and what they decided from them, in your own words; if you don't, say so plainly and say what you do use Excel for. Never describe a report you have not built | F5's thin bridge, rehearsed before the probe arrives. The question's premise is the JD's ("build reporting"), and the guidance does not adopt it |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who's already run multiple terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause. Restate. Then three facts in the quotes' own words: seven years in warehouse and distribution ops, the 40% mis-pick cut, the surge plan two years running, plus the green belt. Concede the real point without folding: if the other candidate has run terminals, that is a genuine advantage. Then say what you would bring. Hold through two follow-ups | Tests composure on F1's gap. JD because the comparison is about the listed scope |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede. Answer slot: say which part of the redesign was yours and who else was involved, in your own words; if it was a team effort, say so and name your part. Don't fold on what was yours just to sound modest, and don't claim what wasn't | The stress version of C1; it rehearses precise attribution under pressure |
| D3 | "One of your twelve supervisors is struggling and their site is behind. You have one week. Go." | CASE | [generic] | Time-box yourself: what you would look at on day one (the site's numbers, the supervisor's view), the conversation you would have, the one support you would put in, and how you would know by day seven whether it worked. Short and structured beats complete | Tests F4's requirement live, under time pressure; CASE because it asks about no past |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc using only these facts, in order: seven years in warehouse and distribution ops; now a senior shift manager over three supervisors; cut the mis-pick rate 40% by redesigning the pick path; ran the site's peak-season surge plan two years running; green belt certified. End with why this role, in your words. Rehearse it out loud until it fits 90 seconds | The likeliest opener in any round; the arc draws on F1, F4 and F8 |
| E2 | "What are you actually doing with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say it in its own terms: "I'm green belt certified." Answer slot: if you have applied the methods to a piece of work, say which and what you did, in your own words; if you have not, say so plainly and say where you would use them in this role | F8's "a plus" line, asked casually, is still scored. JD because it covers a listed requirement |
| E3 | "How long have you been leading people, and in what roles?" | JD, EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: say how many of your seven years you have led people, and in which roles, in your own words; if it is fewer than five, say so plainly and stay with what you have led. Today's role is the anchor: senior shift manager over three supervisors | F7's "required" years line, asked in a friendly register; JD because it checks the listed minimum |

### G — Values / Behavioral

No published Atlas values were found, so these use standard behavioural prompts and JD themes rather than a values framework.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they did not want to hear. It needs a clear stake, what you said, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle it | A standard behavioural prompt; tests candour, which matters in a role reporting on performance numbers |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a customer need pulled against a number you were measured on. Say what you chose, why, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle it | Logistics roles trade service against cost (F2 and F3's requirements); this tests how you make that call |
| G3 | "Tell me about a time you had to deal with a supervisor's performance problem." | VAL, JD | [generic] | Pick a real case with one of your supervisors: what you noticed, the conversation, what you did, and the outcome. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then say how you would handle it | The JD's "lead a team of 12 supervisors" (F4's requirement) raises this; VAL delivery on JD content |

### H — Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Your work and mine overlap. Where's the seam, and what happens when we disagree?" | CASE | [generic] | You don't know Atlas's seams yet, so don't pretend to. Propose principles instead: agree who owns which decision, share the numbers early, escalate together rather than around each other | Tests partnership fit without needing facts you don't have |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time work you did depended on another team. Say what was yours and what was theirs. If no such time comes to mind, say so plainly, then say how you would handle it | Standard peer probe on credit-sharing |
| H3 | "What would you need from peers like me in your first month, and what would you give back?" | CASE | [generic] | Two halves, both concrete: what you need (their view of the sites, the numbers, the known problems) and what you offer in return (a regular check-in, sharing what you learn). Reciprocity is the point | Peers price what a new hire costs them; this lets you show you add, not just take |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, B1, B3, D1 |
| Drive on-time performance up | B1, B2, C2 |
| Drive cost-per-shipment down | B2, C2 |
| Lead a team of 12 supervisors | A1, B3, D3, G3 |
| Build reporting in Excel | C3 |
| Build reporting in Power BI | A2 |
| 5+ years operations leadership required | E3 |
| Lean/Six Sigma a plus | E2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured here, and which site is furthest from where you want it?" | Shows you think in the role's own metric, and tells you where the real problem is |
| R2 | "What goes into cost per shipment in your numbers?" | Signals you won't cut a number before you understand it; also tells you what you'd be judged on |
| R3 | "What reporting exists today, and how much of it is already in Power BI?" | Shows you know the reporting is part of the job, and tells you how big your Power BI ramp (F6) really is |
| R4 | "How are the twelve supervisors spread across the four sites, and how long have they been in their roles?" | Shows you are already thinking about the team; the answer shapes your first 90 days |
| R5 | "What would make someone successful in this role at 90 days?" | Gets the real success bar on the table, which you can then answer to |
| R6 | "What's the biggest operational change coming in the next year?" | Shows altitude, and tells you what the role is really being hired for |

---

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the question banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Has owned operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material shows warehouse and distribution ops and the site's surge plan, not a multi-site scope. A1's slot stays inside the surge plan |
| Has led a team of twelve, or "a large supervisor team" | Inflated form of F4 | F4's quote: "currently a senior shift manager over 3 supervisors." The step to twelve is a plan, never a past |
| Seven years of operations leadership | Inflated form of F7 | F7's quote: "7 years in warehouse and distribution ops." E3's slot asks only how many of those years you led people |
| The pick-path redesign improved on-time performance or cut cost per shipment | Inflated form of F1's mis-pick quote | The quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path." C2 holds to the mis-pick rate |
| Power BI experience, or "familiar with Power BI" | Negative you stated, F6 | The plain acknowledgment: "I've never used Power BI." No slot |
| Black belt, or Lean/Six Sigma expert | Inflated form of F8 | F8's quote: "green belt certified." E2's slot stays inside the certification |

---

## Sources

**Provided:** your message (the JD lines and your background). No CV file, no dossier.

**Searches sent:**

- `"Atlas Freight" logistics company values mission` — refused (web search permission not granted)
- `"Atlas Freight" interview process operations manager` — refused (web search permission not granted)
- `"Atlas Freight" news 2026 terminals expansion` — refused (web search permission not granted)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have themed the G bank with Atlas's own values, if it publishes any and they could be attributed to this company |
| 2. `Atlas Freight interview process` | unavailable | The search was refused. It would have set persona weights from a documented loop instead of the Generic fallback |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have added a CO question grounded in current company news and sharpened A4 and the reverse questions |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative Operations Manager JD | skipped | The JD lines you pasted fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Who you are meeting and their relationship to the role (manager, HR, panel, peer) → persona weights set from the real round instead of flat; banks reweighted
- The recruiter's prep note, if any (focus areas, a presentation or case to bring) → coverage of anything pre-declared, with its own build section
- Web search allowed → Atlas values, interview process and recent news, labelled and sourced; a grounded CO question; tailored reverse questions
- The interviewer's name → a read of their public professional background and a reverse question tied to their own path
- How much prep time you have → a prioritised prep schedule
- Your actual CV → more quoted evidence; rows F2, F3, F5 and F7 may move up from `discovery`
- Your answers to the answer slots in F1, F2, F3, F5, F7 and F8 → those rows and A1, A3, C3, E2 and E3 rebuilt on your own words
- A `tuesday-dossier.md` from an earlier underwriting pass, if you ever make one → verified evidence and a named objection for the highest-ROI rehearsal, instead of the one inferred here
