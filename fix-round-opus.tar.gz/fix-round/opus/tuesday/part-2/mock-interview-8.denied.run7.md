No dossier present. Reading the mock-interview files.
I've written your prep pack, Dara. It has one fit snapshot that all three rounds share, then a separate pack for each round on 21 November, based on the recruiter's email. Each round has its own questions to rehearse and its own questions for you to ask them. There are 26 practice questions in total.

- **The most important thing to practise is question B4, in Round 2.** The Head of Member Services will probably push on scope: you've handled one branch's complaints log and never worked in a contact centre, but this role runs complaints across every branch and the contact centre. The pack scripts the answer as:
  - say the gap first, in your own words;
  - point only to what you've actually done: the branch's complaints log, training new tellers on the escalation script, and the monthly complaints spreadsheet your regional manager uses;
  - finish with a 90-day plan, stated as a plan.
- **Three gaps from your message:** the contact centre, presenting above regional level, and coaching supervisors rather than tellers. The first two are said plainly in your own words, never covered over. For the third, you describe the teller training at its real scope.
- **Where your message doesn't say, the pack asks you to fill it in.** There are five of these:
  - whether your complaints fell under a regulator's rules;
  - what the spreadsheet tracks;
  - whether you built it in Excel;
  - any work with a digital team;
  - whether your teller training went beyond the escalation script itself.

  Each one has an honest answer whichever way it goes.
- **Round 3 has two extra sections:**
  - a plan for the 20-minute complaint case: a timeline, three positions to argue (each with something you should concede), and what to avoid;
  - a sheet that links each of the four values to either one of your real experiences or a guide to picking one.

I didn't run any web searches. The values text, the recruiter's email and the July strategy brief already covered everything a search would have found.

If you like, I can play the Head of Member Services and put B4 to you live, with follow-ups that react to what you say.
I can also save a tuesday-dossier.md recording the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-8-denied-f896eb08:
- Ashgrove-Credit-Union_member-experience-lead_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of interviews:** 21 November 2026, three rounds on the same day
**Mode:** Loop. One fit snapshot is shared by all three rounds, and each round has its own mini-pack. The rounds come from the recruiter's email:

| Round | Length | Who | What it holds |
|---|---|---|---|
| 1 | 30 min | Recruiter | Screen |
| 2 | 45 min | Head of Member Services, who would be your manager | "mostly behavioural" |
| 3 | 60 min | Panel of two branch managers | Includes "a 20-minute case on a complaint escalation". This is the values round, scored against the four values |

Interviewer names haven't been assigned yet, so this pack has no interviewer read.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what's being scored. Each question has both.
- **Question IDs** use one letter per persona: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Data-Driven Prober, G Peer Evaluator, H Pressure. The letter F is kept for fit-snapshot rows (F1 to F9), so a question ID and a fit row are never confused.
- **The answer guidance is scaffolding, not a script.** Say it in your own words. Where a cell says **answer slot**, the pack doesn't know the answer. Fill it with what actually happened. If nothing happened, say so plainly. Both answers are honest.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's four published values |
| EXP | Whether your stated experience holds up when probed, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | How you structure a live problem from the role |

**Highest-ROI prep in this pack: B4 in Round 2.** It is the scope objection: one branch's complaints log against a role that runs across every branch and the contact centre. It will come up in some form, probably in more than one round, and it gets the deepest rehearsal below.

---

## Fit snapshot (shared by all rounds)

Your evidence is quoted from your message exactly. Nothing else in this pack about your past goes beyond these sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in years. With no CV or review behind it yet, expect a probe. State it in the sentence's own terms: six years in retail banking, the last three as a branch supervisor. Let the interviewer map that onto "customer operations". Don't relabel your history in the JD's words |
| F2 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material covers one branch's log, not a process across branches, and your words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on what handling the log involved likely. If any part of how the branch's complaints were handled was yours to decide, say which part and how, in your own words. If none was, say so plainly and stay with the log you handled |
| F3 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You have said this gap yourself, and wording can't close it. Words: "I haven't worked in a contact centre." Then how you would learn the contact centre's side, said as a plan and never as something in your past. Don't add anything to make the gap feel smaller |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your sentence says formal complaints. It doesn't say whether they fell under a regulator's rules. Answer slot: if those complaints came under a regulator's rules, say which rules and what they required of you, in your own words. If they didn't, or you don't know, say so plainly and stay with the log you handled |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence reaches monthly complaints work. It doesn't say what the spreadsheet tracks. Answer slot: the JD's "volumes and resolution times" makes a probe on what it tracks likely. If it tracked either, say how each was counted, in your own words. If it tracked neither, say so plainly and say what it does track |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not Excel. Answer slot: the JD's Excel line makes a question about the tool likely. If you built it in Excel, say so and what you did in it, in your own words. If you built it in something else, name that plainly and say how you would get up to speed |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material covers training new tellers, not coaching supervisors, and your words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you trained likely. If the training went beyond taking tellers through the script, say how, in your own words. If it didn't, say so plainly and stay with the training |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a time you worked with the people who build digital channels on something members do for themselves. Answer slot: the JD names this work. If you've worked with a digital team or on a self-service channel, say what you did and which part was yours. If you haven't, say so plainly and say how you would start |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You have said this gap yourself. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan. In Round 2 your answers to a senior leader are themselves a live demonstration, so make them structured and short. That is delivery, not a claim |

---

## Grounding brief (shared)

Use Ashgrove's own words. They say **member**, not customer, and **hubs** for the consolidated branches.

| Item | What your documents say | Provenance | How to use it |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] strategy brief, July 2026, as you relayed it | D2, A5. Complaints show which self-service journeys are failing members, which is where this role meets the JD's "self-service journeys" line |
| Branch consolidation | Eight branches become five hubs over 2027 | [grounded] strategy brief | G1, R2 and R3 reverse questions. Members whose branch closes are a likely source of complaints. Treat that as your reasoning and offer it as a question, not as a fact about Ashgrove's data |
| New product | A small-business lending product launches in Q1 2027 | [grounded] strategy brief | Reverse question R2-5. A new product will bring complaint types the process hasn't handled before |
| Competition | The main competitive pressure is app-only banks | [grounded] strategy brief | A5, D2. The values ("Neighbours, Not Numbers", "Plain Words") are what an app-only bank can't easily copy. That is a reading, so say it as your view |
| Values | Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | [grounded] values text you copied from ashgrovecu.org/about/values on 12 November 2026 | Round 3 is scored against these four. Learn them word for word |

The brief is about four months old, so the material in hand is current enough. There are no stale framings to flag.

---

# Round 1: Recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers: your journey, why Ashgrove | High. Recruiter screens run in a friendly register, and the risk is treating them as unscored [generic] | A 90-second arc built only from your three quoted sentences (A1). Treat every casual question as scored |
| Skeptic (light) | Knockout checks: years, contact centre, Excel | Medium. Recruiters screen against the JD's listed requirements [generic], and F3 is a requirement you have said you don't meet | Plain acknowledgment first, then one plan sentence. Don't bridge |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, three beats, each one a sentence you gave: six years in retail banking, the last three as a branch supervisor. As supervisor, you handled the branch's formal complaints log and trained new tellers on the escalation script. You built the monthly complaints spreadsheet your regional manager uses. Then one line on why this role (A2). Add no titles, team sizes or dates you didn't give | Every later round builds on this frame, and F1, F2, F5 and F7 all start here. EXP because it sets what the recruiter believes is yours |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Answer slot: say in your own words what draws you. Tie it to something Ashgrove published, such as one of the four values or the move to hubs, and say why it matters to you. If your real reason is simpler, for example the role itself, say that plainly. Don't name a motive you don't hold | Motivation consistency gets checked across all three rounds, so settle it now. CO because a good answer uses Ashgrove's own published words |
| A3 | "What made you look beyond branch supervisor now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start from the sentence: six years in retail banking, the last three as a branch supervisor. Answer slot: give your reason for moving now in your own words. If the honest reason is that this role fits the complaints work you already do, say that. Don't criticise your current employer | Recruiters screen for why-now consistency. EXP because the answer rests on F1 |
| A4 | "How are you with Excel? The role reports monthly." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the sentence: you built the monthly complaints spreadsheet your regional manager uses. Answer slot (F6): if you built it in Excel, say so and what you did in it, in your own words. If you used something else, name it plainly and say how you'd get up to speed | This covers F6, a mid-list requirement that gets asked casually. JD because it checks a stated requirement |
| A5 | "What do you know about where we're heading?" | CO | [grounded] | Name two of the brief's moves: 40% of member service on digital channels by 2028, and eight branches becoming five hubs over 2027. Then say one thing you'd want to understand about how each changes where members complain. Ask it, don't assert it. Mention that you read the July brief | It shows you've done the homework early, and the recruiter passes that on. CO, grounded in the brief the recruiter sent you |
| A6 | "What does good member experience mean to you?" | VAL | [grounded] | Use their words, "we decide from the member's side of the counter", then say what that means to you in your own words. If you have an example, pick a time a decision went the member's way when the easier option went the other way. It needs a named member need and what you did. If no such time comes to mind, say so plainly, then say how you would handle it | This previews Members First, Always before the values round. VAL because it is scored against a published value |
| B1 | "The JD asks for 4+ years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the sentence's own terms: six years in retail banking, the last three as a branch supervisor. Stop there and let the recruiter map it. Don't call it "customer operations" experience yourself | F1 is a box the recruiter has to tick, and a clean answer ticks it. JD because it checks a listed requirement |
| B2 | "The role covers the contact centre too. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then one sentence of plan, said as a plan, such as how you would learn its complaints flow in your first weeks. Don't argue that a branch counter is basically the same | F3 is a stated gap, and saying it first in your own words takes the sting out of it in Round 2. JD because it is the JD's scope |

### Reverse questions, Round 1

| Question | Why it lands |
|---|---|
| "How is the 20-minute case in round three set up? Is it spoken or written, and do I get any material beforehand?" | It is a graded deliverable, and recruiters expect this question |
| "Is this a new role or a backfill?" | It tells you whether you'd be building the complaints process or inheriting one, which changes your Round 2 answers |
| "Where does the role sit relative to the contact centre? Does anyone there report to it?" | F3 is your gap. Knowing the reporting line tells you how hard B4 will press |
| "Is there anything about how the panel scores the four values that would help me prepare?" | A fair process question, and the answer may tell you what each value looks like to them |
| "What happens after 21 November, and when would I hear?" | Logistics, and it signals you're treating this seriously |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes, "mostly behavioural")

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scope gap: one branch against all branches plus the contact centre | Highest. A hiring manager is buying capability and reducing risk [generic], and F2, F3 and F9 are where this role's scope is widest compared with your material | Rehearse B4 until it's boring. Concede specifically, hold only what your sentences carry, give a 90-day plan |
| Values / Behavioral | "Tell me about a time…" stories | High. The recruiter said "mostly behavioural" [grounded], which raises this above the hiring-manager default | Story-mapped where your sentences carry a story. Elsewhere use the selection scaffolds, with their honest branches |
| Case / Strategist | First 90 days, the digital shift | Medium. The hiring-manager default is Case plus Skeptic [generic], lowered here by "mostly behavioural" | Clarify, then objective, approach, metrics, risks. Use Ashgrove's vocabulary |
| Data-Driven Prober | What your spreadsheet counts, and how resolution time is defined | Medium. Monthly reporting is in the JD, and F5 is your nearest evidence | Know what you can and can't say about how it was counted |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "This role owns complaints across every branch and the contact centre. You've handled a branch's complaints log and you haven't worked in a contact centre. Why are you ready for this?" | JD | [grounded] "I handled the branch's formal complaints log" "Never worked in a contact centre" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses." | **Highest-ROI rehearsal in the pack.** Concede first, and be specific: "I haven't worked in a contact centre, and my complaints work has been at one branch. I handled the branch's formal complaints log." Then hold, using only what your sentences carry: you trained new tellers on the escalation script, and you built the monthly complaints spreadsheet your regional manager uses. Then the plan, said as a plan: how you would learn the contact centre's side and get one view across sites in your first 90 days. Follow-up 1, "one branch isn't eight": return to the log you handled. Don't add branches. Follow-up 2, "what would you get wrong first?": name the contact centre honestly. Answer slot: if any part of how the branch's complaints were handled was yours to decide, say which part, in your own words. If none was, say so plainly and stay with the log | F2, F3 and F9 all press on this question, so it will come up in some form. JD because it scores the role's scope. Deepest rehearsal because the gap is where you'll be most tempted to say more than you did |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" | Pick a real weakness. If you've already covered the contact centre in B4, use F9: "I haven't presented to anyone above regional level." Then your plan for the first monthly report, said as a plan. Don't offer a fake weakness | F9 is a stated gap and your future manager will own your presentations upward. JD because it is a listed requirement |
| B6 | "Here's your first monthly complaints report to the executive team. What's on the first slide?" | CASE | [generic] | Structure: the headline (volumes and resolution times compared with last month), the one theme driving it, what's being fixed and who owns the fix, then what you need from them. One plain sentence each. Your answer is itself the demonstration of presenting to a senior leader, so keep it under two minutes. The question asks nothing about your past, so the guidance claims nothing | This tests F9 and F5 live rather than on record. CASE, with JD content |
| E1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats your sentence states: you built it, it's monthly, it covers complaints, and your regional manager uses it. Answer slot (F5): if it tracked volumes or resolution times, say how each was counted, in your own words. If it didn't, say so plainly and say what it does track. If you don't know how a figure in it was counted, say that | F5 is your closest evidence for the reporting line, so a prober will start here. EXP because it tests what's yours |
| E2 | "How would you count resolution time? When does the clock start and stop?" | CASE | [generic] | Structure: define the start (when the complaint is received or logged, whichever the rules require), the stop (the final response), which complaints are in or out, reopened cases, and the median compared with the average. Then name the assumption you'd defend least. Answer slot: if your spreadsheet already counts this, say how, in your own words. If it doesn't, say so and stay with the definition | The JD names resolution times. A prober wants definitions, not adjectives. CASE because it is a live problem |
| E3 | "Which complaint rules did you work to, and how did you keep within their deadlines?" | JD | [inferred] "I handled the branch's formal complaints log" | Answer slot (F4): if those complaints came under a regulator's rules, say which rules and what they required of you, in your own words. If they didn't, or you don't know the rule names, say so plainly and stay with the log you handled. Don't name a regulation or a deadline you didn't work to | The JD says "regulated complaints", and F4 is silent on it. JD because it is a listed requirement |
| C1 | "Tell me about a time an escalation didn't go the way it should have." | VAL | [grounded] "trained new tellers on our escalation script" | Pick a real escalation from your branch. It needs what the member needed, what you did, and what changed afterwards. Say "we" for the branch and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the escalation script you trained new tellers on, or how you would handle one | Escalations are in the JD, and "Own the Fix" makes the follow-through scorable. VAL first, EXP second |
| C2 | "Tell me about a time you helped someone get better at handling escalations." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7: the training, the new tellers, the escalation script. Tell it in your own words. Answer slot: if the training went beyond taking tellers through the script, say how. If it didn't, say so plainly and describe the training you did | F7 is the nearest evidence for coaching supervisors. JD because the requirement is stated, and the limit is named in F7 |
| D1 | "You'd own complaints across branches and the contact centre. In your first 90 days, how would you get one view of the process?" | CASE | [generic] | Clarify first: what's logged where today, and who closes what. Then the objective (one view of volumes, resolution times and themes), the approach (sit with each channel, map the steps, agree definitions), the metrics, and the risks (adding workload to branches during the move to hubs). Your plan, not your past | This tests F2 and F3 as a forward plan, which is where your gaps are honestly answerable. CASE with JD content |
| D2 | "We plan to move 40% of member service to digital channels by 2028. What does that mean for complaints, and how would you work with the digital team?" | CO | [grounded] | Structure: complaints as the signal for which self-service journeys are failing, Plain Words applied to the app, and the members who won't move to digital (Neighbours, Not Numbers). Then how you'd share themes with the digital team on a regular rhythm. Answer slot (F8): if you've worked with a digital team or on a self-service channel, say what you did. If you haven't, say so plainly and stay with the plan | This is the strategy question most candidates can't answer well, and F8 is a discovery gap. CO first, CASE second |

### Reverse questions, Round 2

| Question | Why it lands |
|---|---|
| "What do the monthly complaint numbers look like today, and which trend worries you most?" | It shows you think in the role's own measures, and you learn where the pain is |
| "What would you want this role to have done before the first branch moves into a hub?" | It ties you to the 2027 plan and shows you're thinking about timing |
| "How does complaints data reach the digital team's self-service work today?" | It's the JD's digital line, and the answer shows how much of that bridge already exists |
| "Six months in, what would make you say this hire was right?" | Your future manager tells you how you'll be judged |
| "When the small-business lending product launches in Q1 2027, who handles its complaints?" | It shows you've read the brief and are thinking about new complaint types early |

---

# Round 3: Panel of two branch managers (60 minutes, values round with a 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One question per value, scored | Highest. The recruiter said the panel "score against the four values" [grounded] | Values cheat sheet below. Every story needs a specific decision, not a slogan |
| Case / Strategist | The 20-minute complaint escalation case | Certain. The recruiter announced it [grounded] | The case build section below |
| Peer Evaluator | "How would you work with us?" Hubs, coaching their supervisors | Medium-high. Their branches are where this role coaches supervisors and where consolidation lands, which is a reading of the JD and the brief [inferred] | Reciprocity: what you bring their branches. Propose working principles, don't pretend to know their branches |
| Pressure (light) | Time-boxed "why you", "how much was you" | Low-medium. A panel may test composure [generic] | Pause, anchor on your sentences, hold through two follow-ups |

### Case build: "a 20-minute case on a complaint escalation"

**What you're building on.** The recruiter's words: the case is 20 minutes, it's about a complaint escalation, and the panel scores against the four values. Your facts: F2, "I handled the branch's formal complaints log", and F7, "trained new tellers on our escalation script". Use them only if the panel asks how you've done this before, and say no more than they say.

**A 20-minute shape** [generic]: about 2 minutes clarifying, 3 minutes on member contact and containment, 5 minutes on investigating and deciding, 3 minutes on the response, 4 minutes on root cause, prevention and reporting, and 3 minutes to sum up.

**Clarify first** (two or three questions before you structure anything): What does the member want? How long has the complaint been open, and which deadlines apply? Is the member in a vulnerable situation? Does it involve the app or a branch change? If you know the deadline your regime sets for a final response, use it. If you don't, say you'd confirm it against Ashgrove's complaints policy. Don't invent a figure.

| Thesis | Why it's defensible | Mandatory concession |
|---|---|---|
| T1. Fix the member's problem first, then the process | Members First, Always. The member shouldn't wait while the cause is found | Speed can't skip the documented investigation that regulated complaints require. Say you'd do both in parallel |
| T2. Every escalation becomes data: close the loop into the monthly report and into coaching the branch | Own the Fix. One named person keeps hold of it until the cause is gone, not only this case | It adds work for branches during the move to hubs, so keep the ask small and say what you'd take off them |
| T3. Write the final response so it never needs a second read | Plain Words: "if a member needs it explained twice, we wrote it wrong" | Some wording may be required by the rules or by compliance. Plain language works inside those limits, not around them |

**Differentiation.** The answer most candidates give is apologise, investigate, resolve, follow up. Do that, and add three things:
1. Clarify before you structure.
2. Say out loud who keeps hold of the problem until it's solved (Own the Fix).
3. End with the root cause and where it shows up in next month's report.

**The anti-pick.** Don't promise compensation before you have the facts. Don't blame the teller or the branch before you have the facts. Don't treat "pass it to compliance" as the end of the case. Branch managers will be listening for whether you protect their staff and the member together.

**Close.** The recruiter named no required close. End on the member's outcome in one plain sentence, then one line naming which value each step served. Keep that line short: listing all four values mechanically reads as box-ticking.

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide as if you're the member | Selection scaffold: a decision you made that favoured the member when the easier option went the other way. It needs the member's need, your decision, and what it cost. If no such time comes to mind, say so plainly, then say how you would decide such a case | C3 |
| Plain Words | Write and speak so nobody needs it explained twice | F7: "trained new tellers on our escalation script". Tell the training in your own words. Answer slot: if you changed how you explained the script when it didn't land, say what you changed. If you didn't, say so and describe the training | C4 |
| Neighbours, Not Numbers | Each branch belongs to its town, and members are people, not cases | Selection scaffold: a time you treated a member as part of the community rather than a case number. It needs a named situation and what you did differently because of it. If no such time comes to mind, say so plainly, then say how you'd keep that through the move to hubs | C5 |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | F5: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because of a problem you found, say what the problem was and how you saw it through. If it wasn't that kind of story, say so and use the scaffold: a problem you found and kept hold of until it was solved. If none comes to mind, say so plainly and say how you would | C6 |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold (see the cheat sheet): a real decision, the member's need, what it cost the branch, and the outcome. Say "I" for your part. If no such time comes to mind, say so plainly, then say how you would decide such a case | Members First, Always, in its own words. Scored. VAL |
| C4 | "Tell me about a time you had to explain something so it landed the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7: training new tellers on the escalation script. Answer slot: if you changed how you explained it when it didn't land, say what you changed, in your own words. If you didn't, say so plainly and describe how you trained them | Plain Words. F7 is the sentence that carries a story. VAL |
| C5 | "Tell me about a time you treated a member as a person in the community, not a case number." | VAL | [grounded] | Selection scaffold (see the cheat sheet). If no such time comes to mind, say so plainly, then say how you'd protect that as eight branches become five hubs | Neighbours, Not Numbers, and it matters more to branch managers facing consolidation. VAL |
| C6 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you built the spreadsheet because of a problem you found, say what the problem was and how you saw it through, in your own words. If it wasn't that kind of story, pick another problem you kept hold of. If none comes to mind, say so plainly and say how you would | Own the Fix. F5 is the only sentence that might carry it, and only if it really was a fix. VAL |
| G1 | "Eight branches become five hubs over 2027. How would you handle complaints through that without adding to our load?" | CO | [grounded] | Reciprocity first: what you'd take off their branches, then what you'd need from them. Offer principles, not a pretend plan for branches you don't know: one owner per complaint, one shared definition of resolution time, and themes fed back to branches monthly. Ask what's already working for them | Their branches carry the consolidation. CO first, CASE second |
| G2 | "You'd be coaching our supervisors on escalations, and you're a supervisor yourself today. How does that work?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "trained new tellers on our escalation script" | Name the limit first: you've trained new tellers on the escalation script, and coaching other supervisors would be new. Then principles, said as a plan: coach from real cases, not from rank, and ask what's worked in their branches. Answer slot: if you've ever helped another supervisor with an escalation, say what happened. If you haven't, say so plainly | F7 is a transferability gap, and these are the managers whose supervisors you'd coach. JD |
| H1 | "Sixty seconds: why you, over someone who already knows our branches?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." | Pause. Concede the local knowledge. Then three sentences: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log. You built the monthly complaints spreadsheet your regional manager uses. End with one line on what you'd do first. Finish inside the minute | A composure test. EXP because it rests on F1, F2 and F5 under time pressure |
| H2 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold: "I built it." Answer slot: if others supplied data or shaped its design, say who did what, in your own words. If nobody did, say plainly that it was yours. Hold through two follow-ups by returning to what you built. Don't add who else uses it beyond your regional manager | F5 gets an attribution probe. EXP because the test is what was yours |

### Reverse questions, Round 3

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would genuinely help your branches?" | Reciprocity with peers. It turns the panel into a working conversation |
| "When an escalation goes wrong in your branch today, where does it get stuck?" | It's the role's real problem, and it shows you listen before you prescribe |
| "How are your branches thinking about members who don't use the app as you move to hubs?" | Neighbours, Not Numbers, tied to the 2027 plan |
| "Which of the four values do you see tested most at the counter?" | It invites their stories, and it's useful for you |
| "How do your supervisors like to be coached?" | F7 is the coaching line. Asking now is good practice for the job |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years financial-services customer operations (F1) | B1, A1, H1 |
| Own complaints process end to end across branches (F2) | B4, D1 |
| Across the contact centre (F3) | B2, B4, D1 |
| Regulated complaints (F4) | E3, case clarify step |
| Monthly reporting on volumes and resolution times (F5) | E1, E2, B6, H2 |
| Excel reporting (F6) | A4 |
| Coach branch supervisors on escalations (F7) | C2, G2 |
| Digital teams and self-service journeys (F8) | D2 |
| Presenting to senior leaders (F9) | B5, B6 |
| Four values | A6, C3, C4, C5, C6 |
| Strategy (digital, hubs, lending, app-only banks) | A5, D2, G1, reverse questions |

---

## Prohibited claims

This pack will not coach the claims below.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the log, not the process |
| Has worked in, or with, a contact centre | A negative you stated, F3 | "I haven't worked in a contact centre." |
| Has presented to senior leaders | A negative you stated, F9 | "I haven't presented to anyone above regional level." Note: that sentence doesn't say what you have presented at regional level, so claim nothing there unless it happened |
| Coached branch supervisors | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script." |
| Wrote or designed the escalation script | Inflated form of F7 (participation turned into authorship) | "trained new tellers on our escalation script" |
| Reports monthly to the regional manager, or runs the region's complaints reporting | Inflated form of F5 (building a spreadsheet turned into reporting) | "I built the monthly complaints spreadsheet our regional manager uses." |

---

## Sources

**Provided documents:**
- The JD text
- The values text you copied from ashgrovecu.org/about/values on 12 November 2026. It was pasted, not fetched
- The recruiter's email describing the three rounds
- Your relayed summary of the July 2026 strategy brief the recruiter sent you
- Your background, in your message

No dossier was present.

**Searches and fetches:** none were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted, copied this morning, already sets the cheat sheet and C3 to C6 |
| 2. Ashgrove interview process for Member Experience Lead | skipped | The recruiter's email already sets the three rounds, their lengths, interviewers and the case, so it fixes the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief is under six months old and already sets A5, D2, G1 and the grounding brief |
| 4. Interviewer names | n/a | No names have been assigned, so there was no query to form |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD |

---

## Upgrade menu

- **Your CV:** each evidence cell gains a CV quote, and F1's years become checkable.
- **How many hours you have before 21 November:** a prep triage schedule.
- **Interviewer names, once assigned:** an interviewer read, persona weights from each person's public professional footprint, and a reverse question tied to each person's path.
- **Your answers to the answer slots on F2, F4, F5, F6, F7 and F8**, told to me outside a drill: those rows' evidence cells and B4, E1, E3, A4, C2, C4, C6 and D2 regenerate from your own words.
- **Which regulator's complaint rules Ashgrove works under** (the recruiter can confirm in one email): E3 and the case's deadline step become specific instead of conditional.
- **Inspectable support for F5 and F7:** for example a performance review or training record naming the complaints log or the teller training, and, only if your employer's policy allows, a blank layout of the spreadsheet with no member data. This could raise F5 and F7 above medium. Don't bring internal documents to the interview.
- **Deeper research (L2):** up to 6 more searches and 2 more fetches, several more minutes, covering recent Ashgrove news, any announced detail on which branches become hubs, and candidate reports of its interviews. It would sharpen G1, D2 and the reverse questions.
- **A tuesday-dossier.md from a job-underwriter run:** the highest-ROI objection would be drawn from evidence you confirmed rather than inferred, and the prohibited list would carry your confirmed corrections. It isn't required.
