Quick update: I've read the prep playbook. Next I'm running a few targeted searches on Larkfield Systems (values, interview process, recent news) before I build the three-round pack.
I've built one prep pack for all three rounds: **/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-6-denied-ec6808f8/larkfield-systems_engineering-manager_interview_pack.md**

The web searches were declined, so none of it uses anything published about Larkfield. The questions about the company itself are general, and there's no list of Larkfield's own values for Monday.

**What it contains:**
- **One shared table of how you fit the role.** Each part of the job description is set against your own sentences, quoted word for word, with the gap named.
- **A mini-pack for each round.** Each has the likely interviewer styles, 8–11 practice questions and 5–6 questions for you to ask them.
  - **Tuesday (your would-be boss):** mostly probing your gaps, plus live problems from the role.
  - **Thursday (panel):** the two staff engineers as peers who dig into your numbers, and the PM on product trade-offs.
  - **Monday (VP):** mostly values questions, plus a couple of pressure questions.

**The most valuable thing to rehearse is A1:** "You haven't owned a hardware-adjacent roadmap…" Concede it in your own words, give a ramp plan, then return to what you've actually done. Expect it in all three rounds.

**Your 60% on-call drop** will be probed hard by the staff engineers (A3, E1, E2). Be ready to say how it was counted and which part was yours. Your sentence says the drop came *after* the reliability quarter, not *because* of it, and the pack keeps it that way.

**What the pack won't coach you to claim:**
- managing managers
- owning a hardware roadmap
- leading two squads
- causing the 60% drop on your own
- designing the hiring process

Where your background doesn't say something, the answer guidance leaves a space for you to fill in honestly. Device-management work and growing engineers are the main examples.

If you can, send your CV, the full job posting or the interviewers' names, or allow web search. The pack's last section lists what each would improve.

I can play the Tuesday hiring manager on A1 for a live practice run.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Role:** Engineering Manager, Larkfield Systems ("industrial IoT, ~600 people")
**Mode:** Loop. Three scheduled rounds, one shared fit snapshot, a mini-pack per round.

| Round | When | Who | Relationship | Length |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | Hiring manager, your would-be boss | 45 min |
| 2 | The Thursday after | Two staff engineers and a product manager | Panel: technical peers plus a cross-functional partner | 60 min |
| 3 | The following Monday | VP Engineering | Skip-level; the recruiter called it "values and leadership philosophy" | 30 min |

Your own description of the schedule sets the loop structure (see Sources). No interviewer names were given, so there is no interviewer read and the reverse questions are written for the role.

---

## How to use this pack

Two axes. **Personas** describe how a question is asked (the interviewer's style). **Types** describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values and leadership philosophy they are testing for |
| EXP | Whether your stated experience holds up under questioning: what was actually yours |
| JD | Whether you can do the job as described, gaps included |
| CO | Company and strategy knowledge. Thin in this pack because research did not run (see Sources) |
| CASE | A live problem from the role, which you structure out loud |

**Guidance is scaffolding, not a script.** Each guidance cell rests only on the four sentences you gave me about yourself. Each sentence is quoted in the row's Provenance column. Where a strong answer needs something those sentences don't say, the cell has an **answer slot**: an instruction for the interview with two honest branches. Fill it from what really happened, or say plainly that it wasn't so.

Provenance labels: `[grounded]` traces to your message or the role text you supplied. `[inferred]` is this pack's own derivation, and the derivation is named. `[generic]` is a role-family pattern that makes no claim about you or Larkfield.

**The single highest-ROI prep in this pack is A1** (Tuesday, Skeptic): the hardware-adjacent roadmap gap. It will come up in some form in at least one round, probably all three.

---

## Fit snapshot (shared across all rounds)

All requirements are quoted from the role text in your message. All evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role text | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material shows one team of 6 led for 3 years, not two squads, and the words stay at that scope: "I've been a team lead for three years, of a team of six." If the probe is about leading through other leads: "I haven't managed managers." Answer slot: the two-squad line makes a probe on running more than one team or stream at once likely. If you have done that inside your current role, say what and how, in your own words. If not, say so plainly and stay with the team of six |
| F2 | "building device-management services" — role text | none given | none | [grounded] | discovery | Your material says nothing either way about device-management work. Strong evidence would be services you built or ran that manage, configure or monitor things outside your own systems. Answer slot: the device-management line makes "what have you built that's close to this?" likely. If any of your services had real overlap, say which and what, in your own words. If none did, say so plainly and say what you would learn first |
| F3 | "own delivery" — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | Pushing a reliability quarter through is one delivery decision. The material doesn't show whether delivery commitments in general were yours. Words at the quote's scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after it." Answer slot: "own delivery" makes a probe on who set scope and dates likely. If you set or negotiated those, say how. If that sat with someone else, or there was no such process, say so plainly and stay with the reliability quarter |
| F4 | "hiring" — role text | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but this is a self-report with nothing inspected behind it, so expect a probe. Lead in the sentence's own terms: you run the hiring loop for backend roles, about 40 interviews last year. Keep "backend roles" and keep "about" |
| F5 | "growth for 11 engineers" — role text | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | Being a team lead doesn't show what growth work you did. The derivation stops there. Answer slot: the growth line makes a probe on developing people likely. If growing people on your team was part of your job, say how, in your own words. If it wasn't, or it sat with your manager, say so plainly and say how you would approach it for 11 |
| F6 | "partner with hardware and product on roadmap" — role text, hardware side | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap that wording can't close, and you have said so yourself. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as something you've done. Don't add anything to make the gap feel smaller |
| F7 | "partner with hardware and product on roadmap" — role text, product side | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | "Against roadmap pressure" touches roadmap trade-offs, but it doesn't say who the pressure came from or how the decision was made. Answer slot: if you worked the trade-off out with product, say how, in your own words. If the pressure came from elsewhere, or it wasn't a negotiation, say so plainly and stay with what you did |

### Requirement coverage

| Requirement | Row | Covered by |
|---|---|---|
| "Lead two squads" | F1 | A2, J1, J2 |
| "building device-management services" | F2 | A4, B2, E4 |
| "own delivery" | F3 | B1, B3 |
| "hiring" | F4 | B4, E3, H3 |
| "growth for 11 engineers" | F5 | H4, H5, K1 |
| "partner with hardware and product on roadmap" (hardware side) | F6 | A1, B1, G3 |
| "partner with hardware and product on roadmap" (product side) | F7 | B3, G1, G2 |
| Headline figure: the 60% on-call drop | F3 | A3, E1, E2 |

---

## Round 1: Tuesday, hiring manager (Director of Engineering, 45 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: the hardware side, team size, "why here" | High. A hiring manager is reducing risk on gaps (relationship prior), and F6 and F1 are the visible ones | Rehearse A1 until it's boring. Concede in your own stated words, then give a plan, then return only to what your four sentences carry |
| Case / Strategist | Live problems from their roadmap: inheriting the squads, a field incident, a reliability-versus-date call | High. The other hiring-manager prior. They are buying capability | Clarify, objective, approach, risks. Think aloud. Challenge one premise politely |
| Conversational | The "walk me through your journey" opener and the 90-day question | Low to medium. 45 minutes with your would-be boss usually opens warm, and warm questions are still scored | A rehearsed 90-second arc built only from your four sentences (C1) |

### Question bank: Skeptic (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't owned a hardware-adjacent roadmap, and this role partners with hardware all the time. Why should I bet on you here?" | JD, EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI rehearsal in the pack.** Concede first, in your words: "I haven't owned a hardware-adjacent roadmap." Don't soften it and don't stretch payments work into hardware work. Then give a plan, said as what you would do: who you'd learn from, what you'd ask hardware partners first, how you'd want planning with them to run. Then return to what your sentences carry: three years leading a team of six, and the reliability quarter. **Follow-up 1** ("A firmware slip cascades into your services. How would you even see it coming?"): hold on the plan and say plainly you'd be learning that seam. **Follow-up 2** ("So I'd be carrying you for months?"): concede that you don't know how long the ramp would take, and ask what ramp they've seen work. Don't fold into "yes", and don't overclaim to escape the question | F6 is the one gap you stated outright, and it sits on a headline line of the role, so it is the most predictable objection. JD because it scores the stated partnership requirement, EXP because it tests what you've actually done |
| A2 | "You've led a team of six. This is two squads. What changes?" | JD, CASE | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | State the scope plainly: "I've been a team lead for three years, of a team of six." Then give your view of what changes at two squads, as analysis rather than experience: where your time goes, how information flows, what you'd delegate. If they ask about leading through leads: "I haven't managed managers." Answer slot: if you have run parallel streams or covered another team, say what and how. If not, say so plainly and stay with the team of six | F1's scope gap. JD because it scores "Lead two squads", CASE because the strong half of the answer is reasoning, not history |
| A3 | "Your team's on-call burden dropped 60%. How much of that was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say it at the sentence's scope: you pushed the reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% after it. Your sentence says "after", not "because", so keep it that way unless you can show the link. Answer slots, each in your own words: how the 60% was counted; what the figure is sensitive to; the assumption behind it you'd defend least, named before they find it; and which part was yours. Your sentence makes the pushing-through yours. If you did any of the technical work yourself, say which; if it was the team's, say so. If you don't know how the figure was counted, say so plainly | The one figure in your material, so it will be probed in some round. EXP because it's an attribution test |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick something true. F6 is the honest candidate you've already stated: "I haven't owned a hardware-adjacent roadmap." Pair it with the plan from A1. Answer slot: if device-management services are new territory for you, you can name that instead or as well, said plainly. If you have related work, say what it is in your own words. Don't offer a disguised strength | Tests self-assessment. JD because the answer has to land on a stated requirement (F6, F2) |
| A5 | "Why leave payments for industrial IoT, and why now?" | VAL, JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: your real reasons, in your own words. This pack can't supply them. A clear shape: one reason about the role, one about the domain, one about timing. Keep the same reasons for the panel and the VP, because consistency across the rounds is part of what's scored | A standard Skeptic motivation probe. The premise (you're at a payments company) is your own sentence. VAL because motivation is judged against what they're looking for, JD because it's about this role |

### Question bank: Case / Strategist (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit two squads mid-quarter. One is behind on a release that hardware is waiting on. What do you do in your first two weeks?" | CASE, JD | [generic] | Clarify first: what's late, why, what hardware actually depends on, and who has already been told. Then the objective (a credible date, or an honest re-plan), then the approach: talk to the squad, talk to the hardware counterpart, decide what to cut or protect, communicate once and clearly. Then the risks. The question makes no claim about your past, so the guidance doesn't either | A live version of "own delivery" (F3) and the hardware partnership (F6). It lets you show judgment on exactly the seam you haven't worked |
| B2 | "A device-management service starts failing for a slice of devices in the field. Walk me through how you run it." | CASE | [generic] | Structure: contain the impact, get the right people in, communicate to hardware, product and customer-facing teams, diagnose, fix, then review afterwards. Ask what "failing" means for a device in the field before you go further. That question alone shows you know the domain is different | F2's domain, tested as reasoning rather than history, which is the fair way to meet a discovery gap |
| B3 | "You've got a reliability backlog and a roadmap date from product. How do you decide?" | CASE, EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Start with how you'd decide: cost of the risk, cost of the delay, who needs to agree. Then the one time your material carries: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after it." Answer slot: if the final call was yours, say so. If someone above you signed off, say who and what convinced them. If there was no sign-off step, say so. Each in your own words | Your strongest sentence meets F3 and F7. CASE first because they're scoring the decision rule, EXP because your example will be probed |
| B4 | "How would you approach hiring for these squads over your first six months?" | JD, CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Lead with the sentence: you run the hiring loop for backend roles, about 40 interviews last year. Then your approach as a plan: understand the gaps, set the bar with the squads, run a consistent loop. Answer slot: if you set the interview bar or made hire/no-hire calls, say how. If those sat with others, say so plainly and stay with running the loop | F4 is your closest direct match. JD because hiring is named in the role |

### Question bank: Conversational (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc built from these three sentences only: nine years in engineering, the last three leading a team of six at a payments company; you run the backend hiring loop, about 40 interviews last year; the reliability quarter you pushed through, after which on-call dropped 60%. End on why this role, using your A5 reasons | Almost certainly the opener. EXP because every beat is checkable later in the loop |
| C2 | "What does a great first 90 days look like to you?" | CASE, JD | [generic] | Listen, map, act. Meet each engineer, the hardware counterpart and the PM. Learn the services and the on-call picture. Pick one or two early fixes. State what you'd expect to be judged on by day 90, and ask whether that matches what they expect | Hiring managers use this to check whether you'd ramp on the right things, especially F6 |

### Reverse questions: Tuesday

| Question | Why it lands |
|---|---|
| "A year from now, what would make you say this hire was clearly the right one?" | Gets their scorecard in their own words, which you can then use in the panel and the VP round |
| "Do the squads have tech leads today, and how do you see the split between EM and lead?" | Settles whether the two-squad role involves leading through leads (F1) without you guessing |
| "How does planning between your teams, hardware and product work today, and where does it tend to break?" | Meets your stated gap (F6) with curiosity rather than defensiveness |
| "What's the hardest problem in front of these two squads right now?" | Shows you're already thinking about the work, and gives you material for Thursday |
| "How do you like to work with your managers: cadence, what you want escalated, what you'd rather not hear about?" | This is your would-be boss, so the relationship is part of what you're both evaluating |
| "What does the hiring plan for these squads look like over the next year?" | Connects to your closest match (F4) and tells you how much of the job is hiring |

---

## Round 2: Thursday, panel (two staff engineers and a product manager, 60 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | "What would you need from us?", disagreement between EM and staff engineer, credit across teams | High. The panel rule blends each member's top two personas, and staff engineers relate to an EM as peers, which puts Peer Evaluator first | Reciprocity: what you'd take off their plates, not just what you'd ask of them. Propose principles for the seam rather than pretending to know it |
| Data-Driven Prober | Two levels down on the 60% figure, the reliability quarter and the hiring loop | High. The peer prior's second persona. Two staff engineers means two people likely to ask how things were counted | For each figure, know what you can and can't say about how it was counted. Say plainly when you don't know |
| Values / Behavioral | The PM's "tell me about a time" questions on product trade-offs | Medium. A cross-functional interviewer's prior, applied to one of three panellists | Map the reliability quarter (F7) where it fits. Use a selection scaffold with an honest branch where it doesn't |

This weighting assumes the staff engineers would work alongside you rather than report to you. If one of them would sit in your squads, the Prober weight rises and the Peer framing becomes "what would you need from your manager".

### Question bank: Peer Evaluator (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "When a staff engineer and the EM disagree on technical direction, who decides, and how have you handled that?" | VAL, CASE | [generic] | Start with a principle: technical calls sit with the people closest to the system, delivery calls with you, and disagreements get surfaced early, not escalated late. Then the history part. Pick a time you disagreed with a senior engineer: it needs a real stake, your position, and a working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | The seam a staff engineer cares about most. VAL for the story, CASE for the principle |
| D2 | "What would you need from us, and what would you take off our plates?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Reciprocity first. You can offer to carry hiring-loop load, since you run one now, and to protect reliability time against roadmap pressure, since you've pushed a reliability quarter through. Say both as offers, then name what you'd need from them: context on the systems, honest early warnings | Peer evaluators are measuring whether you add to their load or reduce it. JD because it's about the EM job they'd live alongside |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | "We" for the context, "I" for your contribution. Pick a cross-team piece of work where credit was shared. If none comes to mind, say so plainly and describe how you'd handle it. A good answer shows you give credit away by default | A standard peer stem. It also tests how you'll talk about the squads' work to leadership |
| D4 | "How technical will you stay? Design reviews, code, on-call?" | JD, EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Your nine years in engineering are the context. Answer slot: if you still review designs, write code or carry on-call now, say which and how much. If you don't, say so plainly. Then your view of the right technical depth for an EM of two squads | Staff engineers want to know whether you'll understand their trade-offs. EXP because they'll test whatever you claim |

### Question bank: Data-Driven Prober (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The four defend-the-number slots, in your own words: what "on-call burden" was measured in and over what period; what the figure is sensitive to; the assumption you'd defend least, named before they find it; and which part was yours. Keep "after", not "because". If you don't know how it was counted, say so plainly. That beats a reconstructed method that falls apart on the second question | The figure will be probed harder here than on Tuesday. EXP because it's a scrutiny test |
| E2 | "What was actually in the reliability quarter? What did the team change?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your sentence says you pushed the quarter through. It doesn't say what work it held. Answer slot: if you know what went into it and which parts you chose or did, say so in your own words. If the content was set by the team, say so plainly and stay with what your sentence makes yours, which is getting the quarter through against roadmap pressure | Staff engineers separate scheduling the work from doing it. Rehearsing that line before they draw it is the point |
| E3 | "You run the hiring loop. What's your bar for a senior backend engineer, and how do you know the loop works?" | EXP, JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Lead with the sentence's terms. Answer slots: if you defined the bar or the rubric, say how. If it was inherited or there wasn't a written one, say so plainly and describe how you run the loop. If you've checked whether it works, say how. If you haven't, say so and say what you'd look at. On "about 40 interviews", be ready to say in your own words whether that's interviews you did yourself or the loop's total | F4 is your strongest match, so it's where a prober goes looking for depth. JD because hiring is named in the role |
| E4 | "Device-management at scale: what's the hardest technical problem you'd expect here, and what would you want to see in our systems first?" | CASE | [generic] | Ask before you assert. Name what you'd want to understand: how devices check in, how changes roll out, what failure looks like in the field. Ask which of those hurts most today. Don't guess at their architecture | F2's discovery gap. Staff engineers reward calibrated curiosity and punish bluffing in their own domain |

### Question bank: Values / Behavioral, from the PM (G)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you pushed back on product's priorities. How did it land?" | VAL, EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on your sentence: the reliability quarter, pushed through against roadmap pressure, and on-call dropping 60% after. Tell it in your own words. Answer slot: the PM will ask where the pressure came from and how the relationship held up. If it came from product and the relationship held, say how. If it cost something, say what. If the pressure came from elsewhere, say so plainly and stay with the quarter | A PM's natural test of whether you'll be a partner or a blocker (F7) |
| G2 | "How do you want to work with your PM on roadmap? Who owns what?" | JD, CASE | [generic] | A clear split: the PM owns what and why, you own how and when, and trade-offs get made together and early. Then ask how it works today. Collaborative, with no claim about your past | "Partner with … product on roadmap" is in the role. JD for the requirement, CASE for the working model |
| G3 | "Hardware slips a date, and that pushes our launch. How do you handle it with me and with customer-facing teams?" | CASE | [generic] | Clarify the size of the slip and what depends on it. Re-plan with the PM, not around them. Then one clear message to the customer-facing teams. Say what you'd protect and what you'd cut | Puts F6's hardware seam in front of the person who feels it most |

### Reverse questions: Thursday

| Question | Why it lands |
|---|---|
| To the staff engineers: "What could a new EM do in the first month that would genuinely help your work?" | Reciprocity question for peers. It turns the panel into a working conversation |
| "How do technical decisions get made between staff engineers and EMs here today?" | Gets the real seam behind D1 |
| To the PM: "How does roadmap planning with hardware actually run, and where does it break?" | Compare the answer with the director's on Tuesday. Differences are useful information |
| "What does on-call look like for these squads right now?" | Shows what you care about (F3) and tells you what you'd be inheriting |
| "What's worked well about how these squads have been run, and what would you change?" | Invites candour without assuming anything about who came before |
| "What would make you say, after six months, that the new EM made your job easier?" | Gets the panel's own scorecard |

---

## Round 3: Monday, VP Engineering ("values and leadership philosophy", 30 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" questions on leadership, hiring and growing people | High. The recruiter described the round as "values and leadership philosophy", which makes it a dedicated values round | One story per theme, used only where your sentences carry it. A selection scaffold with an honest branch everywhere else |
| Pressure | "You've never managed managers, so why this step?", time-boxed "why you" | Medium. The skip-level prior, and 30 minutes rewards short, composed answers | Pause, restate, anchor in what you stated, hold through two follow-ups |
| Case / Strategist | A leadership scenario rather than a technical one | Low to medium. Skip-level prior, softened by the stated values focus | Use the same structure as Tuesday, framed as how you lead |

**No values cheat sheet.** The round is values-style, but Larkfield's published values weren't available because the search was refused (see Sources). The VAL questions below are themed on the recruiter's own words and the role text, not on Larkfield's values. If you paste their values page, I'll map each value to a story.

### Question bank: Values / Behavioral (H)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy, in a couple of minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: your principles are yours to state, and this pack can't supply them. Shape: two or three principles, each tied to something you did. If one of yours is about when to put the team's health or reliability ahead of the roadmap, your material carries a story for it: the reliability quarter you pushed through against roadmap pressure, after which on-call dropped 60%. For principles your material doesn't carry, pick a time you acted on that principle. If none comes to mind, say so plainly and say how you'd act on it | The recruiter's stated focus. Almost certainly the opening question |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL, EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on your sentence: the reliability quarter, pushed through against roadmap pressure. Answer slot: if you made that case to leadership, say to whom and how it landed, in your own words. If the pressure and the decision sat at your own level, say so plainly and tell it as it was. Use a different story only if it's true and you can name the stake | A values-round staple. Your one well-evidenced decision probably fits it, but only as far as the sentence goes |
| H3 | "Tell me about a hiring call you'd make differently now." | VAL, EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Context from your sentence: you run the backend hiring loop. Pick a real call you'd now make differently: it needs the decision, what you learned, and what you changed. If none comes to mind, say so plainly and describe what you watch for now | "hiring" is in the role, and your loop is where they'll look for judgment rather than volume |
| H4 | "Tell me about someone on your team you helped grow." | VAL, JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Context: three years leading a team of six. Pick one person: where they started, what you did, where they got to, in your own words. If you can't name such a case, say so plainly and describe how you'd approach growth for 11 engineers | F5's discovery gap meets "growth for 11 engineers". VAL for the story, JD for the requirement |
| H5 | "How do you handle someone who isn't performing?" | VAL, JD | [generic] | Principle first: be clear early, give specific expectations and real support, then follow through. If you've handled such a case, tell it in your own words, keeping the person anonymous. If you haven't, say so plainly and walk through how you would | The hard side of the growth requirement (F5), and a common test of whether a manager avoids conflict |

### Question bank: Pressure (J)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You've never managed managers. Why is this the right next step and not a stretch too far?" | JD, EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Concede plainly: "I haven't managed managers." Hold on what your sentences carry: three years leading a team of six, the backend hiring loop, and the reliability quarter. You don't know whether this role involves managing leads, so don't assert either way; ask (see the Tuesday reverse question about tech leads). **Follow-up 1** ("Two squads is a different job"): agree that it's bigger, and say what you'd change in how you work, as a plan. **Follow-up 2** ("So why not wait?"): give your A5 reasons, and don't fold | F1 plus your stated negative. A skip-level is likely to press on the step up, and the negative is yours, so the question can be put that bluntly |
| J2 | "Sixty seconds: why you over an internal candidate?" | VAL, JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Three beats from your sentences, no more: three years leading a team of six, you run the backend hiring loop, and the reliability quarter you pushed through against roadmap pressure. Then one line on what you'd bring that's different, from your A5 reasons. Stop inside 60 seconds | Pressure stem. Tests economy and whether you stick to what you can back |

### Question bank: Case / Strategist (K)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Your squads are hitting dates, but on-call is creeping up and two engineers seem quietly unhappy. What do you do?" | CASE, VAL | [generic] | Clarify: how long has this been going on, and are the two connected? Talk to both engineers one-to-one. Look at the on-call data. Decide what to protect, and tell your director and the PM about the trade-off before it becomes a surprise. A leadership philosophy shown in action | Checks whether what you said in H1 survives a real trade-off (F3, F5) |

### Reverse questions: Monday

| Question | Why it lands |
|---|---|
| "What does great leadership at the manager level look like to you here?" | A values round invites you to ask for their philosophy |
| "What's a leadership habit you've seen get managers into trouble here?" | A sharper version of the above, and it tells you what they guard against |
| "How does the org make reliability-versus-roadmap trade-offs at your level?" | Signals what you care about (F3) and shows how much backing an EM would get |
| "Where does device-management fit in engineering's next couple of years?" | Stands in for the company-strategy question this pack can't ground without research |
| "How do EMs grow here: toward managing managers, or deeper in a domain?" | Meets your stated gap (F1) as ambition rather than apology |

---

## Prohibited claims (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated: "I've never managed managers and never owned a hardware-adjacent roadmap." | "I haven't managed managers." |
| Has owned or run a hardware-adjacent roadmap | A negative you stated, the same sentence | "I haven't owned a hardware-adjacent roadmap." |
| Has led two squads or a team of 11 | Inflated form of F1 | F1's quote at its own scope. As the pack's own observation, not words for you: your material says a team of 6, not two squads. A2's answer slot stays inside your current role |
| Cut on-call by 60% personally, or caused the 60% drop | Inflated form of F3's quote, which says "after", not "because" | F3's quote at its own scope: on-call dropped 60% after you pushed the reliability quarter through. A3 and E1's slots ask how it was counted and which part was yours |
| Owned the team's roadmap or delivery commitments | Inflated form of F3 and F7 | The quote at its own scope: you pushed a reliability quarter through against roadmap pressure. B3 and G1's slots stay inside that quarter |
| Designed the hiring process or made the final hiring decisions | Inflated form of F4 | F4's quote: you run the hiring loop for backend roles, about 40 interviews last year. E3's slot stays inside running the loop |

Device-management experience (F2) and growing engineers (F5) are not listed here. Your material is silent on them rather than stretched, so those rows have answer slots instead.

---

## Sources

**Provided:** the role text, your background (four sentences), and the round schedule including the recruiter's "values and leadership philosophy" description, all from your message. No CV, full posting or dossier was provided.

**Loop:** your own description of the three rounds (who runs each and its format) establishes the loop. It's a loop source in your words, and it also identifies Monday as a values-style round.

**Searches sent:**
- `Larkfield Systems values`: refused
- `Larkfield Systems interview process engineering manager`: refused
- `Larkfield Systems industrial IoT news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have given the Monday values cheat sheet and let the H bank be themed on Larkfield's named values |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have shown whether any round has a case or exercise format. The rounds and persona weights rest on your own description, so they don't depend on it |
| 3. `Larkfield Systems` strategy and recent news | unavailable | The search was refused. It would have grounded CO questions and a strategy-based CASE, so the pack has no CO-tagged question |
| 4. Interviewer names at Larkfield Systems | n/a | No names were given, so there was nothing to search for. There is no interviewer read |
| 5. Representative Engineering Manager JD | skipped | The role text you supplied sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search:** Larkfield's values page gives a Monday values cheat sheet with one story per named value, and recent news makes B1, B2 and the Monday reverse questions company-specific instead of `[generic]`
- **Your CV:** every evidence cell can quote CV lines alongside your message, F2 and F5 may gain real evidence, and more answers become story-mapped instead of answer slots
- **The full job posting:** any requirements beyond the summary line become fit-snapshot rows, each with a JD-tagged question
- **Interviewer names:** per-person personas on the Thursday panel, a public-footprint read of the VP, and reverse questions tied to each interviewer's path
- **Your answers to the answer slots, given here outside a drill:** how the 60% was counted and what the quarter held upgrades A3, E1 and E2; device-adjacent work upgrades F2, A4 and E4; growth work upgrades F5, H4 and H5; who the roadmap pressure came from upgrades F7, B3 and G1
- **Recruiter guidance for Thursday:** if the panel includes an exercise or a system-design discussion, it gets its own build section
- **Prep time per round:** a prioritised schedule for each round, ordered around A1, A3 and E1
- **Deep research (L2):** up to 6 more searches and 2 more fetches, several more minutes. Adds a strategy brief, the VP's public talks if a name is given, interview reports for this role family, and recent org context. It needs search permission
- **A job-fit dossier:** carries verified evidence and a named objection into this pack, so the highest-ROI question rests on confirmed evidence rather than inference
