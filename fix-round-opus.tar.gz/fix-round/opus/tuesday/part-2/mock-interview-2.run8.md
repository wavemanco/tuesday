Building your prep pack now. I'm running a few quick searches on Atlas Freight first.
I've saved your prep pack as `Atlas-Freight_operations-manager_interview_pack.md`. I didn't know who you're meeting or what kind of round it is, so it covers the whole interview process with every interviewer style weighted equally. My web searches on Atlas Freight were blocked by this session's permissions, so the questions about the company itself are general, not specific to Atlas.

**What matters most:**
- **Your biggest risk is scale.** You lead 3 supervisors at one site; the job is 12 supervisors across 4 sites. Question A1 is the one to rehearse hardest. The pack gives you words for it that stay true to what you told me.
- **Power BI:** you said you've never used it, so the pack coaches you to say that plainly and then give a learning plan. If you start learning before the interview, you can talk about what you've actually done.
- **The 40% mis-pick result** is your best number, so expect "how was that counted?" and "how much of it was you?" (B1, D2).
- **"5+ years operations leadership required"** is likely to be checked literally. Your message says 7 years in ops but not how many of those were leading people, so have the real number ready (B4).

If you like, I'll play the Skeptic and run you through A1 live.
I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is this a recruiter screen, a hiring-manager round or a panel, and has the recruiter mentioned any focus areas or an exercise? The answer changes how every bank is weighted.
Do you want me to research Atlas Freight? That needs you to allow web search. I can also do a deeper pass of up to 6 more searches and 2 page reads, which takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager. **Company:** Atlas Freight (regional logistics, 800 employees, per the JD you pasted). **Interviewer:** not known. **Round type:** not known. This pack covers the whole loop with flat persona weights, which is weaker than a pack built for one round. The upgrade menu says what would sharpen it.

## How to use this pack

Two axes. **Personas** describe how a question gets asked, meaning who is asking and in what style. **Types** describe what is being scored. The same content can arrive in any persona's style, so rehearse both.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values the company publishes, or in this pack (no values page could be read) the leadership behaviour the role needs |
| EXP | Whether your stated experience holds up under scrutiny: what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Homework on the company: why here, what you know about them |
| CASE | Live problem-solving on a problem from the role |

Provenance labels: `[grounded]` means traceable to your message or the JD, `[inferred]` means derived from them with the derivation named, and `[generic]` means a role-family pattern with no claim about you or Atlas.

The guidance is scaffolding, not a script. An **answer slot** is a place where only you know the answer. It gives you two honest branches, and both are good answers.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution, and one site. It does not say terminal operations or four sites, so the words stay at that scope: "I've spent seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's "terminal operations across 4 sites" makes a probe on terminal work and multi-site work likely. If any of your work covered a terminal or more than one site, say what and how, in your own words. If none did, say so plainly and stay with the site whose surge plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is a different measure from on-time performance or cost per shipment, so don't stretch the bridge. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names on-time performance and cost per shipment, so expect a probe on them. If you tracked or moved either one at your site, say which and how, in your own words. If you didn't, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Same kind of work, smaller span. Your material shows 3 supervisors, and the JD asks for 12. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's twelve makes a probe on wider-span leadership likely. If you have led a larger group at any point, say when and how, in your own words. If you haven't, say so plainly and stay with the 3 supervisors you lead now. Anything about leading twelve is said as a plan, never as a past |
| F4 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops is not the same claim as seven years leading people, and your material doesn't show how many of the seven were in leadership roles. Answer slot: "required" means this line is likely checked literally. Say how many of the seven years you have held supervisory or management roles, and which roles, in your own words. If it's fewer than five, say so plainly and stay with what your current role carries |
| F5 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" touches the requirement but doesn't show that you build reporting. Answer slot: if you've built reports in Excel, say what they tracked, who read them and how often, in your own words. If you haven't built reporting, say so plainly and describe what you use Excel for |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | You said this yourself, and no wording closes it. Words: "I haven't used Power BI." Then how you'd learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap look smaller. If you start learning before the interview, what you have actually done becomes new evidence |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but the certificate hasn't been seen, so expect a probe. Lead with the certification in your own terms. Answer slot: the JD's Lean/Six Sigma line makes a probe on applying it likely. If you've applied it to a project, including the pick-path redesign, say which project and how, in your own words. If you haven't, say so plainly and say what you'd apply first here |

## Persona table

No loop source was available: the searches for Atlas Freight's interview process were refused, and your message doesn't say who you're meeting. Weights therefore fall back to the generic archetype (screen, then hiring manager, then panel), with flat weights. This rests on a pattern, not on Atlas's documented process.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scale jump: from 3 supervisors to 12, and from one site to four | Flat, but carries the pack's highest-ROI question, because F1 and F3 are the visible gaps any reader of your background will see | Rehearse A1 until it's boring. Hold only what your quotes say, name the limit before they do, then give a concrete plan |
| Data-Driven Prober | Asks how the 40% was counted, and what your reporting looks like | Flat. Your one headline figure is the obvious target, and the JD's reporting line invites it | Know what you can and can't say about how the 40% was counted, and say plainly when you don't know |
| Case / Strategist | Live problems: cost per shipment rising, on-time slipping, the first 90 days, peak planning | Flat. Generic archetype hiring-manager rounds lean this way | Clarify, then objective, segments, approach, metrics, risks. Think aloud |
| Pressure | Time-boxed challenges: "how much was actually you", "why wait for you to learn Power BI" | Flat | Pause, restate, anchor in what you stated, hold through two follow-ups, then concede something specific |
| Conversational | Friendly "walk me through your journey" and casual Lean talk | Flat. Most loops open this way | A pre-built 90-second arc from your own facts. Treat casual questions as scored |
| Values / Behavioral | Leadership stories: a struggling supervisor, an unpopular truth, a customer over a metric | Flat. No values-style round was detected and no values page could be read, so these are themed on the JD's leadership line | Pick real stories with a named stake. Where none comes to mind, say so rather than invent one |
| Peer Evaluator | Seams and disagreement with equals | Flat. A panel at an 800-person firm may include a peer | Reciprocity framing. Propose principles for the seam rather than pretending to know it |

## Question banks

IDs run by persona. Letter F is skipped so that question IDs never collide with fit-snapshot rows. Weights are flat, so banks are ordered by where your gaps sit, not by likelihood.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role runs four sites and twelve supervisors. Where have you led at that scale?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | **Highest-ROI rehearsal in this pack.** Hold only what the quotes carry: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Say the comparison before they do: "Twelve supervisors across four sites would be a bigger span than the role I hold now." Answer slot: if you've led a larger group or more than one site at any point, say when and how, in your own words. If not, say so plainly and return to the 3 supervisors and the surge plan. Then give the plan as a plan: how you'd learn four sites and twelve people in the first weeks. Likely follow-ups: "So that's three supervisors at one site, why should we believe you can run twelve?" Hold by returning to the quotes, never by adding to them. "What would you do in month one?" Go to the plan. Concede the span difference specifically, and never fold on what you did | F1 and F3 are the two widest gaps between the JD and your material, so this objection arrives in some form in almost any round. JD because it scores the stated span directly |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick the gap you've already named: "I haven't used Power BI." Follow straight away with what you'd do about it, as a plan with a timeframe you would actually keep. Don't pick a fake weakness. They'll see the Power BI line either way, and naming it yourself scores as self-assessment | F6 is a gap you stated, which makes it the honest answer to the classic Skeptic stem. JD because it maps to the reporting requirement |
| A3 | "Your background is warehouse and distribution. This job is terminal operations. How does that carry over?" | JD | [grounded] "7 years in warehouse and distribution ops" | Describe what you've done in your own words, starting from "seven years in warehouse and distribution ops", and let them draw the inference. Don't tell them it's proof of anything. Answer slot: if any of your work involved a terminal, say what it was. If none did, say so plainly. Then say, as a plan, what you'd want to learn first about how their terminals run | F1's transferability gap. The Skeptic tests whether you overclaim the overlap. JD because "terminal operations" is the JD's own phrase |
| A4 | "Why Atlas Freight, and why now?" | CO | [generic] | Research on Atlas couldn't run, so this pack can't give you company facts. Build this from your own reading of their site or job ad before the interview: one thing about Atlas that's specific, plus one reason this role is the step you want. Answer slot: if you have a reason for moving now, say it in your own words. Keep it forward-looking, not a complaint about your current employer | The Skeptic's "why here, why now" stem. CO because it scores homework. `[generic]` because no company source could be read |

### B — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that 40% mis-pick figure was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on F2: the mis-pick rate, the 40% and the pick-path redesign, which are the beats your sentence states. Tell them in your own words. Answer slots the figure raises, each in your own words: how the 40% was counted; what it's sensitive to; the assumption behind it you'd defend least, which you name before they do; and which part of the result was yours. If you don't know how it was counted, say so plainly. That's an honest answer, and better than one you can't repeat under a second question | Your one headline number is the Prober's first target. EXP because it tests what you did and how you know it |
| B2 | "Tell me about the reporting you've built in Excel." | JD | [inferred] "solid Excel" | Say what you use Excel for, in your own words. Answer slot: the JD's "build reporting in Excel/Power BI" makes this likely. If you've built reports, say what they tracked, who used them and how often. If you haven't built reporting, say so plainly and describe what "solid Excel" means in your day-to-day work | F5 is thin. Rehearsing it means the honest answer is ready before the probe comes. JD because it scores the stated reporting requirement. `[inferred]` because the question's premise is the JD's, not yours |
| B3 | "On-time performance drops two points across four sites in a month. How do you find out why?" | CASE | [generic] | Structure: define it first (on time against what: pickup, delivery or appointment, and measured where); check that the data is right before acting on it; segment by site, shift, lane and customer to see whether it's everywhere or concentrated; go to the floor where it's concentrated; fix, then monitor the measure weekly. This question needs no claim about your past, so the guidance makes none | F2's on-time half, asked as a live problem. CASE, with Prober delivery: expect "what's the denominator?" |
| B4 | "Of your seven years, how many have been in leadership roles?" | JD | [inferred] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Answer slot: give the actual number and the roles, in your own words. If it's five or more, say so with the titles. If it's fewer, say so plainly and stay with what your current role carries. Don't round up, and don't count non-leadership years as leadership | F4: the JD marks "5+ years operations leadership" as required, so it's likely checked literally. JD because it's a stated requirement |

### C — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Cost per shipment is up 8% across the four sites. Diagnose it." | CASE | [generic] | Clarify: what's in cost per shipment here, over what period, and whether shipment mix changed. Then split it into the numerator (labour, overtime, equipment, linehaul, damage and claims) and the denominator (did volume fall?). Compare sites to find whether it's one site or all four. Pick the largest driver, propose one fix and say how you'd measure it. State one premise you'd challenge. No claim about your past is needed | F2's cost half. CASE because hiring managers buy structure on their own problem |
| C2 | "First 90 days: four sites, twelve supervisors you didn't hire. What's your plan?" | CASE | [generic] | Days 1–30: listen and learn (each site, each supervisor, current KPIs and reporting). Days 31–60: pick one or two problems with the data behind them. Days 61–90: deliver a visible improvement and set a reporting rhythm. All of it is said as a plan. Don't describe a past 90-day plan unless you've done one | F1 and F3: the scale of the role asked as a plan rather than a record, which is the honest ground for you on this gap |
| C3 | "Peak season is eight weeks out across all four sites. How do you plan for it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | You can anchor in the fact that you ran the site's peak-season surge plan two years running, in your own words. Then structure the four-site version as a plan: forecast volume by site, set staffing and shift needs, plan equipment and space, set escalation rules, and do a post-peak review. Don't describe the contents of your past surge plan beyond what you know you did. If they ask, tell it in your own words, and only what was yours | Your surge-plan experience is the closest thing you have to this problem, asked at the JD's scale. CASE, with an EXP anchor |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" | Pause, then give two facts in your own words: the mis-pick rate cut 40% by redesigning the pick path, and the peak-season surge plan you ran two years running. Then one line on what you'd do first in the role, said as a plan. Don't guess what an internal candidate lacks. You don't know, and it comes across as an attack | A classic time-boxed stem. JD because it asks you to make the case for fit |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say exactly which part was yours and which part was others', in your own words. If it was yours alone, say so. If others did parts, name their parts. Hold that answer through two follow-ups. If pushed, concede only something specific and true, such as what you don't know about how it was counted, and never fold on what was actually yours | The Pressure version of B1. EXP because it scores attribution honesty |
| D3 | "You've never used Power BI, and this job builds reporting in it. Why should we wait for you to learn?" | JD | [grounded] "solid Excel, never used Power BI" | Hold calmly: "I haven't used Power BI. My Excel is solid." Then the plan. Answer slot: if you've started learning it before the interview, say what you've actually done. If not, say what you will do and by when. Don't oversell how fast you'll learn it | F6, the gap you stated, under pressure. JD because it scores the reporting requirement |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc built only from these facts: seven years in warehouse and distribution ops; now a senior shift manager over 3 supervisors; the mis-pick rate cut 40% by redesigning the pick path; the site's peak-season surge plan, run two years running; green belt certified. End on why this role is the next step. Write it in your own words and say it aloud three times | The likely opener. The friendly register hides that it's scored for economy |
| E2 | "What are you actually doing with Lean these days?" | JD | [grounded] "green belt certified" | Start with the certification, in your own terms. Answer slot: the JD's "Lean/Six Sigma a plus" makes this likely. If you've applied it to a project, say which project and how, in your own words. If not, say so plainly and say what you'd look at first in a terminal | F7 is a plus-skill, and the Conversational persona asks about plus-skills casually. JD because it maps to the stated plus |

### G — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time one of your supervisors was struggling. What did you do?" | VAL | [generic] | Selection scaffold: pick a real time with a named problem, what you did yourself, and how it ended, including if it ended badly. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Themed on the JD's "lead a team of 12 supervisors" (F3). VAL because it scores leadership behaviour. `[generic]` because no published Atlas values could be read |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a real time, the truth, who heard it, what it cost you to say it, and whether it landed. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A standard Values stem. An ops manager reporting on four sites' numbers will need to do this |
| G3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a real decision, the metric you let slip, why, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A standard Values stem. On-time performance is the JD's customer-facing measure, so the tension is real in this role |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Ask what it is. Propose principles instead: shared data first, escalate early, agree on what each side owns. Say what you'd bring to their team, not only what you'd need from them | A panel may include a peer. CASE because it's a live working-relationship problem, with VAL undertones |
| H2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use the mis-pick result as the example. Answer slot: say which part of it was yours and which part was others', in your own words. If it was yours alone, say so plainly. Credit others by name for their parts | The figure raises the "which part was yours" slot, and this stem asks it collegially. EXP because it scores attribution |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" (F1) | A1, A3, C2, C3, H1 |
| "drive on-time performance and cost-per-shipment down" (F2) | B3, C1 |
| "lead a team of 12 supervisors" (F3) | A1, C2, G1 |
| "5+ years operations leadership required" (F4) | B4 |
| "build reporting in Excel/Power BI" (F5, F6) | A2, B2, D3 |
| "Lean/Six Sigma a plus" (F7) | E2 |
| Headline figure: the 40% mis-pick reduction | B1, D2, H2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is on-time performance measured today, and how do the four sites compare?" | It shows you expect to be measured on it, and it tells you the baseline you'd inherit |
| "What goes into cost per shipment here, and which inputs does this role control?" | It shows you think in unit economics, and it shows you how much of the target is actually yours to move |
| "What reporting exists now in Excel and Power BI, and what's missing?" | It shows how big your Power BI gap really is in practice, and it shows you've read the JD closely |
| "How are the twelve supervisors spread across the sites, and how long have they been in role?" | It goes straight at A1. You learn what leading them would involve, and you signal that you're already thinking about the team |
| "What would a strong first six months look like in this role?" | It gives you their success criteria in their words, which you can mirror in any later round |
| "Why is this role open?" | It tells you whether you'd be stepping into a turnaround, a growth role or a backfill, which changes what you'd need to show |

## Prohibited claims

These are claims this pack won't coach, because each one is a wider version of something you said, or something you said you haven't done. An interviewer can test every one of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is this pack's observation: your material says warehouse and distribution, at one site. A1 and A3's slots stay inside that |
| Has led a team of twelve supervisors, or a team at that scale | Inflated form of F3 | F3's quote: "currently a senior shift manager over 3 supervisors." The comparison with the role you hold now is fine. Anything about leading twelve is a plan |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope: the mis-pick rate, cut 40% by redesigning the pick path. Mis-pick rate is a different measure |
| Has 5+ years of operations leadership | Inflated form of F4 | F4's quotes at their own scope: seven years in ops, and a current leadership role. The number of leadership years is yours to state in B4's slot |
| Built reporting in Excel | Inflated form of F5 | F5's quote: "solid Excel." Whether you built reports is B2's slot |
| Has used Power BI or built Power BI reports | A negative you stated, F6 | "I haven't used Power BI." No slot |
| Designed or wrote the surge plan, as opposed to running it | Inflated form of F1's second quote | "ran the site's peak-season surge plan two years running." "Ran" stays "ran" unless you say more yourself |
| Ran the pick-path redesign as a Lean/Six Sigma project | An inflated link between F2 and F7 | Each quote stands on its own. E2's slot lets you connect them only if that's what happened |

## Sources

Provided documents: your message, which includes the JD text and your background.

Searches sent (all three were refused by this session's permissions, so none returned anything):

- `"Atlas Freight" logistics company values`: refused
- `"Atlas Freight" interview process operations manager`: refused
- `"Atlas Freight" terminal news 2026`: refused

No fetches were sent. No dossier was present. Persona weights use the generic archetype because no loop source was available.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Refused. It would have given official value names to theme the G bank, and a values cheat sheet if a values round were detected |
| 2. `Atlas Freight interview process operations manager` | unavailable | Refused. It would have named the rounds, so persona weights could follow Atlas's documented process instead of a flat generic pattern |
| 3. `Atlas Freight` strategy / recent news | unavailable | Refused. It would have given recent moves for a company-specific CO or CASE question and a real answer to A4 |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting (recruiter, hiring manager, peer, panel) → persona weights set for that round instead of flat, with the top banks deepened and the rest trimmed
- The interviewer's name and title → a read of their public professional background, persona weights adjusted to it, and a reverse question tied to their path
- The recruiter's prep email or invite → focus areas, and a build section for any exercise or presentation they've announced (a data or reporting exercise would be a common one for this role)
- Allowing web search for this session → targets 1–3 rerun: Atlas's values, its interview structure and recent news, which turns A4 and the CO and CASE questions from `[generic]` into Atlas-specific ones
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a short Atlas strategy and context brief for the "why us" and strategy questions
- Your actual CV → evidence quotes taken from your résumé lines rather than this message, and likely more stories for the G bank's scaffolds
- Your answers to the slots on F1 (terminal or multi-site work), F4 (leadership years) and F5 (reports you've built) → those rows regraded, possibly from `discovery` or `transferability` to a firmer fit, with B2, B4, A1 and A3 rewritten around what you say
- The artifacts this field keeps (before-and-after mis-pick data, the surge plan document, an Excel report you built, your green belt certificate) → F2, F5 and F7 rise toward `high` confidence, and you have something concrete to point to if you're probed
- A `tuesday-dossier.md` from job-underwriter → the highest-ROI objection derived from verified evidence instead of inferred here, and a prohibited list checked against claims you've confirmed. It's optional, and this pack is complete without one
