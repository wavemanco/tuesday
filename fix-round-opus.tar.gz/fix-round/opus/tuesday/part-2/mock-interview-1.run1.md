No dossier in the working directory. Reading the step files.
I've built the full prep pack for Priya's 60-minute peer conversation with Dan: 24 questions, each tagged by interviewer persona and question type, with answer guidance and a rationale. It's built only from what you gave me. All four web searches I tried were blocked by permissions, so nothing in it has been checked against outside sources.

Because of that, three things in the pack haven't been checked:
- **Your research note.** The three Northwind priorities and the bundling threat are used as you wrote them, and I couldn't confirm they're current. The Compass, bundling and profitability cases rest on them.
- **Northwind's published values.** I couldn't get them, so the behavioural questions are general patterns rather than mapped to Northwind's own values.
- **Dan's profile.** Everything about him comes from your summary; I found no talks or posts.

**Highest-ROI prep: question D1.** Dan is likely to say "You haven't done sales ops or quota setting, and this role sits right next to sales strategy." That objection sits squarely in his own field, so he's the one person she can't bluff. The guidance has her say it plainly first ("I haven't done classic sales-ops or quota-setting work"), then point to the volume targets she set without calling them quotas, then give a ramp plan. It scripts three follow-ups with exact concession wording.

**How the questions are weighted.** As a peer sharing her VP, Dan is mostly weighing what she adds to or takes from his team, so the "where's the seam between us" questions lead. His "relentlessly data-driven" self-description means her ~$400M figure gets two questions on how it was counted. His pricing background tilts the live cases toward packaging and pricing.

**What's in the pack:**
- A fit snapshot comparing each JD line to her background.
- A read on Dan.
- The 24 questions, plus a table showing which questions cover each JD requirement.
- Seven questions for Priya to ask Dan.
- A list of claims the pack won't coach, such as "drove $400M," "designed a partner motion" or "led the carrier negotiations."
- A list of what would improve the pack, ending with what more input would add.

**Before you rehearse:**
- Where your notes don't cover something, the guidance doesn't fill it in. It tells Priya to answer from her own experience and gives her an honest way to say it didn't happen. The main gaps are how the $400M was counted, whether her revenue model shaped the partner terms, and why she wants to move to B2B. She needs her own answers to those before the interview.
- The "no quota-setting" line is your wording, not hers. She should confirm she'd say it that way.

Files are in the working directory:
- NorthwindData_senior-gtm-strategy-lead-emerging-products_interview_pack.md

I can play Dan as the Skeptic and run D1 live with real follow-ups, then give feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: NorthwindData_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. He would be Priya's **peer**, and both report to the same VP.
**Format:** a single 60-minute conversation, as your note describes it. That note is the loop source, so this pack prepares for one session and does not fall back on a generic loop archetype.

---

## How to use this pack

Questions are organised on two axes:

- **Persona = how the question is asked.** One sub-table per interviewer style, heaviest-weighted first. Dan is one person, but he will move between styles during the hour. The persona table shows how likely each style is and why.
- **Type = what the question scores.** Each question has a primary tag, plus a secondary one where it applies.

| Tag | What it is really testing |
|---|---|
| VAL | Behavioural: whether past behaviour shows the right working values |
| EXP | Work-experience deep-dive: whether the claims hold up and what was actually hers |
| JD | Role-driven: can she do the listed job, including the gaps |
| CO | Company and strategy: can she think at Northwind's altitude (Compass, bundling, profitability) |
| CASE | Live problem: structure and reasoning on a problem from the role, done out loud |

**Provenance labels** (in their own column): `[grounded]` means traceable to what you provided. `[inferred]` means derived by this pack, and the derivation is named. `[generic]` means a role-family pattern that makes no claim about Priya or Northwind.

**The guidance is scaffolding, not a script.** Every claim about Priya's past sits beside the exact sentence from your notes that supports it. Where your notes don't say something, the guidance gives an **answer slot**: an instruction to answer from her own experience, with an honest branch if the thing never happened. She should rehearse in her own words and never fill a slot with something she didn't do.

---

## Fit snapshot

Requirements are quoted from the JD highlights in your message. Evidence is quoted from your notes on Priya. None of it has been inspected or confirmed by Priya herself, which is why nothing is rated above `medium`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows a proposal credited with an outcome, not ownership of a go-to-market. The words stay at that scope: "I proposed a store-surface change that was credited with roughly $400M of ARR uplift." Answer slot: the JD's "own GTM strategy" line makes a probe on go-to-market decisions likely. If any of them were hers for that change (who it targeted, how it launched, how it was sequenced), she says which and how she decided, in her own words. If there were none, or they weren't hers, she says so plainly and stays with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | The material says nothing about customer-lifecycle or whitespace analysis. Answer slot: if she has sized untapped demand, attach, or expansion potential in an existing base, she says what she looked at and what came of it, in her own words. If she hasn't, she says so plainly and goes straight to how she would do it here (see B4) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. It is a self-description with nothing inspected behind it, so expect Dan to test it hands-on. She leads with "I work in SQL and Tableau myself." Answer slot: if there is an analysis she ran end to end herself, she offers to walk through it. If none comes to mind that she can describe in detail, she says so and describes how she would work the problem in front of her |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model used in negotiations is adjacent to designing a partner motion but is not the same thing. The words stay at the quote: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's "partner-motion design" line makes a probe on design likely. If any part of the partner structure, terms, or programme was hers to shape, she says which and how. If not, she says so plainly and stays with the model she built |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap. The quote already speaks to influence across orgs. She leads with it in its own terms: "I set annual volume targets with cross-org consensus." Expect a probe on how the consensus was reached. The answer slot for that is in A2 |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Using AI tools daily is not AI product or AI go-to-market experience, and the bridge should not stretch it. Words: "I use AI tools daily." Answer slot: the JD's AI line makes a "which tools, for what" probe likely. She names the tools and the work she uses them on, in her own words. If none of that touches an AI product, she says so |
| F7 | Seam with Dan's function: "Director of Sales Strategy at Northwind — he would be Priya's PEER, both reporting to the same VP" — your message | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | This is a stated absence, and wording cannot close it. Words: "I haven't done classic sales-ops or quota-setting work." After that, how she would learn it, said as a plan and never as a past. Have Priya confirm she'd phrase it this way, since the sentence is yours, not hers |
| F8 | Role context: "B2B data-infrastructure SaaS" — your message | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material shows consulting plus consumer-tech product strategy, and says nothing about selling B2B data infrastructure. Words: the career line at its own scope. Answer slot: if any of her consulting or consumer-tech work involved business buyers or enterprise partners, she says what and in what role. If none did, she says so and points to what does carry over: F4's partner model and F3's analysis |

---

## Reading the interviewer

Everything below about Dan comes from the summary of his profile in your message. The web searches that would have checked it and added his public talks or posts were refused (see Sources).

| Signal (source) | Provenance | What it changes in this pack |
|---|---|---|
| Director of Sales Strategy, Priya's peer under the same VP — your message | [grounded] | He is weighing what Priya would add to or take from *his* team's work. Peer Evaluator is the top persona. Reciprocity framing (what she brings him, not only what she needs) runs through bank A and the reverse questions |
| Self-describes as "relentlessly data-driven" — your message, from his profile | [grounded] | Every number she says will be probed for inputs and assumptions. The Prober persona is pushed up, and the ~$400M figure gets two dedicated questions (B1, B2) |
| Career spine in pricing and monetization — your message | [grounded] | The live cases lean toward packaging, pricing, and unit economics (C1, C2), because that is his native language. A packaging answer with no pricing logic will feel thin to him |
| One early-stage-startup chapter — your message | [grounded] | Expect scepticism about big-company pace and a "scrappiness" probe (G2). Builder stories land well. Reverse question R6 connects to this chapter |
| Mirror opportunity, shared vocabulary rather than a shared career jump: revenue modelling. F4's evidence reads "built a partner-level revenue model used in carrier negotiations" | [inferred] | She can talk about that model in revenue and pricing terms. That is common ground with a monetization career, as long as she describes what the model was and not what it proves. There is no shared career jump in the material, so none is offered |

---

## Persona table

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | "Where's the seam between us?" "What would you need from my team?" Credit-sharing and conflict scenarios. Objections from other banks come back in a friendly tone | **High.** Peer is the baseline for this relationship, and sharing a VP makes the seam real for him. 5 questions | Frame what she brings him as well as what she needs. Propose principles for the seam rather than claiming to know how Northwind works today. Bring disagreement stories that show spine and tact together |
| Data-Driven Prober | "How was that counted?" "What was the denominator?" Goes two levels deeper than her answer | **High.** Peer interviewers probe competence, and his profile line ("relentlessly data-driven") raises it further. 5 questions | Before the interview, know exactly what she can and cannot say about how the ~$400M was counted, and say plainly if she doesn't know. Name her own weakest assumption before he does. Offer to walk through an analysis she did herself |
| Case / Strategist | Live problems from Northwind's stated priorities: Compass GTM, bundling defence, expansion vs. profitability | **Medium.** Not the default for a peer, but your research note gives him obvious material and his pricing background pulls cases toward packaging. 4 questions | Clarify, then state the objective, segment, approach, metrics, and risks. Think out loud. Respectfully challenge one premise per case |
| Skeptic | Quiet, persistent probing of F7 and F8: no quota-setting and no B2B, in front of the person whose job *is* sales strategy | **Medium on frequency, top on stakes.** F7 sits squarely in his own field, and his startup chapter adds a pace objection. D1 is the highest-ROI rehearsal in the pack. 4 questions | Rehearse D1 until it is boring. Use only bridges her notes actually support, and state the limits plainly. Have a concrete plan for ramping up. Never bluff the skill he owns |
| Pressure | Rare from a peer. It mostly appears as a Prober follow-up delivered sharply | **Low.** Peers seldom stress-test, but "how much was actually you" is a natural follow-up to the ~$400M. 2 questions | Pause and restate the question. Anchor in what she actually stated. Hold through two follow-ups, then concede specifically |
| Conversational | Opening "walk me through your journey" and a casual "what are you doing with AI?" | **Low but scored.** It's the default opener, and AI is a JD plus that gets asked casually. 2 questions | Have a scripted 90-second arc. Treat the casual AI question as scored |
| Values / Behavioural | Lightly behavioural: an unpopular truth, moving fast | **Low.** Your note names no values round, and Northwind's published values could not be retrieved. 2 questions | Use her own stories with "we" for context and "I" for her contribution. Where no story fits, say so rather than inventing one |

---

## Question banks

**Highest-ROI prep in this pack: D1**, the "no quota-setting" objection. It will come up in some form, because it sits inside Dan's own function.

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams would sit side by side under the same VP. Where do you see the seam between Sales Strategy and this role, and what happens when we disagree?" | CASE, JD | [generic] | Don't pretend to know the seam. Propose principles: (1) one shared number per product, owned by whoever owns capacity and comp; (2) this role brings the new-product view into that number, it doesn't build a parallel one; (3) disagreements are resolved in a shared model before going to the VP. Then ask him where it breaks today. Close with what she would give his team, such as analysis on new-product attach | This is the likeliest peer opener, because his own scope depends on the answer. CASE because it asks about the future, not her past. JD because it scores the "cross-functional influence" line |
| A2 | "Tell me about a time you got a number agreed across orgs that didn't all want the same thing." | JD, EXP | [grounded] "set annual volume targets with cross-org consensus" | Story mapped on F5. Beats the quote supports: she set them, they were annual volume targets, and the result was cross-org consensus. Tell it in her own words. Answer slot: the JD's influence line makes a probe on where the orgs disagreed likely. If they did, she says what the disagreement was and which part of moving people was hers. If they didn't, or it wasn't hers, she says so plainly and describes how the targets were set | F5 is her strongest evidence for influence, and it is also closest to Dan's world of targets. JD first because it scores a stated requirement, EXP second because he will test what was hers |
| A3 | "How do you handle credit when work spans two teams?" | VAL, EXP | [generic] | Selection scaffold: pick a cross-team piece of work where she can say clearly what was hers and what was others'. It needs a named partner team, a clear split of contribution, and a relationship still intact afterwards. Use "we" for context and "I" for her part. If no such time comes to mind, she says so plainly, gives the nearest example her experience does carry, or explains how she would handle it with Dan's team | Credit is the classic peer probe, and with a shared VP it is a live concern for him. VAL because it scores behaviour. Northwind's values weren't retrieved, so this is a pattern, not a values-mapped question |
| A4 | "What would you need from my team in your first 90 days, and what would we get from you?" | JD, CASE | [grounded] "skilled in SQL/Tableau" | Reciprocity first. The quote supports saying she works in SQL and Tableau herself, so she can promise to run her own analysis rather than join his analysts' queue. Then what she would need: his team's planning calendar, how quota and capacity are built, and access to pipeline and usage data. Then one thing she could deliver for his team early, framed as an offer. No claims about past work beyond the quote | He is calculating the effect on his team's workload. F3 turns her analytical independence into a direct benefit to him. JD because "run independent analysis" is a stated requirement |
| A5 | "Partner deals tend to create channel conflict with direct sellers. How would you design a partner motion for a new product line that my sellers won't fight?" | CASE, JD | [generic] | Structure: which partner type (resell, referral, embedded, or the bundling platform itself), what the partner gets versus what the seller gets, and the rules of engagement (deal registration, account ownership, comp neutrality or overlay). Then measures: partner-sourced vs. influenced pipeline, conflict escalations, and margin. Don't use this question to claim partner-design experience. That is D3's ground | "partner-motion design experience required" is the JD's one hard requirement, and Dan's sellers carry the cost of a bad design. CASE because it asks for a design, not a history |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You proposed a store-surface change credited with a ~$400M ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Beats the quote supports: she *proposed* the change, and the change was *credited* with about $400M ARR uplift. She keeps both verbs and never says "drove" or "delivered." Answer slots raised by the figure: how it was counted, in her own words, or a plain "I don't know exactly how it was counted"; what the figure is sensitive to; and which part was hers. The proposal is what the quote supports. If more of the work (analysis, build, rollout) was hers, she says which. If not, she says so and stays with the proposal | This is her headline number, in front of someone who calls himself "relentlessly data-driven." The defend-the-number rule requires it. EXP because it tests attribution and counting, which is what he scores |
| B2 | "Which assumption behind that ~$400M would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Weakest-assumption move: she names it first, in her own words, before he finds it. The pack doesn't name one because her notes don't. If she doesn't know how the figure was built, she says so plainly, then says what she would check first. That is an honest answer, and it beats a confident method she can't repeat when asked again | A self-described data-driven interviewer goes two levels deep, and this is level two. Naming the weak point yourself turns a gotcha into credibility |
| B3 | "Walk me through the partner-level revenue model you built for the carrier negotiations." | EXP, JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote supports: she built it, it was partner-level, it was a revenue model, and it was used in carrier negotiations. Answer slot: the JD's SQL and Tableau line makes a probe on how it was built likely. If she built it in those tools or another, she says how, in her own words. If not, she says so. Answer slot: the JD's partner-motion line makes a probe on whether the model shaped partner terms likely. If it did, she says how and which part was hers. If it informed negotiations someone else led, or shaped no terms, she says so plainly and stays with the model | F4 is her best evidence toward the one *required* item, and it is in Dan's pricing and monetization vocabulary. EXP because he will test what the model was. JD second because of the partner requirement |
| B4 | "Say you had our customer data. How would you find whitespace for a new product across land, adopt, expand, and renew? Which tables, which cuts?" | CASE, JD | [generic] | Structure it live. Grain: account by product by lifecycle stage. Signals: product usage depth, seats or consumption against entitlement, attach of adjacent products, renewal date, firmographics. Cuts: who looks like current adopters but hasn't bought, who is under-penetrated at renewal. Output: a ranked list that sales can act on, built in SQL, shown in Tableau. Name the data-quality risk (account hierarchies, usage-to-account joins). Makes no claim about her past | F2 has no evidence behind it, so this is where she shows the method live instead. CASE delivery of JD content, and Dan can test it hands-on |
| B5 | "Tell me about an analysis you ran yourself, end to end: the question, the data, and what changed because of it." | JD, EXP | [grounded] "skilled in SQL/Tableau" | The quote supports only that she is skilled in SQL and Tableau. The story has to come from her. Selection scaffold: an analysis she ran herself, with a business question, data she pulled, and a decision it changed. If no such analysis comes to mind that she can describe in detail, she says so plainly, then gives the nearest example her experience carries or describes how she would approach the first one here | "run independent analysis in SQL and Tableau" is a stated requirement, and F3 is a self-description he will want to see backed up. JD first, EXP second |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is our AI copilot launch. Sketch the GTM: who buys first, how it's packaged and priced, and what you'd measure in the first two quarters." | CASE, CO | [grounded] | Clarify: is it sold separately or bundled into existing plans, and who is the buyer? Ask rather than assume. Objective: tie it to the stated priorities of enterprise expansion and profitability. Segment: start with existing customers by usage depth, because it's an expand motion before it's a land motion. Packaging and pricing (his native language): included tier, per-seat add-on, or usage-based, with one trade-off stated for each. Metrics: attach rate, weekly active use, expansion ARR, and gross margin net of AI running costs. Risks: the bundling vendor and cannibalising existing tiers. Challenge one premise | Compass is one of the three priorities in your research note, and Dan's pricing background makes a packaging case likely. CASE delivery, CO content. Grounded on your note, which this pack could not check for freshness |
| C2 | "A much larger platform vendor is bundling something close to what we sell. How do you defend a new product line against that?" | CO, CASE | [grounded] | Concede the hard part first: bundled-and-free wins buyers who only need "good enough." Then: find where depth matters (segments and use cases where the bundle falls short), price on a value metric the bundle can't match, consider partnering with the platform rather than only fighting it (a partner-motion angle), and first identify the customers most at risk (the SQL work from B4). Ask him one question: is the bundle actually costing deals, or only causing price pressure? | Your research note names bundling as the main competitive threat, so a strategy-literate peer is likely to raise it. CO first because it scores competitive fluency |
| C3 | "Enterprise expansion and getting to profitability can pull against each other. If you could only fund one new-product motion first, how would you choose?" | CO, CASE | [grounded] | State a decision rule out loud: rank motions by payback and contribution margin, then adjust for strategic value (does it protect against the bundle, does it feed expansion?). Say what data would change her mind. Ask what tiebreaker the VP uses. Pick one; don't sit on the fence | It sets two of the three stated priorities against each other. A peer who shares the VP will want to know whether she can make that call. CO because it tests thinking at company altitude |
| C4 | "Your targets for a new product and sales' capacity plan disagree by 30%. Walk me through how we resolve it." | CASE, JD | [generic] | Diagnose before negotiating: break each number into its assumptions (conversion, ramp, attach, deal size) and find which one accounts for the gap. Reconcile in one shared model, then escalate to the VP only the assumption that can't be settled. Don't claim to know Northwind's planning process. Ask how it runs today | This is the exact seam where F7 lies, framed as a problem rather than a history. CASE, with JD second for "cross-functional influence" |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales ops or quota setting, and this role sits right next to sales strategy. Why should I believe you can set GTM targets sellers will actually carry?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal in this pack.** Open with the plain acknowledgment, once, without apology: "I haven't done classic sales-ops or quota-setting work." Then the adjacent fact at its own scope: "I set annual volume targets with cross-org consensus." She says what it was, not that it was quota-setting by another name, and lets him draw his own inference. Then the plan, said as a plan: learn how his team builds capacity and quota, and ask to sit in on the next planning cycle. **Follow-up 1, "volume targets aren't quotas":** concede fully, "Agreed, it's a different thing," and stay with the quote. **Follow-up 2, "so who owns the Compass number?":** propose a principle (whoever owns capacity and comp owns the number sellers carry, and this role brings the new-product view into it), then ask how it works at Northwind today. **Follow-up 3, "wouldn't a sales-ops hire be safer?":** hold on the JD's scope, "own GTM strategy for two new product lines," not on a claim about herself, and concede that someone from sales ops would ramp faster on quota. Answer slot: the JD's land/adopt/expand/renew line makes a probe on targets by motion likely. If any of her volume targets were set by motion, she says how, in her own words. If not, she says so plainly and stays with the targets she set | F7 is a stated gap, and it sits in Dan's own field, so the objection is close to certain and he is the one person who can't be bluffed. JD because it scores the role's fit to its seam. It gets three follow-up levels and exact concession wording because that is where the material is thinnest |
| D2 | "I don't see B2B in your background. How does consumer-tech product strategy translate to selling data infrastructure?" | JD, EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" | She keeps the career line at its own scope. The carrier quote supports that her revenue model was used in negotiations with carriers. She says that, not "so I've done B2B." Answer slot: if any of her consulting or product work involved business buyers or enterprise partners, she says what and in what role. If none did, she says so plainly. Then what carries over, stated without spin: the partner model and the analysis. Then how she would close the gap: shadowing deals and customer calls in the first month | F8 is the second-most-predictable objection. JD first because it is about fit for the role. EXP second because he will check the career line |
| D3 | "The JD says partner-motion design is required. A model used in negotiations isn't designing a motion. What partner motion have you actually designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote supports: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of the partner structure, terms, or programme was hers to design, she says which and how she decided. If none was, she says so plainly. That limit is not a confession. She returns to the model and offers to show live how she would design one (A5). She holds through two follow-ups by coming back to the model, never by adding to it | F4 bridges to the only requirement the JD marks as required, so the gap will be pushed on. JD because it scores that requirement directly |
| D4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Choose an honest, real weak spot. The one her material supports is F7: "I haven't done classic sales-ops or quota-setting work." Then the ramp plan from D1. If she would rather name a different weak spot, it must be a real one in her own words, not a disguised strength. Keep it under 60 seconds | A standard Skeptic stem. A rehearsed, sourced answer stops it turning into a second D1. JD because it scores self-assessment against the listed job |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's run sales ops at a SaaS company?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" "built a partner-level revenue model used in carrier negotiations" "No classic sales-ops or quota-setting experience." | Pause, then three beats, each at the scope of its quote: she proposed a change credited with about $400M ARR uplift; she built a partner-level revenue model used in carrier negotiations; and the concession, "I haven't done classic sales-ops or quota-setting work, so on quota they'd start ahead." Close on the JD's own scope, strategy for two new product lines. **Hold-then-concede:** if he pushes twice, hold the same three beats. Concede specifically on quota, never on the core claims | Timed comparisons with an imagined rival are a natural way for a peer to press F7. JD because it scores fit. The concession is built in so she doesn't fold to restore the mood |
| E2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change, and the uplift was credited to it." **Hold-then-concede:** through two follow-ups she keeps "proposed" and "credited" exactly. Answer slot: if she did more (the analysis behind the proposal, the build, the measurement), she says which. If others did that work, she names that plainly as theirs. Conceding that others shipped and measured it strengthens the claim | It is the attribution follow-up to B1, often delivered sharply. EXP because it tests what was hers |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc: consulting, then nine years in product strategy and ops at a consumer-tech company, then why this role. Answer slot: why B2B data infrastructure, and why now. Your notes don't state her reason, so it has to be hers, in her own words, and specific to Northwind's emerging products. End on what she wants to build here, not a recap | The near-certain opener, and casual answers still count. A tight arc frames the rest of the hour. EXP because it opens her history for probing |
| F2 | "What are you actually doing with AI these days?" | JD, CO | [grounded] "uses AI tools daily" | The quote supports only that she uses AI tools daily. Answer slot: the JD's AI line makes "which tools, for what" likely. She names the tools and the work, in her own words, including how she checks their output if she does. She never implies AI product experience. Then a pivot she can make honestly: what using them daily makes her think about how Compass is bought and adopted, offered as a view, not a credential | "AI experience a plus" usually gets asked casually, and Compass makes it current. JD first, CO second because the strong answer connects to the launch |

### G. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a time she told senior people something they didn't want to hear. It needs a named stake, the moment she didn't back down, and the truth actually landing. Use "we" for context and "I" for her part. If no such time comes to mind, she says so plainly, then gives the nearest example her experience carries or explains how she would handle it. She does not recast the store-surface proposal as contested unless it was | A standard behavioural probe, and a peer will want to know she'll push back on the shared VP. VAL. `[generic]` because Northwind's values weren't retrieved |
| G2 | "Big companies can be slow. Tell me about a time you moved fast on incomplete data." | VAL, EXP | [generic] | Selection scaffold: a decision she made or pushed for before the data was complete. It needs what was missing, why waiting cost more, and how she limited the risk. If no such time comes to mind, she says so plainly, then gives the nearest example or describes how she would move fast on a new product line here | This is the scrappiness probe his startup chapter predicts, aimed at her nine years at a large company. VAL first, EXP second |

### Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| "own GTM strategy for two new product lines" | F1 | C1, C3, E1, D1 (follow-up 3) |
| "identify whitespace across land/adopt/expand/renew" | F2 | B4, D1 (answer slot) |
| "run independent analysis in SQL and Tableau" | F3 | B5, B3, A4 |
| "partner-motion design experience required" | F4 | D3, A5, B3, C2 |
| "strong cross-functional influence" | F5 | A2, A1, C4 |
| "AI experience a plus" | F6 | F2, C1 |
| Seam with Sales Strategy (your note) | F7 | D1, D4, E1, C4 |
| B2B data-infrastructure context (your note) | F8 | D2, F1 |

Total: 24 questions.

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "What could someone in this role do in their first month that would genuinely help your team?" | The reciprocity question. It answers his real concern (does this hire add to my load or reduce it?) before he raises it |
| R2 | "You've spent your career in pricing and monetization. How is pricing and packaging for Compass being decided, and where does your team sit in that?" | It's tied to his own career path and draws on his expertise, and it shows she researched him, not only the company |
| R3 | "Where does the handoff between Sales Strategy and the emerging-products work break most often today?" | It shows she is thinking about the seam from his side. His answer tells her what A1 should have said |
| R4 | "With bundling pressure from the larger platform vendor, where are deals actually being lost: price, packaging, or something else?" | Grounded in your research note, and it invites the data he likes. It's also the question she'd want answered for C2 |
| R5 | "How do you expect the VP to judge this role at twelve months?" | Peers usually know the unwritten scorecard. Asking shows she is calibrating, not assuming |
| R6 | "You've worked at an early-stage startup. What from that would you want new product lines here to have more of?" | Tied to his startup chapter. It turns the pace objection into a shared conversation instead of a probe |
| R7 | "When enterprise expansion and profitability point different ways, how does the call actually get made?" | It tests how decisions really get made against the stated priorities, and his answer is useful context for C3 |

---

## Prohibited claims

What this pack will not coach, and why. All of these were built from the fit snapshot because no dossier was available.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove or delivered $400M ARR | Inflated form of F1 | F1's quote at its own scope: she proposed the change, and the uplift was credited to it. The material does not say she delivered it. Any further role is the B1 and E2 answer slot |
| Owned go-to-market strategy | Inflated form of F1 | F1's quote at its own scope. The material shows a proposal, not ownership of a go-to-market. F1's slot stays inside the proposal |
| Designed a partner motion or partner programme | Inflated form of F4 | F4's quote at its own scope: she built a partner-level revenue model used in carrier negotiations. D3's slot asks only which parts of the structure, if any, were hers |
| Led or ran the carrier negotiations | Inflated form of F4 | F4's quote at its own scope: the model was *used in* negotiations. The material doesn't say who led them |
| Has set sales quotas or done sales ops | Negative stated in the coach's notes, F7 | The plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." No slot |
| Has AI product or AI go-to-market experience | Inflated form of F6 | F6's quote at its own scope: she uses AI tools daily |
| Has B2B or enterprise SaaS experience | Inflated form of F8 | F8's quote at its own scope: consulting plus consumer-tech product strategy and ops. D2's slot stays inside that work |

Whitespace across land/adopt/expand/renew (F2) is not on this list. The material is silent on it rather than stretched, so it is handled by an answer slot.

---

## Sources

**Provided documents:** your message, which contained the JD highlights, the candidate background (quoted as "the coach's notes"), the interviewer profile summary, and your research note on Northwind's three stated priorities and its main competitive threat. No dossier was present.

**Searches sent:**

- `"Northwind Data" company values`: refused
- `"Northwind Data" interview process strategy`: refused
- `"Northwind Data" Compass AI copilot launch`: refused
- `"Dan Kovac" "Northwind Data"`: refused

**Fetches sent:** none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Refused. It would have supplied official value names to theme bank G and A3. There is no values cheat sheet either way, because your note names no values round |
| 2. `Northwind Data interview process` | unavailable | Refused. Your note already establishes this session, so it would only have confirmed or contradicted the format and persona weights |
| 3. `Northwind Data strategy` / recent news | unavailable | Refused. It was a check that your research note is current. C1–C3, R4 and R7 rest on that note as given |
| 4. `Dan Kovac Northwind Data` | unavailable | Refused. It would have checked your profile summary and added any public talks or posts to the interviewer read and the reverse questions |
| 5. representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** (all four searches were refused): Northwind's official values to theme bank G, a check that your research note is current, and Dan's public talks or posts for a sharper interviewer read and reverse questions.
- **Deep research pass** (up to 6 more searches and 2 more fetches, several more minutes, run only if you want it): a strategy brief on Northwind's financial trajectory, the competitive set, and recent moves. That adds a grounding brief section and sharper C1–C3.
- **Full JD text**: catches mid-list requirements (named tools, methods, metrics) that the highlights may leave out, each of which would get its own question and fit row.
- **Recruiter or HR guidance** (usually one email): any focus areas or deliverable announced for this conversation, which would get its own build section.
- **Prep time available**: a prioritised prep schedule sized to the time Priya actually has.
- **Priya's own answers to the slots**, in her words: how the ~$400M was counted and what was hers, whether the revenue model shaped partner terms, any whitespace or expansion analysis, any B2B exposure, and her reason for moving to B2B. These would upgrade B1, B2, B3, D2, D3, E2, F1 and fit rows F1, F2, F4 and F8 from slots to mapped stories.
- **Priya confirming the coach's-notes wording**, especially "No classic sales-ops or quota-setting experience." This lets D1, D4 and E1 use her own phrasing.
- **An inspectable artifact** for the two headline items: a sanitised write-up or deck of the store-surface proposal or the partner revenue model. That would raise F1 and F4 from `medium` toward `high`.
- **A `tuesday-dossier.md` from a job-underwriter pass**: an objection derived from verified evidence instead of inferred, verified claims, and an underwriter-built list of prohibited claims. Useful, not required.
