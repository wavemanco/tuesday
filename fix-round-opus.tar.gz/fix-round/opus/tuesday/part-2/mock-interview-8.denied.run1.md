Quick update: I've read the interview-prep playbook. I'm now writing your pack as a three-round plan for 21 November.
I've saved your prep pack as `ashgrove-credit-union_member-experience-lead_interview_pack.md` in your working folder. There's a separate section for each of the three rounds on 21 November, using the recruiter's description of each one.

- **What to rehearse most:** question C1 in the Head of Member Services round. It's the likely challenge "this role covers every branch and the contact centre, and you've handled one branch's complaints log." The pack gives you an answer you can hold through two follow-ups, based only on what you told me.
- **Your two gaps:** you've never worked in a contact centre, and you haven't presented above regional level. The pack gives you a short, plain way to say each one, followed by a plan, so neither turns into an excuse or a bluff.
- **The 20-minute case:** there's a timed structure that uses the four values as decision points, which makes it easy for the panel to score you against them.
- **The values round:** none of your four sentences describes a specific story for a value. So the cheat sheet tells you what kind of story to pick for each one, plus an honest fallback if nothing comes to mind.
- **Research:** I didn't do any. Your pasted values, the recruiter's email, the July strategy brief and the JD already covered everything a search would have found.

Say the word and I'll play the Skeptic on C1 as a live drill.
I can also save a tuesday-dossier.md recording the gaps this prep found, so you can carry it into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date:** 21 November 2026, three rounds on one day
**Round 1:** Recruiter, 30 minutes
**Round 2:** Head of Member Services (your future manager), 45 minutes, mostly behavioural
**Round 3:** Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case; this is the values round, scored against the four values
**Interviewer names:** not yet assigned

Mode: loop. One shared fit snapshot and sources block, then a mini-pack for each round with its own persona weights, questions and reverse questions. The round structure comes from the recruiter's email, so the persona weights rest on Ashgrove's stated process, not on a guessed pattern.

---

## How to use this pack

Two axes. **Personas** describe how a question is asked: the style, register and pressure. **Types** describe what is being scored. Rehearse both. The same complaint question sounds very different as a friendly aside from the recruiter and as a quiet "help me understand" from your future manager.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's four published values, not generic virtue |
| EXP | Whether what you say about your experience holds up, and exactly which part was yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs are lettered by persona (A, B, C, D, E, G, H, J, K) so the drill can refer to them. F1 to F10 are rows of the fit snapshot.

**An answer slot** is an instruction for the interview, not a question for you to answer here. It names what the interviewer is likely to probe and gives you two honest branches. Answer whichever branch is true, in your own words.

The guidance is scaffolding, not a script. Every sentence about your past rests on one of the four sentences you wrote to me, quoted in the Provenance column. If a guidance cell ever seems to say more than your sentence does, trust your sentence.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Expect a probe, because nothing beyond your own sentence has been inspected. Say it exactly as you wrote it: six years in retail banking, the last three as a branch supervisor. Keep the title exact, and leave the JD's phrase "customer operations" for the interviewer to match |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says the branch's formal complaints log. It does not say whether those complaints came under regulatory rules. Words: "I handled the branch's formal complaints log." Answer slot: because the JD says "regulated complaints", a probe is likely. If the complaints on that log were handled under regulatory requirements, say which ones and what your part was, in your own words. If they weren't, or that part sat with someone else, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's log, not a process across branches, and your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: "end to end" makes a probe on the steps from first contact to closure likely. For the complaints on that log, if any of those steps were yours to decide, say which and how you decided, in your own words. If they weren't yours, say so plainly and describe how you handled the log |
| F4 | "…and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this gap and wording cannot close it. Words: "I haven't worked in a contact centre." Then say how you would learn it, as a plan and never as something you've done. Never claim contact-centre experience, and add nothing to make the gap look smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says you built a monthly complaints spreadsheet and that your regional manager uses it. It does not say what the spreadsheet measures. Answer slot: if it tracks volumes or resolution times, say how each is counted, in your own words. If it doesn't, say so plainly and say what it does track. "I built" stays "I built" |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence doesn't name the tool, so the link to Excel is the pack's inference. Answer slot: if you built it in Excel, say which parts you built and what it shows, in your own words. If you used another tool, name it plainly. Never name an Excel feature you haven't used |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes training new tellers on a script, not coaching supervisors. Words at that scope: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you trained likely. If you shaped the training, such as what you covered or how you checked it had landed, say so in your own words. If you delivered it as it was set, say so plainly and describe the training you gave |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this gap. Words: "I haven't presented to anyone above regional level." Then describe a plan for building the skill, said as a plan, never as a past. Never claim a senior audience |
| F9 | "confident presenting" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | low | [inferred] | discovery | Your sentence sets an upper limit and leaves open what sits below it. The pack does not assume you have presented at regional level. Answer slot: if you have presented, at branch or regional level, say to whom and on what, in your own words. If you haven't presented formally, say so plainly |
| F10 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't cover this. Answer slot: if you have worked on any digital or self-service change, at your branch or with a digital team, say what your part was, in your own words. If you haven't, say so plainly and answer as a plan for how you would work with those teams |

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter announced this, so it is scored. Prepare a structure, not a script, because you won't know the scenario until the day.

**Grounded facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| The role owns the member complaints process end to end across branches and the contact centre, and coaches branch supervisors on escalations | JD | [grounded] |
| The panel scores against Members First, Always; Plain Words; Neighbours, Not Numbers; and Own the Fix | Recruiter email; values page as pasted | [grounded] |
| Eight branches are being consolidated into five hubs over 2027, and 40% of member service is moving to digital by 2028 | Strategy brief, July 2026 | [grounded] |
| Your anchor if asked what you've done: F2, "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Fit snapshot F2 | [grounded] |

**A 20-minute structure** `[generic]`. This is a pattern for escalation cases, not Ashgrove's process.

1. **Clarify (about 2 minutes).** What happened, who the member is, what they want, and what has already been said to them. Ask before you structure.
2. **Members First: contain it (about 3 minutes).** What the member hears today, from whom, in plain words.
3. **Own the Fix: who keeps hold of it (about 5 minutes).** Name the one person who owns the case until it is closed, how the branch supervisor stays involved if it moves centrally, and what gets checked. Wherever a regulatory timeline or rule applies, say you would confirm the requirement. Don't quote a number you're unsure of.
4. **Root cause and reporting (about 4 minutes).** Is this a one-off or a pattern? How does it show up in the monthly complaint volumes and resolution times the JD asks for?
5. **Plain Words and Neighbours: the reply and the branch (about 3 minutes).** The final reply as you would word it, and what the branch and its town hear.
6. **Close (about 1 to 3 minutes).** Name which value drove each decision. The panel is scoring against them, so make it easy.

**Theses to choose from (pick one and keep its concession)**

| Thesis | Mandatory concession | Provenance |
|---|---|---|
| An escalation is solved only when the member has understood the outcome and the cause has reached the monthly report | For a simple complaint this adds work. Speed can matter more than analysis, and you would say where you would draw that line | [generic] |
| Whoever first found the problem keeps hold of it, even after specialists take over some steps. That is Own the Fix applied to escalation | Ownership doesn't mean doing every step. Some steps belong with people who hold authority you don't | [grounded] — the value's own words |
| Ask whether the hub move or the digital shift played a part | It may have played no part, and the case shouldn't become a critique of the strategy | [grounded] — strategy brief |

**Standing out.** The answer most prepared candidates give is apologise, escalate, resolve, follow up. Use it as your skeleton, then do two things they won't: name the values at each decision point, and feed the case into the reporting loop.

**What not to do.** Don't promise redress or an outcome before you have the facts. Don't send the member to the app as the fix: the strategy moves service to digital, but the case is about this member.

---

## Grounding brief

Built from the documents you supplied. No research was run (see Sources).

| Item | Detail | Source | Provenance |
|---|---|---|---|
| Ownership and size | Member-owned, about 900 staff | JD | [grounded] |
| Digital shift | 40% of member service moved to digital channels by 2028 | Strategy brief, July 2026 | [grounded] |
| Branch footprint | Eight branches consolidated into five hubs over 2027 | Strategy brief, July 2026 | [grounded] |
| New product | Small-business lending launches in Q1 2027 | Strategy brief, July 2026 | [grounded] |
| Competition | App-only banks are the main competitive pressure | Strategy brief, July 2026 | [grounded] |
| Vocabulary | "Members", never "customers"; "hubs"; "member's side of the counter"; "Own the Fix" | JD, values page as pasted, strategy brief | [grounded] |
| Sensitivity | Both Round 3 panelists are branch managers, and the plan consolidates branches. Talk about hubs as a change members and staff live through, not as a number | The panel make-up from the recruiter email, plus the strategy brief; the advice is the pack's own reasoning | [inferred] |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre (F3, F4) | B1, C1, K2, case build |
| Report monthly on complaint volumes and resolution times (F5) | G1, G2, E1 |
| Coach branch supervisors on escalations (F7) | C3, D3, J2, K1 |
| Work with digital teams on self-service journeys (F10) | E2, A5 |
| 4+ years in financial-services customer operations (F1) | A1, A3 |
| Regulated complaints experience (F2) | B2, D1, case build |
| Confident presenting to senior leaders (F8, F9) | B3, C2 |
| Excel reporting (F6) | A4, G1 |
| Strategy (grounding brief) | A5, C4, E1, E2, J1 |

---

# Round 1: Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers, "walk me through it", motivation | High (5 questions). A recruiter screen leans on rapport, and the friendly tone is still scored | A rehearsed 90-second arc built only from your four sentences. Treat casual questions about the JD as scored |
| Skeptic (light) | Knockout checks against the JD's requirements | Medium (3 questions). Recruiters screen against the requirements list, and F4 and F8 are gaps you have stated | Plain acknowledgment, then a plan. Never bluff a requirement |

### Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP, JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, three beats, each one a sentence you wrote: six years in retail banking with the last three as a branch supervisor; the complaints log and training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. Close with one sentence, in your own words, on why this role | F1, F2 and F3 between them carry the role's core. The opener sets the frame every later round inherits. EXP because it is your story, JD because the years requirement is checked here |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | The reason has to be yours, so the pack won't supply one. Anchor it in something Ashgrove has published: "member-owned" from the JD, or one value by its official name. Then say in your own words why it matters to you | A standard recruiter check on motivation. CO because it tests whether you've read what Ashgrove says about itself |
| A3 | "What's drawing you from branch supervision into a central role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Use your own words, framed as moving toward something: owning the complaints process across Ashgrove. Don't run down branch work. Round 3 is two branch managers, and the recruiter may pass on what you say | F1 is the move being asked about. EXP because the premise is your own title |
| A4 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD names Excel. If you built it in Excel, say which parts you built and what it shows, in your own words. If you used another tool, name it plainly. Never name an Excel feature you haven't used | F6 is a likely checkbox question at the screen. JD because it is a stated requirement |
| A5 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name two items in the brief's own words, for example the 40% digital target by 2028 and the eight branches becoming five hubs over 2027. Link one of them to the role as a question you'd want answered: how complaints change when service moves to digital and hubs. Don't recite all four | The strategy brief came from the recruiter, so they may check you read it. CO by definition |
| B1 | "The role covers the contact centre too. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't worked in a contact centre." Then a short plan, said as a plan: how you would learn the contact centre's complaint flow in the first weeks. Stop there and don't over-explain | F4 is a stated gap against a stated scope. A short, calm answer here keeps it from becoming a knockout |
| B2 | "The JD asks for regulated complaints experience. Tell me about yours." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with the log, in the sentence's words: you handled the branch's formal complaints log. Answer slot: if those complaints were handled under regulatory requirements, say which ones and what your part was, in your own words. If they weren't, or that part sat with someone else, say so plainly and stay with the log you handled | F2 is the requirement most directly tied to the role's title. JD because it is quoted from the requirements list |
| B3 | "The role presents to senior leaders. What's the most senior audience you've presented to?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if you have presented at branch or regional level, say to whom and on what, in your own words. If you haven't presented formally, say so plainly. Then describe a plan: how you would prepare for the first monthly report to senior leaders | F8 is a stated gap and F9 is open. Rehearsing the honest version early stops you overcorrecting later in the day |

### Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| What does the Head of Member Services most want this hire to change in the first six months? | Signals a focus on outcomes, and tells you what to bring forward in Round 2 |
| Will the 20-minute case be handed to me on the day as written material, or described aloud? | A fair process question, and it changes how you prepare |
| How is the values scoring done? Does each panelist score all four values? | Shows you took the values round seriously, and tells you whether to touch every value or go deep on a few |
| Do you know yet which branches the panelists run? | If you get names or branches, the panel round becomes much more specific (see the upgrade menu) |
| Is this a new role or a backfill? | Tells you whether you'd be building the complaints process or inheriting one |

---

# Round 2: Head of Member Services, 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of scope gaps | High (4 questions). A future manager buys capability and tests the gaps, and F3, F4 and F8 are the widest | Rehearse C1 until it bores you. Stay at the scope of your own sentences, say limits plainly, and offer a ramp plan |
| Values / Behavioral | "Tell me about a time…" questions on complaints and escalation | Medium (3 questions). The recruiter said this round is mostly behavioural, which moves this persona above the usual hiring-manager Case weight | Use "we" for context and "I" for your part. Use a selection scaffold where your material has no story |
| Data-Driven Prober | Questions on what the spreadsheet tracks | Low (2 questions). F5 is your one concrete reporting artifact, and the JD makes monthly reporting a core duty | Know what you can and can't say about how it is counted. "I don't know how that figure was counted" is an honest answer |
| Case / Strategist | Live problems drawn from the strategy | Low (2 questions). Hiring managers usually set live problems, but the recruiter's "mostly behavioural" lowers the weight | Clarify, then objective, segment, approach, measures and risks. Use Ashgrove's own vocabulary |

### Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role owns complaints end to end across every branch and the contact centre. Your experience is one branch's complaints log. Why should I believe you can run the whole thing?" | JD, EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | **The highest-ROI rehearsal in this pack.** Hold only what your sentences carry: "I handled the branch's formal complaints log, and I built the monthly complaints spreadsheet our regional manager uses." Before they press, name the limit: "I haven't worked in a contact centre." Answer slot: if the spreadsheet covered more than your branch, say what it covered, in your own words. If it was your branch's alone, say so plainly. **Follow-up 1**, "So you've never seen the contact-centre side": hold. Repeat the plain acknowledgment once, then give the plan in the future tense, for example sitting in on contact-centre complaint handling in the first weeks. **Follow-up 2**, "Then why not hire someone who has?": concede the specific point and keep the core. "Someone from a contact centre would know that side faster than me. What I've done is the branch's formal complaints log and the spreadsheet." Don't fold, and don't add anything | F3 and F4 together are the gap a future manager is most likely to press. Deepest rehearsal because some version of it will be asked. JD content, EXP delivery |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose a weakness you have actually stated: presenting. "I haven't presented to anyone above regional level." Then a concrete plan, said as a plan, for example asking to rehearse the first monthly report with your manager. One weakness, said plainly. No disguised strength | F8 is the honest answer, and the hiring manager is the person you'd be presenting with or for. A stem the Skeptic uses often |
| C3 | "You'd be coaching branch supervisors on escalations. What coaching on escalations have you done?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Stay at your sentence's scope: "I trained new tellers on our escalation script." Answer slot: if you shaped that training, such as what you covered or how you checked it had landed, say so in your own words. If you delivered it as it was set, say so plainly and describe the training. Then a plan for coaching supervisors, said as a plan | F7 is the transferability gap. The question invites you to widen tellers into supervisors, and the guidance holds the line |
| C4 | "Why move into a central role now, while Ashgrove is consolidating branches into hubs?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Your reason, in your own words. If the hub move is part of why the role interests you, say how. Don't present the move as escaping branch work, and don't comment on whether consolidation is right | F1 is the move, and the brief supplies the timing. CO because the question tests whether you've thought about the strategy's effect on people |
| D1 | "Tell me about a time you handled a complaint where the member was unhappy with the outcome." | VAL, JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a complaint from the log you handled where the member didn't get what they wanted. It needs the member's situation (anonymised), what you decided or passed on, what you told them and how, and what happened next. Use "I" only for your part. If no such time comes to mind, say so plainly, then describe how you handled the log, or how you would handle it | F2 is your only complaints material. A behavioural round almost always asks for the hard case |
| D2 | "Tell me about a time you found a problem and kept hold of it until it was fixed." | VAL | [grounded] | Selection scaffold, themed on Own the Fix. It needs a problem you found, the point where you could have handed it off and didn't, and the fix. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix is one of the four values and describes the role. Your manager may test it ahead of the panel |
| D3 | "Tell me about a time a teller brought you something the escalation script didn't cover." | VAL, JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a case where the script didn't fit. It needs what was missing, what you did, and whether anything changed afterwards. Answer slot: if you changed the script or the training as a result, say what, in your own words. If nothing changed, or that wasn't yours to change, say so plainly. If no such time comes to mind, say so plainly, then describe how you'd handle it | F7. The script is in your sentence, and coaching on escalations is in the JD |
| G1 | "Walk me through the monthly complaints spreadsheet. What goes in, and what comes out?" | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you built, in that sentence's words. Answer slot: the JD asks for volumes and resolution times. If the spreadsheet tracks them, say how each is counted and the counting rule you'd defend least, in your own words. If it doesn't track them, say so plainly and say what it does track. If you didn't set the counting rules, say so. If you don't know how a figure is counted, say "I don't know how that's counted" | F5 and F6 are the closest you come to the monthly reporting duty. EXP because a prober will go a level deeper than the headline |
| G2 | "How does your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you know how it's used, say what you've seen, in your own words. If you don't know, say so plainly and come back to what you built. Don't describe decisions it led to unless you saw them | F5. The premise is your own sentence, and the risk is filling in its impact |
| E1 | "Complaint resolution times are rising at branches about to merge into hubs. Where do you start?" | CASE, CO | [grounded] | Clarify first: which measure, counted how, since when, and at which branches. Segment by branch, complaint type and channel. Form hypotheses and test them rather than asserting them. Act on one thing this month and measure it. Close on Neighbours, Not Numbers: which members are waiting, not only the average. The question needs no claim about your past, so the guidance makes none | Combines the hub plan from the brief with the JD's resolution-time reporting. CASE delivery, CO premise |
| E2 | "We're moving 40% of service to digital by 2028. How should a member raise a complaint in a self-service journey?" | CASE, JD | [grounded] | Structure: where in the journey a member realises something is wrong, how they reach a person, how it's worded (Plain Words), and how complaint data reaches the digital teams. Answer slot: if you have worked on any digital or self-service change, say what your part was, in your own words. If you haven't, say so plainly and answer as a plan | F10 is silent, and the JD lists working with digital teams. This lets you think through it live |

### Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| Where do complaints get stuck today between the branches and the contact centre? | Goes to the main gap in your experience and shows you'll learn it first |
| What would a good first monthly complaints report to you look like? | Shows you'll meet the reporting duty on their terms. It also helps you plan for F8 |
| How do you expect the move to hubs in 2027 to change the complaints process? | Ties the role to the strategy, and it's a question your future manager actually owns |
| How do the digital teams use complaint data today? | Covers the self-service part of the role, where your material has no story |
| Do you expect the small-business lending launch in Q1 2027 to bring new kinds of complaints? | Shows you read the brief and are thinking ahead of the launch |
| What would make you say, in a year, that this hire worked? | Gives you their measure of success in their own words |

---

# Round 3: Branch-manager panel, 60 minutes (values round, with a 20-minute case)

The case build is in the shared section above.

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One probe for each published value | High (4 questions). The recruiter said the panel scores against the four values | Have one story or scaffold ready per value, using its official name. Make sure the hard part of each story actually happened |
| Case / Strategist | The 20-minute escalation case, plus follow-ups | Medium (the case build, plus 2 questions). The recruiter announced the case | The 20-minute structure above. Clarify before structuring, and use Ashgrove's words |
| Peer Evaluator | "What would you need from us?" and where your job ends and theirs begins | Low (2 questions). Panelists who are branch managers would be the people whose supervisors you coach | Frame it as what you bring their branches. Propose principles for the boundary rather than claiming to know how it works today |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Make decisions from the member's point of view | Selection scaffold. Nearest material is F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Pick a decision where the member's view outweighed what was easier for the branch. If no such time comes to mind, say so plainly, then describe how you'd handle it |
| Plain Words | If a member has to ask twice, the wording failed | Selection scaffold. Nearest material is F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Pick a time you reworded something so that it landed. If no such time comes to mind, say so plainly, then describe how you'd handle it |
| Neighbours, Not Numbers | Each branch belongs to its town | Selection scaffold. Nearest material is F1: "6 years in retail banking, the last 3 as a branch supervisor." Pick a time you treated a member as part of the community rather than as a case. If no such time comes to mind, say so plainly, then describe how you'd handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | Selection scaffold. Nearest material is F5: "I built the monthly complaints spreadsheet our regional manager uses." If building it was a fix for a problem you found, say what the problem was, in your own words. If it wasn't, say so plainly and pick another time you kept hold of a problem. If none comes to mind, say how you'd handle it |

### Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter, even though it was harder for the branch." | VAL | [grounded] | Selection scaffold. It needs a named stake for the branch, the decision, what the member experienced, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Members First, Always is a scored value and the panel will probe it by name. The theme uses the value's own wording |
| H2 | "Tell me about a time you had to re-explain something because it didn't land the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. The teller training is the nearest material: you trained new tellers on the escalation script. Answer slot: if part of that training didn't land the first time and you changed how you explained it, say what you changed, in your own words. If not, say so plainly and pick another time. If no time comes to mind, say how you'd handle it | Plain Words is a scored value. F7 is the nearest material |
| H3 | "Tell me about a time you treated a member as a neighbour rather than a number." | VAL | [grounded] | Selection scaffold. It needs a member, a moment where procedure pointed one way, what you did, and why the person mattered more. If no such time comes to mind, say so plainly, then describe how you'd handle it | Neighbours, Not Numbers matters most to branch managers going through consolidation. The theme uses the value's wording |
| H4 | "Tell me about a problem you found that wasn't strictly yours, and you kept hold of it until it was solved." | VAL | [grounded] | Selection scaffold. It needs where you found it, why it wasn't yours, the point where you could have let go, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Own the Fix is a scored value and is close to the job description itself |
| J1 | "A member complains that their branch is becoming a hub and nobody told them. What do you do?" | CASE, VAL | [grounded] | Use the case structure. Contain it with what the member hears today, in plain words. Decide who keeps hold of it. Treat the root cause as a communication gap for the whole town, not just this member. Then the monthly reporting. Name the values as you use them. Don't argue for or against the hub plan | Puts the strategy brief's consolidation in front of two branch managers, which is where it will feel most real |
| J2 | "Two branch supervisors handle the same escalation differently. How do you get consistency without taking away their judgment?" | CASE, JD | [grounded] | Structure: find out why they differ, agree what must be consistent and what can vary, coach on the reasoning rather than only the script, then check. No claim about your past is needed. If asked what you've done, stay with F7's sentence about training new tellers on the escalation script | F7. The JD's coaching duty, asked by managers of the supervisors you'd coach |
| K1 | "If you were in this role, what would you need from us, and what would our branches get from you?" | JD | [generic] | Answer the second half first: what you'd bring their branches, said as a plan. Then what you'd need: early sight of complaints and supervisors' time for coaching. Keep it two-way | A typical peer question. The panelists' branches would deal with you every week |
| K2 | "A complaint comes into my branch. Where does my job stop and yours start?" | JD | [generic] | Propose principles rather than claiming to know the current process: the branch keeps the member relationship, the lead keeps the process and the reporting, and under Own the Fix whoever finds it keeps hold of it. End by asking how it works today | F3. Boundary questions come up when the role sits between teams |

### Reverse questions for the panel

| Question | Why it lands |
|---|---|
| What could the new lead do in the first month that would genuinely help your branches? | Reciprocity, which is the question peers rate highest |
| How are your supervisors handling escalations today, and what would they want from coaching? | Goes straight to the coaching duty (F7) and lets them shape it |
| Which of the four values is hardest to live by when a complaint gets difficult? | Shows you see the values as decisions, not slogans, in the round that scores them |
| As the hub plans take shape, what are members in your towns raising? | Neighbours, Not Numbers, asked with care to the people closest to it |
| When a complaint is resolved centrally, how do you want to hear about it? | A concrete commitment on where your job meets theirs (K2) |

---

## Prohibited claims

This pack does not coach these claims, under any persona or follow-up:

| Not coached | Basis | Honest form |
|---|---|---|
| Ran or owned the complaints process across branches | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: your material describes the branch's log, not a process across branches. The F3 and C1 answer slots stay inside that log |
| Has contact-centre experience | Negative you stated, F4 | "I haven't worked in a contact centre." No answer slot |
| Has presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." No answer slot |
| Coached branch supervisors | Inflated form of F7 | F7's quote at its own scope. The C3 and D3 answer slots stay inside the teller training |
| Reports monthly to the regional manager, or owns regional complaint reporting | Inflated form of F5 | F5's quote at its own scope: you built the spreadsheet and your regional manager uses it. The G1 and G2 answer slots stay inside what you built |
| Branch manager, or managed the branch | Inflated form of F1 | F1's quote with the title exact: branch supervisor |

---

## Sources

**Provided documents:** the JD text; Ashgrove's values, pasted by you, copied on 12 November 2026 from ashgrovecu.org/about/values; the recruiter's email describing the three rounds; the July 2026 strategy brief as you summarised it; your background in four sentences. No dossier was present.

**Searches and fetches:** none sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The pasted values text, copied this morning, already fixes the values cheat sheet and the VAL themes |
| 2. Ashgrove interview process for member-services roles | skipped | The recruiter's email sets out all three rounds, the panel's values scoring and the 20-minute case, so the persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 strategy brief is under six months old and already supplies the CO and CASE material |
| 4. Interviewer names at Ashgrove | n/a | No interviewers are assigned, so there is nothing to search. The interviewer read is absent, and the upgrade menu says what names would add |
| 5. A representative JD for Member Experience Lead | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Interviewer names, once assigned → a section on each interviewer from their public professional footprint, persona weights for each panelist, and at least one reverse question tied to each person's career path
- How much prep time you have before 21 November → a prioritised prep schedule tied to question IDs
- Your answers to the answer slots, given here outside a drill → rows F2, F5, F6, F7, F9 and F10 move from slots to quoted evidence, and questions B2, C1, C3, D3, G1, G2 and E2 become story-mapped
- Your CV → more evidence for every row, and EXP questions on any figures it contains
- A deeper research pass: up to 6 more searches and 2 more fetches, several minutes. It would cover recent Ashgrove news since July, candidate reports on its interview loop, and any public leadership context. It is offered once, here
- A tuesday-dossier.md from the job-underwriter module → an evidence-derived highest-ROI objection instead of an inferred one, and a prohibited-claims list you have confirmed
