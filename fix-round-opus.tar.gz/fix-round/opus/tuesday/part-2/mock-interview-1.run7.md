Quick update: I've read the prep-pack playbook. Next I'm running a few web searches on Northwind Data's values, its interview process and Dan Kovac's public profile, and then I'll build the pack.
I've built Priya's prep pack for the single 60-minute conversation with Dan, treating him as a peer. It's saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-1-denied-7d6aaaec/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

- **What's in it:** 22 questions, grouped by interviewer persona. Each has a question-type tag, answer guidance that quotes your notes on Priya, and a rationale for including it and for its tags.
- **Weighting:** questions that probe her numbers and questions about how her role and Dan's would split and work together get the most, because he's a peer who calls himself "relentlessly data-driven". The case questions lean toward pricing, packaging and unit economics because that's his background.
- **Highest-ROI prep:** question C1, the "no quota-setting or sales-ops background" objection. It sits on Dan's own turf, so it's the one most likely to come up. The pack scripts it in detail: acknowledge the gap first, then two rehearsed follow-ups with exact concession wording.
- **Research didn't run:** all three web searches (Northwind's values, its interview process and Dan's public profile) were refused for lack of permission. So everything about Dan and Northwind comes only from your message, and nothing there was independently checked. The two values questions are generic as a result.
- **Your research note:** the questions on company strategy are built on it. Its date and source weren't stated.

If you'd like, I can play Dan on C1 as a live mock with real follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
And if you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. He is a **peer**: you would both report to the same VP. **Format:** one 60-minute conversation.

This pack covers that one conversation. Sections that don't apply have been left out: there is no prep-time schedule because no prep time was given, no deliverable build because none was announced, no values cheat sheet because no values round was detected, and no delivery coaching because no assessment was provided.

---

## How to use this pack

Two axes organize every question:

- **Persona** is how the question arrives: who is asking, and in what register. The banks below are grouped by persona.
- **Type** is what the question is really scoring. Each question has one primary type, and the rationale names any secondary one.

| Type | What it scores |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows specific values, not generic virtue |
| EXP | Work-experience deep-dive: whether CV claims survive scrutiny, and what was actually hers |
| JD | Role and JD: whether she can do the listed job, gaps included |
| CO | Company and strategy knowledge: whether she can think at Northwind's altitude |
| CASE | A live problem from the actual role, structured aloud |

**Provenance labels** grade what this pack wrote:

- `[grounded]`: traceable to what you gave me.
- `[inferred]`: a derivation, and the derivation is named.
- `[generic]`: a role-family pattern that claims nothing specific about Priya or Northwind.

**Answer slots.** An answer slot marks a place where the interviewer will likely probe something your notes don't state. It always has two honest branches. Priya answers it from her own experience in the room, or says plainly that it wasn't hers or didn't happen.

The guidance is scaffolding, not a script. Question IDs use a letter per persona: A, B, C, D, E, G, H. The letter F is reserved for fit-snapshot rows.

---

## Fit snapshot

The JD requirements come from the JD highlights in your message. The evidence is quoted from your notes on Priya. Proposed bridge wording is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "No classic sales-ops or quota-setting experience." — the coach's notes | medium | [grounded] | transferability | Product strategy and ops in consumer tech is adjacent to B2B GTM ownership but does not reach it. The words stay at the quote's scope: "nine years in product strategy and ops at a large consumer-tech company." The stated negative gives her a plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Say it first and unprompted. Answer slot: the JD's "own GTM strategy" line makes a probe on go-to-market work likely. If any launch go-to-market decisions were hers, she says which ones and what she decided, in her own words. If there were none, or they weren't hers, she says so plainly and stays with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | Derivation: spotting a revenue opportunity on a consumer store surface touches whitespace identification, but nothing shows whether it reaches a land/adopt/expand/renew lifecycle. Keep "proposed" and "credited with" exactly as they are, because they are the precise attribution. Answer slot: if she has found growth room inside an existing customer or partner base, she names it in her own words. If not, she says so and lays out how she would map whitespace here, as a plan |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but this is a self-report with nothing inspected behind it, and Dan calls himself "relentlessly data-driven", so expect a probe. She leads with the skill in the quote's own terms |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A model used in partner negotiations is adjacent to designing a partner motion, not the same thing. Our observation, not words for her: the material says a model, not a motion. Her words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if she knows what the model's outputs changed in the carrier terms, she says what, in her own words. If she doesn't, or it wasn't hers to see, she says so plainly and stays with the model she built |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already speaks to the requirement in role-relevant terms. She leads with it as written: she set annual volume targets, with cross-org consensus. Expect a probe on how the consensus was reached |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Derivation: daily use of AI tools touches "AI experience" but doesn't show whether it reaches what Northwind means by it. With Compass launching, that probably means GTM for an AI product. Answer slot: she names the tools she uses and what for, in her own words. If her use is everyday productivity rather than AI products, she says so plainly |

**No gate rows.** The JD highlights name no location, authorization, credential or travel term.

---

## Reading the interviewer

This section uses only what your message says about Dan's public profile. A search for his public footprint was refused (see Sources), so nothing here was independently checked.

| Signal (source) | What it implies for this hour | Provenance |
|---|---|---|
| "Director of Sales Strategy", a peer reporting to the same VP — your message | He is weighing whether Priya adds to his team's load or lightens it, and where the line between their remits falls. Sales strategy is his turf, so the quota gap in F1 lands hardest with him. Bank B is built for this | [grounded] |
| "relentlessly data-driven", self-described — your message | Every number will be probed down to its assumptions, so bank A is the heaviest. The ~$400M figure in F2 is the likeliest target. Naming her own weakest assumption before he does scores well | [grounded] |
| "career spine is pricing and monetization roles" — your message | Case questions tilt toward pricing, packaging and unit economics (D2, D3, B4, B5). Talking about margin, attach rate and payback is his native language | [grounded] |
| "one early-stage-startup chapter" — your message | Expect a scrappiness probe and some skepticism about big-company pace (C3) | [grounded] |

**Mirror opportunities.**

- *Shared vocabulary:* F4's "built a partner-level revenue model used in carrier negotiations" sits next to his monetization work, and F3's "skilled in SQL/Tableau" matches his data framing.
- *Shared career jump:* none offered. No F-row shows a pricing or startup path on Priya's side, so the pack does not present one.

---

## Persona table

How the weights were set: start from the peer-round prior (Peer Evaluator plus Data-Driven Prober), then adjust for Dan's profile signals. The loop is the single 60-minute session your message describes, so there is no other round to weight against. If you know something different about how Dan interviews, change the weights.

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy | Bank depth |
|---|---|---|---|---|
| Data-Driven Prober | "How was that counted?", denominators, two-level follow-ups | High. It is the peer prior, and his "relentlessly data-driven" self-description raises it further | Know what she can and can't say about how each number was counted, and say plainly when she doesn't know. Name the weakest assumption first | A, 5 questions |
| Peer Evaluator | Where the two remits meet, "what would you need from me", credit, disagreement | High. Peer relationship, same VP | Reciprocity: what she brings his team. Propose principles for where the line between remits falls rather than claiming to know it. Show spine and tact together | B, 5 questions |
| Skeptic | The B2B, sales-ops and quota gap; why leave consumer tech | Medium. The gap sits on his turf, so it will come up even in a collegial register | Rehearse C1 until it's boring. Acknowledge first, bridge only from quotes, give a ramp plan | C, 3 questions, one of them the deepest rehearsal in the pack |
| Case / Strategist | Live problems: whitespace, pricing Compass, profitability calls | Medium. A peer will test thinking rather than run a formal case. His pricing spine tilts these toward monetization | Clarify, then objective, segments, approach, metrics, risks. Think aloud. Challenge one premise respectfully | D, 3 questions |
| Pressure / Stress | A time-boxed "why you" or "how much was you" | Low. Not the peer default, but it can surface as a sharp follow-up | Pause, restate, hold through two follow-ups, then concede specifically | E, 2 questions |
| Conversational / Rapport | "Walk me through the journey", a casual AI question | Low. A likely opener in a 60-minute peer chat, and still scored | A 90-second arc. Treat the AI question as scored | G, 2 questions |
| Values / Behavioral | "Tell me about a time…" | Low. No values round was detected, and Northwind's values were not retrieved | Choose a story with a selection scaffold. "I" for her contribution, "we" for context | H, 2 questions |

---

## Question banks

22 questions, ordered by persona weight. All proposed answer wording is pending your approval.

**Highest-ROI prep in this pack: C1.** It is the B2B and quota-setting objection, raised on Dan's own turf. It will come up in some form.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift from the store-surface change was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F2, using only the beats the quote states: she proposed the change, and it was credited with a ~$400M ARR uplift. Keep "proposed" and "credited with" exactly, because that precision is the answer. Answer slots, each in her own words: how the figure was counted; what it is sensitive to; the assumption behind it she would defend least, named before Dan names it; and which part was hers. If she doesn't know how the credit was calculated, she says so plainly and returns to what she proposed | The CV's headline metric, in front of a self-described data-driven interviewer, so it is the likeliest single probe in the hour. EXP because it tests what was actually hers |
| A2 | "Walk me through the partner-level revenue model you built: how was it structured, and how was it used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: she built the model, it was partner-level, and it was used in carrier negotiations. She describes the structure in her own words, and offers to sketch it end to end only if she can. Answer slot (the JD's partner-motion line makes this probe likely): if she knows what the model's outputs changed in the carrier terms, she says what. If not, or it wasn't hers to see, she says so plainly and stays with the model | F4 is her evidence for the one requirement the JD marks "required". EXP primary, with JD as secondary, because it verifies the artifact before Dan asks what it proves |
| A3 | "How do you run independent analysis in SQL and Tableau, and what would you build in week one here?" | JD | [grounded] "skilled in SQL/Tableau" | She leads in the quote's terms: she is skilled in SQL and Tableau. Answer slot (the JD's "independent analysis" line makes this probe likely): if she has an analysis she wrote herself, she names the question it answered and what part she wrote. If her analyses were built with or by others, she says so plainly. Week one, as a plan: a cut of the install base by land, adopt, expand and renew for the two new lines, built herself, with the denominator stated | Covers F3, a stated JD requirement that Dan can test directly. JD content, with a CASE tail |
| A4 | "At 90 days, how would we know the GTM for the new lines is working? Which metrics, and how would you instrument them?" | CASE | [generic] | One metric per lifecycle stage. Land: pilots started and pilot-to-paid conversion. Adopt: activation and usage depth. Expand: attach to the existing install base. Renew: early retention signals. Give a denominator for each, split leading from lagging indicators, and name which early metric is noisiest. Makes no claim about her past | A live problem built from the JD's land/adopt/expand/renew line, delivered in Dan's metric-first register. `[generic]` because it is a pattern for the problem, not a fact about Northwind |
| A5 | "Tell me about a time a number you presented was challenged and you turned out to be wrong." | EXP | [generic] | Selection scaffold: a number she owned, a specific challenge, what she checked, and what she changed. The story must end with her updating the number, not defending it. If no such time comes to mind, she says so plainly, then gives the nearest thing her material carries, or how she would handle it | An open prompt themed on the Prober's core test. No quote carries a story here, so it is scaffolded. EXP because it scores honesty about her own analysis |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I own sales strategy; you'd own GTM for the new lines. Where's the line between us, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose principles, not a map. Her assumptions, stated as assumptions: his team owns the core motion's capacity, territories and quota; hers owns hypotheses, pilots and packaging for the new lines; they decide jointly how the new lines show up in rep targets and comp. On disagreement: agree the data and the decision rule first, then take any escalation to the VP as a joint recommendation. Evidence: she set annual volume targets, with cross-org consensus. Answer slot (the JD's cross-functional line makes this probe likely): if an org held out and she moved them, she says how, in her own words. If consensus came without a holdout, or the persuading wasn't hers, she says so plainly and stays with the targets she set | The defining peer question, and it covers F5. JD because it scores cross-functional influence, delivered collegially |
| B2 | "What would you need from my team in your first 90 days, and what would we get back?" | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Give before asking. What she can offer: independent analysis (she is skilled in SQL and Tableau), and she has built a partner-level revenue model used in carrier negotiations. What she needs: access to pipeline and bookings data, a channel for rep feedback, and a seat in planning wherever the new lines touch targets. Keep it to two or three items each | Tests whether the hire adds to or lightens Dan's load. JD (cross-functional influence), framed as reciprocity |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The quote already separates her contribution from the credit: she proposed the change, and the change was credited with the uplift. Answer slot, the "which part was yours" slot the figure raises: she says, in her own words, what was hers and what was others'. If she doesn't know how the credit was assigned, she says so plainly. She uses "we" for the change and "I" only for the proposal | A peer stem, mapped onto the one quote that carries an attribution seam. EXP because it tests her precision about her own role |
| B4 | "The JD says partner-motion design is required. How would you design a partner motion for one of the new lines, and how would it sit alongside our direct sales comp?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure it: which partner type (resell, referral, SI, marketplace); which segment partners reach that direct sales doesn't; the economics, meaning margin or fee against cost to acquire; conflict rules such as deal registration and comp neutrality for reps; enablement; metrics. Lean into the economics, since that is Dan's language. Then the bridge at its scope: "I built a partner-level revenue model that was used in carrier negotiations." The F4 slot applies, and nothing beyond the model is claimed | Covers the one required JD item, F4, through a live design problem. JD content, CASE delivery, with a pricing tilt for Dan |
| B5 | "Bundling by the big platform vendor shows up in pricing conversations every week. How should GTM for the new lines respond?" | CO | [grounded] | Frame it with hypotheses she would test, not claims about Northwind's product. Where does the bundle win, and where is it weakest? Should the new lines land first where the bundle is weakest, or be packaged as attach to the existing base? Where do partners strengthen the position? Avoid a discount war, given the profitability priority. Then ask Dan what he is seeing, which turns the answer into a peer conversation | Grounded in the competitive threat your research note names. CO with a CASE tail, set in his pricing territory |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **Highest-ROI.** "I don't see quota-setting or classic sales ops in your background, and this is a sales-led B2B business. Why would you be effective owning GTM here?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **1. Acknowledge first, and plainly:** "I don't have classic sales-ops or quota-setting experience." Better still, she says it before he does. **2. What she has, at its scope:** she set annual volume targets, with cross-org consensus, and she built a partner-level revenue model that was used in carrier negotiations. She never calls the targets quotas. **3. Ramp plan, as a plan:** what she would learn first (comp mechanics, pipeline stages) and from whom, which means his team. **Follow-up 1, "Volume targets aren't quotas":** "Right, they aren't, and I won't call them that." Then return to the consensus work. **Follow-up 2, "So you'd be learning on our time":** concede the specific learning curve, and hold that the JD frames this role around GTM strategy for two new lines | F1 is her biggest gap, and it sits in Dan's own remit, so it will arrive in some form. JD because it scores the stated ownership requirement. Deepest rehearsal: two follow-ups, exact concession wording, and the limit volunteered first |
| C2 | "Why leave consumer tech for B2B data infrastructure? Why here, and why now?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Context from the quote: nine years in product strategy and ops at a large consumer-tech company. Answer slot: her actual reason, in her own words. The pack can't supply it. Then link it to one of Northwind's three priorities from your research note (enterprise expansion, the Compass launch, profitability) and say why that one draws her. One consistent story, under 90 seconds | The motivation probe every domain switcher gets. EXP primary, with CO as secondary for the "why here" half |
| C3 | "Say there's no clean pipeline data for the new lines and no analyst to lean on. What do you do in your first month?" | CASE | [grounded] "skilled in SQL/Tableau" | Answer as a live plan: hypotheses before data; pull what exists herself (she is skilled in SQL and Tableau); run the smallest test that could kill a hypothesis; check in with his team weekly. If she has a time she worked with thin data, she gives it in her own words. If none comes to mind, she says so and stays with the plan | His early-stage chapter makes a scrappiness probe likely. CASE because it is a hypothetical about the role and presupposes nothing about her past |

### D. Case / Strategist (pricing tilt)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "We have an enterprise install base and two new lines. How would you find and size the whitespace across land, adopt, expand and renew?" | JD | [grounded] | Clarify first: what each line does, who buys it, and current attach. Segment the base by fit and propensity, and map each stage: land in which new accounts, adopt where, expand through cross-sell, protect renewals. Size each as value × win probability × cost to serve. Tie it to the enterprise-expansion priority, and name the riskiest input | Covers F2 directly, with the gap rehearsed as method rather than claimed history. JD content, CASE delivery, grounded in the JD and your research note |
| D2 | "How would you price and package Compass, the AI copilot?" | CASE | [grounded] | Clarify the value metric: seat, usage or outcome. Raise cost to serve (inference cost and margin) because profitability is a priority. Packaging options: include it in a top tier to blunt the bundling threat, or sell it as a paid add-on, and set out the trade-offs. Then a test plan and risks such as cannibalization and margin. Makes no claim to AI product experience | Dan's pricing spine plus the Compass launch from your research note, so this is the likeliest case. Also covers F6 from the strategy side. CASE, with CO as secondary |
| D3 | "Profitability is a company priority. One new line looks promising but expensive to sell. How do you decide whether to keep investing?" | CO | [grounded] | Unit economics: CAC payback, gross margin, expansion potential, sales-cycle length. Ask whether a partner channel lowers cost to sell. Set the kill criteria and review dates in advance. Name what would change her mind | Tests thinking at company altitude on a stated priority, in Dan's native terms. CO primary, CASE delivery |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run B2B sales strategy?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau" | Pause, then three beats in her words: she built a partner-level revenue model used in carrier negotiations; she set annual volume targets with cross-org consensus; she is skilled in SQL and Tableau, so she can run her own analysis. Hold through two follow-ups by returning to those three. Concede something specific: someone with B2B sales-strategy history would ramp faster on comp and pipeline mechanics | The C1 objection in its time-boxed form. JD because it scores fit for the role as listed. Hold-then-concede rehearsal |
| E2 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold on the quote: "I proposed the change; it was credited with a ~$400M ARR uplift." Answer slot: which part was hers, in her own words. If others built or shipped it, she says so and stays with the proposal. Never fold below "proposed", and never rise above it | The attribution probe on the headline number, sharpened. EXP |

### G. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company, then why GTM for new B2B lines now (her own reason, the same one as in C2). At most one highlight backed by a quote | The likely opener, and it is scored for economy. EXP |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | She uses AI tools daily. Answer slot (the JD's "AI experience a plus" line makes this probe likely): she names the tools and what she uses them for, in her own words. If it is everyday productivity rather than AI products, she says so plainly. Then a question back about how buyers evaluate Compass | Covers F6. A casual question on a JD plus-skill is still scored |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment she didn't soften the message, the truth actually landing, and the relationship intact afterwards. "I" for what she said. If no such time comes to mind, she says so plainly, then gives the nearest thing her material carries, or how she would handle it | A persona stem. No values round was detected and Northwind's values weren't retrieved, so this is generic insurance. VAL |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the metric, the customer cost, the choice she made, and what it cost or earned. If no such time comes to mind, she says so plainly, then gives the nearest thing her material carries, or how she would handle it | Insurance against a values question showing up in casual form. VAL |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own GTM strategy for two new product lines | C1 (JD), E1, D1, D3 |
| Identify whitespace across land/adopt/expand/renew | D1 (JD), A1, A4 |
| Independent analysis in SQL and Tableau | A3 (JD), C3 |
| Partner-motion design experience (required) | B4 (JD), A2 |
| Strong cross-functional influence | B1 (JD), B2, B3 |
| AI experience a plus | G2 (JD), D2 |
| Company priorities (research note): enterprise expansion, Compass, profitability, bundling threat | D1, D2, D3, B5, C2 |

Headline metric: the ~$400M figure is covered by A1, E2 and B3.

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "Coming from pricing and monetization, what do you see differently in sales strategy than someone who came up through sales ops?" | It is tied to his own career path, which turns the interview into a peer conversation |
| R2 | "What could someone in this role do in their first month that would genuinely help your team?" | Reciprocity, the question a peer cares about most |
| R3 | "Where does the platform vendor's bundling hurt most in your deals today: price, procurement, or 'good enough'?" | Shows she read the competitive frame, and his answer feeds her B5 thinking |
| R4 | "How do you expect Compass to change the sales motion? Is it sold, attached, or included?" | Pricing and packaging is his home ground, and it ties to a stated priority |
| R5 | "From your startup chapter, what do you still apply to launching something new inside a larger company?" | Invites his builder perspective, and it is relevant to emerging products |
| R6 | "How do you and the VP expect the line between sales strategy and emerging-products GTM to work in the first year?" | Shows she is thinking about where the two remits meet before day one |

---

## Prohibited claims

None of these will be coached in any answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove or delivered the ~$400M ARR | Inflated form of F2 | F2's quote at its own scope: she proposed the change, and it was credited with the uplift |
| Has set sales quotas or run sales ops | Negative the coach stated, F1 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." |
| Calling the annual volume targets quotas | Inflated form of F5, set against F1's stated negative | F5's quote at its own scope: annual volume targets, set with cross-org consensus |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope. Our observation, not her words: the material says a model, not a motion. The F4 slot stays inside the model |
| Led the carrier negotiations | Inflated form of F4 | The quote: the model was used in carrier negotiations |
| Has owned B2B go-to-market | Inflated form of F1 | F1's quote at its own scope: product strategy and ops in consumer tech |
| Has built or launched AI products | Inflated form of F6 | F6's quote at its own scope: she uses AI tools daily |

---

## Sources

**Provided in your message:**

- JD highlights
- Candidate background
- Interviewer profile summary
- Your research note: three priorities and the competitive threat. Its age and source were not stated.

**Searches sent:**

- `"Northwind Data" company values`: refused (permission not granted)
- `"Northwind Data" interview process GTM strategy`: refused (permission not granted)
- `"Dan Kovac" "Northwind Data"`: refused (permission not granted)

No fetches were sent, and no dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The call was refused. It would have themed H1 and H2 with Northwind's own value names. A cheat sheet would follow only if a values round were documented |
| 2. Northwind Data interview process, GTM strategy | unavailable | The call was refused. Your words already establish the loop (one 60-minute peer conversation), so it would only have added format detail, such as whether a case is expected |
| 3. Northwind Data strategy / recent news | skipped | Your research note supplies the priorities and the competitive frame that B5 and D1 to D3 are built on. It was not checked for currency |
| 4. Dan Kovac, Northwind Data | unavailable | The call was refused. It would have checked the profile you summarized and found any talks or posts, which could add reverse questions and sharpen the persona weights |
| 5. Representative JD for the title | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text:** every mid-list requirement (tools, partner types, methods) gets its own JD-tagged question, and the F1 to F6 quotes get checked against the full wording.
- **Web search permission:** targets 1, 2 and 4 run. That gives Northwind's values by name (H1 and H2 rethemed), the interview format, and a check on Dan's public profile, plus reverse questions drawn from anything he has published.
- **A deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes. It would cover the Compass launch, the bundling competitor and recent org context, and add a grounding brief section.
- **Recruiter guidance:** stated focus areas, or any case or presentation announced for this conversation, would get its own build section. This is usually one email.
- **Priya's answers to the answer slots:** how the ~$400M was counted and her part in it; what the carrier model changed; whether an org held out on the volume targets; what she uses AI tools for. These would turn A1, A2, B1, B3, E2 and G2 from slots into story-mapped guidance.
- **Prep time available:** adds a prioritized prep schedule.
- **An inspectable work sample:** a sanitized SQL or Tableau walkthrough, or the structure of the partner model, would raise F3 and F4 from medium toward high.
- **The date and source of the research note:** confirms that B5 and D1 to D3 rest on current priorities.
- **A `tuesday-dossier.md` from an underwriting pass on this role:** evidence-derived prohibited claims and a named top objection, in place of the ones this pack inferred.
