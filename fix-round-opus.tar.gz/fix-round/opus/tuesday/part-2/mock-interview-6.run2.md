I've drafted the full loop pack and I'm saving it now. Web search was refused, so it's built only from what you gave me.
I've saved a prep pack covering all three rounds: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-6-denied-712d6dd1/larkfield_engineering-manager_interview_pack.md`

The web searches for Larkfield's values, interview process and recent news were refused because search permission wasn't granted. So the pack uses only what you gave me, and nothing about Larkfield is taken from outside your message. As a result, there's no values cheat sheet for Monday, and the strategy questions are general rather than Larkfield-specific.

**How it's laid out:**
- **One shared fit table** compares each line of the role with your four sentences.
- **A section for each round:**
  - **Tuesday:** 12 questions, weighted toward live problems and the doubts a hiring manager will want settled.
  - **Thursday:** 12 questions, weighted toward cross-examining your numbers and how you'd split work with the panel.
  - **Monday:** 9 questions, weighted toward values, with time-boxed pressure questions.
- **Reverse questions:** each round has its own set to ask them.

**The one to rehearse most is A1:** "This role is two squads and 11 engineers, partnering with hardware. You've led a team of six. What makes you ready?" It's likely to come up in all three rounds. On Thursday it can come back as H2, and on Monday as K1 ("you've never managed managers"). Your own words already handle it honestly: "I haven't managed managers" and "I haven't owned a hardware-adjacent roadmap."

**Keep "after" as "after":** your 60% sentence says on-call burden dropped *after* the reliability quarter, not *because* of it. The staff engineers will push on that.

If you'd like a rehearsal, I can play the Director and ask you A1, with follow-ups that react to what you say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I can convert it.

Could you paste the full job description and your CV, or tell me to go ahead without them? Adding them would turn several of the "pick a story" prompts into prompts built on your actual stories.
Should I try the research again? That needs web search allowed. If not, I'll leave the pack as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Interview prep pack — Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Role:** Engineering Manager. "Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap." Larkfield is industrial IoT, about 600 people (your message).
**Mode:** Loop. One shared fit snapshot, then a mini-pack for each scheduled round:

| Round | When | Who | Length | Focus |
|---|---|---|---|---|
| 1 | Tuesday | Hiring manager: Director of Engineering, your would-be boss | 45 min | Not stated. Weighted as a hiring-manager round |
| 2 | Thursday after | Panel: two staff engineers and a product manager | 60 min | Not stated. Weighted as a blend of each member's relationship |
| 3 | Following Monday | VP Engineering | 30 min | "values and leadership philosophy" (the recruiter, via you) |

No interviewer names were given, so there's no interviewer read. Web research was refused in this session, so company values, loop format and strategy come from nothing outside your message. See Sources.

---

## How to use this pack

- **Personas** describe how a question gets asked: who's asking and in what style. **Types** describe what's being scored.
- Type key:
  - **VAL**: values and behaviour. Whether your past behaviour shows the values they care about.
  - **EXP**: experience deep-dive. Whether what you've said survives scrutiny, and what was actually yours.
  - **JD**: role-driven. Whether you can do the listed job, gaps included.
  - **CO**: company and strategy. Whether you can think at Larkfield's altitude.
  - **CASE**: live problem. Structure and reasoning on a problem from the actual role.
- **Provenance**: `[grounded]` means traceable to your message. `[inferred]` means a derivation, which is named. `[generic]` means a role-family pattern with no claim about you or Larkfield.
- **Answer slots** are instructions for your answer in the room, not questions for me. Each one has two honest branches. Answer whichever branch is true.
- Guidance is scaffolding, not a script. Say it in your own words. Every candidate sentence the pack leans on is one of your four sentences, quoted exactly.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads, and the words stay there: "I've spent three years as a team lead of six." Answer slot: the two-squad line makes a probe on leading across more than one group likely. If the six worked across more than one workstream or sub-team that you led across, say how, in your own words. If they didn't, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" — JD, the delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | Pushing a reliability quarter through is a call about what the team worked on. Your material doesn't show whether the team's delivery commitments were yours to own. Words, as you said them: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the JD's delivery line makes a probe on accountability for dates likely. If the team's delivery commitments were yours, say what that covered, in your own words. If they sat with someone else, or weren't set up that way, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" — JD, the hiring part | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | Running the loop sits next to owning hiring, and the words stay at the loop: "I run our hiring loop for backend roles; about 40 interviews last year." Answer slot: the JD's hiring line makes a probe on the hire decision likely. If hire or no-hire calls were yours, say how you made them, in your own words. If they sat with someone else, or there was no such step for you, say so plainly and stay with running the loop |
| F4 | "own delivery, hiring and growth for 11 engineers" — JD, the growth part | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Your material says team lead. It doesn't show whether growth conversations, review input or promotion cases for the six were yours. Answer slot: the JD's growth line makes a probe on developing engineers likely. If you did any of that for people on the team, say which and how, in your own words. If it sat with a manager above you, or didn't happen, say so plainly and say how you'd start with 11 |
| F5 | "partner with hardware and product on roadmap" — JD, the product part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | "Against roadmap pressure" touches the roadmap without showing who you worked it out with. Answer slot: the JD's partnering line makes a probe on how you work with product likely. If you worked the reliability quarter out with a product partner, say how it went, in your own words. If the pressure came from elsewhere, or there was no such negotiation, say so plainly and stay with the quarter you pushed through |
| F6 | "partner with hardware and product on roadmap" — JD, the hardware part | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | Wording can't close this gap, and you've said so yourself. Words: "I haven't owned a hardware-adjacent roadmap." Then how you'd learn the hardware side, said as a plan and never as a past. Your sentence is about owning such a roadmap. It says nothing either way about other contact with hardware teams, which F7's slot covers |
| F7 | "building device-management services" — JD; "industrial IoT" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Your material puts you in payments and doesn't show device or IoT work either way. Answer slot: the device-management line makes a domain probe likely. If you've worked on device, embedded, fleet or field-hardware systems, or alongside a hardware team, say what and in what role, in your own words. If not, say so plainly and stay with your nine years of engineering |

No row is a gate. The role text names no location, authorisation, travel or credential term.

### Requirement coverage

| Requirement | Fit row | Covered by |
|---|---|---|
| Lead two squads | F1 | A1, A4, B2, H2, K1 |
| Own delivery | F2 | B1, D1, E4, L2 |
| Own hiring | F3 | B4, D2, J3 |
| Own growth for 11 engineers | F4 | C2, J4, J5 |
| Partner with product on roadmap | F5 | B3, F2, G1 |
| Partner with hardware on roadmap | F6 | A2, B1, F3 |
| Device-management services, industrial IoT | F7 | A3, E3 |
| Your headline figure: the 60% on-call drop | F2, F5 | D1, E1, H1 |
| Your figure: about 40 interviews | F3 | D2 |

**Highest-ROI prep in the whole loop: A1**, the scale-up objection. Two squads and 11 engineers, against a team of six. It will come in some form in all three rounds: from the Director as a derisking question, from the staff engineers as H2, and from the VP as K1. Rehearse it until it's boring.

---

## Round 1 — Tuesday: Hiring manager (Director of Engineering), 45 min

### Persona weights

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scale step and the hardware gap | High. Your would-be boss is buying capability and derisking gaps, and F1 and F6 are the two biggest gaps in the snapshot | Rehearse A1 until it's boring. Bridge only from your quotes, say limits plainly, and close with a concrete ramp plan |
| Case/Strategist | Live problems from their actual roadmap: slips, inherited teams, trade-offs | High. The hiring-manager prior. Expect problems about two squads and a hardware dependency | Clarify, then objective, approach, metrics, risks. Think aloud and challenge one premise per case |
| Data-Driven Prober | Two levels down on the 60% and the 40 interviews | Medium-low. Hiring managers probe headline numbers, though less hard than staff engineers will on Thursday | Know how the figure was counted, or say plainly that you don't. Name your weakest assumption first |
| Conversational | "Walk me through your journey" opener | Low, but near-certain as the opener | A pre-built 90-second arc (C1). Treat it as scored |

### Bank A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role is two squads and 11 engineers, partnering with hardware. You've led a team of six. What makes you ready for the step?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I've never managed managers and never owned a hardware-adjacent roadmap" | **Highest-ROI rehearsal in the loop.** Open by naming the limit before they do: "I've spent three years as a team lead of six." Then the F1 answer slot: if the six worked across more than one workstream that you led across, say how. If they didn't, say so plainly. Then your 90-day plan for two squads, said as a plan. If they push with "isn't 11 nearly double?", hold by returning to the six, never by adding to it. If they ask about managing managers, the words are yours: "I haven't managed managers." Concede the step is real, and say what you'd want from them in the first quarter | F1 is the widest gap between the JD and your material, so the Director has to derisk it. JD because it scores the headline requirement directly |
| A2 | "Hardware is a big part of this job. What's your experience working with hardware teams?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Plain acknowledgment first: "I haven't owned a hardware-adjacent roadmap." Then F7's answer slot: if you've worked alongside a hardware team or on device systems in any role, say what. If not, say so plainly. Close with how you'd learn the hardware side in the first months, said as a plan: whose release calendar you'd learn, which handoffs you'd sit in on. Don't add anything to make the gap feel smaller | F6 is the one capability gap you stated yourself, so the honest answer is ready-made. Rehearsing it stops a live bluff. JD because it scores the partnering requirement |
| A3 | "Why leave payments for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your material doesn't say why, so this is a selection scaffold. Pick a reason that's true for you. It needs something pulling you toward this role, not just away from where you are, and it should be specific to device-management or the EM step. If no reason beyond "it's the next step" comes to mind, say that plainly. A plain answer beats a polished invented one | A Skeptic stem the F7 domain switch makes near-certain. JD because the Director is pricing motivation against the role, not the company's strategy |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pick F6 and say it plainly: "I haven't owned a hardware-adjacent roadmap." Then one sentence on how you'd close it, as a plan. Calibrated candour is the scored behaviour. Don't pick a fake weakness, and don't pick F1 again if you've already handled A1 | A Skeptic stem. F6 is the honest answer, and having it ready makes it read as self-awareness. JD because it scores self-assessment against the listed job |

### Bank B — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A hardware release slips three weeks. Your cloud-side squad is ready to ship. Walk me through what you do." | CASE | [generic] | Clarify first: is the cloud work usable without the hardware, who depends on the date, and what does the customer see? Then the options: ship dark behind a flag, re-sequence the squad onto other work, or hold. Name who decides with you (hardware lead, PM) and how you'd tell the squad. Close with what you'd change so the next slip shows up earlier. The question needs no claim about your past, so the guidance makes none | A live problem built from the JD's hardware-partnership and delivery lines (F2, F6). `[generic]` because it's a pattern, not a known Larkfield incident |
| B2 | "You inherit two squads on day one. What do you need to know in the first 30 days, and what do you leave alone?" | CASE | [generic] | Structure: people (one-to-ones with all 11, who leads each squad day to day), delivery (what's committed, to whom, and when), systems (on-call load, the riskiest service), partners (hardware and product counterparts). Say what you'd leave alone: no reorganising before you've listened. End with what you'd report back to the Director at day 30 | Tests F1's scale step as a plan rather than a record. CASE because it presupposes nothing about your past |
| B3 | "Product wants a feature quarter. On-call is burning people out. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer the case first: the cost of on-call in people and risk, what product loses by waiting, and a split or time-boxed option. Then you may say you've faced this, in your own words: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after." Keep "after". Don't say "because" unless you know it. F5's slot applies if they ask who you negotiated with | The JD's product-partnering line (F5), set as a live trade-off. CASE first and EXP second, because your quote gives you a real instance to anchor on |
| B4 | "You need to hire three engineers this half, and device-management experience is scarce. How do you run it?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Case structure: what the role really needs versus what can be learned, where candidates come from, what the loop tests, and how fast you close. You may draw on what you said: "I run our hiring loop for backend roles." Say nothing about how that loop is designed unless it's true and yours to describe. Then the F3 slot: if hire or no-hire calls were yours, say how you made them. If not, say so plainly | Covers the JD's hiring line (F3) as a live problem. CASE because it asks for a plan, with an EXP anchor from your one hiring sentence |

### Bank C — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc with three beats, all from your sentences: nine years of engineering, three as a team lead of six, now at a payments company. You run the backend hiring loop, about 40 interviews last year. You pushed a reliability quarter through against roadmap pressure, and the team's on-call burden dropped 60% after. End on why this role, using A3's answer. Don't add titles or scope your sentences don't carry | Near-certain opener, and casual openers are still scored. EXP because it sets the record every later probe tests |
| C2 | "What do you enjoy most about leading a team?" | JD | [generic] | Selection scaffold: pick something specific and true. It needs a concrete moment, not a principle. Prefer one that touches growing engineers, because that's the JD's growth line (F4). If nothing specific comes to mind, say so plainly, give what you're drawn to, and how you'd act on it with 11 | Casual phrasing, but it scores the growth requirement. JD because the JD's growth line is what it's probing |

### Bank D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your team's on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slots, in your own words: how the 60% was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours. "I don't know exactly how it was counted" is an honest branch. Name your weakest assumption before they do. Your sentence says "after", so be ready to say whether you know the quarter caused the drop. If you don't, say so. Keep the scope: the burden was the team's, and the push was yours | Every headline figure gets a defend-the-number question, and this is your only big one. EXP because it tests attribution |
| D2 | "About 40 interviews last year. What did you learn about hiring from that?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Slots for the figure: how the 40 was counted (yours personally, or the loop's total) and which part was yours. Then the lesson, in your own words, as a selection scaffold: one thing you'd do differently in Larkfield's hiring. If no specific lesson comes to mind, say so plainly and say what you'd want to measure in their loop | The 40 is a figure on F3's row, so it gets probed. EXP because it checks the number and what was actually yours |

### Reverse questions for the Director

| # | Question | Why it lands |
|---|---|---|
| 1 | "Six months in, what would make you say this hire worked?" | Gets your future boss to name the bar out loud. You can then rehearse against their words, not the JD's |
| 2 | "Who's been leading these two squads until now, and how do you see that changing when the role is filled?" | Shows you're thinking about the people already in the seat. It also tells you whether you inherit an interim lead, a vacancy or a conflict |
| 3 | "Where do the handoffs with hardware happen day to day, and where do they go wrong?" | Faces F6 head-on, as a learner rather than a bluffer, and gets you the real shape of the partnership |
| 4 | "How do you and your managers decide when reliability work beats roadmap work?" | Lets your own reliability story become a shared conversation, and shows whether the Director would back you |
| 5 | "How do you like your managers to keep you informed: written updates, one-to-ones, or something else?" | A practical manager-fit question that reads as wanting to work well with them in particular |

---

## Round 2 — Thursday: Panel (two staff engineers and a product manager), 60 min

### Persona weights

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Staff engineers going two levels into the 60% and into technical depth | High. Technical specialists probe depth, and this is the round where the on-call figure gets cross-examined | Keep "after" as "after". Know what you can and can't say about how the figure was counted, and offer only walkthroughs of work that was yours |
| Peer Evaluator | Seam questions: where the EM's call ends and the staff engineers' begins, and how you work with the PM | High. All three panellists will work beside you and are pricing whether you add to their load or reduce it | Reciprocity framing. Propose seam principles rather than pretending to know their seam |
| Values/Behavioral | The PM asks for stories about disagreement and saying no | Medium. A cross-functional panellist tends toward behavioural stories | "We" for context, "I" for your contribution. Stories only from your quotes, scaffolds elsewhere |
| Pressure | "How much of that was actually you?" and "why you over one of us?" | Low-medium. Staff engineers on an EM panel sometimes test composure | Pause, restate, hold the quoted position through two follow-ups, and concede specifically |

### Bank E — Data-Driven Prober (staff engineers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the reliability quarter. How do you know it's what moved on-call?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The beats your sentence states: you pushed the quarter through, against roadmap pressure, and the team's on-call burden dropped 60% after. Tell them in your own words. Then the causation question is a figure slot: what the drop is sensitive to, the assumption you'd defend least, and which part was yours. If you can't separate the quarter from other causes, say so first. That's the credibility move with staff engineers. Expect a follow-up on what the work was, and answer it only with what you actually know | Staff engineers will take your one headline story apart. Rehearse it so the honest limits arrive before they ask. EXP because it tests what actually happened and what was yours |
| E2 | "How hands-on are you still? When did you last read a design doc closely or review code?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold. Pick a recent, real example of technical work. It needs a date, a system and what your part was. If you're no longer hands-on, say so plainly and say how you'd stay credible with staff engineers: what you'd read, which reviews you'd sit in. Don't claim depth on device systems (see F7) | The JD's "building device-management services" means the panel wants an EM who can follow the engineering. EXP because it tests your current technical footing |
| E3 | "Sketch a service that pushes configuration to 50,000 field devices on unreliable connections. Where are the hard parts?" | CASE | [generic] | Clarify before structuring: device types, connectivity pattern, how bad a wrong config is, and whether rollback is possible on the device. Then the hard parts as questions you'd ask the staff engineers: staged rollout, idempotency, devices that come back after weeks offline, observability across the fleet. Say plainly that devices are new to you if F7's slot ends that way. Asking good questions here is the scored behaviour, not designing it all | Tests F7's domain gap live. Staff engineers judge how you reason in their domain more than whether you know it already. CASE because it asks about no past |
| E4 | "How would you decide when a squad's tech debt should beat a roadmap item?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A principle first: the cost of the debt (incidents, on-call, slowed delivery), made visible to product in their terms, plus a standing budget or a negotiated quarter. Then your instance, in your words: "I pushed a reliability quarter through against roadmap pressure." Ask the panel how they make the call today. That's a peer move | Covers the JD's delivery line (F2) as a judgement call, with your real instance as the anchor. CASE because it asks for your decision rule |

### Bank F — Peer Evaluator (staff engineers and PM)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "We're your staff engineers. Where's the line between your call and ours on technical decisions?" | CASE | [generic] | Propose principles rather than a rule: technical direction is theirs, while trade-offs against people, dates and partners are yours to make with them. You break ties only when they can't agree and a date forces it. Say what you'd need from them (early warning on risk) and what they get from you (cover, context, and time for the work that isn't on the roadmap). End by asking how it works today | The core seam for staff engineers sitting beside an EM. CASE because it asks for a working model, not a record |
| F2 | (PM) "When product and engineering disagree about a quarter's priorities, what happens with you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your instance, in your words: you pushed a reliability quarter through against roadmap pressure. Then F5's answer slot: if you worked it out with a product partner, say how it went. If the pressure came from elsewhere, or there was no such negotiation, say so plainly and stay with the quarter. Speak about product as a partner, not an obstacle. The PM is listening for that | The PM's natural probe on the JD's partnering line (F5). EXP because it asks what you've actually done |
| F3 | (PM) "Hardware, product and your squads all depend on each other's dates. How do you keep that from becoming a blame loop?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Answer as a plan: shared visibility of dependencies, an agreed way to flag a slip early, and a regular three-way check-in. If it's relevant, be plain: "I haven't owned a hardware-adjacent roadmap", so you'd learn the hardware cadence first. Ask the PM where it breaks today | F6's gap set as a three-way seam. CASE because it asks how you'd work, with your stated negative ready if the gap comes up |
| F4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold. Pick a time credit was shared or contested. It needs a named piece of work, who did what, and what you did about the credit. If no such time comes to mind, say so plainly and give the principle you'd hold: credit goes to the people who did it, by name, in front of the people they'd want to hear it | A Peer Evaluator stem. Staff engineers want to know whether an EM takes credit upward. VAL because it scores behaviour, not a requirement |

### Bank G — Values/Behavioral (PM)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you said no to a stakeholder and the relationship survived." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on your sentence: you pushed the quarter through against roadmap pressure, and on-call burden dropped 60% after. Answer slot: whether the relationship survived isn't in your material. If it did, say what showed you, in your own words. If it was strained or you don't know, say so plainly. An honest ending lands better than a tidy one | Your one quoted story with a real stake in it. VAL because the PM is scoring how you disagree, not what the result was |
| G2 | "Tell me about a time you were wrong about a call, technical or people." | VAL | [generic] | Selection scaffold. It needs a decision that was clearly yours, the moment you realised, and what you changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural probe for a cross-functional panellist. VAL because it scores self-awareness |

### Bank H — Pressure (staff engineers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold, then concede. The hold is exactly what your sentence says is yours: "I pushed the reliability quarter through against roadmap pressure." The concession is also in your sentence: the burden was the team's, and the drop came after. Hold through two follow-ups by returning to the push, never by claiming the engineering work. If you don't know how much of the drop the quarter caused, say so plainly | A Pressure stem aimed at your one headline figure. EXP because it tests attribution under pressure |
| H2 | "Sixty seconds. Why should two staff engineers want you over promoting one of us?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year" | Pause, then don't argue against them. Say what you'd bring in your sentences' terms: three years as a team lead of six, and running a hiring loop with about 40 interviews last year. Say what you'd protect for them: their technical time. End by naming that the step to two squads is new for you (F1). Composure is what's being scored | F1's objection in its sharpest panel form. JD because it scores the lead-two-squads requirement |

### Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| 1 | (Staff engineers) "What could a new manager do in the first month that would genuinely help your work?" | The reciprocity question. It puts their load first, which is exactly what peers are scoring |
| 2 | (Staff engineers) "Which technical calls do you want to keep, and which would you be glad to hand off?" | Shows you'll respect the seam from F1 before you've crossed it |
| 3 | (PM) "How does a quarter's roadmap get set today between you, hardware and engineering?" | Gets you the real F5 and F6 process, and reads as partnership |
| 4 | (All) "What's on-call like on these services today?" | Connects your reliability story to their reality without boasting |
| 5 | (PM) "When a hardware date last moved, what happened on your side?" | Concrete, non-hypothetical, and teaches you the seam you're weakest on |

---

## Round 3 — Monday: VP Engineering, 30 min, "values and leadership philosophy"

A values-style round is detected here because the recruiter's description of the round, relayed in your message, names it. There's no values cheat sheet because Larkfield's published values aren't in hand: the search for them was refused. See the upgrade menu.

### Persona weights

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time…" and "what's your philosophy on…" | High. The recruiter named the round "values and leadership philosophy" | Short STAR stories, only from your quotes, with scaffolds where none applies. Hard truths that actually landed. Say so where the ending isn't known |
| Pressure | Time-boxed altitude checks: "you've never X, why you?" | Medium. The executive prior, and 30 minutes forces short answers | Pause, give a two-sentence answer, then stop. Hold-then-concede on K1 |
| Case/Strategist | One altitude question: leading engineering at a 600-person company | Medium-low. The executive prior, tempered by the stated values focus | Principles over tactics. Ask one question back |
| Conversational | Warm opener, then "any questions for me?" | Low, but the reverse-question slot is heavily weighted | Never say "you've covered everything" |

### Bank J — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" "I run our hiring loop for backend roles — about 40 interviews last year" | Two or three principles in your own words, each anchored to something you said. If one principle is about protecting a team's sustainability, anchor it on pushing the reliability quarter through against roadmap pressure. If one is about who you bring in, anchor it on running the backend hiring loop. A principle with no anchor gets a scaffold: say what you believe and say plainly you haven't been tested on it yet. Keep it under two minutes | The recruiter's own framing of the round, so this is near-certain. VAL because it scores how you'd lead |
| J2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on your sentence: there was roadmap pressure, you pushed a reliability quarter through, and on-call burden dropped 60% after. Answer slot: who you had to persuade isn't in your material. If it was leadership, say who and how, in your own words. If it wasn't leadership, say so plainly and use the scaffold instead: a time you told someone senior something they didn't want to hear, and what happened | A Values stem with your best-fit story. The rehearsal is not stretching "roadmap pressure" into "pushed back on leadership" unless that's true |
| J3 | "Tell me about a hiring decision that didn't work out." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | F3's slot first: if hire or no-hire calls were yours, pick one that went wrong and what you changed afterwards. If those calls weren't yours, say so plainly and talk about what the loop you run taught you. Don't invent a mis-hire to have a story | The JD's hiring line (F3) as a values question. Executives check whether a manager learns from hiring mistakes |
| J4 | "How do you grow engineers, including ones who are technically stronger than you?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | F4's slot: if you've done growth conversations, review input or promotion cases for anyone on your team, say which and how. If not, say so plainly and give your approach for 11 as a plan. On engineers stronger than you, a principle: give them scope and visibility, and remove blockers | The JD's growth line (F4), likely to be asked in a philosophy round. VAL because it scores how you'd lead people |
| J5 | "Tell me about a time you had to deal with someone who wasn't performing." | VAL | [generic] | Selection scaffold. It needs a named situation, what you did and when, and how it ended. Keep the person anonymous. If you haven't had to handle it as a lead, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard probe for any new EM, and harder to fake than growth stories. VAL because it scores judgement and fairness |

### Bank K — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You've never managed managers. If this group grows to four squads, are you the person?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | This is A1 at VP altitude. Hold, then concede. Concede plainly first: "I haven't managed managers." Hold to what you can stand on: the step this role asks for now is two squads. Say what you'd need to grow into four, as a plan. Don't promise readiness you haven't shown. Keep it under 45 seconds | The VP only asks this if they've heard it, perhaps from Tuesday's debrief, so be ready for it. JD because it scores the leadership-scale requirement |
| K2 | "Thirty seconds. What would your team say is your worst habit as a lead?" | VAL | [generic] | Selection scaffold. Pick a real habit you've been told about or noticed yourself, plus what you do about it. It must be true and yours. If you haven't had that feedback, say so plainly and name what you'd ask your new team for | A Pressure stem testing candour under a time box. VAL because it scores self-awareness |

### Bank L — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "At about 600 people, what changes about leading engineering compared with a smaller or bigger place?" | CO | [generic] | Don't claim facts about Larkfield or about your current company's size. Neither is in hand. Reason aloud: at around 600 people, an EM is close enough to know everyone but far enough that process starts to matter. Ask the VP where Larkfield feels that tension. Asking beats asserting here | Executives check altitude. `[generic]` because research couldn't run, so no Larkfield-specific strategy is available |
| L2 | "What one principle would you set for how your squads trade reliability against roadmap?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | One sentence of principle, then your instance: you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Keep "after". Then ask how the VP thinks about it | The JD's delivery line (F2) at VP altitude, with your strongest anchor. CASE because it asks for a rule you'd set |

### Reverse questions for the VP

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do your strongest managers do that you'd want a new one to copy?" | Turns their philosophy into behaviour you can be measured against |
| 2 | "Which of Larkfield's values is hardest to live day to day?" | Values-round gold. It gets a real answer, not the poster version |
| 3 | "How do you see engineering's side of the hardware relationship changing over the next couple of years?" | Shows altitude on F6's gap without pretending to expertise |
| 4 | "How do first-time EMs get support here in their first year?" | Honest about the step from F1, and tells you whether you'd be set up to succeed |
| 5 | "What would worry you about a new EM at the six-month mark?" | Invites the VP to name the risks out loud while you're still in the room |

---

## Prohibited claims

What this pack won't coach, and why. These bind every bank, every drill and every reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers, or led leads | A negative you stated (F1, K1) | "I haven't managed managers." No slot |
| Owned or led a hardware or device roadmap | A negative you stated (F6) | "I haven't owned a hardware-adjacent roadmap." No slot |
| Led two squads, or a team of 11 | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team of six. F1's slot stays inside the six |
| Was the people manager of record for the six | Inflated form of F1 and F4: "team lead" is a different kind of role from "manager" | The quote at its own scope: "3 as a team lead of 6". F4's slot asks only which growth work was yours |
| Built or designed the hiring loop, or owned hiring | Inflated form of F3: "run" is not "built" or "owned" | "I run our hiring loop for backend roles; about 40 interviews last year." F3's slot asks only about hire or no-hire calls |
| Cut on-call by 60% personally, cut incidents by 60%, or the quarter caused the drop | Inflated form of the on-call sentence: the burden was the team's, it measured on-call burden rather than incidents, and the drop came "after", not "because" | The sentence at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Causation is a figure slot (D1, E1) |
| Owned the roadmap, or owned the team's delivery | Inflated form of the reliability-quarter sentence (F2, F5) | "I pushed a reliability quarter through against roadmap pressure." F2's and F5's slots stay inside that quarter |

---

## Sources

- **Provided:** your message. The role text (quoted as the JD), the three-round schedule and the recruiter's description of Monday, and your four background sentences.
- **Searches sent:**
  - "Larkfield Systems values": refused (search permission not granted in this session)
  - "Larkfield Systems interview process engineering manager": refused
  - "Larkfield Systems industrial IoT news 2026": refused
- **Fetches:** none.
- **Loop:** your message is the loop source. It establishes all three rounds: who runs each, and that Monday is values and leadership philosophy. No archetype fallback was used.
- **Dossier:** none was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Refused. It would have supplied the values cheat sheet for Monday and themed bank J by Larkfield's own value names |
| 2. Larkfield Systems interview process, EM | unavailable | Refused. It would have shown the panel's format (system design, case or conversation) and any declared deliverable. Persona weights still follow your schedule |
| 3. Larkfield Systems strategy and recent news | unavailable | Refused. It would have grounded at least one CO or CASE question in Larkfield's current strategy. L1 and the strategy-dependent parts stay `[generic]` |
| 4. Interviewer names at Larkfield | n/a | No names were given, so no query could be formed. There's no interviewer read, and reverse questions are role-tied, not path-tied |
| 5. Representative EM JD | skipped | The role text you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text:** turns mid-list requirements (stack, on-call expectations, location, team structure) into `[grounded]` rows, each with its own JD question. It may also surface a gate row the summary doesn't show
- **Your CV:** more of your own sentences to quote. E2, F4, G2, J5 and K2 move from scaffolds toward story maps
- **What the reliability quarter actually contained, and who you persuaded:** E1, F2, G1, J2 and L2 move from quote-only beats to full story maps
- **Your answers to the F1 to F7 answer slots, said to me outside a drill:** each one enters the fit snapshot verbatim, and the rows that draw on it get regenerated
- **Web search allowed, or Larkfield's values page pasted:** a values cheat sheet for Monday, and bank J mapped to Larkfield's values by name
- **The recruiter's prep email or Larkfield's careers or interview page:** the panel's real format. If there's a system-design exercise, a case or a presentation, it gets its own build section. Usually one email to the recruiter
- **Interviewer names:** an interviewer read for each round, per-member persona assignment on Thursday's panel, and a reverse question tied to each person's own path
- **A deeper research pass, once search is allowed (up to 6 more searches and 2 more fetches, several more minutes):** a grounding brief on Larkfield's strategy, competitors and recent moves, and CO questions for Monday that aren't generic
- **Hours you have for prep before Tuesday:** a prep-triage schedule, sized to your time and ordered by question ID
- **A tuesday-dossier.md from an earlier fit assessment of this role:** an evidence-derived highest-ROI objection and an absolute prohibited-claims list from that assessment, instead of ones inferred here
