Building your prep pack now. I'm running a few quick company searches first.
I've built your prep pack: 21 practice questions, each with answer guidance drawn only from what you told me. I used equal weight across all seven interviewer styles, since you don't know who you're meeting yet.

I couldn't research Atlas Freight. All three web searches (company values, interview process, recent news) were blocked because search permission wasn't granted. So the pack has no Atlas-specific facts. Look up the company yourself before the interview (question E2 covers this).

The question to rehearse most is A1: "You run 3 supervisors at one site. This role is 12 supervisors across four sites. Why you?" Name that gap yourself before they do, then give a 90-day plan. The other gaps are Power BI, which you've never used, and whether 5 of your 7 years were spent leading people, which your background doesn't show.

Saved at: /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-2-denied-851addd2/AtlasFreight_operations-manager_interview_pack.md

I can play the Skeptic interviewer on A1 with you whenever you're ready.
I can also save a `tuesday-dossier.md` file listing the gaps this prep exposed, for later sessions.
I can convert the pack to a Word document if you'd like.

1. Who are you meeting: the hiring manager, peers, a panel, or a recruiter screen first? Has the recruiter mentioned any presentation or case task? Either answer changes which questions get the most depth.
2. Do you want me to retry the Atlas Freight searches? You'd need to allow web search when it asks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** unknown, and the round type is unknown too. Persona weights are flat (see the persona table).

---

## How to use this pack

- **Personas** describe *how* a question comes at you: who is asking, and in what style. **Types** describe *what* is being scored.
- Type key:
  - **JD**: can you do the listed job, gaps included
  - **EXP**: do your own claims hold up under scrutiny, and what was actually you
  - **CASE**: a live problem from the role, solved out loud
  - **VAL**: whether your past behaviour shows the values they care about
  - **CO**: company and strategy knowledge. There are none in this pack, because the company research could not run (see Sources)
- **Provenance** shows what each row rests on. `[grounded]` means it traces to your own words or the JD. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a common pattern for the role, with no claim about Atlas or about you.
- **Answer slots** are spots where the interviewer is likely to probe something your material doesn't settle. Each one has two honest branches. Fill it from what really happened, or say plainly that it didn't happen or wasn't yours.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution ops and one site's surge plan. It does not mention terminal operations or more than one site. Words at their own scope: "I've spent seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: "across 4 sites" makes a multi-site probe likely. If you have run or covered more than one site, say which and how, in your own words. If you haven't, say so plainly and stay with the site you ran the plan for |
| F2 | "drive on-time performance and cost-per-shipment down" (on-time part) — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Running a surge plan is not the same as owning an on-time number, so don't stretch this bridge. Answer slot: if the surge plan carried an on-time target, say what it was and how it went, in your own words. If it didn't, or the number wasn't yours, say so plainly and say what you would measure first |
| F3 | "drive on-time performance and cost-per-shipment down" (cost part) — JD | none given | none | [grounded] | discovery | Your material doesn't show any cost work either way. Strong evidence here would be a cost measure you were responsible for and moved. Answer slot: if you have been accountable for cost-per-shipment or any other cost measure, say which one and what you did, in your own words. If not, say so plainly and walk through how you'd attack it (B2) |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Words: "I'm currently a senior shift manager over 3 supervisors." The pack's own observation is that 3 is not 12. Name that gap before the interviewer does, then give a plan for 12. This is the pack's highest-ROI objection (A1) |
| F5 | "build reporting in Excel/Power BI" (Excel part) — JD | "solid Excel, never used Power BI" — your message | low | [inferred] | discovery | "Solid Excel" describes a skill. It doesn't say which reports you've built. Answer slot: if you have built a report or tracker that others used, say what it tracked and who used it, in your own words. If not, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" (Power BI part) — JD | "solid Excel, never used Power BI" — your message | none | [grounded] | capability | You stated this gap yourself, and wording can't close it. Words: "I haven't used Power BI." Then give a learning plan, said as a plan and never as a past. If you start learning before the interview, say exactly how far you got and no further |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | A years-of-experience requirement is not a gate, but it may be screened literally. Your material shows 7 years in ops and a current leadership role. It doesn't show how many of those years you spent leading people. Answer slot: count the years you have had people reporting to you and give that number plainly. If it's under five, say so and don't pad it with years you weren't leading |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, though nobody has inspected the certificate, so expect a probe on where you've used it (C2, E3). Lead with the credential in its own words: "I'm green belt certified." |

No row is a gate. The years requirement in F7 is graded like any other requirement.

---

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "3 supervisors to 12, one site to four, no Power BI: convince me" | Flat weight. No loop source told me who you're meeting, so I used the generic fallback (screen, then hiring manager, then panel) with flat weights. These weights rest on a pattern, not on Atlas's process. The Skeptic bank holds the highest-ROI question (A1) anyway, because F4 and F1 are the widest gaps | Rehearse A1 until it bores you. Name the limit first, hold on what your quotes carry, then give a concrete ramp plan |
| Case / Strategist | Live problems on on-time performance and cost-per-shipment at a terminal | Flat weight. The JD's two headline metrics make case questions likely from any hiring manager, which is a reading of the JD and not a fact about Atlas | Clarify, then objective, then segment, then approach, then metrics, then risks. Think out loud |
| Data-Driven Prober | Digs into the 40% figure: how it was counted, what else changed, what was yours | Flat weight. A quantified CV claim draws probers in any loop | Know what you can and can't say about how the 40% was counted. Name the assumption you'd defend least before they do |
| Pressure | Time-boxed "why you" and "how much was actually you" | Flat weight | Pause, restate, anchor in what you actually said. Hold through two follow-ups, then concede specifically |
| Conversational | "Walk me through your journey", plus a casual question about Lean | Flat weight. Openers in this style are common in screens and early rounds | Have a 90-second arc ready. Treat a casual Lean question as scored |
| Peer Evaluator | Another ops lead asking about shared resources, credit and disagreement | Flat weight. Applies if a panel includes peer managers | Frame things as reciprocity, and offer seam principles rather than pretending to know the seam |
| Values / Behavioral | Classic "tell me about a time" questions on leading supervisors and handling failure | Flat weight. No values-style round was detected, but behavioural questions are common in generic loops | Choose a real story for each theme, or say plainly that none fits |

---

## Question banks

Question IDs go by persona. Each persona has three questions because the weights are flat.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads 12 supervisors across four sites. You're running 3 supervisors today. Why should I believe you can make that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | **This is the highest-ROI rehearsal in the pack.** Name the limit first, in plain words: today you're a senior shift manager over 3 supervisors, and this role is a bigger span than that. Don't round the 3 up. Next comes the surge plan, which you ran two years running. Answer slot: "a team of 12 supervisors" makes a probe on whether peak put more people under you likely. If it did, say how many and how you ran them, in your own words. If it didn't, say so plainly and stay with what running the plan involved. Close with a ramp plan, said as a plan: time on the floor at each site early on, a one-to-one with each of the 12 supervisors, one daily report format across all four sites, and one or two shared targets. Hold through two follow-ups by coming back to the 3 and the surge plan, never by adding to them | F4 and F1 are the widest gaps, so some version of this objection is near-certain. JD because it scores the stated span directly |
| A2 | "The role builds reporting in Excel and Power BI. Where are you with Power BI?" | JD | [grounded] "solid Excel, never used Power BI" | Plain acknowledgment: "I haven't used Power BI." Then Excel: "my Excel is solid." Answer slot: the JD's reporting line makes "what have you built in Excel?" likely. If you've built reports others used, say what they tracked, in your own words. If not, say so plainly. Then give a learning plan with dates, said as a plan. If you start a course before the interview, report only the progress you've actually made | F6 is a gap you stated and F5 is unproven, so a stated tool requirement with no rehearsed answer is a free miss. JD because it scores the tool line |
| A3 | "The JD asks for 5+ years of operations leadership. How many of your 7 years were you actually leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Give a number and keep it exact: count the years you've had people reporting to you. Then put it in context with what's quoted: 7 years in warehouse and distribution ops, currently a senior shift manager over 3 supervisors. If the count is under five, say it plainly, don't blend in years you weren't leading, and point to the current role. The honest number survives a reference check | F7 is where a literal screen bites. JD because it scores the stated requirement |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four terminals dropped sharply last month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is measured, which lanes or customers, since when, and whether the measurement itself changed. Then segment by shift, lane, customer, dock and carrier. Check the data before acting on it. Give hypotheses: volume or mix change, staffing gaps, missed cutoffs, dock congestion, equipment. Use the other three sites as a comparison. Separate containment this week from the root-cause fix, and name the metric you'd watch daily. This question needs no claim about your past, so the guidance makes none | It's a live problem drawn from the JD's on-time line (F2). `[generic]` because it's a pattern for the problem, not a fact about Atlas. CASE because it's delivered live |
| B2 | "Cost-per-shipment is above target across the network. Where do you look first?" | CASE | [generic] | Define it first: what goes into the cost and what counts as a shipment. Break the cost down into labour, equipment, rework or damage, and overhead. Labour is usually the biggest lever you control at a terminal, so look at productivity per labour hour, overtime and idle time. Compare the four sites, find the best one's practices, and spread them. Name the trap: cutting cost in a way that hurts on-time performance | It covers F3, which your material is silent on, so a strong case answer is your best evidence here. `[generic]` because it's role-family structure |
| B3 | "Your first 90 days owning four terminals: what's the plan?" | CASE | [generic] | 0 to 30 days: learn. Spend time at each site, hold one-to-ones with the 12 supervisors, and baseline on-time and cost-per-shipment per site. 30 to 60 days: build one shared daily report, plus a short list of the problems that matter most. 60 to 90 days: one or two improvement targets with owners at each site, and a weekly review rhythm. Say what you'd *not* change in the first month | It tests F1 and F4 as a plan rather than a record, which is where your honest answer is strongest. JD content, CASE delivery |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State the claim at its own scope: you cut the mis-pick rate 40% by redesigning the pick path. Keep the 40% attached to the mis-pick rate, not to cost or on-time. Answer slots, each in your own words. How it was counted: what counted as a mis-pick, over what periods, before versus after. What it's sensitive to: whatever else changed in that window. The assumption you'd defend least: name it before they do. Which part was yours: what you did in the redesign and who else was involved. "I don't know exactly how it was counted" is an honest answer, and far better than a method you can't repeat under a second question | Your headline metric gets a defend-the-number question. EXP because it tests attribution |
| C2 | "Was the pick-path redesign a Lean or Six Sigma project?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" "green belt certified" | Answer slot: if you used green belt tools on the redesign, name which ones and what each showed you, in your own words. If it wasn't run as a structured project, say so plainly and describe how the redesign came about. Don't retrofit a methodology story onto it. "I'm green belt certified" stands either way | F8 meets your metric here, and the temptation is to merge them. EXP, with JD as a second tag because of the "Lean/Six Sigma a plus" line |
| C3 | "Tell me about a report or tracker you've used to run your operation." | JD | [grounded] "solid Excel, never used Power BI" | Pick a report or tracker you built or relied on in Excel. It needs a named purpose, who looked at it and one decision it changed. If none comes to mind, say so plainly, stay with "solid Excel" and move to what you'd put on a daily terminal report: on-time percentage, cost-per-shipment, volume, labour hours and exceptions | It covers the Excel half of the reporting line (F5). Open prompt, themed from the JD |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already run a multi-site terminal network?" | JD | [grounded] "7 years in warehouse and distribution ops" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" | Pause and keep it to three beats: 7 years in warehouse and distribution ops, you cut the mis-pick rate 40% by redesigning the pick path, and you ran the site's peak-season surge plan two years running. Don't claim multi-site experience. Answer slot: if pushed on whether you've run more than one site, say which and how if you have, and say so plainly if you haven't. End with the 90-day plan in one sentence (B3) | It combines F1 and F4 under time pressure. JD because it scores the stated scope |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold, then concede. Answer slot: say what you personally did in the redesign, in your own words. Use "we" for the team context and "I" only for your part. If others did parts of it, name their parts. Hold your share through two follow-ups, and concede anything specific you're unsure of rather than everything | It's the attribution probe a quantified claim invites. EXP |
| D3 | "Terminal work isn't warehouse work. Aren't you a warehouse manager applying up?" | JD | [grounded] "7 years in warehouse and distribution ops" | Don't relabel your experience. Hold on "warehouse and distribution ops." Answer slot: the JD's "terminal operations" makes this probe likely. If your distribution work included terminal operations, say which part and how, in your own words. If it didn't, say so plainly and say how you'd learn the terminal side fast, for example by shadowing dock leads at each site in the first weeks | F1 is a change in kind of work as well as scope, and that's where a candidate is most tempted to blur it |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc built from those beats only: 7 years in warehouse and distribution ops, now a senior shift manager over 3 supervisors, the pick-path redesign and the 40% mis-pick cut, the surge plan two years running, and green belt certified. Then why this role, in your own words | The biographical opener is scored, and it sets up everything after it. EXP because it frames your record |
| E2 | "What draws you to Atlas Freight?" | JD | [generic] | I couldn't research Atlas (see Sources), so do it yourself: their website, services, regions and anything recent. Pick one specific thing and tie it to the role's scope of four sites, on-time performance and cost. Say nothing about Atlas you didn't actually read | A motivation check that's common in every loop. `[generic]` because no Atlas facts are in hand |
| E3 | "Are you doing much with Lean these days?" | JD | [grounded] "green belt certified" | Treat it as scored, however casual it sounds. "I'm green belt certified." Answer slot: if you've applied it recently, name the problem and the tool, in your own words. If you haven't, say so plainly and say what you'd apply first at a terminal, as a plan | It's the JD plus-skill (F8) asked casually, the classic place for a casual answer to cost you |

### F — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "We'll share equipment and people across sites at peak. What happens when we both need the same thing?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Seam principles: agree the rules before peak, prioritise by customer commitment, escalate early with numbers, and make the trade-off visible to both bosses. Answer slot: if running the site's surge plan meant negotiating resources with other teams, say how, in your own words. If it didn't, say so and stay with the principles | Peers price whether you add to their load. CASE delivery, with the slot tied to F1 |
| F-2 | "Some of your 12 supervisors may have wanted this job. How do you handle that?" | CASE | [generic] | Acknowledge it early and privately, give them real ownership of one target, be consistent across all four sites, and judge them on results. No claim about your past is needed | A live leadership problem from the JD's supervisor line (F4) |
| F-3 | "How do you handle credit when an improvement spans teams?" | VAL | [generic] | Pick a time credit was shared on something you worked on. It needs a named piece of work, who did what, and how you made others' parts visible. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona stem. It pairs with D2 on attribution |

The peer rows are labelled F-1 to F-3 so they don't collide with the fit snapshot's F rows.

### G — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to address a supervisor who was underperforming." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: a time with one of your supervisors where you named the problem, agreed what would change and followed up. It needs a clear issue, a direct conversation and an outcome. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Themed from "lead a team of 12 supervisors" (F4). VAL because it scores leadership behaviour |
| G2 | "Tell me about a time you pushed back on someone senior." | VAL | [generic] | Pick a time you held a position with someone senior. It needs a named stake, a moment you didn't fold, and an intact relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona stem. Ops managers sit between leadership and the floor |
| G3 | "Tell me about a time a plan broke down under volume and how you recovered." | VAL | [grounded] "ran the site's peak-season surge plan two years running" | If a peak you ran under the surge plan had a moment like this, use it: what broke, what you did that day, and what you changed afterwards, in your own words. If none did, say so plainly, then give the nearest thing your material carries, or how you would handle it | Themed from the JD's on-time line (F2). It's a behavioural form of the B1 case |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, B3, D1, D3 |
| Drive on-time performance down (the JD's wording) | B1, G3 |
| Drive cost-per-shipment down | B2 |
| Lead a team of 12 supervisors | A1, B3, F-2, G1 |
| Build reporting in Excel/Power BI | A2, C3 |
| 5+ years operations leadership required | A3 |
| Lean/Six Sigma a plus | C2, E3 |
| Headline metric: 40% mis-pick | C1, D2 |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is on-time performance measured here, and where does each of the four sites stand today?" | It shows you think about the definition before the number, and it tells you how big the job is |
| "What goes into cost-per-shipment, and what target would this role be held to?" | It turns the JD's headline metric into something concrete you can plan against |
| "What reporting exists today? Is there Power BI already, or would I be building from Excel?" | It's real diligence, and the answer tells you how much your Power BI gap (F6) matters |
| "How are the 12 supervisors spread across the sites, and how experienced are they?" | It shows you're already thinking about the team, and it sizes the leadership jump (F4) |
| "What would a strong first six months look like to you?" | It gives you their success criteria in their words, so you can reflect them back |
| "Why is the role open?" | It surfaces whether you're backfilling, growing a role or fixing a problem, which changes what success means |

---

## Prohibited claims

These are the claims this pack won't coach. Under pressure they're the ones that tempt you.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run multi-site operations | Inflated form of F1 | F1's quotes at their own scope. The pack's observation is that your material says "the site's" surge plan, one site |
| Has run terminal operations | Inflated form of F1 (a change of kind) | "7 years in warehouse and distribution ops," at its own scope. D3's slot stays inside what you did |
| Leads a large team, or more than 3 supervisors | Inflated form of F4 | "currently a senior shift manager over 3 supervisors." A1's slot asks only about peak |
| Designed or built the peak-season surge plan | Inflated form of F1's quote (from "ran") | "ran the site's peak-season surge plan two years running" |
| Has 7 years of operations leadership | Inflated form of F7 | The 7 years were in ops. A3's slot asks how many of them were leading people |
| The pick-path redesign cut cost or improved on-time performance | Inflated form of the metric quote (the number moved to a different noun) | "cut mis-pick rate 40% by redesigning the pick path." The 40% stays with the mis-pick rate |
| Led Six Sigma projects | Inflated form of F8 | "green belt certified." C2's slot asks only whether the tools were used on the redesign |
| Has used Power BI | A negative you stated (F6) | "I haven't used Power BI." No slot |

---

## Sources

- **Provided documents:** your message, including the JD text you pasted and your background.
- **Searches sent:**
  - `"Atlas Freight" logistics values`: refused
  - `"Atlas Freight" interview process operations manager`: refused
  - `"Atlas Freight" news 2026`: refused
- No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Refused. It would have themed VAL questions and, if a values-style round turned up, a values cheat sheet |
| 2. `Atlas Freight interview process operations manager` | unavailable | Refused. It would have named the rounds and replaced the flat persona weights |
| 3. `Atlas Freight strategy` / recent news | unavailable | Refused. It would have grounded CO and CASE questions in current company context. Without it, the pack has no CO questions and E2 is generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Round type and who you're meeting (manager, peer, panel, or a recruiter screen first) → real persona weights instead of flat ones, with the top persona's bank deepened to 4–5 questions
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- The recruiter's prep email or any process details → coverage of any pre-declared task, such as a presentation or a case
- Search permission for this session → targets 1–3 above run: Atlas values, loop structure and recent news, plus a CO question grounded in the company
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a company strategy brief, the context the role exists for, and sharper CASE questions
- Your resume → more quoted evidence, especially for F2 (on-time) and F3 (cost), which currently rest on silence
- How many of your 7 years were in people-leadership roles → F7 and A3 move from an answer slot to a stated number
- Whether you've built reports others used in Excel → F5 and C3 upgrade from discovery
- Before-and-after mis-pick data, or how the 40% was measured → C1 becomes story-mapped instead of slot-led
- Your green belt certificate → F8 confidence moves from medium to high
- How much prep time you have before the interview → a prioritised prep schedule
- A `tuesday-dossier.md` from a job-underwriter pass → an evidence-derived highest-ROI objection and a prohibited-claims list confirmed by you rather than built here
