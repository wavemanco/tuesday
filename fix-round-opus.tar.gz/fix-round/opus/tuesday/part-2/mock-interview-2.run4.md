Building your prep pack now. Next I'm running a few quick searches on Atlas Freight's values, interview process and recent news.
I've saved your prep pack: `atlas-freight_operations-manager_interview_pack.md`. It covers how you fit each line of the JD, 23 practice questions with guidance, 6 questions to ask them, and a list of claims not to make. My web searches on Atlas Freight were blocked, so nothing in the pack about the company comes from research.

Because you don't know who's interviewing you, I didn't assume a round. All the interviewer styles are weighted equally, with extra questions where your gaps are.

- **Highest-priority prep (A1):** "This role leads twelve supervisors. You lead three today. Why are you ready?" You lead 3 supervisors now and the role has 12, so expect this question in some form. The pack gives you a way to name that gap yourself, hold your ground, and give a plan.
- **The "5+ years operations leadership required" line (A3):** your 7 years are in operations, and you didn't say how many of them were spent leading people. Work out the exact number before the interview. Don't let "7 years in ops" stand in for 7 years of leadership.
- **Power BI (A4):** "I haven't used Power BI. My Excel is solid." Then give a learning plan as a plan. Don't mention a course unless you've actually started one.
- **The 40% mis-pick figure (C1, D2):** it's your one number, so expect questions on how it was counted and which part was yours. "I don't know how it was counted" is a fine answer if it's true.
- **Warehouse vs. freight terminals (A2):** describe your warehouse and distribution work as it was and let them draw the link. Don't relabel your past work as "terminal operations."

Say the word and I'll play the tough interviewer on A1, with follow-ups that react to what you say.
I can also save a short file recording the gaps this prep found, for you to bring to later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Do you know who you're meeting (hiring manager, a panel, HR, a site leader), or did the recruiter say anything about the format or ask you to prepare a case or presentation? That would change which questions get the most space.
2. My web searches were blocked. If you allow web search, should I rerun the basic company research? I can also do a deeper pass: up to 6 more searches and 2 page fetches, taking several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** unknown. The round type is also unknown, so this pack covers the full set of personas with flat weights. That makes it noticeably weaker than a pack built for a known round, and the upgrade menu says what would sharpen it.

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking, and in what style. **Types** describe *what is being scored*.
- Type key:
  - **VAL**: behavioral and values alignment against the company's published values
  - **EXP**: work-experience deep-dive. Does what you said survive scrutiny, and what was actually you?
  - **JD**: the stated responsibilities and qualifications, gaps included
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the actual role, reasoned through out loud
- Provenance labels: `[grounded]` traces to what you gave me or to cited research, `[inferred]` is this pack's own derivation (the derivation is named), and `[generic]` is a role-family pattern that makes no claim about Atlas or about you.
- An **answer slot** is an instruction for the interview, not a question for me. It has two honest branches, and either one is a good answer.
- The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

The requirements are quoted from the JD text in your message. The evidence is quoted from your message, and nothing else counts as evidence here.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and the site's surge plan. It does not say terminal operations or more than one site, so the words stay at the quotes' scope: "Seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's terminal and four-site line makes a probe on terminal or cross-dock work, and on running more than one site, likely. If you have done either, say where and what part was yours, in your own words. If not, say so plainly and stay with the warehouse and distribution work and the site plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" (on-time half) — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A mis-pick rate measures accuracy, not timeliness, so the bridge should not be stretched. Answer slot: if you tracked an on-time or timeliness measure, or saw the pick-path change move one, say which measure and how it was counted. If not, say so plainly and say what you would measure first in this role |
| F3 | "drive on-time performance and cost-per-shipment down" (cost half) — JD | none given | none | [grounded] | discovery | Your material says nothing about cost per shipment or any cost measure. Answer slot: if you have tracked or been responsible for a cost measure, say which one and what you did with it, in your own words. If not, say so plainly and walk through how you would break cost per shipment down |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Words: "Today I'm a senior shift manager over 3 supervisors." The JD's span is four times that, and no wording closes the difference. Answer slot: the JD line makes a probe likely on how you would lead through supervisors at a bigger span. If you have led a larger group at any point, say when and how, in your own words. If not, say so plainly and stay with the three you lead now, then give your plan for twelve, said as a plan |
| F5 | "build reporting in Excel/Power BI" (Excel half) — JD | "solid Excel" — your message | medium | [grounded] | discovery | "Solid Excel" names the tool. It does not say whether you have built reporting in it. Answer slot: if you have built reports other people use, say what they tracked and who read them. If not, say so plainly and say what you use Excel for today |
| F6 | "build reporting in Excel/Power BI" (Power BI half) — JD | "never used Power BI" — your message | none | [grounded] | capability | You have stated this gap yourself, and wording cannot close it. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as a past. Add nothing to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material says seven years in ops. It does not say seven years leading people. The JD marks this requirement "required", so expect it to be checked. Answer slot: if five or more of those years were in roles leading people, name the roles and how long each lasted, in your own words. If fewer, say so plainly and give the number. Never round your leadership years up to the seven |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. A certification is checkable, but nothing has been inspected, so expect a probe. Lead with it in the quote's own terms: "I'm green belt certified." Answer slot: the JD's Lean/Six Sigma line makes a probe on applying it likely. If you have used it on a project, say which project and what you did, in your own words. If not, say so plainly and stay with the certification |

## Persona table

No source established Atlas's interview loop, because the research searches were refused (see Sources). The pack therefore falls back to the **Generic** archetype (screen, then hiring manager, then panel) with **flat weights**. Your persona weights rest on a pattern, not on Atlas's documented process. Bank sizes still tilt toward the Skeptic and the Case/Strategist, because that is where this pack's material sits: F1, F4, F6 and F7 are the gaps a Skeptic presses, and the JD's metric and reporting lines are the live problems.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the scope step, the warehouse-to-terminal move, the leadership years and Power BI | medium. Weights are flat because the round is unknown. This bank is largest because F1, F4, F6 and F7 give a Skeptic the most to work with | Rehearse A1 until it is boring. Build bridges only from your own sentences, say the limit plainly where none reaches, and give a plan said as a plan |
| B. Case / Strategist | Live problems: four-site on-time, cost per shipment, a reporting build, a first 90 days | medium. Flat. The JD's metric and reporting lines are natural live problems for any manager-level round | Clarify, then objective, segmentation, approach, metrics and risks. Think aloud, and challenge one premise per case |
| C. Data-Driven Prober | Digs into the 40% figure and what you track | medium. Flat. The figure is the one headline metric in your material | Know what you can and cannot say about how it was counted, and say plainly where you don't know |
| D. Pressure | Time-boxes, devil's advocate, "how much was actually you" | medium. Flat | Pause, restate the question, anchor in what you said, and hold through two follow-ups before conceding anything real |
| E. Conversational | Friendly openers, "walk me through it", casual questions about the Lean plus | medium. Flat | Have a 90-second arc ready, built only from your own sentences. Treat casual questions as scored |
| F. Peer Evaluator | Seams with other teams, disagreement with equals | medium. Flat | Frame what you bring the other team. Propose seam principles rather than pretending to know their seam |
| G. Values / Behavioral | Behavioral stories | medium. Flat. No published Atlas values are in hand, so these questions are themed by the JD and persona stems, not by Atlas's values | We for context, I for contribution. Where your material shows no story, say so rather than supplying one |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads twelve supervisors. You lead three today. Why are you ready for that span?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **The highest-ROI rehearsal in this pack.** Name the limit before they press it: "Today I'm a senior shift manager over 3 supervisors. Twelve is a bigger span than I lead today, and I won't pretend otherwise." Answer slot: if you have led a larger group at any point, say when and how, in your own words. If not, say so plainly and stay with the three. Then give your plan for twelve, said as a plan: how you would set expectations, see each site and hear from each supervisor. Expected follow-up 1: "But three to twelve is a different job." Hold: return to what you do with the three now, in your own words, and do not add to it. Expected follow-up 2: "What breaks first at four times the span?" Concede specifically: name the thing you would have to change about how you work today, said as your own judgment | F4 is the widest gap between your material and the JD and the likeliest objection in any round. JD because it scores the stated span |
| A2 | "We run freight terminals. Your background is warehouse and distribution. What carries over, and what doesn't?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start with what you did, at the quote's scope: seven years in warehouse and distribution ops. Answer slot: the JD's terminal line makes a probe on terminal or cross-dock work likely. If you have done any, say where and what part was yours. If not, say so plainly and stay with warehouse and distribution. For "what doesn't carry over", say what you would need to learn, as a plan. Describe what you did and let them draw the transfer, rather than claiming it transfers | F1 is the domain step, and a terminal-operations interviewer will hear the difference within a sentence. JD because it scores the first line of the role |
| A3 | "The JD says five-plus years of operations leadership. How many of your seven years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: if five or more of those years were in roles leading people, name the roles and how long each lasted, in your own words. If fewer, say so plainly and give the number, then return to the senior shift manager role you hold now. Give an exact number. Never let "seven years in ops" stand in for seven years leading people | F7 is marked required, so a literal check is likely. JD because it scores a stated qualification |
| A4 | "Power BI is in the JD. Where are you with it?" | JD | [grounded] "never used Power BI"; "solid Excel" | "I haven't used Power BI." Then: "My Excel is solid." Then a learning plan, said as a plan and never as something started: what you would learn first and how fast you would aim to build a first report. Do not mention a course or a trial unless you have actually begun one | F6 is a gap you have stated, and a rehearsed one-breath answer turns it from a stumble into candor. JD because it scores the reporting requirement |
| A5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick one real answer, not a disguised strength. F6 is the one you have already stated, so it is the safest honest pick: "I haven't used Power BI," followed by the plan from A4. If you would honestly name something else, use it, and say only what your own experience supports | A classic Skeptic stem. F6 gives you an answer that is true, specific and recoverable. JD because it scores self-assessment against the listed job |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time at one of our four sites dropped ten points last month. Diagnose it." | CASE | [generic] | Clarify first: how is on-time defined here, and is the drop in inbound, outbound or both? Is it one site only? Then segment: by shift, lane or customer, and by day of week. Look for what changed: volume, staffing, a carrier, equipment. Then the fix, and the metric you would watch to know it worked. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time line (F2's requirement). `[generic]` because it is a pattern for the problem, not a fact about Atlas |
| B2 | "Cost per shipment is up year over year. Where do you look?" | CASE | [generic] | Clarify the definition: what is in the numerator and what counts as a shipment. Split the change into volume and mix versus cost per unit of work. Then labor hours per shipment, overtime, damage and claims, and other handling costs. Close with the one or two levers you would test first and how you would know. Answer slot, only if asked about your past: F3's slot applies | The cost half of the JD's metric line (F3), which your material does not touch, so the case is where you can show reasoning without a record. CASE because it is a live problem |
| B3 | "Build me a weekly report the four site leads and I would actually use." | CASE | [grounded] "solid Excel"; "never used Power BI" | Clarify the audience and the decisions the report should drive. Propose a short list of measures (on-time, cost per shipment, plus one or two you would argue for), by site, with trend and exceptions. Say you would build it in Excel first because "my Excel is solid," and say "I haven't used Power BI" without apology, with a plan to move the report there. Answer slot: F5's slot applies if they ask what you have built before | JD content, CASE delivery: it tests the reporting line (F5 and F6) as a design problem rather than a tool quiz |
| B4 | "It's your first 90 days across four sites. What do you do?" | CASE | [generic] | A structure, not a record. First, listen: visit every site and meet every supervisor. Then set a baseline on on-time and cost per shipment using the current definitions. Find the one or two problems most worth fixing, and land one visible win before changing structure. Make no claim about your past here unless you use one of your own sentences | The JD's four-site ownership (F1) asked as a plan. CASE because it is a live problem with no single answer |
| B5 | "Peak is six weeks out across four sites. Walk me through how you'd plan it." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Your sentence carries one fact: you ran the site's peak-season surge plan, two years running. Say that in your own words and describe how you ran it only as far as you actually did. For four sites, structure out loud: forecast by site, staffing, space and equipment, carriers, the escalation path, and the daily review. Answer slot: the JD's four-site line makes a probe on coordinating across sites likely. If you have done that, say how. If not, say so plainly and present the structure as your plan | Draws on F1's strongest quote and stretches it toward four sites, which is exactly where it must not be inflated. CASE because it is a live planning problem |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 40% mis-pick reduction. How was it counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats your sentence states are the mis-pick rate, 40%, and the pick-path redesign. Answer slots for the figure, each in your own words: how it was counted (what measure, over what period, compared with what); what it is sensitive to; the assumption behind it you would defend least, which you should name before they do; and which part of the redesign was yours. If you don't know how the figure was counted, say so plainly. That is an honest answer, and a better one than an explanation you can't repeat under a second question | Every headline figure gets a defend-the-number rehearsal, and this is the only figure in your material. EXP because it tests what survives scrutiny |
| C2 | "Did the pick-path change move anything else, like on-time or cost?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Stay with what your sentence says: the mis-pick rate. Answer slot: if you measured an effect on on-time, cost or anything else, say what and how it was counted. If you didn't, say so plainly and stay with the mis-pick result. Never claim an effect you did not measure | It tests the JD's metric line (F2 and F3) through your one figure, which is exactly where the pull to stretch it is strongest. JD because it scores stated responsibilities |
| C3 | "What do you track week to week today, and in what?" | EXP | [grounded] "solid Excel" | Answer slot: if you track measures and report them, name them and who reads the reports, in your own words. If you don't build reports, say so plainly and say what you use Excel for. Name a measure only if you actually track it | It tests F5 directly. EXP because it asks about current practice, not a hypothetical |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause. Grant what the question already grants, that the internal candidate knows the sites, without adding a weakness of your own. Then three beats, each from your own sentences: seven years in warehouse and distribution ops; a 40% mis-pick cut from redesigning the pick path; running the site's peak plan two years running. Close on the green belt. Stop at 60 seconds | A standard stress stem. It rehearses composure plus a tight arc built only from what you said. JD because it scores fit to the listed job |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: say exactly which part was yours and who else was involved, in your own words. If others did parts of it, say so plainly, because that strengthens you. Hold through two follow-ups by returning to your part, never by enlarging it | C1's figure under stress. It is the attribution probe, rehearsed as candor. EXP because it tests what was actually you |
| D3 | "Your peak plan. What would you do differently?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: if there is something you would change, name it in your own words and say why. If nothing comes to mind, say so plainly and name what you would check first if you ran it across four sites. Don't invent a failure to sound reflective | It tests F1's strongest quote for self-critique. EXP because it probes the plan you ran |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc made only of your own sentences: seven years in warehouse and distribution ops; now senior shift manager over three supervisors; the 40% mis-pick cut from redesigning the pick path; running the site's peak plan two years running; green belt certified. End on why this role, in your own words | The biography question is scored even when it is asked casually. EXP because every beat is checkable |
| E2 | "You've got a green belt. What have you used it on?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: if you have applied it to a project, name the project and what you did, in your own words. If not, say so plainly and stay with the certification | The JD's Lean/Six Sigma plus (F8), asked casually. JD because it scores a listed plus |
| E3 | "What do you know about Atlas Freight?" | CO | [generic] | This pack has no verified facts about Atlas, because research did not run. Before the interview, read their own website and any recent news, pick one fact that connects to the JD, and say where you read it. Guessing at facts about the company is worse than saying what you read | The CO slot every round touches. `[generic]` because nothing about Atlas was established |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "A customer-facing team promises a delivery window the dock can't hit. What do you do?" | CASE | [generic] | Structure: find out what was promised and why, protect the shipment today, then set a principle with the other team on who commits to windows and on what data. Frame it as what you bring them, not only what you need from them | Seam questions are where peers price a hire. `[generic]` because it is a pattern, not a fact about Atlas |
| F2q | "Tell me about a time you disagreed with a peer, another shift manager say, and how it ended." | EXP | [generic] | Selection scaffold: pick a time with a real disagreement with an equal, a position you held for a reason, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement with equals is what a peer scores. `[generic]` because your material holds no story for it |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold: pick a time with a named stake, a message leadership did not want, and what happened next. We for context, I for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem. Tagged EXP rather than VAL because no published Atlas values are in hand to score against |
| G2 | "Tell me about a time a supervisor on your team wasn't performing. What did you do?" | JD | [generic] | Selection scaffold: pick a time with a specific gap, what you did about it, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Themed by the JD's supervisor line (F4's requirement). JD because it scores leading supervisors |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, B4, B5 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C2 |
| "lead a team of 12 supervisors" | A1, G2 |
| "build reporting in Excel/Power BI" | A4, B3, C3 |
| "5+ years operations leadership required" | A3 |
| "Lean/Six Sigma a plus" | E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time measured across the four sites today? Is it the same definition everywhere?" | It shows you think about the measure before the number, which is the B1 skill in reverse |
| R2 | "What goes into cost per shipment here?" | It signals you will manage the real driver, not the headline, and it tells you what you would be held to |
| R3 | "Where is reporting today? Is there an existing Power BI build, or would I be starting from Excel?" | It addresses F6 head-on and tells you how big the reporting job actually is |
| R4 | "How are the twelve supervisors spread across the sites, and are any of those roles open?" | It shows you are already thinking about the span in A1, and it surfaces what you would inherit |
| R5 | "What would a great first six months in this role look like to you?" | It gives you their scorecard in their own words, which you can use against B4 |
| R6 | "What's the biggest operational problem the person in this role will face first?" | It invites a live problem you can respond to, and it is better than any question that could be answered from the website |

## Prohibited claims

What this pack will not coach, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Has led twelve supervisors, or a multi-site team | Inflated form of F4 | F4's quote at its own scope: "currently a senior shift manager over 3 supervisors." The limit is this pack's observation, not words for you: the material says three supervisors, not twelve. A1's slot stays within what you have led |
| Ran terminal operations, or ran more than one site | Inflated form of F1 | F1's quotes at their own scope: warehouse and distribution ops, and the site's surge plan. A2's and B5's slots stay inside that work |
| Designed or built the peak-season surge plan | Inflated form of F1 ("ran", not "designed") | "ran the site's peak-season surge plan two years running", at that verb |
| Improved on-time performance or cost per shipment | Inflated form of F2 | F2's quote at its own scope: the mis-pick rate. C2's slot asks only what else you actually measured |
| Has seven years of operations leadership | Inflated form of F7 | "7 years in warehouse and distribution ops", which is years in ops, not years leading people. A3's slot asks for the actual number |
| Has built reports, or used Power BI | Negative you stated (F6); F5 is the inflated form for report-building | Power BI: "I haven't used Power BI." No slot. Report-building: F5's quote, "solid Excel", with its slot |
| Ran Lean or Six Sigma projects, or holds a higher belt | Inflated form of F8 | "green belt certified", at that level. E2's slot asks only what you have applied it to |

## Sources

- **Provided:** your message (the JD text, and your background).
- **Searches sent:**
  - `"Atlas Freight" logistics company values`: refused (web search permission not granted)
  - `"Atlas Freight" interview process operations manager`: refused (web search permission not granted)
  - `"Atlas Freight" regional logistics news 2026`: refused (web search permission not granted)
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The call was refused. It would have themed the VAL questions by Atlas's published values, and it could have fed a values cheat sheet if a values-style round were detected |
| 2. `Atlas Freight interview process operations manager` | unavailable | The call was refused. It would have tried to establish the loop. Persona weights fell back to the Generic archetype with flat weights instead |
| 3. `Atlas Freight` strategy and recent news | unavailable | The call was refused. It would have grounded at least one CO or CASE question in Atlas's current priorities, so E3 and the B bank stay `[generic]` |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The pack has no interviewer read |
| 5. Representative Operations Manager JD | skipped | The JD in your message fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Who you're meeting and what kind of round it is** → real persona weights instead of flat ones, with banks resized to match (for example, a hiring manager pushes B and A up, and a panel blends them)
- **The interviewer's name** → an interviewer read from their public professional footprint and a reverse question tied to their own path
- **The recruiter's prep email, if there is one** → a build section for any pre-declared case, presentation or exercise, plus a documented loop instead of the archetype fallback
- **Web search permission** → targets 1 to 3 run: Atlas's published values, its documented interview process, and one CO or CASE question on its current priorities, so E3 and B1 to B4 can lose their `[generic]` labels. After that, a deeper pass of up to 6 more searches and 2 more fetches (several more minutes) can cover company strategy and recent org context
- **Your CV** → more of your own sentences, so the scaffolds in F2q, G1 and G2 can become story-mapped answers
- **Your answers to the slots on F2, F3, F5 and F7** → those rows move from `discovery` toward a settled gap type, and A3, B2, C2 and C3 get story-mapped guidance
- **Before-and-after mis-pick data, and your green belt certificate** → the artifacts that would raise C1 and F8 from `medium` toward `high`
- **How much prep time you have** → a prep-triage schedule at the top of the pack
- **A fit-assessment dossier from a prior run** → an evidence-derived highest-ROI objection and a prohibited-claims list confirmed with you, instead of one built here
