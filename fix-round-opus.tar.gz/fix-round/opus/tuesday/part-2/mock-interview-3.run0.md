Building your Stripe prep pack now. I'm starting with a short research pass: Stripe's values, its interview process, recent strategy, and a sample Product Ops JD.
Web search permission was declined, so I'm building the pack without research: every requirement is labelled generic, and nothing about Stripe comes from memory. Writing the pack now.
I've saved your prep pack as `stripe_product-operations-manager_interview_pack.md`. It has 22 practice questions across seven interviewer styles, plus six questions for you to ask them.

It's a generic version for now. Web search was declined, so I had no job description, no CV, no Stripe values and no details of their interview process, and I didn't fill those gaps from memory. Instead:
- **The requirements** are ones common to Product Ops roles, not quotes from Stripe.
- **Your experience section** is a worksheet for you to fill in.
- **Each answer guide** helps you pick a story from your own work, with an honest fallback if nothing fits.
- **The interviewer mix** is a guess at a typical final round, not Stripe's actual format.

Start with B2, "Product ops owns no roadmap. How would anyone know you made a difference?" It's the challenge you're most likely to get in some form.

Say the word and I'll play the skeptical interviewer on B2, with real follow-ups and feedback afterwards. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, so you can use it in later sessions. If you'd like the pack as a Word document, I can convert it.

1. Could you paste the job description and your CV, or a few lines on your background? I can keep working without them, but they would turn the worksheet into answers built on your actual experience.
2. Who is on the final-round schedule (hiring manager, peers, a senior leader, a dedicated values interview), and did the recruiter mention focus areas or a presentation or case to prepare? That reshapes the whole pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Round: final round, interviewers and schedule not yet known. Built as one session-mode pack with blended persona weights. Inputs: your one-line message only. No JD, no CV, no research (web search was not permitted in this session), so the fit snapshot is a self-assessment worksheet and every question is `[generic]`.

## How to use this pack

Two axes. **Personas** describe how a question is asked: the style, register and pressure. **Types** describe what is being scored. Rehearse both, because the same content lands differently from a skeptic than from a rapport-builder.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's published values, not generic virtue |
| EXP | Whether your experience survives scrutiny: what you actually did, attributed honestly |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework depth on the company's strategy and recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. With no CV in hand, almost every guidance cell tells you how to *choose* a story, not which story to tell. Pick from your own work, say it in your own words, and when nothing fits, use the honest branch at the end of each cell.

Question IDs run A, B, C, D, E, G, H by persona. F is kept for fit-snapshot rows.

## Fit snapshot (worksheet)

No JD was supplied and none could be fetched, so the requirements below are common Product Operations requirements, written as plain prose and labelled `[generic]`. They are not quotes from Stripe. Your evidence column is empty because the pack has nothing you've written about your past. Fill it in yourself before you rehearse.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running launch and release readiness across product, engineering, support and go-to-market (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a launch you coordinated, which teams were involved, what "ready" meant and who decided it. Pick a launch where the coordination itself was your job, not just one you attended. If no such launch comes to mind, say so plainly, then give the nearest thing your work does include, or how you would run one |
| F2 | Turning customer and internal feedback into prioritized product input (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a feedback channel you ran or shaped, how inputs were sorted, and one thing that changed in the product because of it. Pick a case where you can name the change and your part in it. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would set the loop up |
| F3 | Defining, instrumenting and reading operational metrics, with comfort with data and SQL (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a metric you defined or reported on, how it was counted, and what decision it fed. Pick a figure you can explain to the denominator. If you have not defined one, say so plainly and describe the metrics you used and what you would measure first |
| F4 | Building scalable processes, playbooks and tooling, including automation (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a process or tool, what it replaced, who used it and how you knew it worked. Pick one where the build was yours or clearly co-owned, and say which. If none comes to mind, say so plainly, then give the nearest thing, or how you would approach it |
| F5 | Cross-functional influence without formal authority (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a time you moved a team you didn't manage, what they wanted, and what made them move. Pick one with a real disagreement in it. If none comes to mind, say so plainly, then give the nearest thing your work carries |
| F6 | Handling escalations, operational risk and compliance-sensitive launches (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: an escalation or risk issue you were part of, what your role was and what you did in the first hours. Pick one where your part is clear. If you haven't handled one, say so plainly and walk through how you would |
| F7 | Clear written communication: launch docs, decision memos, status updates (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a document you wrote that others acted on, and what it changed. Pick one you could describe in two sentences. If none comes to mind, say so plainly, then describe how you would write a launch brief |

## Persona table

No loop source established how Stripe's final round is structured: no schedule, recruiter note or fetched interview guide. So the weights fall back to the **Generic** archetype (flat weights), adjusted only for the fact that this is a final round. That is a pattern, not Stripe's documented process. If your final turns out to be several sessions, send the schedule and the weights get rebuilt per session.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan a launch, diagnose a spike, prioritize requests | High. A final round in the Generic archetype usually includes someone buying capability, and Product Ops work is easiest to test live `[generic]` | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic | Quiet probing of fit, motivation and day-one weakness | High. Final rounds are where remaining doubts get resolved, so this is the round to rehearse hardest `[generic]` | Rehearse B2 until it's boring. Build bridges only from things you actually did, and say limits plainly |
| Data-Driven Prober | Asks how numbers were counted, two levels deep | Medium. Metrics are core to the role family (F3) `[generic]` | Know how each number you mention was counted. Name your weakest assumption before they do, and say plainly when you don't know |
| Peer Evaluator | Seam between teams, credit sharing, "what do you need from me" | Medium. Product Ops sits between teams, so a peer is a plausible interviewer `[generic]` | Lead with reciprocity. Propose principles for the seam rather than pretending to know it |
| Conversational | Friendly "walk me through your journey" openers, still scored | Medium. Almost every session opens this way `[generic]` | A rehearsed 90-second arc. Treat casual questions about the role's core topics as scored |
| Values / Behavioral | Scenario stories, STAR-shaped | Medium-low as a dedicated round. Stripe's values could not be fetched, so no values round is detected; these questions are still common in any session `[generic]` | "We" for context, "I" for your contribution. Choose stories where the hard truth actually landed |
| Pressure | Interrupts, time-boxes, asks how much was actually you | Low-medium. Usually shows up as a single question rather than a whole style `[generic]` | Pause, restate, anchor in what you actually did, hold through two follow-ups, then concede specifically |

## Question banks

**Highest-ROI prep in this pack: B2.** Product Ops owns no roadmap, so "how would anyone know you made a difference?" is the objection most likely to come up in some form. Without your CV, this is inferred from the role family, not from your background. Once you share your CV, the objection may move.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the launch-readiness plan for a new product going live in several countries next quarter. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, which countries, what "launched" means, the hard date and who owns it. Then the objective, then a workstream map (product, engineering, support, go-to-market, risk), a readiness checklist with an owner for each item, a go/no-go moment, and the two or three metrics you would watch in launch week. Name the biggest risk and what you'd do if it hits. The question asks nothing about your past, so the guidance claims nothing about it | Tests F1 live. CASE because it scores structure, not history |
| A2 | "Support contacts about one product area rose 20% the week after a release. Diagnose it." | CASE | [generic] | Clarify before diagnosing: rate or volume, which channel, which customer segment, and what else shipped that week. Split it into a real product problem, a docs or communication gap, a measurement artifact, or a change in the mix of customers. Say what data you'd pull first and why, then what you'd tell product and support today versus after you know more | Tests F2 and F3 together. Metric-diagnosis cases are the classic live test for this role family |
| A3 | "Product, sales and support each send you a list of top requests. You have one quarter. How do you decide what goes to the product team?" | CASE, JD | [generic] | Say the criteria out loud first: customer impact, how many customers are affected, revenue or risk exposure, effort, strategic fit. Explain how you'd make the three lists comparable, who signs off, and how you'd tell each team what didn't make it and why. Close on how you'd know in three months whether you chose well | F2 and F5 under constraint. JD content, CASE delivery |
| A4 | "Design the operating rhythm between product ops and an engineering team that ships weekly. Which meetings, docs and metrics exist, and which do you kill?" | CASE | [generic] | Start from what decisions need to be made and how often, then set the minimum meetings and documents that serve those decisions. Name one artifact you'd write, such as a launch brief, and what goes in it. Say what you'd cut and why: killing process is part of the job | F4 and F7. Tests whether you add process or remove it |
| A5 | "A launch is two days out and the risk reviewer flags a concern nobody planned for. Walk me through your next 48 hours." | CASE | [generic] | Understand the concern precisely before reacting. Find the decision owner, lay out the options (ship as planned, ship with mitigations, delay, ship to a smaller audience) and the cost of each, and say who you'd tell and when. Make clear that you don't overrule the risk call yourself; you make the decision easy and well informed | F6 live. Tests composure and respect for the people who own the decision |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick a real one from the fit snapshot rows you scored weakest, not a disguised strength. Say what it is plainly, what you already do that sits next to it (only if that's true), and a concrete 30-day plan to close it | Every final-round Skeptic asks this in some form. JD because it scores self-assessment against the role |
| B2 | "Product ops owns no roadmap. How would anyone on this team know you made a difference?" | JD, EXP | [generic] | **Highest-ROI rehearsal.** Choose one piece of work where you can name what changed afterwards and how you knew. It needs a before, an after, and a part that was clearly yours. Describe what you did and let the interviewer draw the conclusion; don't tell them it proves anything. Follow-up 1, "how do you know it wasn't the PM's doing?": say plainly which part was yours and which was the team's. Follow-up 2, "so it was really a team effort?": agree about the team, and keep your own piece exactly the size it was. If you can't point to a measured change, say so plainly, then say what you'd measure in this role and how. That's a limit, not a confession | The most predictable objection to the role family, so it gets the most follow-up levels. Inferred, not drawn from your background |
| B3 | "Why leave, why here, why now?" | JD, CO | [generic] | Three short beats in your own words: what you want more of, why this role gives you that, and why now. Base "why here" only on things you've read or seen yourself. This pack has no researched Stripe facts to give you | The motivation check every final round makes. CO because "why here" scores your homework |
| B4 | "How would you handle the data and SQL side of this role?" | JD | [generic] | If you write queries yourself, say what kind and how often, in your own words. If you don't, say so plainly, then describe how you've worked with data so far and a concrete ramp plan. Never claim a level you'd fail a live exercise at | F3 is where a Skeptic tests depth fastest. It's worth an honest answer ready in advance |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick a number from your own work you'd stand behind. Walk me through how it was counted." | EXP | [generic] | Pick a figure you could defend to the denominator. In your own words: what was counted, over what period, by whom, and which part was yours. If you don't know how it was counted, say so plainly. That's an honest answer, and a guessed method is worse | F3. Probers drill whatever number you mention, so choose it before they do |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it yourself before they find it, in your own words, and say what would change if it were wrong. If you don't know the assumptions, say so plainly | The weakest-assumption move turns a gotcha into a gain in credibility |
| C3 | "How would you measure whether a launch-readiness process is working? What's the denominator?" | CASE, JD | [generic] | Separate output measures (launches through the process, checklist completion) from outcome measures (incidents or support contacts per launch, time to fix). Name the denominator explicitly, for example per launch or per customer affected. Say which one you'd trust least and why | F1 and F3. Tests whether you measure activity or results |

### D. Values / Behavioral

Stripe's published values could not be fetched, so these questions are not mapped to them. If you paste Stripe's values page, this bank gets rebuilt around them.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you didn't soften the message, and a working relationship intact at the end. Context as "we", your part as "I", and what happened to the message afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your work carries, or how you would handle it | Product Ops often carries bad news upward. A standard behavioral prompt |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a case with a real trade-off: what the metric said, what the customer needed, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing, or how you would weigh it | Tests judgment where the role's feedback loop (F2) meets its metrics (F3) |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE, VAL | [generic] | Don't pretend to know their seam. Propose principles: who decides what, how disagreements get escalated, and what you'd write down. Then ask what the seam looks like from their side | F5. Peers score whether you'll add to their workload or take some off it |
| E2 | "How do you handle credit when work spans teams?" | VAL, EXP | [generic] | Pick a shared project and say plainly which part was yours and which was others'. If no example comes to mind, describe how you'd credit work that spans teams | Tests attribution honesty in a collegial setting |
| E3 | "What would you need from me in your first 90 days, and what would I get from you?" | CASE | [generic] | Lead with what you'd bring them, then what you'd ask for: context, access, a weekly check-in. Keep the asks small and specific | Reciprocity framing. Peers notice who leads with giving |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc you've rehearsed, built only from your own history: where you started, the turns, and why this role comes next. End on the role, not on your past | Opens almost every session. Casual delivery, still scored |
| G2 | "What are you actually playing with in tooling or automation these days?" | JD | [generic] | Only what you really use or are trying. Say what it is, what problem it solves for you and what you've learned. If nothing current, say so and name what you'd like to try | F4, asked casually, which still means it's scored |
| G3 | "What's caught your eye about Stripe lately?" | CO | [generic] | Base this only on something you've read yourself this week from Stripe's own site, blog or newsroom. Say what it was and the operational question it raises for you. This pack has no researched facts to give you here | The CO slot. Without research it's yours to fill, and it's a strong preparation signal |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give two or three reasons drawn only from what you've actually done, and one honest concession: an internal candidate knows the systems, and you'd close that gap with a concrete plan. Stop on time | Time-boxed composure test |
| H2 | "That result. How much of it was actually you?" | EXP | [generic] | Hold-then-concede. Repeat your part exactly as large as it was. Through two pushes, keep that size and don't inflate it to win the exchange. Concede specifically ("the team did X") without folding your own piece | Follows whatever story you just told, so rehearse it on your B2 and C1 stories |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | A1, C3 |
| F2 Feedback to product input | A2, A3, D2 |
| F3 Metrics and data | A2, B4, C1, C2, C3 |
| F4 Processes and tooling | A4, G2 |
| F5 Influence without authority | A3, E1, E2, E3 |
| F6 Escalations and risk | A5 |
| F7 Written communication | A4 only, as one strand. Gets its own question once a JD shows how much weight writing carries |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a great first six months look like in this role, and what would tell you it hadn't worked?" | It asks for the scorecard, which shows you plan to be measured |
| R2 | "Which teams does this role sit between, and where does work fall through the cracks today?" | It shows you understand the role and gives you the real seam for E1-style follow-ups |
| R3 | "Can you share a recent case where product ops input changed what the product team built?" | It tests how much influence the role really has, which is the B2 question turned around |
| R4 | "How is product ops' impact measured here today?" | It shows metric discipline and tells you how you'll be judged |
| R5 | "What's one process here you'd love to see retired?" | It signals you remove process as well as add it, and it usually gets a candid answer |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for any peer interviewer |

## Prohibited claims

Nothing is listed yet. The pack holds no sentences about your past, so there is nothing to inflate and no stated gap to protect. That is a statement about the inputs, not a clearance. Once your CV or background arrives, this section will list the stretched versions of your own lines that the pack won't coach. Until then the standing rule applies to every answer above: say only what you did, at the size you did it.

## Sources

- Provided documents: your message ("final-round interview at Stripe for a Product Operations Manager role").
- Search "Stripe operating principles": refused
- Search "Stripe interview process final round onsite operations role": refused
- Search "Stripe strategy news 2026": refused
- Search "Stripe "Product Operations" manager job description": refused
- Fetches: none sent

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. Would have given official value names to theme the D bank and, if a values round were detected, a values cheat sheet |
| 2. Stripe interview process, operations role family | unavailable | Search refused. Would have named the final round's sessions and replaced the Generic-archetype weights |
| 3. Stripe strategy / recent news | unavailable | Search refused. Would have grounded G3, B3 and at least one CASE question in Stripe's current priorities |
| 4. Interviewer name + Stripe | n/a | No interviewer name given, so no query could be formed. No interviewer read |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. Would have turned the `[generic]` fit snapshot rows into quoted `[inferred]` requirements |

## Upgrade menu

- The JD text → the seven `[generic]` fit rows become quoted, `[grounded]` requirements, and the JD-tagged questions get rebuilt against Stripe's actual list
- Your CV or a few lines on your background → the worksheet becomes a real fit snapshot, guidance goes from story-selection to story-mapped, the highest-ROI objection is drawn from your actual gaps, and the prohibited list gets real entries
- The final-round schedule and interviewer names or titles → per-session mini-packs with their own persona weights, an interviewer read, and a tailored reverse question per person
- The recruiter's prep email → coverage of any declared presentation, case or take-home as its own build section, plus their stated focus areas
- Allowing web search in this session → Stripe's official values, loop structure and recent strategy, which lifts the D, G3 and B3 rows off `[generic]`
- A deeper research pass, once search is allowed → up to 6 more searches and 2 more fetches (several more minutes) for a strategy brief and role-family loop reports, feeding a sharper CO and CASE bank
- How much prep time you have → a prioritized prep schedule at the top of the pack
- A tuesday-dossier.md from a job-underwriter run → verified evidence and pre-set limits on what to claim; useful, never required
