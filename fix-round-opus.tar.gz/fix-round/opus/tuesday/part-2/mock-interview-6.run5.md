I've written one prep pack covering all three rounds: `larkfield-systems_engineering-manager_interview_pack.md` in your working folder. I couldn't research Larkfield because the web searches were refused (web search permission isn't granted in this session). Anything company-specific is therefore marked as a general pattern, not a fact about Larkfield.

All three rounds share one table that matches each line of the role text against your own words. Then each round gets its own section:

| Round | Main interviewer styles | Questions |
|---|---|---|
| Tuesday, Director (45 min) | Skeptic and live problems | 11 |
| Thursday panel (60 min) | Probing your numbers and peer fit, plus the PM's behavioural questions | 12 |
| Monday VP (30 min) | Values and leadership, under time pressure | 10 |

- **Most important thing to rehearse: question A1.** It's the step from leading one team of 6 to two squads of 11. Expect some version of it in all three rounds. The pack has you say your real scope first, then give a plan, without adding to either.
- **Your two stated gaps get plain answers.** For managing managers and hardware roadmaps, the pack uses your own words: "I haven't managed managers" and "I haven't owned a hardware-adjacent roadmap." It doesn't try to make either gap sound smaller.
- **The 60% on-call drop will be probed hardest.** It comes up on Tuesday and again from the staff engineers. The pack keeps your word "after" and never turns it into "because". Before Thursday, be ready to say how the figure was counted and how much of it was yours.
- **Monday has no values cheat sheet.** I didn't have Larkfield's published values. If you paste their values page, I can map each value to one of your stories.

The end of the pack lists what else would improve it.

I can play the Skeptic on A1 as a live mock interview. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, for later sessions, or convert the pack to a Word document.

Could you paste your CV? It would turn about half a dozen generic answer outlines into answers built on your actual stories. The pack works without it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop. Three scheduled rounds share one fit snapshot, and each round gets its own mini-pack.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager (your would-be boss) |
| 2 | Thursday after | Two staff engineers and a product manager | 60 min | Panel: technical peers plus a cross-functional partner |
| 3 | Following Monday | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

Interviewer names weren't given, so this pack has no "reading the interviewer" section.

---

## How to use this pack

- **Personas** describe *how* a question is asked: a skeptic probing a gap, a peer testing how you'd work together, a prober asking how a number was counted.
- **Types** describe *what* is being scored:
  - **VAL**: whether past behaviour shows values and leadership philosophy
  - **EXP**: whether what you say about your own work holds up under questioning (what was actually you)
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: company and strategy altitude
  - **CASE**: a live problem from the role, reasoned out loud
- **Provenance labels:** `[grounded]` means traceable to your message or the role text you gave. `[inferred]` means derived, with the derivation named. `[generic]` means a role-family pattern with no claim about Larkfield or you.
- **Answer slot:** a place where the pack doesn't know the answer and won't make one up. It names the likely probe and gives two honest branches. Fill it in your own words, or say plainly that it wasn't yours or didn't happen.
- Guidance is scaffolding, not a script. Each answer should be speakable in 90–120 seconds.

---

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the role text you supplied. Evidence is quoted from your message, word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material says one team of six, led for three years. Two squads and 11 engineers is the step up, and your words stay at their own scope: "For three years I've led a team of six." How you would run two squads is said as a plan, never as a past. If someone asks whether you've managed managers, you have already given the words: "I haven't managed managers." |
| F2 | "own delivery, hiring and growth for 11 engineers" — role text (delivery) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | Pushing a quarter through against roadmap pressure touches delivery, because it was a prioritisation call. It doesn't show whether delivery planning was yours to own. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: expect a probe on how that quarter's work was planned and sequenced. If that was yours, say how, in your own words. If it sat with someone else, or there was no such step, say so plainly and stay with pushing the quarter through |
| F3 | "own delivery, hiring and growth for 11 engineers" — role text (hiring) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running a loop and interviewing is adjacent to owning hiring for a team. Your material doesn't say what else running it covered. Words: "I run our hiring loop for backend roles — about 40 interviews last year." Answer slot: the role's hiring line makes a probe on how the loop works likely. If any part of how it runs was yours to set, say which and how, in your own words. If none was, say so plainly and stay with running it and the interviews |
| F4 | "own delivery, hiring and growth for 11 engineers" — role text (growth) | none given | none | [grounded] | discovery | Your material doesn't show growth work either way. Answer slot: the role's growth line makes a probe on how you have grown engineers likely, for example feedback, career conversations or promotion cases. If you've done this, pick one person and say what you did and what changed, in your own words. If it wasn't part of your role, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" — role text (product) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | "Against roadmap pressure" touches roadmap negotiation but doesn't show who was on the other side. Answer slot: expect a probe on how the quarter got agreed. If agreeing it involved a product partner, say how it went and what part was yours, in your own words. If it was settled some other way, say so plainly and stay with what you pushed |
| F6 | "partner with hardware and product on roadmap" — role text (hardware) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You have stated this gap yourself, and no wording closes it. Words: "I haven't owned a hardware-adjacent roadmap." Then say how you would learn it, as a plan and never as a past. Don't add anything to make the gap feel smaller |
| F7 | "industrial IoT" — role text (company line) | none given | none | [grounded] | discovery | Your material says nothing either way about device, firmware or fleet-scale work. Answer slot: expect "what do you know about managing a device fleet?" If you've worked near devices or fleet-scale systems, say where and what part was yours, in your own words. If you haven't, say so plainly and say how you'd ramp |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: lead two squads, 11 engineers | A1, B1, P1, Q1 |
| F2: own delivery | B1, B3, H2 |
| F3: own hiring | D2, H3, M2 |
| F4: own growth | C2, M3 |
| F5: partner with product on roadmap | B2, H2, K2, N2 |
| F6: partner with hardware on roadmap | A3, B2, H1, N2 |
| F7: industrial IoT, device management | A2, A4, G3, J1 |
| Your 60% on-call figure | B3, D1, G1, P2 |
| Your "about 40 interviews" figure | D2 |

**Highest-ROI prep in the pack: A1**, the step from one team of six to two squads of 11. Some version of it will come up in every round: the Director as risk, the staff engineers as "will you cope", the VP as "are you ready". Rehearse it until it's boring.

---

## Round 1: Tuesday, Director of Engineering (45 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scope step (F1), the hardware gap (F6) and the domain switch (F7) | High. A hiring manager is reducing the risk of a hire they will own, and F1, F6 and F7 are where your material is thinnest | Rehearse A1 until it's boring. Hold only what your quotes carry, name the limit first, then give a plan |
| Case / Strategist | Live problems set in the role: inheriting squads, hardware slips | High. Case is a hiring-manager prior, and a would-be boss tests how you'd run *their* teams | Clarify → objective → approach → risks. Think aloud, and challenge one premise respectfully |
| Conversational | The "walk me through your journey" opener and casual asides | Medium. 45 minutes usually opens with rapport, and that part is still scored | A 90-second arc built only from your quoted sentences |
| Data-Driven Prober | "How was the 60% counted?" | Medium. A headline figure attracts probes, though it's less central here than on Thursday | Know what you can and can't say about how it was counted |
| Pressure | Time-boxed "why you" | Low here. It's heavier on Monday | See P1 |

### Question bank

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This is two squads and 11 engineers. You've led a team of six. What changes for you, and why are you ready?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI rehearsal.** Hold only what the quote carries: "For three years I've led a team of six." Name the limit before they do: one team of six, and this is two squads of 11. Then the plan, said as a plan: what you'd want to learn first about each squad and how you'd split your time between them. Asking how the squads are led today is a fair clarifying move, not a dodge. If they ask whether you've managed managers: "I haven't managed managers." Hold through two follow-ups by returning to the team of six and the plan, never by adding to either | F1 is the widest step in this loop, and a would-be boss owns the risk of getting it wrong. JD because it scores the stated scope directly |
| A2 | "Your background is payments. Why device management, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | The fact is "I'm currently at a payments company." The why is yours: give your real reasons for this move, in your own words. Don't claim device knowledge, because your material shows none (F7). Interest isn't experience, so say it as interest | F7 makes the domain switch the obvious motivation probe. JD because the role text names the industry |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The honest answer is already yours: "I haven't owned a hardware-adjacent roadmap." Then give a ramp plan, said as a plan: who you'd sit down with on the hardware side first and what you'd want to understand about how their schedule shapes yours. Don't follow it with a bridge your material doesn't carry. A clean concession plus a concrete plan beats a stretched bridge | F6 is a gap you stated, and this persona stem invites it. JD because it scores the partnership line |
| A4 | "What do you actually know about running services for a fleet of devices?" | JD | [grounded] | Answer slot, as F7: if you've worked near devices or fleet-scale systems, say where and what part was yours. If not, say so plainly, then say what you'd want to learn first and how. The question needs no claim about your past, so the guidance makes none | F7 has no evidence either way, and a device-management director will check. JD because the role text names device-management services |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit two squads mid-quarter, and one is behind on a release. What do you do in your first 30 days?" | CASE | [generic] | Clarify first: what was committed, to whom, and whether a hardware date depends on it. Then diagnose before reshuffling, decide what to protect and what to cut, and say how you'd tell the people affected. The question asks about no past, so the guidance makes none | Covers the two-squad scope (F1) and delivery (F2) as a live problem. `[generic]` because it's a pattern, not a fact about Larkfield |
| B2 | "Hardware slips a device launch by a quarter. Product wants your squads to hold their date anyway. What do you do?" | CASE | [generic] | Clarify what the service date actually serves if the device is late. Lay out the options with their costs, get hardware and product in one conversation, and make a recommendation. Name the risk you'd accept. No claim about your past | Tests the partnership line (F5, F6) without needing hardware history. `[generic]` because the scenario is a pattern |
| B3 | "How would you decide between reliability work and roadmap features for these squads?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Give the framework first: how you'd weigh on-call load, customer impact and commitments. Then one example, in the quote's own terms: you pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% after. Keep "after". Don't turn it into "because" unless you know that's true (see D1) | The reliability quarter is the strongest story you gave, and the Director will want to know whether you'd do it again here. CASE content, EXP evidence |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc using only these beats: nine years in engineering, the last three leading a team of six, currently at a payments company; you run the backend hiring loop, about 40 interviews last year; the reliability quarter you pushed through against roadmap pressure, after which on-call burden dropped 60%. End on why this role, in your own words | The opener sets the frame for the whole 45 minutes. EXP because every beat can be probed |
| C2 | "Tell me about someone on your team you helped grow." | JD | [grounded] | Answer slot, as F4: if you've done this, pick one person and say what you did and what changed, in your own words. If no such case comes to mind, say so plainly, then say how you'd approach growth for 11 engineers | The role text names growth, and F4 has no evidence either way. JD because it's a stated responsibility |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "On-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, each in your own words: how the 60% was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours. "I don't know exactly how it was counted" is an honest answer. Name your weakest assumption before they do. The quote says the drop came *after* the quarter, so keep that word | Every headline figure gets a defend-the-number question. This is your only percentage, so it attracts probes |
| D2 | "About 40 interviews last year. What did that teach you about a good backend hire?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Your view, in your own words, drawn from interviewing. If they ask how the 40 is counted, your own word was "about", so say it's approximate. Answer slot, as F3: if any part of how the loop runs was yours to set, say which. If none was, say so and stay with running it | F3, plus the second figure in your material. The Director will be hiring through you |

### Reverse questions: Tuesday

| Question | Why it lands |
|---|---|
| "What does success look like for this role at six and twelve months?" | It gets the real bar from the person who will hold you to it |
| "How are the two squads led today: tech leads, a single backlog, or separate ones?" | It answers F1's open question honestly and shows you're thinking about the structure you'd inherit |
| "How does device-management work get planned against hardware schedules today?" | It goes straight at F6 and turns your gap into diligence |
| "What's the biggest delivery risk these squads carry right now?" | It invites them into a working conversation, the way your boss would brief you |
| "How do you like to work with your EMs: cadence, and where you want to be involved?" | It's the would-be-boss question, and it signals you're already modelling the relationship |
| "What made this role open?" | It tells you whether you're backfilling, growing the team or fixing something |

---

## Round 2: Thursday, panel of two staff engineers and a PM (60 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Staff engineers ask what was technically in the reliability quarter and which part moved the number | High. Technical specialists verify depth, and the 60% is the one figure in your material | Know what you can and can't say. Name your weakest assumption first |
| Peer Evaluator | "Where's the seam?" and "What would we get from you?" from both engineers and the PM | High. The panel is pricing what you add to their work or cost it | Reciprocity framing: propose seam principles rather than pretending to know the seam |
| Case / Strategist | Incident and prioritisation scenarios set in device management | Medium. The panel is likely to test reasoning live | Clarify, structure, then answer |
| Values / Behavioural | The PM's partnership and customer stories | Medium. A cross-functional interviewer usually tests behaviour | Stories only where your quotes carry one, otherwise honest scaffolds |
| Pressure | Follow-ups that push on attribution | Low, but it shows up through the Prober's second follow-up | Hold, then concede |

Who will ask what isn't known, since names weren't given. Assume the staff engineers lead G, H1 and H3, and the PM leads H2, J2, K1 and K2.

### Question bank

**Data-Driven Prober (staff engineers)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What was actually in the reliability quarter, and which part moved the 60%?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your material says what you did, pushing the quarter through, not what work it held. Answer slot: say what the work was and what part of it was yours, in your own words. If you don't know which part moved the number, say so plainly. The quote supports "after", not "because" | Staff engineers will go a level below D1. This is the seam a prober finds |
| G2 | "How hands-on would you be as EM of two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | The fact you have is nine years in engineering. The rest is a plan: where you'd stay close to technical decisions, where you'd defer to staff engineers, and how you'd avoid becoming the bottleneck | Staff engineers are pricing whether you'll crowd their decisions or leave them on their own. JD because of the two-squad scope (F1) |
| G3 | "A bad rollout on device-management services can reach devices in the field. How would you run on-call for that?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure: staged rollouts, a rollback path, who gets paged, and how you'd learn from each incident. Draw on your one quoted fact, the reliability quarter and the drop after it, and don't claim device rollout experience, because your material shows none (F7) | F7 asked as a live problem, so it can't be bluffed. The quote gives you a real anchor without stretching it |
| G4 | "Tell me about a technical decision on your team you disagreed with. What happened?" | EXP | [generic] | Selection scaffold: pick a time with a real stake, a view you stated, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | It tests how you disagree with equals, which staff engineers care about directly |

**Peer Evaluator (both engineers and the PM)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Your squads sit beside hardware. Where's the seam, and what happens when we disagree?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Propose seam principles, such as shared release calendars, early heads-up on interface changes and one named owner per dependency, rather than pretending to know their seam. If asked about your hardware experience: "I haven't owned a hardware-adjacent roadmap." Then say what you'd want to learn from them first | F6, put collegially. A persona stem with JD content |
| H2 | "When product wants a date and your team needs reliability time, how do you handle it?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The example in the quote's terms: you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Answer slot, as F5: if agreeing it involved a product partner, say how it went and what part was yours. If it was settled another way, say so plainly and stay with what you pushed. To the PM, show you'd bring the trade-off to them, not around them | It's the PM's partnership question, aimed at F2 and F5. Your strongest story, told to the person most affected by it |
| H3 | "What would you need from us, and what would we get from you?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Reciprocity first. One thing you can bring rests on the quote: you run a hiring loop, so you could help hire for their squads. Then what you'd ask of them, said as a plan. Don't claim more of the loop than running it (F3) | The panel prices load and contribution. Hiring help is concrete value for an 11-person scope |
| H4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: a case where you named others' parts specifically. If no such case comes to mind, say so plainly, then say how you'd handle it | A persona stem the PM and engineers both care about |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A firmware change ships, and the device-management API starts seeing error spikes from part of the fleet. Walk us through the first hour and the first week." | CASE | [generic] | First hour: contain the damage (can the firmware be paused or rolled back?), decide who leads, and communicate with hardware and support. First week: root cause across the seam, what changes in release gating, and a blameless review. No claim about your past | F6 and F7 as a live problem, which tests reasoning without device history. `[generic]` because the scenario is a pattern |
| J2 | "Next quarter we can fund one of two things: rollout tooling or a fleet-health view. How would you help us decide?" | CASE | [generic] | Clarify which problem costs more today. Agree the decision criteria with the PM, size both options roughly, make a recommendation and name what you'd give up. No claim about your past | The PM sees how you partner on roadmap (F5). `[generic]` because the options are illustrative, not Larkfield's actual roadmap |

**Values / Behavioural (PM)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a case with a named customer impact, a metric you let slip, and a reason you'd stand behind. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A persona stem that cross-functional interviewers favour |
| K2 | "Tell me about a time you disagreed with a product decision." | VAL | [generic] | Selection scaffold: a real disagreement, how you raised it, and how it ended, including if you lost. If no such time comes to mind, say so plainly and say how you'd handle one with this PM | The role text's "partner with hardware and product on roadmap" makes this the PM's likeliest behavioural probe (F5) |

### Reverse questions: Thursday

| Question | Why it lands |
|---|---|
| (To the staff engineers) "What could a new EM do in the first month that would genuinely help your work?" | It's the reciprocity question, and it shows you're thinking about their load |
| "Where do staff engineers and the EM split technical decisions on these squads today?" | It goes at the seam G2 raises, and tells you what you'd inherit |
| (To the PM) "How does roadmap get set between product, hardware and these squads, and who has the last word?" | It goes at F5 and F6, and the answer tells you what partnering actually means here |
| "What's on-call like for device-management services right now?" | It's diligence on the area where your strongest story lives |
| "What did the previous person in this seat do that you'd want kept, or changed?" | It invites honesty and shows you're not arriving with a fixed playbook |
| (To the PM) "What's one thing you want from engineering that you're not getting today?" | It turns the panel into a working session |

---

## Round 3: Monday, VP Engineering, "values and leadership philosophy" (30 min)

A values-style round is detected here because the recruiter described it as one. The **values cheat sheet is not included**: Larkfield's published values weren't available (the search was refused, and nothing was pasted). Values questions below are themed from the recruiter's words and standard behavioural prompts, not from Larkfield's own value names. See the upgrade menu.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "What's your leadership philosophy?" and "tell me about a time" prompts | High. The recruiter named the round's focus | State principles you hold, each tied to something your quotes carry. Where none carries one, give an honest scaffold |
| Case / Strategist (strategy-heavy) | Altitude: where engineering leadership matters at a 600-person IoT company | Medium. A skip-level executive tests altitude | Clarify, think aloud, and assert nothing about Larkfield you haven't read |
| Pressure | Time-boxed "why you", "how much was actually you" | Medium. Executives with 30 minutes compress the conversation | Pause, anchor in what you said, hold, then concede |
| Conversational | Forward-looking and closing questions | Low to medium. A short slot leaves little room for rapport | Short, true answers |

### Question bank

**Values / Behavioural**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "What's your leadership philosophy, in a couple of minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | Two or three principles you actually hold, in your own words. Each one gets one piece of evidence, only as the quotes say it: you pushed a reliability quarter through against roadmap pressure, and you run the backend hiring loop. A principle with no evidence behind it is said as a belief, not as a track record | The recruiter's words name this as the round's centre. VAL because it's scored against behaviour |
| M2 | "How do you think about the bar in hiring?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Your view, in your own words, drawn from running the loop and interviewing. Answer slot, as F3: if any part of how the loop runs was yours to set, say which. If none was, say so and stay with running it | Hiring is a named responsibility (F3) and a common leadership-philosophy probe |
| M3 | "Tell me about a time you got it wrong with someone on your team." | VAL | [generic] | Selection scaffold: a real misstep, what you noticed, what you changed, and what happened after. If no such time comes to mind, say so plainly, then say how you'd want to learn from one | It's a leadership-philosophy staple, and it touches growth (F4). It tests candour, which also defuses Skeptic material from earlier rounds |
| M4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the quote, with only its beats: there was roadmap pressure, you pushed a reliability quarter through it, and the team's on-call burden dropped 60% after. Tell how it happened in your own words, and only what happened. Use "I" for what you pushed and "we" for the team's work | Your one quoted story with a stake in it. The VP will be weighing whether you'll push back on their roadmap too |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| N1 | "Where does engineering leadership matter most at a company like ours?" | CO | [generic] | Clarify what they see as the hard problems. Reason out loud about the hardware–software seam and fleet-scale reliability as hypotheses, not facts about Larkfield. Ask, don't assert. Research didn't run, so the pack holds no Larkfield strategy facts for you to use | CO questions go generic without research, which is the honest cost here. `[generic]` throughout |
| N2 | "Your squads and the hardware team both want the same quarter. How do you decide, and how do you tell the side that loses?" | CASE | [generic] | Name the decision criteria, who decides, and how you'd tell the losing side with the reason and what they get next. No claim about your past | F5 and F6 at VP altitude. `[generic]` because the scenario is a pattern |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, then three facts: three years leading a team of six, running the backend hiring loop, and the reliability quarter. Hold-then-concede: if pushed on hardware, concede with "I haven't owned a hardware-adjacent roadmap" and pair it with your ramp plan. Don't fold on the three facts to restore harmony | A persona stem, and F1 under a time limit. JD because it's about the role's scope |
| P2 | "That on-call drop: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold what the quote says was yours: you pushed the quarter through against pressure. The drop was the team's on-call burden, and it came after. Answer slot: what share was yours, in your own words. If you can't separate it, say so plainly. Hold through two follow-ups, then concede the attribution limit specifically | A persona stem, aimed at the one figure that executives will push on |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "What kind of leader do you want to be in a few years?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Your aim in your own words. If it involves leading leaders, say it as an aim: "I haven't managed managers", and say what you'd want to learn first | Ties leadership philosophy to F1 honestly, and connects to the reverse question on growing EMs |
| Q2 | "Anything from your conversations so far that gives you pause?" | CO | [generic] | Name one real question carried from Tuesday or Thursday, put as curiosity, not as a complaint | Executives often close this way. A specific answer shows you were listening across the loop |

### Reverse questions: Monday

| Question | Why it lands |
|---|---|
| "What leadership behaviour do you most want from EMs here that's hard to find?" | It's the values round turned back to them, and the answer tells you the real bar |
| "How do device-management services fit where Larkfield is heading?" | It's altitude without asserting strategy you haven't read |
| "When an EM pushes back on roadmap pressure for reliability, how does that usually land here?" | It goes at your strongest story, and it's real diligence on whether that would be welcome |
| "How do you grow EMs toward leading managers?" | It's honest about F1 and signals ambition without overstating |
| "What's a call you made as VP that you'd make differently now?" | It invites the same candour you've been showing, which suits a values round |

---

## Prohibited claims (shared)

These are the claims this pack won't coach, each with its basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated (F1) | "I haven't managed managers." There's no slot for this |
| Has owned a hardware-adjacent roadmap | A negative you stated (F6) | "I haven't owned a hardware-adjacent roadmap." There's no slot for this |
| Has led multiple teams, or 11 engineers | An inflated form of F1's quote | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says one team of six |
| Owned hiring for a team | An inflated form of F3's quote | F3's quote at its own scope. Your material says you run the loop and did about 40 interviews. It doesn't say what else running it covered. The slots stay inside running the loop |
| Owned delivery for the team | An inflated form of F2's quote | F2's quote at its own scope. The slots ask only how the quarter's work was planned |
| Co-owned a roadmap with product | An inflated form of F5's quote | F5's quote at its own scope. The slots ask only how the quarter got agreed |
| Personally cut on-call burden by 60%, or caused the drop | An inflated form of your on-call sentence | The quote as given: your team's on-call burden dropped 60% after you pushed the quarter through. Your material doesn't say what share the quarter caused or who did the work |

---

## Sources

- **Provided:** your message (the role text, the round schedule and your background).
- **Searches sent** (all refused because web search permission wasn't granted):
  - "Larkfield Systems values": refused
  - "Larkfield Systems interview process engineering manager": refused
  - "Larkfield Systems industrial IoT news": refused
- **Fetches:** none.
- **Dossier:** none present, so the pack was built from raw inputs.
- **Loop:** established by your own words (three rounds, each naming who runs it), so no archetype fallback was used. The values-style round is detected for Monday, from the recruiter's description you relayed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Search refused. It would have supplied the Monday values cheat sheet, which is dropped, and Larkfield's own value names for the M bank |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Search refused. It would have supplied panel and case formats within the rounds and adjusted persona weights inside each round. The rounds themselves rest on your words |
| 3. `Larkfield Systems` strategy / recent news | unavailable | Search refused. It would have grounded N1, J1 and J2 in Larkfield's actual strategy and sharpened the reverse questions. They stay `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form. The interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role text you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Your CV → F2, F4, F5 and F7 could move off `discovery`, and the scaffolds in C2, G4, H4, K1, K2 and M3 could become story-mapped answers
- Larkfield's values or leadership-principles page, pasted → a Monday values cheat sheet mapping each official value to one of your stories, with the M bank re-themed on Larkfield's own value names
- Allowing web search → targets 1–3 (values, interview process, current strategy), with N1, J1 and J2 grounded in Larkfield's actual direction
- A deeper research pass, once search is enabled (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, interviewers' public talks and writing, loop reports and recent org context
- Interviewer names (Director, both staff engineers, the PM, the VP) → a per-round interviewer read, per-member persona assignment on the panel, and a reverse question tied to each person's path
- The recruiter's prep note for Thursday → whether there's a system-design exercise, a case or a presentation, with a build section for any that exist
- The full job posting → more requirement rows and JD questions than the one-line role text supports
- How many prep hours you have before each round → a prep triage per round, in order of value
- Your answers to the answer slots on F2, F3, F4, F5 and F7, told to me outside a drill → those rows regrade, and the questions that draw on them get rewritten
- A tuesday-dossier.md from job-underwriter → an evidence-derived ranking of objections and a strategy per weak area. It would sharpen this pack, but the pack is complete without it
