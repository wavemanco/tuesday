Your prep pack for Priya's 60-minute peer conversation with Dan is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-1-denied-7a6c84cb/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`.

- **What it rests on:** only the material in your message. I treated your JD highlights and background summary as the JD and CV.
- **No web research yet:** a search would send Northwind's and Dan's names to an outside service, so I held off until you say it's OK.
- **Structure:**
  - An 8-row fit snapshot of requirements against Priya's evidence.
  - A section on reading Dan.
  - A persona table with the reasoning behind each weight.
  - 21 questions across 7 personas. Each is tagged by type and has answer guidance and a rationale.
  - A table showing which questions cover each JD requirement.
  - 7 reverse questions.
  - A list of claims the pack won't coach.
- **Personas, in order of weight:** Data-Driven Prober, Peer Evaluator, Case/Strategist (tilted toward pricing), Skeptic, Pressure, Conversational, Values.
- **Highest-ROI item: D1.** It's the "no sales-ops or quota background, coming from consumer tech" objection, and someone who runs Sales Strategy will raise it in some form. It has the deepest rehearsal in the pack: admit the gap first, then the closest work she has actually done, then a ramp plan.
- **Second priority: D2.** It covers the only JD item marked "required", partner-motion design, where her closest evidence is the revenue model she built.
- **Wording to watch:**
  - The ~$400M was "credited" to a change she "proposed". The pack keeps it that way and doesn't let it become "drove $400M".
  - The revenue model was "used in carrier negotiations". The pack doesn't turn that into Priya negotiating the deals.

Say the word and I'll play the Skeptic on D1 with Priya, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document or a shareable web page, say so and I'll convert it.

1. Can you paste the full JD and Priya's actual CV? The answers would then quote her own wording, and any JD items beyond the highlights would get questions. The pack works as it is if you'd rather not.
2. Is it OK for me to search the web for Northwind's published values and Dan's public professional footprint? That's up to 6 searches and 2 page fetches, using their names.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya · **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer (both report to the same VP) · **Format:** one 60-minute conversation

---

## How to use this pack

Two axes organize every question:

- **Persona** is *how* a question arrives: the style, the register, the follow-up pattern. Banks are ordered by how likely each persona is in this conversation.
- **Type** is *what* is being scored:
  - **VAL**: behavioral or values alignment. Past behavior against stated values.
  - **EXP**: work-experience deep-dive. Whether the claims in Priya's background survive scrutiny, and what was actually hers.
  - **JD**: role or JD-driven. Whether she can do the listed job, gaps included.
  - **CO**: company and strategy knowledge. Whether she can think at Northwind's altitude.
  - **CASE**: hypothetical or live problem, solved out loud.

Fit-snapshot rows are F1 to F8. Bank question IDs are lettered by persona (A, B, C, D, E, G, H). **F is skipped** so a bank ID can never be mistaken for a fit row.

Guidance is scaffolding, not a script. Where a cell says **answer slot**, the pack doesn't know the answer. Priya fills it from what actually happened, in her own words, or says plainly that it didn't happen or wasn't hers.

**Highest-ROI prep in this pack: D1**, the "no sales-ops or quota background, coming from consumer tech" objection. A Director of Sales Strategy will raise it in some form. If she rehearses only one question, it should be this one.

---

## The fit snapshot

Requirements are quoted from the JD highlights in the coach's notes. F7 and F8 are not in those highlights: they are role-family requirements for a seat beside Sales Strategy, so they're written as plain prose and labeled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material says product strategy & ops, plus a change she proposed. It does not show GTM ownership for a product line, so the words stay at the quotes' scope: "Nine years in product strategy and ops; I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's GTM-ownership line makes a probe on go-to-market decisions likely. If any were hers to make, she says which ones and how she decided, in her own words. If none were, or they weren't hers, she says so plainly and stays with product strategy & ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | Proposing one change that was credited with uplift touches opportunity-finding. It doesn't show mapping opportunity across a customer lifecycle, and the bridge shouldn't stretch. Answer slot: if she has sized or mapped growth opportunities across an existing customer base, she says how, in her own words. If not, she says so plainly and walks through how she would approach it (C3 rehearses this) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but nothing has been inspected behind the line, and a self-described data-driven interviewer will probe it. She says it at its own scope: skilled in SQL and Tableau. The JD's word "independent" is what A3 rehearses |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote is a model she built that was used in carrier negotiations. It is not the design of a partner motion, and it doesn't say she negotiated. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on partner terms, tiers, incentives or route to market likely. If any of that was hers to shape, she says which and how. If none was, she says so plainly and stays with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. She leads with it as her cross-functional example, worded as the quote is: "I set annual volume targets with cross-org consensus." Nothing is added to it |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Daily tool use is adjacent to AI experience in a role launching an AI copilot. It isn't the same thing. Answer slot: the JD's AI line makes a probe on AI in products or workflows likely. If she has worked on an AI product, feature or workflow beyond her own use, she says what, in her own words. If not, she says so plainly and stays with daily use |
| F7 | Sales-ops or quota-setting grounding, for a GTM seat next to Sales Strategy (role-family, not in the JD highlights) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [generic] | capability | A stated gap that wording can't close. Words: "I haven't done classic sales-ops or quota-setting work." Then how she would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F8 | Familiarity with B2B or enterprise SaaS go-to-market (role-family, not in the JD highlights) | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [generic] | discovery | The material says consumer tech and doesn't show whether any of the work faced business customers or a sales team. Strong evidence would be work where the counterpart was a business buyer or a sales organization. The nearest item in the material is F4's model, used in carrier negotiations, kept at that scope. Selection scaffold: she picks the work in her history that sat closest to a business buyer or a sales team. If none comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she would get up to speed |

---

## Reading the interviewer

Everything here comes from the profile summary in the coach's notes. No public research ran (see Sources).

| What's known | Source | Practical implication | Provenance |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | Coach's notes, from his profile | Every number in Priya's background will be probed to its assumptions. The Prober bank (A) is weighted highest, and "I don't know how that was counted" beats a guessed method | [grounded] |
| Career spine is pricing and monetization roles | Coach's notes | Case questions tilt toward packaging, pricing and unit economics. C1 and C2 are framed that way. Pricing trade-offs are his native language, so name them explicitly | [grounded] |
| One early-stage-startup chapter | Coach's notes | Expect a probe on whether a big-company operator can move scrappily on emerging products (D3, E2) | [inferred] |
| Director of Sales Strategy, a peer reporting to the same VP | Coach's notes | He is also weighing what this hire adds to or takes from his own team's work, so seam and reciprocity questions are likely (bank B) | [grounded] |
| Mirror opportunity: shared vocabulary in revenue modeling | Coach's notes; F4 | F4's quote, "built a partner-level revenue model used in carrier negotiations", sits close to his pricing and monetization spine. Offer to walk through the model's logic when it comes up (A2), without stretching it into pricing ownership | [inferred] |

---

## Persona table

Weights start from the peer-round prior (Peer Evaluator and Data-Driven Prober dominant), then shift on his stated profile. The loop is fixed by the coach's notes: one 60-minute conversation with Dan. No dedicated values round was named.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | "How was that counted?", "What was the denominator?", follow-ups two levels deep | **Highest (5 questions).** Peer prior, plus his "relentlessly data-driven" self-description | Know what she can and can't say about how each number was counted. Name the weakest assumption before he does. Offer to walk through analysis she did herself |
| B. Peer Evaluator | "Where's our seam?", "What would you need from me?", credit questions | **High (4).** He'd be her peer under the same VP | Reciprocity first: what she brings his team. Propose seam *principles* rather than pretending to know the org chart |
| C. Case / Strategist | Live problems on Compass, bundling and whitespace, with a pricing tilt | **Mid (3).** Peer prior is low, but his pricing and monetization spine and the role's strategy content raise it | Clarify, objective, segment, approach, metrics, risks. Think aloud. Challenge one premise respectfully per case |
| D. Skeptic | Quiet probes on the consumer-to-B2B jump and the sales-ops gap | **Mid (3), but holds the highest-ROI item.** F7 and F8 are exactly what a Sales Strategy director would test, and the startup chapter adds a scrappiness probe | Acknowledge the gap first, plainly. Bridge only with quoted adjacent work. Give a concrete ramp plan |
| E. Pressure | Short, pointed versions of A and D: "how much was actually you?", "sixty seconds" | **Low (2).** Not his stated style, but a data-driven peer often presses on attribution | Pause, restate, hold the core claim through two follow-ups, then concede the specific uncertainty |
| G. Conversational | Opening "walk me through it", casual AI chat | **Low (2).** Peer rounds usually open warm. "AI experience a plus" in the JD makes casual AI chat a scored moment | A 90-second arc, rehearsed. Treat casual questions on Compass and AI as scored |
| H. Values / Behavioral | "Tell me about a time…" stories | **Low (2).** No values round was named and no published values are in hand | Pick stories with a real stake and an intact relationship at the end. Say "I" for her part and "we" for context |

---

## Question banks

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift from the store-surface change was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F1 and F2: she proposed the change, and the change was credited with a ~$400M ARR uplift. Keep both verbs, "proposed" and "credited", because they are the attribution. Answer slots, each in her own words: how the figure was counted; what it is sensitive to; the assumption behind it she would defend least, named before Dan asks; which part of it was hers. If she doesn't know how it was counted, she says so plainly and returns to what she proposed | The headline metric in her background, put in front of a self-described data-driven interviewer. It will be probed. EXP because it tests the number and her attribution, not the role |
| A2 | "Tell me about the partner-level revenue model. What went into it, and how was it used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: she built the model, it was partner-level, and it was used in carrier negotiations. Offer to walk through it end to end in her own words, since it's work she built. The quote says the model was used in negotiations, not that she negotiated. Answer slot: if she took part in the negotiations, she says what her part was. If she didn't, she says so plainly and stays with the model | F4 is her closest evidence for a required JD item, and it overlaps Dan's pricing and monetization spine, so he'll go deep. EXP because it verifies what she built |
| A3 | "Tell me about an analysis you ran end to end in SQL and Tableau, from the query to the decision it fed." | EXP, JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold on F3: pick an analysis where she wrote the queries and built the view herself, with a decision it informed. She says which parts were hers if others contributed. If no single example comes to mind, she says so plainly, then describes how she works in SQL and Tableau, or how she would tackle C3. Don't attach SQL or Tableau to the revenue model unless that's what happened | The JD says "independent analysis". F3 is a bare skills line, and a prober tests bare lines first. EXP first because it verifies the claim. JD second because it scores a listed requirement |
| A4 | "How were the annual volume targets set? What were they anchored on, and how did they land against actuals?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: she set annual volume targets, with cross-org consensus. Don't call them quotas (F7). Answer slots: what the targets were anchored on, if she knows, in her own words; how they compared with actuals, if that was tracked and she saw it. If either wasn't hers or wasn't tracked, she says so plainly and stays with setting the targets | F5 is the nearest thing in her material to the planning a Sales Strategy team does, so Dan will test it in his own terms. EXP because the question is about what she did |
| A5 | "Which number in your background would you defend least, and why?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | She answers in her own words, and she picks it before he does. The pack observes that the ~$400M is the natural candidate, because the quote says "credited". She names the assumption she trusts least. If she doesn't know how the figure was counted, she says so plainly. That counts as a credible answer, not a failure | A classic prober stem, and the move that turns a gotcha into credibility. EXP because it tests self-knowledge of her own claims |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We'd both report to the same VP and our work touches. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD, CASE | [grounded] "skilled in SQL/Tableau" | She proposes seam principles, not an org chart she doesn't know: one shared source of truth for the numbers; agreement up front on who decides what for the new product lines; disagreements taken to the VP as one shared data view, not two decks. Reciprocity: she can bring analysis capacity, said at the quote's scope ("I'm skilled in SQL and Tableau"). Close by asking him where friction has shown up before | The peer stem in its purest form, from someone who shares her boss. JD because it scores the cross-functional mandate. CASE because it's answered as a live design problem |
| B2 | "Tell me about a time you got another org to commit to a number they didn't own." | EXP, VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets, which had cross-org consensus. Those are the beats the quote states. Answer slot: the JD's cross-functional influence line makes a probe on how consensus was reached likely. If she did work to get it, she says what, in her own words. If consensus was already there or someone else drove it, she says so plainly and stays with the targets. Say "I" only for what was hers | Influence across orgs is a JD requirement, and to a peer it's the main thing that decides whether she adds to his load or takes some off it. EXP first because it verifies a story. VAL second for the behavioral shape |
| B3 | "How do you handle credit when work spans teams? Take the store-surface change." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped: she proposed the change, and the uplift is credited to the change. She says in her own words whose work the change depended on and what was hers beyond the proposal. If the proposal was the whole of her part, she says so plainly. "We" for the change, "I" for the proposal | A peer credit-sharing probe aimed at the most credit-sensitive line in her background (F1, F2). EXP because the score is attribution honesty |
| B4 | "What would you need from my team in the first 90 days, and what would we get from you?" | JD, CO | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Needs: access to pipeline, bookings and usage data; his read on sales capacity for new products; pricing guardrails, since pricing is his background. Gives, at the quotes' scope: "I'm skilled in SQL and Tableau" and "I built a partner-level revenue model used in carrier negotiations". Offer, don't promise: name one thing she could produce for his team early, framed as a proposal for him to react to | Reciprocity is what a peer is really pricing. JD because it maps to the role's analysis and influence lines. CO because it shows she has thought about how Northwind works |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles a 'good enough' version of one of our new products in for free. How do you respond on packaging and GTM?" | CASE, CO | [grounded] | Clarify: which product, which segment, and how much renewal revenue is exposed. Objective: protect land, or protect expand? Segment: accounts where the bundle is good enough versus accounts where depth matters. Options: don't race to free; a differentiated tier; attach to Compass; partner integrations that the bundler can't match; targeted offers at at-risk renewals. Metrics: win rate against the bundler, attach rate, net retention. Risk: discounting against the profitability priority. Premise worth challenging: is the bundle actually displacing deals, or only showing up in evaluations? Says nothing about her past | Built on the bundling threat in the coach's research note, and pitched at Dan's pricing and monetization spine. CASE because it's live. CO because it requires Northwind's competitive frame |
| C2 | "Compass is launching. Design the first-year GTM: who it's for, how it's packaged and priced, and what sales and partners do." | CASE, JD | [grounded] | Clarify: who buys, who uses, and is the goal adoption or revenue in year one? Segment: start with existing enterprise accounts, which ties to the enterprise-expansion priority. Packaging options with trade-offs: paid add-on, usage-based, or folded into a higher tier. Weigh each against profitability and against the bundling threat. Motion: what the sales team carries versus what partners carry; how the land/adopt/expand/renew motion changes. Metrics: leading (activation, weekly use) and lagging (attach, expansion). Premise to challenge: whether Compass should be sold separately at all | Ties together all three priorities in the research note, and asks for the JD's core job (GTM strategy for new product lines) plus partner design. CASE first. JD second because it's the listed job |
| C3 | "You have our account data. How would you find the best expand and renew whitespace for the new product lines in your first 60 days?" | CASE, JD | [grounded] | Frame it on land/adopt/expand/renew. Data to pull in SQL: install base, product holdings, usage and adoption depth, renewal dates, segment. Approach: headroom times propensity, per account. Validate with Sales Strategy before anything ships to the field. Publish a Tableau view reps can use. Offer to sketch the query logic aloud. Says nothing about her past | The JD's whitespace and SQL/Tableau lines as a live problem, and the honest landing for F2's thin bridge. CASE because it's solved live. JD because it scores two listed requirements |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting, and you're coming from consumer tech. GTM here runs through a sales team. Why would the field trust your plans?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI rehearsal in the pack.** Step 1, acknowledge first and don't shrink it: "I haven't done classic sales-ops or quota-setting work." Step 2, the adjacent work at its own scope: "I set annual volume targets with cross-org consensus, and I built a partner-level revenue model used in carrier negotiations." Don't call the targets quotas, and don't call the carriers customers she sold to. Step 3, name the limit before he does. The pack observes that the material doesn't show B2B, sales-team-facing work. Answer slot: if any of the nine years involved selling to businesses or working alongside a sales team, she says what, in her own words. If not, she says so plainly. Step 4, a ramp plan, said as a plan: shadow reps, learn the quota and comp mechanics from his team, and build the first new-product plans *with* sales leadership. Follow-up 1, "so you'd learn on our time?": hold, with a question: "As I read it, the role is GTM strategy for two new product lines rather than quota-setting. Tell me if that's wrong." Follow-up 2: concede the sales-mechanics ramp specifically, and hold that the analysis and the cross-org target-setting carry over | F7 and F8 together are the most predictable objection to Priya, and the person asking runs Sales Strategy. JD because it scores fit to the role as listed, with the gap included |
| D2 | "Partner-motion design is listed as required. I don't see a partner motion you designed. What's the closest thing, and where does it fall short?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Closest thing, at its scope: "I built a partner-level revenue model used in carrier negotiations." She names the limit herself. The pack observes that a model used in negotiations isn't the design of a partner program. Answer slot: the JD's partner-motion line makes a probe on partner terms, tiers, incentives or route to market likely. If any of that was hers to shape, she says which and how. If none was, she says so plainly and stays with the model. Then how she would design one, said as a plan: start from partner economics, which is where the model gives her a footing | F4 sits against the only JD item marked "required", so it can't go unrehearsed. JD because it scores a stated requirement |
| D3 | "Why leave a large consumer-tech company for emerging products at a 3,000-person B2B company, and why now?" | JD, CO | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Selection scaffold: her real reasons only, tied to this role's actual content (two new product lines, a partner motion, an AI copilot launch). A strong answer has a pull toward this work, not just a push away from the last job. If she can't yet say why now, she works that out before the interview. A vague answer here reads as no answer | His startup chapter makes a pace-and-scrappiness test likely, and the nine-year tenure in F8's quote invites "why move". JD first because it's fit to the role. CO second because a good answer needs Northwind's context |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, then hold what the quote carries: "I proposed the change, and the change was credited with a ~$400M ARR uplift." Through two follow-ups, return to the proposal, never adding to it. Then concede specifically: the uplift is credited to the change, not to her alone. Answer slot: what else her part included, if anything, in her own words. If the proposal was all of it, she says so plainly. Don't fold into "it was really the team", because the proposal was hers | The pressure form of A1. The persona stem is aimed at the most attribution-sensitive line in her background. EXP because it scores attribution under stress |
| E2 | "Sixty seconds: why you over an internal candidate who already knows our sales team?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau" | Pause, restate, then three beats at the quotes' scope: consulting plus nine years of product strategy and ops; a partner-level revenue model she built; skilled in SQL and Tableau. Concede the internal candidate's real edge (they know the sales team) and pair it with her ramp plan from D1. Hold: an outside view on new product lines is part of what the role is hiring for. Say this as a question if unsure | The time-boxed persona stem, made harder by the sales-team angle that D1 opens. JD because it scores fit |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc, rehearsed: two years in strategy consulting, then nine years in product strategy and ops at a large consumer-tech company. Two stories at their own scope: the partner-level revenue model she built, and the store-surface change she proposed. Then one sentence on why emerging-products GTM at Northwind now, in her own words, consistent with D3. End by handing the conversation back to him | The near-certain opener, and it's scored on economy. EXP because the content is her history |
| G2 | "What are you actually playing with in AI these days?" | JD, CO | [grounded] "uses AI tools daily" | Treat it as scored: "AI experience a plus" is in the JD. Answer slot: which tools, and for what work, in her own words, with one concrete example. A data-driven listener wants specifics. Don't call daily use AI product experience (F6). Bridge to Compass with a genuine question about how Northwind's customers are expected to use it | A casual question on a JD plus-skill is a classic hidden scoring moment, and Compass is a stated priority. JD for the plus-skill, CO for the Compass link |

### H. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a time she brought leadership data or a recommendation they didn't want. It needs a named stake, what she brought, what happened, and a relationship still intact at the end. "We" for context, "I" for her part. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she would handle it | A persona stem. No Northwind values are in hand, so it's generic, but a data-driven peer values someone who will carry an unwelcome number upward. VAL because it scores behavior |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where a customer outcome cost a number she or her team was measured on. It needs the trade-off, the call, and what happened next. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she would weigh it at Northwind, where profitability is a stated priority | A persona stem with an edge here: the research note's profitability priority makes the trade-off live. VAL because it scores behavior |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | C2, C1, D1, D3 |
| "identify whitespace across land/adopt/expand/renew" | C3, A1 |
| "run independent analysis in SQL and Tableau" | A3, C3, B1 |
| "partner-motion design experience required" | D2, A2, C2 |
| "strong cross-functional influence" | B2, B1, A4, B4 |
| "AI experience a plus" | G2, C2 |
| F7: sales-ops or quota grounding (generic) | D1, E2 |
| F8: B2B or enterprise GTM familiarity (generic) | D1, D3 |
| Company priorities in the research note (enterprise expansion, Compass, profitability, the bundling threat) | C1, C2, H2, reverse questions |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Coming from pricing and monetization, how would you package Compass: a separate SKU, or folded into a tier, given the bundling pressure?" | Tied to his career path. It invites him into his own expertise and turns the interview into a peer working session |
| R2 | "You've worked at an early-stage startup. What from that carries over to launching emerging products inside a 3,000-person company, and what doesn't?" | Tied to his path, and it lets him answer the scrappiness question he might otherwise ask her |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question. A peer is weighing whether she adds to his load or lightens it |
| R4 | "Where do Sales Strategy and Emerging Products GTM overlap today, and where has that caused friction?" | Shows she's already thinking about the seam from B1, and gets real information about the job |
| R5 | "Does a partner motion for the new lines exist today? Is the job to design one, or to fix one?" | Goes straight at the one "required" item (F4), and tells her what she'd actually be walking into |
| R6 | "How does our VP weigh profitability against growth for new product lines in year one?" | Uses the research note's priorities, and asks the shared boss's expectations of the one person who also reports to them |
| R7 | "Where does the source-of-truth data for pipeline and usage live, and how self-serve is analysis in SQL and Tableau here?" | Speaks his data-driven language and checks how independent the "independent analysis" in the JD can really be |

---

## Prohibited claims

These are the claims this pack will not coach, because each would fail the first follow-up from a data-driven interviewer.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led GTM strategy for a product | Inflated form of F1 | F1's quotes at their own scope. The pack's observation: the material says product strategy & ops and a change she proposed, not GTM ownership. A1 and B3 stay inside the proposal |
| Delivered or drove ~$400M in ARR | Inflated form of F1's store-surface quote | "proposed a store-surface change credited with a ~$400M ARR uplift": proposed, and credited to the change. E1 holds exactly this |
| Designed a partner motion or partner program | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations". D2's slot stays inside what she shaped |
| Negotiated the carrier deals | Inflated form of F4 (the model was used in negotiations) | The quote at its scope. A2's slot lets her say plainly whether she took part |
| Built the revenue model in SQL or Tableau | Inflated form that joins F3 and F4 | Each quote kept separate, at its own scope |
| Built or drove cross-org consensus | Inflated form of F5 | "set annual volume targets with cross-org consensus". B2's slot asks how the consensus came about, without assuming it was hers |
| Set quotas, or has sales-ops experience | Negative stated in the coach's notes, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting work." No slot |
| Has AI product experience | Inflated form of F6 | "uses AI tools daily". G2's slot stays with her actual use |

---

## Sources

**Provided documents:** the coach's notes in this conversation: JD highlights, the candidate background summary, the interviewer profile summary, and the coach's research note on Northwind's priorities and competitive threat. No dossier was present.

**Searches and fetches sent:** none. No search was sent, because each one would name the company and the interviewer from a private prep engagement, so research is waiting on your go-ahead.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have supplied published value names to theme H1 and H2 and to make them VAL-specific. No search was sent while research awaits your go-ahead |
| 2. `Northwind Data interview process, GTM strategy` | skipped | The coach's notes fix the loop: one 60-minute conversation with Dan, a peer. Persona weights follow from that |
| 3. `Northwind Data strategy` / recent news | skipped | The coach's research note supplies the priorities and competitive frame the CO and CASE questions use. A freshness check is offered in the upgrade menu |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have added any public talks or writing to the interviewer read and to R1 and R2. No search was sent while research awaits your go-ahead |
| 5. Representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text** → mid-list requirements (named tools, methods, metrics) each get a question, and F1 to F6 quote the posting itself rather than highlights.
- **Priya's actual CV** → evidence cells quote her own bullets. H1, H2 and D3 can move from scaffolds to story-mapped answers, and F8's B2B question may resolve.
- **Your go-ahead for research (L1: up to 6 searches and 2 fetches)** → Northwind's published values theme the H bank, Dan's public footprint sharpens the interviewer read and R1 and R2, and a quick check confirms the research note is current. A deeper pass after that (L2: up to 6 more searches and 2 more fetches, several more minutes) adds a strategy brief and recent org context for the C bank.
- **Priya's answers to the answer slots in A1, A2, A4, B2, D1, D2 and G2**, given to you as facts outside a drill → those rows become story-mapped on her own words.
- **Any recruiter guidance** (stated focus areas, or a pre-declared case or presentation) → a build section for the deliverable and retuned weights.
- **Prep time available** → a prioritized prep schedule sized to it.
- **A `tuesday-dossier.md` from a job-underwriter pass** → evidence verified with Priya, a named highest-ROI objection, and a prohibited-claims list confirmed against her own corrections.
