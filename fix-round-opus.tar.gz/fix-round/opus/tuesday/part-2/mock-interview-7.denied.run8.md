Reading done — I've gone through the prep-pack rules. Next I'm running a few web searches on Saltmarsh Games and Tobias Wrenfield, then I'll build the pack.
I've built your prep pack: saltmarsh-games_live-operations-producer_interview_pack.md. It assumes Tobias is the hiring manager, because your note gives his title but doesn't say he'd be your boss.

**Web search was blocked in this session**, so the pack has nothing on Saltmarsh's values, interview process or recent news, or on Tobias's background. Everything about the company is labelled as general to live-ops roles, not specific to Saltmarsh.

What's in it:
- **A fit table** that matches each line of the job description to your own sentences, word for word.
- **23 practice questions**, grouped by interviewer style.
- **Six questions for you to ask Tobias.**
- **A list of claims to avoid**, such as leading a team or in-app purchase experience.
- **A plan for tonight**, since Friday is tomorrow.

The most important question to rehearse is B1: the role coordinates four teams, and you've said you've never led one. I've also prepared a short answer for the in-app purchase gap (B2).

Say the word and I'll play the Skeptic on B1, the question the pack names as its most important prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Would Tobias be your direct manager, and did the recruiter mention any focus areas or anything to prepare? The answer could change the question mix, or add a section for anything you're asked to bring.
Would you like to allow web search? Then I can add Saltmarsh's values and process and Tobias's public career history.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interview:** Friday, 60 minutes, with Tobias Wrenfield, Head of Live Operations
**Built as:** a hiring-manager round. Your note gives his title but doesn't say he'd be your manager, so this is an assumption. Web search was blocked in this session, so nothing here comes from Saltmarsh's website or Tobias's public profile.

---

## How to use this pack

Two axes. **Personas** describe *how* a question gets asked. **Types** describe *what* the answer is scored on.

| Type | What it scores |
|---|---|
| JD | Can you do the job as listed, gaps included |
| EXP | Whether what you say about your past holds up under follow-up questions |
| CASE | How you structure and reason through a live problem from the role |
| CO | Whether you know the company, its games and its current direction |
| VAL | Whether your past behaviour matches the company's published values |

The guidance is scaffolding, not a script. Wherever a cell says **Answer slot**, the pack doesn't know the answer, and you fill it from what really happened. Both branches of a slot are good answers.

Question IDs go by persona: A, B, C, D, E, G, H. **F is used only for the fit-snapshot rows**, so F1 always means a fit row and never a question.

---

## Prep triage (for one evening: Friday is tomorrow)

1. **B1, out loud, three times.** This is the highest-return prep in the pack: the coordination and team-leadership objection. Stop when it sounds boring. About 25 minutes.
2. **Read the fit snapshot.** Fill the answer slots in F1, F2, F3 and F5 *for yourself* before you're asked. About 15 minutes.
3. **Play both of Saltmarsh's mobile titles**, even briefly, and note one live event or update you see in each. This feeds D4 and the reverse questions. About 30 minutes.
4. **Talk through A1 and A3 using the structure in their guidance cells.** About 20 minutes.
5. **C1:** know exactly which retention numbers you presented and how they were counted, or say plainly that you don't know. About 10 minutes.
6. **Choose three reverse questions.**

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material describes a weekly content-drop calendar for one main title. The JD asks for live events across two mobile titles. Keep your words at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on scale and event type likely. If any of your drops ran as time-limited events, say so and describe one in your own words. If they weren't events, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | Your material doesn't show which teams the calendar involved. What you've said about never leading a team is about leading, and the JD's word is coordinate. Answer slot: if running the calendar meant working with design, art, engineering or community on a drop, name which teams and what you did with them, in your own words. If it didn't, say so plainly and stay with the calendar. If you're asked about leading people, the words are: "I haven't led a team." |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting numbers is not the same as owning a review or choosing its KPIs. Keep your words at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe likely. If you chose which numbers went in, or ran any review after a drop, say which and how, in your own words. If you didn't, say so plainly and stay with the presentation. Then describe how you'd run a post-event review, as a plan (A3) |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but this is a claim with nothing to inspect behind it, so expect a probe (E1). Lead with it in the quote's own terms: "I wrote the release checklist our QA team still uses." A named artifact that's still in use beats an adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | Four years clears the count. Your material doesn't say whether the puzzle game was a live-service title for all four years. Answer slot: if the game was live and updated throughout your time there, say so in your own words. If that's true only for the calendar years, say which years and stay with those |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement. Expect the Prober to ask which measures they were and how they were counted (C1). The words: "I presented the monthly retention numbers to the studio head." |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A checklist that's still in use touches written communication, but it doesn't show range. Answer slot in D3 |
| F8 | Live events tied to in-app purchases, a common pattern in mobile live operations. Not in this JD | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap that wording can't close, and you've said so yourself. The words: "I haven't worked on a game with in-app purchases." Then say how you'd learn it, as a plan and never as a past. The JD doesn't list this, so don't volunteer it as a weakness, but have the answer ready (B2) |

---

## Persona table

The loop source is your own description: one 60-minute session run by the Head of Live Operations. No values round was named, and the search that might have found Saltmarsh's process was blocked.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: calendar clashes, a late asset, a retention dip after an event | High. A hiring-manager round leads with Case. Running events for two titles is a planning job, so expect to plan live | Clarify, objective, constraints, options, decision, who you'd tell. Think aloud |
| Skeptic | Probes on one title versus two, content drops versus live events, and coordination without having led a team | High. The other hiring-manager prior. F1, F2 and F8 are the visible gaps | Rehearse B1 until it's boring. Bridge only with your own sentences, say limits plainly, give a ramp plan |
| Data-Driven Prober | "Which retention numbers? How were they counted?" | Medium. The JD names retention metrics and KPIs, and F3 and F6 sit on one sentence | Know what was yours and what wasn't. "I don't know how it was counted" is allowed |
| Conversational | A friendly opener, "walk me through it", what you're playing | Medium. 60 minutes usually leaves room to open informally, and casual answers are still scored | A 90-second arc built only from your four sentences |
| Pressure | "How much of that checklist was you?" "Sixty seconds: why you?" | Low to medium. Nothing suggests a stress style, but attribution probes are standard | Pause, restate, hold on what you said, concede specifically |
| Peer Evaluator | Disagreements across teams (community versus design, engineering versus the date) | Low. He isn't a peer, but the role sits between four teams, so seam questions arrive in a manager's voice | Talk in principles: what you'd ask each side, how you'd decide, who you'd tell |
| Values / Behavioral | "Tell me about a time…" stories | Low. No values round is known and no published values are in hand | Selection scaffolds with honest branches |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Both titles want an event in the same fortnight and engineering can support one. How do you plan the calendar?" | CASE | [generic] | Clarify first: what each event is for, what's already announced, what's fixed. Name the goal: which matters more this month, retention or reach. Then the options: stagger, cut scope on one, or reuse existing tech for one. Pick one, say what you'd give up, and say who you'd tell and when. The question asks nothing about your past, so the guidance claims nothing | Tests the JD's two-titles calendar line live. CASE because it scores structure, not history |
| A2 | "An event launched yesterday and day-1 retention among participants is below the last event's. What do you do in the first 48 hours?" | CASE | [generic] | Check the data first: same measure, same cohort, any tracking change. Then segment: new versus returning players, by platform, by entry point. Then look outside the data: bugs, community sentiment, a competing event. Decide whether to act mid-event or record it for the review. Say what you'd report and to whom | Retention plus post-event KPIs, both in the JD. A Prober-style CASE because the first move should be doubting the number |
| A3 | "Design the post-event review you'd run after every event. What's on it?" | JD | [generic] | Structure: the goal set before the event. The KPIs against that goal. What worked and what didn't, by team. What players said, via community. Actions, each with an owner and a date. Who reads it. Offer it as a plan for this role. F3's limit stands: this is how you would run one | The JD's "own the post-event review" line, F3's gap. JD content, CASE delivery |
| A4 | "Three days before an update ships, art says a key asset will be a week late. What do you do?" | CASE | [generic] | First, what does the asset block? Then the options: ship without it, swap in a placeholder, move the update, cut the dependent feature. Who decides, who needs to know (engineering, QA, community), and what players are told. Then how you'd stop it happening next time | The JD's coordination line, rehearsed as a decision rather than a record, so it needs no past claim |
| A5 | "You'd be new to two titles. What do your first 90 days look like?" | CASE | [generic] | Learn the current calendar and the last few post-event reviews. Meet the leads in design, art, engineering, community and QA. Shadow one event end to end before running one. Learn how the studio defines its KPIs. Read the release checklist before proposing any change to it. Keep it a plan, not a promise | The JD's two-titles scope. It also gives you a ramp plan to reuse in B1 and B2 |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates design, art, engineering and community on every update. You haven't led a team. How would you handle that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | **Highest-return prep in this pack.** Open with the plain acknowledgment: "I haven't led a team." Then the fact you have: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's coordination line makes a probe on who you worked with likely. If running that calendar meant working with any of those teams on a drop, name which and what you did, in your own words. If it didn't, say so plainly and stay with the calendar. Then ask him: "I read this role as coordinating across teams rather than managing them. Is that right?" Close with A5's ramp plan, said as a plan. Hold through two follow-ups by going back to the calendar, never by adding to it | F2 is the thinnest row on the JD's most demanding line, and the material doesn't show coordination, so this objection arrives in some form. JD because it scores a stated responsibility |
| B2 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Stop there for a beat. Don't apologise and don't bridge. Then a plan: how you'd learn how events and offers connect on these titles, and who you'd learn it from. Then ask how events and purchases connect here (reverse question 6). Nothing added to make the gap feel smaller | F8. Not a JD requirement, but common in mobile live operations, so a Head of Live Operations may ask. A rehearsed short answer keeps it from taking over the hour |
| B3 | "You ran the content-drop calendar for your main title. Here it's two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Keep the premise to the quote: one main title, two years. Then the forward-looking part, which claims nothing: shared versus separate calendars, competing resource, staggering, keeping the two player bases from clashing. Close with one thing you'd want to learn first | F1's scale gap. JD because it presses the two-titles line directly |
| B4 | "How close is a weekly content drop to a live event, in your view?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if any of your drops had start and end dates, goals, or player-facing event mechanics, say so in your own words and give one. If they were content additions without that, say so plainly and say what you'd need to learn. Then turn it back: "What does a typical event look like on your titles?" | F1 and F5. Tests the live-service and live-events lines without assuming either way |
| B5 | "Why leave a puzzle studio for this role, and why now?" | JD | [generic] | Selection scaffold: one real reason you want this role (the JD's scope, live events, two titles) and one real reason it's the right time. Both have to be true for you. If you can't name one, say what you're looking for instead. Don't criticise your current studio | A standard motivation check in any hiring-manager round. Kept generic because your reasons aren't in the material |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Which numbers, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story beats are only what the quote states: monthly retention numbers, presented to the studio head. Answer slots, in your own words: which measures they were; how they were counted; the assumption behind them you'd defend least; and which part was yours, whether pulling the data, analysing it or presenting it. "I don't know how they were counted" is an honest branch. The pack supplies no method | F6's only evidence. A figure-type claim invites this probe |
| C2 | "Tell me about a time a retention number you presented surprised you or the studio head." | EXP | [generic] | Selection scaffold: one month where a number moved, what you said about it, and what happened next. If no such time comes to mind, say so plainly, then describe how you presented the numbers, or how you'd handle a surprise | The JD's retention line. This is an open prompt, so no event is presupposed |
| C3 | "If you owned the KPIs for a live event, which three would you report, and why?" | JD | [generic] | Pick three and say why each one. Common choices in the field: participation rate, retention of participants against non-participants, event completion, player sentiment, and revenue where it applies. Name the one you'd trust least and why. Say you'd want to know how Saltmarsh defines retention before committing | The JD's "KPIs it reports" line, F3. JD because it scores the stated responsibility |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | 90 seconds, four beats, each one only what its sentence says: four years as associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title, the last two years; the release checklist QA still uses, which you wrote; the monthly retention numbers you presented to the studio head. End with one true line on why this role | Almost certain opener. Every beat comes from your own sentences, so every follow-up lands on solid ground |
| D2 | "What mobile games are you playing at the moment? Any live events you've liked?" | CO | [generic] | Selection scaffold: one game, one event, and what made it work for players. If you aren't playing much right now, say so and name the last one you did play | Casual register, still scored, and it checks genuine interest |
| D3 | "What does good written communication look like for a producer?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | One principle: written for the reader, scannable, with owners and dates. Then your example: you wrote the release checklist your QA team still uses. Answer slot: if you've written other documents the team or players read, name one and who read it. If the checklist is your main example, say so plainly and stay with it | F7. The JD's written-communication line |
| D4 | "What do you think of our games?" | CO | [generic] | Whatever you play tonight: what you played, one event or update you noticed, and one honest question about it. If you didn't get to play one, say so plainly rather than guess | No research reached Saltmarsh's titles, so this stays generic. A Head of Live Operations will expect you to have played them |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold on the quote: you wrote it, and QA still uses it. Answer slot: the JD's "manage the release checklist" line makes a probe on upkeep likely. If others added to it or you maintained it over releases, say who did what, in your own words. If it's essentially as you wrote it, say so plainly. Hold through two follow-ups. Concede only specifics that are true | F4 is your strongest row, so it's the one a pressure question tests for attribution |
| E2 | "Sixty seconds: why you over someone who's already run live events on a mobile game with purchases?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Concede first and briefly: "I haven't worked on a game with in-app purchases." Then hold on three facts in the quotes' words: four years as associate producer at a puzzle-game studio, two years running the weekly content-drop calendar, and the release checklist QA still uses. Close on what you'd do first (A5). Don't argue that the other candidate is weaker | F1 and F8 together, time-boxed. Hold-then-concede is the scored structure |

### G. Peer-style seam questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Mid-event, community says players are angry and want a change, and design says no. Where do you land?" | CASE | [generic] | Find out what the players are actually angry about, and how many of them. What does design's no protect? What does changing mid-event cost, and does it risk the release? Decide or escalate, then say what players are told. Stating the principle matters more than the verdict | The JD's coordination line, with community and design named |
| G2 | "The event date is announced, but the release checklist and QA say it isn't ready. What do you do?" | JD | [generic] | The checklist exists to be honoured. What's failing, and is it a blocker? Options: ship with a known issue, push the date, cut the feature. Who decides, and what community tells players. Then what changes in planning next time | The JD's "manage the release checklist with QA" line, under live pressure. JD content, CASE delivery |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, what you said, and what happened. Use "we" for the context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A persona stem. No published values are in hand, so it isn't mapped to a value |
| H2 | "When did you put players ahead of a deadline or an internal number?" | VAL | [generic] | Selection scaffold: the trade-off, who disagreed, and how it ended. If none comes to mind, say so plainly and say how you'd weigh it | A persona stem, themed on live operations |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A1, A5, B3, B4 |
| Coordinate design, art, engineering and community on each update | B1, A4, G1 |
| Own the post-event review and its KPIs | A3, C3, A2 |
| Manage the release checklist with QA | G2, E1 |
| 3+ years producing live-service games or apps | B4, D1 |
| Experience running a content calendar | B3, B4 |
| Comfortable with player-retention metrics | C1, C2, A2 |
| Clear written communication | D3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical event on these two titles look like, start to finish, and where does it usually go wrong?" | It gets you his view of the job's real pressure points, and it fills your F1 gap with facts |
| R2 | "Which KPIs does the post-event review report today, and who reads it?" | It goes straight at a responsibility you'd own, and it tells you what success looks like |
| R3 | "Do the two titles share one events calendar, or run separately?" | It shows you're thinking about the two-title scope, and the answer changes how you'd plan |
| R4 | "What would you want the person in this role to have changed six months in?" | It invites him to describe the gap he's hiring for |
| R5 | "How does feedback from the community team get back into the calendar?" | It's a coordination question from the JD, asked as curiosity |
| R6 | "How do events and in-app purchases connect on these titles, and who owns that side?" | It turns your F8 gap into a learning question instead of a confession |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | A negative you stated (F2) | The plain acknowledgment: "I haven't led a team." |
| Experience with in-app purchases or event monetisation | A negative you stated (F8) | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar across multiple titles | An inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for one main title. B4's slot stays inside the drops |
| Owned the retention KPIs or ran post-event reviews | An inflated form of F3 | F3's quote at its own scope: you presented the numbers. C1's slots ask only what was yours |
| Owned or designed the QA process | An inflated form of F4 | F4's quote at its own scope: you wrote the checklist, and QA still uses it |

---

## Sources

- **Provided:** the job description and your background, both pasted in your message.
- **Searches sent:** "Saltmarsh Games values"; "Saltmarsh Games interview process live operations producer"; "Saltmarsh Games mobile studio news 2026"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations". All four were refused (web search permission not granted). No fetches were sent.
- No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Refused. Would have themed the H bank on Saltmarsh's published values |
| 2. `Saltmarsh Games interview process` | unavailable | Refused. Would have confirmed or changed the one-session, hiring-manager reading. Your own description of the session stands as the loop source |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Refused. Would have grounded D4 and given a CO question on the studio's current direction |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Refused. Would have added a read on the interviewer, persona adjustments, and a reverse question tied to his career path |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** → Saltmarsh's values, interview process and recent news, plus Tobias's public professional profile. That adds a read on the interviewer, a reverse question tied to his career path, a grounded D4, and possibly a values cheat sheet.
- **Deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief on Saltmarsh's titles and competitors, plus any talks or posts by Tobias.
- **Whether Tobias would be your manager, and any recruiter notes** → recomputed persona weights, and a build section for anything you've been asked to prepare.
- **The names of the two titles** → grounded D4, R1 and R3, and a game-specific CASE question.
- **Your answers to the slots in F1, F2, F3, F5 and F7**, given here outside a drill → those rows get your own words. B1, B4, C1 and D3 change most.
- **The release checklist or a retention deck you presented, shown to me (redacted is fine)** → F4 and F6 can go from medium to high confidence.
- **A `tuesday-dossier.md` from an earlier underwriting session** → it would name the objection to rehearse from evidence you confirmed, rather than inferring it.
