No dossier present. Reading the required references.
I've written your prep pack for the three rounds on 21 November: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md. It has one shared section on how your experience matches the JD, then a set of practice questions and questions to ask for each round: the recruiter, the Head of Member Services and the branch-manager panel. Your background, the JD, the values you pasted and the recruiter's email covered everything, so I didn't search online.

- **What to rehearse most (C1, Round 2):** the question about the contact centre. The role covers "branches and the contact centre", and you said you've "Never worked in a contact centre". Expect it in some form in more than one round. The pack scripts how to admit it plainly, what you can point to instead, a learning plan, and how to handle two follow-up challenges.
- **Two gaps you stated yourself:** the contact centre and "I've never presented to anyone above regional level." The pack gives you a plain admission and a plan for each, and won't coach you to talk around them.
- **The 20-minute case:** it has its own section, with a timed outline, three ways to approach it, and things to avoid saying.
- **The values:** there's a cheat sheet for all four, for Rounds 2 and 3. Your four sentences give only partial story material for Plain Words and Own the Fix. For Members First, Always and Neighbours, Not Numbers, you'll need to pick stories of your own; the pack says what a good one needs.
- **A tension the panel may test:** "Neighbours, Not Numbers" sits awkwardly with closing eight branches into five hubs. One of your panellists may run a branch that's affected. Question J2 rehearses handling a complaint about a closure without taking a side on the strategy.
- **Claims the pack won't coach:** for example "owned the process across branches", "coached supervisors" or "advanced Excel". Each is listed with the honest version to use instead.

If you'd like a mock run, I can play the sceptical hiring manager on C1, or the panel on the 20-minute case.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of loop:** 21 November 2026, three rounds on one day (from the recruiter's email)
**Mode:** Loop. One shared fit snapshot, then a mini-pack for each round

| Round | Who | Length | Relationship to you | What the recruiter said it holds |
|---|---|---|---|---|
| 1 | The recruiter | 30 min | Recruiter | A conversation with the recruiter |
| 2 | Head of Member Services | 45 min | Your future manager | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | Stakeholders whose branch supervisors you would coach | "a 20-minute case on a complaint escalation"; "the values round — they score against the four values" |

No interviewer names have been assigned yet, so this pack has no interviewer read. Persona weights come from each round's relationship and from what the recruiter said each round holds.

---

## How to use this pack

- **Personas** describe *how* a question is asked: friendly, sceptical, time-boxed, collegial.
- **Types** describe *what* is being scored:
  - **VAL**: whether things you have done show Ashgrove's four published values
  - **EXP**: whether what you say about your own work holds up when someone digs into it
  - **JD**: whether you can do the job as the JD lists it, gaps included
  - **CO**: whether you know Ashgrove's strategy and pressures
  - **CASE**: a live problem from the role, reasoned through out loud
- **Provenance** shows where each row comes from: `[grounded]` means traceable to something you or Ashgrove supplied, `[inferred]` means derived from it, with the derivation named, and `[generic]` means a general pattern for this kind of role, with no claim about Ashgrove or you.
- **An answer slot** is an instruction for your answer in the room. The pack does not know the answer, so it gives you two honest branches and you fill in whichever one is true. It is never a question for you to answer to me.
- The guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.

---

## Fit snapshot (shared across all three rounds)

Every statement this pack makes about your past comes from the four sentences in your message, quoted below.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material shows one branch's complaints log, not a process across branches, and the words should stay there: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on how a complaint moved through your branch from receipt to close likely. If any part of that was yours to decide, say which part and how you decided, in your own words. If none of it was yours to decide, or there was no set route, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you have stated, and wording cannot close it. Words: "I haven't worked in a contact centre." Then how you would learn that side, said as a plan and never as something in your past. Do not add anything to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | This is close, but your material does not say whether the spreadsheet counts volumes, resolution times or something else, or whether it covers one branch or more. Answer slot: if it counts volumes or resolution times, say what it counts and over what, in your own words. If it does not, say so plainly and describe what it does hold. Do not widen "our regional manager uses" into region-wide reporting |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message, and "the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Training new tellers is adjacent to coaching supervisors, but it is not the same thing: the audience is different and the relationship is different. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on coaching people at supervisor level likely. If you have advised or coached fellow supervisors on escalations, say when and how, in your own words. If you haven't, say so plainly and stay with the tellers you trained |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. Answer slot: if you have worked with a digital team, or on any change to how members serve themselves, say what it was and what your part was, in your own words. If you haven't, say so plainly and say what you would bring to that work from the complaints side. Never describe digital work you did not do |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Lead with the sentence in its own terms: six years in retail banking, the last three as a branch supervisor. Let the interviewer map it onto "customer operations" rather than relabelling your history in the JD's words. It is a self-report with nothing inspected behind it yet, so expect a question about it |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | "Formal" touches "regulated" but does not show it. Answer slot: the JD says "regulated complaints", so expect a probe on the rules the log was kept under. If it was kept to a regulator's requirements and you know which ones, name them and say what part you handled, in your own words. If you don't know which rules applied, or that side wasn't yours, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you have stated. Words: "I haven't presented to anyone above regional level." Your material does not say either way whether you have presented at regional level, so that part is an answer slot: if you have, say to whom and about what, in your own words; if you haven't, leave it out. Then how you would prepare to present to Ashgrove's senior leaders, said as a plan |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material does not name the tool or the techniques. Answer slot: if you built it in Excel, say so and describe what it does in your own words. If you used another tool, name it. Never claim a level of skill or a feature you have not used |

There are no gate rows. None of the JD's requirements is an eligibility term like a licence, location or right to work. Its "4+ years" is a length-of-experience requirement, graded like any other row.

### Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own the complaints process end to end across branches | F1 | C4, C1, J1, B1 |
| …and the contact centre | F2 | A4, C1 |
| Report monthly on volumes and resolution times | F3 | E1, E2 |
| Coach branch supervisors on escalations | F4 | C3, K1, K2 |
| Work with digital teams on self-service journeys | F5 | G1 |
| 4+ years in financial-services customer operations | F6 | A1, B3 |
| Regulated complaints experience | F7 | B1, J1 |
| Confident presenting to senior leaders | F8 | B2, C2 |
| Comfortable with Excel reporting | F9 | A5, E1 |

**Highest-ROI prep in this pack: C1**, the contact-centre objection in Round 2. The role spans "branches and the contact centre" and you have said you have "Never worked in a contact centre", so this objection will arrive in some form, probably in more than one round. A4 and L2 are lighter versions of it.

---

## Grounding brief: Ashgrove's language and current direction

This comes from your summary of the July 2026 strategy brief, the values you copied this morning and the JD. The aim is for you to sound current, not to recite any of it.

| Fact | Source | Provenance | How to use it |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Strategy brief, July 2026, as summarised in your message | [grounded] | The backdrop to the JD's "self-service journeys" line. Expect complaints about digital journeys to become a bigger share of the work, and say that as a question you would want answered, not as a fact about Ashgrove |
| Consolidate eight branches into five hubs over 2027 | Strategy brief, July 2026 | [grounded] | Your Round 3 panel is two branch managers. Treat consolidation as a decision already made: talk about how you would look after members through it, and never about whether it is right |
| A small-business lending product launches in Q1 2027 | Strategy brief, July 2026 | [grounded] | A new product brings a new kind of complaint. Useful in G2 and J3, and as a reverse question |
| The main competitive pressure is app-only banks | Strategy brief, July 2026 | [grounded] | Why "Members First" and "Neighbours, Not Numbers" matter commercially: they are what an app-only bank cannot easily copy. Used in L1 |
| Member-owned, about 900 staff | JD | [grounded] | Say "members", never "customers", throughout the loop |
| Four values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Values page text you copied on 12 November 2026 | [grounded] | Use the names exactly as written. See the values cheat sheet |
| There is a tension between "every branch is part of its town" and closing branches into hubs | Derived from the values page together with the strategy brief | [inferred] | The panel may well test this, and J2 rehearses it. Show you can hold both, without taking a side on the strategy |

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter's words: "a 20-minute case on a complaint escalation", scored by the panel, which "score against the four values". No brief has been shared, so prepare a structure, not an answer.

**Facts to build on**

- About you: F1, "I handled the branch's formal complaints log"; F4, "trained new tellers on our escalation script"; F3, "I built the monthly complaints spreadsheet our regional manager uses." Mention these only if they fit, at their own scope.
- About Ashgrove: the four values, the hub consolidation, the 40% digital target (grounding brief above).

**A suggested 20-minute shape** `[generic]`

| Minutes | Move |
|---|---|
| 0–2 | Clarify before solving: which channel the complaint came through, what the member has been told so far, how long it has been open, whether any response deadline applies, whether there are signs the member is vulnerable, and what outcome they want |
| 2–4 | Say your structure out loud: the member today, the facts, the decision, the fix behind the complaint, and what goes in the report |
| 4–14 | Work through it, naming a value where it is the real reason for a step, not as decoration |
| 14–18 | Stop it happening again: the root cause, who owns the fix, and how it appears in the monthly figures |
| 18–20 | Close: what you would say to the member, in plain words, and what you would follow up within a week |

**Three ways to frame it, each with the concession you must make**

| Thesis | Leans on | The concession you must make |
|---|---|---|
| T1 Settle the member first, then the facts. Acknowledge, take ownership of the next step, and give a plain-words update and a date | Members First, Always; Plain Words | Speed cannot replace investigation. Don't promise an outcome or redress before you have the facts |
| T2 Fix this complaint and the cause behind it, and keep hold of both | Own the Fix | You cannot promise to fix a whole system inside the case. Name who you would bring in and how you would track it |
| T3 Treat the escalation as a coaching moment for the branch supervisor, after the member is looked after | The JD's coaching line; Neighbours, Not Numbers | The member comes before the coaching, and the coaching must not undercut the supervisor in front of the branch manager |

**How to stand out:** most candidates will say "apologise, escalate, resolve, follow up". Make that the spine, then add one move most candidates leave out: what this complaint tells Ashgrove, and how it reaches the monthly report or the digital team. That links the case to F3's requirement and to the 40% digital target.

**The anti-pick:** say out loud what you would *not* do. Don't bypass the branch supervisor, don't offer goodwill payments to make it go away, and don't blame the hub consolidation or the app to the member.

**Answer slot:** if a step in the case echoes something from your branch's formal complaints log, you may mention it, in your own words and at its own scope. If nothing does, keep the case hypothetical. A hypothetical case scores without any claim about your past.

---

## Values cheat sheet (Rounds 2 and 3)

Round 2 was described as "mostly behavioural" and Round 3 as "the values round", so this sheet serves both.

| Value (official name) | What it means in practice | Your story | Asked in |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter, even when another route is easier for the branch | No sentence in your message carries this story, so choose one: a time a member's interest changed what you or the branch did. It needs the member, the easier route you didn't take, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | D2, H1 |
| Plain Words | If a member needs something explained twice, the wording failed, not the member | F4: "trained new tellers on our escalation script". This tells you that you trained people on the script. Answer slot: if you changed any wording in it, or in what members were told, because something wasn't understood, say what and why, in your own words. If you didn't, say so plainly and talk about how you explained the script to new tellers | D4, H2 |
| Neighbours, Not Numbers | Every branch is part of its town, so treat members as neighbours, not case numbers | No sentence carries this, so choose one: a time knowing a member or the local community changed how you handled something. It needs the person, what you knew, and what you did differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | H3, J2 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because you spotted a problem, say what the problem was and how you saw it through, in your own words. If it didn't start that way, say so plainly and choose another time you kept hold of a problem until it was solved. If none comes to mind, say so plainly, then give the nearest thing your material does carry | D1, H4 |

Use "we" for context and "I" for your own part.

---

# Round 1: the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, chatty: "walk me through your journey" | High. A recruiter screen's usual register, and the recruiter runs this round | Have a 90-second journey ready. Treat casual questions on JD topics as scored |
| Skeptic (light) | Knock-out checks against the JD's requirements | Medium. Recruiters screen against the four listed requirements, and two of them, presenting and the contact centre, sit near the gaps you have stated | Plain acknowledgment, then a plan. Never bluff |

## Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc built only from these three sentences: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words. Keep "trained", not "coached", and "the branch's log", not "the process" | The opener in almost every screen; it sets which of F6, F1, F4 and F3 the rest of the loop probes. EXP because it is your history, told at its own scope |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Name one value by its official name and one strategy point, for example being member-owned, or the move to hubs as something you want to help members through. Answer slot: if you have a personal link to Ashgrove or to credit unions, say it in your own words; if you don't, leave it out rather than invent one | Motivation is a screen staple. CO because the strong answer uses Ashgrove's own words. `[grounded]` on the values text and brief; it makes no claim about your past |
| A3 | "Why move from branch supervisor into a member-experience role now?" | EXP | [grounded] "the last 3 as a branch supervisor." "I handled the branch's formal complaints log" | Your reason, in your own words, then the link: of everything in your supervisor role, the complaints log is the work closest to this job. Answer slot: if handling the log is what drew you to complaints work, say so and say why; if your reason is something else, give that reason. Don't present the move as a promotion you have already earned | Probes whether your motivation hangs together, drawing on F6 and F1. EXP because it asks what in your past points here |
| A4 | "This role covers branches and the contact centre. What's your experience on the contact-centre side?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then a one-line plan, for example that in your first weeks you would want to sit in on calls and read the contact centre's complaint records. Then stop. C1 rehearses the full version | F2 in screening form; a recruiter may screen on it. JD because it is the stated remit |
| A5 | "The JD mentions Excel reporting. How comfortable are you with it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it is in Excel, say so and say what it does in your own words; if it is another tool, name it. No skill level, no feature names you haven't used | A listed requirement (F9) that recruiters tick off. JD because it is a stated qualification |

## Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for experience with regulated complaints. Tell me about the complaints you've handled." | JD | [grounded] "I handled the branch's formal complaints log" | Start with the log: you handled the branch's formal complaints log. Answer slot: the JD says "regulated", so expect "under which rules?". If you know which regulator's requirements the log was kept to, name them and say what part was yours; if you don't, say so plainly and describe what handling the log involved for you, in your own words | F7 is a hard requirement and a knock-out candidate. JD because it scores the stated qualification |
| B2 | "Have you presented to senior leadership before?" | JD | [grounded] "I've never presented to anyone above regional level." | "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words; if you haven't, leave that out. Then the plan: how you would prepare a monthly complaints update for senior leaders. Don't apologise more than once | F8 is a listed requirement and a gap you have stated. Rehearse it here so it is calm by Round 2. JD because it is a stated requirement |
| B3 | "This role is a step up from supervising a single branch's complaints. What makes you ready?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I built the monthly complaints spreadsheet our regional manager uses." | Hold on what the sentences carry: six years in retail banking, the last three as a supervisor, and a monthly complaints spreadsheet your regional manager uses. Then name one thing you would need to learn, the contact centre, and how. Don't argue that you are already operating at this level | Covers F6 and F3 and invites the gap-honest answer recruiters trust. JD because it tests the experience requirement |

## Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| "For the 20-minute case, will I get a written brief on the day, or will it be a role-play?" | Tells you how to prepare the case, and shows you are taking the graded part seriously |
| "When the interviewers are confirmed, could you share their names and roles?" | The recruiter said they haven't been assigned yet; names let you prepare for each person |
| "Is this a new role or a backfill?" | Shows whether you would be building the complaints process or inheriting one |
| "Does the role's remit cover the five new hubs as they open in 2027?" | Uses the strategy brief, and checks the scope you would own |
| "What would make someone stand out in the values part of the panel?" | Uses the recruiter's own "values round" framing and invites useful guidance |

---

# Round 2: Head of Member Services, your future manager (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probes on the gaps: the contact centre, presenting, coaching supervisors | High. A hiring manager is buying capability and reducing risk, and you have stated two of the gaps yourself (F2, F8) | Rehearse C1 until it is boring. Concede plainly, bridge only from your quotes, give a plan |
| Values / Behavioral | "Tell me about a time…" questions themed on the values | High. The recruiter called this round "mostly behavioural" | Use the values cheat sheet. Where no story is mapped, use the scaffold and its honest branch |
| Data-Driven Prober | Digs into the spreadsheet: what it counts, and how | Medium-low. The JD asks for monthly reporting and you built a monthly complaints spreadsheet (F3), so expect a few questions on it | Know what you can and cannot say about how it counts, and say plainly what you don't know |
| Case / Strategist | Short live problems about the job you would do for them | Low-medium. The hiring-manager pattern, toned down because the recruiter said "mostly behavioural" | Clarify, then structure, then answer, in Ashgrove's words |

## Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked in a contact centre, and this role owns complaints end to end across branches *and* the contact centre. Why should I trust you with the whole thing?" **Highest-ROI prep in this pack** | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | **Opening (about 60 seconds):** (1) Concede first: "I haven't worked in a contact centre." (2) What you do bring, at its own scope: "I handled the branch's formal complaints log." (3) The plan, said as a plan: what you would do in your first weeks to learn the contact-centre side, for example sitting in on calls, reading its complaint records and meeting its team leaders. (4) Hand it back: what would they want you to learn there first? **Follow-up 1, "Phone complaints are different from branch ones":** agree that they can be, and that this is exactly why you would learn it first. Don't claim to know how they differ. **Follow-up 2, "So someone from a contact centre would be better?":** hold your position and don't fold. Concede the specific point, that they would start ahead on that side, then come back to the log and your plan. Never say "complaints are complaints" | F2 is the widest gap against the core remit, and you have stated it yourself, so a manager who is reducing risk will press on it. Deepest rehearsal, with two follow-ups. JD because it scores the remit as written |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level." "Never worked in a contact centre" | Pick one honestly, not a disguised strength. Either: "I haven't presented to anyone above regional level", with how you would get ready; or the contact centre, as in C1. Say the plan, then stop | A classic Skeptic question that rewards honesty about yourself. Both answers rest on gaps you have stated (F8, F2). JD because it scores your self-assessment against the listed requirements |
| C3 | "You'd be coaching branch supervisors on escalations, people at your current level. How would you get them to take coaching from you?" | JD | [grounded] "trained new tellers on our escalation script" "the last 3 as a branch supervisor." | Start with what you did: you trained new tellers on your escalation script, and you are a supervisor yourself, so you know the role from the inside. Answer slot: if you have advised or coached other supervisors, say when and how; if you haven't, say so plainly. Then your principles: you are there to support supervisors, not judge them; work from real cases; agree what "good" looks like with their branch managers | F4's gap between training and coaching, asked in the form a manager would ask it. JD because coaching is a stated responsibility |
| C4 | "Owning the process end to end: what part of your branch's complaints process was yours to decide?" | EXP | [grounded] "I handled the branch's formal complaints log" | Start with the sentence: you handled the branch's formal complaints log. Answer slot: if any part of how a complaint moved from receipt to resolution was yours to decide, say which part and how you decided; if none was, or there was no set route, say so plainly and describe what handling the log involved. The honest branch is a statement of scope, not a confession | F1 is the stretch from one branch's log to a process across branches. EXP because it tests what was actually yours |

## Bank D: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Follow the Own the Fix row of the cheat sheet. Answer slot: if the spreadsheet started from a problem you spotted, say what it was and how you saw it through, in your own words. If it didn't, say so plainly and choose another time; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The wording of Own the Fix turned into a question. VAL because it scores a published value |
| D2 | "Tell me about a time you made a decision from the member's side, even though it was harder for the branch." | VAL | [generic] | A selection scaffold: pick a time a member's interest changed what you or the branch did. It needs the member, the easier route you didn't take, and the result. Use "we" for the branch and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always. VAL because it scores a published value. `[generic]` because no sentence in your material carries this story |
| D3 | "Tell me about an escalation that didn't go well. What did you learn?" | VAL | [generic] | A selection scaffold: pick a real escalation where something went wrong. It needs what happened, your part, and what you changed afterwards. Own your share without blaming the member or a colleague. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's "escalations" line, asked behaviourally. VAL because a manager is scoring ownership. `[generic]` because no escalation story is in your material |
| D4 | "Tell me about a time you had to explain something complicated, to a member or to a new colleague." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers on your escalation script. Tell it in your own words. Answer slot: if you changed how you explained the script, or its wording, because someone didn't follow it, say what you changed; if you didn't, say so plainly and describe how you trained them | Plain Words. VAL because it scores a value, and F4 carries part of the story |

## Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through your monthly complaints spreadsheet. What does it count, and how does your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence: you built it, it is monthly, and your regional manager uses it. Answer slot: say what it counts and over what period, in your own words. If you know how your regional manager uses it, say so; if you don't, say so plainly. Name the figure in it that you would trust least before they ask, or say plainly that you don't know how a figure was counted. Don't add columns, measures or tools that aren't in it | F3 and F9 both rest on this one sentence. EXP because the strongest evidence you have will be the most heavily probed; JD as the second tag because it maps to the monthly-reporting line |
| E2 | "A branch's average resolution time halves in a month. What would you check before reporting it as an improvement?" | CASE | [generic] | Think out loud: did complaint volumes or the mix of complaints change; are complaints being closed early, or reopened; are any missing; is it one branch or several; is one month a trend. Then: what you would put in the report and what caveat you would add. No claim about your past is needed | Tests the JD's reporting line live. CASE because it is reasoning, not a record. `[generic]` because these are general data checks |

## Bank G: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for complaints, and what would you want from the digital teams?" | JD | [grounded] | Clarify: which journeys move first. Then reason: complaints may shift towards digital journeys, and complaints data is early warning for the digital team. Ask for a regular look at complaint themes with them, and plain words in the app. Answer slot: if you have worked with a digital team, say what and what your part was; if you haven't, say so plainly and go on with the plan. No claims about digital work | F5's requirement, set in Ashgrove's own target. JD and CO because it covers both the responsibility and the brief. `[grounded]` on the brief; no claim about your past |
| G2 | "What would you do in your first 90 days?" | CASE | [inferred] | Listen first: visit branches, spend time in the contact centre, establish a baseline for the monthly complaints report, meet the digital team, and get ready for the hubs and the Q1 2027 lending launch. Name one early win that you would want to agree with them, not announce. No claim about your past is needed | A standard manager question. `[inferred]` because the plan is derived from the JD and the brief |

## Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| "What would great look like in this role at twelve months?" | Gets you the manager's own scorecard |
| "Who sees the monthly complaints report today, and how is it presented to senior leaders?" | Shows you are thinking about the presenting part of the role (F8) and lets you plan for it |
| "How do you expect the hub consolidation to affect complaint volumes in 2027?" | Uses the strategy brief at the manager's level |
| "How does this role work with contact-centre leadership day to day?" | Turns the C1 gap into a question about how the work is done |
| "What would you want me to learn first about the contact centre?" | Invites them to shape your plan, and shows you take the gap seriously |

---

# Round 3: panel of two branch managers, the values round with the case (60 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" questions, one value at a time | High. The recruiter said the panel "score against the four values" | Prepare one story or scaffold per value (cheat sheet). Name the value only when it is the real reason |
| Case / Strategist | The 20-minute escalation case, plus short follow-on problems | High. The recruiter pre-declared the case | Use the graded-deliverable section: clarify, say your structure aloud, think aloud |
| Peer Evaluator | "What will you need from my branch? How does your coaching help us?" | Medium. Branch managers would work alongside this role and see its coaching land on their supervisors | Frame it as what you bring them. Propose principles for working together rather than claiming to know how their branches work |
| Pressure / Stress | Devil's advocate on app-only banks, or "why you over our own people?" | Low-medium. Panels often add one challenge, and the case invites follow-up pressure | Pause, restate the question, hold through two follow-ups, then concede the specific point |

## Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "When have you put a member ahead of a branch target or a process?" | VAL | [generic] | A selection scaffold (Members First row): it needs the member, the target or process, the choice, and what happened, including any cost to you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always. VAL because the panel scores each value. `[generic]` because no sentence in your material carries this |
| H2 | "Tell me about a time something had to be explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers on your escalation script. Answer slot: if part of the script or your explanation had to be explained twice and you changed it, say what you changed; if not, say so plainly and choose a time with a member instead. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plain Words, worded almost as Ashgrove writes it. VAL because the panel scores it |
| H3 | "Tell me about a time knowing a member, or the local community, changed how you handled something." | VAL | [generic] | A selection scaffold (Neighbours row): it needs the person, what you knew, and what you did differently. Keep members' details anonymous. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers, the value branch managers are likely to feel most strongly about. VAL. `[generic]` because no sentence carries it |
| H4 | "Tell me about a problem you spotted that wasn't strictly yours to fix. What did you do with it?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Own the Fix row. Answer slot: if the spreadsheet came from a problem you spotted, tell that story in your own words; if not, say so plainly and choose another time you kept hold of a problem. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix asks whether you keep hold of the problem. VAL |

## Bank J: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member's complaint has been escalated to you (details given on the day). Talk us through what you do." **The 20-minute case** | CASE | [grounded] | Use the graded-deliverable section above: two minutes clarifying, say your structure aloud, choose a thesis (T1 to T3) and make its concession, prevent a repeat, a plain-words close, and the anti-pick. Ask which response deadline applies rather than assuming one | The pre-declared graded case; it covers F1's and F7's requirements live. CASE. `[grounded]` on the recruiter's description |
| J2 | "Your branch is closing into a hub next year, and a long-standing member makes a formal complaint about it. How do you handle it?" | CASE | [grounded] | Treat the decision as made and the feeling as real. Listen, explain in plain words what changes and what doesn't, look for what you *can* do for this member, log the complaint properly, and pass the theme up through reporting. Never criticise the strategy, and never brush off the complaint. Be aware that a panel member's own branch may be one of those affected | Combines the hub consolidation with Neighbours, Not Numbers, the tension noted in the grounding brief. CASE with a VAL lens |
| J3 | "Small-business lending launches in Q1 2027. What complaints would you expect, and how would you get ready?" | CO | [grounded] | Reason, don't claim: a new product means questions about eligibility, decision times and how clearly things were explained. Prepare by getting complaint categories set up before launch, briefing branches and the contact centre, and agreeing an early-warning report with the product team. Don't claim any lending experience | Uses the brief's Q1 2027 launch. CO because it tests whether you can think at strategy level |

## Bank K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You'd be coaching our supervisors on escalations. How do we make sure that helps my branch rather than adding to its load?" | JD | [grounded] "trained new tellers on our escalation script" | Start with what you did: you trained new tellers on your escalation script, so you know training has to fit around the counter. Then the reciprocity principles: agree with each branch manager what to coach on, use the branch's own cases, keep sessions short, and report back to them. Ask what has and hasn't worked before | F4's responsibility, priced from the branch manager's side. JD |
| K2 | "If you think one of my supervisors handled an escalation badly and I disagree, what happens?" | JD | [generic] | Principles, not a story: talk to the branch manager first and never go around them, look at the case facts together, agree what the member needs, keep any difference between the two of you, and escalate only if a member or a regulatory deadline is at risk. Show both firmness and tact | Tests how you disagree with equals, a key part of the coaching remit (F4's requirement). JD. `[generic]` because no story is assumed |
| K3 | "As a branch supervisor, what did you need on complaints from the people above the branch that you didn't get?" | EXP | [grounded] "the last 3 as a branch supervisor." "I handled the branch's formal complaints log" | Answer slot: say, in your own words, what you needed while handling the branch's log that didn't come; if nothing was missing, say so plainly. Then turn it round: what you would make sure their branches get from this role. Don't criticise your current employer | Uses your view from inside a branch (F6, F1) as something you offer the panel. EXP because it is premised on your supervisor role |

## Bank L: Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Members are leaving for app-only banks. Isn't the honest answer that branch complaints matter less every year?" | CO | [grounded] | Pause, then hold: complaints matter in every channel, and how they are handled is part of what app-only banks cannot easily copy. Concede the specific point: the brief targets 40% digital by 2028, so the mix will shift and complaints work has to follow members into digital channels. Hold the core point through a second push; don't fold | Uses the brief's competitive frame to test your composure. CO |
| L2 | "Sixty seconds: why you rather than one of our own branch supervisors?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." | Concede first: an internal supervisor knows Ashgrove and its towns. Then hold on what the sentences carry: six years, three as a supervisor; you handled the branch's formal complaints log; you built the monthly complaints spreadsheet your regional manager uses. Close on how you would learn Ashgrove quickly. Don't run down internal candidates | A time-boxed challenge on the experience requirement (F6), asked by people who know the internal pool. JD |

## Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "When a complaint from your branch gets escalated today, where does it tend to get stuck?" | Shows them the problem as they see it, and shows you care about their branch |
| "What would make coaching for your supervisors genuinely useful, rather than one more thing?" | A reciprocity question for people who will share the coaching load |
| "How are your branches helping members through the move to hubs?" | Shows you have read the strategy; ask it with care, because their own branches may be affected |
| "What do you wish the people above the branches understood about complaints in your town?" | Puts Neighbours, Not Numbers into practice and invites their view |
| "How would you like to hear about complaint trends for your branch, and how often?" | Shows you see them as customers of the monthly report |

---

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's own observation, not words for you: your material shows one branch's log, not a process across branches. C4's slot stays inside the log |
| Has contact-centre experience, or "complaints are complaints, whatever the channel" | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders or executives | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." The regional-level part stays an answer slot (B2) |
| Coached supervisors, or designed or wrote the escalation script | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script." The script is "our" script, and the people trained were new tellers. C3's slot stays inside what you did |
| Produces region-wide complaints reporting | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Being used by a regional manager is not the same as covering the region. E1's slot asks only what it counts |
| Managed regulatory compliance for complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." B1's slot asks only which rules it was kept to |
| Advanced Excel or Excel expert | Inflated form of F9 | F9's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." A5's slot asks only which tool and what it does |

Digital and self-service work (F5) is not on this list: your material is silent on it, so it is an answer slot rather than something prohibited.

---

## Sources

**Provided documents**

- Job description, Member Experience Lead, Ashgrove Credit Union (pasted)
- Values text you copied on 12 November 2026 from ashgrovecu.org/about/values (pasted; not fetched)
- Recruiter's email describing the three rounds on 21 November (pasted)
- Your summary of Ashgrove's 2026 strategy brief, published July 2026 and sent to you by the recruiter (the summary was pasted; the brief itself was not)
- Your background, in your message

No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted, copied this morning, already supplies the four value names and their wording for the cheat sheet and the VAL banks |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email establishes the loop: three rounds, who runs each, the case and the values round. Persona weights follow it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Your summary of the July 2026 brief is under six months old and supplies the priorities behind the CO and CASE questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names have been assigned, so there was no query to form. The interviewer read is absent |
| 5. Representative `Member Experience Lead` JD | skipped | You supplied the JD, which sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once the recruiter assigns them** → an interviewer read for each round, persona weights for each panel member based on their public professional profile, and at least one reverse question tied to each person's career path
- **The strategy brief itself, not only your summary** → a fuller grounding brief with Ashgrove's own wording and figures, and sharper G1, J2, J3 and L1 rows
- **Your CV** → more of your own sentences to quote, which could give mapped stories for D2, D3, H1 and H3, where the pack now has only scaffolds
- **Your answers to the answer slots, told to me outside a drill** → F1, F3, F4, F5, F7 and F9 regenerate from your own words, and so do C3, C4, E1, B1, A5 and G1
- **An anonymised copy or screenshot of the monthly complaints spreadsheet, if your employer allows you to share it with no member data** → the artifact this kind of work keeps; it could move F3 and F9 from `medium` to `high`
- **How much prep time you have before 21 November** → a prioritised prep schedule tied to question IDs
- **Whether the case has a written brief or is a role-play (ask the recruiter)** → a case section shaped to that format
- **A deeper research pass, up to 6 more searches and 2 more fetches, taking several more minutes** → recent Ashgrove news since July (for example, hub announcements), the interviewers' public profiles once they are named, and any published reports on Ashgrove's interviews
- **A `tuesday-dossier.md` from an earlier job-underwriter session** → evidence-checked confidence ratings and a list of claims you have already confirmed or rejected. Not needed; this pack is complete without one
