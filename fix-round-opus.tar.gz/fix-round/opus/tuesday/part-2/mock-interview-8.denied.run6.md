I've saved your prep pack. Here's the file:
Dara, your prep pack is ready: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-8-denied-365b295e/ashgrove-credit-union_member-experience-lead_interview_pack.md`

It covers all three rounds from the recruiter's email. One shared table matches each line of the job description to your own words. Then each round gets its own section, with likely questions, answer guidance and questions for you to ask them. I didn't need to search the web: your values page, the recruiter's email and the strategy brief covered everything.

What matters most:
- **Your biggest risk is in Round 2, question D1.** The Head of Member Services will probably ask how you'd cover the contact centre and present to senior leaders when you haven't done either. Admit both plainly first. Then stand on what you have done: the branch's formal complaints log and the monthly complaints spreadsheet. Then say how you'd learn the rest.
- **The 20-minute case has its own section.** It includes a minute-by-minute outline tied to the four values, a practice scenario and what to avoid promising.
- **Your values stories are the gap to close.** Nothing in what you sent me describes a specific moment for any of the four values. So the values section tells you how to pick a story for each one rather than giving you one. Choosing four real stories before 21 November is the most useful prep you can do for the panel.
- **Branch consolidation is a sensitive topic.** Your panel is two branch managers, and the brief plans to merge eight branches into five hubs over 2027. Raise it carefully, and don't guess whose branch is affected.

The pack also lists what it won't coach you to say, such as "owned the process end to end" or "coached supervisors", because your own sentences don't back them.

If you'd like a live rehearsal, I can play the Head of Member Services on D1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union — Member Experience Lead — interview pack

**Candidate:** Dara · **Date of interviews:** 21 November 2026 · **Mode:** loop, three rounds

| Round | Length | Who | What the recruiter said it holds |
|---|---|---|---|
| 1 | 30 min | The recruiter | Screen |
| 2 | 45 min | Head of Member Services (your future manager) | "mostly behavioural" |
| 3 | 60 min | Panel of two branch managers | "a 20-minute case on a complaint escalation"; "the values round — they score against the four values" |

Interviewer names are not assigned yet, so there is no interviewer read; personas rest on the roles the recruiter named.

**Highest-ROI prep in the whole pack: question D1** (Round 2), the contact-centre and senior-leader objection. Second: the 20-minute case build (section 4).

---

## 1. How to use this pack

- **Personas** describe *how* a question will be asked. **Types** describe *what* is being scored.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Provenance** says what each row stands on. `[grounded]` = your own sentences, the JD, the recruiter's email, the values page or the strategy brief. `[inferred]` = this pack's own derivation, which it names. `[generic]` = a common pattern for this kind of role, with no claim about Ashgrove or about you.
- An **answer slot** marks a place where the interviewer will probably dig and your material doesn't give the answer. It has two honest branches: if you did it, say how, in your own words; if you didn't, or it wasn't yours, say so plainly. Both branches are good answers.

| Type | What it scores |
|---|---|
| VAL | Whether things you've done show Ashgrove's four *published* values |
| EXP | Whether what you say about your experience holds up when they probe it, including which part was yours |
| JD | Whether you can do the job as listed, gaps included |
| CO | How well you know Ashgrove's strategy, competition and plans |
| CASE | How you structure and reason through a live problem from the role |

---

## 2. Fit snapshot (shared across all rounds)

Every quote in the evidence column is your own sentence from your message. Everything the pack says about your past draws on these quotes and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on a complaint's stages likely. If any stage of a complaint in that log, from logging it to closing it, was yours to decide, say which and how, in your own words; if none was, or there was no such step, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you've said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence shows a monthly complaints spreadsheet. It doesn't show whether it counts volumes or resolution times, or that you reported from it. Answer slot: if the spreadsheet counts complaint volumes or resolution times, say which and how they're counted, in your own words; if it doesn't, say so plainly and say what it does track |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Training new tellers isn't the same as coaching supervisors, and the bridge shouldn't be stretched. Words: "I trained new tellers on our escalation script," and "my last three years were as a branch supervisor." Answer slot: if you've coached anyone beyond new tellers on escalations, say who and how, in your own words; if you haven't, say so plainly and stay with the teller training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a time you worked with a digital or online-banking team, or on how members do something without staff. Answer slot: if you've done anything like that, say what and what part was yours, in your own words; if you haven't, say so plainly and say how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence already covers this, just in different words. Say it as written: "Six years in retail banking, the last three as a branch supervisor." Leave it to the interviewer to read that as "customer operations". Don't relabel it in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" doesn't show "regulated", and the pack won't make that jump for you. Answer slot: if particular rules applied to how the complaints in that log were handled, say which ones and what part of following them was yours, in your own words; if you don't know of any, or following them wasn't your part, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated gap. Words: "I haven't presented to anyone above regional level." Your sentence doesn't say you presented *at* regional level either, so the pack doesn't claim that. A ramp plan, said as a plan |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says spreadsheet. It doesn't say Excel. Answer slot: if it's built in Excel, say so and name what you actually use in it, in your own words; if it's built in another tool, name it and say plainly how comfortable you are in Excel |

### Requirement coverage

| JD requirement | Questions that rehearse it |
|---|---|
| Own complaints end to end across branches (F1) | A3, D2, H1, H2 |
| …and the contact centre (F2) | B2, D1 |
| Monthly reporting on volumes and resolution times (F3) | P1, E2 |
| Coach branch supervisors on escalations (F4) | C2, J1, J3 |
| Digital self-service journeys (F5) | E3 |
| 4+ years financial-services customer operations (F6) | A1, B3 |
| Regulated complaints (F7) | D3 |
| Presenting to senior leaders (F8) | D1 |
| Excel reporting (F9) | A4, E2 |

---

## 3. Grounding brief (from the strategy brief and pages you supplied)

The strategy brief is from July 2026, about four months old. If an interviewer mentions something newer, go with what they say. Don't correct them from the brief.

| Fact or reading | Source | Provenance | Where it's used |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, via recruiter | [grounded] | A5, E3; the JD's "self-service journeys" line sits on this |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief | [grounded] | A5, E1, J2 |
| Your panel is two branch managers, and the brief plans branch consolidation over 2027. The brief doesn't say which branches. Treat it as a topic they may feel personally and raise it with care. Don't speculate about whose branch is affected | Reading of the brief and the recruiter's email | [inferred] | J2; panel reverse question 3 |
| Small-business lending product launching Q1 2027 | 2026 strategy brief | [grounded] | A5; a new product can bring new kinds of complaint, which is this pack's reasoning, not the brief's |
| Main competitive pressure: app-only banks | 2026 strategy brief | [grounded] | A2, A5, E3 |
| Member-owned, about 900 staff | JD | [grounded] | A2 |
| Four values, by name: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | ashgrovecu.org/about/values, as pasted 12 November 2026 | [grounded] | Section 9 cheat sheet; G1–G5; H1 |

---

## 4. Graded deliverable: the 20-minute complaint-escalation case (Round 3)

**What's established:** "a 20-minute case on a complaint escalation", run by "a panel of two branch managers", who "score against the four values" (recruiter's email). The recruiter didn't say whether it's a written scenario, a role-play or a discussion, or whether you get prep time. That's recruiter reverse question 2.

**Your facts to build on:** F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." Nothing beyond that sentence is said about your past in this section.

**A 20-minute shape (a rehearsal method, not a script):**

| Minutes | Move | Value it shows |
|---|---|---|
| 0–2 | Clarify: what the member wants, what's already been tried, which channel, any deadline or rules that apply. Ask the panel. Don't assume | Plain Words |
| 2–5 | Restate it from the member's side of the counter, in one or two plain sentences | Members First, Always |
| 5–10 | Immediate fix: what you'd do today, who you'd speak to, what the member hears and when | Own the Fix |
| 10–14 | Cause: was this one mistake or a pattern? Which branch or channel? Did the escalation route itself work? | Own the Fix |
| 14–17 | Prevent and report: what changes for supervisors, what goes into the monthly complaints numbers | JD coaching and reporting lines |
| 17–20 | Close the loop: the plain-words message to the member, and how the branch stays involved rather than having it taken away | Neighbours, Not Numbers; Plain Words |

**Three defensible theses, each with its concession:**

| Thesis | Concession you say aloud |
|---|---|
| Fix the member's problem first, then chase the cause. Whoever takes the escalation keeps hold of it until both are done | Speed can't override whatever rules govern a complaint's handling, so you'd check which apply before promising a timeline |
| One escalation is data. Log it so the monthly report can show whether it's a pattern | One case isn't a trend, and changing a process on a single case risks fixing the wrong thing |
| The resolution is only finished when the member understands it first time, in writing and in person | Plain words can't make an unwelcome outcome welcome. Sometimes the honest answer is still no |

**Differentiation:** the consensus answer is a generic apologise–resolve–follow-up script. It's correct, and every candidate brings it. What sets an answer apart here is naming the value out loud at each decision point, because the panel scores against the values. Then go one step past the member: say how this case feeds supervisor coaching and the monthly report. Both of those are in the JD.

**Anti-pick (what to say no to):** don't promise compensation, a refund or an outcome before you know the facts and the policy. Don't quietly take the complaint off the branch. Say how the branch stays part of the fix.

**Requested close:** the recruiter named none. End on what the member hears, which is where all four values meet.

**Practice scenario to rehearse with** `[generic]` (a made-up pattern, not an Ashgrove case): a member's fee complaint was closed at the branch. They then rang the contact centre and were told something different. Now they're asking for the branch manager. Run the 20-minute shape on it out loud, with a timer.

---

## 5. Round 1 — Recruiter screen (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk-through of your background, motivation, logistics | High. A recruiter screen's usual register, and 30 minutes leaves little room for depth | A pre-built 90-second background arc (A1). Treat casual questions as scored |
| Skeptic (light) | Knockout checks against the JD lines your background doesn't obviously show | Medium. Recruiters screen the listed requirements, and F2 and F6 are the visible ones | Short, plain answers drawn from the F2 and F6 quotes. No over-explaining |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, in this order: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words. Stop there and let them pick what to dig into | F6, F1, F4 and F3 together are the spine of every later round, so the arc gets set once here; EXP because the recruiter is checking that your story is consistent |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Selection scaffold: pick the published value, or the strategy fact (the hubs, the move to digital, the app-only competition), that matches a reason you actually have, and say it in your own words. If none of them is why you applied, give your real reason plainly. A made-up fit to a value reads as homework, not motivation | Motivation consistency gets checked early and again in Round 3; CO because the honest answer has to touch the values page or the brief |
| A3 | "Tell me about the complaints log you handled at your branch." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the sentence says: the branch's formal complaints log was yours to handle. Answer slot: the JD's "end to end" makes a probe on a complaint's stages likely. If any stage of a complaint in that log was yours to decide, say which and how; if none was, say so plainly and describe how you handled the log | F1 is your closest evidence to the headline JD line; EXP because a recruiter will want it in your words before passing you on |
| A4 | "How are you with Excel?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it's in Excel, say so and name what you actually use in it; if it's another tool, name it and say plainly how comfortable you are in Excel. Don't list features you don't use | F9 is a listed requirement asked casually; JD because it's a checkbox the recruiter is ticking |
| A5 | "What do you know about where we're heading?" | CO | [grounded] | Two facts from the brief, briefly: 40% of member service to digital by 2028, and eight branches into five hubs over 2027. Then the small-business lending launch, and app-only banks as the pressure. Finish with one sentence on what that means for complaints, said as your view: more complaints arriving through digital channels, and branch changes members will have feelings about | The recruiter sent you the brief, so they'll expect you to have read it; CO because it scores homework |
| B1 | "Why move from the branch into a central role now?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say what you've done, as the sentence states it, then your real reason for wanting the wider remit, in your own words. Avoid anything that reads as running away from branch work. The panel are branch managers | F6 and F4 set up the move; JD because it checks that your motivation matches the job's actual scope |
| B2 | "This role covers the contact centre as well. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain and short: "I haven't worked in a contact centre." Then one line of plan: how you'd learn it, said as what you'd do, not what you've done. Don't fill the silence. A short honest answer passes a screen better than a long hedge | F2 is a stated gap against a JD line, so a recruiter will check it; JD because it's a knockout-style check. Full rehearsal is D1 |
| B3 | "The JD asks for customer operations experience. How does your background fit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say the sentence: six years in retail banking, the last three as a branch supervisor. Six is more than the four asked for. Let them map it; don't restate it as "customer operations" | F6 is a presentation gap, so the move is to say it plainly; JD because it scores the listed requirement |

### Reverse questions (Round 1)

| Question | Why it lands |
|---|---|
| "Could you share who the Head of Member Services and the two panel members will be, once they're assigned?" | Lets you prepare for each of them. It's a normal logistics ask |
| "How is the 20-minute case run: a written scenario, a role-play or a discussion, and is there prep time?" | The case is the one graded deliverable, and its format changes how you rehearse it |
| "Is this a new role or a backfill?" | Tells you whether you'd be building the complaints process or taking one over |
| "How does the panel's values scoring feed into the final decision?" | Shows you've read the process and take the values round seriously |
| "What's the timeline after the 21st?" | Practical, and it closes the screen cleanly |

---

## 6. Round 2 — Head of Member Services (45 minutes, "mostly behavioural")

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" questions | High. The recruiter said this round is "mostly behavioural", which outweighs the usual hiring-manager tilt toward cases | Pick stories in advance (C1–C3 scaffolds). "We" for context, "I" for your part |
| Skeptic | Quiet, persistent probing of F2 and F8 | High. A future manager is reducing their hiring risk, and both stated gaps sit on JD lines they own | D1, rehearsed until it's boring |
| Case / Strategist | Short live problems on their roadmap | Medium. The usual hiring-manager focus, scaled down by "mostly behavioural" | Clarify, then structure, then answer; use the brief's own terms |
| Data-Driven Prober | "What's in the spreadsheet? How is it counted?" | Low to medium. Monthly reporting is a JD line and F3 is your only evidence for it | Know exactly what you can and can't say about the spreadsheet (P1) |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't worked in a contact centre, and you haven't presented above regional level. This role owns complaints across the contact centre and reports to senior leaders. Why should I take that risk?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | **Highest-ROI rehearsal in the pack.** Concede first, plainly, using only what you told me: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then hold on what you did, at its own scope: you handled the branch's formal complaints log, trained new tellers on your escalation script, and built the monthly complaints spreadsheet your regional manager uses. Then a ramp plan said as future, with steps you'd really take. For example: time with the contact-centre team early on, and asking them what a good senior-leader update looks like before you give one. Follow-up 1, "So you'd be learning on the job?": yes for the contact centre. Say so, then return to the log and the spreadsheet without adding to them. Follow-up 2, "Why not hire someone who's done both?": concede the risk is real and name it; don't fold on what the quotes carry. Never let it slip that you've presented at regional level. Your sentence doesn't say so | F2 and F8 are the two stated gaps, and both sit on JD lines this manager owns, so this objection will come in some form; JD because it scores listed requirements under Skeptic pressure |
| D2 | "The JD says end to end. What part of a complaint's journey have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold only what the quote carries: "I handled the branch's formal complaints log." Answer slot: if any stage of a complaint in that log, from logging to closing, was yours to decide, say which and how, in your own words; if none was, say so plainly and describe how you handled the log. The second branch is a limit, not a confession. Hold through follow-ups by going back to the log, never by adding to it | F1 is where the JD's ownership line presses hardest; JD because it scores the headline requirement |
| D3 | "What experience do you have with regulated complaints?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with what the sentence says: you handled the branch's formal complaints log. Answer slot: if particular rules applied to how the complaints in that log were handled, say which ones and what part of following them was yours; if you don't know of any, or following them wasn't your part, say so plainly and stay with the log | F7 is a discovery gap on a listed requirement, so the honest answer needs to be ready before the probe; JD, with the JD's premise not adopted by the guidance |
| C1 | "Tell me about a time a complaint had to be escalated beyond you." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one real escalation. It needs the member's problem (no names or account details), why it went beyond you, what you did before and after, and how it ended for the member. If no such time comes to mind, say so plainly. Then give the nearest thing your material carries, the branch's formal complaints log you handled, or how you'd handle one | The JD's escalation lines (F1, F4) make this the likeliest behavioural opener; VAL because a behavioural round scores the behaviour, EXP as secondary |
| C2 | "Tell me about a time you coached someone who was getting something wrong." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: you trained new tellers on your escalation script. Those are the beats the sentence gives; tell them in your own words. Answer slot: the JD's "coach branch supervisors on escalations" makes a probe on how you trained likely. If you corrected someone mid-way, say how you did it; if training was all upfront, say so plainly and describe it | F4 is your evidence for the coaching line; VAL delivery, JD content |
| C3 | "Tell me about a time you told someone more senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: it needs a named stake, what you said, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then say how you'd handle it. Your future manager is the person you'd be telling hard truths to | Senior-leader reporting (F8's requirement) makes this a natural behavioural theme; `[generic]` because none of your sentences carries a story for it |
| E1 | "Six months after a branch moves into a hub, its complaints are up 20%. How do you work out what's going on?" | CASE | [grounded] | Clarify first: up 20% in count or as a share, which complaint reasons, which channels. Split by reason, by channel (branch, contact centre, digital) and by before and after the move. Check resolution times too, not just volume. Then: talk to the hub supervisors, listen from the member's side, fix what's fixable, report it monthly. Say the value when you use it | The hub consolidation is in the brief, and a hiring manager asks about their own roadmap; CASE because it scores structure, and it presupposes nothing about your past |
| E2 | "What would you put in the monthly complaints report you'd give me?" | CASE | [grounded] | Start from the JD's own words: volumes and resolution times, split across branches and the contact centre. Then what you'd add and why, and what you'd ask them first (who reads it, what decisions it feeds). Make no claim about your spreadsheet here unless they ask, and if they do, go to P1 | F3's and F9's requirements, asked as design rather than track record; JD content, CASE delivery |
| E3 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints, and how would you work with the digital team?" | CO | [grounded] | Your view, structured: which complaints may shift to digital channels, how you'd hear about them, and how complaint themes could feed back into fixing self-service journeys. Answer slot for the second half: the JD's "work with digital teams on self-service journeys" line makes this likely. If you've worked with a digital or online-banking team, say what you did; if you haven't, say so plainly and say how you'd start | Grounded in the brief's headline target; CO, plus JD for F5's requirement, which no other question covers |
| P1 | "Tell me about the monthly complaints spreadsheet. What's in it, and how much of it was you?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the sentence says: you built it, and your regional manager uses it. Answer slot: the JD raises volumes and resolution times. If the spreadsheet counts either, say which and how they're counted, in your own words; if it doesn't, say so plainly and say what it does track. If any part of it is someone else's work, say which part. Don't describe it as a report you presented | F3 and F9 both rest on this one sentence, so a prober will go there; EXP because it tests what was actually yours |

### Reverse questions (Round 2)

| Question | Why it lands |
|---|---|
| "Where does the complaints process break today, between the branches and the contact centre?" | Goes straight at the JD's end-to-end line and shows you'll start by listening |
| "Who reads the monthly complaints report now, and what decision did it last change?" | Shows you think about reporting as something used, not just produced |
| "Who would I be presenting to, how often, and what does a good update look like to you?" | Raises F8 yourself, on your own terms, as a question about how to do it well |
| "How do you expect the move to five hubs to change where complaints come in?" | Puts the brief to work and invites them to think out loud with you |
| "What would make the first 90 days a success, from where you sit?" | Your future manager's answer is your scorecard |

---

## 7. Round 3 — Branch-manager panel (60 minutes: values round + 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One or more questions per value, scored | High. The recruiter: "they score against the four values" | Section 9 cheat sheet; one prepared story per value |
| Case / Strategist | The complaint-escalation case | High. 20 of the 60 minutes, stated by the recruiter | Section 4 build; H1–H2 |
| Peer Evaluator | "What would you need from us? What happens when we disagree?" | Medium. This role coaches their supervisors (JD) and handles complaints from their branches, so they're judging what you'd add to their load or take off it | Talk about what you bring their branches, and propose working principles rather than claiming to know the seam |
| Pressure | One time-boxed challenge | Low. No signal for it; one item so the style isn't new on the day | Pause, restate, anchor in your quotes |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | The case: "Here's a complaint that's been escalated. Talk us through how you'd handle it." | CASE | [grounded] | Use the 20-minute shape in section 4. Clarify before you structure, name the value at each decision, and finish on what the member hears. Think out loud and check in with the panel at the halfway point | Recruiter-declared, 20 minutes, scored against the values; CASE, and it presupposes nothing about your past |
| H2 | "You've fixed it, and the member is still unhappy. What now?" | CASE | [generic] | Hold, then concede. Hold on what was fixed and why; concede that fixed and satisfied aren't the same thing. Then: listen again, explain the outcome in plain words, say what further options exist under the policy, and keep hold of it until it closes. Don't promise what the policy doesn't allow | The predictable follow-up to any escalation case; `[generic]` because it's a common pattern, not an Ashgrove fact |
| G1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Members First, Always. Selection scaffold: pick a time you chose something by asking what the member would experience. It needs a specific situation (no names or account details), the choice you made, and what happened for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the branch's formal complaints log you handled, or how you'd handle it | The value's own wording sets the theme; VAL, scored by name |
| G2 | "Tell me about a time you had to make something clear to a member, or to staff, that wasn't clear the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Plain Words. Selection scaffold: it needs what was unclear, what you changed in how you explained it, and how you knew it landed. If no such time comes to mind, say so plainly. Then give the nearest thing your material carries, training new tellers on your escalation script, or how you'd handle it | The value's "explained twice" line sets the theme; VAL |
| G3 | "Tell me about a time something local to your branch's town shaped how you handled a member." | VAL | [generic] | Neighbours, Not Numbers. Selection scaffold: it needs the local context, what you did differently because of it, and the outcome. If no such time comes to mind, say so plainly, then say how you'd keep a hub feeling like part of its town | The value's "every branch is part of its town" sets the theme, and the hub moves make it live for this panel; `[generic]` because none of your sentences carries a story for it |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Own the Fix. Selection scaffold: it needs the problem, the point where you could have handed it off, what you did instead, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the branch's formal complaints log you handled, or how you'd handle it | The value's own wording sets the theme; VAL |
| G5 | "When would 'Own the Fix' and escalating a complaint pull in different directions?" | VAL | [grounded] | Hypothetical, so no claim about your past. Structure: escalating isn't letting go. Whoever finds the problem keeps hold of the member and the follow-through, even when someone else has the authority to decide. Name the tension honestly, then the rule you'd apply | Tests whether you understand the value, not just its slogan; VAL with CASE delivery |
| J1 | "If you were coaching our supervisors on escalations, what would you need from us?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with what you'd bring their branches, then what you'd need: time with their supervisors, their view of where escalations go wrong, and a say in how the coaching runs. You trained new tellers on your escalation script, so you can say that and stop there. Don't describe coaching supervisors as something you've done | F4's requirement asked as a peer would ask it; JD content, Peer delivery |
| J2 | "Branches are moving into hubs over 2027. How would you handle complaints about that, when our own staff are unsettled too?" | CO | [grounded] | Gently: acknowledge it's their teams and their towns. Then structure: hear complaints about the change from members' side, explain plainly, keep the local link (Neighbours, Not Numbers), and report the themes so leadership sees them. Don't speculate about which branches are affected | The brief's consolidation plan, seen through the panel's own seat; CO with Peer delivery |
| J3 | "You'd be coaching our supervisors, the job you do now. How do you make that land with them?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say what the sentence says: your last three years were as a branch supervisor, so you know the seat. Then how you'd coach, as a plan: as a colleague who's been in the role, not as head office. Answer slot: if you've coached anyone beyond new tellers on escalations, say who and how; if you haven't, say so plainly | F4's limit, said as a seam question by people whose supervisors you'd coach; JD |
| K1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause, then give two of your quotes, the branch supervisor years and the complaints log, and one honest line: an internal candidate knows Ashgrove better than you do, and you'd close that by listening first. Stop before sixty seconds. Don't run down an unnamed rival | Tests composure; JD because it scores fit under time pressure |

### Values cheat sheet

None of your sentences carries a story for any of the four values. Your material describes roles and responsibilities, not specific moments. So every row is a selection scaffold. Picking four real stories before the 21st is the single most useful thing you can do for this round.

| Value (official name) | Working meaning | Your story | Question |
|---|---|---|---|
| Members First, Always | Decide by looking at it the way the member would | Scaffold: a time you chose something because of what the member would experience. Needs the situation, your choice and the member's outcome. If none comes to mind, say so plainly, then give the nearest thing F1 carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | G1, H1 |
| Plain Words | If it has to be explained twice, it was written wrong | Scaffold: a time you made something clearer for a member or a colleague. Needs what was unclear, what you changed, and how you knew it worked. If none comes to mind, say so plainly, then give the nearest thing F4 carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | G2, H1 |
| Neighbours, Not Numbers | Each branch belongs to its town | Scaffold: a time local context changed what you did. If none comes to mind, say so plainly, then say how you'd keep hubs local | G3, J2 |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | Scaffold: a problem you didn't hand off. Needs the hand-off moment and what you did instead. If none comes to mind, say so plainly, then give the nearest thing F1 carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | G4, G5, H1 |

### Reverse questions (Round 3)

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would actually help your supervisors with escalations?" | Reciprocity: it asks what you can give their teams, not what you need from them |
| "When a complaint is escalated out of your branch today, what do you hear back?" | It's Own the Fix as a question, and it tells you where the loop breaks |
| "How are you thinking about keeping branches part of their towns through the move to hubs?" | It's Neighbours, Not Numbers, asked with care on a subject that may be personal to them |
| "Which of the four values is hardest to live at the counter?" | Invites candour, and their answer is useful data for the job |
| "What does a well-handled escalation look like from your side?" | Their answer is how they'll judge you in the role |

---

## 8. Prohibited claims (what this pack will not coach)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material says one branch's log, not a process across branches. D2's slot stays inside the log |
| Has worked in, or alongside, a contact centre | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F8 | "I haven't presented to anyone above regional level." No slot |
| Has presented at regional level | Inflated form of F8. Your sentence rules out above regional and doesn't state at regional | F8's quote, nothing more. The pack's observation: the material says nothing about presenting at any level |
| Reported or presented complaint volumes and resolution times to the regional manager | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." The pack's observation: the material says built and uses, not reported or presented. P1's slot asks only what the spreadsheet counts |
| Coached branch supervisors | Inflated form of F4 | "I trained new tellers on our escalation script." The pack's observation: the material says new tellers |
| Wrote or designed the escalation script | Inflated form of F4. The quote says "our escalation script" | F4's quote at its own scope. The pack's observation: the material says you trained people on it, not who wrote it |
| Handled regulated complaints | Inflated form of F7. "Formal" widened to "regulated" | F7's quote at its own scope. D3's slot asks only which rules applied to the log you handled |
| Six years in financial-services customer operations | Inflated form of F6. It uses the JD's vocabulary for your own history | "6 years in retail banking, the last 3 as a branch supervisor." |

---

## 9. Sources

**Provided documents:** the JD (pasted); Ashgrove's values, pasted from ashgrovecu.org/about/values (copied 12 November 2026); the recruiter's process email (pasted); the 2026 strategy brief, as you summarised it from the copy the recruiter sent; your background (your message). No dossier was present.

**Searches and fetches:** none sent. Every L1 target was already covered by what you pasted.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted this morning gives the four names and definitions that the cheat sheet and G1–G5 use |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email sets out all three rounds, who runs each, the case and the values scoring. Persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 strategy brief is under six months old and supplies the priorities that A5, E1, E3 and J2 rest on |
| 4. Interviewer names at Ashgrove | n/a | No names have been assigned, so there was no query to form. There's no interviewer read, and the upgrade menu says what names would add |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions |

---

## 10. Upgrade menu

- **Four real stories, one per value**, told to me in a sentence or two each → the values cheat sheet turns from scaffolds into mapped stories, and G1–G4 become story-mapped
- **Your answers to the answer slots on F3, F5, F7 and F9** (what the spreadsheet counts and what it's built in, any digital or online-banking work, which rules applied to the complaints log) → those rows can be re-graded, and P1, E3, D3 and A4 get firmer guidance
- **Your CV or résumé text** → more of your own sentences to quote, which may close gaps the four sentences in your message don't reach
- **A redacted layout of the monthly complaints spreadsheet** (column headings only, no member data) → the inspectable artifact that could raise F3 and F9 above `low`
- **Interviewer names, once assigned** → per-person persona weights, an interviewer read, and a reverse question tied to each person's path
- **How much prep time you have before the 21st** → a prioritised prep schedule
- **Deep research** (up to 6 more searches and 2 more fetches, several more minutes) → checks on Ashgrove's recent news since the July brief, and on any public material from the Head of Member Services once named
- **A tuesday-dossier.md from an underwriting pass** → would add an evidence-derived highest-ROI objection and binding strategies per weak area; this pack is complete without one
