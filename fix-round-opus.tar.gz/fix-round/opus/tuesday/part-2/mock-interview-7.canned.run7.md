I'll just read the files directly.
Research is done (four searches, two page fetches). I'm writing the prep pack now.
Femi, your prep pack is ready: `saltmarsh-games_live-operations-producer_interview_pack.md`. Friday is tomorrow, so it opens with a plan sized for one evening.

**What Saltmarsh's own site says about the interview:**
- **Format:** the hour is called the "Outage Hour". It starts with a live tabletop exercise on a simulated outage during a live event, then moves to a values conversation. There's no take-home. The page says the hiring manager runs it, so I've treated Tobias as your future manager.
- **Values:** Saltmarsh has three, and you should know their exact names: "Players Before Plans", "Ship the Patch Not the Promise" and "Leave the Build Greener". Your release checklist fits the third one almost word for word.
- **Tobias:** he gave a GDC 2026 talk called "Patch Notes Are a Promise", and he used to be a QA lead. Your checklist is your strongest point of contact with him.
- **Recent news:** in September Saltmarsh announced Project Larkspur. From February 2027 its two titles, Tidepool Tactics and Lantern Row, move to a season pass and share one events calendar, run by a single live-ops group. That makes your lack of in-app-purchase experience a live topic. The pack gives you a plain way to say it (C4).

**What to rehearse most (C1):** the question "what have you coordinated across design, art, engineering and community?" Nothing you told me shows that coordination, and you've said you've never led a team. The pack gives you a way to hold your ground on the content calendar you ran, concede the leadership gap in one sentence, and then lay out a plan.

**Gaps you can close tonight:** the pack leaves blanks where I didn't know the answer:
- Was your main title a mobile game?
- Was it a live-service game?
- Which teams did you work with on the content drops?
- What was in the monthly retention numbers you presented?

Fill those with your own facts before Friday.

If you'd like a practice run, I can play the Skeptic and ask you C1, with follow-ups that react to your answers.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, so you can use it in later sessions.
If you'd like the pack as a Word document, I can convert it.

Has the recruiter confirmed that Tobias is your future manager, or told you anything to focus on for the tabletop? A different setup would change how the pack weights the question types.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The pack treats him as the hiring manager, because Saltmarsh's interviewing page says the 60-minute interview is run by the hiring manager.
**Format:** the "Outage Hour", one 60-minute session. It opens with a live-incident tabletop on a simulated outage during a live event and then moves to a values conversation. There is no take-home (Sources, target 2).
**Date:** Friday 13 November 2026

---

## How to use this pack

- **Personas** describe *how* a question gets asked (who is asking, and in what style). **Types** describe *what* it is scored on.
- Type key:
  - **VAL**: behavioural or values fit, measured against Saltmarsh's *published* values
  - **EXP**: work-experience deep-dive. Does your account hold up, and which part was actually yours?
  - **JD**: a stated responsibility or requirement from the job description
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, worked out loud
- **The guidance gives you structure, not a script.** Every claim about your past rests on one of your own sentences, which is quoted next to it. Wherever the pack doesn't know something, it gives you an **answer slot**: a probe you should expect, with two honest ways to answer it.
- Question IDs go by persona: A (Case), B (Values), C (Skeptic), D (Prober), E (Pressure), G (Conversational), H (Cross-team).

## Prep triage: one evening

Friday is tomorrow, so this plan assumes you have one evening.

1. **C1, rehearsed out loud twice.** This is the highest-ROI prep in the pack: the coordination objection, and how to hold your ground and then concede it.
2. **A1 to A3 as one continuous run.** The tabletop is the first half of the hour. Practise the clarify → stabilise → communicate → decide → record structure until you no longer have to think about it.
3. **B1 to B3: one story per value, using the official names.** The values conversation is the second half of the hour.
4. **D1:** know exactly what was in the monthly retention numbers and who prepared them.
5. **C4:** practise the in-app-purchases acknowledgment and your ramp plan until saying them feels ordinary.
6. Pick three reverse questions, including R1 or R2.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material covers one title's weekly content drops. It doesn't cover two titles or live events, so describe it at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD says "mobile titles". If your main title was on mobile, say so. If it wasn't, say that plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show any cross-team coordination. Answer slot: if you worked with any of design, art, engineering or community on the content drops, say which teams and what you did with them, in your own words. If you didn't, say so plainly and describe how you'd run that coordination. Coordinating is not leading, so don't treat this as the same gap as F9 |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | You presented monthly numbers. That isn't the same as owning a post-event review, so stay at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you ever reviewed how a drop performed after it went out, say what you looked at. If you didn't, say so and describe the review you'd run |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap here, but nothing has been inspected behind it, so expect a probe. Lead with the quote's own two beats: you wrote it, and QA still uses it. Answer slot: the JD says "manage … with QA", so expect to be asked how it worked release by release. If you ran it with QA on each release, say how. If you didn't, say so and stay with writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives the four years and the weekly drops. It doesn't say whether the main title was a live-service game. Answer slot: if it was, say so in your own words. If it wasn't, say that plainly and describe what the weekly drops were |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | This one is direct. Say it in the quote's terms: weekly, main title, last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Your quote reaches the requirement, but a prober will ask what was behind it. Answer slot: say which retention measures were in those numbers and who prepared them. If you don't know how they were counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist is one kind of writing, and it's the one your material shows. Answer slot: if you also wrote event briefs, patch notes or player-facing text, say which. If you didn't, stay with the checklist |
| F9 | Leading a team. Not in the JD, but a likely probe when the role coordinates four disciplines | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated this gap yourself. The words for it: "I haven't led a team." After that, describe how you'd approach it, as a plan and never as something in your past |
| F10 | Season-pass model under Project Larkspur. Not in the JD, from Saltmarsh's news page | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated this gap too. The words for it: "I haven't worked on a game with in-app purchases." After that, describe how you'd get up to speed, as a plan |

**Requirement coverage**

| JD requirement | Fit row | Questions |
|---|---|---|
| Plan and run the live-events calendar, two mobile titles | F1 | C2, A5 |
| Coordinate design, art, engineering, community | F2 | C1, H1 |
| Own the post-event review and its KPIs | F3 | A4, D2 |
| Manage the release checklist with QA | F4 | H2, D3, B1 |
| 3+ years producing live-service games or apps | F5 | C3, G1 |
| Experience running a content calendar | F6 | C2, A5 |
| Comfortable with player-retention metrics | F7 | D1, D2 |
| Clear written communication | F8 | G2, A2 |

---

## Reading the interviewer

| What | Detail | Provenance |
|---|---|---|
| Career pattern | Previously a QA lead at a console studio, now Head of Live Operations at Saltmarsh | [grounded] GDC 2026 talk listing (Sources) |
| Public theme | GDC 2026 talk "Patch Notes Are a Promise". His argument is that a live team is judged by how often its patch notes describe what actually shipped | [grounded] GDC 2026 talk listing |
| The company line it echoes | Saltmarsh's value "Ship the Patch Not the Promise: we announce what is built, not what is hoped" | [grounded] values page |

**What this means in practice**

- During the tabletop, every player-facing message you propose will probably be judged on one thing: does it say only what is true right now? Announce what's known and fixed, never an ETA you haven't confirmed (A2, E2).
- He came up through QA, so release checklists and QA hand-offs are his home ground. F4 is your strongest point of contact with him. Describe it in the quote's own words, "Wrote the release checklist our QA team still uses", and don't add anything to it.
- Don't recite his talk back to him. Use it for one reverse question (R1).
- There's no shared career move to point to: his path runs from QA to live ops, and your material doesn't show the same jump. Don't present it as one.

---

## Persona table

| Persona | How it shows up on Friday | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event, worked through live | **Highest (5 questions).** The interviewing page puts the tabletop first in the hour, and the hiring-manager prior already leans toward live problems | Clarify → stabilise → communicate → decide → record. Think out loud and question one premise respectfully |
| Values / Behavioral | The second half of the hour, built on the three published values | **High (4).** The interviewing page names a values conversation, so this is certain to come up | One story per value, using the official names. "We" for the context, "I" for what you did |
| Skeptic | Probes the gaps: two titles, coordination, live-service, monetisation | **Mid (4).** The hiring-manager prior. F1, F2, F5, F9 and F10 give a skeptic plenty to work with | Rehearse C1 until it bores you. Hold on your quotes, concede plainly, then give the plan |
| Data-Driven Prober | "Which retention numbers? How were they counted?" | **Mid (3).** The JD names retention metrics and the post-event KPIs, and F7 is your only quote on numbers | Know what you can and can't say about those numbers. "I don't know how it was counted" is an honest answer |
| Pressure | Time-boxed moments inside the tabletop, plus a "why you" challenge | **Low (2).** A simulated outage invites time pressure, but nothing names a stress style | Pause, restate the question, anchor on your quotes, and hold through two follow-ups |
| Conversational | The opener and the move between the two halves | **Low (2).** A 60-minute single session usually opens with a biography question | Have a 90-second arc ready. Casual questions are still scored |
| Cross-team (Peer-style) | Scenarios about design, art, engineering and community disagreeing | **Low (2).** No peer is in the room, but the JD's coordination line makes these scenarios likely | Agree principles for how teams hand work over, and decide by player impact |

The weights rest on Saltmarsh's own interviewing page, not on a guess about the format. If the recruiter says someone other than Tobias is in the room, the weights change.

---

## Question banks

### A. Case / Strategist: the Outage Hour tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a weekend event on one of our titles. The event server goes down and players can't claim rewards. Walk me through your first 30 minutes." | CASE | [grounded] | Clarify first: which title, all players or a segment, whether rewards are lost or only delayed, and whether purchases are affected. Then stabilise: get engineering on it and agree who owns the fix. Communicate: community posts what is known, with no ETA you haven't confirmed. Decide what happens to the event clock. Record a timeline as you go so the post-event review has it. Say each step aloud as you do it. Nothing here needs a claim about your past | The interviewing page names this exact exercise. CASE because what's being scored is your structure under a live problem |
| A2 | "Engineering says a fix is ready in two hours but untested. Community wants to give players a time. What goes out?" | CASE, VAL | [grounded] | This is "Ship the Patch Not the Promise" played live. Recommend a message that says what's broken, that it's being worked on, and when the next update will come, rather than when the fix will land. Then say what would change your mind: once QA has confirmed the fix, announce it. Write the message out loud in two sentences, because that also shows written communication (F8's requirement) | The values page and Tobias's talk both make this the moment most likely to be judged. CASE delivery, VAL content |
| A3 | "It's fixed, but players lost most of a day of a seven-day event. Extend it, compensate, or neither?" | CASE | [grounded] | "Players Before Plans" decides the direction, and the calendar sets the cost. Clarify what an extension pushes on the calendar, especially once both titles share one calendar from February. Compare the options against player impact and the next event's dates. Pick one and give your reason. Name the risk you're accepting | This tests a values-led call against a calendar the role owns (F1's requirement). CASE |
| A4 | "Now run the post-event review for that incident. What's in it, and which KPIs do you report?" | JD, CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: timeline, player impact, root cause in engineering's words, what the release checklist did or didn't catch, and actions with owners and dates. KPIs: participation, retention around the event window, and support contacts, each against a pre-event baseline. Present it as a plan. If you mention your past, the nearest thing your material carries is "I presented the monthly retention numbers to the studio head". Don't describe that as owning a review | This covers F3's "own the post-event review". JD content in CASE delivery. Your material is adjacent here, so the answer has to be a plan |
| A5 | "From February our two titles share one events calendar. How would you plan it so they don't cannibalise each other?" | CO, CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Show you know the facts: Project Larkspur, Tidepool Tactics and Lantern Row, one shared calendar, one live-ops group. Then structure it: goals per title, overlap between their audiences, staggering the big beats, shared capacity across art and engineering, one release checklist per drop, and a review cadence. Your anchor at its own scope: one title, weekly drops, two years. Answer slot: if running that calendar shaped how you'd plan this one, say how, in your own words. If not, give the plan on its own | This is the CO question tied to Saltmarsh's current strategy, and it covers F1 and F6. It goes beyond what most candidates prepare |

### B. Values / Behavioral: the second half of the hour

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Leave the Build Greener. Tell me about something you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats are the two your sentence states: you wrote the checklist, and QA still uses it. Tell them in your own words. Answer slot: the value says every release leaves "the checklist better than it found them". If you revised the checklist after a release showed a gap, say what changed and why. If it didn't change, or the changes weren't yours, say so and stay with writing it | This is your best value match and Tobias's home ground. VAL because it's scored against the published value by name |
| B2 | "Players Before Plans. Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The setting is the calendar you ran. Answer slot: if a drop was ever moved, changed or pulled because of how players responded, say what happened and what part of the decision was yours. If no such time comes to mind, say so plainly, then describe how you would decide | The value is defined in the calendar's own terms, and F6 is the calendar. VAL |
| B3 | "Ship the Patch Not the Promise. When have you held back an announcement until the thing was actually built?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick an instance from the calendar years. It needs a drop that wasn't ready, a choice about what to say, and what was said. If no such time comes to mind, say so plainly, then give the rule you'd work by: announce what has passed the checklist | This is the value closest to Tobias's talk, so expect him to ask it. VAL |
| B4 | "Tell me about a time you told leadership something they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | The setting is the monthly presentation to the studio head. Answer slot: if a month's numbers were bad news, say how you presented them and what happened next. If none were, say so plainly and give the nearest example your experience carries | A standard values stem, and F7 is your only evidence that you presented to leadership. VAL |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role coordinates design, art, engineering and community on every update. What have you coordinated across teams yourself?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI rehearsal in this pack.** What you can hold is what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if running it meant working with design, art, engineering or community, name which teams and what you did with them, in your own words. If it didn't, say so plainly. Follow-up 1 will probably be "Who did you lead?" Concede it cleanly: "I haven't led a team." Then return to the calendar and don't add to it. Follow-up 2, "So how would you do this here?": give a plan. Agree hand-off dates per discipline, keep one shared checklist, and hold a short pre-release sync. Say it as what you'd do, not what you've done | The JD lists four disciplines, and your material shows none of them (F2), plus a stated gap in leading (F9). That makes this the most predictable objection. JD because it scores a stated responsibility |
| C2 | "We run two titles. You ran one calendar. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the scope: one main title, weekly, two years. Then say what changes when there are two: dependencies, shared capacity, and audience overlap (A5 has the structure). Answer slot: the JD says "mobile titles". If your title was on mobile, say so. If it wasn't, say so plainly | This covers F1 and F6. Skeptic delivery, JD content |
| C3 | "Was your game a live-service title? How does a weekly content drop compare with a live event?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if the main title was run as a live-service game, say so in your own words. If it wasn't, say that plainly and describe what the weekly drops were. Then compare them as a producer: cadence, dependencies, and what can go wrong mid-event | F5 is the requirement with the clearest wording in the JD, and your material doesn't answer it. JD |
| C4 | "Under Larkspur both titles move to a season pass. Have you worked on monetised games?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly and early: "I haven't worked on a game with in-app purchases." Then the ramp, as a plan: what you'd learn first about how a season pass changes the calendar and the post-event KPIs, and who you'd learn it from. Don't claim season-pass or monetisation experience, and don't soften the gap | F10 is a gap you stated, and Larkspur makes it a live topic. CO because it tests whether you know the strategy |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which retention numbers were in that monthly presentation, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which retention measures were in them, how they were counted, and who prepared them, all in your own words. If you don't know how they were counted, say so plainly. That's an honest answer. Name the part of them you'd defend least before he asks | F7 is your only quote involving numbers, and a prober will press on it. EXP because it tests what was yours |
| D2 | "Did retention move around your content drops? How would you know a drop caused it?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Answer slot: if you ever compared retention against the drops, say how, in your own words. If you didn't, say so plainly. Then the plan: a baseline before each event, a comparison window, and the other things that could explain a change. Say what would make you distrust the result | This covers F3 and F7: the post-event KPIs and how comfortable you are with retention. JD |
| D3 | "What's in the release checklist, and how do you know QA still uses it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats your sentence carries are that you wrote it and QA still uses it. Answer slot: describe what's in it, in your own words, and how you know they use it. Don't list contents from memory you're not sure of | F4 is the claim closest to Tobias's QA background, so he'll want detail. EXP |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run monetised live events?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Pause, then three beats in your quotes' own words: the calendar, the checklist, the retention numbers. Concede the gap in one line: "I haven't worked on a game with in-app purchases." Hold the three beats through two pushes. Don't add a fourth claim to win the argument | The hardest comparison anyone could put to you, combining F6, F4, F7 and F10. Time-boxed to test composure |
| E2 | Mid-tabletop interruption: "Players are already posting about it. Thirty seconds. What goes out?" | CASE | [grounded] | Two sentences: what's broken, and when the next update will come. No promise of a fix time. Then stop talking | It tests "Ship the Patch Not the Promise" under time pressure. CASE |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc using only your quotes: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist QA still uses; the monthly retention numbers you presented to the studio head. Close on why live ops at Saltmarsh, in your own words | The likely opener. It covers F5 in casual delivery |
| G2 | "What does clear written communication look like on a live team?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Your example at its own scope: a checklist your QA team still uses. Then the principle: player-facing text says only what has shipped. Answer slot: if you also wrote event briefs, patch notes or player-facing text, say which. If you didn't, stay with the checklist | This covers F8 and touches Tobias's public theme without reciting it. JD |

### H. Cross-team

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Art is late on an event asset two days before release. Engineering wants to cut the feature and design wants to ship it. What do you do?" | CASE | [generic] | Clarify what's actually late and what depends on it. Lay out the options: ship without the asset, swap in a fallback, or move the beat on the calendar. Decide by player impact, with each discipline heard. Record the decision and the reason | This covers F2's coordination requirement through a live scenario. It's generic, a common live-ops pattern rather than a fact about Saltmarsh |
| H2 | "How do you work with QA on a release?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Lead with the quote. Answer slot: the JD says "manage the release checklist with QA". If you ran it with QA release by release, say how, in your own words. If you didn't, say so and describe how you would | This covers F4, and it's Tobias's own background. JD |

---

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F6: "I ran the weekly content-drop calendar for our main title for the last two years." Pick a drop that changed because of how players responded. If none did, say so plainly and give the rule you'd work by (B2) |
| Ship the Patch Not the Promise | Announce only what's built | F6: "I ran the weekly content-drop calendar for our main title for the last two years." Pick an instance where an announcement waited for the build. If no such time comes to mind, say so plainly and state the rule (B3) |
| Leave the Build Greener | Each release leaves the code and the checklist better | F4: "Wrote the release checklist our QA team still uses." (B1) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your GDC talk you argued a live team is judged by how often its patch notes describe what actually shipped. How does the live-ops group track that today?" | It's tied to his own published argument, and it shows you researched him as well as the company |
| R2 | "You came to live ops from QA. What did QA teach you that you look for in a producer?" | It's tied to his career path and turns the hour toward a conversation between equals |
| R3 | "With per-title event teams folding into one live-ops group, how will producer work split across Tidepool Tactics and Lantern Row?" | It shows you know about Larkspur, and the answer tells you what the job will actually be |
| R4 | "What does a post-event review look like here now, and which KPI does leadership read first?" | It's the JD's ownership line, asked as diligence |
| R5 | "Who owns changes to the release checklist today, and how does a change get agreed?" | It ties "Leave the Build Greener" to your strongest area |
| R6 | "What would a strong first 90 days look like, given the February calendar change?" | It invites him to describe success and shows you're thinking about the transition |

---

## Prohibited claims

These are claims this pack won't coach. Don't let follow-up pressure pull them out of you.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated (F9) | "I haven't led a team." No slot |
| Has worked on a monetised, in-app-purchase or season-pass game | A negative you stated (F10) | "I haven't worked on a game with in-app purchases." No slot |
| Ran live-events calendars across multiple titles | An inflated form of F1 | F1's quote at its own scope. The pack's observation: your material covers one main title's weekly drops |
| Owned post-event reviews or the KPIs they report | An inflated form of F3 | "I presented the monthly retention numbers to the studio head." The pack's observation: presenting isn't the same as owning a review |
| Managed the QA team or ran QA | An inflated form of F4 | "Wrote the release checklist our QA team still uses." Slots stay on how the checklist was used |

---

## Sources

**Provided:** the JD text and your background, both pasted in your message. No dossier was present.

**Searches and fetches**

- Search "Saltmarsh Games values" → saltmarshgames.com/values
- Fetch saltmarshgames.com/values → three values and their definitions
- Search "Saltmarsh Games interview process producer" → saltmarshgames.com/careers/interviewing
- Fetch saltmarshgames.com/careers/interviewing → recruiter call, then the Outage Hour: a 60-minute hiring-manager interview with a live-incident tabletop followed by a values conversation. No take-home
- Search "Saltmarsh Games mobile studio news 2026" → saltmarshgames.com/news/project-larkspur (September 2026: Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, and per-title event teams are retired in favour of a single live-ops group)
- Search "Tobias Wrenfield Saltmarsh Games Head of Live Operations" → talks.gdconf.example/2026/patch-notes-are-a-promise (GDC 2026 talk listing, snippet only)

**Target accounting**

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and bank B, with the three values by official name |
| 2. Saltmarsh Games interview process | yes | Established the loop: one 60-minute session with a tabletop and then values. This set the persona weights, made bank A the tabletop, and detected a values round |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur: A5, C4, F10, R3, R6 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read, R1, R2, and the framing of A2 and E2. Snippet only, because the fetch budget went on targets 1 and 2 |
| 5. Representative JD | skipped | The JD you supplied sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **The recruiter confirming who's in the room and any focus areas** → confirms or resets every persona weight
- **Deep research pass (L2)**: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief on Tidepool Tactics and Lantern Row, the full text of Tobias's talk, and sharper CO and CASE questions
- **Your answers to the answer slots** (mobile or not, live-service or not, which teams you worked with, what was in the retention numbers) → F1, F2, F3, F5, F7 and F8 regenerate with your own words, and C1, C2, C3, D1 and D2 get story maps instead of slots
- **The release checklist itself, or a redacted page of it** → F4 moves from `medium` to `high`. It's the one artifact in this field that a QA-minded interviewer can actually inspect
- **One of your monthly retention decks, redacted** → F7 moves toward `high`, and D1 gets a real story map
- **Your CV** → more quotes to draw on, and possibly answers to the F2 and F5 slots
- **A tuesday-dossier.md from an underwriting pass** → would make the highest-ROI objection evidence-derived and add a ready-made prohibited-claims list. You don't need it for this pack
