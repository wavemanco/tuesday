Building your prep pack now. Next I'm running a few targeted searches on Kelverton Rail and your panel.
I've saved your prep pack as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. It covers the 15-minute POV, 22 practice questions split between Deepa and Ross, and a four-hour plan for the weekend.

What it's based on: only your message and the recruiter's email. Every web search I tried was blocked by this session's permissions. The market report's content isn't in our conversation, so nothing in the pack draws on it. Anything about Kelverton beyond your words and the recruiter's is a general template, labelled as such, with blanks showing where the report's findings go.

The most important thing to rehearse is Ross asking how much of the £4M was actually you. It's question D1, and it combines influenced revenue with never having carried a quota. The pack gives you a way to state that limit before he asks, and three follow-ups to practise holding your ground through.

If you want, I'll play Ross on D1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Do you have the job description? If you paste it, the two rows based on generic role assumptions get replaced with its actual wording. Otherwise I'll keep going without it.
2. Do you want me to research Kelverton and both panellists? That means allowing web search. The standard pass is up to 6 searches and 2 page reads; a deeper pass adds 6 more searches and 2 more reads and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second-round panel, 60 minutes, Tuesday. **Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). **Format, in the recruiter's words:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."

**What this pack was built on:** your message and the recruiter's email as you quoted it. No job description was supplied. The internal market report is not in this conversation, so nothing in this pack draws on it; where it would help, the pack tells you where to plug it in. Every web search was refused by this session's permissions, so anything about Kelverton beyond the recruiter's words and yours is a scaffold labelled `[generic]`.

---

## How to use this pack

- **Personas** describe how a question is asked: who asks, and in what register. **Types** describe what is being scored.
- Type key:
  - **VAL**: behaviour against values (no values round is documented here, so these are light)
  - **EXP**: whether your own history holds up under questioning, and what was actually you
  - **JD**: can you do the role's stated job, including its gaps (here the "stated job" is the recruiter's brief, as there is no JD)
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, reasoned out loud
- Provenance labels: `[grounded]` traces to your words or the recruiter's; `[inferred]` is a derivation with its source named; `[generic]` is a role-family pattern that makes no claim about Kelverton.
- **Answer slots** are instructions for the interview, not questions for me. Each has two branches, and the "it wasn't mine / it didn't happen" branch is a real answer, not a confession.
- Guidance is scaffolding, not a script. Say it in your own words.
- Question IDs: fit-snapshot rows are F1–F5, so the question banks use A–E, G and H. The letter F is skipped so the two sets of IDs never clash.

---

## Prep triage (about 4 hours over the weekend)

| Order | Block | Time | What to do |
|---|---|---|---|
| 1 | The POV, section "Graded deliverable" | 75 min | Choose your two or three theses, fill the report slots from the market report, then say the whole thing aloud twice with a 15-minute timer. Cut until it fits in 13 minutes |
| 2 | D1, the highest-ROI question | 30 min | Rehearse the influenced-revenue answer through all three follow-up levels until it bores you |
| 3 | B1, B2, B3 | 30 min | Write your own answers to the defend-the-number slots: how the £4M and the 6-to-40 were counted, and which part was yours. Ross will go two levels down |
| 4 | Answer slots on F1 and F2 | 20 min | Write down, in your own words, which channel decisions were yours, and what contact your consulting work had with operators. A1 and C1 both depend on it |
| 5 | Bank A (Deepa's cases) | 30 min | One pass out loud on A1–A3 using the clarify → objective → segment → approach → metric → risk structure |
| 6 | C1, D2 | 15 min | The rail gap: plain acknowledgment, the bridge, the ramp plan |
| 7 | Reverse questions | 10 min | Pick three: one for Deepa, one for Ross, one you actually need answered |
| 8 | One live drill | 20 min | Ask me to play Ross on D1 |

Everything else in this pack is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material shows a partner channel you ran and grew, in payments rather than rail. Nothing is inspected behind it, so expect a probe. The words stay at the quote's scope: "For the last four years I ran the ISV channel at a payments company. It went from 6 partners to 40, and roughly £4M of influenced revenue." Answer slot: the recruiter's "where you'd take" line makes a probe on how the channel's direction was set likely. If choosing which partners to add, or the channel's plan, was yours, say how you decided, in your own words. If there was no such plan, or it wasn't yours, say so plainly and stay with running the channel |
| F2 | "land on what it means for the operators themselves" — recruiter | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material shows five years of bus and light rail network planning from the consulting side. It does not show train operators or work inside an operator. Keep the modes exactly as you stated them. Words: "Before partnerships I spent five years in transport consulting, on bus and light rail network planning." Answer slot: the recruiter's operator line makes a probe on what you actually saw of operators' own priorities likely. If your planning work put you alongside operators' decisions, say which and what you saw, in your own words. If it didn't, say so plainly and stay with the network planning |
| F3 | Knowledge of selling to UK train operating companies (role-family requirement, no JD) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | none | [generic] | capability | A gap you have stated yourself, and wording cannot close it. Words: "I haven't sold into rail specifically." Then F2's quote at its own scope, then a ramp plan said as a plan, never as a past. Add nothing to make the gap feel smaller |
| F4 | "Ross will push on commercials" — recruiter | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Influenced revenue is commercial evidence. It is a different measure from revenue you closed or carried. Keep "roughly" and keep "influenced": "roughly £4M of influenced revenue". Answer slot: Ross's commercial push makes the defend-the-number probes likely: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words. "I don't know exactly how it was counted" is an honest answer |
| F5 | Owning a direct revenue target (role-family requirement for a senior partnerships role, no JD) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | A gap you have stated. Words: "I've never carried a direct quota. My number has been influenced revenue." Then how you would want to be measured here, said as a plan. Never imply a quota you didn't hold. Don't guess either way about deals you did or didn't close. That's an answer slot in D1 |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1: where to take operator partnerships, 18 months | The POV build, A1, A2, A4, D3 |
| F2: what it means for operators | The POV close, A3, A5, C2, G2 |
| F3: selling to train operators | C1, C2, D2 |
| F4: commercials | B1, B2, B3, B4, B5, E1, E2 |
| F5: owning a direct number | B3, D1, D3 |
| Motivation (not stated by the recruiter, but asked at almost every panel) | C3, G1 |

---

## Graded deliverable: the 15-minute POV

**What you're building:** a spoken point of view on where you'd take Kelverton's operator partnerships over 18 months, with no slides, ending on what it means for operators (the recruiter's requested close). Deepa and Ross circulated the market report themselves, so reciting it scores as homework. Use one consensus point from it to show you've read it. Then make one clear divergence with reasons, and one thing you would *not* do.

**Facts about you that the POV may lean on, quoted exactly:**
- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
- F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- F3/F5, to concede early rather than have it found: "Never sold into rail specifically and never carried a direct quota, only influenced revenue."

**Shape for 15 minutes** (pending your approval):

| Minutes | Beat | Content |
|---|---|---|
| 0–2 | Frame | Who you are, using F1 and F2 at their own scope. What you'll cover. Your one-sentence thesis. Name what you're not claiming: you haven't sold into rail |
| 2–4 | The consensus point | Report slot: the report's headline finding about operators or partnerships, in your words, with one number from it if it has one. "Your own report says X, and I agree." |
| 4–10 | Two or three theses | Choose from the table below. Each gets what you'd do, why, and the concession |
| 10–13 | What it means for operators | The requested close. Say it in operator terms, not Kelverton terms |
| 13–15 | Commercials and measures, pre-empting Ross | How partners would earn and how you'd be measured, including the honest line about influenced versus sourced revenue. Then the anti-pick, and stop |

**Thesis options** (pending your approval). Each is a hypothesis to test against the market report, not a fact about Kelverton:

| # | Thesis | Mandatory concession | Provenance | Operator meaning (for the close) |
|---|---|---|---|---|
| T1 | Pick partners by operator workflow, not partner count. Prioritise the products an operator's planners and controllers already use next to scheduling, and make the integration the partnership | Integration partnerships are slow to show revenue. The first 6–9 months look like cost | [generic] | Fewer hand-offs between systems the operator already runs, and fewer re-keyed timetables. Report slot: use the report's own operator pain point here if it names one |
| T2 | Fewer, deeper. A small set of anchor partners with a joint operator proposition, tiered, before any breadth play | Fewer partners means a smaller logo count to show the board in year one, and it concentrates risk on a few relationships | [generic] | One accountable answer when something breaks across two vendors, instead of two vendors pointing at each other |
| T3 | Treat operators as design partners. One or two operators co-shape the partner roadmap, so partnerships follow operator demand rather than vendor supply | Operators' procurement and governance cycles may make this slow. A design partner is not a buyer | [generic] | A say in what gets built and integrated, rather than being sold a bundle |

**Anti-pick (choose one, say it with reasons):** a candidate who grew a channel from 6 to 40 is expected to propose a count-led recruitment drive. Saying you would *not* lead with partner count, and why, is the strongest divergence available to you. It uses F1's own quote as context, not as a boast. Say it only if you believe it. If your payments experience taught you the opposite, say that instead.

**Differentiation against the consensus answer** `[generic]`: the predictable POV is "more partners, a marketplace, a partner portal". What sets you apart is sequencing (what you'd do in months 0–6, 6–12 and 12–18), a stated thing you'd stop or refuse, and an operator-side close that sounds like an operator talking, not a vendor.

**Report slots to fill before you rehearse:** (1) the report's headline operator finding, (2) any named adjacency or competitor, (3) any number about operator count, contract cycle or market size. Quote those only from the report itself, never from memory. If the report doesn't say it, leave it out.

---

## Persona table

The recruiter's own words establish this session's loop: one 60-minute panel, a 15-minute POV, then Q&A, with two named panellists. So the weights below come from that, not from a guessed company pattern.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (Deepa) | Follow-ups on the POV: "which partner first", "how would you know it's working" | High. She's your future manager, and the hiring-manager pattern is Case plus Skeptic. The POV invites plan-level follow-ups | Clarify, then objective, segment, approach, metric, risk. Say the structure out loud. Challenge one premise respectfully |
| Data-Driven Prober (Ross) | Takes your £4M and 6-to-40 apart: denominators, attribution, what counted | High. The recruiter said "Ross will push on commercials", and F4 is the number he will reach for | Know what you can and can't say about how each figure was counted. Name your weakest assumption before he does |
| Skeptic (Deepa) | "You haven't sold into rail. Why you?" | Medium. It's the hiring-manager prior, and F3 is a stated gap | Plain acknowledgment, then the bridge at its own scope, then a ramp plan |
| Pressure (Ross) | Interrupts, time-boxes, "how much of that was actually you" | Medium. A commercial director told to "push" often plays devil's advocate. F5 is the soft spot | Pause, restate, hold through two follow-ups, then concede the specific thing, not the whole case |
| Peer Evaluator (Ross) | Where partners and his sales team collide | Low to medium. Partnerships and the commercial function share revenue, so the seam is his real concern | Propose seam principles, not a turf claim |
| Conversational | The opener: "walk us through your background" | Low. Two minutes at most, but it's scored | A rehearsed 90-second arc |
| Values / Behavioural | A "tell me about a time" or two | Low. No values round is documented, and Kelverton's values page couldn't be read | Selection scaffolds, ready but light |

---

## Question banks

### A. Case / Strategist (Deepa): 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Of all the partner types you could build around a scheduling product, which would you sign first, and what do you need to know before committing?" | CASE | [generic] | Clarify first: what operators buy alongside scheduling, and where today's partner revenue comes from. Segment the partner types out loud (integration and technology partners, consultancies and integrators, data partners, operators as design partners). Choose using operator demand, integration effort and channel conflict with direct sales. Commit to one first move and say what would change your mind. This question needs no claim about your past, so the guidance makes none | This is the most natural follow-up to the POV, and it tests whether the plan survives one level down. CASE because it is a live problem from the role |
| A2 | "It's month six. How do I know your plan is working?" | CASE | [generic] | Separate leading from lagging indicators: partner-sourced pipeline, partner-influenced pipeline, integrations live, operator references. Say plainly which of these is a sourced number and which is an influenced number. Ross will hear the difference, and it is F4's distinction | Deepa will want to know how she'd manage you. CASE, and it sets up Ross's B3 |
| A3 | "An operator says they'd rather buy the bundle through a partner than from us. What do you do?" | CASE | [generic] | Clarify why: procurement, an existing relationship, or a better combined offer. Objective: keep the operator, then keep margin. Options: let the partner lead with registration and margin rules, co-sell, or hold direct. Choose one and name the risk you accept. Bring it back to what the operator gets | Channel conflict is the classic partnerships case, and it lets Deepa watch you reason with Ross in the room. CASE |
| A4 | "Walk me through how you took the ISV channel from 6 partners to 40." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Story-mapped on F1, telling only the beats the quote states: four years, running the ISV channel, 6 partners to 40, and roughly £4M of influenced revenue. Use your own words. Answer slot: the recruiter's "where you'd take our operator partnerships" line makes a probe on how partners were chosen likely. If choosing which partners to recruit was yours, say how you decided, in your own words. If it wasn't yours, or there was no deliberate selection, say so plainly and stay with running the channel | F1 is the only evidence for the partnership-strategy requirement, so Deepa will open it up. EXP because it tests what was actually yours |
| A5 | "Strip the vendor language out. What does an operator actually get from our partnerships that it doesn't get buying us direct?" | CO | [generic] | Answer as an operator would: fewer systems that don't talk to each other, one accountable answer across vendors, a voice in what gets integrated. Report slot: use the report's operator pain point if it names one. Never borrow F2 to claim you've been inside an operator | This is the recruiter's requested close turned into a question, so expect it if the POV close is thin. CO because it tests company altitude, `[generic]` because no Kelverton strategy could be researched |

### B. Data-Driven Prober (Ross): 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Say it as you said it: "roughly £4M of influenced revenue". Keep both "roughly" and "influenced". Answer slot, the four things the figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least (name that one before he asks), and which part was yours. If you don't know exactly how it was counted, say so plainly and say what you do know | F4 is the headline commercial figure and the recruiter has said Ross will push on commercials. EXP because it is a defend-the-number probe |
| B2 | "Forty partners. How many of them actually moved revenue?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: this is the denominator question. If you know how many of the 40 contributed, and how concentrated it was, say so in your own words. If you don't know, say so plainly. Don't estimate on the spot. Then the honest point: a count of partners and the revenue they influenced are different measures | The 6-to-40 count is the second headline in F1, and a prober always asks for the concentration behind a count. EXP |
| B3 | "If I gave you a number to own here, what would it be and how would you want to be measured?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Plain acknowledgment from your own words: "I haven't carried a direct quota. My number has been influenced revenue." Then a proposal, said as a plan: a split between partner-sourced pipeline you'd own and influenced revenue you'd report, and why you'd want both. Don't name a figure you can't reason to. Say what data you'd need to set it | F5 is the stated gap and F4 the commercial push. JD because it scores the role's commercial expectation directly |
| B4 | "How would you structure the commercials with a partner: referral fee, revenue share, resale margin?" | CASE | [generic] | Lay out the options and when each fits: referral for light-touch introductions, revenue share for co-built integrations, margin where the partner resells and supports. Answer slot: Ross's commercial push makes "have you set partner terms before" likely. If you set or negotiated partner commercial terms at the payments company, say which and how, in your own words. If that wasn't yours, say so plainly and reason it through as a plan | This is Ross's native ground, from the recruiter's line on commercials. CASE delivery |
| B5 | "What does a partner-sourced pound cost us compared with a direct one?" | CASE | [generic] | Structure it: partner payout, enablement and support cost, and channel-conflict leakage, against direct cost of sale and the operator's lifetime value. Say which input you'd need from Ross's team to answer it properly. Concede that partner economics often look worse in year one | Unit economics is how a commercial director tests whether partnerships pay. CASE |

### C. Skeptic (Deepa): 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't sold into rail. Why should I trust your read of operators?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Concede first, in your own words: "I haven't sold into rail specifically." Then F2's quote at its own scope: five years of bus and light rail network planning in consulting. Answer slot: if that work put you alongside operators' decisions, say what you saw. If it didn't, say so and keep to the planning. Close with a ramp plan in your first 90 days (operator conversations, shadowing sales, the report), said as a plan | F3 is the gap Deepa owns the risk on as hiring manager. The negative is your own statement, so the question can say it. JD |
| C2 | "Payments ISVs and rail operators are very different buyers. What doesn't transfer?" | JD | [generic] | Name what doesn't transfer before she does. Pick from what you believe: buying cycle length, the regulatory and franchise context, the number of buyers, safety-critical change control. Then what does transfer, without claiming the operator side. Ending on "here's what I'd have to learn" is a strong close | This is the Skeptic's version of F1's transferability gap. JD because it tests the role's domain requirement |
| C3 | "Why leave payments? Why rail, and why now?" | EXP | [generic] | Selection scaffold: give your actual reasons, using at least one that connects back to F2's quote at its own scope. Avoid anything that sounds like running from payments. If there's no strong "why now", say what's true rather than inventing urgency | Motivation consistency is the Skeptic's standard probe on a sector switch. EXP |

### D. Pressure (Ross): 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Influenced revenue is everyone's revenue. You've never carried a number. How much of that £4M was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | **The highest-ROI rehearsal in this pack.** Name the limit first: "It's influenced revenue, roughly £4M. I didn't carry a direct quota." Hold on what the quotes carry: you ran the ISV channel, and it went from 6 partners to 40. **Follow-up 1** ("so how much was you?"): answer slot. If you can say which part of that influence was your work, say it in your own words. If you can't separate it, say so plainly. **Follow-up 2** ("so you've never closed anything?"): answer slot. Your material doesn't say either way. If you negotiated or closed deals yourself, say which. If not, say so and return to running the channel. **Follow-up 3** ("why put you in front of operators' commercial teams?"): hold, without adding to the quotes, then B3's proposal for how you'd be measured. Never fold on the core claim. Concede only the specific thing | F4 and F5 together are the single most predictable objection to you. The recruiter has said Ross will push on commercials, and influenced revenue is exactly where he'll press. EXP because it is an attribution probe under pressure |
| D2 | "Sixty seconds: why you over someone who's sold rail software for ten years?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Pause. Concede in one clause that they'd know rail selling better. Then the two quotes at their own scope: a partner channel you ran and grew, and transport planning before that. Close on the POV's thesis, not on a claim about yourself. Stay inside 60 seconds | This is the time-boxed version of F3. JD |
| D3 | "Your 18-month plan. Give me the one number you'd commit to by month twelve." | CASE | [generic] | Choose the type of number (partner-sourced pipeline, live integrations, or operator references) and say why that one. Don't invent a figure. Say what it would be based on, and that you'd set it once you'd seen the pipeline data. If he insists, give a range with its assumption named | This pressure-tests the POV and F5 together. CASE |

### E. Peer Evaluator (Ross): 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "My sales team and your partners will sometimes chase the same operator. Where's the seam?" | CASE | [generic] | Propose principles rather than claiming turf: deal registration, compensation that doesn't penalise sales for partner-led wins, a named owner per operator account, and a joint review of contested deals. Ask what works today, which is reciprocity in action | Partnerships and the commercial function share revenue, so this is Ross's real working concern. CASE |
| E2 | "How do you handle credit when a deal spans partners and direct sales?" | EXP | [generic] | Selection scaffold: choose a time at the payments company when credit for revenue was shared between teams. You need a named situation, how it was resolved, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then say how you would set the rule here | Credit is the peer version of D1, from the recruiter's commercial line. EXP |

### G. Conversational: 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Before you start, walk us through your background." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | 90-second arc, pending your approval: transport consulting on bus and light rail network planning for five years, then partnerships, with the last four years running a payments company's ISV channel from 6 partners to 40 and roughly £4M of influenced revenue. Then one line on why rail now. Don't let it eat the POV's 15 minutes | Nearly every panel opens this way, and F1 and F2 are the arc. EXP |
| G2 | "What are you seeing in rail tech at the moment?" | CO | [generic] | Casual, but scored. Anchor on the market report in your own words (report slot) and one thing you'd want to test. Say nothing about the market you can't source | Panels often ask this lightly, and it tests whether you're current. `[generic]` because no research could run |

### H. Values / Behavioural: 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you told a partner or a senior colleague something they didn't want to hear." | VAL | [generic] | Selection scaffold: you need a named stake, a moment you didn't back down, and a relationship that survived. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | A standard behavioural stem. It's kept light because no values round is documented. VAL |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, the metric it cost, and why it was right. If no such time comes to mind, say so plainly, then say how you'd weigh operator outcomes against partner revenue here | It ties to the recruiter's operator close. VAL |

---

## Reverse questions

| # | Question | For | Why it lands |
|---|---|---|---|
| R1 | "What does a great first year in this role look like to you, and what would make you think the hire hadn't worked?" | Deepa | It's her bar as your manager, in her words, and it tells you what the POV should have prioritised |
| R2 | "How is partner-influenced revenue counted and credited here today?" | Ross | It meets his commercial push head-on and shows you know the difference matters (F4) |
| R3 | "Which part of the market report do you two disagree with, if any?" | Both | It shows you read it as a debate, not as homework, and draws out the real strategy tension |
| R4 | "Where do partners and direct sales collide today, and who decides?" | Ross | It addresses the seam (E1) as a peer, before it becomes a turf question |
| R5 | "Which operators would you most want me to sit in front of in my first 90 days?" | Deepa | It turns the rail gap (F3) into a ramp plan she helps shape |
| R6 | "What do operators complain about most that partnerships could fix?" | Both | It brings the conversation back to the recruiter's operator close, from their side |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried, hit or beat a revenue quota | A negative you stated, F5 | "I've never carried a direct quota. My number has been influenced revenue." |
| Generated, closed or sold £4M | Inflated form of F4. "Influenced" is not closed | F4's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: the material says influenced, not closed |
| A precise £4M figure | Inflated form of F4, which says "roughly" | Keep "roughly £4M" |
| Rail sales experience | A negative you stated, F3 | "I haven't sold into rail specifically." |
| Worked inside an operator, or operator-side experience | Inflated form of F2 (relationship axis) | F2's quote at its own scope. The pack's observation: the material says you know the operator world from the other side, through consulting |
| Train or heavy-rail planning experience | Inflated form of F2 (scope axis) | F2's own modes: bus and light rail network planning |
| Built the ISV channel from scratch | Contradicted by F1's own "from 6 partners to 40" | F1's quote: "took it from 6 partners to 40" |

---

## Sources

**Provided:**
- The recruiter's email, as you quoted it in your message.
- Your background, from your message.
- The internal market report: you said it was attached and that you've read it, but its content is not in this conversation, so nothing here draws on it.

**Searches sent (all refused by this session's permissions):**
- `Kelverton Rail values`: refused
- `Kelverton Rail interview process partnerships`: refused
- `Kelverton Rail scheduling software train operating companies news 2026`: refused
- `Deepa VP Partnerships Kelverton Rail`: refused
- `Senior Partnerships Manager rail software job description UK`: refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have themed H1 and H2 on Kelverton's published values. No values cheat sheet either way, because no values round is documented |
| 2. `Kelverton Rail interview process` | unavailable | The search was refused. It would have checked the loop, but the recruiter's words already set this session's structure |
| 3. `Kelverton Rail` strategy and recent news | unavailable | The search was refused. It would have grounded A5, G2 and the POV theses in Kelverton's current strategy and moves, rather than `[generic]` |
| 4. Interviewer footprint | unavailable | The Deepa query was refused. No query was sent for Ross after the refusals. It would have added a "Reading the interviewer" section and a reverse question tied to each panellist's career path |
| 5. Representative Senior Partnerships Manager JD | unavailable | The search was refused. It would have turned F3 and F5 from `[generic]` into quoted `[inferred]` rows |

---

## Upgrade menu

- **The job description text** → F3 and F5 become quoted `[grounded]` rows, the requirement-coverage table becomes the JD's own list, and any mid-list requirement gets its own JD question.
- **The market report's key pages or findings, pasted** → the POV's report slots get filled, T1–T3 are tested against it, and A5 and G2 move from `[generic]` to `[grounded]`.
- **Web search allowed** → Kelverton's values, recent news, and Deepa's and Ross's public professional footprint. That adds a "Reading the interviewer" section, persona weights read from their backgrounds, and reverse questions tied to their paths.
- **A deeper research pass (L2)** → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, the panellists' talks or writing, and recent org context. Offered once.
- **Your own answers to the slots in F1, F2 and F4** (which channel decisions were yours, what operator contact your consulting involved, how the £4M was counted) → A4, B1, B2, C1 and D1 move from answer slots to story-mapped guidance.
- **A tuesday-dossier.md from an earlier evaluation of this role** → an evidence-checked list of objections and claims to avoid, instead of the ones this pack inferred.
