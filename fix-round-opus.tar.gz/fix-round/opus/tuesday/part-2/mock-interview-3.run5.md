No dossier. Reading the files the playbook requires.
I've built your prep pack, but it's generic so far. I had no job description and no CV, and my web searches were blocked by permissions, so I couldn't look up Stripe's values, interview process or current strategy. Nothing in it about Stripe or about you is made up.

What's in it:
- **A fit worksheet** with seven requirements typical of product operations roles. Each row says what strong evidence looks like, and there's a blank for you to write one real sentence about your own work.
- **21 practice questions** across seven interviewer styles, mixing live cases, metric probes, pressure questions and behavioral questions. Each comes with answer guidance and a note on why it's likely to come up.
- **Seven questions to ask your interviewers**, and a list of what each missing input would improve.

The most valuable thing to rehearse is B1, "Which part of this role would you be weakest at on day one?", including what to say to the two follow-ups that usually come after it.

The pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-3-denied-6e2bb135/stripe_product-operations-manager_interview_pack.md`.

If you'd like a live mock, I'll play the skeptical interviewer on B1, react to what you actually say, and then give you feedback.
I can also save a `tuesday-dossier.md` file listing the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Who will you meet in the final round? How many sessions, and is each one with your future manager, a peer, a partner from another team, or someone more senior? If the recruiter named focus areas or asked you to prepare something, like a presentation or a case, send that too. This changes how the questions are weighted.
2. Can you paste the job description and your CV, or a few paragraphs about your background? I can carry on without them, but they turn the scaffolds into answers built from your own experience.
3. If you allow web access, should I do a quick research pass (up to 6 searches and 2 page reads, covering Stripe's published values, its interview process and recent strategy) or a deeper one as well (up to 6 more searches and 2 more page reads, several more minutes)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — Final-round prep pack

- **Role:** Product Operations Manager
- **Company:** Stripe
- **Round:** final round; number of sessions and who runs them not yet known
- **Interviewer:** not named
- **Built from:** your one-line message only. No job description, no CV, and no web research (every search and fetch was refused by permissions). This is the worksheet edition: honest scaffolding, not story-mapped answers. The upgrade menu at the end says what each missing input turns into.

## How to use this pack

Two axes. **Personas** describe how a question is asked: who is across the table and in what register. **Types** describe what is being scored. Rehearse both: the same content lands differently from a friendly rapport-builder and a time-boxing stress interviewer.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behavior shows the company's published values, not generic virtue |
| EXP | Whether your claims about your own work survive scrutiny: what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework depth: company strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to something you gave me or to cited research; `[inferred]` is derived from a representative source; `[generic]` is a role-family pattern with no claim about Stripe or about you. Everything in this edition is `[generic]`, because nothing else was available.

Guidance is scaffolding, not a script. Where a cell says "pick a time…", choose a real one from your own work and tell it in your own words. Every scaffold ends with an honest branch, and taking it is a legitimate answer.

Start with the fit snapshot: fill in the evidence column yourself. Every bank below draws on what you put there.

## Fit snapshot (worksheet)

You gave no job description and no background, so the requirements below are typical of product operations roles in general, written as plain prose, and every evidence cell is blank for you to fill. Before the interview, write one real sentence of your own under each row: what you did, at the size you did it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches and programs across product, engineering, support and go-to-market teams (role-family pattern; no JD given) | none given | none | [generic] | discovery | Strong evidence looks like: a named launch or program, the teams involved, what you personally coordinated, and how you knew it was ready. Pick a launch or cross-team program where you held part of the coordination; it needs a date or milestone, at least two teams, and a part that was yours. If no such program comes to mind, say so plainly, then give the nearest thing your work does carry, or how you would run one |
| F2 | Turning customer and support signal into product input, with a loop that closes (role-family pattern; no JD given) | none given | none | [generic] | discovery | Strong evidence looks like: a source of signal (tickets, calls, sales notes), how it reached a product team, and what changed or did not. Pick a time feedback you gathered or routed changed a decision; it needs the signal, the route, and the outcome as you know it. If none comes to mind, say so plainly, then give the nearest thing you have done, or how you would build that loop |
| F3 | Defining and analyzing operational metrics, often with SQL or dashboards (role-family pattern; no JD given) | none given | none | [generic] | discovery | Strong evidence looks like: a metric you defined or tracked, how it was counted, and what it led someone to do. Pick a number you worked with closely; you need to be able to say how it was counted and which assumption behind it is weakest. If you do not know how it was counted, that is an honest answer. If you have not owned a metric, say so plainly, then give the analysis you have done, or how you would approach it |
| F4 | Designing processes and tooling that scale and that other people adopt (role-family pattern; no JD given) | none given | none | [generic] | discovery | Strong evidence looks like: a process before and after, who had to adopt it, and how you knew it worked. Pick a process you built or changed that someone else had to follow; it needs the problem it fixed and the adoption, smooth or not. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would design one |
| F5 | Influencing without authority and communicating clearly to leadership (role-family pattern; no JD given) | none given | none | [generic] | discovery | Strong evidence looks like: a recommendation you made to someone you did not manage, what you brought, and what happened. Pick a time you changed a decision you did not own; it needs a named stake and an outcome, including a no. If none comes to mind, say so plainly, then give the nearest thing you have done, or how you would approach it |
| F6 | Prioritizing competing requests under ambiguity (role-family pattern; no JD given) | none given | none | [generic] | discovery | Strong evidence looks like: more asks than capacity, the criteria you used, and who you said no to. Pick a time you had to choose between requests; it needs the trade-off and how you communicated it. If none comes to mind, say so plainly, then say how you would decide |
| F7 | Working knowledge of the product area the team supports (role-family pattern; no JD given) | none given | none | [generic] | discovery | Strong evidence looks like: hands-on use of, or work near, the product area this team owns, which you will only know once you have the JD or the recruiter's description. Pick what you have actually used or worked near. If nothing relevant, say so plainly and say how you would ramp |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch and program coordination | A1, H1, H3 |
| F2 Customer signal into product | A2, A3, E2 |
| F3 Operational metrics | A2, C1, C2, C3 |
| F4 Process design that scales | A1, A3, D3, E3 |
| F5 Influence and leadership communication | C3, E1, H1, H2 |
| F6 Prioritization under ambiguity | A3, D3 |
| F7 Product-area knowledge | B3, G2 |

## Persona table

No source tells this pack how Stripe's final round is structured: "final round" names a round but not its sessions or who runs them. So the weights below rest on the **Generic** fallback, with flat weights, said plainly. They are not this company's documented process. Each persona gets three questions so you never meet a style for the first time live.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan this, diagnose that | Even. Flat weight; a final round commonly includes a hiring-manager-style session, which is where cases tend to sit, but nothing here establishes one | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of gaps and motivation | Even. Flat weight; with no JD in hand the gap it will press is unknown, which makes B1 the safest rehearsal | Rehearse the single most predictable objection until it is boring; bridge only from what you actually did; name a ramp plan |
| Data-Driven Prober | Asks how numbers were counted, two levels deep | Even. Flat weight; product operations roles usually carry metrics | Know what you can and cannot say about how each number was counted; name your weakest assumption first |
| Pressure / Stress | Interrupts, time-boxes, plays devil's advocate | Even. Flat weight | Pause, restate, anchor in what you actually did, hold through two follow-ups before conceding anything real |
| Values / Behavioral | Scenario stories, often from outside the function | Even. Flat weight; no values page could be read, so these are themed on general prompts, not on Stripe's published values | "We" for context, "I" for your contribution; pick stories where the hard truth actually landed, and say so where it did not |
| Conversational / Rapport | Friendly openers that are still scored | Even. Flat weight | A pre-built 90-second arc; treat casual questions as scored; always have questions ready |
| Peer Evaluator | Seams between teams, credit, reciprocity | Even. Flat weight; product operations sits between teams by design | Lead with what you bring their team; propose seam principles, not knowledge of a seam you have not seen |

## Question banks

Question IDs skip the letter F so they never collide with fit-snapshot rows. **Highest-ROI prep in this pack: B1.**

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team launches a new feature to business customers in six weeks, and you own launch readiness. Sketch the plan. What do you need to know first?" | CASE | [generic] | Clarify first: who the customer is, what changes for support and sales, and what breaks if it goes wrong. Then the objective in one sentence. Then workstreams: support enablement, documentation, internal tooling, escalation path, go or no-go criteria with owners. Then metrics: a leading one in week one and a lagging one at a month. Then risks. Challenge one premise: is a single date right, or is a staged rollout safer. The question needs no claim about your past, so the guidance makes none | Launch readiness is the most common product operations case shape and covers F1 and F4 together; CASE because it scores structure, delivered live |
| A2 | "Support tickets about one product area rose 30% in two weeks. Diagnose it." | CASE | [generic] | Clarify the number before explaining it: raw tickets or tickets per active customer, and did the denominator move. Then timeline against releases, outages, pricing or policy changes. Segment: customer type, region, channel, ticket category. Rank two or three hypotheses and say what data would kill each. Close with what you would tell the product team today and what you would tell them after the analysis | The prober's "metric dropped, diagnose it" in an operations setting; covers F2 and F3; CASE because there is no right answer, only a defensible structure |
| A3 | "Sales and support send forty feature requests a month and product can take five. Design the intake and prioritization process." | CASE | [generic] | Clarify who decides today and what "take" means. Design: one intake channel, a minimum template so requests arrive comparable, de-duplication, criteria stated in advance such as customer impact, revenue at risk, effort, and strategic fit, a cadence, and a visible no with a reason sent back to the requester. Name the failure mode you are designing against: the loudest team wins. Say how you would know the process works in a quarter | Prioritization and feedback loops are the role's core trade-off; covers F2, F4 and F6; CASE because it scores process design live |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Before the interview, fill in the fit snapshot and pick the row where your honest sentence is thinnest; that is your answer, not a strength in disguise, which a Skeptic hears immediately. Structure: name it in one plain sentence. Then the nearest real thing you have done, only if it is true and at its real size; if there is none, say so. Then a ramp plan said as a plan, never as a past: what you would learn in the first 30 days and from whom. Follow-up one, "Why should we take that risk?": hold on the plan and the honest scope, add nothing. Follow-up two, "Isn't that core to the job?": concede specifically if it is, "It is, which is why I named it first", then return to the plan. Never fold into a different, safer weakness | A final round almost always tests self-assessment, and with no JD the objection cannot be predicted from a gap, so this open form is the one that arrives in some shape; JD because it scores fit against the job's requirements |
| B2 | "Why product operations, and why leave what you're doing now?" | EXP | [generic] | Two parts, in order: what pulls you toward this kind of work, said as something you have done or seen, and what is true about the move from where you are. Pick a moment that made you want this work; it needs a real event and what you took from it. If no single moment comes to mind, say so plainly and give the pattern instead. Keep the "why leave" part forward-facing and factual; never criticize the current employer | Motivation consistency is the Skeptic's main test and will be cross-checked against what you say in other sessions; EXP because it is about your own history |
| B3 | "How would you handle the parts of this role that sit outside your background?" | JD | [generic] | Use your weakest fit-snapshot row again, so your answer matches B1 if both get asked. Name the area, say what you have actually done near it if anything, and give a concrete way to learn it: the people, the documentation, the first small piece of work. If you do not yet know what this team's product area involves, say that you would want to learn it hands-on and how | Asked without assuming any gap, because no source establishes one; covers F7; JD because it scores ramp-readiness against the role |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a number you reported that someone challenged. How was it counted?" | EXP | [generic] | Pick a real number you reported; it needs the audience, the challenge, and what happened next. Then the defend-the-number beats, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part of the work was yours. Name the weakest assumption before you are asked. If you do not know how it was counted, say so plainly; that beats a reconstructed method you cannot repeat under a second question. If nothing was ever challenged, say so and pick a number you would expect to be | Probers go two levels below any figure; covers F3; EXP because it tests what you actually know about your own work |
| C2 | "Pick the operational metric you've tracked most closely. Which assumption behind it would you defend least?" | JD | [generic] | Pick one you actually worked with. Say what it measured, how it was counted to your knowledge, and the weakest assumption in your own words. If you have not tracked an operational metric, say so plainly, then describe the analysis you have done, or how you would choose and validate one | The weakest-assumption move is the credibility gain probers reward; covers F3; JD because metrics fluency is a typical stated requirement |
| C3 | "Leadership wants one number to tell them whether product operations is working. What do you propose, and what would you refuse to measure?" | CASE | [generic] | Push back gently on "one number" first. Propose a small set: one outcome such as time from customer signal to product decision, one quality check such as launch incidents or support contacts per launch, and one adoption measure for processes you own. Then what you would refuse: activity counts such as tickets routed or meetings held, because they reward motion. Name the weakest assumption in your own proposal before they do | A metrics design question in prober register; covers F3 and F5; CASE because it is a live problem with no past presupposed |

### D — Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then three beats inside a minute: what you have actually done that this role needs (one sentence each, at its true size), what an outside view brings, and a candid concession that an internal candidate knows the systems better. Hold on your one or two real strengths through the follow-up; do not inflate to win the comparison | A classic time-boxed composure test; JD because it scores fit; the concession is the move that keeps it credible |
| D2 | "Pick the result you're proudest of. How much of it was actually you?" | EXP | [generic] | Pick a real result. "We" for the team's context, "I" for exactly your part. State your share plainly, smaller rather than larger when unsure. If challenged, hold on your part as you described it; if they find something you overstated, concede it specifically and immediately. Never fold on the core of what you did just to restore harmony | Attribution probes exist to catch inflation, so precise candor is the rehearsal; EXP because it tests your own history |
| D3 | "Product says your process slows them down. Defend it or kill it, right now." | CASE | [generic] | Do not pick a side in the first sentence. Ask one clarifying question: which step, and slowed by how much. Then hold on what the process protects, such as launch quality or support readiness, and concede specific steps that could go. Offer a test: remove the step for one team for a month and watch the risk it was there to catch. Hold that structure through two interruptions | Product operations constantly negotiates process against speed; covers F4 and F6; CASE delivered under pressure |

### E — Values / Behavioral

Stripe's published values could not be read, so these questions are themed on general prompts, not on them. With web access, this bank is rebuilt around the official list by name.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they did not want to hear; it needs a named stake, what you brought as evidence, the moment of delivery, and what happened, including if they disagreed. If no such time comes to mind, say so plainly, then give the nearest thing your work carries, or how you would handle it | Leadership communication is central to the role; covers F5; VAL because it scores behavior, not skill |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a real trade-off; it needs the metric, the customer impact, and who you had to convince. Say what it cost. If no such trade-off comes to mind, say so plainly, then give the nearest thing you have done, or how you would weigh it | Product operations sits between customer signal and internal targets; covers F2; VAL because it scores judgment |
| E3 | "A teammate skips a step on the launch checklist to hit a date, and it works. What do you do?" | CASE | [generic] | Separate the outcome from the risk: it worked this time. Talk to the teammate first, privately, and ask why the step was skipped; it may be the wrong step. Then either fix the checklist or restate why the step matters, and say what you would record. The question needs no claim about your past, so the guidance makes none | A values question delivered as a live scenario; covers F4; CASE primary, VAL delivery |

### G — Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc, built before the interview: where you started, the two or three moves that matter for this role and why you made them, and why this role is the logical next step. Every beat is something you actually did. Stop at 90 seconds and let them pull | The biography question opens most sessions and is scored on economy; EXP because it previews what probers will dig into |
| G2 | "What's drawing you to Stripe specifically?" | CO | [generic] | This pack holds no facts about Stripe, because no research could run. Build your answer from Stripe's own published material that you have read yourself, and from your own use of its products if any. Two parts: one specific thing you have read or used, and why it connects to the work you want to do. If you have not used its products, say so and anchor on what you have read | Company-motivation questions are asked casually and scored seriously; covers F7; CO because it tests homework, and the honest gap here is the pack's, not yours |
| G3 | "Anything you'd like to ask me?" | CO | [generic] | Never "I think you've covered everything." Use two from the reverse questions below, picked for this interviewer's seat, and one follow-up on something they said earlier in the session | Rapport interviewers weight this slot as a preparation signal; CO because it shows homework |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Do not pretend to know the seam. Propose principles: one owner per decision, written agreements for hand-offs, disagreement raised early and directly, escalation as a joint step rather than a surprise. Ask them where it hurts today | Peers price what the hire adds to their load; covers F1 and F5; CASE because it is a live collaboration design |
| H2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick a real piece of cross-team work; say how credit was shared and what your part was, exactly. If you have no strong example, say so plainly and state the principle you would follow | Credit-sharing probes test partnership fit; covers F5; EXP because it asks about your own conduct |
| H3 | "What would you need from me in your first month, and what would I get from you?" | CASE | [generic] | Lead with what you would bring: listening sessions with their team, one small friction you would remove for them, regular written updates. Then a short, specific ask: access, context, one standing meeting. Keep the ask smaller than the offer | Reciprocity is the peer's real question; covers F1; CASE because it is a forward plan, not a past |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a great first 90 days look like, and what would make you think the hire wasn't working at six months?" | It asks for the actual scoring sheet and shows you plan to be measured |
| R2 | "Which product teams does this role support most, and where is the friction with operations today?" | It tells you the real job, and it turns the H-bank seam question back into a conversation |
| R3 | "How is product operations' impact measured here right now?" | It pairs with C3 and tells you whether the role is valued for outcomes or for activity |
| R4 | "What's a process the team retired recently, and why?" | It shows you care about removing process as much as adding it |
| R5 | "What decision would you most like this person to take off your plate?" | Best for a manager-type interviewer; it gets you their priorities in their own words |
| R6 | "How do you expect this role to change over the next year?" | It reads as long-term interest and surfaces any change in scope before you accept |
| R7 | "Is there anything in our conversation that gives you pause about my fit? I'd like the chance to address it." | It catches an objection while you are still in the room; use it only if the session has gone well enough to ask |

## Prohibited claims

No entries in this edition. You have not given any sentences about your past, so there is no wording that could be stretched, and no negative you have stated for the pack to hold. Every place an answer would need your history is a selection scaffold with an honest branch instead. Once you add a CV or background, this list is rebuilt from it: each sentence's stretched form (for example, "helped with" becoming "led") is listed here and kept out of every guidance cell.

## Sources

Provided documents: your message, "I have a final-round interview at Stripe for a Product Operations Manager role. Help me get ready."

Calls sent:

- Search: `Stripe operating principles`: refused
- Search: `Stripe interview process product operations onsite`: refused
- Search: `Stripe Product Operations Manager job`: refused
- Search: `Stripe 2026 annual letter strategy news`: refused
- Fetch: `https://stripe.com/jobs/culture`: refused

Research tier: L1 — searches 4 of 6, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Search and fetch both refused. Would have supplied the official values by name: a values cheat sheet if a values round were detected, and the E bank themed on them |
| 2. `Stripe interview process product operations` | unavailable | Search refused. Would have tried to establish the final round's sessions and the persona weights; the weights fall back to Generic, flat |
| 3. `Stripe strategy` / recent news | unavailable | Search refused. Would have grounded at least one CO or CASE question in current strategy; G2 stays generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | Search refused. Would have turned the seven `[generic]` fit rows into quoted `[inferred]` requirements and added answer slots to JD-tagged questions |

## Upgrade menu

- The job description text → the seven `[generic]` fit-snapshot rows become quoted `[grounded]` requirements, JD-tagged questions get answer slots on the posting's own lines, and the coverage table checks against the real list
- Your CV, or a few paragraphs about your background → the worksheet becomes a real fit snapshot, the selection scaffolds in banks A to H become story maps built from your own sentences, and the prohibited list gets real entries
- Who you are meeting in the final (manager, peer, cross-functional, senior leader) → persona weights reweighted from flat, and the banks resized to match
- If your final is several sessions, the schedule → a mini-pack per session, each with its own weights, bank and reverse questions
- The recruiter's prep email or any stated focus areas → coverage of those areas, and a build section for any presentation, case or take-home they announced
- Web access allowed → Stripe's published values by name, any documented loop structure, current-strategy CO and CASE questions, and a representative JD if you do not have the real one
- Interviewer names → a reading of each interviewer's public professional footprint and at least one reverse question tied to their path
- How much prep time you have → a prioritized prep schedule sized to it
- A tuesday-dossier.md from a role-underwriting pass, if you ever run one → an evidence-derived highest-ROI objection and a prohibited-claims guardrail; nothing in this pack needs it
