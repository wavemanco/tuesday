Reading done — now running the light research pass on Saltmarsh Games and the interviewer, then I'll build the pack.
Research is done; I'm writing the pack now.
I've built your prep pack for Friday, which is tomorrow. It's 22 practice questions with answer guidance, all built from what you told me, the JD, and Saltmarsh's own public pages.

**What the interview will look like.** Saltmarsh's careers page describes it, and it calls it the Outage Hour. It's a single 60-minute interview with the hiring manager. The first half is a role-play where you run the response to a simulated outage during a live event. The second half is a conversation about their three published values: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. There's no take-home. I've assumed Tobias is the hiring manager, because the page says this interview is with the hiring manager and his title fits the role.

**What I found that matters most:**
- **Project Larkspur.** Saltmarsh's news page announced in September 2026 that two of its titles will move to a season-pass model with one shared events calendar from February 2027. Their per-title event teams are being merged into one live-ops group. I only saw this as a search result, not the full article.
- **Your highest-ROI prep is the season-pass question (C1).** You told me you've never worked on a game with in-app purchases, and that's exactly the direction they're heading. The pack walks you through it:
  - Say the gap plainly, in your own words.
  - Point to the two years you ran the weekly content-drop calendar.
  - Give a plan for getting up to speed.
  - Hold that answer through two harder follow-ups.
- **Tobias was a QA lead at a console studio before this job,** according to his GDC 2026 talk listing. The talk is called "Patch Notes Are a Promise," and its argument is that a live team is judged by whether its patch notes match what actually shipped. That makes your release checklist, which your QA team still uses, your strongest common ground with him. It also means overclaiming will cost you more with him than with most interviewers.

**The rest of the pack:**
- A table matching each JD requirement to what you've told me, with how to talk about each gap.
- Five practice runs of the outage role-play.
- A story or story-picking prompt for each value.
- Six questions to ask him.
- A list of claims not to make, such as leading a team or running events across two titles.

If you tell me how many hours you have tonight, I'll add a prioritized prep schedule.

Files are in:
/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-canned-6b21ec32
- saltmarsh-games_live-operations-producer_interview_pack.md

If you'd like to practise out loud, I can play the skeptical interviewer on C1, the season-pass question.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The pack treats him as the hiring manager. Saltmarsh's interviewing page says the 60-minute interview is with the hiring manager, and his title fits this role.
**Format:** Saltmarsh's interviewing page calls it the Outage Hour: "a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."

---

## How to use this pack

- **Personas** describe how a question gets asked. **Types** describe what it scores. One question can come in under any persona.
- **Type key:**
  - **CASE**: a live problem from the role. Scores structure and reasoning. This is the first half of the Outage Hour.
  - **VAL**: values. Scores whether your past behaviour shows Saltmarsh's three published values. This is the second half.
  - **JD**: a stated responsibility or requirement. Can you do the listed job, gaps included?
  - **EXP**: a deep-dive on your experience. Does what you said hold up, and what was actually yours?
  - **CO**: company knowledge. Mostly about Project Larkspur.
- **Provenance labels:** `[grounded]` is traceable to your message, the JD, or a source listed under Sources. `[inferred]` is derived from one of those, and the derivation is named. `[generic]` is a role-family pattern with no claim about Saltmarsh or about you.
- **An answer slot** is an instruction for the interview, not a question to answer here. It has two branches. If you did the thing, say how, in your own words. If you didn't, or it wasn't yours, say so plainly.
- **Guidance is scaffolding, not a script.** Rehearse the shape in your own words.
- **The highest-ROI prep is C1**, the season-pass objection. Rehearse it until it bores you. The tabletop bank (A) comes next.

---

## Fit snapshot

Every sentence quoted from you below comes from your message, and everything else the pack says about your past draws on these quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material shows four years as an associate producer and two years of running weekly content drops. It doesn't show whether the title ran as a live service for all four years. Answer slot: the JD's "3+ years producing live-service" line makes a probe on the earlier two years likely. If the title was being updated live before you took over the calendar, say what your part in that was, in your own words. If it wasn't, or your work then was something else, say so plainly and stay with the two years on the calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. But there's nothing behind the line he can inspect, so expect a probe. Lead in the quote's own terms: weekly, the main title, the last two years. A cadence and a duration said plainly beat any adjective |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says weekly content drops for one title, not a live-events calendar across two, and your words should stay there. Answer slot: the JD's "live-events" and "two of our mobile titles" make a probe on events and scale likely. If any of those drops were time-limited events, say which and what you planned for them, in your own words. If they weren't events, say so plainly and describe how you ran the weekly cadence. Going from one title to two is a plan you can describe, not something you've done |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | Running the calendar touches coordination but doesn't show whether it meant working across those four teams. Answer slot: if you worked with design, art, engineering or community to get a drop out, say which teams and what you did, in your own words. If you didn't, say so plainly and say how you'd set that coordination up. Coordinating isn't leading, and the JD doesn't ask for leadership. If leadership comes up, the words are yours: "I haven't led a team." Don't let a probe on one turn into a claim about the other |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting numbers isn't owning a review or choosing its KPIs, and your words should stay at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "own" makes a probe on authorship likely. If you prepared those numbers or chose what went into the presentation, say which part was yours. If they came to you ready-made, say so plainly and stay with presenting them. How you would run a post-event review is a plan, said as a plan |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote speaks to retention metrics directly. There's nothing behind it to inspect, so expect a definitions probe. Answer slot: if you know which retention measures those were and how they were counted, say so in your own words. If you don't know how they were counted, say that plainly. It's an honest answer and it beats a guessed definition |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap. Lead in the quote's terms: you wrote it, and your QA team still uses it. Answer slot: the JD's "manage" makes a probe on upkeep likely. If you've kept it updated since, say how. If you haven't, or the updates weren't yours, say so plainly and stay with having written it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote already reaches this requirement in other terms. When writing comes up, name the document: "I wrote the release checklist our QA team still uses." Then stop, and let Tobias draw the inference. The live test is the tabletop's player post (E2) |
| F9 | Season-pass model. Saltmarsh's news page, seen only as a search result: Project Larkspur moves two titles to a season-pass model from February 2027. Not in the JD | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You've said it, so the words are yours: "I haven't worked on a game with in-app purchases." Then how you'd get up to speed, said as a plan and never as a past. Don't offer the content drops as a monetization story, and don't add anything to make the gap feel smaller |

---

## Reading the interviewer

Public professional footprint only, from one source: the GDC 2026 talk listing returned by the search.

| Item | What the source says | Provenance |
|---|---|---|
| Career pattern | Head of Live Operations at Saltmarsh Games, "previously a QA lead at a console studio" | [grounded] |
| Self-described position | Talk title "Patch Notes Are a Promise". His argument: "a live team is judged by how often its patch notes describe what actually shipped" | [grounded] |

**Practical implications** (the pack's reading, `[inferred]` from the two rows above):

1. **Release discipline is his home ground.** Expect him to push hardest on the release checklist (A3, D3, E1). That's also where your evidence is strongest (F7).
2. **In the tabletop, say only what's confirmed.** His talk and Saltmarsh's value "Ship the Patch Not the Promise" both reward player messages that don't run ahead of the fix. E2 rehearses exactly that.
3. **Overclaiming will cost you more with him than with most interviewers.** His thesis is that words should match what shipped. An answer that keeps to what you did is the same discipline, applied to yourself.
4. **Mirror opportunity, shared vocabulary.** The release checklist is common ground between a former QA lead and the F7 line: "Wrote the release checklist our QA team still uses." That's shared vocabulary, not a shared career jump. Your material shows no QA-to-live-ops move, so don't offer one.

---

## Persona table

The loop is established by Saltmarsh's interviewing page: one session, a tabletop, then values. Weights start from the hiring-manager prior (Case and Skeptic), get adjusted for that two-part format, then for Tobias's QA background and talk.

| Persona | How it shows up on Friday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The simulated outage itself: he narrates, you run it | Highest. The first half of the hour is a live-incident tabletop, per the interviewing page | Clarify before you structure. Say the structure out loud: scope, stabilize, communicate, players, record. Take one premise and challenge it respectfully |
| B. Values / Behavioral | The second half: the three published values | High. The interviewing page names a values conversation, and the values page names three values | One story or selection scaffold per value (cheat sheet below). Use "we" for context and "I" for what was yours |
| C. Skeptic | Probing gaps: season pass, two titles, associate-to-producer step | Mid. The hiring-manager prior, raised by F9, F3 and F1 | Rehearse C1 until it bores you. Bridge only from what you said, name the limit plainly, then give a ramp plan |
| D. Data-Driven Prober | Retention definitions, checklist contents, post-event KPIs | Mid. The JD names retention metrics and KPIs, and his QA background points at checklist detail | Know what you can and can't say about how your numbers were counted. Say "I don't know how it was counted" when that's true |
| E. Pressure | Time pressure inside the tabletop, plus the "how much was actually you" probe | Low. A simulated outage is time-boxed by nature, but nothing documents a stress-style interviewer | Pause, restate the question, then hold your position through two follow-ups before you concede anything real |
| F. Conversational | Opener and close: journey, why Saltmarsh | Low. Opening minutes only, but still scored | Have a 90-second journey arc ready. Never answer "any questions?" with "I think you've covered it" |
| G. Peer Evaluator | Cross-team conflict and credit questions, coming from the HM | Low. No peer is in the room, but the JD's coordination line brings these up | Talk about principles for handling the seams between teams, and give examples of what you'd bring to each team, not only what you'd need |

---

## Question banks

### A. Case / Strategist: the tabletop (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event and event rewards have stopped granting for a chunk of players. Walk me through your first fifteen minutes." | CASE | [inferred] | Clarify first: which title, which platforms, how many players, since when, and whether it's still happening. Then stabilize: get engineering on-call and QA looking, and decide whether to pause the event. Then communicate: one short player post saying what you know and nothing more. Then players: start thinking about a make-good now, not later. Then record: open the incident log so the review has a timeline. Say the five words of the structure out loud before you fill them in. This question needs no claim about your past, and the guidance makes none | The interviewing page names exactly this format, so this is the likeliest opening. `[inferred]` because the scenario details are the pack's, built on that page's format |
| A2 | "Engineering says the fix is four hours out. The event ends in two. Do you extend it?" | CASE | [inferred] | Work the trade-off out loud: who loses out if the event ends on time (players who couldn't earn rewards) and who loses if it runs on (the next calendar slot, and the team's weekend). The values page says "when the calendar and the players disagree, the players win", so name that as the principle you're weighing. Then make a call. A recommendation with its cost named beats "it depends" | A typical follow-up that forces a decision. It tests whether you'll commit under uncertainty |
| A3 | "The fix is ready. What has to be true before it goes out mid-event?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Start with the quote: you wrote the release checklist your QA team still uses. Describe your own checklist only from memory, in your own words. Answer slot: the JD's "manage the release checklist with QA" makes a probe on fast or emergency releases likely. If your checklist had a path for a mid-cycle fix, say how it worked. If it didn't, say so plainly and say what you'd add for a hotfix mid-event: QA sign-off on the fix, a regression check on the live event, a rollback plan, and the player post updated only once the fix is confirmed live | Covers the JD's checklist line inside the tabletop, on F7, your strongest row. It's also Tobias's home ground |
| A4 | "The event's over. How do you run the post-event review for this incident?" | CASE | [generic] | Make it blameless and keep it on a timeline: what happened, when it was spotted, when players were told, when it was fixed. Then what went well, what didn't, and two or three actions, each with an owner and a date. Close by checking the player-facing messages against what actually happened. This question needs no claim about your past, and the guidance makes none | The JD's "own the post-event review" asked live. F5 shows presenting rather than owning, so the pack rehearses the method as a plan |
| A5 | "From February both titles run on one shared events calendar. How would you plan its first quarter?" | CO | [grounded] | Clarify: do the two titles' audiences overlap, are art and engineering shared between them, and what does the season pass require? Then approach: rules for keeping the two titles' events from colliding, buffers around releases, and a review slot after every event. Then metrics: retention per title, measured against each title's own baseline. If the season pass comes up, the honest line is the one from F9: "I haven't worked on a game with in-app purchases." Say it once and move to what you'd ask | Project Larkspur is current strategy, per the news-page search result. This is the strategy-grounded question most candidates won't have prepared. `[grounded]` on that search result, which is named in Sources |

### B. Values / Behavioral: the values conversation (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] | Selection scaffold for Players Before Plans. Pick a time a planned drop or date ran into what players needed or were saying. A good story has a named stake, what you recommended, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme is the value's own definition on the values page. None of your quoted sentences carries this story, so it's a scaffold |
| B2 | "When have you had to say something wasn't ready?" | VAL | [grounded] | Selection scaffold for Ship the Patch Not the Promise. Pick a time you said a drop, feature or date wasn't ready, to players or to the studio. It needs what you said, who heard it, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own definition, which also echoes Tobias's talk. Expect him to lean on this one |
| B3 | "What have you left better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F7, using only the beats the quote states: you wrote the release checklist, and your QA team still uses it. Tell those two beats in your own words. Answer slot: the value says every release "leaves the codebase and the checklist better", so expect a probe on how it changed over time. If you revised it after releases, say what changed and why, in your own words. If it stayed as written, or the revisions weren't yours, say so plainly and stay with having written it | Leave the Build Greener names the checklist by word, and F7 is the one line of yours that speaks to it. It may be your best values moment |
| B4 | "Tell me about a time you had to tell leadership something they didn't want to hear." | VAL | [grounded] | Selection scaffold, tied to Ship the Patch Not the Promise. Pick a time you brought unwelcome news upward, with what you said and what happened next. Your monthly retention presentations are one place to look, if one of them qualifies. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's standard stem, in Saltmarsh's terms. It's a scaffold because no quote says any presentation carried bad news |

### C. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our titles are moving to a season pass. What experience do you have with monetized live events?" | CO | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | **Highest-ROI rehearsal in the pack.** Name the limit before he has to dig for it: "I haven't worked on a game with in-app purchases." Then say what you do bring, at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Then the ramp, as a plan: learn how the season pass is paced and tiered, sit with whoever owns monetization, and read past event data before your first calendar. First follow-up, "So you'd be learning on our players?": hold. The calendar is what you've run, and the monetization side is new, so say how you'd reduce the risk in your first weeks. Second follow-up, "Why take that risk?": don't fold, and don't inflate. Concede the gap again in the same words, then return to the calendar and the plan. Don't claim the content drops resemble a season pass | F9 against Larkspur is the gap this candidate is most likely to be pressed on. It's the move the studio announced, and you've said plainly you haven't done it. CO because it's about the company's strategy, not a JD line |
| C2 | "This role runs two titles. You've run one. What changes going from one to two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Accept the premise at the quote's scope: your calendar was for the main title. Then reason out loud about what two titles add: competition for shared art and engineering time, events colliding, two different player communities, and twice the reviews. Close with one principle for each. Describing how two titles would work is planning, not experience | Covers the JD's two-titles line against F3's transferability gap. The premise matches the quote, so it can be asked as written |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Name one real gap; don't dodge with a strength. F5 is the honest pick: your material shows presenting the numbers, not owning a post-event review. Words at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you prepared any of those numbers, say which part. If you didn't, say so. Then give a 30-day plan to own a review, as a plan | The standard Skeptic stem. Choosing F5 here keeps C1's gap from being spent twice |
| C4 | "Your title's been associate producer. This is a producer role on live-service titles. What makes you ready?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Name both lines as they are: four years as an associate producer, and for the last two, the weekly content-drop calendar for the main title. Answer slot: the JD's "3+ years producing live-service" makes a probe on the earlier years likely. If that work was live-service producing, say what was yours. If it wasn't, say so plainly and rest your case on the two years of the calendar. Don't claim the producer title or a team you didn't lead | Covers the JD's years requirement on F1, and the step up in title the role implies |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented monthly retention numbers. Which measures were they, and how were they defined?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start with the quote: monthly retention numbers, presented to the studio head. Answer slot: if you know which measures they were and how they were counted, say so in your own words, and name the assumption behind them you'd defend least. If you didn't define them or don't know how they were counted, say so plainly. "I presented them; the definitions were set before me" is a complete answer if it's true | Your presentations are the one place your record touches retention, so they draw the prober. Being straight about how the numbers were counted is what this question scores |
| D2 | "Which retention measures would you put in a post-event review, and why?" | JD | [generic] | Answer as a plan. Name the event's goal before you name a metric. Then compare players who took part against those who didn't, and set it against the title's normal baseline. Cover short-term return and whether it lasted after the event ended. Then the caveat: players who join events were probably more engaged already, so take-up alone doesn't prove the event caused anything. This question needs no claim about your past, and the guidance makes none | Covers the JD's retention-metrics and KPI lines. It's a JD question rather than a CASE because it tests the stated requirement |
| D3 | "Your QA team still uses your checklist. What's on it, and what has it caught?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Describe the checklist's sections from memory, in your own words. Answer slot: the question assumes it caught something. If a checklist item stopped a bad release, say what, in your own words. If you don't know of one, say so plainly and stay with what it covers and the fact that QA still uses it | F7 is a line a former QA lead will open up and check. Rehearsing it from memory keeps it accurate |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: you wrote it. Pause, then say it plainly. Answer slot: if other people contributed parts or reviewed it, say who and which parts, in your own words. If no one did, say so. If he pushes a second time, the answer stays the same. Conceding detail you're unsure of is fine, but don't give up the core claim just to ease the moment | The standard attribution stem, aimed at your strongest line. Holding steady here shows you'll hold steady on the others |
| E2 | "Stop. The community manager has already posted that the fix is live. It isn't. Dictate the correction, now." | JD | [inferred] | Time-boxed: say the post out loud in two or three sentences. What's actually happening, that the earlier post was wrong, and when players will hear more. Make no promise of a fix time you don't have. Then one line on what you'd do with the community manager afterwards: what to fix in the process, not who to blame | Tests the JD's "clear written communication" live, since there's no take-home. Ship the Patch Not the Promise and Tobias's talk both point here |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | 90 seconds, four beats, each one only what its quote says. Four years as an associate producer at a puzzle-game studio. The last two running the weekly content-drop calendar for the main title. You wrote the release checklist your QA team still uses. You presented the monthly retention numbers to the studio head. End with why live ops, in your own words | The likely opener. Casual in tone, but it's scored, and it sets the frame for the whole hour |
| F2 | "Why Saltmarsh, and why now?" | CO | [grounded] | Say why in your own words, and tie it to something specific. Two options: Project Larkspur's single shared calendar, or Saltmarsh's three published values, one of which you can name. Don't recite the values list. Pick one and say why it matters to you | A motivation question with research behind it scores higher than a generic one. Both sources are listed under Sources |

### G. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Engineering says your event date can't happen. Art says it can. How do you handle it?" | JD | [generic] | Separate the facts from the positions: what exactly blocks engineering, and is it scope or time? Bring both teams into one conversation and lay out the options: move the date, cut scope, or stage the release. Then decide, or take it to whoever owns the decision, with the trade-off written down. This question needs no claim about your past, and the guidance makes none | Covers the JD's coordination line (F4 is a discovery gap). JD content, delivered as a case |
| G2 | "How do you handle credit when an update lands well and five teams worked on it?" | VAL | [generic] | Selection scaffold. Pick a time a drop went well and you made sure the teams behind it got the credit. Say what you did, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Peer stem that the JD's coordination line makes likely |

### Requirement coverage

| JD line | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | C2, A5 |
| "coordinate design, art, engineering and community teams on each update" | G1, A1, E2 |
| "own the post-event review and the KPIs it reports" | D2, A4, C3 |
| "manage the release checklist with QA" | A3, D3, E1, B3 |
| "3+ years producing live-service games or apps" | C4, F1 |
| "experience running a content calendar" | C2, F1 |
| "comfortable with player-retention metrics" | D2, D1 |
| "clear written communication" | E2 |

---

## Values cheat sheet

Values-style round detected: Saltmarsh's interviewing page names a values conversation. Value names and definitions come from the fetched values page.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players' experience conflict, the players' experience wins | Selection scaffold (B1): a time a planned drop or date ran into what players needed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it |
| Ship the Patch Not the Promise | Only announce what's actually built | Selection scaffold (B2, B4): a time you said something wasn't ready, or brought unwelcome news upward. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it |
| Leave the Build Greener | Every release should leave the code and the checklist better than before | F7: "Wrote the release checklist our QA team still uses" (B3) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from QA lead to running live ops. What from QA do you think live teams still under-use?" | It's tied to his own path, and it opens the release-discipline ground where F7 sits, as a conversation rather than a pitch |
| R2 | "In your GDC talk you said a live team is judged by how often its patch notes describe what actually shipped. How do you track that here?" | It shows you researched him, not just the company, and it invites him to talk about his own thesis |
| R3 | "With the event teams merging into one live-ops group under Larkspur, where does this role sit, and which title would I start on?" | It's current and specific, and it tells you what the job actually is |
| R4 | "What does a post-event review look like here today, and which KPI does it lead with?" | It's the JD line you'd own, and the answer tells you what you'd be measured on |
| R5 | "What would make the first shared calendar in February a success for you?" | It gives you his definition of success for the role's first big milestone |
| R6 | "For someone new to season-pass pacing, what's the best way to get up to speed here, and who would I learn from?" | It's honest diligence on F9. It turns the gap into a plan he helps shape instead of a weakness he finds |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated (F4) | "I haven't led a team." Coordinating can be discussed only through F4's answer slot |
| Has worked on a monetized or in-app-purchase game, including season passes | A negative you stated (F9) | "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar across multiple titles | Inflated form of F3 | F3's quote at its own scope. Pack's observation: your material says one title's weekly content drops. C2's discussion of two titles is planning, not experience |
| Owned post-event reviews or set KPIs | Inflated form of F5 | F5's quote at its own scope: "I presented the monthly retention numbers to the studio head." C3 and D1 keep their slots inside the presenting |
| Four years producing a live-service game | Inflated form of F1 | F1's quotes at their own scope. Pack's observation: your material shows two years on the calendar. C4's slot stays inside the earlier years' work |
| Owned the release or QA process | Inflated form of F7 | F7's quote at its own scope: "Wrote the release checklist our QA team still uses" |

---

## Sources

**Provided documents:** the JD text and your background, both pasted in your message.

**Searches sent:**
1. `Saltmarsh Games values` → https://saltmarshgames.com/values
2. `Saltmarsh Games interview process producer` → https://saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile news 2026` → https://saltmarshgames.com/news/project-larkspur. Seen as a search snippet only, not fetched, because the fetch budget went on targets 1 and 2
4. `Tobias Wrenfield Saltmarsh Games` → https://talks.gdconf.example/2026/patch-notes-are-a-promise. Seen as a search snippet only

**Pages fetched:** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing

No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | The values cheat sheet, B1 to B4 and F2. Three values by name, from the fetched page |
| 2. `Saltmarsh Games interview process producer` | yes | Loop established: the Outage Hour (tabletop, then values). Persona weights, bank A and bank B follow from it |
| 3. `Saltmarsh Games` strategy / recent news | yes | Project Larkspur: A5, C1, F9, R3, R5. Snippet only, not fetched |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer, R1, R2, and the Prober weight. Snippet only, not fetched |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- How many hours you have before Friday → a prep triage schedule, sized to your time
- Confirmation that Tobias is the hiring manager, or the recruiter's prep note → if he isn't, the persona weights change; the note may also confirm the Outage Hour format
- Your answers to the answer slots in F1, F3, F4, F5 and F7 → firmer guidance in A3, B3, C2, C3, C4, D1, D3 and G1, with slots turned into mapped stories where your answers carry them
- Your CV → more of your own sentences to draw on, so B1, B2, B4 and G2 can move from scaffolds to mapped stories
- Your own working copy of the release checklist, or a retention deck you presented (for your prep only, nothing confidential taken into the room) → F7 and F6 move from `medium` to `high` confidence, and D1 and D3 can quote real detail
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → fetch the Larkspur announcement and Tobias's talk page in full, look for loop reports from other candidates, and check recent org changes. Sharpens A5, C1 and R1 to R3
- A `tuesday-dossier.md` from an earlier underwriting of this role → evidence-graded rows and a named objection in place of the pack's inferred one. Not needed for this pack
