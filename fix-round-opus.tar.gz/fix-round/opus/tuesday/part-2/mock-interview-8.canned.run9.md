I've built your prep pack for all three rounds on 21 November: AshgroveCreditUnion_member-experience-lead_interview_pack.md

It treats the day as three separate rounds, and each one gets its own questions, likely interviewer styles and questions for you to ask back. Everything rests on the documents you gave me, and I ran no web searches. Your values text was copied this morning, the strategy brief is from July and the recruiter's email sets out the rounds, so a search wouldn't have changed anything.

- **Where they'll probe:** I lined up each requirement in the job description against your own four sentences. Your two stated gaps, the contact centre and presenting to senior leaders, get plain honest wording plus a plan. Four other points depend on facts only you know: whether your complaints were regulated, what the monthly spreadsheet tracks, whether it's in Excel, and any digital work. Those have "answer slots" with an honest answer for either case.
- **Your most important rehearsal:** question E1 in the round with the Head of Member Services: "You haven't worked in a contact centre — why should I take that risk?" It's scripted as admit it first, then what you bring, then your plan, with two likely follow-ups.
- **The panel round:** there's a sheet for the four values, plus a structure for the 20-minute case: a 20-minute shape, three positions you could take (each with its weak point) and the mistakes to avoid. Don't state complaint deadlines from memory; ask which rules apply. The hubs move from eight branches to five, and the brief doesn't say whose branches change. Since the panel is two branch managers, the pack keeps that topic careful.
- **Claims to avoid:** there's a list of claims to avoid saying because they stretch what you've told me. For example, "handled complaints" when you said you handled the complaints log, or "coached supervisors" when you trained new tellers.

The last section lists what would make the pack sharper, such as your CV or the interviewers' names once they're assigned.

I can play the sceptical Head of Member Services on E1, with follow-ups that react to what you actually say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AshgroveCreditUnion_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date:** all three rounds on 21 November 2026 (pack built 12 November 2026)
**Mode:** loop. The recruiter's email sets out three rounds, so there is one shared fit snapshot, then a mini-pack for each round with its own persona weights, question bank and reverse questions.

| Round | Length | Who | What it holds (recruiter's words) |
|---|---|---|---|
| R1 | 30 min | The recruiter | "30 minutes with me" |
| R2 | 45 min | Head of Member Services, your future manager | "mostly behavioural" |
| R3 | 60 min | Panel of two branch managers | "a 20-minute case on a complaint escalation"; "the values round — they score against the four values" |

Interviewer names have not been assigned yet, so this pack has no section on reading individual interviewers.

---

## How to use this pack

- **Personas** describe how a question will be asked (friendly, sceptical, under time pressure). **Types** describe what is being scored:
  - **VAL**: whether your past behaviour shows Ashgrove's four published values
  - **EXP**: whether what you say about your experience holds up when probed, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: whether you know Ashgrove's strategy and can think at its level
  - **CASE**: how you structure and reason through a live problem
- **Quotes in double quotation marks are your own sentences** from your message. Every claim the pack makes about your past rests on one of them. If a guidance cell says more than the quote does, trust the quote.
- **Answer slots** are spots where the interviewer is likely to probe something your material doesn't settle. Each has two honest branches. Answer whichever is true. Both are fine answers.
- **Guidance is scaffolding, not a script.** Say it in your own words.
- Question IDs are letters by persona (A, B, C in R1; D, E, G, H in R2; J, K, L, M in R3). Fit-snapshot rows are F1 to F9.

---

## Fit snapshot (shared across all three rounds)

Your four sentences, used throughout:

- Q1: "6 years in retail banking, the last 3 as a branch supervisor."
- Q2: "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- Q3: "I built the monthly complaints spreadsheet our regional manager uses."
- Q4: "Never worked in a contact centre, and I've never presented to anyone above regional level."

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence meets the requirement in different words. Say it plainly: "I've spent six years in retail banking, the last three as a branch supervisor." Then let the interviewer connect it to the requirement. Don't relabel the job as "customer operations" |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says *formal* complaints log. It doesn't say whether those complaints fell under a regulator's rules, or whether you dealt with the complaints yourself or kept the log. Answer slot: if those complaints came under a regulator's complaint rules, say which rules and what you did to meet them, in your own words. If you don't know, or they didn't, say so plainly and describe the log |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence covers one branch's log, not a process across branches, and your words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" line makes a probe on which steps of a complaint were yours likely. If any steps from first contact to closure were yours, say which ones, in your own words. If your part was the log, say so plainly and describe it |
| F4 | "...and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this gap, and no wording closes it. Words: "I haven't worked in a contact centre." Then how you'd learn it, as a plan, never as something you've done. E1 is the full rehearsal |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | A monthly complaints spreadsheet is close to this requirement. Your material doesn't say whether it tracks volumes or resolution times. Answer slot: if it counts either, say what it counts and where the data comes from, in your own words. If it tracks other things, say what. If you don't know how a figure in it is counted, say so |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | "Spreadsheet" doesn't say which tool. Answer slot: if you built it in Excel, say so, and name only the features you actually used. If it was another tool, name it plainly |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." and "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Training new tellers on a script is not coaching supervisors, and the bridge shouldn't stretch it into that. Words: "I trained new tellers on our escalation script, and for the last three years I've been a branch supervisor myself." Answer slot: if you've helped another supervisor with an escalation, say how and what your part was. If not, say so plainly and stay with the teller training |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital work either way. Answer slot: if you've given input to a digital or self-service change, say what it was and what your part was, in your own words. If not, say so plainly, then say what you'd bring to the digital team from complaints, as a plan |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this gap. Words: "I haven't presented above regional level." Then a preparation plan, said as a plan. E2 is the rehearsal |

**What the snapshot shows:** F1 is a wording job. F2, F5, F6 and F8 depend on facts only you know, so check your answer slots before the 21st. F3 and F7 are real adjacent experience with clear limits. F4 and F9 are the two gaps you've named, and they are where the sceptical questions will land.

---

## Grounding brief: Ashgrove's strategy as you gave it

Source: the July 2026 strategy brief the recruiter sent, as you summarised it, plus the JD and the values page. You don't need to correct anyone. Just use these terms so you sound current.

| Brief says | What it likely means for your rounds | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | Lines up with the JD's "self-service journeys" line, so expect a question on how complaints inform digital (G2). A channel shift is also something members complain about. | [grounded] the brief and the JD; [inferred] the reading |
| Consolidate eight branches into five hubs over 2027 | Your R3 panel is two branch managers, and the brief doesn't say whose branches change. Talk about consolidation with care: never as a closure count, always through what it means for members and staff (M2). | [grounded] the brief and the recruiter's email; [inferred] the reading |
| Launch a small-business lending product in Q1 2027 | A new product means new kinds of complaints. This is a good reverse question for R2. | [grounded] the brief; [inferred] the reading |
| Main competitive pressure: app-only banks | Gives you a "why member experience matters" line: branches and plain-spoken service are what an app-only bank lacks, and complaints are where that gets tested. Present it as your reading, not as Ashgrove's stated position. | [grounded] the brief; [inferred] the reading |
| Values page (copied 12 November 2026): Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | The R3 panel scores against these four, so use the exact names. | [grounded] the values page and the recruiter's email |

---

## Graded deliverable: the 20-minute complaint escalation case (R3)

The recruiter announced it but didn't say what the case is about, so the practice case in K1 is invented for rehearsal. The structure below works for any escalation case.

**Grounded facts to build on**

- The JD: "Own the member complaints process end to end across branches and the contact centre"; "coach branch supervisors on escalations"; "report monthly on complaint volumes and resolution times"; "work with digital teams on self-service journeys".
- The four values, which the panel scores. Name them where they come up naturally, not as a checklist.
- About you, from F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Escalation routes are something you've taught. Say it only at that scope.
- About you, from F4: "Never worked in a contact centre, and I've never presented to anyone above regional level." If the case runs through the contact centre, ask how their side works instead of assuming.

**A 20-minute shape:** clarify (2 minutes), member first (5), fix the case (5), find the root cause (5), close (3).

**Clarifying questions worth asking out loud:** Which complaint rules and internal deadlines apply? (Don't state a deadline from memory. Ask.) What has the member been told so far? Who owns the case right now? Is this a one-off or one of several?

**Three theses you could defend, each with its concession**

| Thesis | Concession you name yourself |
|---|---|
| Resolve the member's problem and tell them plainly, before any process review. Members First, Always and Plain Words decide the order | Speed has limits. If the fix needs someone else's authority, the member gets an honest timeline rather than a promise |
| The branch supervisor stays the owner, with your support. You coach rather than take over (Own the Fix, and the JD's coaching line) | If the case is past a complaint deadline, or already at the CEO, you may need to take it centrally and explain why to the supervisor |
| Treat the escalation as data: is it one case or a pattern? Check the log, then put the pattern in the monthly report and, if it began in a digital journey, take it to the digital team | The member doesn't wait for the analysis. Pattern work runs after the member is sorted, not instead of it |

**How to stand out from the obvious answer:** Most prepared candidates will say "apologise, escalate, resolve, follow up." Use that as your skeleton to show you know the basics. Then do two things it skips: separate *this member's outcome* from *the process fix*, and name who keeps hold of each. That second step is Own the Fix applied, and it's what the panel is scoring.

**The anti-pick:** Don't promise the member a specific outcome or compensation before you have the facts, and don't go around the branch supervisor to look decisive. Both are tempting under time pressure, and the branch managers on the panel will notice the second.

**Close:** The recruiter named no required close. Since the panel scores values, end with one sentence on what changes so the next member doesn't need to escalate, and stop there.

---

## R1: Recruiter, 30 minutes

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers, "walk me through", "why us" | High. A recruiter screen is a conversation, and a 30-minute slot leaves little room for depth | A rehearsed 90-second arc (A1). Treat casual questions as scored |
| Skeptic (light) | Checks you against the JD's stated requirements | Medium. Recruiters often check the requirements before passing you on, and F2 and F4 are the obvious ones | Short, honest answers. Save the full defence for R2 |
| Values / Behavioural (light) | "Which value speaks to you?" | Low. The recruiter told you the panel scores values, so values may come up early | One value, by name, with your own reason |
| Case, Prober, Pressure, Peer | Unlikely here | Low. These belong to R2 and R3, where the email puts behavioural questions and the case | Rehearsed in R2 and R3 |

### Question bank: Conversational (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc using only these beats: six years in retail banking; the last three as a branch supervisor; the branch's formal complaints log; training new tellers on your escalation script; the monthly complaints spreadsheet your regional manager uses. End with why this role, in your own words. Don't add volumes, team sizes or outcomes you haven't stated | Recruiters score openers for economy. EXP because it previews the rows R2 and R3 will probe (F1, F2, F5, F7) |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Two parts. First, your own reason, in your own words: if it's about credit unions, say why; if it's mainly the role, say so plainly. Second, one thing from Ashgrove's own material, by name, such as "Members First, Always" or the move to digital channels by 2028, and why it connects to complaints work. Don't claim a long-standing interest in credit unions unless it's true | Tests whether your motivation stays consistent across rounds. CO because it rewards having read the values and the brief |
| A3 | "Why move on from branch supervision now?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start from three years as a supervisor. Answer slot: if the complaints work is what draws you, say what about it, using the log and spreadsheet you've already named. If something else is, say that. Nothing negative about your current employer | Recruiters listen for push versus pull. JD because the answer has to land on this role |
| A4 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name two items from the July brief in its own terms, for example 40% of member service on digital channels by 2028 and eight branches becoming five hubs over 2027. Connect one to the role as your reading ("I'd expect both to show up in complaints"), not as knowledge of Ashgrove's data. Then ask a question back (R1 reverse questions) | Most candidates won't have the brief. CO because it shows homework at strategy level |

### Question bank: Skeptic (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for 4+ years in financial-services customer operations. How does your experience line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | "I've spent six years in retail banking, the last three as a branch supervisor." Then stop and let them connect it to the requirement. If they ask whether branch work counts, describe the branch work in your own words rather than relabelling your title | F1 is a wording gap. JD because it's a stated requirement |
| B2 | "Have you handled regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start at the quote's scope: "I handled the branch's formal complaints log." Answer slot: if those complaints came under a regulator's complaint rules, say so and what you did to meet them, in your own words. If you don't know, or they didn't, say so plainly and describe the log. "Regulated" is the JD's word; use it about your log only if it's true | F2 is a discovery row and a likely screen check. JD because it's a stated requirement |
| B3 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "No, I haven't worked in a contact centre." Then one sentence of plan, such as time with agents and their escalation route in your first weeks. Keep it short: a recruiter needs the honest answer, not a defence. E1 is the full version | F4 is a gap you've stated, and a recruiter will want it on record before R2. JD because the JD names the contact centre |

### Question bank: Values (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which of our four values means most to you?" | VAL | [grounded] | Name one exactly as published: Members First, Always; Plain Words; Neighbours, Not Numbers; or Own the Fix. Give your reason in your own words, plus one story from the values cheat sheet (R3) if you have one. Don't recite all four | The panel scores values, and the recruiter may test early that you've read them. VAL on the published values |
| C2 | "Tell me about a time you put a member first." | VAL | [grounded] | Selection scaffold: a time you changed what you did because of how it would land for a member. It needs a named decision, what was at stake for the member, and how it ended. Use "I" for your part. If no such time comes to mind, say so plainly, then say how you'd handle it | Light version of J1. Its theme comes from "Members First, Always" |

### R1 reverse questions

| Question | Why it lands |
|---|---|
| "For the panel's values scoring, is each value scored separately?" | Shows you took in what they told you, and tells you how to pace R3 |
| "Will the 20-minute case be given in writing beforehand, or presented live?" | It's a logistics question that changes how you prepare |
| "Is this a new role or a replacement?" | Tells you what the Head of Member Services is buying in R2 |
| "How are complaints split between the branches and the contact centre today?" | Background for R2, where F4 will be tested |
| "What happens after 21 November, and when would I hear?" | A normal, practical close |

---

## R2: Head of Member Services (your future manager), 45 minutes

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "Tell me about a time…" stories | High. The recruiter said "mostly behavioural" | Stories built only from what you've said. Where a story isn't there, use the scaffold and say so |
| Skeptic | Quiet pressing on F4, F9 and F3 | High. Hiring managers are de-risking gaps, and your manager would own the contact centre and the senior reporting you'd join | Rehearse E1 until it bores you. Concede first, then the plan |
| Data-Driven Prober | Your spreadsheet, Excel, what the numbers mean | Medium. The JD's monthly reporting and Excel lines make your spreadsheet the natural target | Know exactly what the spreadsheet does and doesn't track (F5, F6) |
| Case / Strategist | Short live problems from the brief | Low-medium. Manager rounds often include live problems, but "mostly behavioural" lowers it | Clarify, segment, approach, metrics, risks |
| Pressure | Time-boxing, "how much was you?" | Low here. M1 and M2 cover it in R3 | Hold, then concede |

### Question bank: Values / Behavioural (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a complaint you took from first contact to resolution." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: one complaint you can tell start to finish, covering what the member raised, what happened, what they were told and how it closed. Answer slot: the JD's "end to end" line makes a probe on which steps were yours likely. If you investigated or replied yourself, say so in your own words. If your part was recording it in the formal complaints log, say that plainly and describe the log. If no single complaint comes to mind, say so and describe how the log worked | Tests F3 as a story. VAL first with EXP delivery: it's behavioural, but the probe is what was actually yours |
| D2 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Mapped on F7: you trained new tellers on your escalation script, and you've been a branch supervisor for three years. Tell those beats in your own words. Answer slot: the JD's line on coaching supervisors makes a probe on peer coaching likely. If you've helped another supervisor with an escalation, say how. If not, say so plainly and stay with the teller training. Don't call it coaching supervisors | F7 is the closest match to a headline responsibility. JD because it scores the coaching line |
| D3 | "Tell me about a mistake you made with a complaint, and what you did about it." | VAL | [grounded] | Selection scaffold: a real mistake that was yours, what you did once you found it, and what changed afterwards. That last part is Own the Fix. If no such time comes to mind, say so plainly, then say how you'd handle one. Never invent a safe-sounding mistake | Manager rounds test candour. Its theme comes from "Own the Fix" |
| D4 | "Tell me about a time you told a manager something they didn't want to hear." | VAL | [grounded] | Selection scaffold: a named issue, the person you told, how you said it, and where the relationship ended up. The point is that the hard truth actually got through. If no such time comes to mind, say so plainly, then say how you'd raise bad complaint numbers with senior leaders | Monthly reporting upward means delivering bad news. Behavioural stem from the persona model |

### Question bank: Skeptic (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You haven't worked in a contact centre, and you'd own complaints there too. Why should I take that risk?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | **This is the most valuable rehearsal in the pack.** (1) Concede first, plainly: "I haven't worked in a contact centre." (2) What you bring, in your quotes' words only: you handled the branch's formal complaints log, you trained new tellers on your escalation script, and you've been a branch supervisor for three years. (3) A plan, said as a plan: in the first weeks, sit with agents on live calls, learn how they log and escalate complaints, map where they hand over to branches, and ask the contact-centre lead what breaks. (4) Follow-up "So you'd be learning on the job?": hold with "On that channel, yes, and here's how I'd shorten it," then return to the plan. (5) Follow-up "How long until you're useful there?": concede specifically that you don't yet know their volumes or setup, and offer a checkpoint you'd agree with them. Never imply contact-centre exposure you haven't stated | F4 is the most predictable objection: the JD names the contact centre and you've said you haven't worked in one. JD because it scores a stated responsibility. Skeptic delivery, the deepest rehearsal |
| E2 | "This role reports monthly and presents to senior leaders. What's the most senior audience you've presented to?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | "I haven't presented above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words. If not, say so plainly. Then what you can point to: you built the monthly complaints spreadsheet your regional manager uses. Then a plan: a one-page summary, a run-through with your manager first, and asking what format leaders want. Hold, then concede: don't argue that it's the same thing | F9 is the second gap you've stated, and your manager would be in those senior meetings. JD on the presenting requirement |
| E3 | "You've handled one branch's complaints log. This is every branch plus the contact centre. What makes you ready for that jump?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Stay at the quote's scope: "I handled the branch's formal complaints log." Answer slot: if any steps from first contact to closure were yours, say which. If not, say so plainly. Then a plan for scale, said as a plan: a shared way of logging across branches, one monthly report to the same definitions, and coaching supervisors on escalations. Don't claim work across branches | F3's limit is scope, and a manager will test it. JD on "end to end across branches" |

### Question bank: Case (G)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Eight branches are becoming five hubs over 2027. What happens to complaints during that, and what would you do?" | CASE | [grounded] | Clarify: which branches, the timing, and how members are being told. Segment: members of branches that are changing, members less likely to move to digital, small-business members once lending launches, and staff. Approach: track complaint volumes and resolution times by branch before, during and after; brief supervisors on likely complaints; write member letters in plain words; create a clear route for complaints about the move itself. Risks: blaming the strategy, and complaints peaking just as staff move. The question needs no claim about your past, so the guidance makes none | Uses the brief's own consolidation line. CASE first, CO second, because it tests strategy fluency through a live problem |
| G2 | "We want 40% of member service on digital channels by 2028. How should complaints shape the self-service journeys?" | CASE | [grounded] | Structure: treat complaint themes as a map of where journeys fail; pick the top few; work with the digital team to test a fix; check whether complaints on that theme fall afterwards. Members First: keep a human route open. Answer slot: the JD's digital line makes a probe on past digital work likely. If you've given input to a digital or self-service change, say what and what your part was. If not, say so plainly and stay with the plan | F8 is a discovery row. CASE delivery on the JD's digital line and the brief's 40% target |

### Question bank: Data-Driven Prober (H)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Walk me through the monthly complaints spreadsheet you built. What does it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The quote's beats: you built it, it's monthly, your regional manager uses it. Answer slot: the JD's line on volumes and resolution times makes a probe likely. If it counts either, say what it counts and where the data comes from, in your own words. If it tracks other things, say what. If you don't know how a figure is counted, say so. Don't call it "the region's reporting": the quote says your regional manager uses it | F5 is your strongest reporting evidence and the prober's natural target. EXP because it tests what you actually built |
| H2 | "How comfortable are you in Excel? What's the most involved thing you've built?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you built the spreadsheet in Excel, say so and name, in your own words, only the features you actually used. Expect a follow-up on any you name. If it was another tool, name it plainly | F6 is a discovery row on a stated requirement. JD because it's the JD's Excel line |
| H3 | "Complaints are up 20% this month. How do you tell if that's a real problem?" | CASE | [generic] | Ask for the denominator (members, contacts or transactions) and the comparison month. Check whether the way complaints are logged changed. Split by channel, branch and complaint type. Look for a single event. Then resolution times: volume up with times steady reads differently from both rising. Say which assumption you'd check first. The question asks about no past, so the guidance claims none | Prober stem applied to the JD's reporting line. CASE with a prober's style of delivery. Generic because it's a pattern, not an Ashgrove fact |

### R2 reverse questions

| Question | Why it lands |
|---|---|
| "What would make the first six months a success, from your side?" | Your future manager's own criteria. It's the most useful answer you can get |
| "How do branches and the contact centre hand complaints to each other today?" | You name your gap (F4) by asking to learn it |
| "What format do senior leaders prefer for the monthly complaints report?" | Shows you're preparing for F9 rather than hiding it |
| "How will complaints work for the small-business lending product launching in Q1 2027?" | Uses the brief, and asks about a new kind of complaint they'll need to plan for |
| "On self-service journeys, does this role decide, advise or test with the digital teams?" | Clarifies the JD line behind F8 |

---

## R3: Panel of two branch managers, 60 minutes (values round plus the 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One story per value, scored | High. The recruiter said they "score against the four values" | Values cheat sheet below. "I" for your part |
| Case / Strategist | The 20-minute escalation case | Certain. The recruiter announced it | The build section above |
| Peer Evaluator | "What would you need from us?", where the boundary between their branches and your role sits | Medium. Branch managers are the people whose supervisors you'd coach | Offer before you ask. Propose principles for the boundary; don't pretend to know it |
| Pressure | Time-boxed challenges on credibility and on the hubs | Low-medium. A panel can push, and consolidation is a live topic for branch managers | Pause, hold, then concede specifically |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story | Bank IDs |
|---|---|---|---|
| Members First, Always | Decide from the member's point of view, not the process's | No quote of yours carries a member-first story yet. Selection scaffold: a time you changed a decision because of how it would land for a member, with a named decision, the stake and the ending. If none comes to mind, say so plainly, then say how you'd handle it | C2, J1 |
| Plain Words | If something needs explaining twice, the wording is at fault, not the member | Nearest material, F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if the script's wording ever changed because tellers or members found it unclear, say what changed and what your part was. If not, leave it at the training and use the scaffold in J2 | J2 |
| Neighbours, Not Numbers | Each branch belongs to its town | No quote carries this story. Selection scaffold: a time knowing your local members or town changed how you handled something. If none comes to mind, say so plainly, then say how you'd keep that during the move to hubs | J3, M2 |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | Nearest material, F5: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because something was missing or broken, say what and how you saw it through. If it was a request, say so plainly and use J4's scaffold for another problem | D3, J4 |

### Question bank: Values (J)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Tell me about a decision you made from the member's side of the counter." | VAL | [grounded] | Selection scaffold: a named decision, what the member's side looked like, what it cost or risked for the branch, and how it ended. "We" for the context, "I" for your part. If no such time comes to mind, say so plainly, then say how you'd handle it | Scored value one. The theme is the value's own words: "we decide from the member's side of the counter" |
| J2 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: what was being explained, why it didn't land, and what you changed in the words. Answer slot: if the escalation script's wording changed because of what tellers or members found, say how and what your part was. If not, say so plainly and use another example or say how you'd handle it | Scored value two. The theme is its line "if a member needs it explained twice, we wrote it wrong" |
| J3 | "Tell me about a time knowing your town changed how you handled something at the branch." | VAL | [grounded] | Selection scaffold: something local you knew, the decision it changed, and the outcome. If no such time comes to mind, say so plainly, then say how you'd keep that local knowledge as branches become hubs. Avoid anything that sounds like a closure count | Scored value three, from "every branch is part of its town". Sensitive for this panel (grounding brief) |
| J4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you built the monthly complaints spreadsheet because something was missing or broken, say what you noticed and how you saw it through, in your own words. If it was a request or a routine task, say so plainly and pick another problem with this scaffold: you found it, it wasn't strictly yours, you kept it until it was fixed. If none comes to mind, say so plainly, then say how you'd handle one | Scored value four, from "whoever finds the problem keeps hold of it until it is solved" |

### Question bank: Case (K)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | Practice case: "A member's complaint about a payment error has bounced between their branch and the contact centre for three weeks. They've now written to the CEO. You have the file. Talk us through it." | CASE | [generic] | Use the 20-minute shape from the build section: clarify (rules, deadlines, what the member has been told, who owns it), member first (a call, plain words, an honest timeline), fix the case, find the root cause (the handover), then close. Name the values where they fall naturally. Ask how the contact centre logs complaints instead of assuming. The case asks about no past, so the guidance claims none | A stand-in for the announced case, invented for rehearsal. CASE because the case is the graded deliverable |
| K2 | Follow-up: "The branch supervisor feels you've gone over their head. What do you say?" | CASE | [generic] | The supervisor stays the owner, with your support: agree who calls the member, what you'll handle centrally and why, and a debrief afterwards. Own the Fix: whoever found the problem keeps hold. Don't pull rank | Tests the JD's coaching line under the panel's own branch-side view |
| K3 | Follow-up: "You find four more complaints with the same handover failure. What now?" | CASE | [generic] | Moves from one case to a pattern: confirm it's the same cause, fix the handover with both sides, coach supervisors on the new route, report it in the month's complaints figures, and check next month whether it's gone. If it began in a digital journey, take it to the digital team | Covers the JD's monthly reporting and digital lines inside the case |

### Question bank: Peer Evaluator (L)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Our supervisors are stretched. What would you take off their plate, and what would you need from us?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Offer first: clear escalation routes, short coaching, and a monthly report they can actually use. Then ask: early warning on difficult complaints and time for supervisors to debrief. You can say, "For the last three years I've been a branch supervisor myself," and stop there. Promise no headcount or tools | Peers are pricing your effect on their workload. JD on the coaching line |
| L2 | "If a complaint shows one of our branches got it wrong, how do you raise it with us?" | VAL | [generic] | Privately first, facts from the log, the member's outcome, then fix it together, with the branch keeping hold (Own the Fix). No league tables that turn towns into numbers. The question asks about no past, so the guidance claims none | Tests disagreement style with peers. VAL because two values apply directly |
| L3 | "Where's the line between what the branch resolves and what comes to you?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Propose a principle, not knowledge of their current setup, for example: the branch keeps what it can resolve, and you take what crosses channels, breaks a deadline or repeats. Mention that you've trained new tellers on an escalation script, so escalation routes are something you've taught. Then ask how it works today | Peer stem on boundaries. JD on "end to end across branches and the contact centre" |

### Question bank: Pressure (M)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "You've been a supervisor for three years. Why would our supervisors take coaching from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause. Hold with what you said: three years as a branch supervisor, and training new tellers on your escalation script. Return to those through two follow-ups. Answer slot: if you've helped a peer supervisor with an escalation, say so. If not, say so plainly. Then concede specifically: coaching supervisors would be new for you, and here's how you'd earn it (sit alongside them first, then coach) | F7's limit under pressure. JD because it's the coaching responsibility |
| M2 | "Sixty seconds: five hubs instead of eight branches. Is 'Neighbours, Not Numbers' just a slogan now?" | CO | [grounded] | Pause. Neither attack the strategy nor defend it blindly. Hold this position: the value is tested by how members of the changing branches are treated, through a clear complaints route, plain-words letters and tracking complaints from those towns. Concede that you don't know the detail of the hub plan. Never speak for the panel's own branches | Combines the brief's consolidation line with a published value. CO first, VAL delivery |

### R3 reverse questions

| Question | Why it lands |
|---|---|
| "What do members in your towns complain about that never makes it into a formal log?" | Branch-level knowledge, Neighbours, Not Numbers, and real input for the job |
| "What could someone in this role do in the first month that would actually help your supervisors?" | A reciprocity question for peers |
| "When an escalation goes well here, what does it look like from the branch side?" | Lets them describe what good looks like to them |
| "Which of the four values is hardest to live up to day to day in a branch?" | Invites candour in the values round itself |
| "How are your teams preparing members for the move to hubs?" | Only if the conversation has already opened that door. Read the room, because the brief doesn't say whose branches change |

---

## Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own the complaints process end to end across branches | F3 | D1, E3, L3, K1 |
| ...and the contact centre | F4 | B3, E1, K1 |
| Report monthly on complaint volumes and resolution times | F5 | H1, H3, K3, G1 |
| Coach branch supervisors on escalations | F7 | D2, K2, L1, M1 |
| Work with digital teams on self-service journeys | F8 | G2, K3 |
| 4+ years in financial-services customer operations | F1 | A1, B1 |
| Experience handling regulated complaints | F2 | B2, D1 |
| Confident presenting to senior leaders | F9 | E2, D4 |
| Comfortable with Excel reporting | F6 | H2 |
| Four published values (panel-scored) | cheat sheet | C1, C2, J1 to J4, M2 |
| Strategy (digital, hubs, lending, app-only banks) | grounding brief | A4, G1, G2, M2, reverse questions |

---

## Claims this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Handled members' complaints personally, end to end | Inflated form of F2 and F3 | Quote at its own scope: "I handled the branch's formal complaints log." Your material says the log, not each complaint. D1's slot stays inside the log |
| Handled *regulated* complaints | Inflated form of F2 ("formal", not "regulated") | Quote at its own scope. B2's slot uses "regulated" only if it's true of your log |
| Owned or ran complaints across branches | Inflated form of F3 | "I handled the branch's formal complaints log." One branch, as the quote says |
| Has contact-centre experience | A gap you stated (F4) | "I haven't worked in a contact centre." Then a plan |
| Has presented to senior leaders | A gap you stated (F9) | "I haven't presented above regional level." Then a plan |
| Coached supervisors | Inflated form of F7 | "I trained new tellers on our escalation script." Your material says tellers, not supervisors |
| Runs the region's complaints reporting | Inflated form of F5 (scope) | "I built the monthly complaints spreadsheet our regional manager uses." It's a spreadsheet one manager uses, not regional reporting |

---

## Sources

**Provided documents:** the JD; Ashgrove's values text, copied by you from ashgrovecu.org/about/values on 12 November 2026; the recruiter's email about the process; the July 2026 strategy brief (from your summary of it); your background message. No dossier was consumed.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you copied this morning from the official page already supplies the four names and definitions for the cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email already sets out all three rounds, the case and the values scoring, so the loop structure and persona weights rest on it |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief is under six months old and already supplies the priorities and competitive context for the grounding brief and the CO and CASE questions |
| 4. Interviewer name at Ashgrove | n/a | No names have been assigned, so there's nothing to search. The upgrade menu says what names would add |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

---

## Upgrade menu

- **Your answers to the answer slots** (F2 on whether complaints were regulated, F3 on which steps were yours, F5 on what the spreadsheet tracks, F6 on Excel, F7 on peer coaching, F8 on any digital input) → those rows regenerate with your words, and B2, D1, D2, E3, H1, H2, G2, J2 and J4 become story-mapped instead of slots
- **The structure of your monthly complaints spreadsheet** (column headings only, with no member data) → F5 and F6 rest on something inspectable, and H1 can rehearse exactly what it tracks
- **Your CV** → a second source for F1 to F3, and any experience your message didn't mention becomes material for the values cheat sheet
- **Interviewer names, once assigned** → a section reading each interviewer from their public professional profile, persona weights per person, and a reverse question tied to each one's path
- **The strategy brief's actual text** → the grounding brief in Ashgrove's own wording rather than your summary of it
- **How many hours you have to prep before the 21st** → a prioritised prep schedule tied to question IDs
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → recent Ashgrove news and organisation context since July, and any published candidate reports on its interview loop
- **A tuesday-dossier.md from a job-underwriter run** → evidence-checked grading for the fit snapshot and an evidence-derived list of the claims to avoid, instead of the local one built here
