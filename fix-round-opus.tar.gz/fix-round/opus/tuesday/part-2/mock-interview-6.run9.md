Reading's done; I've worked out the prep structure. Next I'm searching for Larkfield's values and interview process, then I'll write the pack.
Search permission was declined, so I won't retry it. I'm writing the pack from what you gave me and noting what research would have added.
I've written one prep pack for all three rounds. It starts with a shared table of how your experience matches the role, then has a separate section for each round, each with its own interviewer styles, 9–10 practice questions and questions to ask back. The pack is saved at `larkfield-systems_engineering-manager_interview_pack.md` in your working folder.

I built it only from the role text and your message, because web search was declined. That means:
- **No values cheat sheet for Monday.** I couldn't read Larkfield's published values, so the Monday questions come from the recruiter's "values and leadership philosophy" wording instead.
- **No Larkfield company facts.** Any question about the company or its strategy is generic.

- **The question to prepare most is A1:** "You've been a team lead of six; this is two squads and eleven engineers. Why are you ready?" Some version of it will come up in every round.
- **Your strongest material** is the hiring loop you run and the reliability quarter.
- **Your stated gaps** are managing managers and owning a hardware-adjacent roadmap. The pack gives you plain wording for both and never stretches past what you said.
- **Places your message doesn't cover:** growing engineers, working with hardware teams, and device-management experience. The pack marks each one with two honest answers you can choose between. It doesn't fill them in for you.

Say the word and I'll play the Skeptic on A1 before Tuesday, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to bring to later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Did the recruiter tell you anything about the format of Thursday's panel or Monday's call, like a system-design or planning exercise, or any pre-work? Any of those would get its own prep section.
2. Can you paste your CV? The gaps above might turn out to be covered, and the answers would use your real bullets. I'm fine going on without it.
3. Would you like to allow web search, or paste Larkfield's values and careers pages? That gives Monday a values cheat sheet and replaces the generic company questions with real ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop. One shared fit snapshot, then a mini-pack for each of your three scheduled rounds.

| Round | When | Length | Who | Relationship |
|---|---|---|---|---|
| 1 | Tuesday 17 Nov | 45 min | Director of Engineering | Hiring manager, your would-be boss |
| 2 | Thursday 19 Nov | 60 min | Two staff engineers and a product manager | Panel: technical peers plus a cross-functional partner |
| 3 | Monday 23 Nov | 30 min | VP Engineering | Skip-level. Recruiter: "values and leadership philosophy" |

No interviewer names were given, so there is no interviewer read and the reverse questions are role-specific, not personal.

## How to use this pack

- **Personas** describe how a question is asked: the Skeptic probes your gaps quietly, the Prober asks how a number was counted, the Peer Evaluator tests the seam between teams. **Types** describe what is being scored:
  - **VAL**: whether your past behaviour shows the values and leadership philosophy they're assessing
  - **EXP**: whether what you said about your work holds up, and what was actually yours
  - **JD**: whether you can do the job as listed, gaps included
  - **CO**: company and domain knowledge, and thinking at the company's level
  - **CASE**: a live problem from the role, solved out loud
- **Provenance** shows how far each row rests on what you told me. `[grounded]` means it traces to your message or the role text, `[inferred]` means it's my derivation and names what it comes from, and `[generic]` means a role-family pattern that claims nothing about you or Larkfield.
- **Answer slots** are places where the pack can't know your answer. Each one names the probe you're likely to get and gives two honest branches. Answer from what actually happened. "It wasn't mine" and "that didn't exist" are both full answers.
- The guidance is scaffolding, not a script. Say it in your own words.
- **Highest-ROI prep in the pack: A1**, the scope jump from one team of six to two squads of eleven. Every round will raise it in some form.

## Fit snapshot

Requirements are quoted from the role text you pasted. Evidence is quoted from your message, word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material shows one team of six, led for three years. It doesn't show two squads, and the words stay at your scope: "For three years I've been team lead of a team of six." Answer slot: "Lead two squads" makes a probe on leading more than one group at once likely. If you have done that, say how, in your own words. If you haven't, say so plainly and stay with the team of six |
| F2 | "own delivery" — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [inferred] | discovery | Pushing a reliability quarter through touches what your team delivered. It doesn't show whether delivery was yours to own. Answer slot: "own delivery" makes a probe on what you were accountable for delivering likely. If your team's commitments were yours to set or answer for, say which and how, in your own words. If they sat with someone else, or there was no such commitment, say so plainly and return to the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role text | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running the loop is the interviewing side of hiring. Owning hiring for a team reaches further. Words at your scope: "I run our hiring loop for backend roles — about 40 interviews last year." The 40 counts interviews, not hires. Answer slot: owning hiring makes a probe on hire or no-hire decisions likely. If any were yours to make, say which and how. If they sat with someone else, or the loop had no such step, say so plainly and stay with running the loop |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role text | none given | none | [grounded] | discovery | Your material doesn't show growing engineers. Answer slot: "growth for 11 engineers" makes a probe on developing people likely. If growing people on your team was part of your role as lead, say what you did, in your own words. If it wasn't, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" (the product part) — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [inferred] | discovery | "Against roadmap pressure" touches roadmap negotiation. It doesn't say who the pressure came from or how it was worked out. Answer slot: "partner with … product on roadmap" makes a probe on who pushed back and how it ended likely. If product partners were part of it, say how the conversation went and where it landed, in your own words. If the pressure came from elsewhere, or there was no negotiation as such, say so plainly and stay with the quarter you pushed through |
| F6 | "partner with hardware and product on roadmap" (owning a hardware-dependent roadmap) — role text | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | This is a gap you stated, kept at its own scope. Words: "I haven't owned a hardware-adjacent roadmap." Then say how you would learn it, as a plan and never as a past. Nothing gets added to make the gap feel smaller |
| F7 | "partner with hardware and product on roadmap" (working with hardware teams at all) — role text | none given | none | [grounded] | discovery | Your sentence in F6 covers owning a hardware-adjacent roadmap. Your material says nothing about working with hardware people in any other way. Answer slot: if any of your work involved a hardware team, say what it was and what your part was, in your own words. If none did, say so plainly |
| F8 | "industrial IoT" and "building device-management services" — role text | none given | none | [grounded] | discovery | Your material doesn't show work on services that manage devices. Answer slot: if you've built or run anything like that, say what, in your own words. If not, say so plainly and say how you would ramp up |

**How to read the snapshot.** Your strongest material is F3 (the hiring loop) and the reliability quarter in F2 and F5. Your stated gaps are F6, plus managing managers (see Prohibited claims). The silences are F4, F7 and F8. Silences aren't weaknesses. They're places where your interviewers will ask and the pack can't answer for you.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads (F1) | A1, D1, H2, K1 |
| Device-management services, industrial IoT (F8) | A3, F2, J1 |
| Own delivery (F2) | B1, B2, G1, J2 |
| Hiring (F3) | B3, C2, I4 |
| Growth for 11 engineers (F4) | E3, I3 |
| Partner with hardware (F6, F7) | A2, A4, B2, G2, H2 |
| Partner with product (F5) | E1, E4, G1, G2 |

---

## Round 1: Hiring manager, Director of Engineering (Tuesday, 45 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Why are you ready for this scope?", "What about the hardware side?" | High. A would-be boss is paying to remove risk, and F1 and F6 are the visible risks | Rehearse A1 until it's boring. Hold with your quoted facts, name the limit before they do, then give a plan |
| Case / Strategist | "Your first 90 days", "A hardware milestone slips" | High. Hiring managers test you against the job they'll hand you | Clarify, then objective, constraints, approach, how you'd measure it, risks. Think out loud |
| Data-Driven Prober | "How was that 60% counted?" | Medium. A director will notice the one figure in your story | Know what you can and can't say about how the figure was counted. Saying "I don't know" is allowed |
| Conversational | "Walk me through your journey" | Low but certain. It's usually the opener, and it's scored | Have a 90-second arc built only from what you've said |

### Question bank

**A — Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've been a team lead of six. This is two squads and eleven engineers. What changes for you, and why are you ready?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | **Highest-ROI rehearsal in the pack.** Name the jump yourself first: "It's a real step up, from one team of six to two squads." Hold with only what the quote carries: "For three years I've been team lead of a team of six." Then give the forward half as a plan, not a past: how you'd split your time across two squads, what you'd want from each squad's technical lead, and what you'd measure in the first quarter. Answer slot: the role's "own delivery, hiring and growth" makes "which of those were yours as lead?" the likely follow-up. Say which were yours and how, in your own words. If some weren't, or didn't exist in your role, say so plainly and come back to the team of six. Hold through two follow-ups by returning to the quote, never by adding to it | F1 is the main gap a hiring manager prices, so this arrives in every round in some form. Tagged JD because it scores the role's headline requirement against your scope |
| A2 | "Have you owned a roadmap that depended on hardware? How would you partner with a hardware team here?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Lead with the plain answer, then move straight to the plan: "I haven't owned a hardware-adjacent roadmap." The plan is forward-looking: what you'd ask hardware leads in week one, how you'd learn their release cadence and constraints, and where you'd want joint planning. Answer slot: if any of your work involved a hardware team in another way, say what and what your part was. If none did, say so and stay with the plan. Don't claim familiarity you haven't stated | F6 is a gap you stated and F7 is a silence. The director's own org works with hardware, so this is near certain. Tagged JD because it's a listed responsibility |
| A3 | "Why leave payments for industrial IoT, and why Larkfield?" | CO | [generic] | Pick reasons that are actually yours. A strong answer has a pull (what draws you to the domain or this role), a reason the timing is right, and one specific thing about Larkfield you've read yourself. If you don't have a Larkfield-specific reason yet, say what draws you to the role as written, and don't invent company facts. Answer slot: if something in your payments work pointed you toward this move, say what, in your own words. If nothing did, say so and give the pull plainly | F8 is a silence, so motivation gets tested. Tagged CO because it scores homework. Research couldn't run, so no Larkfield facts are supplied here |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Choose a real gap from the role text: "I haven't owned a hardware-adjacent roadmap." Then give a concrete ramp plan with a timeframe you'd commit to. Don't pick a fake weakness. This interviewer will be your manager and will remember the answer | F6 gives you an honest, role-relevant answer. Tagged JD because the answer is scored against the listed responsibilities |

**B — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit two squads. What do you need to know in the first 30 days, and what would you have done by day 90?" | CASE | [generic] | Clarify first: the squads' current commitments, on-call load, who the technical leads are, and how they're working with hardware and product. Then cover listening (one-to-ones, the backlog, incident history), one early visible improvement, and a hiring plan. Close with how you'd know it's working. This makes no claim about your past | Tests "own delivery" (F2's requirement) as a plan. Tagged CASE because it's live and asks about no past |
| B2 | "A hardware milestone slips six weeks, and a device-management release your squads committed to depends on it. Walk me through your next week." | CASE | [generic] | Structure: confirm the facts with the hardware lead, map what actually depends on the slipped piece, separate what can still ship from what can't, re-plan with product, then tell stakeholders early with options. Name one risk you'd watch, such as the squads losing momentum. This makes no claim about your past | Partnering with hardware (F6, F7) as a live decision rather than a record. Tagged CASE, with JD content |
| B3 | "You can make two hires across the squads. How do you decide what to hire for, and how do you run the loop?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | First half is the decision, as a plan: the gaps in the squads, the roadmap's next two quarters, and seniority balance. Second half is what you run today: "I run our hiring loop for backend roles." Tell the loop's shape in your own words. Answer slot: if you've decided what roles to open, say how. If that sat with your manager, say so plainly and stay with running the loop | F3 is your strongest evidence and the role owns hiring. Tagged CASE delivery on JD content |

**C — Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your team's on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Keep the sentence's own terms: the team's on-call burden dropped 60% after the reliability quarter. Then the four slots, each in your own words. First, how the 60% was counted: what "on-call burden" measured and over what period. Second, what the figure is sensitive to. Third, the assumption behind it you'd defend least, said before they ask. Fourth, which part was yours: you say you pushed the quarter through, so say what pushing it through involved. "I don't know exactly how it was counted" is an honest branch. Say it plainly rather than guess | Every headline figure gets a defend-the-number question, and this is your only one. Tagged EXP because it tests whether the claim holds up |
| C2 | "What does running the hiring loop actually involve for you?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Describe the loop as you run it, in your own words. The 40 is interviews, so say it that way and don't let it become hires. Answer slot: owning hiring makes a probe on hire decisions likely. If the final call was yours, say how you made it. If it sat with someone else, say so plainly and describe your part | F3 is a bridge to "own hiring". Rehearse it so the number stays attached to the right noun |

**D — Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | 90 seconds. Nine years in engineering, the last three as team lead of a team of six, at a payments company now. One story, the reliability quarter, in the sentence's own terms. End on why this role is the next step. Stop there and let them pick a thread | The opener is scored. Tagged EXP because it sets up the claims the rest of the hour will test |

### Reverse questions, Round 1

| Question | Why it lands |
|---|---|
| "What would make you say, a year from now, that this hire was clearly right?" | Gets your future manager to state the bar. It shapes everything you say in later rounds |
| "How do the two squads split today, and where is the seam between them hardest?" | Shows you're already thinking about leading two groups, the F1 question, without claiming you've done it |
| "How does roadmap planning work between your org, hardware and product?" | Goes straight at F6 and F7 and tells you what you'd be learning |
| "What's the biggest delivery risk on the device-management services right now?" | Tests the job, and gives you material for the Thursday panel |
| "What support do new engineering managers get here, and how do you run one-to-ones with yours?" | A first-time EM of two squads needs to know this. It reads as diligence, not need |
| "What would you want me to probe in the panel and VP rounds that you haven't been able to cover today?" | Turns the gap the director noticed into prep you can do before Thursday |

---

## Round 2: Panel, two staff engineers and a PM (Thursday, 60 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | "Where's the seam between us?", "What would you take off our plate?" | High. All three are pricing what you'd add to or take from their own work. The PM is your roadmap partner in the role text | Lead with what you bring to them, not just what you'd need. Propose principles for the seam rather than pretending to know it |
| Data-Driven Prober | Staff engineers digging into the reliability quarter and the 60% | Medium-high. Technical interviewers verify depth, and the reliability story is the most technical claim you've made | Know the beats your sentence states, and use answer slots for the rest |
| Case / Strategist | Planning with hardware and product, on-call triage | Medium. A 60-minute panel has room for a live scenario | Clarify first, then structure, then make the trade-off explicit |
| Pressure | "How much of that was actually you?", time-boxed challenges | Low-medium. Panels sometimes have one person play the hard line | Pause, restate, hold the core claim through two follow-ups, then concede specifically |

Panels blend each member's personas. If you learn who has which background, reweight: a PM leans Peer Evaluator, staff engineers lean Prober.

### Question bank

**E — Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | PM: "You and I would share this roadmap. Where's the seam, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Start with principles: the PM owns what and why, you own how and when, and you surface engineering health as a roadmap input, not a veto. Then the one story: you pushed a reliability quarter through against roadmap pressure, and the team's on-call burden dropped 60% after. Answer slot: the PM will want to know who the pressure came from. If it was product partners, say how the disagreement went and how the relationship ended up, in your own words. If it came from elsewhere, or there was no negotiation as such, say so plainly and stay with what you pushed through | F5's requirement, asked by the person you'd partner with. Tagged JD |
| E2 | Staff engineer: "How do you handle credit when work spans teams, like hardware and your squads?" | VAL | [generic] | Pick a time credit was shared across teams. It needs a named piece of work, what you did about credit, and what happened to the relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Peer Evaluator stem on the F7 seam. Tagged VAL because it scores behaviour |
| E3 | Staff engineer: "What would a staff engineer working with your squads get from you, and what would you leave alone?" | JD | [generic] | Reciprocity first: what you'd take off their plate, such as process, cross-team noise and hiring load, and what you'd protect, such as technical direction and focus time. Answer slot: "growth for 11 engineers" makes "how have you grown senior people?" the likely follow-up. If growing people was part of your lead role, say what you did. If it wasn't, say so plainly and say how you'd approach it | F4 is a silence, and senior engineers test it from their own side. Tagged JD |
| E4 | PM: "Tell me about a time you said no to a product ask." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | If the reliability quarter fits, tell it with only the beats the sentence states: the roadmap pressure, you pushing the quarter through, and the team's on-call burden dropping 60% after. Whether it was a "no" to product is the F5 answer slot: if it was, say so in your own words. If it wasn't a product ask, say so and pick another story or explain how you'd handle one | F5. The PM is testing whether you'll partner or block. Tagged VAL with JD content |

**F — Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through that reliability quarter. What did the team actually work on?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Tell what the work was in your own words: what was fixed, in what order, and who did it. Use "we" for the team and "I" for your part. Your sentence says you pushed the quarter through, so be ready to say what that meant day to day. If it was mostly the argument for it rather than technical leadership of the work, say that plainly | Staff engineers will go two levels deeper than the headline. Tagged EXP because it tests what was yours |
| F2 | "Services that manage devices in the field fail differently from payments APIs. How would you think about reliability here?" | CASE | [generic] | Clarify first: what the devices are, how they connect, and what an update costs if it goes wrong. Then structure it: staged rollouts, being able to roll back, visibility into the fleet, and on-call design that matches. Ask them what hurts today. Answer slot: if your payments work has a direct parallel, name it in your own words. If it doesn't, say so and reason from first principles | F8 is a silence. A live problem lets you show reasoning without claiming domain history. Tagged CASE |

**G — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "One squad is drowning in on-call. The other is ahead on features. The PM wants more features. What do you do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure: look at the on-call data, estimate what it's costing in delivery, bring the PM a trade-off with numbers rather than a refusal, and consider moving capacity between squads. You can name the reliability quarter as the closest thing you've done, in the sentence's own terms. Never say the 60% is what Larkfield would get | "Own delivery" (F2) and partnering with product (F5) together. Tagged CASE. Your quote earns it a grounded anchor |
| G2 | "How would you run a quarterly planning cycle across hardware, product and two squads?" | CASE | [generic] | Inputs (hardware milestones, product priorities, engineering health), sequencing around dependencies, one joint review, and a slip protocol agreed in advance. Say plainly that you'd learn the hardware cadence first. Don't describe a hardware planning process as if you've run one | Partnering with hardware (F6, F7) as a design question. Tagged CASE with JD content |

**H — Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: "I pushed the reliability quarter through. The work and the drop were the team's." That's the sentence's own split. Concede specifically and early: the sentence says the drop came after the quarter, so say in your own words what else might have contributed, or say you don't know. Don't claim the 60% as your personal result | Pressure stem on your one figure. Tagged EXP. The hold-then-concede is the skill being tested |
| H2 | "Sixty seconds: why should we want you over someone who's already run hardware-facing teams?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Concede first, briefly: "I haven't owned a hardware-adjacent roadmap." Then two things you bring, in your quotes' own terms: you run the backend hiring loop, about 40 interviews last year, and you pushed a reliability quarter through against roadmap pressure. Close with your ramp plan. Keep it to 60 seconds | F6 under time pressure. A rehearsed concede-then-pivot beats a defensive one. Tagged JD |

### Reverse questions, Round 2

| Question | Why it lands |
|---|---|
| To the staff engineers: "What could a new EM do in the first month that would genuinely help your work?" | The reciprocity question. It tells peers you're there to reduce their load |
| To the PM: "Where does the roadmap get stuck today, with hardware, with engineering capacity, or somewhere else?" | Tests the F5 and F6 partnership from the inside |
| "What does on-call look like across the two squads today?" | Connects to your strongest story without claiming anything for it |
| "When engineering and product disagree here, who usually breaks the tie, and how?" | Shows you're thinking about the seam you'd sit on |
| To the staff engineers: "What's the technical decision from the last year you'd most like to revisit?" | Invites a real conversation and tells you how they think |
| "What would you want from your EM in hiring?" | Brings F3 into a question about their needs |

---

## Round 3: VP Engineering, "values and leadership philosophy" (Monday, 30 min)

The recruiter's description makes this a values-style round. I couldn't read Larkfield's published values (search was declined), so there's no values cheat sheet and the VAL questions are themed from the recruiter's words and the role text. The upgrade menu says what the values page would add.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?", "Tell me about a time…" | High. The recruiter named the round's focus | Have three or four stories chosen from your quoted material. Use "we" for context and "I" for your part |
| Case / Strategist | "Where does this team create value?", "How would I know you were a good hire?" | Medium. VPs test altitude | Answer at org level, briefly. Name the trade-off |
| Pressure | "You've never managed managers. Why bet on you?" | Medium. Thirty minutes and a skip-level means short, sharp probes | Pause, hold, concede the stated gap, close with the plan |
| Conversational | "Where do you want to be in five years?" | Low. A likely closer | A short, true answer that fits the role |

### Question bank

**I — Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | Two or three principles you actually hold, each tied to one thing you've said: the reliability quarter you pushed through against roadmap pressure, and the backend hiring loop you run. State each principle, then the example in its own terms. Don't list principles you can't anchor | The recruiter named this. Tagged VAL. Anchoring to quotes keeps it from sounding like slogans |
| I2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The reliability quarter may fit: it went through against roadmap pressure. Answer slot: whether pushing it through meant taking a case to leadership is not in your sentence. If it did, say who, what you said and how it landed, in your own words. If it didn't, say so plainly and pick another time, or say how you'd handle it | Values persona stem, themed by "leadership philosophy". Tagged VAL |
| I3 | "Tell me about someone you helped grow." | VAL | [generic] | Pick a person (role, not name) whose growth you contributed to. It needs where they started, what you did, and where they got to. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd approach growth for eleven engineers | F4 is a silence, and the role names growth. Tagged VAL with JD content |
| I4 | "Tell me about a hiring decision you'd make differently now." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Context in the quote's terms: you run the backend hiring loop, about 40 interviews last year. Answer slot: if there's a decision you'd revisit, say what it was and what you'd change, in your own words. If the decisions weren't yours, say so plainly and talk about what you'd change in how the loop runs | F3. VPs test judgement about people. Tagged VAL |

**J — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Where does a device-management services team create the most value for a company like ours?" | CO | [generic] | Reason out loud, and don't assert Larkfield facts you haven't read. Clarify, then cover reliability of the fleet, speed of safe updates, and what it frees hardware and product to do. Then ask what the VP sees as the team's biggest lever | F8 is a silence. Tagged CO, but research couldn't ground it, so it stays generic |
| J2 | "Eighteen months from now, how would I know you were a good hire?" | CASE | [generic] | Three measures you'd sign up to: delivery predictability, team health (on-call, retention), and hiring. Then one thing you'd want the VP to hold you to | "Own delivery" (F2) at VP level. Tagged CASE |

**K — Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You've never managed managers. If we grow and you need leads under you, why bet on you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Concede plainly and don't argue the premise: "I haven't managed managers." Hold on what you have: three years as team lead of a team of six. Then say how you'd learn it: what you'd ask for (a mentor, a peer EM) and what you'd do first. Hold through two follow-ups. Never imply you've done it | You stated this gap and a VP may test it. Tagged JD because the role's scope could grow into it |
| K2 | "Thirty seconds: what would your current team say is your weakest point as a lead?" | VAL | [generic] | Pick something true and current, plus what you're doing about it. If you honestly don't know what they'd say, say that and say how you'd find out | Pressure under time-boxing. Tagged VAL for self-awareness |

**L — Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Where do you want to be in five years?" | VAL | [generic] | A short, true answer that fits the role. If you don't know yet, say what you want to get better at instead | A likely closer. Tagged VAL for motivation fit |

### Reverse questions, Round 3

| Question | Why it lands |
|---|---|
| "What leadership behaviour do you most want more of across your EMs?" | Answers the round's own theme from their side |
| "What's the hardest trade-off engineering has made with hardware or product this year?" | Org-level, and tests F6 from the top |
| "How do you grow first-time engineering managers here?" | Honest about F1, and tells you what support exists |
| "What does Larkfield need from device-management services over the next year or two?" | Gets the strategy research couldn't supply |
| "What would make you worried about this hire, six months in?" | Brave and useful. It surfaces the doubt while you can still answer it |

---

## Prohibited claims

What this pack will not coach, and why. Each entry gives its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated (F6's evidence sentence) | "I haven't managed managers." |
| Has owned a hardware-adjacent roadmap | A negative you stated (F6) | "I haven't owned a hardware-adjacent roadmap." |
| Line manager of six, "managed a team of six" | Inflated form of F1 | F1's quote at its own scope: team lead of 6. Your material doesn't say whether you were their line manager. A1's slot stays inside the lead role |
| Made or owned hiring decisions, hired a number of engineers | Inflated form of F3 | F3's quote at its own scope. The 40 counts interviews, not hires. C2's slot stays inside the loop |
| Personally cut on-call by 60%, or cut incidents by 60% | Inflated form of the F2 and F5 sentence | The sentence exactly: the team's on-call burden dropped 60% after you pushed the quarter through. It states what came after your push, not that the drop was yours alone, and it measures on-call burden, not incidents |
| Set or owned the team's roadmap | Inflated form of the F2 and F5 sentence | The sentence exactly: you pushed a reliability quarter through against roadmap pressure. E1's and E4's slots ask only who the pressure came from |

## Sources

- **Provided:** the role text you pasted; your background as written in your message.
- **Searches sent:**
  - "Larkfield Systems industrial IoT values": refused (web search permission not granted)
  - "Larkfield Systems interview process engineering manager": refused
  - "Larkfield Systems device management news 2026": refused
- **Fetches:** none.
- **Loop:** your message establishes the loop: three sessions, with length, interviewers and focus for each. That source names Round 3 as a values-style round.
- **Dossier:** none present; built standalone.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Refused. It would have added a values cheat sheet for Round 3 and VAL questions named after Larkfield's own values |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Refused. It would have checked the panel's format against documented practice. Your message already fixes the rounds |
| 3. Larkfield Systems strategy and recent news | unavailable | Refused. It would have grounded A3, J1 and a CO question in current priorities. They're generic for now |
| 4. Interviewer name at Larkfield | n/a | No names were given, so no query could be formed. There's no interviewer read |
| 5. Representative Engineering Manager JD | skipped | You supplied the role text, and it fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Allow web search, or paste Larkfield's values and careers pages** → a values cheat sheet for Round 3 mapping each value to an F-row story, VAL questions named after their values, and CO questions (A3, J1) grounded in current strategy
- **Your CV** → F4, F7 and F8 may gain quoted evidence, and the banks would map to your actual bullets
- **Interviewer names (director, staff engineers, PM, VP)** → an interviewer read, persona weights from their public footprint, and at least one reverse question per round tied to their path
- **Recruiter notes on the panel's format or any pre-work** → a build section for any graded exercise, such as a system-design or planning case
- **Your prep hours before each round** → a prioritized prep schedule for each round
- **Your answers to the slots on F1 to F5, F7 and F8, given here rather than in a drill** → those rows regenerate with your own words as evidence
- **The full posting** → rows and JD questions for any requirement the summary leaves out, such as location, on-call expectations or tools
- **What could back the 60%, such as an on-call rotation report or pager-load export you can describe** → C1, H1 and F2's confidence could rise from medium
- **A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; needs search permission)** → a grounding brief on Larkfield's strategy, org context and loop reports
- **A tuesday-dossier.md from an earlier underwriting session** → an evidence-derived highest-ROI objection and a confirmed prohibited-claims list
