No dossier present. Reading the references.
I've built your prep pack: 21 practice questions with answer guidance drawn from your background, plus a values cheat sheet, questions to ask Tobias, and a plan for tonight. I assumed this is your hiring-manager interview. Saltmarsh's careers page describes it as a 60-minute "Outage Hour" with the hiring manager, with no take-home, and your 60 minutes with Tobias fits that.

**What the hour holds, per the careers page:**
- **First half:** a role-play exercise on a simulated server outage during a live event. Question A1 rehearses it, and it's the first thing to practise tonight.
- **Second half:** a values conversation. Saltmarsh publishes three values: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. Your release checklist fits the third almost word for word, because that value says each release should leave the checklist better than it found it.

**Two things I found that matter:**
- **Project Larkspur.** In September Saltmarsh announced that both titles will move to a season-pass model, with one shared events calendar from February 2027. This sharpens the objection you're most likely to face: you ran one title's weekly calendar, and this job is two titles on one calendar. Question C1 is that objection, and it's the highest-value question to practise.
- **Tobias's background.** He was a QA lead before running live ops. His GDC 2026 talk, "Patch Notes Are a Promise", argued that a live team is judged by how often its patch notes describe what actually shipped. Expect close interest in your checklist and in how honest your player communication is.

**Where you're thin:** you said you've never led a team and never worked on a game with in-app purchases. The pack gives you a plain one-sentence answer for each. I couldn't tell from the announcement whether the season pass is a paid purchase, so one of your questions for Tobias asks.

The pack lists the claims it won't help you make, like saying you ran events across several titles or owned post-event reviews. It marks the places where only you know the answer. Fill those from what actually happened, or say plainly that it didn't happen.

Files are in `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-canned-18b78daf`:
- saltmarsh-games_live-operations-producer_interview_pack.md

Say the word and I'll play the hiring manager on the outage exercise, or the skeptic on C1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. This is the hiring-manager interview.
**Round:** Friday, 60 minutes. Saltmarsh's careers page calls it the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, followed by a values conversation. There is no take-home (see Sources).

---

## How to use this pack

- **Personas** describe how a question gets asked: the style and register. **Types** describe what the interviewer is scoring. You will meet both on Friday.
- Type key:
  - **VAL**: whether your past behaviour shows Saltmarsh's *published* values.
  - **EXP**: whether what you say about your experience holds up under follow-up, and which parts were actually yours.
  - **JD**: whether you can do the job as the posting lists it, including the parts where you have gaps.
  - **CO**: how well you know Saltmarsh's current plans, and whether you can think at the studio's level.
  - **CASE**: a live problem from the role, which you reason through on the spot.
- Question IDs use a letter per persona (A, B, C, D, E, G, H). The letter F is kept for fit-snapshot rows (F1 to F9) so the two never get mixed up.
- The guidance is scaffolding, not a script. Say it in your own words. An **answer slot** marks a place where only you know the truth. Fill it from what actually happened, or say plainly that it didn't happen.

## Prep triage: you have tonight

1. **A1, the outage tabletop.** Say the structure out loud twice, then run it once against a timer. This is half the hour.
2. **C1, the highest-ROI question in the pack.** Rehearse the hold and both follow-ups until they feel boring.
3. **The values cheat sheet, plus B1 to B3.** Pick your story or scaffold for each of the three values by name.
4. **D1, your retention numbers.** Know what you can and can't say about how they were counted.
5. **Reverse questions.** Pick three, and make sure R1 is one of them.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a weekly content-drop calendar for your main title. It does not describe live events across two titles, so the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title events line makes a probe on events and on more than one title likely. If any of those drops were time-limited events, or the calendar touched another title, say which in your own words. If neither is true, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [grounded] | discovery | Your quote is about leading a team, and this line doesn't ask for that. Your material says nothing about coordinating across disciplines. Answer slot: expect a probe on which of those four disciplines you worked with on each drop. If you worked across any of them, name which ones and say how, in your own words. If you didn't, say so plainly. If leading comes up, the plain acknowledgment is: "I haven't led a team." |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly numbers. It does not say you owned a post-event review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe likely on whether drops were reviewed after they ran. If any review of a drop was yours, say what it looked at. If there was no such review, or it wasn't yours, say so plainly and stay with the monthly numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist. It does not say you managed it. Words: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage … with QA" makes a probe likely on who ran the checklist each release. If you ran it with QA, say how. If QA ran it, or it was run some other way, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Four years clears the number. Your material doesn't use the words "live service". Answer slot: if the puzzle game was run as a live service for a live player base, say so in your own words. If it wasn't, say so plainly and stay with the weekly content-drop calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but nothing sits behind this line yet, so expect a probe. Lead with it in the quote's own terms: weekly, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a prober will ask how the numbers were counted. Answer slot: if you calculated them, say how, in your own words. If someone else did, or you don't know how they were counted, say so plainly and stay with presenting them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your evidence is a written document that people still use. Say it in the quote's words. A5's player-facing line is where the interview tests your writing live |
| F9 | Season-pass model for both titles from February 2027 (Project Larkspur news post, read only as a search snippet; not a JD line) | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | This row is a derivation. The snippet doesn't say whether the pass is bought in-app, so R2 asks. If it is, the plain acknowledgment is: "I haven't worked on a game with in-app purchases." After that, say how you would learn it, framed as a plan and never as something you've done. Add nothing that makes the gap feel smaller |

## Reading the interviewer

| Signal | Source | Provenance | What it means for Friday |
|---|---|---|---|
| Head of Live Operations at Saltmarsh, previously a QA lead at a console studio | GDC 2026 talk listing (Sources) | [grounded] | He has worked on QA's side of a release. Expect your checklist and how you work with QA to be read closely. Use F4's own words, "Wrote the release checklist our QA team still uses.", and don't go beyond them. Your material shows no QA-to-live-ops move of your own, so there is no shared career jump to point to |
| His talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk listing (Sources) | [grounded] | In A1 and A5, keep "what is fixed" separate from "what we hope". This is also the value Ship the Patch Not the Promise, so one habit serves both halves of the hour |
| Public talk on a single theme | GDC 2026 talk listing (Sources) | [inferred] | Recurring themes tend to come back as questions. Expect accuracy of player communication to come up, and R1 asks him about it directly |

## Persona table

| Persona | How it shows up on Friday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The outage tabletop, plus planning and diagnosis problems | **Highest (5 questions).** The careers page makes a tabletop half the hour, and hiring managers lean this way by default | Clarify, then set the objective, segment, give your approach, name metrics and risks. Think aloud. Challenge one premise per case, respectfully |
| Values / Behavioral | The second half: three values, by name | **High (4).** The careers page names a values conversation in this interview | Use the cheat sheet. Say "we" for context and "I" for your contribution. Where your material carries no story, say so rather than invent an ending |
| Skeptic | Quiet probing of F1, F2, F3 and F9 | **Mid (3).** Hiring managers lean this way by default, and the snapshot has real gaps | Rehearse C1 until it's boring. Bridge only from your quotes, and give a concrete ramp plan |
| Data-Driven Prober | "How were those retention numbers counted?" | **Mid (3).** The JD's KPI and retention lines, plus F7 | Know what you can and can't say about the numbers you presented. "I don't know how they were counted" is an honest answer |
| Pressure | Interruptions and time-boxes inside the tabletop | **Low (2).** A simulated outage is time pressure by design. This is inferred from the format, not documented | Pause, restate the question, hold for two follow-ups, then concede something specific |
| Conversational | The opener, and casual asides about games | **Low (2).** Any interview opens this way | A 90-second journey arc. Treat casual questions as scored |
| Peer Evaluator | Seams between design, engineering and community | **Low (2).** It's a single hiring-manager interview, but the JD's coordination line brings seam questions in | Propose principles for handling seams rather than claiming you know Saltmarsh's. Show you can hold a line and stay tactful |

## Question banks

### A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event on one of our titles and the event server goes down. Walk me through the first hour." | CASE | [grounded] | Clarify first: who is affected, whether progress or rewards are lost, and what's on the line for the event. Then stabilise: who is on call, and what engineering needs from you. Then protect players: pause timers or extend the event (Players Before Plans). Then communicate: tell players what's known and what's being done, with no ETA you can't keep (Ship the Patch Not the Promise). Keep a decision log. Close with the post-incident review, and put the lesson into the release checklist (Leave the Build Greener). The question asks nothing about your past, so the guidance makes no claim about it | The careers page names this exact format, and it is half the hour. CASE because it scores structure under a live problem. Tying each step to a value bridges into the values half |
| A2 | "From February, both titles share one events calendar under Project Larkspur. How would you plan the first quarter?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Anchor in the quote's terms: a weekly content-drop calendar, your main title, two years. Then say what changes here: two titles, two player bases, one calendar. Structure your answer around clashes, shared resources, which title gets priority in a busy week, and what you'd measure. Ask one clarifying question about how the season pass fits the event cadence | The studio's current strategy (Sources). CO with CASE delivery. F1 is the row this presses on |
| A3 | "Day-7 retention for players who joined during the event is down against the last event. Diagnose it." | CASE | [generic] | First clarify the definition and the cohort. Compare like with like: event length, content, how players were acquired. Segment: new versus returning players, title, platform. Rule out instrumentation and release changes before forming hypotheses. End with what goes in the post-event review and what you'd change next time. No claim about your past | This scores the JD's KPI and post-event review line live. It is generic because it is a pattern for this kind of problem, not a fact about Saltmarsh |
| A4 | "Art for next week's event update will land three days late, and engineering's freeze is Wednesday. What do you do?" | CASE | [generic] | Clarify what's late and whether it blocks the update. Give options: cut scope, swap in ready content, or move the date. Name who decides and who you tell (design, art, engineering, community). Explain what you'd say to players. No claim about your past | This tests the JD's coordination line as a decision instead of a record, which suits F2's thin evidence |
| A5 | "QA finds a bug in the event update the afternoon before release, and the patch notes are already drafted. Talk me through it, then draft the line to players." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Work out severity with QA, then make the call to hold, ship with a fix, or ship with the feature off. Rewrite the notes so they describe only what will ship. Say the player line aloud in two sentences. You can connect it to "I wrote the release checklist our QA team still uses." without claiming you've handled this exact situation before | His talk's theme, the checklist line in the JD, and the JD's written-communication line, all in one question. F4 and F8 are the rows |

### B: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. The calendar you ran is where a time like this would sit. It needs a plan, a signal from players, and a change you made because of it. If no such time comes to mind, say so plainly, then talk about the calendar you ran or how you would handle it | This is a published value, asked by name. F1 and F6 carry the calendar, but no story about a disagreement |
| B2 | "Ship the Patch Not the Promise: when have you had to say what was actually built, rather than what was hoped?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. A good story needs something announced or expected, the gap between that and what was ready, and what you said. If no such time comes to mind, say so plainly, then give the nearest thing from the calendar or how you'd handle it | A published value that also matches the interviewer's talk, so expect it. F6 is the nearest row |
| B3 | "Leave the Build Greener: what did you leave better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats are that you wrote it and QA still uses it, in your own words. Answer slot: the value's wording, "the checklist better than it found them", makes a probe on later changes likely. If you revised it after releases, say what changed and why. If you didn't, say so plainly and stay with having written it | Your strongest value match, because the value names the checklist itself. F4 |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. You need a named stake, a moment where you didn't soften the message, and a working relationship that survived it. Your monthly presentations to the studio head are where such a time could sit. If no such time comes to mind, say so plainly, then describe how you would handle it | A common values stem that pairs with Ship the Patch Not the Promise. F3 is the nearest row |

### C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You ran the weekly content-drop calendar for your main title. This job plans live events for two titles, and from February it's one shared calendar. Why are you ready for that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **This is the highest-ROI rehearsal in the pack.** Hold to the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Say its scope yourself before he does: it was your main title's calendar, and it ran weekly. Answer slot: if any of it touched events or another title, say which. If it didn't, say so plainly. Then give a 30-day ramp plan, as a plan: learn both titles' event history, the shared calendar, and who owns which decisions. **Follow-up 1:** "Two titles is a different job." Hold by coming back to the cadence you ran, and agree that the difference is real. **Follow-up 2:** "What would you get wrong first?" Answer slot: name, in your own words, the part of a two-title calendar you'd expect to learn hardest. Don't add experience to make the gap smaller | F1 is the biggest distance between your material and the JD, and Larkspur makes it sharper, so this objection will come in some form. JD because it scores the headline requirement |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." "never worked on a game with in-app purchases" | Pick the one that's actually true. One option is the post-event review: you presented the monthly retention numbers, and anything beyond that is F3's answer slot. If the season pass comes up, use the plain acknowledgment: "I haven't worked on a game with in-app purchases." Follow either with a concrete plan. Don't choose "leading a team", because the JD doesn't ask for it | A Skeptic stem that hiring managers use. F3 and F9 are the honest candidates for your answer |
| C3 | "Each update here needs design, art, engineering and community lined up. How have you done that?" | JD | [grounded] "Never led a team" "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you worked with any of those disciplines on the calendar, say which and how, in your own words. If you didn't, say so plainly and stay with the calendar you ran. If he asks about leading, the plain acknowledgment is: "I haven't led a team." Keep coordinating and leading separate: the JD asks for the first | F2's evidence is thin and the JD names four disciplines, so expect this. JD because it's a listed responsibility |

### D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. What was in them, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start with the quote: you presented them to the studio head, monthly. Answer slots, each in your own words: how they were counted, what they were sensitive to, which assumption behind them you'd defend least, and which part was yours. "I don't know how they were counted" is an honest answer. Don't name a metric or method you didn't use | F7 is your retention evidence, and it is where a prober goes first. EXP because it tests what you actually did |
| D2 | "If you ran our post-event review, which retention numbers would you put in it, and why?" | JD | [generic] | Structure it: what the event was meant to change, the cohort, the comparison point, two or three numbers, and the decision each one informs. Name one number you'd leave out and why. No claim about your past | This covers the JD's post-event review line as a forward-looking problem. It's generic because Saltmarsh's actual KPIs aren't public |
| D3 | "Tell me how your puzzle game ran as a live service." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Lead with the quotes: four years as an associate producer at a puzzle-game studio, and the weekly content-drop calendar. Answer slot: if the game was run as a live service, describe how in your own words. If it wasn't, say so plainly and stay with the weekly drops | This covers the "3+ years live-service" requirement. F5 is a discovery row, so the honest answer needs to be ready before Friday |

### E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who's already run a season pass?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "never worked on a game with in-app purchases" | Pause, then hold on three quotes: the weekly calendar for two years, the checklist QA still uses, and the monthly retention numbers to the studio head. If the pass is a paid product, concede plainly: "I haven't worked on a game with in-app purchases." Then give one line of plan. Don't fold on the three things you did | A time-boxed version of F9 and F1. JD with Pressure delivery |
| E2 | Mid-tabletop: "The studio head wants the event extended two days. Engineering says the fix isn't safe until Monday. Thirty seconds." | CASE | [generic] | Restate the conflict. Ask the one question that decides it, such as whether the extension needs the fix. Make a call, name the risk, and say who you'd tell. Don't split the difference just to keep everyone happy | An interruption is likely inside an outage format. It's generic because it's a pattern, not documented Saltmarsh practice |

### G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made of the four quotes, in this order: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the last two years, the checklist QA still uses, and the monthly retention numbers to the studio head. Answer slot: why live ops, and why Saltmarsh now, in your own words | Almost certainly the opener, and still scored. It draws on F5, F6, F4 and F3 |
| G2 | "What live events in mobile games have caught your eye lately?" | CO | [generic] | Pick one you have actually played. Say what it did on its calendar and what you'd take from it. Don't comment on Saltmarsh's titles unless you've played them | This tests genuine interest in a casual register. It's generic because it depends on what you play |

### H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Community wants to announce the event date now, and engineering won't commit. You sit between them. What do you do?" | CASE | [generic] | Propose a principle for the seam: announce only what's built (Ship the Patch Not the Promise). Give community a holding line and a date for the date. Get engineering's commit criteria in writing. No claim about your past | The JD's coordination line plus a published value. It's generic because it describes a pattern |
| H2 | "How do you handle credit when an update spans teams?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Use "we" for the update and "I" for your part. The checklist is a fair "I": you wrote it, and QA uses it. Selection scaffold for a shared update: if no such moment comes to mind, say so plainly and describe how you would handle it | A Peer stem the JD's coordination line makes plausible. F4 |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | C1, A2, B1 |
| Coordinate design, art, engineering and community | C3, A4, H1 |
| Own the post-event review and its KPIs | A3, D2, C2 |
| Manage the release checklist with QA | A5, B3 |
| 3+ years producing live-service games or apps | D3, G1 |
| Experience running a content calendar | C1, A2 |
| Comfortable with player-retention metrics | D1, A3, D2 |
| Clear written communication | A5 |

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players conflict, the players win | Selection scaffold, set in F1's calendar ("I ran the weekly content-drop calendar for our main title for the last two years."): a plan, a player signal, and a change you made. If no such time comes to mind, say so plainly and explain how you would handle it (B1) |
| Ship the Patch Not the Promise | Announce only what is built | Selection scaffold: an expectation, the gap between it and what was ready, and what you said. If no such time comes to mind, say so plainly and explain how you would handle it. In the tabletop, A1 and A5 show this live |
| Leave the Build Greener | Each release leaves the code and the checklist better | F4: "Wrote the release checklist our QA team still uses." The answer slot for later revisions is in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How do you track that here?" | It ties to his public work and shows you researched him, not just the studio |
| R2 | "Under Larkspur, is the season pass a paid purchase, and how do event KPIs change once both titles share one calendar?" | You need this answer (it settles F9), and it reads as diligence |
| R3 | "Larkspur replaces per-title event teams with one live-ops group. Where does this role sit, and what does February look like for it?" | It shows you read the announcement and are thinking about the transition this hire is for |
| R4 | "What does a strong post-event review look like here? Who reads it, and what decision has one changed?" | The JD says you'll own the review, so this asks what good looks like |
| R5 | "Who owns the release checklist today, and how does QA want to work with this role on it?" | It speaks to his QA background and to the "manage … with QA" line |
| R6 | "Coming from QA, what did you have to unlearn when you moved into live ops?" | It's tied to his career path and turns the interview into a conversation between peers |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated: "Never led a team" | "I haven't led a team." |
| Has worked on in-app purchases or a paid season pass | A negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." |
| Ran live events across multiple titles | An inflated form of F1 | F1's quote at its own scope. The pack's observation: your material describes a weekly content-drop calendar for your main title. C1's answer slot stays inside that calendar |
| Owned post-event reviews or KPIs | An inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says you presented monthly numbers. The answer slot asks only about reviews of drops |
| Built or calculated the retention analysis | An inflated form of F7 | F7's quote at its own scope. D1's answer slots ask how the numbers were counted, in your words |
| Managed the release process with QA | An inflated form of F4 | F4's quote at its own scope. The pack's observation: your material says you wrote the checklist |

## Sources

Provided documents: the JD and your background, both pasted in your message.

Searches:
- `Saltmarsh Games values` → https://saltmarshgames.com/values
- `Saltmarsh Games interview process producer` → https://saltmarshgames.com/careers/interviewing
- `Saltmarsh Games mobile studio news 2026` → https://saltmarshgames.com/news/project-larkspur (September 2026; read as a snippet only)
- `Tobias Wrenfield Saltmarsh Games` → https://talks.gdconf.example/2026/patch-notes-are-a-promise (read as a snippet only)

Fetches:
- https://saltmarshgames.com/values: the three values and their definitions
- https://saltmarshgames.com/careers/interviewing: recruiter call, then the Outage Hour (tabletop followed by values conversation), with no take-home

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | The values cheat sheet and B1 to B3, with all three values by official name |
| 2. `Saltmarsh Games interview process producer` | yes | It established the loop: this one session is the hiring-manager tabletop plus values. It set the persona weights and the A bank |
| 3. `Saltmarsh Games` strategy / recent news | yes | Project Larkspur. It moved A2, C1, F9, R2 and R3 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, R1, R5 and R6 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → reading the full Larkspur post and Tobias's talk, which would settle F9 and sharpen A2, A5 and R1
- Your actual CV → more of your own sentences to quote, which could open story maps where B1, B2, B4 and H2 are currently scaffolds
- Your answers to the answer slots in F1 to F5 and F7 (events or a second title, which disciplines you worked with, reviews of drops, who ran the checklist, live-service status, how the numbers were counted) → those rows get regenerated, and C1, C3, D1 and D3 get firmer guidance
- Any recruiter prep email → coverage of any focus areas they named
- The checklist itself, a calendar export, or a retention deck you presented → the field's inspectable artifacts. Any of them would raise F4, F6 or F7 from `medium` to `high`
- A `tuesday-dossier.md` from an underwriting pass → an evidence-derived highest-ROI objection and a prohibited list checked against confirmed evidence. It is not required for anything here
