I'm running the default research pass on Kelverton Rail and the panel before I build your pack.
I've built your prep pack and saved it as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. It's built from the recruiter's email and your background only. Web search was blocked in this session and you didn't share a JD or the report, so anything about Kelverton itself is marked `[generic]`.

- **The POV:** your panel already has the report, because their own strategy team wrote it. So the build section has you do three things with it: agree with one finding, argue against one, and name one thing you deliberately wouldn't do. There are three theses to choose from, each with the concession you have to make. Each one ends on what operators get, as the recruiter asked.
- **The question you most need to rehearse is C1:** "Your £4M is influenced. If I hand you a number you own, what happens?" Say "I've never carried a direct quota, only influenced revenue" before Ross asks. Then hold through two follow-ups without upgrading "influenced".
- **The 4 hours:** 75 minutes on the POV out loud, 40 on C1, 30 on commercials, 30 on the rail gap, 20 on your opening "walk us through your journey" answer, 15 on reverse questions, then a 30-minute full run-through.
- **Off-limits claims:** five things the pack won't coach you to say. These include rail sales experience, train-operator work beyond your bus and light rail planning, and £4M of revenue described as anything other than "roughly" and "influenced".

I can play Ross on C1 as a live drill with follow-ups that react to your answers.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I'll convert it.

Do you have the JD text? It would turn three of the six fit rows from role-family guesses into quoted requirements. Will you allow web search so I can rerun the research on Kelverton's values, recent news, and Deepa's and Ross's public profiles? A deeper pass of up to 6 more searches is also available if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel prep pack

**Round:** 60-minute panel on Tuesday. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). It opens with a 15-minute spoken POV, no slides, then Q&A. The recruiter says Ross will push on commercials.
**Built from:** the recruiter's email as you quoted it, and the background in your message. There was no JD. Web research was attempted and refused in this session (see Sources), so every company-specific line here is either your own material or marked `[generic]`.

---

## How to use this pack

- **Personas** describe how a question is asked: the register and the pressure behind it. **Types** describe what is being scored.
- Type key:
  - **VAL**: whether past behaviour shows the company's published values
  - **EXP**: whether your stated experience holds up under scrutiny, including what was actually yours
  - **JD**: whether you can do the stated job, gaps included
  - **CO**: company and strategy homework, and whether you can think at the company's level
  - **CASE**: a live problem from the role, reasoned through out loud
- Question IDs go by persona: A Case, B Skeptic, C Pressure, D Prober, E Conversational, G Values, H Peer. **F# always means a fit-snapshot row**, which is why no bank uses the letter F.
- The guidance is scaffolding, not a script. Say it in your own words. An **answer slot** is a place only you can fill. If the thing it asks about did not happen, or was not yours, the honest branch is the answer.
- All proposed language in this pack is **pending your approval**. That covers the snapshot's bridge wording, the POV build and the bank guidance.

---

## Prep triage: 4 hours over the weekend

| Order | Block | Time | What done looks like |
|---|---|---|---|
| 1 | POV build (section "Graded deliverable") | 75 min | Pick your three theses and fill each report slot from the report you read. Say it aloud twice against a 13-minute timer |
| 2 | C1, the highest-ROI rehearsal, plus D1 | 40 min | Say the influenced-revenue limit before Ross asks for it, and hold through both follow-ups aloud |
| 3 | The commercials block: C3, D3, A5 | 30 min | One partner commercial model you can sketch in two minutes, and a sizing logic that names its inputs rather than inventing them |
| 4 | The rail gap: B1, B2, C2 | 30 min | One plain sentence on the gap, then your adjacent evidence at its real scope, then the plan |
| 5 | E1 arc | 20 min | A 90-second journey that links consulting, the ISV channel and this role without stretching any of them |
| 6 | Reverse questions | 15 min | Choose three, with at least one for each panellist |
| 7 | Full run-through | 30 min | The POV, then C1, out loud and timed. A live drill works well here |

Everything else in the pack is insurance.

---

## Fit snapshot

Requirements come from the recruiter's own words, quoted, or are marked `[generic]` where no JD was given. Proposed wording here is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter | "running the ISV channel — took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material shows a partner channel grown at a payments company. It does not show operator partnerships in rail. Keep the words at that scope: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the recruiter's 18-month framing makes a probe on how the channel grew over time likely. If you chose which partners to add, or in what order, say how in your own words. If there was no such choice, or it was not yours, say so plainly and stay with the 6 to 40 |
| F2 | "Please land on what it means for the operators themselves" — recruiter | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning. It does not say mainline train operating companies or scheduling software, and the words stay at that scope: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: the operator close makes a probe on what operators cared about in that work likely. If the planning work put you alongside operator teams, say how in your own words. If it did not, say so plainly and stay with the planning work |
| F3 | Credibility selling software into UK rail operators, a role-family requirement and not a quoted one | "Never sold into rail specifically" — your message | none | [grounded] | capability | You stated this gap and wording cannot close it. Words: "I haven't sold into rail specifically." Follow with how you would learn it, said as a plan and never as a past. Add nothing to make the gap feel smaller |
| F4 | "Ross will push on commercials" — recruiter | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Influenced revenue is next to commercial ownership. It is not the same thing. Keep both qualifiers every time: "roughly" and "influenced". Answer slots, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you don't know how it was counted, say so plainly |
| F5 | Owning a direct revenue target, which senior partnerships roles at software vendors often carry; a role-family requirement and not a quoted one | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | You stated this gap. Words: "I've never carried a direct quota, only influenced revenue." Then say, as a proposal, how you would want to be measured here. Never a claim to quota experience |
| F6 | Seniority in partnerships for a Senior title, a role-family requirement and not a quoted one | "9 years in partnerships" — your message | medium | [grounded] | none | No gap. Lead with the plain number in the quote's own terms |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1, 18-month operator partnership direction | POV build; A1; A2; A4; B2; C4; D2 |
| F2, what it means for operators | POV close; A3; A5; G2 |
| F3, selling into rail | B1; B4; C2 |
| F4, commercials | C1; C3; D1; D3; A5 |
| F5, direct revenue target | C1; B4; H2 |
| F6, partnerships seniority | E1; C2 |

---

## Graded deliverable: the 15-minute operator-partnerships POV

**The ask, in the recruiter's words:** "present a short POV on where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", "Please land on what it means for the operators themselves".

**Facts about you to build on:**
- F1: "running the ISV channel — took it from 6 partners to 40"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F4: "roughly £4M of influenced revenue"

**The one fact about the situation that matters most:** the market report came from Kelverton's own strategy team, so Deepa and Ross have it too. If you recite it, it scores as homework. Use it in three moves: name one finding you agree with, to show you read it; make one argued departure from it; and give one anti-pick, something you would deliberately *not* do. The report's contents are not in this pack, so the theses below carry slots for you to anchor from it.

**Suggested shape, about 14 minutes with room for interruption:**
1. **Frame (2 min).** Give your one-sentence thesis. Then nod to the consensus: "Your strategy team's report says ___, and I agree, because ___." Fill this from the report.
2. **Three moves (8 min).** Pick from the theses below, one sentence each, with the operator benefit attached as you go.
3. **The anti-pick (1 min).** Say what you would not do, and why.
4. **What it means for operators (2–3 min).** This is the close the recruiter asked for. Restate each move as what an operator gets.
5. **What you'd need (1 min).** The seam with whoever owns operator relationships today, and how you'd want to be measured. This sets up C1 on your terms.

**Thesis options.** Each has a mandatory concession, and is pending your approval.

| # | Thesis | Mandatory concession | What it means for operators | Provenance |
|---|---|---|---|---|
| T1 | Depth over count. In a market with a small number of large operator customers, aim the 18 months at a few integration partners operators actually use, not a long partner list | It breaks from the pattern in F1, "running the ISV channel — took it from 6 partners to 40". Say that yourself, and say breadth may still suit niche add-ons. Check the report for how many operators and partners there actually are before you rely on "small number" | Fewer, better-tested integrations around the schedule data they already depend on | [generic] the market-shape premise is a role-family pattern; anchor it to the report's own figures or drop "small number" |
| T2 | Operators as design partners. Bring one or two operators in to shape a partner integration before it is offered to the rest | Risk of bespoke work for one operator, and of other operators reading it as favouritism. Name a rule for keeping it general | A say in what gets built, and earlier access to it | [generic] |
| T3 | Commercials that track operator use. Structure partner offers so operator spend follows adoption, not signature | Slower or lumpier revenue. Ross will push here, so offer a hybrid with a base fee plus a usage element, and say what you'd need to learn about current pricing first | Lower up-front risk, and paying for what is actually live | [generic] |
| Anti | Do not put a reseller layer between Kelverton and operators | If the report shows operators buying through integrators or consultancies, say you'd revisit this | No extra party between them and their scheduling vendor | [generic] |
| Divergence | Pick the report finding you most disagree with, or think is over-weighted, and say why in one sentence. Answer slot: use only what the report actually says. If nothing in it strikes you as wrong, pick the finding you think is under-weighted instead | Name what would change your mind | Tie it back to an operator outcome | [generic] built from your own reading of the report, which is not in this pack |

**Differentiation.** Most candidates will present a partner list. You can present a partner *posture*: depth, operators as co-designers, and commercials tied to use. That ties directly to what Ross will push on. Your F2 background is the only place in your material that speaks to operators, so use it at its stated scope and let the panel draw the inference.

---

## Reading the panel

This draws only on the recruiter's email. Public profiles were not researched because search was refused.

| Panellist | What the recruiter said | Practical implication | Source |
|---|---|---|---|
| Deepa | "VP Partnerships, your future manager" | Expect hiring-manager weighting: can you do the job, and where are you thin. She will likely own the follow-up questions on the POV | Recruiter email |
| Ross | "Commercial Director", "Ross will push on commercials" | Expect pressure and probing on money: how your numbers were counted, partner commercial models, and what you'd be accountable for | Recruiter email |

---

## Persona table

The weights are blended across the two panellists, as panels are. The loop is set by the recruiter's words: one 60-minute session, a POV and then Q&A. No values-style round is named, so there is no values cheat sheet.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | Follow-ups on the POV: what first, what you wouldn't do, how you'd measure it | High. Both panellists' roles prime it, and the POV invites it | Clarify, then objective, approach, metrics and risks. Think aloud. Challenge one premise per case, respectfully |
| B Skeptic | The rail gap, the ISV-to-operator transfer, why now | High. Deepa is buying capability and de-risking gaps, and F3 is your clearest gap | Rehearse the gap sentence until it's boring. Use only your stated adjacent evidence. Give a concrete ramp plan |
| C Pressure | Ross on influenced revenue against owning a number | High. "Ross will push on commercials", and F4 and F5 are exactly where he'll push | Pause and restate. Hold what your quotes carry through two follow-ups. Concede the stated gap plainly and early |
| D Data-Driven Prober | Counting questions on £4M and the 6 to 40 | Medium. These are commercial-director questions about your two headline numbers | Know what you can and cannot say about how each number was counted, and say plainly where you don't know |
| E Conversational | The journey opener, and "what did you make of the report" | Low to medium. Panels often open warm, and the warm questions are still scored | A pre-built 90-second arc |
| G Values/Behavioral | Generic behavioural probes | Low. No values round is named | Selection scaffolds only |
| H Peer | The seam with whoever owns operators today, and credit-sharing | Low to medium. Partnerships almost always sits beside a sales function | Seam principles, not pretended knowledge of their org chart |

---

## Question banks

Ordered by weight. Proposed guidance is pending your approval.

### A. Case/Strategist (Deepa and Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Say we hire you. What do you do in your first 90 days to find out whether this POV is right?" | CASE | [generic] | Say what you'd need to know first: which partners exist today, which operators use them, and what the report leaves open. Then name the conversations you'd hold, with operators, with whoever owns those relationships and with Ross's team. End with one test that would tell you that you were wrong. This makes no claim about your past | The natural follow-on to any 18-month POV. CASE because it scores structure, not a record |
| A2 | "Which partner would you turn down even if they came to us?" | CASE | [generic] | Your anti-pick, plus a criterion: a partner that adds a layer between Kelverton and the operator, or that operators would not actually use. Give the rule, then one example type | Tests whether you can say no, which is half of partner strategy. It also rehearses the anti-pick from the POV |
| A3 | "An operator calls: a partner's integration broke their schedule publish just before a timetable change. What do you do in the next 24 hours?" | CASE | [generic] | Order it: operator first (contain, communicate, escalate); partner next (root cause, accountability); then the process change that stops a repeat; then what you'd tell the operator afterwards. This makes no claim about your past | Lands the "what it means for operators" theme in a live problem. Pure CASE |
| A4 | "You've read our strategy team's report. Where do you think it's wrong?" | CO | [generic] | Your divergence from the POV, said with respect: what it gets right, the one point you'd weight differently and why, and what evidence would change your mind. Answer slot: use only what the report says. If you don't think it's wrong anywhere, say which finding you'd under-line rather than invent a disagreement | The panel shares the document, so this is a likely and sharp test of judgement over recall |
| A5 | "Month 18. How do we know operator partnerships are working?" | CASE | [generic] | Pair one operator-side measure (adoption or use of partner integrations) with one commercial measure (revenue the partnership touches, defined the way Kelverton counts it) and one leading indicator. Say you'd agree the definitions with Ross up front. This makes no claim about your past | Bridges the operator close and the commercials push. CASE delivery with JD content |

### B. Skeptic (mostly Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Why would an operator's leadership take you seriously early on?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Concede first, plainly: "I haven't sold into rail specifically." Then the adjacent work at its own scope: five years of transport consulting on bus and light rail network planning. Answer slot: if that work put you alongside operator teams, say how in your own words; if not, say so and stay with the planning work. Then the plan: who you'd learn from in the first weeks and what you'd listen for. Let them draw the inference | The negative is your own statement, so the question can name it. F3 is the gap and F2 is the only bridge, which is why it is likely |
| B2 | "Payments ISVs and train operators are very different. What from your channel actually carries over, and what doesn't?" | EXP | [grounded] "running the ISV channel — took it from 6 partners to 40" | Say what you ran, in the quote's terms. Answer slot: name what you'd keep doing from that channel, in your own words; if you can't point to a specific practice, say what you learned instead. Then the part that doesn't carry over, as your analysis of this market: few large buyers, not many small ones. That links to T1 | F1's transferability limit, asked head-on. EXP because it tests what was actually yours |
| B3 | "Why leave payments for rail, and why now?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships" | The arc from consulting to partnerships to this role, each step at its stated scope. Answer slot: give your actual reason for moving now, in your own words. If part of it is a push rather than a pull, say the pull first and keep the push short and true | A motivation-consistency probe. Your F2 history makes the "why" credible if you say it plainly |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Pick one stated gap and name it plainly, using F3's or F5's words. Then a specific ramp plan. Don't list both unless asked, and never pick a fake weakness | The Skeptic's classic question. Rehearsing it stops a defensive answer |

### C. Pressure (mostly Ross)

**C1 is the highest-ROI rehearsal in this pack.** Your two headline numbers are "influenced", and the person pushing on commercials will notice.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your £4M is influenced revenue. If I hand you a number you own, what happens?" | JD | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | **Say the limit before he does:** "I've never carried a direct quota, only influenced revenue." Then the figure at its own scope: roughly £4M, influenced. Answer slot: say which part of it was yours and how it was counted, in your own words; if you don't know how it was counted, say so. Then a proposal, not a past: how you'd want the number defined here, and what you'd need from sales to own it. **Follow-up 1:** "So you've never been accountable for a number?" Hold: repeat the acknowledgment, then say what you were measured on, in your own words. Don't upgrade "influenced". **Follow-up 2:** "Why should I take that risk?" Concede the risk explicitly, then offer a de-risking structure, such as an agreed 6-month target definition. Don't fold into apology | F4 and F5 together are the panel's most predictable objection, and the recruiter flagged Ross on commercials. It gets the deepest rehearsal |
| C2 | "Sixty seconds: why you over someone who's sold to operators for a decade?" | JD | [grounded] "9 years in partnerships"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "Never sold into rail specifically" | Concede in one clause ("I haven't sold into rail specifically"), then the combination at its stated scope: nine years in partnerships plus five years of bus and light rail network planning. Then one line tying it to your POV. Stop at 60 seconds | A time-boxed composure test on F3. The concession first takes the sting out |
| C3 | "Walk me through the commercial model you'd put on a partner integration. Who pays whom?" | CASE | [generic] | Lay out the options and choose one: referral fee, revenue share, co-sell with joint pricing, or a usage-linked model (T3). Say what the operator pays and what the partner earns. Answer slot: if your ISV channel ran on a particular model and it was yours to shape, name it in your own words; if it wasn't yours, or you don't know how it was set, say so plainly and reason from first principles | Raised directly by "Ross will push on commercials". CASE because he wants reasoning live |
| C4 | "6 to 40 partners. How much of that was actually you?" | EXP | [grounded] "running the ISV channel — took it from 6 partners to 40" | Hold what the quote carries: you ran the channel, and it went from 6 to 40. Answer slot: say which part of the growth was yours (sourcing, signing, onboarding or other) in your own words; if others did parts of it, say who and how, plainly. "We" for context, "I" for contribution | The persona's standard attribution stem, applied to F1's headline number |

### D. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was the £4M counted?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slots, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you'd defend least, and which part was yours. Name the weakest assumption before he does. If you don't know how it was counted, say so plainly; that is an honest answer. The pack supplies no method | The defend-the-number rule for F4. A figure explained in words you can't repeat under a second question is worse than none |
| D2 | "Of the 40, how many actually produced revenue?" | EXP | [grounded] "running the ISV channel — took it from 6 partners to 40" | Answer slot: this is the what-it's-sensitive-to probe. If you know the split, say it; if you don't, say so plainly and say how you'd find out. Never estimate a figure you didn't track | F1's count is a magnet for a quality-over-quantity probe, especially after T1 |
| D3 | "What would partner-influenced revenue look like for us in year one?" | CASE | [generic] | Build the logic aloud: number of operators, likely attach rate of a partner integration, price per integration, and time to live. Say which inputs you'd need from Kelverton or the report, and put no numbers on any you don't have. Answer slot: use the report's figures only if it states them | A live sizing exercise on Ross's ground. Rewards naming inputs over guessing outputs |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "running the ISV channel — took it from 6 partners to 40"; "9 years in partnerships" | A 90-second arc: consulting on bus and light rail network planning, then partnerships, then the ISV channel from 6 to 40, then why this role. Each step at its stated scope. Answer slot: give the reason for each move in your own words | A likely opener. Arcs that aren't pre-built run long |
| E2 | "What did you make of the report we sent?" | CO | [generic] | Its authors are colleagues of the panel. One thing it gets right, one question it raised for you, and how that shows up in your POV. Answer slot: quote only what the report says | A casual question that is scored as homework |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, the moment you said it, and what happened to the relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A standard behavioural probe. Partnerships often means telling sales or a partner no |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time you traded a number for a customer's or partner's interest. It needs the metric, the choice and the result. If none comes to mind, say so plainly, then say how you'd make that call with an operator | Mirrors the operator-first close the recruiter asked for |

### H. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Someone here already owns the operator relationships. How do you work with them without stepping on them?" | CASE | [generic] | Seam principles: one owner per operator relationship, partners introduced through that owner, shared account plans, and an agreed rule for credit. Say you'd want to learn how it works today before proposing changes | The seam is a predictable panel question for a partnerships hire. CASE because it asks about the future |
| H2 | "How do you handle credit when a deal spans a partner and direct sales?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Your own number was influenced, so you have a view on credit. Answer slot: if you've been in a credit dispute, say what happened and what part was yours, in your own words; if not, say so and give your principle. Keep it collaborative | A credit-sharing probe that connects to F5 without re-litigating it |

---

## Reverse questions

| # | Question | To | Why it lands |
|---|---|---|---|
| R1 | "If operator partnerships looked very different in 18 months, what's the one change you'd most want to see?" | Deepa | Turns your POV into a shared goal and tells you what your future manager will judge you on |
| R2 | "How is partnerships' commercial contribution measured today: sourced, influenced, or something else?" | Ross | Answers the F5 question on your terms, and you need to know it before accepting |
| R3 | "Which conclusion in the strategy team's report is leadership still debating?" | Both | Shows you read the report as a live document, and shows you where the real decisions sit |
| R4 | "When a partner is involved with an operator, who owns the relationship, and how was that agreed?" | Deepa | Seam diligence. It reads as experience, not anxiety |
| R5 | "What's been tried with operator partnerships before, and what did it teach you?" | Both | Avoids proposing something they've already ruled out, and invites candour |
| R6 | "Twelve months in, what would make you say this hire wasn't working?" | Ross | A direct question to the person most likely to hold the bar |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried or hit a direct revenue quota | A negative you stated, F5 | "I've never carried a direct quota, only influenced revenue." No slot |
| Has sold into rail, or has rail sales experience | A negative you stated, F3 | "I haven't sold into rail specifically." No slot |
| Generated, closed or owned £4M of revenue | Inflated form of F4 | F4's quote at its own scope: "roughly £4M of influenced revenue". Both qualifiers stay. D1's slots stay inside how the figure was counted |
| Worked with or inside mainline train operating companies | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation: your material says bus and light rail planning, not train operators. B1's slot stays inside the planning work |
| Built or founded the ISV channel, or personally signed the 34 new partners | Inflated form of F1 | F1's quote at its own scope: "running the ISV channel — took it from 6 partners to 40". Your material says you ran the channel and it grew. C4's slot asks which part was yours |

---

## Sources

**Provided material**
- The recruiter's email, as quoted in your message: panel, timing, the POV ask and the commercials flag.
- Your message: your background.
- The internal market report: you've read it, but it was not shared here, so nothing in this pack draws on its contents. The POV's slots are where it goes.

**Searches sent**

| Query | Outcome |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail interview process partnerships | refused |
| Kelverton Rail scheduling software train operating companies news 2026 | refused |
| Deepa VP Partnerships Kelverton Rail; Ross Commercial Director Kelverton Rail | refused |
| "Senior Partnerships Manager" rail software job description train operators | refused |

**Target accounting**

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The search was refused. It would have themed the G bank on published values |
| 2. Kelverton Rail interview process | unavailable | The search was refused. The recruiter's email already sets this session's structure, so it would only have added context on later rounds |
| 3. Kelverton Rail strategy and recent news | unavailable | The search was refused, and the report's contents aren't in hand. It would have grounded A4, E2 and the POV's anchors |
| 4. Deepa and Ross at Kelverton Rail | unavailable | The search was refused. It would have added career patterns, a mirror opportunity and a reverse question tied to their own paths |
| 5. A representative Senior Partnerships Manager JD | unavailable | The search was refused. It would have replaced the three `[generic]` requirement rows (F3, F5, F6) with quoted, `[inferred]` ones |

---

## Upgrade menu

- **JD text** → F3, F5 and F6 become quoted requirements, every JD requirement gets a coverage check, and any mid-list requirement gets its own question.
- **The report's headline findings, pasted** (a few lines is enough) → the POV's consensus nod, divergence and T1 anchors become specific, and A4, E2 and D3 become grounded rather than `[generic]`.
- **Allowing web search in this session** → the L1 pass reruns: published values for the G bank, recent company news for A4, and Deepa's and Ross's public profiles for a panel read and a reverse question tied to their own paths.
- **A deeper research pass (L2)** → up to 6 more searches and 2 more fetches, several more minutes, adding a strategy brief, competitive context and recent org changes. Needs search allowed.
- **A partner-attributed revenue report or channel dashboard from your payments role** → the field's usual inspectable proof for influenced revenue. F4 could move from medium towards high, and D1's slots would have something behind them.
- **Your answers to the answer slots in F1, F2 and F4, told to me outside a drill** → those rows, and B1, B2, C1, C4 and D1, regenerate as story-mapped guidance on your own words.
- **A tuesday-dossier.md** → would add an underwriter-graded evidence map and prohibited-claims list. It is not needed for this pack.
