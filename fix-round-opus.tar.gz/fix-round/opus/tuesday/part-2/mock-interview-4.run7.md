Quick status: I've read the dossier and the prep playbook. Next I'll run a few searches on Quartzline (values, interview process, recent strategy), then build and save your prep pack.
I built your prep pack from the dossier and saved it as `Quartzline_product-manager-platform-apis_interview_pack.md`. It has 22 questions across seven interviewer styles, every one tied to your three verified evidence lines and the dossier's three prohibited claims.

- **Start with A1.** It's the dossier's named objection, "You have never held the PM title or owned a roadmap…". The answer is to concede both points cleanly, then describe your integrations and roadmap-input sessions in their own words, then give a ramp plan. It includes three rehearsed follow-ups.
- **Watch the integrator-vs-builder line (F3, A4, E2).** Your evidence says you led client integrations of the vendor's REST APIs, not that you shipped the API product. A hiring manager for an API platform will notice that difference immediately.
- **There's no research on Quartzline in the pack.** My web searches were refused. The company questions (D2, D3) and the strategy cases are generic patterns, and the pack doesn't claim anything about Quartzline itself.
- **"Seven years" isn't used anywhere.** Your dossier's decision line says "seven years of integration leadership", but none of your verified evidence lines carries that figure. If it's accurate, tell me and I'll add it.
- **Today is Thursday, November 12.** If the interview is today rather than next week, rehearse A1 out loud and bring the two questions for the manager, R-1 and R-2. Everything else is insurance.

If you want to practise, I'll play the sceptical hiring manager on A1 and push back on your actual answers.
I can also save an updated `tuesday-dossier.md` with what this prep turned up, for later sessions.
If you'd like the pack as a Word document, I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday (your own words). Interviewer name not given.
**Built from:** your job-underwriting dossier (v1.1, 2026-08-14, decision `conditional_go`). Web research was attempted and refused, so nothing about Quartzline beyond the dossier is in here. See Sources.

---

## How to use this pack

Two axes. **Personas** describe how a question will be asked, meaning the register and style. **Types** describe what is being scored:

| Tag | What it scores |
|---|---|
| VAL | Behavioral: whether past behavior shows the values the company publishes |
| EXP | Work-experience deep-dive: whether your claims hold up and what was actually yours |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company knowledge: homework depth, strategy, recent moves |
| CASE | A live problem from the role, solved out loud |

Provenance labels: `[grounded]` traces to your dossier or a document. `[inferred]` is this pack's derivation, and the derivation is named. `[generic]` is a role-family pattern with no claim about Quartzline.

**Answer slots** mark the places where the pack stops and only your own memory can continue. Each one has two honest branches. Guidance is scaffolding, not a script. Say it in your own words.

**Start with A1.** The dossier named it as the objection you'll most likely face, and it's the highest-ROI rehearsal in this pack.

---

## Fit snapshot

The quotes below are the three entries from your dossier's `verified_candidate_evidence`, copied exactly. Everything this pack says about your past comes from these three sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | transferability | This is a bridge. Position it as adjacent experience and never as PM experience: that is the dossier's condition. Name the limit first. The dossier sources the words (prohibited_claims: "Having held a product manager title or role"): "I haven't held a product manager title." Then describe the adjacent work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through scoping, requirements, architecture, UAT and go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." Let the interviewer draw the inference, and don't call the work product management. The sessions line is confirmed but has limited inspectable proof, so describe the sessions in the quote's terms before you're asked. `[inferred]` because the bridge is the underwriter's derivation from adjacent evidence |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities, the R1 sub-claim) | none given | none | [grounded] | capability | The dossier records this as an `acknowledge_gap` area (uncertain_or_weak_areas) and as prohibited_claims: "Having owned a product roadmap". The words: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as something in your past. There is no bridge here, not even from the roadmap-input sessions. The underwriter looked and found nothing, and building a bridge live is how a candidate gets caught |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | Your material says you led client integrations of the vendor's REST APIs. It does not say you shipped the API product, and your words should stop where the quote stops. Watch which side of the relationship you are on: the quote says client integrations of the vendor's APIs, so say in your own words where you sat, and don't let a follow-up move you onto the API builder's side. Answer slot: the JD's "shipped API or platform products" line makes a probe on what went live likely. Of the stages the quote names (scoping, requirements, architecture, UAT, go-live), say which decisions were yours and how you made them, in your own words. If a stage's decisions weren't yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | REST API integrations that ran through requirements and architecture come close to docs and schemas. Your material doesn't show whether you read, wrote or reviewed them. Answer slot: if you worked from or wrote API docs or schemas in those integrations, or the playbook covers them, say which and how, in your own words. If not, say so plainly and say how you would get fluent in Quartzline's docs in your first week |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | discovery | Clients and product appear in the quotes: client integrations, and client evidence fed to product. Engineering and sales don't. The sessions line is confirmed but has limited inspectable proof, so expect a probe and describe the sessions before you're asked. Answer slot: the JD names engineering and sales. If you worked with either on those integrations or sessions, say who and what the working relationship was, in your own words. If you didn't, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | The dossier's strategy for this one is `clarify`, and no verified entry speaks to agile delivery itself. Answer slot: expect "how have you worked in agile delivery?" If your integration work ran in sprints or a similar cadence, say how it ran and what your part was, in your own words. If you never worked that way, say so plainly. Then clarify: "Here's what I'd want to confirm about how your squads define it: the cadence, who owns the backlog, and how specs get into a sprint" |

---

## Persona table

The loop comes from your own words: one 45-minute conversation with the hiring manager. Weights start from the hiring-manager prior (Case/Strategist plus Skeptic). There is no interviewer profile and no research to adjust them.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Probes on the PM-title and roadmap gap, and on why you, why here, why now | **High.** The hiring-manager prior, plus a must-have (R1) where your evidence is adjacent rather than direct. The dossier names this objection | Concede the sourced negatives cleanly, then give the adjacent work in the quotes' own words, then a ramp plan. Never bluff the roadmap |
| B. Case / Strategist | Live problems from the actual JD: first roadmap, adoption diagnosis, squad disagreement, discovery, specs | **High.** Hiring managers test the real job, and every JD responsibility becomes a ready-made case | Clarify, then the objective, segmentation, approach, metrics and risks. Think aloud. Ask the two open questions (decision authority and the adoption baseline) inside the cases |
| C. Data-Driven Prober | "30+: how counted?", "what's in the playbook?", "what came of the sessions?" | **Medium.** You have one headline figure and one medium-confidence entry, and both draw probes | Know how the figure was counted, or say plainly that you don't. Name the weakest assumption before they do. Volunteer the sessions' limit |
| D. Conversational | The opener, "why Quartzline", "what have you looked at" | **Medium.** It always shows up in the first and last five minutes, and it is scored | A 90-second arc built only from your three quotes. Treat the casual company questions as scored |
| E. Pressure | Time-boxed attribution challenges, integrator versus builder | **Low-medium.** Not the hiring-manager default, but the R1 and R2 gaps invite it | Pause, restate, hold the quote's verb through two follow-ups, then concede specifically |
| F. Peer Evaluator | The seam with the two squad leads | **Low-medium.** The hiring manager will likely ask on the leads' behalf, and decision authority is a dossier unknown | Propose principles for the seam rather than pretending to know it. Bring something as well as asking for things |
| G. Values / Behavioral | Stakeholder-conflict and hard-truth stories | **Low.** No values round is known, and no published values are in hand | Pick stories from your material and use the honest branch where none fits |

---

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | **The highest-ROI rehearsal in this pack, named by the dossier.** Concede first, cleanly and without hedging: "That's right. I haven't held a product manager title, and I haven't owned a product roadmap." Then give the adjacent work in the quotes' terms: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through scoping, requirements, architecture, UAT and go-live. I ran quarterly roadmap-input sessions feeding client evidence to product." Stop there and don't say what the work proves. Then give the plan, as a plan: what you would learn first (how the two squads work today, who decides what, how adoption is measured) and who you would meet first (partners). **Follow-up 1,** "So you've never made the trade-off calls?": hold the concession without backfilling: "Not as the owner of a roadmap, no." Then return to what the quotes carry. **Follow-up 2,** "Why not just hire the experienced PM?": don't argue against the other candidate. Say what you would bring in the quotes' terms, and say that your ramp is roadmap ownership. **Follow-up 3,** a probe on the sessions: describe them in the quote's terms. Answer slot: if you know of something product did with that evidence, say what, in your own words. If you don't know, say so plainly | The dossier's `likely_interviewer_objections` names this question, and F1 and F2 are where the must-have R1 presses hardest. It is tagged JD because it scores R1 directly and arrives in the Skeptic's register. Every negative in it has a dossier source, so it is asked as written |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap" | Pick the real one, not a humble-brag: "I haven't owned a product roadmap." Then give two or three concrete ramp steps for the first 60 days, said as plans: learn the current roadmap and how it was set, sit with each squad lead, talk to a handful of partners, and get the adoption numbers. Don't pivot into a strength in the same breath. Let them ask | F2 is the dossier's `acknowledge_gap` area. A calibrated answer here buys credibility for every other answer. Tagged JD because it asks you to score yourself against the listed job |
| A3 | "This role writes specs and drives delivery with two engineering squads. What part of that have you done?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having set prioritization for an engineering squad" | Say what the quote carries: requirements and architecture were stages of the integrations you led, through UAT and go-live. Answer slot: the JD's "write specs" line makes a probe on documents likely. If you wrote requirements or specs in those integrations, say what they covered and who used them, in your own words. If you didn't, say so plainly and stay with the integrations. On the squads: "I haven't set prioritization for an engineering squad." Then describe how you would want to work with them, which is B3's answer | It tests a JD responsibility next to a dossier prohibited claim, which is where the pull to stretch is strongest. It draws on F3 and F4 |
| A4 | "Have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer with what you did, not with yes or no: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through scoping, requirements, architecture, UAT and go-live." Say in your own words which side of the vendor-client relationship you sat on. Answer slot: of the stages the quote names, say which decisions were yours and how you made them, in your own words. If a stage's decisions weren't yours, say so plainly and stay with the integrations you led | F3 covers the must-have R2, and the honest answer is a description of the work rather than a verdict on it. Tagged JD because R2 is the scoring line |
| A5 | "How have you worked in agile delivery?" | JD | [grounded] | Answer slot (dossier strategy: `clarify`): if your integration work ran in an agile way, say how it ran and what your part was, in your own words. If you never worked that way, say so plainly. Then clarify: "Before I map it, what does agile look like on your squads? The cadence, who owns the backlog, how specs get into a sprint?" | F6. R5 is only preferred, but a clean answer closes it. The question presupposes a practice the material doesn't show, so the guidance is an answer slot whose second branch allows that the practice never existed |

### B. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "If you joined, how would you build the first roadmap for the partner API platform — what do you need to know first?" | CASE | [generic] | Clarify first: what's already committed, which decisions are the PM's and which belong to the squad leads, and how adoption is measured today. Then the objective (for example, adoption or partner retention, whichever they say matters). Segment partners by size or integration depth. Approach: gather partner evidence, list the candidate bets, size each against effort with the leads, sequence the work. Then metrics and risks. Present it as a plan, with nothing about having done it before | Built from the JD's "Own the roadmap" line. A live problem asks nothing about your past. `[generic]` because it is a pattern, not a fact about Quartzline |
| B2 | "Partner API adoption is flat this quarter. Diagnose it." | CASE | [generic] | Open with the dossier's unknown: "How is adoption measured today? Active partners, call volume, integrations in production?" Then walk a funnel: discover, sign up, first successful call, production, expanded use. Say what data you would pull at each step. Give hypotheses: docs or onboarding friction, a missing endpoint, partners' own priorities, pricing or limits. Close with what you would do this week | Built from the JD's "Define and track adoption metrics" line. The dossier says no baseline is stated, so asking for it first is itself the strongest move |
| B3 | "Two squad leads disagree on what ships next quarter. Both have a case. What do you do?" | CASE | [generic] | Clarify whose call it is here, which is the dossier's open authority question, asked live. Then put both cases in terms of partner impact and cost, bring the partner evidence, make a recommendation, say who decides, and write the decision down. Speak in the future tense ("I'd…"), never "when I prioritized…" (see the prohibited list) | From the JD's "two engineering squads" line and the dossier's unknown about decision authority. CASE delivery |
| B4 | "How would you run discovery with our integration partners?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure it: which partners, what you want to learn, how (conversations, integration and usage data, support tickets), and how the findings reach the roadmap. Where your past is relevant, use only the quote: scoping and requirements were stages of the client integrations you led. Answer slot: the JD's "run discovery with integration partners" line makes a probe on how you scoped likely. If your scoping included working through clients' needs with them, say how you ran it, in your own words. If not, say so and stay with the plan | From the JD's "Run discovery with integration partners" line. Q1's scoping stage is the nearest quoted evidence, which makes this tagged CASE with an EXP edge |
| B5 | "Sketch the spec for a new partner-facing endpoint. What goes in it?" | CASE | [generic] | Think aloud: the partner problem it solves, the success metric, the request and response schema and error cases, auth, versioning and deprecation, docs and examples, rollout and partner comms, and open questions for engineering. Ask what spec template the squads already use | Covers R3 (API docs, schemas) and the JD's "Write specs" line as a live exercise. `[generic]` structure |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30-plus integrations — how are you counting those?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words. Answer slots: how the 30+ was counted, meaning what counts as one integration; what the count is sensitive to; the assumption behind it you would defend least, which you should name before they do; and which part was yours. If you don't know exactly how it was counted, say so plainly. The pack supplies none of these | It is the only headline figure in your evidence, and probers go straight to the denominator |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the quote states: you wrote it, it's internal, and your team uses it. Answer slot: what's in it and how it came to be written, in your own words. Answer slot: the JD's API-docs line makes a probe on whether it covers docs or schemas likely. If it does, say how. If not, say so. Don't claim use wider than "my team uses it." If a section is shareable and it's yours to share, offer to show it | The dossier marks this entry as inspectable, so it's your strongest proof. It feeds F4 |
| C3 | "Tell me about the quarterly roadmap-input sessions. What came of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | This entry is confirmed but has limited inspectable proof. Expect this probe and say the limit first: these were input sessions feeding client evidence to product. The beats the quote states: they were quarterly, you ran them, and they carried client evidence to product. Answer slot: if you know of something product did with that evidence, say what and how you know, in your own words. If you don't know, or nothing traceable came of it, say so plainly and stay with what the sessions were | The dossier says "expect a probe" on this line. It feeds F1 and F5, and inflating it into roadmap ownership is listed below |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from these three quotes: the integrations, the playbook, the sessions. Then why this role. Answer slot: why you're moving toward a PM role now, in your own words. Leave out any title or year count your material doesn't carry (see Sources about "seven years") | The opener sets the frame for A1, and it is scored even when it feels casual |
| D2 | "Why Quartzline, and why now?" | EXP | [generic] | Selection scaffold: one reason about the role (the partner API platform, in the JD's words), one about the company that you can point to from your own reading, and one about timing. If you have no company-specific reason, say what draws you to the role and don't invent one | It checks motivation consistency. `[generic]` because the research was refused, so the pack holds no facts about Quartzline |
| D3 | "What have you looked at of our API platform so far?" | CO | [generic] | Before Thursday, read whatever public developer docs Quartzline has, and note one thing that worked and one question it left you with. Say only what you actually read | The CO coverage slot. It is generic because the research was refused, and the upgrade menu says what research would add |

### E. Pressure (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 30-plus — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate the question. Hold the quote's verb: "I led them, end to end." Answer slot: which parts were the team's and which were yours, in your own words. Hold through two follow-ups by returning to "led". Concede specifically what others did, but never give up the "led" to restore harmony | An attribution probe on the one figure. Tagged EXP because it scores what was yours |
| E2 | "Integrating against an API and building one are different jobs. Which one have you been doing?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Agree with the premise, because it's fair, then describe: "Here's what mine was:" followed by the quote. Answer slot: say in your own words which side of the vendor-client relationship you sat on. Don't move sides under pressure. Hold the description through two follow-ups, and concede only what the quote doesn't say | F3's relationship risk, delivered as a challenge. Tagged JD because it presses on R2 |

### F. Peer Evaluator (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You'd drive delivery with two engineering squads. Where's the seam between you and their leads, and what happens when you disagree?" | CASE | [generic] | Propose principles for the seam: you bring partner evidence and the why, the leads own the how and the capacity, and you agree up front who decides scope trade-offs. Ask how that works here. For a disagreement, put both cases in partner-impact terms and escalate with a recommendation. Speak in the future tense only (see the prohibited list) | Decision authority versus the squad leads is the dossier's top unresolved risk, so the hiring manager is likely to probe it. JD content, CASE delivery |
| F2 | "What would you need from engineering in your first month, and what would you bring them?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | What you need: a walkthrough of the API and its docs, the current backlog, and the partner pain list. What you bring: answer slot. If something like the playbook you wrote would help them, say what, in your own words, and keep it to the quote's scope ("the internal integration playbook my team uses"). Otherwise, name what you would take off their plate, as a plan | A reciprocity framing for R4's engineering half. JD because it tests stakeholder management |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time engineering, sales and a customer wanted different things." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection scaffold: pick one of those integrations or sessions where the parties pulled in different directions. The story needs a named conflict, what you did, and how it ended. The quotes don't carry a conflict. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | An open prompt themed on R4. Tagged JD first because R4 is the scoring line, with VAL delivery. It feeds F5 |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, the truth you delivered, and how it landed. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | A common hiring-manager behavioral question. `[generic]` because there are no published Quartzline values to map it to |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A2, D1 |
| R1 sub-claim: own the roadmap | A1, A2, B1 |
| R2: Shipped API or platform products | A4, E2, C1, E1 |
| R3: Technical fluency: API docs, schemas | B5, A3, C2 |
| R4: Stakeholder management across engineering, sales, customers | G1, F1, F2, C3 |
| R5: Agile delivery experience | A5 |
| Responsibility: run discovery with integration partners | B4 |
| Responsibility: write specs and drive delivery with two squads | A3, B3, B5, F1 |
| Responsibility: define and track adoption metrics | B2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier. The JD asserts this authority without evidence, and the answer tells you what the job actually is before you accept it |
| R-2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier. Adoption is a listed responsibility with no baseline stated, so this tells you whether you're inheriting a metric or building one |
| R-3 | "What would a strong first 90 days look like to you in this role?" | It turns your ramp plan from A1 and A2 into their plan, and tells you what they'll judge you on |
| R-4 | "Where do partners get stuck most today?" | It signals a discovery-first instinct, which matters for a role whose JD asks for partner discovery |
| R-5 | "How do specs move from this PM into the squads' work today?" | It follows through on R5 and the spec responsibility without claiming a practice, and it shows you how agile works here |
| R-6 | "What made you open this role now?" | It shows what problem the hire is meant to solve, and often reveals the context behind the authority question |

---

## Prohibited claims

What this pack will not coach, and why. Hold these under follow-up pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The plain acknowledgment: "I haven't held a product manager title." F1's quotes stand beside it at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims` and an `acknowledge_gap` area | "I haven't owned a product roadmap." No slot and no bridge. Give the ramp plan as a plan |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." In B3 and F1, talk about how you would work, never "when I prioritized" |
| Calling the integration work "product management experience" | Dossier decision condition ("positioned as adjacent, never as PM experience"); an inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material describes integration work, and the interviewer draws the inference |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says client integrations of the vendor's REST APIs, not the API product. The A4 and E2 slots stay inside the integration stages |
| Shaped or decided the roadmap through the input sessions | Inflated form of F1 and F5 (the sessions quote) | The sessions quote at its own scope: sessions feeding client evidence to product. C3's slot asks only what you know became of that evidence |

---

## Sources

**Provided:** `tuesday-dossier.md`, envelope v1.1 (a known major version), generated 2026-08-14 by job-underwriter. Sections consumed:
- `role_profile`: requirements R1 to R5 and the responsibilities. It stands in for the JD.
- `decision`: used as context only.
- `handoff_to_mock_interview`: all seven fields. The verified evidence fills the fit snapshot, the weak-area strategies constrain F1, F2 and F6, the objection is A1, the risks and employer questions are R-1 and R-2, and `prohibited_claims` bind every cell.

The dossier as pasted carries no `evidence_map`, `evidence_state` or `risk_register`, so the fit snapshot's evidence cells quote `verified_candidate_evidence` directly.

**About "seven years":** the dossier's decision line says "seven years of integration leadership". No verified entry carries that figure, so this pack uses it nowhere.

**Loop source:** your own words, "a 45-minute conversation with the hiring manager". That establishes one session and who runs it. No values-style round is detected.

**Searches sent:**
- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline API platform partners news 2026": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have given G1 and G2 a published value to map to, and the official value names |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. Your own words already establish Thursday's session, so the persona weights stand. It would have shown what rounds come after this one |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have grounded D2, D3, B1 and B2 in Quartzline's current priorities instead of `[generic]` patterns |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements and responsibilities |

---

## Upgrade menu

- Allow web search, then ask me to rerun the research. Targets 1 to 3 run at L1: D2, D3, B1 and B2 move from `[generic]` to Quartzline-specific, and G1 and G2 get published values to map to.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): a strategy brief, recent org context and loop reports, which would add a grounding brief and sharper CASE questions.
- The hiring manager's name: an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their career path.
- Any recruiter guidance (focus areas, or anything to prepare): coverage of a pre-declared deliverable, if there is one.
- How much prep time you have before Thursday: a prioritized prep schedule at the top of this pack.
- Confirm the "seven years" in your own words: it enters F1 as quoted evidence, and D1's arc and A1's answer can use it.
- Your answers to the answer slots (agile, docs and schemas, engineering and sales, how the 30+ was counted): rows F4, F5 and F6 regrade, and A3, A5, B4, C1, C2, E1 and G1 become story-mapped.
- Anything inspectable behind the roadmap-input sessions (an agenda, a summary deck, notes, if they're yours to share): C3's medium-confidence caveat could lift.
