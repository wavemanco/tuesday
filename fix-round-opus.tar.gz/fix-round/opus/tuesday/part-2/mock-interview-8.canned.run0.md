Building your prep pack now: I've read the module's rules and I'm writing the three-round pack from what you pasted.
I've saved your prep pack at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-8-canned-a5cb13d5/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It has a separate section for each of the three rounds on 21 November, built from the recruiter's description of each one.

- **Most important question to prepare (C1):** "You've handled your branch's complaints log and never worked in a contact centre. This role owns complaints across every branch and the contact centre. Why are you ready?" The strongest answer starts by admitting both limits before they raise them. Then say only what you actually did, and give a 90-day plan.
- **Things you told me you haven't done:** the contact centre and presenting above regional level. The pack gives you plain ways to say both and doesn't try to disguise them. It also lists the overstatements it won't coach, like "coached supervisors" or "owned regional reporting".
- **Round 3:** there's a section for the 20-minute case, with a structure, three positions you could take and the weak point to admit for each, and what to avoid. There's also a sheet for the four values. None of your four sentences contains a complete story yet, so each value has guidance on choosing one rather than a ready-made answer. One real story per value, sent to me, would make this round much stronger.
- **Research:** I didn't run any web searches. Your pasted values, the recruiter's email and the July strategy brief already covered everything a search would have found. The menu at the end of the pack lists what more input would add, including the interviewer names once they're assigned.

If you'd like to practise, I can play the Head of Member Services and put C1 to you live, with follow-ups.
I can also save a `tuesday-dossier.md` file recording the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of loop:** 21 November 2026, three rounds back to back (the recruiter's email)
**Round 1:** 30 minutes with the recruiter
**Round 2:** 45 minutes with the Head of Member Services, your future manager, "mostly behavioural"
**Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation; also the values round, scored against the four values
**Interviewers:** not yet named, so there is no interviewer read; personas rest on the roles the recruiter gave

Built in loop mode: one shared fit snapshot, then a mini-pack per round with its own persona weights, its own bank and its own reverse questions.

---

## How to use this pack

- **Personas** describe *how* a question will be asked (friendly aside, quiet probe, live case). **Types** describe *what* is being scored. Rehearse both.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Answer slot** means the pack does not know the answer and will not guess. Each one has two honest branches: if it happened, say how in your own words; if it didn't, or it wasn't yours, say so plainly and go back to what you did do.
- Provenance labels: `[grounded]` traces to something you or Ashgrove supplied; `[inferred]` is the pack's own derivation, which it names; `[generic]` is a pattern for this kind of role, with no claim about Ashgrove.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's four published values, not generic virtue |
| EXP | Whether what you say about your work survives follow-ups, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know where Ashgrove is going and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep in this pack: C1.** It's the scope objection (one branch's log versus a process across every branch and the contact centre). It will come up in some form, probably in Round 2 and possibly again in Round 3.

---

## Fit snapshot (shared across all three rounds)

All evidence quotes come from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's log, not a process across branches, and your words should stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how complaints moved through your branch likely. If any step was yours to set or change (how a complaint was logged, who it went to, when it counted as closed), say which and how, in your own words. If none was, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have said this gap yourself, and wording cannot close it. Words: "I haven't worked in a contact centre." Then say how you would learn it, framed as a plan and never as a past (for example, time sitting with contact-centre staff in your first weeks). Never claim contact-centre work, and add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | A monthly complaints spreadsheet sits close to this, but your material doesn't show what it counts. Keep the split in your sentence: you built it, and your regional manager uses it. Answer slot: if it tracks complaint volumes or how long complaints took to resolve, say which, in your own words. If it tracks something else, say what, and don't stretch it |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script." That's tellers, not supervisors, and the script is "our" script, not yours. Answer slot: the JD's coaching line makes a probe on how you trained likely. If any part of how the training ran, or of the script itself, was yours to shape, say what, in your own words. If it was a set approach and a set script, say so and describe how you trained the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show any digital or self-service work. Strong evidence would be a time member problems you saw changed how a channel worked (app, website, phone menu, online form). Answer slot: if you ever passed complaint patterns to someone who changed a channel, say what happened and what your part was, in your own words. If not, say so plainly and say what you would bring from the complaints log to a digital team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | Your years clear the bar, so this row has no gap. Expect a light probe all the same. Say it in your own terms: six years in retail banking, the last three as a branch supervisor. Let the interviewer map that to "customer operations"; don't relabel your history in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Your sentence says "formal". Your material doesn't show whether those complaints fell under regulatory rules. Answer slot: if formal complaints at your branch had rules on how they were recorded, answered or how fast, say what they were and which part you handled, in your own words. If you don't know, or there were none, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have said this gap yourself. Words: "I haven't presented to anyone above regional level." Then describe how you would prepare the first monthly report for senior leaders, said as a plan. Whether you have presented *at* regional level isn't in your material; B1 and C2 handle it as an answer slot, never as a claim |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your sentence says "spreadsheet", not Excel. Answer slot: if it's built in Excel, say so and describe what you built in it, in your own words. If it's another tool, name the tool |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| F1: own the complaints process end to end across branches | A4, C1, J1, J3 |
| F2: the contact centre part | A5, C1, C3 |
| F3: monthly reporting on volumes and resolution times | G1, G2, E1 |
| F4: coach branch supervisors on escalations | C4, D3, J2, K1 |
| F5: digital teams and self-service journeys | E1 |
| F6: 4+ years in financial-services customer operations | A1, B2 |
| F7: regulated complaints | A4, J1 |
| F8: presenting to senior leaders | B1, C2, C3 |
| F9: Excel reporting | B3, G1 |

---

## Grounding brief

Built from the parts of the July 2026 strategy brief you passed on, plus the JD and the values page. At four months old the brief is current; nothing in it looks stale. This is your summary of the brief, not the full text, so it carries only the lines you gave me.

| Item | What to know | Provenance |
|---|---|---|
| Their words | "Member", never "customer"; "branches", "the contact centre", "self-service journeys", "digital channels", "hubs". Using their vocabulary is the cheapest signal you've done the homework, and it matches the Plain Words value | [grounded] |
| Headline numbers | 40% of member service moved to digital channels by 2028. Eight branches consolidated into five hubs over 2027. A small-business lending product launching in Q1 2027 | [grounded] |
| Competitive frame | The main pressure is app-only banks | [grounded] |
| Size and model | Member-owned, about 900 staff | [grounded] |
| Why this role exists now | Each of the three moves lands in this job: digital shift (the JD's self-service line), consolidation (the branches whose supervisors you'd coach) and a new product (new kinds of complaint). This is the pack's reading of the brief, not something Ashgrove has said | [inferred] |

---

## Graded deliverable: the 20-minute complaint escalation case (Round 3)

**Declared by the recruiter:** "a 20-minute case on a complaint escalation". The panel "score against the four values", so the case is very likely scored on values as well as structure. That second point is the pack's inference from the recruiter's email.

**Grounded facts to build on**
- JD: "Own the member complaints process end to end"; "coach branch supervisors on escalations"; "report monthly on complaint volumes and resolution times".
- Values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix.
- Strategy: branch-to-hub consolidation in 2027; the push to digital.
- You (F1/F4): "I handled the branch's formal complaints log and trained new tellers on our escalation script." Use this only at its own scope ("I've handled a branch's formal complaints log"), never as having run escalations across branches.

**A structure for 20 minutes**
1. **Clarify (2–3 min).** What does the member want? What has already happened? Who owns it right now? Which complaint rules and deadlines apply? Is the member vulnerable or in hardship? Asking before solving is itself scored.
2. **The member today.** Name who contacts them, when, and what they'll hear, in plain words.
3. **The case.** Facts, decision, the final response.
4. **The cause.** Why did it escalate? Is it a one-off, a branch pattern or a process gap?
5. **Close the loop.** The supervisor's learning, what goes into the monthly report, and who keeps hold of it until it's fixed.

**Theses to choose from (each with its concession)**

| Thesis | Concession to say aloud |
|---|---|
| Coach the branch supervisor to close the case themselves, and take it off the branch only if the member's trust in the branch is gone | This can be slower, and the member must not wait while you coach |
| Every escalation is data: it should appear in the monthly report with a cause, not just a count | It adds recording work for branches in a consolidation year, so keep it to one or two fields |
| Write the final response so the member never needs it explained twice | Plain wording still has to meet whatever the complaint rules require, so check it with whoever owns compliance |

**Differentiation.** The consensus answer is apologise, investigate, resolve, maybe a goodwill payment. Most candidates will give it. To stand out:
- Name an owner (Own the Fix): whoever found the problem keeps it, so say who that is in this case.
- Separate fixing it for this member from fixing the cause.
- End on what the panel's branches would see change.

**The anti-pick.** Don't promise compensation or an outcome before you have the facts. Don't go around the branch manager or supervisor; two branch managers are scoring you.

**The close.** Land on a member outcome. Mention a value only where a step really serves it, once or twice, not after every sentence.

---

## Round 1: Recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly "walk me through" openers; motivation and logistics | High: a recruiter screen's prior, in a short slot | A pre-built 90-second arc (A1); treat casual questions on JD topics as scored |
| Skeptic (light) | Polite knockout checks against the JD's requirement list | Medium: recruiters screen against the requirement list, and F2 and F8 are visible gaps | A plain acknowledgment plus a one-line plan; don't over-explain in a 30-minute slot |
| Others | Not expected here | Low: the recruiter's email puts the behavioural, case and values work in Rounds 2 and 3 | — |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Build the arc from those three sentences only: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log, which you handled; training new tellers on your escalation script; the monthly complaints spreadsheet you built, which your regional manager uses. Then one line on why this role (A2). Ninety seconds, and stop | The opener in nearly every screen. F6, F1 and F3 are its evidence. EXP because it sets what you'll be held to in Rounds 2 and 3 |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Name one value by its exact name and one move from the strategy (the hubs or the digital shift), then say in your own words why each matters to you. The reason has to be yours. A named value plus a named strategy line beats "I like that it's member-owned" | Motivation is scored even in a friendly register. CO because the strong answer uses Ashgrove's own published material |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | The four lines from the brief, in its terms: 40% of member service to digital channels by 2028; eight branches into five hubs over 2027; small-business lending in Q1 2027; app-only banks as the main pressure. Then one sentence on what you'd want to understand about complaints through those changes. Frame it as a question you bring, not a forecast | Few candidates will quote the brief back accurately. CO by definition |
| A4 | "How much of your work has been complaints, and were they formal or regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | "I handled the branch's formal complaints log." Answer slot: the JD asks for regulated complaints and reporting on volumes, so expect "how many?" or "under what rules?" If you know a figure or the rules, say them in your own words. If you don't have the number to hand, or don't know whether the rules were regulatory, say so plainly and stay with the log | F1 and F7 are both on the JD's list, and a recruiter will check them. JD because it scores two stated requirements |
| A5 | "The role covers the contact centre too. What's your contact-centre experience?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't worked in a contact centre." Then one line of plan, said as a plan: how you'd learn it early (for example, sitting with handlers). Say it once, without apology, and move on | F2 is a gap you stated, sitting in the JD's first line. A screener ticking requirements will reach it. JD because it's a stated responsibility |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for confidence presenting to senior leaders. Where have you done that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and on what, in your own words. If not, say so plainly. Either way you can add: "I built the monthly complaints spreadsheet our regional manager uses." Then one line of plan for the first senior-leader report | F8 is a stated gap. The short version is rehearsed here so the long version (C2) is ready for Round 2 |
| B2 | "You've been a branch supervisor. This is a lead role across the organisation. Is that a step up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say yes. Admitting the step up is stronger than denying it. Say it in scope terms: you've handled a branch's formal complaints log, and this is the process across branches. Then why you want that step, in your own words | F6 clears the years bar, but F1's scope jump is visible from the CV. JD because it tests readiness for the stated responsibilities |
| B3 | "Are you comfortable with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it's in Excel, say so and describe what you built in it in your own words. If it's another tool, name it. Never describe a feature or formula you didn't build | F9's row is discovery. A one-word "yes" here invites a deeper probe later (G1) |

### Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| "Has this role existed before, or is it new?" | Tells you whether you're inheriting a process or building one, which changes how you pitch F1 in Round 2 |
| "For the 20-minute case, is it all live, or is there material to read first?" | Shows you're preparing for the graded part, and the answer changes your case plan |
| "How does the panel score the four values: one score per value, or overall?" | Shows you took the values round seriously, and tells you whether to land all four |
| "Do you know yet who'll be on the panel?" | Interviewers aren't assigned yet. The names, if you get them before the 21st, unlock the interviewer read |
| "What would make the Head of Member Services say, six months in, that this hire worked?" | Gives you Round 2's success criteria an hour before Round 2 |

---

## Round 2: Head of Member Services, your future manager (45 minutes, "mostly behavioural")

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: scope, the contact centre, presenting | High: a hiring manager is derisking gaps, and F1, F2 and F8 are the ones they own day to day | C1 rehearsed until it's boring. Bridges only from your own quotes, the limit said plainly, then a ramp plan |
| Values / Behavioral | "Tell me about a time…" stories | High: the recruiter called this round "mostly behavioural" | One story per theme, chosen in advance; "we" for context, "I" for what you did |
| Case / Strategist | Live problems from the manager's roadmap | Medium-low: the formal case is in Round 3, but managers pull in their own problems (digital shift, hubs) | Clarify, then structure; use the brief's vocabulary |
| Data-Driven Prober | Digs into the monthly reporting and your spreadsheet | Medium-low: the JD's monthly reporting and Excel lines sit with this manager | Know exactly what your spreadsheet counts and what it doesn't |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've handled your branch's complaints log, and you've never worked in a contact centre. This role owns complaints end to end across every branch and the contact centre. Why are you ready?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | **Highest-ROI rehearsal in the pack.** (1) Concede first, and name the limit before they do: "I haven't worked in a contact centre, and the log I handled was my branch's." (2) What you bring, at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script," and "I built the monthly complaints spreadsheet our regional manager uses." (3) A first-90-days plan, said as a plan: learn the contact centre's flow from the people in it, see how each branch logs complaints today, and agree what goes in the monthly report. Answer slot: the JD's across-branches line makes "did anything go beyond your branch?" likely. If complaints from your log went to region or another team, say what happened and what your part was. If not, say so plainly. Follow-up 1 ("but at this scale?"): go back to the branch log and the plan, and add nothing. Follow-up 2 ("so it's a big jump?"): "Yes, it's a step up in scope," then stop. Never claim cross-branch work | F1 and F2 together are the clearest gap between your material and the JD's headline line, and this manager owns that line. JD because it scores the first stated responsibility. Deepest rehearsal because the strongest answer here is the most exact concession, not the most content |
| C2 | "This role presents monthly to senior leaders. Tell me about presenting to people senior to you." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom, on what, and what happened next, in your own words. If not, say so plainly and say what you have produced for someone senior: "I built the monthly complaints spreadsheet our regional manager uses." Then your plan for the first senior-leader report, said as a plan (for example: one page, the few numbers that matter, one ask). Hold: don't drift into "I'm a natural presenter" | F8 is a stated gap that this manager will watch most closely, because they'll put you in front of their leaders. JD because it's a named requirement |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one, and pick a real one: the contact centre or presenting above regional level. Name it in your own words, give a two-line plan, and stop. Don't offer a disguised strength, and don't list both and spiral | A Skeptic staple. F2 and F8 give you honest answers ready-made. JD because it asks about the listed job |
| C4 | "You've trained tellers. This role coaches branch supervisors on escalations. What's different?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | "I trained new tellers on our escalation script." Answer slot: if any part of how that training ran, or of the script itself, was yours to shape, say what, in your own words. If it was set, say so and describe how you trained. Then your view of the difference, as reasoning about the role: tellers follow the script, and supervisors decide when to leave it. That is your read of the job, not a claim about your past | F4 is transferability, from tellers to supervisors. JD because it's a stated responsibility |

### Bank D: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a complaint where the member was right and the process was wrong." | VAL | [grounded] | Selection scaffold. Pick a complaint from your branch log that has a named member problem, a process that caused it, what you did, and what changed for the member. Say "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Theme from Members First, Always and the JD's complaints line. Your material names the log (F1) but no particular case, so this is a scaffold. Keep a different story for H1 |
| D2 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [grounded] | Selection scaffold. You need a named stake, the moment you said it, what happened, and a working relationship intact at the end. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | A manager hiring someone to report complaint data upward needs to know you'll bring bad news. VAL because it tests behaviour, not knowledge |
| D3 | "Tell me about training someone who was struggling to pick it up." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: the JD's coaching line makes this likely. If training new tellers on the escalation script included someone who struggled, tell what you noticed, what you changed and how it turned out, in your own words. If no particular case comes to mind, say so plainly and describe how you trained the tellers, which is what your sentence carries | F4's evidence, probed for a story. Plain Words ("if a member needs it explained twice, we wrote it wrong") applies to colleagues too |
| D4 | "Tell me about an escalation where you disagreed with the outcome." | VAL | [grounded] | Selection scaffold. You need a real disagreement, what you did with it (raised it, accepted it, escalated further), and what you learned about escalation. Show spine and tact together. If no such time comes to mind, say so plainly and say how you would handle one | Theme from the JD's escalations line. Tests the judgement you'd be coaching others on |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Suppose complaints about the app rise as we move service to digital. What do you do in your first month?" | CASE | [grounded] | Clarify first: which complaints, which members, since when. Then the JD's own measures: volumes and resolution times. Then work with the digital team on the journey that causes them; then a plain-words fix (Plain Words); then report it. Name the trade-off: the 40% target versus members who struggle with digital. Neighbours, Not Numbers gives you the language for it | Grounded in the brief's 40% line and the JD's self-service line (F5). CASE delivery, JD content |
| E2 | "Eight branches become five hubs over 2027. How do you stop complaints spiking through the change?" | CASE | [grounded] | Clarify: which branches, when, what members are told. Then before (a baseline from the logs), during (watch volumes weekly, coach supervisors on what's likely to come in) and after (compare against the baseline). Members First: the member hears it from Ashgrove first, in plain words. Concede: some rise may be unavoidable, so the goal is that they resolve fast | Grounded in the brief's consolidation line. CASE because it's this manager's actual next year |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats your sentence carries: you built it, it's monthly, it's about complaints, and your regional manager uses it. Answer slot: the JD's "volumes and resolution times" and "Excel" lines make "what does it count, and in what?" likely. Answer in your own words. If it doesn't count those, say what it does count. If you know which part of the counting you'd trust least, say so before they ask; if you don't know, say that plainly | F3 and F9 both rest on this one sentence, so it will be probed. EXP because it tests exactly what was yours |
| G2 | "How would you know resolution times were getting worse in one branch, and what would you look at first?" | CASE | [generic] | Structure: define resolution time (opened to closed), compare the branch against itself over time and against the others, then look at mix (new types of complaint) before blaming people. Then ask the supervisor before concluding. This is a pattern for the problem, not a claim about Ashgrove's data | Tests the JD's monthly-reporting line (F3) as reasoning rather than as a record |

### Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| "What does the complaints picture look like today, and what would you want different in a year?" | Gets the real brief behind the JD, and shows you think in outcomes |
| "Do branches and the contact centre work to one complaints process today, or two?" | Goes straight at F1 and F2 as a question, so you're learning the gap rather than defending it |
| "Which senior leaders does the monthly report go to, and what do they do with it?" | Shows you're already preparing for F8 rather than avoiding it |
| "Which complaint rules and timescales does the team work to, and where do they get missed today?" | Shows regulatory awareness without claiming anything about F7 |
| "How will the move to five hubs change the supervisors I'd be coaching?" | Connects the brief to the JD's coaching line. It's a question your future manager will have thought about |

---

## Round 3: Panel of two branch managers (60 minutes, including the 20-minute case; the values round)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored stories against the four values | Highest: the recruiter says the panel "score against the four values" | One story or scaffold per value (H1–H4), with the value's exact name |
| Case / Strategist | The 20-minute escalation case | Certain for one segment: the recruiter declared it | The structure in the graded-deliverable section; clarify before solving |
| Peer Evaluator | Branch managers sizing up someone who'll coach their supervisors and handle their branches' complaints | Medium: the JD puts this role across their branches, and their branches are in the consolidation | Reciprocity: what you'd bring their branch, and seam principles rather than turf claims |
| Pressure | Follow-ups that push back during the case, or "why you?" | Low-medium: a panel of two can tag-team follow-ups | Pause, restate, hold through two follow-ups, then concede the specific thing |

### Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter, even though it was harder for the branch." | VAL | [grounded] | **Members First, Always.** Selection scaffold. You need a named member situation, the easier option for the branch, what you chose and why, and what it cost. Use a different story from D1 if you can. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Phrased in the value's own words, so expect something close to it. VAL by definition |
| H2 | "Tell me about a time something had to be explained twice, and what you changed." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **Plain Words.** Answer slot: if training new tellers on the escalation script, or a member letter or conversation, showed you something was being explained badly and you changed it, tell it in your own words: what wasn't landing, what you changed, what happened. If not, say so plainly and say how you would test whether something is written plainly | The value's own test ("explained twice") is the likely question shape. F4's quote is your nearest material, but it carries no event, so this is a slot |
| H3 | "What does it mean to you that every branch is part of its town?" or "Tell me about a time you treated a member as a neighbour, not a number." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | **Neighbours, Not Numbers.** Selection scaffold. You need a time local knowledge of a member or the community changed what you did. Your sentence gives the setting (three years as a branch supervisor) but no event, so the event has to be one you supply, in your own words. If no such time comes to mind, say so plainly and say what this value means to you in a year when eight branches become five hubs | This panel's branches are in the consolidation. This value is where they'll listen hardest. VAL by definition |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | **Own the Fix.** Answer slot: if the spreadsheet you built started from a problem you noticed, say what it was, what you did and what changed, in your own words. If it was asked of you, say so and choose a different story: a problem you found, kept, and saw through. If no such time comes to mind, say so plainly and say how you would apply this value to complaints that cross teams | F3's quote is your nearest material, but your sentence doesn't say how the spreadsheet started, so the slot keeps both branches open |
| H5 | "Which of our four values would be hardest to live by in this job?" | VAL | [grounded] | No past needed. A strong answer picks one, says why the job strains it (for example, Own the Fix when a complaint crosses branches, the contact centre and digital, or Neighbours, Not Numbers during hub consolidation), and says how you'd handle that tension. Name the value exactly | Tests whether you've thought about the values rather than memorised them. VAL with CO flavour, because it draws on the brief |

### Values cheat sheet

The four value names and definitions below are from the values page you copied on 12 November 2026. None of your four sentences carries a full story, so every row is a selection scaffold. Bring one real story per value on the day (see the upgrade menu).

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side, even when it costs the organisation effort | Selection scaffold: a named member, the easier path you didn't take, and the outcome. If no such time comes to mind, say so plainly and give the nearest thing you have, or how you'd handle it. Questions D1 and H1 |
| Plain Words | If it needs explaining twice, the writing failed, not the reader | Nearest material: F4, "I handled the branch's formal complaints log and trained new tellers on our escalation script." It carries no event, so the story is an answer slot (H2): use it only if a real moment of rewording happened. Otherwise say so plainly and describe how you'd test plainness |
| Neighbours, Not Numbers | Each branch belongs to its town; members aren't just accounts | Nearest material: F6, "6 years in retail banking, the last 3 as a branch supervisor." That gives the setting, not a story. Selection scaffold (H3): a time local knowledge changed what you did. If none comes to mind, say so plainly |
| Own the Fix | Whoever finds the problem keeps it until it's solved | Nearest material: F3, "I built the monthly complaints spreadsheet our regional manager uses." Whether it began as a problem you spotted isn't in your material. Answer slot (H4): if it did, tell it; if not, choose another story or say so plainly |

### Bank J: Case / Strategist (the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member has complained three times about a payment error. The branch closed it each time. Now they say they'll take it to the ombudsman and the local paper. Walk us through what you do." | CASE | [generic] | Use the five-step structure from the graded-deliverable section. Clarify (what the member wants, what's been done, which complaint rules apply, whether the member is vulnerable), then the member today, then the case, then the cause (why it was closed three times), then close the loop. Values naturally in play: Members First (the member, today), Own the Fix (who keeps it), Neighbours (the local paper is the town). Don't promise compensation before you have the facts | A practice version of the declared case. The scenario is a pattern, not Ashgrove's. CASE, scored here on values as well as structure |
| J2 | "The supervisor who closed it feels undermined that you're involved. What do you do?" | CASE | [generic] | Separate the member fix from the supervisor's learning. Talk to the supervisor before the member does; keep the supervisor in the fix where trust allows. Coaching means asking what they saw before telling them what you'd do. Two branch managers are listening, so show you'd back their people | Likely follow-up in the case. Tests the JD's coaching line (F4) live |
| J3 | "What would you change so this doesn't happen again, and how would you know it worked?" | CASE | [generic] | Find the cause: was it a one-off, a branch habit or the process? Then a change sized to it, and a measure in the JD's terms (repeat complaints, resolution times) in the monthly report. Own the Fix: say who keeps hold of it, and until when | The case's likely last move. JD content (F1, F3), CASE delivery |

### Bank K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "My branch is part of the hub changes next year. Why should my supervisors take escalation coaching from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Reciprocity first: what you'd bring their supervisors, not what you need from them. Your basis, at its own scope: "the last 3 as a branch supervisor" (you've sat in their supervisors' seat) and "trained new tellers on our escalation script". Then how you'd coach: ask, listen, back them with members. Don't claim you've coached supervisors | F4 and F6, tested by the people whose teams you'd coach. JD because it's the coaching line |
| K2 | "On a complaint, where does my branch's job end and yours begin?" | CASE | [generic] | Propose principles rather than claiming to know the line already: the branch owns the member relationship and the first fix; you own the process, the pattern, and anything that crosses branches or channels. Disagreements get settled on what the member needs. Then ask how it works today | The seam question. Peers score turf awareness. You don't know Ashgrove's current split, so principles plus a question is the honest answer |

### Bank L: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you over one of our own branch supervisors?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Pause, then three sentences from your quotes: branch supervisor experience; the formal complaints log you handled and the tellers you trained; the spreadsheet you built that your regional manager uses. Concede the real thing: an internal candidate knows Ashgrove's branches and you don't yet. Then say why you'd learn them fast. Don't run down internal people; two of them are interviewing you | A stem built for a panel of insiders. Hold-then-concede is the scored behaviour. JD because it compares fit for the listed job |
| L2 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "I built it." Keep "uses" as your regional manager's. Answer slot: if others added to it or gave you its structure, say who did what, in your own words. If it was entirely yours, say so plainly. Hold through a second push by repeating what you did, adding nothing | F3's sentence is your only reporting evidence, so attribution on it matters. EXP because it's the attribution stem |

### Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "What could someone in this role do in their first month that would genuinely help your branches?" | The reciprocity question. Peers weight it heavily, and the answer is your onboarding plan |
| "How do escalations work from your branches today: who calls whom?" | Shows you'll learn the current seam before redrawing it (K2) |
| "With the move to five hubs, what are your members most worried about?" | Neighbours, Not Numbers turned into a question, and about their towns |
| "What does a complaint handled well look like from your side of the branch?" | Hands them the definition of success. Members First, from people who see members daily |
| "Where do members get stuck between the branch, the contact centre and the app?" | Connects the digital shift to their branches, and shows you're thinking about F5's territory |

---

## Prohibited claims

Things this pack will not coach, and why. Built from the fit snapshot before the question banks were written, which were then written against it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process across branches, or for the region | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not a process across branches. C1's slot stays inside what went beyond your branch, if anything did |
| Has contact-centre experience | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders, executives or a board | A negative you stated, F8 | "I haven't presented to anyone above regional level." No slot on this claim. Whether you presented at regional level is a separate answer slot (B1, C2) |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: tellers, and "our" escalation script. The slots ask only which part of the training or script was yours to shape |
| Owns or produces the region's complaints reporting | Inflated form of F3 | F3's quote at its own scope: you built the spreadsheet, and your regional manager uses it. The slots ask only what it counts and what it's built in |
| "Financial-services customer operations" as a description of your own history | The JD's vocabulary applied to F6's quote | Your own words: six years in retail banking, the last three as a branch supervisor. Let the interviewer make the mapping |

---

## Sources

**Provided documents**
- The JD for Member Experience Lead, pasted
- Ashgrove's values, copied from the values page on 12 November 2026 and pasted. The page was not fetched; it's the source of the pasted text
- The recruiter's email describing the three rounds, pasted
- Your summary of the 2026 strategy brief (published July 2026, sent to you by the recruiter)
- Your background, as written in your message

No `tuesday-dossier.md` was present, so none was consumed. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values you pasted this morning fix the values cheat sheet and the VAL banks; the four names are copied exactly |
| 2. Ashgrove interview process for this role family | skipped | The recruiter's email establishes the loop (three rounds, who runs each, the case and the values scoring), which fixes the persona weights and the loop structure |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief, four months old, fixes the CO questions, the CASE scenarios and the grounding brief |
| 4. Interviewer names at Ashgrove | n/a | No names have been assigned, so there's no query to form. The interviewer read is absent; the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned:** an interviewer read for each person, persona weights from their public professional footprint, and at least one reverse question tied to their own career path
- **One real story per value (a few lines each, in your own words):** H1–H4, D1, D2 and D4 move from selection scaffolds to story-mapped guidance, and the values cheat sheet gets real story rows
- **What your monthly spreadsheet counts, and what it's built in:** the F3 and F9 rows, and G1, B3 and L2, move from answer slots to story-mapped guidance
- **Whether your branch's formal complaints had regulatory rules or deadlines, and your part in them:** F7 and A4 firm up, and J1 can use your real experience
- **Anything that went beyond your branch: complaints passed to region, other branches or other teams:** C1's slot gets a real answer, strengthening the pack's highest-ROI rehearsal
- **Any contact with digital or self-service changes:** F5 moves off `none given`, and E1 gets a story to lean on
- **Whether you have presented at regional level, to whom and on what:** B1 and C2's slots get a real answer
- **Hours you have for prep before 21 November:** a prioritised prep schedule tied to question IDs
- **The full text of the July 2026 strategy brief:** a fuller grounding brief (headline numbers, segment language, the reasoning behind the hubs) and sharper E1, E2 and A3
- **Deep research (L2), on your say-so:** up to 6 more searches and 2 more fetches, several more minutes. It would look at recent Ashgrove news and organisational context (consolidation announcements, leadership changes) and any reports of this loop
- **A `tuesday-dossier.md` from a job-underwriter pass:** an evidence-checked objection for C1, a strategy constraint for each weak area, and a sourced prohibited list. Useful, not required
