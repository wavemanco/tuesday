I'm reading the interview-prep playbook's rules, and next I'll run a short round of web research on Kelverton Rail before I build your pack.
I've built your prep pack and saved it as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. The web searches I tried were declined, so it's built only from your message and the recruiter's email. Anything in it about Kelverton or the rail market is marked as general, and your reading of the market report is where the specifics need to come from.

The pack starts with a schedule for your 4 hours. It then covers:
- a build for the 15-minute talk, with three possible main arguments and one thing to deliberately not do
- the honest wording for your two gaps: no rail sales and no direct quota
- a list of claims to avoid making
- 22 practice questions, weighted towards Ross's commercial push

The one to rehearse most is B1, Ross asking why he should trust you on commercial numbers when you've never carried a direct quota.

Say the word and I'll play Ross on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the job description and your CV to hand? Either one would replace the general requirements with quoted ones and turn the "pick a story" prompts into answers built on your own lines.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack — Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel, on Tuesday
**Panel:** Deepa, VP Partnerships (your future manager), and Ross, Commercial Director
**Format, in the recruiter's words:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."
**Built from:** your message and the recruiter's email, as you quoted it. There was no job description or CV, the market report's content isn't in this conversation, and the web searches were declined, so anything about Kelverton or the rail market below is either your input or labelled `[generic]`.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who asks it and in what register. **Types** describe *what is being scored*:
  - **VAL**: whether your past behaviour shows the values they care about
  - **EXP**: whether your own claims hold up, and what was actually you
  - **JD**: whether you can do the job as stated, gaps included
  - **CO**: how deep your homework goes on the company, its market and its strategy
  - **CASE**: how you structure and reason through a live problem from the role
- Provenance labels: `[grounded]` means traceable to your message or the recruiter's email. `[inferred]` means derived, with the derivation named. `[generic]` means a role-family pattern with no claim about Kelverton.
- An **answer slot** is where only you can fill in the substance. It always has two honest branches, and "that wasn't mine" or "there was no such step" is one of them.
- The guidance is scaffolding, not a script. Say it in your own words.

## Prep triage (about 4 hours over the weekend)

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV from the report and say it aloud twice with a timer. The second run must finish by 14:00 | Section: Graded deliverable |
| 2 | 45 min | The highest-ROI rehearsal: the quota objection, then the £4M walk-through, then the rail ramp plan. Say each aloud until it's boring | B1, D1, C1 |
| 3 | 40 min | Ross's commercials: the number you'd own, deal structure, the margin question | B2, B3, B4, H2 |
| 4 | 30 min | Skim the Case bank and decide on a first move and a prioritisation logic you'd stand behind | A1 to A5 |
| 5 | 15 min | Pick three reverse questions, one for each interviewer plus one spare | Reverse questions |
| 6 | 20 min | One drill on B1 with follow-ups, here or with a friend | B1 |

Everything else in this pack is insurance.

## Fit snapshot

The requirements come from the recruiter's words where she gave them `[grounded]`, and otherwise from role-family patterns `[generic]`. That's because no JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material shows you running a payments ISV channel. It doesn't show rail operator partnerships, and your words stay there: you ran the ISV channel and took it from 6 partners to 40. Answer slot: an 18-month POV invites "how did you plan the 6-to-40 growth". If you set that plan, say how you decided its stages, in your own words. If the plan wasn't yours, or there wasn't one, say so plainly and stay with running the channel |
| F2 | "land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your own framing is the bridge, at its own scope: bus and light rail network planning, and the operator world seen from the other side. It isn't mainline rail, and it wasn't inside an operator. Answer slot: the recruiter's close makes "what do operators actually need" likely. If your consulting put specific operator problems in front of you, name them in your own words. If it didn't, say so and offer your view as a hypothesis |
| F3 | "Ross will push on commercials" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | Influenced revenue is commercial work, but it isn't a direct quota, and you've said so. Your words: "I've never carried a direct quota, only influenced revenue — roughly £4M of it." Answer slot: if any of the channel's commercial terms were yours to set or negotiate, say which and how. If none were, say so plainly and stay with the influenced figure. Never round "influenced" off the number |
| F4 | Selling or partnering into the employer's own sector, here UK train operators | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | A gap you've stated, and wording can't close it. Your words: "I haven't sold into rail specifically." Then the ramp plan, said as a plan and never as a past. Add nothing to make the gap feel smaller |
| F5 | Building and scaling a partner programme | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap, but these are self-reported lines with nothing inspected behind them, so expect a probe. Lead with the quote's own terms: you ran the channel and took it from 6 partners to 40. The channel already had 6 partners when the 4 years started |
| F6 | Senior stakeholder management with customers' leadership teams | none given | none | [generic] | discovery | Strong evidence here would be a named relationship with a customer or partner executive, a moment where it was tested, and what changed because of you. Pick a time from the ISV channel or your consulting years that has all three. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Company homework: the market report | "She also attached the market report their strategy team circulated internally last quarter, which I've read." — your message | medium | [grounded] | none | You've read the panel's own document. Use it the way the Graded deliverable section says: one point from it to show grounding, one place you depart from it, with reasons. Never recite it |

## Graded deliverable — the 15-minute POV

**What was asked, verbatim:** "a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

### Facts to build on

- **From the recruiter:** the 18-month horizon, "operator partnerships" as the subject, the operator-benefit close, and the warning that Ross will push on commercials. That warning means your POV needs a commercials sentence in it, so Ross isn't the first person to raise the topic.
- **From you, at their own scope:**
  - F1/F5: "took it from 6 partners to 40, roughly £4M of influenced revenue"
  - F2: "bus and light rail network planning, so I know the operator world from the other side"
- **From the report:** you hold this and I don't, so the content is yours to supply. Pull three things out of it:
  - (a) what the strategy team means by "operator partnerships"
  - (b) the one conclusion everyone at Kelverton will already have heard
  - (c) one assumption in it you'd test or disagree with

### The move that differentiates you

Open by **defining the term**, not by listing initiatives. "Operator partnerships" could mean deeper strategic relationships with the operators Kelverton sells to. It could also mean third parties that help Kelverton reach and serve operators. Those are different jobs with different economics, and your ISV background is in the second. Say which one you're talking about (check what the report implies), and invite Deepa to correct you. Doing this aloud shows judgement and stops the panel from hearing "payments ISV playbook" before you get there.

The consensus answer will be the report's own recommendations, played back. Bring one of them to show you did the reading. Then spend most of the time on one thesis-driven divergence and one anti-pick, meaning something you'd deliberately *not* do.

### Thesis options (pick one as the spine and use one more as supporting material)

| Thesis | 18-month shape | Mandatory concession | What it means for operators | Provenance |
|---|---|---|---|---|
| T1. A few deep operator partnerships beat broad coverage | 0–6 months: pick 2–3 anchor operators using criteria you state aloud. 6–12 months: joint roadmap or design-partner arrangement. 12–18 months: published outcomes that sell to the next operators | Concentration risk, roadmap capture by one operator, and procurement rules that may limit preferential terms. Say you'd check the last point first | Their planning problems shape the product before they have to work around it | [generic] — anchor the selection criteria on the report's data |
| T2. Partner *around* the operator: the systems they already run next to scheduling | 0–6 months: map which adjacent suppliers each priority operator depends on. 6–12 months: 2–3 integration partnerships. 12–18 months: joint proposals to operators | Integration partners can turn into competitors, the value depends on maintenance, and revenue may land after month 18 | Fewer manual handoffs between systems the operator has already paid for | [generic] — this is where F5's quote is relevant, at its scope |
| T3. Follow the buying decision if it's moving | Only if the report shows decision-making moving away from individual operators. Then partnerships must reach whoever actually decides, and the operator relationship becomes the proof point | If the report doesn't show that shift, drop this thesis. Don't assert market structure the report doesn't carry | Continuity: what they've built with Kelverton survives a change in who buys | [generic] — fully conditional on the report |
| Anti-pick. Don't copy the 6-to-40 volume playbook | Say plainly that a partner count is the wrong target in a market with few buyers, if the report bears that out | You're setting aside the thing you're known for, so say why in one sentence | Operators deal with fewer, better-integrated partners, not more vendors | [generic] — your F5 quote stays at its own scope |

### Suggested 15-minute run (pending your approval)

1. **0:00–1:30 Frame.** What you mean by operator partnerships, and the one question that decides the strategy.
2. **1:30–3:30 What the report tells us.** One consensus point, credited to the report, then the assumption you'd test.
3. **3:30–10:00 The plan.** Your spine thesis in three blocks (0–6, 6–12, 12–18 months), with a kill criterion for each block.
4. **10:00–12:00 Commercials preview for Ross.** How partnerships would show up in revenue: sourced versus influenced, which metric you'd want to be held to, and that you'd set the number after seeing the baseline. Don't invent a figure.
5. **12:00–14:00 What it means for operators.** The close they asked for. Two or three concrete operator outcomes from your theses' right-hand column, plus where F2's vantage point fits: "from the other side," in your words.
6. **14:00–15:00 Concession and hand-over.** "The thing I'm least sure of is ___ — I'd want your read on it."

## Reading the interviewer

Built only from the recruiter's email. A public-profile search for Deepa was declined, so there's nothing on either interviewer's career path.

- **Deepa, VP Partnerships, future manager.** Expect hiring-manager priorities: whether you can do the job, and the risk in your gaps (F1, F4). Her questions decide whether she wants to manage you, so the reverse question for her should be about how she defines success.
- **Ross, Commercial Director, "will push on commercials."** This is pre-announced pressure. Every partnership idea will get a "how does this make money and when" follow-up. His most likely target is F3.
- **Implication:** in a panel the two will hand off to each other. When Deepa asks a strategy question, finish your answer with its commercial consequence before Ross asks for it.
- **Mirror opportunities:** none offered. Without public footprints there's no shared career path to point to.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | POV follow-ups, prioritisation, "what first" | High. It's the dominant prior for Deepa as hiring manager and for Ross as executive, and the 15-minute POV makes the rest of the hour strategy-led | Clarify, state the objective, segment, give the approach, then metrics and risks. Challenge one premise per case |
| Pressure | Ross on commercials: time-boxed, devil's advocate | High. The recruiter pre-announced it, and the executive prior adds Pressure | Pause, restate, anchor in what you actually said, hold through two follow-ups, then concede something real and specific |
| Skeptic | Deepa on the gaps: no rail, no quota, payments to rail | High. It's the hiring-manager prior, and F3/F4 are gaps you've stated yourself | Rehearse the objection until it's boring. Acknowledge plainly, then give the ramp plan |
| Data-Driven Prober | "How was £4M counted?" and "how many of the 40 produced?" | Medium. F1/F5 hold your headline numbers, and a Commercial Director is likely to test them | Know what you can and can't say about how each number was counted, and say when you don't know |
| Conversational | Openers, "what did you make of the report?" | Low. It's a second round, so expect only a short warm-up | A 90-second biography arc, and treat casual questions as scored |
| Values / Behavioral | One or two "tell me about a time" questions | Low. The recruiter's format names no values round | A selection scaffold for each, chosen in advance |
| Peer Evaluator | The seam between partnerships and direct sales or commercial | Low. Neither interviewer is a peer, but Ross's team probably sits beside yours | Propose principles for the seam, not a turf map |

## Question banks

### A — Case / Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If you could only do one thing with operator partnerships in your first six months, what is it?" | CASE | [generic] | Your POV's first block, compressed to 60 seconds: the move, why it comes first, what it unlocks, and the signal at month six that tells you it worked. Name what you'd need to learn in the first 30 days to confirm it. This question needs no claim about your past, so don't make one | The natural follow-up to any 18-month plan. CASE because it tests prioritisation live |
| A2 | "What does an operator actually want from a supplier's partnerships team that it doesn't get from account management?" | CASE, CO | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | You can bring your vantage point, in your words: bus and light rail network planning, the operator world from the other side. Answer slot: the recruiter's operator close makes this probe likely. If your consulting work showed you specific things operators needed from suppliers, name them in your own words. If it didn't, say so and give your view as a hypothesis you'd test with operators in month one | F2 is your strongest asset for the requested close, and also where a relationship-axis stretch ("I know operators") is most tempting. CASE content, CO altitude |
| A3 | "How would you decide which operators to prioritise?" | CASE | [generic] | Clarify first: prioritise for what — revenue, reference value, product learning? Then 3–4 criteria you'd state openly, the data you'd want (point to the report where it has it), and the one operator type you'd deliberately leave out at first | Prioritisation is what T1 and T2 both rest on. A pure CASE question |
| A4 | "What would make you abandon your plan at month nine?" | CASE | [generic] | Name the kill criteria from your POV blocks before they ask, and say what you'd do instead. A ready answer here signals that you plan with exits built in. Hold the plan, and concede the specific assumption it rests on | Tests whether the POV is a conviction or a recital. CASE because it's a live judgement |
| A5 | "Which kinds of partners would you build with first, and which would you not touch?" | CASE, JD | [generic] | One partner type you'd start with and why, tied to your spine thesis. Then the anti-pick, with a one-sentence reason. Say no deliberately: saying no is part of the job | It forces the anti-pick into the open. JD content, CASE delivery |

### B — Pressure, mostly Ross (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota — only influenced revenue. Why should I believe you'll deliver commercial numbers here?" | JD, EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | **The highest-ROI rehearsal in this pack.** Concede first, plainly: "That's right — I've never carried a direct quota; my number was influenced revenue, roughly £4M of it, running the ISV channel." Then hold: say what you'd want to be measured on here and how you'd report it. Answer slot: if any of the channel's commercial terms were yours to set or negotiate, say which and how, in your own words. If none were, say so and stay with the influenced figure. Hold through two follow-ups by going back to those quotes, never by adding to them. Concede the real point: a direct number is new to you. Don't fold on the claim that influenced revenue is commercial work | F3 is the gap the recruiter's "push on commercials" points straight at, so it will come in some form. JD because it scores a commercial requirement, EXP because it tests attribution |
| B2 | "Sixty seconds: what revenue number should partnerships own in 18 months, and how would you measure it?" | CASE | [generic] | Don't invent a figure. Give the shape: which revenue you'd count as sourced versus influenced, the baseline you'd need first, and when you'd commit to a number (for example, after the first 90 days). Then one leading indicator you'd report monthly | Ross is likely to time-box a number. A made-up figure is the trap. CASE because it's structure under pressure |
| B3 | "Walk me through the commercials of a partnership with an operator — who pays whom, for what?" | CASE | [generic] | Clarify which kind of partnership (your POV's definition). Then lay out two or three structures, and for each: what the operator gets, what Kelverton gets, and the risk. End with the one you'd test first and why. Present them as options you'd evaluate, not as practice you've run | The commercial depth of the POV gets tested here. A pure CASE question |
| B4 | "Partners take margin. Why should we give up margin when we already sell direct to operators?" | CASE | [generic] | Accept the premise's cost first. Then reach, or capability, or retention that direct sales can't get alone: which of these your spine thesis buys, and the condition under which you'd agree with Ross and not partner | A classic commercial-director challenge. Holding the position while granting the cost is what's being scored |

### C — Skeptic, mostly Deepa (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail. What's your ramp plan?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Plain acknowledgment, in your words: "I haven't sold into rail specifically." Then a concrete 90-day plan, said as a plan: who you'd sit with, which operators you'd visit, and what you'd read. Then F2's vantage point at its scope: "bus and light rail network planning … the operator world from the other side." Don't bluff domain detail that Deepa knows better than you | F4 is a stated gap and the most predictable hiring-manager risk. JD because sector fit is implicit in the role |
| C2 | "Your consulting was bus and light rail. How much of that carries over to train operators?" | EXP, JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Hold the scope as you gave it: bus and light rail, network planning, consulting. Answer slot: if specific parts of that work carry over to train operators, name which ones, in your own words. If you're not sure how much carries, say so and say what you'd test first. Volunteer the limit before they ask | F2's scope is the seam a skeptic opens. EXP because it tests your own claim |
| C3 | "Payments ISVs and rail operators are very different partners. What from your 6-to-40 doesn't transfer?" | JD, EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Name what doesn't transfer before you name what does. That's the credibility move. What doesn't transfer is your judgement call, from your own experience of the channel. Then one thing that does, in your own words, and stay inside running the channel | F1/F5 are your strongest evidence and the obvious target for a "different world" probe |
| C4 | "Why leave payments — why rail, and why now?" | VAL | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Keep it to 60 seconds: the transport years are where you started, and this role joins those years to your partnerships work. Answer slot: if there's a real reason for the timing, say it in your own words. If there isn't one beyond the role itself, say that | A standard motivation probe, and stronger for you because of F2. VAL because it scores motivation consistency |

### D — Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M influenced figure was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Keep "roughly" and "influenced". Answer slots, in your own words: how the figure was counted, what it's sensitive to, the assumption behind it you'd defend least (say it before they ask), and which part was yours. "I don't know exactly how it was counted" is an honest branch. Never offer an attribution method you can't repeat under a second question | It's your headline metric, and a Commercial Director is the person most likely to ask for the denominator |
| D2 | "Six to forty partners — how many of the forty produced, and how much of that growth was you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: if you know how many partners produced revenue, give the number. If you don't, say so. Then which part of the growth was yours, in your own words. If others signed or recruited partners, say so: "running the channel" is your claim, at its scope | F5's count gets probed for quality as well as quantity |
| D3 | "What would you measure at month three to know the plan is working?" | CASE | [generic] | Two or three leading indicators tied to your spine thesis, plus the one you'd treat as the warning sign. Say how each would be counted | It turns the POV into something measurable, and the Prober scores that |

### E — Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk us through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc in the order of your own two sentences: transport consulting, bus and light rail network planning, then partnerships, running the ISV channel from 6 partners to 40. End on why this role. Keep the numbers worded exactly as you gave them | Second rounds still often open this way, and the arc sets the frame for everything after it |
| E2 | "What did you make of the market report?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | One point you agree with, credited to the report, then one assumption you'd test, with your reason. Answer slot: the content comes from your reading. Don't recite the report back | It's their own document, so reciting it scores as homework and departing from it with reasons scores as judgement |

### G — Values / Behavioral (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Pick a time with a named customer or partner, the metric you set aside, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A natural fit for the operator-benefit theme the recruiter set |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you didn't fold, and the relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | It tests the spine your anti-pick will need. VAL because it scores behaviour |

### H — Peer Evaluator (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Partnerships and direct sales both talk to operators. Where's the seam, and what happens when we disagree?" | CASE, VAL | [generic] | Propose principles, not turf: who leads which conversation, how a disagreement gets escalated, and a shared metric. Say you'd want to agree it with sales in month one | Ross's commercial team probably shares operators with you, so this tests whether you'll create friction |
| H2 | "How do you handle credit when a deal involved both partnerships and sales?" | EXP, CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | You've worked on the influenced side, in your words. Answer slot: if the payments company had a rule for crediting influenced deals, describe it as you understood it. If there wasn't one, or you don't know it, say so and propose a principle. Never present a crediting model as one you ran unless you did | F3 makes credit the sharpest seam question for you. It ties directly to B1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 POV on operator partnerships, 18 months | Graded deliverable, A1, A3, A4, A5, D3 |
| F2 What it means for operators | Graded deliverable close, A2, C2 |
| F3 Commercials | B1, B2, B3, B4, D1, H2 |
| F4 Sector experience | C1, C2 |
| F5 Scaling a partner programme | C3, D2, E1 |
| F6 Senior stakeholder management | G1, G2. There's no dedicated question because the recruiter's email doesn't raise it, so the scaffolds cover it |
| F7 Report homework | E2, Graded deliverable |

## Reverse questions

| Question | Why it lands |
|---|---|
| To Deepa: "When you say 'operator partnerships', what do you mean today — and what do you want it to mean in 18 months?" | It closes the definitional loop your POV opened, and you learn the real scope |
| To Deepa: "What would make you say, twelve months in, that this hire was the right call?" | Your future manager's success criteria, asked directly |
| To Ross: "How is partnership revenue credited against sales today — and would you change that?" | It meets his commercial lens on your own weak spot (F3) and shows you're not avoiding it |
| To both: "Which conclusion in the strategy team's report do you two disagree with most?" | It uses their own document without reciting it, and it reveals the live debate |
| "Where do operators feel the relationship with Kelverton is weakest right now?" | It keeps the close on operators, which is what they asked for |
| "What's the hardest partnership decision you've had to say no to recently?" | It shows you expect the job to involve saying no |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried or hit a direct revenue quota | Negative you stated, F3 | "I've never carried a direct quota, only influenced revenue." No slot |
| "Generated", "closed" or "drove" £4M, or £4M without "influenced" or "roughly" | Inflated form of F3 | The F3 quote at its own scope: roughly £4M of influenced revenue. D1's slots stay inside how it was counted |
| Has sold into rail | Negative you stated, F4 | "I haven't sold into rail specifically." No slot |
| Worked inside or for train operators | Inflated form of F2 (relationship axis) | The F2 quote at its own scope: transport consulting, the operator world "from the other side". The material says consulting, not operator-side |
| Mainline or heavy-rail network planning | Inflated form of F2 (scope axis) | The F2 quote: bus and light rail network planning. C2's slot asks only what carries over |
| Built the ISV channel from scratch, or founded it | Inflated form of F5 | The F5 quote: took it from 6 partners to 40. The material shows 6 partners already in place |
| Personally signed or recruited all of the partners | Inflated form of F5 (scope axis) | The F5 quote at its own scope: running the channel. D2's slot asks which part of the growth was yours |

## Sources

**Provided inputs:**
- Your message: your background and your account of the recruiter's email, with her words quoted.
- The market report: mentioned, but its content isn't in this conversation, so nothing in this pack comes from it.

No dossier was present.

**Searches sent:**
- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships": refused
- "Kelverton Rail scheduling software train operating companies news 2026": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Senior Partnerships Manager rail software job description UK train operators": refused

No fetches were sent.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. Would have themed the VAL questions with published values. No values-style round was detected, so there's no cheat sheet either way |
| 2. `Kelverton Rail interview process partnerships` | unavailable | The search was refused. The recruiter's email already sets out the format of the session, so the persona weights rest on her words |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The search was refused. Would have grounded the CO questions and the theses in current company moves. They're `[generic]` instead, with the report as your anchor |
| 4. `Deepa / Ross, Kelverton Rail` | unavailable | The one call, for Deepa, was refused, and none was sent for Ross after that. Would have added career-path detail to the interviewer read and a profile-tied reverse question |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The search was refused. Would have turned the `[generic]` rows F4 to F6 into quoted `[inferred]` requirements |

## Upgrade menu

- **The job description** → rows F4 to F6 become quoted `[grounded]` requirements, and the JD-tagged questions get checked against its own list.
- **Your CV** → more evidence quotes, so selection scaffolds (F6, G1, G2) can become story-mapped answers.
- **The report's three key points (definition, consensus conclusion, the assumption you'd test), if you're comfortable sharing an internal document** → the theses move from `[generic]` to grounded in their own material.
- **Web search enabled** → targets 1 to 5 run. There's also an optional deeper pass on strategy, interviewers and recent organisational changes: up to 6 more searches and 2 more fetches, taking several more minutes.
- **Deepa's and Ross's public profiles, pasted** → a real interviewer read, career-path mirror opportunities and a tailored reverse question each.
- **A partner pipeline or attribution report from the ISV channel (even just knowing what it contained)** → this is the artifact that would raise F3 and F5 above `medium`.
- **Your answers to the B1, D1 and D2 slots** → those rows, and F3/F5, regenerate on your own confirmed words.
- **A tuesday-dossier.md** from an earlier evaluation of this role → the strongest objection would come from evidence you'd confirmed rather than being inferred, and a prohibited-claims list would be carried forward.
