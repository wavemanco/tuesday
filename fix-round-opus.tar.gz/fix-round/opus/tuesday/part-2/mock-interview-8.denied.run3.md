No dossier in the working directory. Reading the module's reference files.
I've built your prep pack for all three rounds on 21 November, using the round details from the recruiter's email. It's saved at /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-8-denied-e55a178f/ashgrove-credit-union_member-experience-lead_interview_pack.md.

Your materials covered everything it needed, so I ran no web searches.

**What to practise first.** Question C1, in the round with the Head of Member Services: you've handled one branch's complaints log, but this job covers every branch plus the contact centre, which you haven't worked in. That's the objection most likely to come up. The pack has you say "I haven't worked in a contact centre" before they press it, stick to what you've actually done, and then give a plan for your first month.

**The other gap.** You haven't presented to anyone above regional level. Same approach: say it plainly, then give a plan. It's rehearsed in all three rounds, at the recruiter level (B3), the manager level (C2) and under pressure from the panel (L2).

**The panel round.** There's a 20-minute plan for the complaint case. It suggests three positions, each with a trade-off you say out loud, and a way to stand out from the obvious "apologise, investigate, resolve" answer. There's also a sheet for the four values. I couldn't pick your stories for those because nothing you've told me covers them yet, so it gives you criteria for choosing real ones from memory.

**Things to check before the 21st.** Where I didn't know a fact, the pack doesn't guess. It gives you two honest ways to answer, and either is fine. These will go better if you check:
- What your monthly complaints spreadsheet actually counts, and whether it's in Excel.
- Whether your branch's formal complaints came under any regulator's complaint rules.

The pack also lists claims it won't coach because they would stretch your experience, such as "ran complaints across branches" or "coached supervisors". It shows the accurate wording to use for each instead.

Say the word and I'll play the sceptical manager on C1.
I can also save a tuesday-dossier.md recording the gaps this prep turned up, for you to bring to later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date:** all three rounds on Friday 21 November 2026, nine days from this pack (12 November 2026)
**Loop, from the recruiter's email:** Round 1, 30 minutes with the recruiter. Round 2, 45 minutes with the Head of Member Services (your future manager), "mostly behavioural". Round 3, 60 minutes with a panel of two branch managers, including "a 20-minute case on a complaint escalation". The panel "is also the values round — they score against the four values."
**Interviewers:** names not assigned yet, so this pack has no interviewer read.

This is a loop pack. The fit snapshot, the grounding brief and the sources are shared. Each round then gets its own mini-pack: persona weights, a question bank and reverse questions. The case build and the values cheat sheet sit with Round 3.

---

## How to use this pack

- **Personas** describe how a question will be asked: friendly, sceptical, under time pressure. **Types** describe what is being scored. Rehearse both, because the same question lands differently depending on who asks it.
- **Type key:**
  - **VAL**: values. Does your past behaviour show Ashgrove's four published values?
  - **EXP**: experience deep-dive. Does what you said about your background hold up, and what was actually yours?
  - **JD**: job description. Can you do the listed job, including the parts you haven't done?
  - **CO**: company and strategy. Have you done the homework, and can you think at Ashgrove's level?
  - **CASE**: a live problem. How you structure and reason, out loud.
- **Provenance labels.** `[grounded]` means traceable to something you gave me: your message, the JD, the values text, the recruiter's email or the strategy summary. `[inferred]` means the pack's own derivation, with the derivation named. `[generic]` means a common pattern for this kind of role, with no claim about Ashgrove or about you.
- **Answer slots.** Where the pack doesn't know something about your past, it doesn't guess. It gives you an instruction with two honest branches: say how, if you did it; say plainly, if you didn't. Either branch is a good answer.
- **Guidance is scaffolding, not a script.** Say it in your own words. Each cell should take 90 to 120 seconds to say out loud.

---

## Prep triage: nine days

Do these in order. Each one is tied to a section or question ID.

1. **C1, out loud, three times, with its follow-ups.** This is the highest-ROI rehearsal in the pack: the jump from one branch's complaints log to a process that also covers the contact centre. Get the plain acknowledgment and the plan smooth enough to be boring.
2. **Round 3 case build, then J1 timed at 20 minutes.** It's graded, it's scored against the values, and it's the part you can practise most directly.
3. **Values cheat sheet: choose your four stories (H1 to H4).** The pack can't supply them because your material carries none yet. Choose real ones from your own memory using the scaffolds.
4. **G1 and G2: open your monthly complaints spreadsheet.** Know what it counts and what tool it's built in before someone asks.
5. **B1 and the F7 slot.** Work out whether the complaints in your branch's formal log came under any regulator's complaint rules, and which ones.
6. **A1: a 90-second biography arc.**
7. **Grounding brief: learn the vocabulary,** so that "hubs", "digital channels" and "member" come naturally.

Everything else is insurance.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not a process across branches. The words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what was yours likely. If any part of how the log was kept or used was yours to decide, say which part and how, in your own words. If none was, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You stated this gap, and no wording can close it. Words: "I haven't worked in a contact centre." Then say how you would learn the contact centre's complaint path, as a plan and never as a past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material shows a monthly complaints spreadsheet you built. It doesn't show what the spreadsheet counts. Words that stay inside the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet tracks. If it counts either one, say how, in your own words. If it tracks other things, say what they are. If it counts neither, say so plainly |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Training new tellers is not the same as coaching supervisors, so don't stretch the bridge. Words at the quotes' scope: "I trained new tellers on our escalation script," and "for the last three years I've been a branch supervisor." Answer slot: the JD's coaching line makes a probe on how you trained likely. If how the teller training ran was yours to shape, say how, in your own words. If it wasn't, say so plainly and stay with the training you gave |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a time you fed what members complained about into a change to a digital or self-service journey, or worked alongside a team that built one. Answer slot: if you have done any of this, say what it was and what your part was, in your own words. If you haven't, say so plainly, then describe what you would bring a digital team from the complaints side, as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. It's still a line with nothing inspected behind it, so expect a probe. Say it in the quote's own terms (six years in retail banking, the last three as a branch supervisor) and let the interviewer map it to the requirement. Don't relabel your history in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says "formal" complaints. It doesn't say whether they fell under a regulator's complaint rules. Answer slot: if they did, name the rules or deadlines that applied, in your own words. If they didn't, or you're not sure, say so plainly and describe the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You stated this gap. Words: "I haven't presented to anyone above regional level." Your sentence doesn't say whether you have presented at regional level, so this pack doesn't say it either. Then say how you would prepare, as a plan. Add nothing to make the gap feel smaller |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says "spreadsheet", not Excel. Answer slot: if it's built in Excel, say so and say what you built in it, in your own words. If it's built in another tool, name the tool and say plainly what you have and haven't done in Excel |

**Reading the snapshot.** No row is a gate: the JD's requirements are all experience and skills, not eligibility terms. The two `capability` rows, F2 and F8, are gaps you stated yourself. That's a strength: you can name them before anyone else does. The `discovery` rows (F3, F5, F7 and F9) are where a few minutes with your own records or memory could turn an answer slot into a story.

---

## Grounding brief (shared)

Built from the strategy summary you gave me (Ashgrove's 2026 strategy brief, published July 2026, about four months old), the JD and the values text. Use it to sound current. Don't recite it.

| Item | What it says | Provenance |
|---|---|---|
| Ownership and size | Member-owned, about 900 staff | [grounded] JD |
| Their word for customers | "member", as in "member complaints", "member's side of the counter". Use it every time | [grounded] JD and values text |
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] strategy brief, July 2026 |
| Branch footprint | Consolidate eight branches into five hubs over 2027 | [grounded] strategy brief, July 2026 |
| New product | A small-business lending product launches in Q1 2027 | [grounded] strategy brief, July 2026 |
| Competition | The main competitive pressure is app-only banks | [grounded] strategy brief, July 2026 |
| What it may mean for this role | The hub consolidation and the digital shift both fall within the role's first year or so. Both change where and how members will complain: at fewer, larger sites and through self-service journeys. That's why the JD pairs complaints with "work with digital teams on self-service journeys" | [inferred] from the brief's timeline set against the JD's remit; a reading, not a fact Ashgrove has stated |
| What it may mean for this role | A new lending product for small businesses may bring complaint types the branches haven't handled before | [inferred] from the brief's Q1 2027 launch; ask rather than assert |
| What it may mean for this role | Competing with app-only banks on service tends to put weight on the in-person and plain-language strengths their four values describe | [inferred] from the competition line and the values text; frame as your reading |

No stale framings to flag: the summary is under six months old. You have the recruiter's summary, not the full brief. If the brief has headline numbers beyond these four, they aren't in this pack (see the upgrade menu).

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end, branches and contact centre (F1, F2) | B2, C1, J1, L1 |
| Report monthly on complaint volumes and resolution times (F3) | G1, D1 |
| Coach branch supervisors on escalations (F4) | C3, J2, K1 |
| Work with digital teams on self-service journeys (F5) | C4, D2 |
| 4+ years in financial-services customer operations (F6) | B4, A1 |
| Experience handling regulated complaints (F7) | B1, E1 |
| Confident presenting to senior leaders (F8) | B3, C2, L2 |
| Comfortable with Excel reporting (F9) | G2 |

Every published value has a VAL question in Round 3 (H1 to H4). Strategy is covered by A4, D2, D3 and J3.

---

# Round 1: Recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly openers: "walk me through", "why us". Feels unscored | High. This is the prior for a recruiter screen, and 30 minutes leaves room for little else | A rehearsed 90-second arc (A1). Treat every casual question as scored |
| Skeptic (light) | Knock-out checks against the JD's requirements, asked gently | Medium. Recruiters screen against the requirements list before passing you to the manager | Name F2 and F8 plainly if they come up. Don't let a friendly tone pull you into overclaiming |
| Values / Behavioral, Case, Prober, Pressure, Peer | Unlikely here | Low. The recruiter has put these in Rounds 2 and 3 | Covered in later rounds |

### Question bank, Round 1

**A: Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, in this order: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log. You trained new tellers on your escalation script. You built the monthly complaints spreadsheet your regional manager uses. Close on the thread: complaints keep showing up in your work, and this role is that thread full time. Say the reason in your own words. Don't summarise this as "running complaints" | The near-certain opener. It's where to set out F1, F3, F4 and F6 at their true scope before anyone probes them. EXP because it sets up every later probe on what was yours. It also covers F6's requirement in passing |
| A2 | "Why Ashgrove, and why a credit union?" | VAL | [grounded] | Pick the reason that is genuinely yours. If it's the member-owned model, say what about it matters to you. If one of the four values drew you, name it by its official name ("Members First, Always", "Plain Words", "Neighbours, Not Numbers", "Own the Fix") and say why, in your own words. If no reason comes to mind beyond the role itself, say so plainly and speak to the role | Motivation consistency is the recruiter's knock-out check. VAL because the answer is scored against their published values; `[grounded]` because the values are the text you pasted |
| A3 | "Why are you looking to move on from the branch now?" | EXP | [generic] | Give the genuine reason, short, and pointed forward at this role rather than away from your current one. Never criticise your current employer. If the honest answer is "I want to do complaints across more than one branch", that's a good answer. Say it only if it's true | A standard screen question. EXP because it tests whether your story is consistent. `[generic]` because nothing about Ashgrove shapes it |
| A4 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name the four moves from the July 2026 brief in one breath: 40% of member service to digital by 2028, eight branches into five hubs over 2027, small-business lending in Q1 2027, and app-only banks as the main pressure. Then say which one you'd most want to understand for this role, and why, in your own words. Hubs and digital are the natural picks for a complaints role. Frame it as interest, not expertise | Recruiters test homework. The brief came from them, so not knowing it would cost you. CO because it scores strategy fluency |
| A5 | "What are your salary expectations, and what's your notice period?" | JD | [generic] | Have your own figure or range ready, and your actual notice period. Answer slot: if you've researched pay for this level, give your range and say it's flexible within reason. If you haven't, say you'd like to understand the full package first. Don't invent a number to sound decisive | A standard logistics check. JD because it's a term of the role. `[generic]` because the pack holds no pay data for Ashgrove |

**B: Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for experience handling regulated complaints. Tell me about the complaints you've handled." | JD | [grounded] "I handled the branch's formal complaints log" | Say the log in those words: you handled the branch's formal complaints log. Answer slot: the JD's "regulated complaints" line makes a probe on whether these complaints were regulated likely. If they were, say which rules or deadlines applied, in your own words. If they weren't, or you're not sure, say so plainly and describe the log you handled | F7 is a JD requirement your material touches but doesn't settle, so a recruiter checking the list will ask. JD because it scores a stated requirement |
| B2 | "This role covers the contact centre as well as branches. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment, first and without apology: "I haven't worked in a contact centre." Then one sentence of plan, such as how you'd learn the contact centre's complaint path in your first weeks, said as what you would do. Stop there. The manager round will go deeper (C1) | F2 is a stated gap against half the JD's opening line. A recruiter may flag it early. JD because it scores the stated remit |
| B3 | "The role asks for confidence presenting to senior leaders. What's your experience?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words. If you haven't, say so plainly. Then one sentence on how you'd prepare for a first senior presentation, as a plan | F8 is a stated gap against a listed requirement. Rehearsing it here makes L2 easier later. JD because it scores the requirement |
| B4 | "The JD asks for four years in financial-services customer operations. Talk me through yours." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | In the quote's own terms: six years in retail banking, the last three as a branch supervisor. Let the recruiter tick the box. Don't restate it in the JD's vocabulary | F6 has no gap. Every hard requirement gets a JD question, and this one is quick to clear. JD because it's a listed requirement |

### Reverse questions, Round 1

| Question | Why it lands |
|---|---|
| "How is the 20-minute case run: a scenario sent in advance, or given on the day?" | It's logistics only the recruiter can answer, and it changes how you rehearse the case build |
| "Is there anything in my background you'd like me to be ready to speak to with the Head of Member Services?" | It invites the recruiter to tell you the objection they've already spotted, which is free prep for C1 |
| "Does the complaints remit for this role change as service moves to digital channels?" | It shows you read the brief, and the answer tells you how much of F5 matters in Round 2 |
| "What happens after 21 November, and when would I hear?" | A legitimate process question, and it gives the recruiter an easy close |
| "Is this a new role or a replacement?" | It tells you whether you'd be building the complaints process or inheriting one, which reframes Round 2 |

---

# Round 2: Head of Member Services, your future manager (45 minutes, "mostly behavioural")

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: contact centre, senior presenting, coaching supervisors, digital | High. The prior for a hiring manager, and your stated gaps (F2, F8) sit in this person's own remit | Rehearse C1 until it's boring. Bridge only from your quoted sentences, say limits plainly, and have a concrete ramp plan |
| Values / Behavioral | "Tell me about a time…" prompts, expecting STAR-shaped stories | High. The recruiter said this round is "mostly behavioural", which lifts it above the manager-round prior | Pick real stories from memory using the scaffolds. Use "we" for context and "I" for your part |
| Case / Strategist | Short live problems on the manager's actual roadmap: resolution times, hubs, digital | Medium. The prior for a hiring manager, pulled down by "mostly behavioural" | Clarify, then state the objective, structure, approach, metrics and risks. Think aloud |
| Data-Driven Prober | "What does your spreadsheet actually count?" | Medium-low. The role reports monthly on volumes and resolution times, and F3 is your nearest evidence | Know what the spreadsheet counts and what tool it's in (G1, G2) |
| Pressure | Time-boxing or devil's advocate | Low. Nothing in the loop signals it for this round | L1 and L2 in Round 3 cover it |

### Question bank, Round 2

**C: Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This job owns complaints end to end across branches and the contact centre. You've handled one branch's complaints log, and you haven't worked in a contact centre. Why are you ready?" | JD | [grounded] "I handled the branch's formal complaints log" "Never worked in a contact centre" "I built the monthly complaints spreadsheet our regional manager uses." | **The highest-ROI rehearsal in this pack.** Name the limit before they finish pressing it: "I haven't worked in a contact centre." Hold on exactly what your sentences carry: "I handled the branch's formal complaints log," and "I built the monthly complaints spreadsheet our regional manager uses." Then a plan, said as a plan: how you'd learn the contact centre's complaint path first, for example by sitting with the people who log complaints there and comparing the path with a branch's. Follow-up 1, "So you'd be learning half the job?": yes, on the contact-centre side. Say so, and don't fold on the branch side. Follow-up 2, "Why not hire someone who's run contact-centre complaints?": don't argue with a candidate you can't see. Go back to your two sentences and the plan. Follow-up 3, "What does your first month look like?": the plan, in order. Never widen the log into "a process" | F1 and F2 together are where the JD's opening line presses hardest on your material, so your future manager will raise this in some form. JD because it scores the headline remit. The guidance holds only what the quotes carry and concedes F2 in your own stated words |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Pick one real answer and don't dress it up as a strength. Either "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level." Then what you'd do about it in the first months, as a plan. Choose the one you have the better plan for. Both are true, and neither needs softening | A classic Skeptic stem. F2 and F8 are your stated gaps, so a fake weakness here would be visible. JD because it scores self-assessment against the listed job |
| C3 | "Coaching branch supervisors is different from training new tellers. Why do you think you can do it?" | JD | [grounded] "trained new tellers on our escalation script" "6 years in retail banking, the last 3 as a branch supervisor." | Hold on what the quotes say: you trained new tellers on your escalation script, and for the last three years you've been a branch supervisor. Let the interviewer draw the link to coaching supervisors; don't assert it. Concede the difference in a sentence. Answer slot: the JD's coaching line makes a probe on how you trained likely. If how the teller training ran was yours to shape, say how, in your own words. If it wasn't, say so plainly and stay with the training you gave | F4 is a transferability row, and the manager will test the scope step from tellers to supervisors. JD because it scores a stated responsibility |
| C4 | "The role works with digital teams on self-service journeys. What have you done there?" | JD | [grounded] | Answer slot: the JD's digital line raises this. If you've worked with a digital team, or on any change to a self-service journey, say what it was and your part, in your own words. If you haven't, say so plainly, then give your view of what complaints can tell a digital team, as an idea for this role and not a past | F5 has no evidence in your material, and the 40% digital target makes it live for your manager. JD because it's a stated responsibility. The label stands alone because the guidance makes no claim about your past |

**E: Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a complaint you handled that escalated beyond the branch." | EXP | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one where you can name what the member wanted, what you did, what happened next and what you'd do differently. "I" for your part. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry (you handled the branch's formal complaints log) or how you would handle one | The JD's escalations line is the theme, and "mostly behavioural" makes an open prompt on complaints near-certain. EXP because it tests what was actually yours. Your material carries no escalation story yet, so this is a scaffold |
| E2 | "Tell me about a complaint where the first fix didn't work." | VAL | [generic] | Selection scaffold: it needs a first attempt that failed, what you learned from that, and what you did next. This is "Own the Fix" territory, so make it clear who kept hold of it. If no such time comes to mind, say so plainly, then say how you would handle it | Theme from the "Own the Fix" value and the JD's complaints remit. VAL because your manager may score values informally too. `[generic]` because no quote carries the story |
| E3 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: a named stake, the moment you said it, how you said it, and a relationship still intact afterwards. Choose one where the hard truth actually landed. If none comes to mind, say so plainly, then give the nearest thing you have, or how you'd handle it | A standard behavioural stem, and it's relevant because this role reports to senior leaders (F8). VAL because it probes candour. `[generic]` because no quote carries it |

**D: Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Complaint resolution times have crept up for three months. Where do you start?" | CASE | [generic] | Clarify first: how is resolution time measured, is it all channels or one, and has the volume or mix of complaints changed? Then segment by channel (branch, contact centre, digital), by complaint type and by stage where time is lost. Form two or three hypotheses, then the one metric you'd watch weekly. Risk: fixing the average while the oldest complaints get older. Don't claim you've done this before; reason it live | It's the JD's monthly reporting line as a live problem. CASE because there's no past in the premise. `[generic]` because it's a pattern, not Ashgrove's data |
| D2 | "We're moving 40% of member service to digital by 2028. What does that do to complaints, and what would you do about it?" | CASE | [grounded] | Think aloud. Some complaints will move into the digital journeys themselves; complaints data can show a digital team where a journey confuses members (a "Plain Words" link); and members who don't go digital still need a path. Pick one thing you'd set up in your first quarter, say why, and give its concession: the digital teams own the journeys, and you'd bring evidence, not orders | The brief's headline target meets the JD's digital line. CASE delivery, with CO content, which counts as the strategy-grounded question. `[grounded]` on the brief |
| D3 | "Eight branches become five hubs during 2027. How should the complaints process get ready?" | CASE | [grounded] | Clarify: which towns lose a branch, and when? Then think aloud. Complaints may rise about the change itself, about travel and about account moves. Keep a named owner for each town's members through the move. Track complaint types before and after so you can see what the move caused. Concession: some complaints about a closure can't be fixed, only answered honestly and plainly | The brief's consolidation falls in this role's likely first year. CASE because it's a live problem. `[grounded]` on the brief |

**G: Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about the monthly complaints spreadsheet you built. What does it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the quote states: you built it, it's monthly, and your regional manager uses it. Answer slot: the JD names complaint volumes and resolution times, so expect a probe on those. If the spreadsheet counts either one, say how each is counted, in your own words. If it tracks other things, say what. Never describe a column it doesn't have. Before the interview, open the actual spreadsheet and check | F3 is your nearest evidence for the reporting requirement, and a manager will want to know what it measures. EXP because it tests what you built |
| G2 | "Is that in Excel? How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the spreadsheet is in Excel, say so and say what you built in it, in your own words. If it's in another tool, name the tool and say plainly what you have and haven't done in Excel. Don't name features you haven't used | F9 reads "spreadsheet", not Excel, and the JD names Excel. JD because it scores a listed requirement |

### Reverse questions, Round 2

| Question | Why it lands |
|---|---|
| "What would you want to see from this role in the first monthly report?" | It's what your future manager will judge you on, and it shows you think about the output, not just the job |
| "How do complaints from the contact centre and the branches come together today?" | It's your F2 gap turned into curiosity, and the answer is your first-month map |
| "Who reads the monthly report, and what decisions does it drive?" | It tells you the senior audience you'd present to (F8), and signals that you see reporting as a decision tool |
| "How do you expect the move to five hubs to change what branch supervisors escalate?" | It ties the brief to the coaching remit (F4), which is the role's sharpest strategy link |
| "What support would there be for presenting to senior leaders in the first few months?" | It's candour about F8 put forward as a plan, which reads as self-awareness rather than weakness |

---

# Round 3: Panel of two branch managers (60 minutes, including a 20-minute case; scored on the four values)

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Prompts mapped to "Members First, Always", "Plain Words", "Neighbours, Not Numbers" and "Own the Fix" | High. The recruiter said the panel "score against the four values" | One real story per value (H1 to H4). Use each value's official name once, naturally |
| Case / Strategist | The 20-minute complaint escalation case, plus short follow-on problems | High. The recruiter named the case | Use the case build below: clarify, structure, walk through, recommend, then close on what the member gets |
| Peer Evaluator | "Where does your role end and our supervisors' begin?" | Medium. You'd coach these managers' supervisors on escalations, so they're pricing what you add to their load. Following the panel rule, both members are blended as branch-side stakeholders | Use reciprocity framing and propose principles for the boundary (K1, K2) |
| Pressure | Devil's advocate on your gaps, possibly time-boxed | Low to medium. Two interviewers tag-teaming can feel like pressure even when it isn't meant to | Use hold-then-concede (L1, L2) |
| Skeptic, Prober, Conversational | Gaps resurfacing in branch-side language | Low. Covered in Rounds 1 and 2 | Your C1 answer carries over |

### Question bank, Round 3

**H: Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold: it needs a real decision, what the member needed, what pulled the other way (a rule, a target, convenience), what you chose and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd decide now | Themed by "Members First, Always — we decide from the member's side of the counter." VAL because the panel scores this value by name. `[grounded]` on the values text; no quote of yours carries the story yet |
| H2 | "Tell me about a time you had to explain something more simply, to a member or a colleague." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: something that was hard to understand, who needed it, what you changed about how you said or wrote it, and how you knew it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (you trained new tellers on your escalation script) or how you'd approach it | Themed by "Plain Words — if a member needs it explained twice, we wrote it wrong." VAL because it's a scored value. F4 is the nearest material, offered only as the honest fallback |
| H3 | "Tell me about a time your branch's place in its town shaped how you handled something." | VAL | [grounded] | Selection scaffold: a specific local situation, why the town mattered to the decision, what you did and what it meant for the members involved. If no such time comes to mind, say so plainly, then say how you'd keep each town in view through the move to hubs | Themed by "Neighbours, Not Numbers — every branch is part of its town." Live because of the consolidation. VAL because it's a scored value |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] | Selection scaffold: a problem you found, the point where you could have passed it on, why you didn't, and how it ended. "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you'd do it in this role | Themed by "Own the Fix — whoever finds the problem keeps hold of it until it is solved." It's the value closest to "own the member complaints process", so the panel will lean on it. VAL |

**J: Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member's complaint has been passed between a branch and the contact centre for two weeks, and they've now asked for the branch manager. Take us through it." | CASE | [generic] | Run the case build below at full length, timed at 20 minutes. Clarify first: what the member has been told and by whom, what they want, whether a regulatory deadline applies, and whether they're vulnerable. Then one owner from today (Own the Fix), a plain-words reply to the member (Plain Words), the remedy decided from their side (Members First, Always), and the cause logged for the monthly report | A likely shape for the declared escalation case, and it lands on F2's seam. CASE. `[generic]` because the scenario is the pack's, not Ashgrove's |
| J2 | "One of the supervisors keeps escalating complaints they could resolve themselves. What do you do?" | CASE | [generic] | Clarify: is it confidence, authority or the script? Look at three or four of their escalations with them. Agree what they can resolve and what must come up. Then check back after a month. Concession: sometimes escalating is the right call, and you'd say so. Don't claim you've coached a supervisor before; reason it live | The JD's coaching line as a live problem, and these panellists manage those supervisors. CASE |
| J3 | "A branch is closing into a hub and members are complaining about the closure itself. What do you do?" | CASE | [grounded] | Separate the complaints you can fix (access, account moves, how members were told) from the one you can't (the decision). Answer the decision honestly and in plain words, and fix the rest fast. Keep a local point of contact through the move (Neighbours, Not Numbers). Concession: being honest about the decision will disappoint some members, and that's still better than evasion | The brief's consolidation set as a branch-side problem. It tests two values at once. CASE, `[grounded]` on the brief |

**K: Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You'd be coaching our supervisors on escalations. Where does your role end and ours begin?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Propose principles; don't pretend to know their boundaries. For example: the branch keeps hold of the member, you keep hold of the pattern, and you agree the escalation thresholds together. You can say that for the last three years you've been a branch supervisor, and stop there. Let them draw the inference. End by asking how they'd want it to work | These managers are pricing what you add to their load. JD content (coaching supervisors), peer delivery |
| K2 | "What would you need from us, and what would we get from you?" | JD | [generic] | Reciprocity. What they'd get: a monthly complaints picture by branch and a consistent escalation approach, as a plan. What you'd need: time with their supervisors, and honest data on escalations. Keep it about their branches | A standard peer stem. It scores partnership fit. `[generic]` because it's a pattern |

**L: Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you over someone who's run complaints for a contact centre?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." | Pause, then restate. Hold: you handled the branch's formal complaints log, and you built the monthly complaints spreadsheet your regional manager uses. Concede specifically: "I haven't worked in a contact centre." Close on how you'd close that gap. Don't knock the other candidate. If they push again, hold the same two sentences and don't add to them | F2 resurfaces in a tougher register. Hold-then-concede is the point of the rehearsal. JD because it scores the remit |
| L2 | "You've never presented above regional level. How do we know you'll hold the room with senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses." | Concede plainly, without hedging: "I haven't presented to anyone above regional level." Hold on what you have: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if you've presented at regional level, say to whom and about what, in your own words. If you haven't, say so plainly. Then give the preparation plan. Don't promise confidence; describe how you'd prepare | F8 is a stated gap that a panel can press harder than the recruiter did. The negative in the question is one you stated, so it can be asked. JD |

### Case build: the 20-minute complaint escalation (graded deliverable)

**What you know about the case.** The recruiter said it's "a 20-minute case on a complaint escalation". The panel is two branch managers, and the round is scored against the four values. The JD frames the remit as complaints across branches and the contact centre, coaching supervisors on escalations, and regulated complaints. The brief adds hubs and digital.

**What you can say about yourself in it.** Only the sentences already in the fit snapshot. From F1: "I handled the branch's formal complaints log." From F4: "trained new tellers on our escalation script." Use them only if they fit naturally. The case is scored on reasoning, not on your CV.

**A shape for 20 minutes** `[generic]`: about 2 minutes to clarify, 3 to set out your structure, 10 to work through it and 3 to recommend, leaving 2 for their questions.

**Clarifying questions to ask first:**
- What has the member been told so far, and by whom?
- What does the member actually want: an answer, a remedy, an apology?
- Does a regulatory complaint deadline apply, and where are we against it?
- Is the member vulnerable or at risk of harm?
- What authority does this role have to put things right?

**Three defensible positions, each with its concession:**

| Thesis | Concession you say out loud |
|---|---|
| Fix it for this member first, then fix why it happened | The root-cause fix may belong to another team and take months. Promise the member what you can deliver, not what you hope for |
| Coach the supervisor through it instead of taking it over | If a deadline is close or the member is vulnerable, you step in, and you say why |
| Every escalation becomes a line in the monthly report | The report must never slow the member's answer. Log it after resolving if you need to |

**How to differentiate.** The consensus answer is "apologise, investigate, resolve, follow up". Any prepared candidate gives it, so give it too, briefly, to show you know it. Then add two things.
- **Use the values by name where they decide something:** "Own the Fix" for who holds the complaint, "Plain Words" for the reply to the member, "Members First, Always" for choosing the remedy, "Neighbours, Not Numbers" for the branch's local context. The panel is scoring these.
- **Link it forward:** say what this case would tell you about the hub move or a self-service journey, framed as a question you'd take away rather than a claim.

**The anti-pick.** Say no to promising an outcome before the facts are in, and no to passing the member on without a named owner. Saying either "no" out loud is the judgement this role needs.

**Close on the member:** what they get, by when, and from whom.

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide as the member would see it, not as the process would | Selection scaffold: no sentence in your material carries a story for this yet. Choose a decision where the member's need beat a rule or a target and you chose the member's side. If none comes to mind, say so plainly and say how you'd decide now. See H1 |
| Plain Words | If it needs explaining twice, rewrite it | Selection scaffold: a time you made something simpler for someone. If none comes to mind, say so plainly and give the nearest thing your material carries, F4: "trained new tellers on our escalation script". See H2 |
| Neighbours, Not Numbers | Every branch belongs to its town; treat it that way | Selection scaffold: a time local context changed what you did. If none comes to mind, say so plainly and say how you'd keep towns in view through the hub move. See H3 |
| Own the Fix | Whoever finds a problem keeps it until it's solved | Selection scaffold: a problem you found and didn't pass on. If none comes to mind, say so plainly and say how you'd do it here. Nearest material, F1: "I handled the branch's formal complaints log". That's a log you handled, not a fix story, so don't tell it as one. See H4 |

### Reverse questions, Round 3

| Question | Why it lands |
|---|---|
| "What could someone in this role do in the first month that would genuinely help your branches?" | Reciprocity with peers. It shows you're there to reduce their load, not add to it |
| "When a complaint escalates from your branch today, what happens next, and where does it stall?" | It gets their real pain point, and it shows "Own the Fix" thinking |
| "What do your supervisors find hardest about escalations?" | It's the coaching remit (F4), framed around their people |
| "How are your towns reacting to the plans for hubs?" | "Neighbours, Not Numbers" shown rather than claimed, and current with the brief |
| "Which of the four values do you see tested most at the counter?" | It invites them to talk about their world. In a values round, their answer tells you what they're scoring hardest |

---

## Prohibited claims: what this pack will not coach

Built from the fit snapshot before any question was written. Every bank above is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's own observation, not words for you: your material says one branch's log. B1, C1 and L1 stay inside it |
| Has worked in a contact centre | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders above regional level | A negative you stated, F8 | "I haven't presented to anyone above regional level." No slot |
| Has coached branch supervisors | Inflated form of F4 | F4's quotes at their own scope: "trained new tellers on our escalation script" and "the last 3 as a branch supervisor". The limit is the pack's observation: your material says you trained tellers, not supervisors. C3's slot stays inside the teller training |
| Wrote or designed the escalation script | Inflated form of F4 | "trained new tellers on our escalation script". Your material says you trained people on it, not who wrote it |
| Built or runs the region's complaints reporting | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: your material says the regional manager uses it, not what it covers. G1's slot stays inside the spreadsheet |

---

## Sources

**Provided documents**
- The JD for Member Experience Lead, Ashgrove Credit Union, pasted.
- The values text, pasted. You copied it on 12 November 2026 from ashgrovecu.org/about/values. The page itself was not fetched.
- The recruiter's email on the process, pasted. It establishes the three-round loop.
- Your summary of Ashgrove's 2026 strategy brief (published July 2026, sent by the recruiter). The pack holds your summary, not the brief itself.
- Your background, from your message.
- No dossier was present.

**Searches and fetches:** none sent. Every declared target was already answered by your inputs, or had no query it could form.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values you pasted, copied this morning, fix the cheat sheet and the H1 to H4 themes |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email establishes all three rounds, the case and the values scoring, so it fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief, about four months old, supplies the current priorities behind A4, D2, D3 and J3 and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names have been assigned, so there was no query to form. The interviewer read is absent |
| 5. Representative `Member Experience Lead` JD | skipped | You supplied the JD, which fixes the fit snapshot and every JD-tagged question |

---

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for each person, persona weights based on their public professional profile, and at least one reverse question per round tied to their career.
- **The full strategy brief, rather than the summary** → a grounding brief with any headline numbers beyond the four you gave, and sharper D2, D3 and J3.
- **Your answers to the answer slots, given here in the chat** → F3, F5, F7 and F9 move from discovery to story-mapped, and G1, G2, B1, C4 and C3 get real beats instead of slots. The key ones are what the spreadsheet counts, what tool it's built in, whether your branch's complaints came under a regulator's rules, and any digital work.
- **One real story per value, told here** → H1 to H4 and the values cheat sheet go from scaffolds to mapped stories, with your own sentences quoted.
- **An anonymised copy or screenshot of the monthly complaints spreadsheet** → the artifact that would raise F3 and F9 from `medium` to `high` confidence, and give G1 concrete beats.
- **One email to the recruiter about the case format** (sent in advance or given on the day, and whether you present a recommendation) → the case build tuned to the actual format.
- **Your prep hours over the next nine days** → the triage resized from an ordered list to a schedule.
- **A deeper research pass (L2)** → up to 6 more searches and 2 more fetches, taking several more minutes: recent news about Ashgrove's branch plans, and candidate reports on its interviews. Run only if you ask for it.
- **A `tuesday-dossier.md` from job-underwriter** → an objection drawn from evidence you've confirmed and a prohibited-claims list from underwriting. This pack doesn't need one.
