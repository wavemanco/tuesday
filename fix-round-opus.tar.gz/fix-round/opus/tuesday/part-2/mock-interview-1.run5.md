Reading the prep playbook is done. Next I'm running a few targeted searches on Northwind Data and Dan Kovac, and then I'll build the pack.
I've built the full mock-interview pack for Priya's 60-minute conversation with Dan.

The web searches I tried were refused: Northwind's values, its interview loop, and Dan's public profile. So everything in the pack rests only on what you gave me. Dan's profile and your research note are used as you wrote them, unverified.

**Key decisions in the pack:**
- **Weights:** the questions are weighted for a peer conversation, then adjusted for what you said about Dan. Because he calls himself "relentlessly data-driven", the number-probing style gets the most questions. Peer-relationship questions come next (where your teams overlap, who gets credit). Live cases are tilted toward pricing, his home turf. There are 21 questions across seven styles, each with answer guidance and a rationale.
- **Highest-ROI prep (D1):** "I don't see classic sales-ops or quota-setting in your background…" Your notes state this gap outright, and it sits right in Dan's own area. The guidance opens by admitting it plainly, then holds through three follow-ups. It never presents her volume targets as quotas.
- **The ~$400M figure** gets three separate rehearsals (A1, B2, E2). The guidance keeps "proposed" and "credited with" exactly as you wrote them, because Dan will almost certainly dig into how it was counted and how much was hers.
- **Partner-motion design** is the only "required" line in the JD, and the nearest evidence is a revenue model used in carrier negotiations. A2 and C3 coach her to describe the model at that scope and say plainly that a model is not a motion.
- **Gaps:** where her material doesn't show something, such as lifecycle whitespace analysis, B2B buyers or pricing work, the pack doesn't invent it. Instead it marks the spot with two honest options: say what she actually did, or say plainly it wasn't hers.
- **Left out:** a values cheat sheet (no published values in hand), a prep schedule (prep time unknown) and a company briefing (no deep research ran). The upgrade menu at the end says what would add each one. Sending her real CV would help most.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-1-denied-5b503162:
- NorthwindData_senior-gtm-strategy-lead_interview_pack.md

If you'd like, I can play Dan in the data-probing style and run D1, the highest-ROI question, as a live drill.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for use in later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: NorthwindData_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. He is a **peer**: you and he would report to the same VP.
**Format:** one 60-minute conversation, per the coach's notes.
**Candidate:** Priya. The guidance below speaks to you directly.

---

## How to use this pack

Questions sit on two axes:

- **Persona** describes *how* a question arrives: who is asking and in what style. Each persona has its own bank below, ordered by how likely it is in this conversation.
- **Type** describes *what is being scored*.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the company's published values. None were in hand for this pack, so VAL rows are generic behavioral rehearsal |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company & strategy | Whether you can think at Northwind's altitude: its priorities, Compass, the bundling threat |
| CASE | Live problem | Your structure and reasoning on a problem from the actual role |

Every question row has a **Provenance** column. `[grounded]` means it traces to the coach's notes. `[inferred]` means it was derived, and the derivation is named. `[generic]` means a role-family pattern that makes no claim about you or Northwind. Where guidance says anything about your past, the sentence it rests on is quoted in that column. If you can't stand behind the quote, don't say the guidance.

An **answer slot** marks a place where a strong answer needs a fact the material doesn't give. It tells you what Dan is likely to probe and offers two honest branches. Fill it from your own experience or take the "it wasn't mine, or it didn't exist" branch. Never fill it with what sounds good.

Guidance is scaffolding, not a script. Every cell should take 90 to 120 seconds to say aloud.

Question IDs use the persona's letter: A Prober, B Peer, C Case, D Skeptic, E Pressure, G Conversational, H Values. **F is skipped** so it can't be confused with the fit-snapshot rows F1 to F8.

---

## Fit snapshot

Requirements are quoted from the JD highlights in the coach's notes. F7 and F8 are not JD lines. They are role-family requirements raised by who Dan is and what Northwind sells, so they appear as plain prose labelled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, the coach's notes | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material covers product strategy & ops and a proposal. It does not cover owning a go-to-market, and the words should stay at that scope: "I proposed a store-surface change, and it was credited with a ~$400M ARR uplift." Answer slot: the JD's own-GTM line makes a probe on go-to-market work likely. If any of your product strategy & ops work included taking something to market, say which part was yours and how you decided, in your own words. If there was no such work, or it wasn't yours, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, the coach's notes | none given | none | [grounded] | discovery | Strong evidence would be an analysis you ran that found where customers could adopt, expand or renew, and what it changed. Answer slot: the JD names all four stages, so expect a probe on lifecycle analysis. If you have done segmentation, expansion or retention analysis, say what you looked at and what it fed, in your own words. If not, say so plainly and say how you would approach it here |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, the coach's notes | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. But it is a skill claim with nothing inspected behind it, and Dan is "relentlessly data-driven", so expect him to test it. Lead with the quote's own terms and be ready with a real analysis you ran yourself (A3) |
| F4 | "partner-motion design experience required" — JD highlights, the coach's notes | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model used in partner negotiations sits next to designing a partner motion. It is not the same work. Words at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD marks partner-motion design as required, so expect a probe on how partners were recruited, incented or managed. If any of that was yours, say which part and how, in your own words. If none was, or there was no such step, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, the coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in its own terms. Say it as written: "I set annual volume targets with cross-org consensus." Let Dan draw the influence inference himself. Don't relabel it in the JD's words |
| F6 | "AI experience a plus" — JD highlights, the coach's notes | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Daily tool use is adjacent to AI experience, not the same thing, and it matters more here because Compass is an AI copilot launch. Words at scope: "I use AI tools daily." Answer slot: if any of your work involved an AI product or AI-driven analysis, say what and which part was yours. If not, say so plainly and stay with how you use the tools |
| F7 | Working fluency in sales-strategy mechanics such as quota-setting and sales ops, since the role sits beside a Director of Sales Strategy | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A stated gap that wording can't close. Words: "I haven't done classic sales-ops or quota-setting." Then a learning plan, said as a plan and never as a past. Never present the volume targets in F5 as quotas |
| F8 | B2B enterprise SaaS go-to-market context, since Northwind sells data infrastructure to businesses | none given | none | [generic] | discovery | Strong evidence would be work where the buyer was a business or a partner rather than a consumer. Selection scaffold: pick a piece of your work where the counterparty was a business, with a named stake and a decision it fed. If none comes to mind, say so plainly and give the nearest thing your material carries, or how you would get up to speed |

### Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| F1 own GTM strategy for two new product lines | C1, C2, D1, E1, G1 | |
| F2 whitespace across land/adopt/expand/renew | A5, D2 | |
| F3 SQL and Tableau | A3, A5 | |
| F4 partner-motion design | A2, C3 | |
| F5 cross-functional influence | A4, B1, B3, B4 | |
| F6 AI a plus | G2, C2 | |
| F7 sales-ops / quota fluency | D1, D2 | Highest-ROI prep |
| F8 B2B SaaS context | D1, D3, C1 | |
| Headline metric: ~$400M ARR uplift | A1, B2, E2 | Every headline figure gets a defend-the-number rehearsal |

---

## Reading the interviewer

This is built only from the profile in the coach's notes. The web searches meant to verify it were refused (see Sources), so check it against his actual profile before relying on it.

- **Career pattern:** his roles have centred on pricing and monetization, with one early-stage startup chapter.
- **Self-description:** "relentlessly data-driven."
- **Relationship:** a peer under the same VP. He isn't deciding whether you can do the job alone. He is judging what you would add to his work and what you would take from it.

What this means in the room:

1. **Every number will be probed down to its assumptions.** Expect the ~$400M figure (F1) to be the first thing he digs into. A precise "I proposed it, and here is what I know and don't know about how it was credited" earns more with him than a confident round number.
2. **Pricing is his native language.** Case questions will likely turn toward packaging, discounting and unit economics, especially on Compass and the bundling threat. Your material says nothing about pricing work, so don't claim any. Bring structure, and ask him how he sees it.
3. **Expect a scrappiness check.** People with a startup chapter often test whether someone from a big company can work with thin resources (D3).
4. **He will look for the seam between your role and his.** Two strategy roles under one VP, one in sales and one in emerging-products GTM, overlap on targets, pricing and data. Arrive with seam principles, not a turf claim (B1, B4).
5. **Mirror opportunities:** no shared career jump is offered, because nothing in the fit snapshot carries your side of one. The nearest shared vocabulary is F4, "built a partner-level revenue model used in carrier negotiations". It is a revenue model, which sits near his monetization world. Describe it at that scope and let him make the connection.

---

## Persona table

The weights come from a peer-round prior, adjusted for the interviewer signals in the coach's notes. The loop is set by the coach's own words: one 60-minute conversation with Dan. That makes this a single session, not loop mode. No values-style round is named.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Asks for denominators, how your numbers were counted, the query behind a chart | **Highest.** The peer prior puts Prober in the top two, and his self-description raises it further | Know what you can and can't say about how each number was counted. Name your weakest assumption before he does. Say "I don't know" plainly where it's true |
| B. Peer Evaluator | "Where's our seam?", "What do you need from me?", how credit is shared | **High.** The peer prior's other top persona. Same VP, adjacent remit | Lead with reciprocity: what you would bring his team. Propose seam principles rather than claiming turf. Show a disagreement style that pairs spine with tact |
| C. Case / Strategist | A live problem on pricing or packaging a new line, the bundling threat, or Compass | **Mid-high.** Not a prior for peers, but his pricing career pulls cases toward monetization. Your research note gives him obvious material | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| D. Skeptic | "I don't see sales-ops in your background", "consumer to B2B, why now?" | **Mid.** F7 is the most predictable objection, and a sales-strategy peer is the natural person to raise it, gently | Rehearse D1 until it feels boring. Give the plain acknowledgment, what your quotes do carry, and a learning plan |
| E. Pressure | Time-boxed "sixty seconds: why you?", "how much was actually you?" | **Low-mid.** Peers rarely stress-test, but a data-driven peer may press hard on attribution | Pause, restate the question, anchor in what you actually said. Hold through two follow-ups, then concede the specific uncertainty |
| G. Conversational | The opening "walk me through your journey" and a casual "what are you doing with AI?" | **Low-mid.** Every 60-minute conversation opens and closes this way, and casual questions on hot JD topics are still scored | Have a 90-second arc ready. Treat the AI question as scored. Never say "I think you've covered everything" when asked for your questions |
| H. Values / Behavioral | "Tell me about a time you delivered an unpopular truth" | **Low.** No values round is named and no published values were in hand. Peers still ask the odd behavioral question | Choose a real story where the hard truth actually landed. "We" for context, "I" for your contribution |

---

## Question banks

### A. Data-Driven Prober (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift credited to the store-surface change was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start at the quote's scope: you proposed the change, and it was credited with a ~$400M ARR uplift. Keep "proposed", "credited with" and the "~". Then the four slots this figure raises, each in your own words. How it was counted: if you know, say how; if you don't, or another team did the attribution, say so plainly. What it is sensitive to: say it if you know it. The assumption you would defend least: name it before he asks, or say you don't know how it was attributed. Which part was yours: the quote says you proposed it. If more was yours, say what. If not, stay with the proposal | The single headline figure on your record, in front of someone who calls himself "relentlessly data-driven" and has a monetization background. It is almost certain to come up. EXP because it tests attribution, not the role |
| A2 | "Walk me through the partner-level revenue model you built and how it was used in the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats the quote states: you built it, it was partner-level, and it was used in carrier negotiations. Answer slot: his pricing background and the JD's partner-motion line make probes on inputs and on your role in the negotiations likely. Name what went into the model and the assumption you would defend least, in your own words. If you were part of the negotiations, say what you did. If you weren't, say so plainly and stay with the model. Offer to walk it end to end only if you can | F4 is your evidence for the required partner-motion experience and the nearest thing to his own world. EXP because he will test what the model actually was before deciding what it proves |
| A3 | "Tell me about an analysis you ran yourself in SQL and Tableau, end to end: the question, the data, and what changed because of it." | EXP | [grounded] "skilled in SQL/Tableau" | An open prompt, so pick the instance. It should be an analysis you personally queried and built, with a clear business question, a data source you can name, the assumption you would defend least, and a decision it fed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, or how you would run one here. Expect follow-ups on table grain and joins. Answer at the level of detail you actually worked at | F3 is a skill claim with nothing inspected behind it, and the JD says "independent", so a peer will check you won't need his analysts. EXP primary, JD secondary |
| A4 | "Those annual volume targets: how did you set them, and how did you know afterwards whether they were right?" | EXP | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience" | Beats from the quote: the targets were annual, they were volume targets, and they were set with cross-org consensus. Answer slot: "how did you set them" invites a method. Give yours in your own words. If you can't, say so. "How did you know they were right" presumes a look-back. If there was one, say what it showed. If there was no such step, say so plainly and return to how consensus was reached. Don't call them quotas. If he asks, the honest line is "I haven't done classic sales-ops or quota-setting" | F5 is your nearest neighbour to sales planning, so a sales-strategy peer will test it. The second quote is here so the honest line is ready if he tries to equate targets with quotas (F7). EXP because it probes what you actually did |
| A5 | "Say I give you our CRM and product-usage data tomorrow. What's the first query you'd write to find expansion whitespace?" | CASE | [generic] | Clarify first: the unit (account or contract), what counts as whitespace (products owned versus products an account could use), and which lifecycle stage he cares about. Then the first cut: accounts by product ownership, with a size or usage measure beside it, to find accounts that use a lot but own little. Say the assumption your cut depends on, such as whether usage data is trustworthy for the new lines. Close with the Tableau view you would put in front of sales. Makes no claim about your past | A live test of F2 and F3 together, in the vocabulary of the JD's land/adopt/expand/renew line. A natural "show me" for a data-driven peer. CASE because it is a live problem. `[generic]` because the structure is a pattern, not Northwind's schema |

### B. Peer Evaluator (high weight, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams would sit side by side: sales strategy and emerging-products GTM. Where's the seam, and what happens when we disagree?" | JD | [generic] | Don't pretend to know the seam. Ask how he sees it today, then offer principles: one shared source of truth for bookings and pipeline data; targets for the new lines set jointly rather than handed over; when you disagree, take one joint recommendation to the VP rather than two competing ones. Close with reciprocity: what you would take off his plate. Makes no claim about your past | The core peer question: will this hire add to my load or reduce it? JD because it scores "strong cross-functional influence" (F5). `[generic]` because these are seam principles, not facts about Northwind's org |
| B2 | "On the store-surface change: who else was involved, and how was the credit shared?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | "We" for context, "I" for your part. The quote says you proposed it and that it was credited with the uplift. Answer slot: if other teams built, shipped or measured it, name them plainly and say what was theirs. If it was more yours than "proposed", say exactly what, in your own words. Point out that "credited with" is the company's attribution, not your own estimate | A1's attribution probe in peer packaging. A peer is listening for how you will share credit on joint work. EXP because the real test is honesty about your share |
| B3 | "What would you need from my team in your first 90 days, and what would you bring us?" | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | What you need: access to bookings and usage data, his read on how the sales org will receive the new lines, and his pricing guardrails. What you bring, in the quotes' own words: you are skilled in SQL/Tableau, so you would run your own analysis rather than queue for his team's; you built a partner-level revenue model used in carrier negotiations, which you can describe at that scope. Offer one concrete thing in the first month, such as a shared view of new-line pipeline. Present it as a plan, not as a record | The reciprocity test for a peer. JD because it scores influence (F5) and independent analysis (F3). Both claims are kept at the quotes' scope |
| B4 | "Pricing a new product line runs straight into my world. How would you want to work that with me?" | JD | [generic] | Acknowledge that pricing is his area. Propose a split: you bring segmentation, whitespace and adoption analysis; he brings price architecture and discount governance; you design any pricing test together. Ask where pricing for new lines sits today. If he asks whether you have done pricing work, your material says nothing either way. Answer slot: if you have, say what and which part was yours. If not, say so plainly and stay with the split you proposed | Built directly from his monetization background, where the turf risk is highest. JD because it scores cross-functional influence (F5) on his home ground |

### C. Case / Strategist (mid-high weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling something that competes with one of the new lines. Sketch our GTM response." | CASE | [grounded] | Clarify: which line, which segment, and how much the bundle actually overlaps. Objective: the stated profitability priority rules out a pure price war, so say that early. Segment: where the bundle is "good enough" versus where depth matters. Approach: concentrate where depth wins; use enterprise expansion by attaching to existing accounts; consider a partner route; price to value rather than to match. Metrics: win rate in deals where the bundle is present, discount depth, net retention. Risks: name one. Challenge one premise, for example whether the bundle reaches the buyers who matter here. Makes no claim about your past | Built on the coach's research note: the bundling threat, enterprise expansion and profitability. This is the differentiating strategy question for this company. CASE delivery, CO content. `[grounded]` because the premise traces to the coach's note, though that note was not re-verified |
| C2 | "How would you price and package Compass, given we also have to reach profitability?" | CASE | [grounded] | State a hypothesis early, which is how pricing people like to work. Options: bundled into existing tiers to drive adoption and retention; a paid add-on; usage-based. Test them against two stated priorities, enterprise expansion and profitability, and say plainly that you would need the cost-to-serve figure before choosing. Metrics: attach rate, expansion revenue per account, gross margin per account. Ask him how pricing for the launch is being decided. Makes no claim about AI product experience you haven't stated (F6) | Compass is a stated priority, the JD lists AI as a plus, and pricing is his native language. This is where those three meet. CASE delivery, CO content. Premise from the coach's research note |
| C3 | "Design the partner motion for a new product line: which partners, what we give them, and how we'd know in two quarters whether it's working." | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" | Clarify which line and which lifecycle stage partners should own: land, or expand. Partner types: resellers, systems integrators, technology or marketplace partners. Pick one with a reason. The deal: margin or referral fee, enablement, co-selling rules, and conflict rules with direct sales (his world, so ask). Two-quarter metrics: partner-sourced pipeline, time to first deal, deal-registration conflicts. If you mention your own background, keep it at the quote's scope: you built a partner-level revenue model used in carrier negotiations. Say plainly that a model is not a motion | Partner-motion design is the JD's only "required" line, and F4 is a transferability gap, so a live design question is likely. CASE because it is a live problem. The structure is a role-family pattern; the quote bounds any claim about you |

### D. Skeptic (mid weight, 3 questions)

**D1 is the highest-ROI prep in this pack.** It will come up in some form, and from a sales-strategy peer it will sound friendly.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background, and this role sits right next to sales. Why should I believe you can run GTM strategy in a B2B sales org?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | Name the limit before he finishes pushing: "I haven't done classic sales-ops or quota-setting." Don't soften it. Then what the quotes carry: "I set annual volume targets with cross-org consensus, and I built a partner-level revenue model used in carrier negotiations." Then a learning plan, said as a plan: sit with his team through a planning cycle and learn how territories and quotas are built here. **Follow-up 1:** "Volume targets are basically quotas, right?" Hold: "They were annual volume targets, set with cross-org consensus. I haven't done quota-setting." **Follow-up 2:** "So what do you bring that my team doesn't?" Say the role is GTM strategy for new lines, which needs the analysis and partner work your quotes describe, and offer what you would hand his team (B3). **Follow-up 3:** "Consumer tech to B2B, though?" Answer slot: if any of your work had a business or a partner as the buyer, say what and which part was yours; the carrier negotiations are a candidate only at the quote's scope. If there was none, say so and give the learning plan. **Concede specifically:** "On quota mechanics, I'd be learning from your team." Never fold on the core: the role is GTM strategy, not quota ownership | F7 is the one gap the candidate has stated outright, and Dan's own remit is exactly where it shows. A rehearsed answer that isn't defensive changes the conversation. JD because it scores whether you can do the listed job beside sales. Deepest rehearsal: three follow-ups, exact concession wording, and the limit named before he asks |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Pick a real weakness, not a disguised strength. Two honest candidates. The sales-ops gap, in its plain words: "I haven't done classic sales-ops or quota-setting." Or lifecycle whitespace (F2), which your material doesn't show. Answer slot: if you have done expansion or renewal analysis, say so and pick something else. If not, say it's the area you'd ramp on first and how. Give one weakness and one plan. Don't list three | A standard Skeptic stem. With a stated gap available, the honest answer is easy if rehearsed and awkward if not. JD because it scores self-assessment against the listed job |
| D3 | "Emerging products rarely get big-company resources. Tell me about a time you got something done with less than you needed." | EXP | [generic] | An open prompt, so pick the instance. It needs a real constraint (people, data or time), what you did yourself, and an outcome you can state honestly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it here. Don't recast a well-resourced project as scrappy; he will ask follow-ups | His startup chapter makes a scrappiness probe likely, and nine years at a large company invites it. EXP because it tests a past instance. `[generic]` because nothing in the material carries such a story yet (F8 notes the same silence on B2B) |

### E. Pressure (low-mid weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone from inside our sales strategy team?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau" | Pause, then three beats from the quotes, kept at their scope: strategy consulting, then nine years in product strategy & ops; the partner-level revenue model; SQL/Tableau for independent analysis. Don't criticise insiders. **Hold** that the role is new-product GTM strategy, which these beats speak to. If pushed twice, **concede** the specific point: an insider knows Northwind's sales motion better on day one, and you would close that gap through his team (D1's plan) | The classic time-boxed Pressure stem, sharpened because he sits on the team an internal candidate could come from. JD because it scores fit to the listed job. Hold-then-concede structure |
| E2 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | **Hold** the quote exactly: "I proposed the change, and it was credited with a ~$400M ARR uplift." Don't trade up to "drove" or "delivered", and don't trade down to dismissing the number. **Follow-up:** "But who actually built it?" Answer slot: if others built or shipped it, say so plainly. If more than the proposal was yours, say what. **Concede** that the figure is the company's attribution, not your measurement. Never fold on having proposed it | The attribution stem, aimed at the figure most likely to be pressed. Rehearsing honesty under pressure is the point of this row. EXP because it tests your share |

### G. Conversational (low-mid weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc in three beats from the quote: two years of strategy consulting, then nine years in product strategy & ops at a large consumer-tech company, then why GTM strategy for emerging products at Northwind now. Say the "why now" in your own words. It is the bridge he will test in D1, so make sure the two answers agree. End by handing the conversation back to him | Almost certainly the opener, and it frames F1 and F7 before he asks about them. EXP because it is your own history. Casual register, still scored |
| G2 | "What are you actually doing with AI these days?" | EXP | [grounded] "uses AI tools daily" | Treat this as scored: AI is a JD plus and Compass is a launch priority. Answer slot: name the tools and one real use from your own work. If you can't, keep it general and say so. Stay at the quote's scope: daily use. Don't upgrade it into AI product experience (F6). Then turn it into curiosity about Compass: how he expects a copilot to change the sales motion | A JD plus-skill, asked casually. Conversational stems on hot JD topics are where unprepared candidates ramble. EXP because it asks what you actually do |

### H. Values / Behavioral (low weight, 2 questions)

No published Northwind values were in hand (see Sources), so these are generic behavioral rehearsal, not mapped to named values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Selection scaffold. The story needs a named stake, the moment you said it, and a hard truth that actually landed. The store-surface proposal is a candidate only if it really met resistance. Answer slot: if it did, say who pushed back and what you did, in your own words. If it didn't, pick another story. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A common behavioral stem that peers use to see how you would disagree with a shared VP. VAL by type, though no published values were in hand to map to |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a real decision where a metric you were measured on pulled one way and the customer the other, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard behavioral stem. Lowest weight, but it means you won't meet this style for the first time live. `[generic]` because nothing in the material carries such a story |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "You've worked mostly in pricing and monetization, with one startup chapter. What did the startup years change about how you'd price a product that has no history yet?" | Ties to his own path, which shows you researched him, and puts the conversation in his native language |
| R2 | "What could someone in this role do in the first month that would genuinely help your team?" | The reciprocity question for a peer. It signals you mean to reduce his load, not add to it |
| R3 | "How do sales strategy and emerging-products GTM split the work under the VP today, and where does pricing for the new lines sit?" | Gets the seam (B1, B4) from him rather than you guessing, and shows turf awareness |
| R4 | "What's the source of truth for bookings and usage data, and how usable is it for the new lines yet?" | Speaks to "relentlessly data-driven" and tells you how independent your SQL/Tableau work can really be |
| R5 | "Where is the platform vendor's bundling showing up in deals, and is it changing discount depth?" | A pricing person's question about the stated competitive threat. It shows strategic homework |
| R6 | "How is Compass expected to show up commercially: a paid line, a retention lever, or both?" | Connects the AI launch to monetization, his area, and tells you how AI-heavy the role will be |
| R7 | "With profitability as a stated priority, how long can a new partner motion run before it has to pay back?" | Tests the real room for the JD's required partner work against the profitability goal |

---

## Prohibited claims

These are claims the pack will not coach, built from the fit snapshot. They are the claims most tempting to reach for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led go-to-market for a product | Inflated form of F1 | F1's quotes at their own scope. The pack's own observation: the material says product strategy & ops and a proposal, not GTM ownership. Slots stay inside that scope |
| Drove, delivered or generated the ~$400M ARR | Inflated form of F1 | "proposed a store-surface change credited with a ~$400M ARR uplift": keep "proposed", "credited with" and "~" |
| Designed a partner motion or partner program | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations". The pack's observation: a model, not a motion |
| Negotiated or won the carrier deals | Inflated form of F4 | The same quote: the model was "used in" the negotiations. Any role in them is an answer slot, never an assumption |
| Has set quotas or run sales ops | Negative stated in the coach's notes, F7 | The plain acknowledgment: "I haven't done classic sales-ops or quota-setting." No slot |
| The volume targets were quotas | Contradicted by F7's stated negative | "set annual volume targets with cross-org consensus", alongside "No classic sales-ops or quota-setting experience" |
| Has AI product or AI go-to-market experience | Inflated form of F6 | "uses AI tools daily", at that scope |

---

## Sources

**Provided document:** the coach's message. It supplied the role and JD highlights, the candidate background, Dan Kovac's profile (relationship, self-description, career pattern), and the research note on Northwind's three priorities and the bundling threat. The JD highlights are a summary, not the full JD text. The research note is undated.

**Searches sent (all three refused: web search permission was not granted in this session):**

| Query | Result |
|---|---|
| "Northwind Data" company values | refused |
| "Northwind Data" interview process strategy | refused |
| "Dan Kovac" "Northwind Data" sales strategy | refused |

No fetches were sent. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The call was refused. It would have given the H bank named values to map stories to |
| 2. Northwind Data interview process, GTM strategy | unavailable | The call was refused. The coach's words already set this session as one 60-minute conversation with a peer; this search would have shown the other rounds in the loop and whether one is values-style |
| 3. Northwind Data strategy / recent news | skipped | The coach's research note already supplies the three priorities and the bundling threat behind C1, C2 and R5 to R7. A freshness check would have been worthwhile, since the note is undated |
| 4. Dan Kovac, Northwind Data | unavailable | The call was refused. It would have verified the profile behind "Reading the interviewer" and the persona weights, and found any talks or posts for R1 |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The coach supplied JD highlights, which fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Priya's actual CV** → evidence quotes in her own words instead of the coach's summary. It could also show B2B, lifecycle or pricing work that would move F2 and F8 out of `discovery`.
- **Her answers to the answer slots**, such as how the ~$400M was attributed, her role in the carrier negotiations, and any B2B or partner-facing work → A1, A2, B2, D1, E2 and the F1, F4 and F8 rows can be rewritten as story-mapped guidance.
- **The full JD text** → mid-list requirements the highlights may have dropped (tools, metrics, team scope) each get a JD-tagged question, and the coverage table is checked against the real list.
- **Allowing web search**, which was refused this time → Northwind's values by name for the H bank, the rest of the interview loop, and a check on Dan's public profile and the research note's freshness.
- **A deeper research pass**, up to 6 more searches and 2 more fetches and several more minutes → a grounding brief (segment language, numbers, recent moves), Dan's talks or writing, loop reports, and recent org context. This would sharpen C1, C2 and the reverse questions.
- **How much prep time Priya has** → a prioritized prep schedule sized to that time.
- **Recruiter guidance on focus areas, or any requested deliverable** → coverage matched to what Dan has been asked to assess, plus a build section for any deliverable.
- **The schedule of any other rounds** → loop mode: a shared fit snapshot plus a mini-pack per round.
- **A dossier from a job-underwriter pass** → user-confirmed evidence, the objection to rehearse named from verified material rather than inferred, and binding guardrails on each weak area.
