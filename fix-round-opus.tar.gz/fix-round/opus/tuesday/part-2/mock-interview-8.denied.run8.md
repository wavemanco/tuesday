Nothing in your notes needed a follow-up question, so I'm skipping straight to building your prep pack for all three rounds now.
I've built your prep pack, saved as `AshgroveCreditUnion_member-experience-lead_interview_pack.md`. It covers all three rounds on 21 November. Your notes covered everything I'd have asked, so I didn't run any searches.

- **Biggest risk:** the role owns complaints across branches "and the contact centre", and you've never worked in one. Expect your would-be manager to raise it. Question B1 in the pack is the one most worth rehearsing. It opens by naming the gap yourself, then sticks to what you actually did. Your presenting gap is the second risk, covered in B2 and C9.
- **Your strongest evidence:** the branch's formal complaints log, training new tellers on the escalation script, and the monthly spreadsheet your regional manager uses. The pack keeps each of these to exactly what you told me. It doesn't stretch the log into "regulated complaints" or the spreadsheet into "Excel reporting". Where an interviewer will probe past that, it gives you two honest ways to answer.
- **The panel round:** there's a cheat sheet linking each of the four values to a story you can use. There's also a build for the 20-minute case: questions to ask first, three positions to take (each with a point to concede), and a trap to avoid. The trap is resolving the complaint by steering the member to the app just because of the digital target.
- **What would sharpen it most:** a quick email to the recruiter asking which complaint rules Ashgrove works to and what format the case takes.

If you want to practise, I can play your would-be manager on B1, the contact-centre question.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AshgroveCreditUnion_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date:** all three rounds on 21 November 2026
**Loop, from the recruiter's email:**

1. 30 minutes with the recruiter.
2. 45 minutes with the Head of Member Services, your would-be manager, "mostly behavioural".
3. 60 minutes with a panel of two branch managers, including "a 20-minute case on a complaint escalation". This is also the values round, scored against the four values.

**Interviewers:** names not assigned yet, so no interviewer profiles.
**Mode:** loop. One shared fit snapshot, then a mini-pack for each round.

---

## How to use this pack

- **Personas** describe how a question gets asked: the style and register. **Types** describe what is being scored.
- **Type key:**
  - **VAL:** whether a past behaviour shows one of Ashgrove's *published* values.
  - **EXP:** whether what you've said about your background holds up when someone probes it.
  - **JD:** whether you can do the listed job, gaps included.
  - **CO:** company and strategy knowledge.
  - **CASE:** a live problem from the role, solved out loud.
- **Provenance labels:**
  - `[grounded]` traces to something you or Ashgrove supplied.
  - `[inferred]` is this pack's own derivation, and the row says what it was derived from.
  - `[generic]` is a role-family pattern with no claim about you or Ashgrove.
- **Answer slots.** These are instructions for the interview itself, not questions for you to answer here. Each one has two honest branches. Either branch is a good answer.
- **The guidance is scaffolding, not a script.** Every claim about your past comes from one of the sentences quoted in the fit snapshot. Say those things in your own words, and don't say more than they do.
- **Vocabulary.** Ashgrove's own documents say "member", not "customer": "member complaints process", "the member's side of the counter". Use their word.

---

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material covers one branch's complaints log, not a process across several branches, so your words stay with the log: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on what handling the log involved likely. Say what it meant day to day, in your own words. If it meant keeping the record and no more, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You have said this yourself, and no wording closes it. Words: "I haven't worked in a contact centre." Then say how you would learn that side, as a plan and never as something you've done. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote is monthly and about complaints. Your material doesn't show what the spreadsheet tracks, so the bridge isn't stretched. Words: "I built the monthly complaints spreadsheet our regional manager uses." Keep "uses" as "uses". Answer slot: say what the spreadsheet tracks, in your own words, and stop there |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Training new tellers is next door to coaching supervisors, but the audience is different. Words, at the scope of the quotes: "I trained new tellers on our escalation script," and "The last three of those six years were as a branch supervisor." Your material doesn't say who wrote "our" script, so make no claim about that. Answer slot: if any part of how that training ran was yours to shape, say which, in your own words. If you delivered it as it was given to you, say so plainly and stay with the training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show this either way. Answer slot: if you have worked with a digital team or on an online or app journey, say what it was and what your part was, in your own words. If you haven't, say so plainly and say how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. There's no document behind the claim, though, so expect a quick check. Lead with the quote in its own terms: six years in retail banking, the last three as a branch supervisor. Let the interviewer match that to the JD's phrase rather than relabelling your years in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | "Formal" touches the requirement, but it doesn't show whether those complaints were regulated, so the bridge isn't stretched. Words: "I handled the branch's formal complaints log." Answer slot: say what went into the log and what made it formal, in your own words. If you don't know what made it formal, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You have said this yourself. Words: "I haven't presented to anyone above regional level." Your sentence doesn't say whether you have presented at regional level. Answer slot: if you have, say to whom and about what, in your own words. If you haven't, say so plainly. Then say how you would prepare, as a plan |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material doesn't name the tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: name the tool you built it in and what you do in it, in your own words, and stop there |

**The biggest objection to you:** F2 (no contact-centre experience) against a role that owns complaints "across branches and the contact centre". It is rehearsed most deeply at **B1**, the highest-ROI prep in this pack. F8 (presenting) comes second, at B2 and C9.

---

## Grounding brief (shared)

What the provided documents say about Ashgrove right now, in their own terms. The strategy points come from the recruiter's July 2026 summary, which is four months old. You have the four headline points, not the full brief.

| Fact | Source | Provenance | What it means for your answers |
|---|---|---|---|
| Member-owned, about 900 staff | JD | [grounded] | Members are owners. "Members First, Always" is the frame for every complaint answer |
| Move 40% of member service to digital channels by 2028 | Strategy brief, July 2026 | [grounded] | The JD's "self-service journeys" line sits here. Expect a CO question on what digital means for complaints (B11) |
| Consolidate eight branches into five hubs over 2027 | Strategy brief, July 2026 | [grounded] | Your panel is two branch managers, and this change lands on their branches. Treat it with care (C8) and don't guess which branches are affected |
| Small-business lending product launches Q1 2027 | Strategy brief, July 2026 | [grounded] | A new product means new kinds of member to serve. This is the pack's reasoning, not something the brief says. It's a good reverse-question topic, not something to claim knowledge of |
| Main competitive pressure is app-only banks | Strategy brief, July 2026 | [grounded] | Answer from Ashgrove's own values ("Neighbours, Not Numbers", "Plain Words"), not from claims about competitors (C10) |
| Four values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Values text you copied on 12 Nov 2026 from ashgrovecu.org/about/values | [grounded] | The panel scores against these by name. Learn the names exactly |

---

## Graded deliverable: the 20-minute complaint-escalation case (round 3)

**What's declared.** The recruiter's email says "a 20-minute case on a complaint escalation". It is run by two branch managers, who "score against the four values". No format is given: it doesn't say whether you get a written brief, and no requested close is named.

**What you can draw on** (only at the scope of the quotes):
- F1: "I handled the branch's formal complaints log"
- F4: "trained new tellers on our escalation script"
- F6: "6 years in retail banking, the last 3 as a branch supervisor"

**Suggested shape for 20 minutes:**
1. **Clarify (about 3 minutes), before solving anything.** Find out:
   - What's the complaint, and where did it start: a branch, the contact centre or the app?
   - How long has it been open, and what has the member already been told?
   - Is there anything that makes this member vulnerable?
   - What complaint rules and deadlines does Ashgrove work to? Ask; don't assume a timeline.
   - What authority does this role have to put things right?
2. **Objective (about 1 minute).** Say it out loud: a member who feels heard and gets a fair fix, and a branch that learns from it.
3. **Approach (about 10 minutes).** Use the theses below and think out loud.
4. **Prevention and measures (about 4 minutes).** Cover what changes so the complaint doesn't recur, and how you'd know.
5. **Close (about 2 minutes).** What the member hears, what the branch learns, what goes into the monthly report.

**Theses.** Each comes with the concession you should make yourself.

| Thesis | Values it carries | Your concession |
|---|---|---|
| Fix the member's problem first, then fix the process that caused it | Members First, Always; Own the Fix | Some fixes need the facts or a sign-off first. You won't promise an outcome before you know the rules and the facts |
| One named owner holds the complaint from escalation to close, and the branch stays in the loop | Own the Fix; Neighbours, Not Numbers | A single owner can become a bottleneck. At volume, this needs clear handover rules |
| Every escalation is a coaching moment for the supervisor and a data point for the monthly report | Plain Words; Own the Fix | One case isn't a trend. You wouldn't redesign the process because of one complaint |

**Standing out from the standard answer.** The standard answer is "apologise, investigate, resolve, follow up". Every prepared candidate will give it. Give it in one breath to show you know it, then add three things:
1. Say the member's final response out loud, in one plain sentence. This is "Plain Words" in action.
2. Close the loop with the branch supervisor as coaching, not blame.
3. Log the root cause so it shows up in the monthly report.

**The anti-pick.** Don't fix an escalated complaint by steering the member to the app because of the 40% digital target. The fix comes first; moving them to another channel is a separate conversation. And don't criticise branch staff in front of two branch managers.

**Close.** None was requested. End on the three outcomes in step 5.

---

## Round 1: Recruiter, 30 minutes

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly walk-through, "why Ashgrove", logistics | High. This is the recruiter-screen prior, and the email says this round is "30 minutes with me" | A 90-second arc built only from your background sentences (A1). Treat every casual question as scored |
| Skeptic (light) | Quick checks against the JD's requirements | Medium. Recruiter screens check stated requirements, and two of yours are gaps you've named (F2, F8) | Answer each check plainly and briefly. The full rehearsal is in round 2 |

### Question bank A

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | 90 seconds, four beats, each one only what its sentence says: six years in retail banking with the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. End with one line on why this role, in your own words (see A2) | This opener sets the frame the recruiter passes on to the next rounds. EXP because each beat is something you'll be probed on later (F1, F3, F4, F6) |
| A2 | "What's drawing you to Ashgrove and this role?" | CO | [grounded] | Pick one value by its exact name and one strategy point, and say why each matters to you. The reason is yours, so don't borrow one. Don't recite all four values. This answer needs no claim about your past | Recruiters test whether you've read the material and whether you'll stay. CO because it rests on the values text and the brief |
| A3 | "What has you looking at a move now?" | EXP | [generic] | Keep it forward-facing: what this role has that you want. Your material doesn't say why you're moving, so use your own honest reason. Don't criticise your current employer | A standard screening question about whether your story holds together. `[generic]` because it's a role-family pattern |
| A4 | "The role reports monthly on complaints. What reporting do you do today?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say the quote: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD's reporting line makes a follow-up on what the spreadsheet holds likely. Say what it tracks, in your own words, and stop there | F3 is your closest match to a headline JD line, and it gets asked casually. JD because it scores the reporting requirement |
| A5 | "The JD asks for four-plus years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it in the quote's own terms: six years in retail banking, the last three as a branch supervisor. Don't rename it "customer operations"; let the recruiter tick the box | Recruiters screen length-of-experience lines literally. F6 meets this one, so keep the answer short |
| A6 | "Have you handled regulated complaints?" | JD | [inferred] "I handled the branch's formal complaints log" | Say what you did: you handled the branch's formal complaints log. Answer slot: say what went into the log and what made it formal, in your own words. If you don't know what made it formal, say so plainly and stay with the log. Your material doesn't show whether those complaints were regulated, so don't settle that question here | F7 is thin, and a JD line this specific gets read out as written. `[inferred]` because the fit is this pack's derivation |
| A7 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | "No, I haven't worked in a contact centre." Then one sentence on how you'd learn it, as a plan (see B1). Stop there without apologising; a short, plain answer reads as confident | F2 is a knockout-style check. The full rehearsal is B1, so here the goal is not to wobble |
| A8 | "What are you looking for on salary and start date?" | EXP | [generic] | Decide your number and notice period before the call, and say them plainly. Nothing in your material speaks to this, so the answer is yours to set | Standard logistics. Treated as scored, because a hesitant answer reads as unprepared |

### Reverse questions, round 1

| Question | Why it lands |
|---|---|
| "Is the 20-minute case given in advance, or on the day? Is there any written material?" | It settles the biggest unknown in the loop, and recruiters can answer it |
| "Have the panel and the Head of Member Services been confirmed, and could you share their names?" | Names unlock the interviewer read in the upgrade menu |
| "Where does this role sit: a branch, a hub or head office? Does the 2027 consolidation change that?" | It shows you've read the brief, and the answer matters to you practically |
| "Who would I work with most day to day: the contact-centre leads, branch supervisors, the digital team?" | It maps the role's actual relationships before the manager round |
| "What's the timeline for a decision after 21 November?" | Practical, and expected |

---

## Round 2: Head of Member Services (your would-be manager), 45 minutes, mostly behavioural

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "Tell me about a time…" prompts tied to the JD's duties | High. The recruiter calls this round "mostly behavioural", which puts it above the hiring-manager prior | STAR shape. "We" for context, "I" for your part. Where none of your sentences carries a story, use a scaffold and its honest branch |
| Skeptic | Quiet probing of the gaps a manager would carry: the contact centre (F2) and presenting (F8) | High. Your manager is the one who inherits the risk of those gaps | Name the gap before you're asked, hold on what you did, and give a concrete ramp plan (B1, B2) |
| Data-Driven Prober | "Walk me through that spreadsheet." | Medium. F3 is your one artefact on the JD's reporting line | Know what it tracks and say plainly what you don't know |
| Case / Strategist | Short live problems on reporting and digital | Medium-low. This is the hiring-manager prior, reduced because the round is behavioural | Clarify, then structure, then answer, using Ashgrove's words |
| Pressure | One time-boxed challenge | Low. It's touched once here and again at C9 | Pause, restate, hold, then concede only what's true |

### Question bank B

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns complaints across branches and the contact centre. You haven't worked in a contact centre. How would you handle that side?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | **The highest-ROI rehearsal in this pack.** Open with the gap before they press: "I haven't worked in a contact centre." Then what you did, at the quotes' scope: you handled the branch's formal complaints log, and you trained new tellers on your escalation script. Don't claim branch complaints are "the same" as contact-centre ones; describe what you did and let them judge. Then the ramp, as a plan: sit in on complaint calls early, learn the contact centre's escalation route from its leads, and ask where branch and contact-centre handoffs break. **Follow-up 1, "Why would that transfer?":** hold. "What I can tell you is what I did at the branch," then the same two facts, adding nothing. **Follow-up 2, "Wouldn't someone from a contact centre be safer?":** concede it specifically. "They'd know that side on day one and I wouldn't." Then hold on the branch log and the training, and on the plan | F2 against the JD's headline line is the objection most likely to come up, in some form, from the person who'd manage you. JD because it scores the stated scope. Deepest rehearsal because a calm, pre-emptive answer here changes the interview |
| B2 | "This role presents to senior leaders. Tell me about your experience presenting." | JD | [grounded] "I've never presented to anyone above regional level" | Plain: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words. If you haven't, say so plainly. Then how you'd prepare, as a plan: the monthly report as the anchor, a dry run with your manager, one message per slide. Hold on the plan and don't inflate the past | F8 is the second gap you named, and a manager will want to know how much support you'd need. JD because it scores the stated requirement |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick one real gap, F2 or F8, and name it plainly using its quote. Give the plan in two sentences. Don't offer a disguised strength. Choose the one whose plan you can describe more concretely | A Skeptic stem a manager is very likely to use. A rehearsed honest answer beats a dodge |
| B4 | "Tell me about a time a member was right and the process was wrong." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint from your branch years. It needs a member, the specific process fault, what you did and how it ended. Say which part was yours. If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry, that you handled the branch's formal complaints log, or how you'd handle it | Its theme is "Members First, Always", applied to the JD's complaints duty. VAL because it tests behaviour against a published value. A scaffold because the log sentence carries no single incident |
| B5 | "Tell me about a time you escalated something beyond your branch." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: pick an escalation from your time as a branch supervisor. It needs what triggered it, who you went to, what you handed over, and what happened next. If no such time comes to mind, say so plainly, then explain how you'd decide when to escalate | The JD's escalations line, asked from the other side. A scaffold because none of your sentences describes an escalation you made |
| B6 | "Tell me about a time you got people ready to handle something difficult." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4. The beats are what the quote states: new tellers, the escalation script, and you trained them. Answer slot: the JD's coaching line makes a probe on how the training ran likely. If any part of it was yours to shape, say which and why, in your own words. If you delivered it as it was given to you, say so plainly and describe how you trained them | F4 is your evidence for the coaching requirement. Its theme comes from the JD's coaching line. VAL in delivery, JD in content |
| B7 | "Tell me about a time you told someone above you something they didn't want to hear." | VAL | [generic] | Selection scaffold: it needs a named stake, a moment you didn't fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | The Values persona stem. Your manager will want to know you'll raise problems upward, which is "Own the Fix". `[generic]` because none of your sentences carries this |
| B8 | "Walk me through that monthly complaints spreadsheet. What's in it, and how does your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | You built it, and the quote says so. Answer slot: say what it tracks and where its data comes from, in your own words. If you don't know where some of it comes from, say so. On how it's used, the quote says "uses": if you know how, say so; if you don't, say so plainly. Name the part you'd defend least before they find it | F3 is your one artefact on the reporting line, and a prober will open it up. EXP because it tests what was actually yours |
| B9 | "How comfortable are you in Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: name the tool you built the spreadsheet in and what you do in it, in your own words, and stop there. Don't list functions you don't use | F9 is a stated requirement, and your material doesn't name the tool. JD because it's on the list |
| B10 | "If I gave you our monthly complaints data, what would you look at first?" | CASE | [generic] | Structure it out loud. What counts as a complaint. Volumes and how quickly they're resolved, which is the JD's own pair. A split by where complaints arrive: branch, contact centre, digital. The month-on-month trend. Repeat themes. Then what you'd do with each. This question needs no claim about your past | A live problem from the JD's reporting line. CASE delivery on JD content. `[generic]` because it's a method, not a fact about Ashgrove |
| B11 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] | Ideas, with Ashgrove's words attached: complaints data shows where self-service journeys fail ("work with digital teams on self-service journeys"); journeys written so nobody needs them explained twice ("Plain Words"); members who won't go digital must still be able to complain easily ("Members First, Always"). Answer slot: if you have worked with a digital team or on an online journey, say what and your part, in your own words. If not, say so plainly and go to how you'd start | CO is required when strategy material is in hand. This one covers F5. `[grounded]` because it rests on the brief and the JD |
| B12 | "Sixty seconds: why you over an internal candidate?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Pause, then three facts at the quotes' scope: six years in retail banking, the last three as a supervisor; you handled the branch's formal complaints log; you built the monthly complaints spreadsheet your regional manager uses. Don't run down the hypothetical rival. If they press on the contact centre, concede F2 plainly and stop. Finish under 60 seconds | A Pressure stem that tests composure under a time box. EXP because the answer can only rest on what you've done |

### Reverse questions, round 2

| Question | Why it lands |
|---|---|
| "Which complaint rules and deadlines does this role work to, and where does Ashgrove find them hardest to meet?" | The JD names regulated complaints. This shows you know the stakes, and it asks where the pain is |
| "Where does the complaints process break today between branches and the contact centre?" | That seam is the job, and the side you know least, asked about openly |
| "Who receives the monthly report, and what do they do with it?" | It shows you're thinking about the presenting part, and tells you who the audience is |
| "What would you want me to have done by the end of my first 90 days?" | It gives you your manager's own success measure |
| "How do you like to be kept up to date by the people who report to you?" | A manager-specific question that signals you'll fit their working style |

---

## Round 3: Panel of two branch managers, 60 minutes (values round, with the 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One or more prompts for each value, scored by name | High. The recruiter says the panel "score against the four values" | Use the cheat sheet below: one story or scaffold per value, with the value named |
| Case / Strategist | The 20-minute escalation case, plus strategy questions about their branches | High. A third of the round is a case | The graded-deliverable section above: clarify, objective, approach, measures, close |
| Peer Evaluator | "How would you work with us and our supervisors?" | Medium. The JD has this role coaching branch supervisors, who work in their branches | Reciprocity: what you bring them, plus principles for the line between your role and theirs. Don't pretend to know that line yet |
| Pressure | One push on a gap | Low. Panels sometimes push, and F8 is the obvious target | Hold, then concede (C9) |

Panel names aren't known, so both managers get the same weighting.

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's point of view, not the organisation's | Selection scaffold: pick a decision you made as a supervisor where the member's view changed what you did. It needs the member, the choice and the outcome. If none comes to mind, say so plainly, then give the nearest thing your material carries (F1: "I handled the branch's formal complaints log"), or how you would handle it |
| Plain Words | If something needs explaining twice, the wording is the problem, not the person | F4: "trained new tellers on our escalation script". Answer slot: if you changed how you explained it when it didn't land, say what and why. If you didn't, say so plainly and describe how you trained them |
| Neighbours, Not Numbers | Each branch belongs to its town, so treat members as people from that town, not case numbers | Selection scaffold: pick a time knowing the local community changed how your branch handled something. If none comes to mind, say so plainly, then say how you would bring that into the role (F6: "the last 3 as a branch supervisor") |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses". Answer slot: if you built it because you spotted a problem, say what the problem was, in your own words. If you were asked to build it, say so plainly and describe building it. Don't supply an outcome your material doesn't give |

### Question bank C

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold from the cheat sheet: the member, the choice, what the member's view changed, and the outcome, with your part said as "I". If no such time comes to mind, say so plainly, then give the nearest thing your material carries, that you handled the branch's formal complaints log, or how you'd handle it | Members First, Always, worded as the value page words it. VAL because the panel scores it by name |
| C2 | "Tell me about a time you had to explain something so people got it first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: new tellers, the escalation script, and you trained them. Answer slot: the value's "if a member needs it explained twice" makes a probe on whether you changed how you explained it likely. If you did, say what and why. If you didn't, say so plainly and describe how you trained them | Plain Words. F4 is your closest sentence to it |
| C3 | "Tell me about a time local knowledge, of the town or the people, changed how your branch handled something." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: a specific member or local situation, what local knowledge told you, what you did differently. If no such time comes to mind, say so plainly, then say how you'd keep each branch's local view in a process run across several branches | Neighbours, Not Numbers. Branch managers will care about this one most, and the 2027 hubs make it live |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: you built the spreadsheet your regional manager uses. Answer slot: if you built it because you spotted a problem, say what, in your own words. If you were asked to build it, say so plainly and describe building it. Don't claim it solved anything unless you can say what | Own the Fix, worded as the value page words it. F3 is the one sentence where you made something |
| C5 | The 20-minute case: a complaint escalation | CASE | [grounded] | Follow the graded-deliverable section. Clarify first, including which rules and deadlines apply. Then the three theses, each with its concession. Then the anti-pick. End on what the member hears, what the branch learns and what goes into the report. Name a value aloud when you use it | Declared in the recruiter's email and scored. CASE delivery on F1, F4 and F7's requirements |
| C6 | "You'd be coaching our supervisors on escalations. How would you do that without cutting across us as their managers?" | JD | [grounded] "trained new tellers on our escalation script"; "the last 3 as a branch supervisor" | Principles first: agree with each manager what you coach on, share what you see with them, and leave their people's management to them. Then your background at the quotes' scope: the last three of your six years were as a branch supervisor, and you trained new tellers on your escalation script. Answer slot: if any part of how that training ran was yours to shape, say which. If not, say so plainly | The Peer persona on the JD's coaching line. F4 is adjacent, not a match, so lead with principles |
| C7 | "When a complaint at my branch escalates to you, what do I need to give you, and what do I get back?" | JD | [generic] | Reciprocity: from the branch, a clear handover and what the member has already been told. Back to the branch: the member kept informed, the outcome shared, and patterns across branches each month. This needs no claim about your past | A collegial version of the "end to end" ownership line. `[generic]` because it's a working pattern |
| C8 | "Over 2027, eight branches become five hubs. How would you keep complaint handling steady through that?" | CO | [grounded] | Recognise first that these are their teams and towns ("Neighbours, Not Numbers"), and don't guess which branches are affected. Then: watch complaint volumes around each change, keep one owner per complaint across any move, and tell members about changes in plain words | Required strategy question, and the one most personal to this panel. CO because it rests on the brief |
| C9 | "You've never presented above regional level. Why should we trust you to put our branches' complaints in front of senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Pause. Concede plainly: "I haven't presented to anyone above regional level." Hold on what you did: you built the monthly complaints spreadsheet your regional manager uses. Then the plan: the monthly report as the anchor, a dry run, and the branches' view carried in. Through two follow-ups, hold on the plan and add nothing to the past | Pressure on F8. The negative in the question is one you stated yourself, so it's a fair premise |
| C10 | "App-only banks are our main competitor. What can a branch do for a complaining member that they can't?" | CO | [grounded] | Answer from Ashgrove's values, not from claims about competitors: a person in the member's own town ("Neighbours, Not Numbers"), answers that don't need explaining twice ("Plain Words"), and one person who keeps hold of the fix ("Own the Fix"). Don't make claims about how app-only banks handle complaints | The competitive frame from the brief, asked in a values round |

### Reverse questions, round 3

| Question | Why it lands |
|---|---|
| "What could someone new in this role do in their first month that would genuinely help your branches?" | A reciprocity question for partners whose supervisors you'd coach |
| "Where do your supervisors find escalations hardest?" | It's your coaching brief, straight from the source |
| "How do complaints get from your branch to the centre today, and what would you change?" | It shows you'll own the process with branches, not over them |
| "How are your branches thinking about members who won't move to digital?" | It links the 40% target to Members First and Neighbours, Not Numbers |
| "What does Own the Fix look like when a problem crosses from a branch into the contact centre?" | It uses their value by name, on the gap you'd be closing |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches (F1) | C5, B4, C7 |
| ...and the contact centre (F2) | A7, B1, B3, B12 |
| Report monthly on volumes and resolution times (F3) | A4, B8, B10 |
| Coach branch supervisors on escalations (F4) | B6, C6 |
| Work with digital teams on self-service journeys (F5) | B11 |
| 4+ years in financial-services customer operations (F6) | A5, A1 |
| Experience handling regulated complaints (F7) | A6, C5 (the clarify step) |
| Confident presenting to senior leaders (F8) | B2, B3, C9 |
| Comfortable with Excel reporting (F9) | B9 |
| Each published value | C1 to C4, cheat sheet |
| Defend-the-number questions | None needed: your background states no figures beyond years of service, which A5 checks |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end, or ran complaints across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." Your material covers one branch's log, not a process. F1's slot stays inside the log |
| Has contact-centre experience | A gap you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A gap you stated, F8 | "I haven't presented to anyone above regional level." The only slot is about regional level |
| Reported on complaint volumes and resolution times, or reports to senior leadership | Inflated form of F3 | F3's quote, with "uses" left as "uses". The slot asks only what the spreadsheet tracks |
| Handled regulated complaints | Inflated form of F7 | F7's quote. The slot asks only what went into the log and what made it formal |
| Coached supervisors, or wrote the escalation script | Inflated form of F4 | F4's quotes. The slot asks only which part of the training was yours to shape |
| Built Excel reports | Inflated form of F9 | F9's quote. The slot asks only for the tool's name and what you do in it |
| Calling your six years "customer operations" | Inflated wording of F6, using the JD's words for your history | F6's quote: six years in retail banking, the last three as a branch supervisor |

---

## Sources

**Provided documents:**
- The job description, pasted by you.
- The values text, pasted by you, copied on 12 November 2026 from ashgrovecu.org/about/values. I didn't fetch it.
- The recruiter's email about the process, pasted by you.
- Four points from Ashgrove's 2026 strategy brief (published July 2026, sent to you by the recruiter), pasted by you.
- Your background, from your message.

**Searches and fetches:** none sent.
**Dossier:** none consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you copied this morning sets the cheat sheet and the VAL themes |
| 2. Ashgrove Credit Union interview process | skipped | The recruiter's email sets all three rounds, the case and the values scoring |
| 3. Ashgrove Credit Union strategy and recent news | skipped | The July 2026 brief is under six months old and supplies the priorities and competitive frame for the CO questions |
| 4. Interviewer names | n/a | No names have been assigned, so there's nothing to search. The interviewer read is left out |
| 5. A representative Member Experience Lead JD | skipped | You supplied the JD, which sets the fit snapshot and the JD questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for each person, persona weights from their public professional profiles, and at least one reverse question tied to each person's career.
- **Which complaint rules and deadlines Ashgrove works to** (one email to the recruiter) → F7, A6 and the case's clarify step move from asking to knowing.
- **The case format** (written brief or verbal, given in advance or on the day) → a case section built for that format.
- **Your answers to the answer slots in F1, F3, F4, F5, F7, F8 and F9**, told to me outside a drill → those rows and every question that draws on them regenerate as quoted evidence.
- **A de-identified copy of the spreadsheet's layout**, column headings only and no member data → F3 and F9 can move from medium towards high, and B8 can be drilled against the real columns.
- **How much prep time you have before 21 November** → a prioritised prep schedule.
- **The full strategy brief text**, not just the four points → sharper CO questions and a fuller grounding brief.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → recent Ashgrove news, published complaint or member-service data, and reports on how this kind of role is interviewed.
- **A tuesday-dossier.md from job-underwriter** → verified evidence and an objection drawn from the evidence rather than inferred. It isn't needed for this pack.
