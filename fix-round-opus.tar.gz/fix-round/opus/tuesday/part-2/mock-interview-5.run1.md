Reading the prep playbook's rules is done. Next I'll run a few web searches on Kelverton Rail and the two panellists, then write your prep pack.
I've built your prep pack. It's sized to your four hours: about 75 minutes on the 15-minute talk, then the commercial pushback you'll get from Ross.

**What it's built on:** your message and the recruiter's email, nothing else. I tried six web searches on Kelverton, Deepa and Ross, but web search permission wasn't granted, so none ran. That means:
- Anything about Kelverton beyond what you told me is labelled `[generic]`, meaning a typical pattern for this kind of role rather than a fact about them.
- I don't have the market report. The pack tells you where to use it, but nothing in it comes from the report.

**The four things that matter most:**

- **The 15-minute talk.** There's a build section with a time plan and three arguments to choose from, each paired with a weakness to admit before they raise it. It ends on what each argument means for operators, which is the close the recruiter asked for.
- **The report.** Deepa and Ross's own team wrote it, so summarising it back to them only proves you did the reading. The pack has you use it in three moves:
  1. one point you agree with;
  2. one place you'd go further, with your reasons;
  3. one thing you'd deliberately not do in the 18 months.
- **Your most important rehearsal (B1).** Ross asking, "You've never carried a quota, so why should I trust you with a number?" The pack coaches you to say it first, in your own words: "I've never carried a direct quota — my number was influenced revenue." Then hold that through two follow-ups without calling it closed or owned revenue.
- **Claims to avoid.** The pack lists what you must not drift into under pressure:
  - The £4M is influenced revenue, never closed or sourced.
  - Your consulting was bus and light rail network planning, not train operators.
  - Your message doesn't make clear whether the five consulting years are inside the nine, so never add them up to "14 years".

The rest of the pack is 23 practice questions grouped by interviewer style, six questions to ask them, and a sources section.

I can play Ross on B1, the quota question, and push back on your answers live.
I can also save a `tuesday-dossier.md` file recording the gaps this prep exposed, for you to bring to later sessions.
If you want the pack as a Word document, I'll convert it.

Can you paste the job description, or your CV if you have it to hand? Either one would let the pack quote your real CV lines and the role's actual requirements, instead of the typical requirements it uses now. It works without them.

Do you want me to research Kelverton, Deepa and Ross? I'd need web search allowed. The standard pass is up to 6 searches and 2 page reads. A deeper pass adds the same again and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-5-denied-ca79508b:
- Kelverton-Rail_senior-partnerships-manager_interview_pack.md

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel, Tuesday
**Panel:** Deepa, VP Partnerships (your future manager) and Ross, Commercial Director
**Format, as the recruiter set it:** a 15-minute spoken POV with no slides on where you'd take operator partnerships over the next 18 months, landing on what it means for the operators themselves. Then Q&A, with Ross pushing on commercials.
**Built on:** your message and the recruiter's email you quoted. No JD, no CV, and no web research: every search was refused (see Sources). Anything about Kelverton beyond what you told me is labelled `[generic]`.

---

## 1. How to use this pack

- **Personas** describe how a question gets asked: who asks it, and in what register. **Types** describe what's being scored.
- Type key:
  - **VAL**: behaviour against values
  - **EXP**: whether your stated experience holds up under scrutiny
  - **JD**: whether you can do the job as stated, gaps included
  - **CO**: company and market homework
  - **CASE**: a live problem from the role
- Provenance labels: `[grounded]` traces to your message or the recruiter's email. `[inferred]` is a derivation, and the derivation is named. `[generic]` is a role-family pattern that makes no claim about Kelverton.
- An **answer slot** is an instruction for the interview, not a question to me. It names a probe you're likely to get. If the practice was yours, describe it in your own words. If it wasn't yours, or never existed, say that plainly.
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words.

## 2. Prep triage: 4 hours

| Order | Time | What | Pack reference |
|---|---|---|---|
| 1 | 75 min | Build the POV, then deliver it aloud three times against a 13-minute timer. Write a single index card; nothing more | Section 3 |
| 2 | 40 min | The highest-ROI rehearsal: the quota objection, through both follow-ups, until it bores you | B1 |
| 3 | 25 min | Defend both numbers aloud: the £4M and the 6 to 40 | B2, D1, D2 |
| 4 | 30 min | Re-skim the market report. Pick the one point you agree with, the one you'd take further, and the one thing you'd not do | Section 3, A4 |
| 5 | 30 min | Ross's commercial cases | B4, B5, D3, F1 |
| 6 | 20 min | Deepa's skeptic bank | C1–C4 |
| 7 | 10 min | Choose 3 reverse questions, one for each panellist and one shared | Section 7 |
| 8 | 10 min | One live drill, on B1 or the POV close | Drill offer |

Everything else in the pack is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material describes an ISV channel in payments, not operator partnerships in rail. Keep the words at that scope: "At a payments company I ran the ISV channel and took it from 6 partners to 40." Answer slot: an 18-month brief makes a probe on how that growth was planned likely. If any of the plan was yours to set, say which part and how you decided. If there was no plan, or it wasn't yours, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, done as a consultant. It doesn't say train operators, and it doesn't say who the clients were. Words: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: "the operators themselves" makes a probe on who your consulting clients were likely. If operators were among them, say what kind and what the work was. If the clients were others, say so plainly and stay with network planning |
| F3 | Experience selling into, or partnering within, the rail sector — role-family requirement, no source | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I haven't sold into rail specifically." Follow with how you'd ramp, stated as a plan and never as past experience. Don't add anything to shrink the gap |
| F4 | "Ross will push on commercials." — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure is influenced revenue, roughly £4M, and it stays exactly that. Answer slot: the figure raises four probes. How it was counted. What it's sensitive to. Which assumption behind it you'd defend least. Which part was yours. Answer each in your own words. "I don't know how it was counted" is an honest branch |
| F5 | Being accountable for a direct revenue target — role-family requirement, no source | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I've never carried a direct quota — my number was influenced revenue." It's the single most predictable objection in this panel, and B1 rehearses it |
| F6 | Building and scaling a partner programme — role-family requirement, no source | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap, but this is a self-report with nothing behind it that anyone has checked, so expect a probe. Lead with the count in your sentence's own terms: 6 partners to 40. Which partners came from you is D1's slot |
| F7 | Senior, sustained partnerships experience — role-family requirement, no source | "9 years in partnerships" — your message; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | none | Your message can be read two ways: the five consulting years may or may not sit inside the nine. Tell your timeline the way that's true, and never add the two numbers together |
| F8 | Current knowledge of the company's market and position — role-family requirement, no source | "She also attached the market report their strategy team circulated internally last quarter, which I've read." — your message | medium | [grounded] | none | The panel's own strategy team wrote this report, so they know it better than you do. Use it to show you've read it, then depart from it with reasons (section 3). Don't recite it |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 the 18-month POV | Section 3, A1, A2, A5, C1 |
| F2 what it means for operators | Section 3 close, A3, C4, G2 |
| F3 rail sector | B3, C2, E2 |
| F4 commercials | B1, B2, B4, B5, D2, D3, F1 |
| F5 revenue accountability | B1, C2 |
| F6 programme building | A2, D1 |
| F7 seniority | E1 |
| F8 market knowledge | A4, E2 |

---

## 3. Graded deliverable: the 15-minute POV

The recruiter asked for a POV on "where you'd take our operator partnerships over the next 18 months". It should be "no slides needed, just talk us through it", and it must "land on what it means for the operators themselves."

### Grounded facts to build on

| Fact | Row | Quote it rests on |
|---|---|---|
| You ran a partner channel and grew it | F1, F6 | "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" |
| You come at operators from consulting | F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." |
| You've read their strategy team's report | F8 | "She also attached the market report their strategy team circulated internally last quarter, which I've read." |
| Two gaps you'll name, not hide | F3, F5 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." |

### Shape: about 13 minutes, leaving 2 for interruptions

| Minutes | Beat | Provenance |
|---|---|---|
| 0–1 | **Frame.** "Operator partnerships" can mean two things: operators as the partners, or partners who serve operators through Kelverton. Say which reading you're taking, or that you're taking both, in one sentence. Then one sentence on your vantage point, using F1 and F2's quotes at their own scope | [inferred] from the recruiter's phrase, which supports both readings |
| 1–3 | **Where things stand.** Take one point from the report you agree with and say why. This is the consensus item that shows you've done the reading | [grounded] on F8, with the content taken from the report |
| 3–10 | **Two or three theses**, from the table below, each with its concession said out loud | [generic] |
| 10–13 | **What it means for operators.** The close the recruiter asked for. See below | [generic] |
| 13–15 | Hand over. "That's where I'd start. I'd like to know where you'd push back." | — |

### Thesis options: pick two, or three if they fit in time

| Thesis | What you'd argue | Mandatory concession | Provenance |
|---|---|---|---|
| T1 Depth over breadth | Build a small, tiered set of deeply integrated partners around the operator workflows the scheduling product touches, instead of a wide catalogue. Measure partnerships on operator outcomes and revenue, not on partner count. Answer slot: growing a channel to 40 makes a probe on what breadth cost you likely. If growing it taught you something about breadth, say what, in your own words. If it didn't, present this as a judgment about rail, not a lesson from payments | Depth looks slow at month 6: fewer logos and a smaller headline. Say that before Ross does | [generic] |
| T2 Operators as design partners | Bring a small group of operators in as design partners, so partner integrations get built on problems operators name rather than ones vendors assume | Operators' time is scarce, and a group like this can turn into a complaints forum. It needs a tight remit and a visible payoff for the operators who take part | [generic] |
| T3 A partnership P&L | Give each partner tier clear economics: who sources, who sells, who supports, and how each party gets paid. Hold partnerships to a number Ross recognises | Partner-led and direct selling will collide on the same operators. Name channel conflict as a risk you'd design for in month one | [generic] |

### Differentiation

Deepa and Ross's own team wrote the report, so reciting it scores as homework and nothing more. Use it in three moves:

1. **One consensus item** from the report, to show you've read it.
2. **One divergence** with your reasons: a point where you'd go further than the report, or in a different direction.
3. **The anti-pick:** one thing you would deliberately not do in the 18 months, and why. Saying no is part of a partnerships lead's job. A broad open marketplace and partner-count targets are two candidates. Pick whichever is true for you after re-reading the report. `[generic]`

### The close: what it means for operators

Translate each thesis you used into something an operator would notice. Use the operator problems the report names, in its own words where you can.

| Thesis | Operator-facing outcome to say | Provenance |
|---|---|---|
| T1 | Fewer integration projects operators run themselves, and one accountable route when a partner product touches their schedule | [generic] |
| T2 | A say in what gets built, and evidence that it was heard | [generic] |
| T3 | Clear terms when a partner is involved: who they call, who fixes it, who they pay | [generic] |

---

## 4. Reading the panel

There's no public footprint here, because research was refused. This is only what the recruiter's email says.

| Panellist | What the recruiter said | Practical implication | Provenance |
|---|---|---|---|
| Deepa | "VP Partnerships, your future manager" | She's buying a strategy she'd have to defend upward. Expect her to test whether the POV can actually be executed, and whether your experience carries over | [grounded] on the role; implication [generic] |
| Ross | "Commercial Director" and "Ross will push on commercials." | Every thesis gets a "where's the money" follow-up. Influenced revenue versus quota is the seam he's most likely to press | [grounded] on the email; implication [inferred] from that line |

## 5. Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Case / Strategist | Follow-ups on the POV: which move first, how you'd choose partners, what you'd measure | Highest. It's the top persona for both a hiring manager and a senior commercial interviewer, and the POV invites it | Clarify, then structure, then say what you'd measure. Challenge one premise politely | [generic] prior, set by the recruiter's format |
| Pressure | Ross time-boxing, "how much was you", "why not a rail seller" | High. The recruiter said "Ross will push on commercials." | Pause, restate the question, hold through two follow-ups, then concede only what's real | [grounded] on the email |
| Skeptic | Deepa on fit: payments to rail, the consulting vantage, the weakest area on day one | Medium-high. It's a hiring manager prior, and F3 and F5 are visible gaps | Name the gap first, then give your bridge from quoted evidence and a ramp plan | [generic] prior |
| Data-Driven Prober | The £4M and the 6 to 40, taken to their assumptions | Medium. Commercial focus plus two headline figures | Know what you can and can't say about how each was counted | [inferred] from the email line |
| Conversational | The opener and the "why rail" aside | Low-medium. Panels usually open with it, and it's still scored | Have a 90-second arc ready | [generic] |
| Peer Evaluator | Ross on where partnerships meets sales | Low-medium. He isn't your peer, but his team sits on the seam | Talk about reciprocity, and propose principles for the seam | [inferred] from the two roles |
| Values / Behavioral | A "tell me about a time" with partners or customers | Low. No values round was named | Use selection scaffolds | [generic] |

---

## Question banks

### A. Case / Strategist: Deepa and Ross

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If you could only fund one of those moves in the first six months, which one, and why?" | CASE | [generic] | Pick one thesis from your POV. Say why it goes first: operator value, revenue timing, how reversible it is. Say what you'd deliberately leave until later. The question asks for no claim about your past, so don't make one | The most natural first follow-up to an 18-month POV. CASE because it scores prioritisation live |
| A2 | "How would you decide which partners to bring in first?" | CASE | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Structure: the operator problem, then the partner category that solves it, then the criteria (operators you share, integration effort, commercial fit), then a pilot. You can mention that you took a channel from 6 partners to 40. Answer slot: that growth makes a probe on how partners were chosen likely. If you had criteria, say what they were. If there were none, or they weren't yours, say so plainly and stay with the structure above | F6 is evidence of growth, not of selection. CASE content, with an EXP edge |
| A3 | "An operator asks us to integrate with a supplier we don't partner with. What do you do?" | CASE | [generic] | Clarify: how many operators want it, and what problem it solves. Options: build, partner, refer, or decline. Decide on operator value against cost. Close on how you'd tell the operator | Tests the operator-first close under commercial constraint (F2's requirement) |
| A4 | "What did you take from the market report we sent?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Three beats: one thing you agree with, one you'd push further, one question it leaves open. Quote the report's own terms. Don't summarise it back to its authors | F8. CO because it's homework depth, and its authors are sitting in the room |
| A5 | "What would you measure at 6, 12 and 18 months to know this is working?" | CASE | [generic] | Pair leading indicators (integrations live, operators using them) with lagging ones (revenue sourced or influenced, retention). At least one metric should be an operator outcome. Partner count should not be the headline | A POV without measures invites Ross's next question. It sets up B5 |

### B. Pressure: Ross

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a quota. Why should I trust you with a commercial number?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "took it from 6 partners to 40, roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Hold only what the quotes carry. Start: "That's right — I've never carried a direct quota; my number was influenced revenue: roughly £4M, across a channel that went from 6 partners to 40." Then stop, and let him ask the next question. Follow-up 1, "So someone else closed it?": answer slot. Say which part was yours, in your own words. If none of the closing was yours, say so plainly and return to the channel. Follow-up 2, "Would you take a number here?": answer honestly with what you'd want, in your own words. The concession, said once and specifically: "A direct quota would be new for me." Never rename influenced revenue as closed, sourced or owned | F5 is a gap you stated, and the recruiter's line about Ross makes this probe close to certain. JD because it scores commercial accountability. The pressure is in how it's delivered |
| B2 | "£4M influenced. How much of that was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Keep "roughly" and "influenced". Answer slot: how the figure was counted, what it's sensitive to, which assumption behind it you'd defend least, and which part was yours. Answer each in your own words. If you don't know how it was counted, say so. Name the weakest assumption yourself, before he does | F4's figure is the obvious target. EXP because it scores attribution honesty |
| B3 | "Sixty seconds: why you over someone who's sold into rail for ten years?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."; "last 4 at a payments company running the ISV channel" | First: "I haven't sold into rail specifically." Then two facts at their own scope: you ran an ISV channel at a payments company, and you spent five years in transport consulting on bus and light rail network planning. Leave the interviewer to draw the inference; don't assert it for yourself. Stay inside 60 seconds | F3 plus the time-box. JD because it scores fit against what the role needs |
| B4 | "Partners want a bigger share than we want to give. Where do you land?" | CASE | [generic] | Clarify what the partner brings: sourcing, delivery, support. Tie their share to that contribution, and to what the operator gets. Offer a tiered structure, or a time-limited trial. Say what you'd walk away from | Ross's native ground (F4's requirement). A live problem that presupposes nothing about your past |
| B5 | "Your POV sounds like a cost. Where's the revenue for us inside 18 months?" | CASE | [generic] | Take it head on. Name where revenue would show up first in your chosen thesis, when, and what you'd need to believe for that to happen. Concede that early quarters are mostly investment, if your own plan says so | Puts the POV under pressure (F1, F4). CASE content in a pressure delivery |

### C. Skeptic: Deepa

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Rail isn't payments. What carries over from your ISV channel, and what doesn't?" | JD | [grounded] "last 4 at a payments company running the ISV channel" | Two lists, said plainly. Answer slot: if particular ways you ran the channel would carry over, name them in your own words. If you can't point to any, say so and talk about what you'd want to learn first. On what doesn't carry over, lead with F3's words: "I haven't sold into rail specifically." | F1's transferability gap. JD because it scores whether you can do this job |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Choose one of your two stated gaps and say it plainly, in its plain form: "I haven't sold into rail specifically", or "I've never carried a direct quota". Then a 90-day ramp plan, stated as a plan. Don't pick a fake weakness | Calibrated candour on F3 or F5. JD |
| C3 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | You can name the consulting years as part of the thread. Answer slot: give your real reason in your own words. If the consulting years aren't part of why, don't force them in | Motivation consistency. Nothing in your material states the reason, so it's a slot |
| C4 | "You say you know the operator world from the other side. What does that actually mean?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Start with the facts: five years, transport consulting, bus and light rail network planning. Answer slot: say who your clients were and what the work was, in your own words. If operators weren't the clients, say so plainly. Never stretch it to train operators | F2. Your own phrase invites the probe, and the relationship axis is where it would break |

### D. Data-Driven Prober: Ross

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through 6 to 40. Which partners came from you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: how the count was kept, what it's sensitive to, which assumption you'd defend least, and which partners came from you, in your own words. If you don't know, or none came from you, say so and stay with running the channel | F6's figure. Defend-the-number |
| D2 | "How did your last company define and count influenced revenue?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: how it was counted and the assumption you'd defend least, in your own words. "I don't know how it was counted" is an honest answer. Don't describe a method you didn't use | F4. The definition is exactly where a commercial director digs |
| D3 | "What commercial terms did your partners sit on?" | EXP | [grounded] "last 4 at a payments company running the ISV channel" | Answer slot: Ross's push on commercials makes a probe on partner terms likely. If you set or negotiated any terms, say which ones and how. If there were no such terms, or they weren't yours, say so plainly and return to the channel you ran | F4's discovery gap. EXP because it tests what was actually yours |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through the journey." | EXP | [grounded] "9 years in partnerships"; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."; "last 4 at a payments company running the ISV channel" | A 90-second arc in your own order: transport consulting, then partnerships, with the last four years running the ISV channel at a payments company. Tell the timeline the way it's true (F7), and don't add the years together. End on why this role | The opener is scored too. F7's ambiguity is caught here |
| E2 | "What are you following in rail at the moment?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | The report is one honest source you can name. Answer slot: if you follow other things in rail, name them. If you don't, say so plainly and talk about the report | F8 and F3, asked casually. Still scored |

### F. Peer Evaluator: Ross, on the seam with sales

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "A partner-sourced deal and a direct deal land on the same operator. What happens?" | CASE | [generic] | Propose principles: registration rules, who owns the operator relationship, how credit is shared. Make the operator's experience the tiebreaker | Channel conflict is T3's concession. Ross owns the other side of this seam |
| F2 | "What would you need from my team in your first 90 days, and what would you give back?" | CASE | [generic] | Give before you ask. What you'd bring sales (partner-sourced pipeline, integrations they can sell), then what you'd need (account context, joint planning) | Reciprocity framing. The partnerships and sales seam |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you told a partner something they didn't want to hear." | VAL | [generic] | Pick a time you can name: what was at stake, what you said, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Persona stem. No values round was named |
| G2 | "When did you put the end customer ahead of a partner's number?" | VAL | [generic] | Pick a time with a real trade-off and an outcome you can name. If none comes to mind, say so plainly, then say how you'd handle it here, using the operator lens from the POV close | The theme comes from the recruiter's "what it means for the operators themselves" |

---

## 7. Reverse questions

| # | Question | Who to ask | Why it lands |
|---|---|---|---|
| R1 | "How is partnerships measured today: sourced, influenced, or a direct number?" | Deepa | It shows you've seen your own F5 seam, and the answer tells you what you'd be held to |
| R2 | "When a partner is in a deal, how do you and Deepa split commercial ownership?" | Ross | Raises the seam before he does, and gets real information about channel conflict |
| R3 | "Of what your strategy team's report flagged, where do you two disagree with it?" | Both | It turns your reading into a conversation and draws out live strategy |
| R4 | "Which operator relationship would you most want this role to change in its first year?" | Deepa | Ties the POV close to their reality |
| R5 | "What's one thing in the current partner setup you'd stop tomorrow?" | Ross | It invites candour, and tells you what you're inheriting |
| R6 | "What would make you say, at 12 months, that this hire worked?" | Both | It makes them state the bar out loud |

---

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried, hit or beat a quota | A negative you stated, F5 | "I've never carried a direct quota — my number was influenced revenue." |
| Has sold into rail, or has rail experience | A negative you stated, F3 | "I haven't sold into rail specifically." |
| Closed, generated, sourced or owned £4M | Inflated form of F4 | F4's quote at its own scope: roughly £4M of influenced revenue. The pack observes that your material says influenced, not closed. B2 and D2 slots stay inside that scope |
| A precise £4M | Logical-form drift on F4 | Keep "roughly" |
| Built or founded the ISV channel, or personally recruited the 34 new partners | Inflated form of F1 and F6 | You ran the ISV channel and took it from 6 partners to 40. Which partners were yours is D1's slot |
| Worked with train operators, or in heavy rail | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning, in consulting. C4's slot covers who the clients were |
| 14 years' experience | Ambiguity in F7, resolved downward | Tell the timeline the way it's true |

---

## 14. Sources

**Provided documents:** your message, including the recruiter's email quoted in it. You mentioned the market report, but its contents weren't shared with me, so nothing in this pack comes from it.

**Searches sent, all refused** because web search permission wasn't granted:

1. `Kelverton Rail values`: refused
2. `Kelverton Rail interview process partnerships`: refused
3. `Kelverton Rail scheduling software train operating companies news 2026`: refused
4. `Deepa VP Partnerships Kelverton Rail`: refused
5. `Ross Commercial Director Kelverton Rail`: refused
6. `"Senior Partnerships Manager" rail software job description UK`: refused

No fetches were sent.

**Loop:** the recruiter's email sets out the session: one 60-minute panel, a 15-minute POV, then Q&A. That email names no values round, so the pack has no values cheat sheet.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Refused. It would have themed VAL questions with published values. No cheat sheet would have followed, since no values round was named |
| 2. `Kelverton Rail interview process` | unavailable | Refused. The recruiter's email sets out the session anyway, so persona weights stand |
| 3. `Kelverton Rail` strategy / news | unavailable | Refused. It would have grounded the CO questions, the POV theses and the operator close in current facts. They're `[generic]` instead |
| 4. `Deepa` and `Ross` at `Kelverton Rail` | unavailable | Both searches refused. They would have given a career-pattern reading of the panel and a reverse question tied to each person's path |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | Refused. Rows F3 and F5–F8 are role-family requirements labelled `[generic]`, and a fetched JD would have made them `[inferred]` |

---

## 15. Upgrade menu

- The JD text → F3 and F5–F8 become `[grounded]` on the JD's own lines, and every stated requirement gets a JD question
- Your CV → the pack can quote each bullet alongside the figures. Currently everything rests on six sentences from your message
- The market report's key points, pasted (headline numbers, operator pain points, priorities) → a grounding brief, CO questions built on its actual claims, and a POV close in the report's own operator terms
- Allowing web search → Kelverton's published values, recent news and Deepa's and Ross's public career paths. That changes the panel reading, the persona weights and R1–R6. A deeper pass is up to 6 more searches and 2 more fetches, several more minutes
- Telling me in plain text who your consulting clients were, and how the £4M was counted → F2, F4 and the C4, B2 and D2 slots become story-mapped guidance
- A `tuesday-dossier.md` from an underwriting pass → evidence already verified, the main objection derived from that evidence rather than inferred, and a prohibited list you'd already confirmed. Useful, not required
