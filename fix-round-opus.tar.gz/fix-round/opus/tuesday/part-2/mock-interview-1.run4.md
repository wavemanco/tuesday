Reading the reference files directly.
I've built the full mock-interview pack for Priya's 60-minute conversation with Dan: 21 questions split across seven interviewer personas. Each question carries a type tag, answer guidance, a column showing which of your notes it rests on, and a rationale for both why it's included and why it's tagged that way.

My web searches were refused, so the pack uses only what you gave me. That means I couldn't check Northwind's published values, its interview loop, Dan's public profile, or whether your research note is still current.

**How it's organized**
- **Persona weights** come from Dan being a peer, plus his "relentlessly data-driven" self-description, his pricing background and his startup chapter. The banks run in this order: Data-Driven Prober (5 questions), Peer Evaluator (4), Case/Strategist leaning toward pricing (3), Skeptic (3), Pressure (2), Conversational (2), Values (2).
- **Highest-value prep is question D1, on partner-motion design.** It's the only requirement the JD marks as required. Priya's closest evidence is the partner-level revenue model used in carrier negotiations, which is related work but not the same thing. The pack rehearses it through three follow-ups.
- **The ~$400M number** gets two defend-the-number questions (A1 and E2). The guidance keeps your wording: she *proposed* the change, and it was *credited with* the uplift.
- **The lack of sales-ops or quota experience** matters more than usual because that's Dan's own function. The pack coaches a plain admission and never presents her volume targets as quotas.
- **The case questions** use your research note: how to package Compass, how to respond to the bundling threat, and where to launch first under the profitability goal.

The pack also includes six reverse questions for Priya to ask Dan, including one about his move from pricing into sales strategy. There's also a list of claims it won't coach her to make, such as "negotiated the carrier deals" or "drove the $400M." In several places the guidance leaves a slot for Priya's own answer, with an honest version for either case, rather than inventing details.

If you like, I can run a live drill where I play the Skeptic on D1.
I can also save a `tuesday-dossier.md` file recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-1-denied-ecac403a:
- northwind-data_senior-gtm-strategy-lead_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Conversation:** one 60-minute session with Dan Kovac, Director of Sales Strategy, a **peer** (you would both report to the same VP)

---

## How to use this pack

Each question has two tags. The **persona** describes how the question is asked, meaning who is asking and in what style. The **type** describes what is being scored. The banks are ordered by how likely each persona is in this conversation.

| Tag | What it scores |
|---|---|
| **VAL** | Behavioral and values fit: past behavior that shows the company's published values |
| **EXP** | Work-experience deep-dive: whether the claims survive scrutiny, and what was actually Priya's |
| **JD** | Role and JD: can she do the job as listed, including where she has gaps |
| **CO** | Company and strategy: can she think at Northwind's level about its priorities and competition |
| **CASE** | A live problem from the role, worked through out loud |

**Provenance labels.** `[grounded]` means the row traces to something you gave me. `[inferred]` means it is derived, and the derivation is named. `[generic]` means it follows a role-family pattern and says nothing specific about Northwind or Dan.

**Answer slots.** Some guidance cells contain an **answer slot**. That is a place where Dan is likely to ask about something your notes don't cover. Each slot has two honest answers: one if Priya did the thing, and one if she didn't or it wasn't hers. Both are good answers. The pack never fills in a slot for her.

The guidance gives Priya a structure to answer from. It is not a script. She should give every answer in her own words.

---

## Fit snapshot

The requirements come from the JD highlights in your message. The evidence quotes your description of Priya exactly. These quotes are the only facts the pack uses about her past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Her notes describe product strategy and ops in consumer tech. They don't describe owning GTM for a B2B product line, and her words should stay at that scope. She has product strategy and ops, and she proposed the store-surface change. Answer slot: the GTM-ownership line makes a probe on her B2B or go-to-market work likely. If any of her work went to business customers or set how a product went to market, she should say what and how, in her own words. If none did, she says so plainly and stays with the product strategy work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Strong evidence would be an analysis that found under-penetrated customers or segments, acted on by someone. Answer slot: if she has run that kind of penetration or attach analysis, she says what she looked at and what came of it, in her own words. If she hasn't, she says so and walks through how she would do it (A3 rehearses this) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but this is a résumé-style claim with nothing behind it to inspect, so Dan will likely test it live. She should state it at its own scope and be ready to work through one analysis end to end (A4) |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | This is adjacent work: a model used in partner negotiations is not the same as designing a partner motion. Her words: she built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: if any partner terms, structures or program elements were hers to shape, she names which and how. If her part was the model, she says so plainly and then presents her design for Northwind as a plan, never as past work (D1) |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already speaks to the requirement. She should tell it in its own terms (she set annual volume targets with cross-org consensus) and let Dan draw the conclusion about influence |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Using AI tools is not the same as AI product or GTM experience. The derivation is that the JD's "AI experience" could mean either. Answer slot: if any of her work involved AI features, products or launches, she says what, in her own words. If not, she says so and stays with what she uses AI tools for |
| F7 | Sales-strategy fluency: quota setting, sales ops, capacity and coverage planning. This is Dan's own function, not a JD line | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | This is a gap stated in your notes, and no wording closes it. Her words: "I haven't done classic sales ops or quota setting." After that she gives how she would learn it, framed as a plan. The annual volume targets in F5 are not quotas, and the pack never presents them as quotas |

---

## Reading the interviewer

Everything below is drawn only from what you told me about Dan. I couldn't run any research on him (see Sources).

| Signal | Provenance | What it means for this conversation |
|---|---|---|
| "Director of Sales Strategy at Northwind" and "he would be Priya's PEER, both reporting to the same VP" — your message | [grounded] | He will be judging whether she makes his job easier or harder. Expect questions about where their two remits meet (Bank B), and expect F7 to come up in a friendly way, because sales strategy is his own field |
| "'relentlessly data-driven'" — your message | [grounded] | He is likely to push every number to its assumptions. A1 and E2 (the ~$400M) are the most likely targets |
| "career spine is pricing and monetization roles" — your message | [grounded] | He will tend to frame problems through pricing, packaging and unit economics. Compass packaging (C1) and the bundling response (C2) are where he will feel most at home. Priya should reason through pricing questions out loud and not claim pricing experience her notes don't show |
| "with one early-stage-startup chapter" — your message | [grounded] | Expect some doubt about whether a big-company operator can move at startup pace, and probes on scrappiness (D3). Stories about building things tend to land well with him |
| Shared career path | [grounded] | None offered. His move was from pricing to sales strategy. None of the fit-snapshot rows describes a comparable move on Priya's side, so the pack doesn't build on one |

---

## Persona table

The weights below are a judgment call, with the reasoning shown. If you know something about Dan that I don't, adjust them.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | "How was that counted?" Follow-ups that go two levels deep on every number | **Highest.** A peer interview starts with this persona near the top, and his "relentlessly data-driven" self-description pushes it higher | Know what she can and can't say about how each number was counted. Name the weakest assumption before he does. Offer to walk through one analysis of her own end to end |
| B. Peer Evaluator | Where the two remits meet, what she would need from his team, how she handles credit and disagreement | **High.** This is the default lead persona for a peer, and they report to the same VP | Talk about what she brings to his team, not only what she needs from it. Propose principles for dividing the work rather than claiming to know where the line sits. Show both spine and tact when disagreeing |
| C. Case / Strategist | Live problems on Compass packaging, the bundling threat and where to launch first | **Mid.** His pricing and monetization background tilts the cases toward packaging and unit economics | Clarify, set the objective, segment, lay out options, name metrics, name risks. Think out loud, and respectfully challenge one premise per case |
| D. Skeptic | Quiet probes on the partner-motion gap, the move from consumer to B2B, and why now | **Mid.** The startup chapter raises the odds of scrappiness probes, and F4 is the gap behind a "required" JD line | Rehearse D1 until it bores her. Bridge only from facts in her notes, then give a concrete plan for ramping up |
| E. Pressure | Time-boxed questions, "how much was actually you" | **Low.** It's a peer interview, but a data-driven interviewer can switch into this mode on a single number | Pause and restate the question. Hold her position through two follow-ups, then concede specifically |
| F. Conversational | "Walk me through your journey," and a casual question about AI | **Low.** Likely as the opener, and the AI question is still scored because the JD lists AI as a plus | Use a prepared 90-second arc, and treat the casual AI question as scored |
| G. Values / Behavioral | Generic behavioral prompts | **Low.** No values round is documented, and his background isn't values-led. It still appears so she doesn't meet the style cold | Use a story that comes from her own material. Where none fits, she says so plainly |

---

## Question banks

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ~$400M ARR uplift on the store-surface change. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start with the quote's own verbs: she proposed the change, and the change was credited with a ~$400M ARR uplift. "Credited with" means someone else measured and assigned the result, so she should say it that way. Answer slot, covering the four things he may ask about the number: how it was counted, what it is sensitive to, the assumption behind it she would defend least, and which part was hers. She answers each in her own words, naming the weakest assumption before he asks. If she doesn't know how it was counted, she says so plainly ("I didn't own the measurement") and goes back to the proposal she made | Every headline number gets a defend-the-number rehearsal, and this is the biggest number in her notes, facing an interviewer who calls himself relentlessly data-driven. It is EXP because it tests attribution and measurement, not the role |
| A2 | "Walk me through the partner-level revenue model you built: what went into it, and how was it used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Tell it as the quote states it: she built the model, and it was used in carrier negotiations. She should be ready to sketch the model's structure from memory. Answer slot: the JD's partner-motion line makes a probe likely on whether the model shaped partner terms. If it did, and that part was hers, she says what changed and how, in her own words. If the negotiation was someone else's, she says so plainly and stays with the model | F4 is her closest evidence for the only "required" JD line, so Dan will want to see how deep it goes. EXP rather than JD because it scores what she actually built. D1 handles the requirement itself |
| A3 | "Say I give you our install base: accounts, products owned, usage, renewal dates. How do you find expand and renew whitespace? What's your first query?" | CASE | [generic] | Clarify which data exists and how clean it is. Objective: rank accounts by expansion potential and renewal risk. Approach: build an account × product footprint table, add usage trend and renewal window, segment by size or industry, and flag accounts that are deep on one product but haven't adopted an adjacent one. Show it in Tableau as a segment heat map with drill-down to account lists. Metrics: attach rate, the gap to a peer-segment benchmark, net revenue retention. Risk: usage data that doesn't reflect value. This question makes no claim about her past | It covers F2 and F3 together, as a live test of the JD's land/adopt/expand/renew and SQL/Tableau lines. CASE because it is the role's work done on the spot. Generic because the data model is assumed |
| A4 | "Tell me about an analysis you ran yourself, end to end, in SQL and Tableau." | JD | [grounded] "skilled in SQL/Tableau" | Selection guidance: pick one analysis she ran herself, from query to decision, that she could rebuild on a whiteboard. It needs a question, the data she pulled, what she found and who acted on it. "Skilled in SQL/Tableau" is the only fact the pack holds, so the specifics come from her. If no single analysis fits, she says so plainly, gives the nearest one, and offers to do A3 live | It covers F3, the JD's "independent analysis" line. Dan is likely to test whether she does the analysis herself or directs others. JD because the requirement is the target. It is an open prompt, so it assumes no particular analysis |
| A5 | "You set annual volume targets with cross-org consensus. How did you build the number?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Tell it as the quote states it: she set annual volume targets, with cross-org consensus. Answer slot: how the number was built, what it was sensitive to, the assumption she would defend least, and which part was hers rather than the result of the consensus process. All in her own words. If she doesn't know how actuals landed against the targets, she says so. She should not call these quotas | F5 is the nearest thing in her notes to Dan's own forecasting and planning work, so he will probe it in his own terms. EXP because it tests the method and her share of it |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "My team is sales strategy; yours would be GTM for emerging products. Where's the seam, and what happens when we disagree?" | JD | [grounded] "skilled in SQL/Tableau" | Propose principles as hypotheses to check with him, without claiming to know the line. One possible split: he owns the core sales motion and its mechanics, she owns GTM for the two new lines, and coverage, incentives and pipeline definitions for the new lines are shared ground they agree on together. For disagreement: agree on the metric definitions first, settle it with data, and if they still disagree, take one shared document to the VP together. What she offers his team: she is skilled in SQL/Tableau and can take analysis on the new lines off his plate. She should close by asking how he sees the split | It covers the JD's cross-functional influence line (F5) and the F7 boundary, delivered in the peer register. JD because influence is a stated requirement. It is the question most likely to decide whether he wants to work next to her |
| B2 | "Tell me about a time you had to get a number agreed across orgs that wanted different things." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets, and the cross-org consensus. Those are the beats the quote supports. Answer slot: the JD's cross-functional influence line makes a probe likely on where the orgs disagreed. If they did, she says what happened and her part in it, in her own words. If they didn't, she says so plainly and stays with how the targets were set. She uses "we" for the context and "I" for her own contribution | F5 is the evidence for a stated requirement, and a peer will care about how she gets agreement from equals. JD content, open-prompt delivery |
| B3 | "How do you handle credit when the work spans teams, say, on the store-surface change?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | She proposed the change, and that is the "I." The uplift was credited to the change, and that is the "we." Answer slot: which parts of building, shipping and measuring it belonged to other teams, in her own words. If she doesn't know who did each part, she says so and stays with the proposal | This is the peer persona's credit question pointed at her biggest claim. It shows Dan how she will share credit on work across both their teams. EXP because the test is attribution |
| B4 | "What would you need from my team in your first 90 days, and what would you take off our plate?" | JD | [generic] | Needs: access to pipeline and bookings data and its definitions, a sales leader to test ideas with, and early input on coverage for the new lines. Gives: analysis of the new lines that his team won't have to build, and hypotheses about the partner motion for him to react to. Then she asks what is on his plate right now. Nothing here claims anything about her past | It covers the JD's GTM-ownership line (F1) in reciprocity form. A peer is weighing whether this hire adds to his load or lightens it. JD because it is a test of how she would run the role |

### C. Case / Strategist, tilted toward pricing (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass launches. Do we bundle it into existing tiers or sell it as a paid add-on? How do you decide?" | CASE | [grounded] | Clarify: who buys it, how it's packaged today, and what AI usage costs Northwind to serve. Objective: weigh adoption against margin, since profitability is a stated priority, and weigh both against defense, since a much larger vendor bundles. Segment: existing enterprise accounts, where expansion is a stated priority, versus new logos. Options: include it in the top tier, sell it as an add-on, price it by usage, or a free tier with paid limits. Metrics: attach rate, expansion ARR, gross margin, and the effect on renewals. Respectfully challenge one premise: the answer may differ by segment. When he pushes on pricing, she reasons out loud and proposes a test. She doesn't claim pricing experience | It is grounded in your research note: the Compass launch, profitability and the bundling threat. His pricing background makes packaging his home ground. CASE with CO content. It is the best chance to show she thinks at the company's level |
| C2 | "A much larger platform vendor bundles a good-enough version of one of our new products for free. What's the GTM response?" | CASE | [grounded] | Clarify: which segment is exposed and how hard switching is. Then: where Northwind is genuinely better, and for whom. Defend renewals first in the accounts most at risk. Use partners as a channel the larger vendor doesn't control. On price, protect margin, because profitability is a priority. Not matching on price everywhere is the strategic choice. Metrics: win rate against the bundle, churn in exposed segments, discount depth. Risk: a price war the company can't win | It is grounded in the competitive threat in your research note. It tests whether she says no to a reflexive price cut, which a pricing-minded peer will notice. CASE with CO content |
| C3 | "You own GTM for two new product lines with a profitability mandate. Where do you land first: new logos or the installed base?" | JD | [grounded] | State a hypothesis early: probably the installed enterprise base first, because enterprise expansion and profitability are both stated priorities and selling to existing customers usually costs less. Then say what would change her mind: weak product fit in the base, or a segment the base doesn't reach. Lay out land/adopt/expand/renew per line, the metric for each stage, and the data she would pull in week one. Nothing here claims anything about her past | It covers the JD's GTM-ownership and whitespace lines (F1, F2) using the priorities from your note. JD content, CASE delivery. It is the closest thing to the actual job |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Partner-motion design is a hard requirement for this role. What partner motion have you designed yourself, and how would you design ours?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | **The highest-ROI prep in this pack.** Hold to exactly what the quote carries: she built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: if any partner terms, partner structure or program design were hers, she names which and how, in her own words. If none were, she says so plainly. That is a limit, not a confession, and she moves to the plan. **Follow-up 1** ("So you haven't designed one?"): she repeats the answer from her branch of the slot without adding to it. **Follow-up 2** ("Then why should we believe you can?"): she offers the plan. Segment partners by role (sourcing, influence, delivery), set economics for each, write rules for where partners and the direct sales team overlap (Dan's territory, so she asks for his input), plan enablement, and pick metrics such as partner-sourced pipeline and attach. All of it framed as a plan and none as past work. **Follow-up 3** ("How long to ramp?"): a concrete first 90 days, framed as a plan. She never adds a program, partner or result her notes don't show | F4 is the gap behind the only "required" line in the JD, so this objection is close to certain in some form. It goes in Skeptic because it is the persistent probe on a gap. JD because it scores that requirement directly |
| D2 | "Your background is consumer tech. Why does it carry over to selling data infrastructure to enterprises?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations" | Hold to the quotes: nine years in product strategy and ops at a large consumer-tech company, and a partner-level revenue model used in carrier negotiations. She shouldn't claim the move is easy. Answer slot: if any of her work went to business customers or partners, she says what, in her own words. If none did, she says so plainly. Then she names what she would have to learn (B2B buying cycles, enterprise sales motions) as a ramp plan. She describes what she did and lets him decide whether it carries over | F1 is a transferability gap, and the move from consumer to B2B is the broad objection behind D1. JD because it scores the GTM-ownership requirement. A premised question that rests only on her own quote |
| D3 | "Why leave a large consumer-tech company for a 3,000-person company, and can you move at our pace?" | CO | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Answer slot: her actual reasons for leaving and for choosing this role, in her own words. The pack doesn't supply motive. For "why Northwind," use the three priorities from your research note and the job of building GTM for two new lines from scratch. On pace: open prompt territory. If she has a time she built something with thin support, she tells it. If no such time comes to mind, she says so plainly and describes how she would work with less support | Motivation consistency is the Skeptic's core test, and his startup chapter makes the pace probe likely. CO because a strong answer depends on knowing Northwind's priorities |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run sales strategy in B2B SaaS?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau" | Pause, then answer in three beats taken from the quotes: the partner-level revenue model used in carrier negotiations, the annual volume targets set with cross-org consensus, and her SQL/Tableau skill. Then concede plainly: "I haven't done classic sales ops or quota setting." Hold that position through two follow-ups by returning to the three beats. Don't fold, and don't turn the volume targets into quotas | F7 is a stated gap, and Dan's function makes it the natural pressure point. JD because it scores fit to the role. The time box is the test of composure |
| E2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: she proposed the change. Concede the specific point: the ~$400M was credited to the change, and others built, shipped and measured it, as far as she knows. Answer slot: which part was hers beyond the proposal, in her own words. If nothing beyond the proposal, she says so. Hold through two follow-ups. She doesn't inflate the number to keep things smooth, and she doesn't shrink it to seem humble | This is the pressure version of A1. "How much was actually you" is a standard pressure stem. EXP because it tests attribution |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | A 90-second arc: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Two highlights: the partner-level revenue model used in carrier negotiations, and the annual volume targets set with cross-org consensus. Close with an answer slot for why this role now, in her own words. Keep the ~$400M for when he asks about it, so the opener doesn't invite the probe in A1 | This is the likely opener. Being concise is scored even when the question is casual. EXP because it sets up every claim he will later probe |
| F2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | She uses AI tools daily. Answer slot: which tools and what she uses them for, in her own words. If any of her work involved AI products or launches, she says so. If none did, she says so plainly. Then she turns it toward Compass with curiosity, for example how its buyers are reacting, without claiming product experience | It covers the JD's "AI experience a plus" line (F6), asked casually but scored. It is labeled inferred because F6's link to the requirement is a derivation |

### G. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection guidance: a time she told someone senior something they didn't want to hear. It needs a named stake, a moment she held her position, and a working relationship that survived. If no such time comes to mind, she says so plainly, gives the nearest thing her material does carry, or describes how she would handle it | This is the standard behavioral stem. It's included so she doesn't meet the style cold. VAL, generic, because Northwind's values could not be researched |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection guidance: a decision where a customer outcome won out over a number she or her team was measured on, with what it cost. If no such time comes to mind, she says so plainly, gives the nearest thing her material does carry, or describes how she would handle it | This stem tends to land with GTM interviewers, and a peer who owns sales metrics will listen for how she trades them off. VAL, generic, for the same reason as G1 |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" (F1) | C3, D2, B4 |
| "identify whitespace across land/adopt/expand/renew" (F2) | A3, C3 |
| "run independent analysis in SQL and Tableau" (F3) | A4, A3 |
| "partner-motion design experience required" (F4) | D1 (highest ROI), A2 |
| "strong cross-functional influence" (F5) | B1, B2 |
| "AI experience a plus" (F6) | F2, C1 |
| Sales-strategy fluency, Dan's function (F7, not a JD line) | E1, B1 |
| Company priorities and competitive threat (your research note) | C1, C2, C3, D3 |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization before sales strategy. What from that background shapes how you run sales strategy now?" | It's tied to his own career path, and it turns the interview into a conversation between peers |
| R2 | "What could a new person in this seat do in their first month that would genuinely help your team?" | The reciprocity question. It shows she is thinking about his load |
| R3 | "How are you two thinking about where sales strategy ends and emerging-products GTM begins, and how does the VP want us to resolve disagreements?" | It brings up the boundary between their roles openly, which reads as maturity. His answer tells her how contested that boundary is |
| R4 | "How is the team weighing Compass packaging between expansion and profitability?" | It draws on your research note, and it is in his native subject |
| R5 | "With a much larger vendor bundling, where do you see partners helping or hurting us?" | It ties the bundling threat to the required partner-motion line, and it invites him to share his view |
| R6 | "What would make you say, a year in, that this hire was a great call?" | It gives her the success criteria straight from a peer who will be judging them |

---

## Prohibited claims

These are claims the pack will not coach Priya to make. Each one is built from the fit snapshot above.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove or delivered the ~$400M ARR uplift | Inflated form of the quote behind A1 (the verb and the attribution) | "proposed a store-surface change credited with a ~$400M ARR uplift," at its own scope. The analysis notes that her material says she proposed the change, and that the credit for the number was given by others |
| Negotiated the carrier deals | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations." The analysis notes that her material says she built the model and the model was used in the negotiations, not that she ran them |
| Has designed partner motions or programs | Inflated form of F4 | F4's quote at its own scope. D1's answer slot stays within what F4 shows |
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quotes at their own scope: product strategy and ops, and a proposal |
| Has quota-setting or sales-ops experience, including presenting the volume targets as quotas | A negative stated in the coach's notes (F7) | "I haven't done classic sales ops or quota setting." No answer slot |
| Has built or launched AI products | Inflated form of F6 | "uses AI tools daily," at its own scope |

---

## Sources

**Provided documents:** your message, which held the JD highlights, the candidate summary, Dan's profile and your research note on Northwind's priorities and competitive threat. No dossier was provided.

**Searches sent:**
- `Northwind Data company values`: refused
- `Northwind Data interview process GTM strategy`: refused
- `Northwind Data Compass AI copilot launch`: refused
- `Dan Kovac Northwind Data sales strategy`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The search was refused. Published values would have given the VAL questions (G1, G2) their themes and replaced the generic stems |
| 2. Northwind Data interview process | unavailable | The search was refused. The session itself is established by your words (one 60-minute conversation with Dan). This search would have shown the rest of the loop and whether a values round exists |
| 3. Northwind Data strategy and recent news | unavailable | The search was refused. It was meant to check that your research note is current. C1 to C3, D3, R4 and R5 rest on the note as you gave it |
| 4. Dan Kovac at Northwind Data | unavailable | The search was refused. His talks or posts would have added likely questions and a sharper version of R1 |
| 5. Representative JD for the title | skipped | The JD highlights you supplied already set the fit snapshot and the JD-tagged questions |

**Loop:** your own words establish this session as one 60-minute conversation with a peer. No values-style round is documented, so the pack has no values cheat sheet.

---

## Upgrade menu

- **The full JD text** would show requirements the highlights may have left out, such as tools, methods and the mid-list items, and would let the coverage table check every one of them.
- **Priya's own CV or her own sentences** would replace the coach's notes with her words. That lets story maps carry more of the beats, and confirms that F7's "no classic sales-ops" is how she would put it herself.
- **Priya's answers to the slots in A1 and E2** (how the ~$400M was counted, and what part was hers) would upgrade A1, B3 and E2 from answer slots to story-mapped answers.
- **Her answer to the D1 and A2 slots** (whether any partner terms or structure were hers) would upgrade D1 and A2 and might change F4's gap type.
- **Search permission** would run the four declined targets: Northwind's values (for G1 and G2), the loop, a freshness check on the research note, and Dan's public footprint (for R1).
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) would cover Northwind's strategy brief, Dan's talks and writing, loop reports for this role family and recent changes in the org. This mainly sharpens C1 to C3.
- **The date of your research note** would confirm it is under about six months old, the freshness standard for strategy claims.
- **Recruiter guidance** on focus areas or any pre-declared deliverable would add a build section if one exists. That usually takes one email.
- **Prep time available** would add a prioritized prep schedule.
- **A `tuesday-dossier.md` from job-underwriter** would replace the inferred highest-ROI objection with one derived from evidence, and would add verified claims and binding interview strategies per gap. The pack is complete without one.
