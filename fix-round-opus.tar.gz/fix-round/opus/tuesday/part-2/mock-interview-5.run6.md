Quick update: I've read the prep playbook and I'm running a few targeted searches on Kelverton Rail and the panel before I build your pack.
I've saved your prep pack as `Kelverton-Rail_senior-partnerships-manager_interview_pack.md`. It's built from your background and the recruiter's email only. Every web search I tried was blocked by permissions, so none of it rests on research about Kelverton or the panel. I also haven't seen the market report.

What the pack contains:

- **A 4-hour prep plan.** It spends 90 minutes on the 15-minute talk before anything else.
- **A plan for the talk.** It opens by defining "operator partnerships", because the brief leaves it unclear whether that means working directly with operators or partners who serve them. You then pick two of three positions, each with a weakness you admit out loud. One of them is not to judge partnerships by partner count, which will sound credible from someone whose headline number is a count. There's a section on how partnerships make money, for Ross. It closes on what it means for operators, as the recruiter asked.
- **The question to rehearse most (C1):** "You've never carried a direct quota. Why should we trust you with a commercial number?" Ross is set up to push on commercials, so expect it in some form. The answer opens with the limit before he gets there: "I've never carried a direct quota, only influenced revenue." It then comes back to your roughly £4M of influenced revenue, and the pack walks through three follow-ups.
- **Protecting your numbers.** Every time you mention the £4M, keep "roughly" and "influenced" attached. Don't call it closed or sourced revenue. Don't describe the bus and light rail consulting as having worked for operators or on mainline rail. The pack lists the stretched versions of each claim to avoid.

Next steps:

- I can play Ross on C1, or Deepa on A1, as a live drill. Tell me which.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
- I can convert the pack to a Word document if that's easier to work from.

Two things would change the pack:

1. **Can you paste the job description, and your CV if it's handy?** It would settle whether this role carries a quota, which reshapes C1, and would replace my guessed requirements with Kelverton's own.
2. **Do you want me to run the research?** That needs search permission, for six searches on Kelverton and the panel. I can also do a deeper pass of up to six more searches and two page reads, which takes several more minutes. Separately, pasting the key passages of the market report would let me anchor your talk in their own figures.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

**Round:** Second round, 60 minutes, panel. 15-minute spoken POV (no slides), then Q&A.
**Panel:** Deepa, VP Partnerships (your future manager). Ross, Commercial Director ("Ross will push on commercials").
**Built from:** your message, including the recruiter's email you quoted. No JD, no CV, and the market report's contents were not shared with me. Every web search was refused by permissions, so nothing here comes from research (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question is asked: who asks it and in what style. **Types** describe *what* is being scored.
- **Type key:**
  - **VAL**: behaviour and values. Does a past decision show the values?
  - **EXP**: experience deep-dive. Does the claim survive scrutiny, and which part was yours?
  - **JD**: the role's requirements, including its gaps.
  - **CO**: company and market knowledge, at the company's level of thinking.
  - **CASE**: a live problem from the role, reasoned out loud.
- **Provenance labels:** `[grounded]` traces to your message or the recruiter's words. `[inferred]` is derived, with the derivation named. `[generic]` is a role-family pattern that says nothing specific about Kelverton.
- **Answer slots** are instructions for the interview, not questions for me. Each one has two honest branches. Pick the one that's true.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage (about 4 hours)

| Order | Block | Time | What to do |
|---|---|---|---|
| 1 | The POV build (Graded deliverable) | 90 min | Pick 2 theses. Write the 15-minute shape on one page. Say it aloud twice with a timer and aim for 12–13 minutes. Weave in one point from the market report, with one point where you disagree with it |
| 2 | C1, the highest-ROI rehearsal | 30 min | Rehearse the opening acknowledgment until it's boring. Then run the three follow-ups aloud |
| 3 | Defend your numbers: B1, B2, D2, B5 | 45 min | Answer each answer slot in your own words, out loud. Where you don't know how a figure was counted, practise saying so |
| 4 | Deepa's cases: A1, A4, A5 | 30 min | Run the structure aloud once each |
| 5 | Reverse questions | 15 min | Pick three: one for Deepa, one for Ross, and R1 |
| 6 | One live drill | 30 min | Ross on C1, or Deepa on A1 |

Everything else in this pack is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material shows a partner channel at a payments company. It does not show operator partnerships in rail, so the words stay at that scope: "At a payments company I ran the ISV channel and took it from 6 partners to 40." Answer slot: the 18-month brief makes a probe on how you plan likely. If you planned the ISV channel's growth yourself, say how, in your own words. If there was no such plan, or it wasn't yours, say so plainly and stay with what the channel did |
| F2 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure touches commercials but doesn't show whether you set or negotiated terms. Keep both qualifiers when you say it: "roughly £4M of influenced revenue." Answer slot: Ross's commercial push makes a probe on deal terms likely. If any commercial terms on those partnerships were yours to set, say which ones and how you decided. If none were, or there were no such terms, say so plainly and go back to the influenced figure |
| F3 | Accountability for a revenue number. This is a role-family pattern for senior partnerships roles; no source says this role carries a quota | "never carried a direct quota, only influenced revenue" — your message | none | [generic] | capability | You stated this gap, and no wording closes it. Words: "I've never carried a direct quota, only influenced revenue." Then describe how you would work to a number here, as a plan and never as a past. Whether this role carries a quota is unknown; R2 or the JD settles it |
| F4 | "land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Bus and light rail network planning, done as a consultant, sits next to operators buying rail scheduling software but is not the same thing. Keep the words at the quote's scope: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: the recruiter's operator close makes a probe on what you know of operators likely. If your consulting work put you alongside operators, say how and what you saw, in your own words. If your clients weren't operators, or you didn't work with them directly, say so plainly and stay with the planning work |
| F5 | Selling into rail operators. This is a role-family pattern for rail-tech partnerships roles | "Never sold into rail specifically" — your message | none | [generic] | capability | You stated this gap. Words: "I've never sold into rail specifically." Then say how you would get up to speed, as a plan and never as a past |
| F6 | Building and scaling a partner programme. This is a role-family pattern for the title | "9 years in partnerships" — your message and "took it from 6 partners to 40" — your message | medium | [generic] | none | No gap, but expect a probe on what the 40 produced. Lead with the count in your own terms: 6 partners to 40, at the payments company. Your message doesn't say over how long, so don't attach a timeframe unless you know it. B2 rehearses this |

---

## Graded deliverable: the 15-minute POV

**The brief, in the recruiter's words:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

### What you can build on

| Fact | Source | Provenance |
|---|---|---|
| 15 minutes, spoken, no slides, an 18-month horizon, closing on operators | Recruiter's email | [grounded] |
| Ross will push on commercials, so the POV needs a commercial spine | Recruiter's email | [grounded] |
| The panel has read the same market report you have | The report was circulated internally and attached for you | [grounded] |
| Your partnership base. F6: "took it from 6 partners to 40". F1: "running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Your message | [grounded] |
| Your transport base. F4: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your message | [grounded] |
| What "operator partnerships" means at Kelverton | Unknown: is it co-development with operators, partners serving operators, or both? | Not established |

### Open by defining the term, because it is genuinely ambiguous

In your first minute, say how you are reading "operator partnerships" and that you'll adjust if they mean something else. Use either the report's own definition or your stated assumption. This also earns you a reverse question (R1).

### Thesis options (pick two)

| # | Thesis | Mandatory concession | Provenance |
|---|---|---|---|
| T1 | **Partnerships that reduce the operator's integration burden.** Scheduling software sits among other operator systems. Partner with adjacent suppliers so that operators get joined-up outcomes instead of a set of separate integrations | Integrations are slow, and their priority should follow what operators actually ask for. You would check customer demand before committing a roadmap | [generic] The claim about operator systems is a role-family pattern. Replace it with whatever the report says about the operator tech stack |
| T2 | **A few deep operator partnerships beat many shallow ones.** Two or three co-design or reference partnerships with operators over 18 months | Concentration risk is real. Operator procurement rules may limit preferential arrangements, so you would verify those before proposing anything exclusive | [generic] |
| T3 | **Measure partnerships by operator outcomes and revenue, not by partner count.** This is the anti-pick, and it is credible coming from someone whose headline is a partner count (F6: "took it from 6 partners to 40"). Answer slot: if the move from 6 to 40 taught you something about count versus value, say what, in your own words. If it didn't, don't claim a lesson; state the principle as your view for Kelverton | Outcome metrics lag, so the first six months need leading indicators. Name the ones you would use | [generic] |

### Differentiation

- **Don't recite the market report.** Deepa and Ross have read it, so a summary of it scores as homework.
  - Use **one** point from it to show you're grounded.
  - Then give **one** place where you'd go further or disagree, with your reason.
  - Quote its figures exactly or not at all.
  - If the report describes changes in how operators are owned or buy software, that is your 18-month context. Build around it, and don't import facts the report doesn't contain.
- **Name what you would not do.** For example: chase partner count, or sign partnerships before there's a commercial model. Saying no signals judgment.

### Commercial spine (for Ross)

- Lay out two or three options for how a partnership makes money:
  - a referral fee
  - a resale margin
  - a revenue share on co-built capability
  - a no-fee co-sell with joint pipeline
- Pick one and name its main risk.
- Say what it depends on that you don't yet know, and ask what Kelverton does today.
- Never state Kelverton's current model as fact. `[generic]`

### Suggested 15-minute shape

1. **0:00–1:30 Frame.** Your definition of "operator partnerships", plus the one point from the report.
2. **1:30–3:30 Starting point.** What you'd need to learn in the first 90 days. Say it as hypotheses, not facts.
3. **3:30–9:30 Your two theses.** Each with its concession said out loud.
4. **9:30–11:30 The commercial spine.**
5. **11:30–12:30 The anti-pick.**
6. **12:30–14:30 The close: what it means for operators.** One sentence per thesis on what the operator gets. Use the report's evidence where it has some. Otherwise label each outcome clearly as your hypothesis. Answer slot, using F4's "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)": if that work showed you first-hand what operators struggle with, say what, in your own words. If it didn't, say you'd learn it from Kelverton's operators, and how.
7. **14:30–15:00** Stop, and invite the hardest question.

---

## Reading the interviewer

Built only from the recruiter's email. No public profile was researched (see Sources).

| Interviewer | What the recruiter said | Implications |
|---|---|---|
| Deepa | VP Partnerships, your future manager | She owns the strategy you're pitching, so expect "what would you actually do first" questions (A bank). Define "operator partnerships" in her terms, not yours |
| Ross | Commercial Director. "Ross will push on commercials" | Every number you say will be probed, so keep "roughly" and "influenced" attached to the £4M every time. Expect the sales-versus-partnerships seam (A5) and cost and payback questions (B3, B4, D3) |

No shared-career mirror is offered, because nothing is known about either person's path.

---

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Deepa, on the POV and "what would you do" | Highest. The hiring-manager prior plus a pre-declared POV | Clarify, then state the objective, structure and metrics. Think aloud, and challenge one premise respectfully |
| B. Data-Driven Prober | Ross, on numbers and deal economics | Highest. The recruiter said he will push on commercials | Know what you can and can't say about how each figure was counted. Say plainly when you don't know |
| C. Skeptic | Either, on rail and quota | High. The hiring-manager prior, and F3 and F5 are stated gaps | Rehearse the acknowledgment until it's boring. Bridge only from your quotes, then give a ramp plan |
| D. Pressure | Ross, interrupting the POV or time-boxing | Medium. A commercial push often arrives as interruption | Pause, restate, and hold through two follow-ups. Concede specifically |
| E. Conversational | The opener and the warm-up | Medium-low. Common at panel openings, and still scored | Have a 90-second arc ready |
| V. Values / Behavioural | Customer-versus-partner stories | Low. No values round is named, but the operator close invites it | Use story selection scaffolds with honest branches |
| Peer Evaluator | Not banked | Not plausible. Neither panellist is your peer | — |

The weights rest on the recruiter's description of this session plus relationship priors. No company process was researched.

---

## Question banks

### A. Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've said 18 months. What actually happens in your first 90 days?" | CASE | [grounded] | Say your framework aloud first: listen, pick, prove. **Listen:** which operator partnerships exist, what operators say, and what the report flags. **Pick:** one or two to deepen. **Prove:** one measurable early outcome. Name what you'd need from Deepa. This question needs no claim about your past | The follow-up the POV invites most directly. CASE because it scores how you sequence the work |
| A2 | "Which operators would you go to first, and why those?" | CASE | [generic] | Give criteria before names: depth of the existing relationship, willingness to co-design, reference value to other operators, and contract timing. Name operators only if the report does | Tests whether the POV turns into choices. `[generic]` because no Kelverton customer data is in hand |
| A3 | "When would you end a partnership?" | CASE | [generic] | Set exit criteria at the start, review on a fixed cadence, and exit without burning the relationship. If you have an instance from your own work, use it. If none comes to mind, say so and give the criteria | Senior partnership roles are judged on saying no. Pairs with the T3 anti-pick |
| A4 | "Twelve months in, how do I know operator partnerships are working?" | CASE | [generic] | Give two leading indicators for months 0–6 and two lagging ones: an operator outcome and revenue. Say explicitly that partner count is not the measure. Name the metric you'd trust least, and why | Deepa owns the scorecard you'd be judged on |
| A5 | "Where does partnerships stop and sales start here?" | CASE | [generic] | Propose principles for the seam rather than pretending to know it. For example: who owns the operator relationship, how a partner-sourced deal is credited, and how disputes are settled. Then ask how it works today | Ross's team sits on the other side of this seam. CASE because it's a live organisational problem |

### B. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that roughly £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Keep "roughly" and "influenced" every time. Answer slot, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you'd defend least (say this before Ross finds it), and which part was yours. If you don't know how it was counted, say so plainly. Never call it closed, sourced or quota revenue | F2's figure is the main target for a commercial prober. EXP because it tests attribution |
| B2 | "6 partners to 40. How many of the 40 actually moved revenue?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot, in your own words: what counted as a partner, what the count is sensitive to, the assumption you'd defend least, and which part of the growth was yours. If the split wasn't tracked, or you don't know it, say so plainly and stay with the count | F6's headline count. A partner count invites the "how many were real" probe |
| B3 | "What commercial model would you put on an operator partnership? Who pays whom?" | CASE | [generic] | Lay out two or three options from the POV's commercial spine. Give your criteria: incentive alignment, margin, and operator procurement. Pick one, name its risk, and ask what Kelverton does now. This question needs no claim about your past | Ross's native ground. CASE because it is reasoned live |
| B4 | "Build me the business case for one operator partnership. What numbers would I see?" | CASE | [generic] | **Costs:** people, integration and incentives. **Revenue:** new, retained and expansion. **Then:** timing and payback, and the assumption you'd defend least. Use placeholders and say they are placeholders; don't invent Kelverton figures | Tests whether you can talk P&L, not only relationships (F2, F3) |
| B5 | "On those ISV partnerships, which commercial terms were yours to set?" | EXP | [grounded] "running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: the recruiter's "push on commercials" makes this likely. If any terms were yours to set, say which and how you decided, in your own words. If none were, if they were set elsewhere, or if there were no such terms, say so plainly and go back to the channel you ran | F2's discovery gap, rehearsed before Ross finds it |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never carried a direct quota. Why should we trust you with a commercial number?" | JD | [grounded] "never carried a direct quota, only influenced revenue" and "roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** **Open with the limit, before you're pushed:** "I've never carried a direct quota, only influenced revenue." **Then hold only what your quotes carry:** roughly £4M of influenced revenue at the payments company. **Then a plan, said as a plan:** how you'd get the number defined with Ross, how you'd build a pipeline view, and a forecast cadence with sales. **Follow-up 1**, "So you've never been accountable for revenue?": return to the quote, influenced revenue, roughly £4M. Don't widen it and don't shrink it. **Follow-up 2**, "Influenced is soft, isn't it?": concede specifically, in your own words, that it is a different measure from a quota. Then offer B1's account of how it was counted, or say plainly that you don't know. **Follow-up 3**, "Would you take a quota here?": give your honest answer, and don't commit to a number you haven't seen | F3 is a stated gap and Ross is briefed to push on commercials, so this objection will come in some form. JD because it scores the role's commercial requirement |
| C2 | "You've never sold into rail. How long before operators take you seriously?" | JD | [grounded] "Never sold into rail specifically" and "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **Acknowledge:** "I've never sold into rail specifically." **Then the adjacent fact, at its scope:** five years of transport consulting on bus and light rail network planning. **Then a ramp plan, said as a plan:** shadow operator conversations, learn the report and the account history, and earn credibility with one operator first. Don't claim operator-side or mainline experience | F5 is a stated gap and the likeliest Skeptic line after C1 |
| C3 | "Bus and light rail planning isn't selling software to train operators. What actually transfers?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Concede the difference first. Then use F4's answer slot. If your consulting put you alongside operators, say how and what you saw, in your own words. If it didn't, or your clients weren't operators, say so plainly and name what the planning work gave you, in your own words. Don't recast it as operator-side work | F4's transferability limit is exactly where a skeptic presses |
| C4 | "Why leave payments for rail-tech, and why now?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" and "running the ISV channel" | Your arc is transport consulting, then running the ISV channel in payments. The reasons for coming here are yours to give: say the real one, briefly. If going back to transport is part of it, say why in your own words. Don't say anything negative about your current employer | A motivation-consistency check that every skeptic runs |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's already sold to train operating companies?" | JD | [grounded] "Never sold into rail specifically" and "took it from 6 partners to 40" | Pause, then concede the comparison in one line. Then give two things your quotes carry: the partner channel, 6 to 40, and the transport consulting. End with what you'd do first here, from A1. Stop by 60 seconds | F5 asked as a time-boxed comparison |
| D2 | "Everyone claims influenced revenue. How much of that £4M was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Hold, then concede. Keep "roughly". Answer slot: say which part was yours, in your own words. If it was shared, or you can't separate it, say so plainly. Hold that answer through two pushes, and don't trade it up to restore harmony | F2's figure under the "how much was you" stem |
| D3 | (interrupting the POV) "That sounds expensive. What does it cost us, and when does it pay back?" | CASE | [generic] | Don't defend with invented numbers. Name the cost lines and what payback depends on, and offer to size it with their data. Hold the thesis and concede the unknowns. Then go back to your POV structure | Interruptions test whether you lose the thread. Pairs with B4 |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" and "9 years in partnerships" and "running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc. Five years of transport consulting on bus and light rail planning, then nine years in partnerships. The last stretch was running the ISV channel at a payments company: 6 to 40 partners and roughly £4M of influenced revenue. End with why this role, in your own words | The biography opener. Casual, but scored for economy |
| E2 | "What did you make of the strategy team's market report?" | CO | [grounded] | Make one point you agree with and are using, and one you'd push on, with your reason. Quote it accurately. Don't imply insider knowledge beyond the report | They chose to send it to you. CO because it tests how you read their market |

### V. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time a partner wanted something that wasn't right for the end customer." | VAL | [generic] | Pick a time with a named stake, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | The recruiter's operator close makes a customer-over-partner story the one that lands |
| V2 | "Tell me about a time you told leadership a partnership wasn't working." | VAL | [generic] | Pick a time with a hard message delivered upward and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing, or how you would handle it | Pairs with A3. A future manager is scoring whether you'll bring bad news early |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 POV and the 18-month plan | Graded deliverable, A1, A2, A3, A4, D3 |
| F2 Commercials | B3, B4, B5, D3, the POV's commercial spine |
| F3 Revenue accountability | C1, D2, R2 |
| F4 What it means for operators | The POV close, C3, V1, A2 |
| F5 Selling into rail | C2, D1 |
| F6 Partner programme scale | B1, B2, E1 |
| Motivation (not a stated requirement) | C4 |

---

## Reverse questions

| # | For | Question | Why it lands |
|---|---|---|---|
| R1 | Deepa | "What does 'operator partnership' mean here today, and what would you want it to mean in 18 months?" | It settles the ambiguity your POV had to assume, and shows you didn't guess |
| R2 | Ross | "How are partnerships measured commercially today: sourced revenue, influenced revenue, or a quota?" | It speaks Ross's language, and it answers something you need to know (F3) |
| R3 | Deepa | "What would make you say, at six months, that this hire was right?" | It turns her scorecard into your plan |
| R4 | Ross | "Where do partnerships and your sales team step on each other today?" | It surfaces the seam (A5) honestly, before it surprises you |
| R5 | Both | "Which part of the market report do you think is most likely to be wrong?" | It shows you read it as an argument, not a briefing |
| R6 | Deepa | "What has the team tried with operators that didn't work?" | It shows you want the history before you prescribe |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried, hit or beat a revenue quota | A negative you stated (F3) | "I've never carried a direct quota, only influenced revenue." |
| Generated, closed or sourced £4M | Inflated form of F2 | F2's quote at its own scope: "roughly £4M of influenced revenue." The pack's observation: your material says influenced, not sourced or closed |
| Rail sales experience | A negative you stated (F5) | "I've never sold into rail specifically." |
| Operator-side or mainline rail experience | Inflated form of F4, on the relationship and scope axes | F4's quote at its own scope: transport consulting on bus and light rail network planning. The pack's observation: the material says consulting, on bus and light rail, and does not say who the clients were |
| Built the channel from scratch, or personally recruited the new partners | Inflated form of F6 | "took it from 6 partners to 40." The pack's observation: the material doesn't say which partners you recruited, or over what period |

---

## Sources

**Provided:**
- Your message, including the recruiter's email as you quoted it.
- The market report is referenced in your message, but its contents were not provided to this pack.

**Searches sent (all six refused by permissions):**
1. "Kelverton Rail values": refused
2. "Kelverton Rail interview process partnerships": refused
3. "Kelverton Rail scheduling software train operating companies news 2026": refused
4. "Deepa VP Partnerships Kelverton Rail": refused
5. "Ross Commercial Director Kelverton Rail": refused
6. "Senior Partnerships Manager rail software UK job description train operating companies": refused

**Fetches:** none.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Refused. Published values would have themed V1 and V2. No values round is named, so there would still be no cheat sheet |
| 2. `Kelverton Rail interview process` | unavailable | Refused. The recruiter's email already sets out this session, so this search could not have moved anything and should not have been sent |
| 3. `Kelverton Rail` strategy and recent news | unavailable | Refused. It would have moved A2, E2 and the POV theses from `[generic]` towards `[grounded]` |
| 4. `Deepa` and `Ross` at `Kelverton Rail` | unavailable | Two searches, both refused. They would have moved the interviewer read and the persona weights, and given a reverse question tied to each person's path |
| 5. A representative Senior Partnerships Manager JD | unavailable | Refused. It would have moved F3, F5 and F6 from `[generic]` to `[inferred]`, and retargeted the JD-tagged questions |

---

## Upgrade menu

- **JD text:** F3, F5 and F6 become `[grounded]` or drop out, the JD-tagged questions retarget, and it settles whether this role carries a quota.
- **The market report's key passages, pasted:** the POV theses and the operator close get grounded in Kelverton's own figures, and a grounding brief section gets added.
- **Search permission:** Kelverton's values, recent news, Deepa's and Ross's public professional footprint, and a representative JD. The empty Sources rows fill in.
- **A deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes. It adds a company strategy brief and recent org context for the POV.
- **Your CV:** more of your own sentences, so V1, V2 and C4 become story-mapped instead of scaffolds.
- **Your answers to the slots in B1, B2, B5 and F4:** how the £4M was counted, which terms were yours, and who your consulting clients were. Those rows become story-mapped.
- **A tuesday-dossier.md from job-underwriter:** an objection derived from evidence you confirmed, in place of the inferred one, plus an underwriter-built prohibited-claims guardrail.
