I'm reading the prep playbook and now doing a few quick searches on Atlas Freight, so the pack doesn't rest on guesses.
I've saved your prep pack as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-2-denied-be9756b2/atlas-freight_operations-manager_interview_pack.md`. It has 22 practice questions, each with guidance built only from what you told me.

**The company research didn't run.** Web search isn't allowed in this session, so all three searches were refused. Nothing in the pack about Atlas Freight comes from research. The practice questions cover the whole interview process with equal weight on each interviewer style, because you don't know who you're meeting.

**What to prepare first:**
- **The jump from 3 to 12 supervisors (A1)** is the objection most likely to come up, so it gets the deepest practice. Keep the 3 exact, say the limit before they do, and follow it with a 90-day plan.
- **Power BI** is a gap you named yourself. The pack has you say "I've never used Power BI" calmly and then give a learning plan. Don't try to talk around it.
- **Your 40% mis-pick cut** is your one number, so expect to be asked how it was counted and how much of it was you. Have that answer ready.
- **"5+ years operations leadership required"** will probably be checked as a number. Work out how many of your 7 years were actually in leadership roles.
- **Your green belt and the pick-path redesign** stay two separate facts. Link them only if the redesign really was a green belt project.

If you'd like a practice run, I can play the Skeptic on A1 and push back on your answers.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, I can convert it.

Who are you meeting: the hiring manager, HR, a panel, or someone else? And did the invite mention any presentation or exercise? The answer changes which questions get the most weight.
If you allow web search, should I run the Atlas Freight research (their values, interview process and recent news) and update the pack?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type: not known. This pack covers the full loop with flat persona weights. That makes it noticeably weaker than a pack built for one known round, and the upgrade menu says how to fix it.

## How to use this pack

- **Personas** describe how a question is asked (who is asking, in what style). **Types** describe what the question scores.
- Type tags:
  - **VAL**: behavioral and values. Does your past behavior show what they care about?
  - **EXP**: work-experience deep-dive. Do your claims hold up, and what was actually you?
  - **JD**: role-driven. Can you do the job as listed, gaps included?
  - **CO**: company knowledge. Have you done your homework on Atlas Freight?
  - **CASE**: a live problem from the role, answered on the spot.
- Provenance labels: `[grounded]` traces to what you told me or the JD. `[inferred]` is a derivation, and the row names it. `[generic]` is a common pattern for this kind of role, not a fact about Atlas Freight.
- An **answer slot** is a fork for the interview itself. If you did the thing, say how in your own words. If you didn't, or it wasn't yours, say so plainly. Both branches are honest answers.
- The guidance is scaffolding, not a script. Rehearse it out loud in your own words.

## Fit snapshot

Each requirement is quoted from the JD. Each piece of evidence is quoted exactly from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution ops as a senior shift manager. It does not mention terminal operations or more than one site, and the words should stay at that scope: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's "terminal operations across 4 sites" makes a probe on terminals and on more than one site likely. If any of your work was in a terminal or spanned more than one site, say what and how, in your own words. If not, say so plainly, then say how you would learn four sites, as a plan and never as a past |
| F2 | "drive ... cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material doesn't mention cost work, so this row is silent, not a gap you've admitted. Answer slot: if you've tracked or reduced a cost measure such as labor, overtime or cost per unit, say which one and what you did, in your own words. If you haven't, say so plainly and say what you would look at first |
| F3 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | Both quotes touch performance, but neither says anything about on-time measures. Don't let the bridge stretch them. Answer slot: if on-time or a service-level measure was part of the surge plan or of your shift's targets, say which measure and how you tracked it. If it wasn't, say so plainly and stay with the surge plan and the pick path as they are |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | You lead 3 supervisors today, and the role leads 12. Keep the number exact: "I'm currently a senior shift manager over 3 supervisors." What changes at 12 is a plan you describe, never something you claim to have done |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill level. It doesn't show that you've built reports. Answer slot: if you've built a report or tracker in Excel, describe one in your own words: what it tracked and who used it. If you haven't, say so plainly and say what you would build first |
| F6 | "build reporting in ... Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | You stated this gap yourself, so the words come straight from you: "I've never used Power BI." Then a learning plan, said as a plan. Never claim Power BI work, and don't shrink the gap |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops is not the same as seven years leading people, and your material doesn't say how many of those years were in leadership roles. It is a length-of-experience requirement, not a gate, but expect it to be checked literally. Answer slot: say how many of the 7 years were in a leadership role and which roles they were, in your own words. If the number is under five, say it plainly |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. Expect a probe, because nothing has been inspected behind the line. Lead with the certification in its own terms: "I'm green belt certified" |

## Persona table

None of these is weighted by a documented Atlas Freight loop. Every web search was refused, so no loop source exists, and the generic fallback (screen, then hiring manager, then panel) gives flat weights. The Skeptic bank gets one extra question because it holds the highest-ROI rehearsal, not because the Skeptic is more likely.

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quietly presses on the jump in scale: 3 to 12 supervisors, warehouse to terminal, one site to four | Flat: round unknown. This is the persona most likely to find F1, F4 and F7 | Rehearse A1 until it's boring. Keep your numbers exact, say the limit before you're asked, and follow it with a concrete ramp plan |
| Case / Strategist (B) | Live problems: an on-time drop, rising cost-per-shipment, a 90-day plan | Flat: round unknown. The JD names on-time and cost as the job's two outcomes | Clarify, set the objective, segment, give the approach, the metrics and the risks. Think aloud |
| Data-Driven Prober (C) | Takes the 40% apart and asks what reporting you've actually built | Flat: round unknown. The 40% is your only number, so it's a magnet | Know what you can and can't say about how the 40% was counted, and name your weakest assumption first |
| Pressure (D) | Time-boxes you, plays devil's advocate on the internal candidate and on Power BI | Flat: round unknown | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Conversational (E) | A friendly walk through your career and casual questions on green belt | Flat: round unknown. Casual questions are still scored | A rehearsed 90-second arc using only the facts you gave me |
| Values / Behavioral (G) | Asks for stories: accountability, an unpopular truth, a plan under volume | Flat: no values-style round was detected and no Atlas Freight values were found | Use STAR: "we" for the context, "I" for your part. Use only stories you actually have |
| Peer Evaluator (H) | Other site or function leads ask where the boundaries between teams sit | Flat: a panel round may include peers | Frame it as reciprocity: what you'd bring to them. Propose principles for the boundaries rather than pretending to know them |

## Question banks

**Highest-ROI prep in this pack: A1.** The jump from 3 supervisors to 12 is the most predictable objection to your background, and it will come up in some form.

### A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads 12 supervisors. How many do you lead today, and what changes at four times that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Deepest rehearsal. Open with the exact number, never rounded: "I'm currently a senior shift manager over 3 supervisors." Name the limit yourself before they do: 12 is four times your current span. Answer slot: if you've ever led people beyond those 3, say when and how, in your own words. If you haven't, say so plainly and stay with the 3. Then give the plan, clearly framed as a plan: how you'd spend your time across 12 supervisors you won't see every shift, and what you'd want reported daily. Follow-up 1 ("so you've never run this scale?"): hold on the 3, concede the scale plainly, and return to the plan. Follow-up 2 ("why would it work?"): give the plan's first step and how you'd know it's working. Never add supervisors, sites or years | F4 is the widest scale gap, and it sits in the job's headline line. JD because it scores the stated requirement directly |
| A2 | "The job is daily terminal operations across four sites. Which part of your background speaks to that?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say what you have, in those words: 7 years in warehouse and distribution ops, currently a senior shift manager. Answer slot: if any of your work was in a terminal or covered more than one site, say what and how. If not, say so plainly and stay with warehouse and distribution ops. Close with how you'd learn four sites: what you'd look at first and who you'd learn from | F1 is a transferability row on two axes, the kind of operation and the number of sites. JD because the line is the role's first responsibility |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "solid Excel" | Give the gap you stated, in your words: "I've never used Power BI." Add "My Excel is solid," and nothing beyond it. Answer slot: if you've started learning Power BI, say what you've done. If you haven't, say so plainly and give a concrete plan with a timeframe you'll commit to. Don't pick a fake weakness. This one is real, and naming it first is the credible move | F6 is the only gap you stated yourself, so it's the honest answer to a question that's coming. JD because it scores a listed requirement |
| A4 | "Why leave a senior shift manager role, and why Atlas Freight, why now?" | CO | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: your reasons are yours, and your material doesn't state them. Give why you're moving, why this role, and why now, each in a sentence. The company research couldn't run, so "why Atlas Freight" has to come from what you actually know about them. If you know little, say what in the JD drew you rather than inventing company facts | Every Skeptic asks about motivation, and with no research the "why here" part is thin. CO because it tests your homework |

### B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance dropped eight points at one of the four terminals last month. Diagnose it." | CASE | [generic] | Clarify first: how is on-time defined, inbound or outbound, which customers or lanes, and when did it start? Then segment by shift, by dock or door, by carrier or lane, and by volume against staffing. Name the two or three data cuts you'd pull first, a likely hypothesis, how you'd test it, and the risks of a quick fix. This question needs no claim about your past, so the guidance makes none | The JD names on-time performance as a core outcome (F3's requirement). It's asked live because your material carries no on-time story |
| B2 | "Cost-per-shipment is up across the network. Where do you look first, and how do you bring it down without hurting on-time?" | CASE | [generic] | Break cost into its parts first, and ask what's in Atlas Freight's figure. Common parts are labor and overtime, equipment, damage and claims, and freight moving between sites. Ask which sites are the outliers. Say what you'd change first and how you'd watch on-time while you do it. Make the trade-off explicit, because it's the point of the question | F2 has no evidence, so a structured live answer is your best shot at this requirement. CASE because it's the role's own problem |
| B3 | "Walk me through your first 90 days across four sites and 12 supervisors." | CASE | [generic] | Days 1–30: visit every site, meet all 12 supervisors, and learn the current numbers. Days 31–60: agree on a standard daily report and fix the one or two biggest problems. Days 61–90: set targets with the supervisors. State it as a plan. Don't present it as something you've done before | Covers F1 and F4 in forward-looking form. It's where the scale gap turns into a credible plan |

### C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-picks 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slots, each in your own words: how the 40% was counted, what it's sensitive to (for example, how long you measured), the assumption behind it you'd defend least, and which part was yours. If you don't know exactly how it was counted, say so plainly. That's a credible answer, and an invented method is not. Name your weakest assumption before they do | It's your only headline number, and the Prober will take it apart. EXP because it tests the claim itself |
| C2 | "What did redesigning the pick path actually involve, and how much of it was you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Story beats from your sentence: the pick path, redesigned, the mis-pick rate cut 40%. Tell them in your own words. Answer slot: say which steps were yours and which were the team's ("we" for the team, "I" for you). The JD's Lean/Six Sigma line makes a question about whether this was a green belt project likely. If it was, say how. If it wasn't, say so plainly and keep the certification and the pick path as two separate facts | C1 covers the number; this covers the work and who did it. It also covers F8. EXP primary |
| C3 | "This role builds reporting in Excel and Power BI. What reporting have you built?" | JD | [inferred] "solid Excel"; "never used Power BI" | For Power BI, the plain answer: "I've never used Power BI." Answer slot for Excel: if you've built a report or tracker, describe one in your own words: what it tracked and who used it. If you haven't, say so plainly and say what you'd build first. Never describe a formula, pivot or dashboard you didn't build | F5 and F6 together. The JD line is specific, so it will be checked specifically |

### D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path" | Pause, then three facts in your own words: 7 years in warehouse and distribution ops, ran the site's peak-season surge plan two years running, cut the mis-pick rate 40% by redesigning the pick path. Concede the real point: an internal candidate knows their terminals better on day one. Hold on what you've done through two follow-ups. Don't attack the internal candidate | A common stress question. It tests composure and whether your facts stay steady under a time limit |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold on the sentence. Answer slot: say exactly which part was yours, and give the team its share if it had one. If they push ("so it wasn't really you?"), restate your part calmly and concede only what's true. Don't puff up your share to end the pressure, and don't shrink it to seem humble | The attribution probe on your only number. Rehearsing it here makes C1 and C2 easier |
| D3 | "You've never used Power BI, and this job builds reporting in it. Why shouldn't that rule you out?" | JD | [grounded] "never used Power BI"; "solid Excel" | Concede first, plainly: "I've never used Power BI." Then hold on what you have, in your own words: solid Excel. Then the plan, with a timeframe you'll commit to. On follow-up 2, don't promise a speed of learning you can't stand behind | F6 is a stated gap, so a Pressure interviewer can use it legitimately. Rehearse the concession so it sounds calm |

### E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc using only these beats: 7 years in warehouse and distribution ops, now a senior shift manager over 3 supervisors, the pick-path redesign that cut mis-picks 40%, the site's peak-season surge plan two years running, and green belt certified. End with one sentence, in your own words, on why this role is the next step. Time it | The opener in almost every round, and casual questions are still scored |
| E2 | "Green belt. What have you used it on?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: if you've applied it to a project, name it and your part in your own words. If you haven't, say so plainly and say where you'd apply it first in this role. Link it to the pick path only if that was actually a green belt project | F8 is the JD's "plus", and the Conversational interviewer raises a plus casually. JD because it's a listed qualification |
| E3 | "How long have you been leading people, and in what roles?" | JD | [inferred] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: say how many of the 7 years were in leadership roles and which roles, in your own words. If it's under five, say the number plainly. Don't let "7 years in ops" stand in for 7 years of leadership. The current role is the anchor: senior shift manager over 3 supervisors | F7 is marked "required" and will likely be checked as a number. This rehearses giving it exactly |

### G: Values / Behavioral

No Atlas Freight values were found (search refused), so these are common behavioral themes for the role, not a values map.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, what you said, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle it | A standard behavioral stem. Leading 12 supervisors means carrying bad news both up and down |
| G2 | "Tell me about a time you had to hold a supervisor accountable for performance." | VAL | [grounded] | Selection scaffold, from your current role if you have the story: the issue, what you said, what changed, and where the relationship ended up. Use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle it | The JD's "lead a team of 12 supervisors" raises it (F4's requirement). VAL primary, JD secondary |
| G3 | "Your peak-season surge plan: what happened when the volume actually hit?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story beat from your sentence: you ran the site's surge plan, two years running. Answer slot: if something didn't go to plan, say what and what you did, in your own words. If it ran as planned, say so plainly and say what made it hold. If the second year changed from the first, that's worth a sentence, but only if it did | F3's strongest adjacent story. Behavioral in delivery, EXP in what it scores |

### H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Terminal ops sits next to sales and customer service. Where's the boundary, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than pretending to know their boundaries: agree on what "on time" means, share one set of numbers, and raise problems early. Say how you'd handle a disagreement: get the data, then talk to the person directly before escalating. This question needs no claim about your past | A panel may include peers who'll judge whether you add to their workload or reduce it |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: a time work you were part of involved another team. "We" for the context, "I" for your part, and name what the other team did. If no such time comes to mind, say so plainly and say how you'd handle it | A standard peer stem. It also previews D2's attribution test in a friendlier register |
| H3 | "What would you need from the other site leads in your first month?" | CASE | [generic] | Answer with reciprocity: what you'd ask for (their numbers, a walk-through of each site, what's broken), and what you'd offer back (a standard report, help with the busiest days). Keep it short | F1's four-site scope means you'd depend on peers early. CASE because it's forward-looking |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites (F1) | A2, B3, H3 |
| Drive cost-per-shipment down (F2) | B2 |
| Drive on-time performance (F3) | B1, G3 |
| Lead a team of 12 supervisors (F4) | A1, B3, G2 |
| Build reporting in Excel (F5) | C3 |
| Build reporting in Power BI (F6) | A3, C3, D3 |
| 5+ years operations leadership required (F7) | E3, A1 |
| Lean/Six Sigma a plus (F8) | E2, C2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is on-time performance measured here, and which of the four sites is furthest from target?" | It shows you think in the job's own outcome, and it tells you where your first 90 days would go |
| "What goes into cost-per-shipment, and who owns each part of it?" | It shows you know cost depends on how it's defined, and it tells you what you'd actually control |
| "What reporting exists today in Excel and Power BI, and who builds it?" | It shows you're facing the Power BI gap directly, and it tells you whether you'd build from scratch or inherit something |
| "How are the 12 supervisors split across the four sites, and how much time does this role spend on-site at each?" | It shows you're already planning around the scale, and it surfaces travel expectations before an offer |
| "What would make the first 90 days a clear success for you?" | It invites the interviewer to set the bar and gives you a target to answer against |
| "What are the next steps in the process, and who else will I meet?" | Practical, and the answer tells you which personas to prepare for in later rounds |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has owned daily operations of a terminal or more than one site | Inflated form of F1 | F1's quotes at their own scope: 7 years in warehouse and distribution ops, as a senior shift manager. Your material says warehouse and distribution, not terminals or multiple sites. A2's slot stays inside what you did |
| Has led a team larger than 3 supervisors | Inflated form of F4 | F4's quote, with the number exact: "currently a senior shift manager over 3 supervisors." A1's slot asks only whether you've led beyond those 3 |
| Has 7 years of operations leadership | Inflated form of F7 | F7's quote at its own scope: 7 years in warehouse and distribution ops. E3's slot asks how many of those years were in leadership |
| Improved on-time performance through the surge plan or the pick path | Inflated form of F3 | F3's quotes at their own scope: you ran the surge plan, and you cut the mis-pick rate. Neither says anything about on-time. F3's slot asks only whether on-time was a measure |
| Ran the pick-path redesign as a green belt / Six Sigma project | Inflated form joining F3's and F8's quotes | Two separate facts: the pick-path redesign, and the green belt certification. C2's and E2's slots let you join them only if it's true |
| Has used Power BI or built reporting in it | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." No slot |

## Sources

- Provided: the JD text you pasted, and your background, as written in your message.
- Searches sent (all three were refused because web search permission isn't granted in this session):
  - `"Atlas Freight" values`: refused
  - `"Atlas Freight" interview process operations manager`: refused
  - `"Atlas Freight" logistics news 2026`: refused
- Fetches: none.
- No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have supplied official values for G1–G3, and a values cheat sheet if a values round turned up |
| 2. `Atlas Freight interview process operations` | unavailable | The search was refused. It would have named the actual rounds, replacing the flat persona weights |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have given A4's "why here" and the CASE questions a real company angle |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was nothing to search for. That's why there's no interviewer read |
| 5. representative Operations Manager JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting and in what round → real persona weights instead of flat ones, with the top persona's bank expanded
- The interviewer's name → an interviewer read and a reverse question tied to their career path
- The recruiter's invite or prep email → coverage of any announced presentation or exercise, plus their stated focus areas
- Web search allowed in this session → Atlas Freight's values, loop and recent news. G1–G3 and A4 become grounded, and the CASE questions get a company angle
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for differentiator questions. It needs web search allowed
- Your answers to the slots (leadership years, any Excel reports you've built, how the 40% was counted, whether the pick path was a green belt project) → upgrades F3, F5 and F7 and questions A1, C1, C2, C3, E2 and E3
- The inspectable proof this field keeps (your green belt certificate, and a before/after mis-pick report or KPI scorecard) → F8 and C1 move from medium to high confidence
- How much prep time you have → a prioritized prep schedule
- A tuesday-dossier.md from job-underwriter → an evidence-checked objection and a prohibited-claims list you've confirmed, instead of ones inferred here
