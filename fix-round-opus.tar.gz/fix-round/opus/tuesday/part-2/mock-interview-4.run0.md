I've built your prep pack for a 45-minute conversation with the hiring manager, using your dossier for the role requirements and your verified evidence. It's saved as `quartzline_product-manager-platform-apis_interview_pack.md` in your working folder.

- **Most important to rehearse:** question A1. It's the objection your dossier named: "You have never held the PM title or owned a roadmap — why should we hire you into one…" The answer has four steps:
  1. Admit it plainly: "I haven't held a product manager title, and I haven't owned a product roadmap."
  2. Describe the 30+ integrations you led, in exactly the dossier's words.
  3. Mention the roadmap-input sessions, and say up front that they were input you fed to product.
  4. Give a plan for how you'd ramp up.
- **Where the pack keeps you honest:** your dossier's summary describes you more broadly than any of its three verified entries do, including "seven years of integration leadership". The pack gives you only the verified wording to say. It also adds three local limits, beyond your dossier's forbidden claims:
  - your integrations work isn't "shipped an API product";
  - the input sessions didn't "shape the roadmap";
  - the playbook is the one your team uses, not one used company-wide.
- **No company research:** all three searches on Quartzline were blocked by permissions. So the "why Quartzline" question and the four live-problem questions are general, with no Quartzline facts in them. Before the interview, read their partner API docs yourself and mention only what you actually read.
- **Timing:** today is Thursday, 12 November. If the interview is today rather than next week, rehearse A1, A2 and A3 plus the reverse questions R-1 and R-2. Everything else is backup.
- **What's in the pack:** a fit table against R1–R5, 21 questions across seven interviewer styles, a table showing which questions cover each requirement, six questions for you to ask them, and a list of what to add to sharpen it.

If you want to practise, I can play the skeptical interviewer on A1 and push back on your actual answers.
I can also add a section to your `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager (your words). Interviewer name not given.
**Built from:** your `tuesday-dossier.md` (job-underwriter, v1.1, generated 2026-08-14). No web research could run (see Sources), so everything about Quartzline itself is `[generic]`.

---

## How to use this pack

- **Personas** are *how* a question arrives (who's asking, in what style). **Types** are *what* is being scored.
- Type key:
  - **VAL**: behavioral / values. Does past behavior show the company's published values?
  - **EXP**: work-experience deep-dive. Do your claims survive scrutiny, and what was actually you?
  - **JD**: role-driven. Can you do the listed job, including its gaps?
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the actual role
- Provenance labels: `[grounded]` traces to your dossier or the requirements in it; `[inferred]` is this pack's derivation, with the derivation named; `[generic]` is a role-family pattern with no claim about Quartzline.
- **Guidance is scaffolding, not a script.** Say it in your own words. An **answer slot** is an instruction for the interview with two honest branches. It is not a question for me, and either branch is a good answer.
- The only sentences this pack gives you about your past are the three verified entries in your dossier, quoted as written, plus the plain acknowledgments your dossier's `prohibited_claims` support. Your dossier's decision summary describes you more broadly than any verified entry does, so the pack doesn't give you that summary's wording to say.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | low | [inferred] | transferability | The dossier's strategy here is bridge, and the limit stays in: this is adjacent work, never PM experience. Concede first, using the plain acknowledgment `prohibited_claims` supports: "I haven't held a product manager title." Then the adjacent case at its own scope: "I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live." V3 is medium confidence (confirmed, limited inspectable proof), so mention its limit before you're asked: the sessions fed client evidence *to* product. What product did with it is not in your material. Derivation: adjacency per the dossier's bridge framing, not a claim that the work was PM |
| F1b | "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier uncertain_or_weak_areas | none given | none | [grounded] | capability | The dossier's strategy here is acknowledge_gap, so there's no bridge. The words come from `prohibited_claims`: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F2 | "Shipped API or platform products" — dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | Your material says you integrated clients onto the vendor's APIs, not that you shipped the API product. Keep your side of the table exact: you worked on integrations, the vendor's product was the API. Answer slot: the "shipped API or platform products" line makes a probe on your side of the API likely. If any integration's scoping or requirements went back to the vendor's product team, say which and what part was yours, in your own words. If none did, or it wasn't yours, say so plainly and stay with the integrations you led |
| F3 | "Technical fluency: API docs, schemas" — dossier R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | Neither entry mentions docs or schemas, so it's unclear whether they reach this requirement. Answer slot: if your integration work had you reading or writing API docs or schemas, or the playbook covers them, say how in your own words. If not, say so plainly and describe what the integrations and the playbook did cover. Derivation: REST API integrations touch this requirement but don't show it |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | transferability | Your material shows clients (the integrations) and product (the input sessions). It doesn't mention engineering or sales. Answer slot: the JD names engineering and sales, so expect a probe on each. If you worked with either, say how and what part was yours, in your own words. If you didn't, say so plainly and stay with clients and product. V3 is medium confidence: say what record of the sessions you could show, or say plainly that there isn't one you can share |
| F5 | "Agile delivery experience" — dossier R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy here is clarify. No verified entry speaks to agile, so the words are an answer slot: "agile delivery experience" is the probe. If you worked that way, say how in your own words. If you never did, say so plainly. Either way, add: "what I'd want to confirm is how your squads define and run agile here" |

---

## Persona table

The loop here is established by your own words: one 45-minute conversation with the hiring manager. So the weights start from the hiring-manager prior (Case/Strategist and Skeptic dominant) and move on two things: the dossier's named objection, and the 30+ figure on V1.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | "Why you without the PM title?" asked quietly, then followed up | **High (5 questions).** Hiring managers derisk gaps, and the dossier names F1/F1b as the likeliest objection | Rehearse A1 until it's boring. Concede first, bridge only from V1/V3 at their own scope, then give a ramp plan |
| B. Case / Strategist | Live problems on their roadmap: discovery, adoption, squad trade-offs | **High (4).** The JD's four responsibilities are things an HM can hand you as live problems | Clarify, then objective, segmentation, approach, metrics, risks. Ask about decision authority and the adoption baseline before structuring |
| C. Data-Driven Prober | Pulls on "30+" and the playbook | **Mid (3).** V1 carries the only figure, and figures attract probes | Know how the 30+ was counted, in your own words, or say you don't. Name your weakest assumption first |
| D. Conversational | "Walk me through the journey", "why us" | **Mid (3).** HM conversations usually open this way, and the casual questions are still scored | A 90-second arc built only from V1 to V3. Treat casual questions as scored |
| E. Pressure | Time-boxed "why you over someone internal" | **Low (2).** Not the HM default, but the F1 gap invites it | Pause, restate, hold on V1 through two follow-ups, concede the title gap plainly |
| F. Peer Evaluator | How you'd work with sales and engineering | **Low (2).** R4 is a stated requirement and the squads are a JD responsibility | Propose working principles. Don't pretend to know their seams |
| G. Values / Behavioral | "Tell me about a time…" stems | **Low (2).** No values-style round detected, and no published values in hand | Selection scaffolds, each with its honest branch |

---

## Question banks

### A. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | **The highest-ROI rehearsal in this pack, and your dossier's underwriter named it.** 1) Concede, without apologizing: "That's right. I haven't held a product manager title, and I haven't owned a product roadmap." 2) The adjacent case, positioned as adjacent: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live." 3) V3, with its limit said before they find it: "I also ran quarterly roadmap-input sessions feeding client evidence to product." Present it as input you fed to product, and if you don't know what product did with it, say so. 4) The ramp, as a plan: what you'd learn first (the current roadmap, how the squad leads decide today, the adoption baseline) and when you'd expect to be useful. Never say "I've effectively been doing PM." Hold through two follow-ups by going back to the integrations, never by adding to them | F1 and F1b are the requirement's must-have gap. JD because it scores R1 directly. Both negatives in the Question have a source in `prohibited_claims`, so it's asked as the underwriter wrote it |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Name it before they do: "Owning the roadmap and setting priorities for the squads. I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan in the future tense: how you'd learn the squads' current priorities, who you'd ask, and the first call you'd expect to make with the squad leads' input. No bridge here, because the dossier found nothing to build one from | F1b is acknowledge_gap, so the honest answer is a named gap plus a plan. JD because it scores the role's core mandate |
| A3 | "Integrating a vendor's APIs isn't the same as building the API product. What have you shipped?" | JD, EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Accept the distinction, because it's accurate: "Fair. My work was on the integration side." Then V1 at its own scope: the 30+ integrations you led, scoping through go-live. Answer slot: if any of that work went back to the vendor's product team as a change to the API, say what it was and which part was yours, in your own words. If none did, or it wasn't yours, say so plainly and stay with the integrations you led | F2 is a must-have answered only by adjacent work, and an HM will test the difference. JD for R2, EXP because it checks what was yours |
| A4 | "Tell me about your experience with agile delivery." | JD | [grounded] | Clarify strategy, with no claim from me. Answer slot: if you worked in agile delivery, say how, in your own words. If you never did, say so plainly. Either way, close with: "What I'd want to confirm is how your squads define and run agile here." | F5 is R5, a preferred requirement whose dossier strategy is clarify. Asked as an open prompt so the guidance presupposes nothing |
| A5 | "Why move into product management, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your real reason, in your own words, in under a minute. Answer slot: if the input sessions are part of why you want this, say so and say what about them drew you. If they aren't, give your actual reason and leave them out. Don't frame the move as a title catching up with work you've already done | The Skeptic's "why now" probe, aimed at F1. JD because motivation consistency is part of how R1's gap gets priced |

### B. Case / Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit the partner API roadmap in week one. What do you need to know before you change anything?" | CASE, JD | [generic] | Clarify first: what the roadmap is meant to achieve this year, who decides what (you, the squad leads, leadership), how adoption is measured and its baseline, and which partner commitments are already promised. Then the approach: listen for 30 days, build a view of the evidence, and propose changes against stated objectives. The question asks about no past, so the answer makes no claim about one | Tests the "own the roadmap" responsibility as a live problem. Both dossier unknowns, decision authority and the adoption baseline, sit inside it, so asking them shows judgment |
| B2 | "How would you run discovery with our integration partners next quarter?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure: which partners (segment by size, stage, or how live they are), what you need to learn, the method (interviews, integration data, support tickets), how findings reach the roadmap, and what "done" looks like. You may say you led integrations through scoping, requirements, architecture, UAT and go-live, in those words. What you learned in them is yours to say or leave out. Don't supply a finding the material doesn't carry | The JD's "run discovery with integration partners" responsibility, delivered as a case. V1 is the nearest real material, and it is quoted so you can mention it without stretching it |
| B3 | "Partner API adoption is flat. How would you define adoption and diagnose it?" | CASE | [generic] | Clarify the definition first: partners signed, partners live, active usage, depth of endpoints used. Ask what the baseline is. Then segment (new vs established partners, by use case), form hypotheses (onboarding friction, docs, missing endpoints, commercial reasons), say what data would separate them, and name the metric you'd track weekly. Make no claim about past metrics | The JD's "define and track adoption metrics" responsibility. The dossier flags that no baseline is stated, so asking about one is part of the answer |
| B4 | "Two squad leads disagree on what ships next quarter. What do you do?" | CASE, JD | [generic] | First establish who decides: "Before anything else, I'd want to be clear whether that call is mine or theirs." Then: get each lead's case and evidence, tie both to partner impact and adoption goals, make or recommend the call within your authority, explain the reasoning to both, and record it. The question asks about no past, so the answer makes no claim about one | R4 on the engineering side, plus the dossier's open risk about squad authority. JD content, CASE delivery |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The number counts end-to-end client integrations, so keep it on that noun. Answer slots, each in your own words: how the 30+ was counted, what it is sensitive to, the assumption behind it you'd defend least, and which part was yours. Name the weakest assumption before they ask. If you don't know exactly how it was counted, say so plainly. That's an honest answer, not a failure | The only figure in your verified evidence, so it will be probed. EXP because it tests attribution |
| C2 | "Pick one of those integrations and take me through it, start to finish." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F2. The beats are the stages the quote names: scoping, requirements, architecture, UAT, go-live. Pick one integration you can tell in your own words. Answer slot: the JD's technical-fluency line makes a probe on the architecture stage likely. If architecture choices were yours, say which and how you decided. If they weren't, or there were none, say so plainly and describe what you led | Tests F2 and F3 in one story. EXP because it's a depth check on V1 |
| C3 | "Tell me about the integration playbook you wrote." | EXP, JD | [grounded] "Wrote the internal integration playbook her team uses" | What it covers and who uses it, in your own words and at its own scope: your team, not wider. Answer slot: the JD's "API docs, schemas" line makes a probe likely. If the playbook covers reading API docs or schemas, say how. If it doesn't, say so plainly and describe what it does cover. If you can bring it or show part of it, offer to | V2 is high confidence and inspectable, the strongest artifact you have, and it's the nearest material to F3. JD for R3 |

### D. Conversational (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from these three: the integrations you led, the playbook your team uses, the input sessions you ran for product. Then why this role, as in A5's slot. Add no years, titles or team sizes the quotes don't carry. If you want to mention your tenure, use the number you know is right | The likely opener, and it sets the frame A1 will test. EXP because it's your history, in your own words |
| D2 | "What do you know about Quartzline, and why here?" | CO | [generic] | The pack has no Quartzline facts (research couldn't run), so it gives you none. Before the interview, read their partner API docs or developer pages yourself. Say only what you actually read, and name one thing you'd want to understand better. Then why the role, as in A5 | CO coverage. `[generic]` because there's no company research behind it |
| D3 | "What did those roadmap-input sessions actually look like?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | In the quote's terms: quarterly, client evidence, fed to product. Medium confidence, so volunteer the limit: say what record of them you could show, or say plainly that there's nothing you can share. Answer slot: if you know what product did with the input, say so in your own words. If you don't, say so. Never describe the sessions as setting the roadmap | V3 is the entry the dossier expects to be probed, and it's asked casually here so the probe doesn't catch you off guard. EXP because it tests attribution |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal PM who already knows our APIs?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | Pause and restate. Hold on what's real: the 30+ integrations you led from scoping to go-live, said in those words, letting them draw the inference. Concede what's true: "I haven't held a product manager title." Make no claim to know their APIs. Hold through two follow-ups by returning to V1, and concede uncertainty specifically, never by folding | F1 under time pressure. JD because it scores R1 |
| E2 | "Those 30+ integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Keep the quote's verb: you led them. Answer slot: say which parts of the integrations were yours and which were the team's, in your own words. If you can't separate them for some stages, say so plainly. Hold "led" through two follow-ups, and never let it slide into "built" | The attribution probe on F2's only evidence. EXP because it's a scrutiny check |

### F. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sales has a partner deal that needs an API change we haven't planned. How do you handle it?" | CASE | [generic] | Clarify the deal value, the partner's actual need versus the ask, cost to the squads, and who owns the trade-off. Then: options (workaround, timeline, scoped change, say no), how you'd decide, and how you'd tell sales and the partner. Make no claim about past deals | The sales side of R4, as a live problem. CASE because it asks about no past |
| F2 | "Tell me about a time a client and engineering wanted different things, and you were in the middle." | JD, EXP | [grounded] | Selection scaffold: pick a time with a real disagreement, a stake for both sides, your specific part in resolving it, and how both relationships stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The engineering-and-customers side of R4 (F4), asked as an open prompt themed on the JD line. Nothing in the verified entries describes a disagreement, so this is a scaffold |

### G. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named audience, the message they didn't want, why you said it anyway, what happened, and what you'd do the same or differently. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common behavioral stem. `[generic]` because no Quartzline values are in hand |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the customer, the metric you didn't optimize for, the cost, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Customer-first framing suits a partner-facing platform role. `[generic]` for the same reason as G1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 — 3+ years product management experience (incl. roadmap sub-claim) | A1, A2, A5, E1, D1 |
| R2 — Shipped API or platform products | A3, C2, E2 |
| R3 — Technical fluency: API docs, schemas | C3, C2 |
| R4 — Stakeholder management across engineering, sales, customers | F1, F2, B4, D3 |
| R5 — Agile delivery experience | A4 |
| Responsibility — own the roadmap | B1 |
| Responsibility — run discovery with partners | B2 |
| Responsibility — specs and delivery with two squads | B4 |
| Responsibility — adoption metrics | B3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From your dossier. The JD claims roadmap authority but doesn't show it. The answer tells you whether this is a PM role or a coordinator role, and asking it reads as someone who has thought about operating in it |
| R-2 | "How is partner API adoption measured today, and what is the current baseline?" | From your dossier. Adoption is listed as yours to track, but no baseline is stated. If there isn't one, you're being hired to build it, which changes the first six months |
| R-3 | "Where do partner integrations tend to stall today: scoping, docs, testing, or go-live?" | Asked from the integration side you know, it starts a working conversation instead of an interrogation. The answer also shows where the roadmap's real pain is |
| R-4 | "How does partner and sales input reach the roadmap now, and what would you change about that?" | Tests R4's reality on their side, and links naturally to the kind of input work in your V3 entry without your having to claim more for it |
| R-5 | "What would make the first six months a success, in your eyes?" | Gives you their scoring sheet directly, and tells you whether expectations fit a ramp from adjacent experience |
| R-6 | "What's the hardest thing about this role that the job description doesn't say?" | Brings out the unwritten part of the job. Useful whatever the answer |

Never answer "I think you've covered everything."

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The plain acknowledgment that field supports: "I haven't held a product manager title." Then V1 at its own scope |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the acknowledge_gap area on roadmap ownership | "I haven't owned a product roadmap," plus a ramp plan. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad," plus how you'd learn the squads' current priorities |
| Shipped an API product | Inflated form of F2 | V1's quote at its own scope. The limit is the pack's observation, not words for you: your material says integrations of the vendor's APIs, not the API product. A3's slot stays inside the integrations |
| Shaped or set the roadmap through the input sessions | Inflated form of F1 (V3) | V3's quote at its own scope: you ran the sessions and fed client evidence to product. What product did with it is not in your material. D3's slot asks only what you know of it |
| Wrote a playbook used across the company | Inflated form of F3 (V2) | V2 at its own scope: the internal integration playbook your team uses |

---

## Sources

**Provided documents:** `tuesday-dossier.md` (envelope 1.1, generated by job-underwriter 2026-08-14, stage interviewing; decision conditional_go). Sections consumed: `role_profile` (requirements R1–R5, responsibilities, unknowns), `decision` (context only), and `handoff_to_mock_interview` (verified evidence V1–V3, weak areas and their allowed strategies, the A1 objection, risks and employer questions for R-1/R-2, `prohibited_claims`). The pasted envelope carried no `evidence_map`, `evidence_state` or `risk_register`, so the fit-snapshot grading for R2–R4 is this pack's own, while F1, F1b and F5 follow the dossier. The dossier is about three months old. Nothing in it was re-verified.

**Searches sent:**
- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline partner API platform news 2026" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search refused. Would have themed bank G on Quartzline's published values. No values cheat sheet either way, since no values-style round is detected |
| 2. `Quartzline interview process product manager` | unavailable | Search refused. Your own words already establish this session (one 45-minute HM conversation), so it would have moved at most the case format in bank B |
| 3. `Quartzline strategy` / recent news | unavailable | Search refused. Would have grounded D2 and the B cases in Quartzline's current priorities, which is why they're `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name given, so no query to form. No interviewer read |
| 5. representative PM, Platform APIs JD | skipped | The dossier's `role_profile` supplies the requirements |

---

## Upgrade menu

- **Allow web search, or paste Quartzline's values page or recent product news** → D2 and B1–B4 get company-specific grounding, and bank G is themed on their published values
- **A deeper research pass**, once search is allowed (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief: competitive frame, recent moves, and a "why Quartzline" answer worth giving
- **The hiring manager's name** → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path
- **Any recruiter notes about the conversation** → coverage of stated focus areas, and a build section if an exercise was announced
- **How much prep time you have** → a prioritized triage schedule at the top of the pack
- **Your answers to the slots in A3, A4, C1, C2, C3, D3 and E2**, told to me outside a drill → they enter the fit snapshot as quotes, and F2–F5 regenerate with your real specifics
- **The integration playbook itself** → C3 and F3 could quote what it covers on API docs and schemas, which may close F3's discovery gap
- **Any record of the roadmap-input sessions** (an agenda, a summary you sent product) → V3 could move from medium to high, and D3's caveat shrinks
- **Your own statement of how long you've done integration work** → a tenure line for D1. The dossier's summary mentions one, but no verified entry carries it, so the pack uses none
