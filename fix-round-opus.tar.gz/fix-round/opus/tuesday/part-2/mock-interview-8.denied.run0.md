Reading the prep-pack playbook's reference files is done. Next I'm checking the rules for the optional dossier, then I'll write your pack.
I've written your prep pack. It covers all three rounds on 21 November, with a separate set of questions for each and one shared assessment of how your background matches the job description.

**What to rehearse most (D1, Round 2):** "This role owns complaints across every branch and the contact centre. You've handled one branch's formal log and you've never worked in a contact centre. What makes you ready?" This is the objection your future manager is most likely to raise. The pack gives you a set order:
1. Name the limit yourself, before you're asked.
2. Fall back on what's true: three years as a branch supervisor, and the branch's formal complaints log you handled.
3. Give a concrete plan for learning the contact centre.

L1 in Round 3 is the same objection, asked under time pressure.

**Your two honest gaps** are the contact centre and presenting to senior leaders. For both, the pack uses your own words ("I haven't worked in a contact centre", "I haven't presented above regional level") and adds a plan. It doesn't try to make either gap look smaller.

**Where a sentence from you would help:** four job requirements depend on things your note doesn't say:
- what your spreadsheet tracks;
- whether it's built in Excel;
- whether the complaints on your log were regulated ones;
- any work with digital teams.

The pack leaves a fill-in spot on each of these. If the thing happened, you say how in your own words. If it didn't, you say so plainly. Either answer is fine.

**The 20-minute case** has its own section: a time plan, three positions you could take (each with a concession to say out loud), how to stand out from the obvious answer, and what not to do in front of two branch managers. It tells you to ask which regulatory deadline Ashgrove works to rather than quote one, because your material doesn't say which rules apply to them.

**The values round:** "Plain Words" is the only one of the four values your background speaks to directly, through training new tellers on the escalation script. For the other three, the pack gives you criteria for choosing a story and an honest fallback if none comes to mind. It doesn't invent stories for you.

I didn't search the web. Your pasted values, the recruiter's email and the strategy brief already covered everything research would have checked. The end of the pack lists what would improve it, mainly interviewer names once they're assigned and your answers to the fill-in spots above.

Files are in the working folder:
- /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-8-denied-26bdf276/Ashgrove-Credit-Union_member-experience-lead_interview_pack.md

If you like, I'll play your future manager on D1 and push back on your answers as you give them.
I can also save a `tuesday-dossier.md` that records the gaps this prep turned up, so you can carry them into later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of loop:** 21 November 2026, three rounds · **Pack built:** 12 November 2026

| Round | Length | Who | What it holds |
|---|---|---|---|
| 1 | 30 min | The recruiter | Screen |
| 2 | 45 min | Head of Member Services, your future manager | "mostly behavioural" |
| 3 | 60 min | Panel of two branch managers | A 20-minute complaint escalation case. Also the values round, scored against the four values |

No interviewer names have been assigned yet, so the pack works from their roles alone.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key.** **VAL**: past behaviour against Ashgrove's published values. **EXP**: what you actually did, under scrutiny. **JD**: whether you can do the listed job, gaps included. **CO**: company and strategy homework. **CASE**: a live problem, solved out loud.
- **Provenance labels.** `[grounded]` means it traces to something you gave me: your message, the JD, the values page, the recruiter's email or the strategy brief. `[inferred]` means the pack worked it out from that material, and the reasoning is shown. `[generic]` means a common pattern for this kind of role, with no claim about Ashgrove.
- **Answer slots.** An answer slot is a spot only you can fill. If the thing it names happened, say how in your own words. If it didn't happen, say so plainly. Both answers are good ones.
- **IDs.** F1 to F9 are fit-snapshot rows. Question IDs use one letter per persona per round: A to C for Round 1, D, E and G for Round 2, H, J, K and L for Round 3. F and I are skipped so they can't be confused with fit rows.
- **The guidance is scaffolding, not a script.** Say it your way.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material covers one branch's formal log, not a process spanning several sites, and your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on the stages likely. If any step between a complaint arriving and it closing was yours to decide, say which and how, in your own words. If none was, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you've stated yourself, and no wording closes it. Words: "I haven't worked in a contact centre." Then say how you would learn it, as a plan and never as something in your past. Nothing should be added to make the gap look smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The monthly cadence and the complaints subject match. What the spreadsheet tracks isn't in your material. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it tracks volumes or resolution times, say which and how each is counted, in your own words. If it doesn't, say what it does track |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message, and "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material covers training new tellers on a script, not coaching supervisors. It also shows you have done the supervisor's job yourself for three years. Words: "I trained new tellers on our escalation script," and "the last three years I've been a branch supervisor." Answer slot: the JD's "coach" makes a probe on cases outside the script likely. If you helped someone through an escalation the script didn't cover, say what you did, in your own words. If not, say so plainly and stay with the training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't mention this. Answer slot: if you have ever fed into a digital or self-service change, say what your part was, in your own words. If you haven't, say so plainly, then say what you would want complaint data to tell a digital team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Lead with the sentence as written, six years and the last three as a branch supervisor, and let the interviewer map it onto "customer operations" |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | "Formal" may mean regulated, but your material doesn't say. Answer slot: if the complaints on that log were regulated ones, say what that meant for how you handled them, in your own words. If they weren't, or you aren't sure, say so plainly and stay with the log you handled. Ashgrove's regulatory regime isn't in your material, so don't name rules or deadlines as theirs |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you've stated yourself. Words: "I haven't presented above regional level." Then give a plan as a plan, such as asking for a dry run before the first senior session. Don't imply any presenting history your sentence doesn't state |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material says spreadsheet, not Excel. Answer slot: if you built it in Excel, say so and which parts of Excel you used, in your own words. If it was another tool, name it |

The `capability` rows are F2 and F8, and both use your own words. The `discovery` rows are F3, F5, F7 and F9. Each of those has an answer slot that a sentence from you could upgrade.

---

## Grounding brief

These come only from the material you gave me. Nothing here is from outside research.

| Fact | Source | Provenance | Where it shows up in this loop |
|---|---|---|---|
| "move 40% of member service to digital channels by 2028" | Strategy brief, July 2026 | [grounded] | G2. It is also the reason the JD includes "self-service journeys" (F5) |
| "consolidate eight branches into five hubs over 2027" | Strategy brief, July 2026 | [grounded] | J1, L2. The Round 3 panel is two branch managers, and this plan affects their branches |
| "launch a small-business lending product in Q1 2027" | Strategy brief, July 2026 | [grounded] | J2, and a reverse question for Round 2 |
| "the main competitive pressure is app-only banks" | Strategy brief, July 2026 | [grounded] | G2. It frames why member experience is the battleground |
| Vocabulary: "member", "branches", "contact centre", "hubs", "self-service journeys", "digital channels" | JD, values page, strategy brief | [grounded] | Say "member", never "customer". That is the word on every page they wrote |
| The brief arrived as four lines in your note, not the full document | Your message | [grounded] | Anything beyond those four lines would be a guess, so the pack makes none |

---

## Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own the complaints process end to end across branches | F1 | D1, E1, Round 3 case build |
| ...and the contact centre | F2 | B1, D1, L1 |
| Report monthly on volumes and resolution times | F3 | C1, C2, G1 |
| Coach branch supervisors on escalations | F4 | D4, K1, K2 |
| Work with digital teams on self-service journeys | F5 | G2, A4 is adjacent |
| 4+ years financial-services customer operations | F6 | A1 |
| Experience handling regulated complaints | F7 | B2, Round 3 case build |
| Confident presenting to senior leaders | F8 | D2, D3, E3 |
| Comfortable with Excel reporting | F9 | A4, C1 |
| Values: Members First, Always · Plain Words · Neighbours, Not Numbers · Own the Fix | — | H1 to H4, values cheat sheet, E2, L2 |

---

# Round 1: Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, "why us", logistics | High. A recruiter screen leans on rapport and motivation, and the register is casual even though it is scored | A 90-second background arc built only from your four sentences. Treat every casual question about the JD as scored |
| Skeptic, light | Knockout checks against the JD's requirements | Medium. Recruiters check the listed requirements before passing you on, and F2, F7 and F8 are the obvious ones | Short, plain answers on the gaps. Don't apologise at length |
| Data-Driven Prober | "How many?" and "what's in it?" | Low. Possible on the spreadsheet | Know what you can and can't say about your own numbers |

### Question bank

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses." | Four beats in this order, each as you wrote it: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log. You trained new tellers on your escalation script. You built the monthly complaints spreadsheet your regional manager uses. Close with why this role. Answer slot: give your own reason for moving toward complaints work, in your own words. If there's no single reason, say what about the work keeps you interested | F6 settles the years requirement, and F1, F3 and F4 are the complaints thread. Ninety seconds that hits all four sets up every later round. EXP because the recruiter is checking that your story matches your application |
| A2 | "Why Ashgrove?" | CO | [grounded] | Name one value in its own words, for example "we decide from the member's side of the counter". Name one strategy fact, such as the move to digital or the hub plan, and say why it interests you. Answer slot: if member ownership or the credit-union model matters to you personally, say why in your own words. If it doesn't specifically, say what draws you to this role instead | A near-certain recruiter question. Using their own words shows you read what they published. CO because it scores homework |
| A3 | "Why step out of a branch role now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start from the fact: three years as a branch supervisor. Answer slot: give your reason for wanting a wider remit now, in your own words. Keep it pointed toward this role rather than away from your current one | A motivation-consistency check. Round 2 will test the same answer harder |
| A4 | "How comfortable are you in Excel?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the sentence. Answer slot: if you built it in Excel, say so and say what you used to build it, in your own words. If it was another tool, name it and say how you'd get up to speed in Excel. Don't list features you haven't used | F9 is a listed requirement, often asked casually. JD because it scores the stated requirement |

**Skeptic, light**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre too. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" | One sentence: "I haven't worked in a contact centre." Then one sentence of plan, as a plan: what you'd want to learn first and from whom. Stop there. A short honest answer reads as confident, and a long one reads as worried | F2 is a stated gap the recruiter can see in the JD. Rehearsed here so it's calm by Round 2 |
| B2 | "Have you handled regulated complaints?" | JD | [inferred] "I handled the branch's formal complaints log" | Start with the sentence. Answer slot: if those complaints were regulated, say so and say what that changed about how you handled them, in your own words. If they weren't, or you aren't sure, say so plainly and describe the log you handled | F7 is a listed requirement, and the most likely knockout question. Your answer decides how hard Round 2 presses on it |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What goes into that monthly complaints spreadsheet?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what it tracks and how each figure is counted, in your own words. If it covers volumes or resolution times, say so, because the JD names both. Name the figure you'd defend least and why. Describe it at the scope it really has, which is the spreadsheet you built and that your regional manager uses | F3 and F9 both rest on this sentence, so expect it to be probed in every round. Rehearse it once and it's ready for all three |
| C2 | "Roughly how many formal complaints does your branch log a month?" | EXP | [grounded] "I handled the branch's formal complaints log" | Answer slot: give a number only if you know it and how it's counted. If you'd be estimating, say so, and say "I'd want to check" rather than guessing. An honest range beats a confident wrong figure | Scale questions are routine in screens. EXP because it tests whether you know your own data |

### Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "For the 20-minute case, will I get the scenario in advance or in the room, and is there prep time?" | You get the format of a graded exercise, and asking about logistics reads as preparation |
| R1.2 | "When the panel scores against the four values, are they looking for past examples or for how I'd handle the case?" | It tells you whether Round 3 rewards stories or reasoning |
| R1.3 | "Will I know the names of the Head of Member Services and the two branch managers before the 21st?" | Names are the biggest single upgrade to this pack, and recruiters can often share them |
| R1.4 | "Is there anything public about Ashgrove's complaints process I should read before the case?" | The case can then rest on their process, not a generic one |
| R1.5 | "Does the role manage complaints staff directly, or work through branch and contact-centre leads?" | It shapes how you pitch "Own the Fix" and coaching supervisors in Rounds 2 and 3 |

---

# Round 2: Head of Member Services, 45 minutes, "mostly behavioural"

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scope jump and the stated gaps | High. A future manager is paying to reduce the risk of a gap, and F1, F2 and F8 are where this role is bigger than your record | Rehearse D1 until it's boring. Bridge only from your four sentences, say the limit before you're asked, and give a concrete plan |
| Values / Behavioral | "Tell me about a time..." | High. The recruiter called this round "mostly behavioural", which pushes it above the usual hiring-manager pattern | Use STAR. "We" for context, "I" for your part. Where no story comes, say so and give your nearest real material |
| Case / Strategist | A live problem from their own work | Medium. Hiring managers usually set one, but "mostly behavioural" pushes it down | Clarify, set the objective, split the problem, choose an approach, name the measures and the risks. Think aloud |

### Question bank

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across every branch and the contact centre. You've handled one branch's formal log and you've never worked in a contact centre. What makes you ready?" | JD | [grounded] "I handled the branch's formal complaints log" "Never worked in a contact centre" "6 years in retail banking, the last 3 as a branch supervisor." | **The highest-ROI prep in this pack.** Name the limit first: "I haven't worked in a contact centre, and my complaints work has been at one branch." Then hold on what's true: "I handled the branch's formal complaints log, and for the last three years I've been a branch supervisor." Then give a plan, as a plan: the first things you'd do to learn the contact centre, and who you'd learn from. Follow-up 1, "How would you know what good looks like on the phones?": stay in the plan, and don't borrow experience you don't have. Follow-up 2, "One branch is a long way from 900 staff": agree that the scale is bigger, then answer slot: say what from handling that log you'd carry across, in your own words. If you can't name something specific, say so and return to the plan. Never add to your record to win the exchange | F1 and F2 together are the single most predictable objection to you for this role. It will come in some form, most likely from your future manager. JD because it scores the role's headline requirement against your record |
| D2 | "Presenting to senior leaders is part of this job. You've told us you haven't presented above regional level. How do you get there?" | JD | [grounded] "I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Hold-then-concede. Concede first and plainly: "I haven't presented above regional level." Then give what's true and nearby: you built the monthly complaints spreadsheet your regional manager uses. Then a plan, as a plan: ask for a dry run with them before the first senior session, and keep it to Plain Words. Hold there through two follow-ups. Don't claim a presenting record your sentence doesn't state | F8 is a stated gap, and the person who'll send you into those rooms is the one assessing it. JD because "confident presenting" is listed |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | Pick one real weakness, F2 or F8, not a disguised strength. Say it in your own words, then the first concrete step you'd take. Choosing one and owning it scores better than listing both | A standard Skeptic stem, and you have two honest answers ready. JD because it maps to listed requirements |
| D4 | "You've trained tellers. This role coaches supervisors, people at your own level. What changes?" | JD | [grounded] "trained new tellers on our escalation script" "6 years in retail banking, the last 3 as a branch supervisor." | Two true facts: you trained new tellers on your escalation script, and you've been a branch supervisor for three years, so you know the supervisor's seat. Answer slot: if you've ever helped someone through an escalation the script didn't cover, say what you did, in your own words. If you haven't, say so and say how coaching a peer would differ from training a new starter | F4 is a transferability gap. Your own supervisor years are the honest bridge, and the slot keeps it from widening. JD because coaching supervisors is a listed duty |

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a complaint that went badly before it went well." | EXP | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Pick one complaint from that log where something went wrong first. It needs what the member wanted, what went wrong, what you personally did, and how it ended. If no such case comes to mind, say so plainly, then describe how a complaint moved through your log, or how you'd handle one | Complaints are the job (F1), so a complaint story is almost guaranteed. EXP because a manager will check that your part was yours |
| E2 | "Tell me about a problem you spotted and kept hold of until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Themed on "Own the Fix". Answer slot: if the spreadsheet began because something was missing or broken, say what it was and how you kept at it, in your own words. If it didn't, say so and pick a different time you saw a problem through. If no such time comes to mind, say so plainly and say how you'd handle one | A manager may preview the values the panel scores. F3's spreadsheet is your nearest material, and the slot stops the pack from inventing its origin |
| E3 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [grounded] | Selection scaffold. It needs a named person above you, the unwelcome fact, what you said and how, and whether it landed. If no such time comes to mind, say so plainly and say how you'd do it with a monthly complaints report that shows bad news | Senior reporting is in the JD (F3, F8), and bad-news reporting is the hard part. A persona stem, VAL because it tests candour |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Average resolution times have crept up for three months. Where do you start?" | CASE | [generic] | Check how the number is counted first: has the definition or the complaint mix changed? Then split it by channel, by branch and by complaint type. Find which stage is slow, fix that stage, and report it in plain words. Say your weakest assumption out loud, for example "I'm assuming the clock starts the same way in branches and the contact centre." The question asks about no past, so the guidance makes no claim about yours | A live problem drawn from the JD's reporting line (F3's requirement). `[generic]` because it's a pattern, not Ashgrove data |
| G2 | "We plan to move 40% of member service to digital by 2028, with app-only banks as the main pressure. What does that do to complaints?" | CO | [grounded] | Clarify: which services move first? Then reason out loud. The kinds of complaints shift toward the digital journeys. Complaint data can show digital teams where members get stuck, which is the JD's "self-service journeys". Members still need a clear human route when the app fails. Close on Members First: judge each journey from the member's side of the counter. The forecasts are reasoning, not Ashgrove fact, so say them as "I'd expect" | The one CO question grounded in their published strategy, and the reason F5 exists. CO first, CASE in delivery |

### Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would you need to see from this role at six months to know it was working?" | Your future manager defines success in their own words, and you learn what's really being bought |
| R2.2 | "Where does the complaints process hurt most today, in branches, on the phones, or in the handoff between them?" | It turns your F2 gap into a curious, forward question, and the answer is real onboarding information |
| R2.3 | "Who reads the monthly complaints report, and what do they do with it?" | It shows you think about reporting as a tool for decisions, which is the JD's reporting line |
| R2.4 | "If I'm presenting to senior leaders, would there be room for a dry run with you first?" | It names your F8 gap as a plan you've already made, and tests how much support you'd get |
| R2.5 | "With small-business lending launching in Q1 2027, will business members' complaints come through the same process?" | It uses their strategy brief, and a new product is where a new process breaks first |

---

# Round 3: Panel of two branch managers, 60 minutes, including a 20-minute case. This is the values round

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One or more questions per value, scored | Dominant. The recruiter said the panel "score against the four values" | Map a story to each value where your sentences carry one, and use a scaffold with an honest exit where they don't. See the cheat sheet |
| Case / Strategist | The 20-minute escalation case, plus live strategy questions | High. The case is announced and graded | Use the case build below |
| Peer Evaluator | "What will you need from my supervisors?" | Medium. You'd coach their supervisors (F4), so they're weighing what you add to their load | Frame it as reciprocity: what you bring their branches, not only what you need |
| Pressure | Devil's advocate on consolidation, or "why you" | Low. Panels sometimes have one person push. Consolidation touches their branches | Pause, restate, and hold through two follow-ups. Concede only what's real |

### Graded deliverable: the 20-minute complaint escalation case

**What the case is graded on, from the recruiter's words:** it is a case "on a complaint escalation", run by a panel that "score against the four values". Expect the values to be the scoring sheet for the case as well.

**Facts to build on**

- About Ashgrove: member-owned with about 900 staff (JD). Complaints span branches and the contact centre (JD). The four values (values page). Consolidation into hubs and the move to digital (strategy brief).
- About you, at their own scope: F1, "I handled the branch's formal complaints log". F4, "trained new tellers on our escalation script". F7, the same log sentence. Whether those complaints were regulated is F7's answer slot, so don't assert it.

**A shape for 20 minutes**

1. **Clarify, about 2 minutes.** Is this a regulated complaint, and what deadline applies at Ashgrove? Is the member in a vulnerable situation? What has already been promised? Which channel did it come through? Has it happened before? Asking about the regulatory deadline instead of quoting one is deliberate, because Ashgrove's regime isn't in your material.
2. **Contain, about 3 minutes.** What the member hears today, and from whom. One named owner, which is Own the Fix.
3. **Resolve, about 8 minutes.** The facts you'd gather, the decision and who is allowed to make it, and the response written in Plain Words. Offer to say the first two sentences of the member letter aloud.
4. **Root cause, about 4 minutes.** Is it a one-off or a pattern? Where would it show in the monthly report, and does a supervisor need coaching or does the process need fixing?
5. **Close, about 2 minutes.** The member's outcome, then the one change that stops it happening again. The recruiter named no required close, so lead with the member, which is Members First.

**Three theses you could defend, each with its concession**

| Thesis | Concession you say out loud |
|---|---|
| Fix it for the member first, then fix the process, with one named owner holding it until it's closed | Speed can't skip the regulated steps or the record. You'd still log it properly even when the fix is fast |
| An escalation is information, not just a failure: it goes into the monthly report and the root-cause review | Not every escalation is systemic. A one-off doesn't justify redesigning the process |
| More escalations should be resolvable at the branch, through coaching supervisors on judgement rather than only following a script | Some decisions in a regulated complaint have to go up. Giving supervisors more power needs clear limits |

**How to stand out from the obvious answer.** The obvious answer is "apologise, escalate, resolve, follow up", and every candidate gives it. Give that, then add three things: name the owner out loud, speak the member's letter in Plain Words, and close the loop to root cause and the monthly report. With two branch managers in the room, Neighbours, Not Numbers fits naturally: ask what the branch knows about this member that the file doesn't.

**The anti-pick.** Don't offer a goodwill payment or a policy exception just to make the escalation go away before the facts are in. Don't blame branch staff in front of two branch managers. Don't promise an outcome in the first minute.

### Question bank

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | **Members First, Always.** Selection scaffold. It needs a moment where the easy option for the branch and the right option for the member split, what you chose, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing from your complaints log work, or how you'd handle it | The panel scores each value, and this one is named first on their page. Themed in their own words |
| H2 | "Tell me about a time you had to explain something so it landed the first time." | VAL | [grounded] "trained new tellers on our escalation script" | **Plain Words.** Story-mapped on F4: you trained new tellers, and the subject was your escalation script. Tell it in your own words. Answer slot: the value's line, "if a member needs it explained twice, we wrote it wrong", makes a follow-up likely. If you ever changed how you explained the script after someone didn't get it, say what you changed. If you didn't, say so plainly and stay with the training | The one value one of your sentences carries directly. The slot keeps the story at what you said |
| H3 | "Tell me about a time a member's local situation changed how you handled something." | VAL | [grounded] | **Neighbours, Not Numbers.** Selection scaffold. It needs a member or branch circumstance, a standard approach that didn't fit, what you did, and how it ended. If no such time comes to mind, say so plainly, then say how you'd keep that local knowledge alive when branches become hubs | Two branch managers are scoring a value about branches belonging to their towns |
| H4 | "Tell me about a problem you found that wasn't strictly yours, and how you saw it through." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | **Own the Fix.** Answer slot: if the spreadsheet started because you noticed something missing, say what and how you kept at it, in your own words. If it didn't, say so and pick another time. If none comes to mind, say so plainly and say how you'd hold a fix that crosses branch and contact-centre lines | "Own the Fix" is the value closest to the job description. F3 is the nearest material, and the slot stops the pack from supplying its origin |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Two branches become one hub next year. What happens to complaints, and what do you do?" | CO | [grounded] | Clarify: which branches, when, and what changes for members. Reason out loud and label it as expectation: travel and access complaints, and members losing familiar faces. Then act: tell members in plain words, check whether complaint-handling ownership changes, watch the affected branches' figures, and give the hub supervisors time on escalations. Show Neighbours, Not Numbers without criticising the plan | Taken from their published plan, and the people asking run branches. CO first, CASE in delivery |
| J2 | "Small-business lending launches in Q1 2027. How should complaints be ready?" | CO | [grounded] | Clarify: which channel serves business members? Then: brief staff before launch, add the new product as its own category in the monthly report, watch the first months closely, and feed what you find back to the product team. Say forecasts as "I'd expect" | The strategy brief's newest move. A new product is a predictable source of complaints |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "My supervisors are stretched. What would you need from them, and what would they get back?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Reciprocity. Start from the fact that you've been a branch supervisor for three years. Then what they'd get: fewer escalations bouncing back to them, clearer limits on what they can decide themselves, and their branch's complaint picture each month. What you'd need is small and specific. Answer slot: if you've seen what makes supervisors' complaint work harder, say what, in your own words | Coaching their supervisors (F4) adds to these managers' load, and that is what they're judging |
| K2 | "One of my supervisors resolves a complaint their own way, off-script, and the member's happy. What do you do?" | CASE | [generic] | Thank them. Check that the record and any regulated steps were done. Ask what the script was missing. If the improvised fix was better, change the script, so the lesson is Own the Fix and not a telling-off. Say what you'd do if a required step was skipped. A live problem, so no claim about your past | It splits the seam between control and branch judgement. `[generic]` because it's a pattern |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you over someone who's run a contact centre?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "6 years in retail banking, the last 3 as a branch supervisor." | Pause. Concede once: "I haven't worked in a contact centre." Hold on what's true: six years in retail banking, the last three as a branch supervisor, and you handled the branch's formal complaints log. Close on the branch side of the job, which half of this role covers. Hold through two follow-ups, and don't attack the hypothetical rival | D1 again, time-boxed. Rehearsing it a second time under pressure protects the highest-ROI answer |
| L2 | "We're closing branches and you're talking about digital journeys. Isn't that Numbers over Neighbours?" | VAL | [grounded] | Don't defend or attack the strategy. Restate the tension fairly. Then say how you'd keep the value inside the change: plain-words communication, a human route, and watching affected towns' complaints. Concede that the tension is real. Hold the position that the value is honoured in how the change is done | It sets their values against their own plan, in front of people whose branches it affects. VAL because composure on this is scored as values |

### Values cheat sheet

| Value, official name | Working meaning | Your story |
|---|---|---|
| Members First, Always | Choose what's right for the member, even when another option is easier for us | Selection scaffold, H1. If none comes, say so plainly and give the nearest thing from F1, "I handled the branch's formal complaints log", or how you'd handle it |
| Plain Words | If it needed explaining twice, the explanation was the problem | F4: "trained new tellers on our escalation script". Story-mapped in H2, with its answer slot |
| Neighbours, Not Numbers | Each branch carries local knowledge that a spreadsheet doesn't | Selection scaffold, H3. If none comes, say so plainly and say how you'd keep local knowledge alive through the hub moves |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | Answer slot on F3, "I built the monthly complaints spreadsheet our regional manager uses.", in H4. Otherwise a scaffold, ending in its honest exit |

### Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does a good escalation look like from your side of a branch?" | It invites them to define success, and their answer gives you material for the rest of the session |
| R3.2 | "As your branches move toward hubs, what would you want the complaints process to protect?" | It respects that the change affects them, and connects it to Neighbours, Not Numbers |
| R3.3 | "What could someone in this role do in the first month that would actually help your supervisors?" | The reciprocity question. Branch managers are weighing what you'd add to their load |
| R3.4 | "Where do complaints get stuck between your branch and the contact centre?" | It turns your F2 gap into something you want to learn about |
| R3.5 | "Which value do you think is hardest to keep under pressure, and why?" | A values round ending on their own values reads as genuine interest, and the answer tells you the culture |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation: your material covers one branch's log, not a process across sites. D1's answer slot stays inside that log |
| Built regional complaints reporting | Inflated form of F3 | F3's quote exactly: "I built the monthly complaints spreadsheet our regional manager uses." The pack's observation: your material says who uses it, not what it covers |
| Coached supervisors, or wrote the escalation script | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script." The pack's observation: your material says trained, says tellers, and says "our" script |
| Any contact-centre experience | Negative you stated, F2 | "I haven't worked in a contact centre." |
| Presented to senior leaders | Negative you stated, F8 | "I haven't presented above regional level." |

---

## Sources

- **Provided documents:** the JD; the values text you copied on 12 November 2026 from ashgrovecu.org/about/values; the recruiter's email; four lines from Ashgrove's July 2026 strategy brief; your background in your message.
- **Searches and fetches sent:** none. The values page URL was the source of text you pasted, not a link to read, so it wasn't fetched.
- **Dossier:** none present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted, copied this morning, already fixes the values cheat sheet and the H bank |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email already sets out all three rounds, the case and the values round, so it fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief, about four months old, already fixes the grounding brief and G2, J1 and J2 |
| 4. interviewer name at Ashgrove | n/a | No names have been assigned, so there was no query to form. The interviewer read is absent |
| 5. representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → a "reading the interviewer" section, persona weights read from their public professional profiles, and at least one reverse question tied to each person's career path.
- **Your answers to the answer slots on F3, F5, F7 and F9** → those rows move from `discovery` to quoted evidence, and A4, B2, C1, C2, G2, E2 and H4 get story-mapped guidance.
- **Anything you've presented, and to whom** → if your F8 sentence leaves room for presenting at regional level or below, telling me lets D2 and E3 use it. Right now the pack can't.
- **The anonymised spreadsheet itself, or a screenshot of its layout** → this is the record your field keeps as proof of reporting work. It would let F3 and F9 rise above `medium`.
- **Ashgrove's complaints policy, or the regulatory regime they work under, ideally from the recruiter** → the case build could use their real deadlines and decision limits instead of asking about them.
- **The full strategy brief text** → a fuller grounding brief, with more of their own vocabulary and figures.
- **How much prep time you have before the 21st** → a prioritised prep schedule tied to question IDs.
- **A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes** → recent Ashgrove news, leadership and organisation context, and published reports from people who have been through this loop, added to the grounding brief and the reverse questions.
- **A job-underwriter dossier** → if one existed, verified evidence and a named objection would replace the pack's own inference on D1. The pack is complete without one.
