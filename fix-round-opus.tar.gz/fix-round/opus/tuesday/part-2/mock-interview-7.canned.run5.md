Reading done — now running the default light research pass on Saltmarsh Games and Tobias Wrenfield before writing your pack.
I've built your prep pack. It assumes Tobias is the hiring manager, because Saltmarsh's careers page says its single 60-minute interview, the "Outage Hour", is run by the hiring manager.

The hour has two halves:
- **First half:** a live-incident exercise on a simulated outage during a live event, which you work through out loud.
- **Second half:** a conversation about the company's three published values: "Players Before Plans", "Ship the Patch Not the Promise" and "Leave the Build Greener".

**What to prepare first:**
- **The question most likely to hurt you.** Saltmarsh announced in September that both games move to a season-pass model from February 2027. You told me you've never worked on a game with in-app purchases, and that's probably the gap Tobias pushes on. The pack scripts a calm answer: say it plainly ("I haven't worked on a game with in-app purchases"), steer back to what you've done, and give a plan for learning it.
- **The outage exercise.** Five practice scenarios with an answer structure: clarify, contain, tell players, coordinate the teams, recover, review.
- **Your strongest material for this interviewer.** He gave a GDC 2026 talk called "Patch Notes Are a Promise" and was previously a QA lead. That makes your release checklist the best fit, so say you "wrote" it and that QA "still uses" it. Don't stretch that to "managed QA" in front of a former QA lead.

The pack also has 22 practice questions, a fit check of each job requirement against your background, a values cheat sheet, six questions to ask him, and a list of claims not to make. The talk and the season-pass news come from search snippets only; I didn't read either page in full.

I can play Tobias and run the season-pass question with live follow-ups.
I can write a one-page outline for the outage exercise to keep in your head on the day.
I can save a tuesday-dossier.md file recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I'll convert it.

Is Tobias definitely the hiring manager, and did the recruiter tell you anything about the outage exercise? Either answer would change how the questions are weighted.
Do you want a deeper research pass (up to 6 more searches and 2 more page reads, several more minutes) to read the season-pass announcement and Tobias's talk in full?

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-canned-afa471e8:
- saltmarsh-games_live-operations-producer_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. I'm treating him as the hiring manager, because Saltmarsh's interviewing page says its 60-minute interview is run by the hiring manager (see Sources).
**Format:** one 60-minute session, the "Outage Hour". Saltmarsh's careers page describes it as "a live-incident tabletop on a simulated outage during a live event, then a values conversation", with "no take-home".

---

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking and in what style. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: values alignment, scored against Saltmarsh's three published values
  - **EXP**: a deep-dive into what you actually did
  - **JD**: can you do the job as the posting lists it, gaps included
  - **CO**: company and strategy knowledge (here, Project Larkspur)
  - **CASE**: a live problem from the role, solved out loud. The outage tabletop is one.
- Each row has one Type. Where a question scores two things, the rationale names the second one.
- Question IDs go by persona: A, B, C, D, E, G, H. **F is skipped** so the IDs don't clash with fit-snapshot rows (F1 to F9).
- **The guidance is scaffolding, not a script.** Every claim about your past rests on one of your own sentences, quoted in that row's Provenance column. Where your material doesn't settle something, the guidance gives you an *answer slot*: two honest branches, and you pick the one that's true.
- **Highest-ROI prep in this pack: C1** (season pass and no in-app-purchase experience), then the A-bank tabletop.

---

## Fit snapshot

Your sentences, as quoted below, all come from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says content drops on one title. It doesn't say live events, and it doesn't say two titles. Keep the words at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "live-events" line makes a probe on time-limited events likely. If any of those drops were time-limited events, say which and how they ran, in your own words. If none were, say so plainly and stay with the weekly calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Running a calendar touches this requirement, but your material doesn't show which teams you worked with or how. Answer slot: if you coordinated design, art, engineering or community on the drops, say which and how, in your own words. If the drops ran with other teams, or the coordination sat with someone else, say so plainly and describe your part in running the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | A monthly retention presentation is adjacent to a post-event review, but it isn't one. Keep the words at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran or wrote any review after a drop or a release, say what it covered, in your own words. If there was no such review, or it wasn't yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in kind. It's a line from your message with nothing behind it that I've inspected, so expect a probe. Lead with your own verb: you *wrote* it, and QA *still uses* it. A named artifact that's still in use beats an adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Four years clears the length. Your material doesn't say whether the title was live-service, and the pack doesn't assume it. Answer slot: if you'd describe the main title as a live-service game, say what made it one, in your own words. If you wouldn't, say so plainly and stay with the four years and the weekly drops |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Your sentence already says what the JD asks for. Say it as you wrote it: weekly, the main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [inferred] | discovery | Presenting the numbers is on your record. Whether you built or analysed them isn't. Answer slot: say which retention measures the monthly numbers covered and which part of preparing them was yours, in your own words. If someone else built them and you presented them, say so plainly. That is still a monthly retention conversation with the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Your sentence already reaches this requirement in other terms. Reworded, it says nothing more: "I wrote the release checklist, and our QA team still uses it." |
| F9 | Both titles move to a season-pass model from February 2027 (Saltmarsh news post, search snippet; not in the JD) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated this gap yourself, and no wording can close it. Words: "I haven't worked on a game with in-app purchases." After that, say how you would learn it, as a plan and never as a past. Never claim monetisation work, and add nothing that makes the gap feel smaller |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Live-events calendar, two titles (F1) | C2, C3, A5 |
| Coordinate design, art, engineering, community (F2) | H2, H1, A1 |
| Own post-event review and KPIs (F3) | C4, A4 |
| Release checklist with QA (F4) | A2, B3, E2 |
| 3+ years live-service (F5) | C3, G1 |
| Content calendar (F6) | C2, A5 |
| Retention metrics (F7) | D3, D1, D2 |
| Clear written communication (F8) | A3, A4 |
| Season pass, from strategy (F9) | C1, E1, A5 |

---

## Reading the interviewer

Public professional footprint only. These are from one search result, not a full read of the page.

| Signal | Source | What it means for Friday |
|---|---|---|
| Head of Live Operations at Saltmarsh Games | GDC 2026 talk listing (search snippet) | He owns what this role feeds into, so expect the hiring-manager lens: capability, and de-risking your gaps |
| Previously a QA lead at a console studio | Same listing | Release discipline will be probed with real expertise. Be exact about what you did with the checklist (F4): "wrote", "QA still uses". Don't inflate it to "managed QA" in front of a former QA lead |
| GDC 2026 talk "Patch Notes Are a Promise". His argument, per the listing: a live team is judged by how often its patch notes describe what actually shipped | Same listing | This theme will probably come up in the tabletop's player-comms step (A3) and in the values conversation (B4). It matches the published value "Ship the Patch Not the Promise" |
| Mirror opportunity | F4 | This is shared vocabulary, not a shared career jump: release checklists, QA, and what actually shipped. The F4 sentence is the one to bring: "Wrote the release checklist our QA team still uses." Mention his talk only if you have actually watched or read it |

---

## Persona table

| Persona | How it shows up on Friday | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | The outage tabletop: a simulated outage during a live event, worked live | **Highest, 5 questions.** It's the hiring-manager prior, and Saltmarsh's interviewing page names the tabletop as the first half of the hour | Clarify, then contain, communicate, coordinate, recover, review. Think aloud and challenge one premise respectfully. Ground your process claims only in F4 and F6 |
| Values / Behavioral (B) | The second half of the hour: the "values conversation" | **High, 4 questions.** The loop source documents it, and there are three published values | One story or one honest scaffold per value. Use "we" for the context and "I" for your contribution |
| Skeptic (C) | Quiet probing of the gaps: season pass (F9), one title versus two (F1), drops versus events, review ownership (F3) | **Mid-high, 4 questions.** It's the second hiring-manager prior, and F9 is a stated gap that meets Saltmarsh's announced direction | Rehearse C1 until it's boring. Give the plain acknowledgment first, then a ramp plan, and never bluff |
| Data-Driven Prober (D) | "Walk me through those retention numbers" | **Mid, 3 questions.** F7 and F3 are retention claims, and a KPI-owning role invites the denominator question | Know what you can and can't say about how the numbers were counted. Saying you don't know is allowed |
| Pressure (E) | Time-boxed challenges, perhaps mid-tabletop ("the clock is running") | **Low, 2 questions.** Nothing signals a stress style, but a simulated outage is time pressure by design | Pause, restate the question, hold through two follow-ups, then concede the specific thing |
| Conversational (G) | The opener and the transition between halves | **Low, 2 questions.** Short; one 60-minute session leaves little room for it | Have a 90-second arc ready, built only from your four sentences |
| Peer Evaluator (H) | Cross-discipline collisions inside the tabletop | **Low, 2 questions.** He's not a peer, but the JD's coordination line will come up in collegial scenarios | Talk about seam principles, not claimed history |

---

## Question banks

### A. Case / Strategist: the Outage Hour tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a weekend event on one of our titles, and event rewards stop granting for some players. Walk me through your first hour." | CASE | [inferred] | Structure it out loud. **Clarify:** which title, how many players, since when, and is the issue still happening. **Contain:** who can stop the damage now, and whether you pause the event or a reward. **Communicate:** brief the community team, and tell players only what is confirmed. **Coordinate:** engineering on the fix, QA on verification, design on whether to extend the event or compensate players. **Recover:** confirm the fix and reconcile rewards. **Review:** start the timeline now, while it's fresh. The question needs no claim about your past, so the guidance makes none | The tabletop is the documented first half of the interview, so a version of this is near-certain. The format comes from the careers page and the scenario is the pack's own, so it's `[inferred]`. CASE delivery; it also exercises the JD's coordination line (F2's requirement) |
| A2 | "Engineering says the fix needs a build that hasn't been through the release checklist. Do you ship it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Name the tension: players are losing rewards now, and the checklist exists to stop a second incident. Say what minimum verification you'd insist on, who makes the call, and how you'd record the exception so the checklist learns from it. You can say you wrote the release checklist your QA team still uses. Stop there, at what the sentence says | JD content (F4's requirement), CASE delivery. It pits "Players Before Plans" against "Leave the Build Greener", and it's natural ground for an interviewer who used to be a QA lead |
| A3 | "What do you tell players in the first 30 minutes, and what do you hold back?" | JD | [grounded] | Say what's confirmed, what you're doing, and when the next update comes. Hold back cause guesses, fix ETAs you can't stand behind, and compensation you haven't agreed. Tie it to the published value "we announce what is built, not what is hoped". No claim about your past | JD content (written communication, F8's requirement), CASE delivery. The values page and the interviewer's talk theme both point here, so it's `[grounded]` on the values page |
| A4 | "The outage is fixed. What goes in the post-event review, and which KPIs does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | **Structure:** timeline; player impact; root cause; what worked; actions with owners and dates; and KPIs such as event participation, retention against the comparable pre-event period, compensation claimed and support contacts. These are a generic pattern, not Saltmarsh's actual set. Answer slot: if any of the monthly retention numbers you presented compared periods around a content drop, say so in your own words. If not, leave it out and say you presented the monthly retention numbers to the studio head | The JD says "own the post-event review and the KPIs it reports" (F3's requirement), and the tabletop ends exactly here. JD type, CASE delivery |
| A5 | "From February both titles share one events calendar. How would you plan the first quarter?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Clarify:** each title's audience and cadence, season length, shared team capacity. **Plan:** avoid event collisions across the two titles; set season-pass beats; gate each update through the release checklist; define KPIs per title. Then be honest about scope: you ran the weekly content-drop calendar for your main title for the last two years. Running two titles on one calendar is what you'd learn here, so say what you'd want to know first | Project Larkspur is Saltmarsh's announced strategy (Sources). This is the strategy-grounded CO question the coverage rules require. It also presses F1's one-title scope |

### B. Values / Behavioral: the second half of the hour

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Context you can state: you ran the weekly content-drop calendar for your main title for the last two years. Selection scaffold: pick a time a planned drop was moved, changed or cut because of how players responded. It needs what the plan was, what the players showed, what you did and what happened next. If no such time comes to mind, say so plainly, then say how you would handle it | This is "Players Before Plans" ("when the calendar and the players disagree, the players win") put as a question. Your sentence gives the setting, not the story, so this is a scaffold |
| B2 | "When have you had to stop something being announced before it was built?" | VAL | [grounded] | Selection scaffold: pick a time you pushed back on announcing, or promising players, something that wasn't finished. It needs what was about to be said, why you stopped it, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | "Ship the Patch Not the Promise", which is also his talk's theme. No quoted sentence carries a story here, so it's a scaffold. `[grounded]` on the values page |
| B3 | "Tell me about leaving a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats are only what your sentence says: you wrote the release checklist, and your QA team still uses it. Tell it in your own words. Answer slot: the value says every release leaves "the checklist better than it found them", so expect a probe on whether it changed over time. If you revised it after releases, say what changed and why, in your own words. If it hasn't been revised, or not by you, say so plainly and stay with writing it and it still being in use | "Leave the Build Greener" names the checklist outright. F4 is your strongest match in the whole pack |
| B4 | "Why does 'ship the patch, not the promise' matter in live ops?" | VAL | [generic] | Reason it through without claiming a past. Players' trust in announcements is what makes the next event land, and a promise that slips costs more than the feature earns. Keep it short, and don't quote his talk back at him unless you've actually seen it | This is the theme of the interviewer's talk and of a published value, so it's likely. The reasoning is a role-family pattern, so it's `[generic]` |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **HIGHEST-ROI.** "We're moving both titles to a season pass. You haven't worked on a game with in-app purchases. Why shouldn't that worry me?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Open with the plain acknowledgment, no apology:** "I haven't worked on a game with in-app purchases." **Return to what the role lists and what you've done:** the JD's calendar, review and checklist lines, and your sentences that the weekly content-drop calendar and the release checklist were yours (F6, F4). **Ramp plan, said as a plan:** what you'd do first, for example learning how the season pass is structured, sitting with whoever owns its design, and reading the two titles' past event reviews. **Follow-up 1** ("but the season pass *is* the job now"): hold. The JD's own lines are calendar, coordination, review and checklist. Concede plainly that season-pass economics are new to you. **Follow-up 2** ("how fast can you get there?"): don't invent a timeline; say what you'd need to see first. **Never** bridge to monetisation work you didn't do | F9 is a gap you stated, and it meets Saltmarsh's announced direction, so it's the most predictable objection. CO because it's raised by strategy, not the JD; Skeptic delivery. It's the deepest rehearsal because the pull to soften it is strongest |
| C2 | "You ran the calendar for your main title. This role runs two titles on one calendar. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Keep the quote at its own scope: your main title, weekly, two years. Then reason live about what changes with two titles: collisions, shared art and engineering capacity, two player bases, and a single review rhythm. Say it as analysis, not as something you've done | F1's one-title scope against the JD's "two of our mobile titles" and Larkspur's shared calendar. JD-tagged for the calendar requirement |
| C3 | "Content drops aren't live events. Have you run time-limited events?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "4 years as an associate producer at a puzzle-game studio." | Hold the quote: weekly content drops, main title, two years, four years as an associate producer. Answer slot: if any drops were time-limited events, say which and how they ran, in your own words. If none were, say so plainly and stay with the weekly calendar. The honest branch is a limit, not a confession | The JD says "live-events calendar" and "live-service" (F1, F5). This is the likeliest wording of that probe |
| C4 | "You've presented retention numbers, but have you owned a post-event review?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you did, in those words: you presented the monthly retention numbers to the studio head. Answer slot: if you ran or wrote a review after a drop or release, say what it covered and what part was yours. If there was no such review, or it wasn't yours, say so plainly and return to the monthly presentation, then say how you'd run one here (A4's structure) | F3's transferability gap. The JD says "own", and the prohibited list rules out stretching your sentence to fit it |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. What did they measure?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which retention measures the numbers covered, how they were counted and which part of preparing them was yours, all in your own words. If someone else built them and you presented them, say so plainly. "I don't know exactly how it was counted" is an honest branch | F7 is the evidence for the metrics requirement. A prober will go two levels into it |
| D2 | "Which number in that monthly update would you trust least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The weakest-assumption move: name, in your own words, the number or assumption you'd defend least, before he finds it. If you don't know how one was counted, say so. That's credibility, not weakness | It rehearses the metric bar the rubric sets. EXP because it tests what you know about your own numbers |
| D3 | "Retention dips the week after an event. Diagnose it." | JD | [generic] | Clarify first: which retention measure, which cohort, compared with what period. Check the data is real, then segment by new or returning players, platform, and build version. Ask what changed: event content, bugs, the release itself, outside factors. Then give a hypothesis and how you'd test it. No claim about your past | JD content ("player-retention metrics", F7's requirement), CASE delivery. A post-event KPI dip is exactly the review this role owns |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who's run events on a monetised game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "never worked on a game with in-app purchases" | Pause, then three beats: the weekly content-drop calendar for two years, the release checklist your QA team still uses, and the plain acknowledgment ("I haven't worked on a game with in-app purchases"), followed by how you'd close that gap. Hold through the push-back. Concede the monetisation gap specifically, and don't fold on the calendar or the checklist | A time-boxed version of C1. Pressure is plausible inside a simulated outage. JD-typed because it scores the role's core |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it. Answer slot: if other people contributed items or reviewed it, say who and how, plainly. If it was yours start to finish, say that. Don't add claims about how widely it's used beyond "our QA team still uses" | F4 is your headline claim, and this interviewer has a QA background. It's the classic attribution probe |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc from those four sentences only: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the last two years, the release checklist QA still uses, and the monthly retention numbers presented to the studio head. End with why this role is the next step, in your own words | The opener in almost every interview. It's scored on economy, and it sets up F5 |
| G2 | "Why live ops, and why Saltmarsh, now?" | CO | [grounded] | Answer slot: give your actual reasons in your own words. If Larkspur's shared calendar or one of the three published values is genuinely part of it, name which. If not, don't borrow them | Motivation consistency. It's tied to the strategy and values you've researched, but only if they're really yours |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Art says the event banner won't be ready for the calendar date. What do you do?" | CASE | [generic] | Clarify what's late and why. Look at options: slip the event, ship with a fallback asset, or cut scope. Who decides, how community is told, and what the review records. Seam principle: surface the slip early and let the owners trade it off. No claim about your past | The JD's coordination line (F2's requirement), as a collegial scenario |
| H2 | "How do you keep design, art, engineering and community on the same page for each update?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start from what you can say: you ran the weekly content-drop calendar for your main title. Answer slot: if you coordinated those teams on the drops, say how, in your own words. If the drops ran with different teams, or that coordination was someone else's, say so plainly and describe your part in running the calendar. Then describe how you'd do it here, as a plan | F2's discovery gap, JD-tagged. "Running a calendar" is the sentence most likely to be stretched into "coordinated four teams" |

---

## Values cheat sheet

The values come from saltmarshgames.com/values, fetched. The meanings are paraphrased.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Scaffold (B1). Context from F6: "I ran the weekly content-drop calendar for our main title for the last two years." Pick a time a drop changed because of players. If none comes to mind, say so plainly and say how you'd handle it |
| Ship the Patch Not the Promise | Announce what's built, not what's hoped | Scaffold (B2). Pick a time you held back an announcement of unfinished work. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it |
| Leave the Build Greener | Every release leaves the code and the checklist better than before | F4: "Wrote the release checklist our QA team still uses." (B3, with its slot on revisions) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from QA lead to running live ops. What from QA do you think live teams most underrate?" | It's tied to his path, and it turns the interview into a conversation between two people who care about release discipline |
| R2 | "Your GDC talk argued a live team is judged by whether its patch notes describe what shipped. How does the team track that today?" | Tied to his talk. **Use it only if you've watched or read it**; otherwise drop it |
| R3 | "With per-title event teams becoming one live-ops group under Larkspur, how would this role split its time between Tidepool Tactics and Lantern Row?" | It shows you've read the strategy, and it tells you what the job really is |
| R4 | "Who owns season-pass design, and how does the producer work with them?" | It tells you where your F9 gap sits in the actual org, and it reads as diligence, not anxiety |
| R5 | "What does a good post-event review look like here? Who reads it, and which KPIs do decisions actually turn on?" | It goes straight at the JD's "own the post-event review", and it tells you the real metric set |
| R6 | "How is ownership of the release checklist split between producers and QA today?" | It's your strongest ground (F4), and it's his former specialism |

---

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on in-app purchases, monetisation or season passes | Negative you stated (F9) | "I haven't worked on a game with in-app purchases." Then a ramp plan, as a plan. No slot |
| Led a team | Negative you stated: "Never led a team" | "I haven't led a team." No slot |
| Ran live events | Inflated form of F1 | F1's quote at its own scope. The material says weekly content drops, not events. C3's slot stays inside the drops |
| Ran a calendar across multiple titles | Inflated form of F1 | F1's quote: "our main title". Two titles is described as what you'd learn |
| Coordinated design, art, engineering and community on each update | Inflated form of F2's quote | Running the calendar, at its own scope. H2's slot stays inside the calendar you ran |
| Owned post-event reviews or the KPIs they report | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." C4's slot stays inside drops and releases you worked on |
| Built or analysed the retention metrics | Inflated form of F7 | Presented them. D1's slot asks only what they covered and which part was yours |
| Managed the release process, or managed QA | Inflated form of F4 ("wrote" turned into "managed") | "Wrote the release checklist our QA team still uses." |
| Four years producing a live-service game | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." G1 and C3 stay there |

---

## Sources

**Provided:** your message (the JD text and your background).

**Searches and fetches:**
1. Search "Saltmarsh Games values" → https://saltmarshgames.com/values
2. Search "Saltmarsh Games interview process producer" → https://saltmarshgames.com/careers/interviewing
3. Search "Tobias Wrenfield Saltmarsh Games" → https://talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only)
4. Search "Saltmarsh Games mobile news 2026" → https://saltmarshgames.com/news/project-larkspur (snippet only: September 2026 announcement)
5. Fetch https://saltmarshgames.com/values → three values with definitions
6. Fetch https://saltmarshgames.com/careers/interviewing → the Outage Hour format

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet, the B bank, A3 |
| 2. Saltmarsh interview process | yes | It establishes the loop: one 60-minute hiring-manager session, tabletop then values. Persona weights and the A and B banks follow from it |
| 3. Saltmarsh strategy / recent news | yes | Project Larkspur (season pass, shared calendar, one live-ops group): A5, C1, C2, F9, R3, R4. Snippet only, because the fetch budget went to targets 1 and 2 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read, B4 weighting, R1, R2. Snippet only |
| 5. Representative JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your CV** → the evidence cells quote CV lines as well as your message, and stories may surface for the B1 and B2 scaffolds
- **Your answers to the slots in C3, C4, D1, H2 and B3** (told to me here, outside a drill) → those rows become story-mapped. F1, F2, F3 and F7 are regraded, and the prohibited list is rechecked
- **How much prep time you have before Friday** → a prioritized prep schedule sized to it
- **Any recruiter notes on the Outage Hour** → the tabletop scenario matched to what they said, plus a build section if they named a deliverable
- **The checklist document itself, or a past monthly retention deck** (the artifacts a producer actually keeps) → F4, F7 and F8 confidence can move from medium to high
- **A tuesday-dossier.md from a job-underwriter pass** → an evidence-derived highest-ROI objection and a prohibited list you've confirmed. Not needed for this pack
