Reading's done; now running a few quick searches on Saltmarsh Games and Tobias Wrenfield before I build your pack.
I've written your prep pack for Friday. I built it assuming Tobias would be your hiring manager, since you gave his title but not whether you'd report to him.

My web searches on Saltmarsh and Tobias were blocked by permissions. So nothing in the pack about the company or him comes from research: those parts are general patterns for the role, and they're labelled that way.

**The question to rehearse most (A1):** "You've run one title's calendar and haven't led a team. Why are you ready for two titles and four disciplines?"
- **Hold on:** "For the last two years I ran the weekly content-drop calendar for our main title."
- **Concede before he presses:** "I haven't led a team." The JD asks you to coordinate design, art, engineering and community, not to lead them.
- **Where it can break:** your notes don't say whether you worked with those teams on the drops. If you did, say who and how. If not, say so plainly and stay with the calendar.

**The second gap is in-app purchases (A2 and E1).** Say it in one line: "I haven't worked on a game with in-app purchases." Then give your plan for learning it, as a plan. Don't add anything to make the gap sound smaller.

**Your strong points:**
- Two years running the content calendar matches the JD almost exactly.
- The release checklist your QA team still uses.
- Presenting the monthly retention numbers to the studio head.

Each of these will be probed. Know which parts were yours, and say "I don't know how that was counted" if that's the truth.

The pack also has 22 practice questions with answer guidance, six questions to ask Tobias, and a list of claims it won't coach you to make. The interview is tomorrow, so it opens with a short schedule: A1, then the in-app-purchase questions, then the numbers and the checklist, then two live cases.

Say the word and I'll play the sceptical interviewer on A1, with follow-ups that react to what you actually say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and did the recruiter mention a format or anything to prepare? Either answer could change how the pack is weighted.
If you allow web search, should I run the company and interviewer searches and update the pack?

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-7-denied-1914e657:
- Saltmarsh-Games_live-operations-producer_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Session:** one 60-minute interview, Friday, with Tobias Wrenfield, Head of Live Operations
**Assumed relationship:** hiring manager. Your message gives his title but not whether you would report to him, so every persona weight below rests on that assumption.

---

## How to use this pack

- **Personas** are how a question gets asked: who is asking, and in what style. **Types** are what the answer is scored on.
- **Type key:**
  - **VAL**: behaviour and values. Does what you did show the values they care about?
  - **EXP**: work-experience deep-dive. Does what you said hold up, and what was actually yours?
  - **JD**: the job description. Can you do the listed job, including the parts you haven't done?
  - **CO**: company knowledge. Have you done your homework?
  - **CASE**: a live problem. How do you structure and reason through it, out loud?
- **Provenance labels:** `[grounded]` means it comes from your message or the JD. `[inferred]` means it is this pack's own derivation, and the derivation is named. `[generic]` means it is a common pattern for the role, with no claim about Saltmarsh or about you.
- The guidance is scaffolding, not a script. Wherever a cell gives you words, they are your own sentences from your message. Wherever it says **answer slot**, you fill it with what really happened, or you say plainly that it didn't happen.
- Question IDs skip the letter F so they can't be confused with the fit-snapshot rows (F1 to F9).

---

## Prep triage

The interview is tomorrow, so this assumes you have this evening and Friday morning.

1. **A1, out loud, three times.** It is the highest-ROI prep in this pack (see Question banks). Time-box it to 2 minutes.
2. **A2, then E1.** These are the two in-app-purchase questions. Get the plain sentence in F9 automatic, so it comes out without a wince.
3. **C1 and C2.** Know what you can and can't say about the retention numbers and the checklist. Write down the answer slots before you go in.
4. **B1 and B4.** Each is a live case straight from the JD. Practise the structure aloud, one run each.
5. **Play both Saltmarsh titles tonight,** if you know which two are in this role's scope. B1, B2, A5 and the reverse questions all get stronger if you have played the games yourself.
6. **Pick three reverse questions** from the list near the end.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar. The JD says live events across two titles. Keep the words at their own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-titles line makes a probe on juggling titles likely. If the calendar you ran ever had to fit around another title or team, say how, in your own words. If it didn't, say so plainly and give your plan for running two, said as a plan and never as a past |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Coordinating is not leading. Your negative is about leading, and your material says nothing either way about coordinating. Answer slot: if you worked with design, art, engineering or community people to get content drops out, name which ones and what the coordination looked like, in your own words. If that wasn't part of your work, say so plainly and stay with the calendar you ran. If you are asked about leading, the words are yours: "I haven't led a team." |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning an event review, but it doesn't reach it. Words at their own scope: "I presented the monthly retention numbers to the studio head." Answer slot: if those numbers ever showed how a particular content drop did, say how you read them. If they didn't, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Writing the checklist is authorship. The JD says managing it. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran or updated that checklist release by release, say how. If someone else did, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message, and "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | Four years clears the length. Your material doesn't say whether the game was run as a live service, so don't borrow the JD's term for it. Answer slot: if the main title was run as a live service, describe how it was run, in your own words. If it wasn't, say so plainly and describe the weekly drops you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but it is a self-report with nothing behind it to inspect, so expect a probe. Lead with the quote in its own terms: weekly, main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [inferred] | discovery | Presenting the numbers shows you worked with them. It doesn't show how much of preparing or reading them was yours. Answer slot: if you compiled or interpreted those numbers yourself, say which parts. If they came to you ready-made, say so plainly and describe presenting them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | A checklist people still use is a written artifact, but it is one kind of writing. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote other things for the team, such as update notes or briefs, name them. If not, stay with the checklist |
| F9 | Event KPIs on mobile titles commonly include monetisation as well as retention. This is a role-family pattern, not from the JD, and the JD doesn't mention it | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated this gap yourself, and no wording closes it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Add nothing to make the gap feel smaller |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Live-events calendar, two titles (F1) | A1, B1, C3 |
| Coordinate design, art, engineering, community (F2) | A1, B3, B5, G2 |
| Post-event review and KPIs (F3) | B2, B4, C1 |
| Release checklist with QA (F4) | C2, E2, G1 |
| 3+ years live-service (F5) | A4, D1 |
| Content calendar (F6) | C3, D1 |
| Player-retention metrics (F7) | C1, B2 |
| Clear written communication (F8) | D3, B4 |
| Monetisation, not in the JD (F9) | A2, E1 |

---

## Persona table

The session is established by your own words: one 60-minute interview, run by Tobias. So the weights come from the relationship, not from a guessed company process. The web research didn't run (see Sources), so no interviewer signals adjust them.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | "Why are you ready for two titles?" "What haven't you done?" | High. A hiring manager is de-risking gaps, and F1, F2 and F9 are visible ones | Rehearse A1 until it's boring. Hold only what your quotes carry, and give plain acknowledgments where you stated a gap |
| B. Case / Strategist | Plan a calendar, diagnose a dip, handle a slip | High. A hiring manager buying capability tests the actual job, and the JD lists four live tasks | Clarify, then state the objective, segment, approach, metrics and risks. Think aloud |
| C. Data-Driven Prober | "What did those retention numbers measure?" | Mid. The JD's KPI and retention lines invite it | Know what you can and can't say about how the numbers were counted. Say plainly when you don't know |
| D. Conversational | "Walk me through your journey" | Mid. A 60-minute slot usually opens with rapport, and that part is scored too | Have a 90-second arc built only from your quoted sentences |
| E. Pressure | Time-boxed "why you" | Low to mid. Nothing points to a stress style, but the F9 gap invites one sharp probe | Pause, restate, anchor in what you said, then hold through two follow-ups |
| G. Peer Evaluator | QA or community seam questions | Low. He's a manager, but the JD is built on cross-team work | Propose principles for the seam. Don't pretend to know it |
| H. Values / Behavioral | "Tell me about a time…" | Low. No values round was identified, and Saltmarsh's values couldn't be researched | Selection scaffolds with honest branches |

---

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role runs events across two titles and coordinates design, art, engineering and community. You've run one title's calendar and haven't led a team. Why are you ready?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years", "Never led a team" | **The highest-ROI rehearsal in this pack.** Hold: "For the last two years I ran the weekly content-drop calendar for our main title." Concede before he presses: one title, not two, and, in your words, "I haven't led a team." You may note that the JD says coordinate, which is a reading of their posting, not a claim about you. Answer slot: if you coordinated with any of those disciplines to ship drops, name who and how. If not, say so plainly and stay with the calendar. Close with a plan for picking up the second title, said as a plan. Hold through two follow-ups by returning to the calendar, never by adding to it | F1 and F2 together are the most visible stretch from your material to this JD, so some form of this question will come. JD, because it scores the two-titles and coordination lines directly |
| A2 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases", "Presented the monthly retention numbers to the studio head" | Answer it straight: "I haven't worked on a game with in-app purchases." Then, if you want, the adjacent fact in its own words: "I presented the monthly retention numbers to the studio head." Then how you would get up to speed, said as a plan. Don't claim retention and revenue work the same way. That's an argument, not your experience | F9 is a stated gap, and mobile live-ops interviews commonly raise monetisation. JD-adjacent, because the KPI line is the likeliest place it surfaces |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases", "Never led a team" | Pick one real gap and name it plainly. Either of your stated negatives is honest material. Say what you would do in the first weeks to close it, said as a plan. Don't pick a fake weakness | Stock Skeptic stem. F2 and F9 make a candid answer available, and a candid answer scores here |
| A4 | "You were an associate producer. What was actually yours, and what was your producer's?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | Say the title as it was. Then the three things, in the quotes' own verbs: ran the calendar, wrote the checklist, presented the numbers. Answer slot: if calendar decisions were yours to make, say which. If someone signed them off or set them, say so plainly | F5 and the "associate" title invite an attribution probe. EXP, because it tests what was yours |
| A5 | "Why leave a puzzle studio for Saltmarsh?" | CO | [generic] | Selection scaffold. Give one honest reason about the work (more titles, more events, the scope in this JD), and one about Saltmarsh you can stand behind, ideally from playing its games. If you have no Saltmarsh-specific reason yet, say what draws you to the role and leave out invented company facts | The motivation probe always comes. Generic, because no company research ran |

### B. Case / Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch a quarter's live-events calendar across two titles. What do you need to know first?" | CASE | [generic] | Clarify first: the goals per title, the audience overlap, team capacity, the release cadence and fixed dates. Then the shape: anchor events, a filler cadence, collision rules between the titles, and buffers for slips. Then how you'd measure it and the top two risks. Ask him one premise question | Straight from the JD's calendar line. A hiring manager will test it live |
| B2 | "An event went live and retention dropped the following week. Diagnose it." | CASE | [generic] | Check the data first (instrumentation, cohort, seasonality). Then segment: new versus returning players, platform, region. Then event causes: difficulty, reward pacing, bugs, timing against the other title. Then what you'd check in which order, and what you'd change next time | The JD's KPI and retention lines (F3, F7). A classic diagnose case |
| B3 | "Engineering tells you two days before an update that a feature won't make it. What do you do?" | CASE | [generic] | Clarify what slipped and why. Options: ship without it, swap content, or move the date. Who you tell and in what order (design, art, community, QA). What changes on the checklist. How you'd make the decision visible in writing | The JD's coordination line. Tests calm triage across teams |
| B4 | "Walk me through what you'd put in a post-event review, and which KPIs it reports." | CASE | [generic] | Structure: the goal versus the result, a KPI table (participation, retention around the event, plus whatever the studio tracks, which is worth asking him), what went well, what didn't, cross-team issues, and owned actions. Keep it short and written for people who weren't in the room. This is a design, not a claim about a past review | The JD's "own the post-event review" line (F3). Also tests writing (F8) |
| B5 | "Community says players hated the last event. How does that shape the next one?" | CASE | [generic] | Separate the signal from the volume: what players say against what they did. Find the specific complaint, decide what to change and what to hold, and close the loop with players through community | The JD names community among the teams to coordinate |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through those monthly retention numbers you presented. What did they measure, and what moved them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start from the quote. Answer slot: how the figures were counted. If you know, say it in your own words; if you don't, say "I don't know how it was counted" plainly. Answer slot: the assumption behind them you'd defend least, if you know one. Answer slot: which part was yours. If you prepared or interpreted them, say which parts; if they came to you ready-made, say so. Answer slot: if a content drop ever showed up in them, say how you read it. If none did, say so | F3 and F7 rest on this sentence, so a prober goes straight to it. EXP, because it tests what was yours |
| C2 | "Your release checklist: what's on it, and why does QA still use it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | "I wrote the release checklist our QA team still uses." Answer slot: describe what's on it, in your own words. Answer slot: if you know why QA kept it, say what you know. If you don't, don't guess. Answer slot: if you ran or updated it each release, say how. If not, say so | F4 and F8. The "still uses" detail invites a follow-up |
| C3 | "How did a weekly content drop get from plan to live on your calendar?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: walk the stages as they really were, and which ones were yours to set. If a stage wasn't yours, say who held it. Keep it to the weekly drops on the main title | F1 and F6. It tests whether "ran the calendar" holds up step by step |

### D. Conversational (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc: four years as associate producer at a puzzle studio. For the last two years you ran the weekly content-drop calendar for the main title. You wrote the release checklist QA still uses, and you presented the monthly retention numbers to the studio head. End with why this role is the next step, in your words | The opener in most hour-long interviews. F5 and F6 |
| D2 | "What are you playing on mobile at the moment?" | CO | [generic] | Answer honestly, and name something you've looked at with a live-ops eye: an event you noticed and why. If it's Saltmarsh's own game, even better, but only if it's true | A casual question that is still scored for genuine interest |
| D3 | "How do you like to write things up for a team?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Lead with the checklist in the quote's words. Answer slot: if you wrote other things the team used, name them. If not, describe how you'd write a post-event review (link to B4), said as a plan | The JD's writing line (F8), asked casually |

### E. Pressure (low to mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run events on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years" | Pause. Concede in one line: "I haven't worked on a game with in-app purchases." Hold with the calendar quote at its own scope. Then the reason you'd pick up that side quickly, said as a plan. Don't run over the 60 seconds. If he pushes a second time, hold the calendar and don't add to it | F9 under time pressure. The hold-then-concede structure is the whole point |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote it." Answer slot: if others added to it or reviewed it, say so plainly and name their part. If it was all yours, say so without embellishing | F4. A stock attribution probe on your strongest artifact |

### G. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "QA says the build isn't ready on release day and design wants it out. What happens?" | CASE | [generic] | Clarify the severity. Use the checklist criteria as the shared standard, and lay out the options: hold, ship with a known issue, or ship partial. Say who decides and how it gets written down. Show spine and tact | The JD's QA line (F4), asked as a seam question |
| G2 | "When an update spans design, art, engineering and community, how do you handle credit?" | VAL | [generic] | Selection scaffold. Pick a time you shared credit on cross-team work. It needs named teams and what you did about credit. If none comes to mind, say so plainly and give the principle you'd follow | The coordination line (F2). Peer-style credit probe |

### H. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. It needs a named stake, what you said, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. Your material has no story here, so it's a scaffold |
| H2 | "When did you put players ahead of an internal metric?" | VAL | [generic] | Selection scaffold. It needs a specific decision, the metric that pulled the other way, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem, adapted to players. Live ops lives in that tension |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which two titles would I be running, and how different are their event rhythms?" | It shows you're already thinking about the two-titles load. It also tells you what to play before day one |
| R2 | "What does a good post-event review look like here? Is there one you'd point a new producer to?" | The JD says you'd own it. Asking for their standard reads as diligence |
| R3 | "Which KPIs does the review report today, and who reads it?" | It tells you whether monetisation sits in the review (F9) before it's a surprise |
| R4 | "Where do events most often slip: design, art, engineering, or late QA?" | It invites him to talk about the real seam in his team |
| R5 | "What would you want from this producer in the first 90 days?" | It turns the hiring decision into a shared plan |
| R6 | "How are the producers on the two titles organised? Would I report to you?" | It settles the relationship this pack assumed, and it's useful to you either way |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across multiple titles | Inflated form of F1 | F1's quote at its own scope. Your material says one title's weekly content-drop calendar |
| Owned post-event reviews and their KPIs | Inflated form of F3 | F3's quote at its own scope. Your material says presenting monthly numbers |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope. Your material says you wrote the checklist |
| Owned retention analytics | Inflated form of F7 | F7's quote at its own scope. C1's slot only asks which parts of the presented numbers were yours |
| Has led a team | A negative you stated, F2 | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases, or on monetisation | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |

---

## Sources

- **What you gave me:** your message (JD text, background, interviewer name and title).
- **Searches sent:**
  - "Saltmarsh Games values": refused (web search permission not granted)
  - "Saltmarsh Games interview process producer": refused
  - "Saltmarsh Games mobile studio news 2026": refused
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused
- **Dossier:** none present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every call was refused. It would have themed the H bank with Saltmarsh's own values |
| 2. Saltmarsh Games interview process | unavailable | Every call was refused. It could have shown whether other rounds follow this one |
| 3. Saltmarsh Games strategy and recent news | unavailable | Every call was refused. It would have made A5, D2 and the CO questions specific to Saltmarsh |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Every call was refused. It would have supplied the interviewer read, adjusted the persona weights, and tied a reverse question to his career |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Web search allowed → targets 1 to 4 run: Saltmarsh's titles and recent news make A5, D2 and the CO questions specific, and Tobias's public profile adds an interviewer read and a reverse question tied to his career
- Deeper research pass, offered once (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, his talks or writing, and recent studio context, for a sharper case bank
- Confirm whether Tobias is your future manager → the persona weights and the A bank re-tuned if he's a skip-level or a peer
- Any recruiter note on format, or a task to prepare → a build section for any announced deliverable
- Your answers to the slots in F2, F3, F5 and F7 → those rows and A1, C1, C3 rebuilt on your own sentences
- Your CV text → more quotable sentences, so more stories mapped instead of scaffolded
- A tuesday-dossier.md, if you ever make one → an evidence-checked top objection and a stricter guardrail list
