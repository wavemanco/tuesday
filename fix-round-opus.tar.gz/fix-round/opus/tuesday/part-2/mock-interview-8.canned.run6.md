Building your prep pack now. Everything I need is in your message, so no research or extra questions are needed. Writing the file next.
I've built your prep pack for all three rounds on 21 November: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-8-canned-db609f5d/ashgrove-credit-union_member-experience-lead_interview_pack.md`

Your message covered everything it needed: the job description, Ashgrove's four values, the recruiter's round structure, the strategy brief and your background. So I didn't search the web, and I have no questions for you.

**What's in it:**
- **How your experience lines up with the job description.** Your strongest matches are the formal complaints log, training tellers on the escalation script, the monthly complaints spreadsheet, and six years in banking against the four required.
- **Your real gaps.** Some are ones you told me about: no contact-centre work, and no presenting above regional level. Others your background doesn't mention either way, so the pack gives you an honest answer for each:
  - whether those were regulated complaints
  - whether the spreadsheet tracks complaint volumes and resolution times
  - whether it's built in Excel
  - any work with digital teams
- **One question bank per round, 29 questions in total.**
  - Recruiter (30 min): your background, why you applied, and the knock-out checks against the job description.
  - Head of Member Services (45 min): mostly behavioural, as the recruiter said, plus questions on the strategy. These include the 40% digital target and what goes on page one of a report for senior leaders.
  - Branch-manager panel (60 min): one question per value, case questions on hubs and small-business lending, and how you'd work with their supervisors.
- **A build for the 20-minute escalation case.** It has a six-step structure with time allowances, three positions you could take (each with the point you'd have to concede), and how to stand out from the standard answer.
- **A values cheat sheet.** None of your four sentences describes a specific moment for the values. For each one, the pack tells you what kind of story to pick from your own memory, and what to say honestly if nothing comes to mind.
- **Claims not to make,** even under pressure. For example: "ran the complaints process", "coached supervisors", "managed a branch". The panel are branch managers and will know the difference between a manager and a supervisor.

**The most important thing to rehearse is question D1 in round 2.** The question is: "You've handled one branch's complaints log, but this job covers every branch and the contact centre — why isn't that too big a step?" The pack has your words for admitting the limit, what to stand on, and the two follow-ups to expect.

The pack ends with a list of what would make it stronger. The two most useful are your answers on what the spreadsheet tracks and whether the complaints were regulated, and the interviewers' names once they're assigned.

If you'd like a practice run, I can play your future manager and ask you D1, with live follow-ups and feedback afterwards.
I can also save a tuesday-dossier.md recording the gaps this prep found, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date:** 21 November 2026, three rounds on the same day
**Mode:** Loop. One shared fit snapshot, then a mini-pack for each round
**Rounds, from the recruiter's email:**
1. Recruiter, 30 minutes
2. Head of Member Services (your future manager), 45 minutes, "mostly behavioural"
3. Panel of two branch managers, 60 minutes, including a "20-minute case on a complaint escalation". This panel is also the values round: "they score against the four values"

No interviewer names have been assigned yet, so this pack has no interviewer read. Persona weights come from each round's role and from what the recruiter said about it.

---

## How to use this pack

- **Personas** describe *how* a question is asked: the style and pressure. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behaviour that shows Ashgrove's four published values
  - **EXP**: deep-dive on your experience, checking what was actually yours
  - **JD**: a stated responsibility or requirement from the job description
  - **CO**: knowledge of the company and its strategy
  - **CASE**: a live problem from the role, worked through out loud
- Provenance labels: `[grounded]` means it traces to something you or Ashgrove provided. `[inferred]` means it is this pack's own derivation, which is named. `[generic]` means a common pattern for this kind of role, with no claim about you or Ashgrove.
- Answer slots tell you what to say in the interview, if it's true. Every slot has a second branch for when it isn't true. Both branches are good answers.
- The guidance is scaffolding, not a script. Say it in your own words.
- Question IDs use letters A–J. The letter F is skipped so that question IDs never clash with fit-snapshot rows F1–F9.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's log. It doesn't describe a process across branches, and your answer should stay at that scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's end-to-end, across-branches line makes a probe on how far your part went likely. If any part of complaint handling beyond your branch's log was yours, say which part, in your own words. If none was, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD, same line | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I haven't worked in a contact centre." Then say how you would learn it, framed as a plan and never as a past. Never claim contact-centre experience, and add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material shows a monthly complaints spreadsheet that you built. It doesn't say what the spreadsheet counts, and it doesn't say you report from it: your regional manager uses it. Answer slot: if it tracks complaint volumes or resolution times, say which one and how, in your own words. If it tracks neither, say plainly what it does track |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on a script. It doesn't mention coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you have coached fellow supervisors, or anyone besides new tellers, on escalations, say who and how, in your own words. If you haven't, say so plainly and stay with the teller training. "Our escalation script" doesn't say who wrote it, so neither should your answer |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't mention digital or self-service work. Answer slot: if you have worked with a digital team, or on an online or app journey for customers, say what you did, in your own words. If you haven't, say so plainly and say how you would approach it as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Six years is more than four, so lead with the quote's own terms: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer map it to "customer operations" rather than relabelling your years in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" isn't the same as "regulated", and your material doesn't say which these were. The bridge is this pack's reading of your quote, which is why it's labelled [inferred]. Answer slot: if the complaints in that log were handled under regulatory rules, say which rules and what they required of you, in your own words. If they weren't, or you don't know, say so plainly and describe the log as you handled it |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I haven't presented to anyone above regional level." Then say how you would get ready, framed as a plan. Answer slot: if you have presented at regional level, say what and to whom, in your own words. If you haven't, say so and keep to the plan. Never imply senior-level presenting |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says "spreadsheet" but doesn't name Excel. Answer slot: if you built it in Excel, say what you built in it, in your own words. If you used another tool, name it plainly and stay with what you built. Never name an Excel feature you don't use |

**The single most likely objection** comes from F1 and F2 together. It goes: you've handled one branch's complaints log, but this job owns complaints across every branch and the contact centre. It's rehearsed most deeply at **D1** (round 2), which is **the highest-ROI prep in this pack**.

### Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own the complaints process end to end across branches | F1 | D1, A4, E1, I1 |
| …and the contact centre | F2 | B1, D1 |
| Report monthly on complaint volumes and resolution times | F3 | C1, E2, G2 |
| Coach branch supervisors on escalations | F4 | D3, J1, J2 |
| Work with digital teams on self-service journeys | F5 | E5, G1 |
| 4+ years in financial-services customer operations | F6 | B3 |
| Experience handling regulated complaints | F7 | A4, I1 |
| Confident presenting to senior leaders | F8 | B2, D2, G2 |
| Comfortable with Excel reporting | F9 | C2 |
| Strategy: 40% digital by 2028, hubs, small-business lending, app-only banks | — | G1, I2, I3, A3 |
| The four values | — | H1–H5, plus the cheat sheet in round 3 |

---

## Grounding brief (shared)

This brief draws only on the four strategy points and the organisation facts in your message. If the full brief has more in it, see the upgrade menu.

| Item | What it says | Provenance | How to use it |
|---|---|---|---|
| Organisation | "member-owned, about 900 staff" — JD | [grounded] | Say "members", never "customers". Ashgrove's own values say "Members First" and "member's side of the counter" |
| Digital shift | "move 40% of member service to digital channels by 2028" — strategy brief, July 2026 | [grounded] | Ties to the JD's self-service line (F5). Feeds G1 and the round 2 reverse questions |
| Branch network | "consolidate eight branches into five hubs over 2027" — strategy brief | [grounded] | Use the word "hubs". Your panel is two branch managers, so raise this with curiosity and don't give opinions on how it affects them. Feeds I2 |
| New product | "launch a small-business lending product in Q1 2027" — strategy brief | [grounded] | A new product brings new complaint types. Feeds I3 |
| Competition | "the main competitive pressure is app-only banks" — strategy brief | [grounded] | Feeds A3 and G1. A strong angle: member experience is where a member-owned credit union can be different |
| Their vocabulary | Members; branches; contact centre; Member Services; self-service journeys; hubs; the four value names | [grounded] | Use the value names exactly as written. The panel scores against them |
| Freshness | The brief is dated July 2026, about four months before your interviews | [grounded] | Nothing in your inputs contradicts it. If an interviewer gives a newer figure, use theirs |

---

## Graded deliverable: the 20-minute complaint-escalation case (round 3)

This is a shared section, because the case sits inside the values round.

| Grounded fact | Source | Provenance |
|---|---|---|
| 20 minutes, inside a 60-minute panel of two branch managers | Recruiter's email | [grounded] |
| The panel scores against the four values | Recruiter's email | [grounded] |
| The role owns complaints "end to end across branches and the contact centre" and coaches "branch supervisors on escalations" | JD | [grounded] |
| Your own material for it: F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Fit snapshot F1 | [grounded] |
| Regulated complaints usually come with handling rules, such as time limits and a written response, that set a clock running | Role-family pattern; the actual rules depend on Ashgrove's regulator | [generic] |

**A structure for 20 minutes, said out loud:**
1. **Clarify** (2 min). What does the member want? Which channel did it come through? How long has it been open? Is it already a formal or regulated complaint?
2. **Member first** (4 min). What you would do for this member today. This is "Members First, Always" in action.
3. **Ownership** (4 min). Who keeps hold of it, and how the supervisor stays involved. This is "Own the Fix".
4. **Communication** (3 min). What you would tell the member and how you would put it. This is "Plain Words".
5. **Root cause and report** (4 min). Is this a one-off or a pattern, and where does it show up in the monthly report?
6. **Branch and town** (3 min). What this means for the branch's relationship with its community. This is "Neighbours, Not Numbers".

**Theses to choose from (each comes with the concession you must make):**

| # | Thesis | Mandatory concession | Provenance |
|---|---|---|---|
| T1 | Resolve the member's problem first and fix the process second, but do both | Sometimes the fix for the member has to wait for facts. Promising an outcome before you know it would break "Plain Words" | [grounded] values text |
| T2 | Escalation shouldn't mean handing off. The supervisor who found it stays involved until it's solved, with you supporting | Some complaints genuinely need to move up, for example when there's a regulated clock or a conflict of interest. Say where you'd draw that line | [grounded] "Own the Fix" text |
| T3 | Every escalation is a data point. Log it so the monthly report shows whether it's a pattern | One complaint isn't a trend, so don't over-engineer a process from a single case | [grounded] JD reporting line |

**Differentiation.** The answer most candidates give is "apologise, investigate, resolve, follow up". Give that, then go further in three ways. Use the panel's own value names at the matching step. Name the regulated clock as something to check, framed as a question, not a rule you recite (`[generic]`). Close the loop back to the branch supervisor and the monthly report.

**The anti-pick.** Be willing to say no to something: for example, no goodwill payment, and no promise that the outcome will change, before the facts are in. Then say how you'd explain that to the member in plain words.

**Close.** The recruiter didn't name a required close. End on what the member experiences next, and who owns it.

**Your own experience in the case.** Only F1's quote applies. If you bring it in, keep it to "I handled the branch's formal complaints log and trained new tellers on our escalation script," and don't add a remembered case to it unless it actually happened.

---

## Round 1: Recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly questions about your background and motivation | High. Recruiter screens open this way, and 30 minutes leaves little room for depth | Have a 90-second background arc built only from your four sentences (A1). Treat casual questions as scored |
| Skeptic (light) | Knock-out checks against the JD requirements | Medium. Recruiters screen against the requirements list, and F2 and F8 are gaps you've stated yourself | Short plain acknowledgment, then a one-line plan, then back to what you have done |
| Data-Driven Prober | "What's in the spreadsheet?" | Low. It only comes up if you mention the spreadsheet, and you should, because it's your best match to F3 | Know what it counts. Answer the slot honestly |

### A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, with the beats in the order your sentences give them. Six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log. You trained new tellers on the escalation script. You built the monthly complaints spreadsheet your regional manager uses. End with one sentence on why this role, and make it a reason that is actually yours. Say "branch supervisor", never "manager" | Every round opens with some version of this, and a tight arc sets up F1, F3 and F6. EXP because it fixes what you'll be held to all day |
| A2 | "What made you apply for this role?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Choose the one or two reasons that are genuinely yours. It lands best when it links something you did to a JD line, for example going from one branch's complaints log to the whole process. Only use that if it really is what draws you. If your reason is something else, say it plainly | Recruiters check that your motivation matches what you'll say to the manager later. VAL because it is scored on sincerity and fit, not content |
| A3 | "Why a credit union, and why Ashgrove?" | CO | [grounded] | Use their words. Mention that it's member-owned, cite "Members First, Always" by name, and mention the strategy's move to digital while app-only banks are the main pressure. Then give your own reason, in your own words. If you have none beyond what you've read, say what you read that drew you | Tests your homework. The grounding brief supplies the facts. No claim about your past is needed |
| A4 | "Tell me about the complaints work in your branch role." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Cover the log you handled, the tellers you trained on the script, and the spreadsheet your regional manager uses. Answer slot: the JD's regulated-complaints line makes a probe on whether these were regulated complaints likely. If they were, say which rules applied and what they required of you, in your own words. If not, or if you don't know, say so plainly and describe the log as you handled it | Covers F1 and F7 at screening depth. Primarily JD because it screens a stated requirement, with EXP delivery |

### B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre too, and I don't see that in your background. How would you handle it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't worked in a contact centre." Then a plan in one sentence: what you'd do first to learn how their complaints arrive and escalate, framed as a plan. Then go back to the log you handled. Keep it to 30 seconds and don't over-apologise | F2 is a stated gap and likely to come up as a knock-out check. A rehearsed short answer keeps it from looking bigger than it is |
| B2 | "The role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and to whom, in your own words. If you haven't, say so. Then give a one-line plan for how you'd prepare | F8 is the other stated gap. The JD lists it as a requirement, so a screen will check it |
| B3 | "Do you have the four-plus years in financial-services customer operations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | "Six years in retail banking, the last three as a branch supervisor." Stop there and let them map it | F6 has no gap. The risk is over-explaining, or relabelling your years in the JD's words |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You mentioned a monthly complaints spreadsheet. What's in it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built it, and your regional manager uses it. Answer slot: the JD asks about volumes and resolution times. If it tracks either, say how, in your own words. If it tracks neither, say plainly what it does track. Don't describe it as a report you present | F3 is your strongest match, and it's a discovery gap until you know what you'll say about it |
| C2 | "Is that in Excel? How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you built it in Excel, say what you built in it, in your own words. If you used another tool, name it plainly and stay with what you built. Never name a feature you don't use | F9 is a listed requirement. A confident true answer here is quick, and an inflated one is easy to test |

### Reverse questions (round 1)

| Question | Why it lands |
|---|---|
| "What format is the 20-minute case: a written scenario, a role-play, or a discussion?" | Recruiters can usually answer this, and the answer reshapes how you prepare for round 3 |
| "Will I know the panel's names before the day?" | Practical, and names let you prepare more precisely |
| "How does this role work with the contact centre day to day?" | Shows you've read the contact-centre line in the JD rather than hoping it won't come up |
| "What would make someone stand out in the manager's round?" | Gives you the recruiter's view of what the manager values most |
| "What happens after 21 November, and when would I hear?" | Logistics. Asking it shows you're organised |

---

## Round 2: Head of Member Services, your future manager (45 minutes, "mostly behavioural")

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" questions | High. The recruiter said "mostly behavioural", which outweighs the usual hiring-manager pattern | Before the day, pick real instances for each prompt in E. Use "we" for context and "I" for your contribution. Where no instance exists, use the honest branch |
| Skeptic | Probes the gaps between one branch and the whole process | Medium-high. A manager hiring for this scope has to reduce the risk of F1, F2 and F8 | D1 is rehearsed most deeply. Hold the position through two follow-ups using only what your quotes carry, then concede specifically |
| Case / Strategist | Live problems from the strategy | Medium-low. "Mostly" behavioural leaves room for one or two | Clarify, then structure, then answer, using their vocabulary. G1 and G2 |

### D — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've handled one branch's complaints log. This job owns complaints across every branch and the contact centre, and you've never worked in a contact centre. Why isn't that too big a step?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **This is the highest-ROI rehearsal in the pack.** Name the limit before they press it: "I haven't worked in a contact centre, and what I've handled is one branch's formal complaints log." Then hold with only what your quotes carry: you trained new tellers on the escalation script, and you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if that spreadsheet covers more than your branch, say so. If it covers only your branch, say that plainly. Then give a ramp plan, framed as a plan, for learning how the contact centre handles complaints. Expect two follow-ups. The first will be "What would be new to you?" Answer that plainly: the contact centre's process, which you haven't seen yet. The second will be "So what would you do in your first 90 days?" Answer with the plan. Hold by coming back to the log and the spreadsheet, never by adding to them | This objection comes from the F1 and F2 gaps together, and a manager will raise it in some form. JD because it scores the role's central requirement. It has the most follow-up levels and the most exact concession wording of any question in the pack |
| D2 | "Which part of this JD would you find hardest on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of the gaps you've stated, not a made-up weakness. Presenting is the more relevant one for this manager, because the monthly reporting goes upward. "I haven't presented to anyone above regional level." Then say how you'd prepare, framed as a plan | F8 shows up directly in this manager's world. Picking a real gap and having a plan for it scores as honest self-assessment |
| D3 | "How have you coached people on escalations?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what your sentence says: "I trained new tellers on our escalation script." Answer slot: the JD asks about coaching branch supervisors. If you've coached fellow supervisors, or anyone besides new tellers, say who and how. If you haven't, say so plainly and describe how you'd approach coaching supervisors, framed as a plan. Don't say you wrote the script | F4 is a transferability gap. The verb ("trained" against "coach") and the audience ("tellers" against "supervisors") are where inflation tempts most |

### E — Values / Behavioral (manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a member complaint escalated and you had to handle it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your material names the log, but it doesn't describe a specific case, so pick one. It needs the member's issue, what you did, how it ended, and anything you changed afterwards. If no such case comes to mind, say so plainly, then describe how you handled the log, or how you would handle such a case | The core of the job, asked behaviourally. Primarily VAL because the manager scores what you did, with EXP close behind |
| E2 | "Tell me about a time you used data to change something." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: the JD's monthly-reporting line makes this likely. If the spreadsheet led to a change, say what it was and what part of it was yours, in your own words. If it didn't, or you don't know, say so plainly. Then say what it's used for, or give another time data changed something | F3 tested behaviourally. Don't assume the spreadsheet had an impact unless you know it did |
| E3 | "Tell me about a time you had to deliver an unwelcome truth to someone more senior." | VAL | [generic] | Pick a real time. It needs a named stake, a moment you didn't back down, and a working relationship that stayed intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | A standard behavioural stem. It matters here because the role reports complaints upward (F8) |
| E4 | "Tell me about a time you made something easier for a member to understand." | VAL | [grounded] | The theme comes from "Plain Words". Pick a time you explained or reworded something for a member. It needs what was unclear, what you changed, and how you knew it worked. If no such time comes to mind, say so plainly, then say how you would approach it | Your manager may test the values too. "Plain Words" also connects to self-service journeys (F5) |
| E5 | "Tell me about a time you worked with another team, or with a digital tool, to make something easier for members." | JD | [grounded] | Answer slot: if you've worked with a digital team, or on an online or app journey, say what you did, in your own words. If you haven't, say so plainly. Then give another cross-team instance if you have one, or say how you'd approach working with digital teams | F5 has no evidence yet, so a rehearsed honest answer is needed. JD because it's a stated responsibility, asked behaviourally |

### G — Case / Strategist (manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "We're moving 40% of member service to digital by 2028. What does that do to complaints, and what would you set up?" | CO | [grounded] | Start by clarifying which journeys move first. Then cover what changes: complaints may arrive through new channels and be about the digital journey itself. Say what you'd set up, for example tagging complaints by channel in the monthly report and sending journey complaints back to the digital teams. Name the risk: members who don't use digital, which is where "Members First" applies. This is a live problem, so it needs no claim about your past | The strategy brief's headline target meets the JD's digital line. CO content with CASE delivery |
| G2 | "If the monthly complaints report went to senior leaders, what would you put on page one?" | CASE | [grounded] | Volumes and resolution times (the JD's own words), the trend, the top causes, what's being fixed and by whom ("Own the Fix"), and one decision you need from them. Don't describe your current spreadsheet's layout unless you're asked | Covers F3 and F8 together: reporting and senior audiences. CASE because it's scored on structure |

### Reverse questions (round 2)

| Question | Why it lands |
|---|---|
| "At six months, what would you want the monthly complaints report to be telling you?" | Gets the manager to define success, and shows you're thinking about the reporting line |
| "Where do complaints get stuck between branches and the contact centre today?" | Shows you know the role spans both, and tells you where the real work is |
| "With 40% of service moving to digital by 2028, how do you see digital complaints reaching this role?" | Ties the role to their own strategy |
| "As branches consolidate into hubs over 2027, what do you expect to happen to complaint patterns?" | Strategy-level thinking about the job you'd be doing |
| "Who sees the monthly report beyond you, and how would I be presenting it?" | Faces the F8 gap honestly and shows you want to prepare for it |

---

## Round 3: Panel of two branch managers (60 minutes, values round plus 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One question for each value, scored against the four values | High. The recruiter said the panel "score against the four values" | Use the cheat sheet below. Name the value aloud when your story shows it |
| Case / Strategist | The 20-minute escalation case, plus possible branch scenarios | High for the case itself, which is announced, and medium for anything else | Use the graded-deliverable build above. Clarify before you structure |
| Peer Evaluator | "What would you need from us?" and "Will you add to our supervisors' load?" | Medium. The supervisors you'd coach work in branches like theirs | Frame it as what you bring them, not only what you need. Propose principles for how you'd work together instead of claiming to know how they work |

### H — Values / Behavioral (panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter, even when that was harder for the branch." | VAL | [grounded] | "Members First, Always." Pick a time when the member's interest cost the branch something, such as time, effort or a target. It needs the trade-off, your decision and what happened. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would decide | One question per published value, because the panel scores all four |
| H2 | "Tell me about a time something had to be explained to a member twice. What did you change?" | VAL | [grounded] | "Plain Words." Pick a time something wasn't understood the first time. It needs what was unclear, what you changed and whether it worked. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | The value's own wording, "explained twice", turned into a prompt |
| H3 | "Tell me about a time knowing a member, or your local community, changed how you handled something." | VAL | [grounded] | "Neighbours, Not Numbers." Pick a time local knowledge mattered. It needs what you knew, what you did differently and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | Branch managers will weigh this value heavily, and it's sensitive while hubs are planned |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "Own the Fix." Answer slot: if building that spreadsheet began with a problem you found, tell that story in your own words. If it didn't, don't present it as one: pick another time you kept hold of a problem. It needs what you found, how you kept hold of it and how it was solved. If no such time comes to mind, say so plainly and say how you would handle it | The value closest to this job's "end to end" mandate. The slot stops the spreadsheet from being given a backstory it may not have |
| H5 | "Our values say whoever finds the problem keeps hold of it. So when a supervisor escalates a complaint to you, who owns it?" | CASE | [grounded] | A live tension between "Own the Fix" and escalation. Hold a principle: the member has one owner at a time, and handing it on is a deliberate step, not a drop. The supervisor stays involved, you add support or authority, and you say who the member hears from. Be willing to concede that some cases have to move up | Tests whether you can apply their values rather than recite them. Primarily CASE, with VAL delivery |

### I — Case / Strategist (panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "A long-standing member has complained twice at their branch about a fee and now wants to see the manager. The supervisor wants to pass it to you. Walk us through it." | CASE | [generic] | This is an illustrative stand-in for the announced case. Run the six-step structure in the graded-deliverable section, choose a thesis from T1 to T3, and make its concession. Check whether it's now a formal or regulated complaint, framed as a question. No claim about your past is needed | The announced 20-minute case. Generic because the real scenario isn't known. Rehearse the structure, not this exact scenario |
| I2 | "A branch is consolidating into a hub next year. A member complains they're losing their local branch. How do you handle it?" | CO | [grounded] | Start with the member: listen, and explain plainly what changes and what doesn't. Cover who owns the follow-up, and log it as part of a pattern the monthly report should show during consolidation. Show you're aware of "Neighbours, Not Numbers" without giving opinions on the hub plan | The strategy brief's 2027 consolidation meets the panel's own world. CO with CASE delivery |
| I3 | "We launch small-business lending in Q1 2027. What would you want in place for complaints before launch?" | CO | [grounded] | Cover complaint categories for the new product, who handles which kind, a briefing for branch supervisors on escalation, and close monitoring in the early weeks through the monthly report. Don't claim lending experience | A new product is a near-term source of complaints. Tests whether you can think ahead at the company's level |

### J — Peer Evaluator (panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You'd be coaching our supervisors on escalations. What would you need from us, and what happens when we disagree?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | You've been a branch supervisor for the last three years, so you know the job from inside a branch. Offer what you bring, for example each branch's own complaint data. Then say what you'd need, such as time with supervisors. For disagreements, propose a principle: the member's outcome decides. Never claim to know how their branches work | F4 seen from the branch managers' side. They're judging whether you'll lighten their supervisors' load or add to it |
| J2 | "Our supervisors already have their own way of doing escalations. How would you avoid just adding another process?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start by listening: learn what they do now before changing it. Your sentence says you trained new tellers on an escalation script, so you know what using one looks like. Don't say you wrote one. Propose shared principles first and a process second | Tests how you'd fit in with branch teams. F4 approached from the side of the people being coached |

### Values cheat sheet (round 3)

The value names and wording come from your pasted copy of ashgrovecu.org/about/values (12 November 2026).

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's point of view | Selection scaffold, H1. None of your four sentences describes an instance. Pick a real one. If none comes to mind, say so plainly and say how you would decide |
| Plain Words | If it needs explaining twice, rewrite it | Selection scaffold, H2. None of your sentences carries a story here. Pick a real one, or use the honest branch |
| Neighbours, Not Numbers | Each branch belongs to its town | Selection scaffold, H3. None of your sentences carries a story here. Pick a real one, or use the honest branch |
| Own the Fix | Whoever finds a problem keeps it until it's solved | F3, "I built the monthly complaints spreadsheet our regional manager uses." This is your nearest material, but it's only a story if it began with a problem you found (the slot in H4). Otherwise, pick another real instance or use the honest branch |

### Reverse questions (round 3)

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would genuinely help your supervisors?" | A reciprocity question, which fits a panel of future peers |
| "When an escalation goes wrong in a branch today, where does it usually go wrong?" | Gets real problems on the table and shows you'd listen first |
| "As the hub plan rolls out, how are you thinking about keeping each town's connection?" | Ties "Neighbours, Not Numbers" to the strategy. Ask with curiosity and don't share an opinion, because the change may affect them |
| "Which of the four values is hardest to live by on a busy day in a branch?" | Shows you take the values seriously, and their answer tells you about the culture |
| "What would you want from the monthly complaints report that you don't get today?" | Makes the report useful to branches, not only to senior leaders |

---

## Prohibited claims

This pack won't coach you towards any of the claims below, under any interviewer pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process, or ran it across branches | Inflated form of F1 | F1's quote at its own scope. The pack's observation is that your material describes one branch's log, not a process across branches. The slots in D1 and A4 stay within that log |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote: "trained new tellers on our escalation script." The slot in D3 asks only about whom you trained |
| Wrote or designed the escalation script | Inflated form of F4 | The quote says "our escalation script" and doesn't say who wrote it. Keep to the training |
| Reported on, or presented, complaint volumes and resolution times | Inflated form of F3 | F3's quote: "I built the monthly complaints spreadsheet our regional manager uses." The slot in C1 asks only what it tracks |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: a formal complaints log. The slot in A4 asks which rules applied, if any |
| Advanced Excel skills | Inflated form of F9 | F9's quote: a spreadsheet you built. The slot in C2 asks which tool and what you built |
| Managed a branch | Inflated form of F6 | F6's quote: "the last 3 as a branch supervisor." The panel are branch managers and will know the difference |
| Contact-centre experience | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F8 | "I haven't presented to anyone above regional level." The slot in B2 covers regional level only |

---

## Sources

- **Provided documents:**
  - The JD text
  - The values text you pasted, copied on 12 November 2026 from ashgrovecu.org/about/values. That page wasn't fetched; the pasted copy is the source
  - The recruiter's email about the three rounds
  - The four points from Ashgrove's July 2026 strategy brief, as summarised in your message
  - Your background, in your own words
- **Searches and fetches:** none were sent.
- **Dossier:** none was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | Your pasted copy from this morning already supplies all four value names and their wording for the cheat sheet and bank H |
| 2. Ashgrove Credit Union interview process, member services | skipped | The recruiter's email sets out all three rounds, who runs each, the case and the values scoring, so it fixes the persona weights and the loop structure |
| 3. Ashgrove Credit Union strategy and recent news | skipped | The July 2026 brief is under six months old and supplies the priorities for G1, I2, I3 and the grounding brief |
| 4. Interviewer names | n/a | No names have been assigned, so there was nothing to search for. The interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD |

---

## Upgrade menu

- **Interviewer names, once assigned:** a reading of each interviewer from their public professional profile, persona weights for each person, and at least one reverse question tied to each person's career path.
- **Your prep time before 21 November:** a prioritised schedule built around D1, the case build and the H bank. Without it, the pack gives no schedule.
- **The full strategy brief text:** a richer grounding brief and more specific CO questions. This pack uses only the four points in your message.
- **The case format from the recruiter (written brief, role-play or discussion):** the case build and I1 tuned to the real format. This is round 1's first reverse question, or a one-line email.
- **Your answers to the answer slots, said outside a drill:** what the spreadsheet tracks (F3, C1, E2, H4), whether the log covered regulated complaints (F7, A4), which tool you used (F9, C2), and any digital or self-service work (F5, E5). Each answer becomes quoted evidence, and those rows and questions get regenerated with it.
- **A redacted template of your monthly complaints spreadsheet, with no member data:** the inspectable artifact that would move F3 and F9 from medium to high confidence.
- **A CV:** fit rows quoting your CV lines alongside your message.
- **Deeper research (L2), up to 6 more searches and 2 more fetches, several more minutes:** Ashgrove's published complaints procedure, if it has one, plus recent organisation news. This would sharpen the case build and I2.
- **A tuesday-dossier.md from a job-underwriter run:** an evidence-derived main objection and a prohibited-claims list confirmed with you, instead of one built here. It isn't required.
