Quick status: I've loaded the mock-interview playbook and its rules. Next I'll run a few targeted searches (Northwind's values, its interview process, and Dan's public profile), then write the pack.
Web search was refused by permissions, so I won't retry it. The pack will rest on your notes, and the Sources section records the three refused searches. Writing the pack now.
I've built Priya's prep pack: **Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md**. I built it for one 60-minute **peer** conversation with Dan, using only your notes. The web searches (Northwind's values and interview process, Dan's public profile) were refused by permissions. So nothing in the pack about Dan or Northwind's strategy has been checked against an outside source.

- **What's in it:** 23 questions across seven interviewer personas, weighted for Dan. A data-driven prober and a peer focused on where his team and hers divide the work come first. The live-case questions lean toward pricing and monetization, since that's his background.
- **Each row** gives the question, its type (behavioral, experience, JD, company, case), what it rests on, answer guidance and why it's included and tagged that way.
- **Also included:** a table matching Priya's evidence to each JD highlight, a read on Dan, a JD coverage table, six questions for Priya to ask Dan, and a list of claims she shouldn't make.
- **Most important question: D1.** "You haven't done classic sales-ops or quota-setting, and I run sales strategy. Why you?" It has the deepest rehearsal: open with the gap, then what she has done in its original wording, then a ramp plan, then three likely follow-ups.
- **No values section.** Nothing shows a values-focused round, and Northwind's published values weren't retrieved. The two behavioral questions use general prompts instead.
- **Guardrails worth reinforcing with her:**
  - She "proposed" the store change and it was "credited with" the ~$400M; she didn't drive it.
  - She built a revenue model that was used in carrier negotiations; she didn't design a partner programme.
  - Her volume targets are never called quotas.

I can run a live drill as Dan on D1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full JD text and Priya's actual CV? Mid-list requirements would get their own questions, and several answer slots would become specific story guidance.
Has the recruiter said what Dan will focus on, or asked Priya to prepare anything, like a case or a point of view?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. He is a **peer**: both would report to the same VP.
**Format:** one 60-minute conversation (from the coach's notes)

---

## 1. How to use this pack

Two axes organize every question:

- **Persona** is *how* a question arrives: who is asking, and in what register. The banks are grouped by persona and ordered by weight.
- **Type** is *what* is being scored. Every question has a type tag, with the primary tag first.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows specific values, not generic virtue |
| EXP | Work-experience deep-dive | Whether the background claims survive scrutiny, and what was actually Priya's |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company & strategy | Homework depth: can she think at Northwind's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the actual role |

**How to read a row:**

- Provenance shows what each row stands on. `[grounded]` rests on what you gave me, `[inferred]` is a derivation (named in the row), and `[generic]` is a role-family pattern with no claim about Priya or Northwind.
- Quoted sentences in a Provenance cell are the only things the guidance says about Priya's past.
- An **answer slot** marks a place where only Priya can supply the detail, in her own words. The pack does not fill it in for her.

**Guidance is scaffolding, not a script.** Every guidance cell should be speakable in about two minutes.

Question IDs run A, B, C, D, E, G, H by persona. The letter F is skipped so that question IDs never collide with fit-snapshot rows (F1–F7).

---

## 4. Fit snapshot

Requirements are quoted from the JD highlights in your message. Evidence is quoted from your notes on Priya, so every evidence cell's origin is "the coach's notes".

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes; "then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material shows a proposed change and its credited result, plus product strategy & ops at a consumer-tech company. It does not show GTM ownership of new product lines, and the words stay at that scope: "I proposed a store-surface change that was credited with roughly $400M in ARR uplift." Answer slot: the JD's new-product-lines line makes a probe on launching something new likely. If any of that work took a new product to market, say what part was yours, in your own words. If none did, say so plainly and stay with the change you proposed |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Your material does not show whitespace analysis across a customer lifecycle. Answer slot: if any of Priya's work segmented customers or partners to find untapped revenue, she should say what it was, in her own words. If none did, she says so and walks through how she would do it (rehearsed as C3 and A4) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but it is a stated skill with nothing inspected behind it, so expect a probe on how hands-on she is (A5). Lead with the skill in the quote's own terms |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material says she built a revenue model that negotiations used. It does not say she designed a partner motion or ran the negotiations. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: given "required" in the JD, expect a probe on what the model shaped. If parts of the carrier relationship were yours to set, say which, in your own words. If none were, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | presentation | Both quotes already describe working across orgs. Say it in their terms: "I set annual volume targets with cross-org consensus, and I proposed a store-surface change that was credited with roughly $400M in ARR uplift." Nothing is added about how consensus was reached |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Derivation: daily use of AI tools touches the "AI experience" line without showing whether it reaches AI product or GTM work. Answer slot: if any of her work involved building, launching or selling an AI product, she says what, in her own words. If not, she says plainly that her AI experience is as a daily user and describes how she uses the tools |
| F7 | Sales-ops and quota-setting familiarity. This is a role-family expectation inferred from the land/adopt/expand/renew line and from Dan's sales-strategy remit. It is not a JD line | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A stated gap that wording cannot close. Words: "I haven't done classic sales-ops or quota-setting work." Then a ramp plan, said as a plan and never as a past. Never call the volume targets in F5 quotas |

**The seam Dan will press:** F7, together with F1's consumer-tech context. He runs sales strategy, and Priya would be the peer without a sales-ops background. That is the objection this pack rehearses deepest (D1).

---

## 7. Reading the interviewer

Everything below comes from the coach's notes on Dan's profile. The web search that would have checked it was refused (see Sources), so nothing here comes from research.

| Signal (from the coach's notes) | Practical implication |
|---|---|
| Self-described "relentlessly data-driven" | Every number Priya says will be probed down to how it was counted. She should name her least-defensible assumption before he finds it (A1, A3, E1) |
| "career spine is pricing and monetization roles" | Case questions tilt toward packaging, pricing and unit economics. That is his native language, so C1 and C4 are framed that way |
| "one early-stage-startup chapter" | Expect a probe on big-company pace and scrappiness (D3). Builder stories land well, but only ones Priya can tell from her own experience |
| "would be Priya's PEER, both reporting to the same VP" | He is pricing what her hire costs and adds to *his* work: the seam, his team's load, credit-sharing (bank B). He may also be weighing an internal alternative (E2) |

**Mirror opportunity (shared vocabulary, not a shared jump):** Dan's monetization background and F4's quote, "built a partner-level revenue model used in carrier negotiations", share the language of revenue modeling. If he asks about A2, she can go into the model's mechanics in his terms. No row of the fit snapshot carries a career jump that parallels his startup chapter, so none is offered.

---

## 8. Persona table

The weights are reasoned in three passes:

1. **Relationship prior.** A peer round puts Peer Evaluator and Data-Driven Prober on top.
2. **Interviewer signals.** "Relentlessly data-driven" pushes the Prober up. The pricing and monetization spine tilts the Case bank toward pricing. The startup chapter raises the Skeptic's scrappiness and pace probes.
3. **The loop.** Your notes establish one 60-minute conversation with Dan, so there is no fallback archetype and no loop tilt. No values-style round is detected, and the Values persona stays low.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Data-Driven Prober | "How was that counted?" and two follow-ups deeper on every figure and model | **Highest.** The peer prior plus his self-description | Know what she can and cannot say about how each figure was counted, and say so when she doesn't know. Name the weakest assumption first. Offer to walk an analysis end to end if it was hers | A (5) |
| Peer Evaluator | "Where's our seam?", "What do you need from me?", credit-sharing | **Highest, tied.** The peer prior, same VP | Reciprocity first: what she brings his team. Propose seam *principles* rather than guessing the org chart | B (5) |
| Case / Strategist | Live problems: pricing Compass, the bundling threat, whitespace | **High.** The pricing spine tilts cases to monetization, and Northwind's stated priorities supply the material | Clarify, then objective, segmentation, approach, metrics, risks. State the hypothesis early and challenge one premise per case | C (4) |
| Skeptic | Quiet probing of the consumer-tech-to-B2B move and the F7 gap; "why now" | **Medium.** A sales-strategy peer will see F7 immediately; the startup chapter adds pace probes | Rehearse D1 until it's boring. Give the plain acknowledgment, the adjacent quotes at their own scope, and a concrete ramp plan | D (3) |
| Pressure | "How much of that was actually you?", "60 seconds: why you?" | **Low to medium.** It is not his register by default, but a data-driven peer may press hard on attribution | Pause, restate, anchor in what was stated. Hold through two follow-ups, then concede specifically | E (2) |
| Conversational | The opener, and casual AI chat | **Low.** It is the first five minutes, but still scored | A pre-scripted 90-second arc. Treat casual AI questions as scored (the JD lists AI as a plus) | G (2) |
| Values / Behavioral | An occasional "tell me about a time" | **Low.** No values round is detected, and Northwind's values were not retrieved | Selection scaffolds with honest branches; "we" for context, "I" for contribution | H (2) |

---

## 9. Question banks

### A. Data-Driven Prober (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through that ~$400M ARR uplift from the store-surface change. How was that number counted?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start with the beats the quote gives: you proposed the change, and it was credited with roughly $400M in ARR uplift. Keep both verbs: "proposed" and "was credited with", never "I drove $400M". Then the four defend-the-number slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least (name it before he does), and which part was yours. If you don't know how it was counted, say so plainly and say who credited it, if you know | F1's headline figure is exactly what a self-described data-driven interviewer probes first. EXP because it tests attribution and counting, not the role |
| A2 | "You built a partner-level revenue model for carrier negotiations. Walk me through it: what went in, what came out, and which assumption you'd defend least." | EXP, JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats: you built the model, it worked at partner level, and it was used in carrier negotiations. Walk it end to end in your own words. Name the weakest assumption yourself. Answer slot: keep the line between building the model and the negotiations it was used in. If any part of the negotiations was yours, say which; if none was, say so plainly and stay with the model. This is where his monetization vocabulary and yours can meet | F4 is the only evidence for a "required" JD line, so Dan will test how deep it goes. EXP primary because it tests an artifact; JD second because it is the partner-motion requirement's best support |
| A3 | "How did you set the annual volume targets, and how did you know whether they were right?" | EXP, JD | [grounded] "set annual volume targets with cross-org consensus" | The beats: you set annual volume targets, with cross-org consensus. Answer slot for the method: describe it in your own words, and if the targets came more from negotiation than formula, say so. Answer slot for "were they right": if you tracked how they held up, say how; if there was no such check, or it wasn't yours, say so plainly. Call them volume targets, never quotas. Dan will notice the difference, and F7 says she hasn't done quota-setting | F5's evidence sits right next to Dan's own world (target-setting), so he will price it against quota work. Tagged JD for the cross-functional-influence line |
| A4 | "If I gave you our product-usage and bookings tables, how would you find expansion whitespace for the new lines in the installed base?" | CASE, JD | [generic] | Clarify first: the account hierarchy, what counts as "adopted", and contract versus usage timing. Then the approach: join usage to contract data; segment accounts by product penetration, usage depth and size; flag accounts that are heavy on the core product with no new-line footprint, or that are near renewal with rising usage; check the list with sellers before trusting it. Close with the Tableau view both teams would use. The question asks about no past, so the guidance makes no claim about one | Tests F2 and F3 together as a live problem. CASE because it is delivered as one; JD because both requirements are named in the JD; `[generic]` because it is a pattern, not Northwind's data model |
| A5 | "How hands-on are you in SQL today? When did you last write a query yourself, and what did it answer?" | JD, EXP | [grounded] "skilled in SQL/Tableau" | Lead in the quote's terms: skilled in SQL and Tableau. Answer slot: give the most recent query you wrote and what it answered, in your own words. If your recent work has been more reviewing than writing, say so plainly. A peer is asking whether you will borrow his analysts | F3 is a stated skill with nothing inspected behind it, and "independent analysis" is a JD line. JD primary; EXP because it verifies a background claim |

### B. Peer Evaluator (highest weight, tied)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. I own sales strategy, and you'd own GTM for the new lines. Where's the seam, and what happens when we disagree?" | JD, CASE | [generic] | Propose principles; don't claim to know the org chart. For example: the core motion's planning is his; the new lines' GTM is yours; how new lines show up in sellers' plans and credit is shared, and agreed jointly. For disagreement: agree on the numbers before arguing the conclusion, write one shared doc, and escalate to the VP together, not separately. End with a question back to him: where does pricing for new lines sit today? | The peer prior's signature question, aimed at F1's ownership scope and F5's influence line. JD because it scores the GTM-ownership requirement; CASE because the answer is a design |
| B2 | "What would you need from my team in your first 90 days, and what would you bring us?" | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Lead with reciprocity. What you bring, in the quotes' terms: you are skilled in SQL and Tableau, and you built a partner-level revenue model used in carrier negotiations. Let him draw the inference that you can run your own analysis. What you need: access to bookings and pipeline data, the current segmentation, and an explanation of how sellers are credited on new products. Ask about these; don't assume | Tests whether the hire reduces Dan's load, and the cross-functional line (F5). F3 and F4 are the evidence it draws on |
| B3 | "Tell me about a time you disagreed with a peer in another org and still got to a decision." | VAL, EXP | [grounded] "set annual volume targets with cross-org consensus" | A possible story: the volume targets, set with cross-org consensus. Answer slot: if a peer in another org disagreed along the way, say what the disagreement was, what part of resolving it was yours, and how it ended, in your own words. If there was no disagreement on that one, say so and pick another time. It needs a named stake, a moment you held a view, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt from the Peer persona's stem (disagreement with equals). VAL for behavior, EXP because F5 is the likeliest candidate story |
| B4 | "How do you handle credit when work spans teams, like the store-surface change?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the quote's attribution: you proposed it, and it was credited with the uplift. Answer slot: name who else made it happen and what each did, in your own words. "We" for the delivery, "I" for the proposal. Never claim the build or the launch unless they were yours | A peer is asking how she will share credit with *his* team. It reuses F1's figure in a collegial register. EXP because it tests attribution |
| B5 | "How would you design the partner motion for a new product line without creating channel conflict with my direct sellers?" | CASE, JD | [generic] | Structure: which partner types fit (resellers, SIs, tech alliances, marketplaces), and what role partners play at each stage of land/adopt/expand/renew. Rules of engagement: deal registration and comp neutrality for direct sellers. Economics: margin, discounts, co-sell incentives (his pricing language). Metrics: partner-sourced versus partner-influenced. Risk: conflict over the same logo. This is a design question, so make no claim about past design work | F4's "required" line asked as a live problem, from the seat whose sellers the motion touches. CASE delivery; JD content |

### C. Case / Strategist (high weight, pricing tilt)

The Northwind facts in these questions come from your research note: three priorities (enterprise expansion, the Compass AI copilot launch, reaching profitability) and the main threat (bundling by a much larger platform vendor). Its date is unknown; see Sources.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching while a much bigger vendor can bundle against us. How would you package and price it?" | CASE, CO | [grounded] | Clarify: who buys it, whether it ships standalone or as an add-on, and what it costs to serve. Objective: is it a revenue line, an expansion lever, or a defense of the core? Tie that to the profitability priority. Options: included in a premium tier (defends against the bundle), a paid add-on per seat, or usage-based (protects margin on inference cost). Metrics: attach rate, active use per account, gross margin. Challenge one premise: maybe Compass should be priced as a retention tool, not a P&L line | Grounded in two stated priorities and the stated threat, in Dan's native pricing language. CASE delivery; CO because it tests strategy fluency. Also touches F6 |
| C2 | "The platform vendor bundles a 'good-enough' version of one of our new lines for free. What's the GTM response?" | CASE, CO | [grounded] | Segment where "good-enough" wins (small, price-sensitive) and where it loses (enterprise needs depth, governance, scale). Don't race to zero, because profitability is a stated priority. Concentrate on segments where the bundle is weak. Land with a narrow wedge and expand on proven value. Consider whether partners make you the neutral option. Name the metric that would tell you you're losing: win/loss in your target segment, not overall | The note names bundling as the main threat, so a candidate who cannot discuss it fails the CO bar. CASE because it is live |
| C3 | "Enterprise expansion is a top priority. Where would you look first for whitespace for the two new lines across land/adopt/expand/renew?" | JD, CASE, CO | [grounded] | State a hypothesis early (for example, that expansion into existing enterprise accounts beats new logos for new lines). Then go stage by stage. Land: which personas and entry use cases. Adopt: activation signals. Expand: cross-sell triggers from core usage. Renew: bundling new lines into renewals as defense. Say what data you'd pull first (A4) and what you'd test with sellers | The F2 requirement, asked through the enterprise-expansion priority. JD primary because it is the literal JD line; CASE and CO for the delivery and the grounding |
| C4 | "We need to reach profitability. Which GTM investment for the new lines would you cut or defer, and how would you prove it's the right one?" | CO, CASE | [grounded] | Show you can say no. Rank investments by payback (CAC payback, contribution margin, time to first expansion). Defer what depends on a segment the bundle already owns. Keep what drives expansion in accounts you already have. Prove it with a holdout or a staged rollout, and name what would change your mind | The profitability priority plus Dan's unit-economics lens; tests judgment, not just growth instinct. CO primary |

### D. Skeptic (medium weight; holds the highest-ROI question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | **Highest-ROI prep in this pack.** "Your background is product strategy at a consumer-tech company, and you haven't done classic sales-ops or quota-setting. I run sales strategy. Why are you the right person for GTM here?" | JD | [grounded] "then 9 at a large consumer-tech company in product strategy & ops"; "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | **Beat 1, the plain acknowledgment, first and unprompted:** "I haven't done classic sales-ops or quota-setting work." **Beat 2, what is there, at its own scope:** nine years in product strategy & ops at a large consumer-tech company; you built a partner-level revenue model used in carrier negotiations; you set annual volume targets with cross-org consensus. Say these and let him connect them to the JD. Don't tell him they are equivalent to his work. **Beat 3, the ramp plan, said as a plan:** learn Northwind's capacity and quota model from his team in the first month, and bring independent analysis in return. **Follow-up 1:** "Volume targets are basically quotas, no?" Hold: "They were annual volume targets, set with cross-org consensus. I wouldn't call them quotas." Answer slot: what the targets were tied to, in your own words; if you don't know, say so. **Follow-up 2:** "So you'd learn B2B on our dime?" Answer slot: if you've worked on B2B or enterprise motions, say where; if not, say so plainly and return to beat 3. **Follow-up 3:** "How long until you're useful?" Give a concrete 30/60/90, as a plan. Concede the specific gap; never fold on what the quotes carry | F7 is the most predictable objection, coming from the one interviewer who owns that competency, and F1's consumer-tech context sharpens it. Deepest rehearsal because it will be asked in some form. JD because it scores fit to the role's GTM remit |
| D2 | "What's the part of this JD you'd be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Pick a real one. F4 is the natural candidate: the JD says "required", and your material has the model, not the design of a motion. Words: "The closest I've come is building a partner-level revenue model that was used in carrier negotiations." Answer slot: if the model shaped any terms of the carrier relationship, say which, and what part was yours; if it didn't, say so. Then say how you would close the gap: what you'd learn and from whom | A Skeptic stem. F4 is the thinnest bridge to a "required" line. JD because it scores self-assessment against the listed job |
| D3 | "Why leave a large consumer-tech company after nine years for a 3,000-person B2B data company, and why now?" | CO, EXP | [grounded] "then 9 at a large consumer-tech company in product strategy & ops" | Answer slot: the real reasons, in your own words; they need to be consistent with everything else you say. Why here: connect to what Northwind has stated (two new product lines, Compass, enterprise expansion). Expect his startup chapter to surface as "will a big-company pace survive here?" Answer slot: if you've worked on something scrappy, small-team or 0→1, say what; if not, say so and say how you'd work at this pace | Motivation consistency is the Skeptic's core test, and F1's long tenure invites it. CO because "why here" scores homework; EXP because it is about her history |

### E. Pressure (low-to-medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause first. **Hold:** "I proposed the change, and it was credited with roughly $400M in ARR uplift." **Follow-up:** "But who built it?" Answer slot: name who built and launched it, in your own words. **Concede specifically:** what wasn't yours. Don't fold: if the proposal was yours, it stays yours, and don't retreat to "it was all the team" to restore harmony | The persona's own stem, aimed at F1's headline figure. A data-driven peer may deliver A1's follow-up this way. EXP because it tests attribution |
| E2 | "Sixty seconds: why you over an internal sales-strategy person who already knows our quota model?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Time-box: about 45 seconds. Concede up front: "They'd know your quota model; I haven't done quota-setting work." Then hold on what's there: skilled in SQL and Tableau; you built a partner-level revenue model used in carrier negotiations. Then the role as written: GTM for two new lines and partner motions, not the core quota model. Hold through one push, then stop | F7 delivered at pressure tempo by the person who may have an internal name in mind. JD because it scores fit |

### G. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy & ops. Answer slot: the thread connecting them and why GTM for emerging products now, in your own words. Land it on Northwind's new lines. End early and let him pull | The opener is scored on economy. It draws on F1's tenure. EXP because it previews which stories he'll dig into |
| G2 | "What are you actually doing with AI these days?" | JD | [inferred] "uses AI tools daily" | Derivation: F6 is a daily-user signal, not AI product work. Answer slot: which tools you use daily and for what, in your own words. Don't stretch it into AI product or GTM experience. Then pivot to a view on Compass: questions you'd want answered about how buyers evaluate a copilot. That is a point of view, not a past | The JD lists AI as a plus, and casual-register questions on plus-skills are still scored. JD because it tests a listed line; `[inferred]` because F6 is `low` |

### H. Values / Behavioral (low weight)

No values-style round was detected, and Northwind's published values were not retrieved, so these use generic persona stems.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told senior people something they didn't want to hear. It needs the stake, what you said, how it was received, and what happened next. "We" for context, "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peers check whether a new seat will tell the VP hard truths, including about shared work. VAL; `[generic]` because no quote carries the story |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where a customer or partner outcome won over a number you owned. It needs the metric, the trade-off, who disagreed, and the result. Dan's monetization background will ask what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A monetization-minded peer tests whether she would trade customer trust for short-term revenue. VAL; `[generic]` for the same reason as H1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 "own GTM strategy for two new product lines" | B1, D1, C3, G1 |
| F2 "identify whitespace across land/adopt/expand/renew" | C3, A4 |
| F3 "run independent analysis in SQL and Tableau" | A5, A4, B2 |
| F4 "partner-motion design experience required" | A2, B5, D2 |
| F5 "strong cross-functional influence" | B2, B1, B3, A3, B4 |
| F6 "AI experience a plus" | G2, C1 |
| F7 sales-ops / quota-setting (role-family, not a JD line) | D1, E2, A3 |
| Northwind priorities and threat (research note) | C1, C2, C3, C4, D3 |
| Mid-list JD lines | none, because only highlights were supplied; the full JD would surface them (upgrade menu) |

Totals: 23 questions (A 5, B 5, C 4, D 3, E 2, G 2, H 2).

---

## 11. Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "Your background is in pricing and monetization. How do you expect packaging and pricing for the new lines and Compass to be decided between your team and this seat?" | Tied to his path, and it surfaces the most likely seam before it becomes turf |
| R2 | "You've worked at an early-stage startup. What from that do you find yourself bringing to launching new things inside a company this size?" | Tied to his path; it turns the pace probe (D3) into a peer conversation |
| R3 | "What could a new person in this seat do in the first month that would genuinely help your team?" | The reciprocity question: it signals she is there to reduce his load |
| R4 | "How are sellers credited on the new product lines today? Is that settled, or is it something this role works out with you?" | It shows she understands where new-product GTM fails, and it tells her what she is inheriting |
| R5 | "Where does the bundling threat show up first in your data: win/loss, renewals, or pricing pressure?" | Data-first, in his register, grounded in the stated threat; his answer also preps C2 |
| R6 | "A year from now, what would make you say this hire made your job easier?" | It gets his success criteria in his words, and it is the question peers remember |

---

## 13. Prohibited claims

These are claims this pack will not coach, even under pressure. Each has its basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove or delivered the $400M ARR uplift | Inflated form of F1 | F1's quote at its own scope: proposed a store-surface change credited with a ~$400M ARR uplift. The limit is the pack's observation: the material says "proposed" and "credited", not "drove". A1, B4 and E1's slots stay inside the proposal |
| Designed a partner motion, or a partner program | Inflated form of F4 | F4's quote at its own scope: built a partner-level revenue model used in carrier negotiations. The material says a model, not a motion. D2 and A2's slots ask only what the model shaped |
| Led or ran the carrier negotiations | Inflated form of F4 | The same quote: the model was used in the negotiations. A2's slot asks which part, if any, was hers |
| Set sales quotas, or did sales ops | Negative stated in the coach's notes, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting work." The volume targets are never called quotas |
| Has AI product or AI GTM experience | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. G2's slot asks only how she uses them |

---

## 14. Sources

**Provided documents:** the coach's message. It held the role and JD highlights, the candidate background, Dan's profile summary, and the research note on Northwind's three priorities and main competitive threat. The research note's date and underlying sources were not given, so the C bank treats it as current. No dossier was present.

**Searches sent:**

- `"Northwind Data" company values`: refused (permission not granted)
- `"Northwind Data" interview process strategy`: refused (permission not granted)
- `"Dan Kovac" "Northwind Data"`: refused (permission not granted)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Refused. It would have themed the H bank on Northwind's published values by name |
| 2. `Northwind Data interview process` (GTM strategy) | unavailable | Refused. Your notes already establish this session as one conversation with Dan, so it would only have shown whether a values round sits elsewhere in the loop |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note supplies the current priorities and the competitive threat the CO and CASE questions use |
| 4. `Dan Kovac Northwind Data` | unavailable | Refused. It would have checked the profile summary against his public footprint and found any talks or posts whose themes become questions |
| 5. Representative JD for the title | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

---

## 15. Upgrade menu

- **Full JD text:** mid-list requirements (named tools, methods, specific metrics) each get a question, and F1–F6 rest on the JD's exact words rather than highlights.
- **Priya's own words on the slots in A1, A3, D1 and E1** (how the ~$400M was counted and what part was hers; how the volume targets were set): those slots become story-mapped guidance. Her confirmation that she'd describe F7 in those words matters most, since D1 depends on it.
- **An inspectable artifact for F1 or F4**, such as a performance review or recognition note naming the store-surface change, or a sanitized version of the revenue model: F1 and F4 could move from `medium` to `high`.
- **Recruiter guidance** (focus areas, anything Priya should prepare): a build section for any announced deliverable, and coverage reweighted toward what they flagged.
- **Allowing web search, or a deeper pass of up to 6 more searches and 2 more fetches (several more minutes):** Northwind's values by name for the H bank, Dan's public footprint checked and mined for themes, and a freshness check on the research note.
- **Prep time available:** a prioritized triage schedule at the top of the pack.
- **A tuesday-dossier.md from an underwriting pass:** the highest-ROI objection would be evidence-derived rather than inferred, and weak areas would carry a binding strategy.
