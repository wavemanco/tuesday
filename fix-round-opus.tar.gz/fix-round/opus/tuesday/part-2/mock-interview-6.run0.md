I'm building the three-round prep pack. Next I'm running a few targeted searches on Larkfield Systems to look for published values, interview process and recent news.
I've built one prep pack covering all three rounds. All three share one assessment of how your background matches the role, and each round gets its own 8–10 questions, answer guidance and questions for you to ask them.

My web searches for Larkfield were blocked in this session, so I couldn't look up their published values, interview process or recent news. I built the pack from the role description and background in your message only. The questions about company strategy and the values-round prep are general rather than specific to Larkfield, and the pack says so where it applies.

**The question most worth practising:** "You've led a team of six; this is two squads and eleven engineers. What makes you ready?" It's question A1 for Tuesday's hiring manager, and it comes back on Monday as J2 and K1. The pack's answer leads with your three years leading six people. If the squads have their own leads, you say plainly that you haven't managed managers, then give your plan for taking on the bigger scope.

**Rounds:**
- **Tuesday (hiring manager):** questions probing your gaps, plus live problems like your first 90 days, a delivery-versus-reliability trade-off and designing a hiring process.
- **Thursday (panel):** working together with the staff engineers and the product manager, plus detailed questions on your 60% on-call drop and your roughly 40 interviews. For example, are those 40 interviews you ran yourself or interviews your hiring process ran?
- **Monday (VP):** leadership philosophy and values questions, higher-level strategy questions and a few under time pressure.

The pack also lists claims it deliberately won't coach you to make. For example: managing managers, owning a hardware roadmap, making the hiring decisions, or personally cutting on-call by 60%.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-6-denied-f9b396bf:
- larkfield-systems_engineering-manager_interview_pack.md

I can run a live practice round where I play the Tuesday hiring manager and ask you A1, with follow-ups that react to your answers.
I can also save a tuesday-dossier.md listing the gaps this prep found, so you can carry it into later sessions.
If you'd like the pack as a Word document, I can convert it.

Can you paste the full job posting and your CV? Those would add more of your own words to the parts where the pack has least to go on, especially leading the delivery work, growing engineers and working with product.

If you turn on web search, should I run just the standard search for Larkfield's values, interview process and news, or a deeper pass too (up to 6 more searches and 2 more page fetches, several more minutes)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people, as your message describes it)
**Mode:** Loop, three scheduled rounds
- **Round 1, Tuesday:** 45 min with the hiring manager, a Director of Engineering who would be your manager
- **Round 2, the Thursday after:** 60-min panel with two staff engineers and a product manager
- **Round 3, the following Monday:** 30 min with the VP Engineering, described by the recruiter as "values and leadership philosophy"

Interviewer names: not given. Built from the role summary and background in your message. Web research was refused in this session (see Sources), so nothing in this pack comes from Larkfield's website, published values or news.

---

## How to use this pack

Two axes. **Personas** describe how a question is asked: the register, the follow-ups, the pressure. **Types** describe what is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values and leadership philosophy they are looking for |
| EXP | Whether what you have said about your work holds up under scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy homework, and whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Each round below has its own persona weights, its own question bank and its own reverse questions. All three read from one shared fit snapshot. Question IDs are lettered by persona: A to C on Tuesday, D, E and G on Thursday, H, J and K on Monday. F is kept for fit-snapshot rows.

An **answer slot** is an instruction for the interview, not a question for you to answer here. It names a probe the role makes likely and gives two honest branches. Guidance is scaffolding, not a script. Say it in your own words.

The loop structure comes from your message: three rounds, who runs each one and what each holds. It is not an industry pattern I assumed. Monday is the values-style round because the recruiter described it that way.

**Highest-ROI prep in this pack: A1**, the step from a team of six to two squads of eleven. The same objection comes back as K1 and J2 on Monday and as E3 on Thursday. Rehearse A1 until it bores you.

---

## Fit snapshot (shared)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — JD (two squads) | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material shows one team of six; the role is two squads. Keep the words at that scope: "Three of my nine years have been as a team lead of six." If a probe about leading through other leads comes, you have already said the plain answer: "I haven't managed managers." Answer slot: the JD's two-squad line makes a probe on how you ran the team of six likely. Say which parts of running it were yours, in your own words. If some parts sat with someone else, say so plainly and stay with what was yours |
| F2 | "Lead two squads building device-management services" — JD (device-management domain) | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material puts you at a payments company and says nothing about devices. Words at the quote's scope: "Nine years in engineering, currently at a payments company." Answer slot: the JD's device-management line makes a probe on device, fleet or hardware-facing systems likely. If any of your work touched them, say what it was and which part was yours. If none did, say so plainly and say what you would learn first |
| F3 | "own delivery, hiring and growth for 11 engineers" — JD (delivery) | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | Pushing a reliability quarter through is one prioritization call. Owning a team's delivery is wider, so do not stretch the bridge. Words for the call itself: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the JD's own-delivery line makes a probe on how your team's commitments were set, tracked and reported likely. If that was yours, say how, in your own words. If it was set elsewhere, or there was no such process, say so plainly and come back to the reliability quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" — JD (hiring) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running a hiring loop is next to owning hiring for your own team, but it is not the same thing. Words at the quote's scope: "I run our hiring loop for backend roles — about 40 interviews last year." The figure counts interviews, not hires, and it stays attached to interviews. Your sentence does not say whether the 40 are interviews you conducted or interviews the loop ran, so take the smaller reading unless you know otherwise (E2). Answer slot: the JD's own-hiring line makes a probe on your part in the loop likely. If any part of it was yours to set, such as who interviewed, what was asked or how the debrief ran, say which. If none was, say so plainly and stay with running the loop |
| F5 | "own delivery, hiring and growth for 11 engineers" — JD (growth) | none given | none | [grounded] | discovery | Strong evidence here is a named engineer whose growth you shaped: what you did and what changed for them. Answer slot: the JD's growth line makes a probe on developing engineers likely. If your lead role included growth conversations, reviews or promotion cases, say which and what you did, in your own words. If it did not, say so plainly, then give the nearest thing your material carries, or how you would approach growth for eleven engineers |
| F6 | "partner with hardware and product on roadmap" — JD (product) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | Holding a reliability quarter against roadmap pressure touches the product relationship. It does not show a partnership on the roadmap itself. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the JD's partner-on-roadmap line makes a probe on how that pressure was worked through likely. If you worked it out with a product counterpart, say how and what each side gave up. If it was not worked out that way, say so plainly and stay with what you pushed and what followed |
| F7 | "partner with hardware and product on roadmap" — JD (hardware) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | Wording cannot close this gap, and you have said so yourself. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as something you have done. Nothing is added to make the gap feel smaller. Your sentence covers owning such a roadmap; the material says nothing about working alongside hardware teams in other ways. Answer slot: if you have worked alongside a hardware or device team in some other way, say what it was, in your own words. If not, say so plainly and go to the plan |

## Requirement coverage (shared)

| JD requirement | Covered by |
|---|---|
| "Lead two squads" (F1) | A1, B1, J2, K1 |
| "building device-management services" (F2) | A3, E3, J1 |
| "own delivery" (F3) | B2, B4, C2 |
| "hiring" (F4) | B3, E2, H4 |
| "growth for 11 engineers" (F5) | C2, H3 |
| "partner with … product on roadmap" (F6) | D1, B2, G1 |
| "partner with hardware … on roadmap" (F7) | A2, A4, B2 |
| "industrial IoT, ~600 people" (company context from your message, not a requirement) | A3, J1. CO questions are generic because research did not run |

---

# Round 1: Tuesday, hiring manager (Director of Engineering, 45 min)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the size of the step: team of six to two squads, payments to devices, no hardware roadmap | High. Hiring managers de-risk gaps, and F1, F2 and F7 are the visible ones. This person would be your manager, so the risk lands on them | Rehearse A1 until it is boring. Bridge only from F1's and F7's quotes at their own scope, say the limit before you are asked, then give a ramp plan said as a plan |
| Case / Strategist | Live problems from the squads' likely work: a first-90-days plan, a delivery-versus-reliability call, hiring design | High. Hiring managers buy capability through live problems on their roadmap. No interviewer signals are available to adjust this | Clarify, then objective, approach, metrics, risks. Think aloud and challenge one premise per case. Anchor in F3's quote only where it fits |
| Conversational | Opening "walk me through it" and a casual "what's your week like" | Medium-low. A 45-minute slot usually opens warm, and casual questions are still scored | A 90-second arc built only from F1's quote, then why this role, in your own words |
| Data-Driven Prober | Light. The 60% figure may come up here and is drilled on Thursday | Low on Tuesday. Covered in Round 2 | Know what you can and cannot say about how the 60% was counted (E1) |

## Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role is two squads and eleven engineers. You've led a team of six. What makes you ready for that step?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI rehearsal in the pack.** Open with what the quote carries: "Three of my nine years have been as a team lead of six." Name the limit before they do. If the squads have their own leads, say: "I haven't managed managers." Then give the plan, said as a plan: how you would learn both squads in the first weeks and what you would want from your manager while you do. Answer slot: if they ask which parts of running the team of six were yours, say them in your own words. If some sat with someone else, say so plainly and stay with what was yours. Expect two follow-ups, such as "and if one squad already has a lead?" or "what breaks first at eleven?". Hold by coming back to the team of six and the plan, never by adding to it | F1 is the most visible gap between your background and the JD's two-squad line, so this objection will come in some form. JD because it scores the stated scope. Deepest rehearsal here because it returns as J2 and K1 |
| A2 | "This roadmap is shared with hardware. Have you worked with hardware or firmware teams?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment first, in your own sentence's terms: "I haven't owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside a hardware or device team in some other way, say what it was. If not, say so plainly. Then the plan: what you would ask the hardware leads in the first month, such as their release rhythm and where software dependencies have hurt them. No softening line after the acknowledgment | F7 is a gap you stated, and the JD's partner-with-hardware line will make them probe it. Rehearsing the plain version stops a live stretch |
| A3 | "Why leave payments for industrial IoT, and why now?" | JD, EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Your reasons are yours, and the pack does not supply them. Selection scaffold: one reason about the work (the JD's device-management services) and one about the step in scope (two squads), each true for you. If one of those is not true for you, leave it out and give the real one. Keep the current employer as "a payments company" and say nothing negative about it | F2's domain switch plus a team change brings the standard why-leave, why-here, why-now probe. JD because the hiring manager tests motivation against the listed work |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick a real one. F7 is the one you have already said: "I haven't owned a hardware-adjacent roadmap." Then give the plan in one sentence. Do not pick a disguised strength. A self-assessment that matches what they can already see builds credibility for everything else you say | Standard Skeptic probe. Choosing F7 means your answer agrees with A2 instead of competing with it |

## Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's your first 90 days with two squads and eleven engineers. What do you need to know first?" | CASE | [generic] | Clarify first: what each squad owns, who the leads are if any, what is promised to hardware and product, and the on-call picture. Then the objective: learn before changing. Approach: one-to-ones with all eleven, sitting in each squad's rituals, meeting the hardware and product partners. Then the first decision you would expect to make, and what would tell you that you were wrong. The question asks about no past, so the guidance makes no claim about yours | A near-certain hiring-manager case for a manager hire. Generic because no Larkfield context could be researched |
| B2 | "One squad is behind on a release the hardware team is waiting on, and the other is buried in on-call. You have one quarter. What do you do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure: what the hardware dependency actually needs and by when, what is driving the on-call load, and what can move between squads. Say the trade-off out loud, and say who you would tell, before the quarter starts, what is slipping. One anchor sentence, kept at the quote's scope: "Before, I pushed a reliability quarter through against roadmap pressure, and our on-call burden dropped 60% after." Do not say the quarter caused the full drop (see E1). Challenge one premise, such as whether both problems really need solving this quarter | Brings F3, F6 and F7 together in one live problem, the kind of collision the JD's partner-with-hardware line points to. CASE because it scores reasoning, and the anchor rests only on F3's quote |
| B3 | "You'd own hiring for these squads. How would you design the loop?" | CASE, JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from what the quote carries: "I run our hiring loop for backend roles." Then the design, said as a plan: what the squads need that a backend loop may not test, how you would calibrate interviewers and how a hire decision gets made. Answer slot: if any part of your current loop was yours to set, name it as the part you would keep or change. If none was, say so plainly and present the whole design as a proposal | F4 is a real strength next to the JD's hiring line. CASE delivery tests whether running a loop carries over to owning hiring |
| B4 | "How do you decide when a team should spend a quarter on reliability instead of the roadmap?" | CASE, EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Give your criteria as how you would decide now, then the story as evidence: you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Answer slot: if a particular signal made you push for it, say what it was, in your own words. If there was no single signal, say so plainly and say what you weighed. End with what you would do differently with a hardware partner waiting | F3's quote is your strongest story and fits the JD's own-delivery line. They will want the judgment, not just the outcome |

## Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc from the quote: nine years in engineering, three of them as a team lead of six, now at a payments company. Then one line on why this role, the same reason you give in A3. Stop at 90 seconds and let them choose where to dig | The opening in nearly every hiring-manager round. Rehearsed so it stays inside F1's quote and matches A3 |
| C2 | "What does your week actually look like as a team lead?" | EXP, JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: the JD's own-delivery-hiring-and-growth line makes a probe on how your time splits likely. Say what share goes to people, delivery and hands-on work, in your own words. If one of them is not part of your role, say so plainly. The hiring loop from F4 is a part you can name: "I run our hiring loop for backend roles." | A casual question about F3 and F5, where your material is thinnest. Treat it as scored |

## Reverse questions: Tuesday

| Question | Why it lands |
|---|---|
| "How are the two squads set up today? Does either have a lead I'd be working through?" | Raises the F1 gap yourself and gets the fact that decides how A1 lands |
| "What would make my first six months a success from where you sit?" | This person would be your manager. It asks for the scorecard and shows you plan to be measured |
| "Where do hardware and software roadmaps clash today, and how does it usually get resolved?" | Turns F7 into curiosity about the real seam and tells you what partnering means here |
| "What's the biggest delivery risk the squads are carrying right now?" | A delivery question, the JD's first ownership line, asked as diligence |
| "How do you support a manager who is stepping up in scope?" | Names the step openly. The answer tells you how much support you would get |
| "Why is this role open?" | Backfill, new squad or reorg changes what the job really is |

---

# Round 2: Thursday, panel (two staff engineers and a product manager, 60 min)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam questions: where an EM's call ends and a staff engineer's begins, how roadmap trade-offs get settled with the PM, credit across teams | High. The panel blends each member's top personas. Staff engineers working with your squads and a PM partner on the roadmap are all pricing what you add to, or take from, their work | Reciprocity framing. Propose seam principles instead of pretending to know Larkfield's seams. Disagreement answers that show spine and tact together |
| Data-Driven Prober | Staff engineers taking the 60% and the 40 interviews down two levels, then testing how technically credible you are | High-medium. Engineers who read your background will go for the figures | Know what you can and cannot say about how each figure was counted. Say plainly what you do not know. Name the weakest assumption before they do |
| Values / Behavioral | The PM asking for stories about trade-offs and hard conversations | Medium-low. A cross-functional panellist tends to ask in behavioural form | Choose stories only where one of your quoted sentences carries one, otherwise use the selection scaffold |
| Pressure | Possible from a staff engineer: "how much of that was you?" | Low here. Covered on Monday (K2) | Hold, then concede (K2) |

## Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | (PM) "I need a feature for a hardware launch and your squads want a reliability quarter. How do we settle that?" | JD, CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Start with a seam principle: shared visibility of the cost on both sides, a date that is agreed rather than assumed, and an explicit escalation path. Say what you would bring the PM, such as earlier warning of reliability risk. Your one anchor, at the quote's scope: you pushed a reliability quarter through against roadmap pressure. Answer slot from F6: if you worked that pressure out with a product counterpart, say how and what each side gave up. If not, say so plainly, and say how you would do it with them | The PM's most likely question, since the JD makes the roadmap shared. F6 is the thin bridge, and this rehearses not stretching it in front of the person it describes |
| D2 | (Staff engineer) "Where's the line between your call and ours on technical direction?" | JD | [generic] | A principle, not a turf claim. They own technical direction and you own the conditions: priorities, staffing and the time to do it right. Say what you would do when you disagree with a staff engineer's call, and what you would never override without talking to them first. No claim about your past is needed | Staff engineers measure whether an EM adds to their load. The JD's two-squad line puts you between them and the roadmap |
| D3 | (Staff engineer) "What would you need from us in your first month, and what do we get from you?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Reciprocity both ways. What you need: context on the systems and the history of the squads. What they get: protected time and a clear priority list. One concrete offer from F4's quote: "I run our hiring loop for backend roles", so hiring is something you can take off their plate. Do not promise outcomes you cannot back | A peer reciprocity probe. F4 is the strength most directly useful to staff engineers who interview |
| D4 | (PM) "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time when credit for shared work had to be handled. You need a named piece of work, who did what, and what you said or did about credit. "We" for the context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it across two squads and a hardware team | A standard peer stem. None of your quoted sentences carries a credit story, so this is a scaffold |

## Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your on-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Keep the sentence's own order: the burden dropped 60% after you pushed the quarter through. Then the defend-the-number slots, each in your own words. How it was counted: pages, hours or incidents, and over what window. What it is sensitive to. The assumption behind it you would defend least, named before they ask. Which part was yours. If you do not know how it was counted, say so plainly. The pack does not supply a method or a baseline | Your headline figure, and staff engineers will go two levels into it. EXP because it tests attribution and counting |
| E2 | "About 40 interviews last year. What did you actually decide in that loop?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what the quote carries: you run the hiring loop for backend roles. Then the figure's slots, in your own words. How it was counted: whether the 40 are interviews you conducted or interviews the loop ran. Which part was yours: if any part of the loop was yours to set, such as who interviewed, what was asked or how the debrief ran, say which. If none was, say so plainly. The figure counts interviews and never becomes hires | F4's figure is the second number in your background. Probers check what it counts |
| E3 | "How close to the code are you today, and how would you stay credible with us on device-management systems?" | EXP, JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Nine years in engineering is what the quote carries. Answer slot: the JD's device-management line makes a probe on how hands-on you are likely. Say how much of your week is hands-on now, in your own words. If none is, say so plainly. F2's slot applies too: if any of your work touched device, fleet or hardware-facing systems, say what. If none did, say so and say how you would learn the domain, for example by reading incident history and pairing with them | The panel version of A1 and F2. Staff engineers judge an EM's credibility directly |

## Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | (PM) "Tell me about a time you delivered an unpopular truth about a roadmap." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The reliability quarter may be the story. The beats are what the quote states: the pressure from the roadmap, you pushed the quarter through, and the on-call burden dropped 60% after. Answer slot: the JD's partner-on-roadmap line makes a probe on who you had to convince likely. If someone had to be persuaded, say who and what you said, in your own words. If it was not a persuasion story, say so plainly and pick another time, or say how you would handle it | F6's story told to the person it is about. Tell it the same way on Monday (H2) |
| G2 | (PM) "When did you put a user or customer ahead of a delivery date?" | VAL | [generic] | Selection scaffold: it needs a named date, the user or customer need that competed with it, the call you made, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide it with industrial customers running fleets | Product managers often probe this trade-off. None of your quoted sentences carries this story |

## Reverse questions: Thursday

| Question | Why it lands |
|---|---|
| "What could a new manager do in their first month that would genuinely help your work?" | Reciprocity question for peers. It shows you are pricing what you add to their work |
| (Staff engineers) "Where do staff engineers and the EM overlap here, and where has that gone badly?" | Shows you know where the seam lies and gives you the facts behind D2 |
| (PM) "What's one roadmap trade-off from the last year you'd make differently?" | Invites the PM's real view and shows you see the roadmap as shared |
| "How does on-call work for the device-management services today?" | Ties to F3's story without restating it, and tells you whether the squads need the same thing |
| "When hardware slips, what happens to the software plan?" | Turns F7 into informed curiosity about the seam you would manage |

---

# Round 3: Monday, VP Engineering ("values and leadership philosophy", 30 min)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?", stories about holding a position, growing people, hiring calls | Highest. The recruiter described the round as "values and leadership philosophy", and that is a loop source documenting a values-style round. Larkfield's published values could not be fetched, so the questions are themed by the recruiter's words rather than by named values | One belief, one story that shows it, one cost you accepted. Use stories only where a quoted sentence carries one |
| Case / Strategist | Altitude questions: how payments experience translates to industrial IoT, where your career goes after squads | Medium. Executive interviews test strategic altitude, cut short by a 30-minute slot | Short structured answers. Use the company context from your own message only |
| Pressure | Time-boxed challenges: "sixty seconds, why you" and "how much was actually you" | Medium. Executives often time-box, and 30 minutes compresses everything | Pause, restate, hold through two follow-ups, then concede something specific |
| Conversational, Prober, Peer | Possible in passing | Low. Covered in Rounds 1 and 2 | Use C1, E1 and D1 |

## Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy, in a minute?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The philosophy is yours, and the pack does not write it. Shape: one sentence you believe about leading engineers, one story that shows it, and one cost you accepted for it. If the reliability quarter is the story that shows it, tell it in its own words: you pushed it through against roadmap pressure, and the burden dropped 60% after. If it does not show your belief, use the story that does, or say how you would act on the belief at Larkfield | The recruiter named this round "leadership philosophy", so some version of this question is near-certain. VAL because it scores fit with how they lead |
| H2 | "Tell me about a time you held a position under pressure." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3's quote: the roadmap pressure, you pushed the quarter through, and the drop after. Tell it the same way as in G1. Answer slot: the recruiter's "leadership philosophy" framing makes a probe on how relationships held up likely. If there was friction, say how it ended, in your own words. If there was none, say so plainly. Do not add a confrontation the story did not have | F3 is your one quoted story about holding a position. Telling it consistently across G1, B4 and H2 matters more than a new story each round |
| H3 | "How do you grow engineers who aren't like you?" | VAL, JD | [generic] | Selection scaffold, because your material does not show growth work (F5). It needs a named engineer, what you did, and what changed for them. If no such engineer comes to mind, say so plainly, then say how you would approach growth for eleven engineers: what you would ask each one first and how you would know it was working | F5 is the requirement with no evidence at all, and the JD's growth line will be scored somewhere. Values rounds often ask about it |
| H4 | "Tell me about a hiring call you disagreed with." | VAL, EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Selection scaffold inside the loop you run: a candidate, what the loop leaned toward, what you thought and why, and what happened. Answer slot: if you raised the disagreement, say how. If you did not, or it was not your call, say so plainly. If no such call comes to mind, say so and say how you would handle one as the hiring owner | F4 is a strength, and a disagreement story tests judgment and candour together |

## Bank J: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Industrial IoT isn't payments. What would you have to unlearn?" | CO, CASE | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Keep to what you can stand behind: your background is a payments company. Give a structured answer as questions you would bring: device lifecycles, field updates, the hardware release rhythm. Say you would test these against what the squads know before acting. Make no claim about Larkfield's customers or strategy, because none could be researched | An altitude question at the F2 domain switch. CO because it tests whether you can think at the company's level, and it is generic until research runs |
| J2 | "In a couple of years you might be leading managers. What would you have to stop doing?" | CASE, JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't managed managers." Then the answer as a plan: what you would hand over, how you would stay close to the work through your leads, and what you would ask for to learn it. Keep it short. The honest version is the strong one | Monday's version of A1, aimed at the step after this role. JD because the JD's two-squad line raises the scope question |

## Bank K: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause and take the full sixty seconds. Three beats, each at its quote's scope: three years as a team lead of six, running the hiring loop for backend roles, and the reliability quarter you pushed through. Concede one specific thing before they do: an internal candidate knows the hardware side, and you would learn it (F7). Hold through two follow-ups by coming back to these three beats | Pressure stem, time-boxed. It puts A1's objection under a clock, so the hold must stay inside F1, F3 and F4's quotes |
| K2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the part that is yours in the sentence: you pushed the quarter through. Then concede specifically. Answer slot: which part of the work was yours, and what else the drop is sensitive to, in your own words. If you do not know how much the quarter explains, say so plainly. Never claim the whole 60% | The Prober's E1 asked under pressure. The one place your best story is most tempted to grow |

## Reverse questions: Monday

| Question | Why it lands |
|---|---|
| "What separates the managers here you'd call exceptional?" | A values round invites a values question back, and it asks the VP's own philosophy |
| "How do you see the path from leading squads to leading managers here?" | Raises the F1 step openly and shows you are thinking past the first year |
| "What would you want to be true of engineering here in two years that isn't true now?" | A strategy question at the VP's altitude, asked as genuine curiosity |
| "Where does engineering leadership disagree with itself right now?" | Shows you expect real tension and want to know it before you join |
| "Which values do you see tested hardest in this org?" | Asks for the values in practice, since the published ones could not be read for this pack |

---

## Prohibited claims (shared)

What this pack will not coach, and why. Every bank above was written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led more than one team | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation, not words for you: the material says a team of six. A1's slot stays inside that team |
| Has managed managers | A negative you stated, F1 | The plain acknowledgment: "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | A negative you stated, F7 | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No slot |
| Owned or set the product roadmap | Inflated form of F6 | F6's quote at its own scope: you pushed a reliability quarter through against roadmap pressure. The material says the quarter, not the roadmap. D1's slot stays inside the quarter |
| Owned hiring decisions, or hired about 40 people | Inflated form of F4 | F4's quote: you run the hiring loop for backend roles, about 40 interviews. The figure counts interviews. E2's slot stays inside the loop |
| Personally cut on-call by 60% | Inflated form of F3 | The quote's own order: the burden dropped 60% after you pushed the quarter through. How much the quarter explains is for you to answer in E1 and K2, never for the pack to supply |

---

## Sources

**Provided documents:** your message: the role summary, the three rounds and your background. That is the only source of every quote in this pack.

**Searches sent:**
- `Larkfield Systems values`: refused (web search permission not granted)
- `Larkfield Systems interview process engineering manager`: refused
- `Larkfield Systems industrial IoT news`: refused

No fetches were sent. No dossier was present.

**Loop:** established by your message, which names each round, who runs it and what it holds. No archetype fallback was used. The values-style round on Monday is documented by the recruiter's words as you relayed them.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Refused. It would have given the published values by name, so Monday's bank could map stories to each value and a values cheat sheet could be included. That section is absent because no values are in hand |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Refused. It would have checked the loop your message describes against any published process. Persona weights rest on your description, which already establishes the loop |
| 3. `Larkfield Systems` strategy and recent news | unavailable | Refused. It would have grounded at least one CO or CASE question (J1, B2) in current priorities. Those rows stay `[generic]` or carry no Larkfield claims |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form. There is no interviewer read, and the reverse questions are role-specific rather than tied to anyone's path |
| 5. Representative Engineering Manager JD | skipped | The role summary you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Enable web search** → targets 1 to 3 run. Larkfield's published values by name give a Monday values cheat sheet and VAL questions mapped value by value. A current-strategy pass grounds J1 and B2 in Larkfield's own priorities
- **The full job posting** → more requirements quoted and covered. Mid-list items the summary leaves out get their own JD questions
- **Your CV** → more quoted evidence, which may move F3, F5 and F6 from `discovery` to a stronger row
- **The artifact behind the 60%**, such as an on-call report or incident dashboard you can describe → E1 and K2 rest on something inspectable, and F3 can rise above `low`
- **Interviewer names for each round** → an interviewer read per round, persona weights adjusted from their public footprint, and a reverse question tied to each person's path
- **The recruiter's notes on each round** (focus areas, anything you should prepare in advance) → coverage of any graded deliverable and per-round weights from the source
- **How much prep time you have before each round** → a prep triage per round, in priority order
- **Your answers to the F1, F3, F5 and F6 slots, told to me outside a drill** → those rows regenerate on your own words, along with the questions that draw on them (A1, B2, C2, D1, H3)
- **A tuesday-dossier.md from an underwriting pass** → the highest-ROI objection comes from evidence you confirmed rather than being inferred, and each weak area carries a strategy constraint
