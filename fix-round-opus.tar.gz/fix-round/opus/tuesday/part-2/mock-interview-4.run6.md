I'm building your prep pack from the dossier. First I'm running a few company searches (values, interview process, strategy).
Using Edit instead.
I've saved your prep pack as `quartzline_product-manager-platform-apis_interview_pack.md`. It's built for a single 45-minute conversation with the hiring manager, using your dossier as both the job description and your confirmed track record.

- **Rehearse A1 first.** It's the objection your dossier named: you've never held the PM title or owned a roadmap. The pack gives you three steps:
  1. Concede it plainly.
  2. Give your 30+ client integrations of the vendor's REST APIs, described as adjacent work and never as PM experience.
  3. Answer "why you" with a 90-day plan.

  It also scripts three follow-ups.
- **Every answer stays inside your dossier's three prohibited claims:** holding the PM title or role, owning a roadmap, and setting priorities for an engineering squad. The pack also lists four stretched phrasings to avoid. One is calling the integrations "shipping an API product."
- **The roadmap-input sessions are confirmed but have little you can show behind them.** Mention that limit yourself before you're asked. Don't use them to answer the roadmap gap.
- **No company research is in the pack.** All three web searches were refused, so the company-knowledge and case questions are general to this kind of role, not specific to Quartzline. The two questions for the hiring manager from your dossier are included: who decides what versus the squad leads, and how adoption is measured today.
- **Today is Thursday the 12th.** If the interview is today rather than next week, spend your time on A1, A2, C1 and the questions to ask them.

If you'd like a live rehearsal, I'll play the Skeptic and ask you A1.
I can also add a `pack_feedback` section to your `tuesday-dossier.md` recording the gaps this prep exposed.
If you want the pack as a Word document, I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** one 45-minute conversation with the hiring manager (name not given), on Thursday.
**Built from:** your `tuesday-dossier.md` (v1.1, generated 2026-08-14). No web research made it in, because all three searches were refused (see Sources).

---

## How to use this pack

- **Personas** describe how a question is asked: who is asking and in what style. **Types** describe what is being scored. Every question has both.
- **Type key:**
  - **VAL**: behavioral or values alignment. Does past behavior show the company's published values?
  - **EXP**: work-experience deep-dive. Does what you said survive scrutiny, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. How deep did your homework go?
  - **CASE**: a live problem from the actual role, solved out loud.
- **Guidance is scaffolding, not a script.** Say it in your own words.
- **Answer slots** are marked "Answer slot:". They tell you what the interviewer is likely to probe and give you two honest branches. They are instructions for the interview, not questions for me.
- **Start with A1.** Your dossier named it as the objection most likely to come up, and it is the highest-ROI prep in this pack.
- Provenance labels: `[grounded]` traces to your dossier, `[inferred]` is a derivation that is named in the row, and `[generic]` is a role-family pattern with no claim about Quartzline or about you.

---

## Fit snapshot

Requirements come from your dossier's `role_profile`, captured 2026-08-14. Evidence quotes come from `handoff_to_mock_interview.verified_candidate_evidence`, numbered 1 to 3 in the order the dossier lists them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1 (must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | transferability | Derived from the dossier's low band and bridge strategy for R1. Present this as adjacent and never as PM experience. That is the dossier's condition. First the limit, in words the dossier's `prohibited_claims` item supports: "I haven't held a product manager title or role." Then the adjacent work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." Describe what you did and let the interviewer draw the inference. Don't tell them what it proves |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibility | none given | none | [grounded] | capability | The dossier records this as an `acknowledge_gap` area, and its `prohibited_claims` include "Having owned a product roadmap" and "Having set prioritization for an engineering squad". Words: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past. No bridge here. In particular, the roadmap-input sessions (F7) are not offered as roadmap ownership |
| F3 | "Shipped API or platform products" — dossier R2 (must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | high | [grounded] | transferability | Your material describes integrations of the vendor's REST APIs, not shipping the API product, and the words stay there. Answer slot: R2 makes a probe on what you shipped likely. If any part of what went live was yours to decide, say which part and how you decided, in your own words. If none was, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier R3 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified evidence 2 | low | [inferred] | discovery | Derived from these quotes touching R3 without showing it. They name REST APIs and an architecture stage, not docs or schemas. Answer slot: R3 makes a probe on reading API docs and schemas likely. If you work with them, say how, in your own words. If not, say so plainly and stay with the integrations |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4 (important), the customers part | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | high | [grounded] | none | Client-facing integration work, end to end, in the quote's own stages. Lead with the integrations and their stages. "Stakeholder management" is the JD's phrase, so let the interviewer map it rather than putting it in your own history |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier R4 (important), the engineering and sales parts | none given | none | [grounded] | discovery | Your material does not show work with engineering or sales. Answer slot: if you worked with either on those integrations, say who and what you did together, in your own words. If not, say so plainly and stay with the client side |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibility | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | transferability | Confirmed, with limited inspectable proof, so expect a probe. Volunteer the limit before it gets pulled out of you. Your material says you fed client evidence to product, not that you ran partner discovery. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if you know what product did with that evidence, say what and how you know. If you don't know, or nothing came of it, say so plainly |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibility | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | discovery | Derived from "requirements" appearing as one stage in the quote. Whether you wrote anything at that stage isn't shown. Answer slot: if the requirements stage produced documents you wrote, say what they covered, in your own words. If not, say so plainly. The squads half of this line touches F2's limit, and the dossier's `prohibited_claims` item "Having set prioritization for an engineering squad" holds |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibility | none given | none | [grounded] | discovery | Your material does not show adoption metrics. Answer slot: if you defined or tracked any usage measure, say what was counted and how, in your own words. If not, say so plainly and say what you would measure first |
| F10 | "Agile delivery experience" — dossier R5 (preferred) | none given | low | [inferred] | discovery | Derived from the dossier's `clarify` strategy for R5. No verified entry speaks to it. Answer slot: R5's "agile delivery" is the likely probe. If you worked that way, say how, in your own words. If you never did, say so plainly. Either way, add what you would want to confirm about how this team defines it |

---

## Persona table

The loop is set by your own words: one 45-minute conversation with the hiring manager. No values round is named, so there is no values cheat sheet in this pack.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the PM-title gap and of motivation | High. The hiring-manager prior is Case/Strategist plus Skeptic, and your dossier names a fit objection (A1) aimed straight at F1 and F2 | Rehearse A1 until it's boring. Concede first, then give the adjacent work at its own scope, then a ramp plan |
| B. Case / Strategist | Live problems from this role's own responsibilities: adoption, conflicting partner asks, the first 90 days | High. Hiring managers buy capability, and CASE questions ask about no past, so they are where you can show the most without stretching anything | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise per case |
| C. Data-Driven Prober | Takes "30+" and the playbook apart line by line | Mid. The one figure in your material (F1, F3) and the inspectable playbook (F4) are natural targets | Know how the figure was counted, or say plainly that you don't. Name the weakest assumption before they do |
| D. Conversational | "Walk me through your journey." Casual questions about the JD's topics | Mid. Most hiring-manager conversations open this way, and casual questions still get scored | Have a pre-built 90-second arc taken from your quotes only |
| E. Peer Evaluator | Where you sit relative to the two squad leads | Low to mid. The JD's "two engineering squads" line puts that seam in play even with a single interviewer | Propose seam principles rather than pretending to know the seam. Don't claim past prioritization |
| F. Pressure | Time-boxed "why you" and "how much was you" | Low. Not the prior for this relationship, but A1 can turn into it | Hold through two follow-ups on what the quote says, then concede specifically |
| G. Values / Behavioral | STAR prompts about candor and customers | Low. No values round is named, and no values page was read | Selection scaffolds, each ending in an honest branch |

---

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | **Highest-ROI prep in this pack. Your dossier named this objection.** (1) Concede first and plainly: "That's right. I haven't held a product manager title or role, and I haven't owned a product roadmap." (2) Then the adjacent work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." Describe it and stop. Don't tell them what it proves. (3) Answer the "why you" with a plan in the future tense. For example: in your first weeks, learn which roadmap decisions are yours and which are the squad leads', get the current adoption baseline, and sit with partners before proposing anything. **Follow-up 1:** "So integration work is basically PM work?" Hold: "No. It's adjacent. I led integrations, and I haven't held the PM role." **Follow-up 2:** "Who decided what got built?" Answer slot: if any decisions inside those integrations were yours, say which ones, in your own words. If none were, say so plainly and return to the integrations you led. **Follow-up 3:** "Then why not hire the three-year PM?" "That's a fair comparison to make." Then go back to (2) and (3) and let them weigh it. Don't reach for the roadmap-input sessions here. The dossier closed that bridge (F2), and offering them as roadmap experience is exactly the claim it prohibits | F1 and F2 are the two biggest gaps, and the dossier names this as the likeliest objection. JD because it scores R1 directly. Both negatives in the question are sourced by dossier `prohibited_claims`, so it is asked as written |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Name a real gap, F2: "Owning the roadmap. I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp plan as a plan: what you would learn first, from whom, and how you'd know you were up to speed. Don't pick a fake weakness. They will hear it | A Skeptic stem pointed at F2, the dossier's `acknowledge_gap` area. JD because it scores the roadmap responsibility |
| A3 | "This role is about shipping API products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote says: you led those integrations of the vendor's REST APIs, through go-live. Answer slot: if any part of what went live was yours to decide, say which part and how you decided, in your own words. If none was, say so plainly and stay with the integrations you led. Never call the integrations a shipped API product (see prohibited list) | F3 is R2, a must-have, and only adjacent evidence reaches it. JD because it scores R2 |
| A4 | "Tell me about a piece of work where you had to manage engineering, sales and customers at once." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The client side comes from F5: the integrations and their stages. Pick one and tell it in your own words. Answer slot: if engineering or sales were part of that integration, say who and what you did together. If they weren't, say so plainly and stay with the client side. If no single piece of work fits all three groups, say that rather than stitching several together | F5 and F6 split R4. The customer part is grounded and the engineering and sales parts are silent, so this is where the seam shows |
| A5 | "How have you worked in agile delivery?" | JD | [inferred] | The dossier's strategy here is `clarify`, and no verified entry speaks to it (F10). Answer slot: if you worked that way, say how, in your own words. If you never did, say so plainly. Then: "What I'd want to confirm is how your squads run it: cadence, who writes the tickets, where the PM sits." Make no claim about your own past here unless you say it yourself | R5 is preferred, not required, but it gets one question so it isn't a free miss. `[inferred]` from the dossier's clarify strategy |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Adoption of the partner API is a metric this role owns. How would you define it, and what would you look at first?" | CASE | [generic] | Clarify first: adoption by whom (partners live, partners active, endpoints used), and over what window. Objective: what the business wants adoption to drive. Segment by partner size or by integration stage. Approach: a funnel from signed to live to active. Metrics: one north star plus two diagnostics. Risks: a metric that rewards call volume rather than value. Finish by asking what the baseline is today. That ties straight into reverse question RQ2. No claim about your past is needed | A live problem from the "Define and track adoption metrics" line (F9). It asks about no past, so it's the safest place to show product thinking. `[generic]` because nothing about Quartzline's actual metric is known |
| B2 | "Two integration partners ask for conflicting changes to the same endpoint. Walk me through how you decide." | CASE | [generic] | Clarify: what each partner needs underneath the request, how many others use the endpoint, and versioning constraints. Options: version, extend, or decline one. Criteria: partner reach, cost to the squads, reversibility. Then say who you'd involve and how you'd tell the partner who doesn't get their way. Frame it as how you would decide here, never "the way I did before" | From the roadmap and discovery responsibilities (F2, F7) as a decision, not a record |
| B3 | "Sketch your first 90 days owning the roadmap for the partner-facing API platform. What do you need to know first?" | CASE | [generic] | This is where A1 and A2's ramp plan lives in full. What you need to know first: the decision split with the squad leads, the adoption baseline, the top partner complaints, and what's already committed. Days 0 to 30: listen and map. Days 30 to 60: one small, visible decision. Days 60 to 90: a roadmap proposal with your reasoning attached. All of it in the future tense | F2 is a capability gap, and the honest answer to a capability gap is a credible plan. Persona stem "Sketch the plan for X" |
| B4 | "What do you know about our partner platform, and what would you change?" | CO | [generic] | Say only what you've seen yourself, such as their public docs or developer pages if you've read them, and name where you saw it. This pack has no research on Quartzline, so it can't supply any. If you haven't looked, say so and turn it into a question about what partners struggle with most. Don't guess at their strategy | A homework check is a common opener. `[generic]` because no strategy research ran. Reading their public API docs yourself before Thursday upgrades this row |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Thirty-plus integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, all in your own words: how the 30+ was counted, what the count is sensitive to, the assumption behind it you would defend least (name it before they do), and which part was yours. "Led" is the quote's verb. If you don't know exactly how it was counted, say so. That is an honest answer | The one figure in your material (F1, F3). EXP because it tests attribution |
| C2 | "You wrote the playbook your team uses. Walk me through what's in it and how it gets used." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats are the quote's: you wrote it, it's internal, and your team uses it. Answer slot: say what the playbook covers and how the team uses it, in your own words. If they ask about a part it doesn't have, say so plainly. It's an inspectable artifact, so offer to talk through it, but check before Thursday whether you're allowed to show an internal document | F4 is the R3 row, and this is the strongest inspectable thing you have. EXP because it gets probed line by line |
| C3 | "Tell me about the quarterly roadmap-input sessions. What changed because of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Confirmed, with limited inspectable proof, so volunteer the limit first. Then say what the quote says: you ran them quarterly and they fed client evidence to product. Answer slot: if you know what product did with that evidence, say what and how you know. If you don't know, or nothing changed, say so plainly. Don't let "what changed" pull you into claiming roadmap ownership. F2's limit holds | F7 is medium confidence, and a Prober will find that seam. The question presupposes an outcome, so the slot allows that there wasn't one |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from these three: the integrations and their stages, the playbook you wrote, and the sessions feeding client evidence to product. Your tenure isn't among the verified entries, so this pack doesn't supply a number. If you state years, use the figure you know. Answer slot: close on why PM now, in your own words | The opener in most hiring-manager conversations. It's still scored, and it sets up A1 |
| D2 | "Why product management, and why now?" | JD | [grounded] prohibited_claims: "Having held a product manager title or role" | Answer slot: your actual reason, in your own words. If it fits naturally, the limit: "I haven't held the PM title. This would be my first time in the role." Don't frame the move as a formality you've already earned | Motivation consistency is what a Skeptic scores, asked here in a friendly register. It ties to F1 |
| D3 | "When you open a new API's docs, what do you look at first?" | JD | [inferred] | Casual phrasing, but scored, because it is R3. Answer slot: describe what you actually do, in your own words. If you don't usually read API docs directly, say so plainly and say how you get up to speed on an API | F4 is discovery. `[inferred]` from R3's wording |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You'd be driving delivery with two squads and their leads. Where's the seam between you and a squad lead, and what happens when you disagree?" | CASE | [generic] | Propose principles rather than pretending to know the seam: the PM owns the why and the what, the squad owns the how and the estimate, and disagreements go to evidence first, then to whoever owns the decision. Then ask how it works today. That is reverse question RQ1. Make no claim about past squad prioritization (F2) | The JD names two squads, and decision authority versus the leads is unverified, so it's both a likely probe and something you need to know |
| E2 | "Our squads will build from your specs. What goes into a spec you'd hand them, and what would you need back from them?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure it: the problem, who it's for, acceptance criteria, what's out of scope, and how success is measured. What you'd need back: estimates, risks, and early pushback. Answer slot: if the requirements stage of those integrations produced documents you wrote, say what they covered, in your own words. If not, say so plainly | Covers F8, the spec line. JD content with CASE delivery |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | Pause, then restate the question. Hold on the quote: the integrations and their stages. Don't compare yourself with someone you can't see. If pushed twice, concede specifically: "I haven't held a product manager title or role." Then return to the integrations and the plan. Don't fold on the integrations to restore harmony | A1 in a time-boxed register. Hold-then-concede on F1 |
| F2 | "Those 30-plus integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote's verb: "I led them." Answer slot: which parts were yours and which were others', in your own words. If some stages were someone else's, say so plainly. Precision here builds credibility rather than costing it | The persona's attribution stem applied to the one figure (F3). EXP because it scores attribution |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time where the stakes were named, you said the hard thing, and it landed, with the relationship intact at the end. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem. With no values round detected this is low weight, but candor gets probed in any round |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a real choice where the customer and the metric pulled apart and you chose the customer, with the cost stated. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem that suits a partner-facing role |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A2, D2, F1 |
| R2: Shipped API or platform products | A3 |
| R3: Technical fluency (API docs, schemas) | C2, D3 |
| R4: Stakeholder management (engineering, sales, customers) | A4 |
| R5: Agile delivery experience | A5 |
| Own the roadmap | A1, A2, B3 |
| Run discovery with integration partners | C3, B2 |
| Write specs and drive delivery with two squads | E1, E2 |
| Define and track adoption metrics | B1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From your dossier. Decision authority is asserted in the JD but not evidenced. It reads as diligence, and the answer tells you whether "own the roadmap" is real |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | From your dossier. Adoption is named as a responsibility with no baseline stated. You'd be accountable for a number you haven't seen yet |
| RQ3 | "Where do partner requests enter the roadmap today, and who says no to them?" | It tests the same authority risk from the partner side, and it shows you think about saying no, which is the core of the job |
| RQ4 | "When a new partner signs, who takes them from signed to live, and where does that hand off to this role?" | It brings the conversation onto the integration path, which your F3 and F5 work sits beside, without you having to claim anything |
| RQ5 | "What would make you say, six months in, that this hire was the right call?" | You get their real success criteria in their own words, which you can then answer against in later rounds |
| RQ6 | "What do the two squads most need from a PM that they don't get today?" | Reciprocity framing: it shows you're thinking about reducing the squads' load, not adding to it |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role, including "my integration work was basically PM work" | Dossier `prohibited_claims` | "I haven't held a product manager title or role." Then F1's quote at its own scope, positioned as adjacent |
| Having owned a product roadmap | Dossier `prohibited_claims` and `acknowledge_gap` area | "I haven't owned a product roadmap." Then a ramp plan. No bridge, and not the roadmap-input sessions |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says integrations of the vendor's REST APIs, not shipping the product. A3's slot stays inside the integrations |
| Ran discovery with partners, or shaped product direction | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says feeding client evidence to product. C3's slot asks only what you know came of it |
| The playbook as API documentation or schema work | Inflated form of F4 | F4's quote, "Wrote the internal integration playbook her team uses," at its own scope. C2's slot asks only what the playbook covers |
| Wrote product specs for engineering squads | Inflated form of F8 | F8's quote at its own scope. "Requirements" is one stage the quote lists. E2's slot asks only what any documents you wrote at that stage covered |

---

## Sources

**Provided documents:** `tuesday-dossier.md`, envelope v1.1 (major version 1, which this skill reads), generated 2026-08-14. Sections consumed:
- `role_profile`: requirements R1 to R5 and the responsibilities, used as the JD.
- `handoff_to_mock_interview`: verified evidence (the CV equivalent), weak areas and their strategies, the A1 objection, the reverse questions RQ1 and RQ2, and `prohibited_claims`.
- `decision`: context only.

The dossier has no `evidence_map`, `evidence_state` or `risk_register`. The requirements reflect the posting as captured in August. If it has changed since, the rows that quote it should change too.

**Searches sent:**
- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline partner API platform news 2026": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have given value names to theme the G bank. No values round is detected either way, so there's no cheat sheet |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. Your own words set this round as one 45-minute hiring-manager conversation, so the persona weights stand. It would have shown what other rounds follow |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have grounded B4 and given the B bank Quartzline-specific cases instead of `[generic]` ones |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Web search permission** → targets 1 to 3 rerun. B4 and the B bank get grounded in Quartzline's current strategy, and the G bank is themed on their published values. An optional deeper pass adds up to 6 more searches and 2 more fetches and takes several more minutes.
- **The hiring manager's name** → an interviewer read, persona weights adjusted from their public professional footprint, and a reverse question tied to their own career path.
- **Something inspectable behind the roadmap-input sessions**, such as a session agenda or the summary you sent to product → F7 and C3 could move from medium toward high confidence.
- **Your answers to the answer slots, told to me outside a drill** → F4, F6, F8, F9 and F10, along with A4, A5, D3 and E2, could move from slots to quoted, story-mapped guidance.
- **Your current CV** → more sentences to quote, which may fill rows that currently read `none given`.
- **Recruiter guidance** (focus areas, anything to prepare in advance) → coverage of any pre-declared deliverable, with its own build section.
- **How much prep time you have** → a prioritized prep schedule at the top of the pack.
