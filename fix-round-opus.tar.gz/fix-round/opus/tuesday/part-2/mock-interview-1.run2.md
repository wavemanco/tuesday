I'm running the default research pass for Northwind Data and Dan before I build the pack.
I've built Priya's prep pack for her 60-minute peer conversation with Dan Kovac. It has 22 questions across seven interviewer personas. Each one has a question type, a source label, answer guidance and the rationale for including and categorizing it. It's saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-1-denied-05141fe3/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`.

The web searches for Northwind's values, its interview process and Dan's public profile were refused permission. So the pack uses only what you gave me: the JD highlights, your notes on Priya and Dan, and your research note.

- **Persona weights:** the Data-Driven Prober, Peer Evaluator and Case/Strategist banks get the most questions. The case questions lean toward pricing and packaging because of Dan's monetization background, and they're built on Compass, the bundling threat and the profitability push from your research note.
- **Highest-ROI prep (D1):** "You haven't done sales ops or set quotas — how does that not become my problem?" This uses the "No classic sales-ops or quota-setting" line from your notes. It's rehearsed with a plain admission up front, three likely follow-ups, and a specific point where she concedes. Priya should confirm that wording is hers.
- **The JD's one required line is the second biggest gap.** Her partner-level revenue model was used in carrier negotiations, but that isn't the same as designing a partner motion. A3 and C3 cover it.
- **The ~$400M figure:** the guidance keeps her verbs, "proposed" and "credited with", and never turns them into "drove". A1, A2 and E1 drill how the number was counted and which part was hers.
- **Other sections:** a fit snapshot, a read on Dan, six reverse questions and a requirement-coverage table. There's also a list of claims the pack won't coach, such as "delivered $400M" or "designed partner programs".
- **Left out:** there's no values cheat sheet, because no values round was named. There's no prep schedule, because I don't know how much prep time she has.
- **Upgrade menu at the end:** it lists what would sharpen the pack, such as allowing web search or adding the full JD.

If you'd like, I can play Dan as the Skeptic on D1, the highest-ROI question, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya · **Interviewer:** Dan Kovac, Director of Sales Strategy, a **peer** (you would both report to the same VP) · **Format:** one 60-minute conversation

---

## How to use this pack

Two axes organize every question:

- **Persona** is *how* a question arrives: the register, the pace, the follow-ups. Banks are ordered by how likely each persona is from Dan.
- **Type** is *what* is being scored.

| Tag | Scores |
|---|---|
| **EXP** | Work-experience deep-dive: do the claims survive scrutiny, and what was actually yours |
| **JD** | Role-driven: can you do the listed job, gaps included |
| **CO** | Company and strategy: can you think at Northwind's altitude |
| **CASE** | Live problem set in the role: structure and reasoning, said out loud |
| **VAL** | Behavioral: past behavior against values or principles |

Each question has one primary type. Where a question scores two things, the rationale names the second ("JD content, CASE delivery").

**Provenance labels:** `[grounded]` traces to something you supplied (the JD highlights, the coach's notes on Priya, the interviewer notes, the research note). `[inferred]` is this pack's own derivation, and the derivation is named. `[generic]` is a role-family pattern that makes no claim about Northwind or Dan.

**Answer slots.** Where the guidance says *Answer slot*, the pack doesn't know the answer and won't invent one. Priya fills it in her own words, or says plainly that the thing didn't happen or wasn't hers. Both branches are good answers.

**The guidance is scaffolding, not a script.** Question IDs are lettered by persona (A, B, C…). **F is reserved for fit-snapshot rows**, so the banks skip it.

---

## Fit snapshot

Requirements are quoted from the JD highlights in your message. Evidence is quoted word for word from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material shows product strategy and ops, and a proposal. It doesn't show GTM ownership of a product line, so the words stay where the quotes are: "I spent nine years in product strategy and ops at a large consumer-tech company, and I proposed a store-surface change that was credited with roughly a $400M ARR uplift." Answer slot: the JD's "own GTM strategy" line makes a probe on go-to-market decisions likely. If any launch or GTM decisions were yours to make, say which ones and how you decided, in your own words. If there was no such step, or it wasn't yours, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Strong evidence here would be an analysis that found where growth sat across a customer lifecycle, plus what was done with it. Answer slot: the JD's land/adopt/expand/renew line makes a probe on lifecycle or whitespace analysis likely. If Priya has done one, she says what it was and which part was hers, in her own words. If not, she says so plainly and describes how she would approach Northwind's (A4 rehearses this) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. Expect a probe, though, because nothing inspectable sits behind the line. Lead with the quote's own terms: skilled in SQL and Tableau. Answer slot: the JD's word "independent" makes a probe on an analysis she ran herself, end to end, likely. If she has one, she walks it through in her own words. If her analyses were usually built with or by others, she says so plainly and stays with what the quote says |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material shows a model she built that others used in negotiations. It doesn't show her designing a partner motion. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's "partner-motion design" line makes a probe likely on whether she shaped partner terms, programs or incentives. If any of those were hers to shape, she says which and how. If none were, she says so plainly and stays with the model she built. This is a *required* line, so the gap matters |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it as influence evidence without adding to it: "I set annual volume targets with consensus across orgs." Expect a probe, since no detail sits behind the line |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Daily tool use isn't shown to reach AI product or AI GTM experience, so don't stretch the bridge. Answer slot: the JD's "AI experience a plus" makes a casual probe likely, and so does Compass in your research note. If any of her work involved an AI product, or AI changing a workflow she owned, she says what it was and which part was hers. If her use is personal tooling, she says so plainly and describes what she uses it for, in her own words |
| F7 | Working fluency in B2B sales operations and quota or capacity planning, the work a Director of Sales Strategy's team sits beside. This is a role-family pattern, not a JD line | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [generic] | capability | The gap is stated in your notes, so the pack can give the words back: "I haven't done classic sales-ops or quota-setting." Then say how she would learn it, as a plan and never as a past. Never a claim to quota work. Never describe the volume targets in F5 as quotas |

---

## Reading the interviewer

Everything here comes from your interviewer notes. The web searches for his public footprint were refused this session (see Sources), so nothing below adds to what you supplied.

| Signal (your notes) | What it likely means for this conversation | Practical move |
|---|---|---|
| Self-describes as "relentlessly data-driven" | Every number gets probed down to its assumptions, especially the ~$400M | Rehearse A1, A2 and E1 until the four defend-the-number slots are automatic. Name the weakest assumption yourself, before he does |
| Career spine is pricing and monetization | Cases tilt toward packaging, pricing and unit economics. That's his native language | On C1, C2 and C4, say the unit-economics step out loud: cost to serve, price metric, payback |
| One early-stage-startup chapter | Builder stories land unusually well. Expect skepticism about big-company pace, and scrappiness probes | Your material holds no clear builder story, so don't invent one. If Priya has a real one, it goes in the upgrade menu first. Otherwise answer pace probes from what F5's quote carries, plus how you'd work at Northwind's size |
| Director of Sales Strategy, a peer under the same VP | He's pricing what this hire adds to his load, or takes off it, and where your turf meets his | Lead with reciprocity (B1, B2). Propose principles for the seam instead of pretending to know where it sits |

**Mirror opportunity, shared vocabulary:** F4's evidence cell, "built a partner-level revenue model used in carrier negotiations", is revenue-model language a pricing person reads natively. Say it at that scope and let him ask the next question.

---

## Persona table

The loop is set by your words: one 60-minute session, run by Dan. No values-style round is named, so no values cheat sheet is included.

| Persona | How it shows up from Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | "How was that counted?" Two levels of follow-up below every answer | **High.** A peer interview starts with Prober high, and his "relentlessly data-driven" self-description raises it again | Know what you can and can't say about how each figure was counted, and say so plainly where you don't know. Name the weakest assumption first. Offer to walk an analysis end to end only if you did it |
| B. Peer Evaluator | "Where's the seam? What do you need from me? What happens when we disagree?" | **High.** This is the peer-relationship prior, and you two would share a VP | Reciprocity framing. Propose principles for the seam. Disagreement handled with data and an escalation you take to the VP together |
| C. Case / Strategist | Live problems on Compass, bundling and profitability, framed as pricing and packaging | **High.** Moved up from the peer prior by his pricing and monetization spine, with your research note supplying live material | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise per case |
| D. Skeptic | Quiet: "I don't see B2B sales in your background…" | **Mid.** Raised by F7 and F4, and by the startup chapter's typical pace skepticism | Rehearse D1 until it's boring. Plain acknowledgment, then the ramp plan. Never bluff a competency he personally owns |
| E. Pressure | Time-boxed or "how much was actually you" | **Low to mid.** Not a stress-interview round, but the Prober register slides into it on the $400M | Pause, restate, anchor in the quote. Hold through two follow-ups, then concede the specific thing |
| G. Conversational | The opener, and a casual AI aside | **Low.** Still scored: the journey answer and the AI question (a JD plus-item) | A 90-second arc. Treat the AI aside as scored |
| H. Values / Behavioral | A stray "tell me about a time…" | **Low.** No values round named, and a peer rarely runs one | Have selection scaffolds ready, with the honest branch |

---

## Question banks

### A. Data-Driven Prober (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the roughly $400M ARR uplift from the store-surface change was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep both of the quote's verbs: you *proposed* the change, and it was *credited with* about $400M ARR uplift. Answer slots, each in your own words: how the figure was counted; what it's sensitive to; the assumption behind it you'd defend least, said before Dan asks; and which part was yours. If you don't know how it was counted, say so: "I don't know exactly how that was counted" is an honest answer. Then return to what you proposed | F1's headline figure is the first thing a self-described data-driven interviewer will pull on. EXP because it tests attribution and counting, not the idea |
| A2 | "Who credited the uplift to that change, and was anything else changing at the same time?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: if you know who credited it, say who; if you don't, say so. On other changes, if things were moving at the same time, say what they were, and how the credit was separated if you know. If you don't know, say so plainly. Stay with "proposed". Don't drift toward "drove" while defending the number | This is the second follow-up level on F1, and a Prober always goes there. Rehearsed separately because "credited with" invites exactly this probe |
| A3 | "Take me through the partner-level revenue model: what went in, how it was structured, what it was most sensitive to." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats the quote states: you built it, it was partner-level, and it was used in carrier negotiations. Answer slot: describe the inputs and structure in your own words, and the sensitivity you'd defend least. If parts were built by others, say which. If the negotiations themselves weren't yours, say so plainly. The quote says the model was *used in* them, not who negotiated | F4 is the evidence for the JD's one *required* line, and Dan's pricing background makes him fluent in exactly this kind of model. EXP because it tests what was yours |
| A4 | "If I gave you our customer and usage tables tomorrow, how would you find whitespace across land, adopt, expand and renew?" | JD | [grounded] | Clarify first: what counts as an account, how the two product lines are defined, how each stage is defined. Then a metric per stage. Land: in-profile accounts without the product. Adopt: depth of usage after purchase. Expand: products or seats per account against similar accounts. Renew: risk signals before the date. Then the joins you'd need, one Tableau view that makes the gaps visible, how you'd validate it, and who acts on it. Close by naming the weakest assumption in your own approach | Covers F2 and F3 together, as a live problem rather than a record, so it needs no claim about your past. JD content, CASE delivery |
| A5 | "How did you arrive at the annual volume targets, and which assumption in them would you defend least?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | The beats the quote states: you set them, every year, with consensus across orgs. Answer slot: how they were arrived at and what they were sensitive to, in your own words, then the assumption you'd defend least. If parts were set by others, say which. Don't call them quotas. F7 is the reason | F5 is the nearest thing on the record to planning work Dan's team does, so he will probe it. EXP because it tests how the figure was really built |

### B. Peer Evaluator (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [generic] | Don't claim to know the seam. Propose principles and ask him to correct them: for example, one source of truth for pipeline and pricing data, a named owner per decision, shared readouts before anything goes to the VP. On disagreement: settle facts first with the same data, separate the facts from the judgment call, and if it's still open, take one joint framing to the VP together rather than two competing ones | Peer prior plus the JD's cross-functional line (F5's requirement). `[generic]` because the seam proposals are a pattern, not knowledge of Northwind's org |
| B2 | "What would you need from my team in your first 90 days, and what would we get from you?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with what he gets, then what you need. Offer only what the quote carries: you're skilled in SQL and Tableau, so offer analysis on accounts where your product lines and his core motion overlap. Ask for: access to pipeline data, time with the people who run planning, and his read on where new products confuse reps. Keep it concrete and short | Reciprocity is what a peer is scoring, and F3 is the one asset you can offer without overstating. JD because it scores cross-functional influence |
| B3 | "Tell me about a time you got consensus across orgs that didn't start out agreeing." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets, set with consensus across orgs. That's what the quote states. Answer slot: the question assumes the orgs started apart. If they did, say where they differed and what part of getting to consensus was yours, in your own words. If they didn't, or that part wasn't yours, say so plainly and pick the nearest true example, or say how you would handle it | F5 is presentation-gap evidence for the cross-functional line, and the open prompt tests whether it holds up as a story. JD because the JD names this requirement |
| B4 | "When work spans our teams, say a partner deal that touches a new product line and the core business, how do you handle credit?" | JD | [generic] | A principle first: credit is named in writing, in the shared readout, before anyone asks. Then the channel-conflict piece: agree upfront how a jointly sourced deal is counted for both teams. If he asks for an instance, use a selection scaffold: pick a time credit was genuinely shared and you said so publicly. If no such time comes to mind, say so plainly and describe how you would handle it | Peer credit-sharing probe, sharpened by the JD's partner-motion line (F4's requirement), where channel credit is the classic friction. `[generic]` because no quote carries a story |

### C. Case / Strategist (high, tilted toward pricing)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is our AI copilot. How would you package and price it for the enterprise base: add-on, tier, or bundled in?" | CASE | [grounded] | Clarify: who buys, who uses it, what it costs to serve per use, and what "launch success" means this year. Lay out three options. A paid add-on is an expansion lever. Inclusion in a top tier pushes upgrades. A bundle defends against a bigger vendor. Score each against the three priorities in your research note: enterprise expansion, profitability (cost to serve sets a floor) and the bundling threat. Recommend one, with a test that would change your mind. Make no claim about how Compass is priced today | The case most grounded in the research note, and Dan's pricing spine makes it his home turf. CASE delivery on CO content |
| C2 | "A much larger platform vendor bundles a good-enough version of one of your new product lines at no extra cost. What's the GTM response?" | CASE | [grounded] | Challenge the premise once: which segments actually see the bundle as good enough? Then segment by exposure. Defend where Northwind is differentiated with proof of value. Don't race to zero where it isn't. Use partner and integration plays to raise switching value. Put retention plays on accounts due at renewal. Consider a packaging response, for example bundling into existing contracts, but weigh it against profitability | The research note names bundling as the main threat, so this is a live scenario for both product lines. CASE, with CO content |
| C3 | "Design the partner motion for one of the two new product lines: which partners, what's in it for them, and how you'd measure it." | JD | [grounded] | Clarify the product and the buyer first. Partner types to consider: technology alliances, cloud marketplaces, resellers, systems integrators. Pick one or two and say why. Partner economics: what they earn and what Northwind gives up. Enablement. Metrics: partner-sourced pipeline against partner-influenced pipeline, attach rate, time to first deal. End with channel-conflict rules against direct sales, which is Dan's seam. If you draw on your own model, keep to A3's quote | The JD's one *required* line (F4's requirement), tested live because the record shows a model, not a designed motion. JD content, CASE delivery |
| C4 | "We need to hit profitability. Which of the two new product lines would you slow down, and how would you decide?" | CASE | [grounded] | Don't dodge the anti-pick. Name the data you'd need for each line: contribution margin, cost to acquire against payback, attach rate to the core product, and option value (does it feed Compass or defend against bundling?). Give a decision rule, apply it, name the line it would slow, and say what would reverse the call | The research note lists profitability as a priority, and a role that owns two product lines has to be able to say no. CASE with CO content |

### D. Skeptic (mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | **Highest-ROI prep in this pack.** "You haven't done sales ops or set quotas. In a role that sits right next to my team, how does that not become my problem?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | Name the limit before he finishes: "I haven't done classic sales-ops or quota-setting." No hedge, no bridge to quotas. Then the plan: first 30 days learning how his team plans, sitting in on a planning cycle and a few pipeline reviews, and agreeing with him what you will *not* redo. Then one adjacent fact at its own scope: "I set annual volume targets with cross-org consensus." Say it and stop. Let him draw the inference. **Follow-up 1:** "Volume targets are basically quotas, right?" Don't adopt it: "They were annual volume targets. I wouldn't call them quotas." **Follow-up 2:** "So how would you build a capacity model for a new product line?" Your plan, plus what you'd ask his team for. **Follow-up 3:** "Why shouldn't the VP hire someone from sales ops?" Return to what the JD asks for: GTM strategy, whitespace, partner design. Concede the specific thing: on day one he knows more about quota design than you do | F7 is the gap a Director of Sales Strategy is best placed to spot, and as a peer he has a direct stake in it. Asked in some form, it decides the conversation. JD because it scores fit to the role |
| D2 | "Consumer tech to B2B data infrastructure: why now, and why Northwind?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Your material doesn't say why Priya is moving, so the reasons are an answer slot: give your real ones, in your own words. Then tie them to something specific in the role: two new product lines, Compass, or the partner motion. Keep it under 60 seconds. A long motivation answer reads as defensive | Motivation consistency is the Skeptic's core probe, and F1's evidence makes the sector switch visible. JD because it tests fit to this role |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Pick a real one, not a disguised strength. The pack's candidates are F7 or F2. For F7, use the plain acknowledgment from D1. For F2, your material doesn't show lifecycle whitespace analysis, so the words are an answer slot: if you have done one, say so and what it was; if not, say so and give A4's approach as your plan. Either way, end with a concrete ramp step | This is the Skeptic's most predictable stem. A rehearsed honest answer changes how D1 lands if both come up. JD because it maps directly to F2 and F7 |

### E. Pressure (low to mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, then **hold:** "I proposed the change. It was credited with roughly $400M ARR uplift." Hold that through two follow-ups. **Concede specifically.** Answer slot: if others built it, shipped it or measured it, say so and name what was theirs. If you don't know how the credit was assigned, say that. Never fold into "it was a team thing" in a way that erases the proposal, and never upgrade "proposed" to "led" or "delivered" | F1's figure is the natural pressure point, and the Prober register slides into this. EXP because it scores attribution honesty under pressure |
| E2 | "Sixty seconds: why you over someone who's already run GTM for a B2B SaaS product?" | JD | [grounded] "2 years strategy consulting at a top firm" and "built a partner-level revenue model used in carrier negotiations" and "skilled in SQL/Tableau" and "No classic sales-ops or quota-setting experience." | Three facts at their own scope: two years of strategy consulting at a top firm; you built a partner-level revenue model used in carrier negotiations; you're skilled in SQL and Tableau. One honest limit: you haven't done classic sales-ops or quota-setting. One forward line: what you'd do first here. Don't claim B2B experience. If he pushes, hold the three facts and concede the limit, in that order | Tests composure on the F1, F4 and F7 gaps under a time box. JD because it scores fit to the stated role |

### G. Conversational (low, still scored)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" and "built a partner-level revenue model used in carrier negotiations" and "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc. Two years of strategy consulting at a top firm. Nine years at a large consumer-tech company in product strategy and ops. Two highlights at the quotes' own verbs: you built a partner-level revenue model used in carrier negotiations, and you proposed a store-surface change credited with about $400M ARR uplift. Close with why this role, using your real reasons from D2's slot. Stop at 90 seconds and let him choose where to dig | The opener is scored on economy, and it seeds the Prober's targets, so every verb here must survive A1 to A3. EXP because it previews the CV claims |
| G2 | "What are you actually playing with in AI these days? Have you looked at Compass?" | JD | [inferred] "uses AI tools daily" | Answer slot: say what you actually use AI tools for every day, in your own words. Don't turn daily use into AI product experience (F6). On Compass, if you haven't used it, say so, then connect it to one priority from your research note: its launch is one of Northwind's three stated priorities, and you'd want to know how it's packaged (C1) | The JD flags AI as a plus, and a casual aside on a plus-item is still scored. `[inferred]` because F6's link to the requirement is the pack's derivation |

### H. Values / Behavioral (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a senior audience who didn't want to hear it, the moment you said it anyway, and an ending where the truth landed and the relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No values round is named, but a stray behavioral question is cheap to prepare for. `[generic]` because no quote carries such a story |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific customer impact, the metric that pulled the other way, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Touches the last persona so it never shows up for the first time live. `[generic]` for the same reason as H1 |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" (F1) | D2, E2, C1, C4 |
| "identify whitespace across land/adopt/expand/renew" (F2) | A4, D3 |
| "run independent analysis in SQL and Tableau" (F3) | A4, B2 |
| "partner-motion design experience required" (F4) | C3, A3, B4 |
| "strong cross-functional influence" (F5) | B1, B2, B3, B4 |
| "AI experience a plus" (F6) | G2, C1 |
| B2B sales-ops fluency, a role-family pattern rather than a JD line (F7) | D1, D3 |

---

## Reverse questions

Dan will save time for these, and a peer treats this slot as a preparation signal.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization. For new products like Compass, how much of pricing and packaging sits with your team, and how much with Emerging Products?" | It's tied to his own path, it's his native subject, and it surfaces the seam directly |
| R2 | "What did your early-stage chapter teach you that you still use at a company Northwind's size?" | It invites his own career story, and it shows you read his profile, not just the company's |
| R3 | "What could someone in this seat do in the first month that would genuinely help your team?" | The reciprocity question. It tells a peer you're there to reduce his load |
| R4 | "When the larger platform vendor bundles against us, where do your reps feel it first: in new deals, or at renewal?" | It uses the research note's competitive frame and treats him as the expert on the front line |
| R5 | "What's the source of truth for pipeline and usage data, and how much of it can I query directly?" | It's practical and shows you'd do your own analysis, as the JD asks |
| R6 | "How is the profitability push changing what a good first year looks like for a new product line?" | It ties to a stated priority and to how you'll actually be judged |

---

## Prohibited claims

These are claims the pack will not coach. Each is the stretched version of something in your notes, the kind of thing a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove, delivered or generated $400M ARR | Inflated form of F1 | F1's quote at its own scope: proposed a store-surface change credited with a ~$400M ARR uplift. The pack's observation: the material says *proposed* and *credited*, not *delivered* |
| Owned GTM for a product line or launch | Inflated form of F1 | F1's quotes at their own scope. The material says product strategy and ops |
| Designed a partner program or partner motion | Inflated form of F4 | F4's quote: built a partner-level revenue model used in carrier negotiations. A3's and F4's slots stay inside the model |
| Negotiated the carrier deals | Inflated form of F4 | The quote says the model was *used in* negotiations, not who negotiated |
| Has set sales quotas or run sales ops | Negative stated in your notes, F7 | The plain acknowledgment: "I haven't done classic sales-ops or quota-setting." No slot |
| Drove alignment across the whole company | Inflated form of F5 | F5's quote: set annual volume targets with cross-org consensus |
| Built or shipped AI products | Inflated form of F6 | F6's quote: uses AI tools daily |

---

## Sources

**Provided documents:** your message, which held the JD highlights, the background notes on Priya (cited above as the coach's notes), the interviewer notes on Dan Kovac, and your research note on Northwind's priorities and main competitive threat.

**Searches sent:**

- `Northwind Data company values`: refused (WebSearch permission not granted)
- `Northwind Data interview process GTM strategy`: refused (WebSearch permission not granted)
- `Dan Kovac Northwind Data sales strategy`: refused (WebSearch permission not granted)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The only call was refused. It would have supplied official value names to theme the H bank, and a values cheat sheet if a values round is ever scheduled |
| 2. `Northwind Data interview process` (GTM / strategy) | unavailable | The only call was refused. It would have shown whether Northwind's wider loop has a case or values round. This session's structure is already fixed by your words |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the current priorities and the competitive threat that feed C1, C2, C4, R4 and R6 |
| 4. `Dan Kovac Northwind Data` | unavailable | The only call was refused. It would have added any public talks or posts to the interviewer read, and possibly a more tailored R1 or R2 |
| 5. Representative JD for the title | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** (refused this session) → targets 1, 2 and 4 run: Northwind's official values, any documented loop structure, and Dan's public talks or posts, which would firm up the interviewer read and R1 and R2. A deeper research pass can follow on top: up to 6 more searches and 2 more fetches, several more minutes. It would add a strategy brief that sharpens C1 to C4 with current numbers and recent moves
- **The full JD text** → the posting's own lines replace the highlights, and any mid-list requirements the highlights left out (a named tool, a method, a metric) get their own questions
- **Priya's CV, or her own words on each row** → evidence cells move from the coach's notes to her own sentences, and the bridges in F1, F2, F4 and F6 can tighten
- **Priya's answers to the answer slots** in A1, A2, A3, A5, F2 and F6 → those rows become story-mapped answers in her own words, and A4 and D3 can draw on a real whitespace example if one exists
- **Priya confirming F7 in her own words** → D1's plain acknowledgment, the highest-ROI rehearsal in the pack, rests on her sentence rather than the coach's note
- **A real builder or fast-pace story from Priya, if one exists** → an answer to Dan's likely scrappiness probe, added as a question in the Skeptic bank
- **Recruiter guidance** (focus areas, anything to prepare in advance) → a build section for any pre-declared deliverable, and coverage reweighted to the stated focus
- **Prep time available** → a prioritized prep-triage schedule at the top of the pack
- **A tuesday-dossier.md from the job-underwriter module** → an evidence-derived highest-ROI objection in place of this pack's inferred one, plus a prohibited-claims list Priya has confirmed. Not needed: this pack is complete without one
