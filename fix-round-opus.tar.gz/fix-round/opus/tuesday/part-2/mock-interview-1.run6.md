I'll write the pack now. The three web searches were refused, so it's built from your notes alone.
I've built Priya's prep pack for the 60-minute conversation with Dan. It's in `northwind-data_senior-gtm-strategy-lead_interview_pack.md` in your working folder.

All three web searches I tried (Northwind's values, a check that your Compass and bundling note is current, Dan's public profile) were refused. So the pack rests only on what you gave me: the JD highlights, your notes on Priya, your description of Dan, and your research note.

**What's in it:**
- **21 questions** in tables, one bank per interviewer style. Each row gives the question type, the sentences from your notes it relies on, answer guidance, and why the question is included and categorized that way.
- **Weighting:** Dan is a peer and calls himself "relentlessly data-driven", so the number-probing bank (A) is heaviest, then the peer-collaboration bank (B). His pricing background pushes the case questions toward Compass packaging and the bundling threat.
- **Highest-priority question: C1, the partner objection.** The JD says partner-motion design is required, and Priya's closest evidence is a partner-level revenue model. The pack gives three levels of follow-up and the exact wording for conceding the gap.
- **Two wording traps it guards against:** the ~$400M was a change she *proposed* that was *credited with* the uplift, and her annual volume targets are not quotas. That second point matters because quota work sits on Dan's own turf. A "prohibited claims" table lists these and the other wordings she shouldn't use.
- **Fit table:** each JD requirement against her evidence, plus a table showing which questions cover each requirement and seven questions for her to ask Dan.

Where your notes don't say what Priya did, the guidance has her answer in her own words, with an honest option that the step never happened. Her answers to those (how the ~$400M was counted, any partner design work, her part in the carrier negotiations) would make the pack much sharper.

The last section lists what else would improve it: the full JD text, her actual CV, and allowing web search.

If you'd like, I'll play Dan as the skeptic on C1 and run a live drill with follow-ups that react to what Priya says.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. He is a **peer**: both roles report to the same VP.
**Format:** one 60-minute conversation.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: the register, the follow-ups, the pressure. **Types** describe *what* is being scored. Each question has one of each, so Priya rehearses delivery as well as content.
- **Guidance is scaffolding, not a script.** Every claim about Priya's past is tied to a sentence quoted from your notes in that row's Provenance cell. If a step isn't in her material, the row gives an **answer slot**: two honest branches she answers in her own words, one of which allows that the thing never happened.
- **Question IDs** use a letter per persona (A1, B2…; the Pressure bank is P, so it doesn't clash with the F rows of the fit snapshot) so drills can refer to them.

| Type | What it scores |
|---|---|
| **VAL** | Whether past behavior shows the company's values, not generic virtue |
| **EXP** | Whether the background claims hold up under questioning, and what was actually hers |
| **JD** | Whether she can do the listed job, including the parts she's missing |
| **CO** | Company and strategy knowledge, and thinking at Northwind's level |
| **CASE** | A live problem from the role, with structure and reasoning shown aloud |

Provenance labels: **[grounded]** traces to your message, **[inferred]** is derived and the derivation is named, **[generic]** is a role-family pattern with no claim about Northwind or Priya.

---

## Fit snapshot

Requirements are the JD highlights from your message. Evidence is your notes on Priya, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Her material says product strategy & ops and a change she proposed. It doesn't say she owned GTM strategy for a product line, and her words shouldn't go further: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: "own GTM strategy" makes a probe on which GTM decisions were hers likely. If any were hers to make, she says which and how she decided, in her own words. If there was no such decision, or it wasn't hers, she says so plainly and stays with the change she proposed |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Strong evidence would be an analysis she ran that found where customers could buy more or renew, and what came of it. Answer slot: if she has done any analysis of where customers could adopt, expand or renew, she says what she looked at and what she found, in her own words. If she hasn't, she says so plainly and describes how she would build the first cut at Northwind |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but a self-reported skill with nothing inspected behind it, so expect a probe. She leads with the skill in the note's terms, then gives one analysis she ran herself (A3) |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model is not partner-motion design, and the JD marks this one *required*. Her words stay at the model's scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's line makes a probe on partner-motion design certain. If she designed any part of a partner motion, she says which part and how, in her own words. If she didn't, she says so plainly and returns to the model she built |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement, in its own terms. She says it as written, "I set annual volume targets with cross-org consensus", and lets Dan make the link to influence |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Using AI tools is a different kind of work from building or launching AI products. Her words stay with use: "I use AI tools daily." Answer slot: if any of that use was in her own analysis or workflows, she names the tools and what for, in her own words. If not, she says so and talks about it as a user |
| F7 | Working fluency in sales-strategy mechanics such as quota, territory and capacity, which a peer in Sales Strategy will expect a GTM lead to engage with | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [generic] | capability | Your notes state this gap, so she can say it back: "I haven't done classic sales-ops or quota-setting." Then a plan to learn it, said as a plan and never as past work. Annual volume targets are not quotas, and she shouldn't present them as quotas |

---

## Reading the interviewer

Web search was refused this session, so everything here comes from your description of Dan's profile. Nothing was checked against a public source.

| Signal | Source | What it means for this conversation |
|---|---|---|
| Self-described "relentlessly data-driven" | Your message | Expect every number to be probed down to its assumptions, starting with the ~$400M. The Prober bank (A) carries the most questions |
| Career spine in pricing and monetization roles | Your message | Pricing, packaging, discount discipline and unit economics are his native language. Case answers should get to those levels fast (D1, D2) |
| One early-stage-startup chapter | Your message | Scrappy builder stories tend to land with people like this, and a question about big-company pace is likely. Her material shows no startup work, so she meets that question with C2's slot and doesn't invent a startup-style story |
| Peer under the same VP | Your message | He is weighing whether she adds to his team's load or lightens it. The quota gap (F7) is his own turf, so how she handles it (C3) is a test of judgment as well as candor |

**Shared ground (vocabulary, not a shared career move):** his monetization background and F4, "built a partner-level revenue model used in carrier negotiations". She can talk about the model in those exact words and let a pricing person find the overlap. She should not claim pricing experience.

---

## Persona table

The format and relationship come from your message (one 60-minute conversation with a peer), so the weights rest on that, not on a guessed company interview pattern. No values round is detected, so Values/Behavioral stays low.

| Persona | How it shows up with Dan | Likelihood, and why | Counter-strategy | Questions |
|---|---|---|---|---|
| A. Data-Driven Prober | "Walk me through how that number was counted"; follow-ups two levels deep | **Highest.** Peers usually lead with this persona, and "relentlessly data-driven" pushes it up further | Know what she can and can't say about how each number was counted, and say plainly when she doesn't know. Name her weakest assumption before he does | A1–A5 |
| B. Peer Evaluator | Where the two teams' work divides, what happens when they disagree, how credit gets shared | **High.** Peers usually lead with this too; same VP, adjacent teams | Frame it as what she brings his team as well as what she needs. Propose principles for dividing the work rather than pretending to know where the line sits | B1–B4 |
| C. Skeptic | Quiet questioning of the partner, B2B and quota gaps | **Medium-high.** F4 is a *required* line, and F7 is Dan's own turf. The startup chapter adds pace skepticism | Rehearse C1 until it bores her. Bridge only from what's in her material, and be candid rather than bluff about the area he owns | C1–C3 |
| D. Case/Strategist | Live problems on Compass, bundling and expansion | **Medium.** Peers ask fewer cases than hiring managers. His pricing background tilts any case toward packaging and economics | Clarify, state the objective, segment, give the approach, the metrics, the risks. Challenge one premise per case | D1–D3 |
| E. Conversational | A friendly opener and a casual question about AI | **Low-medium.** Some rapport opening is near-certain in 60 minutes. AI is the JD's plus, and casual questions about it are still scored | A 90-second career story, practised aloud | E1–E2 |
| P. Pressure | Time-boxed "why you" and "how much was you" | **Low.** Not his relationship's style, but the ~$400M invites it | Pause, restate, anchor in what she stated, hold through two follow-ups | P1–P2 |
| G. Values/Behavioral | One or two behavioral questions | **Low.** No values round detected and Northwind's values aren't in hand | Selection scaffolds, ending in an honest branch | G1–G2 |

**Highest-ROI prep in this pack: C1**, the partner-motion objection. The JD marks partner-motion design *required* and her evidence is a model (F4). It will come up in some form.

---

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background has a store-surface change credited with a ~$400M ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F1, using only what the quote states: she *proposed* the change, and it was *credited with* a ~$400M ARR uplift. She keeps both verbs and the "~". Answer slots, each in her own words: how the figure was counted; what it is sensitive to; the assumption behind it she'd defend least, named before he asks; which part was hers. "I don't know exactly how it was counted" is an honest answer and beats an invented method. Never "I drove $400M" | F1's headline number, and the first thing a self-described data-driven interviewer will open. EXP because it tests the figure and her share of it |
| A2 | "Walk me through the partner-level revenue model you built — what went into it, and how was it used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: she built the model, it was at partner level, and it was used in carrier negotiations. She describes what went into it in her own words. Answer slot: if she was in the negotiations or saw how the model's output was used there, she says what she saw. If the model was handed to others who negotiated, she says so plainly and stays with building it. Offer to walk through the model end to end if Dan wants depth | F4 is her strongest evidence for the partner requirement and the most natural ground with a monetization person. EXP because the question is what was hers |
| A3 | "The role runs independent analysis in SQL and Tableau. Tell me about an analysis you ran yourself, end to end." | JD | [grounded] "skilled in SQL/Tableau" | She opens with the skill in F3's terms. Then a selection scaffold: pick an analysis where she wrote the queries herself, built the view, and a decision followed. It needs the question, the data, one judgment call she made, and what changed. If none comes to mind, she says so plainly, then gives the nearest thing her material carries, or how she'd approach Northwind's first one | Covers F3. JD first because "independent analysis" is a listed responsibility; the open prompt lets Dan test depth without the pack supplying a story |
| A4 | "Walk me through how you set the annual volume targets and got to cross-org consensus." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: she set annual volume targets, and they had cross-org consensus. She tells it in her own words and calls them volume targets, never quotas. Answer slot: the JD's influence line makes a probe on disagreement likely. If the orgs disagreed, she says what happened and which part of resolving it was hers. If they didn't, or the resolution wasn't hers, she says so plainly and stays with setting the targets | F5 is her cross-functional evidence. With a Sales Strategy peer, targets will read as near-quota work, so the rehearsal is precise wording (see F7) |
| A5 | "Say we launch a partner-sourced motion for one of the new lines. What three numbers tell you at 90 days whether it's working?" | CASE | [generic] | Clarify the motion's goal first: net-new logos, reach into a segment, or expansion. Then early signals versus outcomes: partner-sourced pipeline and its conversion versus direct; time-to-first-deal per active partner; a check on conflict with direct sales, like overlap or discount on co-sold deals. Name what each one can't tell you yet at 90 days. No claim about her past is needed | Tests the JD's partner requirement (F4's row) in the metrics-first register Dan prefers. CASE because it's a live problem; [generic] because it's a pattern, not a fact about Northwind |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side under the same VP — where's the seam between Emerging Products GTM and Sales Strategy, and what happens when we disagree?" | JD | [generic] | She proposes principles as a hypothesis and invites correction: "my guess is this role owns the motion design and the whitespace hypotheses for the new lines, and your team owns the core commercial mechanics. Where's that wrong?" For disagreement: agree on the data first, write the trade-off down together, and go to the VP jointly with one document instead of separately. Then she asks what's been messy at that seam before | Scores the JD's cross-functional line (F5's row) with a peer's sharpest question. JD because influence is the requirement; [generic] because nothing here asserts how Northwind divides the work |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | She can use F1: she proposed the change, and the change was credited with the uplift. Answer slot: if others built, shipped or measured it, she names their part and hers in her own words. If she doesn't know how the credit was divided, she says so. The point is that her own wording already shares credit: "proposed", "credited with" | Credit-sharing is a standard peer probe, and F1's own wording shows how she shares credit. EXP because it tests attribution |
| B3 | "What would you need from my team in your first 90 days — and what would you bring us?" | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | What she needs: data access, current pricing and packaging context, and how coverage works today, each phrased as a request. What she brings, in her material's words: she is "skilled in SQL/Tableau", so she can run her own analysis instead of waiting in his analysts' queue; and she "built a partner-level revenue model used in carrier negotiations", which is relevant if partner economics come up. End by offering to show him early cuts before they go anywhere | A reciprocity question from a peer, built on F3 and F4. JD because it tests cross-functional influence in practice |
| B4 | "Compass and the new lines will need pricing and packaging calls. How do you want to work with a pricing-minded peer on that?" | CASE | [grounded] | This uses Compass from your research note and makes no claim about her past. She proposes clear decision rights per call (who decides, who's consulted), a shared test design for packaging experiments with agreed guardrails, and one dashboard both teams trust. She asks him: is Compass one of the two new lines or next to them? | Puts his monetization background next to the Compass priority. CASE (shown as collaboration) because it's a live working problem; [grounded] on your note |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Partner-motion design is listed as required. I see a partner-level revenue model in your background — what partner motion have you actually designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI rehearsal in this pack.** The position she holds is only what the quote carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if she designed any part of a partner motion, she says which part and how, in her own words. If she didn't, she says so plainly in her own words and returns to the model; that's a stated limit, not a confession. **Follow-up 1** ("So you haven't designed one?"): she holds by going back to the model and doesn't add to it. **Follow-up 2** ("Why hire for a required skill you'd be learning?"): she concedes the specific gap, then gives a ramp plan as a plan: map Northwind's existing partners, learn where partner-sourced deals win, design one motion for one line. **Follow-up 3** ("What would that first motion look like?"): she switches to case structure: which partner type, the value to the partner, the economics, enablement, how deals get attributed, and rules for conflict with direct sales. The bundling threat makes this real: distribution through partners is one possible answer | F4 is the biggest gap against a line marked required. It is the single most predictable objection, so it gets the most follow-up levels. JD because it scores the stated requirement directly |
| C2 | "Your nine years are consumer tech. Land, adopt, expand, renew is an enterprise motion — why should I believe this translates?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | She doesn't argue it's the same. She states the background in the quote's words. Answer slot: if any of her consulting work touched B2B or enterprise software, she names it in her own words; if not, she says so plainly. Then a ramp plan as a plan: the customer lifecycle data first, sitting in on renewal and expansion calls, one whitespace cut (D3) in the first month. If Dan pushes on big-company pace, she gives the plan's timing, not a story her material doesn't hold | Covers F2 and F1: the background is the most visible mismatch for an enterprise lifecycle requirement. JD because it scores whether she can do the listed whitespace work |
| C3 | "You haven't set quotas or done sales ops, and that's a lot of my world. How do you do this job without it?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | She says it plainly, in F7's words: "I haven't done classic sales-ops or quota-setting." She doesn't use volume targets as a stand-in. If she mentions them, it's as written, "I set annual volume targets with cross-org consensus", and labelled as different work. Then the reciprocity turn: this is the part of the job where she'd lean on his team, and here's what she'd bring back (B3). Hold through two follow-ups by going back to the plan, never by enlarging the targets | F7 is a gap your notes state outright, and it sits on Dan's own turf, so candor here is also turf awareness. JD because it tests the role's commercial mechanics |

### D. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A much larger platform vendor is bundling something that competes with one of our new lines. How do you shape that line's GTM?" | CASE | [grounded] | Clarify: which segments overlap with the bundle, and what win/loss data shows. Objective: grow without destroying margin, because profitability is a stated priority. Segment: where the bundle is "good enough" versus where depth wins. Approach: don't race to zero; package with existing enterprise contracts; use partners as distribution; price on the value of depth. Metrics: win rate against the bundler, discount depth, attach rate, net retention. Risk: margin erosion. One premise to challenge: does the bundle really reach the same buyer? | Grounded on your note's competitive threat and priorities. CASE delivery, with CO content, because it tests strategy fluency |
| D2 | "Compass is our AI copilot launch. Add-on, tier, or usage-based — and how does that square with profitability?" | CASE | [grounded] | Clarify who Compass is for and what it costs to serve. Lay out the options with trade-offs: an add-on lets you see willingness to pay, a tier drives adoption, usage tracks cost. Tie it to enterprise expansion: Compass as an expand lever in the lifecycle. Propose a test design before committing. Metrics: attach rate, gross margin per account, expansion revenue. She asks what's already decided rather than assuming | His monetization background and your note's Compass priority meet here; this is likely his favorite kind of case. Also covers the JD's AI line (F6's row) from a strategy angle |
| D3 | "Enterprise expansion is a priority. Size the whitespace for one of the new lines in our installed base — what do you need first?" | JD | [grounded] | The JD's whitespace work, delivered as a case. Clarify the line's ideal customer and the current product footprint per account. Structure: accounts by fit by current products, then likelihood to buy, then penetration headroom, split into adopt, expand and renew. Approach: a first query, a Tableau view, and a review with Sales Strategy before it goes to the field. Risks: dirty account hierarchies, and counting double where the bundler already wins | Covers the JD's whitespace line (F2's row) and the analysis line (F3's row) live. JD first, CASE delivery, grounded on your note's expansion priority |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey. Why Northwind, why now?" | CO | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second version: the two stages in the quote's words, then one or two items from F1, F4 or F5, quoted. Answer slot: why Northwind and why now, in her own words. Tying it to the stated priorities (expansion, Compass, profitability) shows homework, but only if those are her real reasons | A near-certain opener, and it's scored. CO because the "why Northwind" half tests homework |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | She starts with F6's words. Answer slot: which tools and what for, in her own words. Then a user's view of what she'd want a copilot like Compass to do in a GTM analyst's day. She never claims AI product work | The JD's AI plus, asked casually. JD because it's the listed plus; Conversational delivery |

### P. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who's run sales strategy at a SaaS company?" | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations"; "No classic sales-ops or quota-setting experience" | Pause, then three beats in her material's words: she's "skilled in SQL/Tableau" and runs her own analysis; she "built a partner-level revenue model used in carrier negotiations"; and F1's proposed change. Then the concession before he asks for it: "I haven't done classic sales-ops or quota-setting." She holds the three beats through two follow-ups and doesn't trade them away to sound agreeable | A time-boxed version of the F1/F4/F7 tension. JD because it scores her against the role |
| P2 | "That ~$400M — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The position she holds: "I proposed the store-surface change; it was credited with a ~$400M ARR uplift." Answer slot: if any other part (the analysis, the rollout) was hers, she says which. If not, she says so plainly. Follow-up 1: she repeats the held line and doesn't enlarge it. Follow-up 2: she concedes exactly what wasn't hers, and doesn't fold on having proposed it | F1's figure, pressure-tested for attribution. EXP because the question is what was hers |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: something with a named stake, data she brought, a moment she didn't back down, and a working relationship intact at the end. "We" for context, "I" for her part. If no such time comes to mind, she says so plainly, then gives the nearest thing her material carries, or how she'd handle it | A common behavioral question and a test of whether she has spine with peers. Northwind's published values weren't obtained, so it's [generic] and not mapped to a value |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a real metric she gave up or delayed, the customer reason, and what happened. For a data-driven interviewer, the trade-off should have numbers if she has them. If no such time comes to mind, she says so plainly and gives how she'd handle it | Tests judgment against metrics, which matters with an interviewer who is metric-first. [generic] for the same reason as G1 |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | P1, D1, D2, D3, E1 |
| "identify whitespace across land/adopt/expand/renew" | C2, D3 |
| "run independent analysis in SQL and Tableau" | A3, D3, B3 |
| "partner-motion design experience required" | C1, A2, A5 |
| "strong cross-functional influence" | B1, A4, B2, B3, B4 |
| "AI experience a plus" | E2, D2 |
| Sales-strategy mechanics (generic, F7) | C3, P1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization. How has that shaped the way Sales Strategy works here?" | Tied to his own career; turns the hour into a peer conversation |
| R2 | "You had an early-stage startup chapter. What from that do you think emerging products here need more of?" | Tied to his own path, and it lets him name the pace he expects |
| R3 | "What could a new person in this role do in their first month that would genuinely help your team?" | The reciprocity question; it shows she's thinking about his workload |
| R4 | "Is Compass one of the two new lines this role covers, or adjacent to them?" | Clarifies scope without assuming. Good homework signal |
| R5 | "Where does the bundling threat show up first in your data: win rates, discounting, or renewals?" | Speaks his data-first language about the stated threat |
| R6 | "How does the profitability goal change what 'good' looks like for a new line's first year?" | Connects a stated priority to how this role will be judged |
| R7 | "Where has the line between your team and this role been messy before?" | Makes B1 a shared problem, and shows she's aware of turf |

---

## Prohibited claims

Things this pack will not coach Priya to say, and the honest version of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove or delivered the ~$400M ARR uplift | Inflated form of F1 | F1's quote as written: she *proposed* the change, and it was *credited with* the uplift. The pack's own observation: her material says she proposed it, not that she delivered it. A1 and P2 keep their slots inside that |
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quotes as written. Her material says product strategy & ops, not GTM ownership |
| Designed a partner motion or program | Inflated form of F4 | F4's quote as written: "built a partner-level revenue model used in carrier negotiations." The pack's observation: her material says a model, not a motion. C1's slot stays inside the model |
| Led or ran the carrier negotiations | Inflated form of F4 | F4's quote: the model was *used in* the negotiations. A2's slot allows that others negotiated |
| Has set quotas or done sales ops, including calling the volume targets quotas | A gap your notes state outright (F7) | F7's acknowledgment: "I haven't done classic sales-ops or quota-setting." Volume targets stay "annual volume targets", as F5 says |
| Built or launched AI products | Inflated form of F6 | F6's quote as written: "uses AI tools daily" |

---

## Sources

- **Provided:** your message, which included the JD highlights, your notes on Priya, your description of Dan's profile, and your research note (priorities: enterprise expansion, the Compass AI copilot launch, profitability; threat: bundling by a much larger platform vendor). The research note couldn't be checked for freshness, so the D bank and B4 rest on it as you gave it.
- **Searches sent:** "Northwind Data company values" (refused); "Northwind Data Compass AI copilot" (refused); "Dan Kovac Northwind Data Director of Sales Strategy" (refused).
- No dossier was used.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data's values | unavailable | Refused. Would have given official value names to anchor G1 and G2. No values cheat sheet either way, since no values round is detected |
| 2. Northwind Data interview process for GTM strategy roles | skipped | Your message already sets the session: one 60-minute conversation with a peer. That fixes the persona weights |
| 3. Northwind Data strategy and recent news | unavailable | Refused. This call was a check of your research note on Compass. It would have confirmed the priorities are current and added recent moves to the D bank |
| 4. Dan Kovac at Northwind Data | unavailable | Refused. Would have checked his public profile and any talks or posts, to sharpen the interviewer section and R1/R2 |
| 5. A representative JD for this title | skipped | You supplied the JD highlights, which set the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text:** catches requirements in the middle of the list (a named tool, method or metric) that the highlights may have left out, and re-checks the coverage table against the full list.
- **Priya's actual CV:** her own wording replaces your notes in every quote, so beats and confidence levels may shift. Every [grounded] row gets more precise.
- **Allowing web search:** official value names for G1–G2, a freshness check on the Compass and bundling note for D1–D2, and Dan's public profile for the interviewer section. After that, a deeper pass is available: up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief and recent org context.
- **Priya's answers to the slots in A1, P2, C1, A2 and A4:** how the ~$400M was counted and her share, any partner-design work, her role in the negotiations, and how consensus was reached. Each answer becomes quoted evidence, and those rows move from slots to mapped stories.
- **A write-up or redacted analysis she can describe from the ~$400M work or the revenue model:** something that can actually be inspected moves F1 and F4 from medium toward high confidence.
- **Recruiter guidance:** if a presentation, POV or focus area was announced, it gets its own build section.
- **Prep time available:** adds a prioritized prep schedule.
- **A tuesday-dossier.md from job-underwriter:** would ground the C1 objection and the prohibited list in verified evidence rather than inference. Not required.
