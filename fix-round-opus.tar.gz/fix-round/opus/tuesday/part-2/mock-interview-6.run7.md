Building your three-round prep pack now. I've read the playbook and am starting the company research (values, interview loop, recent news).
I've saved a prep pack for all three rounds as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-6-denied-cc4f56eb/larkfield-systems_engineering-manager_interview_pack.md`.

I built it from the role summary and the four sentences about yourself in your message. Web search permission wasn't granted, so nothing comes from Larkfield's own pages. That means there's no values cheat sheet for Monday, and the company and strategy questions are generic.

How it's laid out:
- **Shared fit snapshot:** the role's requirements matched against your own words.
- **One section per round:** the interview styles to expect, 8–12 practice questions, and questions for you to ask them.
- **The prep that matters most is question A1:** "two squads and eleven engineers, and you've led six." It will come up in some form in all three rounds. It also covers "I've never managed managers", which you told me yourself.
- **Two of your phrases to keep exactly as you said them:** "after" in your on-call sentence, which isn't the same as "because", and "about 40 interviews", which is not 40 hires.

If you want a live practice run, I'll play your Tuesday interviewer on A1.
I can also save a `tuesday-dossier.md` file that records the gaps this prep turned up, for you to bring to later sessions.
If you'd like the pack as a Word document, I can convert it.

Can you paste the full job description and your CV? I'll keep working without them, but your CV would turn about eight of the open "pick a story" questions into answers built on your actual history.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Loop (three rounds, from your message):**

- **Tuesday, 45 min:** hiring manager. A Director of Engineering who would be your manager.
- **The Thursday after, 60 min:** panel. Two staff engineers and a product manager.
- **The following Monday, 30 min:** VP Engineering. The recruiter described it as "values and leadership philosophy".

Interviewer names: none given.

---

## How to use this pack

Two things organize every question:

- A **persona** is how a question gets asked: who is asking, and in what style.
- A **type** is what the answer is scored on.

Rehearse both. The same question sounds very different as a friendly aside than as a time-boxed challenge.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values or leadership approach they are looking for |
| EXP | Whether what you say about your past holds up under follow-ups, and how much of it was yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's level: strategy, why here, why now |
| CASE | How you structure and reason through a live problem from the role |

**The guidance is scaffolding, not a script.** Each "answer slot" is an instruction for the interview itself. It has two honest options: if you did the thing, say how in your own words; if you didn't, say so plainly. Both options are good answers.

Question IDs are lettered by persona and round. The letter F is skipped so question IDs don't clash with the fit-snapshot rows F1 to F7.

| Round | Banks |
|---|---|
| Tuesday | A to D |
| Thursday | E, G, H, I |
| Monday | J to L |

---

## Fit snapshot (shared across all three rounds)

Every requirement below is quoted from the role description you pasted. The evidence column uses only your own sentences from your message. Everything the pack says about your past comes from these four sentences and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads, so keep your words at that size: "For three years I've been a team lead of six." If the squads turn out to have leads reporting to you, say: "I've never managed managers." Answer slot: "two squads" makes a probe on running work across more than one team likely. If you've done that, say when and which part was yours, in your own words. If you haven't, say so plainly and stay with the team of six |
| F2 | "building device-management services" at an "industrial IoT" company — role description | none given | none | [grounded] | discovery | Strong evidence here would be any work you've done on devices, fleets, embedded systems, or services that manage hardware in the field. Answer slot: if you've done any of that, say what and what part was yours, in your own words. If not, say so plainly, say you're currently at a payments company, and give your plan for learning the domain |
| F3 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | This is one team's quarter, not ongoing delivery ownership for two squads. Keep it at that size: you pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% after it. Note that the sentence says "after", not "because". Answer slot: if you've owned your team's delivery commitments beyond that quarter, say how in your own words. If not, say so plainly and stay with the quarter |
| F4 | "own … hiring" — role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but it's one unverified line, so expect a probe. Lead with the quote's own terms: you run the hiring loop for backend roles. The figure counts interviews, not hires, so keep it attached to interviews |
| F5 | "growth for 11 engineers" — role description | none given | none | [grounded] | discovery | Strong evidence here would be a specific engineer you helped grow: where they started, what you did, and what changed. Answer slot: if you have one, tell it in your own words. If none comes to mind, say so plainly, then say how you would approach growth for a team of eleven |
| F6 | "partner with hardware … on roadmap" — role description | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | No wording closes this gap, and you've said so yourself. Words: "I've never owned a hardware-adjacent roadmap." Then explain how you would learn it, as a plan and never as past experience. Don't add anything to make the gap feel smaller |
| F7 | "partner with … product on roadmap" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | Your sentence mentions roadmap pressure. It doesn't say who the pressure came from or whether you worked through it with a product partner. Answer slot: if you settled that trade-off with a product partner, say how in your own words. If it wasn't a product discussion, or it wasn't yours to settle, say so plainly and stay with what the sentence says |

**Loop source.** Your message establishes this loop: three sessions, and who runs each. The persona weights below follow your schedule, not a generic pattern. The Monday round counts as a values-style round, based on the recruiter's description that you passed on.

---

# Tuesday: Hiring manager (Director of Engineering, your would-be boss), 45 min

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, steady probing of size and domain: two squads compared with a team of six, hardware, device management, why this move | High. Hiring managers are mostly reducing the risk of their gaps, and F1 and F6 are the widest gaps in the snapshot | Rehearse A1 until it bores you. Bridge only from your quotes, say the limit before you're asked, then give a concrete plan for getting up to speed |
| Case / Strategist | Live problems about running these squads: first 90 days, a hardware slip, a squad that keeps missing | High. Hiring managers usually test with problems from their own roadmap | Clarify, then the objective, the approach, metrics and risks. Think out loud, and respectfully challenge one premise per case |
| Data-Driven Prober | Follow-ups on the 60% and the 40 | Medium. Those are the only two numbers in your material (F3, F4), and a manager who reads them closely will probe them | Know what you can and can't say about how each number was counted, and say plainly when you don't know |
| Conversational / Rapport | The opening "walk me through it" and the "what do you want in a manager" exchange | Medium-low. Your would-be boss will spend part of the time on the working relationship, and that part is still scored | Have a 90-second arc ready, built only from your four sentences |

## Question bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role is two squads, eleven engineers. You've been a lead of six. What changes for you, and what worries you about it?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap." | **The highest-ROI rehearsal in the whole pack.** Hold only what the quote carries: "For three years I've been a team lead of six." Name the limit before they do, if the squads have leads: "I've never managed managers." Then the plan, said as a plan and not as experience. Cover how you'd stop being in every room, how you'd keep a clear view of two squads, and what you'd want to learn about the current leads in the first month. Answer slot: if you've run work across more than one team, say when and what part was yours. If you haven't, say so plainly and return to the team of six. On "So you'd be learning on us?", agree that the scale is new, and hold on the three years. Never say it's "basically the same job" | F1 is the most predictable objection to you for this role. It will come up in some form in every round, and a calm answer rehearsed here pays off on Thursday and Monday too. Tagged JD because it scores the stated "two squads" requirement |
| A2 | "A lot of our roadmap is set by hardware timelines. Have you worked to a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Say it plainly first: "I've never owned a hardware-adjacent roadmap." Then give the plan as questions you'd ask the hardware team in your first weeks: how their schedule is set, where software usually waits on them, and how changes reach devices already in the field. Present these as questions to learn the answers to, not as knowledge. Answer slot: if you've partnered with a hardware or firmware team in any form, say how in your own words. If not, say so plainly and stay with the plan | F6 is a gap you stated yourself. A rehearsed, undefensive admission plus a learning plan does better than any bridge. JD because it scores the hardware-partnering line |
| A3 | "What do you know about device management, and how quickly can you be useful?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: if you've worked on devices, fleets or embedded systems in any form, say what in your own words. If not, say plainly that you're currently at a payments company and haven't. Then the ramp plan: who you'd learn from, what you'd read or shadow, and what "useful" looks like at 30 and 90 days. Don't bluff the domain to people who work in it every day | F2 is silence in your material, not a stated absence. The honest answer depends on what's actually true, so the guidance leaves both options open. JD because it scores the device-management line |
| A4 | "Why leave payments for industrial IoT, and why now?" | CO | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Choose reasons that are true and specific: one about the work, and one about the step up in the role. Say them in your own words. Avoid anything negative about your current employer. If part of the reason is the move to a bigger management role, say it straight. It's what the role is | A standard Skeptic motivation probe. A larger role in a different domain invites "why now?". CO because it tests why this company; the company knowledge is not grounded, because research couldn't run |
| A5 | "Tell me about a time you grew someone on your team." | JD | [grounded] | Selection scaffold, because none of your sentences covers this. Choose an engineer whose growth you can describe concretely: where they started, what you did, and what changed that you could see. Say "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach growth for eleven people | F5 has no evidence yet, and "growth" is a stated part of the role. The open prompt's theme comes from the posting's "growth" line |

## Question bank: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit both squads on day one. What do your first 90 days look like?" | CASE | [generic] | Start by clarifying: each squad's charter, whether either has a lead, what's already promised to hardware and product, and what on-call looks like. Then three phases. Listen: one-to-ones with all eleven, the staff engineers and the PM. Map: where delivery and quality actually stand. Act: one visible fix, chosen with the team. Close by asking what they'd want fixed first | The most common hiring-manager case for a new manager. It tests whether you clarify before you plan. Generic because it's a pattern for the problem, not a fact about Larkfield |
| B2 | "Hardware slips a quarter. Product still wants the services feature on the original date. Walk me through it." | CASE | [generic] | Clarify what the feature actually needs from the new hardware. Then lay out the options: decouple it, build against a simulated device, ship a reduced scope, or move the date. Say who decides, what you recommend and why, and how you'd tell all three groups. Challenge one premise, for example whether the date is really fixed | Puts F6 and F7, the two roadmap-partnering requirements, into a live problem that doesn't depend on your past. A good place to show the structure your plan in A2 promised |
| B3 | "One squad consistently hits commitments; the other consistently misses. Diagnose it." | CASE | [generic] | Clarify what "miss" means here and for how long it's been happening. Then hypotheses: scope, dependencies (hardware included), on-call load, staffing, how estimates are made. Say what data you'd look at for each, then how you'd act without blaming the squad that misses. Think out loud | Tests "own delivery" (F3) across two squads, which your material doesn't yet show. A live case lets you show the approach without claiming the history |

## Question bank: Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your path." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc made only of these beats: nine years in engineering; three as a team lead of six; currently at a payments company; you run the hiring loop for backend roles, about 40 interviews last year; and your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. Keep "after". End with why this role, in your own words | The opener is scored on economy. An arc built from your own sentences can't be dismantled by the follow-ups |
| C2 | "What do you need from a manager?" | VAL | [generic] | Name two or three things that are true for you, for example how often you want to check in, what you want escalated, how you like feedback. Then ask what they need from their managers. Keep it about working together, not a wish list | From your would-be boss this is a fit question asked casually. It also sets up reverse question 5 |

## Question bank: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "On-call burden down 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slots, in your own words: how the figure was counted, what it's sensitive to, the assumption behind it you'd defend least (say it before they ask), and which part was yours. If you don't know how it was counted, say so. Your sentence says "after". If other things changed in that period, say so rather than let them find it | It's the headline number in your material (F3), so a prober will go straight for it. Naming the weakest assumption first turns a trap into credibility |
| D2 | "About 40 interviews. Tell me what running the loop actually means." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start with the quote: you run the hiring loop for backend roles. Answer slots: say whether the 40 is interviews you conducted or the loop's total, and how you'd count it. "Own hiring" makes a probe on the loop's design likely. If you set its stages or how candidates are assessed, say how. If there was no such step, or it wasn't yours, say so plainly and describe how you run it | F4 is a strong match but has only one line behind it, and the number is easy to stretch into "hires". EXP because it tests what was actually yours |

## Reverse questions: Tuesday

| # | Question | Why it lands |
|---|---|---|
| 1 | "Six months in, what would tell you this hire was the right one?" | You get their real bar, and you can return to it in the later rounds |
| 2 | "How are the two squads structured today? Is there a lead in each, and how are they doing?" | Tells you whether F1's managing-managers question is real, and shows you're already thinking about the team |
| 3 | "Where does the hardware schedule most often constrain the device-management services?" | Starts the learning A2 promised, and gives you material for Thursday |
| 4 | "What's the biggest delivery risk these squads carry into next year?" | Shows you're thinking about owning delivery, and gives you a live problem to raise on Thursday |
| 5 | "How do you work with your managers: cadence, what you want escalated, how you give feedback?" | This is your future boss. It's the conversation you'll actually be having |
| 6 | "Why is the role open?" | Neutral and normal to ask, and the answer changes what the first 90 days are for |

---

# Thursday: Panel (two staff engineers and a product manager), 60 min

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | "Where's the split between your job and ours?", disagreement scenarios, what you'd need from them | High. All three are partners an EM works alongside: staff engineers on technical direction, the PM on the roadmap. This reading comes from their titles; the panel's brief is unknown | Explain what you'd bring them as well as what you'd need. Propose principles for splitting the work rather than claiming to know where the lines are |
| Data-Driven Prober | Staff engineers digging into the reliability quarter and the hiring loop | Medium. People at staff level tend to check depth with follow-ups | Know what was in the quarter and what was yours. Say "I don't know" where that's true |
| Values / Behavioral | The PM's "tell me about a time" questions on delivery and disagreement | Medium. A cross-functional interviewer usually asks for behavioural stories | Choose stories where the hard truth actually landed. "We" for context, "I" for your part |
| Conversational | Light openers, "what are you curious about here" | Low. A 60-minute panel will have some informal stretches, and those are still scored | Treat casual questions about the domain as scored |

## Question bank: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | PM: "Say we disagree on whether a quarter goes to reliability or to features. How do we settle it?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Tell it in the quote's own terms: you pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% after. "Pushed through against" can sound to a PM like overriding product. Acknowledge the tension rather than celebrate winning. Answer slot: if you worked that trade-off through with a product partner, say how. If not, or the pressure didn't come from product, say so plainly. Then give the principle you'd use with them: shared criteria, agreed in advance | F7 is the thinnest evidence you have on product partnership, and this is the question where the PM will test it. JD because it scores "partner with product on roadmap" |
| E2 | Staff engineer: "You won't be the most technical person on these squads. How do we split decisions?" | CASE | [generic] | Propose a principle, not a boundary you can't know yet. Technical direction is theirs to lead, and people, delivery and priorities are yours. Disagreements get resolved by an agreed rule, for example whoever owns the consequence decides, and you escalate together. Ask what's worked for them before. Close with what you'd bring them, for example cover from interruptions, and protected time | The classic peer question about where the lines sit. Answering with principles rather than a pretend map is the right counter |
| E3 | Staff engineer: "Firmware says the interface you need won't exist until the next hardware revision. What do you do?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | If they ask about your background, say it plainly: "I've never owned a hardware-adjacent roadmap." Then reason through it live. Clarify what the interface actually blocks. Then options: build against a stub or simulation, change the order of work, or negotiate a partial interface. Say who you'd bring in, and ask them how this usually goes here | Puts F6 into the problem staff engineers will actually face with you. The plain admission keeps the case honest |
| E4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and say how credit was shared, with "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then say how you would handle it | A standard peer question about sharing credit. Staff engineers notice who an EM credits |

## Question bank: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What was actually in the reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Start with the quote. Answer slots, in your own words: what work the quarter contained, what you chose and what the team chose, and what on-call looked like before and after. If you don't remember a detail, say so rather than fill it in. Staff engineers will follow a vague answer two levels deeper | F3's story, tested on depth by the people most able to check it. A different angle from D1, which is about the number itself |
| G2 | "How do you keep a backend interview loop calibrated?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start with the quote: you run the hiring loop for backend roles. Answer slot: "own hiring" makes a probe on calibration likely. If you calibrate interviewers or debrief decisions, say how. If there was no such step, say so plainly and describe how you run the loop | F4 tested by people who will sit on your future loops. A credible answer here makes it easier for them to imagine you hiring with them |
| G3 | "How is reliability for a fleet of devices different from reliability for a payments service?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | You're currently at a payments company. Say that and don't claim device experience. Reason out loud with differences as questions you'd want answered: devices you can't easily reach, varied hardware versions, how updates roll out. Then ask them which ones bite here. It's fine to say plainly that this is new to you | F2 asked as a live comparison. You can show reasoning without claiming a history. JD content, CASE delivery |

## Question bank: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | PM: "Tell me about a time a commitment slipped. How did you tell stakeholders?" | VAL | [generic] | Selection scaffold: pick a slip where you were the one who told stakeholders. Cover when you knew, what you said, what you offered instead, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme from the posting's "own delivery". PMs weight early, honest communication about slips heavily |
| H2 | PM: "Tell me about a disagreement with a product partner that changed your mind." | VAL | [generic] | Selection scaffold: a real disagreement, what they knew that you didn't, and what you did differently afterwards. If no such time comes to mind, say so plainly, then say how you'd want disagreements with them to work | Balances E1. It shows you can lose an argument well, which matters with a PM partner (F7) |
| H3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a named customer impact, the metric it cost, and why you chose it. If no such time comes to mind, say so plainly, then give the nearest thing you have | A common behavioural question. For services that run devices customers depend on, it's a likely theme |

## Question bank: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What drew you to this role?" | CO | [generic] | Keep it consistent with A4. The panel may compare notes with Tuesday's interviewer. Be specific about the work, and be honest that part of the draw is the larger role | Consistency between rounds is scored even when the question sounds casual |
| I2 | "What are you curious about in device management?" | JD | [generic] | Treat it as scored. Name two or three real questions you have, and use what you learned in Tuesday's reverse questions 3 and 4 if they gave you anything. Don't pretend to have read more than you have | Casual questions about the domain are scored, and this one tests whether you've started learning (F2) |

## Reverse questions: Thursday

| # | Question | Why it lands |
|---|---|---|
| 1 | Staff engineers: "What could a new EM do in the first month that would genuinely help your work?" | Reciprocity: it treats them as partners and tells you what they need |
| 2 | Staff engineers: "Where do you want an EM to stay out of technical decisions, and where do you want backup?" | Shows you already respect the split you proposed in E2 |
| 3 | PM: "How does roadmap planning with hardware work today, and where does it break?" | Goes straight to F6 and F7, and you learn the real process |
| 4 | "What's on-call like for these services today?" | Ties to the work you described in F3 without overselling it |
| 5 | "What's one thing the last person in this seat did that you'd want kept?" | Shows you'd keep what works rather than tear it up, and the answer tells you about the team's history |

---

# Monday: VP Engineering, "values and leadership philosophy", 30 min

Larkfield's published values could not be fetched (see Sources). There is no values cheat sheet, so the questions below are themed on the recruiter's description of the round.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Leadership philosophy, hard calls, unpopular truths | High. The recruiter named the round "values and leadership philosophy" | Each principle you state should be backed by one of your quoted facts, or said plainly as a belief |
| Pressure | Time-boxed challenges like "why you" and "how much was you" | Medium. Executive rounds are often time-boxed tests of composure, and 30 minutes is short | Pause, restate the question, hold your position through two follow-ups, then concede specifically |
| Case / Strategist | Thinking at the level of the org: structure, growth, managers | Medium-low. Executives usually test altitude, but this round's stated focus is values | Clarify, then structure. Ask what they're seeing |

## Question bank: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure."; "I run our hiring loop for backend roles — about 40 interviews last year." | Two or three principles you actually hold. Attach one to the reliability quarter, in the quote's terms, and one to running the hiring loop. Say what you believe, then the fact. Don't claim the principle caused more than the quote says, and keep "after". A principle with no fact behind it is fine if you call it a belief | The round's headline question. Principles backed by real facts are much stronger than slogans |
| J2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Use the beats the quote states: roadmap pressure, you pushed a reliability quarter through, and on-call burden dropped 60% after. Answer slot: if the pressure came from leadership, say who and how you made the case, in your own words. If it didn't, say so plainly and tell it as it was, or choose another time | The quarter is the closest story your material has to this question (F3). The slot stops it being stretched into a story about leadership if it wasn't one |
| J3 | "Tell me about a people decision you got wrong." | VAL | [generic] | Selection scaffold: a real decision (a hire, a placement, feedback you held back), what you missed, and what you do differently now. If no such time comes to mind, say so plainly, then say how you'd catch one early | "Hiring and growth" is in the role, and executives probe self-awareness in values rounds |
| J4 | "What won't you compromise on as a manager?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name one or two things. If the reliability quarter shows one of them, cite it in the quote's terms. Name the cost honestly, because a principle that costs nothing isn't one | Monday's version of E1. A values interviewer looks for where you've held a line |

## Question bank: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why you over an internal candidate who already knows our hardware?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap."; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Concede first: "I've never owned a hardware-adjacent roadmap." Hold on what your quotes carry: you run the hiring loop for backend roles, and your team's on-call burden dropped 60% after you pushed a reliability quarter through. Hold that through two follow-ups. Don't claim to outdo them on hardware | F6 under time pressure. Hold, then concede, with the concession said in your own stated words |
| K2 | "That on-call result. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the part that's yours by the quote: you pushed the quarter through. Answer slot: say what the team did and what you did, in your own words. If you can't separate them cleanly, say so. Concede that the 60% is your team's figure | The attribution follow-up to D1 and G1, asked by an executive. An honest split here is what makes your values answers believable |

## Question bank: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Your area grows to sixteen engineers. Do you put a manager under you, and how would you choose them?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | If asked, say plainly: "I've never managed managers." Then reason it through: what triggers adding a layer, internal versus external candidates, how you'd assess management potential, and what you'd need to learn to manage a manager. Ask how they've handled this before | F1's gap put to the person who decides how you grow. A plan said as a plan is the honest answer |
| L2 | "What should engineering management look like here in two years?" | CO | [generic] | Clarify first and ask what they see. Then two or three themes you'd want to test. Avoid claims about Larkfield's strategy, because research didn't run | An executive question about altitude. Without research it stays generic, so the guidance keeps it to questions |

## Reverse questions: Monday

| # | Question | Why it lands |
|---|---|---|
| 1 | "What separates your strongest EMs from the rest?" | Gives you their real values directly from them, which stands in for the values page we couldn't read |
| 2 | "What does engineering here need to get better at over the next year?" | Shows you're thinking at their level |
| 3 | "How do you want EMs to handle a call between reliability and roadmap?" | Connects to F3 and lets them describe how they think |
| 4 | "What support do EMs get here when they grow into managing managers?" | Addresses F1 directly as a question about growth |
| 5 | "What would you want me to have learned by the end of year one?" | Gives you their success criteria from the top |

---

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: Lead two squads | A1, L1, K1 |
| F2: Device-management services, industrial IoT | A3, G3, I2 |
| F3: Own delivery | B3, D1, G1, H1 |
| F4: Own hiring | D2, G2 |
| F5: Growth for 11 engineers | A5, J3 |
| F6: Partner with hardware on roadmap | A2, B2, E3, K1 |
| F7: Partner with product on roadmap | E1, B2, H2 |

---

## Prohibited claims

These are claims the pack will not coach in any form. Each one is built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated yourself (F1) | "I've never managed managers." |
| Has owned a hardware-adjacent roadmap | A negative you stated yourself (F6) | "I've never owned a hardware-adjacent roadmap." |
| Has led two squads or eleven engineers | An inflated version of F1 | F1's quote at its own size: three years as team lead of six. The material says one team of six. A1's slot stays inside that team |
| Hired about 40 engineers, or made the hiring decisions | An inflated version of F4 | F4's quote at its own size. The 40 counts interviews, and the material doesn't say who made the decisions. D2's slot asks only what the 40 counts and what was yours |
| The reliability quarter caused the 60% drop | An inflated version of F3 | F3's quote as you said it, with "after". The quote states the order of events, not the cause. D1 and K2 ask about attribution in your own words |
| Led or owned roadmap planning with product | An inflated version of F7 | F7's quote at its own size: you pushed a reliability quarter through against roadmap pressure. E1's slot asks only who you worked it through with |

---

## Sources

**Provided:** your message, which gave the role description, the three-round schedule and the recruiter's description of Monday, and your background in four sentences.

**Searches sent:**

- "Larkfield Systems values": refused (search permission not granted)
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT news 2026": refused

**Fetches:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | The call was refused. It would have supplied the Monday values cheat sheet and the J questions themed on Larkfield's own value names |
| 2. Larkfield Systems interview process, engineering manager | unavailable | The call was refused. Your message already establishes the loop, so persona weights are unaffected. It could have added round formats or a pre-declared exercise |
| 3. Larkfield Systems strategy and recent news | unavailable | The call was refused. It would have grounded B2, L2 and A4 in Larkfield's current priorities instead of leaving them generic |
| 4. Interviewer names at Larkfield Systems | n/a | No names were given, so no query could be formed |
| 5. Representative EM job description | skipped | The role description you pasted fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Larkfield's values page, pasted, or web search allowed:** adds a Monday values cheat sheet with each published value mapped to F3 or F4, or to a selection scaffold, and turns the J questions into one question per value by its official name.
- **Larkfield's engineering or careers pages or recent news, pasted, or a deeper research pass** (with search allowed, up to 6 more searches and 2 more fetches, several more minutes): grounds B2, A4 and L2 in the company's actual strategy, and adds a grounding brief so you sound current.
- **The full job description:** checks for any lower-priority requirements this summary leaves out, which would get new fit rows and JD questions.
- **Your CV:** adds more of your own sentences to quote. A5, H1 to H3, J3 and E4 could become story-mapped answers instead of selection scaffolds.
- **Interviewer names** (the Director, the two staff engineers, the PM, the VP): adds a section reading each interviewer from their public professional footprint, personas per panel member on Thursday, and a reverse question tied to each person's own career.
- **The recruiter's prep notes:** covers any pre-declared exercise, such as a Thursday system-design or planning task, with its own build section.
- **Your answers to the answer slots**, given here rather than in a drill: whether you've run work across more than one team (A1), partnered with hardware or firmware (A2), or worked with devices (A3); an engineer you grew (A5); how the 60% was counted and what was yours (D1, K2); what the 40 counts (D2); and who the roadmap pressure came from (E1, J2). Each would become a quoted fit row, and those questions would become story-mapped.
- **A tuesday-dossier.md from job-underwriter:** would add evidence you've verified and an objection drawn from that evidence rather than inferred. It's useful, not required.
