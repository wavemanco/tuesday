I've built your prep pack. It's saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/tuesday/part-2/rooms/case-2-denied-cf4f21e8/AtlasFreight_operations-manager_interview_pack.md`.

I couldn't look anything up on Atlas Freight because the web searches were blocked. So nothing in the pack about the company comes from research: values-style and "why us" questions are general, and the pack prepares you for any round with every interviewer style weighted equally.

**What's in it:**
- **Fit check:** each line of the job description set against what you told me, and where the gaps are.
- **22 practice questions:** each with answer guidance and why it's likely.
- **Coverage table:** which questions cover each line of the job description.
- **Reverse questions:** seven for you to ask them.
- **Claims to avoid:** things the pack won't coach you to say.

**Practise this one most:** question A1, the jump from 3 supervisors at your site to 12 across four sites. You'll get some version of it.

**The other places they'll push:**
- **Power BI:** you've never used it, so say that plainly and give a learning plan.
- **Leadership years:** the job asks for 5+ years leading people. You have 7 years in operations, but how many of those were leading people? Give the exact count.
- **The 40% mis-pick cut:** be ready to say how it was counted and which part was yours.
- **Linking your work to their metrics:** don't claim the pick-path redesign improved on-time performance or cost per shipment unless you actually measured that.

Next steps:
- If you'd like a live practice run, I can play the skeptical interviewer on A1 and give you feedback afterwards.
- I can also save a tuesday-dossier.md, a file recording the gaps this prep found, for you to bring to later sessions.
- If you want the pack as a Word document, I'll convert it.
- If you allow web search, I can run the company research and rebuild the parts it affects.

Do you know who you're meeting (a recruiter, the hiring manager, a panel), and did the invite mention a presentation or exercise? Knowing that changes which questions to focus on.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** unknown. Round type: unknown. This pack prepares you for the full loop with flat persona weights, which makes it noticeably weaker than a pack built for a known round. Tell me who you're meeting and I'll reweight it.

## How to use this pack

Two axes. **Personas** describe how a question is asked: who is asking and in what style. **Types** describe what is being scored.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values they care about |
| EXP | Whether your stated experience holds up, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Your homework on the company and why you want it |
| CASE | How you structure a live problem from the role |

The guidance is scaffolding, not a script. Every claim about your past here is built from your own sentences, quoted. Where your material doesn't say something, the pack gives you an **answer slot**: a two-branch instruction for the interview ("if you did this, say how in your own words; if not, say so plainly"). It never fills the gap for you.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows warehouse and distribution work under one shift-manager role. It doesn't show terminal work or more than one site, and your words stay at that scope: "Seven years in warehouse and distribution ops, and I'm currently a senior shift manager over three supervisors." Answer slot: the JD's terminal and four-site lines make both probes likely. If any of your work covered terminal operations or more than one site, say where and what, in your own words. If none did, say so plainly and stay with the warehouse and distribution work |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A surge plan and a mis-pick figure touch on-time delivery, but nothing you've told me shows an on-time measure. Don't stretch the link. Answer slot: if you tracked or moved on-time performance during peak or after the redesign, say what was measured and what it showed, in your own words. If you didn't, say so plainly and describe the plan and the redesign as you stated them |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | Mis-pick rate is an accuracy figure, not a cost figure. Answer slot: if you know what the redesign did to cost, or you've worked to a cost-per-unit or cost-per-shipment number, say what and how it was counted, in your own words. If not, say so plainly and keep the 40% as an accuracy result |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The scale gap is three supervisors to twelve, and it's the gap an interviewer will press hardest. Words at your scope: "Today I lead three supervisors." Answer slot: if you have led more supervisors at any point, during peak included, say when and how many. If not, say so plainly and talk about how you'd take on twelve, said as a plan, never as a past |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill level. It doesn't show reports you've built. Answer slot: if you've built reports or trackers in Excel that others used, say what they tracked and who used them, in your own words. If not, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in … Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording can't close, and you've said so. Words: "I haven't used Power BI." Then how you'd learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years in ops is not the same as seven years of leadership. Your material doesn't say how many of the seven were leading people. This is a length-of-experience requirement, not a hard gate, but it may be screened literally. Answer slot: count your leadership years honestly, in your own words, and don't round up. If the count is under five, say so plainly and lead with what the role over three supervisors involves |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. The certificate exists but hasn't been inspected, so expect a probe on whether you've used it. Lead with the credential in its own terms: green belt certified. Answer slot: if you have run or worked on a project using it, say which and what you did. If not, say so plainly |

## Persona table

No interviewer, round or company loop is known: all three company searches were refused (see Sources), so no loop source establishes the loop. **The weights below fall back to the Generic archetype (screen → hiring manager → panel) with flat weights.** They rest on a pattern, not on Atlas Freight's documented process.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Presses the scale jump and the Power BI gap | Flat weight. Gets one extra question because it holds the highest-ROI objection (A1). A JD this specific about scale, 4 sites and 12 supervisors, gives any interviewer the obvious probe | Rehearse A1 until it's boring. Hold only what your quotes carry, then give a ramp plan said as a plan |
| Case / Strategist | Live diagnosis on on-time and cost-per-shipment | Flat weight. Both metrics are the JD's headline outcomes, so a hiring manager is likely to ask live problems on them | Clarify, objective, segment, approach, metrics, risks. Think aloud |
| Data-Driven Prober | Digs into the 40% and the peak plan | Flat weight. Your one quantified claim is the magnet target | Know how the 40% was counted, or say plainly that you don't |
| Pressure | Time-boxed challenges on attribution and years | Flat weight | Pause, restate, anchor in what you said, hold through two follow-ups |
| Values / Behavioral | STAR stories on leading supervisors and change | Flat weight. No values round was detected, and none is assumed | Map stories only to what you actually did; pick, don't invent |
| Conversational | Openers, a casual Lean/Six Sigma probe, "why us" | Flat weight. The casual register is still scored | A pre-built 90-second arc from your own facts |
| Peer Evaluator | Seams with other site leads, credit-sharing | Flat weight. Plausible if a panel includes peers | Propose seam principles, don't pretend to know the seam |

## Question banks

**Highest-ROI prep in this pack: A1**, the jump from three supervisors to twelve across four sites. Some version of it will come up.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a shift manager over 3 supervisors. This role leads 12 supervisors across four sites. What makes you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | The deepest rehearsal here. Name the limit before they do, using your own words: "Today I lead three supervisors." Then the surge plan, in the quote's terms: you ran the site's peak-season surge plan, two years running. Answer slot: the JD's 12-supervisor line makes a probe on that plan's scale likely. If it had you directing more supervisors or crews than your usual three, say how many and how, in your own words. If it didn't, say so plainly and stay with the plan you ran. Then give a ramp plan for four sites and twelve supervisors, said as what you would do. Follow-up 1 ("what about running multiple sites?"): return to what you stated, add nothing. Follow-up 2: concede specifically, for example "the number of sites is the new part", and hold that the three-supervisor role and the surge plan are real | F4 and F1 are the widest gaps, so this objection will come in some form. JD because it scores the stated scale requirement directly |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "solid Excel" | Answer it straight, with no fake weakness: "I haven't used Power BI." Then what you carry: solid Excel. Then how you'd learn Power BI, as a plan with a timeframe you choose. Don't claim Excel makes Power BI quick to pick up. That's a claim you'd have to defend | F6 is the one gap you've already stated, so the honest answer is ready-made. A rehearsed straight answer reads as self-awareness |
| A3 | "This role is terminal operations. Your background is warehouse and distribution. What carries over, and what doesn't?" | JD | [grounded] "7 years in warehouse and distribution ops" | What carries over, at its own scope: seven years in warehouse and distribution ops. Answer slot: if any of those years included terminal work, say where and what, in your own words. If none did, say so plainly. For "what doesn't", name what you'd want to learn first about how their four terminals run, framed as questions to them, not as claims about how terminals work. Don't use the JD's word "terminal" for your own past unless it was | F1's transferability gap. JD because it tests the stated domain |
| A4 | "Why leave your current role, and why Atlas Freight, why now?" | CO | [generic] | Your reasons aren't in your material, so this is an answer slot: give your real reasons in your own words, without criticising your current employer. For "why here", draw only on what the posting itself says (regional logistics, 800 employees, four sites, a supervisor team to lead) and on anything you've read on their own site. Don't recite facts you can't point to | The standard motivation probe. CO because "why here" is scored on homework. `[generic]` because no company research came back |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four terminals has dropped three weeks running while the other three held. Diagnose it." | CASE, JD | [generic] | Clarify first: how on-time is measured here, when it started, which shifts, lanes or customers. Since only one site moved, ask what's different about that site: people, volume, equipment, schedule changes. Form two or three hypotheses, name the data that would separate them, and give a containment step this week and a fix after. Close with how you'd report it to your manager. The question asks nothing about your past, so this guidance claims nothing about it | A live problem from the JD's on-time line (F2's requirement). CASE delivery, JD content. `[generic]` because it's a pattern, not a fact about this employer |
| B2 | "Take cost-per-shipment down without hurting on-time. Where do you look first?" | CASE, JD | [generic] | Define the metric first: ask what's counted in the cost and the shipment count. Ask where the biggest cost buckets sit, then name the trade-off with on-time out loud. Propose a pilot at one site with a before-and-after measure, then roll out. Challenge one premise respectfully, for example whether cost and on-time are measured the same way at all four sites | The JD's cost line (F3's requirement), asked live. Interviewers use it to see whether you hold two metrics at once |
| B3 | "First 90 days: four sites, twelve supervisors you've never met. What's your plan?" | CASE, JD | [generic] | Listen, then baseline, then pick one or two changes. Weeks 1–4: visit every site and every shift, and meet each supervisor one-on-one. Weeks 4–8: baseline on-time and cost-per-shipment by site. Weeks 8–12: one improvement at the weakest site, measured. Present it as a plan, not as something you've done before | Covers F1 and F4 as a plan rather than a record, where you can be fully honest and still strong |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 40% mis-pick reduction. How was it counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State it in your own sentence's terms: you cut the mis-pick rate 40% by redesigning the pick path. Then four slots, each in your own words: how the rate was counted, and over what period; what it's sensitive to; the assumption behind it you'd defend least, named before they do; and which part of the redesign was yours. "I don't know exactly how it was counted" is an honest answer. A made-up baseline is not | Your one headline figure. Defend-the-number rehearsal per the coverage rule. EXP because it tests what was actually yours |
| C2 | "You ran the peak-season surge plan two years running. What did you look at to judge how it went?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The plan, the site's, two years running: those are the beats. Answer slot: the JD's on-time line makes a probe on peak results likely. If you tracked on-time or any other measure for peak, say which and what it showed, in your own words. If there was no such measure, or tracking it wasn't yours, say so plainly and describe how you ran the plan | F2's thin link, rehearsed so the honest answer is ready. The question's premise comes from the JD, and the guidance doesn't adopt it |
| C3 | "If you joined, how would you build a weekly on-time and cost report across four sites?" | JD, CASE | [grounded] "solid Excel"; "never used Power BI" | Design it live: who reads it, the few numbers on page one, by-site comparison, trend, exceptions. Answer slot: the JD's Excel reporting line makes a probe on reports you've built likely. If you've built reports in Excel that others used, say what and for whom, in your own words. If not, say so plainly and stay with "solid Excel". On Power BI: "I haven't used Power BI," then your learning plan | F5 and F6 together. JD content, CASE delivery |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Forty percent. How much of that was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate. Hold the sentence you gave: you cut the mis-pick rate 40% by redesigning the pick path. Answer slot: say which part of the redesign was yours and who else was involved, in your own words. If it was all yours, say so without apology. Follow-up 1: repeat the same scope, don't widen it. Follow-up 2: concede what you genuinely don't know, for example how much other factors contributed, and don't fold on the part that was yours | The attribution probe on your headline figure. Hold-then-concede on C1's number |
| D2 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "green belt certified" | Under 60 seconds. Concede the question's point, that an internal candidate knows these terminals, without arguing it. Then three of your own facts: seven years in warehouse and distribution ops, currently over three supervisors, green belt certified. Close with one sentence on what you'd do first (from B3). Don't knock the internal candidate | Composure test with a built-in concession. JD because it asks you to make the fit case |
| D3 | "The JD says 5+ years of operations leadership. How many of your seven years were actually leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot, and the one place rounding up is most tempting: give the count in your own words, exactly. If it's five or more, say it and stop. If it's under five, say so plainly and point to the current role over three supervisors. Don't argue the requirement. Hold on the true count through the follow-up | F7. A titled-years requirement may be screened literally, so a clean, exact answer beats a vague one |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to address a supervisor who wasn't performing." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick one instance from your work, current role included, with a named problem, what you said, what you did, and how it ended. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Themed by the JD's supervisor line (F4). Behavioral, so VAL. No published values were found to map to |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a named stake, what you said and to whom, and whether it landed. Don't supply an ending it didn't have. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. Common in any behavioral round |
| E3 | "When you redesigned the pick path, how did the people working it react, and what did you do?" | VAL, EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The redesign and the 40% are the beats you've stated. Answer slot: the JD's supervisor-leadership line makes a probe on bringing a team through change likely. If there was pushback, say what it was and what you did, in your own words. If there wasn't any, or handling it wasn't yours, say so plainly and describe the redesign as you stated it | Leadership through change, tied to your strongest story. Dual-tagged because it also tests the record |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc from your facts only. Seven years in warehouse and distribution ops. Now senior shift manager over three supervisors. Two things to point to: the mis-pick rate cut 40% by redesigning the pick path, and running the site's peak-season surge plan two years running. Green belt certified. End with why this role, in your own words. Pre-script it and time it | The opener in every round. A tight arc sets up everything after it |
| F2 | "What are you actually doing with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say the credential: green belt certified. Answer slot: the JD lists Lean/Six Sigma as a plus, so expect a probe on use. If you've applied it to a project, say which and what you did, in your own words. If not, say so plainly. Don't attach it to a project it wasn't used on | F8. The JD's plus-skill, asked casually but scored |
| F3 | "What do you know about Atlas Freight?" | CO | [generic] | Say only what you can point to: the posting (regional logistics, 800 employees, four sites) and anything you read on their own site or news before the interview. Then turn it into a question (see the reverse questions). Never guess at their customers, lanes or numbers | Homework probe. `[generic]` because company research didn't run. Reading their site yourself before the day closes this |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "We'd be running sites side by side. Where's the seam, and what happens when we disagree?" | CASE, VAL | [generic] | Don't pretend to know their seam. Propose principles: shared definitions of the metrics, a weekly touchpoint, escalate on data, not opinion. Then ask what the seam looks like today | Peer partnership fit. Plausible on any panel |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: a piece of work where others contributed, what each did, and how you said so. If the pick-path redesign fits, use it only with the attribution you'd give in D1. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing probe. Ties back to D1 so your attribution stays consistent across rounds |
| G3 | "What would you need from the other site leads in your first month, and what would you bring us?" | VAL | [grounded] "solid Excel"; "green belt certified" | Need: access, their read on each site, one honest "what's broken". Bring, at your own scope: solid Excel, green belt certified. Offer something concrete, for example a shared baseline of the numbers from B3, as an offer, not a past | Reciprocity question for a peer interviewer |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, B1, B3 |
| Drive on-time performance | B1, C2, C3 |
| Cost-per-shipment down | B2, C3 |
| Lead a team of 12 supervisors | A1, B3, E1, E3 |
| Build reporting in Excel/Power BI | A2, C3 |
| 5+ years operations leadership required | D3 |
| Lean/Six Sigma a plus | F2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is on-time performance measured today, and how do the four sites compare?" | Shows you think in the JD's own metric, and tells you the baseline you'd inherit |
| "What goes into cost-per-shipment in your numbers?" | Shows you know a metric's definition matters before you try to move it |
| "What reporting exists today in Excel or Power BI, and what would you want built first?" | Shows ownership of the reporting line, and tells you how much Power BI the first months really need |
| "How long have the twelve supervisors been in their roles, and how are they spread across the sites?" | Shows you're already thinking about the team, and sizes the leadership challenge |
| "What would make the first six months a success for this role?" | Gets their scorecard in their words, so you can check your answers against it |
| "Why is this role open?" | Tells you whether you'd be replacing someone, inheriting a problem, or covering growth |
| "Where does Lean or Six Sigma show up in how the sites run today?" | Opens the plus-skill without overclaiming it |

## Prohibited claims

What this pack will not coach, and why. The honest form is what to say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run terminal or multi-site operations | Inflated form of F1 | F1's quotes at their own scope. The pack's observation: your material says warehouse and distribution, one shift-manager role. A3's slot stays within your seven years |
| Has led a team of twelve supervisors, or supervisors at that scale | Inflated form of F4 | "Currently a senior shift manager over 3 supervisors." A1's slot asks only about the surge plan's scale |
| Improved on-time performance or reduced cost-per-shipment | Inflated form of F2 and F3 | The 40% stays an accuracy figure about mis-picks. C2's and F3's slots ask only what was measured |
| Seven years of operations leadership | Inflated form of F7 | "7 years in warehouse and distribution ops." D3's slot asks for the exact count |
| Has built Excel reporting or dashboards | Inflated form of F5 | "Solid Excel." C3's slot asks only what you built, if anything |
| Designed or wrote the peak-season surge plan | Inflated form of "ran the site's peak-season surge plan two years running" | You ran it. Say "ran", not "built" or "designed" |
| Has used Power BI | Negative you stated, F6 | "I haven't used Power BI." No slot |

## Sources

- **Provided:** the job description and your background, both pasted in your message.
- **Searches sent:**
  - `"Atlas Freight" regional logistics company values`: refused
  - `"Atlas Freight" operations manager interview process`: refused
  - `"Atlas Freight" terminals news 2026`: refused
- No fetches. No dossier present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search refused. Would have themed VAL questions to published values; E1–E3 and G1–G3 stay role-generic |
| 2. `Atlas Freight interview process operations manager` | unavailable | Search refused. Would have named the rounds; persona weights fell back to the Generic archetype, flat |
| 3. `Atlas Freight strategy` / recent news | unavailable | Search refused. Would have grounded one CO or CASE question in current strategy; A4 and F3 stay `[generic]` |
| 4. `{interviewer name} Atlas Freight` | n/a | No name given, so there was no query to form; no interviewer read |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting and what round (hiring manager, recruiter screen, panel, site visit) → persona weights from that relationship instead of flat, with banks reweighted and resized
- The interviewer's name → an interviewer read from their public profile and a reverse question tied to their path
- The recruiter's invite or prep email, especially any presentation, case or exercise → a build section for that deliverable
- Allowing web search for this session → the three company targets run: real values for VAL questions, the actual loop for persona weights, and a CO or CASE question grounded in current news. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can follow on request
- How much prep time you have → a prioritised prep schedule
- Your answers to the answer slots (how the 40% was counted and your part in it, your leadership years, the surge plan's scale, any Excel reports you've built, any green belt project) → F2, F3, F5 and F7 regrade, and A1, C1, C2, C3, D1, D3 and F2 become story-mapped instead of slotted
- An inspectable artifact, if you have one, such as your green belt certificate or a report you built → the matching rows can move from medium to high
- A tuesday-dossier.md from an underwriting pass → the highest-ROI objection would be evidence-derived rather than inferred, with a strategy constraint on each weak area
