I worked from the background you typed, not from a resume file, and I've treated it as your own account. Because there's no existing resume, the "Current line" column says *(no current line)*. You didn't give an employer name or dates, so I haven't made any up. You'll need to add them.

The big gap comes first. The posting's first must-have is **3+ years of data engineering**. What you have is 5 years as a Senior Data Analyst. No honest rewording turns one into the other, so I haven't tried. What you can show is real engineering-adjacent work: about 25 dbt models, the orders mart's star schema, the nightly dbt job and its tests, and the vendor-API scripts. The ledger leads with that. Every requirement it can't support is listed as a gap below.

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Header / role title | *(no current line)* | "Senior Data Analyst — Retail" | `retitle` | "Senior Data Analyst, 5 years, retail." | `[grounded]` your notes | pending your approval |
| E2 | Summary | *(no current line)* | "Senior data analyst, 5 years in retail. Built and maintained about 25 dbt models, including the core orders mart, and designed its star schema with our then-data engineer. Moving from analytics into data engineering." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE."; "I'm trying to move into data engineering from analytics" | `[grounded]` your notes | pending your approval |
| E3 | Experience, bullet 1 | *(no current line)* | "Built and maintained about 25 dbt models, including the core orders mart" | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your notes | pending your approval |
| E4 | Experience, bullet 2 | *(no current line)* | "Designed the star schema for the orders mart with our then-data engineer" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your notes | pending your approval |
| E5 | Experience, bullet 3 | *(no current line)* | "Fix our nightly dbt job when it breaks; added tests to it" | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your notes | pending your approval |
| E6 | Experience, bullet 4 | *(no current line)* | "Python for analysis (pandas), plus some scripting to pull vendor APIs on a cron" | `compress` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your notes | pending your approval |
| E7 | Experience, bullet 5 | *(no current line)* | "SQL every day on Redshift — complex window functions and CTEs" | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your notes | pending your approval |
| E8 | Skills | *(no current line)* | "SQL (Redshift: window functions, CTEs) · dbt (models, tests) · Python (pandas, API scripting) · cron · star schema design" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I've fixed our nightly dbt job when it breaks and added tests to it."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your notes | pending your approval |

Why some rows look the way they do:
- **E2 and E4 keep "with our then-data engineer."** You designed that schema alongside someone else. Dropping the co-designer would make it sound like you designed it alone, which is the easiest thing for an interviewer to check.
- **E3 keeps "about 25"** and doesn't round it up to "25+".
- **E5 keeps "when it breaks."** I didn't upgrade it to "owned pipeline reliability" or "on-call for production jobs."
- **E6 keeps "some scripting."** Cutting that word would make the scripts sound like production work.
- **E7 is moved below the dbt and schema bullets.** For this posting, the dbt models and the star schema are your strongest evidence, so they come first.
- **E8 leaves out Airflow, Spark and Kafka entirely**, with no "familiar with" either.

## The coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Gap G1. Your 5 years are as an analyst, and no edit changes that | `[grounded]` your notes |
| R2 | Production Python | must-have | `not_evidenced` | E6 shows analysis Python and some API scripting run on a cron. Nothing yet shows it running in production. Recall prompt C1 | `[grounded]` your notes |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | You run scripts on a cron and look after a nightly dbt job, but you never said what schedules that job. Recall prompt C2 | `[grounded]` your notes |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E4 and E2: the star schema for the orders mart, co-designed | `[grounded]` your notes |
| R5 | Model the warehouse (duty) | important | `surfaced_by_edit` | E3 and E2: about 25 dbt models, including the core orders mart | `[grounded]` your notes |
| R6 | Own data quality | important | `surfaced_by_edit` | E5: you added tests to the nightly dbt job. That shows the work, not ownership | `[grounded]` your notes |
| R7 | Own SLAs | important | `not_evidenced` | Nothing in your notes mentions a deadline, an uptime target, or anyone waiting on the nightly job. Recall prompt C3 | `[grounded]` your notes |
| R8 | Batch pipelines with Spark | important | `not_evidenced` | Gap G2. You said "Never used Airflow or Spark." | `[grounded]` your notes |
| R9 | Streaming / Kafka | preferred | `not_evidenced` | Gap G3. You said "Never touched Kafka." | `[grounded]` your notes |
| R10 | Partner with analytics on requirements | important | `not_evidenced` | Gap G4 | `[grounded]` your notes |

Three of the four must-haves (R1, R2 and R3) are `not_evidenced`. Only R4 is surfaced.

## Recovery per gap

**Recall prompts.** These are gaps where something you've done might count. I'm asking about each one in the questions at the end.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python for analysis and some cron scripting against vendor APIs. Nothing says whether that code loaded data other people relied on, or how it was tested and deployed | It's a must-have, and "for analysis" usually reads as notebook work | A vendor-API script that writes into Redshift every day; retry or error handling you added; the code living in git with review | The script's repo, a PR, a README | `[grounded]` what your notes say; `[generic]` how "for analysis" tends to read |
| C2 | Airflow or equivalent orchestration | must-have | A cron, plus a nightly dbt job you fix and test. What schedules the job isn't stated | Cron by itself rarely counts as "equivalent orchestration." A managed scheduler with dependencies and retries might | dbt Cloud scheduled jobs; a CI runner on a schedule; Step Functions; jobs that depend on your API pulls finishing first | A job config, a screenshot of the schedule, a run history | `[grounded]` what your notes say; `[generic]` what typically counts as orchestration |
| C3 | Own SLAs | important | Fixing the nightly job when it breaks implies something depends on it, but nothing is stated | Your notes never mention the "SLAs" in "own data quality and SLAs" | A dashboard or report due by a set hour; alerts that went to you; a run-time or freshness target you worked to | An alert config, a freshness test, a runbook | `[grounded]` what your notes say; `[generic]` what SLA ownership usually looks like |

**Named absences.** These are gaps where nothing you've described applies.

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| G1 | 3+ years data engineering | Your years are analyst years, and the posting calls this a must-have | Wording can't close it. Your options are: apply anyway and accept that the screener might stop at this line; target analytics-engineer or junior/mid DE roles where your dbt and modelling work counts directly; or push for a DE-titled role internally. Whether to apply at all is job-underwriter's call | `[grounded]` your notes; `[generic]` how a must-have years line gets screened |
| G2 | Spark | You've never used it | A real project, such as a PySpark job over a public dataset in a repo you can walk through. It isn't the first must-have, so that alone won't change this application | `[grounded]` your notes |
| G3 | Streaming / Kafka | You've never touched it | The same route: a small, real project of your own. It's only a plus, so it's not worth delaying the application over | `[grounded]` your notes |
| G4 | Partner with analytics | You *are* the analytics side. Writing "partnered with analytics" would put you on the other side of the table | Nothing to close on paper. Your real asset is knowing what analysts need from a warehouse. That's an interview story, and it only goes in the resume if you can tell me about a specific requirement you defined | `[grounded]` your notes |

## Not written, and why

- **"3+ years of data engineering experience" / the title "Data Engineer" or "Analytics Engineer."** Your title was Senior Data Analyst. Changing it would be an upgrade, not an equivalent.
- **"Built and owned ELT pipelines."** "Pipelines" and "owned" are the posting's words. Yours are "dbt models," "scripting," and "fixed … when it breaks."
- **"Production Python."** You wrote "for analysis" and "some scripting." This stays out unless C1 comes back with production detail.
- **"Orchestrated jobs with cron (Airflow-equivalent)."** That claims the two are equivalent, which your notes don't support.
- **Airflow, Spark or Kafka anywhere, even as "familiar with" or "exposure to."** Your own words are "Never used" and "Never touched."
- **"Owned data quality and SLAs."** You added tests and fix breakages. That's the work, not ownership, and SLAs were never mentioned.
- **"Designed the warehouse's dimensional model" / "led schema design."** It was one mart, and you designed it *with* your then-data engineer.
- **"25+ dbt models."** You said "about 25."
- **"Partnered with analytics on requirements."** That inverts the relationship (G4).

## Parse-safety check

You pasted text, not a file, so I couldn't check for columns, tables or text boxes, images or skill bars, content in headers or footers, or the file type. Those checks ran on nothing. The only one I could check is section headings: the ledger uses Summary, Experience and Skills, which are standard. When you build the document, a `.docx` or a PDF with real selectable text is the safe choice.

## Upgrade menu

- **Your actual resume file.** This gives the ledger real current lines and real dates and the employer name, and it lets me run the layout checks above.
- **The vendor-API script repo or a dbt PR.** Either could turn C1 or C5 into evidence I can point to, rather than something you've told me.
- **The nightly job's scheduler config or run history.** This could settle C2 one way or the other.

## Questions

C1 — Did any of the vendor-API scripts load data into Redshift that other people or models relied on, and how were they deployed and kept running?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — What actually schedules and runs the nightly dbt job (dbt Cloud, CI, cron, something else), and does it wait for anything upstream to finish?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Who or what was waiting when the nightly job broke? Was there a deadline, an alert that came to you, or a freshness target?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.