I've built this from the background you typed. I've treated it as your own account of your work, and nothing has been checked against a document. You described your work in prose rather than pasting resume lines, so every "Current line" below says so, and every proposed line comes from one of your sentences, quoted exactly.

The main problem is the first must-have. The posting asks for **"3+ years data engineering"**, and nothing you've told me supports calling any of your five years data engineering. The ledger doesn't hide that. It brings forward the work closest to data engineering (dbt models, the star schema, the nightly job, the cron scripts), uses your own words for it, and lists the gaps below.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line — background given as prose)* | "Senior Data Analyst, 5 years in retail, moving into data engineering. Built and maintained about 25 dbt models, including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E2 | Experience | *(no current line — background given as prose)* | "Built and maintained about 25 dbt models, including the core orders mart" | `surface` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E3 | Experience | *(no current line — background given as prose)* | "Designed the star schema for the orders mart with the data engineer at the time" | `surface` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E4 | Experience | *(no current line — background given as prose)* | "Fix the nightly dbt job when it breaks; added tests to it" | `surface` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E5 | Experience | *(no current line — background given as prose)* | "Python (pandas) for analysis" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E6 | Experience | *(no current line — background given as prose)* | "Python scripts that pull vendor APIs on a cron schedule" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E7 | Experience | *(no current line — background given as prose)* | "SQL daily on Redshift, including complex window functions and CTEs" | `surface` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |
| E8 | Skills | *(no current line — background given as prose)* | "SQL (Redshift), dbt, Python (pandas), cron" | `merge` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |

What the audit held in place:
- **E3** keeps "with the data engineer". You designed the schema together with someone, and dropping that would make it sound like you designed it alone.
- **E2** keeps "about 25" and doesn't turn it into "25+".
- **E4** keeps "when it breaks". Fixing a job when it breaks isn't the same as owning it.
- **E6** says "cron schedule", not "orchestration". "Orchestration" is the posting's word, and you haven't described your work that way.
- **E8** leaves out Airflow, Spark and Kafka, because you've never used them.

**Proposed order of the Experience bullets:** E2, E3, E4, E6, E7, E5. The data-engineering-shaped work goes first, and analysis-only Python goes last. This is a position change only, and nothing gets reworded. — pending your approval

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | G1. Related work is in E2, E3, E4 and E6, but your title and your own description are analytics | `[grounded]` what you said; `[inferred]` a requirement stated in years is often screened literally against job titles |
| R2 | Production Python | must-have | `not_evidenced` | G2. E6 shows scheduled scripts, but not that they run in production | `[grounded]` your message |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | G3. A cron schedule is in E6 and a nightly job is in E4, but neither says what runs them | `[grounded]` your message |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E3. One mart, designed together with a data engineer | `[grounded]` your message |
| R5 | Build batch pipelines | important | `surfaced_by_edit` | E2 and E4 cover the transformation layer only. Nothing says you built the pipeline end to end | `[grounded]` your message |
| R6 | Spark | important | `not_evidenced` | N1 | `[grounded]` "Never used Airflow or Spark." |
| R7 | Model the warehouse | important | `surfaced_by_edit` | E2 and E3. About 25 models and one star schema, not the whole warehouse | `[grounded]` your message |
| R8 | Own data quality | important | `surfaced_by_edit` | E4: you added tests. That doesn't make you the owner | `[grounded]` your message |
| R9 | Own SLAs | important | `not_evidenced` | G3 | `[grounded]` your message |
| R10 | Partner with analytics on requirements | important | `surfaced_by_edit` | E3. You were the analytics side working with a data engineer. This is a real strength, worth explaining in an interview, but the resume doesn't flip it into "partnered with analytics" | `[grounded]` your message |
| R11 | Kafka / streaming | preferred | `not_evidenced` | N2 | `[grounded]` "Never touched Kafka." |

## Gap handling

**Recall prompts** (the questions are at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | 3+ years data engineering | must-have | Five years as an analyst, with dbt work inside that role. It doesn't say how long you've done the dbt work | This is the first must-have, and it's where a reader will put a career-changer's resume aside | How long you've been building and maintaining the dbt models; whether you've been the one people go to when the nightly job fails, and since when; any time you covered for the data engineer after they left | Your dbt commit history dates; a role description or review that mentions the modelling work | `[grounded]` what you said; `[generic]` that screeners read years requirements literally on applications like this |
| G2 | Production Python | must-have | "Python for analysis" and "some scripting" | It's a must-have, and "analysis" reads as notebooks | Whether the vendor-pull scripts feed tables that other people or dashboards depend on; whether they're version-controlled, tested, or handle retries and failures; how many vendors and how long they've run | The scripts' repo; the tables they land in and who uses those tables | `[grounded]` your message; `[generic]` "production" usually means other people depend on it |
| G3 | Orchestration, and SLAs | must-have | A cron schedule and a nightly dbt job, with no word on what runs them | "Or equivalent" gives you an opening only if something real fills it | What triggers the nightly dbt job (dbt Cloud jobs, a scheduler, a cron box); whether it has dependencies or alerting; whether anyone downstream needs its output by a set time | Job configuration, an alert channel, a stated deadline for the data being ready | `[grounded]` your message |

**Named absences:**
- **N1 — Spark.** You've never used it. It's in the responsibilities, not the requirements. A small PySpark batch job on public data gives you something real to talk about, but it's a project, not work experience, and it can't go under your employment history as job experience.
- **N2 — Kafka and streaming.** You've never touched it, and the posting lists it as a plus. It's not worth closing for this application. One weekend project wouldn't read as experience, and that time is better spent on G3.

## Prohibited claims — not written, and why

- **A "Data Engineer" or "Analytics Engineer" title.** Your title was Senior Data Analyst. Changing it is an upgrade, not an equivalent title.
- **"3+ years of data engineering experience"**, or "5 years in data" worded to suggest it. Your five years are analytics years.
- **"Built and owned batch pipelines."** You built models and fix the job. "Own" is the posting's word, not yours.
- **"Owned data quality and SLAs."** You added tests. You haven't mentioned any SLA.
- **"Orchestrated workflows" or "Airflow-equivalent orchestration" for cron.** That would be using the posting's words to describe your history.
- **"Production Python."** Your words were "for analysis" and "some scripting". G2 might change this. Wording alone can't.
- **"Designed the warehouse" or "led dimensional modelling."** You designed one mart's schema, together with the data engineer.
- **"Partnered with analytics teams on requirements."** That flips which side you sat on.
- **"Exposure to Spark/Kafka" or "familiar with streaming."** You said never.
- **"25+ dbt models."** You said "about 25".

## Parse-safety check

Your background came in as prose, not a file, so I couldn't check columns, tables, text boxes, headers and footers, icons, section headings, file type, or hidden text left by an old template. The upgrade menu covers how to run it. Nothing that could be observed carries a parse risk.

## Upgrade menu

- **Your actual resume, as a .docx or PDF.** I'd get real current lines, could propose cuts and reorders against them, and could run the parse-safety check.
- **The vendor-pull scripts' repo, or a description of what consumes their output.** This is the evidence most likely to settle R2.
- **The nightly job's configuration, or a description of it.** This could settle R3 and R9.
- **One honest way to close R3 at work:** move one cron vendor pull into Airflow at your current job. It turns a must-have gap into a real bullet. This is an x offer: it's advice beyond this skill's spec, and I'll scope it only if you ask.

Whether this posting is worth applying to, given R1, is a separate question that job-underwriter is built to answer.

## Questions

G1 — Roughly when did you start building the dbt models and fixing the nightly job, and has that been a steady part of the job since then?
G2 — Do the vendor-pull scripts feed tables or dashboards other people rely on, and are they in version control with any tests or failure handling?
G3 — What actually runs the nightly dbt job and the cron scripts, and does anyone downstream need their output by a set time?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.