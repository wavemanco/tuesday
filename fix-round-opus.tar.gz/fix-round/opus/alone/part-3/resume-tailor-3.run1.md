I've built this from your CV text and the dossier excerpt, so the ledger rows are all I can send until you approve some. Two assumptions: I only have your CV as the sentences you pasted, so each "Current line" below is one of those sentences. And the dossier excerpt covers only R1 and R2, so I worked out the technical fluency and stakeholder management rows myself.

The main finding first. Your CV clearly supports technical fluency and client-facing work. It doesn't support the "3+ years PM" must-have, or owning a roadmap, writing specs, delivery with engineering, or adoption metrics. The dossier reached the same view: your integration leadership is "adjacent" and roadmap ownership is "not evidenced". So the ledger moves your strongest true lines to the front and adds nothing. The gaps are in the coverage map, and the questions at the end are how we could close some of them.

## Edit ledger — every row pending your approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses" as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; inherited from dossier E1, re-checked | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first Experience bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second Experience bullet)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs" under a plain "Skills" heading | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |

What each row keeps from your wording:
- **E1** keeps "the whole team". It doesn't become "company-wide".
- **E2** keeps "our REST APIs". You worked on the vendor's side, and that stays visible.
- **E3** keeps "roadmap-input" and "for product". You gave input to the roadmap; you didn't own it.
- **E4** keeps "Comfortable in". Cutting it would quietly raise your stated skill level.
- **E5** keeps three separate sentences and keeps your title exactly as you wrote it. "Solutions engineer / implementation lead" could mean one title or two, so I haven't split it either way.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | not_evidenced | The dossier rates this adjacent (a transferability gap, medium confidence). Named absence G1; C1 could make the adjacent case stronger | `[grounded]` dossier evidence_map R1 |
| R2 | Shipped API or platform products | important | not_evidenced | The dossier rates this adjacent (medium confidence): you integrated the vendor's APIs but didn't ship them. Named absence G2; C2 could change this | `[grounded]` dossier evidence_map R2 |
| R3 | Technical fluency | important | surfaced_by_edit | E4 and E2 | `[grounded]` CV |
| R4 | Stakeholder management | important | surfaced_by_edit | E3 and E5, in your words rather than the JD's | `[grounded]` CV |
| R5 | Own the partner API roadmap | important | not_evidenced | C1. E3 shows input to a roadmap, not ownership | `[grounded]` CV; dossier R1 reasoning |
| R6 | Discovery with integration partners | important | not_evidenced | Adjacent: the E3 sessions were with your clients, not partners. C1 | `[grounded]` CV |
| R7 | Write specs, drive delivery with two squads | important | not_evidenced | C2 | `[grounded]` CV |
| R8 | Define adoption metrics | important | not_evidenced | C3 | `[grounded]` CV |

## Gap handling

**Recall prompts** (the questions for these are at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership / prioritisation (R1, R5, R6) | must-have | You collected client feedback for product. It doesn't show you deciding what got built | This is the exact gap the dossier names for R1. For a PM role it's the first thing an interviewer will probe | You ranked the feedback before handing it over; product built something because you argued for it; you decided the order of integration work across clients | Your notes from a roadmap-input session, a prioritised list you sent to product | `[grounded]` CV and dossier; `[generic]` PM interviews typically test prioritisation authority |
| C2 | Specs and delivery with engineering (R7, R2) | important | You're comfortable with OpenAPI specs. Nothing shows you writing a spec or seeing engineering work through to release | This is the core of the job and of "shipped API products" | You wrote up an API gap you found during a client integration and engineering built it; you drafted or reviewed OpenAPI definitions for a change; you tracked a fix to release | A ticket, a spec document, an OpenAPI diff, release notes | `[grounded]` CV; `[generic]` the "shipped" requirement is usually read as owning a release |
| C3 | Adoption metrics (R8) | important | No metrics appear anywhere | The JD asks you to define them, and a CV with no numbers about outcomes reads as weak on this | You tracked time-to-go-live across the 30+ integrations; you measured how many teams used the playbook; you watched API usage after go-live | A dashboard, a quarterly report, a SQL query you ran | `[grounded]` CV; `[generic]` |

**Named absences:**
- **G1: you've never held a PM title, and the JD makes 3+ years PM a must-have.** Tailoring can't close this. Only PM work can: a scoped PM or technical PM role first, or a role where the "3+ years" accepts adjacent experience. A strong C1 answer would make the adjacent case harder to dismiss, but it won't change the title. Whether it's worth applying through this gap is job-underwriter's call, and its dossier already says conditional_go.
- **G2: you haven't shipped an API product; you integrated one.** To close this you'd need product ownership of an API change. If C2 turns up a case like that, this becomes a ledger row. If not, it stays a gap.

## Not written, and why

- **"Product Manager", or retitling your role as "Technical Product Lead" or similar.** You've never held the title. That would be an upgrade, not an equivalent.
- **"Owned / shaped the product roadmap".** You "ran quarterly roadmap-input sessions collecting client feedback for product". That's input to a roadmap, not ownership of it.
- **"Shipped / built REST APIs".** You led integrations of "our REST APIs". That's a different verb and a different kind of work.
- **"Ran discovery with integration partners".** This is the JD's wording. Your sessions were with clients and collected feedback. "Partners" would change which side you sat on.
- **"Stakeholder management" as a phrase about your history.** This is also the JD's wording. Your own sentences already show the work.
- **"Wrote specs / PRDs", "drove delivery with engineering".** Being comfortable with OpenAPI specs isn't the same as writing product specs. That stays out unless C2 confirms it.
- **Any metric**, such as "cut onboarding time by X%" or "playbook adopted company-wide". None was given, and "the whole team" stays as written.
- **From the dossier's rejected_inferences (carried over unchanged):** "built an internal request-triage tool — memory lead, candidate could not confirm ownership"; "has been the customer of a partner API platform — candidate worked vendor-side".

## Parse-safety check

Your CV arrived as pasted text, so I couldn't check columns, tables, text boxes, images, header/footer contents, file type, or hidden text. Rows E4 and E5 use standard headings ("Skills", "Summary"), which parsers recognise. The terms a screener might match ("REST APIs", "OpenAPI", "Postman", "SQL") already appear in your own words. "Product manager" can't be placed anywhere truthfully, so it isn't.

## Upgrade menu

- **Your actual CV file:** runs the layout and hidden-text checks, and replaces my sentence-by-sentence "current lines" with your real bullets and their order.
- **The full dossier:** lets me use its R3/R4 rows and full role profile instead of working them out myself, and picks up any pending edits beyond E1.
- **The playbook, or notes from a roadmap-input session:** an inspectable piece of work that could support C1 or C2 directly.
- **Dates and the employer's name:** needed for a finished Experience section. I haven't added either.

## Questions

C1: When you passed client feedback to product, did you decide or rank what went forward, and did anything get built because you pushed for it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Did you ever write up a change to the API (a spec, ticket or OpenAPI edit) that engineering then built and released, and what was your part in it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Did you track any numbers on the integrations or the playbook, such as time to go live, usage, or how many teams used it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.