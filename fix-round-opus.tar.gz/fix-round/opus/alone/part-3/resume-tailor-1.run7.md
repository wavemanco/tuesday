Here's the tailoring for the Tessellate role. One assumption first: you described your CV rather than pasting it, so I've treated each sentence you wrote as an existing CV line. If the real wording differs, paste the file and I'll redo the rows that change.

The JD fits you closely on latency, request volume and incident response. Your CV doesn't say three things the JD treats as must-haves: that the services you own are written in Go, that you've done backend work for 5+ years, and what distributed-systems work you've done. The questions at the end ask about those. I haven't written lines that claim them.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` cv | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to first bullet under the current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` cv | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` cv | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Ran six incidents as incident commander." / "On-call rotation every fourth week for two years." (two bullets, incident commander first) | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team (usually two or three a year); pair with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` cv | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust · Kafka, Postgres, Terraform, gRPC, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` cv | pending your approval |

Notes on some of the rows:
- **E3:** the 40k figure stays tied to the one service it describes, not to all three.
- **E4:** "every fourth week" stays in. Without it the line would read as constant on-call.
- **E5:** this keeps your words, "onboarding" and "pair with them", rather than switching to the JD's "mentoring".
- **E6:** Python is left out of the skills line because your sentence puts it in the past.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `not_evidenced` | E1 shows 7 years as a software engineer and 4 years of Go/Rust. Nothing says the Python years were backend, so a strict reader can count only 4. Recall prompt C2. | `[grounded]` cv |
| R2 | Production Go (daily use) | must-have | `surfaced_by_edit` | E1, E6 | `[grounded]` cv |
| R3 | Design and ship Go services | must-have | `not_evidenced` | The CV says you own three services and use Go and Rust daily, but not which language the services are in. Recall prompt C1. | `[grounded]` cv |
| R4 | High request volume | important | `surfaced_by_edit` | E3 (about 40k req/min at peak, one service) | `[grounded]` cv |
| R5 | Distributed systems at scale | must-have | `not_evidenced` | A pipeline of three services, plus Kafka and gRPC in the skills list, but no line describes how they're built. Recall prompt C3. | `[grounded]` cv |
| R6 | Drive down p99 latency | important | `surfaced_by_edit` | E2 (380ms → 95ms, balance-read path) | `[grounded]` cv |
| R7 | Strong incident response / on-call | must-have | `surfaced_by_edit` | E4 | `[grounded]` cv |
| R8 | Experience mentoring | must-have | `surfaced_by_edit` | E5 shows onboarding and a first month of pairing. It doesn't show ongoing mentoring of mid-level engineers. | `[grounded]` cv |
| R9 | Partner with product on roadmap sequencing | preferred | `not_evidenced` | Named absence (below) | `[grounded]` cv |

## Gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Design and ship Go services | must-have | Daily Go and Rust, and three services you own. It never says the services are in Go. | The job is owning Go services. If those three are in Rust, the closest match on your CV is to a different language. | One of the three services written or rewritten in Go; new endpoints you shipped in Go; the cache-layer rework done in Go | A design doc, PR history, or service README | `[grounded]` what the CV does and doesn't say; `[generic]` how screeners read language-specific must-haves |
| C2 | 5+ years backend | must-have | 7 years as a software engineer and 4 of Go/Rust. The kind of work in the Python years isn't stated. | Year counts are often read literally, and 4 years explicitly backend is short of 5. | APIs or services in Python, data pipelines, backend for a web product | Your earlier job titles and a line for each role | `[grounded]` what the CV shows; `[generic]` literal reading of year counts |
| C3 | Distributed systems at scale | must-have | Three services in one pipeline; Kafka and gRPC listed as tools only | It's a stated must-have, and listing a tool doesn't show you've built with it | Kafka between the ledger services; gRPC between them; idempotency or ordering guarantees on ledger writes; running across several instances or regions | An architecture diagram or design doc (redacted is fine) | `[grounded]` what the CV shows; `[generic]` how a listed tool is read |

**R9, partnering with product (named absence):** nothing in your material mentions roadmap work with product. It's listed as a responsibility, not a requirement, so the gap costs little. If you've helped sequence work with a PM, tell me in one sentence and it becomes a row. If you haven't, don't add it.

## Not written, and why

- **"Senior Backend Engineer" as your title:** that's the posting's title, not yours. Your title stays "Senior Software Engineer".
- **"Designed and shipped Go services":** your sentence says you own the services. It doesn't say you designed them, and it doesn't say they're in Go.
- **"Distributed systems at scale" about your own work:** this is the JD's wording. Your material doesn't describe the architecture yet.
- **"Own on-call for my services":** you're in a rotation. You didn't say whether it covers your services alone or the team's.
- **"Mentored mid-level engineers":** you onboard new hires and pair with them for a month. Switching to "mentored" changes the kind of work, and no mid-level engineers are mentioned.
- **"Three services handling 40k requests/minute":** the figure belongs to one service, at peak.
- **"Caching / build-cache experience":** you reworked one cache layer. That's relevant, but it isn't build-cache platform work.
- **"Led incident response":** keep "incident commander" and the count of six. "Led incident response" would imply a broader role than you described.

## Parse-safety check

You described the CV in prose rather than sharing the file, so none of the layout checks could run: columns, tables, headers and footers, section headings, file type, and hidden text left by a template. Send the file and I'll run them.

## Upgrade menu

- **The actual CV file:** lets me run the parse-safety check and quote your real lines instead of this summary.
- **A design doc or PR for the cache-layer rework:** would back E2 with something a reader can inspect, and might answer C1.
- **A redacted postmortem from one of your six incidents:** would back E4 and give you something concrete to discuss in interviews.
- **An architecture sketch of the ledger pipeline:** would let C3 become a real row.

## Questions

C1 — Which language are the three ledger-pipeline services in, and did you write any of them, or major parts of them, in Go?
C2 — In your Python years before Go/Rust, was the work backend (services, APIs, data pipelines), and what was your title?
C3 — How do your three services talk to each other and to the rest of the system? Is Kafka or gRPC in the path you own?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.