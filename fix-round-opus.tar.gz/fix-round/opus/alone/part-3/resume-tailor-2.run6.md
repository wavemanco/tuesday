I've read the tailoring rules and your background. Here's the ledger.

**First, the main problem.** The posting's first must-have is "3+ years data engineering," and you said your title for all five years was Senior Data Analyst. I won't retitle your role or describe analytics years as data engineering years, because a recruiter who looks you up or asks about it would see through that quickly. What I can do is move the work that looks most like data engineering (the dbt models, the star schema, the nightly job and its tests, the vendor API scripts) to the top and keep your own words. Whether you should apply against that must-have is a separate question, and the job-underwriter skill handles it. Below is everything I can propose, tied to your own sentences. Nothing has been applied yet.

## Requirements extracted

- **Must-have:** 3+ years data engineering; production Python; Airflow or equivalent orchestration; dimensional modelling
- **Important (from the duties):** build and own batch pipelines; model the warehouse; own data quality and SLAs; partner with analytics on requirements; Spark in the pipeline stack
- **Preferred:** streaming experience (Kafka)

## Evidence inventory (your sentences, word for word)

1. "Senior Data Analyst, 5 years, retail."
2. "SQL every day on Redshift, complex window functions and CTEs."
3. "Built and maintained about 25 dbt models including the core orders mart."
4. "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron."
5. "I've fixed our nightly dbt job when it breaks and added tests to it."
6. "I designed the star schema for the orders mart with our then-DE."
7. "Never used Airflow or Spark. Never touched Kafka."
8. "I'm trying to move into data engineering from analytics."

## Edit ledger

You gave me background notes rather than the resume itself, so the "Current line" column treats each of your sentences as the current line.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst (5 years, retail) moving into data engineering from analytics. Built and maintained about 25 dbt models including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your background notes | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-data engineer" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your background notes | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(E2's wording, moved to the first bullet of the role)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your background notes | pending your approval |
| E4 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(wording unchanged, moved to the second bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your background notes | pending your approval |
| E5 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fix our nightly dbt job when it breaks" / "Added tests to our nightly dbt job" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your background notes | pending your approval |
| E6 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Write Python for analysis (pandas)" / "Some Python scripting to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your background notes | pending your approval |
| E7 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "SQL daily on Redshift, including complex window functions and CTEs" | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your background notes | pending your approval |
| E8 | Skills | *(no current line)* | "SQL (Redshift) · dbt · Python (pandas) · cron · star schema design" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your background notes | pending your approval |

Some notes on these rows:

- **E2 keeps "with our then-data engineer."** That part makes it a shared design. Dropping it would turn "co-designed" into "designed," and the person you co-designed it with is the obvious person a reference check would reach.
- **E5 is split** so the tests stand as their own line. That line is your strongest evidence for "own data quality."
- **E6 keeps "some."** It's the honest limit on how much scripting there was. Splitting it out makes the API ingestion visible without making it sound bigger.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Recall prompt C1. The nearest work is in E1, E4 and E5, but the title says analyst. A posting that states years for a title is likely to be screened against that title literally | `[grounded]` your title as you gave it; `[inferred]` how a titled-years requirement tends to be read, from the posting's wording |
| R2 | Production Python | must-have | `not_evidenced` | Recall prompt C2. "for analysis" and "some scripting" don't establish production code on their own | `[grounded]` your background notes |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | Recall prompt C3. You said you've never used Airflow; whether anything you ran counts as an "equivalent" is unknown | `[grounded]` your background notes |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E2 and E3, a shared star-schema design for the orders mart | `[grounded]` your background notes |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E2, E4 and E7. This is modelling work in your marts, not ownership of the whole warehouse | `[grounded]` your background notes |
| R6 | Build and own batch pipelines | important | `surfaced_by_edit` | E4 and E5 cover dbt transformations and keeping the nightly job running. The ownership the posting asks for isn't established | `[grounded]` your background notes |
| R7 | Own data quality | important | `surfaced_by_edit` | E5, the tests you added to the nightly job | `[grounded]` your background notes |
| R8 | Own SLAs | important | `not_evidenced` | Named absence below | `[grounded]` your background notes |
| R9 | Partner with analytics on requirements | important | `not_evidenced` | Named absence below. You've been the analytics side of that partnership | `[grounded]` your background notes |
| R10 | Spark | important | `not_evidenced` | Named absence below | `[grounded]` "Never used Airflow or Spark." |
| R11 | Streaming experience (Kafka) | preferred | `not_evidenced` | Named absence below | `[grounded]` "Never touched Kafka." |

## Gap handling

**Recall prompts.** The questions these imply are asked once, in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | Five years titled analyst. The dbt work is the most engineering-like, but its length isn't stated | It's the first must-have, and a reader can only credit years they can see | Years spent maintaining the dbt project; whether you deployed or reviewed changes to it; whether the vendor-API pulls loaded into Redshift | The dbt project's git history; the dates of your first commits | `[grounded]` what your notes do and don't say; `[generic]` how years requirements are read on applications like this |
| C2 | Production Python | must-have | Python for analysis, plus "some scripting" on a cron | "Production" usually means unattended code that others depend on | The cron scripts running unattended; their output feeding tables or reports other people used; error handling or alerting; version control or code review | The script repo; a README; an alert or ticket history | `[grounded]` what your notes do and don't say; `[generic]` what "production" usually means in data engineering postings |
| C3 | Airflow or equivalent orchestration | must-have | A nightly dbt job you fix when it breaks; cron for the API scripts | "Or equivalent" leaves room only if you set up or changed scheduling, dependencies or retries | Which tool triggers the nightly job (dbt Cloud, cron, an orchestrator run by the data engineers); whether you edited its schedule or step order; retries or failure alerts you configured | Job configuration in the repo; scheduler screenshots | `[grounded]` what your notes do and don't say; `[generic]` how "equivalent" tends to be read |

**Named absences:**

- **SLAs (R8):** Fixing the nightly job "when it breaks" is incident repair, not ownership of a delivery commitment. What would close it is a committed ready-by time for that job that you were responsible for meeting. If C3 turns that up, the row gets rewritten.
- **Partnering with analytics (R9):** You've stood on the analytics side of that partnership, working with your then-data engineer. Writing it as if you partnered *with* analytics would flip which side you were on. The honest version is already in E2. The point that you know the requester's side well is interview material, not a resume line.
- **Spark (R10):** You've never used it. A small PySpark project on public data would let you list it as a *project*, never as work experience. It's listed under duties, not requirements, so it's lower priority than C2 and C3.
- **Kafka / streaming (R11):** You've never touched it, and it's marked as a plus. It's not worth closing for this application. A practice project wouldn't count as "streaming experience" anyway, and the must-haves matter far more.

## Not written, and why

- **"Data Engineer" as a title, or "5 years of data engineering":** Your title was Senior Data Analyst. Changing it is the claim a background check catches.
- **"Built and owned data pipelines":** The posting says "build and own." You said you built dbt models and fix the nightly job when it breaks. "Own" would put you in charge of a system you described maintaining.
- **"Orchestrated nightly pipelines":** That's the JD's vocabulary laid over "fixed our nightly dbt job when it breaks."
- **"Production Python":** Your sentence says "for analysis" and "some scripting." That stays the wording unless C2 says otherwise.
- **"Dimensional modelling" in place of "star schema":** It's the posting's term. A star schema is a kind of dimensional model, but the rule here is to keep your words about your own work.
- **"Designed the warehouse's star schema" or "led the data model":** It was the orders mart, designed with your then-data engineer.
- **"Defined data quality standards" or "owned SLAs":** You added tests to one job. Nothing you wrote mentions standards or SLAs.
- **Any Airflow, Spark or Kafka mention:** You said you've never used any of them.

## Parse-safety check

You pasted background text, not a file, so I couldn't check columns, tables, text boxes, images, header/footer placement, file type or hidden text. Two things to check yourself: keep your contact details in the body, not the page header, and use the standard headings "Summary," "Experience" and "Skills," which E1 and E8 already assume. A .docx or a PDF with selectable text is the safe format.

## Upgrade menu

- **Your actual resume file:** lets me run the full parse check, use your real bullet wording and dates, and replace these note-based "current lines."
- **The dbt project's git history or your script repo:** the kind of evidence data engineering hiring managers can actually inspect. It could move C1 and C2 from leads to grounded rows.
- **Job configuration for the nightly run:** settles C3 either way.

## Questions

C1 — Roughly how many of your five years have you been building and maintaining the dbt project, and did you deploy changes to it yourself?
C2 — Did the vendor-API scripts run unattended and load data that other people relied on, and did they have alerting, tests or version control?
C3 — What triggers the nightly dbt job, and have you ever changed its schedule, step order, retries or failure alerts yourself?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.