Your theory is partly right but mostly wrong. I'll explain why first, then give you the edits.

**Missing keywords probably aren't what's auto-rejecting you.** The best evidence available is one small vendor study of 25 US recruiters, so it can't settle the question. In it, content-based auto-rejection was rare: "We only saw 2 of 25 using it" (cite C25). The automated rejections people do run into are "almost always knockout questions" (cite C26). Those are "yes/no eligibility checks (work authorization, required license, location)" (cite C26) on the application form, and your resume doesn't affect them. Keywords do matter for ranking: "Many teams use match scores/filters to prioritize who gets reviewed first" (cite C27), and "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27).

**Your layout is a more likely culprit than your wording.** A two-column Canva PDF with skill icons and contact details in the header carries three parse risks (P1–P3 below). If your skills only exist as icons, a parser may not find "AWS", "Docker" or "Python" at all.

**Some of the gap with this job is real experience, not wording.** About half of what this job lists isn't anywhere in what you told me: Terraform, ArgoCD/GitOps, Istio, Prometheus/Grafana, Vault, EKS, Helm, GitLab and Go. Better wording can make your real experience findable. It can't add those tools, and I haven't written them in.

**My assumption:** you described your resume rather than pasting it, so I haven't seen your current wording. Every proposed line below quotes the sentences in your message.

## Edit ledger (nothing applied yet)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(not seen; you say skills are shown as icons)* | "Skills: AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" as plain, selectable text | `surface` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |
| E2 | Experience | *(not seen)* | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs" | `surface` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E3 | Experience | *(not seen)* | "Ran a Kubernetes proof-of-concept for two months; it did not go to production" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E4 | Experience | *(not seen)* | *(E2 first and E3 second, at the top of your current role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E5 | Summary | *(no current line)* | "DevOps Engineer, 4 years — AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Ansible, Python. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |

Notes on these rows:
- **E3 keeps "did not go to production" on purpose.** It's the line most likely to come up in an interview, and the honest version can survive that.
- **E5 keeps your title as "DevOps Engineer".** It does not become "Platform Engineer".
- **E1 is the biggest keyword fix.** It doesn't change any claim. It turns skills that may be icons a parser can't read into text it can.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E3: a two-month PoC only, not production. A reader will see that it's partial | `[grounded]` your message; `[inferred]` priority, since the JD doesn't rank its list |
| R2 | CI/CD | important | `surfaced_by_edit` | E2: a Jenkins deploy pipeline. Whether it also ran builds or tests isn't stated | `[grounded]` your message; `[inferred]` priority |
| R3 | CI/CD on GitLab specifically | important | `not_evidenced` | Named absence N4 | `[grounded]`; `[inferred]` priority |
| R4 | Python | important | `surfaced_by_edit` | E1: "Python scripting" as text, not an icon | `[grounded]`; `[inferred]` priority |
| R5 | AWS EKS | important | `not_evidenced` | Recall C1. Other AWS services (EC2, S3, RDS, IAM) are in E1 | `[grounded]`; `[inferred]` priority |
| R6 | Helm | important | `not_evidenced` | Recall C1 | `[grounded]`; `[inferred]` priority |
| R7 | Observability (Prometheus, Grafana) | important | `not_evidenced` | Recall C2. CloudWatch is in E1, as monitoring only | `[grounded]`; `[inferred]` priority |
| R8 | SRE practices and platform reliability | important | `not_evidenced` | Recall C2 | `[grounded]`; `[inferred]` priority |
| R9 | Terraform | important | `not_evidenced` | Recall C3. Ansible is config management, as you wrote, and isn't the same thing | `[grounded]`; `[inferred]` priority |
| R10 | GitOps and ArgoCD | important | `not_evidenced` | Named absence N1 | `[grounded]`; `[inferred]` priority |
| R11 | Service mesh (Istio) | preferred | `not_evidenced` | Named absence N2 | `[grounded]`; `[inferred]` priority |
| R12 | Vault | preferred | `not_evidenced` | Named absence N3 | `[grounded]`; `[inferred]` priority |
| R13 | Go | preferred | `not_evidenced` | Named absence N5 | `[grounded]`; `[inferred]` priority |
| R14 | Developer experience | important | `not_evidenced` | Named absence N6. Your pipeline work is related | `[grounded]`; `[inferred]` priority |

R1, R2 and R4 can be fixed with edits. R3 and R5–R14 can't. Whether a gap that size is worth applying into is a question for **job-underwriter**, which also checks for knockout-question risk.

## Gap handling

**Recall prompts.** Each one has a matching question at the end.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS, Helm | important | A Kubernetes PoC with no platform, tooling or scope stated | Kubernetes is the first item on this JD. EKS and Helm are how it's usually run on AWS | The PoC ran on EKS rather than locally; you wrote or installed Helm charts; you containerised a real service for it | The PoC repo or manifests, a write-up, a demo note | `[grounded]` what your message says; `[generic]` how EKS and Helm usually go together |
| C2 | Observability, SRE practices | important | "CloudWatch for monitoring" and nothing about alerting, on-call or incidents | The role says you will "own platform reliability" | You set up CloudWatch alarms or dashboards; you were on call; you ran or wrote up incidents; you used Prometheus or Grafana anywhere, even on the PoC | A dashboard, a runbook, a postmortem | `[grounded]` what your message says; `[generic]` how reliability ownership is usually shown |
| C3 | Terraform | important | Ansible only | Infrastructure as code is a core platform-team skill | Any Terraform, even a single module; CloudFormation; provisioning the PoC cluster with code | A repo, a merged PR | `[grounded]` what your message says; `[generic]` |

**Named absences.** These are gaps that need new work, not better wording.
- **N1 GitOps/ArgoCD:** not in your experience. To close it, deploy a sample app to a local cluster with ArgoCD and publish the repo. It's a short project and gives you something to point at.
- **N2 Istio:** not in your experience. It's listed as "preferred", so it isn't worth closing for this application.
- **N3 Vault:** not in your experience. Same as N2; a small Vault-plus-Kubernetes secrets demo would close it if you want to.
- **N4 GitLab CI:** not in your experience. Rebuilding one of your Jenkins pipelines as a `.gitlab-ci.yml` in a personal repo would close it honestly.
- **N5 Go:** not in your experience. It's preferred, and a small CLI tool or Kubernetes operator project would be the path. Not worth chasing for this one application.
- **N6 Developer experience:** not stated. It becomes writable if your pipeline served other developers. Tell me who used it and I'll draft a row.

## Not written, and why

- **"Kubernetes in production" or "Kubernetes (EKS)":** your PoC never went to production, and EKS isn't stated.
- **"Platform Engineer" as your title:** your title is DevOps Engineer.
- **"Observability" for CloudWatch:** you wrote "monitoring". "Observability" is the JD's word and would claim a broader practice.
- **"Infrastructure as code" for Ansible:** you wrote "config management".
- **"CI/CD pipeline" for the Jenkins work:** you wrote "deploy pipeline". Builds and tests aren't stated.
- **Terraform, ArgoCD, Istio, Prometheus, Grafana, Vault, Helm, GitLab or Go in your skills list,** including a "familiar with" or "exposure to" version: nothing in your message supports any of them.
- **"Owned platform reliability" or "SRE":** nothing you've told me supports either yet. C2 might change that.

## Parse-safety check

| # | Check | Finding | What breaks | What it costs |
|---|---|---|---|---|
| P1 | Multi-column layout | Two columns | Parsers read across the page, so the two columns get mixed together | Dates detach from roles, and skills can merge into experience text |
| P2 | Icons | One icon per skill | Icons can come out as junk characters or be skipped | If a skill only appears as an icon, it may be missing from the parsed text. E1 fixes this |
| P3 | Content in the header | Contact details are in the header | Headers can be treated as page furniture and thrown away | You may become unreachable from the parsed record |
| P4 | Text layer, and hidden text from a template | Couldn't check; I haven't seen the file | — | Send the PDF and I'll check both |
| P5 | Section headings | Couldn't check | — | Paste the text and I'll check them |

## Upgrade menu
- **Paste your resume as text.** I can then quote your actual current lines and run P5.
- **Send the PDF itself.** That lets me run P4 and confirm whether the skills survive as text.
- **Tell me whether the Jenkins pipeline ran builds or tests, and who used it.** That could open a CI row (R2) and a developer-experience row (N6).
- **Share a PoC repo or write-up** if you have one. It would make R1 stronger.

## Questions

C1: What did the Kubernetes PoC involve: where did it run (EKS or local), did you use Helm, and what did you deploy?
C2: Beyond CloudWatch, did you set up alarms or dashboards, go on call, or handle incidents?
C3: Have you written any Terraform or other infrastructure-as-code, even small pieces?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.