Your dbt and data-modelling work is the strongest material you have for this role. Three of the four must-haves aren't supported by what you told me: 3+ years of data engineering, production Python, and Airflow or equivalent orchestration. The edits below put the dbt work first and add nothing you didn't say. Whether to apply while that must-have is open is a call for job-underwriter. You described your background in prose, so I treated each sentence as a resume line. Your actual resume probably has more on it, and the rows below cover only what you told me.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Data analyst with 5 years in retail, moving into data engineering." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics." | `[grounded]` your message | pending your approval |
| E2 | Summary | *(no current line)* | "Built and maintained about 25 dbt models, including the core orders mart. Designed the orders mart's star schema with our then-data engineer." | `merge` | "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E3 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first Experience bullet, ahead of SQL)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E4 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-data engineer" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E5 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fix the nightly dbt job when it breaks" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E6 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Added tests to the nightly dbt job" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E7 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Write Python scripts, scheduled on cron, to pull vendor APIs" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E8 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "Daily SQL on Redshift, including complex window functions and CTEs" | `reframe` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |
| E9 | Skills | *(no current line)* | "SQL (Redshift) · dbt (models, tests) · Python (pandas, scripting) · cron" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I've fixed our nightly dbt job when it breaks and added tests to it."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |

**Advice on order (pending your approval):** Put E3, E4, E6 and E5 first under Experience, then E7, then E8. Your analysis work can stay but should come after these. Keep your job title as "Senior Data Analyst."

Why some rows are worded the way they are:
- **E1** says "Data analyst" rather than "Senior Data Analyst with 5 years." I can't tell from what you wrote whether all 5 years were at senior level, so I took the smaller reading. Your real title still appears on the role itself.
- **E2 and E4** keep "with our then-data engineer." Without it, "designed" would read as if you did it alone.
- **E5 and E6** are split so the testing work appears on its own line. Neither one says "owned."

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years data engineering | must-have | not_evidenced | Your title is analyst and the dbt work has no dates. Recall prompt C1 | `[grounded]` your message |
| M2 | Production Python | must-have | not_evidenced | E7 shows scheduled scripts, which isn't the same as "production." Recall prompt C2 | `[grounded]` your message |
| M3 | Airflow or equivalent orchestration | must-have | not_evidenced | You said "Never used Airflow." Cron and a nightly dbt job are scheduling, but only the employer can decide whether that counts as equivalent. Recall prompt C3, named absence G1 | `[grounded]` your message |
| M4 | Dimensional modelling | must-have | surfaced_by_edit | E2, E4. Co-designed, and labelled that way | `[grounded]` your message |
| M5 | Model the warehouse | important | surfaced_by_edit | E3: about 25 dbt models, including the core orders mart | `[grounded]` your message |
| M6 | Data quality | important | surfaced_by_edit | E6 shows you added tests. That isn't ownership of data quality | `[grounded]` your message |
| M7 | Own SLAs | important | not_evidenced | E5 shows you fix the job when it breaks. That isn't owning an SLA. G2 | `[grounded]` your message |
| M8 | Batch pipelines (Spark) | important | not_evidenced | G3 | `[grounded]` your message |
| M9 | Streaming (Kafka) | preferred | not_evidenced | G4 | `[grounded]` your message |
| M10 | Partner with analytics on requirements | important | not_evidenced | You've been on the analytics side of that partnership, not the engineering side. G5 | `[grounded]` your message |

## Gap handling

**Recall prompts** (the questions are in the closing block)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | An analyst title and dbt work with no dates. It doesn't show how long you've done engineering-type work | The JD lists this first as a must-have. A dated line about your dbt work is the most honest way to answer it | When you started building dbt models; whether dbt became a formal part of your role; whether you took over any of the data engineer's work after they left (only if that actually happened) | dbt repo commit history, a job description or review that mentions dbt | `[grounded]` what you wrote; `[generic]` must-haves listed first are usually screened first |
| C2 | Production Python | must-have | Python "for analysis" plus "some scripting" on cron | Production Python is a must-have here, and analysis Python reads as a different kind of work | The vendor-API scripts running unattended on a server; something downstream depending on their output; version control, error handling, alerts | The repo, a README, a cron/server config | `[grounded]` what you wrote; `[generic]` data engineering screens usually separate scripting from production code |
| C3 | Airflow or equivalent orchestration | must-have | A nightly dbt job you fix, with no word on what schedules it | Whatever scheduler runs that job (dbt Cloud, cron, something else) may be the closest honest answer to "or equivalent" | Whether you set up the schedule, retries, dependencies or failure alerts, versus only fixing models when a run fails | A screenshot of the job config, alert setup | `[grounded]` what you wrote; `[inferred]` "or equivalent" suggests the employer accepts other schedulers |

**Named absences**

| # | Requirement | Gap | What closing it would take | Provenance |
|---|---|---|---|---|
| G1 | Airflow | You've never used it | A small public project: run your vendor-API pull and a dbt build as an Airflow DAG, with retries and a test. That gives you something real to link, though it's still not work experience | `[grounded]` "Never used Airflow or Spark." |
| G2 | Own SLAs | Fixing failures isn't owning a freshness or uptime commitment | Taking formal responsibility for when the nightly job has to finish, plus alerts, in your current role. Or answer C3 if that's already true | `[grounded]` your message |
| G3 | Spark | You've never used it | A portfolio batch job in PySpark, or a course. It's a stated tool here, so expect interview questions on it either way | `[grounded]` "Never used Airflow or Spark." |
| G4 | Kafka / streaming | You've never touched it | It's listed as a plus, not a requirement. Probably not worth closing just for this application | `[grounded]` "Never touched Kafka." |
| G5 | Partner with analytics | You've been the analyst working with the engineer, not the engineer taking requirements | Nothing for the resume. It's a strong interview story if you tell it from your actual side: you know what analysts need from a data engineer | `[grounded]` "with our then-DE" |

## Not written, and why

- **"3+ years of data engineering experience" or a Data Engineer / Analytics Engineer title.** Your title is Senior Data Analyst. Changing it is the one edit a background check would catch.
- **"Production Python".** You wrote "Python for analysis" and "some scripting." C2 might close this. The wording can't.
- **"Built / owned data pipelines" or "ingestion pipelines" for the vendor scripts.** That's the JD's wording, not yours. "Pipeline" would turn your cron scripts into a bigger kind of work than you described.
- **"Orchestrated jobs" or "Airflow-equivalent experience".** You've never used Airflow, and only Bellhaven can say what counts as equivalent.
- **"Owned data quality and SLAs".** You added tests and fix failures. "Own" is the JD's word.
- **"Led / designed the warehouse" or star-schema design without "with our then-DE".** You co-designed one mart's schema.
- **"25+ dbt models" or "25 models".** You wrote "about 25," so "about" stays.
- **Airflow, Spark or Kafka in Skills.** You've never used them, and a listed tool reads as one you can use.
- **"Partnered with analytics on requirements".** You were the analytics side, so this would put you on the wrong side of that table.

## Parse-safety check

You pasted text, not a file, so I couldn't check columns, tables, text boxes, headers/footers, images, file type, or hidden text from a template. If you send the file, I can run those. The section names I used (Summary, Experience, Skills) are the standard ones.

## Upgrade menu

- **Your actual resume file:** lets me run the full parse check, write rows for your other bullets, and fill in dates and employer.
- **Answers to C1–C3:** each could turn a `not_evidenced` must-have into a real, dated line.
- **The dbt repo or vendor-script repo:** would back up E3, E6 and E7 and could support a portfolio link.
- **Optional extra:** a short plan for the Airflow + dbt project in G1, scoped to your vendor-API work. It would give you something honest to show for the orchestration requirement. I'll only build it if you say yes.

## Questions

C1 — When did you start building and maintaining dbt models, and after your data engineer left, did you take over any of their work? If so, what?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Do the vendor-API scripts run unattended on a server, does anything downstream depend on their output, and are they in version control?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — What schedules the nightly dbt job, and did you set up any of its schedule, retries, or failure alerts?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.