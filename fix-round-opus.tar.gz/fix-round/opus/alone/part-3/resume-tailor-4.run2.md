I've written six proposed edits below, and none of them is applied yet. First, the premise. Keyword matching probably isn't what's rejecting you, and adding keywords can't fix the real problem.

**What the evidence says about screening.** The best source I have is small. It's one résumé-builder company's interviews with 25 US recruiters. Two of them (8%) had automatic rejection based on resume content switched on. Where automatic filters were used, they were "almost always knockout questions": yes/no checks on the application form, such as work authorization or location. Match scores were mostly used "to prioritize who gets reviewed first", and "Low score ≠ auto-reject". That's a sample of 25, so treat it as a rough guide. Keywords still matter for ranking, but only ones you can defend in an interview.

**The bigger problem is fit, and wording can't change it.** Look at the coverage map below. About ten of the tools this job names aren't in your history at all: Terraform, ArgoCD/GitOps, Istio, Prometheus/Grafana, Vault, EKS, Helm, GitLab, Go and production Kubernetes. A recruiter will see that in seconds, and an interviewer will see it in one question. Your actual layout (two columns, icons, contact details in the header) is a more concrete risk than missing keywords. See the parse-safety check. Whether this role is worth applying for at all is a separate question, which the job-underwriter skill handles.

**Assumption:** I haven't seen your PDF. The "current lines" below come from your description of it, so I'm treating that description as your resume text.

---

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to be the first bullet under your DevOps Engineer role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E2 | Experience | *(not currently a bullet, as far as I can tell)* | "Ran a two-month Kubernetes proof-of-concept" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | *(same items, AWS moved to the front of the list)* | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |
| E4 | Skills | "Bash and Python scripting" | "Python and Bash scripting" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |
| E5 | Skills | *(Kubernetes not listed)* | "Kubernetes (proof-of-concept)", placed next to Docker | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E6 | Summary | *(no summary line known)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |

Notes:
- **E2 and E5 keep the words "proof-of-concept".** Those words make the Kubernetes line defensible. Without them it reads as production experience, and the first interview question would take that apart. I left the year out: you said "last year", and I won't turn that into a date you haven't confirmed.
- **E1 says "deploy pipeline", not "CI/CD".** You only described deployment, not continuous integration.
- **E6 keeps your title as DevOps Engineer.** It doesn't become "Platform Engineer".

## Coverage map

I've assumed the priorities, because the job description doesn't separate must-haves from nice-to-haves.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Kubernetes (hands-on at all) | must-have | `surfaced_by_edit` | E2, E5. Proof-of-concept only. | `[grounded]` your message; `[inferred]` priority |
| M2 | Kubernetes in production | must-have | `not_evidenced` | Named absence A1 | `[grounded]` "never went to production"; `[inferred]` priority |
| M3 | AWS | must-have | `already_evidenced` | Skills list; E3 moves it first | `[grounded]` your message |
| M4 | AWS EKS | must-have | `not_evidenced` | Recall prompt R1 | `[grounded]` EC2/S3/RDS/IAM only |
| M5 | Terraform (infrastructure as code) | must-have | `not_evidenced` | Recall prompt R2. Ansible is configuration management, not provisioning. | `[grounded]` your message |
| M6 | GitOps / ArgoCD | must-have | `not_evidenced` | Recall prompt R1 | `[grounded]` your message |
| M7 | Deploy pipeline experience | must-have | `surfaced_by_edit` | E1, E6. Jenkins. | `[grounded]` your message |
| M8 | GitLab CI | important | `not_evidenced` | Named absence A2 | `[grounded]` Jenkins only |
| M9 | Prometheus / Grafana | important | `not_evidenced` | Recall prompt R1. CloudWatch is adjacent but a different tool. | `[grounded]` your message |
| M10 | Helm | important | `not_evidenced` | Recall prompt R1 | `[grounded]` your message |
| M11 | Python | important | `already_evidenced` | E4 puts it first | `[grounded]` "Bash and Python scripting" |
| M12 | SRE practices, platform reliability, developer experience | important | `not_evidenced` | Recall prompt R3 | `[grounded]` your message |
| M13 | Istio / service mesh | preferred | `not_evidenced` | Named absence A3 | `[grounded]` your message |
| M14 | Vault | preferred | `not_evidenced` | Named absence A4 | `[grounded]` your message |
| M15 | Go | preferred | `not_evidenced` | Named absence A5 | `[grounded]` your message |

## Gap handling: recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | EKS, ArgoCD/GitOps, Helm, Prometheus/Grafana | must-have | A two-month Kubernetes proof-of-concept, with no detail on what it ran on or what tools it used | These are most of the job's core tools. Each one the proof-of-concept actually used could go on your resume. | You ran the proof-of-concept on EKS; you installed something with a Helm chart; you tried ArgoCD or Flux; you set up Prometheus or Grafana to watch it | The repo, a write-up, notes from your demo of it | `[grounded]` what your message says; `[generic]` what this costs on platform roles |
| R2 | Terraform / infrastructure as code | must-have | Ansible for configuration management only | Platform roles usually expect provisioning as code, and nothing here shows it yet | Any Terraform or CloudFormation, even small; reading or changing someone else's Terraform; provisioning the RDS or IAM setup in code | A merge request, a module, a ticket | `[grounded]` your message; `[generic]` what platform roles expect |
| R3 | Reliability, SRE practices, developer experience | important | You maintain about 30 Jenkins jobs, but it doesn't say who uses them or what happens when they fail | The role says "own platform reliability and developer experience", and nothing yet shows either | Being on call; handling incidents or writing post-mortems; developers using the pipeline you built; cutting deploy time or failure rates | A post-mortem, an on-call rota, a before/after metric | `[grounded]` your message; `[grounded]` job description wording |

## Gap handling: named absences

| # | Requirement | Priority | Gap | What closing it would take | Provenance |
|---|---|---|---|---|---|
| A1 | Production Kubernetes | must-have | You said the proof-of-concept "never went to production" | Run real workloads on Kubernetes at work, or aim for roles that list Kubernetes as a nice-to-have rather than core | `[grounded]` your message |
| A2 | GitLab CI | important | Your pipeline experience is in Jenkins | A small public project built with GitLab CI. It's probably the cheapest gap here to close. | `[grounded]` your message; `[generic]` effort estimate |
| A3 | Istio / service mesh | preferred | No mention of it | Probably not worth chasing before production Kubernetes, since a service mesh sits on top of it | `[generic]` |
| A4 | Vault | preferred | No mention of it | A homelab or side project using it for secrets. Listed as a plus, so lower priority. | `[generic]` |
| A5 | Go | preferred | No mention of it | Write a small real tool in Go and publish it. Python already covers the scripting side. | `[generic]` |

## What I refused to write, and why

- **"Platform Engineer" as your title.** You were a DevOps Engineer. Changing the title would upgrade the role, not translate it.
- **"Kubernetes in production" or "managed Kubernetes clusters".** It was a two-month proof-of-concept that never went live.
- **"CI/CD pipelines".** You described a deploy pipeline. Continuous integration isn't stated.
- **"Observability" for CloudWatch.** That's the job description's word, not yours. "CloudWatch for monitoring" is what you said.
- **"Infrastructure as Code" for Ansible.** That would make configuration management sound like Terraform-style provisioning.
- **"Owned platform reliability" or "improved developer experience".** Nothing you've told me supports these yet. R3 asks whether anything does.
- **A skills list of the job's tools you haven't used** (EKS, ArgoCD, Istio, Helm, Vault, GitLab, Go, Terraform). It might lift a match score, and it would fail the first interview question on any of them. Hidden or white text with the same keywords is also off the table: software can read it, and a recruiter who finds it will reject you.

## Parse-safety check

I couldn't inspect the PDF, so these risks come from your description of it.

| Check | Finding | What it costs |
|---|---|---|
| Two-column layout | **Risk.** You described two columns. | Parsers read straight across both columns, so the skills column can mix into your experience text and dates can separate from their roles. |
| Skill icons | **Risk.** If a skill appears only as an icon, with no text label, the parser gets nothing. | Those skills disappear for the machine reader. |
| Contact details in the header | **Risk.** Some parsers throw away header content. | Your name, email or phone could be lost. |
| Canva PDF text layer | **Couldn't check.** Select all in the PDF, copy, and paste into a plain-text editor. Whatever doesn't come out clean or in order is what a parser sees. | If the text is flattened into an image, nothing at all gets read. |
| Section headings | **Couldn't check.** "Experience", "Skills" and "Education" are the safe labels. | A parser may not recognise unusual headings as sections. |
| Hidden text from the template | **Couldn't check.** The same copy-paste test will show any stray text. | Some templates hide leftover text you'd be blamed for. |

## What more input would unlock

- **The resume's actual text or the PDF itself.** I could quote your real lines instead of your summary, and run the parse checks properly.
- **Anything from the Kubernetes proof-of-concept** (repo, write-up, demo notes). It could turn up to four `not_evidenced` rows into real lines.
- **Any infrastructure-as-code or on-call history, even small.** It feeds R2 and R3 directly.

## Questions

R1 — What did the Kubernetes proof-of-concept actually run on and use: EKS or something else, and did it involve Helm, ArgoCD/Flux, or Prometheus/Grafana?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R2 — Have you ever written or changed Terraform or CloudFormation, even once?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R3 — Who uses the deploy pipeline and the 30 Jenkins jobs, and have you been on call or handled incidents for them?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.