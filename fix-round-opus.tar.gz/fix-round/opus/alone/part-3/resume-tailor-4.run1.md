I read through the tailoring rules. Below is the full set of proposed edits and the gaps they leave.

## Is it really the keywords?

Probably not mainly. The best evidence I have is small: one résumé-builder vendor interviewed 25 US recruiters.
- **Auto-rejection for missing words is rare.** Only 2 of the 25 had a system set to reject on content.
- **Forms reject more people than keywords do.** Most automatic rejection comes from yes/no questions on the application form, like work authorisation or location.
- **Match scores mostly set the order.** They decide who gets reviewed first, and 56% of those recruiters either ignore the feature or don't have it.

That sample is too small to be sure. But it suggests two other causes worth more of your attention than keyword density:

1. **Your file format.** A two-column layout, skill icons and contact details in the header are all known ways for text to get scrambled or dropped when the file is read by software. See the parse-safety check below.
2. **The job is a stretch.** Most of what the posting asks for (Terraform, ArgoCD, Istio, Prometheus/Grafana, Vault, EKS, Helm, GitLab, Go) isn't in what you've told me. Rewording can't put it there. A resume that claims it would get you an interview you then fail.

So the edits below only make your real experience easier to find. They don't add anything you haven't done.

**Assumptions:**
- I don't have your resume's text, only your description of it, so the "Current line" column uses your own words.
- The posting doesn't say which skills are required, so I treated the core platform stack as must-have.

## Proposed edits (nothing applied yet)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to first bullet of the role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your description | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | "Ran a Kubernetes proof-of-concept for two months; it never went to production." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E3 | Skills | "Bash and Python scripting" | "Python (scripting)" and "Bash (scripting)" as separate entries, Python first | `split` | "Bash and Python scripting" | `[grounded]` your description | pending your approval |
| E4 | Skills | "Kubernetes" not in the skills list | "Kubernetes (2-month proof-of-concept)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E5 | Skills | "AWS (EC2, S3, RDS, IAM)" | *(unchanged, moved to top of skills list)* | `reorder` | "AWS (EC2, S3, RDS, IAM)" | `[grounded]` your description | pending your approval |
| E6 | Skills | "Docker" | *(unchanged, moved next to the Kubernetes entry)* | `reorder` | "Docker" | `[grounded]` your description | pending your approval |
| E7 | Skills | "CloudWatch for monitoring" | *(unchanged, moved up beside AWS)* | `reorder` | "CloudWatch for monitoring." | `[grounded]` your description | pending your approval |

On E2: I took "last year" out because it reads oddly on a resume. The date belongs with the role it sat in. "Never went to production" stays, because it's what makes the line defensible.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E2, E4. Proof-of-concept only, not production; see C1 | `[grounded]` |
| R2 | AWS | must-have | `already_evidenced` | EC2, S3, RDS, IAM; E5 moves it up | `[grounded]` |
| R3 | AWS EKS | must-have | `not_evidenced` | Unknown whether the Kubernetes trial ran on EKS; see C1 | `[grounded]` |
| R4 | Terraform | must-have | `not_evidenced` | Ansible is configuration management, which is different work; see C2 | `[grounded]` |
| R5 | GitOps / ArgoCD | must-have | `not_evidenced` | Gap, see named absences | `[grounded]` |
| R6 | CI/CD | must-have | `surfaced_by_edit` | E1, using Jenkins | `[grounded]` |
| R7 | GitLab CI | important | `not_evidenced` | Jenkins only | `[grounded]` |
| R8 | Observability (Prometheus, Grafana) | must-have | `not_evidenced` | CloudWatch is related but different (E7) | `[grounded]` |
| R9 | SRE practices / platform reliability | must-have | `not_evidenced` | See C3 | `[grounded]` |
| R10 | Developer experience | important | `not_evidenced` | Who used your pipeline is unstated; see C3 | `[grounded]` |
| R11 | Istio / service mesh | important | `not_evidenced` | Gap, see named absences | `[grounded]` |
| R12 | Vault | important | `not_evidenced` | Gap, see named absences | `[grounded]` |
| R13 | Helm | important | `not_evidenced` | Possibly used in the Kubernetes trial; see C1 | `[grounded]` |
| R14 | Python | important | `surfaced_by_edit` | E3 | `[grounded]` |
| R15 | Go | preferred | `not_evidenced` | Gap, see named absences | `[grounded]` |

## Gaps where you may have more to tell me

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes, EKS, Helm | must-have | A two-month Kubernetes trial, with no detail on what you built or where it ran | Kubernetes is the centre of this role, and a bare "proof-of-concept" line gets probed hard in interview | Running a cluster on EKS; writing manifests or Helm charts; moving one real service onto it; showing the results to your team | A repo, the write-up you gave the team, a diagram | `[grounded]` what you described; `[generic]` how platform interviews probe Kubernetes |
| C2 | Terraform / infrastructure as code | must-have | AWS services and Ansible. How the AWS resources were created isn't stated | Infrastructure as code is a basic expectation for platform roles | Any Terraform, even a single module; CloudFormation; moving resources out of the AWS console into code | Repo files, merge requests | `[grounded]` what you described; `[generic]` what platform roles expect |
| C3 | Reliability and developer experience | must-have | You maintain about 30 Jenkins jobs, but nothing on uptime, on-call or who relies on them | The role description is literally "own platform reliability and developer experience" | On-call shifts; CloudWatch alarms you set up; handling incidents; how many developers or teams deploy through your pipeline; cutting deploy times | Runbooks, alarm configs, incident notes, before-and-after deploy times | `[grounded]` what you described; `[grounded]` the posting's wording |

**Gaps you can't fill by rewording:**
- **ArgoCD/GitOps, Istio/service mesh, Vault, Prometheus/Grafana:** none of this is in your experience. One way to close most of it at once: a public project running a small app on EKS, deployed with ArgoCD and Helm, monitored with Prometheus and Grafana, with secrets in Vault. That's real, defensible evidence, and the honest version of what you're trying to do with keywords.
- **GitLab CI:** not in your experience. Rebuilding one of your Jenkins pipelines in GitLab CI inside that same project would close it.
- **Go:** not in your experience, and only a nice-to-have here. Not worth closing for this application alone. A small Go tool in the same project would be enough.

If the Kubernetes trial is as deep as your production platform work goes, this role may be a stretch. Whether it's worth applying is a separate decision; the `job-underwriter` skill covers that.

## Not written, and why

- **"Platform Engineer" as your title.** You were a DevOps Engineer. Changing the title to match the posting is an upgrade, not an equivalent.
- **"Kubernetes in production", or Kubernetes listed with no qualifier.** It was a two-month trial that "never went to production". Leaving that out makes a trial read as production experience, which an interviewer will catch with the first question.
- **"Observability" or "Prometheus/Grafana" for CloudWatch.** That's the posting's vocabulary attached to different tools.
- **"GitOps" or "GitLab CI/CD" for the Jenkins work.** These are different tools and a different deployment model.
- **"Infrastructure as code" for Ansible.** You described it as configuration management. Calling it something else changes what kind of work it was.
- **"Owned platform reliability", "SRE", "improved developer experience".** These are the posting's phrases. Nothing you've told me supports them yet (see C3).
- **A keyword block or hidden text listing the posting's tools.** These are claims you can't defend, and hidden text can be detected by the same software that reads your resume.

## Parse-safety check

I've only seen your description, not the file. These are risks, not confirmed failures.

| Check | Your resume | Risk |
|---|---|---|
| Two columns | Yes | Reading software often goes straight across both columns, mixing them into jumbled text and separating dates from the roles they belong to |
| Icons for skills | Yes | If a skill appears only as an icon, with no text label, the software doesn't see it at all |
| Contact details in the header | Yes | Headers are often discarded, so a recruiter may have no way to reach you |
| Canva PDF | Yes | Canva sometimes exports text as shapes, which software can't read |
| Section headings, hidden text | Couldn't check | I need the actual file |

**A quick test you can run yourself:** open the PDF, select all, copy, and paste into a plain-text editor. Whatever is jumbled, out of order or missing there is roughly what the software gets.

## What more input would unlock

- **Your actual resume text or file:** verbatim current lines, and a parse check on the real document instead of your description.
- **Answers to C1–C3:** these could turn several gaps into evidence you can put on the page.
- **A repo or write-up from the Kubernetes trial or any infrastructure work:** strengthens rows that currently rest only on your word.

## Questions

C1: In the Kubernetes trial, what did you build and where did it run? Was it on EKS, and did you use Helm?
C2: How were your AWS resources created: through the console, CloudFormation, Terraform, or something else?
C3: Have you been on call or handled incidents? And roughly how many developers or teams deploy through your Jenkins pipeline?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.