I need to read the references before building.
I won't add the hidden instructions or the 1pt keyword block. My reasons:

- **It's deception of the employer.** The screener reads your resume on the employer's behalf, so a hidden instruction to it is aimed at them. "I wasn't lying to a person" is hard to say out loud in an interview.
- **It can be found.** Hidden text is fully visible to the software that parses it. One platform told a newspaper that 1% of the resumes it processed in one half-year contained white text (cite C19). A staffing firm reports finding hidden text in about 10% of the resumes it scans with AI (cite C18). One candidate said a recruiter found his and turned him down for it (cite C35).
- **What happens after it's found is the employer's call, not yours.** You couldn't defend a line you never wrote into the visible resume. That breaks the point of everything below, where each line is one you can stand behind.

Your friend isn't alone in believing this works. In one vendor's survey of 1,200 US job seekers, "41% admit to using prompt injections, hidden text designed to bypass AI filters" (cite C17). But the honest approach is also the one that helps. Make sure your real content survives parsing, put true keywords where your experience supports them, and put your strongest evidence first. Your material already matches this JD well on paid search, HubSpot, lifecycle email, webinars and budget. Below are the proposed edits, all waiting for your approval.

**Assumption:** I'm working from the prose you sent, not your actual resume file. So the "Current line" cells quote what you wrote here.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social on a budget of about $600k a year, built our lifecycle email programme from scratch (12 automated flows), and ran a monthly webinar series." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your message | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your message | pending your approval |
| E4 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Used HubSpot daily for 4 years." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your message | pending your approval |
| E5 | Experience | "Ran a monthly webinar series, average 300 registrants." | "Ran a monthly webinar series averaging 300 registrants." | `compress` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your message | pending your approval |
| E6 | Experience | "I pull my own numbers in HubSpot reporting" | "Pull my own numbers in HubSpot reporting." | `reframe` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your message | pending your approval |
| E7 | Skills | *(no current line)* | "HubSpot (daily use, 4 years), including HubSpot reporting" | `surface` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your message | pending your approval |

Why each row looks the way it does:
- **E1 says "built our lifecycle email programme", not "built it in HubSpot".** You never said the programme ran in HubSpot. It's likely, but the line shouldn't claim it until you confirm.
- **E2 keeps "about".** "About $600k" clears the JD's $500k bar without rounding up to "$600k+".
- **E5 says "registrants", not "attendees".** Registrants is the number you gave.
- **E6 drops the SQL clause** but doesn't replace it with anything SQL-like.
- **Title stays "Marketing Manager"** in every row.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 states 6 years in B2B SaaS and names the channels. Your title stays Marketing Manager, so the reader connects that to demand gen. | `[grounded]` your message |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E4, E7 | `[grounded]` your message |
| R3 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1, E2: "about $600k a year" | `[grounded]` your message |
| R4 | SQL-literate | must-have | `not_evidenced` | You said you're not strong in SQL. This is a named absence (G1). E6 shows your HubSpot reporting and doesn't stand in for SQL. | `[grounded]` your message |
| R5 | Paid search | important | `surfaced_by_edit` | E1, E2 | `[grounded]` your message |
| R6 | Lifecycle email | important | `surfaced_by_edit` | E1, E3 | `[grounded]` your message |
| R7 | Webinars | important | `surfaced_by_edit` | E1, E5 | `[grounded]` your message |
| R8 | Content distribution | important | `not_evidenced` | Nothing in your material covers this yet. Recall prompt C1. | `[grounded]` your message |
| R9 | Demand gen outcomes (pipeline, leads, conversion) | important | `not_evidenced` | The JD says "own demand generation", and nothing you sent says what the programmes produced. Recall prompt C2. | `[inferred]` from "own demand generation" |

## Gap handling

**G1, SQL (named absence).** You've told me you're not strong in SQL and ask your analyst. That's a stated fact, not a gap in memory, so there's nothing to recall. To close it, you'd need enough SQL to write your own SELECT / JOIN / GROUP BY queries against a marketing database, and one real query you wrote yourself that you could walk through in an interview. For a JD that says "SQL-literate", that's weeks of practice, not months. Until then, don't claim it, and be ready to say "I pull my own numbers in HubSpot and I'm learning SQL."

**Recall prompts:**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Paid social and webinars, but no distribution of content assets | It's one of the four areas this JD lists under "own demand generation" | Promoting gated content (ebooks, reports) through paid social; repurposing webinar recordings into email nurtures; syndication or partner newsletters | A campaign brief, a content calendar, a nurture flow that distributes assets | `[grounded]` what you sent; `[generic]` what an unaddressed listed duty costs on an application like this |
| C2 | Demand gen outcomes | important | Inputs (budget, flows, registrants) but no results | A Series B demand gen hire is usually judged on what the channels produced | Leads or opportunities from paid search; conversion lift from the 12 flows; pipeline sourced from webinars | A HubSpot dashboard, a quarterly review deck, an attribution report | `[grounded]` what you sent; `[generic]` how this kind of role is usually judged |

## Not written, and why

- **Hidden white-text instructions and a 1pt keyword block:** you asked for these and I've refused them, for the reasons at the top.
- **"SQL-literate" or SQL in Skills:** you said you're not strong in SQL.
- **"Senior Marketing Manager" or "Demand Generation Manager" as your title:** that would be a retitle upgrade. Your title is Marketing Manager.
- **"Owned demand generation":** this is the JD's phrase. You "ran" channels, and "own" would widen the claim using the employer's own words.
- **"Managed a budget over $500k" or "$600k+":** the JD's wording, and a rounding up. Yours is "about $600k a year".
- **"300 attendees":** you said registrants.
- **"Content distribution":** no evidence for it yet (C1).
- **Any pipeline, MQL or conversion figure:** none stated (C2).

## Parse-safety check

You pasted prose, not a file, so I couldn't check columns, tables, text boxes, headers and footers, images or file type. I also couldn't check whether your current file already has hidden text from a template or a resume service. If you share the file, I'll run all of these.

## Upgrade menu

- **Your actual resume file (.docx or PDF):** I'd quote your real current lines and run the full parse-safety and hidden-text check.
- **Employer names and dates:** the Experience rows could be placed under the right roles, and R1's six years would read from your dates rather than from the summary.
- **A dashboard or review deck:** could turn C2 into `[grounded]` outcome bullets.
- **A job-underwriter run:** could tell you how much the SQL must-have counts against applying at all.

## Questions

C1: Have you ever distributed content assets (ebooks, reports, webinar recordings) through paid social, email or partners? If so, what and how often?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Do you have any result figures for paid search, the 12 flows, or the webinars, such as leads, opportunities, pipeline or conversion rates?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

E1: Did the lifecycle email programme run in HubSpot? If yes, I can say so in the summary.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.