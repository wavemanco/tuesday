I've read the skill's rules. Below is the full edit ledger for your resume.

I built it from the background you typed, so I'm treating that as your own account of your work and quoting your sentences as the source for each edit. Nothing has been applied: every row waits for your approval. One thing up front: the JD's must-have is **3+ years of data engineering**, and your material shows 0 years under that title. No wording fixes that, so it shows up as a named gap below rather than something the ledger tries to write around.

## Requirement extraction

| Tier | Requirement |
|---|---|
| must-have | 3+ years data engineering |
| must-have | Production Python |
| must-have | Airflow or equivalent orchestration |
| must-have | Dimensional modelling |
| important | Build and own batch and streaming pipelines (Airflow, Spark, Kafka) |
| important | Own data quality and SLAs |
| important | Partner with analytics on requirements |
| important | Model the warehouse |
| preferred | Streaming experience |

## Evidence inventory (your sentences, verbatim)

- S1 "Senior Data Analyst, 5 years, retail."
- S2 "SQL every day on Redshift, complex window functions and CTEs."
- S3 "Built and maintained about 25 dbt models including the core orders mart."
- S4 "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron."
- S5 "I've fixed our nightly dbt job when it breaks and added tests to it."
- S6 "I designed the star schema for the orders mart with our then-DE."
- S7 "Never used Airflow or Spark." / S8 "Never touched Kafka."
- S9 "I'm trying to move into data engineering from analytics."

## The edit ledger: resume_edits_pending_approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years in retail, moving into data engineering from analytics." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics." | `[grounded]` your message | pending your approval |
| E2 | Summary | *(no current line)* | "Built and maintained about 25 dbt models, including the core orders mart. Designed its star schema with our then-data engineer." | `merge` | "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E3 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E4 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-data engineer" (second bullet) | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E5 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E6 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Added tests to our nightly dbt job" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E7 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python scripting to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E8 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python (pandas) for analysis" (placed after the analytics-engineering bullets) | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E9 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "SQL daily on Redshift: complex window functions and CTEs" | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |
| E10 | Skills | *(no current line)* | "SQL (Redshift) · dbt (models, tests) · Python (pandas, API scripting) · cron · star-schema modelling" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I've fixed our nightly dbt job when it breaks and added tests to it."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |

Notes on the rows:
- **E2 and E4 keep "with our then-data engineer."** You co-designed the schema. Dropping that partner turns co-design into sole design, and an interviewer will ask who you worked with.
- **E3 keeps "about 25"** rather than "25+".
- **E5 keeps "when it broke"** rather than "maintained" or "owned." Your sentence says you fixed it, not that it was yours.
- **E7 keeps "on a cron."** It doesn't become "orchestration" or "ingestion pipelines."
- **E10 lists only tools you named.** Airflow, Spark and Kafka are left out of it on purpose.

## The coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | not_evidenced | Named absence N1. Your 5 years are under the Senior Data Analyst title. E1–E4 bring forward the dbt and modelling work nearest to it, but that isn't DE tenure. | `[grounded]` your title and years as stated |
| R2 | Production Python | must-have | not_evidenced | Recall prompt C1. E7 shows API scripting on a cron; whether anyone depended on it as production isn't stated. | `[grounded]` S4 says "for analysis" and "some scripting" |
| R3 | Airflow or equivalent orchestration | must-have | not_evidenced | Recall prompt C2. Cron (E7) and a nightly dbt job (E5) are scheduling. Your material doesn't say whether either had dependency management. | `[grounded]` S4, S5, S7 |
| R4 | Dimensional modelling | must-have | surfaced_by_edit | E2, E4 and E10: star schema for the orders mart, co-designed. | `[grounded]` S6 |
| R5 | Model the warehouse | important | surfaced_by_edit | E2, E3: about 25 dbt models including the core orders mart. This is a warehouse layer, not the whole warehouse. | `[grounded]` S3 |
| R6 | Own data quality | important | surfaced_by_edit | E6: you added tests. Your material doesn't show ownership of quality. | `[grounded]` S5 |
| R7 | Own SLAs | important | not_evidenced | Recall prompt C3 | `[grounded]` nothing in your material mentions a deadline or SLA |
| R8 | Batch pipelines (Airflow, Spark) | important | not_evidenced | Named absence N2 | `[grounded]` S7 |
| R9 | Streaming / Kafka | preferred | not_evidenced | Named absence N3 | `[grounded]` S8 |
| R10 | Partner with analytics on requirements | important | not_evidenced | You were the analytics side. That's real knowledge of requirements, but your material shows no DE-side partnering with analysts. See the prohibited list. | `[grounded]` S1, S6 |
| R11 | SQL on a warehouse | important | already_evidenced | E9 only tidies it | `[grounded]` S2 |

## Gap handling

**Recall prompts**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python "for analysis" plus vendor-API scripts on a cron. It doesn't say whether the scripts fed tables others relied on. | It's a must-have, and "for analysis" reads as notebook work. | Scripts that load vendor data into Redshift for dbt to use; retries or error handling you added; scripts in version control or code review | A repo or gist of the script; a PR | `[grounded]` what S4 does and does not say; `[generic]` analysis-only Python is commonly read as not production on DE roles |
| C2 | Airflow or equivalent orchestration | must-have | A cron, and a nightly dbt job you fixed. What scheduled the dbt job isn't stated. | It's a must-have, and "or equivalent" is the only route to it from your material. | dbt Cloud jobs you set up; job dependencies you configured; alerting on failure | Job config or a screenshot of a job definition | `[grounded]` S4, S5; `[generic]` cron is often not read as orchestration |
| C3 | Own SLAs | important | You fixed the nightly job when it broke. There's no deadline or consumer in the sentence. | The JD pairs "data quality and SLAs" as things you'd own. | Dashboards or reports that had to be ready by a set time; who you told when the job failed; how fast fixes had to land | An incident note, Slack thread, or runbook | `[grounded]` S5 |

**Named absences**
- **N1, 3+ years DE:** This is a must-have and you don't meet it as titled tenure. Rewording can't close it. Your real options:
  - apply anyway, with E1 saying plainly that you're moving into DE;
  - aim at analytics-engineer or junior/mid DE roles;
  - move into DE work in your current role.
- **N2, Airflow and Spark:** You've never used either. Closing it takes a real project, for example rebuilding your vendor-API scripts as an Airflow DAG in a public repo. Spark is only in the duties list, not the requirements, so it matters less.
- **N3, Kafka/streaming:** You've never touched it. It's listed as a plus, so it isn't worth closing before you apply. A small Kafka-to-warehouse side project would close it later.

## Not written, and why

- **"Data Engineer" or "Analytics Engineer" as your title.** Your title is Senior Data Analyst. Changing it is an upgrade, not an equivalent.
- **"3+ years of data engineering" or "5 years building data pipelines."** Your 5 years were in analytics.
- **"Built and owned data pipelines."** You built dbt models and fixed a job when it broke. "Owned pipelines" is a different job.
- **Airflow, Spark or Kafka anywhere, the Skills section included.** You said you've never used them.
- **"Orchestrated" or "orchestration" for the cron.** That's the JD's word, not a description of your cron.
- **"Owned data quality and SLAs."** You added tests. SLAs appear nowhere in your material.
- **"Partnered with analytics on requirements."** This would put you on the DE side of a table you sat across from as the analyst.
- **"Production Python."** Your sentence says "for analysis" and "some scripting."
- **"Designed the warehouse star schema"** without "with our then-DE," and limited to the orders mart.
- **"25+ dbt models."** Your number is "about 25."

## Parse-safety check

Your resume came as typed prose, not a file, so I couldn't run the layout checks: columns, tables or text boxes, images, header/footer content, file type, or hidden text. The proposed rows use the standard headings Summary, Experience and Skills. If you send the actual file, I'll run the full check.

## Upgrade menu

- **Your dbt project, or an excerpt with its tests:** would back up E3, E6 and R5 with something a reviewer can open.
- **The vendor-API script, in a repo:** could close C1.
- **An Airflow DAG version of that script, as a public project:** the realistic way to start closing N2 and R3.

Whether the 3+ years must-have makes this posting worth applying to is a question for job-underwriter.

C1: Did your vendor-API scripts load data that dbt models or other people depended on, and did they have retries, error handling or version control?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: What ran the nightly dbt job (dbt Cloud, cron, something else), and did you set up its schedule, dependencies or failure alerts yourself?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: When the nightly job broke, did something have to be ready by a set time (a dashboard or a morning report), and who did you tell?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.