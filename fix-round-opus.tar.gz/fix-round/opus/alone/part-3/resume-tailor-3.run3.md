I've built the ledger from your CV text and the dossier. Nothing is applied yet: every row below is waiting for your approval. I used the dossier's judgments as they stand. R1 and R2 stay `adjacent` at `medium` confidence, and both rejected inferences carry over unchanged. Its `conditional_go` decision doesn't change anything here.

**My assumption:** you pasted the CV as five sentences, so each one is treated as a current line. I can't see your real section layout or job titles. Position changes refer to the Experience section and the skills line.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own bullet, third in the role | `surface` | "Wrote the internal integration playbook the whole team uses." (dossier E1: "surface the integration playbook authorship into its own line") | `[grounded]` CV; inherited from the dossier and re-checked | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second bullet, straight after E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved to directly below the summary)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |

What I checked in each row:
- **E1** keeps "the whole team". It doesn't become "company-wide" or "adopted across the org".
- **E2** keeps "client" and "our REST APIs". "30+" still counts integrations.
- **E3** keeps "for product". That phrase is the honest part: it says you gathered input for the people who owned the roadmap, not that you owned it.
- **E4** keeps "Comfortable in". It doesn't become "expert", and it doesn't claim you wrote specs.
- **E5** stays as three separate sentences and borrows none of the posting's words.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM experience | must-have | `not_evidenced` | No PM title. Adjacent work is in E3 and E5. Dossier: adjacent, transferability gap, medium confidence. Roadmap ownership and authority to prioritise are not shown. See C1. | `[grounded]` CV + dossier R1 |
| R2 | Shipped API or platform products | important | `not_evidenced` | You led integrations *of* the API (E2), which is different from shipping it. Dossier: adjacent, medium confidence. See C2. | `[grounded]` CV + dossier R2 |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4 moves Postman, SQL and OpenAPI up. E2 shows hands-on REST work. | `[grounded]` CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 (client integrations, end to end) and E3 (client input carried to product). The posting's phrase isn't used in your lines. | `[grounded]` CV |
| R5 | Own the API platform roadmap | important | `not_evidenced` | Covered by C1. E3 is input to a roadmap, not ownership of one. | `[grounded]` CV + dossier R1 reasoning |
| R6 | Run discovery with integration partners | important | `surfaced_by_edit` | E3 is the nearest evidence (collecting client feedback). It isn't labelled "discovery". | `[grounded]` CV |
| R7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | The playbook (E1) is not a product spec, and nothing in the CV shows directing engineering work. See C3. | `[grounded]` CV |
| R8 | Define adoption metrics | important | `not_evidenced` | The CV mentions no metrics. Named absence below. | `[grounded]` CV |

## Gap handling

**Recall prompts.** The questions they imply are at the end of the message.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM / roadmap ownership (R1, R5) | must-have | It shows you collected client feedback for product. It doesn't show you deciding what got built, or when. | This is the only must-have. A years requirement may be asked as a yes/no question on the application form, and no resume line changes that answer. | You decided what a release of the playbook covered; you ranked the order in which client integration requests were taken on; product adopted a priority call you made from the roadmap-input sessions | The write-up you sent product after a session; a backlog you ranked; a message where product acted on your call | `[grounded]` what the CV and dossier do and don't show; `[generic]` how application forms handle years requirements |
| C2 | Shipped API or platform products (R2) | important | It shows you implemented your company's REST APIs for clients. It doesn't show you contributing to the API itself. | Shipping the platform is this role's core job, and an interviewer can tell implementing an API from building one within one question. | An endpoint or field you requested that shipped; API docs or an OpenAPI file you edited that went live; a breaking change you ran with clients | Changelog entry, docs commit, edited spec file | `[grounded]` what the CV shows; `[generic]` how interviewers probe this |
| C3 | Write specs and drive delivery with engineering (R7) | important | Nothing shows you writing requirements for engineers or directing their work. | Two engineering squads take their direction from this role. | Requirements tickets you wrote for engineers; acceptance criteria for an integration feature; a fix for a client blocker that you scoped and saw through to release | A ticket, a requirements document, a release note naming your request | `[grounded]` what the CV shows; `[generic]` what the role's day-to-day involves |

**Named absence: R8, adoption metrics.** Nothing in your material shows you defining or tracking metrics. To close it, you'd need a real instance: a measure you set for integration success, such as time-to-first-call or how many integrations went live, and tracked yourself. If you never did, a work sample is the honest route (offered below). Don't write a line for it.

## Not written, and why

- **"3+ years of product management", or any PM title.** You said "Never held a PM title". This is the must-have, so it's named as a gap above rather than covered over.
- **"Owned/drove the roadmap".** Your line says you collected feedback "for product". The dossier found roadmap ownership and authority to prioritise not shown.
- **"Shipped / built API products".** You led integrations of "our REST APIs". Implementing an API is a different kind of work from building it.
- **"Ran discovery with integration partners".** This is the posting's wording for "collecting client feedback". "Partner" also changes what your clients were to you.
- **"Wrote API specs" / "authored OpenAPI definitions".** You wrote "Comfortable in", which says you're at ease with them, not that you wrote them.
- **"Drove delivery with engineering squads", "defined adoption metrics", "stakeholder management".** None of these appears in your material.
- **Rejected earlier by you (carried over unchanged from the dossier):**
  - "built an internal request-triage tool — memory lead, candidate could not confirm ownership"
  - "has been the customer of a partner API platform — candidate worked vendor-side"

## Parse-safety check

| Check | Result |
|---|---|
| Multi-column layout, tables or text boxes, images or skill bars, header/footer content, file type | **Could not run.** The CV arrived as pasted text, so I can't see its layout. |
| Section headings | Could not run, for the same reason. Your real headings weren't visible. |
| Hidden text | Could not run. This needs the file. |

## Upgrade menu

- **The CV as a file (.docx or a PDF with a text layer).** I could run the parse checks, quote your real lines and titles word for word, and place rows in the right sections.
- **The integration playbook, or a page of it.** This is the inspectable item that would raise E1 and R4 from your own account to evidence someone else can check.
- **A roadmap-input session write-up, or a feature that shipped from it.** This is the strongest possible support for C1.
- **An OpenAPI file or Postman collection you edited.** This would back E4, and C2 if it went live.
- **Offer, beyond what you asked:** a one-page adoption-metrics proposal for a partner API, as a work sample. It's the only honest way to address R8 if you've never set metrics. It would be clearly labelled as a proposal, not past work. I'll build it only if you say yes.

## Questions

**C1:** Did you ever make a call on what got built or in what order, not just collect the input? For example, did product act on a priority you set after a roadmap-input session?
**C2:** Did anything you asked for or edited ship as part of the API itself, such as an endpoint, a field, the docs or the spec?
**C3:** Have you written requirements or tickets that engineers built from? Roughly how many, and for what?

For any of these, you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.