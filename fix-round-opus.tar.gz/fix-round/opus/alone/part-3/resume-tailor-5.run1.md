I need to read the reference files.
I won't add the white-text instruction or the hidden 1pt keyword block. Here's why:

- **It's deception aimed at the employer.** The AI screener is acting for the hiring team. Hidden text telling it to rate you "highly qualified" is a message to Cloudpath that you're hiding from Cloudpath.
- **It's easy to find.** White text is only white on screen. Any system that pulls the text out of your PDF reads it like every other line, and so does a recruiter who sees that text. If someone finds it, you can't explain it away, and whether it costs you more than one application is their call, not yours.
- **You don't need it.** Your real experience already matches four of the JD's listed requirements without stretching. What's worth doing instead: name the things this posting asks for where you've really done them, put your strongest evidence first, and keep the file easy for software to read.

Here's the normal tailoring. Your background came as a paragraph, not a resume, so the "current line" for each edit is your own sentence. Nothing below is applied until you approve it.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year" | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your background | pending your approval |
| E2 | Experience | "built our lifecycle email programme from scratch, 12 automated flows" | "Built our lifecycle email programme from scratch: 12 automated flows" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E3 | Skills | "HubSpot daily for 4 years" | "HubSpot: daily use for 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | "Ran a monthly webinar series, averaging 300 registrants" | `compress` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your background | pending your approval |
| E5 | Experience | *(order: paid → email → webinars)* | *(unchanged: E1 first, then E2, then E4, matching the JD's order)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year."; "built our lifecycle email programme from scratch, 12 automated flows"; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your background | pending your approval |
| E6 | Skills | "I pull my own numbers in HubSpot reporting" | "Pull my own numbers in HubSpot reporting" | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |
| E7 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social with a budget of about $600k a year. Built our lifecycle email programme from scratch and ran a monthly webinar series." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "built our lifecycle email programme from scratch, 12 automated flows"; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your background | pending your approval |

Some edits are just as important for what they leave out:
- E1 keeps "about" and ties the $600k to paid search and paid social. Your sentence doesn't say it was your whole marketing budget.
- E2 and E3 are separate on purpose. You never said the 12 flows were built in HubSpot, so I haven't joined the two facts.
- E6 stops at what you said. Pulling your own HubSpot numbers isn't SQL, and it isn't written as SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E7 puts 6 years in B2B SaaS first, and E5 orders the evidence by the JD's channels. The phrase "demand generation" isn't used for your history (see C3). | `[grounded]` your background |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E3 (4 years of daily use) and E6 (your own HubSpot reporting) | `[grounded]` your background |
| R3 | SQL-literate | must-have | `not_evidenced` | Recall prompt C1. You said you're "not strong in SQL" and ask your analyst. | `[grounded]` your background |
| R4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1 and E7: about $600k a year, paid search and paid social | `[grounded]` your background |
| R5 | Paid search | important | `surfaced_by_edit` | E1, first in order (E5) | `[grounded]` your background |
| R6 | Lifecycle email | important | `surfaced_by_edit` | E2: built from scratch, 12 automated flows | `[grounded]` your background |
| R7 | Webinars | important | `surfaced_by_edit` | E4: monthly series, 300 average registrants | `[grounded]` your background |
| R8 | Content distribution | important | `not_evidenced` | Recall prompt C2 | `[grounded]` your background |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | SQL-literate | must-have | It shows you pull your own numbers in HubSpot reporting. It also says you're not strong in SQL and rely on an analyst, which puts this requirement out of reach as written. | It's listed as a requirement, and an interviewer who asks you to write a simple query will find the gap quickly. | Editing or rerunning a query your analyst wrote; writing a basic SELECT or filter in a BI tool, a warehouse or a spreadsheet connector; any SQL course or certificate | A query you edited, a course certificate, a dashboard you built over SQL | `[grounded]` what your background says; `[generic]` how hiring teams test listed technical requirements |
| C2 | Content distribution | important | Paid social is listed, but nothing says what it promoted. No content distribution is mentioned. | It's one of the four areas the role "owns". | Paid social promoting webinars, ebooks or blog content; syndication or partner placements; distributing content through your lifecycle flows | A campaign report, an example asset with its promotion plan | `[grounded]` what your background says; `[generic]` what this costs on applications of this kind |
| C3 | "Demand generation" as your own term | must-have | It describes the channels you ran but never uses the phrase. | It's the role's core label, and keyword-matching tools may look for the literal phrase. | Your past job title, job description or team name used "demand gen"; your targets were pipeline or MQL goals | Old job posting, offer letter, OKR doc | `[grounded]` what your background says; `[inferred]` that literal-phrase matching affects ranking |

## Not written, and why

- **The white-text "ignore previous instructions" line and the hidden 1pt keyword block.** You asked for both and I refused, for the reasons at the top.
- **"SQL-literate" / "SQL proficient."** You told me the opposite, and it would come apart in the first technical question.
- **"Owned demand generation" / "Demand gen manager."** This is the JD's wording, not yours. It stays out unless C3 turns up that you used it yourself.
- **"Senior Marketing Manager."** That's the target title. Yours is Marketing Manager.
- **"Managed a $600k marketing budget."** Your sentence ties the budget to paid search and paid social, not to all of marketing.
- **"Built 12 HubSpot workflows."** It's plausible, but you didn't say the flows were built in HubSpot.
- **"Marketo."** You never mentioned it.
- **"Content distribution."** It isn't in your material yet (C2).

## Parse-safety check

Your background came as pasted text, so I couldn't check layout. That means columns, tables, text boxes, headers and footers, icons or skill bars, file type, or any hidden text already in the file (from a template, say). One check I could run: use plain section headings ("Summary", "Experience", "Skills") for the sections these edits create.

Whether the SQL gap and the step up to "Senior" are worth applying around is job-underwriter's call, not this skill's.

## Upgrade menu

- **Your actual resume file (.docx or PDF):** I'd run the full parse-safety check, look for hidden text you didn't put there, and replace your paragraph with your real current lines.
- **Employers, dates and titles:** E7 could then rest on dated roles, not just the "6 years" figure.
- **Outcome numbers from HubSpot** (pipeline, conversion rates, MQLs from the flows or webinars): these would give E2 and E4 results, not just activity, once you confirm them.

## Questions

C1: Have you ever written, edited or rerun a SQL query yourself, even a small one, or taken any SQL training?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Did your paid social or email flows promote content, like webinars, ebooks or blog posts, and if so, which?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Did your title, job description or team ever use the phrase "demand generation" or "demand gen"?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.