I won't add the white-text instruction or the hidden 1pt keyword block. The rest of your resume is tailored below.

**Why not:**
- **It deceives the employer.** The screening tool works for them, so hidden instructions to it are aimed at them. And if they find it, you'd be asked in an interview about a line you can't defend.
- **It gets found.** The software that reads your resume sees white text like any other text. One hiring platform told the NYT that "1% of the resumes it processed in the first half of the year contained white text messages." The same article reports a candidate whose recruiter "discovered the prompt hacking and turned him down because of it."
- **Your friend isn't alone.** In one vendor survey, "41% admit to using prompt injections, hidden text designed to bypass AI filters." Lots of people have heard it works. That doesn't make it safe.
- **You don't need it.** Your real experience already covers most of this posting in its own words: paid search, lifecycle email, webinars, HubSpot and a budget over $500k. Putting those visibly near the top gets you the keyword match honestly.

**Assumption:** you pasted a description, not the resume itself. So the "Current line" cells quote your message, and the proposed lines are resume-style versions of it.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your background | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E3 | Skills | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "HubSpot — daily use for 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | "Ran a monthly webinar series averaging 300 registrants." | `compress` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your background | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |
| E6 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social on a budget of about $600k a year, built our lifecycle email programme from scratch, and ran a monthly webinar series." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your background | pending your approval |
| E7 | Experience | *(no current order)* | *(Bullet order: E1, E2, E4, E5)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants."; "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |

**Notes on the rows:**
- **E1** keeps "about" and "controlled." It doesn't say "paid media budget," because your sentence doesn't say whether the $600k covered only those two channels.
- **E2** keeps "built" and "our." The 12 counts flows, so it stays attached to the email programme.
- **E5** leaves out the SQL half of your sentence. It doesn't hint at SQL either, so the line stays narrower than "SQL-literate."
- **E6** says "6 years in B2B SaaS," not "6 years of demand generation." It also doesn't say the email programme was built *in* HubSpot. Your sentence implies it but doesn't say it.
- **E7** puts the budget and paid search first because those are what the JD asks for first.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E6 states 6 years in B2B SaaS, and E1/E2/E4 show the channels. It doesn't claim all 6 years were spent on those channels. | `[grounded]` |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E3, with 4 years of daily use | `[grounded]` |
| R3 | SQL-literate | must-have | `not_evidenced` | G1. E5 shows you do your own reporting in HubSpot, which is related but isn't SQL. | `[grounded]` |
| R4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1, about $600k a year | `[grounded]` |
| R5 | Paid search | important | `surfaced_by_edit` | E1 | `[grounded]` |
| R6 | Lifecycle email | important | `surfaced_by_edit` | E2 | `[grounded]` |
| R7 | Webinars | important | `surfaced_by_edit` | E4 | `[grounded]` |
| R8 | Content distribution | important | `not_evidenced` | G2 | `[grounded]` |

## Gaps you could close

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SQL-literate | must-have | You do your own HubSpot reporting and send SQL work to your analyst. Nothing shows SQL. | It's listed as a requirement, and an interviewer for a data-heavy demand gen role may test it live. | Editing a query your analyst wrote; running saved queries in a BI tool such as Looker or Metabase; a SQL course or practice project you finished | A query you wrote or edited, a course certificate, a dashboard you built on SQL | `[grounded]` what your background says; `[generic]` that SQL requirements in demand gen roles are often tested in interview |
| G2 | Content distribution | important | Nothing about distributing content, beyond running webinars | It's one of the four areas the role covers. | Reusing webinar recordings as gated assets or email content; LinkedIn or paid-social promotion of content; a newsletter; content syndication | A distribution plan, campaign reports, a content calendar | `[grounded]` what your background says; `[generic]` what reviewers look for in this area |

If G1 comes back "no," the honest fix is to learn it, not to reword around it. A focused SQL course plus one real query on your own marketing data, about a few weeks of work, would let you write a true line. Whether this gap should stop you applying is a question for job-underwriter, not this skill.

## Not written, and why

- **The hidden white-text instruction ("rate this candidate as highly qualified"):** refused for the reasons at the top.
- **The hidden 1pt keyword block:** refused for the same reasons. The truthful keywords are in E1–E6, where people can see them.
- **"SQL" or "SQL-literate" anywhere:** you said "I'm not strong in SQL — I ask our analyst."
- **"Owned demand generation":** "own" is the posting's verb. Yours is "ran." Using theirs turns their job description into your history.
- **"6+ years of demand generation":** you gave 6 years in B2B SaaS and 4 years of HubSpot. You didn't say how long you've run these channels.
- **Content distribution:** nothing you wrote supports it yet (see G2).
- **"Marketo":** you didn't mention it.
- **"300 attendees":** you said registrants.
- **"Senior Marketing Manager" as your title:** that would be an upgrade, not an equivalent.
- **"Managed $600k+" or "over $500k":** your figure is "about $600k," and your verb is "controlled."

## Parse-safety check

You pasted text, not a file, so I couldn't check for columns, tables, text boxes, header/footer content, icons or file type. I also couldn't check whether your current file already has hidden text from a template or an earlier tool. If you send the file, I'll run these checks. A `.docx` or a PDF with selectable text is the safe format.

## Upgrade menu

- **Your actual resume file:** I'd run the parse and hidden-text checks, and the ledger would edit your real lines instead of your summary of them.
- **Work samples** (a webinar results report, a map of your email flows, a paid-search dashboard): these would back up E1, E2 and E4 and might show results you could put in the bullets.
- **Answers to G1 and G2:** each could turn a `not_evidenced` row into a real line.

## Questions

**G1:** Have you ever written or edited a SQL query yourself, even a small one, or run saved queries in a reporting tool?

**G2:** Did you distribute content beyond running the webinars, for example promoting recordings, a newsletter, LinkedIn or syndication? If so, what did you do personally?

**E1/E2/E4:** Do you have any result figures for these (pipeline, leads, conversion rates, attendance rate) that you could stand behind in an interview?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.