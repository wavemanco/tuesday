I've built the edit ledger below. Nothing has been changed in your CV yet: every row waits for your approval.

You pasted a summary of your background rather than the CV itself. So I've treated the sentences in your message as your current lines, and every quote in the "Traces to" column comes from them. If your actual bullets are worded differently, paste them and I'll redo only the rows that change.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet of your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E3 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E4 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team (usually two or three a year), pairing with each for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your message | pending your approval |
| E5 | Skills | "Go and Rust daily for 4 years, Python before that." | "Go, Rust: daily for 4 years. Python: before that." Placed as the first Skills line, above "Kafka, Postgres, Terraform, gRPC, Datadog". | `reorder` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your message | pending your approval |
| E6 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for the last 4. Own three services in the ledger pipeline at a payments company. Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |

Notes on the rows:
- **E1:** Your strongest line already does what the JD asks for ("drive down p99 latency"), and the fix involved a cache layer. It only needs to move to the top.
- **E2:** The 40k requests/minute belongs to one service, so the line keeps "one", "about" and "at peak". It doesn't become "three services handling 40k rpm".
- **E6:** Each sentence is kept separate. The 40k figure stays out of the summary so it can't drift onto all three services. "For the last 4" assumes your 4 years of Go and Rust are your most recent 4. Your message says "Python before that", which points that way, but if I've read it wrong I'll change it.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E6 states 7 years as a software engineer. It doesn't say all 7 were backend work, so the line doesn't claim that. | `[grounded]` |
| R2 | Production Go | must-have | `surfaced_by_edit` | E5 and E6 show daily Go for 4 years. Nothing says your three services are written in Go. That gap is C1. | `[grounded]` |
| R3 | Distributed systems at scale | must-have | `surfaced_by_edit` | E2: three services in a pipeline, one at about 40k requests/minute at peak. The JD's phrase "distributed systems" isn't written about you. | `[grounded]` |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E3: six incidents as incident commander. | `[grounded]` |
| R5 | Experience mentoring | must-have | `surfaced_by_edit` | E4: onboarding and month-long pairing, worded as that rather than as "mentoring". | `[grounded]` |
| R6 | High request volume, p99 latency | important | `surfaced_by_edit` | E1, E2 | `[grounded]` |
| R7 | Own on-call for your services | important | `surfaced_by_edit` | E3. Your sentence doesn't say the rotation covers your own services, so the line doesn't either. | `[grounded]` |
| R8 | Mentor mid-level engineers | important | `not_evidenced` | C2 | `[grounded]` |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | C3 | `[grounded]` |

## Gap handling: recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go: "design and ship Go services" | must-have | 4 years of daily Go, and three services you own, but nothing connecting the two | Go services are the first thing the role describes. A reader may not assume your services are Go when Rust is listed next to it. | Your ledger services written in Go; a Go service you designed and shipped from scratch; the cache-layer rework done in Go | A repo, a design doc, a service README | `[grounded]` what your message says and doesn't say; `[generic]` how readers treat a language listed beside the work |
| C2 | Mentor mid-level engineers | important | Onboarding and pairing with new hires for their first month | Onboarding new hires and mentoring mid-level engineers are different work. An interviewer is likely to ask which one you've done. | Ongoing 1:1s with an engineer past onboarding; reviewing someone's design docs over time; helping someone get promoted | A promotion write-up you contributed to; a review comment thread | `[grounded]` what your message says; `[generic]` how interviewers probe mentoring |
| C3 | Partner with product on roadmap sequencing | important | Nothing in your material touches product or the roadmap | It's one of five listed responsibilities and is currently blank. | Arguing for the cache rework against feature work; sequencing changes to the ledger pipeline with a PM; estimating work for quarterly planning | A planning doc, an RFC with product sign-off | `[grounded]` absence in your material; `[generic]` what senior backend roles usually expect here |

## Not written, and why

- **"Senior Backend Engineer" as your title.** That's the posting's title, not yours. Your title stays "Senior Software Engineer".
- **"Mentored mid-level engineers".** You onboard new hires and pair with them for a month. Calling that mentoring mid-level engineers would change what kind of work it was.
- **"Built / designed Go services".** You use Go daily, but you haven't said your services are in Go, or that you designed them. That's C1.
- **"Three services handling 40k requests/minute".** The figure belongs to one service.
- **"Own on-call for my services".** You described an on-call rotation, not its scope.
- **"Distributed systems at scale" as a phrase about you.** It's the JD's wording for your history. E2's actual numbers make the case without it.
- **"Redesigned the caching architecture".** You wrote "reworking the cache layer". "Redesigned" claims more.
- **Kafka or gRPC moved into Experience bullets.** Listing a tool doesn't show you own it. They stay in Skills unless you tell me how you used them.
- **Anything about working with product.** There's nothing in your material to support it (C3).

## Parse-safety check

You pasted text, not a file, so I couldn't check for columns, tables or text boxes, images or skill bars, content in headers or footers, file type, or hidden text. Send the `.docx` or PDF and I'll run those checks. The section names these edits use (Summary, Experience, Skills) are standard ones that parsers recognise.

## Upgrade menu

- **Your actual CV text:** turns these rows into exact before-and-after diffs of your wording.
- **How Kafka, gRPC and Postgres figure in the three services:** could let a tool move from Skills into a grounded Experience bullet, which would strengthen R3.
- **A design doc or postmortem you wrote (with sensitive details removed):** could support "design" and incident-response lines beyond what you've told me.

## Questions

C1 — Are the three ledger-pipeline services, including the 40k requests/minute one, written in Go, and did you design any of them or only take ownership later?
C2 — Beyond onboarding new hires, have you had an ongoing mentoring relationship with an engineer past their first month?
C3 — Have you ever worked with a PM on what order things got built in, for example arguing for the cache rework or planning pipeline changes?
For each, you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.