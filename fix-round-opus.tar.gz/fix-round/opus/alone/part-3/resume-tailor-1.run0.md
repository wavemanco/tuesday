Reading the skill's last few rules on how to format the output, then I'll write your ledger.
I've built your tailoring ledger below; nothing has been applied yet. One assumption shapes all of it: you described your CV but didn't paste its actual lines. So every "Current line" cell quotes your description, and the quotes in "Traces to" are your sentences from this message.

Your material fits this JD well. Each of its five requirements has something real behind it. Most of the work is putting the strongest evidence first and keeping your own wording. There are three gaps the JD asks about that your CV doesn't answer, and I haven't written around any of them.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in a payments ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Currently at a payments company." | `[grounded]` your description | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet of your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your description | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline — one handles about 40k requests/minute at peak." *(moved to second bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your description | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Ran six incidents as incident commander." / "On-call rotation every fourth week for two years." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your description | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year; pair with them for their first month." | `reframe` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your description | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Python · Kafka, Postgres, gRPC, Terraform, Datadog" | `reorder` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your description | pending your approval |

Notes on the rows:
- **E3** keeps "one", "about" and "at peak". The 40k figure applies to one service at peak, not to all three.
- **E4** puts the incident-commander work first. The two clauses stay as separate lines because you didn't say whether the rotation covers your own three services.
- **E5** says "onboard" and "pair", not "mentor".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1: 7 years as a Senior Software Engineer. You didn't say all 7 years were backend, so E1 doesn't say it either. E3 shows the service ownership. | `[grounded]` |
| R2 | Go, sustained use | must-have | `surfaced_by_edit` | E1 and E6: "Go and Rust daily for 4 years" | `[grounded]` |
| R3 | Production Go services you designed and shipped | must-have | `not_evidenced` | G1. You didn't say what language the three services are written in or who built them. | `[grounded]` |
| R4 | Distributed systems at scale | must-have | `surfaced_by_edit` | E3 (about 40k requests/minute at peak), with Kafka and gRPC listed in E6. The phrase itself isn't written as your claim. | `[grounded]` |
| R5 | Strong incident response | must-have | `surfaced_by_edit` | E4: six incidents as incident commander | `[grounded]` |
| R6 | Experience mentoring | must-have | `surfaced_by_edit` | E5: onboarding and first-month pairing, in your words | `[grounded]` |
| R7 | Mentor mid-level engineers | important | `not_evidenced` | G2 | `[grounded]` |
| R8 | Drive down p99 latency | important | `surfaced_by_edit` | E2: 380ms → 95ms | `[grounded]` |
| R9 | Own on-call for your services | important | `surfaced_by_edit` | E4: rotation every fourth week for two years. Whether it covers your own services isn't stated. | `[grounded]` |
| R10 | High request volume | important | `surfaced_by_edit` | E3 | `[grounded]` |
| R11 | Partner with product on roadmap sequencing | important | `not_evidenced` | G3 | `[grounded]` |

## Gap handling: recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Design and ship Go services | must-have | Go daily for 4 years, and ownership of three services. Nothing connects the two, and nothing says you built any of them. | This is the core of the role, and an interviewer's first probe will be "which service, and what did you build?" | Writing one of the ledger services in Go from scratch; moving one from Python to Go; designing the reworked cache layer behind the p99 cut | A design doc, the repo or PR history, a launch note | `[grounded]` what the resume does and doesn't say; `[generic]` how technical screens for this kind of role usually probe |
| G2 | Mentor mid-level engineers | important | Onboarding and first-month pairing with new hires. Their level and anything past the first month aren't stated. | The JD wants mentoring of mid-level engineers, which is longer-term work than onboarding | Ongoing design reviews with a specific engineer; helping someone get promoted; coaching a teammate through their first stint as incident commander | A promotion packet you contributed to, written feedback, a review thread | `[grounded]` what the resume does and doesn't say; `[generic]` how senior roles usually separate onboarding from mentoring |
| G3 | Partner with product on roadmap sequencing | important | Nothing | It's a named responsibility, and nothing in your material addresses it | Arguing with a PM about the order of ledger work; the p99 project competing with feature work for priority; scoping a quarter's plan for your services | A planning doc, a roadmap comment thread, a quarterly plan | `[grounded]` |

## Not written, and why

- **"Senior Backend Engineer" as your title.** Your title is Senior Software Engineer, and swapping in the posting's title would be an upgrade, not an equivalent.
- **"Designed and shipped Go services."** You didn't say the services are in Go or that you built them. G1 asks.
- **"Distributed systems at scale" as a claim about yourself.** That's the JD's wording. Your evidence is the 40k figure, and E3 uses your words.
- **"Mentored engineers."** Your verb is "pair", with new hires, for their first month. Changing the verb changes the kind of work.
- **"Own on-call for my services."** That would merge the rotation and the service ownership, which you stated separately.
- **"40k+ requests/minute across my services."** It's about 40k, for one service, at peak.
- **"Led incident response."** You were incident commander on six incidents. "Led incident response" claims a wider scope than that.
- **"Used Datadog to cut p99."** Datadog is a tool your CV lists. You didn't connect it to the latency work.
- **"Partnered with product on roadmap."** Nothing you gave me supports it. G3 asks.

## Parse-safety check

You described your CV rather than sending the file or pasting its text, so I couldn't check any of these: columns, tables or text boxes, images or skill bars, contact details in headers or footers, section-heading names, file type, or any hidden text inherited from a template. If you send the file or its text, I'll run them. The safe file formats are a `.docx` or a PDF with real, selectable text (not a scanned image).

## Upgrade menu

- **Your CV's actual text or file.** The "Current line" cells would compare against your real wording instead of my reading of your description, and I could run the parse checks.
- **A postmortem from one of your six incidents, or a design doc for the cache rework.** Either is the kind of evidence a backend interviewer can actually inspect. It would back up E2 and E4 in the interview.
- **Answers to G1–G3.** Each one could turn a `not_evidenced` row into a real ledger line.

## Questions

G1: Which of your three ledger services are written in Go, and did you build any of them yourself rather than inheriting them?
G2: Apart from onboarding, have you guided a mid-level engineer over months, through design reviews, promotion support or similar?
G3: Have you worked with a product manager to decide the order of work for your services?

For any of these, you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.