I've got the skill's rules loaded. Here is the tailoring pass, Sam.

**First, about the premise.** Keyword matching is probably not the main reason you're being rejected. The one sample I have (a vendor's interviews with 25 US recruiters) found "AI/content auto-rejection configured: 8% of recruiters" (cite C25). It also found "When automated filters are used, they're almost always knockout questions" (cite C26), meaning yes/no eligibility questions on the application form. Where match scores are used, "Many teams use match scores/filters to prioritize who gets reviewed first" (cite C27), and "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27). So keywords probably affect where you sit in the queue more than whether you get binned. Twenty-five people is a small sample, so treat that as a lean, not a fact.

Two things are more likely to be hurting you:

1. **Your file format** (see the parse-safety check below). It may be hiding keywords you actually have.
2. **A real gap against this posting.** It names about 16 technologies. Your evidence covers AWS, Python, a deploy pipeline and a two-month Kubernetes trial. No wording fixes that, and I won't write lines that pretend otherwise. Whether this role is worth applying for is job-underwriter's question, not this skill's.

---

### Requirements extracted

The posting doesn't rank anything. **I assumed** the role statement ("own platform reliability and developer experience") is must-have, and every listed tool is `important`.

### Your evidence (the only material any row below may use)

- S1: "DevOps Engineer, 4 years."
- S2: "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."
- S3: "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."
- S4: "Ran a Kubernetes proof-of-concept for two months last year — never went to production."

### The coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Own platform reliability and developer experience | must-have | `not_evidenced` | Running a pipeline and about 30 jobs is related but doesn't show ownership of a platform others use. Recall prompt C3 | `[grounded]` |
| R2 | Kubernetes | important | `surfaced_by_edit` | E3, kept as a two-month proof-of-concept, not production | `[grounded]` |
| R3 | AWS EKS | important | `not_evidenced` | AWS is shown, EKS isn't. Recall prompt C1 | `[grounded]` |
| R4 | Helm | important | `not_evidenced` | Recall prompt C1 | `[grounded]` |
| R5 | Terraform | important | `not_evidenced` | Ansible is configuration management, which is different work from infrastructure provisioning. Recall prompt C2 | `[grounded]` |
| R6 | ArgoCD / GitOps | important | `not_evidenced` | Named absence N1 | `[grounded]` |
| R7 | Istio / service mesh | important | `not_evidenced` | Named absence N2 | `[grounded]` |
| R8 | Prometheus, Grafana, observability | important | `not_evidenced` | CloudWatch monitoring is related and kept under its own name in E2. Named absence N3 | `[grounded]` |
| R9 | Vault | important | `not_evidenced` | IAM is access management, not secrets management. Named absence N4 | `[grounded]` |
| R10 | SRE practices | important | `not_evidenced` | Recall prompt C3 | `[grounded]` |
| R11 | CI/CD pipeline work | important | `surfaced_by_edit` | E1, E2, E4. Labelled "deployment pipeline" until C3 confirms the CI part | `[grounded]` |
| R12 | GitLab CI | important | `not_evidenced` | Named absence N5 | `[grounded]` |
| R13 | Python | important | `already_evidenced` | Moved earlier by E5 | `[grounded]` |
| R14 | Go | important | `not_evidenced` | Named absence N6 | `[grounded]` |

### The edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` resume | pending your approval |
| E2 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | Cloud: AWS (EC2, S3, RDS, IAM) · Deployment pipeline: Jenkins · Containers: Docker, Kubernetes (two-month proof-of-concept) · Scripting: Bash, Python · Configuration management: Ansible · Monitoring: CloudWatch | `split` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E3 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | "Ran a two-month Kubernetes proof-of-concept last year; it did not go to production." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E4 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to the first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` resume | pending your approval |
| E5 | Skills | "Bash and Python scripting" | "Python, Bash" (within E2's Scripting group) | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` resume | pending your approval |

Why some rows look the way they do:
- **E3 keeps "not production" on purpose.** That qualifier is the honest part, and an interviewer for this role will ask about it in the first five minutes.
- **E2 says "Deployment pipeline", not "CI/CD".** Your sentence says *deploy* pipeline. I'll switch the label if C3 confirms it also builds and tests code.

### Gap handling

**Recall prompts** (the questions for these are at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes on AWS EKS, Helm | important | A two-month proof-of-concept with no details on platform, tooling or scope | It's your only link to the posting's core stack, and right now it's one line with no detail | You ran the trial on EKS rather than minikube or kind; you packaged apps with Helm charts; you migrated a real service into it, even if only in a test environment; you wrote the findings up | The proof-of-concept repo, a design doc, the write-up of why it stopped | `[grounded]` what the resume says; `[inferred]` an interviewer will dig into this first |
| C2 | Terraform (infrastructure as code) | important | Ansible for config management; nothing on provisioning | Terraform is in the posting's first line of tools | Terraform or CloudFormation for any AWS resource; Ansible playbooks that create EC2/RDS rather than just configure them; reviewing someone else's Terraform | A repo, a merged PR, a module | `[grounded]` what the resume says; `[generic]` IaC is usually screened literally |
| C3 | Platform ownership, developer experience, SRE practices, the CI half of CI/CD | must-have | You built a pipeline and maintain about 30 jobs; nothing on who uses them | This is the role statement itself | Other developers or teams deploy through your pipeline; the jobs run builds and tests, not just deploys; you're on call for it; you've cut deploy time or failure rate | Pipeline config, a usage count, an incident write-up, a runbook | `[grounded]` what the resume says; `[inferred]` this is the closest thing you have to the role's core |

**Named absences** (nothing in your material to draw on):
- **N1 ArgoCD/GitOps.** No evidence. To close it, deploy one app through ArgoCD from a Git repo in a home lab, on top of your Kubernetes work. This builds on C1 and is the cheapest of these to close.
- **N2 Istio/service mesh.** No evidence. Closing it takes running Kubernetes for real, so it isn't worth chasing until C1 is solid.
- **N3 Prometheus/Grafana.** No evidence. CloudWatch stays listed under its own name. To close it, instrument one service with Prometheus and build a Grafana dashboard. That's a weekend-sized project.
- **N4 Vault.** No evidence. To close it, use Vault for secrets in the same lab project as N1.
- **N5 GitLab CI.** No evidence. Your Jenkins work is the transferable skill. To close it, rebuild one of your pipelines in GitLab CI on a personal project.
- **N6 Go.** No evidence. Python covers the scripting side. Go is a longer path and not worth closing just for this application.

### Not written, and why
- **"Platform Engineer" as a title.** You've held "DevOps Engineer". Changing the title is an upgrade, not a clarification.
- **"Kubernetes in production", "deployed on EKS", or "Kubernetes" with no qualifier.** You said it "never went to production".
- **"Observability".** You wrote "CloudWatch for monitoring". Using the posting's word would claim a broader practice.
- **"CI/CD pipeline".** You wrote "deploy pipeline". This waits on C3.
- **"Infrastructure as code" for Ansible.** That's a change in the kind of work, and Terraform is what this posting means by it.
- **"Owned platform reliability" or "improved developer experience".** Nothing you wrote says this. It waits on C3.
- **A keyword block of tools you haven't used, visible or hidden.** Every line has to be one you can defend. Hidden text can also be detected by the same software that parses your resume.

### Parse-safety check
I can only see your description, not the PDF, so these are risks to check rather than confirmed findings:

| Check | What I can see | Risk |
|---|---|---|
| Multi-column layout | Two columns | Parsers read across the page, so your skills column can get mixed into your job history and dates can separate from roles |
| Icons for skills | An icon per skill | **If a skill appears only as an icon or logo, with no text, it doesn't exist to a parser.** This could be your actual keyword problem: AWS, Docker or Jenkins may never be read |
| Contact details in the header | In the header | Some parsers treat headers as page decoration and throw them away, so you can end up with no contact details |
| Hidden text | Couldn't check | Couldn't run this without the file |

A quick self-test: open the PDF, select all, and paste into a plain text editor. That's roughly what a parser gets. Check whether each skill name appears as words and whether the sections come out in order. A `.docx` or a PDF with a real text layer is the safe pair.

### Upgrade menu
- **Your actual resume text or file.** I could quote your real bullets instead of your summary of them, and run the parse checks properly.
- **Proof-of-concept artifacts (repo, notes).** These could turn C1 into specific, grounded Kubernetes lines.
- **Pipeline details (config, usage).** These could turn C3 into the CI/CD and platform-ownership lines this role is mostly about.

### Questions
C1: Was the Kubernetes proof-of-concept on EKS, did it use Helm, and what did it actually run?
C2: Have you written any Terraform or CloudFormation, or used Ansible to create AWS resources rather than just configure them?
C3: Who deploys through your Jenkins pipeline, and do those ~30 jobs build and test code or only deploy it?
For each one you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.