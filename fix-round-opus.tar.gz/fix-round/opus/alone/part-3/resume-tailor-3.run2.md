I need to read the reference files.
Nadia, I used the dossier excerpt as it stands. `role_profile` covers the JD. I took the fit judgements from `evidence_map` as they were, and copied both `rejected_inferences` unchanged into the "not written" list. E1 is the underwriter's draft edit, checked again against what you wrote. `conditional_go` is a decision about whether to apply, so it doesn't change any of the edits below.

**One assumption:** I didn't have your CV file, so the "Current line" and "Traces to" columns quote the sentences you typed in this message. If your CV says something different, the CV wins and the row gets rebuilt.

## Edit ledger: `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." *(as its own bullet, third under this role)* | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` resume, via dossier `resume_edits_pending_approval` E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet under this role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` resume | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to the second bullet, directly below E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` resume | pending your approval |
| E4 | Summary | *(no current line)* | "7 years as solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` resume | pending your approval |

Notes on the rows:
- **E1:** in what you typed, the playbook is already its own sentence. If your actual CV buries it inside another bullet, E1 pulls it out. If it's already a separate bullet, E1 changes nothing and you can reject it. "The whole team uses" stays as written. It does not become "company-wide".
- **E2 and E3** only change order. They put the API work and the product-facing work first, where a reader who stops early will still see them. "Client", "our REST APIs" and "30+" stay with the nouns they describe.
- **E4** keeps three separate sentences. Joined into one, the feedback sessions would read as part of the integration work, and neither of your sentences says that. "Collecting client feedback for product" does not become "shaping the roadmap".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | not_evidenced | The dossier rates this adjacent (a transferability gap, medium confidence): roadmap ownership and prioritisation authority aren't shown. E3 and E4 make the nearby work visible but don't meet the requirement. Recall prompt C1 | `[grounded]` dossier evidence_map R1 |
| R2 | Shipped API or platform products | important | not_evidenced | The dossier rates this adjacent (medium confidence). E2 shows you implemented APIs for clients, which is different from shipping one. Recall prompt C2 | `[grounded]` dossier evidence_map R2 |
| R3 | Technical fluency | important | already_evidenced | "Comfortable in Postman, SQL, OpenAPI specs." can be read as written. E2 strengthens it through position | `[grounded]` resume |
| R4 | Stakeholder management | important | surfaced_by_edit | E3 and E4 show that you worked between clients and product. The JD's phrase isn't used for your history | `[grounded]` resume |
| R5 | Discovery with integration partners | important | not_evidenced | E3 shows you collected feedback, which is different work from discovery. Recall prompt C1 | `[grounded]` resume |
| R6 | Write specs and drive delivery with engineering squads | important | not_evidenced | Nothing in what you wrote shows spec authorship or delivery work with engineers. Recall prompt C2 | `[grounded]` resume |
| R7 | Define adoption metrics | important | not_evidenced | Your material has no metrics, apart from the count of integrations. Recall prompt C3 | `[grounded]` resume |

## Gap handling

**Recall prompts.** The matching questions are in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM, roadmap ownership, partner discovery | must-have | You ran quarterly sessions collecting client feedback for product. It doesn't show whether you ranked inputs, made a case for them, or influenced what product built | This is the only requirement the JD marks as a must-have, and it's the first gap a reader without a PM title in front of them will check | Ranking client requests before they reached product; writing the case for a feature that then got built; running problem interviews with clients rather than collecting requests | Session summaries, a prioritised request list, a feature that traces back to your input | `[grounded]` what the resume says and doesn't say; `[generic]` how screeners treat a missing must-have |
| C2 | Shipped API products; specs and delivery | important | You led 30+ integrations of your company's APIs and are comfortable with OpenAPI specs. It doesn't show that you wrote a spec or worked on something engineering shipped | This is the core of the role (two engineering squads, partner-facing API platform) | Writing or reviewing an OpenAPI spec for a new endpoint; filing a requirement that engineering built; joining sprint reviews for an integration-driven feature | A spec, a ticket you wrote, release notes that name your requirement | `[grounded]` resume; `[generic]` how central delivery is to platform PM roles |
| C3 | Define adoption metrics | important | "30+" counts integrations. Nothing shows what happened after go-live | One of the four responsibilities the JD names | Time to go-live per integration; API call volume after launch; how many clients reached active use | A dashboard, a quarterly report, a tracking sheet | `[grounded]` resume; `[generic]` what adoption metrics usually cover |

**Named absence: the PM title.** You've never held a PM title, and no honest resume edit can make one appear. Answers to C1–C3 can close part of the gap by showing PM-shaped work done under your real title. The rest gets covered in the cover letter and the interview, not by renaming your role.

## Not written, and why

- "Built an internal request-triage tool": the dossier records this as a memory lead you couldn't confirm owning. Rejected earlier, so it stays out.
- "Has been the customer of a partner API platform": rejected earlier, because you worked on the vendor side.
- Any PM title, or "product management experience": you've never held the title, and R1 is the must-have.
- "Owned/drove the product roadmap": you ran sessions collecting feedback *for* product. The dossier notes that roadmap ownership isn't shown.
- "Shipped/launched API products": leading integrations of your company's APIs is implementing them for clients. Shipping is a different kind of work.
- "Partner integrations" or "integration partners": your word is "client". "Partner" is the posting's word, and using it would move you to the other side of the relationship.
- "Ran discovery": your sentence says "collecting client feedback". Discovery is the JD's word for a different activity.
- "Stakeholder management", "drove delivery", "defined adoption metrics" as lines about your past: none of these appears in your material.
- "Expert in / designed OpenAPI specs": you wrote "comfortable in". That qualifier is the honest part, so it stays.
- "Playbook adopted company-wide": you wrote "the whole team uses".

## Parse-safety check

Your CV arrived as typed prose, not a file. That means I couldn't check columns, tables, text boxes, images, headers/footers, section headings or file type. I also couldn't see date ranges for the 7 years, so I couldn't check how they're formatted. The slash in "solutions engineer / implementation lead" is plain text and isn't a parse risk.

## Upgrade menu

- **Your actual CV file (.docx or a PDF with selectable text):** I could run the full parse check and quote your real lines, so every "Traces to" cell matches the document you'll send.
- **The full dossier:** the excerpt only covers R1 and R2, so the other `evidence_map` rows might settle R3–R7 without fresh judgements.
- **The integration playbook (redacted is fine):** it could support a more specific E1 line, using what the playbook actually covers in your words.
- **Any spec, ticket, or roadmap-input summary you produced:** this could turn C1 or C2 into grounded rows.

## Questions

C1: Did any input from your quarterly sessions get built because you ranked it, argued for it, or decided it went to product? If so, what was it and what exactly was your part?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Did you ever write or review a spec (OpenAPI or otherwise) for something your engineering team then shipped?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Across the 30+ integrations, did you track any numbers after go-live, such as time to launch, call volume or active use?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Approve or reject by row number (for example, "Approved: E2, E3, E4. Rejected: E1"). I'll produce the tailored CV from the approved rows only.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.