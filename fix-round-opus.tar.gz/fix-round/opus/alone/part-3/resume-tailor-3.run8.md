I've read the skill's rules and your dossier. Here is the tailoring pass.

I've used your dossier as it stands: same role, and your CV matches the one it assessed. Its two rejected inferences are carried over as-is. The one edit it already drafted (E1) is row E1 below, checked again. I treated your CV as the five sentences in your message and quoted them exactly. One assumption: your CV doesn't have a summary or skills section yet, so rows E4 and E5 would add them.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (inside the role description) | "Wrote the internal integration playbook the whole team uses." as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second bullet, above the playbook)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Technical skills *(new heading)* | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." under a "Technical skills" heading | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary *(new)* | *(no current line)* | "7 years as solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |

What each row is careful about:
- **E1** keeps "internal" and "the whole team". The scope stays your team, not the company.
- **E2** keeps "30+" attached to integrations, and keeps "our REST APIs", which shows you were on the vendor side.
- **E3** keeps "for product". You fed input into the roadmap. You didn't own it.
- **E4** keeps "Comfortable in". Turning that into a bare skills list would quietly raise the level you're claiming.
- **E5** doesn't add "product-minded" or "platform", because none of your sentences says either.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Adjacent per dossier (transferability gap, medium confidence): integration leadership is shown, roadmap ownership isn't. Recovery: G1 and G4 | `[grounded]` dossier evidence_map R1 |
| R2 | Shipped API or platform products | important | `not_evidenced` | Adjacent per dossier (medium confidence): you integrated APIs for clients, which isn't the same as shipping them. Closest evidence is in E2. Recovery: G2 | `[grounded]` dossier evidence_map R2 |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4, plus "REST APIs" in E2 | `[grounded]` CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 (client integrations end to end), E3 (client feedback sessions) | `[grounded]` CV |
| R5 | Partner discovery (responsibility) | important | `surfaced_by_edit` | Only partly: E3 shows you collected client feedback. That is input to discovery, not discovery you owned | `[grounded]` CV |
| R6 | Write specs, drive delivery with two squads | important | `not_evidenced` | The playbook (E1) is a document but not a spec. Working with engineering squads isn't mentioned. Recovery: G4 | `[grounded]` CV |
| R7 | Define adoption metrics | important | `not_evidenced` | Nothing in the CV. Recovery: G3 | `[grounded]` CV |

## Gap handling

**Recall prompts.** These are gaps where you may have experience your CV doesn't mention. The questions are at the end.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Roadmap ownership / 3+ yrs PM | must-have | You ran input sessions "for product". It doesn't say whether you had any say in priorities | This is the main thing standing between "adjacent" and a fit on the one must-have | Ranking client requests before they reached product; owning a backlog for integration tooling; deciding what the playbook covered and when | A prioritised request list, a roadmap-input deck, an email showing your ranking was adopted | `[grounded]` CV; `[generic]` PM screeners usually look for decision authority, not just input |
| G2 | Shipped API/platform products | important | Integrations of an existing API | The JD asks for products you shipped, not integrations of someone else's | An endpoint, field or versioning change you specified that shipped; OpenAPI spec edits you authored; SDK or sandbox improvements | A changelog entry, a spec diff, a release note naming the change | `[grounded]` CV; `[generic]` "shipped" is usually probed in the first interview |
| G3 | Adoption metrics | important | Nothing | Defining these metrics is a stated part of the job | Tracking time-to-integrate or go-live rates across the 30+ integrations; error-rate or API-usage reporting for clients | A dashboard, a SQL query, a quarterly report | `[grounded]` CV; `[generic]` platform PM roles commonly test this |

**Named absences:**
- **G4: no PM title, and no delivery with engineering squads on record.** If G1 turns something up, it strengthens the adjacent case, but it can't create a title. There are three honest ways to close this:
  1. Let the cover letter make the transferability case openly.
  2. Find a sprint, release or project where you directed engineering work. That would be a G1-style answer and would get its own row.
  3. Aim at roles that ask for "integration" or "solutions" experience and lead into platform PM.

  For this posting, the title gap stays visible whatever you do, and the CV shouldn't hide it.

## Not written, and why

- **"Built an internal request-triage tool."** Rejected earlier (dossier): it came from my memory, not your CV, and you couldn't confirm you owned it.
- **"Has been the customer of a partner API platform."** Rejected earlier (dossier): you worked vendor-side.
- **"3+ years of product management experience" or a "Technical PM" title.** You've never held the title. That gap is named in G4 rather than covered over.
- **"Owned the roadmap for…"** You ran input sessions *for* product. Ownership would be a bigger claim.
- **"Led partner discovery."** "Discovery" and "partner" are the posting's words. Yours are "collecting client feedback". Swapping them would make you the decision-maker.
- **"Shipped API products."** You integrated them. That's a different kind of work, and G2 asks whether you have the real version.
- **"Authored integration specs."** The playbook is a process document. Calling it a spec changes what kind of document it was.
- **"Drove delivery with engineering squads" and "Defined adoption metrics."** Nothing you wrote supports either.

## Parse-safety check

Your CV came as pasted text, so I couldn't check layout, columns, tables, headers and footers, file type, or hidden text. What I could check: the new headings "Summary", "Experience" and "Technical skills" are standard labels that parsers recognise. If you share the actual file (.docx or a PDF with selectable text), I can run the rest.

## Upgrade menu

- **The playbook itself, redacted:** would make E1 checkable and could strengthen R6.
- **Any roadmap-input output, such as a deck or ranked list:** the most direct way to move R1.
- **Your CV file:** lets me finish the parse-safety check.

## Questions

G1 — When you passed client feedback to product, did you decide or rank which requests went forward, and did product act on your ranking?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Did any change to the API itself (an endpoint, a spec edit, an SDK or sandbox improvement) ship because you specified it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — Across the 30+ integrations, did you track or report anything like time-to-integrate, go-live rates or API usage?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.