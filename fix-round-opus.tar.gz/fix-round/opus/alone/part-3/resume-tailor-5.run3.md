I need to read the key references.
I won't add the hidden white-text instruction or the 1pt keyword block. Here's why:

- **It's deceiving the employer.** The screening software is working for them, so hidden instructions to it are aimed at them. Saying "I didn't lie to a person" doesn't hold up if an interviewer asks about it.
- **It can be found.** The software that reads your PDF sees hidden text the same as visible text. One hiring platform told a newspaper how often it finds white text (cite C19), and a staffing firm says how much its AI scanning catches (cite C18). One candidate said a recruiter turned him down after finding his hidden prompt (cite C35).
- **You can't control what happens next.** If it's found, the employer decides how far that goes, and you'd be defending a line you didn't write. That's my judgement, not a measured rate.

You also don't need it. Your real background matches this JD closely: paid search, lifecycle email, webinars, HubSpot and a budget over $500k are all in what you wrote. What follows puts those in front of any reader, human or machine, with each keyword used only where your own words support it. It also names the two things the JD wants that you haven't shown yet.

## Edit ledger

You gave me prose, not a resume, so "Current line" is your own sentence, and each proposed line is a resume bullet built from it.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Header | "Marketing Manager, 6 years B2B SaaS." | "Marketing Manager, B2B SaaS (6 years)" | `retitle` | "Marketing Manager, 6 years B2B SaaS." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year" | `reframe` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your message | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme in HubSpot from scratch: 12 automated flows" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your message | pending your approval |
| E4 | Skills | *(no current line)* | "HubSpot: daily use for 4 years; pull my own numbers in HubSpot reporting" | `merge` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your message | pending your approval |
| E5 | Experience | "Ran a monthly webinar series, average 300 registrants." | "Ran a monthly webinar series, averaging 300 registrants" | `reframe` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your message | pending your approval |
| E6 | Experience | *(order of bullets)* | *(unchanged wording, ordered E2 → E3 → E5)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your message | pending your approval |
| E7 | Summary | *(no current line)* | "B2B SaaS marketing manager, 6 years. Ran paid search and paid social on a budget of about $600k a year. Built a 12-flow lifecycle email programme in HubSpot from scratch, and ran a monthly webinar series averaging 300 registrants." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your message | pending your approval |

Notes on these rows:
- **E2 keeps "about."** You said about $600k, and the JD only needs more than $500k, so the exact figure gains you nothing. The budget also stays attached to paid search and social, which is where you put it.
- **E4 is the honest neighbour of the SQL requirement.** It doesn't claim SQL.
- **E6** puts paid search and the budget first because that's the order the JD lists its duties. A reader who stops early meets the two things they check first.
- **No row says "demand generation" about your work.** That's the JD's word. You never said it, and adding it would put their framing on your history. Question C1 is how it could be earned.

## Coverage map

Nothing is `already_evidenced` yet, because there's no resume yet. Everything you have gets onto the page through a ledger row.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Paid search | important | `surfaced_by_edit` | E2, led by E6 | `[grounded]` your message |
| R2 | Lifecycle email | important | `surfaced_by_edit` | E3, with the 12 flows named | `[grounded]` your message |
| R3 | Webinars | important | `surfaced_by_edit` | E5 | `[grounded]` your message |
| R4 | Content distribution | important | `not_evidenced` | Nothing in your message covers it; recall prompt G1 | `[grounded]` your message's silence |
| R5 | 5+ years B2B demand gen | must-have | `not_evidenced` | Six years of B2B SaaS marketing is shown (E1), and HubSpot for 4 (E4), but not how many years you ran these channels; recall prompt G2 | `[grounded]` your message |
| R6 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E3, E4 | `[grounded]` your message |
| R7 | SQL-literate | must-have | `not_evidenced` | Named absence G3; E4 is the nearest true line | `[grounded]` "I'm not strong in SQL — I ask our analyst." |
| R8 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E2, E7 | `[grounded]` your message |

## Gap handling

**Recall prompts** (the questions are in the closing block):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Content distribution | important | Paid social and webinars, but nothing about getting content in front of an audience | It's one of the four duties the JD names, and the only one with nothing behind it | Promoting gated assets such as ebooks or reports through paid social; reusing webinar recordings as on-demand content; a newsletter or a nurture flow that sends content; syndication or partner placements | A campaign brief, a HubSpot asset report, a distribution calendar | `[grounded]` what your message shows; `[generic]` that the posting lists it as a core duty |
| G2 | 5+ years B2B demand gen | must-have | Six years as a B2B SaaS Marketing Manager; HubSpot for 4 of them; how long you ran paid search and webinars isn't stated | Your title and years clear the bar, but whether those years were spent on demand-gen work is the obvious screening question | Running paid search from year one or two; owning lead or MQL targets; a team or role called growth or demand gen | Old job descriptions, performance reviews, early campaign reports | `[grounded]` your message; `[generic]` that years in the function, not just the title, is what this kind of requirement checks |

**Named absence: SQL (G3).** You've said you're not strong in SQL and ask your analyst, and the JD lists "SQL-literate" as a requirement. Closing the gap would take a few weeks of practice on the basics (SELECT, WHERE, JOIN, GROUP BY), then pulling one real number yourself from your company's data so you have something true to say. Until then, E4 is the honest line, and in interview you can say "I self-serve in HubSpot reporting and I'm building SQL." Since this is one requirement among several you meet, it's a gap to own rather than a reason not to apply.

## Not written, and why

- **Hidden white-text instructions to the AI screener.** Refused for the reasons at the top.
- **Hidden 1pt keyword block.** Refused for the same reasons. The keywords your evidence supports are already in visible rows.
- **"SQL-literate", "SQL", or "data-driven analyst."** You told me the opposite. An interviewer will check this in one question.
- **"Demand generation leader" or "6 years of demand gen."** This is the JD's term, and your message doesn't establish how long you ran these channels. Pending G2.
- **"Owned the full funnel," "drove pipeline," or "content distribution."** You haven't described funnel ownership, pipeline numbers or distribution work.
- **"Managed a $600k budget."** Your word was "about." The qualifier stays.
- **"Senior Marketing Manager."** That's the target title, not yours.

## Parse-safety check

You pasted prose, so I couldn't check columns, tables, headers and footers, images, or whether your existing file already has hidden text in it. That last one comes from templates more often than people expect. If you send the actual file, I'll run all of those checks. Keep your section headings conventional (Summary, Experience, Skills) and save as `.docx` or a PDF with a text layer.

## Upgrade menu

- **Your actual resume file:** this gets you a full parse check, real "current lines" for each row, and a check for hidden text you may not know about.
- **Results from the webinars or flows** (opportunities, MQLs, pipeline, conversion rates): turns E3 and E5 from activity into outcomes, which is what a Senior role is judged on.
- **An old job description or performance review:** could settle G2 in a single document.

## Questions

G2: Across your 6 years, roughly how many have you spent running paid search, webinars and lifecycle email specifically, and did any title or team name include "demand gen" or "growth"?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1: Have you done anything to get content in front of an audience beyond the webinars themselves, such as promoting gated assets, reusing recordings, or a content newsletter?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

E3/E5: Do you have any outcome numbers for the webinar series or the email flows, such as opportunities, MQLs, pipeline or conversion?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.