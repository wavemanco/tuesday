I've read the tailoring rules and built the edit list. Here it is.

## First, the keyword theory

**Missing keywords probably aren't getting you auto-rejected.** The only data I have is a small one. A résumé-builder company interviewed 25 US recruiters and found "AI/content auto-rejection configured: 8% of recruiters", which was "We only saw 2 of 25 using it". In those interviews, "When automated filters are used, they're almost always knockout questions": yes/no questions on the application form about things like work authorization, licences or location. Keyword match scores do matter, but for ranking. Teams use them "to prioritize who gets reviewed first", and "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." That's 25 recruiters, so it shows patterns, not rates.

**For this role the harder problem is the gap itself.** Look at the coverage map below. Terraform, ArgoCD, Istio, Prometheus, Grafana, Vault, EKS, Helm, GitLab and Go don't appear anywhere in what you've told me. Kubernetes appears only as a two-month proof-of-concept. I can't add any of them, because a recruiter would test each one in the first technical screen. I can do three things:
- Make the real overlap easy to find: Python, AWS, the pipeline you built, the Kubernetes PoC.
- Fix the PDF layout, which may be losing your content before anyone reads it.
- Ask whether you've done things you didn't mention.

**One assumption:** I only have your summary, not the resume text. So the "current line" in each row is your own sentence, quoted exactly.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to the first bullet under your current role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your summary | pending your approval |
| E2 | Experience | *(PoC not on the resume as far as I can tell)* | "Ran a Kubernetes proof-of-concept for two months — never went to production" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your summary | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "Python and Bash scripting, AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Ansible for config management, CloudWatch for monitoring" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your summary | pending your approval |
| E4 | Skills | *(skills shown as icons)* | Skills written out as plain text, exactly as in E3, with no icon standing in for a name | `surface` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your summary | pending your approval |
| E5 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your summary | pending your approval |

Notes on the rows:
- **E2 keeps "proof-of-concept", "two months" and "never went to production".** Without them the line would read as Kubernetes experience, which you'd have to walk back in an interview. I dropped "last year" because a resume needs a real year, and I won't guess it. Add the year yourself.
- **E5 keeps your title as DevOps Engineer.** Changing it to "Platform Engineer" would be a promotion, not an equivalent title.
- **Ordering advice (also pending your approval):** put E1 and E2 under your most recent role, above everything else. Some readers stop early, and that's where your closest overlap with this JD is.

## Coverage map

The JD is a flat list, so the priorities are my reading of it.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Kubernetes (any hands-on) | must-have | `surfaced_by_edit` | E2: two-month PoC, not production | `[grounded]` your PoC sentence; `[inferred]` priority |
| M2 | Kubernetes in production | must-have | `not_evidenced` | Recall prompt R1 | `[grounded]` "never went to production" |
| M3 | AWS | important | `already_evidenced` | Skills: EC2, S3, RDS, IAM | `[grounded]` |
| M4 | AWS EKS | important | `not_evidenced` | Recall prompt R1 (did the PoC run on EKS) | `[grounded]` EKS not mentioned |
| M5 | CI/CD pipelines | important | `already_evidenced` | E1: the Jenkins deploy pipeline | `[grounded]` |
| M6 | GitLab CI | important | `not_evidenced` | Named absence | `[grounded]` only Jenkins mentioned |
| M7 | Python | important | `surfaced_by_edit` | E3: scripting, moved to the front | `[grounded]` |
| M8 | Go | important | `not_evidenced` | Recall prompt R3 | `[grounded]` not mentioned |
| M9 | Terraform / IaC | important | `not_evidenced` | Recall prompt R3; Ansible is config management, a different job | `[grounded]` |
| M10 | Monitoring | important | `already_evidenced` | Skills: CloudWatch | `[grounded]` |
| M11 | Prometheus, Grafana, observability | important | `not_evidenced` | Named absence | `[grounded]` |
| M12 | Helm | important | `not_evidenced` | Recall prompt R1 | `[grounded]` |
| M13 | ArgoCD / GitOps | important | `not_evidenced` | Named absence | `[grounded]` |
| M14 | Istio / service mesh | important | `not_evidenced` | Named absence | `[grounded]` |
| M15 | Vault | important | `not_evidenced` | Named absence | `[grounded]` |
| M16 | SRE practices, owning platform reliability and developer experience | important | `not_evidenced` | Named absence | `[grounded]`; `[inferred]` that this means on-call and SLOs |

## Gaps

**Recall prompts.** These are gaps you might be able to close with things you haven't mentioned. The questions are at the end.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Kubernetes, EKS, Helm | must-have | A two-month PoC that never reached production. It doesn't say what it ran on or what you used. | Kubernetes is the first thing in this JD | The PoC running on EKS; writing Helm charts or manifests; deploying a real service into the PoC cluster | The PoC repo, a design doc, a write-up of results | `[grounded]` resume; `[inferred]` Kubernetes is central here because it's listed first |
| R2 | CI (build/test), not only deploy | important | "deploy pipeline", plus about 30 Jenkins jobs whose purpose isn't stated | Decides whether "CI/CD" can honestly go next to Jenkins | Jobs that run tests or builds on every commit; pipeline-as-code (Jenkinsfiles) | Jenkinsfiles, a job list | `[grounded]` |
| R3 | Terraform, Go | important | Neither is mentioned; Ansible and Python/Bash are | Both are named tools here | Any Terraform you wrote or edited, even small amounts; any Go tooling or contributions | Repos, PRs | `[grounded]` |

**Named absences.** Nothing in your history touches these.
- **Istio / service mesh, ArgoCD / GitOps, Vault, Prometheus / Grafana.** You haven't used them. To close the gap you could run a production-like project on your own: EKS with ArgoCD, Helm and Prometheus/Grafana. On the resume it goes under "Projects", labelled as personal. That's a few weeks of work, and it stays a personal project, not employment history.
- **SRE practices and owning platform reliability.** Closing this takes on-call, SLO or incident work in a real job. If your current job can't give you that, a realistic route is DevOps roles that run Kubernetes in production, with Platform Engineer as the step after. Whether this particular role is worth applying for is a job-underwriter question.

## Not written, and why

- **"Kubernetes experience" or Kubernetes in the skills list without a qualifier.** You ran a PoC, not production. Leaving out the qualifier makes the claim bigger than what happened.
- **Terraform, Helm, ArgoCD, Istio, Prometheus, Grafana, Vault, EKS, GitLab or Go in the skills list.** Listing a tool claims you can use it, and none of these is backed by your history.
- **"Familiar with" or "exposure to" any of these.** These hedges hint at a requirement without meeting it.
- **"CI/CD pipeline" for your Jenkins work**, until R2 is answered. You wrote "deploy pipeline".
- **"Observability" for CloudWatch.** You wrote "monitoring", and the JD uses observability to mean the Prometheus/Grafana stack.
- **"Infrastructure as code" for Ansible.** You wrote "config management".
- **"Platform Engineer" as your title, or "owned developer experience" for maintaining about 30 Jenkins jobs.** The first is a promotion; the second changes what kind of work it was.

## Layout check (parsing risks)

I couldn't open the file, so these are risks based on your description.

| Check | What you described | What breaks |
|---|---|---|
| Two columns | Two-column Canva PDF | Parsers read straight across, so text from both columns can mix together and dates can separate from their roles |
| Skill icons | "icons for each skill" | Icons can't be read as text. If a skill name exists only as an icon, it's missing (E4 fixes this) |
| Contact details in header | Contact details in the page header | Headers are often thrown away, so a parser can lose how to reach you |
| File type and hidden text | Canva PDF | Not checked. I can't confirm a real text layer or rule out leftover template text without the file |

## What would help next

- **The actual resume** (the PDF or its text). I could quote your real lines, check the text layer and hidden text, and replace my assumed current lines.
- **The PoC repo or write-up.** It might support Helm or EKS lines.
- **Your Jenkinsfiles or job list.** They might support "CI/CD".

## Questions

R1: In the Kubernetes PoC, what did you set up yourself: was it on EKS, did you use Helm, and did you deploy a real service to it?
R2: Do any of the ~30 Jenkins jobs run builds or tests on commits, or are they all deployments?
R3: Have you written or edited any Terraform or Go, at work or anywhere else?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.