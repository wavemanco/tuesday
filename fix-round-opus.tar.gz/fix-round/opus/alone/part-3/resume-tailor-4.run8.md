Before the edits, one correction to the premise. Your rejections probably have less to do with keyword matching than with the posting asking for experience your resume doesn't yet show.

**What screening software actually does.** The best source I have is small: a résumé-builder company (Enhancv) interviewed 25 US recruiters. Only 2 of the 25 had software set to reject resumes on content. The automatic rejections they described were "almost always knockout questions" on the application form, such as work authorisation or location. Match scores were mostly used "to prioritize who gets reviewed first", and 56% either ignored that feature or didn't have it. The sample is tiny and the source sells resumes, so take it as a rough picture. Still, it suggests your resume is more often ranked low than thrown out by a machine.

Looking at the coverage map below, about 13 of the 16 tools and practices this posting lists are things your material doesn't support. Your Kubernetes proof-of-concept and Python scripting cover two more only partly. Better wording can make what you have done easier to find, but it can't make up that difference. Whether this role is worth applying to is a separate question for the job-underwriter skill. Here is the full tailoring work.

**How I built this:** I worked from your description, not the PDF, so each "Current line" is your own sentence from your message. The posting doesn't rank its requirements, so I treated Kubernetes, AWS EKS, CI/CD and platform reliability as must-haves because they come first or are what the role says you'll own. That ranking is my guess.

## Edit ledger: `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | "Ran a two-month Kubernetes proof-of-concept (not taken to production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged — moved to the first bullet of your current role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "Python and Bash scripting, AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Ansible (config management), CloudWatch (monitoring)" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |
| E4 | Skills | *(no current line)* | "Kubernetes (two-month proof-of-concept)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E5 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Work across AWS (EC2, S3, RDS, IAM), Docker, Ansible and CloudWatch, with Bash and Python scripting." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |

Notes on what these rows do and don't do:
- **E1 and E4 add the word "Kubernetes" truthfully.** It's the posting's first keyword, and it's only searchable if it appears in your text. Both rows keep the qualifier ("two-month", "not taken to production"). If an interviewer finds "Kubernetes" on a resume with no qualifier, the first follow-up question will undo it.
- **E3 keeps "scripting" next to Python.** The posting probably means Python as a programming language, and scripting is what you described.
- **E5 says "about 30", not "30+".** It also keeps "deploy pipeline" rather than "CI/CD platform".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E1, E4. Proof-of-concept only, not production; see C1 | `[grounded]` |
| R2 | AWS EKS | must-have | `not_evidenced` | You have AWS (EC2, S3, RDS, IAM), but not EKS; see C1 | `[grounded]` |
| R3 | CI/CD (GitLab) | must-have | `surfaced_by_edit` | E2, E5 cover a Jenkins deploy pipeline. GitLab itself isn't evidenced | `[grounded]` |
| R4 | Platform reliability / SRE practices | must-have | `not_evidenced` | Nothing about on-call, incidents or SLOs; see C2 | `[grounded]` |
| R5 | Python | important | `already_evidenced` | "Python scripting". E3 moves it first | `[grounded]` |
| R6 | Terraform | important | `not_evidenced` | Ansible is configuration management, not provisioning; see C3 | `[grounded]` |
| R7 | Prometheus / Grafana / observability | important | `not_evidenced` | You have CloudWatch monitoring only; see C1 and C2 | `[grounded]` |
| R8 | Helm | important | `not_evidenced` | Possibly part of the proof-of-concept; see C1 | `[grounded]` |
| R9 | ArgoCD / GitOps | important | `not_evidenced` | Named absence below | `[grounded]` |
| R10 | Istio / service mesh | important | `not_evidenced` | Named absence below | `[grounded]` |
| R11 | Vault | important | `not_evidenced` | See C3 | `[grounded]` |
| R12 | Go | preferred | `not_evidenced` | Named absence below | `[grounded]` |
| R13 | Developer experience | important | `not_evidenced` | The Jenkins pipeline serves developers, but you didn't describe it that way; see C2 | `[grounded]` |

The priority column is my assumption (`[inferred]` from the order of the list and the sentence about owning reliability).

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes, EKS, Helm, Prometheus/Grafana | must-have | A two-month proof-of-concept with no stack details | It's the closest thing you have to the posting's core, and right now it's one bare line | Was it on EKS or something else? Did you install anything with Helm charts? Did you scrape metrics or build any Grafana dashboards? | Design doc, repo, demo notes, Slack write-up | `[grounded]` what you said; `[generic]` platform roles usually lead with Kubernetes |
| C2 | SRE practices, reliability, developer experience | must-have | Monitoring with CloudWatch only | The role says you will "own platform reliability" | On-call rotation; incident response or postmortems; CloudWatch alarms you set up; making deploys faster or safer for developers | Runbook, postmortem, alarm config, before/after deploy times | `[grounded]` what you said; `[generic]` reliability roles screen for incident experience |
| C3 | Terraform, Vault | important | Ansible for configuration management | Infrastructure-as-code is central to platform roles | Any Terraform or CloudFormation, even small; how you handled secrets (AWS Secrets Manager, Parameter Store, Ansible Vault) | Repo, module, pull request | `[grounded]` what you said; `[generic]` IaC is standard for this kind of role |

**Gaps where your material has nothing to recall:**
- **ArgoCD / GitOps:** none of your experience covers this. To close it, run ArgoCD against a cluster in a personal project and write it up. A day or two of work gives you something real to point to.
- **Istio / service mesh:** none of your experience covers this, and it's hard to fake in an interview. To close it, you'd need hands-on time with a mesh. For this application, it's probably not worth closing; mesh experience is often taught on the job.
- **Go:** not covered. It's listed last, so treat it as a plus. Closing it would mean a small Go tool or contributions to one.
- **GitLab CI:** not covered. Jenkins is the same kind of work, but I won't call it GitLab. A short GitLab pipeline in a personal repo would close this cheaply.

## Not written, and why

- **"Kubernetes in production" or "production-grade Kubernetes":** you said it "never went to production."
- **"AWS EKS":** you listed EC2, S3, RDS and IAM, and EKS isn't among them.
- **"CI/CD (GitLab)" or "GitOps":** your pipeline is Jenkins. Swapping in the posting's tools would misstate what you used.
- **"Observability":** that's the posting's word. Yours is "CloudWatch for monitoring", and observability usually implies metrics, logs and tracing together.
- **"Infrastructure as code (Terraform)":** Ansible does configuration management. It doesn't provision infrastructure the way Terraform does.
- **"Platform Engineer" as a title, or "owned platform reliability":** your title is DevOps Engineer, and you didn't mention owning reliability.
- **A keyword block of the posting's tools you haven't used,** whether visible or hidden. If it's visible, every listed tool becomes an interview question. If it's hidden, it deceives the screener, and that kind of text can be detected.

## Parse-safety check

| Check | Finding | What it costs |
|---|---|---|
| Two-column layout | Risk | Text extractors read left to right across both columns. Your skills and experience can interleave, and dates can come loose from their roles |
| Skill icons | Risk, and possibly the real keyword problem | If any skill exists only as an icon, it won't appear in the extracted text, so a search for "Docker" finds nothing. Text written next to an icon is fine; the icon on its own is invisible |
| Contact details in the header | Risk | Some parsers discard headers, so your name, email and phone may never reach the system |
| Canva PDF text layer | Couldn't check | Some exports turn text into shapes. If you can't select and copy the text in the PDF, no parser can read it either |
| Hidden text | Couldn't check | I'd need the file |

These are reading risks, not design advice. A `.docx` or a PDF with a real text layer is the safest format to send.

## Upgrade menu

- **The PDF itself:** I can check the extracted text for word salad, icons that vanish, a missing header or hidden text, and quote your real resume lines instead of your summary.
- **Proof-of-concept artifacts** (repo, doc, notes): these could turn C1 into specific `[grounded]` rows naming the Kubernetes tools you actually used.
- **Any infrastructure-as-code or pipeline repos:** these could close parts of R6 and R11.

## Questions

C1: In the Kubernetes proof-of-concept, what did you actually run it on (EKS, kind or minikube, something else), and did you use Helm, Prometheus or Grafana at all?
C2: Have you been on call or handled production incidents, and did you set up CloudWatch alarms or write postmortems?
C3: Have you written any Terraform or CloudFormation, and how did your team handle secrets?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

All five rows above are pending. Tell me which ones to approve or reject.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.