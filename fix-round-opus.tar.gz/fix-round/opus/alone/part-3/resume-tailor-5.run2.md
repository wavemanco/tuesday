I need to read the key references before building.
I won't add the hidden text. That covers both the white-text instruction and the 1pt keyword block. Here's why:

- **It deceives the employer.** The screener reads your resume on the employer's behalf, so hidden instructions to it are aimed at them.
- **It gets found.** Hidden text is visible to the software that parses the file. One platform publishes how often it finds white text (cite C19). A staffing firm reports hidden text in about 10% of the résumés it scans with AI (cite C18). One candidate told a newspaper that a recruiter found theirs and turned them down for it (cite C35).
- **You can't control what happens next.** If it's found, it's a line on your resume you didn't really write and can't defend.

Your friend isn't alone: in one vendor's survey, "41% admit to using prompt injections" (cite C17). But you don't need it. Your own words already name four of the JD's seven requirements (paid search, lifecycle email, webinars, a budget over $500k), and HubSpot is a fifth. The edits below make sure a reader, human or software, sees those words.

I've treated your pasted text as your current resume lines. Nothing below is applied until you approve it.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social on a budget of about $600k a year, and built a lifecycle email programme from scratch in HubSpot." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your text | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `reframe` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your text | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch in HubSpot: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your text | pending your approval |
| E4 | Skills | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "HubSpot: daily use for 4 years, including pulling my own numbers in HubSpot reporting" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your text | pending your approval |
| E5 | Experience | "Ran a monthly webinar series, average 300 registrants." | "Ran a monthly webinar series, averaging 300 registrants." | `reframe` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your text | pending your approval |
| E6 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." / "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." / "Ran a monthly webinar series, average 300 registrants." | *(unchanged; bullets ordered paid search, then lifecycle email, then webinars, matching the JD's order)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your text | pending your approval |
| E7 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | *(removed from the resume; the HubSpot reporting half is kept in E4)* | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your text | pending your approval |

Notes on the rows:
- **E1 and E2** keep "about". "$600k+" or "managed a $600k budget" would round up a figure you gave as an estimate.
- **E5** keeps "registrants". It does not become "attendees", which is a different and usually smaller number.
- **E7** only removes the SQL caveat from the resume. Removing it doesn't license any SQL claim. The gap stays open below.
- **Spelling:** "programme" is your spelling and I've kept it. If you'd rather use US spelling ("program") for a US employer, say so and I'll add it as its own row.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 puts "6 years in B2B SaaS" first, next to the demand-gen work. Your text doesn't say all 6 years were spent on this kind of work (see C3) | `[grounded]` your text |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E4 gives it its own Skills line. E1 and E3 also name it | `[grounded]` your text |
| R3 | SQL-literate | must-have | `not_evidenced` | Recall prompt C1 | `[grounded]` your text |
| R4 | Managed a budget over $500k | must-have | `already_evidenced` | "about $600k a year" already clears it. E2 makes it easier to read | `[grounded]` your text |
| R5 | Paid search | important | `already_evidenced` | E6 moves it to the first bullet | `[grounded]` your text |
| R6 | Lifecycle email | important | `already_evidenced` | E3 | `[grounded]` your text |
| R7 | Webinars | important | `already_evidenced` | E5 | `[grounded]` your text |
| R8 | Content distribution | important | `not_evidenced` | Recall prompt C2 | `[grounded]` your text |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | SQL-literate | must-have | You build your own HubSpot reports but say you're "not strong in SQL" and ask your analyst. That rules out any SQL claim as things stand | It's one of four must-haves, so a reader may check for it explicitly. If nothing turns up, the closing path is real but small: a few weeks writing your own queries against your marketing data, or a short course, before applying or before interviewing | Editing a query your analyst wrote; filtering an exported dataset yourself; running a saved query in a BI tool; writing even a simple SELECT/WHERE/GROUP BY | A query you wrote, a dashboard you built from one, a course certificate | `[grounded]` what your text says; `[generic]` how must-haves are screened |
| C2 | Content distribution | important | Paid social sits next to content work, but nothing says you distributed content | It's one of the four channels the role owns | Promoting webinars or reports through paid social; content syndication; gated-asset campaigns; newsletter distribution | Campaign names, the assets you promoted, reach or download numbers | `[grounded]` what your text says; `[generic]` what the role's scope implies |
| C3 | 5+ years B2B demand gen | must-have | 6 years B2B SaaS and 4 years in HubSpot. What your first 2 years covered is unstated | If those 2 years were in another area of marketing, you have about 4 years of this work against a requirement of 5+ | Paid campaigns, email, events or webinars, or lead generation in those first 2 years | Your earlier job titles and dates | `[grounded]` what your text says |

## Not written, and why

- **The hidden prompt-injection text and the 1pt keyword block.** You asked for both and I declined, for the reasons at the top.
- **"SQL-literate", "SQL", or "data-driven analyst".** You said you're not strong in SQL. An interviewer can test it in one question.
- **"Demand Generation Manager" as a title, or "Senior".** Your title is Marketing Manager. Changing it would be an upgrade, not an equivalent.
- **"6 years of demand generation".** Your text says 6 years in B2B SaaS, not 6 years in demand gen (see C3).
- **"Owned demand generation".** This is the JD's wording. Your own verb is "ran", and I've kept it.
- **"Content distribution".** Nothing in your text supports it yet (see C2).
- **"Managed $600k+".** Your figure was "about $600k".
- **"Marketo".** You didn't mention it.
- **"Webinar attendees".** You gave registrants.

## Parse-safety check

You pasted plain text, so I couldn't check the layout: columns, tables, text boxes, headers and footers, icons, or file type. Send the actual file and I'll run those checks. I'll also check that it has no hidden text you didn't put there, for example from a template. The section headings Summary, Experience and Skills are standard and parse reliably.

Whether the SQL gap makes this role worth applying for is a separate question, which job-underwriter covers.

## Upgrade menu

- **Your actual resume file:** lets me run the full parse-safety check and the hidden-text check.
- **Results for your programmes** (pipeline, MQLs, email conversion, webinar-sourced opportunities): would make E2, E3 and E5 stronger without adding any claim you can't back.
- **Answers to C1–C3:** each one could turn a `not_evidenced` gap into a real row.

## Questions

C1: Have you ever written or edited a SQL query yourself, even a simple one?
C2: Did your paid social or webinar work involve promoting content, such as reports, guides, recordings or syndication?
C3: What were you doing in the 2 years before your 4 years in HubSpot, and did it include paid campaigns, email or events?

For each, you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.