Sam, before the edits: keyword matching probably isn't the main reason you're being rejected. There are two bigger problems.

**How screening usually works.** The best evidence I have on this is one small study: a résumé-builder company (Enhancv) interviewed 25 US recruiters. Only two of them had set their software to auto-reject based on resume content. The rest said that "When automated filters are used, they're almost always knockout questions": "yes/no eligibility checks (work authorization, required license, location)". Those are answered on the application form, not the resume. Match scores "prioritize who gets reviewed first", but "Low score ≠ auto-reject". So keywords may affect how high you rank. They're unlikely to be what's rejecting you, though 25 recruiters is too small a sample to be sure.

**Your file may be hiding your content.** A two-column Canva PDF with skill icons and contact details in the header carries real risk of losing text when software reads it. The details are in the parse-safety check below. Fixing that is legitimate keyword work, because it makes sure the tools you really used get read.

**The skills gap.** The posting names 16 tools and practices. Your background supports AWS, Python, CI/CD through Jenkins, monitoring through CloudWatch, and Kubernetes only as a two-month proof-of-concept. No wording turns Ansible into Terraform or Jenkins into ArgoCD, and any line that tried would fall apart at the first technical interview question. What I can do is make your real experience easy to find, and set out each gap plainly.

**What I assumed:** I've treated the lines in your message as your resume's current lines. I couldn't see the PDF.

---

## Edit ledger — every row pending your approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to be the first bullet under your current role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | "Ran a two-month Kubernetes proof-of-concept last year; it did not go to production." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E3 | Skills | *(Kubernetes not in the skills list, as far as I can tell)* | "Kubernetes (proof-of-concept only)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E4 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Python and Bash scripting, CloudWatch for monitoring, Ansible for config management" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |
| E5 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a two-month Kubernetes proof-of-concept last year that did not go to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |

Notes on the rows:
- **E2 and E3 keep "not production" and "proof-of-concept only" on purpose.** Those qualifiers are what let you defend the Kubernetes line in an interview.
- **E5 is optional.** It only repeats your own sentences. Whether you want a not-in-production project in your summary is your call.
- **E4 moves Python up** because the posting asks for it. Nothing in the list changes except the order.

## Coverage map

The posting is an unranked list. I treated Kubernetes/EKS, Terraform, CI/CD, observability and reliability as must-haves, because the job title and the "You will own…" sentence depend on them. That's my reading, not the employer's.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E2 and E3. Proof-of-concept only, not production. Details are question C1 | `[grounded]` your message |
| R2 | AWS EKS | must-have | `not_evidenced` | Your AWS covers EC2, S3, RDS and IAM, not EKS. Question C1 asks whether the proof-of-concept ran on EKS | `[grounded]` your message |
| R3 | Terraform | must-have | `not_evidenced` | Ansible is configuration management, which is a different kind of work. Question C2 | `[grounded]` your message |
| R4 | CI/CD | must-have | `surfaced_by_edit` | E1 makes the Jenkins pipeline your first bullet | `[grounded]` your message |
| R5 | GitLab CI specifically | important | `not_evidenced` | Named absence, below | `[grounded]` your message |
| R6 | Observability / monitoring | must-have | `already_evidenced` | "CloudWatch for monitoring" is already in your skills, and E4 moves it earlier | `[grounded]` your message |
| R7 | Prometheus, Grafana | important | `not_evidenced` | Question C1 asks whether the proof-of-concept used them; otherwise a named absence | `[grounded]` your message |
| R8 | SRE practices, platform reliability | must-have | `not_evidenced` | Question C3 | `[grounded]` your message |
| R9 | ArgoCD, GitOps | important | `not_evidenced` | Question C1; otherwise a named absence | `[grounded]` your message |
| R10 | Helm | important | `not_evidenced` | Question C1 | `[grounded]` your message |
| R11 | Istio, service mesh | important | `not_evidenced` | Named absence, below | `[grounded]` your message |
| R12 | Vault | important | `not_evidenced` | Named absence. IAM is access control, not secrets management | `[grounded]` your message |
| R13 | Python | important | `already_evidenced` | "Python scripting" is in your skills; E4 moves it earlier | `[grounded]` your message |
| R14 | Go | preferred | `not_evidenced` | Named absence, below | `[grounded]` your message |
| R15 | Developer experience | important | `not_evidenced` | Your deploy pipeline is related work, but nothing you wrote says who used it or how | `[grounded]` your message |

## Gaps you might be able to close (each has a question at the end)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes depth (EKS, Helm, ArgoCD, Prometheus/Grafana) | must-have | That a two-month proof-of-concept happened, and nothing about what it involved | Most of the posting's tools live in the Kubernetes ecosystem, so this one project could cover several of them | Running it on EKS; writing or installing Helm charts; trying ArgoCD; installing Prometheus or Grafana on the cluster | Your proof-of-concept repo, a design doc, a write-up of what you found | `[grounded]` what you wrote; `[generic]` what platform roles usually expect |
| C2 | Terraform / infrastructure as code | must-have | Ansible for configuration only; no tool that creates infrastructure | Infrastructure as code is central to most platform roles, and Terraform is named here | Writing or editing Terraform or CloudFormation for your EC2, S3 or RDS resources; reviewing someone else's | A repo, a merge request, a module | `[grounded]` what you wrote; `[generic]` what this costs on platform roles |
| C3 | SRE practices / reliability ownership | must-have | Monitoring through CloudWatch; no on-call, incidents or alerting | The role says you'll "own platform reliability" | Being on the on-call rota; building CloudWatch alarms or dashboards; handling or writing up an incident | A runbook, an alarm setup, a post-incident review | `[grounded]` what you wrote; `[generic]` what this costs on SRE-leaning roles |

**Gaps with nothing to draw on yet:**
- **Istio / service mesh.** You haven't used one. You can't learn this without Kubernetes in production, so it isn't worth chasing before R1 is real.
- **Vault.** Not used. Running Vault in dev mode with a small app that reads its secrets is a weekend project. It becomes resume-worthy only once you've built it, and it should be described as a personal project.
- **Go.** Not used. Since Go is the most preferred-sounding item on the list, it's fine to leave this gap open for this role. A small CLI or Kubernetes operator in Go would close it later.
- **GitLab CI.** Not used. A pipeline in Jenkins doesn't make you a GitLab user, but moving one personal repo to `.gitlab-ci.yml` would close this honestly.
- **ArgoCD / GitOps** (if C1 comes back no). A personal cluster such as kind or minikube, synced with ArgoCD from a git repo, is the standard way to close it.

## Not written, and why

- **"Platform Engineer" as your title.** You were a DevOps Engineer. Retitling would be an upgrade, not an equivalent.
- **"Production Kubernetes" or "Kubernetes experience" without the qualifier.** It was a two-month proof-of-concept that didn't reach production. Dropping that turns a prototype into production experience.
- **"CI/CD pipeline."** You wrote "deploy pipeline". Adding "CI" claims continuous integration you didn't mention.
- **"Infrastructure as code (Ansible)."** You wrote "config management". Relabelling Ansible as infrastructure as code to match Terraform changes the kind of work.
- **"Observability."** That's the posting's word, and yours is "monitoring". The posting's vocabulary goes in the analysis, never in your history.
- **"Improved developer experience" or "owned reliability."** These are the posting's own phrases, and nothing you wrote supports them.
- **Any listing of Terraform, ArgoCD, Istio, Vault, Helm, Go or GitLab in your skills.** Doing that is the "keyword optimisation" this request invites. It would also be the first thing an interviewer tests.

## Parse-safety check (I couldn't see the file, so this is based on your description)

| Check | Your resume | What breaks | What it costs |
|---|---|---|---|
| Multi-column layout | Two columns | Parsers read across columns line by line | Skills text can get mixed into job bullets, and dates can come loose from the roles they belong to |
| Icons for each skill | Present | Icons come out as garbage characters or nothing | **If any skill is shown only as an icon or logo, software can't see it at all.** This is the most likely way your real keywords are going missing |
| Contact details in the header | Present | Headers are often thrown away as page decoration | A recruiter may not be able to reach you |
| Canva PDF export | Unknown | If the text was exported as shapes rather than text, nothing can be extracted | The whole document could be empty to a parser |
| Hidden text | Couldn't check | Templates sometimes include invisible text | You can't see the risk you're carrying |

A two-minute test: open the PDF, select all, paste into a plain text editor, and read it. Whatever is missing or scrambled there is likely missing or scrambled for the parser too. A .docx or a PDF with selectable text is the safe pair.

Whether this role is worth applying to with these gaps is a separate question, which the job-underwriter skill covers.

---

**What would strengthen this:**
- Paste the text from that plain-text test. It shows what a parser sees and gives me your real lines to work from.
- Your Kubernetes proof-of-concept repo or notes could turn C1 into several grounded rows.
- Any Terraform or CloudFormation you've touched could close C2.

**Questions:**

C1 — In the Kubernetes proof-of-concept, what did you actually set up yourself: was it on EKS, and did you use Helm, ArgoCD, Prometheus or Grafana?

C2 — Have you ever written or edited Terraform or CloudFormation, even for a single resource?

C3 — Have you been on-call, handled a production incident, or set up CloudWatch alarms that someone was paged from?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.