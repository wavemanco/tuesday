I've built this from the sentences in your message, and I've treated each one as a line already on your CV. If the CV words them differently, send it and I'll redo the rows against its actual text. Every row below is waiting for your approval, and nothing has been applied. Your background fits this JD well on p99 latency, request volume and incident command. There are three gaps I can't write around, because your material doesn't say: which language your services are in, whether you've worked with product on the roadmap, and whether you've mentored people beyond onboarding new hires.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. Own three services in the ledger pipeline at a payments company. On-call rotation every fourth week for two years; incident commander for six incidents." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your background | pending your approval |
| E2 | Experience (current role) | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your background | pending your approval |
| E3 | Experience (current role) | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your background | pending your approval |
| E4 | Experience (current role) | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your background | pending your approval |
| E5 | Experience (current role) | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year; pair with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your background | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Languages: Go, Rust (daily, 4 years); Python" placed above "Kafka, Postgres, Terraform, gRPC, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your background | pending your approval |

Notes on the rows:
- **E3 ties the 40k number to one service.** You wrote that one of the three services handles that volume, "about" that much and "at peak." All three of those details stay in.
- **E4 keeps "every fourth week."** Removing it would make your on-call load read heavier than it was.
- **E2 only moves your line.** The p99 result answers the JD's "drive down p99 latency" most directly, so it goes first.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 states 7 years. Your material doesn't say all 7 were backend work, so the line says "7 years" and not "7 years backend." | `[grounded]` |
| R2 | Go, daily working use | must-have | `surfaced_by_edit` | E1 and E6 | `[grounded]` |
| R3 | Go in production services | must-have | `not_evidenced` | You don't say which language your three services are in (see C1) | `[grounded]` |
| R4 | Distributed systems at scale | must-have | `surfaced_by_edit` | E3 shows three pipeline services, one at about 40k requests/minute at peak. Kafka and gRPC are only in the tools list, and the system design isn't described. | `[grounded]` |
| R5 | Strong incident response | must-have | `already_evidenced` | Six incidents as incident commander. E1 also puts it in the summary. | `[grounded]` |
| R6 | Experience mentoring | must-have | `surfaced_by_edit` | E5 shows onboarding and first-month pairing for new hires | `[grounded]` |
| R7 | High request volume | important | `surfaced_by_edit` | E3 | `[grounded]` |
| R8 | Drive down p99 latency | important | `already_evidenced` | 380ms to 95ms on the balance-read path. E2 moves it first. | `[grounded]` |
| R9 | Own on-call for your services | important | `already_evidenced` | Two years on rotation. You don't say the rotation covers your own three services. | `[grounded]` |
| R10 | Mentor mid-level engineers | important | `not_evidenced` | The only mentoring you describe is with new hires (see C3) | `[grounded]` |
| R11 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material covers this (see C2) | `[grounded]` |

## Gaps: recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go | must-have | Go daily for 4 years, and three services you own, but nothing links the two | The JD's first duty is "design and ship Go services," and a reader can't infer the language of your services | The 40k-req/min service written in Go; the cache-layer rework done in Go; a Go service you designed from scratch | Repo name, design doc, or a PR you can describe | `[grounded]` what the resume says; `[generic]` that reviewers look for the requirement stated outright |
| C2 | Product partnership on roadmap | important | Nothing | It's a listed duty and the summary has no line for it | Deciding with a PM what order ledger work shipped in; pushing back on a deadline because of a dependency; scoping the cache rework against product asks | A planning doc or roadmap thread | `[grounded]` absence; `[generic]` what this costs at senior level |
| C3 | Mentoring mid-level engineers | important | Onboarding and pairing for new hires | Onboarding is different work from mentoring mid-level engineers, and the JD names the second | Design reviews you ran for a peer; someone you helped toward a promotion; leading an engineer through their first time as incident commander | Promo packet note, review comments | `[grounded]` what the resume says; `[generic]` how reviewers read "mentoring" |

## Not written, and why

- **"Designed and shipped Go services."** Your material doesn't say which language your services use. If C1 confirms Go, this becomes a real row.
- **"Distributed systems at scale."** That's the JD's wording, and you never used it about your own work. E3 shows the scale in your own words.
- **"Mentored engineers" or "mentored mid-level engineers."** You described onboarding and pairing with new hires. Calling that mentoring changes the kind of work.
- **"7 years of backend experience."** You wrote "Senior Software Engineer, 7 years," with Python before Go and Rust, and the kind of work in those early years isn't stated.
- **"Handled 40k requests/minute across my services."** That number belongs to one service, at peak.
- **"Owned on-call for my services."** You said you were on rotation, not which services it covered.
- **"Partnered with product on roadmap."** Nothing in your material supports this.

## Parse-safety check

Your background came as text in the chat, not as a file, so I couldn't check layout, columns, tables, headers and footers, file type, or hidden text from an earlier template. The sections in these rows (Summary, Experience, Skills) are standard headings that parsers recognise.

## What would strengthen this (optional)

- **Your actual CV file (.docx or PDF):** lets me use your real current lines and run the full parse check.
- **A redacted postmortem from one of the six incidents:** gives evidence for incident response beyond your own statement.
- **A design doc or PR for the cache-layer rework:** backs up the p99 result, and may answer C1 too.

## Questions

C1: Are the three ledger services, including the 40k-req/min one, written in Go? If some are in Rust, which ones?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Have you ever worked with a PM or product lead on what order work shipped in? What happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Beyond new hires, have you mentored or guided engineers who were already mid-level?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.