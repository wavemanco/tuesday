I read the tailoring rules and built your edit ledger from the details you gave me. Nothing is applied yet. Every row below is a suggestion that waits for your yes or no.

**What I assumed:** you described your CV rather than pasting it. So I've treated each of your sentences as the "current line" and quoted it word for word. Your real bullets may be worded differently, so check each Current line against the actual document.

## Requirements in the JD

| Priority | Requirement |
|---|---|
| must-have | 5+ years backend |
| must-have | Production Go |
| must-have | Distributed systems at scale |
| must-have | Strong incident response |
| must-have | Experience mentoring |
| important | Design and ship services handling high request volume |
| important | Drive down p99 latency |
| important | Own on-call for your services |
| important | Mentor mid-level engineers |
| important | Partner with product on roadmap sequencing |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your description | pending your approval |
| E2 | Experience (current role) | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your description | pending your approval |
| E3 | Experience (current role) | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your description | pending your approval |
| E4 | Experience (current role) | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(E3's line, moved to second bullet, right after E2)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your description | pending your approval |
| E5 | Experience (current role) | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Two bullets: "On-call rotation every fourth week for two years." / "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your description | pending your approval |
| E6 | Experience (current role) | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, and pair with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your description | pending your approval |
| E7 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Python · Kafka, Postgres, gRPC, Terraform, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your description | pending your approval |

A few notes on the rows:
- **E3** keeps "one", "about" and "at peak". The 40k figure applies to one service, not all three.
- **E6** keeps "usually" and "new hires". It doesn't say "mentored", because that's the JD's word, not yours.
- **E7** puts Go first among the languages but doesn't claim the ledger services are written in Go.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years backend | must-have | `already_evidenced` | "7 years" as Senior Software Engineer. E1 repeats it in the summary. | `[grounded]` your description |
| M2 | Go used daily | must-have | `surfaced_by_edit` | E1 and E7 | `[grounded]` your description |
| M3 | Go in *production services* | must-have | `not_evidenced` | Nothing says which language your three services are written in. See C1. | `[grounded]` your description |
| M4 | Services handling high request volume | important | `surfaced_by_edit` | E3 and E4: about 40k requests/minute at peak, on one service | `[grounded]` your description |
| M5 | Distributed systems at scale | must-have | `surfaced_by_edit` | E3 and E4 for the ledger pipeline and its volume, E7 for Kafka and gRPC. The phrase "distributed systems" isn't written for you. | `[grounded]` your description |
| M6 | Drive down p99 latency | important | `surfaced_by_edit` | E2 | `[grounded]` your description |
| M7 | Strong incident response | must-have | `surfaced_by_edit` | E5: six incidents as incident commander | `[grounded]` your description |
| M8 | Own on-call *for your services* | important | `surfaced_by_edit` | E5 shows the rotation. It doesn't say whether the rotation covers your own three services (see upgrade menu). | `[grounded]` your description |
| M9 | Experience mentoring | must-have | `surfaced_by_edit` | E6: onboarding new hires and pairing with them for their first month, in your words | `[grounded]` your description |
| M10 | Mentor *mid-level* engineers | important | `not_evidenced` | E6 covers new hires only, not mid-level engineers. See C3. | `[grounded]` your description |
| M11 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material. See C2. | `[grounded]` your description |

## Gaps you might be able to fill

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go | must-have | Daily Go and Rust for 4 years, and three services you own. Which language those services use isn't stated. | It's the one tech skill the JD names. A reader could assume your services are in Rust. | The ledger services or the cache layer are written in Go; you shipped Go changes to the 40k/min service; a Go service you built before this job | Repo, design doc, PR history | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications like this one |
| C2 | Partner with product on roadmap sequencing | important | Nothing | It's named as part of the job, and your resume currently has no line about working with product | Arguing for when the cache rework would happen; deciding with a PM which ledger work came first; trading off reliability work against feature work in planning | Planning doc, roadmap proposal, a PM's written feedback | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications like this one |
| C3 | Mentor mid-level engineers | important | Onboarding and first-month pairing with new hires | The JD says "mid-level" specifically, and new hires may or may not be | Ongoing guidance after the first month; a mid-level hire among the ones you onboarded; reviewing someone's design docs over time; coaching a colleague into incident commander | Feedback from a mentee, promo-packet input you wrote | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications like this one |

## What I didn't write, and why

- **"Designed and shipped high-scale Go services"**: the language isn't stated (C1), and "designed" goes beyond "own" and "reworking the cache layer".
- **"Distributed systems at scale"**: this is the JD's wording, not yours. Your own facts (pipeline, 40k/min, Kafka, gRPC) make the case without borrowing it.
- **"Mentored engineers" / "mentored mid-level engineers"**: you wrote "onboarding" and "pair with them for their first month". Switching to the JD's word would make the claim bigger than what you described.
- **"Owned on-call for my services"**: you described a rotation, but not which services it covers.
- **"Partnered with product on the roadmap"**: there's nothing behind it yet (C2).
- **"Cut p99 by 75%"**: the maths is right, but the percentage would be my number, not yours. Your before-and-after figures are easier for a reader to check.
- **"Handled 40k requests/minute across the pipeline"**: the figure is for one service, not the pipeline.
- **Build-cache or developer-tools experience**: your cache-layer work was on a payments balance-read path, which isn't the same thing.

## Parse-safety check

You sent a description, not a file, so I couldn't check columns, tables, text boxes, images, headers/footers or file type. I also couldn't check for hidden text left over from a template or an old tool. Section headings: if your CV uses standard labels (Summary, Experience, Skills), the rows above fit them. I haven't seen the actual headings.

## What else would sharpen this

- **The CV itself (.docx or PDF):** this would replace my stand-in current lines with your real ones and let the parse-safety check run.
- **Whether your on-call rotation covers your own three services:** that would let M8 say "on-call for my services" in your words.
- **A postmortem you wrote as incident commander, or the cache-rework design doc:** either would back up E2 and E5 with something an interviewer can look at.
- **Employer name and dates for each role:** needed for the final document. I won't fill them in.

## Questions

C1: Which language are your three ledger-pipeline services written in, Go, Rust or a mix?
C2: Have you ever worked with a product manager on what got built when, for example getting the cache rework scheduled?
C3: Were any of the people you onboarded or paired with mid-level engineers, or did you keep mentoring anyone past their first month?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.