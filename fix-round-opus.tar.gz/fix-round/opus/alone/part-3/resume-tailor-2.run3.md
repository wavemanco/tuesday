I've read the tailoring rules and am now building your edit ledger.

**The must-have can't be met by rewording.** The posting requires "3+ years data engineering (must-have)". Your five years are as a Senior Data Analyst, so no wording I'm willing to write turns them into data-engineering years. The ledger below brings your strongest engineering-adjacent work to the top: the dbt models, the star schema, fixing the nightly job and adding tests, and the API scripts. Airflow, Spark and Kafka stay off the resume entirely. Whether to apply with that gap is a separate decision, and it's what job-underwriter is for.

There's no resume document yet, only your description. So the "Current line" column quotes your own sentences, and every row is a proposed line for a resume built from them. The quotes are your self-report: an interviewer will probe them, so each one needs to hold up out loud.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years in retail. Built and maintained about 25 dbt models, including the core orders mart. Co-designed the orders mart's star schema with the data engineer at the time." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | "Built and maintained about 25 dbt models, including the core orders mart" *(moved to first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Co-designed the star schema for the orders mart with the data engineer at the time" *(second bullet)* | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fix the nightly dbt job when it breaks; added tests to it" | `surface` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Wrote Python scripts that pull vendor APIs on a cron schedule" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E6 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python (pandas) for analysis" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E7 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "Write SQL daily on Redshift, including complex window functions and CTEs" | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |
| E8 | Skills | *(no current line)* | "SQL (Redshift), dbt, Python (pandas), cron" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |

How these rows stay true:
- **E1 and E3 keep the co-design.** You wrote "with our then-DE", so the line says "co-designed", not "designed" or "led".
- **E2 keeps "about 25".** You didn't give an exact count.
- **E1 and E7 don't place the dbt models on Redshift.** You never said where they run.
- **E4 says "added tests", not "built a data-quality framework".** It also doesn't say you owned the job.
- **E5 calls them "scripts", not "pipelines" or "production ETL".** "On a cron" stays as it is.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Named absence N1. Your 5 years are as an analyst. | `[grounded]` your message |
| R2 | Production Python | must-have | `not_evidenced` | Recall prompt C1. E5 shows scheduled API scripts, but not that they ran in production. | `[grounded]` your message |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | Recall prompt C2. You wrote "Never used Airflow"; whether whatever schedules the nightly dbt job counts as "equivalent" is still open. | `[grounded]` your message |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E1 and E3: co-designed the orders mart star schema | `[grounded]` your message |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E2: about 25 dbt models, including the core orders mart | `[grounded]` your message |
| R6 | Own data quality | important | `surfaced_by_edit` | E4 shows tests added to one job. That's part of this, not ownership. | `[grounded]` your message |
| R7 | Own SLAs | important | `not_evidenced` | Recall prompt C3 | `[grounded]` your message |
| R8 | Build and own batch pipelines | important | `not_evidenced` | Depends on C1 and C2. E2 and E5 are related work but aren't pipeline ownership. | `[grounded]` your message |
| R9 | Spark | important | `not_evidenced` | Named absence N2 | `[grounded]` your message |
| R10 | Streaming / Kafka | preferred | `not_evidenced` | Named absence N3 | `[grounded]` your message |
| R11 | Partner with analytics on requirements | important | `not_evidenced` | Named absence N4. You were the analytics side, not the side that partners with it. | `[grounded]` your message |

## Gaps

**Questions that could close a gap** (the questions themselves are at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python for analysis, plus scripts pulling vendor APIs on a cron. Nothing says whether they ran unattended or whether other people depended on their output. | It's a stated must-have, and "for analysis" doesn't meet it on a first read. | The API scripts loading tables that dashboards or dbt models depended on; retries or alerting when a vendor API failed; the code in version control with reviews | The repo, a commit history, an alert or error-handling snippet | `[grounded]` what your message says and doesn't; `[generic]` how analysis Python reads against a production-Python requirement |
| C2 | Airflow or equivalent orchestration | must-have | You fix the nightly dbt job when it breaks. Nothing says what schedules it or who set it up. | The posting accepts "or equivalent". If you configured scheduling or dependencies, that may count. | Setting up the dbt job's schedule in dbt Cloud or elsewhere; ordering the API pulls ahead of the dbt run; reruns or backfills you triggered | Job config, a screenshot of the schedule, run history | `[grounded]` what your message says and doesn't; `[generic]` how "equivalent orchestration" usually gets read |
| C3 | Own SLAs | important | You fix the job when it breaks. Nothing says whether it had a deadline or anyone waiting on it. | Ownership of SLAs is listed in the posting itself. | A morning deadline for the orders mart; stakeholders who escalated when it was late; you being the default person to fix it | A ticket, an incident note, a Slack thread | `[grounded]` what your message says and doesn't |

**Gaps with nothing to recover:**

| # | Gap | What closing it would take |
|---|---|---|
| N1 | No years titled or scoped as data engineering | Rewording can't fix this. Real paths: about 6–12 months owning pipelines in your current job, or targeting Analytics Engineer roles, where 25 dbt models and a star schema are the core evidence. |
| N2 | Never used Spark | A real project that processes data with Spark, for example in a public repo. It isn't the must-have, so N1 matters more. |
| N3 | Never touched Kafka | It's listed as "a plus". Not worth closing for this application. |
| N4 | You were the analytics side, not partnering with it | You can talk about knowing what analysts need in an interview. A resume line saying you "partnered with analytics" would swap which side you were on. |

## Not written, and why

- **"Data Engineer" or "Analytics Engineer" as your title.** You were a Senior Data Analyst, and changing the title is an upgrade, not an equivalent.
- **"3+ years of data engineering".** You have none titled or scoped that way.
- **"Built and owned batch pipelines" / "ETL pipelines".** You have scripts on a cron and a dbt job you fix, and that's what the lines say.
- **"Owned data quality and SLAs".** You added tests to one job and fix it when it breaks. Ownership waits on C3.
- **"Production Python".** Waits on C1.
- **"Orchestrated workflows", or Airflow in Skills.** You wrote "Never used Airflow".
- **Spark or Kafka anywhere, including "familiar with".** You wrote "Never used… Spark. Never touched Kafka."
- **"Designed the star schema" without the co-designer.** Your sentence says "with our then-DE".
- **"Partnered with analytics on requirements".** That's the posting's phrase, and it would flip which side of the table you sat on.

## Parse-safety check

None of the layout checks could run, because there's no file yet. That covers columns, tables, images, headers and footers, and file type. I also couldn't check for hidden text a template might have left. When you build the file, the proposed rows use standard section headings: Summary, Experience and Skills.

## What more material would unlock

- **Your actual resume file:** the rows become edits to your real lines, I can add dates and your employer, and the parse-safety check can run.
- **The vendor API script repo:** could move C1 from your description to something an employer can inspect.
- **The dbt job's schedule config or run history:** could close C2.
- **The dbt project, with test files:** would back E2 and E4 with something an employer can look at.

## Questions

C1: Did those vendor API scripts run unattended, feeding tables other people relied on, and how did you find out when one failed?
C2: What actually schedules the nightly dbt job, and did you set up or change that schedule or the order jobs run in?
C3: Did the nightly job have a deadline someone depended on, and were you the person expected to fix it when it missed?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.