I've read the tailoring rules; here's the full ledger.

**First, the premise: missing keywords probably aren't what's auto-rejecting you.** The best evidence I have is one small vendor survey of 25 US recruiters. Only two of them had content-based auto-rejection switched on: "We only saw 2 of 25 using it" (cite C25). Where software does reject without a person, "they're almost always knockout questions" (cite C26). Those are the yes/no questions on the application form, such as work authorization or location. Match scores mostly decide who gets read first: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27). Twenty-five recruiters can't tell us how rare auto-rejection is overall, so take this as a lean, not a rule.

Two things follow for you:
- **Your file format is a bigger risk than your keywords.** See the parse-safety check below.
- **The bigger gap is in what you've done.** This posting names about a dozen tools you haven't used in production. Truthful keywords help, but I can't add ones your work doesn't back up.

**What I worked from:** you described your resume rather than pasting it. So each "Current line" below is your own sentence, assuming the resume says roughly that.

### Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Own platform reliability and developer experience | must-have | `not_evidenced` | Your Jenkins pipeline is related, but nothing shows you owned reliability. Question R1 below | `[grounded]` JD's only responsibility sentence; your material |
| M2 | Kubernetes, hands-on exposure | important | `surfaced_by_edit` | E2, a proof-of-concept only, with that limit stated | `[grounded]` "Ran a Kubernetes proof-of-concept for two months last year — never went to production." |
| M3 | Kubernetes in production / AWS EKS / Helm | important | `not_evidenced` | Question R2 below | `[grounded]` same sentence, "never went to production" |
| M4 | AWS | important | `already_evidenced` | Ordered first by E3 | `[grounded]` "AWS (EC2, S3, RDS, IAM)" |
| M5 | CI/CD | important | `already_evidenced` | Jenkins; moved up by E1 | `[grounded]` "Built our deploy pipeline in Jenkins" |
| M6 | GitLab CI specifically | preferred | `not_evidenced` | Named absence A1 | `[grounded]` only Jenkins is named |
| M7 | Terraform | important | `not_evidenced` | Question R3 below | `[grounded]` only "Ansible for config management" |
| M8 | GitOps / ArgoCD | important | `not_evidenced` | Named absence A2 | `[grounded]` your material doesn't mention it |
| M9 | Service mesh / Istio | preferred | `not_evidenced` | Named absence A3 | `[grounded]` your material doesn't mention it |
| M10 | Monitoring | important | `already_evidenced` | CloudWatch only | `[grounded]` "CloudWatch for monitoring" |
| M11 | Prometheus / Grafana | important | `not_evidenced` | Named absence A4 | `[grounded]` only CloudWatch is named |
| M12 | Vault | preferred | `not_evidenced` | Named absence A5 | `[grounded]` IAM is access control, not secrets storage |
| M13 | SRE practices | important | `not_evidenced` | Part of question R1 | `[grounded]` your material doesn't mention it |
| M14 | Python | important | `surfaced_by_edit` | E4 | `[grounded]` "Bash and Python scripting" |
| M15 | Go | preferred | `not_evidenced` | Named absence A6 | `[grounded]` your material doesn't mention it |

The posting doesn't rank its requirements, so the priorities are my guess. I made the one responsibility sentence must-have. A tool that comes with a matching practice (GitOps with ArgoCD, observability with Prometheus) is important. A tool listed once is preferred.

### Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to first bullet under DevOps Engineer)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your description | pending your approval |
| E2 | Experience | *(not on the resume as a bullet, as far as I can tell)* | "Ran a Kubernetes proof-of-concept for two months — did not go to production." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | AWS (EC2, S3, RDS, IAM) · Python scripting · Jenkins (CI/CD) · Docker · Bash scripting · Ansible (config management) · CloudWatch (monitoring) | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your description | pending your approval |
| E4 | Skills | "Bash and Python scripting" | "Python scripting" and "Bash scripting" as separate entries | `split` | "Bash and Python scripting" | `[grounded]` your description | pending your approval |

Notes on the rows:
- **E1** keeps "about 30". The number still counts jobs, and "about" is your own hedge.
- **E2** keeps the limit. "Proof-of-concept" plus "did not go to production" is what makes it safe to say in an interview. The resume still needs a date for it, and only you know it.
- **E3** adds "(CI/CD)" after Jenkins. That's a category label for a tool you used, not a new claim. Reject it if you'd rather keep the bare word.
- **E4** gives Python its own entry so a parser can find the term on its own.

### Gaps

**Questions that could close a gap** (the questions themselves are at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Platform reliability and SRE practices | must-have | You built and maintain pipelines. Nothing about uptime, incidents or on-call | It's the one thing the posting says you'll own | Being on call for prod; leading or writing an incident post-mortem; setting CloudWatch alarms that page someone; cutting failed deploys or rollback time | An alarm config, a post-mortem doc, a runbook you wrote | `[grounded]` what your material says; `[generic]` that reliability roles probe this first |
| R2 | Kubernetes in production / EKS / Helm | important | A two-month proof-of-concept that didn't ship | It sits at the centre of this tool list | Whether the PoC ran on EKS; whether you wrote Helm charts or plain manifests; what workload it ran | The PoC repo, a design doc, a write-up of why it stopped | `[grounded]` your PoC sentence; `[generic]` that hands-on depth counts even unshipped |
| R3 | Terraform | important | Ansible for config management only | Platform teams often treat infrastructure-as-code as a baseline | Any Terraform or CloudFormation, even read-and-modify; provisioning EC2/RDS from code rather than the console | A `.tf` or CloudFormation file, a merge request | `[grounded]` your material; `[generic]` that it's a baseline expectation |

**Gaps with nothing to pull from yet:**

| # | Gap | What closing it would take | Provenance |
|---|---|---|---|
| A1 | GitLab CI: you've used Jenkins only | A small public project with a `.gitlab-ci.yml` pipeline. You'd then be able to say "Jenkins, and GitLab CI on a personal project" | `[grounded]` your material; `[generic]` that pipeline skills carry over between tools |
| A2 | GitOps / ArgoCD: none | ArgoCD syncing a home-lab cluster from a Git repo. That's a weekend or two on top of your PoC skills | `[grounded]` your material; `[generic]` effort estimate |
| A3 | Istio / service mesh: none | Listed once with no responsibility attached, so probably not worth chasing for this role | `[inferred]` from how the JD ranks it |
| A4 | Prometheus / Grafana: none | A Prometheus and Grafana stack on the same home-lab cluster. Until then, CloudWatch is your honest monitoring line | `[grounded]` your material; `[generic]` effort estimate |
| A5 | Vault: none | Low priority here. Reading IAM experience as secrets management would change what kind of work you did | `[grounded]` your material |
| A6 | Go: none | Small Go CLI tools over a few months. Not closeable before you apply | `[generic]` effort estimate |

### What I didn't write, and why

- **"Platform Engineer" as your title.** You were a DevOps Engineer, and changing the title upgrades it.
- **"Kubernetes" as a bare skills entry, or "EKS" or "Helm".** Next to tools you use in production, a bare entry implies production use. The PoC appears only in E2, with its limit.
- **"Built a GitOps CI/CD platform" or "Improved developer experience".** That's the posting's wording for a Jenkins pipeline. Interviewers will ask about ArgoCD in the next sentence.
- **"Observability" or "SRE" for your CloudWatch work.** You wrote "monitoring". Swapping in the posting's word turns monitoring into a practice you haven't described.
- **"Infrastructure as code" for Ansible.** You wrote "config management", which is different work.
- **"Owned platform reliability".** Nothing in your material supports it. That's what R1 is for.
- **Hidden keywords** (white text and the like). You didn't ask for this, but it's the usual next idea. Parsers read hidden text and it does get found, so it isn't a way around the gaps.

### Parse-safety check

I couldn't run this on the file because I only have your description. From that description:

| Check | Risk | What it costs |
|---|---|---|
| Two-column layout | High | Parsers read across both columns line by line. Your skills column can mix into your job bullets, and dates can come loose from the jobs they belong to |
| Icons for each skill | High | Icons usually extract as nothing or as stray characters. If a skill name only appears as an icon, it may be invisible to the parser |
| Contact details in the header | Medium | Some parsers drop headers as page decoration, and you become unreachable |
| Canva PDF text layer | Couldn't check | Some exports turn text into shapes. Try selecting and copying text from the PDF: if you can't, no parser can read it either |
| Hidden text from a template | Couldn't check | Needs the file |

This is one explanation for your rejections that would hit every application regardless of wording. A `.docx`, or a PDF with selectable text, is the safe format.

### What more input would unlock
- **Your actual resume, as text or the PDF.** I could run the parse check properly, use your real lines and check for hidden text.
- **The PoC repo or a write-up.** It could add detail to E2, but only what it shows.
- **Whether this role is worth the effort, given all the gaps above.** That's a separate question, and the job-underwriter skill handles it.

### Questions
R1 — Have you ever been on call, handled an incident, or set up alarms that paged someone? Tell me what happened and what part was yours.
R2 — On the Kubernetes proof-of-concept: did it run on EKS, did you write Helm charts or plain manifests, and what workload did it run?
R3 — Have you written or changed any Terraform or CloudFormation, even someone else's?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.