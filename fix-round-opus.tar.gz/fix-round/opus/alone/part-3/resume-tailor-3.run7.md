I need to read the references.
Here's the tailoring ledger. Nothing has been applied to your CV yet. I'm working from the dossier excerpt you pasted, not the full `tuesday-dossier.md` file, so I've reused its judgments as given. Its `role_profile` is for this same Quartzline role, so it still applies. Your CV came as five sentences of prose, so every line below quotes one of those sentences word for word.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (sits alongside your other duties) | "Wrote the internal integration playbook the whole team uses." as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV, plus dossier edit E1 (taken from the dossier and checked again) | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first Experience bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to directly below E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." (inside the prose) | "Comfortable in Postman, SQL, OpenAPI specs." as a separate Technical skills line | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |

Notes on the checks:
- **E5 keeps "solutions engineer / implementation lead" exactly as you wrote it.** I can't tell whether that's one role or two in sequence, so I took the reading that claims less and didn't retitle it.
- **"Our REST APIs" stays.** It records that you worked on the vendor's side.
- **"30+" stays with "client integrations".** It doesn't move onto "APIs" or "launches".
- **"Comfortable in" stays.** Cutting it would leave a tools list that reads as more than you said.
- **E3 keeps "for product".** You collected feedback that product used; the roadmap wasn't yours. E3 is moved, not reworded, so a PM reviewer sees it early.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| G1 | 3+ years PM | must-have | `not_evidenced` | From the dossier: adjacent, transferability gap, medium confidence. Integration leadership is adjacent; roadmap ownership and authority to set priorities are not shown. E3 and E5 bring the adjacent work forward and claim nothing more. Recall prompt C1 | `[grounded]` dossier R1, CV |
| G2 | Shipped API or platform products | important | `not_evidenced` | From the dossier: adjacent, medium. You integrated the vendor's APIs; nothing says you shipped one. E2 brings forward the adjacent work. Recall prompt C2 | `[grounded]` dossier R2, CV |
| G3 | Technical fluency | important | `surfaced_by_edit` | E4 (Postman, SQL, OpenAPI specs) and E2 (REST API integrations end to end) | `[grounded]` CV |
| G4 | Stakeholder management | important | `surfaced_by_edit` | E2 (30+ client integrations end to end) and E3 (quarterly sessions with clients, feeding product). The resume shows the work; the phrase "stakeholder management" is not written into it | `[grounded]` CV |
| G5 | Own the roadmap for the partner API platform | important | `not_evidenced` | Same gap as G1. Recall prompt C1 | `[grounded]` dossier R1 reasoning |
| G6 | Run discovery with integration partners | important | `not_evidenced` | E3 is the closest evidence. Collecting client feedback for product is not running discovery, and your clients were not this employer's partners | `[grounded]` CV |
| G7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | Being comfortable in OpenAPI specs is not the same as writing product specs for engineers. Recall prompt C3 | `[grounded]` CV |
| G8 | Define adoption metrics | important | `not_evidenced` | Nothing to draw on; see the named absence below | `[grounded]` CV |

**Recall prompts** (the questions themselves are in the closing block):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM / own the roadmap | must-have | You ran quarterly roadmap-input sessions for product. That shows input to the roadmap, not decisions over it. | It's the only must-have. A years-of-experience requirement tied to a job title tends to be screened literally, so adjacent work has to show some decision-making to count. | You ranked client requests before handing them over; product adopted your ranking; you made a scope trade-off on a big integration | A ranked feedback summary, a prioritisation doc, a message from product acting on your ranking | `[grounded]` what the CV says and doesn't; `[generic]` how title-based year requirements are screened |
| C2 | Shipped API products | important | You led integrations of the vendor's APIs, on the consuming side of the build | The role owns an API platform; changes you caused to ship would be the closest direct evidence | A new endpoint or field added because of your integration; a versioning or auth change you requested; a beta you tested | A changelog entry, a ticket you filed, release notes that name your request | `[grounded]` CV; `[generic]` what API PM screens weight |
| C3 | Write specs | important | You're comfortable *reading* OpenAPI specs; the playbook is a document, but not a spec | Writing specs is a core duty in this JD | A requirements doc for a custom integration; an OpenAPI spec you authored; acceptance criteria engineers built from | The document itself, redacted | `[grounded]` CV; `[grounded]` the JD's responsibilities |

**Named absence: adoption metrics (G8).** Nothing in your material touches defining or tracking adoption. Two things could close it:
- something real you can point to, such as tracking integration go-live rates or time-to-first-call for your 30+ clients, if you ever did;
- otherwise, it's better addressed at interview than on the resume.

It's listed as a responsibility, not a requirement, so it isn't worth stretching a line to cover it.

## Not written, and why

- **"Product Manager", or "3+ years of product management".** You've never held the title, and the only must-have can't be met with wording.
- **"Owned / prioritised the API roadmap".** You ran sessions that collected feedback *for* product. The dossier notes that ownership and prioritisation authority aren't shown.
- **"Shipped / built REST APIs".** You integrated "our REST APIs". Building them is a different kind of work.
- **"Ran discovery with integration partners".** That's the JD's wording, not yours. Your sessions collected client feedback, and changing the word moves which side of the table you sat on.
- **"Wrote specs" based on "Comfortable in … OpenAPI specs".** Being comfortable with a format doesn't mean you wrote specs in it.
- **"Defined adoption metrics".** Nothing supports it.
- **"Playbook adopted company-wide".** You wrote "the whole team uses". The scope stays at the team.
- **"Led a team" from "implementation lead".** The title doesn't establish people management.
- **Rejected in the dossier, kept unchanged:** "built an internal request-triage tool". This was a memory lead, and you couldn't confirm ownership.
- **Rejected in the dossier, kept unchanged:** "has been the customer of a partner API platform". You worked vendor-side.

## Parse-safety check

Your CV came as pasted text, so I couldn't run the checks for layout, tables, text boxes, images, header/footer content, headings or file type. Nothing in the text itself is a risk. If you send the file, I can run the full check.

**Optional offer beyond the usual scope:** a short cover-letter paragraph that makes the transferable case and states its limits. The dossier rates your fit as adjacent with a transferability gap, and a paragraph is the place to make that case; a resume line can't. It would go through the same line-by-line check, and I'll only write it if you ask.

## What extra input would unlock

- **The full `tuesday-dossier.md`:** trace cells could quote the evidence-map source quotes directly, and G3 and G4 would carry the dossier's confidence levels instead of mine.
- **The CV as a file:** the complete parse-safety check, plus dates and structure, so the reorder rows (E2, E3) point at real positions.
- **The playbook itself, or a redacted excerpt:** E1 becomes something you can show as a work sample, and it may answer C3.
- **Answers to C1–C3:** each one could turn a `not_evidenced` requirement into a real row.

## Questions

**C1:** When feedback from your quarterly sessions went to product, did you ever decide what got built or in what order? For example, did you rank the requests yourself, make a call on a trade-off, or see product adopt your ranking as it was?

**C2:** Did any change to your REST APIs ship because of an integration you led or feedback you collected, such as a new endpoint, a field, or a versioning or auth change? Was your part requesting it, specifying it, or testing it?

**C3:** Have you written a requirements doc, an OpenAPI spec or acceptance criteria that engineers then built from, as opposed to reading specs to integrate against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.