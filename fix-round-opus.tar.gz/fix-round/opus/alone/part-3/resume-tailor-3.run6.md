Nadia, here's the tailoring ledger. Nothing in it has been applied yet. I worked from the dossier excerpt you pasted, because no `tuesday-dossier.md` file came through with your message. I also treated each sentence of your CV summary as a current line, since you sent a summary rather than the document. If your real bullets are worded differently, send them and I'll swap them into the rows.

**The short version:** your CV doesn't show the role's one must-have, 3+ years as a PM, and no rewording can make it show that. What the edits can do is put your strongest evidence first: 30+ API integrations, the playbook, the roadmap-input sessions and your technical skills, all in your own words. They avoid the posting's vocabulary ("partners", "discovery", "roadmap ownership") because that language describes work you haven't claimed.

## Edit ledger: `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." *(inside the role paragraph)* | "Wrote the internal integration playbook the whole team uses" *(as its own bullet)* | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; carried over from dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second bullet, directly after E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." *(inside the role paragraph)* | "Comfortable in Postman, SQL, OpenAPI specs" *(as its own line under a "Skills" heading)* | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |

Notes on the rows:
- **E1** keeps "the whole team" and doesn't widen it to "company-wide".
- **E2** keeps "client" and "our REST APIs", which show you worked on the vendor's side.
- **E3** keeps "for product", which says you gave input to the roadmap. It doesn't say you owned it.
- **E4** keeps "Comfortable in". That word is the honest qualifier, so I didn't cut it down to a bare tool list.
- **E5** is two of your own sentences, kept separate.

The dossier rates both your PM experience (R1) and your API-product experience (R2) as medium confidence, and these rows don't raise that. An interviewer will probably ask what your role was in the roadmap sessions and in shipping product.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Named absence A1 and recall prompt C1. Per the dossier, your work is adjacent (gap type: transferability, medium confidence); roadmap ownership and prioritisation authority aren't evidenced | `[grounded]` dossier evidence_map R1; CV |
| R2 | Shipped API or platform products | important | `not_evidenced` | E2 shows integration delivery of an API someone else built. Dossier rates this adjacent, medium. Recall prompt C2 | `[grounded]` dossier evidence_map R2; CV |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4 | `[grounded]` CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3: end-to-end client integrations and quarterly client-feedback sessions | `[grounded]` CV |
| R5 | Own the partner-API roadmap | important | `not_evidenced` | E3 shows input to the roadmap, not ownership of it. Recall prompt C1 | `[grounded]` CV; dossier R1 reasoning |
| R6 | Run discovery with integration partners | important | `not_evidenced` | E3 is the closest evidence (collecting client feedback). Named absence A2 | `[grounded]` CV |
| R7 | Write specs, drive delivery with two engineering squads | important | `not_evidenced` | Recall prompt C2 | `[grounded]` CV |
| R8 | Define adoption metrics | important | `not_evidenced` | Recall prompt C3 | `[grounded]` CV |

## Gap handling

### Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM / roadmap ownership | must-have | You ran the sessions that collected client feedback for product. It doesn't say whether you ever made a prioritisation decision yourself. | Owning the roadmap is the first responsibility listed in the posting. Without decision authority, this reads as customer-facing engineering work. | You chose which client requests to escalate and in what order. Product gave you a scope decision on an integration feature. You cut or sequenced the scope of an integration project. | A session summary you wrote, a prioritised backlog, an email showing a decision | `[grounded]` what the CV and dossier show; `[generic]` how PM screeners usually read input versus ownership |
| C2 | Shipped API products; writing specs | important | You're "comfortable" with OpenAPI specs. It doesn't say whether you wrote specs that engineers built from. | The role writes specs for two engineering squads. Authorship is what's being tested. | Engineers built an API change a client needed from requirements you wrote. You drafted or edited an OpenAPI spec that went into production. You wrote tickets that engineering delivered. | A redacted spec, a ticket, release notes | `[grounded]` what the CV shows; `[generic]` what spec authorship signals |
| C3 | Define adoption metrics | important | Your CV has no numbers about outcomes. | Adoption metrics is one of the four responsibilities the role lists. | You tracked time to go-live across the 30+ integrations. You reported which integrations went live or stalled. You saw API usage after launch. | A dashboard, a quarterly report, a spreadsheet | `[grounded]` the CV has no metrics; `[generic]` what metrics work usually looks like |

### Named absences

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | 3+ years PM | You've never held a PM title, and the posting makes 3+ years of PM a must-have. No edit turns solutions-engineering years into PM years. | Answers to C1 and C2 could show PM-shaped decisions you made within your role, but the must-have still wouldn't be met. Fully closing it would take a PM-titled role, for example an internal move into product. Whether to apply anyway is a call for job-underwriter, and its dossier rated this role `conditional_go`. | `[grounded]` your statement "Never held a PM title"; dossier decision |
| A2 | Discovery with integration partners | You collected client feedback, but you didn't say you ran discovery. These are different kinds of work. | You'd need a confirmed example of setting the research questions and interpreting the answers, not just collecting them. If you have one, it would surface under C1. Otherwise it isn't something an edit can close. | `[grounded]` CV |

## Not written, and why

- **"3+ years of product management", or any PM or PM-equivalent title.** You've never held one, and the posting makes it a must-have.
- **"Owned the roadmap" or "drove prioritisation".** Your sentence says you collected feedback "for product". The dossier says roadmap ownership isn't evidenced.
- **"Shipped API products" or "built our REST APIs".** You integrated the APIs for clients. Building or shipping them is different work.
- **"Ran discovery with integration partners".** That's the posting's wording. Your word is "client", and "partner" would change which side of the relationship you were on.
- **"Wrote OpenAPI specs".** "Comfortable in" can be read two ways, so I've taken the reading that claims less.
- **"Drove delivery with engineering squads".** Your material doesn't mention this.
- **Any adoption metric or percentage improvement.** Your material has no figures.
- **"Playbook adopted company-wide".** You wrote "the whole team".
- **Rejected in the dossier: "built an internal request-triage tool".** This came from a memory lead, and you couldn't confirm you owned it.
- **Rejected in the dossier: "has been the customer of a partner API platform".** You worked on the vendor's side.

## Parse-safety check

Your CV arrived as pasted prose, so I couldn't check layout, columns, tables, headers and footers, images or file type. The proposed headings ("Summary", "Experience", "Skills") are the conventional ones parsers look for. If you send the file, ideally as a .docx or a PDF with a text layer, I'll run the full check.

## Upgrade menu

- **Your actual CV text or file.** The rows would quote your real bullets, and the full parse-safety check could run.
- **The integration playbook (redacted is fine).** It's the one document that could raise E1 from claim to inspected evidence.
- **Notes from any roadmap-input session.** These are the most direct evidence for C1.

## Questions

C1: After a quarterly roadmap-input session, was there a time you decided, not just recommended, what got built or in what order?
You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Did engineers ever build from requirements or an OpenAPI spec you wrote, for example an API change a client integration needed?
You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Did you track any numbers on your integrations, such as time to go-live or usage after launch?
You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.