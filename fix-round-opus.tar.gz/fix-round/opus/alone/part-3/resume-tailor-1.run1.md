Here's the full set of proposed edits for your CV against the Tessellate JD. Nothing has been applied yet. Each row is waiting for your approval.

**What I built this on:** you described your CV in sentences rather than pasting it, so I treated each sentence as the current line. If your CV is worded differently, the "Current line" column will be off and I'll redo those rows. Every proposed line uses only your own words: no new facts, no wider scope, and none of the JD's wording applied to your past work.

## Your sentences (the only material any row draws on)

- S1 "Senior Software Engineer, 7 years."
- S2 "Currently at a payments company."
- S3 "Go and Rust daily for 4 years, Python before that."
- S4 "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."
- S5 "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer."
- S6 "On-call rotation every fourth week for two years, I've run six incidents as incident commander."
- S7 "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month."
- S8 "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog."

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years; Go and Rust daily for 4 years. Own three services in a payments company's ledger pipeline, one handling about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV description | pending your approval |
| E2 | Experience (current role) | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV description | pending your approval |
| E3 | Experience (current role) | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in the ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV description | pending your approval |
| E4 | Experience (current role) | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV description | pending your approval |
| E5 | Experience (current role) | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV description | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Python, gRPC, Kafka, Postgres, Terraform, Datadog" | `merge` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV description | pending your approval |

Notes on these rows:

- **E1 keeps your two claims as two sentences.** Joining them would make the 40k-requests figure read as a Go figure, and you haven't said which language those services are in (see R1).
- **E2 leads with the p99 result** because it matches the JD's "drive down p99 latency" almost exactly. The wording stays yours ("the balance-read path"), so it reads as the one path you worked on, not latency work across many services.
- **E3 and E4 stay as separate bullets** on purpose. Merging them would suggest the on-call rotation covers your three services, and you haven't said that (see R4).
- **E5 keeps "onboard" and "pairing".** It does not become "mentored".
- **E6 adds no tools.** It only moves your languages (already in S3) into the skills line, with Go first so a reader finds it.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | Backend experience | must-have | `surfaced_by_edit` | E1, E3: you own services in a ledger pipeline | `[grounded]` S4 |
| C2 | 5+ years of backend | must-have | `not_evidenced` | You give 7 years as a software engineer and 4 of Go/Rust. You don't say whether the Python years were backend work. → R2 | `[grounded]` S1, S3 |
| C3 | Go, used daily | must-have | `surfaced_by_edit` | E1, E6: "Go and Rust daily for 4 years" | `[grounded]` S3 |
| C4 | *Production* Go | must-have | `not_evidenced` | You don't say which of your three services, if any, are written in Go. → R1 | `[grounded]` S3, S4 |
| C5 | Distributed systems at scale | must-have | `surfaced_by_edit` | E3 shows the scale in your own number (40k requests/minute, three services). The words "distributed systems" are left out because you didn't use them. | `[grounded]` S4, S8 |
| C6 | Strong incident response | must-have | `surfaced_by_edit` | E4: six incidents as incident commander, two years on rotation | `[grounded]` S6 |
| C7 | Experience mentoring | must-have | `surfaced_by_edit` | E5: onboarding new hires and pairing with them for their first month. It covers the requirement only as onboarding, not as ongoing mentoring. | `[grounded]` S7 |
| C8 | Mentor mid-level engineers | important | `not_evidenced` | → R5 | `[grounded]` S7 |
| C9 | Drive down p99 latency | important | `surfaced_by_edit` | E2 | `[grounded]` S5 |
| C10 | High request volume | important | `surfaced_by_edit` | E1, E3 | `[grounded]` S4 |
| C11 | Own on-call for your services | important | `not_evidenced` | You own services (S4) and you're on a rotation (S6), but you don't say the rotation covers those services. → R4 | `[grounded]` S4, S6 |
| C12 | Partner with product on roadmap sequencing | important | `not_evidenced` | → R3 | `[grounded]` nothing you sent mentions product |
| C13 | Build-cache domain | preferred | `not_evidenced` | → N1 | `[grounded]` S5 |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Production Go | must-have | Daily Go and Rust use, and three owned services, but nothing linking the two. | The JD lists production Go first among its stack requirements. A line naming Go for the 40k-requests service would cover C4 and strengthen C5 and C10 at once. | One of the three ledger services written in Go; Go on the balance-read path you reworked; a Go service you've since handed off | The repo or service catalog entry; a design doc for the cache rework | `[grounded]` what S3 and S4 do and don't say; `[generic]` that "production" is what screeners look for in a language requirement |
| R2 | 5+ years backend | must-have | 7 years as an engineer, 4 of them clearly on backend services. | You're at 4 clearly backend years against a stated 5+. Confirming the Python years were backend work would close it. | Python APIs or services; data pipelines; backend work at an earlier employer | Dates and the role line from your earlier jobs | `[grounded]` S1, S3; `[generic]` that a years requirement is often read off role lines |
| R3 | Product partnership | important | Nothing. | It's a stated part of the role. Without a line, it falls to the interview. | Sequencing ledger work with a PM; pushing back on a roadmap item for reliability reasons; scoping a migration with product | A planning doc, an RFC with a product reviewer | `[grounded]` absence in your material; `[generic]` that seniors are commonly probed on this |
| R4 | On-call for your own services | important | Ownership and on-call appear separately. | The JD says "own on-call for your services". If your rotation covers your three services, E4 can say so in your words. *Question held back this turn to stay within three.* | The rotation covering the ledger pipeline; incidents on your own services | Rotation schedule, postmortems | `[grounded]` S4, S6 |
| R5 | Mentoring mid-level engineers | important | Onboarding new hires for their first month. | Onboarding and ongoing mentoring of mid-level engineers are different work, and the JD names the second. *Question held back this turn.* | An ongoing 1:1 with a non-new engineer; reviewing someone's design work over months | — | `[grounded]` S7; `[generic]` the onboarding/mentoring distinction |

**N1, build-cache domain (named absence).** Reworking a cache layer for balance reads is not the same work as building a build-cache platform. The domains differ, even though the latency skills transfer. It isn't in the requirements list, so I don't think it's worth closing on the resume. Prepare an interview answer that tells the cache-layer story plainly and doesn't present it as build-cache experience.

## Not written, and why

- **"Distributed systems experience at scale"**: this is the JD's phrase, not yours. Your 40k requests/minute number carries the point and is something you can defend.
- **"Built/owned production Go services handling 40k req/min"**: you haven't said those services are in Go. Joining the two facts would create a claim you never made (R1).
- **"Own on-call for my services"**: you described a rotation, not its scope (R4).
- **"Mentored engineers" / "mentored mid-level engineers"**: your word is "onboarding", and changing it would change what kind of work you're describing (R5).
- **"Drove down p99 latency across our services"**: you described one path, the balance-read path.
- **"Partnered with product on the roadmap"**: nothing you sent supports it (R3).
- **"Caching / build-cache platform experience"**: a cache layer isn't a build-cache platform (N1).
- **"7 years of backend engineering"**: you gave 7 years as an engineer. Your wording doesn't say all of them were backend (R2).

## Parse-safety check

You described your CV rather than sending the file, so I couldn't check the layout (columns, tables, text boxes), contact details in headers or footers, file type, or any hidden text a template might have left behind. One thing I could check: with E6 approved, "Go" appears in plain text in both the summary and the skills line, so a reader scanning for it will find it.

## Upgrade menu

- **The CV file itself (.docx or PDF):** runs the full parse check and replaces my guessed "Current line" cells with your real wording.
- **A design doc or before/after dashboard for the balance-read cache rework:** backs up E2, the strongest row, with something a reader can inspect.
- **One or two postmortems where you were incident commander:** backs up E4 and gives you interview material on incident response.

## Questions

R1: Which of your three ledger services are written in Go, and is the ~40k requests/minute one among them?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R2: Was the Python work before your Go years backend or service work, and roughly how long did it last?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R3: Have you worked with a product manager on what order ledger work gets done in? One concrete example is enough.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.