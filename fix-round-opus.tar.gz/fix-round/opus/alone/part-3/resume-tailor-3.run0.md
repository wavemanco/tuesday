I'm working from the dossier and the background you gave me. Since it's a summary rather than the CV itself, I've treated each of your sentences as a current line. Every row below quotes your words exactly. The dossier is for this same Quartzline role, so I've used all of it. Its two judgements carry over unchanged: R1 and R2 are both `adjacent` at `medium` confidence. Its pending edit E1 is row E1 below, checked again like the others. Its rejected inferences are in the "Not written" list word for word.

## Edit ledger — resume_edits_pending_approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (inside the role description) | "Wrote the internal integration playbook the whole team uses." (as its own bullet) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` dossier E1; your background | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your background | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second bullet)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your background | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved directly under the summary)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your background | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of the company's REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your background | pending your approval |

Notes on the rows:
- **E4:** "Comfortable in" stays. It is your own statement of how well you know these tools, and dropping it would make the line claim more.
- **E5:** The summary stays as three separate sentences, so the feedback sessions don't read as part of the integration work.
  - "our" became "the company's", which has the same scope.
  - The "30+" stays with "integrations".
  - "solutions engineer / implementation lead" is kept exactly as you wrote it. I can't tell whether that's one title or two, so I didn't pick the grander reading.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | The dossier rates this `adjacent` (gap type `transferability`, confidence `medium`). E2, E3 and E5 put the closest work up front, but none of it is PM tenure. This is a named absence, below. | `[grounded]` dossier R1; "Never held a PM title." |
| R2 | Shipped API or platform products | important | `not_evidenced` | The dossier rates this `adjacent` (`medium`). E2 surfaces delivering the company's APIs to clients, which isn't the same as shipping them. Recall prompt C2. | `[grounded]` dossier R2 |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4 (tools) and E2 (REST API integrations) | `[grounded]` your background |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3: 30+ client integrations run end to end, plus feedback sessions feeding product. That phrase from the posting isn't used about you anywhere. | `[grounded]` your background |
| R5 | Own the roadmap | important | `not_evidenced` | E3 shows you gathered input for the roadmap. The dossier says ownership and prioritisation authority aren't evidenced. Recall prompt C1. | `[grounded]` dossier R1 reasoning |
| R6 | Run discovery with integration partners | important | `not_evidenced` | E3 is the nearest work. This is a named absence, below. | `[grounded]` your background |
| R7 | Write specs and drive delivery with engineering squads | important | `not_evidenced` | Being comfortable in OpenAPI specs doesn't show that you wrote product specs. Recall prompt C2. | `[grounded]` your background |
| R8 | Define adoption metrics | important | `not_evidenced` | Nothing in your background touches this yet. Recall prompt C3. | `[grounded]` your background |

## Recovery per gap

**Recall prompts**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own the roadmap | important | You collected client feedback for product. Nothing shows that you decided what got built, or in what order. | Owning the roadmap is the first responsibility the posting lists. It's also the thing the dossier found missing for R1. | Ranking integration requests that product then followed; deciding the order of playbook or onboarding improvements; turning the session output into a backlog that product adopted | The output document from a session; a backlog you maintained; a note from product citing your input | `[grounded]` dossier R1; `[generic]` platform PM roles usually test prioritisation first |
| C2 | Shipped API products; writing specs | important | 30+ integrations of APIs that already existed, and comfort with OpenAPI. No API change or spec of yours is shown as shipping. | This covers both R2 and R7. It's the gap between delivering APIs to clients and building them. | Writing or changing an OpenAPI spec that engineering built from; an endpoint or field that exists because of something you raised; a requirements document for an integration feature | The spec; a ticket or pull request; release notes naming the change | `[grounded]` dossier R2; `[generic]` interviewers for API roles usually ask about one spec in depth |
| C3 | Define adoption metrics | important | Nothing yet. | Metrics are one of the four responsibilities in the posting. | Tracking time-to-go-live for integrations; counting active API calls per client after go-live; reporting how many clients were onboarded each quarter | A dashboard; a report; a SQL query you wrote for this | `[grounded]` none of your sentences mention metrics; `[generic]` platform PM roles usually report adoption |

**Named absences**
- **R1, 3+ years PM:** You've never held a PM title, and the posting makes 3+ years a must-have. A recall prompt can't change your job title or how long you've held it.
  - C1 is the one thing that could show some of the PM authority behind the requirement.
  - Otherwise, closing the gap means a PM title, inside your current company or elsewhere. Or aim at roles closer to integration work, such as technical PM, partner-solutions PM or integrations PM.
  - The dossier said `conditional_go`, so applying anyway is a reasonable choice. Just know the resume will show adjacent work here, not a match.
- **R6, discovery with integration partners:** Running sessions that collected client feedback for product is input to discovery, not running discovery yourself. Closing it would take one piece of discovery you scoped and led: you set the problem, ran the interviews and wrote up the findings.

## Not written, and why

- **"Product Manager" or "3+ years of product management", and any retitle such as "Technical Product Manager":** You've never held the title, and changing a title is the claim an interviewer checks first.
- **"Owned" or "drove the roadmap":** You gathered input for it. The dossier found no evidence of ownership or prioritisation authority.
- **"Shipped API products" or "built the API platform":** You integrated the company's APIs for clients. Shipping them is a different job.
- **"Ran discovery with integration partners":** "Discovery" and "partners" are the posting's words. Yours are "collecting client feedback" and "client". Changing them would claim work you haven't described.
- **"Stakeholder management", "drove delivery with engineering squads" or "defined adoption metrics" about you:** These are the posting's phrases, and nothing you've written backs them yet.
- **"Wrote API specs":** You said you're comfortable in OpenAPI specs, which isn't the same as having written them.
- **"Built an internal request-triage tool":** This is from the dossier's rejected inferences. It was a memory lead, and you couldn't confirm you owned it.
- **"Has been the customer of a partner API platform":** Also from the dossier's rejected inferences. You worked on the vendor side.

## Parse-safety check

I only have a prose summary, so I couldn't check columns, tables, images, header or footer content, or file type. Section headings: use standard labels (Summary, Experience, Skills) so the rows above land where parsers look for them.

## Upgrade menu

- **Your actual CV as a file (.docx or a PDF with selectable text):** I'd use your real lines as the current lines instead of your summary. It would also let me run the parse-safety checks above and see whether anything should be cut.
- **Answers to C1–C3:** Each answer that holds up after confirmation turns a `not_evidenced` row into a real ledger row.
- **Artifacts:** an excerpt from the playbook, a roadmap-input session write-up, or a spec. These would let me back rows with more than your own description.

## Questions

C1: Did you ever decide what got prioritised, for the product, the playbook or the integration backlog, rather than passing feedback on to someone who decided?

C2: Did engineering ever build or ship something from a spec, API change or requirements document you wrote?

C3: Did you track any numbers on how clients adopted or used the APIs after integration?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.