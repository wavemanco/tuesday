I'm reading the skill's rules on the upgrade menu and the closing block, then I'll write your ledger.
I worked from your pasted background. I treated each sentence you gave me as the current line, since I haven't seen the CV document itself. Your material already covers this JD well: owning services, the p99 cut, on-call and incident command are all direct hits. The ledger mainly moves those to the front, without borrowing the JD's wording to describe your past. It leaves three real gaps open below.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience (current role) | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to first bullet of the current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` cv | pending your approval |
| E2 | Experience (current role) | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` cv | pending your approval |
| E3 | Experience (current role) | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |
| E4 | Experience (current role) | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |
| E5 | Experience (current role) | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year; pair with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` cv | pending your approval |
| E6 | Skills | "Go and Rust daily for 4 years, Python before that." / "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Go and Rust daily for 4 years; Python before that. Also: Kafka, Postgres, Terraform, gRPC, Datadog." | `merge` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` cv | pending your approval |
| E7 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. Own three services in our ledger pipeline; cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer. Ran six incidents as incident commander." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer."; "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |

Notes on these edits:
- **E2:** "about 40k requests/minute at peak" stays attached to *one* service. It isn't spread across all three, and "about" and "at peak" stay in.
- **E3 and E4:** these split your on-call sentence because the JD asks for on-call ownership and incident response as two separate things. "Ran" stays "ran". It doesn't become "led incident response".
- **E5:** this keeps your words, "onboard" and "pair". It doesn't become "mentored". The mentoring gap is handled below instead.
- **E7:** this summary doesn't say the services are written in Go, because you haven't said they are (see C1).

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `not_evidenced` | Backend work is clearly shown for the 4 Go/Rust years. "7 years" is your total, and your material doesn't say whether the Python years were backend. See recall prompt C2. | `[grounded]` cv |
| R2 | Production Go | must-have | `surfaced_by_edit` | E6 and E7 put "Go and Rust daily for 4 years" next to the services you own. Which language those services are written in isn't stated. See recall prompt C1. | `[grounded]` cv |
| R3 | Distributed systems at scale | must-have | `surfaced_by_edit` | E2 and E7: three services in a pipeline, one at about 40k req/min at peak. The JD's phrase "distributed systems" isn't written about you. | `[grounded]` cv |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E4: six incidents as incident commander | `[grounded]` cv |
| R5 | Experience mentoring | must-have | `surfaced_by_edit` | E5, in your words: onboarding and a month of pairing, two or three new hires a year | `[grounded]` cv |
| R6 | Mentor mid-level engineers (responsibility) | important | `not_evidenced` | Your material covers new hires only. See recall prompt C3. | `[grounded]` cv |
| R7 | Drive down p99 latency | important | `surfaced_by_edit` | E1 and E7: 380ms → 95ms on the balance-read path | `[grounded]` cv |
| R8 | Own on-call for your services | important | `surfaced_by_edit` | E3: rotation every fourth week for two years | `[grounded]` cv |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Named absence, below | `[grounded]` cv |

## Gap handling

**Recall prompts**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go | must-have | Go and Rust daily for 4 years, and three services you own. It doesn't say which language any of the services is in. | "Design and ship Go services" is the core of the role, so a reader needs to see Go tied to something you own. | One of the ledger services is in Go; the balance-read cache rework was done in Go; you've shipped other Go code like tooling or a sidecar | A repo, a design doc, a PR history | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on applications of this kind |
| C2 | 5+ years backend | must-have | 7 years as an engineer, 4 of them clearly backend | A years-of-backend requirement is often screened literally, so a reader who counts only 4 years falls short | The Python years were spent building APIs, data pipelines or services | Earlier roles on your CV with their dates | `[grounded]` what the resume shows; `[generic]` literal screening of years |
| C3 | Mentor mid-level engineers | important | A month of pairing with each new hire | The posting describes mentoring people who are past onboarding | Regularly reviewing a mid-level engineer's design docs; being a go-to person on the cache layer; guiding someone through their first incident as commander | A review thread, a design doc you reviewed, a note from a manager or peer | `[grounded]` what the resume shows; `[generic]` how this responsibility tends to be read |

**Named absence: R9, product partnership.** Your material says nothing about working with product or on roadmap planning. If you have done that, mention it next turn and it can become a row. If you haven't, it's listed as a responsibility rather than a requirement, so it isn't worth writing around. An interview answer about how you'd prioritize work on your three services would cover more ground than a resume line.

## Not written, and why

- **"Designed and shipped Go services"**: you said you *own* the services, not that you designed and shipped them, and you haven't said they're in Go.
- **"Distributed systems at scale"**: this is the JD's phrase. Your evidence is the pipeline and the 40k number, and those are what's shown.
- **"Handles 40k requests/minute across three services"**: that number belongs to one service.
- **"Reduced p99 latency by 75%"**: the arithmetic is right, but the raw 380ms → 95ms can be checked and is what you said.
- **"Mentored engineers" or "mentored mid-level engineers"**: you onboard and pair with new hires. Changing the word would change the kind of work.
- **"Led incident response" or "owned on-call"**: you're on a rotation and ran six incidents. Those claims would be bigger.
- **"7 years of backend experience"**: not yet established (see C2).
- **"Partnered with product on roadmap"**: nothing in your material supports it.
- **Kafka, Postgres, Terraform, gRPC, Datadog as areas of expertise**: they're listed tools, and E6 keeps them as a list.

## Parse-safety check

Your background came to me as pasted prose, so I couldn't run any of the layout checks: columns, tables or text boxes, images or skill bars, header and footer content, section headings, file type, or a scan for hidden text. Nothing in the text itself is a parse risk. "380ms → 95ms" and "40k requests/minute" will extract cleanly as plain text.

## Upgrade menu

- **The CV itself, as a .docx or PDF:** your real current lines replace my assumption that your prose sentences are those lines, and the parse-safety and hidden-text checks can actually run.
- **A design doc, postmortem or latency dashboard:** for example, the cache rework write-up or an incident postmortem from when you were commander. Any of these would move the p99 and incident rows from your own account to something inspectable.
- **A `tuesday-dossier.md`, if you have one:** it would bring in verified evidence and claims you've already rejected, instead of my deriving them again.

## Questions

**C1:** Which of your three ledger services are written in Go, and was the balance-read cache rework done in Go?

**C2:** Were the years before Go and Rust (the Python years) backend work, and roughly what did you build?

**C3:** Beyond onboarding new hires, have you regularly mentored engineers who were already past onboarding? For example, reviewing their designs, or being their go-to person on the cache layer or during incidents.

For any of these, answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.