Here's the full ledger. Nothing is applied until you approve it row by row.

You're close on the modelling and dbt side, but this resume can't truthfully claim what the posting puts first. It asks for 3+ years of data engineering, production Python and Airflow or something equivalent. Your own material supports none of those, and rewording won't change that. The ledger leads with what is real (the 25 dbt models, the star schema, the nightly job and its tests), gives each gap a way to close, and lists what I refused to write. If you're unsure the 3+ years requirement is worth applying against, job-underwriter is the skill for that call.

You gave me prose rather than a resume document. So each **Current line** cell holds your own sentence, and I've assumed a plain Summary / Experience / Skills layout.

## Requirements and coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | N1: your title is analyst for all 5 years. The DE-adjacent work is in E1–E4 but isn't DE tenure | `[grounded]` your title and years |
| R2 | Production Python | must-have | `not_evidenced` | C2: "for analysis" plus "some scripting" on a cron. Whether any of it is production is unknown | `[grounded]` |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | C3: "Never used Airflow". It's unknown what schedules the nightly dbt job | `[grounded]` |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E1, E3: star schema for the orders mart, designed with the DE | `[grounded]` |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E1, E2, E6: about 25 dbt models on Redshift | `[grounded]` |
| R6 | Batch pipelines on Spark | important | `not_evidenced` | N2: "Never used … Spark" | `[grounded]` |
| R7 | Own data quality | important | `surfaced_by_edit` | E4: added tests to the nightly job | `[grounded]` |
| R8 | Own SLAs | important | `not_evidenced` | C4: you fix the job when it breaks, but nothing says there's an SLA | `[grounded]` |
| R9 | Partner with analytics on requirements | important | `not_evidenced` | N3: you are analytics, so the resume can't say you partnered with it | `[grounded]` |
| R10 | Streaming / Kafka | preferred | `not_evidenced` | N4: "Never touched Kafka" | `[grounded]` |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years in retail. Built and maintained about 25 dbt models, including the core orders mart. Designed the orders mart's star schema with our then-data engineer." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your prose | pending your approval |
| E2 | Experience | Bullet order: none set | *(wording unchanged. Order: dbt models, star schema, nightly job and tests, Python, SQL)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE."; "I've fixed our nightly dbt job when it breaks and added tests to it."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron."; "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your prose | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-data engineer." | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your prose | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fix the nightly dbt job when it breaks." / "Added tests to the nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your prose | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis (pandas); some scripting to pull vendor APIs on a cron." | `compress` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your prose | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "SQL daily on Redshift, including complex window functions and CTEs." | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your prose | pending your approval |
| E7 | Skills | *(no current line)* | "SQL (Redshift), dbt, Python (pandas), cron" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your prose | pending your approval |

What the audit held in place:
- **"with our then-data engineer"** stays in E1 and E3. You didn't design the schema alone.
- **"about 25"** stays as it is, not "25+".
- **"some scripting"** stays, and **"for analysis"** isn't dropped.
- **"Fix … when it breaks"** stays and does not become "owned pipeline reliability."

## Gap handling

**Recall prompts.** The questions these imply are at the end.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C2 | Production Python | must-have | Python for analysis and some vendor-API scripts on a cron. That doesn't show whether anything downstream depends on them | It's a listed requirement, and analysis-only Python is usually read as different work | The API scripts land data in Redshift tables that dbt models or dashboards read; they're in version control with code review; you added retries, logging or alerts; teammates run or maintain them | The repo or a PR; the table the scripts write to | `[grounded]` what you wrote; `[generic]` how DE screens read "Python for analysis" |
| C3 | Airflow or equivalent orchestration | must-have | No Airflow. A nightly dbt job exists, but not what runs it | It's a listed requirement, and "or equivalent" is the only route in without Airflow | You configured the dbt Cloud job schedule; you set up the cron and its dependencies yourself; you used Dagster, Prefect, Step Functions or Jenkins for scheduled jobs | Job config, a scheduler screenshot, the repo's deploy files | `[grounded]` what you wrote; `[inferred]` from "or equivalent" in the JD |
| C4 | Own SLAs | important | You fix the job "when it breaks". No deadline, alerting or downstream impact is stated | The JD puts SLAs next to data quality as things you'd own | The orders mart has to be ready by a set time for a morning report; you get paged or alerted on failure; you track how often it fails | An alert config, a runbook, an incident note | `[grounded]` what you wrote; `[generic]` what SLA ownership usually means in DE roles |

**Named absences.** None of these can honestly be written. Here's what closing each one would take.

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| N1 | 3+ years data engineering | Your title has been Senior Data Analyst for all 5 years. Wording can't turn that into DE tenure | Three options. (a) Apply anyway and let E1–E4 make the adjacent case in a cover letter or interview, not in the title or years. (b) Aim for "analytics engineer" or junior/mid DE roles where dbt work counts directly. (c) Get a DE title internally, for example by taking over pipelines the then-DE owned | `[grounded]` your title; `[generic]` how tenure requirements are usually screened |
| N2 | Spark | "Never used … Spark." | A real project with Spark (PySpark on a public dataset is fine), listed as a project and not as job experience. Not worth closing for this application alone | `[grounded]` |
| N3 | Partner with analytics on requirements | You've been on the analytics side. Saying you partnered with analytics would flip which side you sat on | Nothing for the resume. In an interview the honest version is that you've been the analyst handing requirements to a DE, as with the star schema | `[grounded]` |
| N4 | Streaming / Kafka | "Never touched Kafka." | It's only a plus here. A small Kafka-to-warehouse side project would make it a project line. Not worth delaying the application for | `[grounded]` |

## Not written, and why

- **"Data Engineer" or "Analytics Engineer" as a title.** You've held neither title. A dbt-heavy job doesn't change that.
- **"5 years of data engineering" / "3+ years DE".** Your years are analyst years.
- **"Built batch pipelines" / "built ETL pipelines".** That's the posting's wording. You built dbt models, and your API scripts are "some scripting".
- **"Production Python".** You didn't say any of it is production. C2 asks.
- **"Orchestrated" or "owned the nightly pipeline".** You fix the job when it breaks, which is a different verb.
- **"Owned data quality and SLAs" / "implemented a data-quality framework".** You added tests to one job.
- **"Designed the warehouse's dimensional model" / "led data modelling".** It was one mart, designed with the then-DE.
- **Airflow, Spark or Kafka anywhere, including the skills list.** You've used none of them. A keyword with no work behind it is the first thing a DE interviewer will ask about.
- **"Partnered with analytics on requirements".** That reverses your side of the relationship (N3).

## Parse-safety check

You pasted prose, so I couldn't check columns, tables, images, headers/footers or file type. The proposed rows use standard section headings (Summary, Experience, Skills). Send the file as a .docx or a PDF with selectable text.

## Upgrade menu

- **Your actual resume file:** gives real current lines, your employer, dates and any bullets you didn't mention, and lets me run the layout checks above.
- **A link to the dbt project or a PR that added the tests:** for this field, a repo is the artifact that turns E2 and E4 from self-report into something checkable.
- **The vendor-API scripts' repo:** the most direct way to settle C2.
- **Any personal or side project with Airflow, Spark or Kafka:** each would become an honest Projects line for N2, N4 or C3.

## Questions

C2: Do the vendor-API scripts feed tables that anything downstream relies on? Are they in version control and reviewed?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: What actually runs the nightly dbt job (dbt Cloud, cron, something else), and did you set any of it up?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C4: When the nightly job breaks, how do you find out, and does it have to be done by a set time for someone?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.