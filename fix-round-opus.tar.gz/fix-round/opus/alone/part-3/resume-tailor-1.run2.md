Priya, I worked from the background you pasted, not from the CV file itself. So in the ledger, each "current line" is one of your own sentences. Nothing below has been changed in your CV yet. Every row is waiting for your approval.

**The short version:** your strongest material for this JD is the p99 cut (380ms → 95ms), owning three services (one at about 40k requests/minute at peak), and six incidents as incident commander. Those should lead. Three must-haves have gaps, and each could be closed by an answer only you can give. Is "production Go" actually production? Your text says you use Go daily but doesn't say what the services are written in. Does your background add up to 5+ years of *backend* work? And have you worked with product on sequencing? I haven't written any of those three in.

## Requirement extraction

- **Must-have:** 5+ years backend; production Go; distributed systems at scale; strong incident response; experience mentoring
- **Important (the role's duties):** Go services handling high request volume; driving down p99 latency; owning on-call for your own services; mentoring mid-level engineers; partnering with product on roadmap sequencing
- **Not material:** the build-cache and developer-tools domain isn't stated as a requirement, so I left it out

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your text | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged apart from E1; moved to first bullet of current role)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your text | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged; moved to second bullet of current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your text | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." / "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your text | pending your approval |
| E5 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | *(incident-commander half of E4 moved to third bullet, directly after the p99 line)* | `reorder` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your text | pending your approval |
| E6 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year — pairing with each for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your text | pending your approval |
| E7 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | Languages line added above it: "Go, Rust (daily for 4 years); Python before that" | `surface` | "Go and Rust daily for 4 years, Python before that." | `[grounded]` your text | pending your approval |
| E8 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. Own three services in a payments company's ledger pipeline — one handles about 40k requests/minute at peak. On-call rotation every fourth week for two years; incident commander on six incidents." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your text | pending your approval |

Some choices in these rows:

- **The 40k figure stays tied to "one" service, at "about" and "at peak."** It is not three services' worth of traffic.
- **E8 doesn't call the services "Go services."** Your text doesn't say what they're written in, and the summary is the line most likely to be read aloud back to you.
- **E6 says "onboard" and "pair," not "mentor."** Your text says onboarding new hires. The JD's "mentoring mid-level engineers" is a different claim.
- **Your title stays "Senior Software Engineer."**

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | not_evidenced | You have 7 years as an engineer and 4 years of Go/Rust alongside owning services. Nothing says the Python years were backend work. See C2 | `[grounded]` your text and the JD |
| R2 | Production Go | must-have | not_evidenced | E7 shows daily Go use, but nothing ties Go to the services you own. See C1 | `[grounded]` your text and the JD |
| R3 | Distributed systems at scale | must-have | surfaced_by_edit | E1, E2, E8: three pipeline services, one at about 40k req/min at peak. Kafka and gRPC appear only in the tools list. The phrase "distributed systems" isn't written as a claim | `[grounded]` your text and the JD |
| R4 | Strong incident response | must-have | surfaced_by_edit | E4, E5: six incidents as incident commander, now its own bullet near the top | `[grounded]` your text and the JD |
| R5 | Experience mentoring | must-have | surfaced_by_edit | E6: first-month pairing with two or three new hires a year. Their level isn't stated, and the word "mentoring" isn't written | `[grounded]` your text and the JD |
| R6 | Services handling high request volume | important | surfaced_by_edit | E1, E2 | `[grounded]` your text and the JD |
| R7 | Drive down p99 latency | important | already_evidenced | Your line already says it. E3 moves it up | `[grounded]` your text and the JD |
| R8 | Own on-call for your services | important | surfaced_by_edit | E4. Whether the rotation covers your own three services isn't stated | `[grounded]` your text and the JD |
| R9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in your text. See C3 | `[grounded]` your text and the JD |

## Gap handling: recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go | must-have | Daily Go and Rust for 4 years, and three owned services. It doesn't say which language the services use. | The JD's first duty is "design and ship Go services," so this is likely the first thing a screener checks. | The 40k req/min service being Go; the cache-layer rework being in Go; any Go service you shipped to production, even if Rust is your main language | A repo or PR link (internal is fine to describe), a design doc naming the stack | `[grounded]` what your text does and does not say; `[generic]` screeners checking the headline language first on roles like this |
| C2 | 5+ years backend | must-have | 7 years total, with Go/Rust plus service ownership for the last 4. The Python years are undescribed. | Without them, the backend work you've shown covers 4 years against a 5+ requirement. | Python APIs or services; data pipelines; backend work at an earlier employer | Earlier role titles and dates, and a line on what you built | `[grounded]` what your text does and does not say; `[generic]` years requirements often being read literally |
| C3 | Partner with product on roadmap sequencing | important | Nothing yet. | It's a named duty, and the gap may just be untold rather than real. | Arguing for the cache rework ahead of feature work; splitting a ledger migration into phases with a PM; pushing back on a launch date for reliability reasons | A planning doc, a roadmap thread, a PM who would describe it | `[grounded]` what your text does and does not say |

## Not written, and why

- **"Senior Backend Engineer" as your title.** That's the posting's title, not yours.
- **"Designed and shipped Go services handling high request volume."** Your text doesn't say the services are in Go, and it says "own," not "designed."
- **"Mentored engineers" or "mentored mid-level engineers."** You onboard and pair with new hires. Mentoring mid-level engineers is a different job, and an interviewer will ask about it.
- **"Built distributed systems at scale."** That's the JD's phrase, and it isn't in your text. The 40k req/min line lets a reader draw their own conclusion.
- **"Owned on-call for my services."** Your text says an on-call rotation, not which services it covers.
- **"Drove down p99 latency across services."** You cut it on one path, the balance-read path. "Drove down" is the JD's verb, and "across services" would widen the scope.
- **"7 years of backend experience."** It isn't established (see C2).
- **"~120k requests/minute across three services."** The figure belongs to one service.
- **"Partnered with product on the roadmap."** Nothing supports it yet (see C3).

## Parse-safety check

You pasted prose, not the CV file, so I couldn't run any of the layout checks: columns, tables or text boxes, icons, header or footer content, section headings, or file type. Share the file and I'll run them. I'll also check for hidden text left behind by a template or an earlier tool.

## Upgrade menu

- **Your actual CV file.** I could run the parse-safety check, and the "current line" cells would quote your real bullets instead of your summary of them.
- **Earlier roles with dates.** These could settle R1 directly.
- **A design doc or write-up for the cache-layer rework.** Engineers keep these, and it would back the p99 claim, which is the line an interviewer is most likely to dig into.
- **A postmortem you wrote as incident commander.** This turns six incidents into a story you can show, not just a count.

## Questions

C1: Are the three ledger services, especially the 40k requests/minute one, written in Go, Rust, or a mix?
C2: Before the payments company, what did you build in Python, and for roughly how long?
C3: Have you worked with a product manager on what got built when for your services, such as making the case for the cache rework ahead of other work?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.