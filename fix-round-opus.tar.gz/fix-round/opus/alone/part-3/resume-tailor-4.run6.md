Sam, I can do the keyword side of this, but keywords probably aren't the main reason you're being rejected. I've put the proposed edits below for your approval, with the reason for each.

**Is keyword matching rejecting you?** The only evidence I have is one vendor's interviews with 25 US recruiters, so treat it as a rough guide:

- **Software rejecting resumes on their content is uncommon.** "We only saw 2 of 25 using it."
- **Match scores mostly decide who gets read first.** "Many teams use match scores/filters to prioritize who gets reviewed first" and "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." In the same sample, "56% either ignore the feature or don't have it available."
- **When a filter rejects with no person involved, it is "almost always" a knockout question.** These are yes/no eligibility checks on the application form, not the resume.

Two other problems are probably bigger than keyword choice:

- **Your layout.** A two-column Canva PDF with icons for skills and contact details in the header is risky for the software that reads resumes. If a skill appears only as an icon, the system sees no word at all. Details are in the parse-safety check at the end.
- **The experience gap.** This posting is built around Kubernetes, GitOps and service mesh. Your evidence is Jenkins, Ansible, EC2 and a Kubernetes proof of concept that never reached production. I can make what you've done easy to find. I can't add Terraform, ArgoCD, Istio, Vault or Go without writing claims you'd have to defend in an interview. Those gaps are listed below with what would close each one.

**What I built this on:** your summary, not the resume itself, so the "Current line" column quotes your own sentences. The posting doesn't rank anything, so the priorities are my reading. The one duty it states, "own platform reliability and developer experience", is treated as the must-have.

---

### Edits for your approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "Python and Bash scripting · AWS (EC2, S3, RDS, IAM) · Docker · Jenkins · Ansible (config management) · CloudWatch (monitoring)", written as plain text, not icons | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your summary | pending your approval |
| E2 | Skills | *(Kubernetes not in skills)* | "Kubernetes (two-month proof of concept; not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your summary | pending your approval |
| E3 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to the first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your summary | pending your approval |
| E4 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | "Ran a two-month Kubernetes proof of concept (2025); it did not go to production." | `reframe` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[inferred]` "last year" read as 2025 from today's date | pending your approval |
| E5 | Summary | *(no current line)* | "DevOps Engineer, 4 years, working with AWS (EC2, S3, RDS, IAM), Docker, Jenkins and Ansible. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your summary | pending your approval |

- **E2 and E4** put the word "Kubernetes" where screening software can find it, and keep "not in production" attached. Without that, you'd be claiming production Kubernetes experience.
- **E5** keeps your title as DevOps Engineer. It is not changed to Platform Engineer.

### Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Own platform reliability and developer experience | must-have | `not_evidenced` | Recall prompt C3. Maintaining about 30 Jenkins jobs is related work, but it isn't reliability ownership. | `[grounded]` your summary; `[inferred]` priority |
| M2 | Kubernetes | important | `surfaced_by_edit` | E2, E4. Proof of concept only, which a reader will see. | `[grounded]` your summary |
| M3 | AWS EKS | important | `not_evidenced` | Recall prompt C1. AWS is evidenced; EKS is not. | `[grounded]` your summary |
| M4 | Helm | important | `not_evidenced` | Recall prompt C1 | `[grounded]` your summary |
| M5 | CI/CD (pipeline building) | important | `surfaced_by_edit` | E3. A deploy pipeline is evidenced. Whether it also ran builds and tests (the "CI" part) is asked in C2. | `[grounded]` your summary |
| M6 | GitLab CI | important | `not_evidenced` | Recall prompt C2 | `[grounded]` your summary |
| M7 | Python | important | `surfaced_by_edit` | E1 | `[grounded]` your summary |
| M8 | Terraform | important | `not_evidenced` | Named gap below | `[grounded]` your summary |
| M9 | GitOps / ArgoCD | important | `not_evidenced` | Named gap below | `[grounded]` your summary |
| M10 | Observability (Prometheus, Grafana) | important | `not_evidenced` | Named gap below. CloudWatch monitoring is related but is not this stack. | `[grounded]` your summary |
| M11 | Service mesh (Istio) | important | `not_evidenced` | Named gap below | `[grounded]` your summary |
| M12 | Vault | important | `not_evidenced` | Named gap below | `[grounded]` your summary |
| M13 | SRE practices | important | `not_evidenced` | Recall prompt C3 | `[grounded]` your summary |
| M14 | Go | important | `not_evidenced` | Named gap below | `[grounded]` your summary |

### Gaps where you may have something I don't know about

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS and Helm | important | A two-month Kubernetes proof of concept. Nothing about where it ran or how it was deployed. | Kubernetes on EKS is the core of this platform. | The proof of concept ran on EKS; you installed or wrote Helm charts; you wrote Kubernetes manifests for a real service | Repo, notes or a design doc from the proof of concept | `[grounded]` your summary; `[generic]` what it costs on platform roles |
| C2 | CI/CD with GitLab | important | A Jenkins deploy pipeline and about 30 Jenkins jobs. | The posting names GitLab as its CI/CD tool. | Some Jenkins jobs run builds or tests; you've used GitLab CI anywhere, including side projects or a migration trial | A `.gitlab-ci.yml` or a Jenkinsfile | `[grounded]` your summary; `[generic]` cost of a tool mismatch |
| C3 | Platform reliability and SRE practices | must-have | Monitoring with CloudWatch. No incidents, on-call, alerting or uptime work stated. | It is the one duty the posting spells out. | On-call rotation; CloudWatch alarms you set up; an outage you handled; pipeline work that reduced failed deploys | An alert config, a postmortem, a runbook | `[grounded]` your summary; `[inferred]` must-have from the posting's wording |

**Gaps your summary doesn't cover at all, and what would close each:**
- **Terraform:** no infrastructure-as-code tool is mentioned. Ansible is configuration management, which is a different kind of work. Closing it would take a real Terraform module for your own AWS resources, at work or in a public repo.
- **GitOps / ArgoCD:** there's nothing to build on, because the proof of concept never reached production. A public repo with ArgoCD syncing a small app onto a cluster would close it partly and honestly.
- **Prometheus / Grafana:** CloudWatch is not this stack. Instrumenting a service with Prometheus and building a Grafana dashboard, even in a lab, would be evidence of it.
- **Istio / Vault:** this is specialist work and probably not worth closing just for this application. List it as "learning", or leave it out.
- **Go:** no Go is mentioned. A small Go tool, such as a CLI or a Kubernetes operator, would be the evidence.

### Not written, and why

- **"Platform Engineer"** as your title: you were a DevOps Engineer. Changing the title is an upgrade, not an equivalent.
- **"Kubernetes experience" without the proof-of-concept qualifier, or "deployed services on Kubernetes":** it never went to production.
- **"Infrastructure as Code (Ansible)":** this would quietly turn config management into the Terraform-style work the posting wants.
- **"Observability" for your CloudWatch monitoring:** that's the posting's word, not yours.
- **"CI/CD pipelines" in your experience bullet:** you wrote "deploy pipeline". This waits on C2.
- **"Owned platform reliability" or "SRE":** nothing you've told me supports it yet. This waits on C3.
- **Terraform, ArgoCD, Istio, Vault, Prometheus, Grafana or Go in your skills list:** listing them would be claiming tools you haven't said you used.

### Parse-safety check (from your description; I couldn't open the file)

| Check | Finding | What it costs |
|---|---|---|
| Multi-column layout | Two columns | Software that reads left to right can mix the columns together and separate dates from the jobs they belong to |
| Icons for skills | One icon per skill | If a skill appears only as an icon, it is invisible to keyword matching. Any keyword can be lost this way. |
| Contact details in header | Present | Some software treats headers as page furniture and drops them, so you could be unreachable |
| Canva PDF text layer | Couldn't check | If the text was exported as an image or outlines, nothing is readable by software |
| Hidden text from a template | Couldn't check | Some templates carry invisible text you didn't write |
| Section headings | Couldn't check | Unusual headings may not be recognised as "Experience" or "Skills" |

These are reading risks only. I'm not suggesting a redesign.

Separately, whether this role is worth applying for given the gap, and whether any knockout questions would stop you, is a job for the job-underwriter skill.

---

**Upgrade menu**
- **The resume text or the PDF:** gives each row your exact current lines and lets me run the three checks above that I couldn't.
- **Proof-of-concept material** (a repo, notes or diagrams): could turn C1 into real Kubernetes, EKS or Helm lines.
- **Answers to the questions below:** each one can change a gap row into an edit.

**Questions**

C1 — In the Kubernetes proof of concept, where did the cluster run (EKS or something else), and did you use Helm or write manifests yourself?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Do any of your roughly 30 Jenkins jobs run builds or tests as well as deploys, and have you used GitLab CI anywhere?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Have you been on call, set up CloudWatch alarms, or handled a production incident? If so, what happened and what was your part?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.