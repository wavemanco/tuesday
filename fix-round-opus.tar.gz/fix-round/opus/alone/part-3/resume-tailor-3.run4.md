Need to read references. Let me read them in parallel.
I've read the dossier you attached. It's for this same Quartzline role, so I've used its `role_profile`, `evidence_map` (R1, R2), its pending edit E1 and its `rejected_inferences`. I've ignored its `conditional_go` decision, because whether to apply is job-underwriter's question, not mine.

**What I built this on:** you gave me your CV as six sentences, not the document itself. I've treated each sentence as a line of your CV and quoted it word for word. Where a row says "current line", that is your sentence as you typed it here. Check it against your real CV before approving.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (part of your role description) | "Wrote the internal integration playbook the whole team uses." as its own bullet, second in the role | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV as described; inherited from dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV as described | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to third bullet, directly under E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV as described | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Technical: comfortable in Postman, SQL, OpenAPI specs" as its own Skills line | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV as described | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end, and wrote the internal integration playbook the whole team uses." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV as described | pending your approval |

Notes on what these rows keep:
- **E1:** it says "the whole team", not "company-wide".
- **E2:** "30+" still counts integrations. "Our REST APIs" still means your company's APIs, not APIs you built.
- **E3:** the wording is unchanged on purpose. "Collecting client feedback for product" means you fed the roadmap. It does not mean you owned it, and moving it up is the only change.
- **E4:** it keeps "comfortable in". Turning it into a bare tool list would drop the level you gave yourself.
- **E5:** it keeps your title as you wrote it, with no "product" anywhere.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | The dossier rated this adjacent: a transferability gap, medium confidence, with roadmap ownership and prioritisation authority not evidenced. E3 and E5 put the adjacent work up front; recovery is C1 | `[grounded]` dossier R1 and your "Never held a PM title" |
| R2 | Shipped API or platform products | important | `not_evidenced` | The dossier rated this adjacent at medium confidence. Leading integrations of your company's APIs is different work from shipping them. E1 and E2 put the adjacent work up front; recovery is C2 | `[grounded]` dossier R2 and CV |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4, supported by E2 | `[grounded]` CV |
| R4 | Stakeholder management | important | `not_evidenced` | "End to end" suggests coordination but doesn't say who with; recovery is C3 | `[grounded]` CV |
| R5 | Run discovery with integration partners (from the responsibilities) | important | `not_evidenced` | E3 is the nearest evidence: collecting feedback, not running discovery. Covered by C1 | `[grounded]` CV |
| R6 | Write specs and drive delivery with two engineering squads (from the responsibilities) | important | `not_evidenced` | Named absence N1 | `[grounded]` CV |
| R7 | Define adoption metrics (from the responsibilities) | important | `not_evidenced` | Named absence N2 | `[grounded]` CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM: roadmap ownership and prioritisation | must-have | You collected client feedback for product every quarter. It doesn't show that you decided what got built or in what order | It's the posting's only must-have, and a titled-years requirement is likely screened literally | You chose which feedback from the sessions went forward and how it was ranked; you set priorities for the integration backlog; you ran a discovery-style session yourself, not just collected input | A roadmap-input summary you wrote; a prioritised backlog; a product decision that cites your input | `[grounded]` what the CV says; `[inferred]` literal screening of titled years |
| C2 | Shipped API or platform products | important | You integrated your company's REST APIs for clients. It doesn't show changes to the APIs themselves | It's the core of a Platform APIs role, and "led integrations" and "shipped the API" read as different jobs | You wrote or edited an OpenAPI spec for a new endpoint; an integration need you raised became a shipped API change; the playbook changed how the API was exposed to clients | An OpenAPI diff, a change request, release notes naming your input | `[grounded]` what the CV says; `[generic]` how PM screens tell integration work from platform work |
| C3 | Stakeholder management | important | "Led … end to end" doesn't name who you were coordinating or what you were accountable for | Two engineering squads plus external partners is a coordination-heavy setup | You coordinated client engineers, your own engineering team and account managers; you were accountable for go-live; you handled scope disputes | A project plan, go-live sign-off emails, a client reference | `[grounded]` what the CV says; `[generic]` what this coordination usually involves |

**Named absences:**
- **N1 – specs and delivery with engineering squads.** Nothing you've told me shows you writing product specs or driving an engineering team's delivery. Being comfortable in OpenAPI specs isn't authorship. **To close it:** if you've ever written a spec that engineers built from, that would count. If not, this gap belongs in a cover letter or interview, framed as adjacent experience, not on the resume.
- **N2 – adoption metrics.** Nothing shows you defining or tracking product metrics. **To close it:** if your integration work tracked anything (time to go-live, activation, API call volumes after launch), tell me and it becomes a row. If not, it isn't worth closing for this application; it's one responsibility line, not a listed requirement.

## Prohibited claims: not written, and why

- **"Product Manager" or "product management experience".** You have never held the title, and the posting's one must-have depends on it. E5 keeps your actual title.
- **"Owned" or "contributed to" the roadmap.** You "ran quarterly roadmap-input sessions collecting client feedback for product." That means feeding someone else's roadmap, which is the one gap the dossier already named.
- **"Ran discovery with integration partners".** That is the posting's wording; I won't use it to describe your history.
- **"Partners" in place of "clients".** It's the posting's word. A client relationship and an integration partnership are different commercial relationships, and an interviewer will ask which you had.
- **"Shipped / built REST APIs" or "API product experience".** You led integrations of "our REST APIs", which is a different kind of work.
- **"Wrote API specs".** "Comfortable in … OpenAPI specs" doesn't say you authored any.
- **"Drove delivery with engineering", "defined adoption metrics", "stakeholder management" as stated claims.** None of these are in your material.
- **"Led a team" from "implementation lead".** Your title says nothing about team size, and unclear wording is read as the smaller claim.
- **From the dossier, unchanged:** "built an internal request-triage tool". That came from a memory lead, and you couldn't confirm you owned it.
- **From the dossier, unchanged:** "has been the customer of a partner API platform". You worked vendor-side, so this would put you on the wrong side of the relationship.

## Parse-safety check

You pasted your CV as prose, so I couldn't check layout. That means none of these could run: columns, tables and text boxes, images or skill bars, content in headers or footers, section heading labels, file type, or hidden text left by a template. If you send the actual file (a `.docx` or a PDF with selectable text), I'll run them. E4 and E5 use standard section names ("Skills", "Summary").

## Upgrade menu

- **Your actual CV file.** It lets me quote your real current lines instead of my reading of your summary, and lets the parse-safety check run.
- **The integration playbook itself, or a redacted excerpt.** E1 would go from a claim to an inspectable sample, and it may support C2.
- **Any spec, change request or roadmap-input write-up you authored.** It's the single thing most likely to turn R1 or R2 into evidence.
- **Any numbers your integration work tracked.** They would close N2.

## Questions

C1 — Did you ever decide what went on the roadmap or in what order, for example choosing which feedback from the roadmap-input sessions went forward? Or did product make those calls after you handed it over?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did any of your work change the APIs themselves, for example by editing an OpenAPI spec for a new endpoint, or by raising an integration need that became a shipped change?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Across the 30+ integrations, who were you coordinating, and were you the one accountable for go-live?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.