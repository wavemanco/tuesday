I've drafted the edits below, but nothing is changed yet. I only had the summary you typed in your message, not the CV itself. So every edit is based on your own sentences, quoted exactly, and the "Current line" column is blank because I haven't seen your real wording. I assumed your CV says these things in about the order you listed them.

**The short version:** the strong points are already true and line up with this JD: the p99 drop, six incidents as incident commander, and 40k requests/minute. Most of the work is moving them up the page. There are three gaps I won't write around, because your CV doesn't show them:
- **Production Go:** you use Go daily, but you never said your three services are written in Go.
- **Mentoring mid-level engineers:** what you describe is onboarding new hires.
- **Partnering with product on the roadmap:** nothing in your CV covers it.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(not seen)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in the ledger pipeline at a payments company." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Currently at a payments company." | `[grounded]` your message | pending your approval |
| E2 | Experience (current role) | *(not seen)* | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." *(unchanged, moved to first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |
| E3 | Experience (current role) | *(not seen)* | "Own three services in the ledger pipeline; one handles about 40k requests/minute at peak." *(moved to second bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E4 | Experience (current role) | *(not seen)* | "Ran six incidents as incident commander." / "On-call rotation every fourth week for two years." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E5 | Experience (current role) | *(not seen)* | "Onboard new hires on my team, usually two or three a year, pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your message | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Python · Kafka, Postgres, Terraform, gRPC, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your message | pending your approval |

Some notes on these:
- **E3:** the line doesn't say "Go services" because you didn't say it (see C1 below).
- **E4:** this splits one line into two so "incident commander" gets its own bullet. The JD's "strong incident response" is what you'll be screened on, and your six incidents are the evidence.
- **E5:** this keeps the word "onboarding" and doesn't turn it into "mentoring."
- **E1:** "about 40k" stays "about," and "Python before that" stays in the past tense.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years of experience | must-have | `already_evidenced` | "Senior Software Engineer, 7 years" | `[grounded]` |
| R2 | …and that experience is backend | must-have | `not_evidenced` | The three services show backend work now. Whether the Python years were backend isn't stated. See C3 | `[grounded]` |
| R3 | Go, used daily | must-have | `surfaced_by_edit` | E1, E6 | `[grounded]` |
| R4 | Go **in production** | must-have | `not_evidenced` | The services' language isn't stated. See C1 | `[grounded]` |
| R5 | High request volume | must-have | `surfaced_by_edit` | E3. This is the concrete number, not the label "distributed systems at scale" | `[grounded]` |
| R6 | Drive down p99 latency | important | `surfaced_by_edit` | E2 | `[grounded]` |
| R7 | Incident response / on-call | must-have | `surfaced_by_edit` | E4 | `[grounded]` |
| R8 | Mentoring (the JD says mid-level engineers) | must-have | `not_evidenced` | Related onboarding work is in E5. See C2 | `[grounded]` |
| R9 | Partnering with product on roadmap sequencing | important | `not_evidenced` | See C4 | `[grounded]` |
| R10 | Owning services | must-have | `surfaced_by_edit` | E3 ("I own three services") | `[grounded]` |

## Gaps, and what would close them

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go | must-have | That you use Go and Rust daily, and that you own three services. It doesn't say the services are in Go. | The JD's first duty is "design and ship Go services." If your 40k/min service is in Go, that's your strongest line. If it's in Rust, it still counts but reads differently. | The 40k/min service, the balance-read cache rework, or any Go service you deployed and were on-call for | Repo, design doc, deploy pipeline | `[grounded]` what your CV says and doesn't say; `[generic]` that a reader won't assume the language |
| C2 | Mentoring | must-have | Onboarding two or three new hires a year, with a month of pairing each | "Mentor mid-level engineers" is a different kind of work from onboarding new hires. An interviewer will ask about it. | A longer mentoring relationship, design-review coaching, helping someone toward a promotion, guiding a mid-level engineer through owning a service or running an incident | Promotion packet, feedback someone wrote about you, onboarding doc you wrote | `[grounded]` what your CV says; `[generic]` that interviewers probe mentoring scope |
| C3 | 5+ years of backend | must-have | 7 years as a software engineer, 4 of them using Go and Rust daily. What the Python years were isn't stated. | If the Python years were backend, you clear the bar easily. If they weren't, the backend years come from Go only. | Python APIs, data pipelines, or services before you moved to Go | The old role's title or bullets | `[grounded]` |
| C4 | Partnering with product on the roadmap | important | Nothing | It's one of the duties listed, but not a stated requirement | Agreeing the order of the cache rework with a PM, pushing back on scope, deciding which service work came first | Planning doc, RFC | `[grounded]` that it's absent; `[generic]` that it's often weighted below the hard requirements |

I'm holding C4's question for a later turn so this one stays within three questions.

## Not written, and why

- **"Designed and shipped Go services handling 40k requests/minute"**: you didn't say what language the services are in, or that you designed them. You said you own them.
- **"Distributed systems at scale"** about your own work: this is the JD's phrase. Your words are "three services in our ledger pipeline" and "40k requests/minute," and those are what an interviewer can check.
- **"Mentored engineers" / "mentored mid-level engineers"**: what you describe is onboarding and pairing with new hires for a month. Changing the word changes the kind of work and who it was for.
- **"Owned on-call for my services"**: you described a rotation every fourth week. You didn't say whether it covered your three services specifically.
- **"Led incident response"**: you ran six incidents as incident commander. I kept that exact claim instead of a broader one.
- **"Built with Kafka and gRPC"**: these appear in your tools list, and a tool listed isn't a tool you owned something with.
- **"Partnered with product on roadmap sequencing"**: nothing supports it yet.
- **"7 years of backend experience"**: your CV says 7 years as a software engineer, which isn't the same thing.

## Parse-safety check

You sent text, not a file, so I couldn't check layout: columns, tables, text boxes, icons or skill bars, contact details in headers or footers, file type, or any hidden text left over from a template. To be safe, send a .docx or a PDF that has a real text layer, and use standard headings like Summary, Experience and Skills.

## What would make this stronger

- **Your actual CV text or file:** I could fill in real current lines, quote you exactly against them, and run the layout checks.
- **Answers to C1–C3:** each could turn a gap into an edit you can stand behind. C1 matters most.
- **One document from the cache rework or one of the six incidents** (design doc, postmortem): it would give you more detail to put in E2 and E4.

## Questions

C1 — What language are the three ledger services written in? In particular, the one handling about 40k requests/minute.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Apart from the first month of pairing with new hires, have you guided any engineer over a longer period? For example through a design, a promotion, or running an incident?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Were the Python years before Go spent on backend work?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.