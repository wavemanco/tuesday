I've read the skill's rules. Here is the full ledger. Nothing has been changed in your CV yet.

I used the dossier because it's for the same Quartzline role. Its evidence-map judgments carry over as they were (R1 and R2 are adjacent, medium confidence). Its pending edit E1 is ledger row E1 below and went through the same checks as the others. Both rejected inferences are in the "not written" list. You gave me your CV as a short prose summary, so I've treated each sentence as a line in the CV. The "Current line" cells quote those sentences. If the real CV words them differently, send it and I'll re-trace every row.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." *(as its own bullet)* | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` cv; dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to the second bullet)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |
| E4 | Summary | *(no current line)* | "7 years as solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |
| E5 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved directly below the summary)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` cv | pending your approval |

What these rows hold back from:
- **E1** keeps "the whole team". It doesn't become "company-wide" or "adopted across the org".
- **E2** keeps "our REST APIs". You worked for the company that sold the API, and that side of the table stays as it was. "30+" still counts integrations.
- **E3** keeps "for product". You collected feedback for the product team. You didn't own the roadmap.
- **E4** keeps your three sentences separate so they don't blend into one larger claim. It keeps your title exactly as you wrote it, slash included, rather than guessing whether you held both titles at once.
- **E5** keeps "Comfortable in". Cutting it would make the line claim more than you did.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Dossier: adjacent, transferability gap, medium confidence. Integration leadership is adjacent work; roadmap ownership and prioritisation authority aren't evidenced. E3 and E4 show the adjacent work. Recall prompt C1 | `[grounded]` dossier evidence_map R1 |
| R2 | Shipped API or platform products | must-have | `not_evidenced` | Dossier: adjacent, medium. You integrated clients onto your company's APIs; nothing says you shipped them. E2 puts the adjacent work first. Recall prompt C2 | `[grounded]` dossier evidence_map R2 |
| R3 | Technical fluency | must-have | `already_evidenced` | "Comfortable in Postman, SQL, OpenAPI specs" together with the 30+ REST integrations. E5 moves it up | `[grounded]` cv |
| R4 | Stakeholder management | must-have | `surfaced_by_edit` | E3 and E4: client feedback carried to product, and integrations led end to end. Shown through what you did, never with the JD's phrase | `[grounded]` cv |
| R5 | Discovery with integration partners | important | `surfaced_by_edit` | E3 is the nearest evidence (client feedback sessions). It's adjacent: collecting feedback for product isn't the same as running discovery | `[grounded]` cv |
| R6 | Write specs | important | `not_evidenced` | Being comfortable with OpenAPI specs is a tool skill. It isn't spec authorship. Recall prompt C2 | `[grounded]` cv |
| R7 | Drive delivery with engineering squads | important | `not_evidenced` | Named absence below | `[grounded]` cv |
| R8 | Define adoption metrics | important | `not_evidenced` | Recall prompt C3 | `[grounded]` cv |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM (roadmap ownership) | must-have | You fed roadmap input to product. Nothing shows you decided what got built or in what order. | It's the first must-have, and with no PM title a screener has nothing to count. A titled-years requirement is often screened literally. | You decided which client requests went into the quarterly input and which were dropped; a feature your sessions surfaced that product then shipped; you set the order of integration work across clients | A feedback summary you gave product, a prioritised request list, a roadmap slide that cites your input | `[grounded]` what the CV says; `[generic]` how titled-years requirements are screened |
| C2 | Shipped API products / write specs | must-have | You integrated onto the APIs. Nothing shows you shaped them or wrote spec documents. | A platform-API PM role reads this as the core of the job. | You proposed an endpoint or field change that engineering made; you wrote or edited OpenAPI definitions; you wrote requirements docs for integration features | A spec or API definition you wrote, a ticket or PR comment, a changelog entry crediting you | `[grounded]` what the CV says; `[generic]` how platform PM roles weigh this |
| C3 | Define adoption metrics | important | There are no metrics anywhere in your material. | Measuring adoption is one of the listed responsibilities. | You tracked time-to-integrate or go-live dates across the 30+; you measured whether the playbook cut onboarding time; you reported API usage per client | A dashboard, a SQL query you wrote for reporting, a QBR slide | `[grounded]` what the CV says; `[generic]` what metric ownership usually looks like |

**Named absence, R7 (drive delivery with engineering squads):** nothing in your material mentions working with engineering teams. If your answer to C2 involves engineering, this row can change. If it doesn't, an interviewer will probe this. One concrete delivery example would close it, such as a fix or feature you coordinated with engineers from request through to release.

## Not written, and why

- **"Product management experience" or "Product Manager"**: you've never held the title, and R1 is a must-have. The adjacent work is in E3 and E4, and the gap is named in the map.
- **"Owned the roadmap" or "drove roadmap prioritisation"**: you ran input sessions *for* product. Owning a roadmap is a different job.
- **"Shipped / built our REST APIs"**: you led integrations onto them. Building them would change what kind of work you did.
- **"Ran discovery with integration partners"**: the posting says "partner" and "discovery"; you wrote "client" and "collecting feedback". Swapping in the JD's words would change what you did and whose side you were on.
- **"Wrote API specs"**: "Comfortable in … OpenAPI specs" doesn't say you wrote them. That stays open as C2.
- **"Drove delivery with engineering squads"** and **"defined adoption metrics"**: nothing in your material supports either.
- **"Built an internal request-triage tool"**: rejected in the dossier. It came from memory and you couldn't confirm ownership.
- **"Was a customer of a partner API platform"**: rejected in the dossier. You worked on the vendor side.

## Parse-safety check

Your CV arrived as pasted prose, so I couldn't check layout. That means columns, tables or text boxes, images or skill bars, header and footer content, section headings and file type are all unchecked, and so is hidden text left by a template. Send the file and these checks will run.

## Upgrade menu

- **Your CV file:** the parse-safety check runs, and every trace quotes your actual lines instead of my reading of a summary.
- **The integration playbook, or a redacted excerpt:** something a reader can inspect for E1, which makes E1 stronger.
- **An output from a roadmap-input session**, such as a summary you sent to product: the artifact most likely to move R1 and R5 from adjacent toward direct evidence.
- **Optional extra (not part of the ledger):** a short line for your application explaining the move from solutions engineering to PM, built only from approved rows. I'd write it only if you want it, because R1 is where a screener is most likely to stop.

## Questions

**C1:** Did you ever decide what went into the roadmap input, or what order the work was done in? Did anything from those sessions ship?
**C2:** Did you ever shape the APIs themselves, for example by proposing changes, editing OpenAPI definitions or writing requirement docs? Was engineering involved?
**C3:** Did you track or report any numbers across the integrations, such as time to go live, usage, or playbook impact?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.