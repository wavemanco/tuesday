I can't make this resume show 3+ years of data engineering, and I didn't try. That requirement is a must-have and your 5 years are as a Senior Data Analyst. Your strongest real overlap is the warehouse work: about 25 dbt models, the core orders mart and its star schema. That goes first. Production Python, orchestration and SLAs aren't covered by anything you've told me yet. The three questions at the end could change that. Whether the missing years make this posting worth applying to is a separate call, which the job-underwriter skill handles.

I worked from your pasted background, not a resume file, so the "current line" for each row is your own sentence.

## Proposed edits (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Header | "Senior Data Analyst, 5 years, retail." | "Senior Data Analyst — Retail · 5 years" | `compress` | "Senior Data Analyst, 5 years, retail." | `[grounded]` your background | pending your approval |
| E2 | Summary | *(no current line)* | "Senior Data Analyst, 5 years in retail, moving from analytics into data engineering. Built and maintained about 25 dbt models, including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics"; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your background | pending your approval |
| E3 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged; made the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your background | pending your approval |
| E4 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our data engineer at the time" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your background | pending your approval |
| E5 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fix our nightly dbt job when it breaks; added tests to it" | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your background | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "Write SQL every day on Redshift — complex window functions and CTEs" | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your background | pending your approval |
| E7 | Skills | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis (pandas)" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your background | pending your approval |
| E8 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Wrote some scripts to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your background | pending your approval |
| E9 | Skills | *(no current line)* | "SQL (Redshift) · dbt · Python (pandas) · cron" | `merge` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your background | pending your approval |

Notes:
- **E4** keeps "with". You designed the schema together with an engineer, not alone.
- **E5** keeps "when it breaks". It's an honest description of maintenance, not ownership.
- **E8** leaves out "Python" because your sentence doesn't say for sure the scripts were Python. It also keeps "some", because cutting it would make the claim bigger.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | not_evidenced | Named absence N1. Your 5 years are in a Senior Data Analyst role | `[grounded]` your background |
| R2 | Production Python | must-have | not_evidenced | E7 and E8 show Python for analysis and scripts on a cron. Whether those scripts were production code is recall prompt C2 | `[grounded]` your background |
| R3 | Airflow or equivalent orchestration | must-have | not_evidenced | Cron (E8) and a nightly dbt job (E5) are scheduling, but they don't show orchestration. Recall prompt C1 | `[grounded]` your background |
| R4 | Dimensional modelling | must-have | surfaced_by_edit | E4: the star schema for the orders mart, co-designed | `[grounded]` your background |
| R5 | Model the warehouse | important | surfaced_by_edit | E3 and E4: about 25 dbt models and the orders mart. They cover part of a warehouse, not the whole warehouse | `[grounded]` your background |
| R6 | Build and own batch pipelines | important | not_evidenced | E5 shows you fix the nightly job. Building or owning a pipeline isn't stated. Recall prompt C1 | `[grounded]` your background |
| R7 | Own data quality | important | surfaced_by_edit | E5: added tests to the nightly dbt job | `[grounded]` your background |
| R8 | Own SLAs | important | not_evidenced | Nothing stated about deadlines or delivery guarantees. Recall prompt C3 | `[grounded]` your background |
| R9 | Spark | important | not_evidenced | Named absence N2. You said "Never used Airflow or Spark." | `[grounded]` your background |
| R10 | Streaming (Kafka) | preferred | not_evidenced | Named absence N3. You said "Never touched Kafka." | `[grounded]` your background |
| R11 | Partner with analytics on requirements | important | surfaced_by_edit | E4: you worked with a data engineer on the schema, but from the analytics side of that partnership | `[grounded]` your background |

## Gap handling

**Recall prompts.** Each one is asked as a question at the end.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration; build and own batch pipelines | must-have | A nightly dbt job you fix, and scripts on a cron. No scheduler, dependencies or retries are named. | Orchestration is a must-have here. Screeners for DE roles usually read "cron" as weaker than a named orchestrator. | The nightly job runs on dbt Cloud, Dagster, Prefect or something similar, and you configured it; the vendor pulls must finish before dbt starts; you set up retries or failure alerts | The job config, a scheduler screenshot, a repo | `[grounded]` what you said; `[generic]` how screeners read cron |
| C2 | Production Python | must-have | Python "for analysis" and "some scripting" to pull vendor APIs | This is a must-have, and analysis Python in notebooks is the usual reason analysts get screened out of DE roles | The scripts run unattended and land tables that your dbt models read; they have logging, error handling, pagination or rate-limit handling; how many vendors they cover; they live in version control | A repo, a script, a README | `[grounded]` what you said; `[generic]` how this requirement is screened |
| C3 | Own SLAs | important | Nothing stated | SLA ownership is one of the posting's core duties | The nightly job had a deadline, such as dashboards ready by a set time; you were the person paged or messaged when it broke; you tracked freshness or tests that failed | A runbook, an alert config, a Slack channel | `[grounded]` what you said; `[generic]` what SLA evidence usually looks like |

**Named absences.** These are things nothing you've said can cover.

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| N1 | 3+ years data engineering | You have zero years in a data engineering title. Real pipeline work found through C1–C3 would strengthen your bullets, but it stays analyst-titled experience. | An internal move into a DE or analytics-engineering title. Or target roles that ask for dbt and warehouse modelling rather than 3+ years of DE. If the application form asks your years of DE experience, answer it literally. | `[grounded]` your title; `[generic]` how roles like this are screened |
| N2 | Spark | You've never used it | The posting names it in its duties, not in its requirements. A small, real project would let you list it honestly. Until then it stays off the resume. | `[grounded]` "Never used Airflow or Spark." |
| N3 | Streaming / Kafka | You've never touched it | The posting lists it as a plus, so it isn't worth chasing for this application. A built side project could appear later, labelled as a project. | `[grounded]` "Never touched Kafka." |

## Claims I didn't write, and why

- **"Data Engineer" or "Analytics Engineer" as a title.** Your title is Senior Data Analyst. Changing it is an upgrade, not an equivalent.
- **"3+ years of data engineering experience."** It isn't true. Stating it on the resume or the form fails the first reference check.
- **Airflow, Spark, Kafka or "streaming" in your skills list.** You said you've never used them. Listing a tool that's absent from your experience is the claim an interviewer checks first.
- **"Owned the nightly dbt pipeline" / "Owned data quality and SLAs."** You fix the job when it breaks and you added tests. Ownership is a different job, and "owned" is the posting's word, not yours.
- **"Built production data pipelines in Python."** That's pending C2. Right now your own word is "scripting".
- **"Modelled the warehouse" / "Designed the star schema" with "with" removed.** You designed it for the orders mart, with your then-DE.
- **"Partnered with engineering on requirements."** "Partner" is the posting's word. Yours is "designed … with".
- **"Dimensional modelling" as a keyword.** It's the JD's term. "Star schema" is your own, more specific term. If you want the JD's term added, say so in your own words and it becomes a new row that gets checked like the others.
- **"25+ dbt models."** You said "about 25". Changing it to "25+" moves the claim upward.
- **Any metric** (runtime cut, failures reduced, data volume). You haven't given any.

## Parse-safety check

You pasted prose, not a file, so I couldn't check columns, tables, text boxes, images, headers/footers, file type or hidden text. If you send the actual resume as a .docx or a PDF with selectable text, I'll run those checks.

## What would unlock more

- **Your current resume file:** real current lines to edit, plus the parse-safety and hidden-text checks.
- **The dbt project, or a screenshot of its DAG:** stronger evidence for E3–E5, and possibly for R6.
- **The vendor-API scripts in a repo:** could turn C2 into a solid row.
- **Something you've already built with Airflow or Kafka, if it exists:** a project line that's honestly labelled as a project.

## Questions

C1: What actually schedules the nightly dbt job and the vendor-API cron scripts, and did you set up any of it yourself, such as dependencies, retries or failure alerts?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Do those vendor-API scripts run on their own and load tables your dbt models depend on, and roughly how many vendors do they cover?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Did the nightly job have to be done by a set time for someone downstream, and were you the person who got told when it missed?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.