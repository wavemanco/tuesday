I've read the skill's rules and built the edit ledger from your notes. Nothing below is applied yet. Every row waits for your approval, and each one quotes the sentence of yours it comes from.

**What I assumed:** you gave me prose, not a resume file, so there are no current lines and every row starts from *(no current line)*. Your employer's name and your dates aren't in your notes, so I left them out rather than make them up.

**How it reads:** your strongest evidence for this posting is the dbt work, the orders-mart star schema and the nightly-job tests. The ledger puts those first. Five of the JD's requirements (rows R1, R3, R6, R7, R8 in the coverage map) can't be written from what you've told me. They're handled as gaps below, not as hedged lines. The 3+ years of data engineering is the hardest one. Whether to apply given that gap is a question for job-underwriter. This message only handles the resume.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, retail — 5 years. Built and maintained about 25 dbt models, including the core orders mart. Designed the orders mart's star schema with our then-data engineer." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your notes | pending your approval |
| E2 | Experience | *(no current line)* | "Designed the star schema for the orders mart with our then-data engineer" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your notes | pending your approval |
| E3 | Experience | *(no current line)* | "Built and maintained about 25 dbt models, including the core orders mart" | `surface` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your notes | pending your approval |
| E4 | Experience | *(no current line)* | "Added tests to our nightly dbt job" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your notes | pending your approval |
| E5 | Experience | *(no current line)* | "Fix our nightly dbt job when it breaks" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your notes | pending your approval |
| E6 | Experience | *(no current line)* | "Python scripting to pull vendor APIs on a cron; pandas for analysis" | `reframe` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your notes | pending your approval |
| E7 | Experience | *(no current line)* | "SQL every day on Redshift — complex window functions and CTEs" | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your notes | pending your approval |
| E8 | Skills | *(no current line)* | "SQL (Redshift) · dbt · Python (pandas)" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your notes | pending your approval |
| E9 | Experience | *(no current line)* | *(order: E2, E3, E4, E5, E6, E7)* | `reorder` | "I designed the star schema for the orders mart with our then-DE."; "Built and maintained about 25 dbt models including the core orders mart."; "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your notes | pending your approval |

Notes on the rows:
- **E1 and E2 keep "with our then-data engineer."** Dropping it would make the schema read as yours alone, and an interviewer for a modelling role will ask who designed it. The only change is spelling out "DE."
- **E3 keeps "about."** It doesn't become "25+".
- **E4 and E5 are a split.** Testing goes first because it's nearer to "own data quality." Neither says "owned," "on-call" or "SLA."
- **E6 drops "some" from "some scripting."** The line claims no amount either way, but if you'd rather keep the qualifier, reject the row and I'll propose it back with "some."
- **E8 lists no Airflow, Spark or Kafka.**

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Named absence below. The adjacent work is in E2–E5. | `[grounded]` your title is Senior Data Analyst; `[generic]` a stated years requirement is often screened against job titles, so this is the largest risk on the application |
| R2 | Build and own batch pipelines (transformation layer) | important | `surfaced_by_edit` | E3, E5. This covers dbt models and fixing the nightly job, not owning the whole pipeline. | `[grounded]` your notes |
| R3 | Batch pipelines in Spark | important | `not_evidenced` | Named absence below | `[grounded]` "Never used Airflow or Spark." |
| R4 | Model the warehouse / dimensional modelling | must-have | `surfaced_by_edit` | E2, E1. Co-designed with the then-DE. | `[grounded]` your notes |
| R5 | Own data quality | important | `surfaced_by_edit` | E4 shows tests added. Ownership isn't evidenced. | `[grounded]` your notes |
| R6 | Own SLAs | important | `not_evidenced` | Recall prompt C3 | `[grounded]` your notes don't mention deadlines or commitments |
| R7 | Production Python | must-have | `not_evidenced` | Recall prompt C2. E6 shows Python for analysis plus cron scripts. | `[grounded]` your notes say "for analysis" |
| R8 | Airflow or equivalent orchestration | must-have | `not_evidenced` | Recall prompt C1, plus a named closing path | `[grounded]` "Never used Airflow or Spark."; a cron schedule and a nightly job do appear |
| R9 | Streaming experience (Kafka) | preferred | `not_evidenced` | Named absence below | `[grounded]` "Never touched Kafka." |
| R10 | Partner with analytics on requirements | important | `not_evidenced` | Named absence below. You've been the analytics side, not the partner to it. | `[grounded]` your title; `[generic]` knowing what analysts need is usually useful in this role, but it's material for the interview, not a resume line |

## Gap handling

### Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | must-have | A nightly dbt job you fix, and Python scripts on a cron. Nothing says who set up the scheduling or how. | It's a must-have, and "or equivalent" is the only route open to you | You configured the dbt job's schedule, retries or alerts (dbt Cloud, cron, a CI runner); you set up the cron for the vendor pulls yourself; you made the vendor pull run before the dbt job | Job config, a crontab, a dbt Cloud job screenshot, a CI file | `[grounded]` what your notes say and don't say; `[generic]` interviewers usually ask what scheduled and retried the job |
| C2 | Production Python | must-have | Python "for analysis" and vendor-API scripts | Analysis notebooks and production code read very differently to an engineering screen | The vendor-pull scripts load tables that dbt models or dashboards depend on; they run unattended on a server; you added error handling, logging or tests to them; they're in version control | A repo or a sample of the scripts | `[grounded]` your notes; `[generic]` "production" usually means unattended, depended on and maintained |
| C3 | Own SLAs | important | You fix the nightly job when it breaks | Fixing a job is close to owning its SLA, but not the same thing | There was a deadline for the job (dashboards ready by a set time); you were the person who got paged or messaged when it failed; you tracked how often it failed; you know what your tests checked | A runbook, an incident thread, the test definitions | `[grounded]` your notes; `[generic]` an SLA usually implies a stated deadline and someone accountable |

### Named absences

- **R1, 3+ years data engineering.** You haven't held a data engineering title, and the posting makes it a must-have. The adjacent work (E2–E5) is real, but wording can't turn it into DE years. Ways to close it: apply knowing the title gap is the main risk; target Analytics Engineer roles, where your dbt work matches more directly; or move internally into a DE role for a cycle.
- **R3, Spark.** You've never used it. Ways to close it: a small PySpark project in a public repo, or learning it on the job in a role that offers it. Spark isn't the only stack named in the pipelines line, so it doesn't decide this application by itself.
- **R9, Streaming and Kafka.** You've never touched it, and it's listed as a plus. It's not worth closing for this application. If you want it later, a small Kafka-to-warehouse demo project would start to close it.
- **R10, Partnering with analytics.** You've been the analyst, so this is about which side you sat on, not a skill gap. It belongs in what you say in the interview, not in a resume line.

## Not written, and why

- **"Data Engineer" or "Analytics Engineer" as your title.** You held neither, and that would be an upgrade, not an equivalent.
- **"3+ years of data engineering experience."** Your notes don't support it.
- **"Built and owned ETL/data pipelines."** You built dbt models and fixed the nightly job. Owning the pipeline is a different job.
- **"Orchestrated" anything, or Airflow, Spark or Kafka in Skills.** "Never used Airflow or Spark." "Never touched Kafka."
- **"Production Python."** Not written unless C2 confirms it.
- **"Owned data quality and SLAs" or "on-call for the nightly job."** "Fixed when it breaks" and "added tests" are what you said.
- **"Designed the star schema"** without "with our then-DE." That would turn a shared design into a solo one.
- **"25+ dbt models."** You wrote "about 25."
- **"Partnered with analytics teams on requirements."** This is the posting's wording. You were the analytics team, and the change would put you on the other side of the table.

## Parse-safety check

You gave me prose, not a file, so I couldn't check layout, tables, images, headers and footers, headings or file type. Send the actual resume (.docx or PDF) and I'll run them. I found no hidden text, but with no file to inspect, that check couldn't run either.

## Upgrade menu

- **Your dbt project (repo or an export of the models, tests and schema files):** makes E3, E4 and the R4 claim inspectable, not just self-reported.
- **An ERD or diagram of the orders-mart star schema:** backs up E2, the line an interviewer for a modelling role is most likely to probe.
- **The vendor-API scripts:** could move R7 from `not_evidenced` to real evidence, depending on what they show.
- **A previous resume version:** often holds dates, scope or projects your notes left out.
- **Offer (beyond this skill's scope):** a short plan for one portfolio project, an Airflow DAG that runs your vendor-API pull and then a dbt build. It would close R8 directly and use work you already know. I'll only write it if you ask.

## Questions

C1 — What actually schedules the nightly dbt job and the vendor-API cron, and did you set up or change any of that yourself?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Do the vendor-API scripts load data that other models or dashboards depend on, and do they run unattended (where, and with what error handling)?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did the nightly job have a deadline someone relied on, and when it broke, were you the person expected to fix it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.