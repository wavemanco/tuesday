Here's the full proposal list for your resume. I haven't changed anything yet, and nothing goes in until you approve it line by line.

Three things up front:
- **You sent a description of your background, not the resume itself.** So the "Current line" column says "not provided". Every proposed line is built from your own sentences, which I quote word for word.
- **The "3+ years data engineering" must-have can't be met by rewording.** Your title was Senior Data Analyst. Your dbt modelling, the star schema and the job fixes are real and they're near this role, but they aren't data engineering years. Whether to apply anyway is a separate decision; that's what job-underwriter is for. This list makes the resume as strong as your history allows without saying more than you said.
- **Airflow, Spark and Kafka appear nowhere in the proposed lines,** not even as "exposure to". You said you've never used them.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(not provided)* | "Senior Data Analyst, 5 years in retail. Built and maintained about 25 dbt models including the core orders mart, and designed its star schema with our then-data engineer." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your background prose | pending your approval |
| E2 | Experience | *(not provided)* | "Built and maintained about 25 dbt models, including the core orders mart" | `surface` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your background prose | pending your approval |
| E3 | Experience | *(not provided)* | "Designed the star schema for the orders mart with our then-data engineer" | `surface` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your background prose | pending your approval |
| E4 | Experience | *(not provided)* | "Fixed our nightly dbt job when it broke and added tests to it" | `surface` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your background prose | pending your approval |
| E5 | Experience | *(not provided)* | "Wrote Python scripts to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your background prose | pending your approval |
| E6 | Experience | *(not provided)* | "SQL daily on Redshift: complex window functions and CTEs" | `surface` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your background prose | pending your approval |
| E7 | Experience | *(not provided)* | *(order: E2, E3, E4 first, then E5, E6, then the analysis bullets)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE."; "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your background prose | pending your approval |
| E8 | Skills | *(not provided)* | "SQL (Redshift), dbt, Python (pandas), cron" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your background prose | pending your approval |

Notes on the rows:
- **E1 and E3 keep "with our then-data engineer".** Dropping it would turn shared design work into solo design.
- **E1 keeps the 5 years attached to the analyst role, not to dbt.**
- **E4 says "fixed when it broke", not "owned" or "maintained".**
- **E5 drops your word "some".** A plural "scripts" doesn't claim volume, but if "some" mattered to you, reject E5.
- **E5 and the summary both avoid the job ad's words.** There's no "orchestrated", "pipelines" or "production".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | not_evidenced | Your title is analyst. The nearest work is in E2–E4. See named absence A1. | `[grounded]` your prose |
| R2 | Production Python | must-have | not_evidenced | E5 shows scripts on a cron, but "production" isn't something you said. See recall prompt C1. | `[grounded]` your prose |
| R3 | Airflow or equivalent orchestration | must-have | not_evidenced | A cron schedule plus a nightly dbt job is near this, not equivalent as stated. See C2. | `[grounded]` your prose |
| R4 | Dimensional modelling | must-have | surfaced_by_edit | E3, E1 | `[grounded]` your prose |
| R5 | Model the warehouse | important | surfaced_by_edit | E2, E1, E6 | `[grounded]` your prose |
| R6 | Build and own batch pipelines | important | not_evidenced | You built the models and fixed the job, but owning a pipeline isn't stated. See C2. | `[grounded]` your prose |
| R7 | Own data quality and SLAs | important | not_evidenced | E4 covers the tests. Owning the quality and any finish-time agreement isn't stated. See C3. | `[grounded]` your prose |
| R8 | Spark | important | not_evidenced | See A2 | `[grounded]` "Never used Airflow or Spark." |
| R9 | Streaming / Kafka | preferred | not_evidenced | See A3 | `[grounded]` "Never touched Kafka." |
| R10 | Partner with analytics on requirements | important | not_evidenced | You *were* the analytics side. E3 states the collaboration from your actual side. See A4. | `[grounded]` your prose |

## Gap handling

**Recall prompts.** Each question is asked once, at the end.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python for analysis, plus cron scripts that pull vendor APIs. Nothing about who relied on them or how they were run. | It's a must-have, and "for analysis" usually reads as notebook work. | Scripts that loaded into Redshift tables that dbt models or reports read from; scripts in git with review; retries, logging or failure alerts; scripts you kept running for months | The repo, a cron entry, an alert email | `[grounded]` what your prose says and doesn't say; `[generic]` how "for analysis" Python tends to read |
| C2 | Orchestration; owning batch pipelines | must-have | Cron scripts and a nightly dbt job you fixed. Not what scheduled the job, or whether you set any of it up. | Airflow "or equivalent" is a must-have. A scheduler you configured would be honest evidence for it. | Setting up dbt Cloud jobs or schedules; adding the job's dependencies or run order; being the person who gets paged | The job config, run history, a runbook you wrote | `[grounded]` your prose; `[inferred]` from the JD's "or equivalent" wording |
| C3 | Data quality and SLAs | important | You added tests. Not which kind, and no deadline the job had to meet. | The JD says "own", so a test you added and a deadline you were held to are different claims. | dbt not_null/unique/relationships tests; custom tests; a "marts ready by 7am" expectation; source freshness checks | The schema.yml with your tests, a freshness config | `[grounded]` your prose |

**Named absences.** These are things you said you haven't done.

| # | Gap | What closing it would take | Provenance |
|---|---|---|---|
| A1 | No data engineering title or years | You can't reword your way past this. Options: (a) apply and let the dbt, schema and test work argue for adjacency, accepting that the years line is a risk; (b) aim for roles whose must-haves match dbt-and-warehouse work; (c) an internal move into a data engineering title. | `[grounded]` your title; `[inferred]` that a titled-years requirement is likely read literally |
| A2 | Spark, never used | A real project: a Spark job you built and can talk through, on a public dataset or at work. It isn't a listed must-have, so it's not worth forcing for this application. | `[grounded]` your prose |
| A3 | Kafka/streaming, never touched | Same path, a small streaming project. The ad lists it as "a plus", so the honest move is to leave it off. | `[grounded]` your prose |
| A4 | "Partner with analytics" | Nothing to close, because you'd be the analyst they partner with. Interview framing about knowing that side is a separate conversation and isn't written here. | `[grounded]` your prose |

## Not written, and why

- **"Data Engineer" or "Analytics Engineer" as your title.** You held Senior Data Analyst.
- **"3+ years of data engineering experience"**, in any form.
- **"Built and owned batch pipelines".** "Own" is the job ad's word. Yours is "fixed when it breaks".
- **"Production Python"**, unless C1 confirms it.
- **"Orchestrated jobs" for the cron scripts.** That's the ad's vocabulary applied to your history.
- **Airflow, Spark or Kafka in Skills, including "familiar with".**
- **"Owned data quality and SLAs".** You added tests, which is in E4.
- **"Partnered with analytics on requirements".** That reverses which side of the table you sat on.
- **"Designed the star schema" with "with our then-DE" cut.**
- **"25 dbt models" with "about" dropped.**

## Parse-safety check

You sent prose, not a file, so I couldn't check the layout (columns, tables, headers and footers, icons), the file type, or whether the document contains hidden text you didn't put there. One thing I could check: the true keywords this ad looks for (dbt, Redshift, star schema, Python, SQL) now appear early, in E1 and E8, without adding any you can't support.

## Upgrade menu

- **Your actual resume file** gives me real "Current line" cells and a full parse check.
- **The dbt project repo**, or just the schema.yml with your tests, would firm up E2–E4 and help answer C3.
- **The vendor-API scripts' repo** would let C1 move R2 toward a covered requirement.
- **The nightly job's schedule config or run history** would answer C2.
- **Optional extra:** a short plan for one project that would honestly close A2 or A3 before your next round of applications. Worth it only if you're aiming at this kind of role for months, not just this one posting.

## Questions

**C1:** Did the vendor-API scripts load data that other tables, dbt models or reports depended on, and were they in version control or set up to alert when they failed?

**C2:** What actually scheduled the nightly dbt job (dbt Cloud, cron, something else), and did you configure any of it or only fix runs that failed?

**C3:** What kind of tests did you add (dbt built-ins, custom tests, freshness checks), and was there a time the job had to finish by that you were held to?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.