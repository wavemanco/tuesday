I'm building the tailoring ledger from your CV, the JD and the dossier excerpt. Below is the whole first pass. Nothing is applied yet.

**What I built on:**
- **The dossier.** It covers this same role, so I've used its `evidence_map` judgements as they stand: R1 and R2 are `adjacent` at `medium` confidence. Its pending edit E1 is now row E1 here, re-checked against your CV. Its two rejected inferences are listed under "Not written" and won't come back in any wording.
- **Your CV as you pasted it.** You sent it as sentences rather than a file, so I've treated each sentence as a current line. I can't yet tell where each one sits on the page.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." (its own bullet) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier pending edit E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | "Ran quarterly roadmap-input sessions collecting client feedback for product." (its own bullet, second) | `surface` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." (as a Skills line near the top) | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |

**Why the rows are worded this way:**
- **E1:** "the whole team" stays exactly as you wrote it. It doesn't grow into "company-wide".
- **E2:** "client" and "our REST APIs" stay. They show you worked for the vendor, integrating its APIs for customers. Changing them to "partners" or "built APIs" would change which side of the work you were on.
- **E3:** "for product" stays. You gathered feedback for the product team; you didn't decide what went on the roadmap.
- **E4:** "Comfortable in" stays. It's the qualifier, and cutting it would turn a comfort level into a claim of expertise.
- **E5:** "7 years" stays attached to the two titles together, as in your sentence. I haven't split it into a number of years for each role.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM, including roadmap ownership | must-have | `not_evidenced` | Your integration leadership is related work, but the dossier (R1) records it as a transferability gap at medium confidence. E2, E3 and E5 put the related work up front. Recall prompt C1 below | `[grounded]` dossier R1; CV "Never held a PM title." |
| 2 | Shipped API or platform products | must-have | `not_evidenced` | Dossier R2: related work, medium confidence. You integrated your company's APIs for clients; nothing says you shipped them. E2 puts the integrations first. Recall prompt C2 below | `[grounded]` dossier R2 |
| 3 | Technical fluency | important | `surfaced_by_edit` | E4 (Postman, SQL, OpenAPI), backed up by E2 (REST API integrations) | `[grounded]` CV |
| 4 | Stakeholder management | important | `surfaced_by_edit` | E2 (integrations led end to end) and E3 (quarterly sessions with clients for product). Both keep your own words, not the JD's | `[grounded]` CV |
| 5 | Run discovery with integration partners | important | `surfaced_by_edit` | Partial: E3 shows you collecting client feedback. Calling it "discovery" or "partners" is not written (see below) | `[grounded]` CV |
| 6 | Write specs and drive delivery with engineering squads | important | `not_evidenced` | The playbook (E1) is a team document, not a product spec. Being comfortable with OpenAPI specs isn't the same as writing them. Recall prompt C3 below | `[grounded]` CV |
| 7 | Define adoption metrics | important | `not_evidenced` | Named absence below | `[grounded]` CV says nothing about metrics |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM / roadmap ownership | must-have | Integration leadership and feeding input to product. Nothing about deciding priorities. | It's the headline must-have. A reader will look for prioritisation authority first. | You personally ranked which client requests went to product; you owned the order of an integration-tooling backlog; you decided the scope of a release with engineering | A ranked list you produced, a planning doc, a release note naming you | `[grounded]` dossier R1; `[generic]` how PM screeners read this requirement |
| C2 | Shipped API/platform products | must-have | You integrated your company's REST APIs for clients. Nothing about shipping an API yourself. | The role owns a partner-facing API platform, so having shipped one is the second thing a reader checks. | Requirements you wrote for an endpoint or API change that shipped; an SDK, sample app, sandbox or developer-docs set you owned | A changelog entry, a repo, a docs page with your name on it | `[grounded]` dossier R2; `[generic]` what platform-PM screeners look for |
| C3 | Write specs | important | Comfort with OpenAPI specs; the playbook. | Specs are the day-to-day output of this role. | An OpenAPI spec you wrote rather than read; a written integration-requirements doc handed to engineering | The spec file or doc, with confidential details removed | `[grounded]` CV; `[generic]` what this role produces |

**Adoption metrics: a named absence.** Nothing you've told me covers defining or tracking adoption numbers, and it's an important requirement, not a must-have. Two ways to close it:
- In the interview, describe what you'd measure, framed as a proposal rather than past experience.
- If you did track integration counts or time-to-go-live, tell me in your answer to C2 or C3 and I'll add a row.

## Not written, and why

- **"Product management experience" or any PM title.** You wrote "Never held a PM title." It's a must-have, and the gap stays visible in the coverage map rather than being written around.
- **"Owned / shaped the product roadmap."** You collected feedback "for product". Deciding what went on the roadmap is a different job.
- **"Ran partner discovery."** That's the JD's wording. Yours is "roadmap-input sessions collecting client feedback". Swapping in their phrase makes it sound like you did their exact job.
- **"Integration partners" for your clients.** The posting's word would move you from vendor to platform owner.
- **"Shipped / built REST APIs."** You integrated "our REST APIs". You didn't say you built or shipped them.
- **"Wrote API specs."** You're comfortable with OpenAPI specs, which is not the same as having written them.
- **"Drove delivery with engineering squads"** and **"stakeholder management."** These are JD phrases. Nothing in your CV supports them as written.
- **"Playbook adopted company-wide."** You wrote "the whole team".
- **Rejected in the dossier, and staying out:** "built an internal request-triage tool". It came from something you remembered, and you couldn't confirm you owned it.
- **Rejected in the dossier, and staying out:** "has been the customer of a partner API platform". You worked on the vendor side.

## Parse-safety check

You pasted text, so I couldn't check multi-column layout, tables or text boxes, images, header and footer content, or file type. When you send the file I'll run those checks. Use standard section headings (Summary, Experience, Skills) so E4 and E5 are picked up as sections. A `.docx` or a PDF with selectable text is the safe choice.

## Upgrade menu

- **Your actual CV file.** It would complete the parse check and confirm where each line currently sits.
- **A redacted page of the integration playbook.** It would make E1 checkable evidence rather than a claim, and might show spec-like writing for C3.
- **Answers to C1–C3.** Each confirmed answer can turn a `not_evidenced` must-have into a real row. After that, re-running job-underwriter would update R1 and R2 in the dossier.

## Questions

C1: Was there ever a list, backlog or release where you, not product, decided what came first?
C2: Did anything client- or developer-facing ship with requirements you wrote, such as an endpoint, SDK, sandbox or docs set?
C3: Have you written an OpenAPI spec or a requirements doc that engineering built from?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.