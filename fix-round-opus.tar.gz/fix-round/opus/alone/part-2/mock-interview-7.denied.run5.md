Web search was refused, so I'm building the pack from your message alone and labelling what that leaves generic. Writing it now.
I've saved your prep pack as `saltmarsh-games_live-operations-producer_interview_pack.md`. I assumed Tobias is your hiring manager, because he heads Live Operations, but your note doesn't say whether the role reports to him.

**What to prepare first**
- **B1 is the most useful thing to rehearse.** Expect Tobias to ask some version of: you ran one title's weekly calendar as an associate producer, so are you ready for two titles and four teams? The guidance has you raise the jump in scope before he does. It keeps your answer to what you actually did and keeps "coordinated" separate from "led."
- **B2 is next:** in-app purchases. Admit it in one plain line, "I haven't worked on a game with in-app purchases." Then say how you'd learn it, as a plan. The JD doesn't mention in-app purchases, but it's a likely question for a mobile live-ops role.
- **Your strongest point is the release checklist QA still uses.** It's the one requirement where what you told me matches the JD directly.

**What's missing**
- **Nothing about Saltmarsh itself is in the pack.** All four web searches (values, interview process, company news, Tobias) were refused because web search isn't allowed in this session. So the company questions and the "why Saltmarsh" half of B4 are generic. Play both of their games before Friday so you have specific things to say about their events.
- **Some answers are left for you to fill in.** For example, which teams fed into your content drops and whether you put together the retention numbers yourself. Your answers to those would change how strong several rows are.

Say the word and I'll play Tobias as the Skeptic on B1 and react to your answers.
I can also save a tuesday-dossier.md that records the gaps this prep exposed, so you can use it in later sessions.
If you'd like the pack as a Word document, I'll convert it.

Is Tobias the person this role would report to? And has the recruiter told you anything about what Friday will focus on or what rounds come after it? Either answer would change how the pack is weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interview:** 60 minutes, Friday, with Tobias Wrenfield, Head of Live Operations
**Relationship assumed:** hiring manager. Your note doesn't say whether this role reports to Tobias. If it doesn't, the persona weights below change.
**Research:** none ran. All four web searches were refused (no search permission), so company-specific content is labelled `[generic]` and listed in the upgrade menu.

---

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking and in what register. **Types** describe *what* is being scored. Rehearse both. The same gap question feels very different as a friendly aside and as a time-boxed challenge.
- **Type key:**
  - **VAL**: behavioural / values. Does your past behaviour show the company's values?
  - **EXP**: work-experience deep-dive. Does what you said survive scrutiny, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. Have you done your homework on them?
  - **CASE**: live problem. How do you structure and reason through a problem from the actual role?
- **Provenance labels:** `[grounded]` traces to your message or the JD. `[inferred]` is this pack's derivation, and the derivation is named. `[generic]` is a role-family pattern that makes no claim about Saltmarsh.
- **Answer slots** are instructions for your answer in the room, not questions for me. Each slot has two honest branches. Pick the one that's true.
- **Guidance is scaffolding, not a script.** Say it in your own words, and only what you actually did.

**Highest-ROI prep in this pack: B1.** The objection most likely to come up is the step from one title's calendar, as an associate producer, to two titles and four disciplines. **B2** (no in-app purchase experience) is second.

---

## Fit snapshot

Every claim this pack makes about your past is drawn from the five sentences in the evidence column, and from nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title's weekly content drops. It doesn't say live events across two titles, and your words should stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title line in the JD makes a probe on scale likely. If any of that calendar touched another title, or included something you'd call a live event, say what it was in your own words. If not, say so plainly and stay with the one title's weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Running a calendar doesn't show which teams fed into it. Answer slot: if design, art, engineering or community work went into those drops, say which, and which part of lining them up was yours. If none did, or that part wasn't yours, say so plainly and return to running the calendar. Coordinating teams is not the same as leading them. Keep the two apart (see Prohibited claims) |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Presenting monthly numbers is not the same as owning a post-event review. Answer slot: if you ever reviewed how a particular drop performed, say what you looked at and who saw it. If there was no such review, say so plainly, then describe how you would run one, framed as a plan |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, and it's your closest match. Your message is the only evidence behind it, so expect a probe. Lead with the quote's own terms: you wrote it, and QA still uses it. Answer slot: if you kept it up to date or changed it after writing it, say how. If not, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Four years meets the three-year line. State the title as it is: associate producer. Your material doesn't say whether the main title was a live-service game for all four years. Answer slot: if it was, say so. If part of that time was on something else, say so plainly and count only the live years |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: weekly, main title, last two years. Expect "what did running it involve?" and answer in your own words, describing only what you did |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | Presenting the numbers touches the requirement but doesn't show whether you worked with them beyond presenting. Answer slot: if you pulled, read or explained those numbers yourself, say which measures and how, in your own words. If someone else prepared them, say so plainly and say what you took from presenting them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist the QA team still uses touches on clear writing without proving it. Answer slot: if you wrote other documents your team relied on, name them. If not, say so plainly and point to the checklist |
| F9 | Mobile live-ops events commonly carry in-app purchase offers and monetisation KPIs. This is a role-family pattern; the JD you shared doesn't mention it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | No wording can close this gap, and you've said so yourself. Since it isn't in this JD, treat it as a likely probe rather than a stated requirement. Words: "I haven't worked on a game with in-app purchases." Follow with how you would learn it, framed as a plan and never as past experience. Don't add anything to make the gap feel smaller |

Not a gate: "3+ years" is an experience requirement, and it's graded on fit like the other rows. Nothing in this JD is an eligibility gate.

---

## Persona table

The weights start from the hiring-manager prior (Case/Strategist + Skeptic). No interviewer signals could be read because the search on Tobias was refused. Your own words establish the loop: one 60-minute session, run by Tobias. That session names no values round, so there is no values cheat sheet.

| Persona | How it shows up with Tobias | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | "Plan next quarter's events across both titles", "diagnose this retention dip" | High. A Head of Live Operations hiring a producer is buying calendar and review capability, and that is easiest to test live | Clarify → objective → segment by title and player cohort → approach → metrics → risks. Think aloud, and challenge one premise respectfully |
| B. Skeptic | Quiet probing of the step up (F1, F2) and of in-app purchases (F9) | High. The gaps between your evidence and the JD sit exactly where his function lives | Rehearse B1 until it's boring. Bridge only from your quoted sentences. Say limits before he does, then give a ramp plan |
| C. Data-Driven Prober | "Which retention numbers? How were they counted?" | Medium. The JD names KPIs and retention, and your evidence (F7) is presenting numbers, so expect a drill-down | Know what you can and can't say about those numbers, and say plainly where you don't know |
| D. Conversational | The opening "walk me through your journey", casual questions about games you play | Medium. Most hour-long hiring-manager calls open and close this way, and it's still scored | Have a 90-second arc ready. Treat casual questions on hot JD topics as scored |
| E. Pressure | "Sixty seconds: why you?", "How much of that was actually you?" | Low to medium. Not his prior, but a short call can tighten quickly on a gap | Pause, restate, anchor in what you said, and hold through two follow-ups before conceding |
| G. Peer Evaluator | Cross-team seam scenarios: engineering vs community, art vs the date | Low to medium. Coordinating four disciplines is in the JD, so expect seam questions even from a manager | Use reciprocity framing, and propose seam principles rather than claiming to know theirs |
| H. Values / Behavioural | "A time you told leadership something unwelcome", "a release that went wrong" | Low. No values round named, and no published values in hand | Use the selection scaffolds, with "I" for your part and "we" for context |

(Bank IDs skip F, which the fit snapshot uses.)

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles, one calendar. Walk me through how you'd build the next quarter of live events." | CASE | [generic] | Clarify first: each title's audience and current event cadence, what the events are meant to move, and team capacity. Then the approach: one calendar with a lane per title, dependencies on design, art, engineering and community mapped per event, lock dates, QA gates, and collision checks between the titles. Name the retention measure each event targets. Close with risks (crunch weeks, two events competing for the same team) and the one premise you'd question | The JD's first line, asked as a live problem. CASE delivery of JD content. `[generic]` because it's a pattern for the problem, not a fact about Saltmarsh's calendar |
| A2 | "An event went live and seven-day retention for players who joined it dropped against last month. Diagnose it." | CASE | [generic] | Check the data first: is the cohort defined the same way, and was tracking working? Then segment by new vs returning players, platform and title. Then compare against the event's design (difficulty, reward timing, length) and look outside it (a release bug, a competing event, seasonality). State a hypothesis early and say what would disprove it. End with what you'd change for the next event | Tests the JD's retention line live, which F7 can't show from evidence alone. Pure CASE |
| A3 | "Art is going to miss the date for an asset in next week's event. What do you do?" | CASE | [generic] | Clarify how late, and what depends on the asset. Options: scope down, reuse an existing asset, swap the event order, or slip. Choose by player impact and team cost. Say who you tell and when, including community so players aren't surprised. Note what changes in the checklist so it doesn't happen again | The JD's coordination line (F2's requirement), asked as a decision. Hiring managers use slipped-asset scenarios because they hit every team at once |
| A4 | "Design wants to add a feature to an event two days before code lock. How do you handle it?" | CASE | [generic] | Ask first what it's for and what it would move. Then name the cost: engineering and QA time, and risk to the lock. Offer options: ship it next event, ship a cut-down version, or take it with an explicit trade agreed with engineering. Whatever you decide, write it down and tell the teams affected | Tests holding a date against a colleague's request, the coordination half of the role. CASE |
| A5 | "How would you structure the post-event review so it actually changes the next event?" | CASE | [generic] | A short written document, due within a set number of days of the event: the goal, what shipped, KPIs against target, what broke and why, and two or three changes for next time, each with an owner. Say who reads it and where the changes land (the calendar, the checklist). Keep it the same shape every time so trends show | The JD's ownership line (F3's requirement) and its written-communication line (F8's), asked as a design problem. Lets you show the thinking your material doesn't yet evidence |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've run your main title's calendar as an associate producer. This role runs two titles and coordinates four teams. Why are you ready?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | **The highest-ROI rehearsal in this pack.** Hold only what the quotes carry: four years as an associate producer at a puzzle-game studio, and for the last two years running the weekly content-drop calendar for the main title. Answer slot: if two titles and four disciplines is a step up from what you've run, say so first, before he does. Answer slot (F2): if design, art, engineering or community work fed those drops, say which, and which part of lining them up was yours. If none did, or it wasn't yours, say so plainly and return to the calendar. If he pushes on leadership: "I haven't led a team." Then return to the calendar, and don't blur coordinating with leading. Close with a ramp plan, framed as a plan: how you'd learn both titles' cadences and the four teams' lead times in your first weeks. Follow-up 1, "But who made the calls?": use the answer slot. Follow-up 2, "So nothing this size?": concede the size and hold on the weekly calendar you ran for two years | F1 and F2 are where the JD presses hardest on your material, so this objection will arrive in some form. JD because it scores the stated scope. Deepest rehearsal because the limit has to be named before it's asked for |
| B2 | "What experience do you have with in-app purchases or monetised events?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first, unhedged: "I haven't worked on a game with in-app purchases." Then what you do have, at its own scope: running the weekly content-drop calendar for the main title for the last two years. Then a learning plan, framed as questions you'd ask rather than things you know: how event offers get scheduled, which KPIs monetised events report, who owns the offer decisions. If he follows with "so how would you know if an offer worked?", treat it as a CASE: define the target, compare to a baseline, and check the retention side effects | F9 is role-family, not in this JD, but it's the gap a mobile live-ops lead is most likely to raise. EXP because it tests a stated absence. Second-deepest rehearsal |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." "I ran the weekly content-drop calendar for our main title for the last two years." | Pick one real answer and don't dodge. Candidates are owning the post-event review (F3) or the two-title scale (F1). Say what you have next to it, at its own scope: you presented the monthly retention numbers, or you ran the one title's weekly calendar. Then give the plan for closing the gap. Don't pick something trivial | Skeptic stem, and the honest answer sits in F1 or F3. JD because it scores self-assessment against the list |
| B4 | "Why leave a puzzle studio for this, and why Saltmarsh?" | CO | [grounded] "4 years as an associate producer at a puzzle-game studio." | "Why leave": answer slot. Give your actual reason in your own words, and stay positive about where you are. "Why Saltmarsh": play both titles before Friday and name one specific thing about their events. No research ran, so this pack can't supply it | Motivation probe. CO because the "why here" half is scored on homework. The company half is `[generic]` until research or your own play supplies it |
| B5 | "Your title is associate producer. Why hire you as a producer?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Don't argue the title. Describe the work at its own scope: you ran the weekly content-drop calendar for the main title for two years, and you wrote the release checklist QA still uses. Let him draw the conclusion. Don't tell him what it proves | F5's title line is visible on any CV. EXP because it tests whether the work survives without the title doing the talking |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention numbers went into that monthly presentation, and how were they calculated?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start with the quote's terms: you presented them, monthly, to the studio head. Answer slot: which retention measures they included, how they were counted, and whether you compiled them or received them, all in your own words. If you don't know how a figure was counted, say so plainly. Weakest-assumption slot: if you know an assumption behind those numbers you'd defend least, name it before he asks. If you don't, say so and say what you'd check first | F7 is the evidence for the retention line and the obvious drill-down. EXP because it tests what was actually yours behind the presenting |
| C2 | "Tell me about a time an update you shipped changed whether players stuck around, or didn't." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a drop from the calendar you ran where you saw a change in the numbers. It needs the drop, the measure, and what you concluded. If no such time comes to mind, say so plainly, give the nearest thing your material does carry (running the calendar, presenting the numbers), and say what you'd measure next time | The JD's retention line, as an open prompt. Your material doesn't connect F6 and F7, so this is a scaffold, not a story map |
| C3 | "How do you know an event was worth the effort?" | CASE | [generic] | Define success before the event, not after. Compare against a baseline (the previous event, or non-participants). Weigh the result against team time spent, and add player sentiment from community. Say which one measure you'd lead with and why | The JD's KPI line (F3's requirement), asked as reasoning |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc: four years as an associate producer at a puzzle-game studio, then the last two years running the weekly content-drop calendar for the main title. You wrote the release checklist QA still uses, and you presented the monthly retention numbers to the studio head. Answer slot for the close: why this role now, in your own reason | Almost every hiring-manager call opens here, and it's scored on economy. It touches F4–F7 in one pass |
| D2 | "What mobile games are you playing right now, and what do you think of their live events?" | CO | [generic] | Answer slot: name two games you actually play, and one thing you think works or doesn't in their events. If one of them is a Saltmarsh title, even better, but only if it's true | A casual question on the JD's core topic, still scored. CO because it tests whether you follow the field |
| D3 | "What makes a good release checklist?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Principles first: short, ordered, an owner per line, and updated when something slips through. Then the one you wrote, which QA still uses. Answer slot: what's in it and why, in your own words | F4's requirement asked casually. JD because it scores the stated duty, and it doubles as written-communication evidence (F8) |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live ops with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause. Concede in one line: "I haven't worked on a game with in-app purchases." Hold on two facts in your own words: two years running the weekly content-drop calendar for the main title, and writing the release checklist QA still uses. Close with your reason for this role. Stay inside sixty seconds | Combines F9 and F1 under time pressure. EXP because it tests composure while describing real work |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it. Answer slot: if others contributed, say who and what, plainly. If it was yours alone, say so. Hold through a second push, and concede only what's actually shared | F4 is your strongest row, so it's the one a pressure interviewer tests for attribution. Hold-then-concede practice |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community says players are angry about an event bug. Engineering says the fix needs another week. What do you do?" | CASE | [generic] | Separate the two problems: the player message today, and the fix plan. Get community something honest to say now, agree with engineering on what can ship sooner (a workaround, compensation, or pausing the event), and set a date to revisit. Record it for the post-event review | The JD names both teams. A seam scenario that tests turf awareness and calm |
| G2 | "What would you need from engineering, and what would you give us?" | CASE | [generic] | Reciprocity framing: what you'd give them (early warning on calendar changes, a stable lock date, a checklist they can trust) and what you'd need (honest estimates, early flags when work slips). Propose a seam principle rather than pretending to know how their teams work today | Coordination line in peer register. Tests whether the hire adds to engineering's load or reduces it |

### H. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you told leadership something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time you raised an unwelcome fact with someone senior. It needs a named stake, what you said, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem. No published Saltmarsh values were in hand, so it's generic |
| H2 | "Tell me about a release that went wrong. What did you do?" | VAL | [generic] | Selection scaffold: pick a release where something slipped. It needs what went wrong, what you personally did, and what changed afterwards. If no such time comes to mind, say so plainly and describe how you'd handle it | The JD's release line raises the theme. Behavioural delivery |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B1, B3 |
| Coordinate design, art, engineering and community | A3, A4, B1, G1, G2 |
| Own the post-event review and its KPIs | A5, B3, C3 |
| Manage the release checklist with QA | D3, E2, H2 |
| 3+ years producing live-service games or apps | B5, D1 |
| Experience running a content calendar | B1, C2, D1 |
| Comfortable with player-retention metrics | A2, C1, C2 |
| Clear written communication | A5, D3. Mostly judged outside the hour, in your emails and any follow-up, so write the thank-you note with care |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical event week look like across the two titles, and where does it most often slip?" | Shows you think in calendars and failure points, and tells you where the job's real pressure sits |
| R2 | "Who reads the post-event review today, and what's one decision it changed recently?" | The JD makes you its owner. Asking whether it's used shows you care about outcomes, not just the document |
| R3 | "Which KPIs does an event review report against here, and who sets the targets?" | Mirrors the JD's own wording and gets you the vocabulary for your first month |
| R4 | "How do design, art, engineering and community hand work to the producer right now? What's working and what isn't?" | Goes straight at the coordination line, and his answer tells you where you'd add the most |
| R5 | "If events on these titles have monetisation goals, how are those balanced against engagement?" | Raises your F9 gap on your own terms, as curiosity rather than defence |
| R6 | "As Head of Live Operations, what are you changing about how the function works over the next year?" | Asks about his remit, not the job ad, which turns the close into a peer conversation |
| R7 | "Six months in, what would tell you this hire worked?" | Gets his scoring sheet and shows you plan to meet it |

---

## Prohibited claims

This pack will not coach any of the following. The banks above are written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated, in your message | "I haven't led a team." Coordinating teams is a separate thing, and only an answer slot (F2) can speak to it |
| Has worked on in-app purchases or monetised events | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Has run live events across multiple titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says one title's weekly content drops |
| Has owned post-event reviews and their KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. C1's slot asks only what those numbers were and what part was yours |
| Analysed retention data | Inflated form of F7 | "Presented the monthly retention numbers to the studio head", at its own scope |
| Ran QA or the release process | Inflated form of F4 | "Wrote the release checklist our QA team still uses", at its own scope |
| Producer-level title, or four years of live-service work | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio". F5's slot counts only the live years |

---

## Sources

**Provided documents:** your message (the JD text and your background).

**Searches sent:**
- `Saltmarsh Games values`: refused
- `Saltmarsh Games interview process producer`: refused
- `Saltmarsh Games mobile studio news 2026`: refused
- `Tobias Wrenfield Saltmarsh Games`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Search refused. It would have given official value names, and VAL questions themed on them |
| 2. `Saltmarsh Games interview process` | unavailable | Search refused. It would have confirmed whether more rounds follow Friday. Your own words establish this session, so its weights stand |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Search refused. It would have given CO and CASE questions grounded in their titles and recent moves. Those banks are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Search refused. It would have given an interviewer read, adjusted persona weights, and a reverse question tied to his career path |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Whether Tobias is your future manager, or a peer or skip-level → persona weights recomputed, and banks reordered or swapped
- Any recruiter email (focus areas, a take-home, the rounds after Friday) → a build section for any announced deliverable, and loop mode if more rounds follow
- Allowing web search → targets 1–4 run: official values and a values cheat sheet if a values round shows up, an interviewer read on Tobias, and CO/CASE questions on Saltmarsh's actual titles, turning the `[generic]` rows in banks A, B4 and D2 into grounded ones
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, Tobias's talks or writing, and recent studio context. Available on request, once search is allowed
- The names of the two titles → a sharper A1 and B4, and play-tested answers for D2
- Your answers to the answer slots in F2, F3, F5 and F7 → those rows upgraded from discovery to quoted evidence, and B1, C1 and C2 rewritten as story maps
- How much prep time you have before Friday → a prioritised prep schedule sized to it
- A tuesday-dossier.md from job-underwriter → an objection drawn from verified evidence rather than inferred, strategy constraints per weak area, and an external prohibited list. This pack doesn't need one
