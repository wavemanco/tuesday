I've built a prep pack for all three rounds. Its spine is one table that maps each line of the role text to what you told me about yourself. Each round then gets its own question bank, how each interviewer is likely to come at you, and questions to ask them back.

The web searches for Larkfield's values, interview process and news were blocked, so there's no research behind it. Everything about you comes from the four sentences in your message.

- **Tuesday, hiring manager (12 questions):** the biggest risk is the step from one team of six to two squads of eleven. **A1** is the most valuable thing to rehearse in the whole pack. It has you hold to "team lead of six for three years," say "I've never managed managers" before they ask, and give your ramp plan as a plan.
- **Thursday, panel (12 questions):** the staff engineers will dig into the 60%, and the PM will ask what it's like to disagree with you. **J1**, the blunt version of "you've never owned a hardware-adjacent roadmap," is the one to rehearse.
- **Monday, VP (8 questions):** leadership philosophy plus a short-answer version of the scale question (**M2**). I couldn't fetch Larkfield's published values, so this round has no values cheat sheet yet.

Two wording traps the pack flags:
- **The 60%:** your sentence says on-call burden dropped *after* the reliability quarter, not *because* of it. And it's on-call burden, not incidents or outages.
- **The 40:** "about 40 interviews" counts interviews, not hires, and running the loop isn't the same as owning hiring.

Files are in `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-6-denied-befd304c`:
- larkfield-systems_engineering-manager_interview_pack.md

Say the word and I'll play the sceptical hiring manager on A1, live, with follow-ups that react to what you say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job posting and your CV? Right now everything rests on one paragraph and four sentences. Those two would add requirements and turn several of the "say it in your own words" placeholders into answers built on your real record.

Do you want to allow web search, and if so, standard or deep? Standard means three searches. Deep is up to six more searches and two page fetches, and takes several more minutes. This would give Monday a values cheat sheet and ground the strategy questions in Larkfield's actual business.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Mode:** Loop, three scheduled rounds
- **Round 1, Tuesday:** 45 min with the hiring manager (Director of Engineering, your would-be boss)
- **Round 2, the Thursday after:** 60-min panel with two staff engineers and a product manager
- **Round 3, the following Monday:** 30 min with the VP Engineering ("values and leadership philosophy", per the recruiter)

**What this pack is built on:** the role text you pasted and four sentences about yourself from your message. No CV, no full JD, no interviewer names. The web research was attempted and blocked (see Sources), so nothing here about Larkfield comes from the web.

---

## How to use this pack

Two axes. **Personas** describe how a question will be asked: who is asking and in what register. **Types** describe what is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows the values and leadership philosophy the round is about |
| EXP | Whether what you said about your past survives scrutiny, and what was actually you |
| JD | Whether you can do the job the role text lists, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

**Provenance labels:** `[grounded]` = traceable to what you gave me. `[inferred]` = this pack's derivation, with the derivation named. `[generic]` = a role-family pattern with no claim about Larkfield or about you.

**Answer slots:** where the material doesn't show something an interviewer is likely to ask about, the guidance gives you an answer slot instead of words. Each one has two honest branches: you did it, so say how in your own words; or it wasn't yours or never happened, so say that plainly and go back to what you did do. Either branch is a good answer.

Guidance is scaffolding, not a script. Each cell should be speakable in about 90 to 120 seconds.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text you pasted | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material shows one team of six for three years. The role is two squads. Your words, at the quote's own scope: "I've been a team lead of six for three years." Answer slot: the role's two-squad line makes a probe on running more than one group likely. If your six ever worked as separate workstreams, say how you led that, in your own words. If they didn't, say so plainly and stay with the team of six |
| F2 | "building device-management services" — role text you pasted | none given | none | [grounded] | discovery | Your material doesn't show device-management work either way. Strong evidence here would be work on services that track, configure or update devices in the field. Answer slot: the role's device-management line makes this probe likely. If any of your work involved managing devices, say what it was, in your own words. If none did, say so plainly and say how you would get up to speed |
| F3 | "own delivery" — role text you pasted | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote shows a quarter you pushed through against roadmap pressure. It doesn't show how your team's delivery was planned or tracked. Your words, at the quote's scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the role's own-delivery line makes a probe on how you run delivery likely. If you set or tracked your team's delivery commitments, say how, in your own words. If that sat with someone else, or there was no such process, say so plainly and stay with the reliability quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role text you pasted | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running the loop is next to owning hiring, but owning hiring can be wider than running a loop. Your words, at the quote's scope: "I run our hiring loop for backend roles. About 40 interviews last year." Keep the "about", and keep the 40 attached to interviews. Answer slot: the role's own-hiring line makes a probe on how the loop works likely. If any part of how the loop runs was yours to set, such as its stages or what interviewers assess, say which and how, in your own words. If none was, say so plainly and stay with running it |
| F5 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role text you pasted | none given | none | [grounded] | discovery | Your material doesn't show growth work either way. Strong evidence here would be a named person (by role, not name), where they started, what you did, and where they ended up. Answer slot: if you helped someone on your team grow, say who and what you did, in your own words. If nothing comes to mind, say so plainly and say how you would approach it here |
| F6 | "partner with hardware and product on roadmap" (the hardware part) — role text you pasted | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap you stated yourself, and wording can't close it. Your words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as something you've done. The role says partner, not own, but your negative is the honest frame either way. No bridge from payments, and nothing added to make the gap feel smaller |
| F7 | "partner with hardware and product on roadmap" (the product part) — role text you pasted | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote shows roadmap pressure you pushed against. It doesn't say where the pressure came from or who you worked through it with. Answer slot: if you worked the reliability quarter through with a product partner, say how, in your own words. If the pressure came from somewhere else, or no product partner was involved, say so plainly and stay with the quarter |
| F8 | Leading through other leads. Two squads of eleven often have a lead or tech lead each, so a manager may be leading leads (role-family pattern, not in the role text) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [generic] | capability | A gap you stated yourself. Your words: "I've never managed managers." The role text doesn't say whether this job includes managing managers, so ask (Round 1 reverse question R1-2). Any answer about leading leads is a plan, never something you've done |

### Requirement coverage

| Requirement in the role text | Covered by |
|---|---|
| "Lead two squads" | A1, A4, D2, M2, L2 |
| "building device-management services" | G3, L1 |
| "own delivery" | B1, C2, J2 |
| hiring (from "own delivery, hiring and growth") | B3, C3, K3 |
| growth for 11 engineers | A3, M2 |
| partner with hardware on roadmap | A2, B2, E4, J1 |
| partner with product on roadmap | E1, H1, J2 |

---

## Round 1: Hiring manager (Director of Engineering), Tuesday, 45 min

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scale jump (F1, F8) and the hardware gap (F6) | **High.** Hiring managers are buying capability and reducing risk, and F1, F6 and F8 are the gaps a would-be boss has to settle before saying yes | Rehearse A1 until it's boring. Name the limit before they do. Every plan is said as a plan |
| Case / Strategist | Live problems: two squads, a release, a hardware dependency | **High.** This is the hiring-manager default, and the role text hands them the material | Clarify, then objective, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober | Pushes on the 60% and on the 40 interviews | **Medium.** Those are the only two figures in your material, and figures attract probes | Know what you can and can't say about how each was counted, and say plainly where you don't know |
| Conversational | The opener: "walk me through your background" | **Low,** but it's guaranteed in some form | A 90-second arc made only from the quotes in the fit snapshot |
| Pressure | One time-boxed comparison | **Low.** This isn't a stress-interview round, but managers do test composure once | Pause, hold, then concede something specific |

### Question bank

**Highest-ROI prep in the whole pack: A1.** The scale jump from one team of six to two squads of eleven is the most predictable objection to you. It will come up on Tuesday in some form, and probably again on Monday as M2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led one team of six. This is two squads and eleven engineers. Why are you ready for that?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | **Hold only what the quote carries:** "I've been a team lead of six for three years." Don't round six up, and don't say "teams". **Name the limit before you're asked:** "I've never managed managers." **Answer slot:** if your six ever worked as separate workstreams, say how you led that, in your own words. If they didn't, say so plainly and stay with the six. **Then the plan, said as a plan:** what you'd learn first about each squad and its leads, and what you'd want from your Director in the first 90 days. **Follow-up 1, "but six isn't eleven":** concede it plainly ("It's a real step up, and I won't pretend it isn't"), then go back to the plan. **Follow-up 2, "what would you do differently with two?":** stay in the plan. Never answer with a past you didn't describe | F1 and F8 are the widest gaps between the role text and your material, and a would-be boss has to settle them. JD because it scores the role's first line directly |
| A2 | "I don't see hardware in your background. How would you partner with a hardware team on a roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Say the gap first, in your own words: "I've never owned a hardware-adjacent roadmap." Then a learning plan said as a plan: what you'd ask the hardware lead first (lead times, release cadence, what can and can't change once a device ships), who you'd shadow, and how you'd make your squads' commitments readable to them. Don't reach for a payments story to fill the gap | F6 is the gap you stated yourself, so it's the one where candour costs you least and bluffing costs you most |
| A3 | "This role owns growth for eleven engineers. Tell me about a time you helped someone on your team grow." | JD, EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot on F5: pick one person from your team of six whose growth you had a hand in. You need a starting point, what you actually did, and where they ended up, all in your own words. If no such time comes to mind, say so plainly, then say how you'd approach growth across eleven people here | F5 has no evidence either way, and the role text names growth as a core duty, so it gets asked. JD because the role raises it; EXP because the answer is about your past |
| A4 | "Why leave payments for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: the pack has none of your reasons, so these are yours to give. Pick reasons pointed at this role (two squads, device-management services, the hardware partnership) rather than away from your current one. If part of the reason is about your current job, say it in one sentence and turn to what pulls you here. Keep it consistent with what you'll tell the VP on Monday | Every round can ask the Skeptic's "why here, why now", and the Director will want the answer the loop will hear. JD because it tests motivation for this specific role |
| B1 | "You join, and both squads are behind on a device-management release. What do you do in your first 30 days?" | CASE, JD | [generic] | Clarify first: what was committed, to whom, and what "behind" is measured against. Then the objective (a credible date versus scope), then the approach (talk to both squads' leads, find out where the work is actually stuck, look for hardware dependencies), then how you'd report progress up and out, then the risks. Think aloud. The question needs no claim about your past, so don't force one in | A live problem built from the role's delivery line (F3). `[generic]` because it's a pattern for the problem, not a fact about Larkfield |
| B2 | "Hardware moves a device's firmware date late in the quarter, and it breaks something your squads committed to product. How do you handle it?" | CASE | [generic] | Structure: what exactly moved and why; what your squads can still ship without it; who needs to hear it, in what order (product first, since they own the commitment); what you'd propose instead; and what you'd change so the next slip shows up earlier. Challenge one premise respectfully, for example whether the commitment really depended on the firmware | The role's hardware-and-product line (F6, F7) as a live problem, where no hardware experience is needed to reason well |
| B3 | "You've got two open reqs across the squads. How do you decide where they go, and how do you run the hiring?" | CASE, JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | First the decision: which squad has the bigger gap and which skills it lacks, and how you'd check that with both squads' leads. Then the hiring, at your quote's scope: "I run our hiring loop for backend roles." **Answer slot:** if any part of how the loop runs was yours to set, such as its stages or what interviewers assess, say which and how, in your own words. If none was, say so plainly and describe running it. Don't say "hired" | F4 is your strongest adjacent evidence, and this is where it gets tested against "own hiring" |
| C1 | "Walk me through that 60% drop in on-call burden. How was it counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend the number in your own words, in four parts. **How it was counted.** **What it's sensitive to.** **The assumption you'd defend least:** say it before they find it. **Which part was yours.** "I don't know exactly how it was counted" is an honest branch for any of these. Watch the wording: your sentence says the burden dropped *after* the quarter, and "after" isn't "because". Claim cause only if you can defend it | The single headline figure in your material, so the Prober will go two levels deep. EXP because it tests whether the figure survives scrutiny |
| C2 | "Tell me about that reliability quarter you pushed through against roadmap pressure. What was the trade-off?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The beats your sentence carries: roadmap pressure, a reliability quarter, you pushed it through, and the burden dropped afterwards. Tell them in your own words. **Answer slot:** if roadmap work was deferred, say what it was and how you made the case. If nothing was deferred, or the case was made by someone else, say so plainly and stay with the quarter | Your clearest story of holding a priority under pressure, and the Director will want its middle. It touches F3 and F7. EXP because the substance is your own past |
| C3 | "About forty interviews last year. How many of those were yours, and what did that loop look like?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Defend the number in your own words: what the 40 counts (interviews you sat in, or interviews the loop ran), what it's sensitive to, and which part was yours. If you don't know the exact split, say "about 40" and say what you do know. Keep the number attached to interviews, never to hires | Your second figure, and it sits beside the role's hiring line (F4). A small number answered precisely buys credibility for the rest |
| D1 | "So, walk me through your background." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc made only from these: nine years in engineering, three as team lead of six, currently at a payments company. You run the backend hiring loop, about 40 interviews last year. You pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% afterwards. Close on why this role, using the A4 slot. Add nothing your sentences don't say | Guaranteed opener. Casual register, but still scored, and it sets up everything after it |
| D2 | "Sixty seconds: why you over someone who's already run two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." | Pause and restate the question. Hold on what your quotes carry: three years as team lead of six, and running the backend hiring loop. Concede specifically: "Someone who has run two squads has done this exact job, and I haven't." Then the reason to take the bet, in your own words, without claiming the other candidate's weakness | A compressed A1 under time pressure. Composure is what's scored, and the honest concession is the strong move |

### Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What does success look like for this role at six months, and what would make you think it isn't working?" | Your would-be boss defines the bar in their own words, and you'll know what Thursday and Monday are checking for |
| R1-2 | "How are the two squads structured today? Does each have a lead, and how many of the eleven would report to me directly?" | Answers F8 head-on: you find out whether managing managers is in scope, and you show you aren't hiding from it |
| R1-3 | "Where does the device-management roadmap actually get decided, and how much of that is this role versus product and hardware?" | Shows you've read "partner" in the role text carefully, and the answer tells you what Thursday's PM will expect |
| R1-4 | "Where is the hardest seam between software and hardware right now?" | Invites them to teach you the domain, which turns your gap (F6) into curiosity |
| R1-5 | "How do you like to work with your managers? What do you want escalated, and what do you want handled?" | A real working-relationship question that only a would-be boss can answer |
| R1-6 | "What does hiring look like for these squads over the next year?" | Connects to your hiring-loop work (F4) without overclaiming it |

---

## Round 2: Panel (two staff engineers and a product manager), Thursday, 60 min

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | "What would you need from us?", seam questions, credit across teams | **High.** All three panelists would work alongside you rather than for or above you, and panels blend each member's relationship priors. Peer Evaluator is common to both | Reciprocity: what you'd bring to their work, not only what you'd need. Propose seam principles rather than pretending to know their seams |
| Data-Driven Prober | The staff engineers go two levels into the 60% and the reliability quarter | **Medium-high.** Staff engineers read for technical depth, and your one technical story is the quarter | Precise attribution. Your team did the work and you pushed the quarter through; keep those apart |
| Pressure | One panelist pushes on the hardware gap while others watch | **Medium.** Panels often test how you hold a position in front of several people at once | Hold, then concede specifically; don't fold to restore harmony |
| Case / Strategist | The PM sets a roadmap trade-off | **Medium.** "Partner with product on roadmap" is in the role text, and the PM is the partner | Structure aloud, and bring product into the decision rather than deciding at them |
| Values / Behavioural | The PM asks for a story of saying no | **Medium-low.** A cross-functional interviewer often runs a behavioural conversation | "We" for context, "I" for your contribution, and stop where the story stops |

### Question bank

**Highest-ROI prep for this round: J1.** It's F6 again, but asked in front of the people whose trust it decides.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | (PM) "We'd sit side by side on the roadmap. Where's the seam between you and me, and what happens when we disagree?" | JD, CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Seam principles, not seam facts: product owns what and why, engineering owns how and how fast, and you decide together on trade-offs, with health work made visible in the same plan as features. On disagreement: the data you'd bring, where you'd escalate, and how you'd keep the relationship intact. If you use the reliability quarter, say only what your sentence says. **Answer slot:** if a product partner was part of working that quarter through, say how, in your own words. If not, say so plainly and use it as an example of holding a priority, nothing more | F7 is the product-partnership gap. A collegial question that will bring up whatever you say about roadmap pressure |
| E2 | (Staff engineer) "What would you need from staff engineers here, and what would you take off our plate?" | JD | [generic] | Reciprocity first: what you'd take on (shielding them from planning churn, owning hiring logistics, clearing cross-team blockers), then what you'd ask of them (technical direction, honest design pushback, help reading device-management architecture). Offer these as principles you'd test with them in the first month, not as knowledge of how they work today | Pure peer pricing: they're working out whether you add to their load or take some off it |
| E3 | (Staff engineer) "How do you handle credit when work spans the squads and the hardware team?" | VAL, EXP | [generic] | Answer slot: pick a time from your own work when credit was shared across people or teams. You need what the work was, who did what, and how you made the contributions visible. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then say how you'd handle it here | A persona stem. Credit-sharing is how peers check whether you'll take their team's wins |
| E4 | (PM) "Hardware's schedule slips by a month, and product has a customer commitment. Walk us through how you'd handle it, with us in the room." | CASE | [generic] | Clarify: what the commitment is, what's actually blocked, and what's still shippable. Then the options (slip, reduce scope, phase it) with a recommendation, then who tells the customer-facing side and when. Bring the PM in explicitly: "this is a decision we make together". The question needs no claim about your past | F6 and F7 combined into one live problem, scored on how you treat the partner in the room |
| G1 | (Staff engineer) "On that 60%, what exactly counted as on-call burden?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: say what was counted, in your own words. Pick one measure and own it. If you don't know how it was counted, say so plainly. Don't swap "on-call burden" for a different word like incidents or outages unless that's what was measured | The C1 figure again, from engineers who will ask about its definition. EXP because it tests whether the figure survives a technical reader |
| G2 | (Staff engineer) "What was the hardest technical call in the reliability quarter, and was it yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your sentence says you pushed the quarter through, so say that part as yours. **Answer slot:** if you made a technical call during the quarter, say which one and why, in your own words. If the engineers on your team made those calls, say so plainly and describe what you did to make the quarter happen. That second branch is a strong answer for a manager | Staff engineers want to know how you split technical judgment from management. F3's limit tested from the technical side |
| G3 | (Staff engineer) "How would you get technical enough on device-management services to weigh in on design?" | JD | [grounded] | Answer slot on F2: if any of your past work involved managing devices, say what it was, in your own words. If none did, say so plainly. Then the plan: read the current architecture with a staff engineer, shadow on-call, sit in on hardware reviews, and set a date by which you'd expect to have useful opinions. Say outright that design calls stay with them until you've earned the context | F2 has no evidence either way, and these are the two people who'd notice a bluff |
| H1 | (PM) "Tell me about a time you said no to a product ask." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your sentence carries a candidate story: roadmap pressure, and a reliability quarter you pushed through. **Answer slot:** if the pressure came from product, say what was asked, what you proposed instead, and how the relationship stood afterwards, in your own words. If it came from elsewhere, say so plainly. Then either pick a different time you said no to a product ask, or say plainly that none comes to mind and how you'd do it here. Don't supply an ending the story doesn't have | The role's product line plus a persona stem. The PM is pricing what disagreement with you will feel like |
| H2 | (PM) "When did your team's work most directly affect a customer, and how did you know?" | VAL | [generic] | Answer slot: pick a time from your payments work when your team's work reached a customer in a way you could see. You need what changed, who noticed, and what you did about it. If no such time comes to mind, say so plainly, then say how you'd stay close to customers through product here | Adapted from a persona stem. A PM listens for whether an engineering manager thinks about the customer |
| J1 | (Any panelist) "I'll be blunt: you've never owned a hardware-adjacent roadmap. Why should the hardware team trust your squads' commitments?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause. Agree with the fact in your words: "That's right. I've never owned a hardware-adjacent roadmap." **Hold** on what you'd do, said as a plan: make commitments only after the dependencies are mapped with hardware, keep them visible, and raise slips early. **Follow-up 1, "plans are easy":** concede ("Agreed, trust comes from the first few commitments kept, not from what I say today") and name the first commitment you'd aim to keep. **Follow-up 2:** stay with the plan; don't reach into payments for a substitute story | F6 asked as a pressure item in front of the people it matters to. Rehearsing hold-then-concede makes this calm instead of defensive |
| J2 | (PM and staff engineer together) "Product wants a new device-management feature this quarter, and the staff engineers want to pay down platform debt. You get one. Make the call." | CASE, JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Clarify: what the debt costs now (on-call, velocity, risk), what the feature is worth and to whom, and whether it can be split. Make a call and name what would change your mind. If you bring in your own precedent, say only what your sentence carries: you pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% afterwards. Acknowledge out loud that the answer here may differ | The delivery line (F3) and the product line (F7) as one live problem, with both sides of the panel represented |
| J3 | (Staff engineer) "How much of that 60% was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the part your sentence gives you: "I pushed the reliability quarter through." Give the drop to its owner, as your sentence does: "my team's on-call burden" dropped. Concede specifically: the engineering work was the team's, and "after" isn't proof of "because". Don't fold further than that, and don't claim more | The Pressure persona's attribution stem, from the panelists best placed to know what an EM does and doesn't do |

### Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | (Staff engineers) "What could a new EM do in their first month that would genuinely help your work?" | The reciprocity question: it shows you see their load, and the answer is your first-month plan |
| R2-2 | (PM) "Where does the roadmap get stuck today between product, hardware and engineering?" | You learn the real seam rather than guessing it, and the PM sees you looking for it |
| R2-3 | (All) "Tell me about a recent time product and engineering disagreed here. How did it get resolved?" | Asks for their version of E1, and shows how decisions actually get made |
| R2-4 | (Staff engineers) "What does a good on-call week look like for these squads, and how far off is it?" | Touches the area of your reliability quarter without making claims about it |
| R2-5 | (All) "What would you want from this role that you aren't getting now?" | Lets them say the unsaid, and makes clear the hire is meant to help them |

---

## Round 3: VP Engineering, "values and leadership philosophy", the following Monday, 30 min

The recruiter's description makes this a values-style round. Larkfield's published values aren't in hand, because the values search was blocked, so there is no values cheat sheet. The VAL questions below come from the recruiter's words "values and leadership philosophy" and standard persona stems. If you can paste Larkfield's values page, this round gets one mapped question per value.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "What's your philosophy?", "tell me about a time…" | **High.** The recruiter named this round "values and leadership philosophy", which is the loop source here | One clear sentence of philosophy, then a story that shows it, where your quotes carry one |
| Case / Strategist (strategy-heavy) | Altitude questions about where the squads fit | **Medium.** Skip-level interviewers test whether you can think above your team | Reason aloud and ask; make no claims about Larkfield's strategy you can't source |
| Pressure | Thirty seconds to answer, plus F8 asked bluntly | **Medium.** Thirty minutes is short, and executives time-box | Short answers, then stop. Hold, then concede specifically |

### Question bank

**Highest-ROI prep for this round: M2.** It's A1's objection, as an executive asks it.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What's your leadership philosophy, in a sentence or two?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: the philosophy is yours, and the pack has no sentence of yours about it. Give one or two sentences you'd actually stand behind. Then one story that shows it. The reliability quarter is the one thing in your material where you held a priority under pressure, told as your sentence states it. If it doesn't fit your philosophy, pick a story that does, or say what you'd do here | The recruiter's own words for this round, so it's near-certain to be asked |
| K2 | "Tell me about a time you made an unpopular call as a leader." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your sentence carries a candidate: you pushed a reliability quarter through against roadmap pressure. **Answer slot:** if the call was unpopular, say with whom and how you handled it, in your own words. If the pressure wasn't personal, or it wasn't unpopular, say so plainly, then pick a time that was or say none comes to mind. Land the outcome only as your sentence gives it: your team's on-call burden dropped 60% afterwards | Leadership philosophy is usually tested through a hard call. Persona stem plus the recruiter's wording |
| K3 | "How do you decide who to hire? What do you look for?" | VAL, EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: what you look for, in your own words, drawn from running the backend hiring loop (about 40 interviews last year). If a principle came out of that work, say it and how you hold to it. Don't claim to have set the bar or made the decisions unless you did | Hiring is in the role text and is a common values window. F4 is where your evidence is strongest |
| K4 | "Tell me about a time you got something wrong as a leader." | VAL | [generic] | Answer slot: pick a real mistake from your three years as a team lead. You need what you got wrong, how you found out, what you changed, and what it cost. If no such time comes to mind, say so plainly, though at this level that answer usually costs more than the mistake. Then say how you look for your own mistakes | A standard values probe. It scores self-assessment, which VPs weigh heavily |
| L1 | "Where do you think device-management software creates value for a company like ours?" | CO | [generic] | Reason aloud, and don't assert facts about Larkfield's business. A structure: what operators of industrial devices need (keeping devices up, updating them safely, seeing their state), where software reduces cost or risk for them, and what that implies for the squads. Close by asking how they see it. Without research, the honest move is to reason and ask | Skip-level rounds test altitude. It's `[generic]` because the strategy search was blocked; it becomes grounded with research or a strategy brief |
| L2 | "A year from now, what would your two squads look like if you'd done this job well?" | CASE | [generic] | Plan, not past: delivery the hardware and product partners can rely on, a hiring plan carried out, at least one person grown into more scope, on-call that's sustainable, and engineers who could explain the roadmap. Pick two or three and say how you'd know | Tests whether you can picture the job at a level above any single week |
| M1 | "Thirty seconds: what kind of manager would your engineers say you are?" | VAL | [generic] | Answer slot: don't put words in your team's mouth. If you have feedback in hand, say what it actually said. If you don't, say so plainly and say what you aim to be, in one sentence. Stop at thirty seconds | A time-boxed self-assessment. Composure and honesty are what's scored |
| M2 | "You've never managed managers. If one of the squads needs its own lead, how would you get there?" | JD, VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Agree with the fact: "I've never managed managers." **Hold** on the plan: how you'd identify a potential lead, give them real scope, and support them. **Answer slot:** if you've helped someone on your team of six toward leading, say how, in your own words. If you haven't, say so plainly and stay with the plan. **Concede** if pushed: "I'd be learning this alongside them, and I'd want your managers' experience in the room" | F8 and F5 together, in the round about leadership. Being calm about this gap is itself a leadership signal |

### Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What separates your strongest engineering managers from the rest?" | Gets their philosophy in their own words, and tells you the bar |
| R3-2 | "When hardware timelines and software investment compete, how does that get decided at your level?" | Strategy altitude, and it connects to the hardware partnership in the role |
| R3-3 | "What does the engineering org need most from new managers this year?" | Shows you want to serve the org's need, not just your squads |
| R3-4 | "How do you grow managers here, including into leading other managers?" | Turns F8 into a growth question that you raise yourself |
| R3-5 | "A year in, what would make you say this hire was a mistake?" | A direct question executives tend to respect, and the answer is a checklist for your first year |

---

## Prohibited claims (shared)

These are claims this pack won't coach, because they're where your material is easiest to stretch under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers or led leads | A negative you stated (F8) | "I've never managed managers." No slot |
| Has owned or run a hardware-adjacent roadmap | A negative you stated (F6) | "I've never owned a hardware-adjacent roadmap." No slot |
| Has led two teams, or eleven engineers | Inflated form of F1 | F1's quote at its own scope: three years as team lead of six. The material shows one team of six. A1's slot stays inside the six |
| Owned hiring, made the hiring decisions, or hired some number of people | Inflated form of F4 | F4's quote at its own scope: "I run our hiring loop for backend roles — about 40 interviews last year." The 40 counts interviews, not hires. The B3 and K3 slots stay inside running the loop |
| The reliability quarter caused the 60% drop, or cut incidents or outages by 60% | Inflated form of the F3 quote. "After" is timing, not cause, and "on-call burden" isn't incidents | The quote word for word: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The C1, G1 and J3 slots ask how it was counted and what was yours |

---

## Sources

**Provided material:** your message. It contained the role text, the three-round schedule with the recruiter's description of Round 3, and four sentences about your background. It is also the loop source: it says who runs each of the three rounds and what Round 3 holds. No dossier was present.

**Searches sent:**
- `Larkfield Systems values`: refused (web search not permitted in this session)
- `Larkfield Systems interview process engineering manager`: refused
- `Larkfield Systems industrial IoT news 2026`: refused

**Fetches sent:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Refused. It would have supplied Larkfield's published values for a Round 3 cheat sheet and one mapped VAL question per value. Without it, the cheat sheet is dropped and the VAL questions are themed from the recruiter's words |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Refused. It would have added any documented format for these rounds, for example whether the panel includes a design exercise. Your message already sets the persona weights |
| 3. `Larkfield Systems` strategy and recent news | unavailable | Refused. It would have grounded L1 and the other CO and CASE questions in Larkfield's current priorities. Without it they're `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form. There's no interviewer read, and the reverse questions are role-specific rather than person-specific |
| 5. Representative Engineering Manager JD | skipped | The role text you pasted sets the fit snapshot's requirements and the JD-tagged questions |

---

## Upgrade menu

- **Allowing web search** → targets 1 to 3 rerun: a values cheat sheet and value-named VAL questions for Monday, and CO and CASE questions grounded in Larkfield's actual strategy instead of `[generic]`
- **A deeper research pass (L2, up to 6 more searches and 2 more fetches, several more minutes)** → a strategy brief, recent org context such as reorgs or hiring waves, and any candidate reports on Larkfield's EM loop
- **The full job posting** → requirements beyond the one paragraph you pasted (stack, on-call, location, travel), each with a JD-tagged question, and any gate rows the posting contains
- **Your CV** → more evidence cells than the four sentences from your message. F2, F5 and F7 may get quotes instead of answer slots
- **Your answers to the answer slots on F1, F2, F3, F5 and F7, told to me outside a drill** → those rows, and A1, A3, C2, E1, G3, H1 and M2, regenerate around your actual words
- **Interviewer names (the Director, the two staff engineers, the PM, the VP)** → an interviewer read, persona weights per panel member, and at least one reverse question tied to each person's own career path
- **One email to the recruiter** → whether Thursday's panel includes a design or technical exercise, and whether anything is expected in advance. Either would get its own build section
- **The on-call numbers or the reliability-quarter plan, if you can see them** → you could answer C1, G1 and J3 from the record rather than from memory. They're for your own prep; don't bring them into the interview
- **Hours available before Tuesday** → a prep triage: the few things to do well, in order, with the rest marked as insurance
- **A `tuesday-dossier.md` from an underwriting pass** → objections drawn from evidence you've confirmed rather than inferred here, and a prohibited-claims list you've signed off on
