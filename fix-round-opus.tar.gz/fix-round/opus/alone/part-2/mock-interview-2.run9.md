Reading done; now running the default light research pass (company values, interview process, recent news) before building your pack.
I've built your prep pack and saved it as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-2-denied-af4e6f13/AtlasFreight_operations-manager_interview_pack.md`. Since you don't know who's interviewing you, I've assumed a hiring-manager round. The web searches on Atlas Freight were refused because search permission wasn't granted. So nothing in the pack is specific to Atlas: no values, interview format or recent news.

**What's in it:** 23 practice questions across seven interviewer styles. There's also a table comparing each JD requirement with your background, a list of claims to avoid, and reverse questions to ask them.

**The question most worth rehearsing is A1:** "This role runs four sites and twelve supervisors. Today you're over three supervisors. What makes you ready for that jump?" Some version of it will almost certainly come up.

**Three things to settle before the interview:**
- **Years leading people.** The JD requires 5+ years of operations leadership. Your background says 7 years in ops, but not how many of those you had direct reports. Count the exact number and say it as it is.
- **The 40% mis-pick figure.** You need to be able to explain how it was counted and which part of it was your own work.
- **Power BI.** Say plainly that you've never used it. If you start learning it before the interview, you can mention only what you've actually done by then.

Say the word and I'll play the skeptical interviewer on A1, with follow-ups that react to your answers.
I can also save a `tuesday-dossier.md` that records the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Do you know who you're meeting (your future manager, HR, a peer, or a panel)? If the recruiter has said anything about format or asked you to prepare a presentation, that would help too. Either answer changes which questions matter most.

How much time can you give to prep before the interview?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Interviewer:** unknown. **Round:** unknown. Built on the assumption that this is a **hiring-manager round**, the most common shape for this level when nothing else is known. If that's wrong, the persona weights below change.

---

## How to use this pack

- **Personas** = *how* a question is asked (the interviewer's style). **Types** = *what* is being scored.
- Type key:
  - **EXP**: work-experience deep-dive. Do your claims hold up, and what was actually you?
  - **JD**: role-driven. Can you do the job as listed, including the parts where you have gaps?
  - **CASE**: a live problem from the role. Scored on how you structure and reason.
  - **CO**: company and strategy knowledge, i.e. how much homework you did.
  - **VAL**: behavioral and values. Does your past behavior show the values they care about?
- Provenance labels: `[grounded]` means traceable to what you told me. `[inferred]` means a derivation the pack made, and the derivation is named. `[generic]` means a pattern for this kind of role, with no claim about Atlas or about you.
- **Answer slots** are places where the pack can't know the answer. They come in two honest branches: if you did it, say how in your own words; if you didn't, say so plainly. Either branch is a good answer. Making something up is not.
- The guidance is scaffolding, not a script. Say it in your own words.
- Question IDs go by persona (A, B, C, D, E, G, H). Letter F is skipped so question IDs don't clash with the fit-snapshot rows F1–F8.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution work and one site's surge plan. It doesn't mention terminals or four sites, and your words should stay within what it does say: "I've spent seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: "terminal" and "across 4 sites" make a probe on both likely. If any of your work involved a terminal or cross-dock, or spanned more than one site, say what it was and what your part was, in your own words. If none did, say so plainly and stay with the site you ran the plan for |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Running a surge plan touches service performance but doesn't show you were measured on on-time performance. Don't stretch it. Answer slot: if your site tracked on-time or another service measure that was yours to move, name it and say what you did about it. If none was yours, say so plainly and describe how you ran the surge plan |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material says nothing about cost. Answer slot: if you've been accountable for any cost measure at your site, name it and say what you did, in your own words. If you haven't, say so plainly and walk through how you'd start on cost-per-shipment, framed as a plan |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | You already lead supervisors. The step is from three to twelve, and your words stay at three: "Today I'm a senior shift manager over three supervisors." Answer slot: if you've led more than three supervisors at any point, say when and how many. If you haven't, say so plainly, describe how you lead the three now, and say how you'd run twelve, framed as a plan |
| F5 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Your material counts years in ops, not years leading people. When it's unclear, assume the smaller number. A requirement worded like this is often screened literally, so it's a risk to name rather than a barrier. Answer slot: count exactly how many of the seven years you had people reporting to you, and say that number. If it's under five, say the real number plainly and lead with what you did in those years |
| F6 | "build reporting in Excel/Power BI" (Excel) — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a self-rating. It doesn't show that you've built reports. Answer slot: if you've built reports or trackers that other people used, say what they tracked and who used them. If you haven't, say so plainly and describe what you do in Excel today |
| F7 | "build reporting in Excel/Power BI" (Power BI) — JD | "never used Power BI" — your message | none | [grounded] | capability | No rewording closes this gap, and you've said so yourself. Words: "I've never used Power BI." Then explain how you'd learn it, framed as a plan, never as something already done. If you start learning before the interview, you can say what you've actually done by then, and nothing more |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | none | No gap. The certification meets the "plus" as stated. Lead with it in its own words: "I'm Green Belt certified." Your material doesn't say whether the pick-path redesign used Green Belt methods. Answer slot: if it did, say which steps and how, in your own words. If it didn't, say so plainly and keep the two facts separate |

---

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Pushes on the step up from your current role: one site's plan to four sites, 3 supervisors to 12, warehouse to terminal, Power BI | **High.** Hiring managers protect against gaps, and F1, F4, F5 and F7 are the most visible gaps in this pack | Rehearse A1 until it bores you. Build bridges only from what you've stated, say the limit before they do, and finish with a concrete ramp-up plan |
| Case / Strategist | Live problems from the role: on-time slipping, cost-per-shipment rising, peak across four sites | **High.** Hiring managers are buying capability, and this JD has two numbers you'd own | Clarify the question, state the objective, break the problem into parts, set out your approach, name the metric, flag the risks. Think out loud |
| Data-Driven Prober | Digs into the 40% figure and the surge plan | **Medium.** A CV-style number like that tends to draw follow-ups | Know what you can and can't say about how the 40% was counted. Name your weakest assumption first, or say plainly that you don't know |
| Pressure | Time-boxed "why you" and "how much was you" | **Medium.** Composure under pressure matters for a role that runs four sites day to day. This is a judgment from the role, not a known fact about Atlas | Pause. Hold your position through two follow-ups before you concede anything real |
| Conversational | Friendly openers and casual Power BI questions | **Medium.** It usually opens the conversation, and casual questions still count | Have a 90-second arc built only from your quoted facts |
| Values / Behavioral | "Tell me about a time…" stories on leadership and candor | **Low.** No Atlas values or loop structure could be researched, and the generic fallback has no dedicated values round | Choose stories that meet the selection criteria. Where none fits, say so |
| Peer Evaluator | Where the role meets other teams | **Low.** Only applies if a peer joins, which is unknown | Talk about what you bring them as well as what you need. Propose principles for the handoffs rather than guessing at their org |

No loop source establishes Atlas's interview process: the research was refused (see Sources). So these weights rest on the hiring-manager pattern, not on Atlas's documented process, and the generic fallback adds no tilt.

---

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role runs four sites and twelve supervisors. Today you're over three supervisors. What makes you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | **This is the highest-ROI rehearsal in the pack.** Hold only what your quotes carry: "Today I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: if you've led more than three supervisors or worked across more than one site, say when and what your part was. If you haven't, say so plainly before they make you say it. That's naming the limit, not confessing. Then give a ramp-up plan, framed as a plan: how you'd learn four sites and twelve people in the first 90 days. Follow-up 1, "Three isn't twelve": agree with the number and go back to your quotes. Don't add to them. Follow-up 2, "What breaks first?": say what you'd watch for and how, framed as a plan | F4 and F1 are the biggest gaps between your material and the role, so some version of this objection is near-certain. JD, because it scores two stated requirements directly |
| A2 | "We run terminals, not warehouses. What would you still need to learn here?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from your quote: seven years in warehouse and distribution ops. Answer slot: if any of that involved a terminal or cross-dock, say what and what your part was. If none did, say so plainly. Then name what you'd need to learn and who you'd learn it from (the supervisors, the floor), framed as a plan. Don't describe how terminals work unless you know it firsthand | F1's warehouse-to-terminal step is the second-most visible mismatch. JD, because "terminal operations" is the headline requirement |
| A3 | "Our reporting runs in Power BI. You've never used it. Why isn't that a problem?" | JD | [grounded] "never used Power BI"; "solid Excel" | "I've never used Power BI." Say it flat, without apologizing. Answer slot on Excel: if you've built reports others used, describe one. If you haven't, say what you do in Excel. Then give a concrete learning plan with a timeframe, framed as a plan. If you've started learning by interview day, say exactly what you've done, and nothing more | F7 is a gap you've stated yourself. The honest answer is ready-made, so rehearse saying it calmly. JD, because the JD names the tool |
| A4 | "The JD says 5+ years of operations leadership. How many of your seven years were spent leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: give the exact count of years with people reporting to you, worked out before the interview. If it's five or more, say the number and what roles those were. If it's fewer, say the real number plainly, without rounding up, and go back to what your quotes carry. Never call all seven years "leadership" unless they were | F5's ambiguity is the kind a literal screen catches. Having the precise number ready protects your credibility on everything else. JD, because it's the requirement stated as "required" |
| A5 | "Why leave a senior shift manager role, and why Atlas Freight?" | CO | [grounded] "currently a senior shift manager over 3 supervisors" | Give your reason in your own words, and make it about moving toward something rather than escaping. Tie it to what the JD actually offers: multi-site scope, a team of supervisors, and on-time and cost targets. For "why Atlas," use only what you've learned yourself from their website or the posting. This pack has no researched facts about Atlas, so don't borrow any | It's a standard motivation check. CO, because the "why here" half scores homework, which this pack couldn't do for you |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four terminals has slipped for three weeks. Walk me through your first week." | JD | [generic] | First clarify: how on-time is measured, against what promise, and whether all lanes or shifts are affected or only some. Break it down by shift, lane, customer and inbound versus outbound. Form two or three hypotheses, then test them on the floor and in the data. Make one fix with a single owner, track one metric daily, and tell people what you found. It's a live problem, so no claims about your past are needed | Covers the JD's on-time line with CASE delivery. `[generic]` because it's a pattern for the problem, not an Atlas fact |
| B2 | "Cost per shipment is up this quarter. Where do you look first?" | JD | [generic] | Start by checking the measure itself: did cost rise, or did shipment volume or mix fall? Then split cost into its parts (labor, overtime, equipment, damage or rework) and see which one moved. Ask what changed when it started. Give one quick win and one structural fix, and say how you'd stop service from paying the price for the savings | The cost-per-shipment line has no evidence (F3), so a case is where you can show your thinking without needing a story. JD, with CASE delivery |
| B3 | "Peak is coming across four sites. How do you plan the surge?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Start from your quote: you ran the site's peak-season surge plan two years running. Tell it in your own words. Answer slot: if parts of that plan were yours to set rather than inherited, say which. If none were, say so plainly and describe how you ran it. Then scale it up to four sites as a plan: what's standard across sites, what's local, how you'd check readiness at each site, and what you'd watch daily | Your strongest evidence (F1) applied to the role's scale. CASE, because they'll score the four-site plan, not your history |
| B4 | "You inherit twelve supervisors and two of them are struggling. What do you do in your first 60 days?" | CASE | [generic] | Diagnose before acting: is it skill, will or the system? Set clear expectations with a measure attached, hold regular one-on-ones, give support and a timeline, and document it. Protect the other ten from carrying the load. You can mention how you lead your current three only in terms your quotes carry, or as a selection scaffold: pick a time you coached a supervisor through a performance problem. If none comes to mind, say so plainly and answer as a plan | Tests F4's scale jump as a live problem. CASE, because it's a hypothetical |
| B5 | "If you built a weekly ops report for four terminals, what would be on it?" | JD | [generic] | Lead with the two numbers in the JD, on-time and cost-per-shipment, defined the same way at every site. Add a few drivers under each, an owner per metric, and the trend against target. Say you'd build it in Excel first, which is honest, and plan to move it to Power BI as you learn it. Don't claim Power BI skills | Covers the reporting line (F6, F7) through design thinking rather than tool claims. JD, because reporting is a stated responsibility |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-picks 40%. How was that counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slots. Each is in your own words, and "I don't know" is an honest branch: (1) how the 40% was counted, (2) what it's sensitive to, (3) the assumption behind it you'd defend least, which you should name before they do, (4) what part was yours. The pack supplies no baseline, time window or method, so don't adopt any you can't stand behind | F8's headline number will attract probing. EXP, because it tests whether the figure holds up |
| C2 | "Walk me through the pick-path redesign. What did you change?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The facts in your quote are a redesign of the pick path and a mis-pick reduction. Answer slot: describe what changed, in your own words. If others worked on it, say who did what. If it used your Green Belt tools, say how; if it didn't, keep the two facts separate | F8 again. This checks that the story behind the number is yours. EXP |
| C3 | "How did you know the surge plan worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: if you tracked results, name the measure and what it showed. If you didn't track any, say so plainly and say what you'd measure next time. Never invent a figure | F1 and F2. This is where a Prober asks for numbers your material doesn't give. EXP |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal supervisor who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Pause, then pick your strongest points from these quotes: seven years in warehouse and distribution ops, Green Belt certified, a 40% mis-pick cut from redesigning the pick path, and two years running the site's peak-season surge plan. Say them in their own words. Concede plainly that they know the terminals, and say how you'd close that gap, framed as a plan. If you're interrupted, hold your position once before you concede anything | It's time-boxed composure on the F1 gap. JD, because it's a fit judgment |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say exactly what was yours and what was the team's. "We" is for context and "I" is for your contribution. Hold your share through two follow-ups, then concede specifically what wasn't yours. Never grow your share to win the moment | F8's figure under attribution pressure. EXP |
| D3 | "Plenty of people have a Green Belt. What have you actually done with yours?" | JD | [grounded] "green belt certified" | Hold the fact: you're certified. Answer slot: if you've applied it to a project, name it and your part. If the pick-path work used it, say how. If you haven't applied it yet, say so plainly and name where you'd use it first in this role, framed as a plan | It covers the Lean/Six Sigma line (F8) and tests whether you stay composed when a credential is waved off. JD |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Keep it to 90 seconds, built only from these five facts, in your own words, ending with why this role is the next step. Practice it aloud until it fits | The opener sets the frame, and every fact here comes from F1, F4, F8. EXP |
| E2 | "Are you doing anything with Power BI these days?" | JD | [grounded] "never used Power BI" | Casual tone, but it still counts. "I've never used Power BI." Then say only what you've actually started by interview day, or your plan if you haven't started | F7 often comes up casually. JD, because the tool is in the JD |
| E3 | "What does a good day on the floor look like for you?" | EXP | [generic] | Selection scaffold: describe a real day that shows your priorities in order, such as safety, people and flow. If no single day stands out, describe what you check and in what order. Keep it concrete | A rapport question that still scores how you think about operations. EXP |

### G — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: the story needs a named stake, a moment you didn't back down, and a working relationship that was still intact at the end. "We" is for context and "I" is for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you'd handle it | It's a persona stem. No Atlas values could be researched, so this is `[generic]` |
| G2 | "Tell me about a time you had to hold a supervisor accountable." | VAL | [generic] | Selection scaffold: the story needs a clear expectation, the conversation itself, what you did afterwards, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you'd handle it | The theme comes from the JD's "lead a team of 12 supervisors" (F4). VAL in format, though it scores leadership |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than guessing at their org: a shared definition of on-time, one escalation path, and a regular short sync. Show some backbone and some tact. Talk about what you bring their team as well as what you need from it | Only applies if a peer joins. CASE, because it's a hypothetical seam |
| H2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if others contributed to the pick-path work, name their part first, then yours. If it was yours alone, say so plainly without overstating it | F8 seen through a peer's eyes. EXP |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A2, B3, D1 |
| "drive on-time performance" | B1, B5, C3 |
| "cost-per-shipment down" | B2, B5 |
| "lead a team of 12 supervisors" | A1, B4, G2 |
| "build reporting in Excel/Power BI" | A3, B5, E2 |
| "5+ years operations leadership required" | A4 |
| "Lean/Six Sigma a plus" | D3, C2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured here, and how do the four terminals compare right now?" | It shows you expect to own the number from day one, and it tells you what you'd inherit |
| R2 | "What does reporting look like today: Excel, Power BI, or both? Who builds it?" | It addresses your Power BI gap directly and tells you how steep the learning curve is |
| R3 | "How are the twelve supervisors spread across the four sites, and how much time is this role expected to spend at each?" | It shows you're already thinking at multi-site scale |
| R4 | "What's the biggest driver of cost-per-shipment right now, as you see it?" | It invites them to share the real problem, which gives you material for the rest of the conversation |
| R5 | "What would you need to see in the first 90 days to know you'd made the right hire?" | It shows you think in outcomes, and it hands you the success criteria |
| R6 | "Is this a new role or a backfill, and what's changed since it was last filled?" | It tells you what the role is really for |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has run terminal or cross-dock operations | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says warehouse and distribution, not terminals. The slots in A2 and F1 ask only what your work involved |
| Has run operations across multiple sites | Inflated form of F1 | F1's quote at its own scope: "the site's" surge plan. The slot in A1 stays within your actual experience |
| Has led twelve supervisors, or a team that size | Inflated form of F4 | "Today I'm a senior shift manager over three supervisors." |
| Has seven years of operations *leadership* | Inflated form of F5 | "Seven years in warehouse and distribution ops." The slot in A4 asks for the exact count of leadership years |
| Designed or created the peak-season surge plan | Inflated form of F1's "ran" | "I ran the site's peak-season surge plan two years running." The slot in B3 asks which parts were yours to set |
| The pick-path redesign was a Lean/Six Sigma project | Inflated form of F8 | The two quotes stay separate. The slots in C2 and D3 ask whether the project used those methods |
| Has used or built anything in Power BI | Negative you stated, F7 | "I've never used Power BI." No slot |

---

## Sources

- **Provided:** your message (JD excerpt and background). No dossier was consumed.
- **Searches sent:**
  - `"Atlas Freight" regional logistics company values`: refused (web search permission not granted)
  - `"Atlas Freight" interview process operations manager`: refused
  - `"Atlas Freight" terminals news 2026`: refused
- No pages fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search refused. It would have supplied Atlas's published values by name, for VAL themes in G1–G2 and a values cheat sheet if a values round turned up. Those questions stay `[generic]` |
| 2. `Atlas Freight interview process operations` | unavailable | Search refused. It would have set persona weights from Atlas's actual rounds instead of the hiring-manager pattern |
| 3. `Atlas Freight strategy` / recent news | unavailable | Search refused. It would have supplied current facts for A5's "why Atlas" and a strategy-grounded CASE question |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD lines you supplied fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Who you're meeting (your future manager, a peer, a senior executive, HR) and the round type → persona weights recomputed, and banks added or reweighted
- Any recruiter or HR note (focus areas, or a requested presentation or case) → a build section for any announced deliverable
- How much prep time you have → a prioritized prep schedule
- Allowing web search → targets 1–3 run: Atlas's published values, its interview structure and recent news, which turns A5 and G1–G2 from generic to grounded. On top of that, a deeper pass is available (up to 6 more searches and 2 more fetches, several more minutes) for strategy and org context
- The interviewer's name (with search allowed) → an interviewer read and a reverse question tied to their career path
- The full JD text → any requirements this excerpt leaves out become rows and questions
- Your answers to the slots: years with direct reports (F5, A4), how the 40% was counted (C1, D2), any terminal or multi-site exposure (F1, A1, A2), any on-time or cost measure you owned (F2, F3), reports you've built in Excel (F6) → those rows change from slots to rehearsable stories
- A report or tracker you've built, or your Green Belt project write-up → the inspectable artifact that would raise F6 or F8's confidence
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and a sourced list of prohibited claims, instead of ones inferred here
