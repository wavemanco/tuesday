Web search was refused, so I'm building the pack from your JD and background alone and noting what research would have added. Writing it now.
Your prep pack is ready: /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-denied-98e6745e/saltmarsh-games_live-operations-producer_interview_pack.md

I've assumed Tobias would be your manager, since he heads the team this role sits in. Web search was refused, so the pack has nothing on Saltmarsh's values or strategy, or on Tobias himself. It's built from your JD and background alone.

Since Friday is tomorrow, start with the prep triage section. The question to practise most is B1, the "one title to two titles" objection.

Say the word and I'll play the Skeptic on B1 and push back on your answers.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, so you can use it in later sessions.
If you'd like the pack as a Word document, I can convert it.

Would Tobias be your direct manager, and did the recruiter mention any focus areas or a set exercise? Either answer changes how the questions are weighted.
If you allow web search, should I run the basic research (up to 6 searches) plus a deeper pass (up to 6 more searches and 2 more page reads, several minutes)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interview:** 60 minutes, Friday, with Tobias Wrenfield, Head of Live Operations
**Built as:** a hiring-manager round. The role's title suggests Tobias runs the team this role sits in, but your note doesn't say he'd be your manager. If he wouldn't be, the persona weights change.

---

## How to use this pack

Two separate things describe each question:

- **Personas** describe *how* it gets asked: in a friendly way, under pressure, or as a probe.
- **Types** describe *what* is being scored:
  - **VAL**: whether your past behaviour shows the values they care about
  - **EXP**: whether what you say about your experience holds up when probed (what you actually did)
  - **JD**: whether you can do the job as the description lists it, gaps included
  - **CO**: whether you know the company and its games
  - **CASE**: how you structure a live problem from the role, out loud

**Provenance labels:** `[grounded]` means the row traces to your own words or the JD. `[inferred]` means the row is this pack's reasoning from those, and it says what the reasoning is based on. `[generic]` means a common pattern for this kind of role, with no claim about Saltmarsh.

**Answer slots** are places where the pack can't know the answer. Each one has two honest branches. Answer it from what really happened, or say plainly that it didn't happen.

The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage: tonight, before Friday

Today is Thursday, so this assumes one evening. In order:

1. **B1 out loud, three times** (about 30 min). This is the highest-ROI prep in the pack. Run it through both follow-ups until the honest limit sounds calm rather than apologetic.
2. **D1, your 90-second arc** (15 min). Time it.
3. **Play both Saltmarsh titles** (45 min) for D2. Note how events are shown to players and how often they seem to run, and pick one thing you'd ask about. Research couldn't run for this pack, so this is now your only company homework.
4. **C1 and C2** (20 min). Work out what you actually know about how your monthly retention numbers were counted, and what you don't.
5. **A2 and A4** (20 min). Practise the structure, not a script.
6. **Pick five reverse questions** (10 min).

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material covers one calendar for one title, made of content drops. The role is live events across two titles. Keep your words at their own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "two of our mobile titles" makes a probe about juggling titles likely. If you ever supported another title alongside the main one, say how, in your own words. If you didn't, say so plainly and stay with the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but this is a sentence from your message with nothing behind it that an interviewer can inspect, so expect a probe. Lead with it as you said it: you ran the weekly content-drop calendar, for two years |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | Your material doesn't show whether running the calendar meant working across these disciplines. Coordinating disciplines and leading a team are also different things, and your sentence about never leading a team doesn't settle the first. Answer slot: if getting each drop out meant working with design, art, engineering or community, say which ones and what that looked like, in your own words. If it didn't, or someone else did that part, say so plainly and stay with the calendar |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is not the same as owning a review of each event. Keep your words at their own scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you also wrote up or reviewed how a particular drop performed, say how, in your own words. If you didn't, say so plainly and stay with the monthly numbers |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | This is your closest match. Say it as you said it: "I wrote the release checklist our QA team still uses." Answer slot: "manage" means keeping it up to date over time, so expect a question about that. If you kept it updated with QA after writing it, say how. If someone else did, say so plainly and stay with having written it |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Your material gives four years as an associate producer and two years running the calendar. It doesn't say whether the game was a live-service title. Keep the two numbers apart: the calendar was two years, not four. Answer slot: describe the game's live side in your own words. If it had more than the weekly drops, name what. If the weekly drops were all of it, say so plainly |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but expect a close probe. Answer slot: which retention measures they were and how they were counted. If you produced them, say how. If they came to you from someone else, say so plainly and say what you did with them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist the QA team still uses is one piece of writing. The role also writes post-event reviews. Answer slot: if you've written other documents the team relied on, name them in your own words. If the checklist is your main example, stay with it |
| F9 | Running live events that sell in-app purchases. This is a common expectation for mobile live-ops roles. It is not in this JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you have stated yourself, and wording can't close it. Words: "I haven't worked on a game with in-app purchases." Then say how you'd learn it, framed as a plan and not as past experience. Nothing added to make the gap feel smaller |

**Requirement coverage**

| JD requirement | Snapshot row | Covered by |
|---|---|---|
| Plan and run the live-events calendar for two titles | F1 | A1, A5, B1 |
| Coordinate design, art, engineering and community | F3 | A3, B1, P1, P2 |
| Own the post-event review and its KPIs | F4 | A2, A4, B3 |
| Manage the release checklist with QA | F5 | E2, P2 |
| 3+ years producing live-service games or apps | F6 | B5, D1 |
| Experience running a content calendar | F2 | B1, D1 |
| Comfortable with player-retention metrics | F7 | C1, C2, C3 |
| Clear written communication | F8 | D3, A4 |

---

## Persona table

| Persona | How it shows up with Tobias | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from his team's work: plan a quarter, recover from a slipped asset, read a weak event | **High.** A head of function hiring into his own area usually tests capability on real problems. This is the hiring-manager prior; no public signal could adjust it because research was refused | Clarify, then state the goal, the structure, the metrics and the risks. Think aloud, and question one premise per case |
| Skeptic | Quiet probes on the jump: one title to two, associate to producer, a game without in-app purchases | **High.** The other hiring-manager prior, and F1, F3 and F9 give it material | Rehearse B1 until it's boring. Hold to your quotes, state your limit before he asks, and finish with a plan |
| Data-Driven Prober | "Which retention measures? How were they counted?" | **Medium.** The JD names retention metrics and KPIs, and F7 is a claim he can dig into | Know exactly what you can and can't say about how your numbers were built |
| Conversational | Opener, "walk me through your journey", "have you played our games" | **Medium.** Almost every hour-long interview opens this way, and it is still scored | A timed 90-second arc built only from what you've actually done |
| Pressure | Time-boxed "why you" and "how much was actually you" | **Low.** Nothing suggests a stress format, but a head of function may push once | Pause, hold your position through two follow-ups, then concede the specific thing that's true |
| Peer Evaluator | Scenarios where disciplines disagree | **Low.** Tobias isn't a peer, but the JD's coordination line brings in peer-style seam questions | Offer principles for handling the seam, not claimed history |
| Values / Behavioral | "Tell me about a time…" | **Low.** Your note describes one session with Tobias and no values round. Saltmarsh's published values couldn't be checked | Choose your story with care, and use the honest branch when none fits |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We run two titles. Walk me through how you'd plan the next quarter of live events." | CASE | [generic] | Clarify first: what each title is trying to achieve this quarter, how much each discipline can take on, and what's already announced. Then structure it: a backbone of dates per title, the points where the two titles collide, lock dates for each discipline, and what gets cut first. Close with what you'd measure and the biggest risk (shared people across both titles). The question needs no claim about your past, so the guidance makes none. If you mention your own calendar, use F1's words exactly | F1's responsibility asked as a live problem. It's the most likely case because it is the core of the role. CASE because it scores structure |
| A2 | "An event goes live and day-one participation is well below the last one. Diagnose it." | CASE | [generic] | Define participation first. Then work down the list: did it ship correctly (bugs, a release problem)? Did players see it (how it was shown in the game, community comms)? Who is missing (new or returning players, platform, title)? Is it the content (difficulty, rewards) or the timing (a collision with another event or the season)? Say what you'd look at first and why. End with what goes into the post-event review | F4's KPIs and post-event review tested live. CASE because a diagnosis shows reasoning in a way a description can't |
| A3 | "Art tells you the event's assets will land three days late, and players have already been told the date. What do you do?" | CASE | [generic] | Ask what's actually late, and whether a smaller version could ship. Lay out the options: cut scope, swap in another event, or slip the date with comms to players. Give the criteria you'd use to choose (player trust, knock-on effects on the calendar, the other title). Then: who you'd tell, in what order (community early), and what you'd record afterwards | F3's coordination line under time pressure. Likely because it's the everyday shape of the job |
| A4 | "What goes into a good post-event review, and which KPIs would you put in it?" | JD | [generic] | A structure: the goal versus the result; a short set of KPIs (participation, completion, retention around the event window, player sentiment from community, bugs and incidents); what to repeat; what to change, with owners and dates. Name one KPI you'd look at first and say why. Keep the written version short, because it is also a test of F8. The question needs no claim about your past. B3 handles whether you've written one | F4 is the requirement you match least directly, so expect it head-on. JD because it scores a listed responsibility |
| A5 | "Both titles need the same engineer in the same week. How do you decide?" | CASE | [generic] | Clarify what each event is worth and whether the date can move. Set out the criteria: impact on players, whether the date is fixed (announced, seasonal), the cost of slipping each one, and whether either can be cut down. Say who makes the final call and how you'd bring it to them with a recommendation rather than a problem | F1's "two titles" is the newest thing in this role for you, so expect a test of how you prioritise between titles |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've run a calendar for one title. This role is two titles and four disciplines. What makes you ready?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | **The highest-ROI rehearsal in this pack.** Hold to three sentences: "For the last two years I ran the weekly content-drop calendar for our main title. I wrote the release checklist our QA team still uses. And I presented the monthly retention numbers to the studio head." Answer slot (disciplines): if running that calendar meant working with design, art, engineering or community, say which and how, in your own words. If it didn't, or that part sat with someone else, say so plainly and stay with the calendar. Answer slot (titles): if you supported another title alongside, say so. If not, say so. Name the limit before he does: going from one calendar to two is a real step. Say how you'd ramp up, framed as a plan. Follow-up 1 will narrow in on coordination; go back to the calendar and don't add to it. Follow-up 2 may ask about leading; that's B2 | F1 and F3 are where the role's scope most exceeds your material, so this objection will come in some form. JD because it scores the scope the description sets. Deepest rehearsal: two follow-ups and the limit stated first |
| B2 | "Who has reported to you?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain and short: "No one. I haven't led a team." Then go back to what you did run: the calendar and the checklist, in F1's and F5's words. Don't redefine coordination as leading. The JD asks you to coordinate teams, not manage people, and you can say that in one line if he moves on to it | Your own sentence makes this an easy answer, as long as you don't flinch. It's the likely second follow-up to B1. EXP because it checks what was actually yours |
| B3 | "Tell me about a post-event review you've owned." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you wrote or ran a review of how a particular drop performed, say how, in your own words. If you didn't, say so plainly: the material says monthly numbers, not reviews of each event. Then stay with what you did: "I presented the monthly retention numbers to the studio head." Then A4's structure, as what you'd do here | F4's gap, rehearsed so the honest answer is ready. The question assumes a practice the JD names and your quote doesn't carry, so the slot lets that premise be false |
| B4 | "How much have you worked with in-app purchases or monetised events?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | "I haven't worked on a game with in-app purchases." Then a ramp-up plan, framed as a plan: what you'd want to learn first (how an offer fits into an event, what's measured), and who you'd learn it from. Don't hedge it and don't over-apologise. Ask R7 later if it fits | F9 isn't in the JD, but on mobile it's a common probe. Your stated negative makes the honest answer simple. EXP because it asks about your history |
| B5 | "The JD asks for three-plus years producing live-service games. How 'live' was the game you worked on?" | JD | [inferred] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Keep the numbers attached to what they count: four years as an associate producer, and two years running the calendar. Don't say four years of live calendar. Answer slot: describe the game's live side in your own words. If it had more than weekly drops, name what. If the weekly drops were it, say so plainly | F6 is unresolved in your material, and the JD's year requirement makes it a screening-style check. `[inferred]` because "live-service" is the JD's frame and isn't in your words |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers. Which measures, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: name the measures in your own words, and say how they were counted. If you built them, say how. If they came from someone else, such as analytics, say so plainly and say what you did with them: you presented them to the studio head. "I don't know exactly how that was counted" is an honest branch. Use it rather than guess | F7 is a claim he can test directly. EXP because it checks whether the claim survives scrutiny |
| C2 | "What's the weakest assumption behind those numbers?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: name the one assumption you'd defend least, in your own words, before he finds it. If you don't know how they were counted, say so; that is the honest answer, and better than an invented one | The usual second follow-up to C1. Naming the weak spot yourself builds credibility |
| C3 | "How would you tell whether an event actually moved retention, rather than just happening at the same time?" | CASE | [generic] | Compare against a baseline (a similar window without an event). Look at retention for players who joined the event versus similar players who didn't, and watch for self-selection there. Check for confounds: another update, the season, marketing. Say what you'd treat as a real change, and say plainly what you would not conclude | F7 and F4 combined as a live problem. CASE because it tests reasoning |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made only of those four sentences, in your own words. Four years as an associate producer at a puzzle-game studio. For the last two, the weekly content-drop calendar for the main title. The release checklist QA still uses. The monthly retention numbers you presented to the studio head. Then why this role, in your own words. Time it | Almost certain to be the opener, and it sets the frame for the hour. Building the arc only from your sentences keeps it from inflating |
| D2 | "Have you played our games? What did you notice?" | CO | [generic] | Play both titles tonight. Say what you saw (how events are shown in the game, how often they seem to run, one thing that worked for you) and one honest question. Don't state anything about Saltmarsh you didn't see or verify | The only CO prep available, because research couldn't run. A casual question that still scores preparation |
| D3 | "What does a good written update to the team look like, for you?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Point to the checklist as you described it: you wrote it, and QA still uses it. Answer slot: if you've written other documents the team relied on, name them. If not, stay with the checklist. Then give your principles, briefly: who it's for, the decision or action first, owners and dates | F8's requirement asked casually. JD because it's a stated requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who's already run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause. Concede the specific thing first: "I haven't worked on a game with in-app purchases." Then hold to what you did: two years running the weekly content-drop calendar, and the release checklist QA still uses. Don't comment on the other candidate. Hold through one more push, then stop talking | F9 combined with time pressure. JD because it's about fit to the role |
| E2 | "That QA checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it. Answer slot: if others contributed, or it built on an earlier version, say so plainly. If you kept it up to date afterwards, say how. If someone else maintains it now, say so | F5 is your strongest line, so it's the one a pressure interviewer tests. EXP because it's about attribution |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Mid-event, community says players are angry about the difficulty. Design says it's working as intended. What do you do?" | CASE | [generic] | Get the facts first: what players are saying, and what the data shows. Bring design and community together quickly, and decide on criteria (player trust, the goals of the event). Options: a hotfix, adjusting rewards, comms, or holding. Say who makes the final call, and that it goes into the post-event review | F3's coordination line, set at the point where disciplines meet |
| P2 | "Engineering says the update isn't ready. The calendar says it ships tomorrow. What happens?" | CASE | [generic] | The release checklist is the gate, not the calendar. Find out what's not ready and whether it's player-facing. Options: ship without that feature, slip the date, or swap in another event. Make the call with a recommendation, and tell community early | F3 and F5 together. A collaboration scenario where your checklist experience is relevant without any claim being made about it |

### V. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a story that has a real stake, a moment where you didn't back down, and a working relationship that was still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem. No values round is detected, so it has low weight. Use only a story you can tell in full |
| V2 | "When did you put players ahead of a deadline or an internal metric?" | VAL | [generic] | Choose a time with a concrete trade-off, what you chose, and what happened next. If no such time comes to mind, say so plainly, then say how you'd make that call here | A players-first stem adapted to live ops. `[generic]` because Saltmarsh's values couldn't be checked |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a great first 90 days look like for this role, across both titles?" | Shows you're thinking about ramping up, and tells you which title is the priority |
| R2 | "Is the events calendar planned as one shared calendar for both titles, or one per title?" | Goes straight to the core of the role and to how you'd work day to day |
| R3 | "What goes into your post-event review today, and which KPI do you look at first?" | Mirrors the JD and shows you how he thinks about results |
| R4 | "Where do handoffs between design, art, engineering and community most often slip?" | Tells you where the producer is most needed. It's a peer-level question |
| R5 | "How does the release checklist work with QA now? Who updates it?" | Shows interest in the part of the role closest to your own work |
| R6 | "What's changed most in how live ops runs here since you've been leading it?" | Ties the question to his role and invites him to talk about his own work |
| R7 | "How much of the events work touches monetisation, and how would you want someone new to that to ramp up?" | Turns F9 into a candid, forward-looking question, if the gap has already come up |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar across multiple titles | Inflated form of F1 | F1's quote at its own scope. The pack observes that your material says one weekly content-drop calendar for your main title. B1's slot asks only whether you supported another title |
| Ran a live-ops calendar for four years | Inflated form of F6: the number slides from the job to the calendar | The two quotes kept apart: four years as an associate producer, two years running the calendar |
| Managed the cross-discipline team | Inflated form of F3, and contradicted by your sentence about never leading a team | "I haven't led a team." The coordination slot stays inside the calendar you ran |
| Owned post-event reviews and their KPIs | Inflated form of F4 | F4's quote at its own scope: you presented the monthly retention numbers to the studio head. B3's slot asks only whether you reviewed a particular drop |
| Built or calculated the retention analysis | Inflated form of F7 | F7's quote at its own scope: presented. C1's slot asks who produced the numbers |
| Managed the release process with QA | Inflated form of F5 | F5's quote: you wrote the release checklist QA still uses. E2's slot asks about upkeep |
| Has run events on a game with in-app purchases | A negative you stated (F9) | "I haven't worked on a game with in-app purchases." No slot |

---

## Sources

**Provided documents:** the JD text and your background, both from your message.

**Searches sent:**
- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process producer": refused
- "Saltmarsh Games mobile studio news 2026": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

No fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. It would have given the V-bank questions Saltmarsh's own published values in place of generic stems |
| 2. `Saltmarsh Games interview process producer` | unavailable | The search was refused. Your note already sets this session (60 minutes with Tobias); the search would have added the later rounds and whether one of them is a values round |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | The search was refused. It would have given at least one CO or CASE question built on Saltmarsh's current strategy. Without it, D2 is generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. It would have given a reading of the interviewer, persona weights adjusted to his public profile, and a reverse question tied to his career |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** → targets 1–4 run: a reading of Tobias's public profile, persona weights adjusted to it, a reverse question tied to his career, values-themed V questions, and a CO question on Saltmarsh's strategy and the two titles by name
- **Deep research pass** (up to 6 more searches and 2 more fetches, several more minutes, also needs search allowed) → a strategy brief, Tobias's talks or writing, other candidates' reports of the loop, and recent company context
- **Whether Tobias would be your manager** → the persona weights recomputed; a peer or skip-level round reshuffles every bank
- **Any recruiter guidance** (focus areas, or a set exercise such as drafting a calendar) → a build section for any announced deliverable
- **Your answers to the slots in B1, B3, B5 and C1** → F3, F4, F6 and F7 move from `discovery` and `transferability` to quoted evidence, and the guidance becomes story-mapped
- **The checklist itself, a past calendar or a redacted retention deck** → these are the inspectable artifacts this field keeps; they would raise F2, F5 and F7 from `medium` to `high`
- **A tuesday-dossier.md from a prior evaluation of this role** → verified evidence and an externally built prohibited list in place of this pack's own; the pack is complete without one
