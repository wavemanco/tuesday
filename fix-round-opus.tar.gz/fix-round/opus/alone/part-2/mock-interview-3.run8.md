No dossier or CV uploaded. Reading the required references.
Running L1 research: Stripe's values, interview loop, recent strategy, and a representative JD.
I saved your prep pack as `stripe_product-operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles, plus a fit worksheet, reverse questions to ask them, and a check of which role requirements each question covers.

I only had "Stripe, Product Operations Manager, final round" to go on, and my web searches were blocked in this session. So everything in the pack is a general product-ops pattern, not something specific to Stripe. None of it reflects Stripe's own values, interview loop or current strategy, and I didn't fill those in from memory.

The question most worth rehearsing is **C3**: "In the work you'd point to, what was actually yours to decide?" Product ops candidates are often suspected of coordinating rather than owning work, so expect that question in some form.

Before you practise, fill in the eight-row worksheet with your own examples. It also shows you which part of the role you'd honestly call your weakest, which is question C1.

Say the word and I'll play the Skeptic on C3, the pack's highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who's in your final round: your future manager, peers, a skip-level, someone cross-functional? And has the recruiter mentioned focus areas or anything to prepare, like a presentation or case? The answer reweights every bank.
2. Can you paste the job description and your CV or a few lines about your background? Without them, the pack stays a general worksheet; with them, I'll rebuild it around your own experience.
3. Will you allow web search? A standard pass is up to 6 searches and 2 page reads. It would bring in Stripe's published values, its loop structure and its current strategy. A deeper pass adds up to 6 more searches and 2 more reads, and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — final-round prep pack

**Round:** final round, interviewers and session structure not yet known.
**Built from:** the role title and company only. No job description, no CV, and no web research (every search was refused in this session), so every row below is a role-family pattern labeled `[generic]`, and the fit snapshot is a self-assessment worksheet. The upgrade menu at the end says exactly what each missing input would change.

---

## How to use this pack

Two axes organize every question:

- **Personas** are *how* a question arrives: who is asking and in what register.
- **Types** are *what* is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's values, not generic virtue |
| EXP | Whether your experience survives scrutiny: what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework depth: why this company, and thinking at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs run by persona (A, B, C, D, E, G, H). Fit-snapshot rows are F1 to F8, so the letter F is not used for a question bank.

Guidance is scaffolding, not a script. With no CV in hand, no guidance cell here tells you what you did. Each one tells you how to *pick* the story, what a strong one contains, and what to say if you don't have one. Fill in the stories yourself, out loud, in your own words.

---

## Fit snapshot (worksheet)

No job description was supplied and none could be fetched, so the requirements below are typical product operations requirements, written as plain prose and labeled `[generic]`. No CV or background was supplied, so every evidence cell is empty and every row is something for you to fill in.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Runs product launches and release readiness across teams — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like: a launch where you can name what "ready" meant, who signed off, and what you did when something wasn't ready. Selection scaffold: pick the launch where your part is easiest to point to. If no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Builds feedback loops from customers, support and sales into product priorities — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like: a recurring signal you collected, how it reached a decision-maker, and one decision it changed. Selection scaffold: pick an example where you can trace the signal all the way to an outcome. If no such example comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up |
| F3 | Defines and tracks operational metrics and works directly in data — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like: a metric you can define in one sentence, explain how it was counted, and name its weakest assumption. Selection scaffold: pick the number you know best, not the biggest one. If you have no such number, say so plainly and describe how you would pick one for this role |
| F4 | Designs and scales processes and tooling as volume grows — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like: a process before and after, what broke first, and what you changed. Selection scaffold: pick the process change you can describe step by step. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F5 | Coordinates across product, engineering, support, sales, and risk or legal partners — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like: named functions, a point where their goals conflicted, and how it got resolved. Selection scaffold: pick the example with the clearest conflict. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Influences decisions without formal authority — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like: a decision you didn't own, a position you argued, and what happened next, including if you lost. Selection scaffold: pick a time the other person was senior or outside your team. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Clear written communication: docs, launch notes, decision memos — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like: a document someone else acted on without needing a meeting. Selection scaffold: pick a piece of writing you could describe or share. If none comes to mind, say so plainly and say how you write when it matters |
| F8 | Familiarity with the company's product domain (payments and financial infrastructure) — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like: work near the domain, said at its true scope, plus what you have learned about it since applying. Selection scaffold: pick the closest work to the domain. If there is none, say so plainly and say how you would ramp up |

---

## Persona table

No loop source establishes this final round: "final round" says nothing about how many sessions it is or who runs them. The weights below therefore rest on a fallback pattern, the big-tech structured archetype (recruiter, hiring manager, skills or case, behavioral or values, committee), which tilts Values/Behavioral and Case up. That is a pattern, not Stripe's documented process. Send the schedule and they get reweighted.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: plan a launch, diagnose a metric, scale a process | High: 5 questions. A final round usually includes the hiring manager, and the fallback archetype names a skills or case session | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud, and challenge one premise respectfully per case |
| B. Values / Behavioral | Story prompts, STAR-shaped, often from someone outside product ops | High: 4 questions. The fallback archetype puts a behavioral or values session in the loop. Stripe's published values could not be fetched, so these are themed on standard stems rather than mapped to named values | "We" for context, "I" for your part. Choose stories where the hard truth actually landed, and where none did, say so instead of supplying an ending |
| C. Skeptic | Quiet probing of gaps, motivation and "why here, why now" | Medium: 3 questions. Final rounds are where remaining doubts get tested. This bank carries the pack's highest-ROI question, C3 | Rehearse the most predictable objection until it's boring. Say your limit before you're asked, then give a ramp plan |
| D. Data-Driven Prober | "How was that counted?" Follow-ups go two levels deeper than your answer | Medium: 3 questions. Product ops is metric-heavy work, so any number you say will be probed | Know how each number you'll say was counted, and say plainly when you don't know. Name your weakest assumption first |
| E. Peer Evaluator | Seams between teams, "what would you need from me," credit-sharing | Medium: 3 questions. Product ops sits between functions, so a peer from product, support or engineering is plausible | Reciprocity: what you bring their team, not just what you need. Propose seam principles instead of pretending to know the seam |
| G. Pressure | Interruptions, time-boxes, devil's advocate | Low: 2 questions. Possible in any session, but nothing points to a dedicated one | Pause, restate, anchor in what you actually did. Hold through two follow-ups, then concede specifically |
| H. Conversational | Friendly openers that are still scored | Low: 2 questions. Usually the first five minutes of every session | A rehearsed 90-second arc. Treat casual questions on hot topics as scored |

---

## Question banks

All guidance below is a selection scaffold or a case structure. None of it states anything about your past, because nothing about your past is in hand yet.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan to get a new product feature launch-ready across support, sales and risk. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, what could go wrong for them, the date and whether it's movable. Then define "ready" per function (support has docs and macros, sales has positioning, risk has signed off), set a go/no-go owner and checklist, plan the rollout (staged, with a rollback trigger), and name the 2–3 metrics you'd watch in week one. Close on the biggest risk and how you'd catch it early | Launch readiness is the core of most product ops roles (F1, F5). CASE because it is scored on structure, delivered live |
| A2 | "Adoption of a feature launched last month dropped 20% week over week. Diagnose it." | CASE | [generic] | Don't jump to causes. Check the measurement first: did tracking, the definition or the denominator change? Then segment by user type, region, platform and acquisition source to find where the drop sits. Then check what shipped or changed that week, internally and externally. State a hypothesis early and say what data would kill it. End with what you'd do in the next 48 hours | Uses the Case persona's diagnose stem on a product ops metric (F3). CASE because it scores reasoning order, not the "right" cause |
| A3 | "Sales, support and three large customers are all asking for different things. How do you turn that into a prioritization input the PM can use?" | CASE | [generic] | Structure: collect (one intake, tagged consistently), normalize (frequency, revenue or user impact, severity), separate loud from widespread, and hand over a ranked view with the evidence attached, not a verdict. Say what you'd *not* do: decide the roadmap yourself. Mention how you'd close the loop back to the requesters | Feedback loops into product are a role-family core (F2). CASE because the interviewer is watching structure and where you draw your own role's line |
| A4 | "A manual review step that worked at 50 cases a week is now at 500. What do you need to know first?" | CASE | [generic] | Clarify what the review protects against and the cost of a wrong call. Then split the volume: which cases are routine and which need judgment. Options in order: rules or automation for the routine share, tooling for reviewers, then headcount. Name the metric you'd guard (error rate, time to decision) so speed doesn't quietly cost quality | Scaling processes and tooling (F4), framed as a decision. CASE because it presupposes nothing about your past |
| A5 | "Sketch the plan for retiring an old version of a product that some users still depend on. What do you need to know first?" | CASE | [generic] | Clarify who still uses it, how much, and what breaks for them. Then: segment users by impact, set a timeline with notice periods, provide a migration path and support, track migration progress, and decide in advance what happens to stragglers. Name the trade-off between a clean cutoff and user trust, and which way you'd lean | Deprecations and migrations are a recurring launch-adjacent problem (F1). CASE because it tests trade-off judgment |

### B. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, what you said and how, and what happened, including if they disagreed. Use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Values persona stem, and the core of influence without authority (F6). VAL because it scores behavior |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a case where a number your team tracked and a customer's interest pointed different ways. It needs the trade-off stated plainly, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Values persona stem, and relevant to feedback work (F2). VAL because it scores a judgment call, not a result |
| B3 | "Tell me about a time you told a peer team something unwelcome about their work." | VAL | [generic] | Selection scaffold: pick a time you raised a problem with a team you didn't manage. It needs what you saw, how you raised it, and whether the relationship was intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer-level variant of B1's unpopular-truth stem, and cross-functional at heart (F5, F6). VAL because tact and spine are scored together |
| B4 | "When did you put a customer ahead of a launch date?" | VAL | [generic] | Selection scaffold: pick a time a deadline and a customer's interest pulled apart. It needs who decided, what you argued, and what happened. If it wasn't your call, say whose it was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A launch-shaped variant of B2's stem, close to F1. VAL because it tests what you protect under time pressure |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick a real one, and make it specific, not a disguised strength. Fill in the worksheet first: whichever F-row you had the hardest time filling is probably your honest answer, and F8, the domain, is a common one. Then give a concrete ramp plan: what you'd read, who you'd shadow, what you'd ship in the first 30 days | Skeptic stem. JD because it scores self-assessment against the role's requirements (F1–F8) |
| C2 | "Why leave, why here, why now — and why product ops at this company specifically?" | CO | [generic] | Three short beats: what you want to do next (the work, not the title), why this company is where that work is (use only what you've read in the company's own materials, and name where you read it), and why now. Avoid praise anyone could say. One specific thing you read, plus what it made you want to work on, beats five compliments | Skeptic motivation probe, and the pack's only CO question because research could not run. CO because it scores homework |
| C3 | **Highest-ROI prep in this pack.** "Product ops can look a lot like coordination. In the work you'd point to, what was actually yours to decide?" | EXP | [generic] | Selection scaffold: pick the piece of work where something was clearly yours to decide or change, such as a process you set or a call you made. It needs what the decision was, what the alternatives were, and what changed afterward. Before they ask, say which parts were someone else's. If nothing you've done had a decision that was yours, say so plainly, then describe what you ran at its true scope, and how you would take ownership here. Hold-then-concede: to "But the PM made the final call, right?", hold on the part that was yours and concede the rest in plain words. To "What would have happened without you?", say what you know and say plainly what you don't | Inferred without a CV: the objection most often aimed at product ops candidates is that the work was coordination rather than ownership. It gets the deepest rehearsal here because it will come in some form (F5, F6). EXP because it tests attribution |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you'd put on your résumé and walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose the number you understand best, not the biggest. Be ready to say, in your own words, how it was counted, what it's sensitive to, and which part was yours. If you don't know how it was counted, say so plainly. That is an honest answer, and a better one than a method you can't defend | Prober stem, framed as an open prompt because no CV figure is in hand (F3). EXP because it scores attribution precision |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they find it, in your own words, and say what would change if it were wrong. If you don't know of one, say so and say how you'd check | Prober stem, and the natural follow-up to D1. EXP because naming your own weak assumption turns a gotcha into credibility |
| D3 | "Tell me about an operational metric you've tracked. How did you know it measured the right thing?" | EXP | [generic] | Selection scaffold: pick a metric you watched regularly. It needs a one-sentence definition, why it mattered, and a time it misled or nearly misled someone. If no such metric comes to mind, say so plainly, then say how you would pick and sanity-check one in this role | Prober's validation probe on a core requirement (F3). EXP primary, with JD content |

### E. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Propose principles: one owner per decision, written handoffs, disagreements escalated with both options written down. Ask what the seam looks like today. Then say how you disagree with an equal: privately first, with data, and committing once a decision is made | Peer stem, and product ops lives at seams (F5). CASE because it is a live working problem, not a story |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a cross-team piece of work and say plainly who did what, including what wasn't yours. If no such time comes to mind, say how you would handle it. The bar is accuracy, not modesty | Peer stem, and it rhymes with C3 (F5). VAL because it scores how you treat colleagues |
| E3 | "What would you need from my team, and what would we get from you in your first month?" | JD | [generic] | Lead with what you bring them: fewer ad hoc requests, a clear intake, a written launch checklist. Then name one or two specific things you'd need, like access to data, a weekly slot, or a named contact. Keep it short and concrete | Peer's "what would you need from me" theme. JD because it tests whether you understand what the role is for (F5, F7) |

### G. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then three beats: what you'd bring that an insider can't (an outside view, a pattern from elsewhere, said only at the scope you can back), what you'd learn fast, and how. Don't run down the insider. Hold if pushed; if they say an insider knows the systems, concede that plainly and return to your first beat | Pressure stem. JD because it scores fit to the role under a time-box |
| G2 | "That result — how much of it was actually you?" | EXP | [generic] | Same muscle as C3, under interruption. Say your part first, then others' parts, in plain words. Hold on what was yours through two follow-ups. Concede specifics you're unsure of without folding on what you did | Pressure stem, attribution under stress. EXP because it tests whether your account stays the same when pushed |

### H. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A rehearsed 90-second arc: where you started, the one or two turns that matter, and why this role is the next step. End on the role, not on the past. Time it out loud | Conversational stem, asked in some form in nearly every session. Scored on economy |
| H2 | "What are you actually playing with in data tooling or automation these days?" | JD | [generic] | Treat it as scored. Name one real tool or habit and what you use it for, at its true scope. If the honest answer is "not much lately," say so and say what you'd like to learn | Conversational stem on a likely plus-skill (F3, F4). JD because casual questions on hot topics still score capability |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | A1, A5, B4 |
| F2 Feedback loops | A3, B2 |
| F3 Metrics and data | A2, D1, D2, D3, H2 |
| F4 Process and tooling at scale | A4, H2 |
| F5 Cross-functional coordination | A1, B3, C3, E1, E2, E3 |
| F6 Influence without authority | B1, B3, C3 |
| F7 Written communication | — none, and why: usually scored through how you answer and through any written exercise. If the recruiter has announced one, it gets its own build section |
| F8 Domain familiarity | C1, C2 |

Total: 22 questions.

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does product ops here own outright, and what does it do on behalf of PMs?" | It tells you the real scope, and it shows you're already thinking about ownership, the theme of C3 |
| R2 | "Which process is most overdue for a rebuild, and what has stopped it so far?" | It invites them to describe the job's first real problem, and the answer tells you whether the blocker is politics or bandwidth |
| R3 | "Six months in, what would tell you this hire was the right one?" | It surfaces the success criteria you'll actually be judged on |
| R4 | "Where does product feedback get lost today, between support, sales and product?" | It is specific to the role's core loop (F2) and reads as someone ready to work on it |
| R5 | "How does this role work with risk, legal or compliance partners on launches?" | It shows you understand launches in a regulated domain have more gatekeepers, without claiming domain expertise |
| R6 | "What could a new person in this role do in the first month that would genuinely help your team?" | Reciprocity question. Use it with a peer interviewer |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| none listed | No sentence about your experience is in hand, so there is no wording to inflate and no stated negative to give back. Every requirement is silence, which is handled by a selection scaffold with an honest branch, not by a list entry | Not applicable until your CV or your own words arrive. The list is rebuilt from them then |

---

## Sources

Provided documents: none. The only input was the request itself: a final-round interview at Stripe for a Product Operations Manager role.

Searches sent:

- `Stripe operating principles official` — refused
- `Stripe interview process product operations manager final round` — refused
- `Stripe strategy 2026 news stablecoins agentic commerce annual letter` — refused
- `Stripe "Product Operations" job posting responsibilities` — refused

Fetches sent: none.

No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Refused. Would have supplied Stripe's published values by name, which would let VAL questions be mapped to them and enable a values cheat sheet |
| 2. `Stripe interview process product operations` | unavailable | Refused. Would have supplied the loop structure, replacing the archetype fallback behind the persona weights |
| 3. `Stripe strategy` / recent news | unavailable | Refused. Would have grounded CO and CASE questions in current priorities. Without it, C2 is the only CO question and every case is generic |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so no query could be formed |
| 5. representative `Product Operations Manager` JD | unavailable | Refused. Would have turned the fit snapshot's requirements into quoted `[inferred]` lines and raised answer slots |

---

## Upgrade menu

- **The JD text** → F1–F8 become the posting's own quoted requirements, `[grounded]`, and any requirement it names that this pack doesn't cover gets a JD-tagged question
- **Your CV or a few lines on your background** → the worksheet becomes a real fit snapshot. Scaffolds turn into story-mapped guidance quoting your own sentences, every headline number gets a defend-the-number question, and C3 gets aimed at your actual biggest gap
- **Who's in the final round, and how each person relates to the role** (hiring manager, peers, skip-level, cross-functional) → persona weights recomputed from the real loop instead of the archetype fallback, plus a reciprocity question placed where it fits
- **Interviewer names** → an interviewer read from their public professional footprint and a reverse question tied to their path
- **The recruiter's prep email** → coverage of stated focus areas, plus a build section for any announced presentation, case or written exercise
- **Allowing web search** (standard pass, up to 6 searches and 2 fetches) → Stripe's published values by name and a values cheat sheet, the loop structure, and CO and CASE questions grounded in current strategy
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, role-family loop reports and recent org context, for a sharper differentiator bank
- **Prep time available** → a prioritized triage schedule at the top of the pack
- **If your final is several sessions, the schedule** → a mini-pack per session, each with its own weights and reverse questions
- **A work sample you'd be willing to discuss**, such as a launch checklist, process doc or dashboard you built → evidence that can be inspected, which raises confidence on the rows it covers
- **A `tuesday-dossier.md` from job-underwriter** → verified evidence, a named top objection and guardrails on what not to claim, all carried into the pack
