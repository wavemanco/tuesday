I've saved your prep pack as `ashgrove_member-experience-lead_interview_pack.md`. It covers all three rounds on 21 November, using only what you sent me, with no web searches. Your pasted values, the recruiter's email and the July strategy points already covered everything a search would have looked for.

- **Your hardest question will be B2.** It goes something like: "Your complaints work is one branch, and you've never worked in a contact centre — why should I believe you can own this across every branch?" Your future manager is the most likely person to ask it. The pack gives you a way to name the limit before they do, hold what you've actually done, and answer the two follow-ups. B4, on presenting to senior leaders, is the next hardest.
- **Round by round:**
  - **Recruiter:** a 90-second story built from your three background sentences, plus short answers on the contact-centre and presenting gaps.
  - **Head of Member Services:** behavioural questions and the scope questions.
  - **Branch-manager panel:** one question per value, a 20-minute structure for the escalation case with three positions you can defend, and questions on the strategy.
- **Some answers depend on things you didn't tell me.** For example: what your spreadsheet tracks, whether it's in Excel, and whether your complaints log followed regulatory rules. For each, the pack gives you an honest answer whether the true answer is yes or no.
- **Things not to say, especially to the branch managers.** Don't claim you ran a branch, wrote the escalation script, coached supervisors or presented above regional level. You told me none of those, and a follow-up question would expose it. The pack lists these with the honest version of each.
- **Two things to handle carefully.** Moving eight branches into five hubs may be personal for the panel, so the pack treats it gently. It also doesn't name any complaints regulator, because I don't know which country's rules you work under.

Say the word and I'll play the Head of Member Services on B2, with follow-ups that react to what you say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of loop:** 21 November 2026 — three rounds, one day (loop mode)
**Round 1:** 30 minutes with the recruiter
**Round 2:** 45 minutes with the Head of Member Services, your would-be manager, "mostly behavioural"
**Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four values
**Interviewer names:** not assigned yet

---

## How to use this pack

Two axes run through every question:

- **Personas** say *how* a question is asked — friendly, sceptical, under pressure, as a live case.
- **Types** say *what* is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether what you've done shows Ashgrove's four published values, not generic virtue |
| EXP | Whether what you've told them holds up under follow-ups; what was actually yours |
| JD | Whether you can do the job as listed, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | How you structure and reason through a live problem from the role |

Every question has a **Provenance** label: `[grounded]` = traceable to your message, the JD, the values page text or the strategy points you sent; `[inferred]` = this pack's own reading of them, with the reasoning named; `[generic]` = a common pattern for this kind of role, not a fact about Ashgrove.

**Answer slots** appear where the honest answer depends on something your message doesn't say. Each one has two branches: if you did it, say how in your own words; if you didn't, or it wasn't yours, say so plainly. Both branches are good answers.

The guidance is scaffolding, not a script. Say it your own way.

**Highest-ROI prep in this pack: B2.** It's the scope objection: one branch's complaints log against a role covering every branch plus the contact centre, which you haven't worked in. Some version of it will come up. Rehearse it until it bores you. B4, on presenting to senior leaders, comes second.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's formal complaints log. It doesn't describe a process across branches, so the words stay at that size: "I handled my branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. Say in your own words what came to you and what you did with it. If parts of it went to someone else, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You've stated this gap yourself. Words: "I haven't worked in a contact centre." Then say how you'd learn it, as a plan and never as a past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says you built a monthly complaints spreadsheet and that your regional manager uses it. It doesn't show what the spreadsheet measures. Answer slot: the JD names volumes and resolution times, so expect "what's in it?" If it tracks either, say which and how you set that up, in your own words. If it doesn't, say so plainly, say what it does track, and say how you'd add the missing measure |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the escalation script and spent your last three years as a branch supervisor. It doesn't say you've coached supervisors. Words: "I trained new tellers on our escalation script, and my last three years have been as a branch supervisor." Answer slot: if any part of how that training ran was yours to decide, say which, in your own words. If you delivered it as it was given to you, say so plainly. Then explain how you'd adapt it for supervisors, as a plan |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show any digital or self-service work. Answer slot: if you've worked with a digital team or on an online or app journey in any way, say what and what your part was, in your own words. If you haven't, say so plainly and explain how you'd bring complaint patterns to a digital team, as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Six years is more than four. Your quote uses retail-banking terms and the JD uses customer-operations terms. Keep your own words: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer map that onto customer operations. Don't relabel your history in the JD's vocabulary |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" touches "regulated" without showing it. This pack's reading is that the gap between those two words is where a prober will push. Answer slot: if the log was kept to rules your bank had to follow on complaints, say which rules and what they required of you, in your own words. If you don't know, or no such rules applied to the log, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this gap yourself. Words: "I haven't presented above regional level." Answer slot: if you have presented at regional level, say what and to whom, in your own words. If you haven't, say so plainly. Either way, follow with a plan. Never imply the spreadsheet was presented upward: the quote says your regional manager uses it, not that you presented it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says spreadsheet. It doesn't say which tool or which features. Answer slot: if it's built in Excel, say so and name what you used to build it, in your own words. If it's another tool, say so plainly |

---

## Graded deliverable — the 20-minute complaint-escalation case (Round 3)

The recruiter said the panel runs a 20-minute case on a complaint escalation. You won't know the scenario in advance, so this section gives you a structure and positions to hold, not a pre-written answer.

**Facts about you that the case can use. Only these, and only in these words:**

| Fit row | Quote you can lean on | How it shows up in the case |
|---|---|---|
| F1 | "I handled the branch's formal complaints log and trained new tellers on our escalation script." | "When I handled my branch's formal complaints log…" — useful when you explain why you'd log and track the escalation. Keep it at one branch |
| F4 | "I handled the branch's formal complaints log and trained new tellers on our escalation script." | "I've trained new tellers on our escalation script…" — useful when the case asks how you'd stop it happening again |
| F3 | "I built the monthly complaints spreadsheet our regional manager uses." | Useful when you get to "how would you know if this is a pattern?" Say what the spreadsheet tracks only if F3's answer slot is true for you |

**A 20-minute shape `[generic]`, a common case structure and not Ashgrove's scoring sheet:**

1. **Clarify (2–3 min).** Ask who the member is, what happened, what they've already been told, how long it has been open, whether they might be vulnerable, and whether any regulatory response deadline applies. Asking before solving is part of what's scored.
2. **The member first (4 min).** Say what happens today: who calls the member, what they hear, in plain words. This is where "Members First, Always" and "Plain Words" score.
3. **Own it (4 min).** One named person holds the case until it's closed, across branch and contact centre ("Own the Fix"). Say who that is and how handoffs work.
4. **Resolve and respond (4 min).** Investigate, decide, give a written response the member understands first time. Say you'd check the regulated timescales and response requirements that apply. Don't cite a specific rule unless you know it applies to Ashgrove.
5. **Root cause and learning (3 min).** Is it one member or a pattern? How does it reach the monthly report? What would you coach the branch supervisor on? Treat the supervisor as someone to coach, not someone to blame.
6. **Close (1 min).** Name the member outcome and one process change.

**Three positions you can defend, each with its honest concession:**

| Thesis | Concession to say aloud |
|---|---|
| Fix this member's problem first, then fix the process | Moving fast can cut an investigation short. Say where you'd stop and check before promising anything |
| One named owner keeps the escalation until it's closed, even when it crosses branch and contact centre | A single owner can become a bottleneck, so name the rule for when it gets handed on |
| Every escalation goes into the monthly report as a cause, not just a count | That adds work for supervisors, so say how you'd keep it light |

**How to stand out from the standard answer `[generic]`.** Most candidates will say "apologise, investigate, resolve, follow up." Show you know that structure in one line, then spend your time where it diverges:

- Use the values' own words at the moments they apply. Don't recite them as a list.
- Write the member's response in plain words: say one actual sentence you'd send.
- Treat the escalating supervisor as someone to coach. This links to the coaching line in the JD and to the branch managers sitting in front of you.

**No close was requested.** None was named, so end on the member outcome. It matches "Members First, Always", which the panel is scoring.

---

## Grounding brief — Ashgrove's 2026 strategy

Built from your summary of the July 2026 strategy brief, not from the brief's own text. Paste the brief to get Ashgrove's exact wording.

| Strategy point | What it means for this role | Source |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | More complaints will start in, or be about, self-service journeys. This is the "work with digital teams" line in the JD | Strategy brief, July 2026, via your message |
| Consolidate eight branches into five hubs over 2027 | Branch closures and changes are a likely source of member complaints. Your panel are branch managers, so this pack reads the topic as possibly personal for them: be careful and respectful with it | Strategy brief, via your message; the sensitivity is this pack's inference |
| Small-business lending product in Q1 2027 | A new product needs complaints handling ready before launch | Strategy brief, via your message |
| Main competitive pressure: app-only banks | Complaint handling and the human branch are areas where a member-owned credit union can compete. Frame this as a hypothesis, not as fact about app-only banks | Strategy brief, via your message; the framing is this pack's inference |

**Vocabulary to use:** "members" (never "customers"), "branches" and "hubs", "contact centre", "self-service journeys", "digital channels", and the four values by their exact names.

---

# Round 1 — Recruiter, 30 minutes

## Persona weights

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk-through of your background and motivation | High. The recruiter-screen prior, and nothing in the email changes it | A 90-second arc built only from your three background sentences. Treat every casual question as scored |
| Skeptic (light) | Checks on the stated requirements and the contact-centre gap | Medium. Recruiters screen against the JD's listed requirements | Short, plain answers to the gap questions. The deep versions are for Round 2 |
| Pressure | — | Low. Nothing in the email points to it | — |

## Question bank — Round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, three beats, each one a sentence you gave: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Then the turn to this role. Answer slot: why complaints and member experience is your next step, in your own words | Opens almost every screen. All three beats rest on F6, F1, F3 and F4, so the arc carries no claim the later rounds can break. EXP because it sets the record everything after is checked against |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Answer slot: your own reason, in your own words. If it's about the member-owned model or one of the four values, name the value exactly as Ashgrove writes it. If it's practical, such as location or the role itself, say that plainly. Don't recite all four values | A standard motivation check. CO because a strong answer shows you read the values page and the strategy |
| A3 | "Why are you looking to leave your current role now?" | EXP | [generic] | Answer slot: your real reason, in your own words, said positively and without criticising your current employer. Keep it under 30 seconds and end it pointing at this role | The "why leave, why now" stem. EXP because it is checked against what you say later in the day |
| A4 | "The JD asks for 4+ years in financial-services customer operations — how does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | "Six years in retail banking, the last three as a branch supervisor." Stop there. Let them map it to customer operations | F6 is a likely screening line. JD because it scores a stated requirement |
| A5 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | "No, I haven't worked in a contact centre." Then one sentence of plan, such as how you'd learn the contact-centre side in your first weeks. No apology, no padding. The long version belongs in B2 | F2 is the gap the role's scope makes obvious. Rehearsing the short form stops it from turning into a ramble here |
| A6 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it's in Excel, say so and name what you used to build it. If it's another tool, say so plainly. Name only features you've actually used | F9. JD because it's a listed requirement that a recruiter can tick off |
| A7 | "The role presents to senior leaders. How do you feel about that?" | JD | [grounded] "I've never presented to anyone above regional level." | "I haven't presented above regional level yet." Then one sentence on how you'd prepare. Keep it calm and short | F8. A light first look at the objection B4 takes in depth |
| A8 | "What are your salary expectations and notice period?" | EXP | [generic] | Answer slot: your actual figure or range and your actual notice period. Know both before the call | A routine recruiter check. If you're not ready for it, a scored moment can feel casual |

## Reverse questions — Round 1

| Question | Why it lands |
|---|---|
| "How do the three rounds' scores come together? Does the panel's values score stand on its own?" | Shows you understand the process and tells you where the weight sits |
| "Is the 20-minute case given on the day, or will I see anything beforehand?" | Practical, and it shapes your final prep |
| "Is this a new role, or replacing someone?" | Tells you whether you'd be building the complaints process or inheriting one |
| "What's the timeline after 21 November?" | Logistics that recruiters expect to be asked |
| "Is there anything in my background you'd suggest I speak to more in the later rounds?" | Turns the recruiter into a coach and surfaces the objections early |

---

# Round 2 — Head of Member Services (your manager), 45 minutes, mostly behavioural

## Persona weights

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" questions on complaints, coaching and ownership | High. The recruiter said this round is mostly behavioural, which outweighs the usual hiring-manager tilt towards cases | Stories only where your own sentences carry them. Where none do, the selection scaffold and its honest branch |
| Skeptic | Pushes on scope: one branch against all branches plus the contact centre, and presenting upward | High. A hiring manager is reducing risk on the hire, and F1, F2 and F8 are the obvious gaps | B2 and B4, rehearsed with hold-then-concede |
| Case / Strategist | The strategy points in question form: digital shift, escalation judgement | Medium. Part of the usual hiring-manager pattern, softened by "mostly behavioural" | Clarify, structure, use Ashgrove's vocabulary |
| Data-Driven Prober | Asks about the spreadsheet: what it counts and who uses it | Medium-low. The JD's monthly-reporting line invites it | Answer F3's slot honestly. If you don't know how a figure is counted, say so |

## Question bank — Round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint you handled that was difficult." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a complaint from the branch's formal complaints log that you handled. A strong one has a member with a real problem, a moment where you made a decision, and an outcome you can state. Use "we" for the context and "I" for what you did. If no such complaint comes to mind, say so plainly and give the nearest thing your material does carry, such as how the log worked, or how you'd handle a hard one | F1 is your strongest evidence, and a behavioural round will ask for a specific case from it. VAL because Members First and Own the Fix are both scored on stories like this |
| B2 | "Your complaints experience is one branch. This role owns complaints across every branch and the contact centre, and you haven't worked in a contact centre. Why should I believe you can do it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre" | **Highest-ROI rehearsal.** Name the limit before they press. "You're right on both: my complaints work has been one branch's formal log, and I haven't worked in a contact centre." Then hold only what the quote carries: "I handled that log, and I trained new tellers on our escalation script." Then the plan, said as a plan. Answer slot: what you'd do in your first 30–60 days to learn the contact centre and the other branches, in your own words. Keep it concrete, e.g. sitting with agents, following a complaint from call to close. **Follow-up 1:** "So what do you know about contact-centre complaints?" Answer: "Not from the inside. That's what the first weeks are for." Don't fill the gap with guesses. **Follow-up 2:** "Wouldn't someone from the contact centre be safer?" Hold without running anyone down. Concede the specific point: "They'd know the contact centre better on day one, and that's real." Then return to what you said and your plan | Built on F1 and F2. This is where the role's scope presses hardest on what you've described, so it will come up in some form, most likely from your future manager. JD because it scores the stated requirement directly |
| B3 | "Talk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you built and who uses it, in the quote's words. Answer slot: what it tracks; whether that includes volumes or resolution times; how each figure is counted; and which figure you'd trust least and why, in your own words. If you don't know how a figure is counted, say so plainly. Answer slot: if you know what your regional manager uses it for, say so. If you don't, say so plainly. Don't guess at its impact | F3 and F9. The JD's monthly-reporting line makes this the main probe on your reporting. Also tagged JD, because it covers the reporting requirement |
| B4 | "You'll be presenting to senior leaders every month. You haven't presented above regional level. How will you handle that?" | JD | [grounded] "I've never presented to anyone above regional level." | The second-deepest rehearsal. Open with the limit: "I haven't presented above regional level." Answer slot: if you've presented at regional level, say what and to whom, in your own words. If you haven't, say so plainly. Then a plan: how you'd prepare the first monthly pack, ask for feedback, and practise. Hold: don't imply the spreadsheet was presented upward. **Follow-up:** "Senior leaders can be tough. What if they challenge your numbers?" Answer: "I'd say what I know and what I don't, and come back with the answer." That's a commitment you can make, not a past you're claiming | F8. Monthly senior reporting is in the JD and you've stated this gap yourself, so it's a near-certain probe from the person you'd report through |
| B5 | "Tell me about a time you helped someone get better at handling escalations." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story mapped to F4: you trained new tellers on the escalation script, and the script is "our" script, so don't claim you wrote it. Answer slot: if any part of how the training ran was yours to decide, say which and why, in your own words. If you delivered it as it was given to you, say so plainly and describe what the tellers learned. Then bridge with a plan for supervisors | F4 is your only evidence for the coaching line in the JD. VAL because Plain Words is scored on how you explain things |
| B6 | "How do you decide when a complaint should be escalated — and when it shouldn't?" | CASE | [generic] | Structure it: what the member is asking for, what the front line can authorise, the risk of harm or a regulatory deadline, and whether the member is vulnerable. Then who it goes to and how they hear back. Speak in principles. Don't describe your current bank's script unless you're sure of its content | A live judgement question that sits under the coaching requirement. CASE because it asks for reasoning, not a record |
| B7 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] | Structure it: complaints will arrive through new channels, and some will be about the digital journeys themselves; some members won't want to move or will struggle; complaint data becomes feedback for digital teams. Challenge one premise respectfully, for example: how does the 40% target sit alongside members who prefer the branch, under "Members First, Always"? Frame these as hypotheses | Strategy point 1, and the JD's digital line. CO because it tests whether you've engaged with the strategy |
| B8 | "Have you worked with digital teams on self-service journeys?" | JD | [grounded] | Answer slot (F5): if you've worked with a digital team or on an online or app journey in any way, say what and what your part was, in your own words. If you haven't, say "Not directly" plainly, then say how you'd bring complaint patterns to a digital team | F5 is a listed requirement with no evidence in your material, so it needs a ready answer. JD because it scores the requirement |
| B9 | "Were the complaints in your log regulated complaints? What rules were you working to?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the log was, in your words: the branch's formal complaints log. Answer slot: if it was kept to rules your bank had to follow, name them and say what they required of you, in your own words. If you're not sure, say so plainly and stay with the log you handled. Don't name a regulation you can't explain | F7. "Regulated" is in the JD's requirements and your material says "formal". `[inferred]` because the link between the two is this pack's reading |
| B10 | "Tell me about a time you found a problem nobody had asked you to fix." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you started the spreadsheet because you saw a gap, say that, and what the gap was, in your own words. If it was asked of you, say so plainly and pick another time you spotted a problem and kept hold of it. If no such time comes to mind, say so and say how you'd handle one | Themed on "Own the Fix". The values may come up in your manager's round as well as the panel's. Built on F3 only through the slot, because your material doesn't say why you built it |

## Reverse questions — Round 2

| Question | Why it lands |
|---|---|
| "What would a good first monthly complaints report from this role look like to you?" | Shows you're already thinking about the deliverable, and tells you what your manager values |
| "Where are complaints hardest today: in the branches or in the contact centre?" | Faces your biggest gap head on and tells you where to start learning |
| "How do you expect the move to five hubs to change how complaints flow?" | Shows you know the strategy and links it to the role |
| "How do the digital teams hear about complaints today?" | Opens up the self-service part of the JD, where your material is thinnest |
| "What would you want me to have fixed by month six?" | An "Own the Fix" question that shows you're thinking about outcomes |

---

# Round 3 — Panel of two branch managers, 60 minutes, values round plus 20-minute case

## Persona weights

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Questions mapped to each of the four values, scored | High. The recruiter said the panel scores against the four values | The cheat sheet below. One story or an honest scaffold per value |
| Case / Strategist | The 20-minute escalation case, plus strategy questions | High. The recruiter announced the case | The graded-deliverable structure above |
| Peer Evaluator | "You'd be coaching our supervisors — what would you need from us?" | Medium. Branch managers would work alongside this role, and the JD has it coaching their supervisors | Frame it as reciprocity: what you bring their branches, not just what you need |
| Pressure | Hub consolidation and "why would my supervisors listen to you" | Medium-low. The panel's stake in both is real | Pause, restate the question, hold and then concede |

## Values cheat sheet

| Value (official name) | Working meaning | Your story |
|---|---|---|
| Members First, Always | Make decisions from the member's point of view | F1 — "I handled the branch's formal complaints log and trained new tellers on our escalation script." Selection scaffold: pick a complaint from that log where you decided something with the member's experience in mind. If none comes to mind, say so plainly and say how you'd make that call |
| Plain Words | If it needs explaining twice, rewrite it | F4 — "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if you changed how you explained the script to new tellers, say what and why. If not, say so plainly and pick another time you made something clearer, or say how you'd handle it |
| Neighbours, Not Numbers | Each branch belongs to its town | Selection scaffold: pick a time when knowing your branch's community changed how you handled a member. If none comes to mind, say so plainly and say how you'd keep local context in a cross-branch process |
| Own the Fix | Whoever finds the problem stays with it until it's solved | F3 — "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because you saw a problem, say that. If not, say so plainly and pick another time you kept hold of a problem until it was solved |

## Question bank — Round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a decision you made from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold from the log: a member, your decision, the outcome. Use "I" for what you did. If no such decision comes to mind, say so plainly and give the nearest thing your material does carry, or how you'd make that call | Uses the "Members First, Always" wording directly. VAL because the panel scores against it |
| C2 | "Tell me about a time something had to be explained twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: if training new tellers on the escalation script ever meant changing how you explained it, say what you changed, in your own words. If not, say so plainly, pick another time, or say how you'd handle it | Uses the "Plain Words" wording directly. F4's teller training is the nearest material |
| C3 | "You built a complaints spreadsheet. How do you stop the numbers hiding the member?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold a view rather than a past: numbers and neighbours aren't opposites, and the count shows where to look. Answer slot: if the spreadsheet ever led you to act for particular members, say what happened, in your own words. If not, say so plainly and say how you'd use it that way | "Neighbours, Not Numbers" pressed against F3. A values panel may well test the tension between your reporting and that value |
| C4 | "Tell me about a time local knowledge changed how you handled a member." | VAL | [grounded] | Selection scaffold: a specific member, what you knew about the town or community, and what you did differently because of it. If none comes to mind, say so plainly and say how you'd keep local context in a cross-branch process | "Neighbours, Not Numbers". Your material carries no story for it, so it gets a scaffold |
| C5 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] | Selection scaffold: a problem you noticed, the moment you could have handed it off, and the point it was actually solved. If B10's spreadsheet slot is true for you, use that story. If no such time comes to mind, say so plainly and say how you'd handle one | The "Own the Fix" wording. Each value needs its own question |
| C6 | "You'd be coaching our supervisors on escalations. What would you need from us, and what would we get from you?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Reciprocity first. What they'd get: someone whose last three years have been as a branch supervisor and who has trained new tellers on an escalation script, in those words. What you'd need: time with their supervisors and their view of which escalations go wrong. Don't claim to know their branches | Peer Evaluator: they'd share this work with you. Draws on F4 and F6. VAL and JD, because it's partnership fit on the coaching line |
| C7 | "You've been a branch supervisor. Why would my supervisors take escalation coaching from you rather than from me?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause first. Hold: "My last three years have been as a branch supervisor, so I know the job they do. I've also trained new tellers on our escalation script." Concede the specific point: "You know your branch and your people far better than I do. The coaching should go through you, not around you." Never imply you've run a branch | Pressure, from people senior to the supervisors you'd coach. F4 and F6 at their own size |
| C8 | "Over 2027, eight branches become five hubs. What happens to complaints, and what would you do?" | CO | [grounded] | Be careful: this may be personal for the panel. Structure it: members in affected towns, the complaints a change like this tends to bring (access, travel, losing a familiar face), and how you'd prepare branches before, during and after. Tie it to "Neighbours, Not Numbers". Frame it as hypotheses and ask what they're already seeing | Strategy point 2, and the people who live it are in the room. CO and CASE |
| C9 | "App-only banks are our main competitive pressure. Where can complaint handling help us?" | CO | [grounded] | Hypotheses, not facts about competitors: a human who owns the fix, local branches, plain-words responses. Challenge one premise respectfully, for example that members also expect the app to be good, which links back to self-service journeys | Strategy point 4. CO because it tests whether you think at Ashgrove's level |
| C10 | "Small-business lending launches in Q1 2027. How would you get complaints ready for it?" | CASE | [grounded] | Clarify: who the members are, what can go wrong (decisions, delays, terms). Then before-launch steps: categories in the log and report, briefing supervisors, plain-words responses, and agreeing escalation routes with the product team. Then the first 90 days of watching the data | Strategy point 3. A live problem on Ashgrove's actual roadmap |
| C11 | Case warm-up: "A member asks to escalate after a supervisor's response. Walk us through it." | CASE | [generic] | Rehearse the six-step structure from the graded-deliverable section, timed to 20 minutes | A practice run for the announced case. `[generic]` because the real scenario is unknown |

## Reverse questions — Round 3

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would genuinely help your supervisors?" | The reciprocity question for colleagues you'd work alongside |
| "When a complaint goes beyond your branch today, where does it go, and how do you hear back?" | Shows you care how it works now and gives you a picture of the current process |
| "What does 'Neighbours, Not Numbers' look like in your branch?" | Asks them to tell their own values story, in the round that scores those values |
| "Which escalations do your supervisors find hardest?" | Tells you what to coach, and shows you'll listen first |
| "As the hub changes come in 2027, what would you want a complaints lead to watch for in your towns?" | Treats the consolidation with respect and treats them as the experts |

---

## Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| Own the complaints process end to end across branches | F1 | B2, B1, C1 |
| …and the contact centre | F2 | A5, B2 |
| Monthly reporting on volumes and resolution times | F3 | B3, C3 |
| Coach branch supervisors on escalations | F4 | B5, B6, C6, C7 |
| Work with digital teams on self-service journeys | F5 | B8, B7 |
| 4+ years in financial-services customer operations | F6 | A4 |
| Experience handling regulated complaints | F7 | B9 |
| Confident presenting to senior leaders | F8 | B4, A7 |
| Comfortable with Excel reporting | F9 | A6, B3 |

---

## Prohibited claims — what this pack won't coach

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own size. This pack observes that your material describes one branch's log, not a multi-branch process. Answer slots stay inside the log |
| Has worked in a contact centre | A gap you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders, executives or a board | A gap you stated, F8 | "I haven't presented above regional level." The F8 slot covers regional level only |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own size: you trained new tellers on the escalation script. Supervisor coaching is said only as a plan |
| Wrote or designed the escalation script | Inflated form of F4 ("our escalation script") | F4's quote: you trained tellers on it. Whether any of the training was yours to shape stays an answer slot |
| Handled regulated complaints | Inflated form of F7 ("formal complaints log") | F7's quote at its own size. Whether rules applied to the log stays an answer slot |
| The spreadsheet tracks resolution times, or drives regional decisions | Inflated form of F3 ("our regional manager uses") | F3's quote. What it tracks and what it's used for stay answer slots |
| Managed or ran a branch | Inflated form of F6 ("branch supervisor") | "The last three as a branch supervisor." This matters most in front of branch managers |

---

## Sources

**Provided documents**

- Job description: pasted in your message
- Values: pasted in your message, which says they were copied on 12 November 2026 from ashgrovecu.org/about/values. Not fetched
- Recruiter's email on the process: pasted in your message
- Strategy points: your summary of Ashgrove's July 2026 strategy brief, which the recruiter sent you. The brief's own text wasn't pasted
- Your background: your message

No CV and no dossier were provided.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted, copied today, already settles the cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email sets out all three rounds, the case and the values scoring, which settles the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 strategy points are under six months old and already settle the CO questions and the grounding brief |
| 4. Interviewer names | n/a | No interviewers assigned, so there was nothing to search for. The interviewer read is left out |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted settles the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Answers to the answer slots, said here rather than in a drill** → F1, F3, F4, F5, F7 and F9 move from slots to story-mapped guidance, and A6, B1, B3, B5, B8, B9, B10, C2 and C3 get regenerated
- **Your CV** → dates, employer and team size in the fit snapshot, and a fuller A1 arc
- **The country or regulator your current complaints work falls under** → F7, B9 and the case's regulatory step become specific instead of "check the rules that apply"
- **Interviewer names, once assigned** → a read on each interviewer from their public professional profile, persona weights per person, and a reverse question tied to each person's career path
- **The strategy brief's own text** → the grounding brief uses Ashgrove's exact wording and figures instead of your summary
- **How much prep time you have before 21 November** → a prioritised day-by-day prep schedule
- **A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes)** → recent Ashgrove news and organisation changes, plus published candidate reports on credit-union interview loops, labelled by source quality
- **A tuesday-dossier.md from an earlier evaluation of this role, if you have one** → the highest-ROI objection taken from evidence you'd already confirmed instead of inferred here, and a prohibited-claims list checked against it
