Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. I wrote it assuming Tobias is your hiring manager, because your message didn't say.

Web search wasn't allowed in this session, so all four lookups were blocked: Saltmarsh's values, its interview process, recent studio news and Tobias's public profile. Everything is built from your message and the job description. Anything about the studio itself is marked as general, not specific to Saltmarsh.

**The question to rehearse most (B1):** "Where have you coordinated design, art, engineering and community on an update?" It's the biggest gap between what the job asks for and what you've described.
- **What to stand on:** "For the last two years I ran the weekly content-drop calendar for our main title."
- **What your message doesn't say:** whether running that calendar meant working with those four teams. The pack gives you two honest ways to answer either way.
- **If it turns to leadership:** say "I've never led a team" and go straight to how you'd learn how the teams work there.

**Also in the pack:**
- **Where you match the job:** each requirement next to your own words, and how to talk about the gaps (one title versus two, presenting numbers versus owning the review, no in-app purchase experience).
- **21 practice questions** grouped by interviewer style, with how to answer each.
- **A one-evening prep plan:** B1 out loud, then play both Saltmarsh titles, then the planning and diagnosis questions (A1, A2).
- **6 questions to ask Tobias.**
- **Claims to avoid:** things like "led a team", "managed QA" or calling yourself a "Producer" rather than an associate producer.

Say the word and I'll play the sceptical interviewer on B1, with follow-ups that react to what you actually say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, I can convert it.

Is Tobias going to be your manager, and did the recruiter mention any focus areas or a task to prepare? Either answer would change how the questions are weighted. And if you allow web search, do you want me to look up Saltmarsh's values, interview process, recent news and Tobias's public profile?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interview:** Friday, 60 minutes, with Tobias Wrenfield, Head of Live Operations
**Relationship:** not stated. This pack assumes Tobias is the hiring manager for the role. If he is a peer or a skip-level, the persona weights below change.
**Research:** every web search was refused in this session, so nothing here comes from Saltmarsh's own pages. Anything about the studio is marked `[generic]`.

---

## 1. How to use this pack

- **Personas** describe *how* a question gets asked (who is asking, in what style). **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behavioral or values fit
  - **EXP**: deep-dive on your own experience (what was actually you)
  - **JD**: can you do the listed job, gaps included
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, worked through out loud
- Provenance labels: `[grounded]` traces to your message or the JD. `[inferred]` is this pack's own derivation, and the derivation is named. `[generic]` is a role-family pattern with no claim about Saltmarsh or about you.
- **The guidance is scaffolding, not a script.** Where it reaches the edge of what you told me, it gives you an **answer slot**: two honest branches, to be answered in your own words in the interview.

---

## 2. Prep triage (the interview is tomorrow; sized for one evening)

1. **B1, out loud, three times** (about 45 min). This is the highest-ROI prep in the pack. Practise holding the hold, then the follow-ups.
2. **Play both Saltmarsh titles for 20–30 minutes each.** Note what events are running, how often they run, and what they reward. This feeds A1, D2 and your reverse questions. It's also the cheapest way to cover CO questions that research couldn't.
3. **A1 and A2 structures** (about 30 min). Say each structure aloud once, then run it with a made-up event.
4. **C1 answer slots** (about 15 min). Know which retention numbers you presented, how they were counted, and which part was yours. If you don't know how something was counted, say that.
5. **D1 opening arc** (about 15 min). 90 seconds, built only from your four sentences.
6. **Pick three reverse questions** from section 6.

Everything else is insurance.

---

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title and weekly content drops. The role is two titles and live events. Keep the words at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "two of our mobile titles" makes a probe on planning across titles likely. If you ever planned anything for a second title, say what and how, in your own words. If you didn't, say so plainly and stay with the main title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Your material doesn't show whether running the calendar involved working with these teams. "Never led a team" is about leading, not coordinating, so it neither shows nor rules out coordination. Answer slot: if running the calendar meant working with design, art, engineering or community on a drop, say which teams and what part was yours, in your own words. If it didn't, say so plainly and stay with the calendar. If the question turns to leadership, the words are yours: "I've never led a team." |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a post-event review. Words at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "own" makes a probe likely. If you put the numbers together yourself, or chose what went in, say which, in your own words. If neither was yours, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but this is a sentence with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you wrote it, and your QA team still uses it. Answer slot: the JD's "manage" makes a probe on the ongoing side likely. If you kept it up to date or ran it on each release, say how. If that wasn't yours, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [inferred] | discovery | Four years is more than three. Your material doesn't say whether the puzzle title was run as a live service, and your title was associate producer. Answer slot: if the game was run as a live service, say what made it one, in your own words. If you're not sure it counts, describe the weekly drops and let Tobias judge. Keep the title as "associate producer" |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. This is your strongest sentence. Say it as written: ran it, weekly, main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in kind, but a prober will ask which numbers and how they were counted. Those are answer slots (C1). "I don't know how it was counted" is an honest branch |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The checklist is written work that another team still relies on. Say it that way: "I wrote the release checklist our QA team still uses." Add nothing to it |
| F9 | Live events on mobile titles commonly include paid offers, so monetization often comes up in live-ops interviews. This is not in the JD | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap you stated yourself, and the requirement is a role-family pattern, not a JD line. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

---

## 4. Persona table

The loop as you described it is one 60-minute session with the Head of Live Operations. Weights start from a hiring-manager prior, adjusted by the JD. Nothing about Tobias himself could be researched.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Plan the next quarter's events", "participation dropped, diagnose it" | High. A Head of Live Ops hiring a producer is buying calendar and review capability, and a live problem is the fastest test | Clarify, objective, segment, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Skeptic | Quiet probing of F1, F2, F3: one title versus two, coordination, ownership | High. These are the gaps between your sentences and the JD's verbs | Rehearse B1 until it's boring. Hold only what your quotes carry, then use the answer slot |
| Data-Driven Prober | "Which retention numbers? How were they counted?" | Medium. The JD names retention metrics and KPIs, and F7 is a quotable claim | Know what you can and can't say about each number. Name the weakest assumption you know of first |
| Conversational | "Walk me through your journey", "what are you playing?" | Medium. Most 60-minute manager rounds open this way, and it's still scored | A 90-second arc from your four sentences. Treat casual game talk as scored |
| Pressure | "Sixty seconds: why you?", "how much of that was you?" | Low to medium. No signal either way, so a light touch | Pause, restate, anchor in your sentences, hold through two follow-ups |
| Peer Evaluator | Collaboration with community and engineering, delivered as hypotheticals | Low to medium. The JD's four-team line invites it, though Tobias is senior to the role | Propose working principles, not claims about how Saltmarsh's teams work |
| Values / Behavioral | "A time you gave bad news", "a time something shipped wrong" | Low. No values round is known; a couple of behavioral questions are still common | Pick real instances. Where none comes to mind, say so |

---

## 5. Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're handed the events calendar for two titles. How do you plan the next quarter?" | CASE | [generic] | Clarify first: each title's goal for the quarter, team capacity, current cadence, which KPIs matter. Then the plan: a shared calendar showing both titles, so collisions on shared art and engineering time are visible; a fixed rhythm per title; buffers before risky dates; a review point after each event that feeds the next. Close with what you'd check in week one. No claim about your past is needed | The JD's opening line, as a live problem. CASE because it scores structure, and it answers F1's two-title gap with reasoning rather than history |
| A2 | "An event went live yesterday and day-1 participation is well below the last one. Diagnose it." | CASE | [generic] | First, is the data right (tracking, time zones, partial day)? Then segment: platform, region, new versus returning players. Then the funnel: saw it, entered, completed. Then what changed: timing, rewards, difficulty, a competing event, a bug. Decide what to fix now and what to learn for next time. Name the assumption you'd trust least, out loud | Tests the JD's KPI line under live conditions. CASE delivery with JD content |
| A3 | "Three days before lock, art says a key event asset will slip a week. What do you do?" | CASE | [generic] | Ask what exactly slips and whether a reduced version is possible. Lay out options: cut scope, swap the event order, move the date. Say who you'd tell and in what order (design, engineering, community, QA), what changes in the release checklist, and how you'd write up the decision. No claim about your past | The JD's four-team line, asked as a decision. Covers F2 by reasoning, which is the honest route given F2's evidence |
| A4 | "What makes a good post-event review?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: targets set before the event; KPIs against target; what happened and why; what you'd change; owners and dates. Keep it short, written, and readable by people who weren't there. Optional anchor: "I presented the monthly retention numbers to the studio head." Answer slot: if you shaped how those numbers were put together, say which part was yours. If not, say so and stay with presenting them | The JD's review line (F3) plus written communication (F8). CASE because it's a design question. The anchor stays at the quote's scope |
| A5 | "How would you build a release checklist for an event update shipping on two titles at once?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Open with the fact: "I wrote the release checklist our QA team still uses." Then answer the two-title case live: shared steps versus per-title steps, sign-off points, the rollback plan, who confirms each step. Answer slot: if your checklist already covered more than one build or title, say how. If it didn't, say so plainly and design it here | F4 is your closest match to a JD line. Pairing it with the two-title twist tests transfer rather than recall |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role pulls design, art, engineering and community together on every update. Where have you done that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team" | **The highest-ROI rehearsal in this pack.** Hold: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if running it meant working with any of those four teams on a drop, say which and what part was yours, in your own words. If it didn't, say so plainly and stay with the calendar. That honest branch is a limit, not a confession. Follow-up one, "who decided when something slipped?": if it was you, say how; if it wasn't, say who and how you worked with them. Follow-up two, if it turns to leadership: "I've never led a team." Then what you'd do in your first month to learn how the four teams here work. Never claim authority over a team | F2 is the widest gap between the JD's verbs and your sentences, so this arrives in some form. JD because it scores the stated requirement head-on |
| B2 | "Your calendar experience is on your main title. This role is two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | State your sentence as written. Answer slot: if you ever planned anything for another title, say what. If not, say so plainly. Then answer the "what changes" part as reasoning: shared team time, collisions, two player bases, two review cycles, and how you'd keep one view across both | F1's scope gap. The premise is your own sentence's, so the question stays fair |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team" "never worked on a game with in-app purchases" | Pick a real one from the fit snapshot (F2, F1, or F9), not a disguised strength. If it's monetization: "I haven't worked on a game with in-app purchases." Then a concrete ramp plan. Keep the weakness and the plan in a 2:1 ratio of plan to weakness | A Skeptic staple. It rewards calibrated candor, and you already have honest material for it |
| B4 | "Why leave your current studio, and why live ops at Saltmarsh?" | JD | [generic] | Your material doesn't give your reason, so this is an answer slot: say your actual reason for moving, in your own words. For "why here", use what you saw playing their titles tonight. If you haven't played them, say what draws you to live ops instead. Don't invent studio facts | Motivation consistency is a standard Skeptic probe. `[generic]` because nothing in your material or research covers it |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to the studio head. Which numbers, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slots, each in your own words: which retention numbers they were; how they were counted; what they were sensitive to; the assumption behind them you'd defend least; which part was yours (gathering, analysing, presenting). "I don't know exactly how that was counted" is an honest branch. Say it plainly rather than guess | F7's sentence is the one a prober will press, and the JD names retention metrics. EXP because it tests what was actually yours |
| C2 | "Tell me about a time a number you presented changed what the team did." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Pick an instance from presenting the monthly numbers if one comes to mind. It needs the number, the decision, and your part. If no such time comes to mind, say so plainly, then describe how the numbers were used, or how you'd make them drive a decision | An open prompt themed by the JD's KPI line. Tests whether your metrics work connected to action |
| C3 | "How would you tell whether an event actually improved retention, rather than just landing in a good week?" | CASE | [generic] | Compare against something: players who didn't take part, the same week in earlier cycles, or a held-back group if the tools allow it. Watch for selection effects, since your most engaged players join every event anyway. Name the weakest assumption out loud. No claim about your past | Tests the JD's "comfortable with player-retention metrics" beyond reporting. CASE because it's reasoning, live |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in your own words using only these beats: four years as an associate producer at a puzzle-game studio; the last two years running the weekly content-drop calendar for the main title; writing the release checklist QA still uses; presenting monthly retention numbers to the studio head. End on why live ops next (B4's slot). Answer slot on the JD's live-service line: if the game was run as a live service, say what made it one. If you're unsure it counts, describe the weekly drops | Almost certain opener. It also covers F5's live-service question before it's asked |
| D2 | "What mobile games are you playing at the moment, and whose live events do you rate?" | CO | [generic] | Answer from games you actually play. Name one event mechanic you admire and why. If you've played Saltmarsh's titles tonight, mention one specific thing you noticed. Only say what you saw | Casual, but scored for genuine interest. CO because it's the nearest thing to company knowledge available without research |
| D3 | "What's a content drop you're proud of?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick one drop from the calendar you ran. It needs what the drop was, what your part was, and how it landed. If no single drop stands out, say so plainly and talk about what you were proud of in running the calendar | Invites a story from F6, your strongest row. An open prompt, so you choose the instance |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who has already run live ops on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause, then hold on what's true: two years running the weekly content-drop calendar for the main title, and the release checklist QA still uses. Concede plainly: "I haven't worked on a game with in-app purchases." Then the plan to learn it. Hold through a second push ("but that's the job") by returning to the calendar and the checklist. Don't fold, and don't inflate | F9's stated gap under time pressure. The hold uses only your quotes |
| E2 | "That checklist QA still uses: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it." Answer slot: if others reviewed or shaped it, say who and what they added. If it was yours alone, say so. Don't claim it beyond "our QA team still uses it" | The classic attribution probe, on F4. Rehearsing it makes precise honesty sound confident |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "If players are angry mid-event, what do you need from community, and what do they get from you?" | CASE | [generic] | Reciprocity: from community, fast signal and player wording; from you, a clear status, a timeline, approved messaging, and a heads-up before changes land. Propose a simple working agreement rather than guessing how Saltmarsh does it today | Community is one of the JD's four teams. Tests partnership instinct |
| F2 | "Engineering says the update can't hit the date and design says it must. You're in the middle. What happens?" | CASE | [generic] | Get both constraints written down, look for a scope cut or split release, take the trade-off to whoever owns the call with a recommendation, and record the decision. A producer brokers the decision and doesn't pretend to own the teams. No claim about your past | The coordination seam from the JD, asked collegially. Pairs with B1 |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | If presenting the monthly retention numbers ever meant bringing bad news, that's your candidate story. Tell what the news was, how you framed it, and what happened, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A common behavioral stem. The quote gives you a natural place to look without supplying the event |
| G2 | "Tell me about a time something you shipped went wrong for players." | VAL | [generic] | Pick a real one. It needs what broke, what you did, and what changed afterwards (for example, in the checklist). If no such time comes to mind, say so plainly and describe how you'd run that moment | Themed by the JD's QA and release line. Tests ownership and calm under a live problem |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B2 |
| Coordinate design, art, engineering and community | B1, A3, F1, F2 |
| Own the post-event review and its KPIs | A4, A2, C3 |
| Manage the release checklist with QA | A5, E2 |
| 3+ years producing live-service games or apps | D1 |
| Experience running a content calendar | D3, B2 |
| Comfortable with player-retention metrics | C1, C2, C3 |
| Clear written communication | A4, E2. Usually judged from how you write as much as what you say, so keep any follow-up email tight |

---

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is the calendar split across the two titles today? Does each have its own rhythm, or is it planned as one?" | Shows you're already thinking about the two-title problem (F1) and tells you what you'd inherit |
| R2 | "What does a post-event review look like here now, and which KPIs does it report?" | Goes straight to a responsibility the JD gives this role, and helps you calibrate the retention-versus-revenue mix |
| R3 | "Where does coordination across design, art, engineering and community break down most often?" | Signals you know where producer work actually lives, and shows you the hardest part of the job before you take it |
| R4 | "Do events on these titles include paid offers, and who owns that side?" | Gets an honest answer on how much your F9 gap matters, framed as curiosity rather than worry |
| R5 | "What would a strong first 90 days look like to you in this role?" | Gives Tobias the chance to describe success in his own terms, which you can mirror in your follow-up |
| R6 | "As Head of Live Operations, what's the one thing you most want this hire to take off your plate?" | Tied to his role, so it reads as a question for him rather than for any interviewer |

---

## 7. Prohibited claims

What this pack will not coach, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated: "Never led a team" | "I've never led a team." |
| Worked on monetization or in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." |
| Ran live-events calendars across multiple titles | Inflated form of F1 | F1's quote at its own scope. Your material says the main title. B2's slot stays inside that |
| Owned post-event reviews or KPI reporting | Inflated form of F3 | F3's quote at its own scope. Your material says you presented the numbers. A4's slot asks only which part of them was yours |
| Managed QA or the QA process | Inflated form of F4 | F4's quote at its own scope. Your material says you wrote the checklist, and QA still uses it |
| Held the title "Producer" | Inflated form of F5 | "Associate producer", as you wrote it |

---

## 8. Sources

- **Provided documents:** the JD and background text in your message. No CV file was supplied.
- **Searches sent (all refused, so nothing came back):**
  - `"Saltmarsh Games" values`: refused
  - `"Saltmarsh Games" interview process producer`: refused
  - `"Saltmarsh Games" mobile studio news 2026`: refused
  - `"Tobias Wrenfield" Saltmarsh Games live operations`: refused
- **Loop:** your own words establish one 60-minute session with Tobias Wrenfield, Head of Live Operations. No values-style round is documented, so there's no values cheat sheet.
- **Dossier:** none was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. It would have themed G1 and G2 with the studio's published values |
| 2. `Saltmarsh Games interview process` | unavailable | The search was refused. Your description fixes this session, but it would have shown any other rounds in the loop |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | The search was refused. It would have grounded A1, D2 and a CO question in the studio's titles and recent moves. As it stands, those rows are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. It would have supported a "Reading the interviewer" section, persona weights adjusted to his public profile, and a reverse question tied to his career |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## 9. Upgrade menu

- **Allow web search** → targets 1–4 run. That gives you a values cheat sheet if Saltmarsh publishes values, grounded CO questions on its two titles, and a "Reading the interviewer" section on Tobias's public profile.
- **Deep research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief on the studio, Tobias's talks or writing, and loop reports for this role family.
- **Whether Tobias will be your manager** → persona weights recomputed. If he isn't the hiring manager, the Skeptic and Case banks shrink and the Peer or Pressure banks grow.
- **The recruiter's prep email** → coverage of any stated focus areas, plus a build section if there's a task or presentation.
- **The names of the two titles** → A1, B2 and R1 rewritten around the real games.
- **Your answers to the slots in B1, F3 and F5** → F2 and F5 move from `discovery` to a graded row, and B1, A4 and D1 become story-mapped.
- **A redacted copy of the release checklist, or a slide from a monthly retention deck** → F4 and F7 rise from `medium` to `high`, because there's something inspectable behind them.
- **A tuesday-dossier.md from an underwriting pass** → an evidence-derived top objection, a strategy per weak area, and a prohibited-claims list confirmed with you rather than built here.
