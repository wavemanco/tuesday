Reading the last of the skill's evidence rules, then I'll run a quick company research pass and build the pack.
I've put together one prep pack covering all three rounds:
`/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-6-denied-f6c1300a/Larkfield-Systems_engineering-manager_interview_pack.md`

It's built only from the role text and the background in your message. Web search wasn't permitted in this session, so the pack has nothing Larkfield-specific yet: no company values, products or recent news. The rounds and weightings come straight from what you told me.

**How it's laid out:**
- **One shared comparison** of your background against the role. Your strongest ground is the hiring loop and the reliability quarter. The real gaps are the jump from a team of six to eleven engineers in two squads, and the hardware-adjacent roadmap you said you've never owned.
- **A section for each round,** about 8 to 11 questions each:
  - **Tuesday, Director:** sceptical probing of those gaps, plus live planning questions.
  - **Thursday, panel:** the staff engineers and the PM will test how you'd split decisions with them, and dig into your 60% and 40-interviews figures.
  - **Monday, VP:** values and leadership philosophy, with one or two pressure-tested questions.
- **The question to rehearse most is A1:** "You've led six; this is two squads and eleven — what makes you ready?" All three rounds will come back to it in some form.

**Three things to get right in every round:**
- **Say "after", not "because".** Your on-call burden dropped 60% *after* the reliability quarter. Unless you know the quarter caused it, don't claim it did.
- **Keep "about 40 interviews"** as you said it.
- **"I haven't managed managers"** and **"I haven't owned a hardware-adjacent roadmap"** are your own statements. Say them plainly and follow each with a plan.

Where your message doesn't answer what an interviewer will probe (developing engineers, who made the final hiring calls, whether a PM was behind the roadmap pressure), the pack gives you two honest options: tell what actually happened, or say plainly it wasn't like that.

If you want to rehearse out loud, I can play the Tuesday Director and run A1 with live follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions, or convert the pack to a Word document.

Can you paste the full job posting and your CV? Your message gave me four sentences of background, and more detail would turn many of those two-option prompts into prepared stories.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview prep pack — Engineering Manager, Larkfield Systems

**Candidate:** Yusuf · **Mode:** loop — three scheduled rounds, one shared fit snapshot
**Rounds:** Tuesday, hiring manager (Director of Engineering, your would-be boss), 45 min · Thursday, panel (two staff engineers and a product manager), 60 min · following Monday, VP Engineering, "values and leadership philosophy", 30 min
**Built from:** the role text and the background in your message. No CV, full posting or interviewer names were supplied, and web research was refused in this session (see Sources).

---

## How to use this pack

- **Personas** describe how a question is asked; **types** describe what is being scored. Each round below weights personas for who is in the room.
- **Type key:** **VAL** — values and behavior, shown through past decisions · **EXP** — your experience under scrutiny, including what was actually yours · **JD** — can you do the stated job, gaps included · **CO** — company and domain knowledge, and why here · **CASE** — a live problem from the role, scored on structure.
- **Provenance:** `[grounded]` traces to your message or the role text, with your exact sentences shown; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about Larkfield or you.
- **Answer slots** mark the places where your message doesn't say what an interviewer will ask. Each one has two honest branches: fill it in from what you actually did, or say plainly that it wasn't like that.
- Guidance is scaffolding, not a script. Say it in your own words, in 90–120 seconds.
- **Highest-ROI prep in the pack: A1** — the jump from leading a team of six to two squads of eleven. All three rounds will come back to it in some form.

---

## Shared: fit snapshot

Requirements are quoted from the role text in your message. Evidence is your own sentences, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" and "for 11 engineers" — role text | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads or eleven engineers, and the words stay at that scope: "I've been a team lead for three years, with a team of six." Answer slot: "two squads" makes a probe on work that spanned more than one team likely. If any of your work did, say which work and what part was yours, in your own words. If none did, say so plainly and stay with the team of six. Whatever comes after that is a plan for two squads, said as a plan and never as a past |
| F2 | "own delivery" — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote shows one prioritization call you pushed through. It doesn't show ownership of a team's delivery overall. Keep its own words, including "after": the burden dropped after the quarter, which is not the same as because of it. Answer slot: if you set or answered for your team's delivery commitments, say how, in your own words. If that sat with someone else, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring) — role text | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running the loop for backend roles is adjacent to owning hiring, and the bridge stays there: "I run our hiring loop for backend roles; I did about 40 interviews last year." Keep the "about". Answer slot: "own hiring" makes a probe on who made the hire and no-hire calls likely. If those calls were yours or shared, say which, in your own words. If they weren't, say so plainly and describe what running the loop involved |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — role text | none given | none | [grounded] | discovery | Your material says nothing about growing engineers. Answer slot: if you've helped an engineer on your team grow, pick one case and say what you did and what changed, in your own words. If no such case comes to mind, say so plainly and describe how you would approach growth for eleven people |
| F5 | "partner with hardware and product on roadmap" (hardware) — role text | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You have stated this gap yourself, and wording can't close it. Words: "I haven't owned a hardware-adjacent roadmap." Follow with how you would learn it, said as a plan. Never claim hardware roadmap work, and add nothing to make the gap look smaller |
| F6 | "partner with hardware and product on roadmap" (product) — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote touches the roadmap but doesn't show a partnership with product: it doesn't say who applied the pressure or how the call was made. That reading is this pack's. Answer slot: if you made the case for the reliability quarter to a product counterpart, say who and how, in your own words. If it didn't happen that way, say what actually happened |
| F7 | "building device-management services" — role text | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | Your material names payments, not devices or IoT, and doesn't say what your team builds. Answer slot: if any of your work touches fleets, devices, firmware or long-lived clients, say what, in your own words. If none does, say so plainly and say what you would learn first |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads / 11 engineers (F1) | A1, B1, B3, J1 |
| Own delivery (F2) | A5, B3, G3, K2 |
| Own hiring (F3) | B4, E3, E4, H3 |
| Own growth (F4) | B1, H5 |
| Partner with hardware on roadmap (F5) | A2, A4, B2, G1 |
| Partner with product on roadmap (F6) | A5, D2, D3 |
| Building device-management services (F7) | C2, G1, G2, K1 |
| Industrial IoT company context | A3, K1. The role text gives this as context rather than as a requirement |

---

## Round 1 — Tuesday · Hiring manager (Director of Engineering) · 45 min

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probes on scope (F1), hardware (F5) and why you're leaving payments | High. A hiring-manager round tests capability and derisks gaps, and the widest gaps between your quotes and the role text are F1 and F5. Your would-be boss is the person who owns that risk | Rehearse A1 until it's boring. Name the limit before they do, then give a concrete ramp plan |
| Case / Strategist | Live problems from the role: first 90 days, a hardware slip, an underperforming squad | High. Hiring managers bring problems from their own roadmap, and this role's mandate is delivery across two squads with hardware partners | Clarify, then objective, then approach, then risks. Think aloud, and ask one clarifying question before you structure |
| Conversational | A friendly opener and "what are you into these days" | Low, but certain to appear in the first five minutes. Casual questions are still scored | Have a 90-second arc ready (C1). Treat casual questions about IoT as scored |

### Bank

**A — Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've been a team lead of six for three years. This is two squads and eleven engineers. What makes you ready for that jump?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI rehearsal in the pack.** Open with the limit before they name it: "I've been a team lead for three years, with a team of six. Eleven engineers in two squads is a bigger scope than I've led." Then the hold, using only what your sentences carry: you run your hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure, after which your team's on-call burden dropped 60%. Answer slot: if any of your work spanned more than one team, say which work and what part was yours. If none did, say so plainly. Then give the plan for two squads, said as a plan: how you'd split your time, who you'd lean on in each squad, and what you'd want true by day 90. **Follow-up 1, "Have you managed managers?":** "I haven't managed managers." Then ask whether the squads have leads who would report to you. That's a fair question, and the answer changes what the role needs. **Follow-up 2, "So you'd be learning on our time?":** Hold. Name the specific thing that's new, the size and the two squads, and don't fold on the three years. Don't add anything to the hold to make it feel stronger | F1 is the widest scope gap between the quotes and the role text, and your would-be boss carries the risk of that hire. This objection arrives in some form. JD because it scores the stated scope; it's delivered as a Skeptic probe |
| A2 | "You haven't owned a hardware-adjacent roadmap. How would you work with our hardware team?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Say it plainly: "I haven't owned a hardware-adjacent roadmap." Don't shrink it or pad it. Then the plan, as a plan: learn the hardware team's release cadence and lead times, learn how device and service versions depend on each other, and find out who decides when a device-side change blocks a service release. Ask the director which hardware counterpart they'd want you close to in week one. That turns the gap into a working conversation | F5 is a gap you stated yourself, and hardware partnership is in the role text, so expect it in this round. JD because it scores a stated responsibility |
| A3 | "Why leave payments, and why industrial IoT?" | CO | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Say that you're moving from payments, plainly. Answer slot: your material doesn't give a reason. Give your actual one in your own words, pointed toward what draws you to this role rather than away from your current job. If you have no history with IoT, don't imply one. "It's new to me and that's part of the draw" is a fine honest answer if it's true | The why-here, why-now probe is a standing Skeptic move, and F7 makes the domain switch visible. CO because it scores motivation and homework on the company |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick the one your own message names, the hardware-adjacent roadmap, and say it plainly, then give a one-line ramp plan (A2's). Naming it yourself before A2 arrives turns an objection into self-awareness. Don't swap in a safer-sounding weakness you don't actually believe | A predictable stem from the Skeptic persona. F5 gives you a true answer ready to hand |
| A5 | "Tell me about a time you pushed back on the roadmap." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F2. The beats your sentence states: a reliability quarter, pushed through by you, against roadmap pressure, with your team's on-call burden down 60% afterwards. Keep "after" as it is. Answer slot: the role's "partner with hardware and product on roadmap" line makes a probe on who applied the pressure and how you made the case likely. If you made the case to someone specific, say who and how, in your own words. If it didn't go that way, say what actually happened. Don't supply a stakeholder's reaction you didn't see | F2 and F6 rest on this one sentence, and a director will test whether pushing back is a habit or a one-off. EXP because it probes what was actually yours |

**B — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit two squads on day one. What do your first 90 days look like?" | CASE | [generic] | Clarify first: are there squad leads, what is the director's biggest worry, and what's already committed this quarter. Then structure it as listen (1:1s with all eleven, the staff engineers, the PM and the hardware counterpart), learn (delivery state, on-call load, open roles, who is ready to grow), then commit to two or three changes by day 90 and say how you'd measure them. Leave room to say what you'd defer | The most common opener for a new manager and the natural home for F1 and F4. CASE because it's a live plan, scored on structure |
| B2 | "A hardware revision slips six weeks and product still wants the launch date. What do you do?" | CASE | [generic] | Clarify the dependency first: what actually needs the new hardware, and what can ship without it. Lay out options with costs: ship the software-only slice, re-sequence, or move the date. Bring options to the PM and the hardware lead together rather than carrying the problem alone, and escalate with a recommendation. Say where you'd lean on the people who know the hardware | Rehearses F5's partnership requirement as a decision rather than a record, so it needs no hardware history from you |
| B3 | "One squad hits its commitments and the other keeps missing. How do you diagnose it?" | CASE | [generic] | Treat it as a hypothesis list before acting: scope and estimation, dependencies (hardware, other teams), team health and on-call load, unclear ownership. Explain how you'd check each one cheaply: look at the work, ask the squad, compare interrupts. Then the fix follows the cause. Don't open with a process change | Two squads is the core of F1 and F2. A director wants to see diagnosis before prescription |
| B4 | "You'll own hiring for these squads. How would you approach the next two hires?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Open with what your sentence carries: you run your hiring loop for backend roles and did about 40 interviews last year. Answer slot: "own hiring" makes a probe on who made the final calls likely. If the hire and no-hire calls were yours or shared, say which. If not, say so plainly and describe what running the loop meant. Then the plan: what gap each hire fills, what the loop would test for device-management work, and who on the squads you'd involve | F3 is your strongest adjacent evidence and this role owns hiring outright. JD content, CASE delivery |

**C — Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc: nine years in engineering, three as team lead of a team of six, now at a payments company. You run the hiring loop for backend roles, about 40 interviews last year. You pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% after. Close on why this role, in your own words (A3's slot) | Certain to be asked, and it sets up every later probe on F1–F3. Rehearse the arc to time |
| C2 | "What are you actually reading or playing with in IoT these days?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: if you've been learning about device fleets, OTA updates or industrial IoT, say what and what surprised you. If you haven't yet, say so plainly and name what you'd study first. A casual tone doesn't make this unscored, and a vague "lots of things" costs more than an honest "not yet" | F7 in a friendly register. Hiring managers use this to test genuine interest |

### Reverse questions — Tuesday

| Question | Why it lands |
|---|---|
| "What would make this hire a clear success to you at six months?" | Your would-be boss defines the bar, so ask them for it. Their answer also tells you which bank to lean on for the next two rounds |
| "Where are the two squads strongest right now, and where are they struggling?" | Shows you're already thinking about B3, and gives you real material for Thursday |
| "When the squads' roadmap and the hardware roadmap conflict, who makes the call today?" | Goes straight at F5's seam without pretending to know it |
| "Do the squads have leads, and how do you see this role relative to the staff engineers?" | Clarifies the managing-managers question (A1, follow-up 1) and sets up Thursday's panel |
| "How do you support a manager who's new to a hardware-adjacent domain?" | Candor about F5, put as a question about how they work. It signals self-awareness rather than defensiveness |

---

## Round 2 — Thursday · Panel (two staff engineers and a product manager) · 60 min

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Staff engineers: "where's the line between your calls and ours". PM: "how do we decide when we disagree" | High. Staff engineers and a PM are working partners who are pricing what this hire adds to, or costs, their work. The role text names product partnership directly. This weighting is the pack's reading of a panel with these titles (`[inferred]`) | Frame it as reciprocity: what you'd bring them as well as what you need. Propose principles for the seam rather than claiming to know it |
| Data-Driven Prober | Staff engineers going two levels deep on the 60% and the 40 interviews | High. Both figures are in your own words and are natural targets for engineers | Know what you can and can't say about how each figure was counted. Name your weakest assumption first, and say "I don't know" where that's true |
| Case / Strategist | A technical scenario on a device fleet | Medium. Staff engineers often test technical judgment with a live problem from their own domain | Reason from first principles, say where you'd defer to them, and clarify before structuring |

### Bank

**D — Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where do you draw the line between your technical calls and ours?" (staff) | JD | [generic] | Answer with principles, not history. Technical direction sits with the staff engineers, and priorities, staffing and delivery tradeoffs with you. When the two collide, the disagreement gets surfaced early and decided with the reasoning written down. Ask how it works today before proposing anything. This question makes no claim about your past, so neither should your answer | The defining seam for a staff engineer working with a new EM. JD because leading the squads includes this boundary |
| D2 | "When I want features and the team wants reliability work, how do we decide?" (PM) | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Use the one case your sentence carries: you pushed a reliability quarter through against roadmap pressure, and the on-call burden dropped 60% after. Answer slot: if a PM was part of that decision, say how it went, in your own words. If not, say so plainly. Then a proposal for how you'd do it here, as a proposal: agree a shared measure of reliability's cost, and make the capacity split an explicit, reviewable call rather than a fight | F6 is the thin part of your evidence and the PM is the person who tests it. JD because it scores the product-partnership responsibility |
| D3 | "Tell me about a time you disagreed with a product manager." (PM) | EXP | [inferred] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection scaffold. If the reliability quarter involved disagreeing with a PM, tell it in its own words: you pushed it through against roadmap pressure. Otherwise pick a time with a named stake, your position, how it was resolved, and the relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | The theme comes from the Peer Evaluator persona's disagreement stem. `[inferred]` because the mapping to F6 is this pack's reading, and the quote doesn't name a PM |
| D4 | "What would you need from us in your first month, and what would we get from you?" (staff) | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Need: context on the architecture, its failure history, and how device and service releases depend on each other. Bring: describe what you've done and let them draw the conclusion. You run your hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Don't tell them what it proves | Reciprocity is what peers are scoring. F3 and F2 are what you can put on the table honestly |

**E — Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your team's on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend the number in your own words: how it was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours. Name that weakest assumption before they do. If you don't know how the figure was counted, say so plainly. That's an honest answer, and a made-up method won't survive the second question | Headline figure on your record, in front of engineers. EXP because it tests whether the number holds up under scrutiny |
| E2 | "How much of that drop was the reliability quarter, and how much was other things?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold what your sentence says: the burden dropped after the quarter you pushed through. Your sentence says "after", not "because". Answer slot: if you know of other causes in that period, name them. If you don't, say plainly that you can't separate them. Concede the attribution specifically, and don't fold on the core claim that you pushed the quarter through | Probers go for causation. Hold-then-concede on F2's exact wording is the rehearsal |
| E3 | "About 40 interviews last year. What did running the loop actually involve?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Keep "about 40". Answer slot: say what running the loop meant: who designed it, who sat on it, and which decisions were yours. If someone else designed it or made the final calls, say so plainly and describe your part. Defend the number in your own words: what counted as an interview, and whether the 40 is your own interviews or the loop's | F3's figure and verb are both likely targets. EXP for attribution |
| E4 | "How do you know your loop picks the right people?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: if you tracked how hires went, say what you looked at. If you didn't, say so plainly and say what you'd track here. Never describe a calibration process you didn't run | Engineers who will be hiring with you want to know your bar is tested. Rehearses the honest answer before the probe |

**G — Case / Strategist (technical)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "An over-the-air firmware rollout starts failing on part of the fleet. Walk us through the first hour." | CASE | [generic] | Clarify: is the rollout staged, can it be paused, what does failing mean (devices offline or degraded)? Then: halt the rollout, size the blast radius, open communication with support, product and hardware, decide between rollback and fix-forward with the staff engineers, and set the follow-up. Say plainly where their device knowledge outranks yours. That reads as judgment, not weakness | Device-management services meet hardware here (F5, F7). CASE because it's a live incident scored on structure and composure |
| G2 | "Our device-management services carry a growing on-call load. What would you do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Clarify what's driving the pages first. Then you can mention the one lever your sentence carries, at its own scope: on your current team you pushed a reliability quarter through against roadmap pressure, and the burden dropped 60% after. Say it's one option to weigh, not a recipe, and ask what's been tried here | A natural opening for your strongest story, but the case still scores diagnosis. Grounded on F2's quote |
| G3 | "Hardware, product and tech debt all want the same quarter. How do you decide what goes in?" | CASE | [generic] | Structure: what each item costs and unblocks, which deadlines are fixed (hardware dates often are; say you'd verify that here), what has to be protected, and who needs to agree. End with how you'd communicate what didn't make it in | Delivery ownership (F2) across the three-way seam the role text names. CASE because it's a live tradeoff |

### Reverse questions — Thursday

| Question | Why it lands |
|---|---|
| "What could a new EM do in their first month that would genuinely help your work?" | The reciprocity question for peers, and it gives you their real priorities |
| "Which part of the device-management architecture would you most want a new manager to understand?" | Shows you'll learn their system before managing it (F7) |
| "What does a good EM do for staff engineers here, concretely?" | Invites them to define the D1 seam in their own words |
| "Where do product and the squads disagree most today?" (to the PM) | Gets to F6 honestly and gives you a real issue to talk through |
| "How do hardware timelines show up in roadmap planning?" (to the PM) | Shows you know F5 is the gap, and starts closing it |

---

## Round 3 — following Monday · VP Engineering, "values and leadership philosophy" · 30 min

The round is a values-style round because the recruiter's description names it. Larkfield's published values weren't retrieved (research was refused), so this pack has no values cheat sheet, and the VAL questions below use general themes rather than Larkfield's values by name.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?" and "tell me about a time…" | High. The recruiter described the round as "values and leadership philosophy" | Have two or three principles, each backed by a story you can tell. Use "we" for context and "I" for your contribution |
| Pressure | A time-boxed "why you", and a challenge to your reliability call | Medium. Executive rounds test composure, and 30 minutes forces short answers | Pause, restate the question, anchor on what you actually said, and hold through two follow-ups |
| Case / Strategist | Altitude: the domain, and what success looks like in a year | Medium. Executives check whether you think at their level | Clarify the objective, give a short structure, and name one risk |

### Bank

**H — Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Scaffold: two or three principles, in your own words, each with a story you can tell. If one of them is about trading roadmap work for your team's operational health, the reliability quarter is the story that carries it: you pushed it through against roadmap pressure, and the on-call burden dropped 60% after. For any principle with no story behind it, either cut it or say it's something you're still building | The recruiter named this theme. A philosophy with no story behind it scores as a slogan |
| H2 | "Tell me about a time you made an unpopular call." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F2. The beats are the reliability quarter, pushed through by you, against roadmap pressure, with the burden down 60% after. Answer slot: if you know who was unhappy and what it cost, say so in your own words. If you don't, say so plainly. Land the hard part, that it was against pressure, rather than smoothing it over | The standard values stem for "delivered a hard truth", and F2 is your quoted story for it |
| H3 | "How do you think about the hiring bar?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from what you do: you run your hiring loop for backend roles and did about 40 interviews last year. Then your view of the bar, in your own words. Answer slot: if you've held a no-hire against pressure to fill a role, tell it. If not, say what you'd do | Hiring is a values question at the executive level. F3 gives you real ground |
| H4 | "Tell me about a time you were wrong as a leader." | VAL | [generic] | Selection scaffold: a real mistake that was yours, what it cost, what you changed afterwards, and how you know the change stuck. If no such time comes to mind, say so plainly, then give the nearest thing you can stand behind. Don't pick a disguised strength | A near-certain values probe. Nothing in your material speaks to it, so the guidance is a scaffold |
| H5 | "How do you grow engineers?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot (F4): if you've helped someone on your team of six grow, pick one person and say what you did and what changed, in your own words. If no such case comes to mind, say so plainly and describe your approach as a plan for eleven people | Growth is in the role text and your material is silent on it. A VP will ask |

**J — Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Thirty seconds: why you over someone who's already led a group of eleven?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, then make three points from your sentences: three years as team lead of six, running your hiring loop, and the reliability quarter you pushed through. Concede the scale difference in one clause and don't argue it away. Hold through the follow-up by going back to those three facts, not by adding new ones | A1's objection, time-boxed. Rehearse it in 30 seconds as well as 2 minutes |
| J2 | "You pushed a reliability quarter through against roadmap pressure. Weren't you just putting your team ahead of the company?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold first: you pushed it through, and the on-call burden dropped 60% after. Answer slot: if you know what was deferred and what it cost, say so in your own words. If you don't, concede that specifically. Don't fold on the decision just to smooth things over, and don't claim a business result your sentence doesn't state | Devil's-advocate on your best story. Hold-then-concede is what's being scored |

**K — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What do you think is hardest about engineering in industrial IoT, compared with what you do now?" | CO | [generic] | Reason from outside and say so. Devices in the field can't always be patched quickly, fleets are long-lived, and hardware lead times constrain software. Frame these as hypotheses you'd test, not as expertise. Without research, this pack can't give you Larkfield-specific angles; do your own reading on their products before Monday | F7 at executive altitude. `[generic]` because these are role-family patterns, not claims about Larkfield |
| K2 | "A year from now, how would I know you're succeeding?" | CASE | [generic] | Give two or three outcomes, not activities: both squads delivering what they commit to, the hiring plan filled at the bar, a working rhythm with hardware and product, and engineers growing. Say how each would be visible. Ask what they'd add | A standard executive close, scored on clarity at their level |

### Reverse questions — Monday

| Question | Why it lands |
|---|---|
| "What do your strongest engineering managers do that others don't?" | Asks the VP to state their own leadership philosophy, which is the theme of the round |
| "Which of Larkfield's values is hardest to live as the company grows?" | Values round, values question. It invites candor |
| "How has the relationship between hardware and software engineering changed here, and where is it going?" | Puts F5 at strategy level and shows you're thinking past day one |
| "What would you want someone coming from payments to unlearn?" | Turns the domain switch into a learning conversation |
| "What's a recent hard call in engineering leadership here, and how was it made?" | Gets you a real example of their values in action, beyond the published words |

---

## Shared: prohibited claims

Claims this pack will not coach, with their basis. Nothing in the banks asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led multiple teams, or a group of eleven | Inflated form of F1 | F1's quote at its own scope: three years as team lead of a team of six. The limit is this pack's observation: the material shows one team of six. A1's slot stays inside that |
| Owned the team's delivery | Inflated form of F2 | F2's quote: pushed a reliability quarter through against roadmap pressure. F2's slot asks only whether delivery commitments were yours |
| Cut on-call by 60%, or the reliability quarter caused the 60% drop | Inflated form of F2: the verb, "my team's burden dropped" becoming "I cut", and the logic, "after" becoming "because" | The sentence exactly as you said it: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." E1 and E2 handle attribution |
| Owned hiring decisions | Inflated form of F3 | F3's quote: you run your hiring loop for backend roles, about 40 interviews last year. Keep "about". B4 and E3 ask only what running the loop involved |
| Partnered with product on the roadmap | Inflated form of F6 | F6's quote at its own scope. This pack's observation: it doesn't say who applied the pressure. D2's slot stays inside the reliability quarter |
| Has managed managers | A negative you stated | "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | A negative you stated, F5 | "I haven't owned a hardware-adjacent roadmap." No slot |

---

## Shared: Sources

**Provided:** the role text and the background in your message. No dossier was present.

**Searches sent (all refused, because web search permission wasn't granted in this session):**
- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems engineering manager interview process" — refused
- "Larkfield Systems IoT device management news 2026" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Every call was refused. It would have produced a values cheat sheet for Monday and VAL questions mapped to Larkfield's values by name |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Every call was refused. It would have added case formats and any documented values round. The three rounds themselves come from your message, so the persona weights stand |
| 3. Larkfield Systems strategy and recent news | unavailable | Every call was refused. It would have grounded K1 and A3 in Larkfield's current products and priorities; those questions are `[generic]` for now |
| 4. Interviewer name at Larkfield Systems | n/a | No interviewer names were given, so no query could be formed. This pack has no interviewer read |
| 5. Representative engineering manager JD | skipped | The role text you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Full job posting text → requirements beyond the three lines quoted here get their own fit rows and JD questions, and the coverage table is checked against the whole posting
- Your CV → evidence beyond the four sentences in your message, so more answer slots become story-mapped guidance (F4 and F7 most of all)
- Answers to the answer slots in F1, F3, F4 and F6 → A1, B4, E3, H5 and D2 move from slots to stories, with your words quoted
- Larkfield's published values, pasted or fetched → a values cheat sheet for Monday, with each value mapped to a story or a scaffold
- Web search permission → targets 1–3 above rerun, with Larkfield-specific CO and CASE questions; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can follow on request
- Names of the Director, the staff engineers, the PM and the VP → an interviewer read per round, persona weights read from their public footprint, and a reverse question tied to each person's own path
- The recruiter's notes on any round (focus areas, a planned case or exercise) → a build section for any pre-declared deliverable, and coverage matched to what each round actually scores
- Hours you have to prep before each round → a prioritized triage schedule per round
- A tuesday-dossier.md, if you have one → evidence-derived objections and a prohibited-claims list checked against verified evidence, instead of one built from your message alone
