Status: I've read the skill's rules and your dossier. Next I'm checking Quartzline's public pages (values, interview process, recent news), then I'll build the pack.
I've built your prep pack for Thursday's 45-minute hiring-manager conversation, entirely from your dossier. It's saved as `Quartzline_product-manager-platform-apis_interview_pack.md` in your working folder.

**No web research went into it.** My three searches (Quartzline's values, its interview process, recent news) were blocked by the permission settings. So nothing in the pack comes from Quartzline's own pages, and the strategy and case questions are general patterns for this kind of role.

What's in it:
- **The one question to rehearse most (A1):** the objection your dossier predicted, "You have never held the PM title or owned a roadmap — why should we hire you…?" The pack gives you:
  - an opening that admits both gaps plainly;
  - your integrations sentence, presented as related work, not PM experience;
  - a ramp plan;
  - how to hold up through two follow-ups.
- **Fit snapshot:** nine rows matching each requirement to your three verified dossier entries, with how strong each match is.
- **22 practice questions** in seven interviewer styles. The heaviest weight goes to the skeptical interviewer and to live product problems, which fit a hiring-manager round.
- **Six questions for you to ask.** Two come from your dossier: what roadmap authority the PM has versus the squad leads, and how API adoption is measured today.
- **A "not coached" list:** your dossier's three banned claims, plus four exaggerated versions of your own sentences. One example is saying you "shipped an API product" when your evidence says you led client integrations of the vendor's APIs.

Today is Thursday the 12th. If that's interview day, rehearse A1 out loud three times, then A2 and A3, then pick your two questions to ask. Everything else is extra.

Say the word and I'll play the skeptical interviewer on A1, with real follow-ups.
I can also update your `tuesday-dossier.md` with the gaps this prep exposed, for future sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview Prep Pack — Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday. Interviewer not named.
**Built from:** your `tuesday-dossier.md` (v1.1, generated 2026-08-14). The web research was refused in this session, so nothing here comes from Quartzline's own public pages (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question is asked (who is asking and in what style). **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behavioral and values. Does your past behavior show the company's published values?
  - **EXP**: experience deep-dive. Does what you've claimed hold up, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy. Have you done your homework on the company?
  - **CASE**: live problem. How do you structure and reason through a problem from the actual role?
- **Provenance labels:** `[grounded]` = traceable to your dossier. `[inferred]` = a derivation the pack names. `[generic]` = a role-family pattern with no claim about you or Quartzline.
- Evidence origins: **dossier V1–V3** are the three entries of `verified_candidate_evidence`, in order. **dossier R1–R5** and responsibilities come from `role_profile`.
- **Guidance is scaffolding, not a script.** Say it in your own words. An **answer slot** marks a place where only you know the answer. Answer it honestly either way. Both branches are good answers.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must-have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [grounded] | transferability | The dossier sets the strategy: a bridge, positioned as adjacent and never as PM experience. The limit is part of the answer, and you say it out loud: this is adjacent work, not the PM job. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: the PM-years requirement makes a probe on your decisions within those integrations likely. If any of the scoping or requirements calls were yours to make, say which and how you decided, in your own words. If none were, say so plainly and stay with leading the integrations |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibility | none given | none | [grounded] | capability | The dossier records this as a gap with no evidence (`acknowledge_gap`), so there is no bridge. Words, from `prohibited_claims`: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past |
| F3 | "Shipped API or platform products" — dossier R2, must-have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | Your material says you integrated the vendor's APIs for clients. It does not say you shipped the API product, and the relationship matters here: you worked on the implementation side. Words: the V1 sentence as it stands. Answer slot: if the interviewer asks what you delivered, name the stages you led (scoping, requirements, architecture, UAT, go-live) and how each went, in your own words. If a stage wasn't yours, say so |
| F4 | "Technical fluency: API docs, schemas" — dossier R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | discovery | REST API integrations touch this requirement, but your material doesn't show work with docs or schemas. Answer slot: R3 makes a probe on reading API docs and schemas likely. If your integration work meant working from the API docs or schemas, say how, in your own words. If it didn't, say so plainly and stay with what the integrations covered |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1, "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | discovery | The quotes reach clients and the product function. They don't mention engineering or sales. V3 is confirmed but has limited inspectable proof, so expect a probe on it. Answer slot: if you worked with engineering or sales on those integrations, say who and how, in your own words. If you didn't, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier R5, preferred | none given | low | [grounded] | discovery | The dossier strategy is `clarify`, and no verified entry speaks to agile delivery. Answer slot: if you've delivered inside an agile setup in a product org, say how it ran and what your part was, in your own words. If you haven't worked that way, say so plainly. Then: "Here's what I'd want to confirm about how your squads define it" |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibility | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | discovery | The sessions fed client evidence to product. Your material doesn't say whether that was discovery in this role's sense. It's confirmed but has limited inspectable proof, so name that limit yourself before you're asked. Answer slot: if what you gathered in those sessions changed something product built, say what, in your own words. If you don't know, or nothing did, say so plainly and stay with running the sessions |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibility | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | Requirements work for client integrations is adjacent to writing specs for a squad. Words: the V1 sentence as it stands. Answer slot: if you wrote the requirements for those integrations yourself, say what they covered, in your own words. If others wrote them, say so and say what your part was |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibility | none given | none | [grounded] | discovery | Strong evidence here would be a usage or adoption measure you defined or tracked, with what it showed. Answer slot: if you tracked anything about how clients used the integrations after go-live, say what you counted. If you didn't, say so plainly and say what you'd measure first. The dossier also flags that Quartzline hasn't said how it measures adoption today, so that becomes a reverse question (R2) |

---

## Persona weights

Your own words establish the session: one 45-minute conversation with the hiring manager. These weights start from the hiring-manager prior (Case/Strategist plus Skeptic). Without the interviewer's name, there are no public signals to adjust them.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | "Why you without the PM title?" asked quietly and repeatedly | Highest. A hiring manager is paying to reduce risk, the dossier's verdict is conditional, and the dossier names the objection outright | Rehearse A1 until it's boring. Concede the title and the roadmap first, then give your V1 sentence at its own scope, then a ramp plan |
| B. Case/Strategist | Live problems: roadmap, adoption, conflicting partner requests | Highest. This is the hiring-manager prior, and the JD's responsibilities read like a list of cases | Clarify, then objective, segment, approach, metrics, risks. Think out loud. Respectfully challenge one premise per case |
| C. Data-Driven Prober | "30+ — how counted?" and "what's in the playbook?" | Mid. V1 has a number in it, and V3 has limited inspectable proof | Know what you can and can't say about how the number was counted. Name the V3 limit before you're asked |
| D. Conversational | "Walk me through your journey" as the opener | Mid. A common opener for a 45-minute conversation, and still scored | A 90-second arc built only from V1–V3 |
| E. Pressure | Time-boxed "why you" and "how much was actually you" | Low. Not the HM prior, but the gap invites it | Pause, restate the question, hold through two follow-ups, then concede the specific thing |
| G. Values/Behavioral | Behavioral open prompts | Low. No values round is detected, and Quartzline's values weren't researched | Selection scaffolds, each with an honest branch |
| H. Peer Evaluator | "How will you work with the squad leads?" | Low. A hiring manager may ask on the squads' behalf, because the dossier says the PM's authority relative to the squad leads is unresolved | Propose principles for where the seam sits rather than pretending to know it |

---

## Question banks

**Highest-ROI prep in this pack: A1.** Your dossier named this objection. Rehearse it out loud three times before anything else.

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and `prohibited_claims` items "Having held a product manager title or role" and "Having owned a product roadmap" | **Concede first, in plain words:** "That's right — I haven't held a product manager title, and I haven't owned a product roadmap." **Then the bridge, with its limit:** "What I've done is lead 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. That's adjacent to this job, not the same job." Describe the work and let them draw the inference. Never call it proof. **Then the ramp:** how you'd learn roadmap ownership here, as a plan (B1's structure). **Follow-up 1** ("So how would you prioritize?"): hold with "I haven't set prioritization for an engineering squad." Answer slot: if any scoping calls on those integrations were yours, say which and how you decided. If none were, say so and stay with leading them. **Follow-up 2** ("A three-year PM is safer"): concede the specific point, "On roadmap ownership, they'd start ahead of me." Don't fold on what you led | The dossier names this objection, and F1 and F2 are where the must-have presses hardest. JD because it scores R1 directly. Both negatives have a source in `prohibited_claims`, so it's asked as the dossier wrote it |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it before they do: "Owning the roadmap. I haven't owned a product roadmap." Then a 30-60-90 plan: in the first 30 days, learn which decisions belong to you and which to the squad leads, and what adoption looks like today; then partner discovery; then a first prioritized draft for review. Don't pick a safer weakness. An answer that dodges reads worse than the gap | F2 is the one capability gap in the pack, and this stem is the polite version of A1. JD because it's about the stated job |
| A3 | "I don't see a shipped API product in your background. How would you handle shipping one here?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Accept the observation without arguing. Give your V1 sentence at its scope: you led client integrations of the vendor's APIs. Never say you built them. Answer slot: name which stages you led and how they went, in your own words. If a stage wasn't yours, say so. Then answer the "how would you" half as a plan: discovery with partners, spec, staged release, adoption measure | F3 is a must-have with a relationship-axis limit, so it's the likeliest place for a reach. Part observation, part CASE |
| A4 | "Why move from integrations into product now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your real reason, in your own words. The pack doesn't supply one. If the V3 sessions are part of why, you can say you ran them and fed client evidence to product, in those words. Keep "input" explicit, because the roadmap was someone else's. Don't say you were "already doing PM work." Close forward-looking: what you want to own here | Motivation consistency is the Skeptic's second standard probe after the gap. F7 is the nearest quoted thread |
| A5 | "This role drives delivery with two engineering squads. How have you driven delivery with engineers before?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Lead with what V1 states: you led integrations through UAT and go-live. Answer slot: if you worked with engineers on those integrations, say how and what your part was, in your own words. If you didn't, say so plainly and stay with leading the integrations to go-live. Never claim to have set a squad's priorities. That line is in `prohibited_claims` | F8 and F5 together. The JD names two squads, so this probe is likely. JD because it scores a listed responsibility |

### B. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's your first 90 days. How do you build the roadmap for our partner API platform?" | CASE | [generic] | Clarify first: which decisions are yours and which are the squad leads'? Is there a current roadmap? How is adoption measured? Then: partner discovery (who, how many, what you'd ask), an inventory of current asks and incidents, themes, sequencing criteria (partner impact, effort, strategic fit), review with the squad leads, and a first draft by day 90. Every step is a plan. No "like I did before." Challenge one premise: maybe the 90-day output is a set of decisions, not a roadmap | The JD's first responsibility, asked live. `[generic]` because no Quartzline strategy was researched |
| B2 | "Partner API adoption is flat. Diagnose it." | CASE | [generic] | First ask how adoption is counted. The dossier notes there's no stated baseline. Then walk the funnel: sign-ups, first successful call, production traffic, retained usage. Segment by partner type. Form hypotheses at each step (docs, auth friction, missing endpoints, sales promising one thing and the API doing another). Name the data you'd pull first and the one assumption you'd check before acting | Covers the adoption-metrics responsibility (F9). A metric case lets you show measurement thinking without claiming a past metric |
| B3 | "Two big partners want conflicting changes to the same endpoint. How do you decide?" | CASE | [generic] | Clarify each partner's underlying need, not their proposed solution. Options: versioning, configuration, a third design that serves both, or saying no to one. Criteria: how many partners it affects, revenue and strategic weight, cost of a breaking change. Say who you'd involve (squad lead, the partner owners in sales) and how you'd explain the decision to the partner who loses | Tests prioritization live, which is the R1 sub-claim, without asking about a past you don't have. Also covers R4 |
| B4 | "A sales lead promised a partner a feature that's not on the roadmap. What do you do?" | CASE | [generic] | Separate the partner's problem from the promise. Find out the deal's value and the timeline. Check whether the need already maps to something planned. Then decide: pull it in, offer an interim workaround, or reset expectations together with sales. Agree a process so it doesn't happen again. Keep the relationship with sales intact | R4 names sales as a stakeholder. A common platform-PM tension. `[generic]` |
| B5 | "What goes into a good spec for a new partner-facing endpoint?" | CASE | [generic] | Problem and the partners it serves; success measure; the request and response schema and error cases; auth and rate limits; versioning and deprecation; docs and sample calls; rollout and partner comms; open questions for the squad. Keep it about the spec, not about specs you've written | Covers "write specs" (F8) and R3's docs and schemas (F4) as a live problem |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30+ integrations — how are you counting that, and which were yours end to end?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, in your own words: how the 30+ was counted, what would move the count, the assumption behind it you'd defend least, and which part was yours. If you don't know exactly how it was counted, say so plainly. Name the weakest assumption before they do | The number in F1 and F3 draws the first probe. EXP because it tests attribution |
| C2 | "Tell me about the integration playbook. What's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | You wrote it, and your team uses it. Keep that scope: your team, not the company. Answer slot: what it covers and why, in your own words. The dossier records it as inspectable. If you're free to share a redacted page, offer to | Your highest-confidence artifact. A hiring manager for a PM role will read it as a sign of how you write specs |
| C3 | "What came out of your roadmap-input sessions, and what did product do with it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Volunteer the limit first: you ran the sessions and fed client evidence to product, and there's limited documentation behind it. Say "input" plainly. Answer slot: if any of that evidence led to a product change, say which, in your own words. If you don't know, or none did, say so and describe how you ran the sessions | F7 is medium confidence, so a prober will find the seam. Coaching the limit up front turns that into credibility |

### D. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and "Wrote the internal integration playbook her team uses" and "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each one sentence from the quotes: you led the integrations, you wrote your team's playbook, you ran the roadmap-input sessions. Add tenure and titles in your own words. The pack doesn't supply them. Close on why this role, which matches A4. No "essentially a PM" summary | The likeliest opener. A tight arc sets up A1 on your terms |
| D2 | "How have you worked with engineering teams day to day? Any agile setups?" | JD | [grounded] | Clarify strategy (F6). Answer slot: if you've delivered inside an agile setup, say how it ran and what your part was, in your own words. If you haven't worked that way, say so plainly. Then: "What I'd want to confirm is how your squads run it: sprint cadence, who owns the backlog." The last part doubles as a reverse question | R5, asked casually. Casual questions on JD topics are still scored |
| D3 | "What drew you to Quartzline?" | CO | [generic] | Your real reason. This pack has no researched facts about Quartzline, so don't state any from memory. If you've read their API docs or product pages, say what you noticed. Tie it to the partner-facing API platform the JD names | A standard opener. CO because it signals homework. `[generic]` because research didn't run |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate. Then V1 at its scope, plus the angle: an outside view from the client side of API integrations. Say it as your perspective, not as proof. If they push, concede that an internal candidate knows Quartzline's systems better. Hold on what you led | A compressed A1. The time box tests composure |
| E2 | "That playbook — how much of it was actually you?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Hold with what the quote says: you wrote it. Answer slot: if others contributed sections or reviews, say who did what, in your own words. If it was all you, say so plainly. Don't shrink it to sound modest, and don't widen who uses it | The attribution probe aimed at your strongest artifact. A calm, exact answer helps you most here |

### G. Values/Behavioral (2)

Bank IDs skip F so they don't clash with fit-snapshot rows F1–F9.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you told leadership something they didn't want to hear." | VAL | [generic] | Pick a time with a named stake, a moment you didn't fold, and the relationship still intact at the end. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A persona stem. Product roles involve saying no. `[generic]` because Quartzline's values weren't fetched |
| G2 | "When did you put a customer ahead of an internal metric or deadline?" | VAL | [generic] | Pick a time when a client's need cost something internally, and say what you chose and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A persona stem that fits a partner-facing role. `[generic]` |

### H. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You'll share this roadmap with two squad leads. Where's the line, and what happens when you disagree?" | CASE | [generic] | Propose principles, not a turf claim: the PM owns the what and the why (partner problems, outcomes), and the squads own the how and the estimates. Disagreements get settled with data and partner evidence, then escalated by an agreed rule. Then ask how it works today. This is reverse question R1 | The dossier flags the PM's authority relative to the squad leads as unresolved. The hiring manager may test whether you'll grab or abdicate |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time shared work succeeded, and say how you named others' parts. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A collaboration probe for a role that drives delivery through squads it doesn't manage |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years PM (F1, F2) | A1, A2, E1 |
| R2 Shipped API or platform products (F3) | A3, B5 |
| R3 Technical fluency: API docs, schemas (F4) | B5 |
| R4 Stakeholder management (F5) | A5, B3, B4 |
| R5 Agile delivery (F6) | D2 |
| Own the roadmap (F2) | A1, A2, B1, H1 |
| Run discovery with partners (F7) | C3, B1 |
| Write specs, drive delivery with two squads (F8) | A5, B5, H1 |
| Define and track adoption metrics (F9) | B2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier. The JD claims this authority but nothing shows it, and the answer decides whether the job is the one described |
| R2 | "How is partner API adoption measured today, and what's the current baseline?" | From the dossier. Adoption is a stated responsibility with no stated baseline. It reads as metric discipline and tells you what you'd be judged on |
| R3 | "Where does partner feedback enter the roadmap today, and who hears it first?" | Shows how discovery actually runs, and connects to the V3 sessions without overstating them |
| R4 | "What would make you say, six months in, that this hire was the right call?" | Gets the real scorecard behind the JD |
| R5 | "How do you see someone from integration leadership ramping into this role, and what would you want them to learn first?" | Names the adjacency openly. It shows the self-awareness the dossier's conditions ask for and gets you the ramp expectations |
| R6 | "How do the squads run delivery day to day: sprint cadence, who owns the backlog?" | Answers the R5 clarify honestly and shows you'll adapt to their process rather than import one |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier `prohibited_claims` | "I haven't held a product manager title." Then F1's V1 sentence at its own scope, as adjacent work |
| Having owned a product roadmap | dossier `prohibited_claims` and `acknowledge_gap` | "I haven't owned a product roadmap." Then a ramp plan, as a plan. No bridge |
| Having set prioritization for an engineering squad | dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." A5's slot stays inside leading integrations |
| Shipped an API or platform product | Inflated form of F3 | V1 at its own scope. The pack observes that your material says you integrated the vendor's REST APIs for clients, not that you shipped the API product. A3's slot stays inside the stages you led |
| Wrote product specs for engineering squads | Inflated form of F8 | V1 at its own scope, including "requirements." The limit is the pack's observation: the requirements were for client integrations |
| Ran partner discovery | Inflated form of F7 | V3 at its own scope: you ran the roadmap-input sessions and fed client evidence to product. C3's slot asks only what came of it |
| The playbook is used company-wide | Inflated form of C2's quote | "Wrote the internal integration playbook" that your team uses. Keep the scope at your team |

---

## Sources

- **Provided:** `tuesday-dossier.md`, envelope v1.1 (a version this skill reads), generated 2026-08-14. Sections it supplied:
  - `role_profile`: the requirements and responsibilities in the fit snapshot.
  - `handoff_to_mock_interview`: verified evidence V1–V3, the weak areas and their strategies, the A1 objection, reverse questions R1–R2, and the prohibited claims.
  - `decision`: context only.
  - The dossier has no `evidence_map`, `evidence_state` or `risk_register` sections, so the snapshot's grading for F4, F5, F7, F8 and F9 is this pack's own.
- **Searches sent (all refused, no permission granted in this session):**
  - "Quartzline company values" — refused
  - "Quartzline interview process product manager" — refused
  - "Quartzline partner API platform news 2026" — refused
- **Fetches:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The one call was refused. It would have given G1 and G2 the published values to theme them on. With no values round detected, there would still be no cheat sheet |
| 2. `Quartzline interview process product manager` | unavailable | The one call was refused. It would have shown the later rounds. Thursday's persona weights rest on your own description of the session, so they wouldn't change |
| 3. `Quartzline strategy` / recent news | unavailable | The one call was refused. It would have grounded B1–B3 and D3 in current priorities and turned at least one into a CO question. All of them stay `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so the pack has no interviewer read |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Web search permission** → targets 1–3 run: Quartzline's own values for F1 and F2, the rest of the loop, and current strategy, turning B1–B3 and D3 from `[generic]` into grounded CO and CASE questions.
- **Deep research pass** (up to 6 more searches and 2 more fetches, several more minutes; needs search permission) → a strategy brief and the competitive picture for a "why Quartzline's platform" drill.
- **The hiring manager's name** → a read of their public career path, persona weights adjusted to it, and one reverse question tied to their path.
- **Recruiter guidance** (focus areas, anything to prepare) → coverage of whatever they named, and a build section for any deliverable they announced.
- **How much prep time you have** → a prioritized triage schedule sized to it.
- **Your raw CV** → tenure, titles and any further lines quoted into D1, G1, G2 and H2. Selection scaffolds become story maps where a line carries the story.
- **Your answers to the answer slots on F4, F5, F6, F8 and F9** (told to me outside a drill) → those rows gain quoted evidence, and A3, A5, B5, D2 and B2 regenerate on it.
- **A redacted page of the integration playbook** → C2's guidance can point at real contents.
