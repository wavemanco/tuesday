Still reading the skill's rules. Then I'll do some quick research on Kelverton Rail and build your pack.
I've built your prep pack for Tuesday and saved it as `Kelverton-Rail_senior-partnerships-manager_interview_pack.md`. It's based only on your message and the recruiter's email. My web searches on Kelverton were refused, so it has no company research, and I haven't seen the market report. Wherever the 15-minute talk needs the report's findings, the pack leaves a slot for you to fill.

- **Biggest risk (question B1):** Ross saying "you've never carried a direct quota." The pack has you say it yourself in the first 20 seconds, then stand behind the roughly £4M of influenced revenue. You admit the quota gap once, plainly, and don't argue that influenced revenue is the same thing.
- **The talk:** a minute-by-minute running order and three possible themes to choose from. Each theme comes with a weakness you name yourself and a line on what it means for operators, which covers the recruiter's "land on operators" ask. Since their own strategy team wrote the report, the advice is to agree with one finding and push further on one, rather than reciting it.
- **What not to say:** your consulting was bus and light rail network planning, so never call it "rail experience." Always say the £4M with "roughly" and "influenced."
- **Your four hours:** about two hours on Saturday building the talk and the quota/£4M answers. Then about two on Sunday rehearsing out loud: the talk twice against a timer, Ross's commercial questions, and your opening story.

If you want to rehearse, I can play Ross and ask you B1 with live follow-ups.
I can also save a `tuesday-dossier.md` file with the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I can convert it.

Do you have the job description or your CV to paste in? Either would replace three of the pack's assumed requirements with real ones and give the story questions more of your actual experience to work from.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, 60-minute panel on Tuesday
**Panel:** Deepa, VP Partnerships (your future manager), and Ross, Commercial Director
**Format, from the recruiter's email:** a 15-minute POV with no slides on where you'd take operator partnerships over the next 18 months, landing on "what it means for the operators themselves". After that it's Q&A, and "Ross will push on commercials"
**Built from:** your message and the recruiter's email. I had no JD, no CV and no web research (the searches were refused; see Sources). I haven't seen the market report, so wherever the POV needs its content, the pack leaves a slot for you to fill.

---

## 1. How to use this pack

- **Personas** describe how a question is asked: who is asking and in what register. **Types** describe what is being scored.
- **Type key:**
  - **VAL**: whether your past behaviour shows the values they care about
  - **EXP**: whether your stated experience holds up under scrutiny, and what was actually yours
  - **JD**: whether you can do the job as described, including its gaps
  - **CO**: company and market knowledge, and whether you can think at their altitude
  - **CASE**: a live problem from the role, scored on structure and reasoning
- **Provenance labels:**
  - `[grounded]`: traceable to your message or the recruiter's email
  - `[inferred]`: derived, and the derivation is named
  - `[generic]`: a role-family pattern that says nothing specific about Kelverton
- **Answer slots** tell you what to say in the interview, in your own words, and always include an honest branch. You don't need to answer them here.
- The guidance is scaffolding, not a script. Rehearse it in your own words.

## 2. Prep triage: about four hours over the weekend

| Order | Block | Time | What, tied to the pack |
|---|---|---|---|
| 1 | Saturday | 75 min | Build the POV (section 3). Choose your three moves, write the opening and the operator close word for word, and fill the report slots from the report itself |
| 2 | Saturday | 45 min | Highest-ROI prep: B1 (the quota objection) and D1 (how the £4M was counted). Write your own answers to their slots before rehearsing aloud |
| 3 | Sunday | 40 min | Run the POV aloud twice with a timer and aim for 13 minutes. Cut whatever runs over. Don't add slides |
| 4 | Sunday | 40 min | Ross's commercial cases aloud: B2, B3, B4, then E1 |
| 5 | Sunday | 20 min | C1, C3 and F1 aloud, then pick three reverse questions (section 7), including R2 |

Everything else in the pack is insurance.

---

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your evidence is a partner channel at a payments company, not operator partnerships in rail. Keep the words at that scope: "I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the recruiter's framing makes a probe on how you'd grow partnerships likely. If choosing which partners to bring on was yours, say how you chose, in your own words. If it wasn't yours, or there was no such choice, say so plainly and stay with the channel you ran |
| F2 | "land on what it means for the operators themselves" — recruiter | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material covers bus and light rail network planning in consulting. It doesn't cover train operating companies. "From the other side" is your phrase: use it as yours and don't widen it into rail-operator experience. Answer slot: the recruiter's ask makes a probe on how well you know operators' problems likely. If operators were clients or stakeholders in your planning work, say which kind and what part was yours, in your own words. If they weren't, say so plainly, then say what you know about operators and where that knowledge comes from |
| F3 | "Ross will push on commercials" — recruiter | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The commercial evidence is influenced revenue. Always say the figure with both qualifiers you gave it: "roughly £4M of influenced revenue". Answer slots, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you'd defend least, and which part was yours. "I don't know exactly how it was counted" is an honest answer |
| F4 | Owning a revenue number directly, a common expectation for a senior commercial-facing partnerships role | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap you have stated yourself, which no wording can close. Words: "I haven't carried a direct quota. My number was influenced revenue." Then say how you'd want to be measured here, framed as a plan and never as a past. Don't add anything to make the gap feel smaller |
| F5 | Selling into train operating companies, which your message says is Kelverton's market | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap you have stated yourself. Words: "I haven't sold into rail." Then F2's quote, kept at its own scope, and a ramp plan for learning the rail buyer |
| F6 | Senior-level partnerships experience, as the title implies | "9 years in partnerships" — your message | medium | [grounded] | none | No gap. Lead with the length of time in your own words: nine years in partnerships |
| F7 | "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it" — recruiter | none given | none | [grounded] | discovery | The 15 minutes are the evidence here, so build it (section 3) and rehearse it aloud. Answer slot: if they ask how you usually present, and you've presented to clients without slides before, say so in your own words. If you haven't, there's nothing to say, and the talk itself answers the question |

**Requirement coverage**

| Row | Covered by |
|---|---|
| F1 | POV, A1, A2, A4, D2, D3 |
| F2 | POV close, A3, C1, C2, G2 |
| F3 | B4, D1, D2, D3 |
| F4 | B1 (highest-ROI), B4 |
| F5 | C1, C4 |
| F6 | F1 |
| F7 | POV build (section 3), the Sunday aloud runs |

---

## 4. The POV: 15 minutes, no slides

The recruiter asked for "where you'd take our operator partnerships over the next 18 months", to "land on what it means for the operators themselves". That close is required. The report came from their own strategy team, so Deepa and Ross have probably read it and may have helped shape it. Reciting it scores as homework. Agreeing with one thing in it and diverging from another, with reasons, scores as judgement.

**Facts to build on**

| Fact | Provenance | How to use it |
|---|---|---|
| The brief: 18 months, operator partnerships, land on operators | [grounded] recruiter's email | Repeat the brief back in your first 20 seconds so they hear you answering their question |
| F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | [grounded] | Use it once, as the lens you bring, worded exactly as F1's bridge words it. Don't make the POV about you |
| F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | [grounded] | One line, in your words and at its own scope, explaining why you start from the operator. Never as rail experience |
| Report slot: the two or three findings you'd stand behind | [grounded] once you fill it from the report | Pick one as your consensus anchor and quote its number or phrase accurately |
| Report slot: one finding you'd push further or read differently | [grounded] once you fill it from the report | Your divergence. Frame it as "where I'd go further", never "where the report is wrong" |

**Running order**

| Clock | Beat |
|---|---|
| 0:00–1:30 | Restate the brief. Say what you'll cover, and that you want their reaction on the third move |
| 1:30–3:30 | Where operator partnerships stand today, using the consensus finding from the report |
| 3:30–11:00 | Three moves, each about 2.5 minutes and each with its concession, chosen from the table below |
| 11:00–13:30 | What it means for the operators themselves: one sentence per move, said from the operator's side |
| 13:30–15:00 | What you'd measure at 6, 12 and 18 months, and what you'd want to learn in the first 90 days |

**Candidate theses** (pick two or three, and never present one without its concession)

| Thesis | The move | Mandatory concession | What it means for operators | Provenance |
|---|---|---|---|---|
| T1 Fewer, deeper | Turn a small number of operator relationships into real partnerships: joint roadmap input, early access, shared success measures, and reference rights in return | Depth costs breadth. One operator can capture the roadmap, and other customers may see favouritism | Operators who partner get product shaped around their actual planning problems, sooner | [generic] |
| T2 Build the ecosystem around the operator | Bring the technology partners an operator already depends on into integrations with the scheduling product, so the operator's data flows between systems | Kelverton may not want to be a platform. Partner integrations add support load, and operators may want fewer vendors rather than more | Less manual re-keying between systems. The operator buys an outcome rather than stitching tools together | [generic]; the lens is F1's, so word it as F1's bridge does |
| T3 Commercials tied to operator outcomes | Pilot one partnership where part of the commercial terms is linked to an outcome the operator already measures | Attributing the outcome is hard and Ross will press on it. An operator's own contracts may limit what it can sign | The operator pays partly for results rather than only for licences | [generic]; check against the report's commercial section |

**Differentiation**

| Move | Content | Provenance |
|---|---|---|
| Consensus anchor | One report finding, quoted accurately | [grounded] once filled from the report |
| Divergence | One place you'd push further than the report, with your reason | [grounded] once filled from the report |
| Anti-pick | Say what you would not make the 18-month goal: the number of operator partnerships. Depth and operator outcomes come first. You may set this against F1 at its own scope, "took it from 6 partners to 40", without claiming any lesson from it that you don't hold in your own words | [generic] |

---

## 5. Persona table

The loop is set by the recruiter's email: one 60-minute panel session, a POV, then Q&A. No values-style round is named, so there is no values cheat sheet.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Deepa, following up on the POV | High: she is the hiring manager and set the POV brief | Clarify, then set the objective, segment, approach, metrics and risks. Think aloud, and challenge one premise respectfully |
| Pressure | Ross, on commercials | High: the recruiter said "Ross will push on commercials" | Pause before answering. Hold what F3 and F4 actually say through two follow-ups, and concede the quota gap early and plainly |
| Skeptic | Deepa, on the jump into rail | High: F4 and F5 are stated gaps, and she is the one buying the risk | Rehearse C1 until it feels boring. Bridge only from F2's scope, and pair it with a concrete ramp plan |
| Data-Driven Prober | Ross, on the £4M and the 6-to-40 figures | Medium: the headline figures invite probing, and commercials are his remit | Know what you can and can't say about how each figure was counted, and name the weakest assumption before he does |
| Peer Evaluator | Ross, as the adjacent commercial team | Medium: partnerships and commercial share a seam with operators | Propose principles for the seam and say what you bring to his team |
| Conversational | Either of them, at the opening | Low to medium: it's a second round, but the opener is still scored | Have a 90-second arc ready |
| Values/Behavioral | Either of them, briefly | Low: no values round is named | Have two stories chosen in advance, or say plainly where you have none |

---

## 6. Question banks

### A. Case/Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would you actually do in your first 90 days?" | CASE | [generic] | Listen, diagnose, choose, commit. Listen to internal account owners and a handful of operators. Diagnose which relationships are already partnerships in all but name. Choose one or two lighthouse operators. Commit to the measures you'd report at six months. The question needs no claim about your past, so the guidance makes none | The natural first follow-up to an 18-month POV. CASE because it tests whether the POV can be turned into a plan |
| A2 | "Which operators would you prioritise, and how would you decide?" | CASE | [generic] | Ask first what Kelverton counts as a partnership as opposed to a well-run account. Then give criteria: strategic fit, willingness to co-develop, contract timing, reference value, and the internal cost of serving them. Name one risk of each criterion | Tests the T1 logic under pressure. CASE because the answer is structure, not a past |
| A3 | "Our operators are already our customers. What's a partnership on top of that?" | CO | [generic] | Define tiers aloud: customer, engaged customer, partner. A partner gives something beyond payment (roadmap input, data, reference) and gets something beyond the product (influence, early access). Ask how Kelverton defines it today | The seam the POV has to resolve and the likeliest premise challenge. CO first because it rests on how the company frames its customers |
| A4 | "How would you build a technology-partner ecosystem around the scheduling product?" | CASE | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Start with the operator's problem, then which partners touch it, then integration priority. You may name the lens at its own scope: you ran an ISV channel at a payments company and took it from 6 partners to 40. Answer slot: if you set the criteria for which ISVs to bring on, say what they were, in your own words. If you didn't, say so plainly and stay with the problem-first structure | T2 tested live. F1 is the evidence closest to this question. CASE delivery, with an EXP probe likely inside it |
| A5 | "You've read our market report. What would you push back on?" | CO | [inferred] | Name one finding you agree with and why, then one you'd push further, with a reason. Fill both from the report yourself. Don't call it wrong. Frame it as what you'd want to test in the first six months | Inferred from the recruiter attaching an internal report: sending it invites this question. CO because it scores homework and judgement |

### B. Pressure (Ross, commercials)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep in the pack.** "You've never carried a direct quota. Why should I believe you can deliver a commercial number here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Name the limit in your first 20 seconds, before he does: "I haven't carried a direct quota. My number was influenced revenue: roughly £4M, from an ISV channel I took from 6 partners to 40." **Hold:** influenced revenue is commercial work you can explain number by number. **Concede, plainly and once:** you haven't owned a closing quota, and you won't argue that influenced revenue is the same thing. **Follow-up 1**, "Influenced is soft. Who closed?" Answer slot: say who closed, in your own words, and which part was yours. If you don't know the split, say so. **Follow-up 2**, "So what number would you sign up to?" Plan, not past: say what you'd need first (a baseline, and rules for what counts as partnership-influenced), then propose the shape of a target. **Follow-up 3**, "Would you take a quota?" Give your honest answer. The pack doesn't decide it for you | F4 is the most predictable objection and the recruiter has already said where Ross will push. Deepest rehearsal because some version of it is near-certain. JD because it scores the commercial side of the role |
| B2 | "Sixty seconds: what's the commercial model for an operator partnership? Who pays whom, for what?" | CASE | [generic] | Cover the value created, who captures it, and the options: licence uplift, co-funded development, a revenue share with technology partners, and outcome-linked terms. Say which you'd pilot first and the one risk you'd watch | Ross's native ground. CASE because it is time-boxed structure under pressure |
| B3 | "A big operator wants us to build a feature for them, and wants a discount. Yes or no?" | CASE | [generic] | Your starting answer is "not as asked". Then the conditions: it fits the roadmap, it's reusable for other operators, IP stays with Kelverton, the exclusivity window is short, you get reference rights, and the price stays intact. Hold the no through one push, then name what would turn it into a yes | Tests whether you'll protect price and roadmap. The anti-pick, live |
| B4 | "Your POV costs money. What's the return in 18 months, and how would I know it was you?" | CASE | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Propose agreeing attribution rules up front, before any number is reported, and lead indicators at 6 and 12 months. Answer slot: the recruiter flags commercials, so expect a probe on attribution. If you agreed rules for counting influenced revenue in your channel, say how, in your own words. If you didn't, or someone else set them, say so plainly and propose how you'd set them here | F3 and F4 meet the POV here. CASE, with an EXP probe |

### C. Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail. Why will operators take you seriously?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | "I haven't sold into rail." Then your consulting at its own scope: five years in transport consulting, on bus and light rail network planning. Answer slot: who your clients were, and which side of the table you sat on. If operators weren't the client, say so. Then the ramp: who you'd spend your first month with. Never say "rail experience" | F5, the second stated gap, through the manager's lens. JD because it scores fit to the market |
| C2 | "What do you actually know about how an operator plans its services?" | CO | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Say what you know and where it comes from. Answer slot: if any of it comes from your consulting work, say what part was yours, in your own words. If none does, say so plainly and say how you'd close the gap. Don't borrow product vocabulary as if it came from experience | Tests F2's limit. CO because it is about the buyer's world |
| C3 | "Why leave payments for rail, and why now?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The arc is in your own sentences: transport consulting, then partnerships in payments, now back to transport. Answer slot: the reason is yours to give, in your own words. If it's partly about leaving the payments role, say so briefly and without complaint | The Skeptic's motivation check. F1 and F2 give the arc |
| C4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick a real gap: "I haven't sold into rail." Follow it with the 90-day ramp from A1. Don't offer a disguised strength | A persona stem the honest answer is ready for. F5 supplies the gap |

### D. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M was counted." | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Keep "roughly" and "influenced". Answer slots, in your own words: how it was counted, what it is sensitive to, the assumption behind it you'd defend least (name that one before he asks), and which part was yours. "I don't know exactly how finance counted it" is an honest answer, and better than a method you can't repeat | The headline figure, and F3's main exposure. EXP because it tests attribution |
| D2 | "Of the 40 partners, how many actually produced revenue?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if you know the split, give it. If you don't, say so plainly. Either way, say how you'd want partner productivity tracked here | Asks for the denominator behind the second figure |
| D3 | "Over four years, how much of that growth was you, and how much the team or the market?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say which part was yours and which wasn't, in your own words, using "we" for context and "I" for contribution. If you can't separate them cleanly, say so | The classic attribution probe on F1 and F3 |

### E. Peer Evaluator (Ross, as the adjacent commercial team)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the line between your partnership work and my team's account management of operators?" | CASE | [generic] | Propose principles rather than pretending to know the seam: one owner per operator relationship, partnerships brings the structure and the ecosystem, commercial owns the contract, joint planning on lighthouse accounts, and credit rules agreed in advance. Then say what you'd bring his team | The seam between partnerships and commercial. CASE because it is a live organisational problem |
| E2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Choose an instance from your influenced-revenue work where credit was shared or contested. It needs a named stake, what you did, and a relationship that stayed intact. If no such time comes to mind, say so plainly and describe how you'd set credit rules here | A persona stem made sharper by F4. EXP because it tests what actually happened |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk us through the journey." | EXP | [grounded] "9 years in partnerships" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | 90 seconds: nine years in partnerships; five years in transport consulting on bus and light rail network planning; four years running an ISV channel at a payments company, 6 to 40 partners, roughly £4M of influenced revenue; and why rail now, in your own words. End by handing back to them | The opener is still scored. F6, F2 and F1 give the arc |
| F2 | "What draws you to rail specifically?" | VAL | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot: your reason, in your own words. If the consulting years are part of it, say so at their own scope | A casual-register motivation probe. F2 gives the link |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment where you didn't fold, and a relationship that stayed intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Persona stem. Low weight, but candidates are rarely ready for it |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a partner or client example where you chose their outcome over your number. It echoes the operator close. If no such time comes to mind, say so plainly and describe how you'd handle that trade-off here | Persona stem tied to the recruiter's operator framing |

---

## 7. Reverse questions

| # | Question | To | Why it lands |
|---|---|---|---|
| R1 | "Eighteen months from now, what's the operator partnership you'd most like to exist that doesn't today?" | Deepa | Gets her vision in her own words and lets you connect it to your POV |
| R2 | "How is partnership work credited commercially today? Is there a number this role owns, one it influences, or both?" | Ross | Takes on F4 directly and shows you want to be measured |
| R3 | "Which parts of the market report is the business acting on, and which are still being debated?" | Either | Shows you read it as a working document and tells you where the politics are |
| R4 | "Which operators are closest to a real partnership today, and what's held the others back?" | Deepa | Tests T1 against reality and helps your first 90 days |
| R5 | "How do operators feed into the product roadmap now?" | Either | Shows where partnerships has leverage and where product owns the relationship |
| R6 | "What will make the first six months in this role hard?" | Deepa | Honest signal on the ramp and on what she'll be watching |

---

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried, hit or owned a quota | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't carried a direct quota. My number was influenced revenue." |
| "Generated" or "closed" £4M, or the figure said without "influenced" | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue" |
| Has sold into rail | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't sold into rail." |
| Experience with train operating companies, or "rail experience" | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning in consulting. C1's slot stays inside that |
| Built the ISV channel from scratch, or signed the 40 partners personally | Inflated form of F1 | F1's quote at its own scope: "took it from 6 partners to 40". D3's slot asks only which part was yours |

---

## 9. Sources

- **Provided:** your message, including the recruiter's email as you quoted it. The market report was mentioned but not shared with me, and nothing in this pack is drawn from it.
- **Searches sent:**
  - "Kelverton Rail values": refused
  - "Kelverton Rail scheduling software train operating companies news 2026": refused
  - "Kelverton Rail interview process partnerships": refused
- **Fetches:** none.
- **Dossier:** none consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The search was refused. It would have given G1 and G2 Kelverton's own value names. No cheat sheet either way, because no values round is named |
| 2. Kelverton Rail interview process | unavailable | The search was refused. The loop is still set by the recruiter's email, so the persona weights rest on that |
| 3. Kelverton Rail strategy and recent news | unavailable | The search was refused. It would have grounded A3, A5 and the POV's market framing. The report slots stand in for it if you fill them |
| 4. Deepa and Ross at Kelverton Rail | unavailable | No search was sent because search was refused on this host. It would have added a section on reading the panel, persona weights from their public footprint, and a reverse question tied to their career paths |
| 5. Representative Senior Partnerships Manager JD | unavailable | No search was sent because search was refused on this host. It would have turned F4, F5 and F6 from role-family rows into JD-backed ones |

---

## 10. Upgrade menu

- **The JD text:** F4, F5 and F6 rest on JD lines instead of role-family patterns. Every stated requirement gets a JD-tagged question, and new rows appear for anything the JD lists that this pack can't see.
- **Your CV:** more stories to map, so the selection scaffolds in E2, G1 and G2 become story-mapped answers.
- **The market report's key findings, pasted:** the POV's consensus and divergence slots become concrete, and A3 and A5 are grounded in Kelverton's own framing.
- **Your answers to the slots in D1, C1 and B4** (how the £4M was counted, who your consulting clients were, how attribution worked): those rows upgrade from slots to story-mapped answers.
- **Allowing web search:** targets 1 to 5 above run. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and Deepa's and Ross's public talks and writing.
- **Deepa's or Ross's public profile, pasted:** a section on reading the panel, persona weights tuned to each of them, and a reverse question tied to their own path.
- **A tuesday-dossier.md, if you have one:** evidence-derived objections and confirmed claims instead of inferred ones. It isn't needed for this pack.
