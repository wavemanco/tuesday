I've read the skill's rules and your dossier, and I'm now running a short company-research pass on Quartzline before writing the pack.
I've built your prep pack for the 45-minute hiring-manager conversation, from your dossier alone. Web search was blocked in this session, so nothing in it comes from Quartzline's own pages. The questions that would use their strategy (B1–B4 and D2) are marked `[generic]`.

- **What to rehearse first:** A1, the objection your dossier named: "You have never held the PM title or owned a roadmap — why should we hire you…?" It's coached in three steps:
  1. Concede the title and the roadmap in one sentence.
  2. Give your three verified points at their actual size: the 30+ integrations, the playbook, the roadmap-input sessions.
  3. Close on a 90-day plan, in future tense.

  It also scripts two follow-ups, where you hold your ground and then concede one specific thing.
- **Holding your dossier's line:** integration work is presented as close to PM work, never as PM experience. Roadmap ownership (F2) gets a plain "I haven't" and a ramp plan, with no bridge. Six claims you might reach for under pressure are listed as not coached, each with the honest version beside it.
- **What's in it:**
  - A fit snapshot that checks each requirement against your own sentences (F1–F10).
  - 21 questions across seven interviewer styles, weighted toward the Skeptic and the live-problem (case) questions a hiring manager usually asks.
  - A table showing which questions cover each requirement.
  - Six questions for you to ask them, including your dossier's two on squad authority and how adoption is measured.
- **Answer slots:** several rows (technical docs, sales and engineering contacts, agile, adoption metrics, specs) mark places only you can fill. Each gives you two honest options, including "I didn't do that", rather than words to say.

The pack's last section lists what would sharpen it most: search access or a pasted Quartzline values page, the hiring manager's name, and the full job description. A deeper research pass, if you allow search, costs up to 6 more searches and 2 more page reads.

Say the word and I'll play the Skeptic on A1, live, with follow-ups that react to what you say.
I can also update your `tuesday-dossier.md` with the gaps this prep turned up, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager (interviewer not named) · **Built on:** your `tuesday-dossier.md` (v1.1) plus the role profile inside it · **Research:** web search was refused in this session, so nothing here comes from Quartzline's public pages (see Sources)

---

## How to use this pack

- **Personas** describe *how* a question arrives (who's asking, in what register). **Types** describe *what* is being scored. Rehearse both: the same content lands differently from a Skeptic and from a Rapport Builder.
- **Type key**
  - **VAL**: behavioral / values. Does what you've done show the values they care about?
  - **EXP**: work-experience deep-dive. Does what you claim hold up, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company & strategy. Have you done your homework, and can you think at their altitude?
  - **CASE**: live problem. Structure and reasoning on a problem from the actual role.
- **Provenance labels**: `[grounded]` = traceable to your dossier; `[inferred]` = the pack's derivation, named; `[generic]` = role-family pattern, no claim about Quartzline or you.
- **Fit-snapshot rows are F1–F10.** Question IDs go by persona letter, and the letter F is skipped so the two never collide.
- **"Answer slot"** = a place only *you* can fill. Each one gives two honest branches. Pick the true one, in your own words.
- **The guidance is scaffolding, not a script.** Every claim about your past here is one of the three verified sentences in your dossier, kept at its own scope. If a suggested line sounds bigger than what you did, cut it.

---

## Fit snapshot

Evidence sources: **VE1–VE3** are the three entries in your dossier's `verified_candidate_evidence`, in order (see Sources).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | low | [grounded] | transferability | The dossier's condition is binding: present this as adjacent, never as PM experience. Words: first the plain acknowledgment that `prohibited_claims` ("Having held a product manager title or role") supports: "I haven't held the product manager title." Then the two quotes at their own scope: "I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live, and I ran quarterly roadmap-input sessions feeding client evidence to product." Let the interviewer decide how far that transfers. Don't argue that it counts as PM work. VE3 is medium, so volunteer its limit before it's probed: the input went to product. Answer slot: the JD's roadmap line makes "what did product do with it?" a likely probe. If you know what came of any of it, say what, in your own words. If you don't know, or nothing visible came of it, say so plainly and stay with the sessions you ran |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibility) | none given | none | [grounded] | capability | The dossier records this as `acknowledge_gap`. Owning a roadmap and prioritization authority has no evidence behind it, so there's no bridge and no slot. Words, from `prohibited_claims` ("Having owned a product roadmap"; "Having set prioritization for an engineering squad"): "I haven't owned a product roadmap, and I haven't set priorities for an engineering squad." Then a ramp plan, said as a plan, in future tense: how you'd learn the current roadmap, who you'd sit with first, and when you'd expect to be making calls. Add nothing that makes the gap sound smaller |
| F3 | "Shipped API or platform products" — JD (dossier R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | transferability | The material says integrations of an API, not shipping the API product itself, and the words stay there: "I've led 30+ client integrations of the vendor's REST APIs, end to end, through go-live." What went live was each integration. Let the interviewer weigh that against "shipped". Expect C1 to go deep on one of them |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Wrote the internal integration playbook her team uses" — dossier VE2 | high | [inferred] | discovery | REST API integrations that include architecture touch this requirement, but nothing in your material shows docs or schemas specifically. Answer slot: the JD's "API docs, schemas" line makes a probe likely. If you read, wrote or worked against API docs or schemas in those integrations or in the playbook, say which and how, in your own words. If not, say so plainly and stay with the integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [inferred] | discovery | "Client integrations" carries the customer side. Engineering and sales aren't in the quote. Answer slot: the JD names all three. If those integrations had you working with engineering or sales, say who and how, in your own words. If they didn't, say so plainly and stay with the clients |
| F6 | "Stakeholder management across engineering, sales, customers" — JD (dossier R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | medium | [inferred] | discovery | This carries a client-to-product channel that the JD's three groups don't name. Medium, so expect a probe on how the sessions ran. Answer slot: who attended and how the evidence was gathered, in your own words. If you don't recall the detail, say so and stay with what the quote says |
| F7 | "Agile delivery experience" — JD (dossier R5, preferred) | none given | low | [grounded] | discovery | The dossier's strategy here is `clarify`, and none of the verified entries speaks to agile delivery itself. Answer slot: the JD's "Agile delivery experience" is the likely probe. If you've worked in sprints, stand-ups or a similar cadence, say how, in your own words. If you never worked that way, say so plainly. Either way, close with "here's what I'd want to confirm about how your squads run it" |
| F8 | "Define and track adoption metrics" — JD (dossier role_profile responsibility) | none given | none | [grounded] | discovery | Your material doesn't mention metrics. Answer slot: if you tracked anything about how clients used the integrations after go-live, say what was counted, in your own words. If you didn't, say so plainly and say what you would measure first (B3 rehearses that) |
| F9 | "Run discovery with integration partners" — JD (dossier role_profile responsibility) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | medium | [grounded] | transferability | Sessions that fed client evidence to product sit next to discovery but aren't the same thing, and the words stay at the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if you gathered that evidence yourself, say how, in your own words. If others gathered it and you brought it together, say so plainly |
| F10 | "Write specs and drive delivery with two engineering squads" — JD (dossier role_profile responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | transferability | Leading requirements for client integrations is next to writing specs for squads. It isn't the same work, and squad prioritization is off-limits (`prohibited_claims`). Words: "I led the requirements on those integrations." Answer slot: the JD's spec line makes a probe on your requirements documents likely. If you wrote them, say what they covered, in your own words. If others wrote them, say so plainly and stay with what you led |

**No hard gates.** The dossier lists none, and "3+ years" is a length-of-experience requirement, not an eligibility term, so it's graded on fit (F1).

---

## Persona table

The loop for this session comes from your own words: one 45-minute conversation with the hiring manager. Weights start from the hiring-manager prior (Case/Strategist + Skeptic). There's no interviewer profile to adjust them by.

| Persona | How it shows up in this conversation | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | "Why hire you over a PM who's done this?", "What would you be weakest at?" | **Highest.** Hiring managers derisk gaps, and the dossier named this exact objection (F1, F2) | Rehearse A1 until it's boring. Concede the title and the roadmap plainly, then give your three quotes at their own size, then the ramp plan |
| B. Case / Strategist | Live problems about partner adoption, squad trade-offs, the first 90 days | **High.** The hiring-manager prior. The JD's adoption and squad lines are the natural case material | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Push back on one premise per case |
| C. Data-Driven Prober | "Walk me through one integration", "How did you count 30+?" | **Medium.** VE1's figure and VE2's playbook are the inspectable items, and a careful HM probes them | Know what you can and can't say about how the 30+ was counted. Bring the playbook only if it's shareable |
| D. Conversational / Rapport | The opener, "what do you know about us", casual discovery talk | **Medium.** A 45-minute conversation almost always opens this way, and casual questions are still scored | A pre-built 90-second arc made only from your three quotes. Treat casual questions as scored |
| E. Pressure | Time-boxed "60 seconds: why you", "how much of that was you?" | **Low.** Not the hiring-manager prior, but the PM-title gap invites one sharp version | Pause, restate, hold through two follow-ups, then concede the specific thing |
| G. Peer Evaluator | The HM speaking for the two squad leads: seams, decision rights | **Low.** The squad-authority unknown makes it likely the HM voices the leads' view | Reciprocity framing. Propose working principles rather than claiming to know the seam |
| H. Values / Behavioral | "Tell me about a time…" stories | **Low.** No loop source names a values round, and Quartzline's values weren't researched | Choose stories one of your quotes carries. Where none does, say so rather than invent one |

---

## Question banks

**Highest-ROI prep in this pack: A1.** Your dossier named it as the most likely objection. Rehearse it out loud three times before anything else.

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role", "Having owned a product roadmap" | **Concede first, in one sentence:** "That's right. I haven't held the PM title and I haven't owned a roadmap." **Then what you have, at its own size:** "I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live, and I ran quarterly roadmap-input sessions feeding client evidence to product." **Name the limit before they do:** the sessions fed input to product, and the roadmap decisions weren't mine. **Close on the plan, in future tense:** what you'd learn first and how fast. Don't say "that's basically PM work". Let them draw the line. **Follow-up 1:** "So what did product do with your input?" Use F1's answer slot: say what came of it if you know, and if you don't, say so plainly. **Follow-up 2:** "Isn't integration work just project management?" Hold: go back to the quotes (scoping, requirements, architecture, UAT, go-live, 30+ times) without upgrading them. Concede only the specific thing: "I haven't owned prioritization. That's the part I'd be learning here." | The dossier's named objection, aimed straight at F1 and F2, so some version of it will come up. It's JD-typed because it scores the must-have R1. Asked as written because both negatives have a `prohibited_claims` source |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `prohibited_claims`: "Having owned a product roadmap", "Having set prioritization for an engineering squad" | Name F2 directly. Don't pick a soft weakness: "Owning the roadmap and setting priorities for the squads. I haven't owned a product roadmap, and I haven't set priorities for an engineering squad." Then the ramp plan as a plan: the first conversations you'd have, what you'd read, when you'd expect to make your first prioritization call and get it checked. No bridge here. The dossier found nothing to bridge with, and inventing one live is how this question goes wrong | F2 is an `acknowledge_gap` area, and a hiring manager who has read the dossier-shaped gap will test whether you can see it yourself. JD because it scores the roadmap responsibility |
| A3 | "This role writes specs and drives delivery with two engineering squads. What have you done that looks like that?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having set prioritization for an engineering squad" | "I led the requirements on 30+ client integrations, through architecture, UAT and go-live." Answer slot: if you wrote the requirements documents, say what they covered, in your own words. If others wrote them, say so plainly and stay with what you led. Hold the line on squads: "I haven't set priorities for an engineering squad." Don't let "drove delivery" turn into "ran the squads" | F10's adjacent evidence against the delivery responsibility, which sits right next to the squad-authority unknown. JD-typed, premise from the JD line |
| A4 | "Why move from integrations into product management now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Give your real reason, in your own words. The pack can't supply it. A strong answer names something concrete. If the roadmap-input sessions are part of why, you can say you ran them, as the quote states. If they aren't part of it, don't borrow them. Keep it forward-looking and under a minute. Avoid anything that sounds like leaving integrations rather than choosing product | The Skeptic's "why now" tests whether your story holds together, and F1's gap makes it especially likely. Typed JD because it scores fit to this role, not a past project |
| A5 | "The JD asks for agile delivery experience. How have you worked in sprints?" | JD | [grounded] | Clarify form (dossier strategy `clarify`). Answer slot: if you've worked in sprints, stand-ups or a similar cadence, say how, in your own words. If you never worked that way, say so plainly. Either way, end with what you'd want to confirm: "How do your two squads run it: sprint length, who owns the backlog, where the PM sits in planning?" | F7 is preferred, not must-have, but an unrehearsed blank is a free miss. The guidance makes no claim about your past, so the label stands alone |

### B. Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has gone flat. How would you figure out why?" | CASE | [generic] | **Clarify first:** "How is adoption measured today: keys issued, first successful call, production traffic, active partners?" (this is also reverse question R2). **Segment** partners by size, use case and integration stage. **Funnel:** sign-up, first call, production, sustained use. Find the step where they drop. **Hypotheses** per step: docs, auth friction, missing endpoints, commercial terms. **Evidence:** usage data plus a handful of partner conversations. **Metric** to move and **risks**. Push back on one premise, for example whether flat adoption is really an adoption problem or a pipeline problem | The JD's adoption-metrics line (F8) and the dossier's unknown about the baseline make this the likeliest live problem. Generic because no Quartzline research ran |
| B2 | "Two squad leads each want next quarter for their own priority. How do you decide?" | CASE | [generic] | **Clarify decision rights first:** "Is this my call, or do I bring a recommendation?" (it's also the dossier's open question). Then: the objective the quarter serves, what each priority does for partners and the business, cost and risk, what can be sequenced or split. How you'd bring the leads in. How you'd tell the one who loses. Say plainly that this is how you'd approach it, not a story about having done it | Sits on the squad-authority unknown and F2's gap. Hiring managers test prioritization live when the CV can't show it |
| B3 | "How would you define adoption for a partner-facing API, and what would you track first?" | JD | [generic] | One headline metric (for example, active partners in production), two leading indicators (time to first successful call, integration completion rate), one health check (error rate or support tickets per partner). Say which one you'd track first and why. Answer slot: if you tracked anything like this in your integrations, say what was counted. If you didn't, say so plainly and stay with the plan | Covers the adoption-metrics responsibility (F8). JD content, CASE delivery |
| B4 | "It's your first 90 days. What do you do?" | CASE | [generic] | **30:** learn. The current roadmap, how decisions get made with the squad leads, the adoption numbers, conversations with partners. **60:** a written view of the main partner problems and one or two proposed bets. **90:** first prioritization calls, reviewed with your manager. This is where F2's ramp plan lives, so keep it concrete and in future tense | The natural follow-up to A1 and A2. A credible ramp plan is the honest answer to a capability gap |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through one of those integrations, from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one integration you remember well. The beats are the quote's own: scoping, requirements, architecture, UAT, go-live. Tell each in your own words. Answer slot: R2's "shipped" line makes a probe on what went live likely. Say what went live and what part you led, in your own words. If a stage was handled by someone else, say so plainly and stay with what you led | The deep-dive on F3, the evidence behind both must-haves. EXP because it tests what was actually yours |
| C2 | "30+ integrations — how are you counting those?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number answer slot, in your own words: how the 30+ was counted, what would change the count, the assumption behind it you'd defend least, and which of them you led start to finish. If you don't know exactly how it was counted, say so. That's an honest answer. Don't round up and don't explain a method you didn't use | A headline figure always attracts a prober. Naming its weak spot first turns a gotcha into credibility |
| C3 | "Tell me about the playbook. What's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | "I wrote the internal integration playbook my team uses." Answer slot: the JD's "API docs, schemas" line makes a probe likely. If the playbook covers API docs or schemas, say how. If it doesn't, say so plainly and describe what it does cover, in your own words. Offer to show it only if it's shareable outside your employer | F4's best evidence and your most inspectable item. Rehearsed so R3's technical-fluency probe lands on something real |

### D. Conversational / Rapport (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built from the three quotes only: the integrations you led, the playbook you wrote, the roadmap-input sessions you ran, then why product now (A4's answer). Answer slot: how long you've done this and where, in your own words. The pack doesn't state your years or employers because your verified entries don't | The near-certain opener. A tight arc sets up A1 on your terms. Typed EXP because what you claim here gets probed later |
| D2 | "What do you know about how partners use our API?" | CO | [generic] | Be straight: say what you've actually read or used, and nothing more. Then turn it into curiosity: "What I'd want to understand is how adoption is measured today and where partners get stuck." Don't present guesses about Quartzline as facts. This pack has no researched facts about them | Casual-sounding, but a homework check. Generic because research was refused; see the upgrade menu |
| D3 | "How do you find out what a client actually needs?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-map: the scoping and requirements on your integrations, and the client evidence you fed to product, as the quotes say. Answer slot: how you gathered it (calls, workshops, tickets, whatever it actually was), in your own words. If others gathered it and you brought it together, say so plainly | Covers "Run discovery with integration partners" (F9). Asked casually but scored |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done this exact job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having held a product manager title or role" | A1 compressed. Pause, then one sentence each: the concession ("I haven't held the PM title"), the integrations as quoted, and what you'd do in the first 90 days. Stop inside 60 seconds. Running long under a time box costs more than a short answer | F1 again, in its time-boxed form, so the A1 answer survives compression |
| E2 | "Those roadmap-input sessions — how much of what product built actually came from you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having owned a product roadmap" | **Hold:** "I ran the sessions and fed client evidence to product." **Concede the specific thing:** "The roadmap wasn't mine." Answer slot: if you know any item that came from that evidence, name it and say what part was yours. If you don't, say so plainly. "I don't know what came of it" is a full answer. Hold through two follow-ups by going back to the sessions, never by adding to them | VE3 is medium with little proof, so this probe is predictable (F6, F9). The hold-then-concede structure is what it scores |

### G. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "The squad leads own a lot here. How do you work with engineering leads you don't manage?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold: pick an integration where you worked through architecture or UAT with engineers, with a real disagreement and how it was resolved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the integrations you led), or how you would handle it. Then principles: agree decision rights early, bring evidence, disagree in private, commit in public | Covers the engineering part of R4 (F5) and the squad seam. The HM may speak for the squad leads here |
| G2 | "What would you need from a squad lead in your first month, and what would you bring them?" | CASE | [grounded] "Wrote the internal integration playbook her team uses" | Need: their read on the backlog, technical constraints, how they like to receive requirements. Bring: partner context. The kind of written integration guidance you've already produced; say you wrote your team's internal integration playbook, as quoted. Don't claim to know their pain points before you've asked | A reciprocity check: does this hire reduce or add to the leads' load. CASE because it's a forward-looking plan |

### H. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to a client or to leadership." | VAL | [generic] | Selection scaffold: it needs a named stake, the moment you said it, and what happened to the relationship afterwards. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Don't supply an ending you don't remember | A standard behavioral probe. Quartzline's values weren't researched, so it's themed from the persona stem, not their published values |
| H2 | "Tell me about a time sales and engineering wanted different things from a client integration." | VAL | [generic] | Selection scaffold: the conflict, what each side wanted, what you did, and the outcome. If no such time comes to mind, or you never worked with sales, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from R4 ("engineering, sales, customers"). It covers the sales gap F5 leaves open. VAL delivery, JD content |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1 3+ years product management experience | A1, A4, D1, E1 |
| R2 Shipped API or platform products | C1, C2 |
| R3 Technical fluency: API docs, schemas | C3 |
| R4 Stakeholder management across engineering, sales, customers | D3, G1, H2 |
| R5 Agile delivery experience | A5 |
| Own the roadmap | A1, A2, B4 |
| Run discovery with integration partners | D3 |
| Write specs and drive delivery with two engineering squads | A3, B2, G1, G2 |
| Define and track adoption metrics | B1, B3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From your dossier: the JD states decision authority but doesn't show it. It reads as diligence, and the answer tells you whether the role is what it says |
| R2 | "How is partner API adoption measured today, and what's the current baseline?" | From your dossier: adoption is named as a responsibility with no baseline stated. Ask it after B1 if that case comes up, since it follows straight on |
| R3 | "What would a strong first six months look like to you in this role?" | Lets you check your B4 ramp plan against their expectations while you're still in the room |
| R4 | "Where do partners get stuck most often with the API today?" | Shows partner-first thinking and gives you real material if there's a follow-up round |
| R5 | "How does partner feedback reach the roadmap today?" | Sits right next to what VE3 describes, so you can relate it to how you've seen that channel work |
| R6 | "What made you open this role now?" | Tells you whether this is a new seat or a replacement, which changes what the first year is for |

---

## Prohibited claims

These come from your dossier's `prohibited_claims`, plus the inflated forms the fit snapshot showed. No cell in this pack asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | "I haven't held the product manager title." Then F1's quotes at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims` and `acknowledge_gap` area | "I haven't owned a product roadmap." Then a ramp plan in future tense. No bridge, no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set priorities for an engineering squad." |
| Integration leadership described as product management experience | Inflated form of F1. The dossier's condition requires the bridge to be positioned as adjacent | VE1 at its own scope. The limit is the pack's observation, not a line for you: integrations led is not PM tenure |
| Shipped an API or platform product | Inflated form of F3 | VE1 at its own scope. The material says integrations of the vendor's APIs, not the API product. C1's slot stays inside the integration |
| Roadmap-input sessions described as shaping or deciding the roadmap | Inflated form of VE3 (F1, F6, F9) | VE3 at its own scope: evidence fed to product. E2's slot asks only what came of it, if you know |

---

## Sources

**Provided documents**
- `tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14 (about three months before this pack). Sections consumed: `role_profile` (stands in for the JD: requirements R1–R5, responsibilities, unknowns), `handoff_to_mock_interview` (verified evidence, weak areas with strategies, the named objection, risks, employer questions, prohibited claims), and `decision` (context only). The dossier has no `evidence_map`, `evidence_state` or `risk_register` sections. The fit snapshot is graded from the handoff instead.
- Verified evidence keys used in this pack: **VE1** = "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (high, inspectable). **VE2** = "Wrote the internal integration playbook her team uses" (high, inspectable). **VE3** = "Ran quarterly roadmap-input sessions feeding client evidence to product" (medium, confirmed, limited inspectable proof).
- Your message: one 45-minute conversation with the hiring manager. This sets the session and the persona weights.

**Searches sent**
- "Quartzline company values" — refused (search permission not granted)
- "Quartzline interview process product manager" — refused
- "Quartzline partner API platform news 2026" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have themed the H bank with Quartzline's published values by name. No values cheat sheet either way, since no values round is named for this session |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have shown whether later rounds exist, such as a values round or a case. This session's weights stand on your own description of it |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded B1–B4 and D2 in Quartzline's current priorities. They stay `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. There's no interviewer read |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already sets the requirements the fit snapshot and JD questions rest on |

---

## Upgrade menu

- **Allow web search, or paste Quartzline's values page and a recent news item or two** → B1–B4 and D2 move from `[generic]` to grounded in Quartzline's own priorities. The H bank is themed by their published values. The research table's rows 1–3 get filled.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes, and it needs search permission) → a strategy brief and a grounding section with Quartzline's own vocabulary and recent moves.
- **The hiring manager's name** → an interviewer read from their public professional footprint, adjusted persona weights, and a reverse question tied to their own path.
- **The full JD text** → the dossier's `role_profile` is a summary. The full posting may name tools or methods that have no question yet.
- **Your answers to the answer slots on F4, F5, F6, F7, F8 and F10** → those rows move from slots to quoted evidence, and A3, A5, B3, C3, D3 and G1 become story-mapped rather than two-branch.
- **Your CV** → D1's arc gets your actual years and employers, quoted, instead of a slot.
- **The recruiter's prep note, if there is one** → their stated focus areas and any pre-declared deliverable get their own build section.
- **How much prep time you have before the interview** → a prioritized prep schedule sized to it.
