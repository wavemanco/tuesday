I've built the mock-interview pack for Priya's 60-minute conversation with Dan Kovac. It has 23 questions in 7 banks, each set up as a table with question type, provenance, answer guidance and the rationale for including and categorising it.

The banks are weighted for a peer interviewer who calls himself data-driven:

| Bank | Persona | Questions |
|---|---|---|
| A | Data-Driven Prober | 5 |
| B | Peer Evaluator | 5 |
| C | Case/Strategist, tilted toward pricing | 4 |
| D | Skeptic | 3 |
| E | Pressure | 2 |
| G | Conversational | 2 |
| H | Values | 2 |

There's no bank F: those IDs belong to the fit-snapshot table.

Things to know before Priya rehearses:

- **The most important question is D1.** It's the "no sales-ops or quota-setting, and the partner work is a carrier revenue model" objection. The pack gives her the exact words to concede, what to hold on to, and how to handle two follow-ups.
- **Several answers are deliberately open.** Your notes don't say how the ~$400M was counted, what her part in the carrier negotiations was, or whether she has B2B experience. For those, the guidance gives her two honest branches to answer from rather than filling in details she'd have to defend.
- **The pack also covers:** a table matching Priya's background to each JD line, a read on Dan, why the personas are weighted this way, 7 questions for her to ask him, and a list of claims she shouldn't make. The main one: don't call her volume targets quotas.
- **None of the web research ran.** Search permission wasn't granted, so all three searches were blocked. The company-strategy and Compass questions rest on your research note, which hasn't been checked and whose age I don't know. Dan's profile details come only from your summary.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-1-denied-57aa520f:
- northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md

Say the word and I'll play Dan as the Skeptic on D1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter flag any focus areas or ask for anything to be prepared ahead, like a POV or a short presentation? A required piece would get its own build section. How much prep time does Priya have before the conversation? That would add a prioritised schedule.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. He is a **peer**: you would both report to the same VP. **Format:** a single 60-minute conversation.

---

## How to use this pack

Each question sits on two axes:

- **Persona** is *how* the question gets asked: Dan's register, follow-up style and pressure.
- **Type** is *what* is being scored:

| Tag | Scores |
|---|---|
| VAL | Whether your past behaviour shows values, here the working style Dan describes himself with |
| EXP | Whether your stated record holds up under scrutiny, and exactly what part was yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Northwind's level: its priorities, Compass, the bundling threat |
| CASE | Structure and reasoning on a live problem from this role |

Guidance is scaffolding, not a script. Every claim about your past rests on one of your own sentences, quoted in the row's Provenance cell. Where your material is silent, the guidance gives an **answer slot**: an instruction with two honest branches. One is what you did, in your own words. The other is a plain "that wasn't me" or "that didn't happen". Both branches are good answers.

Bank letters: A Prober, B Peer Evaluator, C Case/Strategist, D Skeptic, E Pressure, G Conversational, H Values. The letter F is skipped so question IDs never clash with fit-snapshot rows (F1–F8).

**Highest-ROI prep in this pack: D1.** Rehearse it until it's boring.

---

## Fit snapshot

Requirements are quoted from the JD highlights in the coach's notes. F7 and F8 are not in those highlights. They are role-family requirements, written as unquoted prose and labelled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material shows product strategy and ops, not ownership of a GTM strategy, and the words stay there: "I spent two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company." Answer slot: the JD's "own GTM strategy" line makes a probe on go-to-market decisions likely. If any go-to-market decisions within your product strategy work were yours, say which and how you made them, in your own words. If none were, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote shows an opportunity you proposed. It does not show whether any customer-lifecycle analysis sat behind it. Answer slot: the JD's whitespace line makes a probe on segmenting a customer base by stage likely. If any of your work did that, say what you segmented and how, in your own words. If none did, say so plainly and walk through how you would do it (A4, C3) |
| F3 | "run independent analysis in SQL and Tableau" — JD | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but nothing has been inspected behind it, so expect Dan to test it live. Lead with the quote's own words, "I'm skilled in SQL and Tableau", then let the A4 walkthrough show it rather than describing yourself |
| F4 | "partner-motion design experience required" — JD | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model is adjacent to partner-motion design and does not reach it. The words stay at the quote's scope: "I built a partner-level revenue model, and it was used in carrier negotiations." Answer slot: the JD's "required" makes a probe on partner-programme design certain. If any part of how partners were engaged was yours to shape (terms, structure, incentives), say which, in your own words. If none was, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already shows influence in other terms. Say it in its own words, "I set annual volume targets with cross-org consensus", and use that instead of calling yourself influential. A named outcome beats an adjective |
| F6 | "AI experience a plus" — JD | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Daily use is adjacent to AI product experience and does not reach it. Words: "I use AI tools daily." Answer slot: the JD's AI line makes a probe on AI product work likely. If you've worked on AI products or features, say what and which part was yours. If your experience is as a user, say so plainly and talk about what you use the tools for |
| F7 | Sales-planning mechanics such as quota setting and sales ops, common in GTM roles that sit beside sales strategy | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A stated gap that no wording can close. Words: "I haven't done classic sales-ops or quota-setting work." Follow it with how you would learn it, said as a plan and never as a past. Never present the F5 volume targets as quotas |
| F8 | Working knowledge of B2B or enterprise buying and selling, common in GTM roles at B2B SaaS companies | none given | none | [generic] | discovery | Strong evidence looks like a time you sold to, priced for, or analysed business customers. Pick that time if you have one. If none comes to mind, say so plainly, then give the nearest thing your material does carry ("I built a partner-level revenue model, and it was used in carrier negotiations"), or how you would ramp |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| F1 own GTM strategy for two new product lines | C1, C2, C3, D1, D3 |
| F2 whitespace across land/adopt/expand/renew | A4, C3 |
| F3 independent analysis in SQL and Tableau | A4, B4 |
| F4 partner-motion design (required) | D1, C4, B5, A3 |
| F5 cross-functional influence | A2, B1, B2 |
| F6 AI experience (a plus) | G2, C2 |
| F7 sales-ops / quota setting | D1, A5, E1 |
| F8 B2B context | D2 |

---

## Reading the interviewer

| Signal | Source | Implication for this conversation | Provenance |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | The coach's notes, relaying his profile | Every number you give gets probed down to its assumptions. That puts the Prober at the top of the weights. Name your weakest assumption before he does | [grounded] |
| "career spine is pricing and monetization roles" | The coach's notes | Case questions tilt toward pricing, packaging and unit economics (C1, C2). Compass pricing and the bundling response are his home ground, so clarify before proposing | [grounded] |
| "one early-stage-startup chapter" | The coach's notes | Building stories land well with him. Expect some scepticism about big-company pace and a probe on scrappiness. Your material carries no startup chapter, so don't borrow his | [grounded] |
| A peer under the same VP | The coach's notes | He is weighing what you add to his work and what you take from it. Seam, credit and reciprocity questions are likely (bank B), and his read probably feeds the VP's decision | [inferred] |
| Mirror opportunities | His path set against the fit snapshot | No shared career jump is offered: nothing in your material matches his startup move. The shared vocabulary is revenue modelling. You can say "I built a partner-level revenue model, and it was used in carrier negotiations" (F4) at that scope, and let him draw the link to his own monetization work | [inferred] |

These signals come from the coach's summary. The research to verify them could not run (see Sources).

---

## Persona weights

Starting point: a peer round leads with the Peer Evaluator and the Data-Driven Prober. Dan's signals adjust it. "Relentlessly data-driven" pushes the Prober up. His pricing background pushes the Case/Strategist up, with a pricing tilt. His startup chapter nudges the Skeptic up. The loop itself (one 60-minute conversation) is set by the coach's notes, so no archetype fallback is used.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Data-Driven Prober | Takes "~$400M" and the revenue model apart: how it was counted, what it's sensitive to, who did what | **Highest.** His self-description, plus a headline figure in your record | For each number, know what you can and can't say about how it was counted, and say plainly when you don't know. Volunteer the weakest assumption. Offer to sketch the analysis live (A4) |
| B Peer Evaluator | "Where's the seam between us?" Credit-sharing. "What would you need from me?" | **Highest.** Same VP, adjacent remit | Lead with reciprocity. Propose principles for the seam instead of pretending to know where it is. Ask how he draws it today |
| C Case/Strategist | Compass pricing, the bundling response, whitespace, partner design | **High.** His pricing background, plus a JD built around two new product lines | Clarify, objective, segment, approach, metrics, risks. Use Northwind's three priorities as the objective function. Challenge one premise per case |
| D Skeptic | The consumer-to-B2B jump, no quota or sales-ops background, partner design marked "required" | **Medium**, but it holds the highest-ROI question. A sales-strategy leader will notice F7 | Rehearse D1 until it's boring. Concede the stated gap in its exact words, hold on what your quotes carry, and give a concrete ramp plan |
| E Pressure | Time-boxed "why you", "how much was actually you" | **Low.** Peers rarely run stress interviews, but a data-driven prober drifts into it | Pause and restate the question. Hold through two follow-ups, then concede something specific |
| G Conversational | Openers and a casual AI aside | **Low**, but it is scored | Have a 90-second arc ready. Treat the casual AI question as a scored JD plus |
| H Values | "Changed your mind on data", "unpopular truth" | **Low.** No values round is in this loop; themes come from his self-description | Selection scaffolds below. Pick real stories before the day |

---

## Question banks

### A — Data-Driven Prober (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift from that store-surface change was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | State it at the quote's scope, keeping "proposed", "credited" and the "~": you proposed the change, and it was credited with roughly $400M ARR uplift. Then the four answer slots, each in your own words: how the figure was counted, what it's most sensitive to, the assumption behind it you'd defend least (name it before he asks), and which part was yours. If you don't know how it was counted, say so plainly and return to what you proposed. Never rebuild a method on the spot | It's the headline figure in your record, and Dan calls himself "relentlessly data-driven", so this is close to certain. EXP because it tests the attribution and the counting rather than the role |
| A2 | "Once you'd proposed the store-surface change, what happened next?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start from the quote: you proposed it, and it was credited with the uplift. Answer slot: the JD's "strong cross-functional influence" line makes a probe on how the proposal moved through other teams likely. If you moved it through other teams, say how and what was yours, in your own words. If the decision path wasn't yours, or you don't know it, say so plainly and stay with what you proposed | "Proposed" invites a "then what?" from a prober. JD-typed because it scores the influence requirement (F5) through the story behind the figure |
| A3 | "Walk me through the partner-level revenue model: what went in, how it was built, and how it was used in the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | You built it, and it was used in carrier negotiations. Those are the quote's beats. Describe its inputs and structure in your own words. Answer slot: the JD's partner-motion line makes a probe on your role in the negotiations likely. If you were in them, say what part was yours. If the model was used by others, say so plainly and stay with the model | It's your closest evidence for the required partner-motion line (F4), and it speaks Dan's monetization language. EXP because the question is what you actually did with it |
| A4 | "Say I hand you our account tables. Find me whitespace for a new product line across land, adopt, expand and renew. What's the first query you'd write?" | CASE | [generic] | Think aloud. Start with the unit (account), then the product-adoption flags, how you'd define each lifecycle stage, the joins to firmographics and spend, and the Tableau view you'd want at the end. Name the data-quality assumption you'd check first and ask what the tables actually hold. The question asks nothing about your past, so the guidance claims nothing | Tests two JD lines live (F2 and F3). CASE because it's a hands-on problem rather than a record. `[generic]` because it's a pattern, not knowledge of Northwind's data |
| A5 | "When you set those annual volume targets, how did you set them, and how did you know they were right?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Keep the words "volume targets" and "with cross-org consensus". Answer slot: describe how the targets were set and checked, in your own words. If there was a model or method, walk through it. If there was no formal method, say so plainly and describe how consensus was reached. Never call them quotas (see Prohibited claims). If he draws the comparison, the honest line is F7's: "I haven't done classic sales-ops or quota-setting work" | Target setting is the closest thing in your record to his world, so he'll press on whether it transfers (F5, F7). EXP because it's a deep dive into stated work |

### B — Peer Evaluator (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between sales strategy and emerging-products GTM, and what happens when we disagree?" | JD | [generic] | Don't pretend to know where the seam is. Ask how he draws it today, then propose principles: one shared source of truth for account data, clear owners for new-product targets, disagreements settled on data first, and the shared VP as a last resort rather than a first move. The guidance makes no claim about your past | It's the core peer question and scores the influence requirement (F5). `[generic]` because the seam principles are a pattern, not knowledge of how his remit is set up |
| B2 | "Tell me about a time you had to get people who didn't report to you to agree to a number." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5. The beats are the annual volume targets, which you set, and the cross-org consensus. Tell them in your own words. Answer slot: the JD's influence line makes a probe on where teams disagreed likely. If they did, say what was contested and what you did. If consensus came without a real dispute, say so plainly and describe how it was reached | The theme comes from the JD's "strong cross-functional influence", and a peer tests it with a number. JD because it scores a stated requirement |
| B3 | "On something like the store-surface change, how do you handle credit when the work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the quote's verbs: you proposed the change, and it was credited with the uplift. Answer slot: if others built, shipped or measured it, name their part. If you don't know the split, say so plainly. The peer is checking whether you'll take credit for his team's work | The attribution probe, asked politely. EXP because what's scored is how precisely you attribute |
| B4 | "What would you need from my team in your first 90 days, and what would you give us back?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first. What you give: you run your own analysis ("I'm skilled in SQL and Tableau"), so you won't queue for his analysts. What you need: his read of the sales motion, and access to pipeline and territory data. Close by asking what would actually help him | Peers judge whether a hire adds to their load or lightens it. JD because the JD's "independent analysis" line is the giving-back point (F3) |
| B5 | "Partner channels often collide with direct reps on the same accounts. How would you set rules of engagement so my reps don't feel partners are taking their deals?" | CASE | [generic] | Structure: which accounts or segments partners own, deal registration, how comp is credited when both sides touch a deal, how conflicts escalate, and the metrics that would show channel conflict. Ask how his reps are paid today before proposing anything. No claim about your past | Partner-motion design is required (F4), and a sales-strategy peer will test it where it meets his team. CASE because it's a live design problem |

### C — Case/Strategist, pricing tilt (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling a good-enough version of one of our new products for free. What do you do next quarter?" | CASE | [grounded] | Clarify first: which product line, which segments overlap with the bundle, and where Northwind wins today. Objective: weigh share against the stated profitability priority. Segment by land, expand and renew, since renewals are where a free bundle bites first. Options: compete on depth, integrate or partner, reprice or repackage, or concentrate on the segments the bundle serves badly. Metrics: win/loss against the bundle, renewal risk. Risk: a price war that undercuts profitability. Challenge one premise: is it actually good enough for enterprise buyers? | The bundling threat is the main competitive threat in the coach's research note. Dan's pricing background makes this his natural case. CASE because it's a live problem |
| C2 | "How would you price and package Compass: a standalone SKU, an add-on, or folded into enterprise tiers?" | CASE | [grounded] | Start by asking what it costs to serve, who the buyer is, and what job it does. Then test each option against the three stated priorities: does it drive enterprise expansion, does it help the launch, does it protect profitability? Pick one, state what would change your mind, and say the metric you'd watch in the first two quarters | Compass is a stated priority in the research note and it's pricing territory, so this is close to Dan's day job. Scores the JD's AI plus (F6) through delivery. CASE because there's no record behind it |
| C3 | "Enterprise expansion is a top priority. Where in our installed base would you look first for a new product line?" | JD | [grounded] | Use the land/adopt/expand/renew frame: which installed accounts look like the product's best early fits, where adoption of adjacent products predicts demand, and what renewal moments let you attach it. State one hypothesis early, then the query that would test it (A4) | Combines the JD's whitespace line (F2) with the note's enterprise-expansion priority. JD because it scores a stated responsibility; the delivery is CASE |
| C4 | "Design the partner motion for one of the new product lines. Who are the partners, what's in it for them, and how do you measure it?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure: partner types (resellers, SIs, technology alliances), the value exchange on each side, enablement, and the metrics (sourced vs influenced pipeline, partner-attached win rate). Where partner economics comes up, state your evidence at its scope: "I built a partner-level revenue model, and it was used in carrier negotiations." Let him draw the link. Don't present it as partner-programme design | The required JD line (F4), asked as a design problem. JD because it scores the requirement directly |

### D — Skeptic (weight: medium, 3 questions; holds the highest-ROI rehearsal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales ops or set quotas, and the partner work I see is a revenue model used in carrier negotiations, in consumer tech. Why should I believe you can design B2B GTM and partner motions here?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "built a partner-level revenue model used in carrier negotiations" "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal in this pack.** **Concede first, in these words:** "That's right. I haven't done classic sales-ops or quota-setting work." **Hold on what your sentences carry:** "I built a partner-level revenue model, and it was used in carrier negotiations. I set annual volume targets with cross-org consensus." Don't add "which is basically the same thing". **Answer slot:** the JD's partner-motion line makes the next probe certain. If any part of how partners were engaged was yours to shape, say which, in your own words. If none was, say so plainly and stay with the model. **Ramp plan, said as a plan:** what you'd learn from his team about sales planning, and which partner and pipeline data you'd look at first. **Follow-up 1:** "A model isn't a motion." Agree with the distinction and return to what the model was used for. **Follow-up 2:** "So you'd be learning the required part on the job." Concede the specific point (B2B partner-motion mechanics) and hold on the analysis and the cross-org target setting. Don't fold into "maybe I'm not right for this" | The F4 and F7 gaps meet here, and a sales-strategy director will see them. Some version of this question will come up. JD because it scores the required partner-motion line and how honestly you assess yourself against it |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Pick a real weak spot, not a humble-brag. F7's stated gap is already covered by D1, so a second honest candidate is B2B context (F8). Answer slot: if you've worked with business or enterprise buyers, say where and what you did. If not, say so plainly, then give the ramp plan. Ending on a plan beats ending on a confession | The standard Skeptic stem. It catches whatever D1 didn't. `[generic]` because F8 is a role-family requirement and the guidance makes no claim about your past |
| D3 | "Why leave consumer tech for data infrastructure, and why emerging products rather than the core business?" | CO | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The past at the quote's scope: consulting, then nine years in product strategy and ops at a large consumer-tech company. Answer slot: your reasons for the move, in your own words. The pack won't supply a motivation. For "why here", tie it to what's on the record: two new product lines, the Compass launch, and the push to profitability, named as Northwind's priorities rather than as things you know from inside | Motivation consistency is the Skeptic's standard probe, and the move from consumer to B2B is your visible jump. CO because a strong answer depends on knowing the company's priorities |

### E — Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal sales-ops person who already knows our motion?" | JD | [grounded] "skilled in SQL/Tableau" "built a partner-level revenue model used in carrier negotiations" "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Pause, then concede the obvious: an internal person knows the motion better. Hold on three quotes, one sentence each: SQL and Tableau, the partner-level revenue model used in carrier negotiations, and consulting followed by product strategy and ops. Close with one line on learning the motion fast, framed as a plan. If he interrupts, finish the sentence you're on, then answer | A time-boxed comparison with an insider, where F7 is the soft spot. JD because it scores fit against the listed job |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the quote exactly: "I proposed the change, and it was credited with roughly $400M in ARR uplift." Answer slot: which part was yours, in your own words. Don't puff it up and don't shrink it to "the team did it". Through two follow-ups, keep returning to "proposed" and "credited". Concede only what you actually don't know about the measurement | The persona's stem pointed at your headline figure. EXP because what's scored is attribution under pressure |

### G — Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc: consulting, then product strategy and ops. Two highlights at their own scope: the revenue model used in carrier negotiations, and the store-surface change you proposed, credited with roughly $400M ARR uplift. Then "why now", which is an answer slot in your own words. Stop at 90 seconds and let him pick a thread | A near-certain opener, and it is scored. Every number you mention here becomes A-bank material, so mention only what you'll defend |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say what you use daily and what for. The tools and uses are an answer slot, in your own words. Stay at the scope of a user, not a builder. Then one forward-looking line: as a daily user, what would make a copilot like Compass worth paying for | Casual on the surface, but it scores the JD's AI plus (F6) and links to Compass. JD because the requirement is what's being tested |

### H — Values (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you changed your mind because of the data." | VAL | [generic] | Selection scaffold: pick a time when you held a view, the data said otherwise, and you changed course. It needs a named decision, the evidence that moved you, and what you did differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | The theme mirrors Dan's "relentlessly data-driven". VAL because it scores behaviour, not skill |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, the truth you delivered, and the outcome, with "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it. Don't invent an ending where the truth landed if it didn't | The persona's standard stem. A GTM lead for new products will have to tell leadership no. VAL because it scores behaviour |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Coming from pricing and monetization, how do pricing decisions for the new product lines get made, and where would you want GTM strategy to plug in?" | It's tied to his career spine and turns him into a collaborator on the seam |
| R2 | "You've worked at an early-stage startup. What from that chapter do you think a new product line inside a company Northwind's size most needs?" | Tied to his path. It invites his perspective rather than probing his history |
| R3 | "What could I do in my first month that would genuinely help your team?" | The reciprocity question for a peer. It signals you mean to lighten his load |
| R4 | "Are the two new product lines tied to Compass, or separate from it?" | It clears up something your preparation can't establish, and shows you've read the priorities |
| R5 | "How is the team thinking about the bundling threat: compete, partner, or focus on segments?" | Uses the research note's competitive frame and invites his strategic view |
| R6 | "Today, who owns targets for new products, sales strategy or GTM?" | It names the seam directly and gives you the real answer to B1 |
| R7 | "With profitability as a stated priority, how will success for the new lines be measured in year one?" | Speaks the data-driven language he uses about himself, and tells you how you'd be judged |

---

## Prohibited claims

This pack will not coach these claims. Each one is something a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led GTM strategy | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's own observation: your material shows product strategy and ops, not GTM ownership. Answer slots stay inside the product strategy work |
| Designed a partner motion or ran a partner programme | Inflated form of F4 | F4's quote at its own scope: "I built a partner-level revenue model, and it was used in carrier negotiations." The material shows a model, not programme design |
| Negotiated the carrier deals | Inflated form of F4 | The quote says the model was used in the negotiations. The A3 slot asks only what part of them, if any, was yours |
| Drove or delivered $400M in ARR (dropping "proposed", "credited" or "~") | Inflated form of the figure in F2's evidence | The quote exactly: proposed, credited with roughly $400M ARR uplift. The A1 and E2 slots cover counting and attribution |
| Has set quotas or run sales ops | Negative stated in the coach's notes, F7 | "I haven't done classic sales-ops or quota-setting work." No slot |
| The volume targets were quotas | Contradicted by F7's quote | F5's quote as written: annual volume targets, set with cross-org consensus |
| Has AI product or AI building experience | Inflated form of F6 | "I use AI tools daily." The G2 and F6 slots ask what for |

---

## Sources

**Provided documents:** the coach's message, which contains:
- the JD highlights
- the candidate background summary
- Dan Kovac's role and profile summary
- the research note on Northwind's three priorities and its main competitive threat

The research note's age is unknown, and strategy goes stale quickly. CO rows rest on it unverified.

**Searches sent:**
- "Northwind Data company values": refused (search permission not granted)
- "Dan Kovac Northwind Data Director of Sales Strategy": refused (search permission not granted)
- "Northwind Data Compass AI copilot launch": refused (search permission not granted). This was a check of the coach's research note.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have themed H-bank questions on Northwind's published values. A values cheat sheet would not render either way, because this loop has no values round |
| 2. `Northwind Data interview process GTM strategy` | skipped | The coach's notes set the loop: one 60-minute peer conversation with Dan. Persona weights rest on that |
| 3. `Northwind Data strategy` / recent news | unavailable | The search was refused. It was a check of the coach's research note and would have confirmed or updated the Compass, expansion, profitability and bundling facts behind C1–C3, D3, R4, R5 and R7 |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have verified his role and career pattern and might have surfaced talks or posts to theme questions |
| 5. Representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied in the coach's notes fix the fit snapshot and the JD-typed questions |

---

## Upgrade menu

- **Full JD text:** catches mid-list requirements the highlights may have dropped, and may add JD-typed questions to the coverage table
- **Priya's CV:** makes the F-row quotes her own sentences rather than a summary, and may turn F8 from a scaffold into a mapped story
- **An inspectable artifact behind the headline claims:** for a strategy role, something like a performance review or internal recognition naming the ~$400M credit, or a redacted structure of the revenue model. Either could raise F2's and F4's evidence above `medium` and harden A1, A3 and E2
- **Priya's answers to the answer slots in F1, F2, F4, F6 and F8:** each answer becomes quoted evidence, and those rows plus A1–A3, D1, D2 and G2 regenerate from it
- **Recruiter guidance (focus areas, a pre-declared deliverable, process details):** focus areas reweight the banks, and a deliverable gets its own build section
- **Prep time available:** adds a prioritised prep-triage schedule
- **Search permission for this session:** runs targets 1, 3 and 4, giving values-themed questions, a check that the research note is current, and verification of Dan's profile
- **Deep research (L2):** a company strategy brief, Dan's talks and writing, loop reports for this role family, and recent org context. Up to 6 more searches and 2 more fetches, several more minutes, and it needs search permission
- **A tuesday-dossier.md from job-underwriter:** evidence-checked confidence grades and a prohibited-claims list from that evaluation, which would sharpen D1
