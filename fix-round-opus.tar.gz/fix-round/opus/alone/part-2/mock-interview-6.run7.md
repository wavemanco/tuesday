Web search was refused, so I'm building the pack from what you gave me. Writing it now.
I've written one prep pack that covers all three rounds: `Larkfield-Systems_engineering-manager_interview_pack.md`. It treats the short role description you gave as the job posting.

**What's in it:** a shared fit map of the role against your background, then a section for each round. Each section has 8–11 likely questions with answer guidance, plus questions for you to ask back.

**Research didn't run.** Web search permission wasn't granted, so all three searches were refused. That changes two things:
- **No company values.** I couldn't get Larkfield's published values, so there's no values cheat sheet for Monday's VP round.
- **Generic strategy questions.** The company-strategy questions aren't specific to Larkfield, and they're marked as generic in the pack.

**The questions to rehearse first:**
- **Tuesday, hiring manager:** "This role partners with hardware on the roadmap. What's your experience there?" You've already said you haven't owned a hardware-adjacent roadmap, and your would-be boss is the person most likely to press on it. The pack scripts a plain admission, then a learning plan, held through two follow-ups.
- **Thursday, panel:** expect the staff engineers to ask how the 60% on-call drop was counted.
- **Monday, VP:** write out your leadership philosophy beforehand. Your background shows one strong decision (the reliability quarter) but no stated principles yet.

**What the pack won't let you say:** that you've managed managers or run two teams. It also keeps the 60% as a drop that came "after" your reliability quarter, never "because of" it.

If you'd like a mock interview, I can play your would-be boss and ask you the hardware question.
I can also save a `tuesday-dossier.md` recording the gaps this prep found, for later sessions.
If you'd like the pack as a Word document, I can convert it.

Can you paste the full job posting, and your CV if you have it handy? The posting will add requirements and questions, and your CV will turn several open-ended questions into answers built on your own stories.

Once you allow web search, should I retry the company research for Larkfield's values and strategy? I can also do a deeper pass: up to 6 more searches and 2 page reads, which takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Engineering Manager, Larkfield Systems: three-round prep pack

**Candidate:** Yusuf · **Role:** Engineering Manager, two device-management squads, 11 engineers · **Mode:** loop. One shared fit snapshot, then one mini-pack per round.

| Round | When | Who | Relationship | Length |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | Hiring manager and would-be boss | 45 min |
| 2 | The Thursday after | Two staff engineers and a product manager | Panel: technical specialists and a cross-functional partner | 60 min |
| 3 | The following Monday | VP Engineering | Skip-level executive; recruiter called it "values and leadership philosophy" | 30 min |

This pack treats the role summary you gave as the JD. The full posting will have more requirements than these four clauses.

---

## How to use this pack

- **Personas** describe *how* a question is asked. **Types** describe *what* is being scored. Rehearse both.
- **Type key:** **VAL** values and behaviour · **EXP** deep-dive on your own experience · **JD** can you do the job as listed · **CO** company and strategy knowledge · **CASE** a live problem from the role.
- **Provenance:** `[grounded]` traces to what you gave me. `[inferred]` is my derivation, and the derivation is named. `[generic]` is a role-family pattern with no claim about Larkfield.
- **Answer slots** are places where the pack can't supply the content because your material doesn't hold it. Each slot gives two honest branches. Answer with whichever one is true. Neither one is a question you need to answer for me.
- The guidance is scaffolding, not a script. Say it in your own words.
- **Loop advantage:** what you learn on Tuesday and Thursday is material for Monday. Write down anything the Director or the panel tells you about the squads, the hardware partnership or the roadmap.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role summary | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads. The words stay at that scope: "For three years I've been the lead of a team of six." Answer slot: the two-squad line makes a probe on running more than one team likely. If you have run work spanning more than one team, say what it was and what your part was, in your own words. If you haven't, say so plainly and stay with the team of six. If the squads turn out to have leads who would report to you, your own sentence applies (F5's quote): "I haven't managed managers." |
| F2 | "own delivery" — role summary | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote touches delivery, because it covers a quarter's priorities held against roadmap pressure. It doesn't show whether delivery was yours to own. Answer slot: if you owned your team's delivery commitments, say how you set and tracked them, in your own words. If delivery was owned elsewhere, or there was no such practice, say so plainly and return to the reliability quarter you pushed through. Keep "after". The sentence doesn't say "because". |
| F3 | "hiring", from "own delivery, hiring and growth for 11 engineers" — role summary | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running the loop sits next to owning hiring for a team, but the two aren't the same thing. Nothing has been inspected behind it, so expect a probe. Words: "I run our hiring loop for backend roles — about 40 interviews last year." The 40 counts interviews, not hires. Answer slot: the role's hiring line makes a probe on hire and no-hire decisions likely. If those calls were yours, say how you made them. If they weren't, or the loop worked another way, say so plainly and stay with the loop you run. |
| F4 | "growth for 11 engineers" — role summary | none given | none | [grounded] | discovery | Strong evidence here is a specific person's progress and what you did to help it. Answer slot: if you have helped an engineer grow, say who they were in role terms and what you did, in your own words. If no such case comes to mind, say so plainly and describe how you would approach it with eleven people. |
| F5 | "partner with hardware … on roadmap" — role summary | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You've stated this gap yourself, and wording can't close it. Words: "I haven't owned a hardware-adjacent roadmap." Follow it with how you would learn, said as a plan and never as a past. Partnering with a hardware team is a different thing from owning the roadmap, and your material says nothing about partnering either way. If any such work exists, it is new material, so tell me (upgrade menu). |
| F6 | "partner with … product on roadmap" — role summary | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote shows roadmap pressure you pushed against. It doesn't show who applied the pressure or how you worked with product. Answer slot: if a product partner was part of the reliability-quarter decision, say what happened and what part of it was yours. If not, say so plainly and stay with the quarter. |
| F7 | "device-management services", industrial IoT — role summary | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [grounded] | transferability | Words: "I've been in engineering nine years and I'm currently at a payments company." Answer slot: the device-management line makes a probe on what carries over likely. If something in your work is close to it, say what, in your own words. If nothing is, say plainly that the domain is new and describe how you'd ramp up. |
| F8 | "values and leadership philosophy" — recruiter, via your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [grounded] | discovery | The quote is the one leadership decision in your material. It doesn't state a philosophy. Answer slot: if that quarter reflects a principle you hold, name the principle in your own words. If you haven't framed it that way, say so plainly and describe the decision as it happened. |

**Reading the snapshot:** F5 is the only row you have stated as a gap yourself. F1, F3 and F7 carry adjacent work. F2, F4, F6 and F8 are places where your material is silent rather than negative, so they hold answer slots, not admissions.

---

## Persona table: all three rounds

| Persona | How it shows up | Round 1 Director | Round 2 Panel | Round 3 VP | Counter-strategy |
|---|---|---|---|---|---|
| Skeptic | "I don't see X — how would you handle it?" | High. A hiring manager derisks gaps, and F5 and F1 are visible from your summary alone | Low | Low | Rehearse A1 until it bores you. Bridge only from your own quotes and state limits plainly |
| Case / Strategist | Live problems from the role: plan it, diagnose it | High. A hiring manager buys capability with problems from their own roadmap | Low | Mid. Executive rounds tilt strategic | Clarify, then objective, approach, metrics and risks. Think aloud |
| Conversational | Friendly openers that are still scored | Low | Low | Low | A 90-second arc built only from your quoted sentences |
| Data-Driven Prober | "How was that number counted?" | Low | High. Staff engineers are technical specialists, and the 60% is a magnet | Low | Know what you can and can't say about the 60% and say "I don't know" where true |
| Peer Evaluator | Where's the seam, what do you need from me | Low | High. The PM is your roadmap partner, and staff engineers would work beside you | Low | Reciprocity: what you bring their work. Seam principles, not claimed seams |
| Values / Behavioral | "Tell me about a time…" | Low | Mid. The cross-functional member, the PM, often runs this | High. The recruiter named values and leadership philosophy | One decision per principle. "We" for context, "I" for your part |
| Pressure | Interruptions, time-boxes, "how much was you" | Low | Low | Mid. Executive rounds test composure | Pause, restate, hold through two follow-ups, then concede the specific thing |

Weights come from round-type priors. Your schedule establishes the rounds. No interviewer profiles were available, so nothing is tuned to individuals.

---

# Round 1: Tuesday, Director of Engineering (45 min)

**Highest-ROI prep in the whole pack: A1.** You've stated the hardware-adjacent gap yourself, it sits in the role's last clause, and your would-be boss is the person most likely to press on it.

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role partners with hardware on the roadmap. What's your experience there?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Lead with the acknowledgment, unhedged, before you're pushed: "I haven't owned a hardware-adjacent roadmap." Then give a plan, said as a plan: what you'd want to learn first from the hardware leads, and how you'd find out where their timelines constrain your squads. Answer slot: if you have worked alongside a hardware team in any form, say what and what your part was, in your own words. If not, leave it at the acknowledgment and the plan. **Follow-up 1:** "So you'd be learning on the job?" Hold: yes on the hardware side, and restate the plan. **Follow-up 2:** "Why should I believe you'll pick it up?" Concede specifically: "I can't point to having done it. I can tell you how I'd go about it." Don't reach for payments as proof of hardware skill | F5 is the only stated gap, and it maps to a named responsibility, so it arrives in some form. JD because it scores the stated requirement. Deepest rehearsal: two follow-ups, with the concession worded in advance |
| A2 | "You've been a lead of six. This is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Hold the quote's scope: three years leading a team of six. Then make it forward-looking: what changes for your time, where decisions sit, and how you'd stay close to two squads at once. Ask whether the squads have leads. If they would report to you, say it before they do: "I haven't managed managers." Answer slot: if you've coordinated work across more than one team, say what, in your own words. If not, say so and stay with the six | F1 is the scale jump, and the Director will see it on paper. JD content, partly CASE delivery |
| A3 | "Why leave payments for industrial IoT, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Your material holds no sentence about why, so the pack can't write your reason. Write your real answer down once and give the same answer in all three rounds. A sound shape names what draws you to this work, then what you'd bring, without running down where you are now | F7's domain switch is the obvious motivation probe. The Skeptic checks that motivation stays consistent, and in a three-round loop that means across rounds |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Choose a real weakness from your own sentence, not a flattering one. The hardware-adjacent roadmap is the honest pick: "I haven't owned a hardware-adjacent roadmap." Then give the plan from A1, kept short. Don't stack both negatives unless the squads have leads (A2) | A Skeptic stem. F5 makes the honest answer easy to find, and a dodged answer here undoes A1 |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's your first 90 days with two squads. What do you do?" | CASE | [generic] | Clarify first: squad structure, current delivery health, the main hardware dependencies, and open hiring. Then give a shape: listen and map the work in the first weeks, make one early visible decision, and say how you'd know it's working by day 90. Make no claim about your past | Hiring managers buy a plan. Two squads plus a hardware partnership make the sequencing question real. `[generic]` because nothing about Larkfield's current state was established |
| B2 | "A firmware release slips three weeks. Your squad's device-management feature depends on it, and product wants the date held. Walk me through it." | CASE | [generic] | Clarify the dependency: what exactly is blocked, and can part of it ship? Lay out the options (re-scope, re-sequence, move the date), who decides, and how you communicate it to product and to the team. You can say plainly that you'd be reasoning without hardware experience. That is consistent with A1 and costs less than bluffing | Tests "partner with hardware and product on roadmap" live, where F5 and F6 meet. The scenario is a pattern, not a Larkfield fact |
| B3 | "Tell me about a time you pushed back on the roadmap." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F2. The beats are the ones your sentence states: there was roadmap pressure, you pushed a reliability quarter through, and afterwards your team's on-call burden dropped 60%. Keep "after". Answer slot: the role's product-partnership line makes a probe on who was on the other side likely. If a product partner was part of it, say what happened and what part was yours. If not, say so plainly and stay with the quarter | Your strongest decision story, and the Director's first chance to test how you hold priorities. EXP because it tests what was yours |
| B4 | "You'll own hiring for this group. I give you two open roles tomorrow. How do you run it?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Reason forward: what the roles need, the loop, who's on it, and how you decide. Bring in the quote at its own scope: you run your current loop for backend roles, about 40 interviews last year. Answer slot: if the hire and no-hire calls in that loop were yours, say how you made them. If not, say so and describe the loop as it runs | F3 is your strongest adjacent evidence for an owned responsibility. CASE delivery on JD content |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc built from these three sentences only: nine years in engineering, three as lead of a team of six, now at a payments company. You run the hiring loop for backend roles, about 40 interviews last year. Your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. Close on why this role, using your A3 answer | Every round opens with some version of this. It still gets scored |
| C2 | "What would you want from me as your manager?" | VAL | [generic] | Be honest and specific about what helps you do the job, given what you've told them about F5: context on the hardware side, for example. Avoid answers that sound like you're asking to be left alone | The Director is your would-be boss. This tests self-awareness and fit with how they manage |

### Reverse questions: Director

| Question | Why it lands |
|---|---|
| "How are the two squads structured today? Do they have leads, and would they report to me?" | It settles A2 and whether F5's managers clause applies. You need the answer anyway |
| "Where does the hardware partnership work well today, and where does it hurt?" | It shows you've taken F5 seriously, and it feeds B2 and the Thursday panel |
| "What would you want this person to have done by month six?" | Their answer is your Monday material: you can say it back to the VP |
| "Why is this role open?" | It explains what the role is really for. Ask it neutrally |
| "How do you like to work with your managers: what do you want to hear about, and what not?" | A would-be boss question, and it signals you're already thinking about the working relationship |
| "What will the panel and the VP be focusing on?" | It sharpens Rounds 2 and 3 directly |

---

# Round 2: Thursday, two staff engineers and a PM (60 min)

**Highest-ROI prep this round: D1.** The 60% is your only number, and staff engineers will ask how it was counted.

### Data-Driven Prober (staff engineers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The pack doesn't supply a method. Answer four slots in your own words. **How it was counted:** what "on-call burden" measured, over what periods. **What it's sensitive to:** anything else that changed in the same window. **The assumption you'd defend least:** name it before they do. **Which part was yours:** the sentence says you pushed the quarter through, so stay there. If you don't know how the figure was counted, say so plainly: that is an honest branch, not a failure. Keep "after", not "because" | Every headline figure gets probed, and specialists probe it deepest. Defend-the-number EXP |
| D2 | "What went into the reliability quarter, and who decided what went in?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The sentence says you pushed the quarter through. It doesn't say what it contained or who chose the work. Answer slot: if you chose the work, say how. If the team or someone else chose it, say so plainly and say what your part was. Don't fill in the technical contents from memory of what such quarters usually hold | F2's quote has no contents, and staff engineers will ask for them. Premised on the quote's own scope |
| D3 | "A device-management service is paging the team every night, and you've just joined. What do you do in week one?" | CASE | [generic] | Structure it: what's paging and why, who's carrying it, what stops the bleeding this week versus this quarter, and how you'd make the trade-off visible to product. You may mention the reliability quarter in your sentence's own words. Don't present it as a playbook you used | It tests delivery and reliability judgement in this team's domain. `[generic]` because nothing about Larkfield's systems is known |
| D4 | "How do you know your hiring loop is selecting well?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: if you've reviewed or measured outcomes, say how, in your own words. If not, say so plainly and say what you'd look at. The 40 counts interviews: if asked how that figure was counted or what part was yours, answer in your own words or say you don't know | F3 is a premised claim, and specialists who interview themselves will test it. The "about 40" raises the defend-the-number slots |

### Peer Evaluator (PM and staff engineers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | PM: "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Propose seam principles rather than pretending to know the seam: who owns what, how trade-offs get made, how disagreement surfaces early. If you use the reliability quarter, keep to the sentence. Answer slot: if product was on the other side of that decision, say how you worked it through. If not, say so | The PM is your roadmap partner and F6 is silent on product partnership. A peer stem |
| E2 | PM: "Hardware tells us a capability slips a quarter. How do you and I decide what to tell customers?" | CASE | [generic] | Clarify what slips and what still ships, who owns the customer message, and what you'd bring the PM: options, engineering cost, risk. Say plainly that you'd learn the hardware side here (A1) | "Partner with hardware and product" is a three-way seam, and the PM will test whether you'd make their job easier |
| E3 | Staff engineer: "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work you led crossed a team boundary. It needs a clear account of who did what. If no such time comes to mind, say so plainly and say how you would handle credit here | A peer stem. Staff engineers are pricing whether you'd take or give credit |
| E4 | Staff engineer: "What would you need from staff engineers here, and what would you take off our plate?" | JD | [generic] | Answer with reciprocity: what you'd ask of them (technical direction, honest pushback) and what you'd absorb (prioritisation fights, hiring logistics, the roadmap conversation). Make no claim about how your current team works | It tests whether hiring you reduces their load or adds to it |

### Values / Behavioral (most likely from the PM)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you said no to a product request." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The reliability quarter is a candidate story only if a product request was what you turned down. Answer slot: if it was, say what was asked, what you said and what happened, in your own words. If not, pick another time you said no to product, or say plainly that none comes to mind and say how you'd handle it | The theme comes from "partner with product on roadmap", and a PM interviewer will look for it |
| G2 | "Tell me about a time an engineer on your team was struggling." | VAL | [grounded] | Selection scaffold, because your material doesn't carry this (F4). Pick a time it needs a person, what you noticed, what you did, and where they ended up. If no such time comes to mind, say so plainly and say how you would approach it | The theme comes from "growth for 11 engineers". F4 has no evidence, so rehearse before it's asked |
| G3 | "Tell me about a time you disagreed with a senior engineer on a technical call." | VAL | [generic] | Selection scaffold: a named disagreement, how it was resolved, and the relationship afterwards. If no such time comes to mind, say so plainly and say how you would handle it | A Peer Evaluator theme. Staff engineers want to know how a manager handles their technical authority |

### Reverse questions: panel

| Question | Why it lands |
|---|---|
| To the staff engineers: "What could a new manager do in their first month that would genuinely help you?" | A reciprocity question. It signals you're there to reduce their load |
| "Where does on-call pain come from in these services today?" | It connects to your one quoted decision without bragging about it |
| To the PM: "How do roadmap decisions get made today between product, hardware and engineering?" | It is the seam the role sits on, and the answer helps with E1 and E2 |
| "Where do staff engineers sit in technical decisions versus the engineering manager?" | It shows you respect their authority, and it tells you how the role works |
| "What do you want kept about how the squads work today?" | It shows you won't arrive and reorganise everything |

---

# Round 3: Monday, VP Engineering (30 min, "values and leadership philosophy")

**Highest-ROI prep this round: H1.** It's the round's stated topic, and your material holds one decision but no stated philosophy (F8). Draft your two or three principles before Monday.

**Values cheat sheet:** not included. Larkfield's published values couldn't be retrieved because the search was refused, and the pack won't guess them. See the upgrade menu.

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy, in a couple of minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name two or three principles in your own words, and anchor each in a real decision. The reliability quarter is the one decision in your material. Answer slot: if it reflects one of your principles, say which one. If it doesn't, use it only as a description of what you did. Keep it under two minutes. A philosophy with no decision attached sounds rehearsed | The recruiter named this as the round's topic, and F8 has a decision but no stated principle |
| H2 | "Tell me about a time you traded short-term delivery for long-term health." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F2, using the sentence's beats: roadmap pressure, you pushed the reliability quarter through, and afterwards your team's on-call burden dropped 60%. Answer slot: if you know what the roadmap gave up, say it. If you don't, say so. Keep "after" | Your best values story maps directly here. VAL because the VP scores the judgement, not the result |
| H3 | "How do you decide who to hire?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | State what you look for, in your own words, then tie it to the loop you run for backend roles. Answer slot: if the decisions were yours, say how you made them. If not, say so and say what you look for when you interview | Hiring is a named responsibility, and a VP will ask how values show up in it |
| H4 | "What would your team of six say is the hardest thing about working for you?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: if you've had that feedback, say what it was and what you did about it. If you haven't asked, say so plainly and give your own honest guess, labelled as a guess | Self-awareness is a staple of leadership rounds, and it is premised on F1's team of six |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you over someone who's already run two teams?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." | Pause, then hold what your sentences carry: three years leading six, the hiring loop, the reliability quarter. Don't claim two teams. If pushed on managers, concede it plainly: "I haven't managed managers." Finish on what you'd bring, using your A3 answer | A Pressure stem aimed at F1, time-boxed. Executives test composure on the gap |
| J2 | "Couldn't pushing that reliability quarter just as easily have been the wrong call?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold through two follow-ups on what the sentence carries: you pushed it through, and the burden dropped 60% afterwards. Then concede specifically what it doesn't establish: that the quarter alone caused the drop, and what it cost the roadmap, if you don't know. Answer slot: if you know the cost, say it. If not, say so | A hold-then-concede rehearsal on your strongest story. The VP may play devil's advocate on it |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Where's device management heading for us, and what does that mean for this team?" | CO | [generic] | Don't present guesses about Larkfield as facts. Use what the Director and panel told you on Tuesday and Thursday, and say where it came from ("from what I heard from the panel…"). Then reason from it | Strategy fluency separates candidates in executive rounds. It's `[generic]` because the company research was refused |
| K2 | "You're six months in. How would I know you're succeeding?" | CASE | [generic] | Answer with a few outcomes across delivery, the team and hiring, plus the hardware partnership. If the Director told you their six-month view (Round 1's reverse question), echo it and say so | It tests whether you think at the VP's altitude. Your Round 1 answer feeds it |

### Reverse questions: VP

| Question | Why it lands |
|---|---|
| "When you think of your strongest managers here, what do they do that others don't?" | It invites the VP to state their philosophy in their own words, which suits a philosophy round |
| "Where is engineering heading over the next year or two?" | It replaces the CO homework the research couldn't do, and the answer is useful to you |
| "Which value here is harder to live than it sounds?" | It shows you take values seriously enough to expect friction |
| "How do you support managers stepping up in scope?" | It is honest about F1 without dwelling on it |
| "What would make you confident in a year that this was the right hire?" | It closes the loop on K2 and the Director's six-month view |

---

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads | A2, B1, J1 |
| Device-management services, industrial IoT | A3, D3, K1 |
| Own delivery | B2, B3, D3, H2 |
| Hiring | B4, D4, H3 |
| Growth for 11 engineers | G2, H4 |
| 11 engineers, the scale | A2, J1 |
| Partner with hardware on roadmap | A1, A4, B2, E2 |
| Partner with product on roadmap | B3, E1, E2, G1 |
| Values and leadership philosophy | H1, H2, H3, H4 |
| Further requirements in the full posting | none, because the posting wasn't supplied |

---

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated, in F5's evidence | "I haven't managed managers." |
| Has owned a hardware-adjacent roadmap | A negative you stated, F5 | "I haven't owned a hardware-adjacent roadmap." Then a plan, as a plan |
| Has led two teams or a group of eleven | Inflated form of F1 | F1's quote at its own scope: a team of six for three years. Slots stay inside that |
| Owned hiring decisions, or hired about 40 people | Inflated form of F3 | F3's quote at its own scope. The material says you run the loop, and the 40 counts interviews |
| Personally cut on-call burden 60%, or the quarter caused the drop | Inflated form of F2 | F2's quote as written: the burden dropped 60% after you pushed the quarter through. "After" never becomes "because" |
| Owned the team's delivery or roadmap | Inflated form of F2 and F6 | F2's quote at its own scope. The material says you pushed a quarter through against roadmap pressure, and it doesn't show ownership of either |

---

## Sources

- **Provided:** your message, which contains the role summary, the round schedule, the recruiter's description of Round 3, and your background.
- **Search 1:** `Larkfield Systems values industrial IoT`. Refused: web search permission wasn't granted.
- **Search 2:** `Larkfield Systems engineering manager interview process`. Refused.
- **Search 3:** `Larkfield Systems news device management 2026`. Refused.
- No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | All calls refused. It would have produced the values cheat sheet for Round 3 and value-mapped VAL questions |
| 2. `Larkfield Systems interview process`, engineering management | unavailable | All calls refused. Your schedule already establishes the three rounds. The search would only have added any documented formats within them |
| 3. `Larkfield Systems strategy`, recent news | unavailable | All calls refused. It would have grounded K1 and the CASE scenarios in Larkfield's current priorities instead of `[generic]` |
| 4. Interviewer names at Larkfield | n/a | No names were given, so no query could be formed. The interviewer read is absent |
| 5. Representative engineering manager JD | skipped | The role summary you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Web search permission** → retry targets 1–3: Larkfield's published values by name, giving a Round 3 cheat sheet with each value mapped to F-rows, plus strategy-grounded versions of K1, B2 and E2
- **A deeper research pass, L2** → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, interviewer talks and writing, role-family loop reports, and recent org changes
- **The full job posting** → the mid-list requirements the summary leaves out get fit rows and JD questions, and the coverage table's last row closes
- **Your CV** → more quotable sentences, so the scaffolds in G2, G3, E3 and H4 can become story-mapped answers
- **Interviewer names** (Director, staff engineers, PM, VP) → an interviewer read, per-member persona weights on the panel, and reverse questions tied to each person's path
- **Your answers to the slots in F2, F4, F5, F6 and F8**, especially any work alongside a hardware team → those rows get quotes, and A1, B3, E1, G1, G2 and H1 regenerate with real beats
- **The recruiter's notes on the panel** → any declared focus areas or deliverables get their own build section. This is usually one email
- **Your available prep hours** → a prioritised schedule across the three rounds
- **A tuesday-dossier.md from job-underwriter** → evidence-graded rows, a strategy constraint per weak area, and an evidence-derived top objection. Optional; this pack is complete without it
