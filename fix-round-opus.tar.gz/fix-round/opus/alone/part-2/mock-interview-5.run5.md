Web search was refused in this session, so I'm building the pack from your message and the recruiter's email alone. Writing it now.
I've written your prep pack, built from your message and the recruiter's email only. There's no job description and I haven't seen the market report. My web searches were refused in this session, so nothing in the pack about Kelverton, Deepa or Ross comes from outside research.

**The 15-minute POV.** Section 5 has a minute-by-minute plan for it:
- **Open by saying how you read "operator partnerships".** It could mean partnering *with* operators, or partners who serve operators. Name which one you mean in your first sentence. The market report should tell you which reading the company uses.
- **Pick a thesis.** There are three options, each with the weakness you'd have to admit. One of them, "fewer, deeper partnerships", runs against your own 6-to-40 growth story. Saying that out loud shows judgment.
- **Commercials.** There's a beat for this, timed for when Ross is likely to jump in.
- **The close.** It's in plain terms for operators, as the recruiter asked. Check those points against the report first; they're my guesses, not findings.

**Most valuable thing to rehearse: C1.** Expect Ross to say something like "You've never carried a quota, so why trust you with a number?" The pack scripts two follow-ups and exactly where to give ground. It also suggests saying the quota limit yourself during the POV's commercials part, before Ross raises it.

**A trap to fix before Tuesday.** 4 years at the payments company plus 5 in consulting makes 9. So "9 years in partnerships" can sound like the consulting years are counted as partnership work. Decide how you'll explain the split (E1).

**Your prep time.** The four hours are split into seven blocks. The POV gets the most, at 75 minutes. Everything not in those blocks is insurance.

Files are in your working directory:
- kelverton-rail_senior-partnerships-manager_interview_pack.md

If you want to practise C1 live, I'll play Ross.
I can also save a `tuesday-dossier.md` noting the gaps this prep exposed, so you can use it in later sessions.
If you'd like the pack as a Word document, I can convert it.

Do you have the job description, or a CV, to paste? Either would replace the guessed requirements (F1, F5, F6) and add a question for each listed requirement.

If you turn on web search, should I run the research I couldn't do? That's Kelverton's values, recent news, Deepa's and Ross's public profiles and a comparable job ad. On top of that, I can do a deeper pass: up to 6 more searches and 2 page reads, adding several minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, a 60-minute panel on Tuesday
**Panel:** Deepa, VP Partnerships (your future manager), and Ross, Commercial Director
**Format, in the recruiter's words:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."

---

## 2. How to use this pack

- **Personas** describe *how* a question arrives: who asks it and in what register. **Types** describe *what is being scored*.
- Type key:
  - **VAL**: values and behaviour. Does what you did in the past show how you work?
  - **EXP**: work-experience deep-dive. Do your claims hold up, and what was actually yours?
  - **JD**: role-driven. Can you do this job, gaps included?
  - **CO**: company and market knowledge. Can you think at Kelverton's level?
  - **CASE**: a live problem from the role, reasoned out loud.
- Provenance labels: `[grounded]` traces to your message or the recruiter's email. `[inferred]` is this pack's derivation, and the derivation is named. `[generic]` is a role-family pattern that makes no claim about Kelverton.
- An **answer slot** is an instruction for the interview, not a question for you to answer here. It has two honest branches. Use whichever one is true.
- Guidance is scaffolding, not a script. Say it in your own words.
- No job description was supplied, so the requirements come from the recruiter's own words plus a few role-family patterns, each one labelled.

## 3. Prep triage: your four hours

| Order | Block | Time | What, tied to this pack |
|---|---|---|---|
| 1 | Build the POV | 75 min | Section 5. Pick the reading of "operator partnerships" the market report uses, choose your skeleton, and write five beats on one card. Say it aloud twice, timed to 12–13 minutes. |
| 2 | The highest-ROI objection | 40 min | C1, then B1 and C3. Settle out loud what you can and cannot say about how the £4M was counted. |
| 3 | Ross's commercials bank | 30 min | B2, B3, B4, C2, and the commercials beat of the POV |
| 4 | Deepa's Skeptic bank | 30 min | D1–D4, plus E1, including how the 9 years splits |
| 5 | Reverse questions | 15 min | Section 11. Pick three: at least one for Deepa and one for Ross |
| 6 | One live drill | 30 min | Have someone interrupt you during the POV, or run C1 with me |
| 7 | Sunday-night run | 20 min | The POV once more, start to finish, with no card |

Everything else in this pack is insurance.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Senior-level partnerships experience. This is a role-family pattern for the title; no JD was supplied | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | The quote reaches seniority directly. One hazard: 4 years plus the 5 consulting years makes 9, so a listener may ask whether the 9 years includes the consulting. Answer slot: if the consulting years involved partnership work, say what it was, in your own words. If the 9 is the 4 plus the 5, say so plainly. Never present it as 9 years of partnerships on top of the consulting |
| F2 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | An ISV channel at a payments company is next door to operator partnerships in rail, not the same thing. Your words stay at their own scope: "At a payments company I ran the ISV channel and took it from 6 partners to 40." Answer slot: the 18-month framing makes a probe on how that growth was planned likely. If you set the plan, say how you decided where to grow, in your own words. If there was no plan of that kind, or it wasn't yours to set, say so plainly and stay with the channel you ran |
| F3 | "what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Bus and light rail network planning in consulting is not the train operating companies Kelverton sells to. Keep your own phrase, "from the other side", and don't widen it to heavy rail. Answer slot: the recruiter's "operators themselves" line makes a probe on what you actually saw of operators likely. Say who your clients were and where the work put you alongside operators, in your own words. If it rarely did, say so plainly and stay with the planning work itself |
| F4 | "Ross will push on commercials" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | low | [inferred] | discovery | Influenced revenue touches commercials. Your material doesn't show whether partner commercial terms were yours to set. Answer slot: if you set or negotiated partner terms (fees, margins, revenue share), say which model and why, in your own words. If terms were set by others, or there were no formal terms, say so plainly and present the models in section 5 as options you would test |
| F5 | Accountability for a revenue number. This is a role-family pattern for senior partnerships roles; whether this role carries a direct number is not established | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | You've stated this gap yourself, and no wording closes it. Words: "I haven't carried a direct quota. My number was influenced revenue." Then how you'd take one on, said as a plan and never as a past. Nothing added to make it feel smaller |
| F6 | Selling into rail operators. This is a role-family pattern for a commercial role at a rail-software vendor | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | Also stated by you. Words: "I haven't sold into rail." Then F3's quote at its own scope, then a ramp plan. Note that your stated negative is about *selling* into rail. It says nothing about knowing rail, so don't give away more than you said |

## 5. Graded deliverable: the 15-minute POV

**The brief, quoted:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves." `[grounded]`

**Facts about you the POV may lean on, exactly as you said them:**
- F2: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
- F3: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- F5: "Never sold into rail specifically and never carried a direct quota, only influenced revenue."
- The report: "She also attached the market report their strategy team circulated internally last quarter, which I've read."

**First, settle the fork.** "Operator partnerships" can be read two ways, and the report you read is the tiebreaker. Open by naming the reading you're using in one sentence ("I'm reading operator partnerships as X. Correct me if you mean it differently"). That opener frames the talk and invites Deepa in.

| Reading | What it means | Provenance |
|---|---|---|
| A | Partnerships *with* operators: joint roadmaps, co-development, operators as design partners | [inferred] from the recruiter's wording, which supports both readings |
| B | Partnerships with third parties (integration partners, consultancies, resellers) that deliver value *to* operators | [inferred] from the recruiter's wording, which supports both readings |

**One check to make in the report before you build.** Look for what it says about how the operator customer base itself will change over the next 18 months: who owns operators, how they buy, and who signs contracts. Whatever the report says on that is the strongest single fact your POV can stand on. This pack could not verify the current picture, because search was refused, so it asserts nothing about it.

**Shape of the 15 minutes:**

| Minutes | Beat |
|---|---|
| 0–1 | The reading you're using, and the one-line thesis |
| 1–4 | Where things stand: one point from the report you agree with, cited as the report's |
| 4–10 | The thesis and three moves across 18 months |
| 10–12 | Commercials. This is where Ross will come in, so name the limit (below) before he does |
| 12–14 | What it means for operators: the close the recruiter asked for |
| 14–15 | What you'd want to learn first, then hand over to questions |

**Thesis options.** Pick one skeleton and one argument. The combination T3 + T1, measured by T2, holds together.

| # | Thesis | Provenance | Mandatory concession |
|---|---|---|---|
| T1 | **Fewer, deeper.** Spend 18 months on a small number of partnerships operators feel in their daily work, rather than growing partner count. F2 is a growth-in-count story. Saying plainly that count is the wrong measure here shows judgment rather than habit | [generic] This pattern fits software sold to a small number of large buyers. Whether Kelverton's buyer base looks like that is the report's to say | Depth shows up more slowly in headline numbers, and Ross may hear "fewer" as "less revenue". Be ready to say what you'd measure instead of count |
| T2 | **Every partnership earns its place through an operator-facing outcome**, named per partnership and reviewed on a fixed cycle | [generic] | Outcomes are harder to attribute than revenue. Say you'd need a proxy, and that the proxy would be imperfect |
| T3 | **Sequenced: 0–6 months learn and choose, 6–12 prove one or two joint operator outcomes, 12–18 make it repeatable** with tiers and standard commercial terms | [generic] | Six months of learning sounds slow to a Commercial Director. Name one commercial move you'd make inside the first 90 days |

**Differentiate from the report, don't recite it.** The panel's own strategy team circulated it, so everyone in the room knows it. Bring one point from it you agree with, to show you've done the reading. Then bring one place you'd put a different bet, with your reason. Frame that as a bet, not a correction: "the report emphasises X; I'd weight Y more heavily because…"

**The anti-pick, the thing you'd say no to:**

| Would decline | Why | Provenance |
|---|---|---|
| Partner-count targets as the headline measure | Count rewards signing partners, not operator value | [generic] |
| A broad reseller channel in a market with few large buyers | Resellers add a layer between you and a customer you can reach directly. This only applies if the report shows few large buyers | [generic] |
| Partnerships with no named operator-facing outcome | They take up partner-team time and give operators nothing they'd notice | [generic] |

**Commercials beat (minutes 10–12).** These are the options to lay out. They are role-family patterns, not Kelverton's current terms:

| Model | Fits when | Provenance |
|---|---|---|
| Referral fee | The partner introduces the deal, and Kelverton sells and delivers | [generic] |
| Resale margin | The partner owns the contract with the operator | [generic] |
| Revenue share on a joint offering | Both products are needed for the operator outcome | [generic] |
| Co-sell with no fee | Both sides win the deal separately, and integration is the value | [generic] |

Answer slot: Ross will push on commercials, so if you set partner terms at the payments company, say which model you used and why, in your own words. If terms were set by others, or there were none, say so plainly and present these as options you'd test with him.

Name the limit in this beat, before Ross asks for it. Use F5's words: "I haven't carried a direct quota. My number was influenced revenue. So the commercial model here is something I'd want to build with you." It costs one sentence, and it takes the sting out of C1.

**The close: what it means for operators.** The recruiter asked for it by name. Treat these as hypotheses to check against the report, not findings:

| For an operator, in 18 months | Provenance |
|---|---|
| Fewer hand-offs and less re-keying between the scheduling system and the systems around it | [generic] |
| One accountable party when something breaks, not several suppliers blaming each other | [generic] |
| Changes reaching them faster because partners build on the product rather than around it | [generic] |

Deliver it as three short sentences, starting "For an operator, this means…". Answer slot: the recruiter's "operators themselves" line makes this the beat they'll remember. If your planning work showed you something about operators' working day, say it in your own words and tie one hypothesis to it. If it didn't, keep these as hypotheses and say you'd test them in the first 90 days.

## 7. Reading the interviewers

No public profiles were researched, because search was refused. This section reads only the recruiter's email.

| Interviewer | What we know | Provenance | Implication |
|---|---|---|---|
| Deepa | "VP Partnerships, your future manager" — recruiter's email | [grounded] | She owns the strategy you're presenting a view on, so she's buying judgment and testing gaps (Case + Skeptic). She'll also be listening for what working with you would be like |
| Ross | "Commercial Director … Ross will push on commercials" — recruiter's email | [grounded] | The numbers banks (B, C) are his. Expect him to interrupt the POV around money |

No shared-path opportunities are offered, because no public career paths were read.

## 8. Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Both interviewers, on the POV and in follow-ups | Highest. A panel blends each member's priors: a hiring manager brings Case, and a Commercial Director brings strategy-heavy Case. The POV itself is a case | Clarify, then objective, then approach, then measures, then risks. Think aloud. Challenge one premise respectfully |
| Data-Driven Prober | Ross, on the £4M and the 40 partners | High. "Ross will push on commercials", and F2 holds your only headline figures | Know what you can and can't say about how each figure was counted. Say plainly what you don't know |
| Skeptic | Deepa, on rail and operators | High. The hiring-manager prior, and F5, F6 and F3 are the gaps | Rehearse C1 and D1 until they're boring. Bridge only from what you actually said |
| Pressure | Ross, time-boxed and interrupting | Mid. A commercial lead pushing in Q&A is a recruiter-flagged pattern | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Conversational | Opening minutes, or the transition into Q&A | Low, but still scored | Have a 90-second journey ready (E1) |
| Values / Behavioural | Woven into Q&A | Low. The recruiter's email names no values round | Pick stories with a real stake. Where none exists, say so |
| Peer | Deepa, on how partnerships works alongside sales | Low. No peer is on the panel, but Deepa will be thinking about seams | Propose working principles for the seam rather than pretending to know it |

These weights rest on the recruiter's description of the session. No company-wide loop source was read.

## 9. Question banks

### A. Case / Strategist (Deepa and Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If we gave you half the resource your POV assumes, what goes first?" | CASE | [generic] | Name the cut, why it goes first, and what operators lose because of it. Then name what you'd protect at all costs, and why it's closest to an operator outcome. The question asks nothing about your past, so the guidance claims nothing | The most natural test of whether a POV has priorities. CASE because it's a live trade-off |
| A2 | "It's your first 90 days. What do you need to know before you change anything?" | CASE | [generic] | Structure it: what "operator partnerships" means here, which partners exist today, which of them operators would notice, how deals currently flow between partners and sales, and what Ross needs to see by month three. Close with the one commercial move you'd make in that window (T3's concession) | Deepa's likeliest follow-up to the POV. CASE because it tests clarify-before-structure |
| A3 | "A partner's integration fails for an operator the night before a timetable change, and the partner blames our product. Walk me through the next 24 hours." | CASE | [generic] | Operator first: restore service, or agree a workaround. Then get facts from both sides before anyone assigns blame. Make one person accountable for updating the operator. Afterwards: what you'd change in the partner agreement or in testing so it doesn't recur. Claims nothing about your past | It tests "what it means for operators" when things go wrong. Generic because it's a pattern, not a known Kelverton incident |
| A4 | "Which partners would you say no to over the next 18 months?" | CASE | [generic] | Use the anti-pick table in section 5. Give one category and one reason, said with conviction, then what you'd offer that partner instead (a lighter tier, a later review) | Saying no is part of a senior partnerships job. JD content, CASE delivery |
| A5 | "You've read our market report. What does it get wrong, or leave out?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Selection scaffold: pick one claim from the report you'd weight differently, and one it doesn't cover that matters to operators. Give your reason for each. Frame it as a different bet, not a correction, since the panel's colleagues wrote it. If nothing in it strikes you as wrong, say so plainly and name the question you'd most want it to answer next | The panel knows you have the report. This separates reading it from thinking about it |

### B. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Say the figure exactly as you hold it: roughly £4M of influenced revenue. Answer slots, each in your own words: how it was counted, what it's sensitive to, the assumption behind it you'd defend least (name this before he does), and which part was yours. If you don't know how it was counted, say so plainly; that's an honest answer. Don't annualise it, and don't call it closed or sourced | F2's only money figure, put to the person the recruiter said will push on commercials. EXP because it tests attribution |
| B2 | "Of the 40 partners, how many actually moved revenue?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: if you know the split, give it, and say how you knew. If you don't, say so plainly and stay with the figures you do hold, 40 partners and roughly £4M influenced. A precise "I don't know" beats a guessed denominator | Count without a denominator is the classic probe on a channel-growth figure in F2 |
| B3 | "When a partner brings us an operator deal, how would you structure the commercials?" | CASE | [generic] | Use the commercials table in section 5: name two models and when each fits, and the one you'd start with and why. Answer slot: if you set partner terms at the payments company, say which model and why, in your own words. If you didn't, say so plainly and present these as options you'd test | F4's discovery gap, raised by the recruiter's "Ross will push on commercials". JD content, CASE delivery |
| B4 | "How would you tell partner-influenced revenue from revenue we'd have won anyway?" | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Structure it: agree the attribution rule with sales up front, separate sourced from influenced, and review a sample of deals. Answer slot: if the £4M was counted under a rule like that, describe the rule in your own words. If it wasn't, or you don't know, say so and say what rule you'd propose here | Ross's natural next question after B1. It turns F2's weakest seam into a design question |

### C. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never carried a direct quota. Why should I trust you with a commercial number?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | **The highest-ROI rehearsal in this pack.** Pause. Then: "I haven't carried a direct quota. My number was influenced revenue: roughly £4M, through an ISV channel I took from 6 partners to 40." Answer slot: if influenced revenue was a target you were measured against, say so, in your own words. If it was tracked but wasn't a target, say so plainly; that's a limit, not a confession. Then the plan: what you'd want agreed with Ross in the first 90 days about how this role's number is set. **Follow-up 1** ("Influence is soft; anyone can claim it"): don't harden the claim. Go back to B1's slot, how it was counted. **Follow-up 2** ("So you'd need a ramp?"): concede specifically. "On owning a closed number, yes, I'd be learning. What I bring from day one is the channel work." Hold the core claim and fold on nothing else | F5 is the biggest stated gap, and the recruiter named the person most likely to press it. JD because it scores revenue accountability |
| C2 | "Sixty seconds: what's the revenue case for your plan?" | CASE | [generic] | Three beats, timed: what drives revenue in your plan, the assumption you'd defend least, and what you'd measure at six months to know. Don't invent a figure. If the report gives one, cite it as the report's | It time-boxes the POV's commercial logic. Pressure delivery, CASE content |
| C3 | "Six partners to forty: how much of that was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | "I ran the ISV channel, and it went from 6 partners to 40." Answer slot: say which part was yours and what others did (team, sales, product), in your own words. If the growth leaned on things outside your control, say which. Use "we" for context and "I" for your share | The persona stem, aimed at F2's headline. EXP because it tests attribution |

### D. Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't sold into rail. How long before you're useful to our operators?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | "I haven't sold into rail." Then, at its own scope: "before partnerships, I spent five years in transport consulting on bus and light rail network planning." Then a ramp plan, said as a plan: who you'd spend your first weeks with (operators, account teams, two or three partners) and what you'd have learned by day 60. Don't claim to know rail beyond those words | F6 is a stated gap and the obvious objection from the hiring manager. JD because it scores domain readiness |
| D2 | "Bus and light rail planning isn't running a train company. What do you actually know about operators like ours?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Hold to the quote: five years, transport consulting, bus and light rail network planning. Agree with the premise where it's right: it isn't train operations. Answer slot: the "operators themselves" brief makes this probe likely. Say who your clients were and what that work showed you of operators, in your own words. If it rarely put you alongside operators, say so plainly and stay with the planning work. Never widen it to heavy rail | F3's limit, pressed by the person who knows the domain best. EXP because it tests "the other side" under cross-examination |
| D3 | "Why leave payments for rail-tech, and why now?" | VAL | [generic] | Selection scaffold: your real reasons, at least one specific to Kelverton, and one about timing. If your consulting years are part of the reason, say how in your own words. If they aren't, don't borrow them as a reason. If you can't yet put the "why now" in a sentence, say what draws you rather than inventing one | The persona stem. Motivation consistency is scored in every second round |
| D4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Answer with what you've already said: "I haven't sold into rail, and I haven't carried a direct quota." Choose one as the answer, name the plan for it, and stop. Don't pad it with a fake weakness | The persona stem. F5 and F6 make this an easy honest answer if it's rehearsed |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc in time order: five years of transport consulting on bus and light rail network planning, then the payments company and the ISV channel, 6 partners to 40, roughly £4M influenced. End on why this role. Answer slot: say how the 9 years splits, since 4 plus 5 makes 9. If the consulting years count as partnership work, say what made them so. If they don't, say the 9 years that way | The F1 arithmetic hazard surfaces here first. EXP because it sets up everything the panel probes later |
| E2 | "What made Kelverton interesting to you?" | CO | [generic] | Selection scaffold: one thing about the company and one about the role, both in your own words. Use something from the report only if it really drew you. If nothing specific stands out yet, say what about the role does | Casual openers are still scored. CO because it tests homework |

### G. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: choose a time with a named metric, a real cost to giving it up, and a customer outcome you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | The persona stem, tied to the operator-first close of your POV |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you didn't back down, and a working relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | The persona stem. A partnerships lead has to say no upward. Low weight, but rehearse it once |

### H. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Say the account teams own the operator relationships. Where's the seam with partnerships, and what happens when you disagree?" | CASE | [generic] | Propose principles rather than pretending to know their seam: one owner for each operator relationship, partners brought in with the account team's agreement, and disagreements settled by asking what the operator gains. Ask how it works today | Deepa will want to know whether you add to her peers' load or lighten it |
| H2 | "How do you handle credit when a partner-influenced deal closes through sales?" | VAL | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: if there was a credit rule at the payments company for the £4M of influenced revenue, describe it and your part in it, in your own words. If there wasn't, or you don't know, say so and propose one: agreed up front, written down, and reviewed when a deal is disputed | Influenced revenue is shared credit by definition. This tests whether you're collegial about it |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 senior partnerships experience | E1, C3, B2 |
| F2 the 18-month direction | Section 5, A1, A2, A4, C2 |
| F3 what it means for operators | Section 5 close, A3, D2, G1 |
| F4 commercials | B1, B3, B4, C1, C2, H2 |
| F5 revenue accountability | C1, D4 |
| F6 selling into rail | D1, D4, A5 |

## 11. Reverse questions

| # | For | Question | Why it lands |
|---|---|---|---|
| R1 | Deepa | "When you say operator partnerships, which partners do operators notice most today?" | It resolves the fork your POV opened on, and it invites her to correct your reading |
| R2 | Ross | "How will this role be measured commercially in year one: influenced, sourced, or a direct number?" | It answers the F5 question you genuinely need answered, and asking it reads as confidence rather than a weak spot |
| R3 | Deepa | "Six months in, what would tell you this hire was the right call?" | It gets you her real success criteria, and it shows you think in outcomes |
| R4 | Ross | "Where do partner deals get stuck commercially today?" | It continues his line of questioning, and his answer will tell you where the role's real friction is |
| R5 | Either | "What did the team disagree about when the market report circulated?" | It shows you read the report as a live debate, not a finished document |
| R6 | Deepa | "How do operators tell you today when a partner integration lets them down?" | It ties back to your close and shows you'll keep operators at the centre of the work |

## 13. Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota, or closed or owned £4M | A negative you stated (F5), plus "influenced" is your word | "I haven't carried a direct quota. My number was influenced revenue." Then the £4M as you hold it: "roughly £4M of influenced revenue" |
| Has sold into rail | A negative you stated (F6) | "I haven't sold into rail." |
| Knows train operating companies or heavy rail operations from the inside | Inflated form of F3 | F3's quote at its own scope. The pack's observation, not words for you: your material says bus and light rail network planning in consulting, not train operators. D2's slot stays within that work |
| Knows what operators need from scheduling software | Inflated form of F3: the quote's "the operator world" widened to a product need | F3's quote at its own scope. The close in section 5 stays as hypotheses unless the slot's first branch is true |
| Built the ISV channel from scratch | Your quote contradicts it: it started at 6 partners (F2) | "took it from 6 partners to 40" |
| Personally signed the partners who took it from 6 to 40 | Inflated form of F2 | F2's quote at its own scope. C3's slot asks which part was yours |
| 14 years of experience, or 9 years of partnerships on top of the consulting | Inflated form of F1: the 9 and the 5 may overlap | F1's quote as you said it. E1's slot says how the 9 years splits |
| £4M per year | Inflated form of F2: "roughly £4M" doesn't say per year | "roughly £4M of influenced revenue", unannualised |

## 14. Sources

**Provided documents:**
- Your message, including the recruiter's email as you quoted it
- The internal market report: you've read it, but it wasn't shared here, so nothing in this pack draws on its content
- No dossier was present

**Searches sent:**
- "Kelverton Rail values": refused
- "Kelverton Rail scheduling software train operating companies": refused
- "Senior Partnerships Manager rail software job description UK": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have given value names to theme the G bank. No values section was due either way, because no values round is named |
| 2. `Kelverton Rail interview process` partnerships | skipped | The recruiter's email already fixes the session: one 60-minute panel, a POV, then Q&A, with named interviewers. Persona weights follow from it |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The search was refused. It would have moved A5, E2 and the POV's starting facts. The market report would answer this target if pasted |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Not sent, because search was refused in this session. It would have moved section 7, the persona weights and a reverse question tied to each person's path |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The search was refused. It would have turned the `[generic]` rows F1, F5 and F6 into `[inferred]` rows and added JD-tagged questions |

## 15. Upgrade menu

- **The job description** turns F1, F5 and F6 into `[grounded]` rows, adds a JD-tagged question for every listed requirement, and settles whether this role carries a direct number (C1, R2)
- **The market report's key points, pasted** (operator landscape, partner types, any figures) make the POV's theses, close and anti-pick `[grounded]`, and sharpen A5 and C2
- **Allowing web search** runs targets 1, 3, 4 and 5 above. It brings public profiles for Deepa and Ross, Kelverton's published values and recent news. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent organisation context
- **Your CV** adds evidence beyond the three sentences in your message. Rows F2, F3 and F4 and the G bank would get story-mapped guidance instead of scaffolds
- **Your answers to the slots in B1, C1 and E1** (how the £4M was counted, whether it was a target, how the 9 years splits) would firm up F1, F2, F4 and F5 and the C bank
- **A tuesday-dossier.md from an underwriting pass** would supply verified evidence and a prohibited-claims list built from it. The pack is complete without one
