Working directory is empty, so no dossier or CV. Reading the references the workflow requires.
Web search was declined, so I'll build the pack from your message alone and record those four calls as refused instead of filling the gaps from memory.
I've saved your prep pack as `stripe_product-operations-manager_interview_pack.md`. It has 20 practice questions across seven interviewer styles, but it's mostly generic for now. Web search was declined, so I couldn't look up Stripe's published values, how its final round is structured, its current strategy, or a real job posting. I didn't fill those in from memory. I also have no CV, so the questions about your past help you pick a story to tell rather than suggest one. Since I don't know who you're meeting, I gave every interviewer style equal weight.

The question to rehearse first is A1: "Which part of this role would you be weakest at on day one?"

If you'd like to practise out loud, I can play the skeptical interviewer on A1 and push back on your answers.
I can also save a `tuesday-dossier.md` file recording the gaps this prep exposed, so you can use it in later sessions.
I can convert the pack to a Word document too.

1. Who are you meeting in the final round: your future manager, peers, a cross-functional partner, or several of them? And did the recruiter name any focus areas or something to prepare, like a case or a presentation? That would change the focus of every set of questions and could add a section for the prepared piece.
2. Could you paste the job description and your CV, or a few lines about your background? I can keep going without them, but with them I can match questions to your own experience and to Stripe's actual requirements.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer(s): not known. Relationship: not known. Built from your message alone: no job description, no CV, and no web research (all four searches were refused, see Sources).

## How to use this pack

**Personas** describe how a question is asked: the register, the pressure, the follow-ups. **Types** describe what's being scored. Rehearse both. The same content asked by a Skeptic and by a Rapport Builder needs a different delivery.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's published values, not generic virtue |
| EXP | Whether your claims about past work hold up under scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge, and whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

The guidance is scaffolding, not a script. Since I have nothing about your background yet, every answer about your past is a **selection scaffold**. It tells you which of your own stories to pick and what the story needs to contain. It never supplies the story. Answer in your own words, from things that actually happened.

## Fit snapshot

This is the worksheet version. With no JD in hand, the requirements are role-family patterns for product operations, written as plain prose and labelled `[generic]`. They are not quotes from Stripe's posting. With no CV, every evidence cell is empty. Fill in the right-hand column yourself before the interview: your answer for each row is the story you'll bring.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running cross-functional launches and operational readiness (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a launch where you coordinated several teams, with a readiness checklist or a go/no-go call, and something concrete that changed because of your work. Pick the launch where your own part is easiest to name. If no launch comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F2 | Building feedback loops between customer-facing teams and product (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a way customer signal reached product decisions that you set up or ran, plus one decision it changed. Pick the one where you can name the decision. If no such loop comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F3 | Defining and tracking operational metrics, and working comfortably with data (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a metric you reported, where you can say how it was counted, what its denominator was, and which assumption behind it was weakest. Pick a number you can defend for two follow-ups. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F4 | Designing processes and scaling them as volume grows (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a process you designed or changed, the volume or pain that forced it, and what broke or held. Pick the one where the before-and-after is clearest. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F5 | Influencing stakeholders without formal authority (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a time you moved a team you didn't manage, with the disagreement, what you did and how the relationship ended up. Pick one where the outcome was real, not where everyone simply agreed. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F6 | Prioritising and triaging competing requests (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a time demand exceeded capacity and you decided what waited, with the criteria you used and how you told the people who lost out. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| F1 Launches and readiness | B1 |
| F2 Feedback loops | B3, D2 |
| F3 Metrics and data | B2, C1, C2, C3 |
| F4 Process design and scaling | B5, G2 |
| F5 Influence without authority | D1, D3, H1, H2 |
| F6 Prioritisation | B4 |
| Motivation and fit (asked in every final round in some form) | A1, A2, E1, G1, H3 |

Not covered: company and strategy knowledge (CO). Without research, any CO question would rest on my memory of Stripe, and this pack doesn't use memory for company facts. Granting search adds it (see Upgrade menu).

## Persona table

**How the weights were set:** I don't know who you're meeting, and no source in hand describes how this final round is structured. So the weights fall back to the *Generic* archetype: flat weights. That's a pattern, not Stripe's documented process. If the final is several back-to-back sessions, each one may favour a different persona, which is why every persona gets a bank. The banks below are ordered for rehearsal, not by weight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of gaps and motivation | Even. Relationship unknown, flat fallback. Any final round tends to test motivation somewhere | Rehearse A1 until it's boring. Build bridges only from things you actually did, plus a concrete ramp plan |
| Case / Strategist | Live product-ops problems: plan this, diagnose that | Even, same reasoning | Clarify, objective, segment, approach, metrics, risks. Think aloud and challenge one premise per case |
| Data-Driven Prober | Asks how your numbers were counted, two levels deep | Even, same reasoning | Know how each number you cite was counted, or say plainly that you don't. Name the weakest assumption first |
| Values / Behavioural | STAR-shaped stories, possibly mapped to Stripe's published values (not in hand here) | Even, same reasoning | Have stories for the D-bank themes. "We" for context, "I" for your contribution |
| Pressure | Time-boxes, interrupts, questions what was really you | Even, same reasoning | Pause, restate, hold through two follow-ups, then concede something specific |
| Peer Evaluator | The seam between teams, credit, what you'd need from them | Even, same reasoning | Offer what you'd bring their team. Propose seam principles instead of pretending to know the seam |
| Conversational | Friendly openers that are still scored | Even, same reasoning | A pre-built 90-second journey. Treat casual questions as scored |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **The highest-ROI rehearsal in this pack.** Name one real gap in a single sentence, in your own words. It should be a real gap, not a strength in disguise. Then say what you've already done about it, only if you've done something. Then give a 30/60-day ramp, said as a plan, not a past. Follow-up 1, "what else": have a second, smaller gap ready. Follow-up 2, "isn't that core to the job": hold by pointing to the ramp and anything you've actually done near it, then concede exactly what you'd need from the team. Don't stretch a nearby experience to cover the gap. If you can't honestly pick one, say which area you'd most want to check against the team's expectations first, and why | Without a JD or CV, the pack can't find your biggest gap, so this question makes you find it before the interviewer does. Some version of it comes up in most final rounds. JD because it scores the role's requirements against you |
| A2 | "Which part of your background is furthest from this role, and how would you handle that part here?" | JD | [generic] | Pick the real distance, in your words. Then say what carries over, using only things you actually did, and finally how you'd close the rest. Name the limit before they do. If nothing in your background feels far from the role, say so plainly, then give the area you'd ramp on first and why | The Skeptic's background-mismatch probe in open form. It rehearses calibrated candour over bluffing. JD because it scores fit to the role |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A new feature launches to business customers in six weeks. Sketch the operational readiness plan. What do you need to know first?" | CASE | [generic] | Clarify first: who it's for, the risk if it goes wrong, and whether six weeks is fixed. Objective: customers can use it, and frontline teams can support it on day one. Workstreams: support training and macros, docs, escalation paths, internal tooling, comms, and a rollback or staged-rollout plan. Give each workstream an owner, a checklist and a go/no-go meeting. Readiness metrics, then risks. Challenge one premise, for example whether a staged rollout beats a single launch date | F1's requirement asked as a live problem. CASE because it scores structure, not your history |
| B2 | "Support contacts about one product area rose 20% last month. Diagnose it." | CASE | [generic] | Clarify the definition first: contacts or tickets, and per what denominator (users, transactions). Then check whether counting changed (new tags, a new channel, a tracking change) before treating the rise as real. Segment by customer type, channel, issue tag and date, and line it up against launches and incidents. Form two or three hypotheses, then the cheapest test for each. Close with what you'd tell product, and when | F3's metrics requirement as a diagnosis. The denominator-first move is what a Prober listens for. CASE delivery, JD content |
| B3 | "Product says it never hears what customers struggle with. Support says it reports everything. Design the feedback loop." | CASE | [generic] | Clarify what "never hears" means: no volume, or no signal they can act on. Objective: product decisions, not more reports. Build it from a shared taxonomy at intake, aggregation that weighs severity against frequency, a regular forum with a named decision owner, and closing the loop back to the frontline. Metric: decisions changed, or time from signal to response. Risks: the loudest customer wins, and taxonomy drift | F2's requirement. It tests whether you design for decisions rather than for throughput. CASE |
| B4 | "Five teams send you requests and you can only take two this quarter. How do you decide?" | CASE | [generic] | Clarify the goals the quarter is judged on. Set criteria first: impact on those goals, effort, risk and reversibility. Make the trade-off visible so the decision isn't made in private. Say no with reasons and a date to revisit. Mention the one request you'd escalate, not decide alone | F6's requirement live. It scores judgment and how you treat the teams that lose out. CASE |
| B5 | "A manual review process works today, but volume is about to triple. What do you change first?" | CASE | [generic] | Find the bottleneck before redesigning anything. Separate the steps that need judgment from the steps that follow rules. Automate or move to self-serve the rule-based ones. Keep a quality guardrail such as sampling or an error rate. Adjust staffing for what's left, and set the metric that tells you it's working. Risk: automating a step that was quietly catching errors | F4's scaling requirement. CASE |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a metric you reported on. Walk me through how it was counted." | EXP | [generic] | Pick a metric you actually reported and can explain: what it measured, where the data came from, the denominator, and which part of the reporting was yours. Say "we" for the team's part and "I" for yours. If you don't know how part of it was counted, say so plainly instead of reconstructing it. If no such metric comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | The Prober's core stem in open form, for F3. EXP because it tests what you can defend from your own past |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Asked about the metric you picked for C1. In your own words, name the assumption you'd defend least before they press. Then say what would change if it were wrong. If you don't know how the figure was counted, say so plainly. That's a valid answer, and guessing isn't | The weakest-assumption move turns a gotcha into credibility. A Prober almost always asks the second level |
| C3 | "A launch's success metric is the share of customers who used the feature in its first week. What's wrong with it?" | CASE | [generic] | Look at the denominator (eligible or exposed customers, not all customers), novelty spikes, adoption versus value, and how easily the number can be gamed. Propose a pair: an adoption measure plus a later outcome or retention measure, and say which assumption in your own pair is weakest | F3 tested live, without relying on your history. CASE |

### D. Values / Behavioural

Stripe's published values aren't in hand (search was refused), so these use common behavioural themes, not Stripe's own value names. Don't recite value names you haven't checked on Stripe's own site.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, where you said the hard thing clearly and it landed or changed something. Structure: the situation, what you said and how, their reaction, the outcome, the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A common behavioural stem. It touches F5. VAL because it scores behaviour against values |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time when the customer and the metric genuinely pulled in different directions. Say what you chose, what it cost, and how you explained it. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A common behavioural stem. It touches F2's customer-signal requirement. VAL |
| D3 | "Tell me about a time you delivered an unpopular truth to a team you didn't manage." | VAL | [generic] | Pick a time you had no authority over the team and still had to land something unwelcome. Show the spine (you said it) and the tact (how), and say where the relationship ended up. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A variant of D1 aimed at F5's influence-without-authority requirement. Product ops roles live in that position. VAL |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then make two points, each from something you actually did, plus what an outsider brings (fresh comparisons, no inherited assumptions). Hold through two follow-ups. Then concede specifically that an internal candidate knows the systems and people on day one, and say how you'd close that gap fast. Don't fold, and don't run down the hypothetical internal candidate | The Pressure stem. Composure is what's scored. JD because it's about fit to the role |
| E2 | "That result: how much of it was actually you?" | EXP | [generic] | Asked about whatever result you've just cited. Separate the team's part ("we") from yours ("I"), precisely. Hold your part through two follow-ups by restating exactly what you did. Concede the rest plainly. Shrinking a claim gracefully scores better than defending an inflated one | The attribution probe. It rehearses honesty under pressure. EXP |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc, in your own words: where you started, the thread that led you towards operations work, the one or two moves that matter, and why this role now. End on "why now", not on your current job title. Time it out loud | The opener is scored for economy. A rambling first answer costs goodwill for the rest of the hour |
| G2 | "What's one operational process you think most teams get wrong?" | CASE | [generic] | One opinion, one reason, and what you'd do instead. Keep it specific and short. Casual register, scored content | A friendly question about the core of the job is still a judgment test. It touches F4. CASE |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Ask what their team owns, then propose principles: one owner per decision, a shared intake, and an agreed way to escalate. For "when we disagree", say how you'd handle it (data first, then the decision owner, then escalation), not a story you'd have to invent | The Peer stem. It scores turf awareness. CASE because it's a live proposal |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A principle first: name contributors specifically, in the forums where it matters. Then, if you have one, a time you made sure another team got credit. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | The Peer stem on credit-sharing. It touches F5. VAL |
| H3 | "What would you need from me in your first month?" | CASE | [generic] | Reciprocity framing. Lead with what you'd bring their team in month one (listening, a map of current processes, one quick fix), then what you'd need: context, an introduction, a standing check-in | Peers price what a new hire costs them. Lead with the give, then the ask |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does product operations own here today, and what should it own that it doesn't yet?" | It shows you're thinking about the role's scope, and the answer tells you what you're walking into |
| "What would make someone in this role clearly successful at six months?" | It gets the real scorecard, which may differ from the posting |
| "Where does the team feel the most friction between product and the customer-facing teams right now?" | Product ops sits on that seam. It shows you know where the work is |
| "What's a process here that works well and that you'd be nervous about someone changing?" | It signals respect for what already works, which is the main worry about an operations hire |
| "How are decisions about what product ops takes on prioritised, and who breaks ties?" | It tests whether the role has the authority its scope needs, and answers something you need to know before accepting |
| "What are the next steps, and is there anything from today you'd like me to expand on?" | It invites a final correction while you're still in the room |

## Prohibited claims

No entries. Your material contains no sentences about your past, so there's no quoted wording an inflated version could stretch, and no stated negative to give back to you. That's why every answer about your past in this pack is a selection scaffold. Once you add a CV, this list will be built from your own sentences.

## Sources

Provided documents: your message ("Final-round interview at Stripe for a Product Operations Manager role"). No dossier was present.

Searches sent:

- `Stripe operating principles`: refused
- `Stripe interview process operations final round`: refused
- `Stripe strategy news 2026`: refused
- `Stripe "Product Operations Manager" job description`: refused

No fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. It would have supplied Stripe's official value names for the D bank and a values cheat sheet |
| 2. Stripe interview process for operations roles | unavailable | Search refused. It would have described the final-round structure. Persona weights fell back to the Generic archetype instead |
| 3. Stripe strategy and recent news | unavailable | Search refused. It would have supplied CO and strategy-grounded CASE questions. None are in the pack |
| 4. Interviewer name at Stripe | n/a | No name was given, so there was no query to form. There's no interviewer read, and the reverse questions are role-generic |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. It would have turned the fit snapshot's prose requirements into quoted, `[inferred]` rows |

## Upgrade menu

- The job description text: F1–F6 become quoted requirements, `[grounded]`, and JD-tagged questions are written against Stripe's actual list
- Your CV, or a few paragraphs about your background: the worksheet becomes story-mapped answers, defend-the-number questions for your metrics, and a prohibited list built from your own sentences
- Who you're meeting (manager, peers, cross-functional partner, skip-level): persona weights set from the relationship, not flat
- The recruiter's prep email: their named focus areas, plus a build section for any declared deliverable (a case, a presentation, a take-home)
- The final round's schedule, if it's several sessions: a mini-pack per session with its own weights and reverse questions
- Interviewer names: an interviewer read from their public professional footprint, plus a reverse question tied to their path
- Web search permission: an L1 rerun covering targets 1, 2, 3 and 5 above (Stripe's values by name, loop structure, CO questions on current strategy, a representative JD)
- A deep research pass (up to 6 more searches and 2 more fetches, several more minutes): a strategy brief behind sharper CASE and CO questions
- How much prep time you have: a prioritised schedule sized to it
- A `tuesday-dossier.md` from job-underwriter: the highest-ROI objection taken from verified evidence instead of inferred, and a prohibited-claims guardrail
