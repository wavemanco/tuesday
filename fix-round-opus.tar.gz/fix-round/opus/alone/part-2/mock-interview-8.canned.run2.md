I've built your prep pack. It covers all three rounds on 21 November, with questions and answer guidance for each one, the 20-minute escalation case, and the four values for the panel.

The question to rehearse most is **D1** in the round with the Head of Member Services: "You've handled one branch's complaints log. This role owns the process across every branch and the contact centre. What makes you ready for that?" Name the contact-centre gap first, before they do. Then stick to what you've actually done (the branch's complaints log, training new tellers on the escalation script, the spreadsheet your regional manager uses) and give a 90-day plan for the rest.

- **Two gaps you've already admitted:** you've never worked in a contact centre, and you've never presented above regional level. The pack gives you a plain way to say each one, followed by a plan for learning it. It never coaches you to make either gap sound smaller.
- **Four things to check before the day:**
  - Whether your complaints log followed rules set outside the branch.
  - What your spreadsheet actually counts, and which tool it's built in.
  - Whether your teller training covered more than the escalation script.
  - Whether you've done any work with digital teams.

  For each one, the pack gives you two honest answers: one if the answer is yes, one if it's no.
- **Round 3 (the panel):** the pack has a 20-minute outline for the case and one question for each of the four values. None of the details you gave me makes a story for any value on its own, so each comes with a guide for choosing a real story, and what to say if you don't have one.
- **The two branch managers:** the eight branches are becoming five hubs in 2027, so the pack suggests you talk about hubs as a change for members and staff in those towns, not as a cost saving.
- **No web research:** your message already had the job ad, the values, the recruiter's email and the strategy brief. The strategy brief is from July, so the pack suggests asking whether plans have moved rather than stating them as current.

Files are in:
- /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-8-canned-bd4acce4/ashgrove-credit-union_member-experience-lead_interview_pack.md

Say the word and I'll play the Head of Member Services asking D1, with follow-ups that respond to what you actually say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of interviews:** 21 November 2026 · **Mode:** loop (three scheduled rounds, one shared fit snapshot)

| Round | Interviewer and relationship | Length | What the recruiter said it holds |
|---|---|---|---|
| 1 | The recruiter (name not given) | 30 min | "30 minutes with me" |
| 2 | Head of Member Services, your would-be manager (name not given) | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers (names not given) | 60 min | "a 20-minute case on a complaint escalation"; "the values round — they score against the four values" |

## How to use this pack

- **Personas** describe how a question is asked (friendly, skeptical, time-boxed). **Types** describe what is being scored. Rehearse both: the same content lands differently when it arrives as pressure.
- **Type key:** **VAL** — whether your past behaviour shows Ashgrove's published values. **EXP** — whether what you've said about your work survives close questions. **JD** — whether you can do the listed job, gaps included. **CO** — whether you know Ashgrove's strategy and can think at its level. **CASE** — a live problem from the role, reasoned out loud.
- **Provenance labels:** `[grounded]` traces to your message, the JD, the recruiter's email, the values text or the strategy brief. `[inferred]` is this pack's derivation, with the derivation named. `[generic]` is a role-family pattern with no claim about Ashgrove or you.
- **Answer slots** are instructions for the interview, not questions for now: each one names a probe you're likely to get and gives two honest branches. Answer whichever is true.
- Every claim the pack makes about your past is one of your own four sentences, quoted. Guidance is scaffolding, not a script — say it in your own words.
- **Highest-ROI prep in this pack: D1** (round 2, Skeptic) — the step from one branch's complaints log to a role across every branch and the contact centre.

## The fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message, whole sentences, nothing added.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's "end to end" makes a probe on which parts of a complaint's handling were yours likely. If any decision on a complaint, beyond handling the log, was yours, say which and how, in your own words; if none was, say so plainly and stay with the log and the training. Expect a probe: nothing inspectable sits behind the line |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you've said so. Words: "I've never worked in a contact centre." Then how you'd learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet you built and your regional manager uses; it does not show what the spreadsheet counts. Answer slot: say what it counts, in your own words; if you're not sure which figures it holds, say so plainly and stay with the fact that you built it and your regional manager uses it |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet and does not name a tool. Answer slot: name the tool you built it in and which parts of it you built, in your own words; never rename the tool to match the JD |
| F5 | "coach branch supervisors on escalations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message; "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the escalation script, as a branch supervisor; the JD's learners are supervisors. Words at their own scope: "I've been a branch supervisor for the last three years, and I trained new tellers on our escalation script." Answer slot: if your training covered more than the script, say what, in your own words; if it was the script, say so plainly and stay with it. Coaching supervisors is spoken as a plan, never a past |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show work with digital teams or self-service. Answer slot: if you've worked with a digital or online-banking team, or helped members through a self-service channel, say what you did, in your own words; if not, say so plainly and say how you'd approach it |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence already reaches the requirement in other terms. Say it as it is: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer map it; don't restate your years in the JD's words |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | "Formal" is your word; your material does not show whose rules the log followed. Answer slot: if the log followed rules set outside your branch, say whose and what they asked of you, in your own words; if you're not sure, say so plainly and stay with the log |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this one. Words: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and what, in your own words; if not, say so plainly. Then how you'd prepare, said as a plan |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Own complaints end to end across branches (F1) | D1, C1, H1, H3 |
| …and the contact centre (F2) | B2, D1, J1 |
| Report monthly on volumes and resolution times (F3) | E1, E2, I2 |
| Coach branch supervisors on escalations (F5) | C2, D3, I1 |
| Work with digital teams on self-service journeys (F6) | F1, H2 |
| 4+ years in financial-services customer operations (F7) | B3, A1 |
| Regulated complaints (F8) | B1, H1 |
| Presenting to senior leaders (F9) | A5, D2 |
| Excel reporting (F4) | E1, E2 |

## Graded deliverable: the 20-minute escalation case (round 3)

The recruiter announced "a 20-minute case on a complaint escalation" with a panel that scores "against the four values". The case itself is not known, so this builds the structure; rehearse it on H1.

**Facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| The panel scores against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Recruiter's email; values text you pasted | [grounded] |
| The role owns complaints "end to end across branches and the contact centre" and coaches "branch supervisors on escalations" | JD | [grounded] |
| Eight branches into five hubs over 2027; 40% of member service to digital by 2028; app-only banks are the main competitive pressure | Strategy brief, July 2026, as you summarised it | [grounded] |
| Your own line, usable once when you say why logging matters to you — F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your message | [grounded] |

**A 20-minute shape**

| Minutes | Beat | Value it shows |
|---|---|---|
| 0–2 | Clarify: who the member is, what they want, how long it's been open, what's been promised, any deadline the complaint rules set | Members First, Always |
| 2–5 | Member first: contact the member, acknowledge in plain words, say who now holds it and when they'll hear next | Plain Words |
| 5–10 | Ownership and investigation: one named owner keeps hold until it's solved; gather the facts from branch and contact centre; confirm which complaint rules and deadlines apply rather than quoting one you're unsure of | Own the Fix |
| 10–13 | The outcome and how it's said: a decision a member understands the first time | Plain Words |
| 13–17 | Prevention: log it so the monthly report shows the pattern; coach the supervisor on what to do earlier next time; work with the branch, not around it | Neighbours, Not Numbers |
| 17–20 | Close: what the member got, what changed, what you'd report | All four |

**Theses, each with its concession**

| Thesis | Concession you say aloud |
|---|---|
| One named owner holds the complaint from escalation to resolution, wherever it started | One owner can become a bottleneck; handover rules for leave and volume are needed |
| Write the outcome for the member before writing the process fix | Regulated final responses may require specific content; plain words don't mean dropping what's required |
| Every escalation is data for the monthly report, by branch and by channel | A report can make a branch feel blamed; report patterns and fixes, agreed with the branch first |

**Differentiation.** The consensus answer is apologise, investigate, resolve, follow up. Bring one of those to show you have the basics, then the divergence: name the owner, name the clock, name what the supervisor learns, and name what the monthly report will show. **Anti-pick:** don't promise an outcome or compensation before the facts are in, and don't take the complaint away from the branch without telling them.

## Grounding brief

| Point | Source | Provenance | How to use it |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Strategy brief, July 2026 | [grounded] | Use it on F1 and H2: where service moves, complaints move with it |
| Consolidate eight branches into five hubs over 2027 | Strategy brief, July 2026 | [grounded] | Your round-3 panel is two branch managers; speak about hubs as a change for members and staff in those towns, not as a saving. That reading is this pack's, from the panel's roles and the brief |
| Launch a small-business lending product in Q1 2027 | Strategy brief, July 2026 | [grounded] | One reverse question at most; the JD doesn't mention it |
| Main competitive pressure is app-only banks | Strategy brief, July 2026 | [grounded] | Pairs with "Neighbours, Not Numbers": the branch-and-town relationship is what an app-only bank doesn't have — say it as your view |
| The brief is four months old; plans may have moved since July | Date of the brief against today, 12 November 2026 | [inferred] | Ask rather than assert ("is the hub plan still on the 2027 timeline?"); never correct an interviewer on it |

## Question banks

### Round 1 — Recruiter (30 min)

#### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Chatty openers, "walk me through", why-us | Highest: recruiter-screen prior, and a 30-minute slot leaves room for little else | 90-second arc from your own sentences; treat casual questions about JD lines as scored |
| Skeptic (light) | Knockout checks on the JD's requirements | Mid: recruiter-screen prior; the JD has four stated requirements a recruiter can tick | Short, plain answers on F2, F7 and F8; no over-explaining |

#### A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, each one your sentence: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words — the reason is yours and the pack doesn't supply it. Under two minutes | F7, F1 and F3 are the evidence every later round probes, so the opener sets what gets tested. EXP because each clause will be checked in round 2 |
| A2 | "Why Ashgrove — and why now?" | CO | [grounded] | Name one strategy point and one value that genuinely matter to you, in the brief's and values page's own words, and say why in your own words. Don't recite all four values; save them for the panel. If "now" has a reason, give it briefly and without criticising your current employer | Motivation is the recruiter's standing question; CO because the strong answer shows you read the brief and values |
| A3 | "What do you know about where we're heading?" | CO | [grounded] | The four points as the brief puts them: 40% of member service to digital by 2028; eight branches into five hubs over 2027; small-business lending in Q1 2027; app-only banks as the main pressure. Then one thing you'd want to understand about complaints through those changes, framed as curiosity, not a verdict | The recruiter sent you the brief, so they know you have it; CO because homework is being checked |
| A4 | "What are you looking for in your next role?" | JD | [grounded] | Pick the JD lines that draw you — owning complaints end to end, monthly reporting, coaching supervisors, digital journeys — and say why in your own words. No claim about your past is needed here | A casual motivation question scored against the JD; JD because the answer should map to its lines |
| A5 | "The role presents to senior leaders — how do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it before it's found: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and what, in your own words; if not, say so plainly. Then how you'd prepare for the first senior presentation, said as a plan — for example, rehearsing it with your manager and leading with what it means for members | F9 is a gap you stated, on a JD requirement; a casual register doesn't make it unscored |

#### B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our JD mentions regulated complaints. Tell me about the complaints you've handled." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | In your sentence's terms: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if the log followed rules set outside your branch, say whose and what they asked of you, in your own words; if you're not sure, say so plainly and stay with the log. Don't upgrade "formal" | F8 is a discovery row on a stated requirement; JD because a recruiter ticks it |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "No — I've never worked in a contact centre." Then one line of plan: how you'd learn it in your first weeks — for example, listening in on calls and sitting with agents — said as a plan. Then stop | F2 is a capability gap you stated; recruiters run knockout checks, so it lands here first |
| B3 | "The role asks for 4+ years in financial-services customer operations. Where does your experience fit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | "Six years in retail banking, the last three as a branch supervisor." Let the recruiter do the mapping; don't rename your years in the JD's words | F7 is a presentation row; JD because it's a knockout-style check |

#### Reverse questions — round 1

| Question | Why it lands |
|---|---|
| "Is the 20-minute case given on the day, or shared beforehand?" | Process is the recruiter's to answer, and the answer changes how you prepare |
| "For the values round, is there anything about how the panel scores that's useful to know?" | Shows you took the four values seriously; asks for shape, not answers |
| "Day to day, how does the contact centre fit with this role?" | Sizes F2 honestly before round 2 |
| "Is this a new role or a backfill?" | Tells you whether you'd build the complaints process or inherit one |
| "What happens after 21 November, and when?" | Practical, and recruiters expect it |

### Round 2 — Head of Member Services, your would-be manager (45 min)

#### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "Tell me about a time…" | Highest: the recruiter said "mostly behavioural", which lifts it above the hiring-manager prior | Selection scaffolds below; "we" for context, "I" for your part |
| Skeptic | Quiet probing of the scope jump | High: hiring-manager prior, and F1, F2 and F9 are where the material is thinnest | D1 rehearsed until it's boring; concede before being asked |
| Data-Driven Prober | "Walk me through the spreadsheet" | Low-mid: your manager would receive your monthly reports (JD), and F3 is your main reporting evidence | Know what you can and can't say about the spreadsheet |
| Case / Strategist | Strategy questions on digital and hubs | Low-mid: hiring-manager prior, cut back by "mostly behavioural" | Clarify → objective → segment → approach → metrics → risks |

#### C — Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a complaint escalated beyond what you could resolve at the branch." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pick a complaint that went beyond the branch. It needs the point where it left your hands or stayed with you, what you did then, and how it ended for the member. If no such complaint comes to mind, say so plainly, then give the nearest thing your material carries — "I handled the branch's formal complaints log and trained new tellers on our escalation script" — or how you'd handle one | The JD's escalation lines make this the likeliest behavioural opener; EXP because it tests what was actually yours under F1 |
| C2 | "Tell me about training someone to handle an escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5: you trained new tellers on the escalation script — those are the beats your sentence states; tell them in your own words. Answer slot: the JD's coaching line makes a probe on what the training covered likely; if it covered more than the script, say what; if it was the script, say so plainly and describe how you trained it | F5 is the bridge to the coaching requirement; EXP because the probe is on what you did |
| C3 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [grounded] | Pick a time you raised something unwelcome with someone above you. It needs a named stake, the moment you said it, and what happened to the relationship after. If no such time comes to mind, say so plainly, then say how you would handle it | A standard behavioural stem, and the JD's senior-leader reporting makes it relevant; VAL because "Own the Fix" asks you to keep hold of problems you find |
| C4 | "Tell me about a time you got something wrong. What did you do?" | VAL | [grounded] | Pick a real mistake, small is fine. It needs what went wrong, when you noticed, what you did to fix it, and what changed after. If none comes to mind, say so plainly rather than offering a disguised strength | "Own the Fix" is published; a manager tests it on your own errors as well as others' |

#### D — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've handled one branch's complaints log. This role owns the process across every branch and the contact centre. What makes you ready for that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI rehearsal in the pack.** Name the limit first: "I've never worked in a contact centre." Then hold on what your sentences carry: "I handled the branch's formal complaints log and trained new tellers on our escalation script, and I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if any decision on a complaint beyond handling the log was yours, say which and how; if none was, say so plainly and stay with the log and the training. Then the ramp, said as a plan: visit every branch, sit in on the contact centre, read a month of complaints across the network before changing anything. **Follow-up 1** — "But that's one branch." Hold: "Yes, one branch." Don't add scope; return to the plan. **Follow-up 2** — "So why you over someone who's done it?" Hold: what you'd do in the first ninety days. Concede specifically — the contact centre, the network scale — and never fold on what you did do | F1, F2 and F3 together are the biggest gap between your material and the role, so this objection arrives in some form; JD because it scores the headline responsibility |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the real one: "I've never presented to anyone above regional level." Then the plan for it, as a plan. Don't pick a disguised strength, and don't repeat the contact centre if D1 already covered it | F9 is a gap you stated; candour here is what the question scores |
| D3 | "You'd be coaching branch supervisors — the role you've held for the last three years. Why would they take coaching from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold on your sentences: three years as a branch supervisor, and you trained new tellers on the escalation script. Answer slot: if your training covered more than the script, say what; if it was the script, say so plainly. Then how you'd coach peers, as a plan: start from their own escalations, ask before telling, never hand them a new script on day one | F5 is a transferability row: tellers to supervisors; JD because it scores the coaching line |

#### E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Open with the sentence: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's reporting line makes a probe on what it measures likely; say what it counts, where its data comes from, which tool it's in and which part you built, in your own words; anything you don't know, say so plainly. Before being asked, name the part of it you'd trust least, in your own words, if there is one | F3 and F4 rest on this one sentence, so a manager who'll read your reports will press it; EXP because it tests the artifact |
| E2 | "Next month I want average resolution time by branch and by channel. How would you build it?" | JD | [generic] | Structure it aloud: when the clock starts and when a complaint counts as resolved; where each channel's data sits and whether the definitions match; average versus median and what outliers do; exclusions you'd show rather than hide; what you'd caveat on version one. Close with the assumption you'd defend least | Covers the Excel and monthly-reporting lines as a live problem; `[generic]` because it's a reporting pattern, not a claim about Ashgrove's data |

#### F — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "The role works with digital teams on self-service journeys, and we're moving 40% of member service to digital by 2028. What would you bring?" | JD | [grounded] | Answer slot: if you've worked with a digital or online-banking team, or helped members through a self-service channel, say what you did, in your own words; if not, say so plainly. Then what you'd bring, as a plan: complaints as the map of where self-service journeys break; a plain-words check on journeys; a route for a complaint that starts in the app to reach a person | F6 has no evidence yet, and the brief's 40% target makes this the strategy question most likely; JD because it scores the digital line |
| F2 | "Eight branches become five hubs over 2027. How would you keep complaints handling steady through that?" | CASE | [grounded] | Clarify (which branches, what timeline, who holds open complaints during the move) → objective (no member complaint lost in the move) → segment (members of merging branches; less-digital members) → approach (a named owner for every open complaint; transfer of logs; plain-words notice to members) → metrics (volume and resolution time at affected branches, before and after) → risks (complaints about the change itself). Challenge one premise respectfully | Grounded in the brief; CASE because it's a live problem in the role |

#### Reverse questions — round 2

| Question | Why it lands |
|---|---|
| "What does the monthly complaints report look like today, and what would you want different in my first three months?" | Asks your future manager to define success in their own terms |
| "Where do complaints get stuck most often now — branches, the contact centre, or the handover between them?" | Shows you're already thinking about the end-to-end seam |
| "How will the hubs in 2027 change where complaints come in?" | Ties the role to the brief without assuming the answer |
| "How do you see this role working with the digital teams on the 40% target?" | Clarifies F6's real scope |
| "A year in, what would make you say this hire was a good one?" | Invites a concrete bar you can be measured against |

### Round 3 — Panel of two branch managers (60 min, values round with 20-minute case)

#### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One question per value, scored | Highest: the recruiter named this the values round, scored on all four | One prepared story or honest branch per value, below |
| Case / Strategist | The 20-minute case and follow-ups | High: the recruiter announced the case | The 20-minute shape in the case section |
| Peer Evaluator | "How would you work with our supervisors?" | Mid: you'd coach supervisors in their branches, so they price what you add to their load | Reciprocity: what you bring their branch, not what you need |
| Pressure (light) | A time-boxed "why you" | Low: case rounds often time-box; nothing in the email suggests more | Pause, restate, hold on your sentences |

#### G — Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Pick a decision where the member's view and the branch's convenience pulled apart. It needs what each side wanted, what you decided, and what it cost or saved the member. If no such time comes to mind, say so plainly, then say how you would decide one | Members First, Always, in the value's own words |
| G2 | "Tell me about a time you had to make something clearer for a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pick a time an explanation didn't land and you changed it. Answer slot: Plain Words makes a probe on wording likely; if you ever changed how the escalation script was worded or explained to new tellers, say what and why; if not, say so plainly and pick another time, or say how you would handle it | Plain Words; F5 is the nearest material |
| G3 | "Tell me about a time knowing your town changed how you handled a member." | VAL | [grounded] | Pick a time local knowledge changed what you did. It needs the member, what you knew about the place, and what you did differently. If no such time comes to mind, say so plainly, then say how you'd keep that local knowledge alive as branches become hubs | Neighbours, Not Numbers; the hub plan makes it pointed for branch managers |
| G4 | "Tell me about a problem that wasn't strictly yours that you kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Pick a problem you found and didn't pass on. Answer slot: if the spreadsheet you built started from a problem you found, say what the problem was, in your own words; if it didn't, say so and pick another. If no such time comes to mind, say so plainly, then say how you would handle it | Own the Fix; F3 is the nearest material |

#### H — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member's complaint about a fee has gone between their branch and the contact centre for three weeks. They've now emailed the chief executive. Take us through it." | CASE | [generic] | Run the 20-minute shape from the case section: clarify → member first → one named owner → facts from both sides → confirm the applicable complaint rules and deadline → outcome in plain words → prevention and reporting → close. Say which value each step serves, briefly | A practice case on the announced format; `[generic]` because the real case is unknown |
| H2 | "Same member. Their branch is merging into a hub next year, and they say they'll move to an app-only bank. Does that change anything?" | CASE | [grounded] | Don't change the fix; change the conversation. Resolve the complaint on its merits, then address the move in plain words: what changes for them and who their contact will be. Resist a retention offer as the fix. Note what it says about members of merging branches for the monthly report | Grounded in the brief's hubs and competitor points; CASE because it's a live twist |
| H3 | "What would you change so this doesn't happen again?" | CASE | [generic] | Root cause before fix: why it bounced, whose handover failed, what the member saw. Then three levels: the branch (coach the supervisor on when to escalate), the network (one owner rule across branch and contact centre), the report (track bounced complaints monthly). Name the one you'd do first and why | The panel scores follow-through; `[generic]` because it's a pattern |

#### I — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Our supervisors have their own way of handling escalations. How would you work with them without treading on our toes?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | You've been a branch supervisor for the last three years — say that, and say what you'd bring their branch: help with the escalations they find hardest, and the monthly picture from other branches. Propose a principle for the seam: supervisors keep the member, you keep the process. Don't claim to have coached supervisors | F5 seen from the branch side; JD because it scores the coaching line |
| I2 | "When a complaint shows a branch got it wrong, how does that show up in your monthly report?" | CASE | [grounded] | Name the tension: Own the Fix versus Neighbours, Not Numbers. Report the pattern and the fix; tell the branch before the report goes out; name a branch where naming it helps the fix, not to rank it. Ask how they'd want it handled | Two published values in tension, from the people whose branches the report covers |

#### J — Pressure (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you over someone from our contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause, then: six years in retail banking, three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Concede the gap by name: "I've never worked in a contact centre." Hold there through the follow-up. Never knock the other candidate | F2 is the gap a branch-heavy panel may press; hold-then-concede on what your sentences carry |

#### Values cheat sheet (round 3)

| Value | Working meaning | Your story |
|---|---|---|
| Members First, Always | Decide from the member's side, not the branch's convenience | No sentence in your material carries a story here. Selection scaffold: a decision where what the member needed and what was easier pulled apart, what you chose, and the result for the member. If none comes to mind, say so plainly, then say how you would decide it |
| Plain Words | Needing to explain twice means it was written wrong | Nearest material, F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." It carries no story by itself. Selection scaffold: a time an explanation didn't land and you changed it; if none comes to mind, say so plainly and say how you'd test an explanation |
| Neighbours, Not Numbers | Each branch belongs to its town | No sentence in your material carries a story here. Selection scaffold: a time local knowledge changed how you handled a member. If none comes to mind, say so plainly, then say how you'd keep that local knowledge as branches become hubs |
| Own the Fix | Whoever finds the problem keeps hold until it's solved | Nearest material, F3: "I built the monthly complaints spreadsheet our regional manager uses." It doesn't say what problem, if any, it started from. Selection scaffold: a problem you found and kept hold of; if none comes to mind, say so plainly and say how you would handle it |

#### Reverse questions — round 3

| Question | Why it lands |
|---|---|
| "What would a Member Experience Lead do in the first month that would genuinely help your branch?" | Reciprocity: asks what you'd add to their work |
| "What do your supervisors find hardest about escalations today?" | Gives you the coaching agenda from the people who'd live with it |
| "When a complaint starts in your branch and moves to the contact centre, how do you hear how it ended?" | Probes the end-to-end seam from their side |
| "How do you think the move to hubs will change the complaints you see?" | Shows you've read the plan and respect their view of their towns |
| "Which of the four values do you find hardest to live in a difficult complaint?" | Invites them to talk about the values they're scoring, honestly |

## Prohibited claims

Built from the fit snapshot. None of these is coached anywhere in the pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's log, not a process across branches. D1's slot stays inside the branch |
| Any contact-centre experience | Negative you stated, F2 | "I've never worked in a contact centre." No slot |
| Has presented to senior leaders above regional level | Negative you stated, F9 | "I've never presented to anyone above regional level." The slot asks only about regional level |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The slot asks only what the spreadsheet counts |
| Built the spreadsheet in Excel | Inflated form of F4: your sentence names no tool | F4's quote at its own scope. The slot asks only which tool it's in |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quotes at their own scope. The slot asks only what the training covered |
| Handled regulated complaints | Inflated form of F8: "formal" is your word | F8's quote at its own scope. The slot asks only whose rules the log followed |
| Six years in financial-services customer operations | Inflated form of F7: the JD's vocabulary on your history | "6 years in retail banking, the last 3 as a branch supervisor." |

## Sources

**Provided documents**

- The JD, pasted by you.
- The values text, pasted by you; you say you copied it from ashgrovecu.org/about/values on 12 November 2026. Not fetched by this pack.
- The recruiter's email about the three rounds, pasted by you.
- Your summary of Ashgrove's July 2026 strategy brief, which the recruiter sent you.
- Your background, from your message.

**Searches and fetches:** none sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you copied this morning fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email fixes the three rounds, who runs each, the case and the values round |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief, under six months old, fixes the grounding brief and the CO and CASE questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, so there was no query to form; there is no interviewer read, and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewers' names for any round → a reading of each one's public professional footprint, persona weights per panel member, and a reverse question tied to each one's career path
- Your CV → more of your own sentences in the fit snapshot, so rows now built on answer slots can become story-mapped
- Your answers to the answer slots in F1, F3, F4, F5, F6, F8 and F9 → those rows, and the questions drawing on them (B1, C2, D1, D3, E1, F1, A5, G2, G4), regenerate as story-mapped guidance
- How much prep time you have before 21 November → a prioritised prep schedule tied to question IDs
- The strategy brief itself, rather than your summary → its own lines quoted in the grounding brief, and sharper F1, F2 and H2
- Which complaint rules Ashgrove works under, from the recruiter → the case section can name the real deadlines instead of "confirm the rule"
- Whether the 20-minute case is shared in advance → a build section on the actual case
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent news since July on the hub plan and leadership, interview reports for this role family, and the competitive frame against app-only banks
- A tuesday-dossier.md from job-underwriter → a highest-ROI objection derived from verified evidence rather than inferred here, and a prohibited-claims list checked against it; this pack is complete without one
