I've built your prep pack. It's one shared assessment of how your background fits the job description, then a section for each of the three rounds on 21 November. The round details come straight from the recruiter's email.

- **Your biggest risk is the scope question.** Expect the Head of Member Services to ask something like: "You've handled one branch's complaints log. This role covers every branch and a contact centre you've never worked in. Why are you ready?" The pack rehearses it most deeply (question D1). Name the limit yourself before they finish asking, then stick to what you actually did: the branch's complaints log, training new tellers, and the monthly spreadsheet.
- **Your two stated gaps get plain answers.** For the contact centre and for presenting above regional level, you say it straight ("I haven't…") and follow with a plan, not a past. I didn't soften either one.
- **Some JD words don't match yours, and the pack won't swap them.** You said "formal" complaints; the JD says "regulated". You said "spreadsheet"; the JD says "Excel". For each one the pack gives you an honest way to answer whichever way the facts go. There's also a list of claims to avoid, like saying you coached supervisors when you trained tellers.
- **The 20-minute case gets its own section.** It has a timed structure, three positions you can take (each with a point to concede), and how to stand out from the standard answer. One thing to avoid is resolving a complaint by pushing the member onto the app, even with the 40% digital target.
- **The values round needs your input.** Nothing in your message is a story for any of the four values, so for each one the pack tells you what kind of story to pick rather than writing one for you. Choose your four stories before the day.

I didn't run any web searches. The JD, values, recruiter email and strategy summary you pasted covered everything. No interviewer names have been assigned yet, so there's no section on the individual interviewers.

Files are in your working directory:
- ashgrove-credit-union_member-experience-lead_interview_pack.md

If you'd like to practise, I'll play the Head of Member Services and ask you D1 with live follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop, 21 November 2026:** three rounds, as the recruiter's email sets them out.

1. **Recruiter screen**, 30 minutes.
2. **Head of Member Services**, your would-be manager, 45 minutes, mostly behavioural.
3. **Panel of two branch managers**, 60 minutes. It includes a 20-minute complaint-escalation case, and it is also the values round, scored against the four values.

**Interviewers:** known by role only, because names haven't been assigned yet.

**Mode:** a loop pack. One fit snapshot is shared by all three rounds, then each round gets its own mini-pack.

---

## How to use this pack

Read the pack along two axes:

- **Personas** describe how a question is asked: who asks it and in what tone.
- **Types** describe what the answer is scored on.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's four published values |
| EXP | Whether what you say about your own work holds up when someone digs into it |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | How you structure a live problem from the role |

**Provenance labels:**

- **[grounded]:** traceable to something you gave me, either your message, the JD, the values, the recruiter's email or the strategy brief summary.
- **[inferred]:** derived by this pack, and the row says how.
- **[generic]:** a general pattern for this kind of role. It makes no claim about you or Ashgrove.

**Answer slots** mark places where the interviewer is likely to probe something your material doesn't settle. Each slot has two honest branches, and either one is a good answer.

The guidance is scaffolding, not a script. Say it in your own words.

**Sections left out:**

- **Prep triage:** I don't know how much prep time you have.
- **Reading the interviewer:** no names yet.
- **Delivery coaching:** no working-style assessment was provided. None is needed.

---

## Fit snapshot

The rows draw on four sentences from your message, quoted exactly. Everything this pack says about your past rests on one of them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material covers one branch's log, not a process across branches, so your words stay at that scope: "I handled the branch's formal complaints log." **Answer slot:** the JD's end-to-end line makes a probe on what handling the log involved likely. If any decisions about how those complaints were handled were yours, say which ones and how you decided, in your own words. If none were, say so plainly and describe what handling the log meant for you day to day |
| F2 | "...and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | This is a gap you have stated yourself, and wording can't close it. Your words: "I haven't worked in a contact centre." Then say how you would learn it, framed as a plan and never as something in your past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says you built the spreadsheet and that your regional manager uses it. It doesn't show what the spreadsheet counts, or who reports from it. Your words: "I built the monthly complaints spreadsheet our regional manager uses." **Answer slot:** the JD's volumes-and-resolution-times line makes a probe on what the spreadsheet holds likely. Say what it tracks, in your own words. If it doesn't track something the interviewer names, say so plainly and stay with what it does hold |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your message says "spreadsheet" but doesn't name the tool. **Answer slot:** name the tool you built it in and what you built into it, in your own words. If it wasn't Excel, say what it was and stay with what you built |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes training new tellers on a script. It doesn't describe coaching supervisors. Your words: "I trained new tellers on our escalation script." **Answer slot:** the JD's coaching line makes a probe on how you trained likely. Say how you went about it, in your own words, and stay with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. **Answer slot:** if you've worked with a digital team, or on anything members use to serve themselves, say what it was and which part was yours, in your own words. If you haven't, say so plainly and say how you would start, drawing on the branch's complaints log you handled |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. This is a self-reported line with nothing inspected behind it, though, so expect it to be probed. Lead with the quote's own terms: "Six years in retail banking, the last three as a branch supervisor." Don't relabel it in the JD's vocabulary. Let the interviewer make the mapping |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your message says "formal", not "regulated", and this pack won't swap one word for the other. **Answer slot:** the JD's regulated-complaints line makes a probe on that log likely. Say what made a complaint formal and what handling one involved for you, in your own words. If you're not sure what made it formal, say so plainly and stay with what you did |
| F9 | "confident presenting to senior leaders" — JD, for audiences above regional level | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | This is a gap you have stated yourself. Your words: "I haven't presented to anyone above regional level." Then say how you would prepare, framed as a plan. Never claim senior presenting, and add nothing to make the gap feel smaller |
| F10 | "confident presenting to senior leaders" — JD, for audiences at regional level or below | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | low | [inferred] | discovery | Your sentence rules out audiences above regional level. It doesn't say whether you've presented at regional level or below, and the pack reads it as not saying. **Answer slot:** if you've presented to your regional manager or to a regional audience, say what and how it went, in your own words. If you haven't, say so plainly |

**No eligibility gates.** None of the JD's requirements is a licence, location or similar term. The years requirement is graded as experience, in F7.

---

## Graded deliverable: the 20-minute complaint-escalation case (panel round)

The recruiter announced this case and it is scored, so prepare it as an assignment, not as one more question. You don't know the scenario yet. Rehearse a structure that works on any escalation, so the content can change while the structure holds.

### Grounded facts to build on

| Fact | Source | Provenance | Use in the case |
|---|---|---|---|
| The role owns complaints "end to end across branches and the contact centre" | JD | [grounded] | Treat the hand-off between channels as part of your job, not someone else's |
| The panel scores against Members First, Always; Plain Words; Neighbours, Not Numbers; and Own the Fix | Recruiter's email and values page | [grounded] | Let each step of your answer show one value, without reciting slogans |
| Eight branches are consolidating into five hubs over 2027, and 40% of member service is moving to digital by 2028 | Strategy brief, July 2026 | [grounded] | Escalations may increasingly start in a channel that is changing. Mention it once, if it fits the scenario |
| F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your message | [grounded] | Your one line of experience if the panel asks "have you done this?" Say it, then go back to the case |

### A 20-minute shape

1. **Clarify, about 2 minutes.** Ask:
   - Who is the member, and how long have they been one?
   - Which channels have they already used?
   - What has already been promised to them?
   - What time limits apply to complaints at Ashgrove?
   - Who can authorise a remedy?

   Ask about the time limits rather than assuming them.
2. **The member now, about 4 minutes.** Cover what you would say to them, when you would say it, and who calls them. Decide from the member's side of the counter.
3. **Ownership and path, about 5 minutes.** Name one owner and the steps from now to close, including any branch-to-contact-centre hand-off.
4. **Cause and record, about 4 minutes.** Cover what went wrong, where it broke, and how it is logged so the monthly report shows the pattern.
5. **Prevent and coach, about 3 minutes.** Cover what changes so the next one doesn't escalate, and what you would coach the supervisor on.
6. **Close, about 2 minutes.** Give the reply to the member in plain words, and say what the branch is told.

### Theses, each with its concession

| Thesis | Mandatory concession |
|---|---|
| One named owner from first contact to close, whichever channel the complaint started in | One owner can become a bottleneck, and the first person to take a call may not be the right owner. Ownership may need a defined hand-off rather than literally one person, and you'd want to see how it works today before redesigning it |
| Fix the member's problem first, then the cause, and say out loud which one you're doing | Sometimes the cause has to be fixed before the member's problem can be. Any time limits Ashgrove works to set the pace, which is why you ask about them in step 1 |
| Every escalation is a data point: close it in the log so the monthly report shows the pattern | Consistent logging costs branch staff time, and a report is only as good as how uniformly branches and the contact centre record complaints |

### Differentiation

- **The consensus answer** is listen, apologise, investigate, resolve, follow up. Use it as your base, because it proves you know the basics.
- **Where you diverge:**
  - Name the specific seam where this escalation broke, and what you would change so the next one doesn't reach the panel.
  - Write the member's reply in plain words, out loud, in the case.
- **The anti-pick:** don't resolve an escalation by moving the member to the app or another channel, even with the 40% digital target in the brief. Say why you wouldn't. This is your reasoning to give, not a fact about Ashgrove.
- **A second anti-pick:** don't promise an outcome or compensation before you know the facts.

No specific close was requested. Finishing with what the member hears and what the branch is told covers Plain Words and Neighbours, Not Numbers without naming them.

---

## Grounding brief

Built from the strategy brief summary in your message. It has the four headline points, not the brief's own wording.

| Fact | Source | Provenance | How to use it |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Strategy brief, July 2026 | [grounded] | Complaints about self-service journeys are where the JD's digital-teams line lands. See E1 |
| Consolidate eight branches into five hubs over 2027 | Strategy brief, July 2026 | [grounded] | The panel are branch managers, so treat this with care. See J2 |
| Launch a small-business lending product in Q1 2027 | Strategy brief, July 2026 | [grounded] | It means a new product and a new kind of complaint early in your tenure. See E2 and J3 |
| App-only banks are the main competitive pressure | Strategy brief, July 2026 | [grounded] | It is the backdrop to "why a credit union". See A2 |
| Member-owned, about 900 staff | JD | [grounded] | Gives you the scale to picture when you talk about reporting and coaching |

---

# Round 1: Recruiter screen (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, motivation and logistics | **High.** It is a 30-minute recruiter screen, and those are rapport-led | Have a 90-second arc ready built only from your quoted sentences. Treat every casual question as scored. Have your notice period and pay range ready |
| Skeptic (light) | Knockout checks against the JD's requirements | **Medium.** Recruiters screen against the JD's listed requirements, and you have two stated gaps, F2 and F9 | Answer stated gaps in one plain sentence and move on. Don't over-explain |
| Others | Rare at this stage | **Low** | Covered in Rounds 2 and 3 |

## Question bank

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc from those three sentences and nothing else: "Six years in retail banking, the last three as a branch supervisor. I handled the branch's formal complaints log and trained new tellers on our escalation script, and I built the monthly complaints spreadsheet our regional manager uses." Close on why this role, in your own words | It is near-certain as the opener. EXP because it sets what Rounds 2 and 3 will probe. Draws on F7, F1 and F3 |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Give your own reason, in your own words, and tie it to one value by its name, for example Members First, Always or Neighbours, Not Numbers. One line on the brief's competitive point shows you've read it: app-only banks are the pressure, and member ownership is what sets Ashgrove apart. If you have a personal connection to Ashgrove or credit unions, say so. If you don't, don't invent one | Motivation is screened at every recruiter stage. CO because a good answer uses Ashgrove's own words and strategy |
| A3 | "In your own words, what does this role do?" | JD | [grounded] | Paraphrase the JD's four duties: complaints end to end across branches and the contact centre, monthly reporting, coaching supervisors on escalations, and self-service journeys with the digital teams. Don't add claims about your past here | It checks that you read the JD, and it is a soft lead-in to the gap checks |
| A4 | "What's been the most satisfying part of being a branch supervisor?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Pick something from your supervisor years that's genuinely yours and that you want more of in this role. The complaints log, the training or the spreadsheet are all in your material. Tell it in your own words. If none of those is the honest answer, say what is | The premise, supervisor, is your own sentence. It is a casual question, but your answer shows whether your motivation is consistent |
| A5 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name the four points without reciting them: digital to 40% by 2028, eight branches into five hubs, small-business lending in Q1 2027, and app-only bank competition. Add one sentence on what they mean for complaints, as your view: new journeys and new products bring new complaints, and hubs change who members talk to | Recruiters often test homework. The brief was sent to you, so not having read it would show |

### B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for regulated complaints experience. Tell me about yours." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with "I handled the branch's formal complaints log," and keep your own word, formal. **Answer slot (F8):** say what made a complaint formal and what handling one involved for you, in your own words. If you're not sure what made it formal, say so plainly and stay with what you did | This is the listed requirement your material touches without settling. A recruiter will tick it or flag it |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "No, I haven't worked in a contact centre." Then one sentence of plan, framed as a plan: in the first weeks, spend time with contact-centre colleagues and read their escalations. Don't apologise twice | F2 is a stated gap against a line in the job title's scope, so it is a likely knockout check |
| B3 | "This role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't presented to anyone above regional level." **Answer slot (F10):** if you've presented to your regional manager or to a regional audience, say what and how it went. If you haven't, say so plainly. Then how you would prepare, framed as a plan. Don't claim confidence you haven't tested | F9 is a stated gap against an explicit requirement. Rehearsing it here makes D2 easier |

## Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| "Is the 20-minute case shared beforehand or on the day, and is it a discussion or a role-play?" | It is a legitimate prep question, and the answer changes how you rehearse |
| "How does the panel's values scoring sit alongside the other two rounds?" | It shows you read the process email closely |
| "Once the interviewers are assigned, could you share their names?" | It is a reasonable request, and it lets you tailor your questions to each person |
| "Is this a new role or a backfill?" | It tells you whether you'd be building the process or inheriting one |
| "What happens after 21 November, and when would I hear?" | It is a clean logistics close |

---

# Round 2: Head of Member Services (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "Tell me about a time…" questions on escalations, training and ownership | **High.** The recruiter says this round is mostly behavioural | Use "we" for context and "I" for your part. Use a story only where your material carries one. Otherwise use the scaffold and its honest branch |
| Skeptic | Probes on scope: one branch against the whole organisation, the contact centre, senior presenting | **High.** A future manager derisks gaps, and F1, F2 and F9 are the gaps | D1 is the pack's highest-ROI rehearsal. Name the limit before you're asked about it |
| Case / Strategist | Short "how would you…" questions on strategy | **Medium.** It is a hiring-manager round, though one weighted toward behavioural questions | Clarify, then structure, then answer. Use the brief's terms |
| Data-Driven Prober | Questions about the spreadsheet and what reporting would look like | **Medium.** The JD's monthly reporting line, and F3 and F4 | Know exactly what you can say about the spreadsheet, and say plainly what you don't know |

## Question bank

### C: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you handled a complaint that had escalated." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one escalated complaint from the branch's formal complaints log you handled. A good story needs the member's problem, what you did, what was decided by you versus someone else, and how it ended. Tell it in your own words. If no single case comes to mind clearly, say so plainly, describe how handling the log worked for you, and then say how you would handle an escalation now | It is the role's core activity asked behaviourally, so it is very likely. Primary type EXP, with VAL as the delivery |
| C2 | "Tell me about training someone to handle escalations." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5. The beats the quote gives you are new tellers, training, and the escalation script. **Answer slot:** say how you went about the training, in your own words. If one teller moment comes to mind, use it. If none does, say so and describe the training itself. Stay with the tellers | F5 is your nearest evidence for the coaching duty. This question sets up D3 |
| C3 | "Tell me about a problem you spotted and kept hold of until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | This tests Own the Fix, and your manager will know the value. **Answer slot:** if building the monthly complaints spreadsheet started from a problem you noticed, that's your story, so say what the problem was and what you did, in your own words. If it didn't, pick another time you kept hold of a problem until it was solved. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the published values. It is the one value a manager is most likely to test directly |
| C4 | "Tell me about a time you had to tell a manager something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time with a real stake, a moment where you didn't fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It is a common behavioural stem. It also edges toward the senior-presenting requirement, because reporting bad complaint numbers upward is part of this job |

### D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've handled one branch's complaints log. This role owns complaints across every branch and a contact centre you've never worked in. Why are you ready for that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** See the four steps below the table | It is the most predictable objection. It joins F1's scope gap and F2's stated gap in the round where the person you'd report to is pricing the risk. JD because it scores the headline duty directly |
| D2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of the two gaps you've already stated, not a safe-sounding fake. Senior presenting is the cleaner pick here because D1 covers the contact centre: "I haven't presented to anyone above regional level." Then what you'd do about it, framed as a plan: sit in on a leadership meeting before presenting at one, send the report ahead of time, and rehearse it with your manager. Don't follow it with reassurance that claims confidence you haven't tested | It is a standard Skeptic stem. F9 is your honest answer, and a plain one scores better than a dodge |
| D3 | "You've trained new tellers. Coaching branch supervisors is different. How would you do it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Agree it's different, and say how in your own words. Training new starters on a script is not the same as coaching people at your own level. Then give your approach as a plan: start from real escalations, ask before telling, and agree what a good escalation looks like. You can also say, as your view, what you would want as a branch supervisor from someone in this role. **If asked how you trained the tellers, F5's slot applies:** say how, in your own words | F5 is a transferability gap, and the premise is your own sentence. This is the coaching duty asked straight |

**D1, the four steps.** D1 gets the deepest rehearsal because it is the objection most likely to come.

1. **Name the limit before they finish asking.** "I haven't worked in a contact centre, and the complaints log I handled was one branch's."
2. **Hold on what your quotes carry.** "I handled the branch's formal complaints log and trained new tellers on our escalation script, and I built the monthly complaints spreadsheet our regional manager uses."
3. **Give your plan, framed as a plan.** Spend early weeks with contact-centre colleagues, read their escalations, and map where branch and contact-centre complaints hand over.
4. **Handle the follow-ups:**
   - *"So what do you know about contact-centre complaints?"* Say "Not from the inside, and here's how I'd learn it," then give the plan again, shorter.
   - *"What's transferable, then?"* Go back to the log and the tellers, at their own scope. F1's slot applies: if decisions about how those complaints were handled were yours, say which ones. If none were, say so plainly and describe what handling the log meant for you.
   - *"Why not hire someone from a contact centre?"* Don't argue the other candidate down. Say what you'd bring, in your quotes' terms, and let them weigh it.

Never add scope, a number or an outcome to make the gap feel smaller.

### E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints?" | CASE | [grounded] | Clarify first: which journeys move first, and which members find digital hardest. Then cover four points: complaints are early-warning data on new self-service journeys; report them by channel; agree with the digital teams how complaints reach them; and keep a human route for members who need one. Challenge one premise politely: complaints may rise during the shift, so treat that as a sign the journeys need fixing, not as failure. **If asked whether you've done this before, F6's slot applies:** if you've worked with a digital team or on self-service, say what. If you haven't, say so plainly | The strategy's headline goal plus the JD's digital-teams line. CASE because it is asked as a live problem, with CO content |
| E2 | "Small-business lending launches in Q1. How would you get complaints ready for it?" | CO | [grounded] | Cover three things. Find out early what's different about the product and its members. Agree with the product team how complaints will be categorised from day one, so the monthly report shows them separately. Brief branch supervisors on likely escalations before the launch, not after. Concede that you'd need to learn the product first | It is a launch inside your first months, so a manager may test whether you think ahead. CO because it rests on the brief |

### G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 and F4. The quote gives you these beats: you built it, it's monthly, it covers complaints, and your regional manager uses it. **Answer slots:** the JD's volumes-and-resolution-times line makes a probe on what it contains likely, so say what it tracks, in your own words, and if it doesn't track something they name, say so plainly. The JD's Excel line makes a probe on the tool likely, so name the tool and what you built into it, and if it wasn't Excel, say what it was. If you know how your regional manager uses it, say so in your own words. If you don't, say "uses" and stop | It is your only reporting evidence, and it sits against two JD lines. A prober will go two levels into it |
| G2 | "How would you measure resolution time, and what would you report each month?" | CASE | [generic] | Define the clock first: when a complaint's time starts and when it stops. Then cover volumes and resolution times by channel and by branch, a median alongside the average so a few long cases don't hide the rest, and the oldest open cases. Name your weakest assumption before they do: that every channel logs complaints the same way. This question asks about no past, so the guidance claims none | The JD's reporting line asked as a live problem. [generic] because it is a pattern for the problem, not a fact about Ashgrove |

## Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| "What would make the monthly complaints report genuinely useful to you, and to the leaders it goes to?" | It shows you see reporting as serving a reader, and it helps you prepare for F9 |
| "Where does complaint handling between branches and the contact centre break today?" | It goes straight at the end-to-end mandate, and it shows you're thinking about the seam you'd own |
| "As branches move into hubs next year, how do you expect complaint patterns to change?" | It uses the strategy, and it asks for their view rather than asserting yours |
| "How do the digital teams hear about complaints on self-service journeys now?" | It covers the JD's digital line, and the answer tells you how much you'd be building |
| "What would you need from this person in the first 90 days?" | A manager-specific question, and it invites them to picture you in the job |

---

# Round 3: Panel of two branch managers (60 minutes: 20-minute case, values scoring)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One or more questions per value, scored | **High.** The recruiter says the panel scores against the four values | Prepare one story or scaffold per value. See the cheat sheet |
| Case / Strategist | The 20-minute escalation case, with follow-ups | **High.** The case was announced | Use the build section above: structure, three theses with concessions, the anti-pick |
| Peer Evaluator | "What would you need from us? What would you bring?" | **Medium.** This role coaches their supervisors and owns complaints from their branches, so they will work alongside you | Use reciprocity framing. Propose principles rather than pretending to know how their branches work |
| Pressure | Tight follow-ups on the case, or a time-boxed question | **Medium.** It is common in a case with two assessors | Pause, restate the question, hold the position through two follow-ups, then concede specifically |

## Values cheat sheet

The values were copied from ashgrovecu.org/about/values on 12 November 2026. **None of your four sentences carries a values story, so every row below is a selection scaffold.** Pick your stories before the day. The upgrade menu says what sending them would change.

| Value (official name) | Working meaning (paraphrased) | Your mapped story | Questions |
|---|---|---|---|
| Members First, Always | Decide from the member's position, not the organisation's convenience | Scaffold: a time you chose what was right for a member when it cost you or the branch something, such as time, a target or effort. It needs the member's situation, the choice, and why you made it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | H1 |
| Plain Words | If a member needs something explained twice, the explanation was at fault | Scaffold: a time you changed how something was explained so people understood it the first time. If it happened while you trained new tellers on the escalation script (F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script."), what you changed is an answer slot in H2. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | H2 |
| Neighbours, Not Numbers | Every branch belongs to its town, and members are people in a community | Scaffold: a time you treated a member as a person in your community rather than as a case. It needs who they were and what you did differently. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | H3, J2 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Scaffold: a problem you found and stayed with to the end, even when it sat partly with someone else. It needs the moment you found it and the moment it closed. C3 holds a slot on the spreadsheet (F3). If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | H4, H5 |

## Question bank

### H: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter, even though it was harder for the branch." | VAL | [grounded] | Use the Members First scaffold from the cheat sheet. Use "we" for the branch and "I" for your part. If no time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The question's wording mirrors the value's own text. It is scored |
| H2 | "Tell me about a time something had to be explained twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | If it happened while you trained new tellers on the escalation script, the quote gives you the tellers and the script. **Answer slot:** what had to be explained again, and what you changed, in your own words. If nothing had to be re-explained, say so and pick another time. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It is Plain Words, scored. Training is the nearest material you have |
| H3 | "Tell me about a time you treated a member as a neighbour rather than a number." | VAL | [grounded] | Use the Neighbours, Not Numbers scaffold. Branch managers will recognise a specific story and see through a general one. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Branch managers on the panel make this value especially live |
| H4 | "Tell me about a problem you found that really belonged to another team. What did you do?" | VAL | [grounded] | It tests Own the Fix across a boundary. Use the scaffold: show you kept hold of the problem without taking over the other team's work. If no time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | This is a different angle from C3, so you aren't telling the same story twice in one day |
| H5 | "A branch supervisor finds a complaint problem, but the cause is in the contact centre. Under 'whoever finds the problem keeps hold of it', who owns it?" | CASE | [grounded] | Hold a position. The supervisor keeps hold of the member, and you own getting the cause fixed. Ownership of the member and ownership of the cause can sit with different people as long as both are named. Concede that a value like this needs a clear hand-off, or "keeps hold" becomes "stuck with". This asks about no past | It tests a value applied to your actual mandate. CASE delivery, with VAL content |

### J: Case / Strategist (practice prompts for the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member has complained three times about the same issue: at their branch, then to the contact centre, then in writing. Nobody has resolved it. Take us through what you do." | CASE | [generic] | Run the 20-minute shape. The seam is visible in the scenario itself, so use the first thesis, one owner, and the divergence, which is naming the seam. Close on the reply in plain words and what the branch is told | It is a practice version of the likely case. [generic] because the scenario is invented for rehearsal |
| J2 | "A long-standing member whose branch is closing in the consolidation complains that they're being pushed onto the app. Handle it." | CASE | [grounded] | Members First and Neighbours, Not Numbers are both live here. Start with the member's actual need. Use the anti-pick: don't sell the app to them. Offer the human route the hub will provide, and record the complaint so the consolidation's effect on members shows in the report. Concede that you can't reverse a strategic decision, only how it lands on this member | It joins two strategy points (hubs and digital) with the panel's own branches. Expect it, or something like it |
| J3 | "A small-business member complains that their new loan application has stalled and nobody can tell them why." | CASE | [grounded] | Clarify who holds the application. Give the member a named contact and a date for an update, find out where it stalled, and log it under the new product. Concede that you'd lean on the lending team for the facts | It is a Q1 2027 launch scenario, a likely case variant, rooted in the brief |

### L: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "You'd be coaching our supervisors on escalations. What would you need from us, and what would you bring?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Bring, in your quotes' terms: "the last three years as a branch supervisor," and that you trained new tellers on your escalation script. Need: their view of what a good escalation looks like, and time with their supervisors on real cases. Propose principles rather than claiming to know how their branches work | It is the coaching duty seen from their side. F5's limit applies, so don't describe coaching supervisors as something you've done |
| L2 | "If you thought one of our branches was handling complaints badly, how would you raise it with the manager?" | CASE | [generic] | Show spine and tact together. Bring them the evidence first, in private, as a shared problem. Agree one change and a date to look at it again. Concede that they know their town better than a central report does. This asks about no past | It is a disagreement-with-equals probe, and Own the Fix and Neighbours, Not Numbers meet in it |

### M: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Sixty seconds: why should a branch manager trust someone central with their members' complaints?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause, then anchor: "Six years in retail banking, the last three as a branch supervisor. I handled the branch's formal complaints log." Then say what you'd do, framed as a plan: keep hold of complaints you take on until they're closed, and tell the branch what happened. If they push with "but not across branches," concede plainly: "No, the log I handled was one branch's." Don't fold on what the quote carries | It is a time-boxed version of D1, delivered by the people whose branches you'd work across |
| M2 | "In the case you just did, what if the member refuses every option you offer?" | CASE | [generic] | Hold: stay calm, restate what you can and can't do, explain how they can take it further through Ashgrove's process, and record it. Concede specifically that not every complaint ends with an agreed outcome, and that a good process is one where the member still knows what happens next | It is a predictable follow-up on the case. It tests the hold-then-concede structure |

## Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "What could the new Member Experience Lead do in the first month that would genuinely help your branches?" | Reciprocity. It shows you'd reduce their load, not add to it |
| "When a complaint escalates out of your branch today, what do you hear back?" | It goes straight at the seam the role owns, from their side |
| "What are members in your towns saying about the move to hubs?" | It shows you care about Neighbours, Not Numbers in practice, and it asks rather than assumes |
| "What does a good escalation from one of your supervisors look like to you?" | It gives you their standard before you start coaching against it |
| "Which of the four values is hardest to live up to on your busiest day?" | It opens an honest conversation about the values they've just scored you on |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches | D1, C1, J1, M1 |
| …and the contact centre | B2, D1, H5 |
| Report monthly on complaint volumes and resolution times | G1, G2, E2 |
| Coach branch supervisors on escalations | D3, L1, C2 |
| Work with digital teams on self-service journeys | E1, J2 |
| 4+ years in financial-services customer operations | A1, A4 |
| Experience handling regulated complaints | B1, C1 |
| Confident presenting to senior leaders | B3, D2, C4 |
| Comfortable with Excel reporting | G1 |
| Values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | H1, H2, H3, H4, plus C3 and H5 |
| Strategy: digital, hubs, small-business lending, app-only banks | E1, J2, E2, J3, A2, A5 |

---

## Prohibited claims

This pack won't coach any of these claims, and neither should your rehearsal.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material covers one branch's log, not a process across branches. F1's slot stays inside the log |
| Six years in customer operations | Inflated form of F7, borrowing the JD's vocabulary | F7's quote: "Six years in retail banking, the last three as a branch supervisor." |
| Has worked in a contact centre | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote. The slot asks only what the spreadsheet tracks |
| Your regional manager makes decisions from your analysis | Inflated form of F3: "uses" stretched | F3's quote, which says "uses" and nothing more |
| Advanced Excel reporting | Inflated form of F4 | F4's quote. The slot asks only which tool and what you built into it |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote. The slot stays with the tellers |
| Wrote or designed the escalation script | Inflated form of F5: "our escalation script" | F5's quote, which says you trained people on the script, not that you wrote it. No slot |
| Handled regulated complaints | Inflated form of F8 | F8's quote. The slot asks only what made a complaint formal |
| Has presented to senior leaders | A negative you stated, F9 | "I haven't presented to anyone above regional level." No slot |

---

## Sources

**Provided documents:**

- The JD, pasted in your message.
- Ashgrove's values, pasted from ashgrovecu.org/about/values, copied 12 November 2026. I didn't fetch the page.
- The recruiter's email about the process. Its excerpt establishes all three rounds.
- The 2026 strategy brief, published July 2026, as summarised in your message. I haven't seen the brief itself.
- Your background, from your message.

**Searches and fetches:** none sent.

**Target accounting**

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values you pasted this morning fix the cheat sheet and the VAL questions |
| 2. Ashgrove interview process | skipped | The recruiter's email establishes every round, so it fixes the persona weights and the case build |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief is under six months old and fixes the CO and CASE questions and the grounding brief |
| 4. Interviewer names at Ashgrove | n/a | No names have been assigned, so no query could be formed. That is why the pack has no interviewer read |
| 5. A representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once the recruiter assigns them:** an interviewer read for each round, persona weights based on each person's public professional profile, and one reverse question tied to each person's career path.
- **A real story for each of the four values:** the four cheat-sheet rows, and H1–H4 and C3, go from selection scaffolds to story-mapped answers built on your own words.
- **Your answers to the answer slots:** they would turn F3, F4, F6, F8 and F10 from discovery gaps into quoted evidence, and sharpen B1, B3, G1, E1 and D1. The slots cover what the spreadsheet tracks and which tool you used, what made a complaint formal, whether you've presented at regional level, and any digital or self-service work.
- **How much prep time you have:** a prioritised prep schedule. Until then, start with D1, the case build and the values cheat sheet.
- **Case format details, which take one email to the recruiter:** whether it's given in advance, a discussion or a role-play, and what material comes with it. That information would tighten the 20-minute shape.
- **The full strategy brief text:** the grounding brief would use Ashgrove's own vocabulary and figures instead of four headline points.
- **A deeper research pass:** up to 6 more searches and 2 more fetches, taking several more minutes. It would add recent organisational context, such as news around the hub consolidation, and any published reports on Ashgrove's interviews.
- **A tuesday-dossier.md from the job-underwriter skill:** a ranking of likely objections based on verified evidence, a strategy for each weak area, and a list of claims not to make built by that skill. This pack is complete without it.
