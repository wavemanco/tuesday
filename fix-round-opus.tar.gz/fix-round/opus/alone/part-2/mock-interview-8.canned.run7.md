The pack is written. I'm fixing one formatting slip, then I'll hand it over.
Dara, your prep pack is saved as `Ashgrove_member-experience-lead_interview_pack.md`. It has a separate section for each of your three rounds on 21 November, based on the recruiter's email. I didn't need to ask you anything first or search the web: your JD, values, process email and strategy summary covered it all.

- **The question most worth rehearsing is C1, in the round with the Head of Member Services.** It's the "one branch's complaints log and no contact centre, so why should I take the risk?" objection. The answer gives you a position to hold and a concession to make before they push, with two follow-ups rehearsed.
- **The 20-minute case has its own section.** It gives you a structure you can speak through and three positions to take, each with a concession, tied to Ashgrove's values and its plans to merge branches into hubs and move service online. You don't know the scenario yet, so it's built to work on any escalation.
- **Some of your experience won't stretch to what the JD asks, and the pack says so.** It won't coach you to say you've coached supervisors, presented to senior leaders or worked under a named regulator's rules. Where your background doesn't say, for example what your spreadsheet tracks or whether your log was regulated, you'll find a prompt to answer truthfully in your own words.
- **The values questions are prompts for choosing a story, not stories.** Nothing you've told me yet matches any of the four values. A real story for any of them, or the answer to any of those prompts, would let me firm up those sections. The end of the pack lists what each would improve.

I can play the Head of Member Services on C1, or run the 20-minute case as the panel.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of interviews:** 21 November 2026, three rounds on the same day
**Round 1:** Recruiter, 30 minutes
**Round 2:** Head of Member Services (your future manager), 45 minutes, mostly behavioural
**Round 3:** Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case; this is also the values round, scored against the four values
**Interviewers:** names not yet assigned, so this pack works from their roles only

---

## How to use this pack

This is a **loop pack**. It has one shared fit snapshot, then shared prep for the case and the strategy brief, then a short pack for each round with its own persona weights, questions and reverse questions.

- **Personas** describe *how* a question gets asked: who's asking and in what style.
- **Types** describe *what* gets scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's *published* values |
| EXP | Whether what you've said about your work holds up, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | How you structure and reason through a live problem from the role |

- **Question IDs** go by persona within each round: A and B for round 1; C, D, E and G for round 2; H, J, K and L for round 3. F and I are skipped so they don't get mixed up with the fit-snapshot rows F1 to F9.
- **Provenance labels:** `[grounded]` means it traces to something you or the recruiter provided. `[inferred]` means it's this pack's own reasoning, and the reasoning is named. `[generic]` means a common pattern for this kind of role, with no claim about Ashgrove.
- **The guidance is scaffolding, not a script.** Where a cell says *answer slot*, the pack doesn't know the answer. Answer it truthfully in your own words, and "no, that wasn't me" is always one of the allowed answers.
- **Say the same thing in every round.** The plain acknowledgments in F2 and F8 should be word-for-word the same with the recruiter, the manager and the panel.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material covers one branch's log, not a process across branches, and your words should stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes it likely you'll be asked which parts of the branch's complaint handling were yours to decide. If any were, say which ones and how you decided, in your own words. If the rules were set above the branch and you worked within them, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | No wording closes this gap, and you've already said so. Your words: "I haven't worked in a contact centre." Then say how you'd learn it, as a plan and never as something you've done. Don't add anything to make the gap look smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The spreadsheet is monthly and about complaints. Your material doesn't show whether it counts volumes or resolution times, or that you report from it. Your words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say what it tracks, in your own words. Where you don't know how a figure in it is counted, say so plainly. Keep the quote's verb: your regional manager *uses* it |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Your material shows training tellers on a script, not coaching supervisors, so the words stay at that scope: "I trained new tellers on our escalation script," and "For the last three years I've been a branch supervisor myself." Let the interviewer draw the connection. Answer slot: if, beyond the script training, you helped a teller through a live escalation, tell it in your own words. If the training was the script and nothing more, say so plainly. "Our script" doesn't mean you wrote it |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a time you worked with people who built or changed a member-facing digital or self-service process, and what changed for members as a result. Answer slot: if you've done anything like that, in any form, say what it was and what your part was, in your own words. If you haven't, say so plainly, then say how you'd approach it |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | There's no gap on length: six years against the four asked for. Say it in your own words ("six years in retail banking, the last three as a branch supervisor") and let them map it onto "customer operations". Don't relabel it in their terms |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | "Formal" may or may not mean regulated, and the pack reads it the cautious way. Answer slot: say what made a complaint formal and what had to be recorded, in your own words, including any deadlines you worked to. If you don't know, or there were no set rules, say so plainly and describe how you handled the log. Don't name a regulator or a deadline you aren't sure of |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You've stated this gap yourself. Your words: "I haven't presented to anyone above regional level." Then say how you'd prepare, as a plan. Your material doesn't say what you *have* presented, so the pack adds nothing about it (see the upgrade menu) |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material says "spreadsheet", not "Excel". Answer slot: name the tool you built it in and what the spreadsheet does, in your own words. Don't list functions or features you don't use |

**Reading the snapshot:** F2 and F8 are the two gaps you stated yourself. F1 and F4 are adjacent work at a smaller scope. F3, F7 and F9 hang on what one spreadsheet and one log actually contain. F1 and F2 together make the **single most likely objection** to you. It gets the deepest rehearsal in the pack at **C1**, which is the highest-ROI prep here. B2 and L1 are shorter versions of the same objection.

---

## Graded deliverable: the 20-minute complaint-escalation case (round 3)

The recruiter announced it, so it's graded. You don't know the scenario yet, so this section builds a structure you can bring to any escalation, then gives three positions to take, each with a concession.

**What you can build on**

| Fact | Source | Provenance |
|---|---|---|
| The role owns "the member complaints process end to end across branches and the contact centre" and says "coach branch supervisors on escalations" | JD | [grounded] |
| The panel "score against the four values": Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Recruiter's email; values page as you pasted it | [grounded] |
| "consolidate eight branches into five hubs over 2027"; "move 40% of member service to digital channels by 2028"; "the main competitive pressure is app-only banks" | Your summary of the July 2026 strategy brief | [grounded] |
| Your side: F1, "I handled the branch's formal complaints log"; F4, "trained new tellers on our escalation script" | Fit snapshot | [grounded] |
| Which complaint rules and deadlines Ashgrove works under: your material doesn't say, so treat it as a clarifying question in the case, not an assumption | Pack observation | [inferred] |

**A spoken structure (about 12 minutes of talking, leaving time for their pushback)** `[generic]`

1. **Clarify (1–2 min).** What does the member want? Where did the complaint start? What have they already been told? Is there anything that makes them vulnerable? Which complaint rules and clock apply here? Ask rather than assume.
2. **The member today.** Who contacts them and when. One named owner. Plain words about what happens next.
3. **Contain.** Stop the harm recurring for *this* member while the fix is worked out.
4. **Resolve and respond.** What you can decide, what you'd escalate and to whom, and the response written so it doesn't need explaining twice.
5. **Root cause.** Where it broke, especially if it fell between the branch and the contact centre.
6. **Record.** How it goes into the log and the monthly report.
7. **Coach.** What the supervisor who escalated it should do differently next time, and how you'd agree that with their branch manager.
8. **Close** on what the member gets and when.

**Three positions to take, each with its concession**

| Thesis | Values it lands | Mandatory concession |
|---|---|---|
| T1. One owner from first contact to close: the member never hears "call the other team" | Own the Fix; Members First, Always | Holding the complaint doesn't mean doing everything. Specialist teams still have to act, and one owner mustn't become a bottleneck |
| T2. An escalation is a coaching moment for the supervisor, not just a handoff upward | Own the Fix (the JD's coaching line) | Some complaints have to leave the branch straight away, for example where the rules or a member's vulnerability require it. Coaching comes afterwards, not during |
| T3. Every escalation is evidence for the monthly report and for the self-service journey that caused it | Members First, Always (the JD's digital and reporting lines) | Neighbours, Not Numbers: the member hears about *their* fix, not about your dashboard. The data work happens after they're sorted |

**How to stand out** `[generic]`. The standard answer is acknowledge, apologise, investigate, resolve, follow up. Use it to show you know the basics, then go further in two ways:

- Name the **seam between branch and contact centre** as where escalations fall, and say what you'd change there. Present it as a hypothesis you'd test, not as knowledge of Ashgrove's current setup.
- **Things to avoid saying:** don't promise compensation or an outcome before you have the facts, and don't steer the member to the app as the resolution.

**The close.** The recruiter named no required close. Ending on the member's outcome in plain words gives the panel two values in one sentence `[inferred]`.

**Your own experience in the case.** You can mention it once, quoted at its own scope: "At branch level I trained new tellers on our escalation script." Nothing in the case needs more than that.

---

## Grounding brief: the July 2026 strategy

This is built from the four points you summarised, not the full brief. The brief is four months old. If the panel quotes newer plans or figures, follow theirs without correcting them.

| Item | What it says (your summary) | Words to use | Where it touches this role | Provenance |
|---|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | "digital channels"; the JD's "self-service journeys" | `[inferred]` New channels can create new kinds of complaint, and the JD links this role to the digital teams. That's E1 and C5 | [grounded] |
| Consolidation | "consolidate eight branches into five hubs over 2027" | "hubs" | `[inferred]` It falls inside your first year, and your panel are branch managers. That's J2, L2 and a reverse question. Don't guess which branches are affected | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" | "small-business lending" | `[inferred]` A new product likely brings new complaint categories into the monthly report. Worth one reverse question, not a whole answer | [grounded] |
| Competition | "the main competitive pressure is app-only banks" | "app-only banks" | `[inferred]` As *your view*, not a fact: how complaints get handled is one place a member-owned organisation can differ. Say it as a hypothesis | [grounded] |
| Who they are | "member-owned, about 900 staff" | "members", never "customers" | `[inferred]` Ashgrove's own words all say "member", so use it | [grounded] |

---

# Round 1: Recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly chat: your journey, why Ashgrove, logistics | High. A recruiter screen is mostly this, and 30 minutes leaves little room for anything else | Have a 90-second arc ready (A1). Treat casual questions on JD topics (Excel, reporting) as scored |
| Skeptic (light) | Quick checks on the gaps: contact centre, presenting to senior leaders | Medium. The JD lists both, and a screen is where knockout checks happen | Short plain acknowledgments, word for word what you'll say in rounds 2 and 3 (F2, F8) |

Have your notice period and salary expectations ready, one sentence each.

### Question bank: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc that uses only what the quotes state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log, trained new tellers on your escalation script, and built the monthly complaints spreadsheet your regional manager uses. Close with why this role, and why now, in your own words. Keep your own verbs ("handled", "trained", "built") and don't swap them for the JD's "own" or "coach" | Every round can open with this, and the recruiter's version sets the story the later rounds hear. It draws on F6, F1, F4 and F3. EXP because it's a work-history walkthrough in a casual register |
| A2 | "Why Ashgrove, and why now?" | CO | [grounded] | Two beats: one of the four values, by its exact name, and one item from the strategy brief, each tied to a line of the JD. Then your real reason for moving, in your own words. If being member-owned is part of the appeal, say why. If it isn't, don't claim it is | This is the recruiter's motivation check. CO because it scores how well you've done your homework. The guidance makes no claim about your past |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Give the four brief items one sentence each, in the brief's terms. Then pick one and say what you think it means for complaints, as your view and framed as something you'd want to test. Don't claim inside knowledge | The recruiter sent you the brief, so not having read it would show. CO |
| A4 | "How are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the spreadsheet in the quote's terms. Answer slot: the JD's "Excel reporting" makes a follow-up on the tool and what's in it likely. Name the tool you built it in and what it does, in your own words. If parts of it are beyond what you use, say so plainly and stay with what you built | This is F9's slot, and a JD requirement asked casually is still scored. JD |
| A5 | "Tell me about that complaints spreadsheet." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what it is and who uses it: it's monthly, it's about complaints, and your regional manager uses it. Answer slot: the JD's "complaint volumes and resolution times" makes a probe on what it counts likely. Say what it tracks, in your own words. If you don't know how a figure in it is counted, say so plainly. Keep "uses": the quote says your regional manager uses it, nothing more | F3 is your closest match to the reporting line, so expect to be asked about it in more than one round. EXP because it tests what was actually yours |

### Question bank: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role covers the contact centre as well as branches. What's your contact-centre experience?" | JD | [grounded] "Never worked in a contact centre" | Keep it short and plain: "I haven't worked in a contact centre." Then one sentence of plan, for example how you'd learn its complaint path early by sitting with agents and following complaints that move between branch and phone. Then stop. Use the same words in every round | F2 is a stated gap a screen will check. JD because it scores a stated responsibility. `[inferred]` Consistency matters because the recruiter's impression is likely to travel to the next rounds |
| B2 | "You're a branch supervisor. This role runs complaints across branches and the contact centre. Why are you ready for that step?" | JD | [grounded] "the last 3 as a branch supervisor" "I handled the branch's formal complaints log" | A short version of C1. Say what you did in the quotes' terms: three years as a branch supervisor, handling the branch's formal complaints log. Then name the limit before they do: the log was one branch's, and "I haven't worked in a contact centre." Then why you want the step, in your own words. Don't say you've already done the bigger job | This is the recruiter's light check on F1 and F2. Rehearsing it here means round 2 isn't the first time you say it out loud. JD |
| B3 | "The role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan, as a plan: how you'd prepare for the first one, for example agreeing with the Head of Member Services what the audience needs and rehearsing with them. Don't add what you *have* presented, because your material doesn't say | F8 is a stated gap. JD |

### Reverse questions: round 1

| Question | Why it lands |
|---|---|
| "For the 20-minute case, will I get the scenario on the day or in advance, and is it a discussion or a presentation?" | It's a process question and its answer changes your prep. Recruiters can answer it |
| "Is this a new role or a backfill?" | It tells you whether you'd be building the complaints process or inheriting one, which shapes how you pitch F1 in round 2 |
| "Which complaint-handling rules does the role work under day to day? Will the case assume I know them?" | It closes the F7 gap honestly before round 3 instead of guessing during it |
| "What does the Head of Member Services most want this hire to fix first?" | It gives you round 2's agenda from someone who has heard it |
| "What happens after 21 November, and when would I hear?" | Plain logistics, which shows you're organised |

---

# Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gap between one branch and the whole organisation, the contact centre, and presenting upward | High. A hiring manager is paying to reduce risk, and F1, F2 and F8 are the visible risks | C1 rehearsed until it bores you. Hold on the quotes, concede the stated gaps first, then give a plan |
| Values / Behavioral | "Tell me about a time…" stories | High. The recruiter said this round is "mostly behavioural" | Pick your stories in advance using the scaffolds. "We" for context, "I" for what you did. Use the honest branch where no story exists |
| Case / Strategist | Live problems from the manager's own agenda: the digital shift, rising volumes | Medium. A hiring manager usually brings some, but "mostly behavioural" lowers it | Clarify, then structure, then answer, using the brief's words |
| Data-Driven Prober | What the spreadsheet measures and how | Low to medium. The JD's monthly reporting and Excel lines invite it | Know what you can and can't say about how each figure is counted. Name your weakest figure first |

### Question bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've handled one branch's complaints log, and you've never worked in a contact centre. This job owns the whole process across branches and the contact centre. Why should I take the risk?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre" "the last 3 as a branch supervisor" | **The highest-ROI prep in this pack.** **Hold:** "For the last three years I've been a branch supervisor. I handled the branch's formal complaints log, and I trained new tellers on our escalation script." **Concede before they push:** "The log I handled was one branch's, and I haven't worked in a contact centre." **Answer slot:** the JD's end-to-end line makes it likely you'll be asked which parts of the branch's complaint handling were yours to decide. If any were, say which ones and how you decided, in your own words. If the rules were set above the branch and you worked within them, say so plainly and stay with the log. **Ramp, as a plan:** what you'd learn in the first months, and from whom. **Follow-up 1**, "What if most complaints come through the contact centre?": "I don't know the split yet. What is it?" Then say how you'd learn that path. **Follow-up 2**, "Wouldn't someone from a contact centre be the safer hire?": hold the quotes, admit the specific learning curve, and don't run down the other candidate | F1 and F2 together are the widest gap between your material and the JD, and a manager hiring for this role will press right there. JD because it scores the end-to-end requirement head-on |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Pick one and name it plainly: either "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level." Then give the plan for it, as a plan. Pick the one you'd honestly pick. Don't dress it up, and don't list both plus three more | A standard Skeptic question, and F2 and F8 give you an honest answer that's already worded. JD |
| C3 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | Built on F1 and F7: the log was the branch's, and it was formal. Tell how you handled it, in your own words. Answer slot: the JD's "regulated complaints" makes a probe on what made a complaint formal and what had to be recorded likely. If you know, say it in your own words, including any deadlines you worked to. If you don't know, or there were no set rules, say so plainly and describe how you handled the log. Don't name a regulator or a deadline you aren't sure of | F1 and F7 both rest on this one sentence, so expect it in some form in every round. EXP |
| C4 | "Have you worked with digital teams on self-service journeys?" | JD | [grounded] | Answer slot: the JD names this. If you've worked with a digital team, or on any self-service process for members, say what it was and what your part was, in your own words. If you haven't, say so plainly, then say how you'd approach it: what you'd want to know from the digital team first, and what complaints could tell them. Don't stretch branch work into "digital work" | Your material says nothing on F5, and the strategy makes this line central. JD |

### Question bank: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you helped someone handle an escalation better." | JD | [grounded] "trained new tellers on our escalation script" | Built on F4: new tellers, the escalation script, and your training. Answer slot: the JD's coaching line makes a probe on one specific escalation likely. If, beyond the script training, you helped a teller through a live escalation, tell it in your own words. If the training was the script and nothing more, say so plainly and describe how you trained. Keep it about tellers | F4 is close to the requirement but doesn't match it, and the manager will test how far it stretches. JD content, behavioural delivery |
| D2 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Scaffold for choosing a story: a named stake, what you said and to whom, what happened next, and a working relationship still intact afterwards. "We" for context, "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural question. A manager who'll put you in front of senior leaders (F8) wants evidence you can carry bad news upward. VAL because it's a behavioural story about a value |
| D3 | "Tell me about a complaint that went badly. What did you learn?" | VAL | [generic] | Scaffold for choosing a story: one complaint, what went wrong, your part in it, and what changed afterwards. Say plainly what was yours. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It tests honest self-assessment. VAL because it probes Own the Fix and Members First, Always |
| D4 | "Tell me about a problem you spotted that wasn't strictly your job to fix." | VAL | [grounded] | Scaffold on Own the Fix ("whoever finds the problem keeps hold of it until it is solved"): the problem, how you found it, how you kept hold of it, and whether it got solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme is Ashgrove's own published wording, which is why the label is `[grounded]`, though the guidance makes no claim about your past. The panel asks this value directly (H4), so use a different story here if you have two |

### Question bank: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints, and what would you do first?" | CO | [grounded] | Structure it out loud. **Clarify:** which services move first, and how complaints from digital channels get logged today. **What might change for members**, as hypotheses: new places to get stuck, and fewer people to ask. **First moves:** make complaints about digital journeys visible in the monthly report, and agree with the digital teams how they'll hear about them. **Risk:** members who can't or won't move to digital. Name Members First, Always once. No claim about your past is needed | This is where the strategy's headline target meets the JD's digital line. CO because it scores strategy fluency, delivered as a case |
| E2 | "Complaint volumes are up across the branches this quarter. Where do you start?" | CASE | [generic] | Clarify before you diagnose: up compared with what, counted the same way as before, in which branches, through which channels, about which complaint types. Then split it: one cause or several; a product change, a process change, a branch change, or a change in how complaints are recorded. Then say what you'd do this month and what you'd report. Name the weakest assumption in your own diagnosis before they do | A diagnosis case built on the JD's monthly reporting line. `[generic]` because it's a common pattern, not Ashgrove data |

### Question bank: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What does your monthly complaints spreadsheet actually measure?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: the JD's "complaint volumes and resolution times" makes probes on what it counts, and how, likely. Say what it tracks and how each figure is counted, in your own words. Say plainly where you don't know how something is counted. Name the figure you'd defend least before you're asked. Don't describe a measure it doesn't have | This is where the JD's reporting line meets F3, in a register that asks for definitions. EXP |
| G2 | "Who uses it, and what do they use it for?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The quote answers the first half: your regional manager uses it. Answer slot: if you know what they use it for, say so in your own words. If you don't, say that plainly, and don't guess at decisions it may have fed into | A follow-up to G1 that tests how far F3 reaches. EXP |

### Reverse questions: round 2

| Question | Why it lands |
|---|---|
| "Where does the complaints process break most often today: in branches, in the contact centre, or in the handover between them?" | It shows you're thinking about where F1 and F2 meet, and the answer tells you what the job really is |
| "What would you want the monthly report to tell you that it doesn't today?" | The answer is the brief for the reporting line, from the person who reads the report |
| "Who would this role present to, and how often? How do you support someone stepping up to that?" | It faces F8 openly and turns a stated gap into a conversation about how you'd develop |
| "How will the 2027 move to hubs change how complaints are handled, and where does this role sit in that?" | It ties the role to the strategy without assuming the answer |
| "What would a strong first 90 days look like to you?" | It gives you the manager's own measure of success |

---

# Round 3: Panel of two branch managers (60 minutes, including the 20-minute case; values scoring)

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One question per value, scored against the four values | High. The recruiter said the panel "score against the four values" | Use the cheat sheet below. Choose specific decisions, not slogans. Use each value's exact name at most once per answer |
| Case / Strategist | The 20-minute complaint-escalation case | Certain. The recruiter announced it | See the graded-deliverable section above. Clarify first, then the member, then root cause, then the record, then coaching |
| Peer Evaluator | "What would you need from us?" and "How do you work with my supervisors?" | Medium. `[inferred]` The panel are branch managers, and the JD's coaching line points at branch supervisors, who probably sit in their teams | Frame it as what you'd give them as well as what you'd ask. Propose working principles rather than pretending to know their branches |
| Pressure | A sharp push on consolidation or on the contact-centre gap | Low to medium. `[inferred]` Branch managers during a consolidation year may push on Neighbours, Not Numbers | Hold, then concede: return to members and to what your quotes say |

### Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's point of view, not the organisation's | Scaffold for choosing a story: one member situation (no identifying details), the decision you made, what it cost the branch or you, and the outcome for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If something needs explaining twice, the explanation was the problem | Scaffold: what was being explained, to whom, what you changed, and whether it landed. Watch which side of the counter you're on. F4's "trained new tellers on our escalation script" is explaining to staff, not to members, so use it only if you say so. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Each branch belongs to its town, and members aren't case numbers | Scaffold: a time knowing the local community changed how you handled a member or a complaint. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem stays with it until it's solved | Built on F3, "I built the monthly complaints spreadsheet our regional manager uses.", plus an answer slot: this value raises the question of why it was built. If it was built to fix something you found, say what, in your own words. If you were asked to build it, or you don't know why it was needed, say so plainly and choose another story |

### Question bank: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell us about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Use the cheat-sheet scaffold for Members First, Always. "We" for context, "I" for the decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Scores the first value directly, in the value's own wording |
| H2 | "Tell us about a time something had to be explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Use the cheat-sheet scaffold for Plain Words. If you use the teller training, say clearly that it was explaining to staff. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plain Words is scored here. F4 is nearby material but sits on the staff side, which is why the guidance flags it |
| H3 | "Tell us about a time knowing the local community changed how you handled a member." | VAL | [grounded] | Use the cheat-sheet scaffold for Neighbours, Not Numbers. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Two branch managers scoring this value during a consolidation year will listen closely. VAL |
| H4 | "Tell us about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Use the cheat-sheet entry for Own the Fix, including its answer slot on why the spreadsheet was built. If that slot's honest answer is "I was asked to build it", choose another story or give the honest branch | Own the Fix is the value closest to the JD's "own the … process" line. VAL |

### Question bank: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | Practice version of the case: "A member's payment failed and they were charged a fee. The contact centre told them it's a branch problem, and the branch told them to call the contact centre. They're in the branch now, angry, saying they'll move to an app-only bank. Walk us through it." | CASE | [generic] | Run the spoken structure from the graded-deliverable section, taking one of T1, T2 or T3 with its concession. Ask which complaint rules apply rather than assuming them. Close on what the member gets and when, in plain words. No claim about your past is needed, apart from at most one quoted line from F4 | A rehearsal scenario built around the seam the JD names (branches and the contact centre) and the competitive pressure in the brief. `[generic]`: the real scenario is unknown |
| J2 | Practice version: "Same member, but the complaint is that their branch is closing into a hub next year." | CASE | [grounded] | Listen first. Don't defend the strategy beyond what you're responsible for, and don't apologise for it either. Say what you can own: their access, what changes for them and when, and who they can call, all in plain words. Log it so it reaches whoever runs the consolidation. Neighbours, Not Numbers is the value being tested | The scenario rests on the brief's hub consolidation. CASE |

### Question bank: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You've been a branch supervisor. What would you need from branch managers to make the complaints process work?" | JD | [grounded] "the last 3 as a branch supervisor" | Frame it both ways: what you'd ask for and what you'd give back. From the quote: three years as a branch supervisor, and let them draw what that means. Answer slot: if, as a supervisor, there was something about escalations you needed from your branch manager, say what, in your own words. If nothing comes to mind, say so plainly and say what you'd ask for here. Then offer what they'd get from you, for example a monthly picture of their branch and one person to call | Tests whether you'd add to their workload or reduce it. JD, through the coaching line |
| K2 | "One of my supervisors escalates every complaint to you. How do you handle it without going around me?" | CASE | [generic] | Principle first: the branch manager hears from you before anything changes. Then: look at which complaints, why they're being escalated, and what the script allows; coach the supervisor with the manager's agreement; and agree a threshold together. Don't claim to have handled this before | The point where the role and the panel's teams meet. CASE |
| K3 | "When your monthly report makes my branch look bad, how do you handle that with me?" | CASE | [grounded] | No surprises: they see it before anyone else does. Give context alongside the number. Neighbours, Not Numbers: talk about the members behind the figure. Agree what you'll each do next. No claim about your past is needed | Combines the JD's reporting line with a published value. CASE |

### Question bank: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you over someone from our contact centre?" | JD | [grounded] "the last 3 as a branch supervisor" "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre" | It's time-boxed, so pause first, then give three points in the quotes' terms: branch supervisor for three years, the branch's formal complaints log, and training new tellers on the escalation script. Then the concession in the first person: "I haven't worked in a contact centre." Don't run down the other candidate. If interrupted, go back to the quotes, not to new claims | The C1 objection in a faster, sharper register, aimed at F2. JD |
| L2 | "Moving members to digital and closing branches: isn't that the opposite of 'Neighbours, Not Numbers'?" | CO | [grounded] | Hold your view, then concede what you don't know. Don't attack the strategy and don't recite it. Acknowledge the tension plainly. Say where you'd stand: making sure that whatever consolidation and the digital shift break for members shows up as complaints and gets fixed. Admit what you don't know, such as how the hubs will work locally. If they push a second time, return to members, not to the strategy document | Tests strategy fluency under pressure, in front of the people the strategy affects. CO |

### Reverse questions: round 3

| Question | Why it lands |
|---|---|
| "What do your supervisors find hardest about escalations today?" | It's the coaching brief, from the people closest to it |
| "What could this role do in its first month that would actually make your week easier?" | It shows you'd reduce their workload, not add to it |
| "When a complaint about your branch comes in through the contact centre, how do you hear about it today?" | It goes straight at the branch and contact-centre seam |
| "How are members in your towns responding to the plans for hubs?" | It's Neighbours, Not Numbers asked as a question, and it's respectful of their position |
| "Which of the four values do complaints test most often here?" | It invites them to talk about the values in their own words, which is useful for you and for their scoring |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches (F1) | B2, C1, C3 |
| …and the contact centre (F2) | B1, C1, L1 |
| Report monthly on volumes and resolution times (F3) | A5, G1, G2, E2, K3 |
| Coach branch supervisors on escalations (F4) | D1, K1, K2 |
| Work with digital teams on self-service journeys (F5) | C4, E1 |
| 4+ years in financial-services customer operations (F6) | A1, B2 |
| Experience handling regulated complaints (F7) | C3, J1 |
| Confident presenting to senior leaders (F8) | B3, C2 |
| Comfortable with Excel reporting (F9) | A4, G1 |
| Four published values | H1 to H4, D4 |
| Strategy brief | A3, E1, J2, L2 |

---

## Prohibited claims

These are claims the pack will not coach you to make, built from the fit snapshot. They're the ones most likely to slip out under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process, or ran complaints across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material covers one branch's log. The C1 and C3 slots stay inside that log |
| Contact-centre experience of any kind | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Coached or trained branch supervisors | Inflated form of F4 | F4's quotes: you trained new tellers, and you were a branch supervisor. D1's slot stays with the tellers |
| Wrote or designed the escalation script | Inflated form of F4 ("our escalation script") | F4's quote at its own scope: you trained tellers on it |
| Presented or reported complaints data to the regional manager | Inflated form of F3 | F3's quote: you built the spreadsheet your regional manager uses. The G2 slot stays with what you know about its use |
| Handled complaints under a named regulator's rules | Inflated form of F7 | F7's quote at its own scope: the branch's formal complaints log. The C3 slot asks what made a complaint formal, without naming a regulator |
| Presented to senior leaders | A negative you stated, F8 | "I haven't presented to anyone above regional level." No slot |

---

## Sources

**Provided documents**
- The JD, pasted in your message
- Ashgrove's values, pasted in your message, copied 12 November 2026 from ashgrovecu.org/about/values (not fetched; the pasted text was used)
- The recruiter's email about the process, pasted in your message
- Your four-point summary of the July 2026 strategy brief the recruiter sent (the full brief wasn't provided)
- Your background, from your message
- No dossier was provided or consumed

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values you pasted this morning already fix the cheat sheet's names and definitions |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email already fixes the three rounds, who runs each one, the case and the values scoring, and so the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief is under six months old and already fixes the CO questions and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names have been assigned, so there was no query to run. The interviewer read is left out, and the upgrade menu says what names would add |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned →** a read of each interviewer's public professional footprint, personas assigned per panel member, and a reverse question tied to each person's own career path
- **Which complaint rules and deadlines your branch log was kept under, and whether you know Ashgrove's →** F7 and C3 move from answer slot to a mapped story, and the case structure can name the clock instead of asking about it
- **What the spreadsheet tracks, and which tool it's built in →** F3 and F9, A4, A5, G1 and G2 move from answer slots to mapped stories
- **Whether you've presented at regional level, to whom, and about what →** a real bridge for F8, B3 and C2, beyond the plain acknowledgment
- **A real story for any of the four values →** H1 to H4 and D2 to D4 move from scaffolds to mapped stories, the part of the panel that's actually scored
- **Any contact you've had with digital or self-service work, however small →** F5 and C4 move from silence to evidence, or a clean "no"
- **How many hours you have before 21 November →** a prioritised prep schedule sized to that time
- **The full strategy brief text →** a fuller grounding brief, with its own figures and vocabulary beyond your four points
- **Any detail from the recruiter on the case format (in advance or on the day, discussion or presentation) →** a sharper build for the graded deliverable
- **Deep research (L2): up to 6 more searches and 2 more fetches, several more minutes →** Ashgrove news since July, any published complaints or annual-report figures, and the regulatory context the case may assume
- **A dossier from job-underwriter →** an objection drawn from verified evidence instead of inferred, plus strategy constraints for each weak area
