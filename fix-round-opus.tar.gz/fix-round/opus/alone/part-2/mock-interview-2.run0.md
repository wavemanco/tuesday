Web search was blocked, so I'm building the pack from your message alone, with each section labeled to show what it rests on. Writing it now.
Your prep pack is saved as /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-2-denied-b9f9392f/AtlasFreight_operations-manager_interview_pack.md.

I couldn't look Atlas Freight up because web search permission was declined. So the pack works only from what you sent me. It doesn't say anything about the company's values, interview process or recent news. And because I don't know who you're meeting, it prepares you equally for seven interviewer styles: about three questions each, 21 in total.

**What's in it:**
- **Where you match the job description, and where you don't.** Each requirement is set against your own words, with the gap named.
  - **Your strongest points:** the green belt, the 40% mis-pick cut, and running the peak-season surge plan two years running.
  - **Your widest gaps:** you lead 3 supervisors at one site, and the role is 12 across four sites. You also come from warehousing rather than terminals.
  - **No evidence yet:** your message says nothing about on-time performance, cost-per-shipment, or reports you've built in Excel.
- **The question most worth practising is A1:** "You manage three supervisors at one site. This role is twelve across four terminals. Why are you ready?" The pack helps you admit the gap plainly and then give a 90-day plan, without making your current scope sound bigger.
- **Power BI:** you said you've never used it, so the pack gives you a straight way to say that ("I haven't used Power BI"), followed by a learning plan.
- **The five-years requirement:** your message doesn't say how many of your 7 years were spent leading people. Work that number out before the interview. If it's under five, say the real number. The pack has a question (A4) for this.
- **Where the pack doesn't know your story**, it leaves a gap for you to fill from what actually happened. Each gap includes an honest option for when the answer is "no" or "I don't know".

If you'd like to practise, I can play the sceptical interviewer and ask you A1, with follow-ups that react to your answers. I can also save the gaps this prep found to a tuesday-dossier.md file you can bring to later sessions, or convert the pack to a Word document.

1. Who are you meeting: the hiring manager, other site managers, HR, or a panel? If the recruiter mentioned specific topics or a presentation, tell me. This changes which questions get the most attention.
2. Do you want me to research Atlas Freight? If you allow web search, I'll look up their values, interview process and recent news. I can also do a deeper pass (up to 6 more searches and 2 page reads, a few more minutes) covering their strategy and recent changes in the company.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack — Operations Manager, Atlas Freight

Role: Operations Manager. Company: Atlas Freight, regional logistics, 800 employees, per the JD. Interviewer: unknown, and so is the round type. This pack is built for a full loop with flat persona weights. That makes it weaker than a pack aimed at a known interviewer, and the upgrade menu at the end says what would sharpen it.

## How to use this pack

Two axes. **Personas** describe how a question is asked: who is asking, and in what style. **Types** describe what is being scored:

- **JD**: can you do the job as listed, including its gaps
- **EXP**: does your experience hold up under scrutiny, and what was actually yours
- **CASE**: a live problem from the role, solved out loud
- **VAL**: behavioral stories, matched to a company's published values where those are known
- **CO**: company knowledge and motivation

Provenance labels: `[grounded]` means it traces to your message or the JD. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a pattern for the role family, with no claim about you or Atlas Freight.

The guidance is scaffolding, not a script. Where a cell says **Answer slot**, the pack does not know the answer. Fill it in from what actually happened, in your own words, or use the honest branch it gives you.

Question IDs run by persona: A, B, C, D, E, G, H. There is no persona F, so no bank ID collides with the fit-snapshot rows F1 to F8.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows one site, a shift-level role, and a warehouse-and-distribution setting rather than a terminal. The words stay at that scope: "I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: with the JD's four-site line, a probe on multi-site work is likely. If any of your work has reached beyond your own site, say what it was and how it worked, in your own words. If none has, say so plainly and stay with your own site and role. Describe your operation in its own terms, not in terminal vocabulary |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | Both quotes touch operational performance. Neither says what happened to on-time performance, so don't stretch the bridge. Answer slot: if the surge plan or the pick-path work tracked an on-time or service measure, say which one and what it showed, in your own words. If neither did, or you don't know, say so plainly and describe what the work covered. The 40% belongs to the mis-pick rate and nothing else |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a cost measure you have tracked or moved. Answer slot: the JD makes a cost probe close to certain. If you have tracked or moved a cost measure, say which one and how, in your own words. If you haven't, say so plainly and say what you would look at first in a terminal's cost-per-shipment |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material carries three supervisors. Twelve is a different span, and the words stay at three: "Today I manage three supervisors." Answer slot: expect a probe on leading through supervisors. Say how you lead those three, in your own words. If you have ever covered a wider span, say when and for how long. If you haven't, say so plainly and describe how you would adapt to twelve, as a plan |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" names the tool, not the reporting. Answer slot: if you have built reports that other people used, say what they tracked and who read them, in your own words. If your Excel work hasn't been reporting, say so plainly and say what you do use it for |
| F6 | "Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | Wording can't close this gap, and you've said so yourself. Words: "I haven't used Power BI." Then say how you would learn it, as a plan, never as something already done. Add nothing to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in operations is not seven years leading people, and your material doesn't say how many of the seven were leadership years. This is not a gate. A years requirement is graded like any other, but it is likely to be screened literally. Answer slot: say exactly how many years you have led people, and in which roles. If that is fewer than five, give the number plainly, taking the lower reading wherever a role is ambiguous, and stay with what you led |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. The certification hasn't been inspected, so expect a probe. Lead with it in its own terms: you're green belt certified. Answer slot: with the JD's Lean/Six Sigma line, a "tell me about a project" probe is likely. If you have applied the method to a project, name the project and what was yours, in your own words. If you haven't yet, say so plainly. Don't call the pick-path redesign a green belt project unless it was one |

## Persona table

No round type, interviewer or loop source was given, and the company research didn't run. So the weights below use the **generic archetype** (screen, then hiring manager, then panel) with **flat weights**. That is a pattern, not Atlas Freight's documented process. Every persona gets about three questions so that no style catches you cold.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scope jump: one site to four, three supervisors to twelve, warehouse to terminal | flat. Highest-ROI anyway, because the F1 and F4 gaps are the most visible thing on your profile | Rehearse A1 until it bores you; concede the span, then give a concrete ramp plan, as a plan |
| Case / Strategist | Live terminal problems: on-time drops, cost creep, a 90-day plan | flat. A hiring manager for an ops role usually tests this; the JD's two named metrics are the obvious case material | Clarify, set the objective, segment, approach, metrics, risks; think out loud |
| Data-Driven Prober | Goes after the 40% figure and your reporting | flat. Your only stated figure is the one magnet | Know what you can and can't say about how the 40% was counted; say plainly where you don't know |
| Pressure | Time-boxed challenges, "how much of that was you" | flat. Common in panels for leadership roles | Pause, restate the question, hold on what you actually said through two follow-ups, then concede specifically |
| Conversational | "Walk me through your journey", casual Lean/Six Sigma chat | flat. Opens most rounds, and it is still scored | A 90-second arc built only from your own sentences |
| Peer Evaluator | Other site or functional managers testing how you handle the seams | flat. Four sites means peers who share loads and decisions | Reciprocity: what you'd bring them; principles for the seams, not pretended knowledge of them |
| Values / Behavioral | Classic behavioral stories | flat. Atlas Freight's published values were not fetched, so these are generic stems | Pick real stories; "we" for context, "I" for your part; if no story fits, say so |

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage three supervisors at one site. This role is twelve supervisors across four terminals. Why are you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | **The highest-ROI rehearsal in this pack.** Concede the span first, in your own sentences: "Today I manage three supervisors, and I ran the site's peak-season surge plan two years running." Don't argue that three is like twelve. Answer slot: if any of your current work reaches beyond your own shift or site, say what it is, in your own words. If none does, say so plainly. Then give a first-90-days ramp plan for four sites, as what you would do and never as what you have done. Hold through two follow-ups by going back to those two sentences, never by adding to them. The concession is specific: twelve across four sites is a bigger span than you lead today | F1 and F4 are the widest gaps between your material and the JD, so this objection will come in some form. JD because it scores the stated scope directly |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick a real weakness. You already have honest words for one: "I haven't used Power BI." Then give the learning plan, as a plan. Don't swap in a flattering fake weakness; skeptics hear those instantly. Stop after the plan and don't keep apologizing | F6 is a stated gap. Naming it before they find it turns a gotcha into candor. JD because Power BI is a listed requirement |
| A3 | "Why move from warehousing into terminal operations, and why Atlas Freight?" | CO | [grounded] "7 years in warehouse and distribution ops" | Start from your own sentence: seven years in warehouse and distribution ops. Answer slot: your real reasons for the move, in your own words. If part of it is the step up in scope, say so; it's honest and it fits the role. For "why Atlas", use only what you actually know. The JD says regional, 800 employees, four sites. Add anything you have read about them yourself, and nothing you haven't | Motivation consistency is the Skeptic's core probe. CO because it tests homework, and the pack's company research didn't run, so the homework is yours |
| A4 | "The posting asks for five-plus years of operations leadership. How many years have you led people?" | JD | [inferred] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Answer slot: give the exact count and the roles, in your own words, using the lower reading wherever a role is ambiguous. If it is five or more, say the number and stop. If it is fewer, give the number plainly, then go back to your two sentences: seven years in ops, and three supervisors today. Never round the ops years up into leadership years | F7 is a required line, and you don't want to fumble a literal screen. `[inferred]` because the pack can't tell from your material how the seven years split |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four terminals has dropped over the last month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is measured here, whether it's one site or several, when it started, which lanes or customers. Then segment where time is lost: inbound arrival, dock dwell, sort or handling, outbound departure, carrier handoff. Say what data you'd pull, form two or three hypotheses, test the cheapest first, and name the metric that tells you it's fixed. Close with the risk of fixing on-time by spending cost. The question makes no claim about your past, so the guidance makes none | The JD's on-time line (F2's requirement), asked as a live problem. `[generic]` because it is a pattern, not knowledge of Atlas Freight's network |
| B2 | "Cost-per-shipment is up across the network. Where do you look first?" | CASE | [generic] | Define it out loud: what goes into the cost and what counts as a shipment, because people often mean different things by the same metric. Break it down into labor and overtime, equipment, rework and claims, and volume, since a falling denominator raises cost-per-shipment with no new spending. Compare the four sites to find the outlier. Pick the biggest lever, then check what it does to on-time. Say what you'd report weekly | F3 is your thinnest row. A strong structure here is the most honest way to show capability you haven't yet claimed. JD content, CASE delivery |
| B3 | "Your first 90 days: four sites, twelve supervisors you've never met. What's the plan?" | CASE | [generic] | Days 1 to 30: walk every site, one-to-ones with all twelve, baseline the two JD metrics, learn the existing reporting. Days 31 to 60: one shared reporting cadence, the two or three biggest problems agreed with the supervisors. Days 61 to 90: one visible fix per site, and a Power BI learning milestone, stated as a plan. Say what you won't change before you understand it | This answers A1's worry with a plan instead of a claim. CASE because it is scored on structure |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the result in its own terms: a 40% cut in the mis-pick rate, from redesigning the pick path. Then four answer slots, all in your own words: how the rate was counted, what it is sensitive to, the assumption behind it you'd defend least, and which part was yours. Name that weakest assumption before they do. "I don't know exactly how it was counted" is an honest answer. Never turn the 40% into a cost, speed or on-time figure | Your only stated metric, so a prober goes straight to it. EXP because it tests whether the number holds up |
| C2 | "What did redesigning the pick path involve, and which decisions were yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The verb is yours: you redesigned the pick path. Answer slot: the steps, and which decisions you made, in your own words. Where others did parts of it, name them and their share. If any step you'd expect isn't something you did, say so plainly. Answer slot: with the JD's Lean/Six Sigma line, they may ask whether this was a structured improvement project. If it was, say how; if it wasn't, say so | It checks what was actually yours behind the figure, and it connects to F8. EXP primary, JD second |
| C3 | "This role builds reporting in Excel and Power BI. What does your Excel work look like today?" | JD | [inferred] "solid Excel" "never used Power BI" | Answer slot from F5: if you build reports others use, say what they track and who reads them; if your Excel work isn't reporting, say what it is. Then the Power BI line, in your own words: "I haven't used Power BI." Follow it with the plan. Don't describe a dashboard or a report you haven't built | The JD's reporting requirement against two thin rows, F5 and F6. `[inferred]` because "solid Excel" leaves the reporting part open |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's already run a multi-site terminal operation?" | JD | [grounded] "7 years in warehouse and distribution ops" "ran the site's peak-season surge plan two years running" "cut mis-pick rate 40% by redesigning the pick path" | Pause, then use the time. Don't knock the other candidate. Name what your sentences carry: seven years in warehouse and distribution ops, the site's surge plan two years running, the pick-path redesign and its 40%. Add one forward-looking reason, in your own words. Finish inside the minute. If they push, hold on those facts, then concede the multi-site gap specifically | Time-boxed comparison is the standard pressure move for a step-up candidate. JD because it scores fit against the stated scope (F1) |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold, then concede. Hold on your sentence: you redesigned the pick path. Answer slot: name who else contributed and what they did, in your own words. If it was mostly you, say so calmly; if it was a shared effort, say your part exactly. Hold through two follow-ups. Concede only what is true, and don't shrink it just to restore harmony | Attribution is the most common pressure probe on a headline number. EXP because what was yours is the thing scored |
| D3 | "You've never used Power BI, and we need reporting from week one. Isn't that a problem?" | JD | [grounded] "never used Power BI" "solid Excel" | Concede the fact without flinching: "I haven't used Power BI." Hold on what you do have, in your own words: solid Excel. Then the plan, as a plan: what you'd learn first and by when. Answer slot: if you've already started learning it, say what you've done; if you haven't, don't imply you have | F6 is a stated gap the interviewer can press hard. The premise is your own stated negative, so it's fair game |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc from your own sentences only: seven years in warehouse and distribution ops; senior shift manager over three supervisors today; the pick-path redesign and its 40% mis-pick cut; the site's surge plan two years running; green belt. Answer slot: how you got into operations and why you want this step, in your own words. End on why this role, in one sentence | It opens almost every round, and economy is scored. EXP because it previews which claims they'll probe |
| E2 | "Are you doing anything with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Treat this as scored even though it's casual. Lead with the certification. Answer slot from F8: if you've applied it to a project, name the project and your part; if you haven't yet, say so plainly and say where you'd apply it at Atlas, as an idea rather than a promise | A JD plus-skill asked casually is a classic rapport-round trap. JD because it maps to the stated plus |
| E3 | "What's a peak season like for you?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on your sentence: the surge plan, at your site, two years running. Tell it in your own words. Answer slot from F2: with the JD's on-time line, expect a follow-up on what happened to on-time or service under the plan. If you know, say what it showed; if it wasn't tracked or you don't know, say so and describe what the plan covered | Your strongest scope story, and the natural place for an on-time probe. EXP because it tests what you did |

### G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites share loads. When a late shipment crossed two terminals, how do you decide whose problem it is?" | CASE | [generic] | Propose a principle rather than a verdict: fix the customer issue first, then sort out the root cause. Agree on one shared definition of late, and settle ownership in a standing review rather than in the moment. Say what you'd want from the other site manager and what you'd offer them. No claim about your past is needed | Four sites means seams between peers; this tests turf awareness. CASE because it is a live scenario |
| G2 | "Tell me about a time you disagreed with another manager. How did it go?" | VAL | [generic] | Selection scaffold: pick a time you disagreed with a peer manager on something that mattered, held your view with reasons, and kept the working relationship. Show both spine and tact. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing you have or how you would handle it | A persona stem; disagreement style with equals is what peers score. VAL because it's behavioral |
| G3 | "What would you need from the other site managers in your first month, and what would you bring them?" | CASE | [generic] | Reciprocity first. What you'd bring: a shared view of the two JD metrics across sites, and an open door to compare notes. What you'd need: their read on what works at their site and where the reporting falls short. Keep it to two items each | It tests whether the hire reduces or adds to a peer's load. CASE because it is forward-looking |

### H — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, what you said, and whether it landed. If it didn't land, say so rather than supplying a happy ending. If no such time comes to mind, say so plainly, then give the nearest thing you have or how you would handle it | A persona stem. Atlas Freight's published values weren't fetched, so this is generic behavioral coverage |
| H2 | "Tell me about a time a supervisor on your team was struggling. What did you do?" | VAL | [generic] | Selection scaffold: pick a real case with one of your supervisors. It needs what you noticed, what you did, and the outcome, including if it didn't work. "I" for your actions. If no such time comes to mind, say so plainly, then describe how you would handle it | The JD's twelve-supervisor line (F4's requirement) makes coaching supervisors a likely theme. VAL because it's behavioral |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, B1, B3, D1, G1 |
| "drive on-time performance" | B1, E3 |
| "cost-per-shipment down" | B2 |
| "lead a team of 12 supervisors" | A1, B3, H2 |
| "build reporting in Excel" | C3 |
| "Power BI" | A2, C3, D3 |
| "5+ years operations leadership required" | A4 |
| "Lean/Six Sigma a plus" | E2, C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured across the four sites today, and where is it weakest?" | It shows you think in the role's metric, and the answer tells you where the job's pressure sits |
| R2 | "What's included in cost-per-shipment here, and what's the biggest driver right now?" | It shows you know a metric is only as good as its definition, which is B2's whole point |
| R3 | "What reporting exists today, and what would you want built first?" | It turns the Power BI gap into a forward conversation about what they actually need |
| R4 | "What separates supervisors who do well here from those who struggle?" | It signals you're already thinking about leading the twelve |
| R5 | "What would make the first six months a success in this role?" | It gets you the real scorecard, which you can then answer against in later rounds |
| R6 | "Where does friction usually show up between the sites?" | It shows awareness of the seams, and the answer is gold if you meet a peer next |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run multi-site or terminal operations | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says the site, at shift-manager level, in warehouse and distribution. A1's slot stays inside your own work |
| Has led a team of supervisors at the JD's scale | Inflated form of F4 | F4's quote at its own scope: three supervisors. The limit is the pack's observation, not a line for you to say |
| The surge plan improved on-time performance | Inflated form of F2 | F2's quote at its own scope. E3's slot asks only what was tracked |
| Cut cost, errors or delays by 40% | Inflated form of F2's mis-pick quote | The 40% stays attached to the mis-pick rate: "cut mis-pick rate 40% by redesigning the pick path" |
| The pick-path redesign was a Lean or Six Sigma project | Inflated form joining F8 and F2's quotes | Each quote at its own scope. C2's slot asks whether it was a structured project, and lets the answer be no |
| Seven years of operations leadership | Inflated form of F7 | F7's quotes at their own scope: seven years in ops, three supervisors today. A4's slot asks for the exact count |
| Has used Power BI | Negative you stated, F6 | "I haven't used Power BI." No slot |

## Sources

Provided documents: your message, which holds the JD excerpt and your background.

Searches sent, all refused, because web search permission wasn't granted in this session:

- `"Atlas Freight" regional logistics company values`: refused
- `"Atlas Freight" interview process operations manager`: refused
- `"Atlas Freight" terminals news 2026`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have themed the H bank on published values and, if the loop has a values round, added a values cheat sheet; the call was refused |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have replaced the generic archetype and flat weights with Atlas Freight's documented rounds; the call was refused |
| 3. `Atlas Freight` recent news | unavailable | Would have added a CO or CASE question on current priorities and sharpened A3's "why Atlas"; the call was refused |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD in your message fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting: hiring manager, peer, site lead, HR, or a panel → persona weights stop being flat; the top persona gets 4 to 5 questions and the rest are trimmed to match
- The interviewer's name → a public-footprint read, personalized weights, and a reverse question tied to their own career path
- The recruiter's prep email, or any note on rounds or a presentation → coverage of anything pre-declared, plus a documented loop in place of the generic archetype
- Web search permission → targets 1 to 3 run: Atlas Freight's published values, its interview process, and recent news, which add a strategy-grounded CO question and possibly a values cheat sheet
- A deeper research pass, on top of that: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief on Atlas Freight, recent org context, and loop reports for the role family
- The full JD text, if what you pasted was a summary → any requirements it adds get their own fit rows and questions
- Your answers to the slots in F2, F3, F5 and F7 → those rows move from `discovery` toward `none` or `transferability`, and A4, B2, C3 and E3 become story-mapped instead of slot-driven
- An inspectable artifact for the 40%, such as the before-and-after mis-pick report from that redesign, or the green belt certificate → C1, D2 and F8 can be rehearsed against the document rather than from memory
- A tuesday-dossier.md from the job-underwriter skill → the highest-ROI objection would be derived from evidence rather than inferred, and the prohibited list would come from verified evidence; this pack is complete without one
