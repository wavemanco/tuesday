Web search was refused, so I'm building the pack from your message and the recruiter's email alone. Writing it now.
I've built a full prep pack for Tuesday. It's built only from your message and the recruiter's email. Web search was refused, so nothing in it comes from Kelverton's public pages, Deepa's or Ross's profiles, or current news. I also haven't seen the market report, so anything about the market is a placeholder for you to fill from it.

**How the 4 hours are split:**
- **The POV (80 min):** build it from the report, then say it aloud twice against a 15-minute timer.
- **The quota objection (35 min):** rehearse it through three follow-ups.
- **Ross's commercials (40 min):** defending your £4M and 6-to-40 figures, plus partner economics.
- **The rest:** Deepa's likely POV follow-ups, your rail gap and motivation story, then one full timed run.

**The 15-minute POV:**
- **Open:** say which reading of "operator partnerships" you're taking. It could mean partnering with the operators themselves, or partners who help Kelverton reach operators.
- **Middle:** make two arguments, each with a concession you say aloud. Leave one out on purpose and say what you wouldn't do. Cover commercials around minute 10, before Ross asks.
- **Close:** what changes for operators, as the recruiter asked.
- **Using the report:** make one point everyone will make from it, then one where you go further or disagree. The panel's own strategy team wrote it, so reciting it won't stand out.

**The most likely objection** comes from your own description: you've never carried a direct quota. Name it yourself early ("I've never carried a direct quota. My numbers have been influenced revenue"), then point to the channel you ran. The pack has three follow-ups to practise.

**What not to say:** the pack lists claims to avoid, all stretches of things you told me. For example, "drove £4M" when you said "roughly £4M of influenced revenue", or "40 revenue-producing partners" when you said 40 partners.

There are 24 practice questions in all, and six questions for you to ask the panel.

Files are in `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-5-denied-ff8c61b8`:
- kelverton-rail_senior-partnerships-manager_interview_pack.md

If you paste the report's key points, the POV section and the market questions can be built on Kelverton's own picture instead of placeholders.

If you'd like, I'll play Ross on the quota objection and you can practise it out loud.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, and your CV if it's handy? Several requirements in the pack are general guesses for this kind of role, and the JD would replace them with Kelverton's actual wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

**Round:** Tuesday, 60 minutes. A 15-minute spoken POV with no slides, then Q&A.
**Panel:** Deepa, VP Partnerships and your future manager. Ross, Commercial Director, who "will push on commercials" (the recruiter's words).
**Built from:** your message and the recruiter's email as you quoted it. Web search was refused, so nothing here comes from Kelverton's public pages. I haven't seen the market report, so nothing here draws on its contents.

---

## How to use this pack

Two axes. **Personas** describe how a question gets asked: who asks it and in what register. **Types** describe what's being scored:

- **VAL**: behavioural or values evidence
- **EXP**: whether your stated experience holds up under scrutiny, and what was actually yours
- **JD**: whether you can do the stated job, gaps included. With no JD, the requirements come from the recruiter's words or are marked `[generic]`
- **CO**: company and market fluency
- **CASE**: a live problem from the role, reasoned out loud

Provenance labels: `[grounded]` means traceable to your words or the recruiter's. `[inferred]` means derived, with the derivation named. `[generic]` means a role-family pattern with no claim about Kelverton.

Guidance is scaffolding, not a script. Wherever a cell gives you words, they are your own sentences or a plain version of them. An **answer slot** is a place where only you know the answer. It has two honest branches, and either one is a good answer.

---

## Prep triage: 4 hours over the weekend

| Order | Block | Time | Tied to |
|---|---|---|---|
| 1 | Build the POV from the report using the structure in section 5, then say it aloud twice against a 15-minute timer | 80 min | Section 5 |
| 2 | Rehearse the highest-ROI objection until it's boring, all three follow-ups, out loud | 35 min | C1, then the prohibited list |
| 3 | Ross's commercials: defend both of your figures and work through the two partner-economics cases | 40 min | B1, B2, B4, B5, D2 |
| 4 | Deepa's POV follow-ups: say the structure of each answer aloud, without full answers | 30 min | A1 to A5 |
| 5 | The rail gap and the motivation story | 20 min | C2, C3, R1 |
| 6 | Pick three reverse questions, one per panellist plus one spare | 15 min | Section 11 |
| 7 | One full run: POV plus C1, out loud, timed | 20 min | Section 5, C1 |

Everything else in the pack is insurance.

---

## 4. Fit snapshot

There's no JD, so requirements come from the recruiter's email where she stated them (`[grounded]`). The rest are role-family patterns for a senior partnerships role (`[generic]`, unquoted).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material shows a partner channel at a payments company, not operator partnerships in rail. The words stay at that scope: "I've spent the last four years running the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the 18-month framing makes a probe on how you planned the channel's growth likely. If that plan was yours to set, say how you chose where to go, in your own words. If there was no such plan, or it wasn't yours, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Bus and light rail network planning in consulting, which is neither train operating companies nor selling to them. Words at that scope: "Before that I spent five years in transport consulting, doing bus and light rail network planning, so I know the operator world from the other side." Answer slot: the recruiter's operator close makes a probe on which operator problems you saw first-hand likely. If you saw specific ones, name them in your own words. If you didn't, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials" — recruiter | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message and "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | discovery | Your material gives one commercial figure, influenced revenue. It says nothing about whether partner terms were yours to set. Answer slot: "commercials" makes a probe on partner terms likely. If any were yours to set or negotiate, say which and how, in your own words. If none were, say so plainly and stay with the channel and its roughly £4M of influenced revenue |
| F4 | Owning a direct revenue number, which senior partnerships roles often carry (role-family) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap you've stated yourself. Words: "I've never carried a direct quota. My numbers have been influenced revenue." Then how you'd want to be measured here, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Selling into the company's target customers, train operating companies (role-family, from your description of Kelverton) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap you've stated yourself. Words: "I haven't sold into rail." F2's consulting sentence is adjacent and stays at its own scope. Then a ramp plan, said as a plan |
| F6 | Building and scaling a partner programme (role-family) | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap. Your sentence already says it in role terms: you ran the ISV channel and took it from 6 partners to 40. Nothing inspectable stands behind it, so expect the figure to be probed. Lead with the partner count as you stated it, because a named count beats an adjective |
| F7 | Fluency in this company's market (role-family) | "She also attached the market report their strategy team circulated internally last quarter, which I've read." — your message | medium | [generic] | discovery | Your material shows you've read the report. I haven't, so no cell here speaks to its contents. Answer slot: if asked what stood out, name the points in your own words and say what you'd do with each. If a point was unclear to you, say so and say what you'd want to test |

---

## 5. Graded deliverable: the 15-minute POV

**The brief, in the recruiter's words:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves." `[grounded]`

**The facts about you it can stand on:**
- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
- F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."

**The facts about the market it stands on:** only what's in the report. The strategy team wrote it and the recruiter sent it, so the panel knows it better than you do. Reciting it scores as homework. Departing from it with reasons scores as judgement.

### First 60 seconds: name your reading of "operator partnerships"

`[inferred]` from the recruiter's wording: the phrase has two readings. It could mean partnering with the operators themselves, or partners who help Kelverton reach and serve operators. "What it means for the operators themselves" fits either. Say which one you're taking and why in one sentence, then move on. Deepa owns this area, and she'll correct you early if you've picked the wrong one, which is far better than finding out at minute 14.

### Theses: pick two, keep one in reserve

| # | Thesis | Mandatory concession | Provenance | What it needs from the report |
|---|---|---|---|---|
| T1 | Measure the partnership motion by what changes for operators, such as adoption and time to value, not by partner count | Early in an 18-month window, partner count and coverage may be the only leading indicators available, so report both and say which one you'd be judged on | [generic] | Whatever the report says operators struggle with, used as the outcome measures |
| T2 | Prioritise partnerships with the systems scheduling software sits alongside in an operator's estate, over a broad resale programme | Integration partnerships take product and engineering time, and their revenue may land after month 18 | [generic] | Which adjacent systems or vendors the report names, and where operators lose time between them |
| T3 | The anti-pick: name one thing you would *not* do in 18 months, for example a tiered partner programme launched before one partnership has shown operator value | It looks less ambitious, and Ross may read it as slow revenue. Hold it by saying what it protects, then say what would change your mind | [generic] | Whether the report argues for scale or for depth. If it argues scale, T3 is your divergence and needs your best reason |

**Differentiation:** one consensus point from the report, said in a sentence to show you've read it. Then one thesis where you go further than the report, or disagree with it, with your reason. Then the anti-pick.

**The pull to resist:** leading with "I took a channel from 6 to 40 and will do it again." F1's sentence is your credential; saying it once in the opener is enough. A plan aimed at partner count invites T1's concession from the panel instead of from you.

### Shape for 15 minutes

| Minutes | Beat |
|---|---|
| 0 to 1 | Your reading of "operator partnerships", plus one sentence of who you are using F1's and F2's words |
| 1 to 3 | Where it stands: one consensus point from the report, and the gap you'd go after |
| 3 to 10 | Two theses, each with its concession said aloud. Sequence the 18 months: the first 6 to learn and choose, 6 to 12 to pilot with named operator types, 12 to 18 to scale what worked `[generic]` |
| 10 to 12 | Commercials, before Ross asks: how you'd measure success, what you'd want to be held to, and the one number you'd most want to understand first. Use the report's figures and invent none |
| 12 to 15 | The close Deepa and Ross asked for: two or three concrete things that change for an operator, in operator terms, each tied back to a thesis |

**The operator close:** these are your hypotheses, said as hypotheses you'd test with operators. They come from the report, plus whatever your consulting showed you first-hand. Answer slot: if F2's work showed you a specific operator problem, open the close with it in your own words. If it didn't, say what you'd go and ask operators first, and keep the close to what the report supports.

---

## 7. Reading the interviewers

Only what the recruiter said. Search was refused, so neither panellist's public profile was read.

| Panellist | What's established | Practical implication |
|---|---|---|
| Deepa | VP Partnerships, your future manager (recruiter) | She owns the area your POV is about. Expect "how would you actually do that" follow-ups on the POV, plus gap probes. Ask her what she would change about the current partner motion |
| Ross | Commercial Director; "Ross will push on commercials" (recruiter) | He'll test both figures and the economics of any partnership you propose. There's also a seam between partner-sourced and direct revenue that he may test as a peer would |

Mirror opportunities: none established, because neither career path was read.

---

## 8. Persona table

Weights come from the recruiter's email, which establishes this session: a two-person panel with a POV followed by Q&A. Panel rule: blend each member's top two personas. Deepa as hiring manager brings Case/Strategist and Skeptic. Ross, flagged for commercials, brings Data-Driven Prober and Pressure.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Deepa unpicking the POV: first 90 days, which partners, which operators | High. The POV is itself a case, and she's the hiring manager | Clarify, then objective, segments, approach, metrics, risks. Think aloud. Challenge one premise per answer |
| Data-Driven Prober (B) | Ross on your two figures and on partner economics | High. The recruiter said so | Know what you can and can't say about how each figure was counted, and say plainly when you don't know |
| Skeptic (C) | The quota gap, the rail gap, why payments to rail | High. F4 and F5 are visible from your own description | Rehearse C1 until it's boring. Bridge only from adjacent work you stated |
| Pressure (D) | Ross time-boxing, playing devil's advocate on the POV | Medium. "Push" suggests it, though not necessarily hostile | Pause, restate, hold through two follow-ups, then concede the specific point |
| Peer Evaluator (E) | Ross on the seam between partnerships and his commercial team | Medium. A Commercial Director and a partnerships hire share revenue, and credit for it | Reciprocity: what you'd give his team. Propose principles for the seam rather than pretending to know where it sits |
| Conversational (R) | Openers and the "walk us through your journey" question | Low to medium. Usually the first minute or two | A pre-scripted 90-second arc |
| Values / Behavioural (V) | A "tell me about a time" question in the Q&A | Low. No values round is named, and Kelverton's published values weren't read | One customer-first story and one hard-truth story, selected in advance |

---

## 9. Question banks

**Highest-ROI prep in this pack: C1.** It's the objection most likely to arrive, from either panellist, because your own description contains it.

### A. Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You said 18 months. What do you actually do in the first 90 days?" | CASE | [generic] | Structure aloud: who you'd listen to first (operators, existing partners, the commercial team), what you'd decide by day 90 (which thesis to back, which one partnership to pilot), and what you'd report back and when. End on the decision you'd bring to Deepa at day 90. This makes no claim about your past | The most natural follow-up to any 18-month plan. CASE because it scores sequencing more than content |
| A2 | "If you could sign only three partners in 18 months, what kinds are they and why?" | CASE | [generic] | Answer in categories, not company names, unless the report names them. Give each one a reason tied to an operator outcome from T1 or T2, then name the kind you'd say no to. Offer the anti-pick unprompted | Forces prioritisation of the POV. Rewards the T3 move |
| A3 | "Which operators would you start with, and which would you leave alone?" | CASE | [generic] | Segment first, using the report's own segmentation if it has one. Pick the segment where a partnership changes the most for the operator, and say why you'd leave another segment for later. Name the assumption you'd test first | Tests whether the POV lands on operators specifically, as the recruiter asked |
| A4 | "What does this plan change for an operator's day-to-day?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Open at F2's scope: "I spent five years in transport consulting, doing bus and light rail network planning, so I know the operator world from the other side." Then two or three concrete changes, from the report, said as hypotheses. Answer slot: if that work showed you a specific operator problem first-hand, name it in your own words. If it didn't, say so plainly and say what you'd go and ask operators first | The recruiter's stated close, so it gets asked again in Q&A if the POV runs short on it. JD because it scores the recruiter's stated requirement |
| A5 | "What in our market report would you challenge?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Pick one claim from the report. State it fairly in a sentence, say what would make it wrong, and say how you'd test it in the first 90 days. If nothing in it strikes you as wrong, say which assumption you'd most want to test, and why | The report is the panel's own document, so engaging with it rather than reciting it is the differentiator. F7 is the evidence. CO because it scores market judgement |

### B. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Restate it as you stated it: roughly £4M of influenced revenue, keeping "roughly" and "influenced". Answer slots, in your own words: how the figure was counted and over what period; what it's sensitive to; the assumption behind it you'd defend least, named before Ross names it; which part was yours. If you don't know how it was counted, say so plainly. "I don't know exactly how that was counted" beats a method you can't repeat under a second question | Every headline figure gets a defend-the-number question, and Ross is flagged for commercials. F3 and F6 are the evidence. EXP because it tests attribution |
| B2 | "Six partners to forty. How many of the forty actually produced revenue?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The quote counts partners, not producing partners, so don't let the 40 slide onto revenue. Answer slot: if you know how many of the 40 contributed to the £4M, give the number and say how you know it. If you don't, say so plainly and say what you'd track here from day one | The denominator question for F6's count. It pairs with B1, and with T1's partner-count concession |
| B3 | "What would you need to see before signing a partnership here?" | CASE | [generic] | Build the case out loud: the operator outcome it serves, the cost to Kelverton (people, product time, margin), time to first revenue, and the signal at month 6 that would make you stop. Close with the one figure you'd most want from Ross's team | Ross's native ground. CASE because it's forward-looking and scores structure |
| B4 | "How should we pay partners: referral fee, resale margin or revenue share?" | CASE | [generic] | Lay out the trade-off: which model fits which partner kind from A2, what each does to Kelverton's margin and to who owns the operator relationship, and which you'd pilot first. Answer slot: if partner terms at the payments company were yours to set or negotiate, say which and how, in your own words. If none were, say so plainly and reason from first principles | F3's discovery gap is exactly where Ross will press. The slot keeps the past honest while the case shows judgement |
| B5 | "What number should we hold you to at month 18?" | CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Propose a small set: one operator-outcome measure (T1), one revenue measure, one leading indicator. Say plainly that your numbers so far have been influenced revenue, then ask how Kelverton counts partner-sourced against partner-influenced revenue. The question converts F4 into a calibration conversation | F4 makes this likely. Answering it with a proposal rather than a defence is the move. CASE because it asks for a design |

### C. Skeptic (Deepa, or Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never carried a direct quota. Why should we trust you with a commercial number?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | **Highest-ROI rehearsal.** Name the limit before it's pressed: "I've never carried a direct quota. My numbers have been influenced revenue. For the last four years I've run the ISV channel at a payments company and took it from 6 partners to 40, with roughly £4M of influenced revenue." Then say how you'd want to be measured here, as a plan (see B5). **Follow-up 1, "Influenced is soft; anyone can claim it":** answer slot: how the £4M was counted, in your own words. If you don't know, say so plainly. **Follow-up 2, "So you've never closed anything?":** answer slot: if partner agreements were yours to negotiate or sign, say which part was yours. If not, say so plainly and return to the channel you ran. **Follow-up 3, "Would you take a quota here?":** that's about terms. Answer from your real preference and ask how the role is measured. Hold on the channel you ran; concede only what you stated: "That's a fair distinction. I haven't carried a direct quota." Never upgrade "influenced" to win the exchange | F4 is the gap your own description puts on the table, and Ross is primed for commercials, so it arrives in some form. EXP because it tests attribution under pressure |
| C2 | "You've never sold into rail. How long before you're useful to an operator?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Concede in one line: "I haven't sold into rail." Then F2 at its own scope: bus and light rail network planning, "from the other side". Then a ramp plan: who you'd shadow, which operators you'd meet in the first month, and what you'd read. Answer slot: if your consulting involved working directly with operators, say which kind and in what capacity. If it didn't, say so plainly | F5 is a stated gap. JD because it scores readiness for the role |
| C3 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Your material doesn't say why, so this is an answer slot: give the real reason in your own words, in two sentences, and connect it to F2's transport years only if that is genuinely part of the reason. If part of the reason is something you'd rather not lead with, say the part that's true and relevant. Keep it under 60 seconds | A standard Skeptic motivation probe, sharpened by the sector switch between F1 and F2 |
| C4 | "Payments ISVs and train operators buy very differently. What from your channel doesn't transfer?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: name one or two things from running the ISV channel that you expect won't carry over, in your own words, and what you'd do instead. Volunteering the limit is the point. Then name one thing you'd keep, at the quote's scope | Tests F6's transferability honestly. Candidates who claim everything transfers lose the Skeptic here |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's sold into operators for ten years?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Pause, then don't argue with the hypothetical person. Concede: "I haven't sold into rail." Then two facts as stated: the channel from 6 partners to 40, and five years of bus and light rail network planning. Then the one thing in your POV you'd do first. Stop at 60 seconds; stopping on time is part of what's scored | The Pressure stem aimed at F5. JD because it scores fit against the role |
| D2 | "£4M influenced. How much of that was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold first: "influenced" is already the honest word, and you chose it. Answer slot: if specific partners or deals were yours to bring in, name them in your own words. If the figure is the channel's total and your share can't be separated out, say so plainly. Hold through two follow-ups, then concede the specific uncertainty, never the channel you ran | The attribution stem on F3's figure. Hold-then-concede is the scored behaviour |
| D3 | "Nice plan. What do you cut if we halve the budget?" | CASE | [generic] | Cut breadth and keep depth: drop the thesis with the longest payback and keep the one operator-facing pilot from T1 or T2. Say what you'd lose by cutting, and the signal that would make you ask for the budget back | Devil's advocate on the POV. Rewards an anti-pick you've already thought through |

### E. Peer Evaluator (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A partner and my sales team both claim the same operator deal. What happens?" | CASE | [generic] | Propose principles: rules agreed in writing before the first conflict, the operator's preference first, and compensation that doesn't make the teams compete for credit. Ask how it works today. If a real conflict from the ISV channel comes to mind, use it in your own words. If none does, say so and stay with principles | The seam between partnerships and direct revenue is Ross's territory. CASE because it's a live problem |
| E2 | "How do you handle credit when a deal spans your team and mine?" | EXP | [generic] | Open prompt: pick a time credit for shared work had to be settled. It needs a named stake, what you did and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. Influenced revenue makes credit-sharing a natural probe |
| E3 | "What would you need from my team in your first quarter?" | CASE | [generic] | Reciprocity: one thing you need (access to operator accounts, pipeline data) and two things you'd give (partner-sourced introductions, operator feedback from partner channels). Ask what his team is short of | Shows you add to his team rather than drawing on it |

### R. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk us through the journey: consulting, payments, now here." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc with only the beats your sentences state: five years of bus and light rail network planning, then partnerships, with the last four running the ISV channel from 6 partners to 40. Then the why-here, which is C3's answer slot in your own words. Then hand off to the POV | The near-certain opener. Casual, but it's scored for economy |
| R2 | "What's caught your eye in rail lately?" | CO | [generic] | Answer slot: if you've followed something specific, name it and where you read it. If you haven't, say so and name what in the report you'd most want to understand better. Don't present the report's points as your own outside reading | Search was unavailable, so this pack can't supply current news. The honest branch matters more than usual |

### V. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time a partner wanted something that wasn't good for the end customer." | VAL | [generic] | Selection scaffold: pick a time a partner's interest and the customer's pulled apart. It needs a named stake, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The customer-first stem, themed by the recruiter's operator focus |
| V2 | "Tell me about a time you told leadership something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time you held a position with someone senior. It needs a named stake, a moment you didn't fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. T3's anti-pick makes this a natural follow-on in a POV round |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: 18-month operator partnerships POV | Section 5, A1, A2, A3, D3 |
| F2: land on what it means for operators | Section 5 close, A4, C2 |
| F3: Ross on commercials | B1, B3, B4, D2 |
| F4: owning a direct number | C1, B5 |
| F5: selling into train operating companies | C2, D1 |
| F6: building a partner programme | B2, C4, R1 |
| F7: fluency in the market | A5, R2 |

---

## 11. Reverse questions

| # | Question | To | Why it lands |
|---|---|---|---|
| 1 | "At month 18, what would make this hire clearly the right call from where you sit?" | Deepa | It recalibrates your POV against her real bar while you're still in the room |
| 2 | "How do you count partner-sourced against partner-influenced revenue, and does this role carry a number?" | Ross | It addresses F4 openly, on your terms, and gets you the comp structure |
| 3 | "Where does partnerships end and your commercial team begin today, and where does it rub?" | Ross | It shows you see the seam before it costs anyone anything |
| 4 | "Which point in the strategy team's report is most debated internally?" | Either | It shows you read the report closely enough to know it's an argument, not a verdict |
| 5 | "Which operator relationship would you most want this person to strengthen first?" | Deepa | It lands the round on operators, which is where the recruiter asked you to land |
| 6 | "What has a partnership that didn't work taught the team?" | Deepa | It invites candour and shows you'd learn from history rather than repeat it |

---

## 13. Prohibited claims

What this pack won't coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a quota, or owned a closed revenue number | A negative you stated (F4) | "I've never carried a direct quota. My numbers have been influenced revenue." |
| Has sold into rail | A negative you stated (F5) | "I haven't sold into rail." |
| Generated, closed or drove £4M of revenue | Inflated form of the F3 and F6 quote | The quote at its own scope: "roughly £4M of influenced revenue". Pack's observation: the material says influenced, and roughly. B1's and D2's slots stay inside that |
| Built the ISV channel from scratch | Contradicted by your own quote (F6) | "took it from 6 partners to 40" |
| Grew to 40 revenue-producing partners | Inflated form of the F6 quote | The quote counts partners: "took it from 6 partners to 40". B2's slot asks only what you know about how many produced revenue |
| Knows train operating companies from the inside | Inflated form of the F2 quote | The quote at its own scope: "bus and light rail network planning, so I know the operator world from the other side". Pack's observation: the material says bus and light rail planning in consulting |

---

## 14. Sources

**Provided:** your message, including the recruiter's email as you quoted it. You've read the market report; it wasn't shared with me, so nothing here draws on its contents.

**Searches sent:**
- "Kelverton Rail values": refused
- "Kelverton Rail scheduling software train operating companies news": refused
- "Kelverton Rail Deepa VP Partnerships": refused
- "Kelverton Rail Ross Commercial Director": refused
- "Partnerships Manager" rail software train operating companies job description UK: refused

**Fetches:** none. No dossier was consumed.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have given the V bank Kelverton's official value names in place of generic stems |
| 2. `Kelverton Rail interview process` partnerships | skipped | The recruiter's email already fixes this session (a two-person panel, a 15-minute POV, then Q&A), and with it the persona weights |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The search was refused. It would have grounded T1 to T3, A2, A3 and R2 in current Kelverton news. The report would answer this target, but its contents aren't in hand |
| 4. `Deepa` / `Ross` Kelverton Rail | unavailable | Both searches were refused. They would have filled the interviewer read, reweighted the personas and tied a reverse question to each panellist's path |
| 5. Representative Senior Partnerships Manager JD | unavailable | The search was refused. It would have moved F4 to F7 from `[generic]` to `[inferred]` and added JD-tagged questions for requirements this pack can't see |

---

## 15. Upgrade menu

- **The report's key points, pasted or summarised** → T1 to T3 grounded in Kelverton's own market picture; real content in A2, A3, A5 and R2; concrete consensus and divergence picks for the POV
- **The JD text** → F4 to F7 become quoted requirements, the coverage table is rebuilt against the JD's own list, and any requirement this pack can't see gets a question
- **Your CV** → more of your own sentences to quote, so V1, V2 and E2 become story-mapped instead of selection scaffolds
- **Web search allowed** → targets 1, 3, 4 and 5 above: official values, recent news, Deepa's and Ross's public footprint, and a representative JD
- **Deeper research, once search is allowed** → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, the panellists' talks or writing, loop reports, and recent org context
- **Your answers to the answer slots** → F1, F2 and F3's bridges, and B1, B2, B4, C1, C3 and A4's guidance, become story-mapped on what you actually did
- **Any record of the channel figures you can still refer to, such as a partner pipeline or scorecard** → F1 and F6 confidence moves from medium toward high
- **A tuesday-dossier.md from a fit evaluation** → an evidence-derived objection and prohibited-claims list. Useful, not needed
