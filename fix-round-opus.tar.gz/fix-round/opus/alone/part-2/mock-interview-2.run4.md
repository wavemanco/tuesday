Quick update: my web searches for Atlas Freight were blocked by permissions, so I'm building your prep pack from the JD and your background alone. Writing it now.
I've written your prep pack: `AtlasFreight_operations-manager_interview_pack.md`. You didn't say who you're meeting, so I built it for one general round. That makes it weaker than a pack built for a known round. My web searches about Atlas Freight were blocked by permissions, so it rests only on the JD and what you told me. It says nothing about the company's values, how it runs interviews or its current strategy.

**What's in it:**
- **Fit check:** each JD requirement next to your own words, with the gap between them stated.
- **21 practice questions**, grouped by interviewer style, each with answer guidance.
- **7 questions to ask them.**
- **A list of claims not to make**, with the honest version of each.

**Where to start:** question A1, "You're a senior shift manager over 3 supervisors today. This role leads 12 supervisors across 4 sites. Why are you ready for that jump?" It's the question you're most likely to get in some form, so it's the most useful one to rehearse.

**What to prepare before the interview:** the pack doesn't fill in facts you haven't given me. Have honest answers ready on these:
- **The 5+ years of operations leadership the JD requires.** How many of your 7 years were actually in leadership roles?
- **On-time performance and cost-per-shipment.** Have you been held to either one?
- **Excel reporting.** Have you built recurring reports, beyond being solid in Excel?
- **Scope.** Have you ever covered more than your own shift or site?

Power BI is the one gap you've already named. Say "I've never used Power BI" plainly, then give a learning plan for it.

Say the word and I'll play the skeptical interviewer on A1.
I can also save a `tuesday-dossier.md` file listing the gaps this prep exposed, for you to bring to later sessions.
I can draft a short Power BI learning plan you could describe in the interview, since that's the one gap no wording can close.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting: your future manager, a peer, someone more senior, or HR? And has the recruiter told you about focus areas or a presentation? The answer changes which questions the pack prioritizes.
2. Do you want me to research Atlas Freight? I'd need web search allowed for that. I can do a standard pass, or a deeper one: up to 6 more searches and 2 more page fetches, taking several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack — Operations Manager, Atlas Freight

Regional logistics, 800 employees. Interviewer and round type: not known. This pack assumes a single general round and uses flat persona weights. That makes it noticeably weaker than a pack built for a known round. The upgrade menu at the end says what fixes that.

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking and in what style. **Types** describe *what* is being scored.
- Type key:
  - **JD**: can you do the job as listed, gaps included
  - **EXP**: does your stated experience hold up under scrutiny, and what was actually yours
  - **CASE**: a live problem from the role, reasoned out loud
  - **VAL**: behavior that shows values
  - **CO**: knowledge of the company and its strategy
- Provenance labels: `[grounded]` traces to your message or the JD; `[inferred]` is this pack's derivation, with the derivation named; `[generic]` is a pattern for this role family and makes no claim about Atlas Freight or about you.
- **Answer slots** mark places where the pack doesn't know the answer and won't invent one. Each gives two honest branches. Fill one in your own words.
- Guidance is scaffolding, not a script. Every claim about your past in this pack quotes your own sentences. Don't let a rehearsed answer grow beyond them.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution operations and one site's surge plan, not terminal operations across four sites, and your words should stay at that scope: "Seven years in warehouse and distribution ops. I ran the site's peak-season surge plan two years running." Answer slot: the JD's terminal and four-site wording makes a probe on wider scope likely. If you have run work at more than one site, or terminal work, say what and for how long, in your own words. If you haven't, say so plainly and stay with what you've run |
| F2 | "drive on-time performance" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is an accuracy measure, not on-time performance. Keep the claim as stated: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if on-time performance has been a measure you were held to, say how it was counted and what moved. If it hasn't, say so plainly and stay with the mis-pick result |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material doesn't show cost-per-shipment work. Answer slot: if you have tracked or been accountable for a cost measure, say which and what part was yours. If not, say so plainly and describe how you'd learn the cost drivers, as a plan |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors to twelve is a real step in span of control. Your words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you've led more people at any point, covering shifts or teams beyond your own, say when and how many. If not, say so plainly and stay with the three |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill, not a report you built. The pack's derivation: the JD asks for built reporting, and your line doesn't show whether you've built any. Answer slot: if you've built recurring reports, say what they tracked and who used them. If not, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | No wording closes this gap, and you've said so. Words: "I've never used Power BI." Then how you'd learn it, said as a plan and never as past experience. Add nothing to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in operations is not the same as seven years leading in operations, and the material doesn't show how many of the seven were leadership years. Pack's reading: a "required" years line may be screened literally. That's a risk to answer precisely, not an eligibility gate. Answer slot: give the actual number of years you've led people, and in what roles. If it's fewer than five, say the number plainly |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but expect a probe. Lead with the quote's own words: "I'm green belt certified." Don't name the certifying body or link it to a project unless you can say which, in your own words |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A2, B3, G1 |
| "drive on-time performance" | B2, C2, C3 |
| "cost-per-shipment down" | B1, C3 |
| "lead a team of 12 supervisors" | A1, B3 |
| "build reporting in Excel/Power BI" | A4, B4, D2 |
| "5+ years operations leadership required" | A3 |
| "Lean/Six Sigma a plus" | E2 |

## Persona table

No loop source establishes how Atlas Freight interviews, so the weights rest on the generic archetype: screen, then hiring manager, then panel, with flat weights. Depth leans slightly toward Skeptic and Case because the gaps in F1, F4, F6 and F7 and the JD's two numeric targets give those personas the most material. That tilt is this pack's own judgment. Recalibrate if you learn who you're meeting.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Presses on the scope jump and the tool gap | High. F4 and F1 are the widest gaps, and any interviewer who read the JD next to your background will see them | Rehearse A1 until it's boring; bridge only from "currently a senior shift manager over 3 supervisors" and "ran the site's peak-season surge plan two years running"; ramp plans said as plans |
| Case / Strategist (B) | Live problems about on-time performance, cost and four-site coverage | High. The JD names two measurable targets, which invites diagnosis questions in a hiring-manager round | Clarify, objective, segment, approach, metrics, risks; think aloud |
| Data-Driven Prober (C) | Asks how the 40% was counted | Medium. A headline percentage attracts this persona in any round | The four answer slots on C1; say plainly where you don't know |
| Pressure (D) | Time-boxes, attacks the 40% attribution and the Power BI gap | Medium. Flat prior; operations roles often test composure | Pause, restate, hold the quoted facts through two follow-ups, concede specifically |
| Conversational (E) | "Walk me through the journey"; a casual Lean question | Medium. Flat prior; openers and a JD "plus" skill tend to arrive casually | A 90-second arc built only from your quoted lines |
| Peer Evaluator (G) | Another site lead pricing what you add or cost them | Low to medium. A panel may include a peer manager | Seam principles, reciprocity, no pretending to know their sites |
| Values / Behavioral (H) | STAR-style open prompts | Low. No values round detected and no published values in hand | Selection scaffolds with honest branches |

## Question banks

Persona letters skip F so they don't collide with fit-snapshot row IDs.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over 3 supervisors today. This role leads 12 supervisors across 4 sites. Why are you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | **The highest-ROI rehearsal in this pack.** Name the step before they do, in your quotes' terms: "Today I'm a senior shift manager over 3 supervisors. This is 12 across four sites, and that's a real step up." Then the fact that carries weight: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's 12 supervisors and four sites make a probe on wider scope certain. If you've covered other shifts, other sites or more people at any point, say what, when and for how long, in your own words. If you haven't, say so plainly and stay with the three supervisors and the surge plan. Then give a plan, said as a plan: how you'd learn four sites and twelve supervisors in your first 90 days. Hold through two follow-ups by returning to these facts, never by adding to them. Concede the scale, not the readiness | F4 and F1 are the widest gaps between your material and the JD, so this objection arrives in some form in any round. JD because it scores the stated span of control. Deepest rehearsal because it's the one place a nervous answer tends to inflate |
| A2 | "Your background is warehouse and distribution. This role runs terminal operations. What doesn't transfer?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer the question asked: say what doesn't transfer before what does. Your words: "My seven years are in warehouse and distribution ops." Answer slot: the JD's "daily terminal operations" makes a probe on terminal work likely. If any of your work has been terminal work, say which and what part was yours. If none has, say so plainly and name what you'd need to learn first, as a plan. Don't describe warehouse work in terminal vocabulary | F1's gap is a difference in the kind of work. A candidate who names it first sounds calibrated rather than caught. JD because it scores the core responsibility line |
| A3 | "How many of your years in operations have been in a leadership role?" | JD | [inferred] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Answer slot: give the actual number of years you've led people, and in which roles, in your own words. If it's fewer than five, say the number plainly and stay with what those years held. Never round seven years of ops into seven years of leadership. A precise number said calmly beats a vague one said confidently | F7. The years line is marked "required" and may be screened literally. `[inferred]` because that screening risk is the pack's reading |
| A4 | "This role builds reporting in Excel and Power BI. Where are you on that?" | JD | [grounded] "solid Excel, never used Power BI" | Both halves, plainly: "I'm solid in Excel. I've never used Power BI." Answer slot: the JD's "build reporting" makes a probe on what you've built likely. If you've built recurring reports in Excel, say what they tracked and who used them. If you haven't, say so plainly and stay with "solid Excel." Then a Power BI ramp, said as a plan in the future tense, never as a past | F5 and F6. The only stated tool in the JD you've said you haven't used. JD because it's a listed responsibility |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Cost-per-shipment at one of our four terminals rose this quarter while the others held flat. Diagnose it." | CASE, JD | [generic] | Clarify first: how cost and shipments are counted, over what window, whether volume or mix changed. Then segment the cost into labor hours and overtime, equipment, damage and claims, and volume mix. Form a hypothesis and say what data would kill it. Close with what you'd do this week and what you'd watch next week. The question needs no claim about your past, so the guidance makes none | Tests the JD's cost target as a live problem. `[generic]` because it's a pattern for the problem, not a fact about this employer |
| B2 | "On-time performance dropped at two of four sites in the same month. What do you need to know first?" | CASE, JD | [generic] | Start with the definition: what counts as on time, and was it measured the same way at both sites. Then ask what the two sites share that the other two don't, such as a carrier, a shift pattern, a volume spike or staffing. Lay out the diagnostic order, the first fix you'd test and how you'd know it worked | The JD's on-time line, asked as a decision. A shared-cause framing shows multi-site thinking without claiming you've done it |
| B3 | "Sketch your first 90 days owning daily operations across four sites." | CASE, JD | [generic] | Structure it in three phases: listen and measure (each site, each supervisor, the current numbers), pick one or two fixes against on-time and cost, then set a reporting and supervisor rhythm. Name the risk you'd watch, such as spreading too thin across sites. Said entirely as a plan | Covers the four-site and 12-supervisor lines without asking you to have done it |
| B4 | "Design the weekly report you'd want across the four sites. What's on it, and how would you build it?" | CASE, JD | [generic] | Lead with the JD's two measures, on-time performance and cost-per-shipment, by site and by trend, with exceptions flagged and an owner per exception. Say who reads it and what decision it drives. On the tool, be honest and forward-looking: you'd start where you're solid and plan the move to Power BI. Keep that a plan | The JD's reporting line as a live build. CASE delivery lets you show reporting judgment apart from tool history |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick figure was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats your quote states: the mis-pick rate, 40%, the pick-path redesign. Then the four defend-the-number slots, in your own words: how the figure was counted; what it's sensitive to; the assumption behind it you'd defend least, named before they ask; and which part was yours. If you don't know how it was counted, say so plainly. Never supply a baseline, window or method you can't stand behind | Your one headline metric, and the first thing a prober reaches for. EXP because it tests whether the number survives scrutiny |
| C2 | "Talk me through the peak-season surge plan you ran. Was anything measured, and what did it show?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats your quote states: the site's surge plan, you ran it, two years running. Answer slot: the JD's on-time line makes a probe on peak results likely. If anything was measured, say what and what it showed. If nothing was, say so plainly and describe what the plan covered, in your own words | F1's strongest evidence. The question allows the honest answer that nothing was measured |
| C3 | "On-time performance and cost-per-shipment are this role's scorecard. Which operational metrics have you been held to?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start with what your material carries: the mis-pick rate. Answer slot: the JD names on-time performance and cost-per-shipment. If either has been a measure you were accountable for, say which, how it was counted and what moved. If neither has, say so plainly and stay with the mis-pick rate. Don't relabel mis-picks as on-time or cost | F2 and F3. JD because it scores the two stated targets directly |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate. Hold what the quote says. Answer slot: say which part of the redesign was yours and which was others', using "we" for context and "I" for contribution. If others did parts, name their roles plainly. Hold through two follow-ups, then concede specifically, naming exactly what wasn't yours, without giving up the part that was | C1's number under attack. Rehearsing the concession wording now stops a defensive answer later |
| D2 | "You've never used Power BI, and the JD says build reporting in it. Why isn't that a dealbreaker?" | JD | [grounded] "never used Power BI" "solid Excel" | Don't argue the premise. It's yours: "I've never used Power BI." Then "I'm solid in Excel." Then a short, concrete learning plan, said as a plan. Hold without apologizing and without claiming it'll be easy. Concede that you'd be learning it on the job | F6. Composure on a stated gap is what's being scored |
| D3 | "Sixty seconds: why you over an internal supervisor who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | Concede the internal candidate's real advantage first. Then pick two of your quoted facts and say them in their own words. Close with what you'd do in your first month, as a plan. Don't disparage the internal candidate. Stay inside 60 seconds | A time-boxed motivation probe. Choosing which two quotes to use is the rehearsal |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc built only from these: seven years in warehouse and distribution ops; now a senior shift manager over 3 supervisors; the 40% mis-pick cut through the pick-path redesign; the site's peak surge plan two years running; green belt certified. Answer slot: close with your real reason for this move, in your own words | The opener in most rounds, and scored even when it feels casual |
| E2 | "What are you working on in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Lead with "I'm green belt certified." Answer slot: if you've applied it to a project, name the project and the part that was yours. If you haven't, say so plainly and say where you'd apply it first in this role. Don't tie it to the pick-path redesign unless that's true | F8. The JD's "plus" skill, which usually arrives in a casual register |
| E3 | "Why Atlas Freight, and why now?" | CO | [generic] | Answer slot: your actual reasons, in your own words. Refer only to what the JD says: four sites, 12 supervisors, on-time and cost targets. Without research, say nothing about the company you can't source | Motivation consistency. `[generic]` because research didn't run, so there are no company facts to draw on |

### G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When two sites need the same resource on the same day, how do you settle it with the other site's lead?" | CASE | [generic] | Propose seam principles rather than claiming to know their sites: agree the priority rule in advance (customer commitment first, then cost), escalate early, share the data, and debrief afterwards. Show what you'd bring to the other lead, not only what you'd need from them | The four-site line, seen from a peer's side. The question needs no claim about your past |
| G2 | "How do you handle credit when an improvement depends on other shifts or teams?" | EXP | [generic] | Selection scaffold: pick a time an improvement of yours needed another shift or team. It needs a named contribution from them, how you credited it, and a working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | A collegial credit probe that peers use. A scaffold because no quoted line describes cross-shift work |

### H — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a specific message, a named stake, the moment you said it anyway, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Common behavioral stem. Without Atlas Freight's published values, it can only test generic behavior |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: it needs the metric, the customer impact, your decision and its cost. If no such time comes to mind, say so plainly, then give the nearest thing, or how you'd handle it | On-time performance is customer-facing, so this tension is plausible in logistics. A scaffold because no quote carries a story for it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured today, and is it the same at all four sites?" | Shows metric literacy, and tells you what you'd actually be scored on |
| R2 | "What do you see driving cost-per-shipment right now?" | Invites the interviewer's own diagnosis, which is the job's real agenda |
| R3 | "How are the 12 supervisors spread across the sites, and how long have they been in their roles?" | Shows you're already thinking about the span-of-control jump in A1 |
| R4 | "What reporting exists today in Excel and Power BI, and who builds it?" | Shows the size of your Power BI ramp and whether you'd have support |
| R5 | "What would make the first 90 days in this role a clear success for you?" | Turns the conversation toward their definition of a win |
| R6 | "Is Lean or Six Sigma work already running at any of the sites?" | Connects your green belt to their reality without overclaiming |
| R7 | "What are the next steps, and who else will I meet?" | Gets you the loop structure this pack couldn't research |

## Prohibited claims

Each entry is a claim this pack won't coach, with the reason and the honest version to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run terminal operations, or operations across multiple sites | Inflated form of F1 | "7 years in warehouse and distribution ops" and "ran the site's peak-season surge plan two years running," at their own scope. The pack observes that your material says warehouse and distribution and one site's plan. A1 and A2 slots stay inside that |
| Has led a large supervisory team | Inflated form of F4 | "currently a senior shift manager over 3 supervisors" |
| The pick-path redesign improved on-time performance or cost | Inflated form of the F2 quote, a change in the kind of claim | "cut mis-pick rate 40% by redesigning the pick path." C3's slot asks about on-time and cost separately |
| Seven years of operations leadership | Inflated form of F7 | "7 years in warehouse and distribution ops." A3's slot asks for the real number of leadership years |
| Has built reporting in Excel | Inflated form of F5 | "solid Excel." A4's slot asks what, if anything, was built |
| Has used Power BI | A negative you stated, F6 | "I've never used Power BI." No slot |
| A named-body or named-methodology green belt, or the redesign as a belt project | Inflated form of F8 | "green belt certified," in your own words |

## Sources

- Provided: your message (the JD text and your background).
- Searches sent:
  - `Atlas Freight regional logistics company values`: refused
  - `Atlas Freight interview process operations manager`: refused
  - `Atlas Freight logistics news 2026`: refused
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have fixed whether a values cheat sheet applies, and themed H1 and H2 on real values |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have named the rounds; persona weights fell back to the generic archetype |
| 3. `Atlas Freight` strategy / recent news | unavailable | Would have grounded E3 and at least one CO or CASE question in current strategy |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting (hiring manager, peer, skip-level, HR) → persona weights stop being flat, and the banks are reordered and resized for that round
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- The recruiter's prep note → stated focus areas, and a build section for any announced presentation or exercise
- Web search permission → targets 1 to 3 run: values cheat sheet if a values round exists, the real loop structure, and E3 plus a CO or CASE question grounded in Atlas Freight's current strategy
- How much prep time you have → a prioritized prep schedule sized to it
- Your answers to the answer slots, told to me outside a drill → F7 and A3 (leadership years), F2, F3 and C3 (on-time and cost accountability), F5 and A4 (Excel reports built), and F1, F4 and A1 (scope beyond your shift) move from slots to quoted, story-mapped guidance
- Your green belt certificate, and the before-and-after mis-pick report behind the 40% → F8 and C1 can be graded on inspectable evidence rather than your word alone
- Your full CV → more quoted lines, so more scaffolds become story-mapped answers
- A dossier from job-underwriter → an evidence-derived top objection and binding strategy limits for the weak areas, in place of this pack's inference
