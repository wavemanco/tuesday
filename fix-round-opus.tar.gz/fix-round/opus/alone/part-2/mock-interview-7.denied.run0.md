I've built your prep pack: 22 practice questions with answer guidance, plus a table matching each line of the job description to your background. I assumed Tobias would be your manager, since your note gives his title but not how you'd work together. The web searches for Saltmarsh's values, recent news and Tobias's public profile were refused, so anything about the company is marked generic.

The two biggest things to rehearse:
- **The step up (B1):** "You've been an associate producer on one title's weekly calendar; this role runs live events on two titles with four teams. Why are you ready?" The pack gives you a way to hold on what you actually did and name the limits yourself before he does.
- **In-app purchases (B2):** say plainly that you haven't worked on a game with in-app purchases, then give a learning plan.

Both are drafted using only your own words. If he asks about managing people, the line is just "I haven't led a team."

The pack is saved here: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-denied-da7c62eb/saltmarsh-games_live-operations-producer_interview_pack.md`

If you have time tonight, play both titles the role covers (D2). It's the cheapest way to sound prepared.

If you'd like a practice round, I'll play Tobias as the Skeptic on B1.
I can also save a tuesday-dossier.md recording the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Is Tobias your future manager, or a peer or skip-level? That changes which questions get the most weight. And how much prep time do you have before Friday? I'll add a schedule sized to it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi · **Interviewer:** Tobias Wrenfield, Head of Live Operations · **Format:** one 60-minute interview, Friday
**Relationship assumed:** hiring manager. Your note gives his title but not whether you'd report to him. If he is a peer or a skip-level, the persona weights below change.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: the interviewer's style. **Types** describe *what* is being scored.
- Type key:
  - **JD**: can you do the listed job, gaps included
  - **EXP**: does your background hold up under close questioning, and what was actually yours
  - **CASE**: a live problem from the role, solved out loud
  - **CO**: company and strategy homework
  - **VAL**: values and behaviour, shown through past conduct
- Provenance labels: `[grounded]` means it comes from your JD or your own words. `[inferred]` means it is a derivation, and the pack names what it derives from. `[generic]` means it is a role-family pattern that makes no claim about Saltmarsh.
- An **answer slot** is a place where only you know the truth. It gives you two honest branches. Answer whichever one is true, in your own words.
- Question banks are lettered A to E, then G and H. There is no bank F, so bank IDs never get confused with fit-snapshot rows (F1–F10).
- The guidance is scaffolding, not a script.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title and weekly content drops. The JD says two titles and live events. Keep the words at their own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "plan" makes a probe on who decided what went into the calendar likely. If deciding what went in, and when, was yours, say how you decided, in your own words. If it was set for you, or there was no such step, say so plainly and stay with running it. Answer slot: the JD says "mobile titles". If your main title was on mobile, say so. If it was not, say so plainly |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but it's a statement with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: weekly, main title, two years |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show coordination across these disciplines. It doesn't rule it out either. Answer slot: if running the weekly calendar meant working with design, art, engineering or community people to get drops out, say which ones and what you did with them, in your own words. If it didn't, say so plainly and describe how the calendar actually ran. Keep this separate from F10: coordinating work and leading a team are different claims |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly numbers. It doesn't say you owned a post-event review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "own … the KPIs" makes a probe on who produced the numbers likely. If you compiled them or chose what to show, say how. If they came to you ready-made, say so plainly and stay with presenting them |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, and it's your strongest line: you wrote it, and QA still uses it. Lead with "wrote", never "managed". Answer slot: the JD's "manage" makes a probe on how the checklist was run on each release likely. If you ran it with QA on releases, say how. If QA ran it without you, say so plainly and stay with having written it |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in role-relevant terms, but a prober will go one level down. Answer slot: if you know how retention was defined and counted for your title, say so in your own words. If you don't, say so plainly. "I presented them; I didn't build the definition" is a complete answer if it's true |
| F7 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Four years clears the length. Your material doesn't say whether the title was run as a live service. Answer slot: if it was, describe how in your own words. If it wasn't, say plainly what kind of game it was and stay with the weekly calendar |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | A checklist other people still work from is written work. Whether it shows clarity is the interviewer's call, so describe it and let them judge. Answer slot: if you wrote other things people relied on, like reports, briefs or release notes, name them. If not, stay with the checklist |
| F9 | Live-event KPIs on mobile titles commonly include monetization measures (role-family pattern, not in the JD) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap you've stated, and wording cannot close it. Words: "I haven't worked on a game with in-app purchases." Then say how you'd learn, as a plan and never as a past. Add nothing to make the gap feel smaller |
| F10 | Producer roles at studios of this size often involve directing other people's work (role-family pattern, not in the JD) | "Never led a team" — your message | none | [grounded] | capability | A gap you've stated. Words: "I haven't led a team." The JD asks you to coordinate teams, not lead one, so don't volunteer this as a weakness against the JD. Say it plainly if you're asked |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A1, A4, B1, E1 |
| Coordinate design, art, engineering and community (F3) | A2, B1, G1, G2 |
| Own the post-event review and its KPIs (F4) | A3, A5, C3 |
| Manage the release checklist with QA (F5) | A2, D3, H2 |
| 3+ years live-service games or apps (F7) | B1, D1 |
| Running a content calendar (F2) | A1, C2, E1 |
| Comfortable with retention metrics (F6) | C1, C2, A3 |
| Clear written communication (F8) | A5, D3 |
| Not in the JD, but it's your stated gap: in-app purchases (F9) | B2, E2 |

---

## Persona table

The loop is set by your own words: one 60-minute session with the Head of Live Operations. It includes no values round, so there's no values cheat sheet.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Plan the calendar for two titles", "this event's numbers dipped", "this fix won't make the cut" | High. The hiring-manager prior puts it on top, and every JD line is an operating problem he'd want to watch you solve | Clarify, then objective, then structure, then metrics, then risks. Think out loud, and challenge one premise respectfully |
| Skeptic | Probes the step from associate producer on one title to producer on two, and the in-app-purchase gap | High. The second hiring-manager prior. F1, F3, F9 and F10 are exactly where a careful reader of your background will press | Rehearse B1 until it's boring. Hold only on what your quotes carry, and concede F9 and F10 plainly |
| Data-Driven Prober | Goes underneath "presented the monthly retention numbers" | Medium. The JD names retention metrics and KPIs, and F4 and F6 are claims with nothing inspected behind them | Know what you can and can't say about how the numbers were counted. "I don't know" is allowed |
| Conversational | The opener, the "what have you been playing", and the reverse-question slot | Medium. Every 60-minute interview has an opener and a close, and both are scored | A 90-second arc built from your own sentences, plus real homework on their games |
| Pressure | "How much of that was actually you?", sixty-second challenges | Low to medium. There's no signal for it, but the associate title invites the attribution question | Pause, restate the question, anchor in your quote, hold through two follow-ups |
| Peer Evaluator | Seams with community and engineering, disagreements between disciplines | Low. He isn't a peer, but the JD's coordination line brings the same questions in a manager's voice | Propose seam principles. Don't claim to know Saltmarsh's seams |
| Values / Behavioral | Generic "tell me about a time" prompts | Low. No values round was named, and Saltmarsh's published values couldn't be researched | Selection scaffolds. Say so if no story fits |

---

## Question banks

### A — Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're taking over the live-events calendar for two titles. What do you need to know in your first two weeks, and how would you build the next quarter?" | CASE | [generic] | Clarify first: each title's audience and goals, what events already exist, team capacity per discipline, release cadence and constraints. Objective: what each event is for, such as retention, re-engagement or another stated goal. Structure: one shared view of both calendars so collisions on art or engineering show up early. Risks: overlapping events competing for the same players or the same people. This guidance makes no claim about your past. If you mention your own calendar, use F1's quote as written | The JD's first line, asked as a live problem. CASE because it scores structure, and the likeliest opener for the hiring-manager prior |
| A2 | "Two days before an event goes live, engineering tells you a fix won't make the release. What do you do?" | CASE | [generic] | Find out what's broken and what the fix affects. Get the options on the table: ship without the fix, cut or change the affected content, or move the date. Ask design and community what each option costs players. Agree with QA what has to pass. Decide with the person who owns the call, and tell community before players notice. If you mention your release checklist, say only that you wrote it and QA still uses it | Combines the JD's coordination and QA-checklist lines. A classic live-ops pinch point that tests whether you can be calm, quick and clear |
| A3 | "Day-7 retention for this event's players came in lower than the last event's. Walk me through how you'd diagnose it." | CASE | [generic] | Check the measure first: same definition, same cohort, any tracking change. Then segment by new versus returning players, platform and region. Then the event itself: difficulty, rewards, length, and timing against other events or releases. Then outside factors: competitor launches, holidays, store featuring. Say what you'd want in the post-event review and which conclusion you'd trust least. Make no claim about having run this analysis before | The JD's post-event KPI line and F6's metric comfort, tested live. The Prober's favourite question in a manager's voice |
| A4 | "Both titles want the same art team for events in the same month. How do you decide?" | CASE | [generic] | Clarify each event's goal and how much it matters, and whether either date can move. Look for ways to share or reuse work. Bring a clear trade-off to whoever owns the priority call, rather than deciding it quietly. Write down the outcome so both teams see the same answer | The JD's "two of our mobile titles" is the step up from F1's one title. This tests whether you'd handle the two-title load sensibly |
| A5 | "What goes into a post-event review you'd write here, and who reads it?" | JD | [generic] | Cover: what the event was meant to do, what happened against that, the KPIs with their definitions, what surprised you, what you'd change, and owners and dates for each change. Keep the top summary short enough for a busy reader. Ask him who reads it today: that's a fair question back. Don't describe past reviews you haven't written | The JD's "own the post-event review", plus its clear-writing requirement. JD-typed because it scores the stated duty directly |

### B — Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've been an associate producer running one title's weekly calendar. This role runs live events for two titles and coordinates four disciplines. Why are you ready?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | **Highest-ROI prep in this pack.** Hold with what the quotes carry and nothing more: four years as an associate producer, two years running the weekly content-drop calendar, the checklist QA still uses, presenting monthly retention numbers. Name the limit before he does: one title, not two. Answer slot (coordination): if running the calendar involved design, art, engineering or community people, say who and what you did with them, in your own words. If it didn't, say so plainly and stay with how the calendar ran. If he asks about leading people: "I haven't led a team." Then give your ramp for the first 90 days as a plan. Follow-up 1, "but weekly drops aren't live events": answer the F7 slot honestly. Follow-up 2, "so it's a big jump": agree that it's a step up, and hold on the calendar you ran | This is the single most predictable objection, because F1, F3 and F10 meet here. JD-typed because it scores the core mandate against your record |
| B2 | "You haven't worked on a game with in-app purchases. If an event here has a revenue goal, how do you get up to speed?" | JD | [grounded] "never worked on a game with in-app purchases" | First sentence: "I haven't worked on a game with in-app purchases." Don't soften it. Then a plan, said as a plan: learn the economy from whoever owns it, read past post-event reviews, ask which numbers this team trusts. Never suggest any of this is familiar | F9 is your stated gap. JD-typed because it's the KPI ownership line seen from the monetization side, and it's conditional because the JD itself doesn't name revenue |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" "Never led a team" | Pick one real gap and say it plainly. B2's in-app-purchase acknowledgment is the cleanest, because you stated it yourself. Or choose two titles instead of one, which is the pack's reading of F1, not your words. Then say what you'd do about it in the first month. Don't dress a strength up as a weakness | A Skeptic stem that tests honest self-assessment. JD because the answer is judged against the job |
| B4 | "Have you managed people?" | EXP | [grounded] "Never led a team" | "I haven't led a team." Stop there for a beat. If he asks what you've done with other people's work, that's the F3 slot: answer whichever branch is true. Don't present working alongside people as leading them | F10 is a stated gap. EXP because it checks your record directly |
| B5 | "Why live ops, why Saltmarsh, why now?" | EXP | [generic] | Answer slot: give your own reasons for wanting this role and this studio, in your own words. If part of the reason is moving up from associate producer or onto more than one title, say so. Tie "why Saltmarsh" only to things you've actually seen in their games | The Skeptic's consistency check. Generic because the reasons are yours and the company research couldn't run |

### C — Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When you presented the monthly retention numbers, how was retention defined and counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know the definition and where the numbers came from, explain them in your own words, and name the assumption behind them you'd trust least. If you don't know how they were counted, say so plainly and stay with presenting them. Never describe a method you didn't use | F6 and F4 are where a prober goes first. EXP because it tests what was actually yours |
| C2 | "Did your weekly drops move retention? How would you know?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Answer slot: if you ever looked at drops against retention, say what you saw and how confident you were. If you didn't, say so plainly. Then say how you'd test it now, for example by comparing players who engaged with a drop to similar players who didn't. Don't claim cause and effect you didn't measure | Connects F2 and F6, the link the JD's KPI line implies. It tests whether you know the difference between correlation and impact |
| C3 | "Which KPIs would you put in a post-event review, and which would you be suspicious of?" | CASE | [generic] | Participation and completion, retention of event players against a baseline, and the event's own goal metric. Be suspicious of totals with no baseline, events whose dates overlapped other changes, and small cohorts. Say why for each | The JD's "the KPIs it reports". CASE because it's judgement shown live |

### D — Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | 90 seconds, with four beats taken straight from the quotes: four years as associate producer at a puzzle-game studio, two years running the weekly content-drop calendar, the release checklist QA still uses, and presenting monthly retention numbers to the studio head. Close with why this role, using your own B5 reasons. Use "associate producer", never shorten it to "producer" | Almost certainly the opener. Scored for economy even though it sounds casual |
| D2 | "Have you played our games? What did you notice?" | CO | [generic] | Tonight: play both titles the role covers, ideally during an event. Note what the event asked of you, how you found out about it, and one thing you'd want to understand better. Only say what you actually saw. Company research couldn't run, so don't quote anything about Saltmarsh you haven't seen yourself | The one CO question, and generic because research was refused. It's the cheapest way to sound prepared |
| D3 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Lead with the fact that you wrote it and QA still uses it. Answer slot: if you remember why you wrote it and what it covers, say so in your own words. If you updated it as releases changed, say how. If you didn't, say so. Don't add incidents it caught unless they happened | F5 and F8, your strongest lines. Expect them to come up as a friendly question |

### E — Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Associate producer. How much of that calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause. Then: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if deciding what went into it was yours, say how. If someone else set it, say who decided and what running it meant for you. Hold through two follow-ups by repeating the calendar, never by adding to it | The associate title invites the attribution probe. F1 is the claim under test |
| E2 | "Sixty seconds: why you over someone who's already run live ops on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" "Wrote the release checklist our QA team still uses." "I ran the weekly content-drop calendar for our main title for the last two years." | Concede first and plainly: "I haven't worked on a game with in-app purchases." Hold on what the quotes carry: the calendar you ran for two years and the checklist QA still uses. Close with your learning plan. Don't attack the hypothetical rival | Hold-then-concede practice on F9. JD-typed because the rival is framed by the job |

### G — Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Mid-event, community says players hate the difficulty. Design wants to hold the line. What do you do?" | CASE | [generic] | Get the facts: how widespread the complaints are and what the numbers show. Ask design why they want to hold it. Lay out the options: change it now, change it next time, or explain it to players. Agree a decision with the owner and get the message to players quickly through community | The JD's coordination line between design and community, tested on the seam |
| G2 | "Tell me about a time you disagreed with another discipline about a release." | VAL | [generic] | Selection scaffold: pick a time when there was a real disagreement, you said where you stood, and it was settled with the working relationship intact. Use "we" for the context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt built from the Peer stem and the JD's coordination line. None of your quotes carries a story like this |

### H — Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you had to tell leadership something they didn't want to hear." | VAL | [generic] | Selection scaffold: it needs a named stake, what you said, and what happened next. If you had a moment like that while presenting numbers to the studio head, use it in your own words. Don't assume the numbers were bad news. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem. F4's presenting role is the nearest setting, but the quote carries no such moment |
| H2 | "Tell me about a release that went wrong." | VAL | [generic] | Selection scaffold: what broke, what you did that day, and what changed afterwards. If something like this led to your checklist, say so only if it's true. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's QA checklist line raises it. Nothing in your quotes describes a failed release |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a great post-event review look like here, and what decision does it feed?" | It goes straight at the JD's ownership line and shows you care what the review is for |
| R2 | "How do the two titles' calendars relate? Do they share teams, or run separately?" | It's the biggest unknown in the role, and his answer tells you how A4-style trade-offs really work |
| R3 | "Which KPIs does the review report today, and is there one you wish it reported?" | It invites him to share his priorities, including any monetization angle, without you claiming expertise |
| R4 | "How does the release checklist with QA work today, and who owns which sign-offs?" | It plays to your strongest line (F5) and shows you'll engage with the process that exists |
| R5 | "What would make someone in this role a clear success after six months?" | It gives you his scorecard, and you can answer against it in the follow-up email |
| R6 | "What's the hardest part of running live operations here right now?" | It asks the Head of Live Operations about his own area, and starts a working conversation rather than an interrogation |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events for two titles, or for several titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says one title and weekly content drops |
| Owned post-event reviews, or owned the KPIs | Inflated form of F4 | F4's quote at its own scope: you presented the monthly numbers. The C1 slot stays inside presenting |
| Managed the release process | Inflated form of F5 | "Wrote the release checklist our QA team still uses." The F5 slot asks only how the checklist ran |
| Built or defined the retention metrics | Inflated form of F6 | F6's quote at its own scope. The C1 slot allows "I didn't build the definition" |
| Producer (rather than associate producer) | Inflated form of "4 years as an associate producer at a puzzle-game studio." | Say the title as it was |
| Has monetization or in-app-purchase experience | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative you stated, F10 | "I haven't led a team." No slot |

---

## Sources

- **Provided:** the JD text and your background, both from your message. No dossier was present.
- **Searches sent (all refused, so nothing came back):**
  - "Saltmarsh Games values" — refused
  - "Saltmarsh Games interview process producer" — refused
  - "Saltmarsh Games mobile studio news 2026" — refused
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Search refused. It would have supplied the values themes for the H bank and, if a values round turned up, a cheat sheet |
| 2. `Saltmarsh Games interview process producer` | unavailable | Search refused. Your own words already establish the session, so it would only have confirmed it or added a case format |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Search refused. It would have turned D2 and the CASE bank from generic into Saltmarsh-specific |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Search refused. It would have supplied an interviewer read, adjusted persona weights and a reverse question tied to his career |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Who Tobias is to you** (your future manager, a skip-level or a peer) → persona weights rechecked, and bank G grows if he's a peer
- **The recruiter's prep email**, if there is one → coverage of any announced task, such as a calendar exercise or a written review
- **How much prep time you have before Friday** → a prioritized triage schedule at the top of the pack
- **Allowing web search** → Sources rows 1–4 run: real Saltmarsh values, recent news for CO and CASE questions, and Tobias's public footprint for an interviewer read. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) adds a strategy brief
- **The names of the two titles** → D2 and A1 become specific to those games
- **Your answers to the answer slots in F1, F3, F4, F5 and F7** (did you set the calendar's contents, which disciplines you worked with, who built the numbers, whether the title ran as a live service) → those rows' bridges, and B1, C1, E1, become story-mapped answers
- **A tuesday-dossier.md from an earlier evaluation of this role** → evidence-graded gaps and a binding prohibited list in place of the ones built here
