Reading the skill's rules before building the pack; a few reference files are left.
Now running the default research pass: company values, interview process, and a quick check of the strategy note.
Web search permission was refused, so I'm building the pack from your notes alone and labeling the research gap.
I've built the mock-interview pack as one markdown file, saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-1-denied-edd27065/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`.

**One gap first:** I wasn't given permission to run web searches, so none of the company facts are checked. Northwind's priorities, Compass and the bundling threat come only from your research note. Dan's profile comes only from your notes on him.

**What's in it:**
- **Fit check:** her evidence against each of the six JD lines, plus a seventh row for the sales-ops and quota gap you noted.
- **Personas:** seven interviewer styles, weighted for Dan. The top two are the numbers prober and the peer focused on how the two teams would split work, because he's a peer and calls himself "relentlessly data-driven."
- **21 questions**, one table per persona. Each row has the question type, the evidence it draws on, answer guidance and the reason it's included.
- **Reverse questions** for Priya to ask Dan.
- **Claims the pack won't coach.**

**The question to rehearse most is D1:** "I don't see quota-setting or classic sales ops in your background. Why should Sales Strategy trust your GTM calls?" That gap is Dan's own territory, so some version of it is very likely. The guidance has her admit the gap plainly first, then describe what she actually did, then give a plan for the role.

**Second priority is the ~$400M.** Your note says she *proposed* the store-surface change and that it was *credited with* the uplift. The pack keeps both words everywhere. Dan will probably ask how the figure was counted, and "I don't know how it was counted" is a fine answer if it's true.

Because I only had your summary of her background, many answers have two honest branches: one if she did the thing, one if she didn't. Her CV, or her own account of the big three stories, would turn those into full story-based answers.

- **Drill:** I can play Dan in a live rehearsal of D1 and follow up on what she actually says.
- **Dossier:** I can also save a `tuesday-dossier.md` with the gaps this prep exposed, for later sessions.
- **Word:** I can convert the pack to a Word document if that's easier to share.

1. Can you paste the full JD text and Priya's CV, or her own description of the $400M change, the partner model and the volume targets? I can keep going without them, but they would firm up most of the answers.
2. Did the recruiter name any focus areas for the conversation with Dan, or ask Priya to prepare anything?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. He would be a **peer**, and both report to the same VP.
**Format:** one 60-minute conversation.

---

## How to use this pack

Read every question along two axes:

- **Persona** is how the question is asked: the style, the register, and what the interviewer is quietly checking for. The banks are ordered by how likely each persona is to show up in Dan's conversation.
- **Type** is what the answer is scored on.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's values, not generic virtue |
| EXP | Whether claims about past work hold up under scrutiny, and how honestly credit is assigned |
| JD | Whether she can do the job as listed, including the parts where she has gaps |
| CO | How deep her company homework goes: strategy, competition, current priorities |
| CASE | Her structure and reasoning on a live problem from the role |

**The guidance is scaffolding, not a script.** Each guidance cell names the beats an answer should hit. Priya should say them in her own words and say only what she actually did. An **answer slot** marks a place where the material doesn't show what happened. It gives two honest branches and she picks whichever is true. Provenance labels: `[grounded]` means traceable to what you gave me, `[inferred]` means derived from it with the derivation named, `[generic]` means a role-family pattern with no claim about Northwind or Priya.

Question IDs run A–E, then G and H. The letter F is reserved for fit-snapshot rows (F1–F7).

---

## Fit snapshot

Requirements are quoted from the JD highlights you supplied. Evidence is quoted from your notes on Priya. Nothing behind any of it has been inspected, so expect Dan to probe every row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy and ops, not ownership of GTM for new product lines. Her words stay at that scope: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's ownership line makes a probe on launch decisions likely. If some go-to-market decisions for a launch were hers to make, she says which ones and how she decided, in her own words. If none were hers, she says so plainly and stays with the product strategy work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | One proposed change is not a whitespace map across a customer lifecycle, so don't stretch this bridge. Answer slot: the JD's whitespace line makes "how did you find that opportunity?" likely. If she found it through analysis of where growth was missing, she says what she looked at, in her own words. If it came about another way, she says so plainly and stays with what she proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but this is a skills line with nothing inspected behind it, and Dan may test it live. She names the tools plainly. Answer slot: the JD's "independent analysis" line makes "show me" likely. If she has an analysis she wrote herself, she says what question it answered. If none comes to mind, she says so and talks through how she would structure one |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model used in partner negotiations is adjacent work, not the design of a partner motion. Her words stay at that scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on motion design certain. If any part of how the carrier partnerships were structured was hers to shape, she says which part and how. If none was, or the model only informed the negotiations, she says so plainly and stays with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement in different words. Reword only the quote: "I set our annual volume targets, with consensus across orgs." Answer slot: the JD's influence line makes "how did you get that consensus?" likely. If she brought the orgs to agreement, she says how, in her own words. If the consensus came about another way, she says so plainly |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | transferability | Using AI tools is not AI product or AI GTM experience. Her words: "I use AI tools daily." Answer slot: the JD's AI line makes "for what?" likely. If there are specific uses in her analysis work, she names them in her own words. If her use is mostly general, she says so plainly |
| F7 | B2B sales-motion fluency (quota, territory and pipeline mechanics), typical of a GTM strategy role that sits beside a sales strategy team. This is a role-family requirement and is not in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | No wording can close this gap, and your notes state it. Her words: "I haven't done classic sales-ops or quota-setting work." After that, she can describe how she would learn the area, said as a plan and never as past experience. Don't add anything to make the gap feel smaller |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 own GTM strategy for two new product lines | C3, B1, D3 |
| F2 whitespace across land/adopt/expand/renew | A3, A4, C3 |
| F3 independent analysis in SQL and Tableau | A3, A4, B2 |
| F4 partner-motion design (required) | D2, A2, C3 |
| F5 cross-functional influence | B3, A5, B1 |
| F6 AI experience (a plus) | E2, C2 |
| F7 sales-motion fluency (role-family, not in JD) | D1, G1 |

---

## Reading the interviewer

Public professional footprint only, as relayed in your notes. I couldn't verify any of it (see Sources).

| Signal | Provenance | What it means for this conversation |
|---|---|---|
| Profile self-describes as "relentlessly data-driven" | [grounded] | Every number Priya says will be probed down to its assumptions, the ~$400M first. Practice saying "I don't know how that was counted" as calmly as she says what she does know |
| Career spine of pricing and monetization roles | [grounded] | Case questions will probably tilt toward pricing, packaging and unit economics, which is his native language. C1 and C2 are written for that |
| One early-stage-startup chapter | [inferred] | Builder stories land well with people who have done 0→1 work. Expect a scrappiness probe on big-company pace (D3, G1). Inferred from the career pattern only |
| Peer, same VP | [grounded] | He is weighing what this hire adds to or takes from his own team's work. The seam between Sales Strategy and GTM Strategy is the likeliest collegial pressure point (B1, B2) |

**Mirror opportunities.** *Shared vocabulary:* revenue modeling, from F4 ("built a partner-level revenue model used in carrier negotiations"). Priya can describe that work in its own terms, and it sits close to his monetization language. *Shared career jump:* none offered. No row of Priya's evidence carries her side of a jump like Dan's.

---

## Persona table

Weighting starts from the peer-interview baseline (Peer Evaluator and Data-Driven Prober dominant), then adjusts for Dan's signals. The loop is established by your own words: one 60-minute conversation with Dan, so no archetype fallback was used.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | Asks for denominators, inputs and the assumption behind each number; follows up two levels deep | Highest. Peer baseline, plus his "relentlessly data-driven" self-description | Know what she can and can't say about how each figure was counted. Name the weakest assumption before he does. Offer to walk through an analysis end to end only if it's hers |
| Peer Evaluator (B) | "Where's our seam?", "What do you need from me?", credit-sharing probes | High. Peer baseline; he shares her VP | Use reciprocity framing. Propose principles for the seam rather than pretending to know it. Have a disagreement story ready |
| Case / Strategist (C) | Live pricing, packaging and GTM problems on Northwind's real priorities | Medium. Raised by his pricing and monetization spine | Clarify, then state the objective, segment, give the approach, the metrics and the risks. Use Northwind's three priorities as the frame |
| Skeptic (D) | Quiet probing of the consumer-to-B2B jump and the missing sales-ops background | Medium. Not a peer default, but the F7 and F4 gaps sit right on his turf | Rehearse D1 until it's boring. Concede plainly, then return to what she did |
| Conversational (E) | "Walk me through the journey" and casual AI chat | Low, but present: openers are still scored | A pre-built 90-second arc. Treat casual AI questions as scored |
| Pressure (G) | A time-boxed "why you" and attribution challenges | Low. Nothing in his profile signals stress interviewing | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Values / Behavioral (H) | Classic behavioral prompts | Low. No values round in this conversation, and Northwind's published values aren't in hand | Two selection scaffolds, so the style never arrives cold |

---

## Question banks

### A. Data-Driven Prober (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "That ~$400M ARR uplift: walk me through how it was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the quote's own attribution: she proposed the change, and it was credited with roughly $400M. Keep the "roughly." Then cover the four answers a figure needs, each in her own words: how it was counted, what it is sensitive to, the assumption behind it she'd defend least, and which part was hers. "I don't know exactly how it was counted" is an honest answer. Never offer a baseline or attribution method she couldn't repeat under a second question | This is the headline metric in a prober's interview, so it will be asked. EXP because it tests whether the figure and the credit hold up. "Credited with" is the phrase he'll pull on |
| A2 | "Tell me about the partner-level revenue model that was used in the carrier negotiations. What went into it, and how confident were you in what it said?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4. She built it, it was partner-level, and it was used in carrier negotiations. Those are the beats the quote states. Answer slot: describe what went into it in her own words, and if parts were built by others, say which. If she checked its output against anything, say what; if she didn't, say so plainly. Answer slot from the JD's partner-motion line: if the model shaped how the partnerships were structured, say how; if it only informed the negotiations, say that | F4 is her closest evidence to a required JD line, and Dan's monetization background makes revenue models the thing he knows best. EXP because it verifies the work before D2 tests the gap |
| A3 | "Say you have an accounts table and a product-usage events table. How would you find accounts using product A that haven't adopted product B? Write it or talk it through." | CASE | [generic] | Clarify the grain first (account or user) and what "using" means, such as a threshold over a time window. Then: aggregate events per account and product, keep accounts over the threshold on A, and anti-join to B with a NOT EXISTS or a left join where B is null. Say how she'd sanity-check it, for example row counts before and after the join and a few accounts spot-checked by hand. Then the Tableau view: the gap list cut by segment and account size, so sales can act on it. If asked to write it, write it and narrate as she goes. This question needs no claim about her past | A live test of F3's "independent analysis" line, with an expand-whitespace framing that touches F2. CASE delivery on JD content. A data-driven peer may well check the SQL claim directly |
| A4 | "How would you size the expand whitespace for a new product line across our installed base? What's your denominator?" | CASE | [generic] | Structure it aloud: installed base, then accounts eligible for the new line, then a likely attach rate, then price per account, which gives the expand whitespace. Settle the denominator first: accounts, workspaces or seats. Name the weakest assumption before he does. For a new line with no history it's usually the attach rate. Say how she'd bound it, for example with a pilot cohort or analog products, and what result would change her mind | Covers F2's whitespace mandate as a live problem. The denominator question is the prober's signature move. A CASE, so it presupposes nothing about her past |
| A5 | "Walk me through how the annual volume targets were set, and how the cross-org consensus came together." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Stay at the quote's scope: she set the annual volume targets, and they had cross-org consensus. Answer slot: if the method behind the targets was hers, describe it in her own words; if it was handed to her or inherited, say so plainly. Answer slot from the JD's influence line: if she brought the orgs to agreement, say how; if it came about another way, say so. Don't call them quotas. To a Director of Sales Strategy that word means something specific, and F7 is the honest limit | F5 is her influence evidence. Volume targets sit next door to Dan's quota world, so he'll probe the method and compare it with his own. EXP because it tests what was actually hers |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams would sit side by side. Where's the seam between Sales Strategy and GTM Strategy for emerging products, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know the seam. Propose a principle, for example: whoever owns a number owns the final call on it, and the other team gets a defined input before it's set. Then ask how the split works today. On disagreement, she can say she'd want to settle it with shared data before it goes to their VP. That's a working principle, not a claim about her past | The classic peer probe, and with a shared VP the turf question is real. CASE because it scores how she reasons about an org she can't see yet. It also tests F1 (owning GTM) and F5 (influence) at the seam |
| B2 | "What would you need from my team in your first 90 days, and what would you give back?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first. What she'd give back: independent analysis, which rests on F3, so she offers her SQL and Tableau work rather than asking his team to run queries for her. What she'd need: pipeline and segment definitions, pricing context, and his view of where emerging products help or complicate the core motion. Keep the ask list short and specific | Peers price the hire's load on their own team. JD because it tests the "independent analysis" line through what she'd take versus contribute |
| B3 | "Tell me about a time you got agreement across orgs that didn't report to you." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets she set, and the cross-org consensus they had. Those are the beats the quote states. Use "we" for context and "I" for her own part. Answer slot from the JD's influence line: if she brought the orgs to agreement, say how, in her own words; if the consensus came about another way, or wasn't hers to build, say so plainly and stay with the targets | An open prompt on a stated JD requirement. The theme comes from the JD's influence line, and F5 is her one story for it |
| B4 | "How do you handle credit when work spans teams? Take the store-surface change." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The quote's verb is "proposed," and that is the answer's spine: she proposed it, and the change was credited with roughly $400M. Answer slot: if any part of building or shipping it was hers, say which; if others built and shipped it, say so plainly. Naming them is the credit answer. Never upgrade "proposed" | A peer version of the attribution probe in A1 and G2, in collegial packaging. EXP because it tests attribution honesty on her biggest claim |

### C. Case / Strategist (pricing-tilted for Dan)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles a good-enough version of one of our new products into its suite. How do you respond on packaging and pricing?" | CASE | [grounded] | Clarify first: which segment, and how deep the overlap is. State the objective with Northwind's priorities from your research note, and name the tension between protecting enterprise expansion and reaching profitability. Then the options: compete on what the bundle can't easily offer (depth, neutrality across platforms), package into existing enterprise contracts so it becomes an expansion motion, and price on a value metric rather than matching free. Challenge one premise: is the bundle really free to the buyer once switching and integration costs are counted? Metrics: win rate against the bundled competitor, and net retention. Risk: discounting to fight a bundle cuts into profitability | The bundling threat from your research note, put in Dan's pricing language. CASE delivery on CO content. It's the differentiator question most candidates answer generically |
| C2 | "Compass, our AI copilot: included, paid add-on, or usage-based? Make the call." | CASE | [grounded] | Make a call; don't just list options. Frame it with the three priorities: an add-on supports enterprise expansion, usage-linked pricing protects margin if serving costs scale with use, which supports profitability, and including a base tier blunts a bundle. One possible answer is a base tier included plus a paid or usage tier, but she should choose and defend her own. Name the weakest assumption, for example adoption rate or serving cost per user, and say what data would settle it. Don't state facts about Compass beyond its existence and its AI-copilot launch | Compass is one of the three stated priorities, and pricing it sits directly in Dan's career spine. It also touches F6's "AI a plus" without needing any claim about her past |
| C3 | "Pick one of the two new product lines. How do you plan its GTM across land, adopt, expand and renew? What do you need to know first?" | JD | [grounded] | Clarify: who buys it, and whether it lands net-new or into the installed base. The research note's enterprise-expansion priority makes "expand first" a hypothesis to test, not an assumption. Then one motion and one metric per stage: land (win rate, time to first value), adopt (active usage), expand (attach rate, net expansion), renew (gross retention). Say where partners could carry part of the motion, as a plan. That gives F4's required area a forward-looking answer. Close with the risk: the bundling threat lands hardest at renew | The core mandate (F1, F2) as a live problem, and a natural place to show partner-motion thinking (F4) as a plan rather than a past claim. JD content, CASE delivery |

### D. Skeptic: holds the highest-ROI prep in the pack

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see quota-setting or classic sales ops in your background. Why should Sales Strategy trust your GTM calls on enterprise products?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI rehearsal in this pack.** *Concede first, plainly:* "I haven't done classic sales-ops or quota-setting work." *Then what she did, at its own scope:* "I set annual volume targets, with cross-org consensus, and I built a partner-level revenue model that was used in carrier negotiations." Describe it; don't claim it "transfers," and let him draw that conclusion. *Then a plan:* she'd learn his team's quota and capacity logic before proposing anything for the new lines. **Follow-ups to hold through.** (1) "Volume targets aren't quotas." Agree without rearguing: "Right, they aren't," then go back to describing what she did. (2) "So what do you actually do in quarter one?" The plan, still framed as a plan. (3) "Shouldn't this be a sales-ops hire?" Hold without arguing that the background doesn't matter: ask what he'd see as the day-one must-have, and answer that. The limit is named before he names it, and nothing is added to make it smaller | The most predictable objection to this candidate in this room: F7 sits exactly on a Director of Sales Strategy's home turf. The negative in the question comes from your notes, so the plain acknowledgment has a source. JD because it scores fit to the role as he'd see it. Rehearse it out loud until it's boring |
| D2 | "Partner-motion design is required for this role. What partner motion have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of how those partnerships were structured was hers to shape, say which and how; if none was, say so plainly and stay with the model. The honest branch is a limit, not a confession. Then, as a plan: how she'd approach designing Northwind's partner motion for a new line. Who partners with, what each side gets, and how she'd measure it | F4 is the gap against the one JD line marked "required." A peer whose career is monetization will press on it. JD because it scores the stated requirement directly |
| D3 | "You've spent nine years in consumer tech. Why B2B data infrastructure, and why now?" | EXP | [grounded] "then 9 at a large consumer-tech company in product strategy & ops" | The reason has to be hers, and this pack can't supply it. A strong answer names a specific pull toward this work, gives an honest "why now," and doesn't criticize consumer tech. If her real reason is simpler than that, she says it plainly. Expect a scrappiness follow-up given Dan's startup chapter. If she has a fast-moving, small-team story, she tells it in her own words; if not, she says so and describes how she'd work at Northwind's pace | The why-leave, why-here, why-now probe that any domain-switching candidate gets. EXP because it tests whether her motivation story holds up. Its premise is F1's own quote |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" "then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc built only from the quotes: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Name at most two pieces of work, using their own phrasing from the snapshot (for example F4's model and F2's proposal). End with why Northwind's emerging products, in her own words. Stop at 90 seconds | The likely opener, and openers are scored on economy. EXP because it sets up every probe that follows, so nothing in it should outrun the quotes |
| E2 | "What are you actually doing with AI tools these days?" | JD | [grounded] "uses AI tools daily" | Casual register, but scored. "I use AI tools daily," then answer slot: if there are specific uses in her analysis or strategy work, name them in her own words; if her use is mostly general, say so plainly. Optionally, connect it to curiosity about how Northwind's customers would use Compass, framed as a question rather than a claim | The JD lists AI as a plus, and casual questions about a plus-skill are still scored. F6 is thin, so the honest answer should be ready |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate who already knows our sales motion?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "skilled in SQL/Tableau" "built a partner-level revenue model used in carrier negotiations" | Pause, then concede the real point: an internal candidate knows Northwind, and "I haven't done classic sales-ops or quota-setting work." Then two items from the quotes, in their own words: SQL and Tableau, and the partner-level revenue model. Finish with what she'd do in the first 90 days, as a plan. Don't criticize the hypothetical rival. Stay within 60 seconds | A time-boxed form of D1. Rehearsing it gets the concession into her mouth under a clock. JD because it scores fit |
| G2 | "That $400M, how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change, and it was credited with roughly $400 million." Through a second challenge, hold the same sentence; don't inflate it. Then concede specifically: how the credit was assigned wasn't hers to decide. Answer slot: if part of the delivery was hers, say which part; if not, say so plainly | The pressure stem built for headline metrics. EXP because it tests attribution. The hold is only what the quote carries, which is why it survives the second follow-up |

### H. Values / Behavioral

Northwind's published values aren't in hand, so these use generic behavioral themes.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, a moment she didn't fold, and an intact relationship afterward. Use "we" for context and "I" for her part. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she'd handle it | A common behavioral stem, and a peer may use it to test spine. None of her quoted sentences carries a story like this, so the guidance is a scaffold |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a decision where a metric and a customer outcome pointed different ways and she chose the customer, with what it cost. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she'd weigh it at renewal | Relevant to the renew stage and to the profitability priority. Included so the style isn't met cold. No quote carries such a story |

---

## Reverse questions

| # | Question | Provenance | Why it lands |
|---|---|---|---|
| R1 | "You came into sales strategy through pricing and monetization. How does that lens shape what you'd want from a GTM partner on emerging products?" | [grounded] | Tied to his own path. It turns the conversation peer-to-peer and shows she looked at *him* |
| R2 | "You've had an early-stage startup chapter. What from it do you still use when Northwind launches something new?" | [grounded] | His path again, and it invites the builder stories his background suggests he values |
| R3 | "What could someone in this role do in their first month that would genuinely help your team?" | [generic] | The reciprocity question. A peer hears that she plans to lighten his load |
| R4 | "With Compass launching, where do you expect the hardest pricing or packaging call to land, and who makes it?" | [grounded] | Uses a stated priority from your research note in his native language, and quietly maps decision rights |
| R5 | "Against bundling by a much larger platform vendor, what data do you wish you had that you don't today?" | [grounded] | Speaks to "relentlessly data-driven" and gives her an opening to offer F3's analysis work concretely |
| R6 | "How do Sales Strategy and GTM Strategy split the work on enterprise expansion today, and where does work fall between the teams?" | [generic] | Lets him define the seam she'd otherwise have to guess at in B1 |

---

## Prohibited claims

Built from the fit snapshot. No guidance cell in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope: "I built a partner-level revenue model that was used in carrier negotiations." The pack's own observation is that the material shows a model, not a motion. D2's slot stays inside the carrier partnerships |
| Owned GTM for a launch | Inflated form of F1 | F1's quote at its own scope: product strategy and ops at a large consumer-tech company. The material says product strategy, not GTM ownership. F1's slot stays inside launches she worked on |
| Drove, delivered or generated the ~$400M | Inflated form of F2 | The quote's own verbs: she proposed the change, and it was credited with roughly $400M. Keep both "proposed" and "credited" |
| Drove the cross-org consensus | Inflated form of F5 | The quote at its own scope: she set the targets, with cross-org consensus. The material doesn't say who brought the orgs to it; A5 and B3's slots ask, in her own words |
| Has set quotas or done sales-ops work, including calling volume targets "quotas" | Negative stated in your notes, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting work." No slot |
| Has built or launched AI products | Inflated form of F6 | F6's quote at its own scope: "I use AI tools daily." |

---

## Sources

**Provided material:** your message. It supplied the JD highlights, your notes on Priya's background, your notes on Dan Kovac's profile, and your research note on Northwind's priorities and competitive threat. No dossier was consumed.

**Searches sent:**

- `Northwind Data values`: refused (permission not granted)
- `Northwind Data interview process GTM strategy`: refused (permission not granted)
- `Northwind Data Compass AI copilot launch`: refused (permission not granted)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The only call was refused. It would have moved bank H from generic themes to Northwind's published values. It would not have added a values cheat sheet, because this conversation isn't a values round |
| 2. `Northwind Data interview process GTM strategy` | unavailable | The only call was refused. It would have shown where Dan's conversation sits in the wider loop. This session's persona weights rest on your own words, which establish the conversation |
| 3. `Northwind Data` strategy, recent news | unavailable | The only call was refused. It was meant as a quick check that your research note is current and genuine. It would have confirmed or refreshed the facts that feed C1, C2, C3, R4 and R5 |
| 4. `Dan Kovac Northwind Data` | unavailable | No call was sent, because search permission was refused for the earlier targets. It would have found any public talks or writing for the interviewer read and a sharper R1 and R2 |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied set the fit snapshot's requirements and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text:** the fit snapshot quotes the posting itself rather than highlights, mid-list requirements get their own JD questions, and the coverage table becomes complete.
- **Priya's CV, or her own words on the ~$400M, the partner model and the volume targets:** the answer slots in F1, F2, F4, F5, A1, A2, A5, B3, B4, D2 and G2 become story-mapped. A redacted model, deck or planning document (the inspectable artifact in strategy and ops work) would let F4 and F5 move above `medium`.
- **Web search permission:** runs targets 1–4. That brings Northwind's published values into bank H, gives a freshness check on the three priorities and Compass, and surfaces Dan's public talks or writing for the interviewer read.
- **Deep research pass (L2), with search enabled:** up to 6 more searches and 2 more fetches, several more minutes. It adds a strategy brief, context on the bundling vendor, and a grounding-brief section, so C1 and C2 can use Northwind's own vocabulary.
- **Recruiter or HR guidance** (focus areas, anything Priya was asked to prepare): a build section for any pre-declared deliverable, and coverage weighted to the stated focus.
- **Prep time available:** a prioritized prep schedule sized to it.
- **Schedule of any other rounds:** loop mode, with a mini-pack and persona weights for each round.
- **A `tuesday-dossier.md` from job-underwriter:** the highest-ROI objection would come from verified evidence rather than inference, and a prohibited-claims list from the underwriter would bind every cell. This pack is complete without one.
