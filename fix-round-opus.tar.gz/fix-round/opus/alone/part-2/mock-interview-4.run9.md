Reading done; running the default light research on Quartzline (values, interview process, recent news) before I build your pack.
I've saved your prep pack at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-4-denied-77195612/Quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the 45-minute hiring-manager conversation you described, using your dossier's requirements, verified evidence and prohibited claims. Quartzline research was blocked, because my web searches weren't permitted, so the company-specific questions are generic rehearsal.

- **Spend the most time on A1.** This is your dossier's objection: "never held the PM title or owned a roadmap." The answer has three beats:
  1. Plainly admit you haven't held the title or owned a roadmap.
  2. Give the 30+ integrations line as adjacent experience, never as PM work.
  3. Lay out a ramp plan for how you'd learn the job.

  A1 also includes the two likely follow-ups and the line not to cross: you never claim you set priorities for a squad.
- **Today is Thursday 12 November.** If you meant today, rehearse A1 out loud, read A4 and E2, and bring reverse questions R1 and R2. The rest of the pack is backup.
- **Several answers are written as forks.** The dossier doesn't say whether you worked with API docs, engineers, sales, or agile teams. Those answers cover both cases: if you did, say how; if you didn't, say so.

I can play the Skeptic and run A1 with live follow-ups.
I can also save your `tuesday-dossier.md` with a record of what this prep exposed, for later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday. Interviewer not named.
**Built from:** your underwriting dossier (`tuesday-dossier.md`, v1.1). The web research was refused, so every company-specific question below is `[generic]`.

---

## How to use this pack

Two labels sit on every question. **Personas** describe *how* a question gets asked, meaning the style and register. **Types** describe *what is being scored*:

| Type | What it scores |
|---|---|
| **JD** | Whether you can do the job as listed, gaps included |
| **EXP** | Whether your stated experience holds up under close questioning, and what was actually yours |
| **CASE** | How you structure a live problem from the role |
| **CO** | Your homework on the company: strategy, product, partners |
| **VAL** | Whether your past behaviour shows the company's values |

Provenance labels: `[grounded]` means the row traces to your dossier. `[inferred]` means it is this pack's own derivation, and the derivation is named. `[generic]` means it follows a role-family pattern and makes no claim about Quartzline.

**The guidance is scaffolding, not a script.** Lines in *italics* are words you could say. Lines in "quotes" are your verified dossier sentences, copied exactly. An **answer slot** is a fork for the interview: if you did the thing, say how in your own words; if you didn't, say so plainly. Both answers are honest, and both work.

Question IDs are lettered by persona. **F** is skipped because F1–F6 are the fit-snapshot rows.

---

## The fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is quoted from `verified_candidate_evidence`, with entries numbered V1–V3 in the order the dossier lists them. Grading follows the dossier wherever it graded a row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | transferability | Dossier strategy: bridge. Its condition is that the bridge is positioned as adjacent and never as PM experience. Start with the acknowledgment the dossier sources (prohibited_claims: "Having held a product manager title or role"): *I haven't held the product manager title.* Then give the quote at its own scope: *I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live.* The limit is the pack's observation: your material shows integration leadership, not product management. Don't call the integrations product work. Let the interviewer make that connection |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | capability | The dossier records this as acknowledge_gap, so there is no bridge here. Words, sourced to prohibited_claims: "Having owned a product roadmap" and prohibited_claims: "Having set prioritization for an engineering squad": *I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad.* Follow it with a ramp plan, said as a plan and never as a past: how you would learn the current roadmap, the squad leads' constraints and the partner evidence in your first weeks. Don't reach for any other row to make this gap feel smaller |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | The dossier marks this as inspectable (integration playbook provided). Use the quote at its own scope: integrations of the vendor's APIs, taken to go-live. The limit is the pack's observation: the quote is about integrating an API product, not shipping one. Answer slot: R2 makes a probe on what went live likely. If you can say what a go-live delivered for the client, say it in your own words. If you can't, say so and stay with the stages the quote names |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | Derivation: REST API integration work touches docs and schemas, but neither quote says you used or wrote them. Answer slot: if you worked from the vendor's API docs or schemas in those integrations, or wrote either, say which and how, in your own words. If you didn't, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | medium | [grounded] | transferability | The quotes cover clients and product. V3 is confirmed but has limited inspectable proof, so expect a probe, and state that limit yourself before someone else does. Answer slot: R4 names engineering and sales. If those integrations or sessions had you working with either, say how, in your own words. If not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | Dossier strategy: clarify. No verified entry speaks to this. Answer slot: if you have worked in agile delivery, describe how your team actually worked, in your own words. If you haven't worked that way, say so plainly. Then: *what I'd want to confirm is how your squads run it: cadence, and who owns the backlog* |

---

## Persona table

The session is fixed by what you told me: one 45-minute conversation with the hiring manager. A hiring manager is buying capability and de-risking gaps, so Skeptic and Case/Strategist lead.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The title gap, the roadmap gap, "why now" | **Highest.** Hiring-manager prior, plus your dossier named the title-and-roadmap objection. F1 and F2 are must-have-adjacent gaps | Rehearse A1 until it's boring. Concede plainly, give adjacent evidence at its own scope, give a ramp plan |
| Case / Strategist | Live problems: adoption metrics, prioritization, discovery, specs | **Highest.** Hiring-manager prior. The JD's four responsibilities are all case-able | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Data-Driven Prober | "30+": how counted, what was yours | **Mid.** F1/F3 carry a headline figure, and V1 is inspectable, which invites a deep dive | Know what you can and can't say about the figure. Say plainly what you don't know |
| Conversational | Opener, "walk me through your journey", casual JD topics | **Mid.** Most 45-minute hiring-manager conversations open this way; `[generic]` | A pre-built 90-second arc. Treat casual questions on JD topics as scored |
| Pressure | A time-boxed "why you", and "how much was you" | **Low.** Not the dominant hiring-manager style, but the F1 gap invites one sharp moment | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Values / Behavioral | Behavioural stems | **Low.** No values round is named for this session, and Quartzline's values weren't retrieved | Selection scaffolds, with "we" for context and "I" for your contribution |
| Peer Evaluator | Squad-lead seams, credit-sharing | **Low.** Not a peer round, but the role works through two squads | Seam principles, and reciprocity framing |

---

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | **The highest-ROI prep in this pack. Your underwriting dossier named this objection.** Three beats, under 90 seconds. **1. Concede first, plainly** (prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap"): *I haven't held the product manager title, and I haven't owned a roadmap.* **2. Adjacent evidence at its own scope:** *I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live, and I wrote the internal integration playbook my team uses.* Stop there. Don't call it product work. **3. Ramp, as a plan:** what you'd do first to learn how this team makes roadmap decisions. If the moment fits, ask reverse question R1. **Follow-up 1**, "integrations is a services job": hold by going back through the stages the quote names, never by adding to them. **Follow-up 2**, "so who set priorities?": concede specifically (prohibited_claims: "Having set prioritization for an engineering squad"): *I didn't set prioritization for an engineering squad; roadmap trade-offs are what I'd be learning.* Never fold on the integrations themselves, and never run down PMs with three years | F1 and F2 are the two biggest gaps against the must-haves, and the dossier derived this objection from your confirmed evidence. JD, because it scores R1 directly. The negatives in the question are kept because the dossier's prohibited_claims items source them |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Name the real one, not a safe one. Words (prohibited_claims: "Having owned a product roadmap"): *Owning the roadmap. I haven't owned one.* Then the ramp plan from F2, as a plan. A disguised strength ("I care too much about partners") reads as evasion here. The guidance makes no claim about your past beyond the sourced acknowledgment | F2 is a capability gap the dossier recorded. Answering this question honestly also takes the sting out of A1 if A2 comes first. JD, because it asks about the listed duties |
| A3 | "Why move from integration work into product management now?" | JD | [generic] | Selection scaffold: your actual reason, in one or two sentences, tied to something you did. If running the roadmap-input sessions is part of the reason, say how in your own words. If it isn't, give the reason that is. If you can't name a single trigger, say so plainly and say what draws you to owning outcomes rather than delivering them. Avoid "a natural next step", which explains nothing | The Skeptic's "why now" probe. It needs a motive the pack cannot supply. JD, because it tests whether you're consistent with a role whose core is product ownership |
| A4 | "Shipped API or platform products is a must-have. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Give the quote at its own scope: *I've led 30+ end-to-end client integrations of the vendor's REST APIs, through to go-live.* The limit is the pack's observation: integrations of an API product, not an API product of your own. Don't let the word "shipped" drift onto it. Answer slot: if you can say what a go-live delivered for the client, say it in your own words. If you can't, say so and walk the stages the quote names | F3 is the must-have with the widest temptation to round up. JD, because R2 is a listed must-have. The question's premise belongs to the JD, and the guidance doesn't adopt it |
| A5 | "Our two squad leads have strong opinions. Why would they follow a PM who hasn't run a roadmap?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Don't claim authority you haven't had (prohibited_claims: "Having set prioritization for an engineering squad"). Give the quote at its scope, then the answer slot: the JD's "drive delivery with two engineering squads" makes a probe on working with engineers likely. If your integrations had you working alongside engineers, say how, in your own words. If not, say so plainly and stay with the stages you led. Close with reverse question R1, because whether they follow you depends on what this PM actually decides | F2, against the JD's two-squad responsibility, plus the dossier's open authority risk. JD, because the squad responsibility is listed. The negative is sourced to the dossier's acknowledge_gap area on roadmap ownership |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Adoption of the partner API is part of this job. How would you define and track it in your first 90 days?" | CASE | [generic] | **Clarify:** how is it measured today, and is there a baseline? (The dossier lists this as unknown, so asking is diligence.) **Objective:** adoption toward what, for example partner revenue or retention. **Segment** partners by size or use case. **Funnel:** credentials issued, first successful call, first production traffic, sustained usage, breadth of endpoints. **Risks:** vanity counts like key sign-ups, and attribution across squads. Name one metric you'd distrust and why. No claim about your past needed | A listed responsibility with no stated baseline. CASE, because it's a live problem from the role. `[generic]`, because the funnel is a role-family pattern, not a fact about Quartzline |
| B2 | "You have fifteen partner requests and capacity for three this quarter. How do you decide?" | CASE | [generic] | Structure it aloud: criteria (partner value, breadth of reuse, strategic fit, cost, risk), the evidence you'd want for each, who you'd consult (the squad leads), how you'd tell the twelve you said no to, and when you'd revisit. Frame it as how you would decide, never "the way I prioritized before". Prioritization authority is on the prohibited list | The roadmap responsibility, tested live. This is the safest place to show judgment on F2's gap without claiming a past. CASE |
| B3 | "Plan discovery with integration partners for a new endpoint. What do you do first?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | You can anchor in what the quote states: you did the scoping and requirements on those integrations. Then the plan: hypothesis, which partners, interview questions, what you'd look at beyond interviews, what would change your mind, and output a short problem statement. Say the plan as a plan. The quote covers integration scoping, not product discovery, so don't rename it | The JD's "Run discovery with integration partners", where F1/F3's adjacent work is closest. CASE |
| B4 | "Walk me through how you'd spec a breaking change to a partner-facing API." | CASE | [generic] | Structure: why the change, who it breaks (usage data), options short of breaking it, versioning and a deprecation window, migration guide and docs, partner comms and timeline, and how you'd measure migration. Name the trade-off between partner pain and platform debt. If F4's slot has a true first branch, this is where it shows | The JD's spec-writing responsibility and R3 (docs, schemas). CASE, delivered with JD content |
| B5 | "Engineering says a partner feature takes two quarters; sales promised it next month. What do you do?" | CASE | [generic] | Clarify the facts: what exactly was promised, to whom, and what is driving the estimate. Look for options: a partial scope, a workaround, a staged delivery. Get engineering, sales and the partner aligned on one honest date. Fix the process so promises route through you. Don't blame sales | R4 (engineering, sales, customers) as a live problem. It tests stakeholder management without asking about F5's thin side. CASE |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Thirty-plus integrations. How are you counting that?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slots, each in your own words: how the 30+ was counted; what the count is sensitive to; the assumption behind it you'd defend least; and which part of each was yours. If you don't know exactly how it was counted, say so. That's an honest answer | Every headline figure gets a defend-the-number rehearsal. EXP, because it tests the figure on F1/F3 |
| C2 | "Walk me through one of those integrations end to end." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on the quote's beats: scoping, requirements, architecture, UAT, go-live. Pick one integration and tell those five in your own words. Answer slot: R3 makes a probe on docs and schemas likely. If you used or wrote either on this one, say how. If not, say so and stay with the five stages | F3/F4's strongest evidence, walked through at depth. EXP |
| C3 | "Tell me about the playbook. What's in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Keep the scope the quote has: you wrote it, and your team uses it. Don't widen it to the company. Answer slot: what it covers and why you wrote it, in your own words. The dossier marks it as inspectable, so if it's shareable, offering a redacted page is strong. Check confidentiality first | V2 is your most inspectable artifact on F4. EXP |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc using only these three: the integrations, the playbook, the roadmap-input sessions, then why this role. Answer slot: your dates, employers and tenure, in your own words. The pack doesn't hold them. End on the role, not on yourself | The likeliest opener. It sets up A1 if told plainly. EXP, with a casual register |
| D2 | "What do you know about our platform and partners?" | CO | [generic] | Homework-shaped. Before Thursday, read Quartzline's public developer docs or partner pages if they exist, and form one specific observation and one question. The pack has no Quartzline facts to give you, because research was refused. If you found nothing public, say what you looked at | No CO question is grounded in research, so this is the one place homework shows. CO |
| D3 | "How did your team run delivery? Sprints, kanban, something else?" | JD | [grounded] | Dossier strategy: clarify. Answer slot: if your team worked in sprints, kanban or another agile cadence, describe how, in your own words. If it didn't work that way, say so plainly. Then: *what I'd want to confirm is how your squads run it.* There is no quote to draw on, so add nothing | F6 (R5), asked casually but scored. JD |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | A1, compressed. Pause, then: the plain acknowledgment (prohibited_claims: "Having held a product manager title or role"), the quote in one sentence, and one line of ramp plan. Hold it if they push. Don't speed up and don't add anything | The same objection as A1 under a timer. It tests composure. JD |
| E2 | "Those roadmap-input sessions. How much of what product built was actually down to you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold-then-concede. Hold what the quote says: you ran the sessions and fed client evidence to product. Volunteer the limit before it's extracted. The dossier grades this confirmed with limited inspectable proof. Answer slot: if something you fed in visibly shaped what product built, say what, in your own words. If you can't trace it, or don't know, say so plainly. Never imply you decided the roadmap | F5's medium-confidence claim is the seam a prober finds. EXP, with Pressure delivery |

### G — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to a client or to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you didn't soften it, and a working relationship intact afterwards. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | A common stem. Quartzline's published values weren't retrieved, so it isn't mapped to them. VAL |
| G2 | "When did you put a client ahead of an internal deadline or metric?" | VAL | [generic] | Selection scaffold: a client need, the internal pressure it competed with, what you did, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Partner-facing role, so customer judgment is likely probed. VAL |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A squad lead pushes back hard on your spec. How do you handle it?" | CASE | [generic] | Seam principles: separate the *what and why* (yours to argue with evidence) from the *how* (theirs). Find the actual objection. Bring the partner evidence. Decide who decides, and escalate only on a real disagreement about outcomes. No claim about your past | The two-squad responsibility, with the decision-authority question open. CASE |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a cross-team piece of work and name exactly what was yours versus others'. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Credit-sharing tests attribution honesty, which matters most for a candidate with F1's gap. VAL |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A2, A3, E1 |
| R1 sub-claim: roadmap ownership and prioritization | A1, A2, A5, B2 |
| R2: Shipped API or platform products | A4, C2 |
| R3: Technical fluency (API docs, schemas) | B4, C2, C3 |
| R4: Stakeholder management across engineering, sales, customers | A5, B5, E2, H1 |
| R5: Agile delivery experience | D3 |
| Responsibility: run discovery with integration partners | B3 |
| Responsibility: write specs, drive delivery with two squads | B4, H1, A5 |
| Responsibility: define and track adoption metrics | B1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From your dossier. The JD asserts decision authority but doesn't evidence it. You need the answer before accepting, and asking it reads as someone who has thought about the job's mechanics |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | From your dossier. Adoption metrics are a named responsibility with no stated baseline. A missing baseline would mean you're building the measurement, not moving it |
| R3 | "What does a strong first 90 days look like for this role, in your view?" | Turns your ramp plan into their success criteria, so you can tune A1's third beat on the spot |
| R4 | "How do partner requests reach the roadmap today, and where does that break down?" | Shows you're thinking about the discovery loop the JD names, and tells you where the job is hardest |
| R5 | "How do the two squads run delivery, and where does the PM's job stop and the squad lead's start?" | Closes F6's clarify honestly and tests the authority question from a second angle |
| R6 | "Six months in, what would make you say this hire worked?" | Gets the real scorecard, which may differ from the JD |

---

## Prohibited claims

This pack won't coach the claims below. Under pressure, a candidate reaches for exactly these, and an interviewer probes exactly these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | The plain acknowledgment, *I haven't held the product manager title*, then V1 at its own scope |
| Having owned a product roadmap | Dossier prohibited_claims, plus the acknowledge_gap area | The plain acknowledgment, *I haven't owned a product roadmap*, plus a ramp plan. No bridge |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | The plain acknowledgment, *I didn't set prioritization for an engineering squad*. No slot |
| Shipped an API or platform product | Inflated form of F3 (V1) | V1's quote at its own scope. The limit is the pack's observation: integrations of the vendor's APIs, not a product shipped. A4's slot stays with what went live |
| Ran product discovery, or shaped what product built, through the input sessions | Inflated form of F5 (V3) | V3's quote at its own scope: ran the sessions, fed client evidence to product. E2's slot asks only what visibly came of it |
| Managed stakeholders across engineering and sales | Inflated form of F5 (V1, V3) | The quotes at their scope: clients and product. F5's slot covers engineering and sales |
| The playbook is used beyond your team | Inflated form of V2 | V2 at its scope: you wrote it, and your team uses it |

---

## Sources

**Dossier consumed:** `tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14 by job-underwriter. Sections it supplied:
- `role_profile`: requirements R1–R5, responsibilities and unknowns. This stood in for the JD.
- `handoff_to_mock_interview`:
  - verified evidence: V1, V2 and V3 are its three `verified_candidate_evidence` entries, in order.
  - weak areas and strategies: F1, F2 and F6.
  - the A1 objection.
  - risks and employer questions: R1 and R2.
  - `prohibited_claims`.
- `decision`: context only.

Not present: `evidence_map`, `evidence_state`, `risk_register`. The dossier is three months old. If anything has changed since, tell me.

**Searches sent:**
- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline API platform news 2026": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search refused. It would have themed the G bank on Quartzline's published values. No values-style round is named for this session, so there would still be no cheat sheet |
| 2. `Quartzline interview process product manager` | unavailable | Search refused. Your description fixes this session's persona weights. It would have shown whether a values or case round follows later in the loop |
| 3. `Quartzline strategy` / recent news | unavailable | Search refused. It would have grounded D2 and at least one CASE question in Quartzline's current priorities |
| 4. `{interviewer name} Quartzline` | n/a | No name was given. The interviewer read is absent |
| 5. representative PM, Platform APIs JD | skipped | The dossier's `role_profile` supplies the requirements |

---

## Upgrade menu

- **Allow web search** (targets 1–3 above): grounds D2 and the B bank in Quartzline's current strategy, and themes G1–G2 on its published values.
- **A deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes. Adds a strategy brief and recent org context for differentiator cases.
- **The hiring manager's name:** adds an interviewer read, reweights the personas from their public footprint, and adds a reverse question tied to their path.
- **Recruiter guidance or a prep email:** covers stated focus areas and any pre-declared deliverable.
- **How much prep time you have before Thursday:** a prioritized prep schedule.
- **Your raw CV:** dates, tenure and employers quotable in D1, plus more fit-snapshot rows.
- **Your answers to the answer slots, told to me outside a drill:** upgrades F3–F6, A4, A5, C1–C3, D1, D3 and E2 from forks to story-mapped guidance.
