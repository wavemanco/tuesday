L1 research: values, interview process, strategy, representative JD.
I've saved your prep pack as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-3-denied-e053c4b9/Stripe_product-operations-manager_interview_pack.md`.

It's built from your message alone. I had no job description, no CV and no research: the four web searches were refused in this session. So all 20 rehearsal questions are general to product operations, and none of the answer guidance says what you've done. Instead, each one shows how to pick a story from your own experience, with an honest fallback if nothing fits.

Because I couldn't look anything up, the pack doesn't state anything about Stripe's values, interview loop or strategy. Before the interview, build your Stripe knowledge yourself from Stripe's own published material.

I can play the interviewer on B1 ("Which part of this role would you be weakest at on day one?"), the question the pack names as the most valuable to rehearse.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final round (your future manager, peers, a skip-level, someone cross-functional), and did the recruiter mention focus areas, a presentation or take-home, or a schedule? That decides which question sets get the most depth.
2. Can you paste the job description and your CV or a short background note? I'll proceed without them if you'd rather. With them, the general rows become specific to you, and the questions about your experience can be built from your own sentences.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not named. Relationship: not known. Built from your one-line message only. There was no job description, no CV, and no research, because the web searches were refused in this session (see Sources). So this pack is a worksheet plus rehearsal banks. It is honest about what it doesn't know, and the upgrade menu at the end shows how to sharpen it.

---

## 1. How to use this pack

- **Personas** describe *how* a question is asked: who is asking and in what style. **Types** describe *what* is being scored. Rehearse both. The same question sounds different from a friendly peer and from a time-boxing skeptic.
- **Guidance is scaffolding, not a script.** I don't have your CV yet, so no guidance cell tells you what you did. Each one tells you how to *pick* your story and what a strong answer contains. It always ends with an honest fallback for when you have nothing that fits.
- **Provenance labels:** `[grounded]` means traceable to something you gave me or to cited research. `[inferred]` means derived from a representative source. `[generic]` means a role-family pattern that makes no claim about Stripe or about you. Every row in this pack is currently `[generic]`.
- Question IDs go by persona: A, B, C, D, E, G, H. The letter F is reserved for fit-snapshot rows.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's published values, not generic virtue |
| EXP | Whether your claims hold up under scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including where you are weakest |
| CO | Homework depth on the company's strategy, competition and recent moves |
| CASE | Structure and reasoning on a live problem from the role |

---

## 4. Fit snapshot (worksheet version)

You haven't shared a CV or background yet, so every evidence cell reads `none given`. With no JD, the requirements are role-family patterns for product operations, written as plain prose. **Fill in the evidence column yourself before the interview.** Each row tells you what strong evidence looks like and how to pick it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Making product launches operationally ready across functions (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence: a launch where you can name what had to be ready, who depended on it, and what you personally did. Pick one launch or rollout where you can say plainly which part was yours. If no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Running cross-functional programmes with product, engineering, support and go-to-market teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a piece of work that needed several teams to move, with your role named exactly. Pick a time you coordinated across at least two teams that didn't report to you. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Defining, tracking and analysing operational metrics (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a metric you can explain end to end, meaning how it was counted, what moves it, and which assumption behind it is weakest. Pick a number you have reported on and can defend under two follow-ups. If you don't know how a figure was counted, say so plainly. That beats a guessed method |
| F4 | Designing and scaling repeatable processes and tooling (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a process you can describe before and after, with what changed and who used it. Pick one you can describe at the scope it actually had. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Closing the loop between customer-facing teams and product (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a time customer feedback reached a product decision, with your part in carrying it named. Pick a case where you can say what you passed on and what happened next. If you don't know what happened next, say so. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Influencing without authority and communicating with senior stakeholders (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a disagreement with someone senior or outside your line, where you can name the stake and how it ended. Pick a time your view changed, or failed to change, a decision. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Prioritising competing requests under ambiguity (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a real trade-off where you can name what you said no to and why. Pick a time you chose between competing asks. If the choice wasn't yours, say who made it and what you contributed. If none comes to mind, say so plainly, then say how you would decide |
| F8 | Fluency in the company's products, customers and strategy (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: current, specific knowledge of the company that you could defend if asked where you learned it. This pack could not research Stripe, so build this row yourself from Stripe's own published material before the interview. Don't rehearse company facts you can't source |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | A1, E3 |
| F2 Cross-functional programmes | A3, G1, G2 |
| F3 Metrics and analysis | A2, D1, D2, D3 |
| F4 Process design and scaling | A2, D3 |
| F5 Customer-to-product loop | C2, A2 |
| F6 Influence and senior communication | C1, G1 |
| F7 Prioritisation | A3, B1 |
| F8 Company fluency | B3, H3. Generic only, because the research did not run |

---

## 8. Persona table

**How the weights were set:** "final round" doesn't establish how many sessions you'll have or who runs them. The relationship to your interviewer(s) is also unknown, and research into Stripe's loop could not run. So this pack falls back to the **generic archetype with flat weights**. That means three questions per persona (two for Values, which has only two documented stems) rather than a guess. The weights rest on a pattern, not on Stripe's documented process. If you tell me who you're meeting, I'll reweight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problems: plan a launch, diagnose a metric, choose between requests | Flat weight. Live problems are the natural test for an operations role, but no source confirms a case round | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic (B) | Quiet probing of gaps and motivation: why this, why here, why now | Flat weight. Finals usually include someone checking that the story holds together, but this is a pattern, not a confirmed round | Rehearse the most predictable objection until it's boring. Build bridges only from things you actually did, and say the limit plainly where there are none |
| Values / Behavioral (C) | "Tell me about a time" probes, STAR-shaped | Flat weight. Stripe's published values could not be fetched, so these questions use generic themes rather than Stripe's own | "We" for context, "I" for your contribution. Choose stories where a hard truth actually landed. Where you have none, say so rather than inventing an ending |
| Data-Driven Prober (D) | Asks how numbers were counted and what they depend on | Flat weight | Know what you can and can't say about how each number was counted. Name the weakest assumption before they do |
| Pressure (E) | Interrupts, time-boxes, questions how much was actually you | Flat weight | Pause and restate the question. Anchor in what you actually did. Hold through two follow-ups, then concede specifically, without folding |
| Peer Evaluator (G) | Asks about seams between teams, credit-sharing and disagreement with equals | Flat weight. Operations roles sit between teams, so a peer is a plausible interviewer | Lead with what you bring their team, not only what you need. Propose principles for the seam rather than claiming to know it |
| Conversational (H) | Friendly openers and the "any questions?" slot | Flat weight | Prepare a 90-second biography arc. Treat casual questions as scored. Never say "I think you've covered everything" |

---

## 9. Question banks

All rows are `[generic]`: no guidance cell makes a claim about your past. Once you share a CV, these become story-mapped and `[grounded]`.

**Highest-ROI prep in this pack: B1.** Some version of "where are you weakest?" is the single most predictable objection in a final round. A rehearsed, non-defensive answer changes the interview. Because I have no CV, I can't predict *your* specific objection. Sharing your background is what makes this row precise.

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're launching a new feature to existing users in several countries next quarter. Sketch the launch-readiness plan. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, what changes for them, the date and how firm it is, and who owns what. Then work through the functions that must be ready: support, documentation, sales enablement, risk or compliance review, and internal tooling. Add a readiness checklist with owners, the go/no-go criteria, and how you'd watch the first two weeks. Close with the biggest risk and your mitigation. The question needs no claim about your past, so the guidance makes none | Tests F1 as a live problem. CASE because it scores structure, not history |
| A2 | "Support tickets about one product area rose 20% month over month. Diagnose it." | CASE | [generic] | Check the measurement first: did the counting, tagging or channel change? Then segment by user type, region, channel and issue category. Then look at causes: a recent release, a policy change, an outside event or seasonality. Pick the likeliest cause, say what data would confirm it, then give the fix and the process change that stops it recurring | Covers F3, F4 and F5 together. A metric-diagnosis prompt is the Case persona's documented stem |
| A3 | "Product, sales and support each send you a top-priority request this week, and you can do one. How do you decide?" | CASE | [generic] | Name your criteria aloud: customer impact, reversibility, deadline risk and strategic fit. Ask what each team actually needs and by when. Choose one, say plainly what you are *not* doing, and explain how you would tell the other two. The "no" is what gets scored | Tests F7 and F2. Live delivery |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI rehearsal.** Pick a real weakness that matters to the role, not a disguised strength. Say it in one sentence. Then say what you would do in the first 30–60 days to close it, as a plan, never as a past. If you have adjacent experience, name only what you actually did and its limit. If you have none, say so plainly. Hold through two follow-ups by going back to your plan, never by shrinking the weakness | The most predictable objection in a final round. JD because it scores the role's requirements. Generic until your CV shows which requirement is actually your gap |
| B2 | "Why product operations, and why now?" | EXP | [generic] | Pick the moment or pattern in your work that pulled you towards operations work, in your own words. Your "why now" must agree with your CV's timeline. If there was no single moment, say what has been consistent instead. Keep it to about 60 seconds | Motivation consistency is what the Skeptic scores. EXP because the answer is checked against your history |
| B3 | "Why this company and not somewhere else?" | CO | [generic] | Name one or two specific things you have read in Stripe's own published material and why they matter to you. Cite only what you can say where you read it. Then connect them to the work this role does. Don't rehearse facts about Stripe from memory or hearsay | Tests F8. Generic because no Stripe research could run, so the pack can't supply company specifics |

### C — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you didn't soften the message, and a relationship still intact afterwards. Use STAR, with "I" for your part. Include what actually happened next, even if the truth didn't land. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F6. A documented Values-persona stem. Generic because Stripe's published values could not be fetched to theme it |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision where the metric and the customer pointed different ways and you can name your part in choosing. Say what it cost, in your own words, and what came of it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F5. A documented stem |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you've reported on and walk me through how it was counted." | EXP | [generic] | Choose a figure you know well. In your own words, cover how it was counted, what it is sensitive to, and exactly which part of it was yours. If you don't know how part of it was counted, say so plainly. Don't reconstruct a method you can't stand behind | Tests F3. Probers score whether your numbers hold up |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they do. Say why it is weak and what would change if it were wrong. If you don't know the assumptions, say so. That's a credible answer, and an invented one isn't | The weakest-assumption move turns a gotcha into a credibility gain. Usually comes as D1's follow-up |
| D3 | "How would you know whether a process change you shipped actually worked?" | CASE | [generic] | Define success before launch. Choose one main metric and one guardrail metric. Get a baseline, then compare: before and after, a holdout, or a staged rollout. Say how long you would wait and what result would make you roll back | Covers F3 and F4 as a live problem. Presupposes nothing about your past |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give two points: what you bring that an insider may not, and how fast you can ramp. Claim only what your background actually shows. Concede what an insider has, specifically, then hold your two points | Documented Pressure stem. Tests composure under a time limit |
| E2 | "That result you just described — how much of it was actually you?" | EXP | [generic] | Separate "we" from "I" in one sentence each. Name exactly the part that was yours, at its real size. If most of it was the team's, say so. The honest answer is what this probe is designed to reward. Don't grow your share under pressure | Documented stem. Rehearses attribution honesty, which is where answers usually fail |
| E3 | "Your launch plan is two weeks late and the PM says ops is the bottleneck. You have one minute — defend it." | CASE | [generic] | Restate the problem. Ask or state what is actually blocking. Separate what is ops-owned from what isn't. Give one concrete recovery step and one trade-off you'd ask the PM to accept. Concede any real ops miss specifically, without folding on the rest | Covers F1 under time pressure. A live scenario, so it asks about no past |

### G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Propose principles instead: who decides what, how you escalate, and how often you review. For disagreement, describe your habit of making the disagreement explicit early and agreeing on the decision-maker. If you have a real example, give it at its real scope | Covers F2 and F6. Documented Peer stem |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your principle, then give one time you applied it: whose work you named, and to whom. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Documented stem. Peers are pricing whether you'll make their work visible or absorb it |
| G3 | "What would you need from me in your first month, and what would you bring my team?" | CASE | [generic] | Answer both halves, the giving first: one concrete thing you'd do for their team early. Then one or two things you'd need, such as context, access or a regular check-in. Keep it small and specific | Reciprocity is what the Peer persona scores |

### H — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the two or three turns that matter for this role, and why this role is the next step. Every beat must match your CV. Rehearse it out loud with a timer | Documented stem. Casual register, but scored for economy |
| H2 | "What tool or method have you been getting better at lately?" | EXP | [generic] | Pick something you have actually used recently. Say what you used it for and what you learned, in your own words. If you're early with it, say so | Adapted from the plus-skill stem. Casual questions about skills are still scored |
| H3 | "Any questions for me?" | CO | [generic] | Never say "I think you've covered everything." Use two or three from the reverse questions below, chosen to suit who you're talking to | Covers F8. Rapport-style interviewers weight this slot heavily as a preparation signal |

---

## 11. Reverse questions

| Question | Why it lands |
|---|---|
| "What does a great first six months look like in this role, and what would make you say the hire was a mistake?" | It shows you're thinking about being measured. The second half gets an honest answer about the risks they see |
| "Where does product operations sit relative to product, support and go-to-market here, and where is that seam hardest today?" | It shows you understand the role lives between teams, and it gives you the real map |
| "What's an operational problem the team has tried to fix that hasn't stuck yet?" | It invites them to share real work, and it gives you a concrete hook for the rest of the conversation |
| "How does the team decide what to stop doing?" | It shows you take prioritisation seriously and tells you a lot about the culture |
| "How will the decision on this role be made after today, and is there anything from our conversation I can clarify?" | It gives you a last chance to address a concern before it hardens |
| (If a peer) "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which is what peers are scoring |

---

## 13. Prohibited claims

**No entries yet.** That isn't because the pack found nothing to inflate. You haven't shared any material about your background, so there are no sentences of yours to stretch and no negatives you've stated. The list is built from your quotes. Once you share a CV, any claims a strong answer might tempt you to inflate will be listed here, each with its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| none yet | No candidate material provided | Not applicable until a CV or background is shared |

---

## 14. Sources

- **Provided:** your message: "I have a final-round interview at Stripe for a Product Operations Manager role. Help me get ready."
- **Searches sent:**
  - `Stripe operating principles official`: refused
  - `Stripe interview process product operations onsite final round`: refused
  - `Stripe strategy news 2026`: refused
  - `Stripe "Product Operations Manager" job description`: refused
- **Fetches:** none sent.
- **Dossier:** none present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values / operating principles | unavailable | The search was refused. It would have supplied Stripe's published values by name, themed the VAL questions and, if a values-style round were detected, enabled a values cheat sheet |
| 2. Stripe interview process, product operations | unavailable | The search was refused. It would have named the rounds and replaced the flat persona weights |
| 3. Stripe strategy / recent news | unavailable | The search was refused. It would have grounded at least one CO or CASE question in current strategy. B3 and H3 stay generic |
| 4. Interviewer name + Stripe | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | The search was refused. It would have turned the fit-snapshot requirements into quoted `[inferred]` rows |

---

## 15. Upgrade menu

- **Full JD text:** the eight `[generic]` fit rows become quoted `[grounded]` requirements. Mid-list items like named tools or methods get their own JD questions, and the questions about the role's stated duties can carry answer slots.
- **Your CV or a short background note:** the worksheet becomes a real fit snapshot. Guidance becomes story-mapped on your own sentences. B1 gets aimed at your actual likeliest objection, and the prohibited-claims list gets built.
- **Who you're meeting and your relationship to them** (manager, peer, skip-level, cross-functional, recruiter): the persona weights move off flat and depth shifts to the banks that matter.
- **Interviewer names:** an interviewer read from their public professional footprint, persona tuning, and a reverse question tied to their own career path.
- **The recruiter's prep email:** stated focus areas, plus a build section for any pre-declared deliverable such as a presentation, case or take-home. If your final is several sessions, send the schedule and I'll split this into per-session mini-packs.
- **Allowing web search:** targets 1, 2, 3 and 5 above can run. That means Stripe's published values by name, the documented loop, and current-strategy CO questions.
- **Deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes, also needs web search): a strategy brief, role-family loop reports and recent org context, for sharper CO and CASE questions.
- **How much prep time you have:** a prioritised prep schedule sized to it.
- **A tuesday-dossier.md from an earlier evaluation of this role:** verified evidence and an evidence-derived top objection in place of inferred ones. Useful, never required.
