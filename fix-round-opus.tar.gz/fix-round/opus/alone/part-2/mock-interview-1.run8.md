Web search was blocked, so I'm building the pack only from what you gave me. Writing it now.
Fixing the last pronouns for Dan, then I'll hand you the pack.
I've built Priya's prep pack for her single 60-minute peer conversation with Dan. It's saved as `northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`.

All four web searches were blocked by this session's permissions, so the pack uses only what you gave me. That means Northwind's published values, the interview process, whether your Compass details are current, and Dan's public footprint are all unchecked. The pack says this wherever it matters.

**What's in it:**
- **Fit snapshot:** six rows for the JD lines and one for the B2B-versus-consumer-tech context. Each row quotes your notes on Priya word for word and gives the gap and how to bridge it.
- **Question banks:** 21 questions across seven interviewer styles, ordered by how likely each style is with Dan:
  - data-driven prober (5)
  - peer evaluator (4)
  - strategist working live cases, tilted toward pricing (3)
  - skeptic (3)
  - pressure (2)
  - conversational (2)
  - values/behavioural (2)

  Every question has a type tag, answer guidance, a column showing which of Priya's quoted lines the guidance rests on, and a rationale for including and categorizing it.
- **Supporting sections:** a table on reading Dan, a table showing which questions cover each JD requirement, 7 questions for Priya to ask Dan, and a list of claims the pack won't coach.

**Highest-ROI prep is D1:** "Consumer tech, no quota-setting or sales ops — why you for B2B GTM?" It comes up for two reasons: your notes say she has no sales-ops or quota-setting experience, and that work sits right next to Dan's own job. The guidance starts with her saying that limit outright. She then holds to her real work through three follow-ups and finishes with a ramp plan. The pack never lets her present her annual volume targets as quotas.

**Two other points:**
- **The ~$400M figure:** Dan calls themself data-driven, so it will be probed. Her own wording is that she *proposed* a change that was *credited with* the uplift, and the pack keeps her to that. If she doesn't know how the uplift was attributed, saying so is the honest answer, and the guidance treats it as a good one.
- **Answer slots:** where her material doesn't show something, such as whether she has done land/adopt/expand/renew analysis, the guidance gives her two honest options to answer from. It doesn't fill in experience for her.

If you allow web search, I'll fill in the unchecked items above, including any published values for the two behavioural questions to use.

Say the word and I'll play Dan as the skeptic on D1, the pack's highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for use in later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Session:** one 60-minute conversation with Dan Kovac, Director of Sales Strategy. Dan is a **peer**: you'd both report to the same VP.
**Built from:** the coach's notes only: JD highlights, Priya's background, Dan's profile summary, and the coach's research note. Every web search was refused in this session (see Sources).

---

## How to use this pack

Questions are sorted along two axes:

- **Persona** is *how* a question gets asked: who is asking and in what style. Each persona has its own bank below, and the banks are ordered by how likely each style is with Dan.
- **Type** is *what* the question scores:

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's values (generic here, because no published Northwind values were in hand) |
| EXP | Whether Priya's stated experience holds up under scrutiny: what was actually hers |
| JD | Whether she can do the listed job, gaps included |
| CO | Company and strategy fluency: Compass, enterprise expansion, profitability, the bundling threat |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs carry a persona letter: A, B, C, D, E, G, H. There is no bank F, because F1–F7 are the fit-snapshot rows. Rationale cells point to Priya's history only by fit-snapshot row.

The guidance is scaffolding, not a script. Anything marked **answer slot** is something only Priya can fill. Each slot has two honest branches, and taking the second ("that wasn't mine", "there was no such step") is a correct answer, not a failure.

**Highest-ROI prep in this pack: D1**, the B2B-GTM-without-sales-ops objection. Rehearse it until it's boring.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy and ops, not GTM ownership of a product line, and the words stay at that scope: "Nine years in product strategy and ops at a large consumer-tech company, and I proposed a store-surface change that was credited with a roughly $400M ARR uplift." Answer slot: the JD's "own GTM strategy" line makes a probe on go-to-market decisions likely. If any of that product strategy work included deciding who a product was sold to, how, or at what price, say which part and how you decided, in your own words. If none did, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | none | [grounded] | discovery | The material says nothing about customer-lifecycle analysis. Answer slot: the JD's land/adopt/expand/renew line makes a probe likely on whether you've analysed customers by lifecycle stage. If you have, say where and how, in your own words. If not, say so plainly, then walk through how you'd do it (A4, C3) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but it's a self-description with nothing inspected behind it, and the interviewer calls themself data-driven, so expect it tested live (A3). Lead with the quote's own terms: you're skilled in SQL and Tableau. Show it by doing it, not by describing it |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material shows a revenue model used in negotiations, not a partner motion that was designed, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD marks partner-motion design as required, so a probe on it is near-certain. If any term, tier or incentive discussed in those negotiations was yours to shape, say which and how, in your own words. If none was, or you don't know how the model was used, say so plainly and stay with the model you built |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement, just in different words. Say it as it is: "I set annual volume targets, with cross-org consensus." Let "cross-org" carry the cross-functional point. Add no process, meeting or conflict the quote doesn't contain |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Derivation: with a copilot launch (Compass) among the company's priorities, "AI experience" in this JD plausibly means work on or around an AI product, and daily tool use touches that without showing it. Answer slot: if any of your work involved an AI product, its pricing or its go-to-market, say what, in your own words. If none did, say so plainly and stay with how you use AI tools day to day |
| F7 | Role context: "Senior GTM Strategy Lead" at a "B2B data-infrastructure SaaS" company — the coach's role description | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "No classic sales-ops or quota-setting experience." — the coach's notes | medium | [grounded] | transferability | The material shows consumer-tech product strategy and ops, and the candidate's side has stated the sales-ops absence. Words: "I haven't done classic sales-ops or quota-setting work. What I have done is nine years of product strategy and ops at a large consumer-tech company, after two years in strategy consulting." Then a ramp plan, said as a plan and never as a past (D1). Never present the volume targets (F5) as quotas |

---

## Reading the interviewer

Public professional footprint only, as the coach summarised it. Nothing was independently researched, because the search was refused.

| Signal | Source | Provenance | What it means for this conversation |
|---|---|---|---|
| Director of Sales Strategy, and a peer reporting to the same VP | the coach's notes | [grounded] | Dan is working out what your hire adds to or takes from their team's load. Expect seam, reciprocity and credit questions (bank B). Come with what you'd *give* their team, not only what you'd need from it |
| Self-describes as "relentlessly data-driven" | the coach's notes | [grounded] | Every number gets probed down to its assumptions (bank A). A crisp "I don't know how that was counted" beats a fluent guess. Offer to walk through an analysis end to end |
| Career spine in pricing and monetization roles | the coach's notes | [grounded] | Cases will tilt toward packaging, pricing and unit economics (C1, C2). Shared vocabulary is available but not a shared story: F4's quote, "built a partner-level revenue model used in carrier negotiations", is a monetization artefact you can name in their language, at its own scope |
| One early-stage startup chapter | the coach's notes | [grounded] | Expect scrappiness probes and some doubt about how fast a big company moves (E2, D3). A reverse question about what carried over from that chapter (reverse question 2) turns this into a peer conversation |
| Sales Strategy is the function closest to quota and capacity planning | role-family pattern, not a fact about Northwind | [generic] | F7's gap sits right next to Dan's own craft. That's why D1 is the objection most likely to come from Dan in particular |

---

## Persona table

The coach's own words establish this session: one 60-minute conversation with a peer. So the weights rest on the peer-relationship prior plus Dan's signals, not on a guessed loop.

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | "How was that counted?", denominators, a live SQL ask | **High (5 questions).** The peer prior already puts this persona second, and "relentlessly data-driven" pushes it to the top | Know what you can and can't say about how each number was counted, and say plainly when you don't know. Name the weakest assumption before they do |
| B. Peer Evaluator | Seams between Sales Strategy and Emerging Products GTM, "what would you need from me", credit | **High (4).** This is the dominant persona in the peer prior, and you'd share a VP | Frame things as reciprocity. Propose principles for the seam rather than pretending to know where it sits. Ask how it works today |
| C. Case / Strategist | Packaging Compass, responding to the bundling threat, sizing whitespace | **Medium (3).** The pricing and monetization spine tilts live problems toward packaging. Peers often test with one live problem | Clarify, then objective, segmentation, approach, metrics, risks. State a position. Challenge one premise per case |
| D. Skeptic | "Consumer tech, no sales ops: why you?" | **Medium (3), but it holds the highest-ROI item.** F7 is the predictable gap, and it sits next to Dan's own function | Concede the stated limit first. Then bridge only with quoted work, plus a concrete ramp plan |
| E. Pressure | "How much of that was actually you?", time-boxed answers | **Low (2).** A peer rarely runs a stress interview, but a data-driven one will press on attribution | Pause, then hold the quote's own claim through two follow-ups and concede specifics plainly |
| G. Conversational | The opener, and casual AI chat | **Low (2).** Every conversation opens somewhere, and AI is the JD's "plus" | A pre-built 90-second arc. Treat casual questions on AI as scored |
| H. Values / Behavioral | Generic behavioural stems | **Low (2).** No values-style round is documented for this session, and no published values were in hand | Story-map where a quote carries a story. Otherwise pick an honest instance, or say none comes to mind |

---

## Question banks

### A. Data-Driven Prober (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You mentioned a store-surface change credited with roughly $400M in ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the quote's verb and hedge: you **proposed** the change, the uplift was **credited** to it, and the figure is **approximately** $400M. Then the defend-the-number slots, each in your own words: how it was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours. If you don't know who did the crediting or how it was attributed, say so plainly: "I don't know exactly how the attribution was done" is an honest, strong answer to this interviewer. Name your least-defensible assumption before they ask. Never "I drove" or "I delivered" | The headline figure, put in front of someone who calls themself relentlessly data-driven: close to certain to come up. EXP because it tests attribution and how the number was counted, not the strategy |
| A2 | "Tell me about the partner-level revenue model: what went in, what came out, and how it was used in the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built it, it worked at partner level, and it was used in carrier negotiations. Describe its structure in your own words. Any part you don't remember, or that wasn't yours, say so. Answer slot: the JD's partner-motion line makes a probe on how the model's output was used likely. If you saw how it was used in the negotiations, say what you saw, in your own words. If you weren't in the room or don't know, say so plainly and stay with the model you built | F4 is the only evidence for a requirement marked *required*, and a model is exactly what a monetization person will open up. EXP because it checks what the model actually was |
| A3 | "Say we have account-level usage and ARR by product. Talk me through the SQL to find accounts that use product A but not product B, then how you'd show it in Tableau." | CASE | [generic] | Clarify before writing: what's the grain (account, or account-month), what counts as "using" (a usage threshold, or any paid seat), and is the period current or trailing? Then: a LEFT JOIN from A-users to B-users, keeping the rows where B is null (or NOT EXISTS); dedupe to account; join ARR and segment. Tableau: a segment × product-footprint heatmap with whitespace ARR as the measure and a filter for renewal date. Say your schema assumptions out loud. The question asks nothing about your past, so the guidance claims nothing about it | A live test of F3's requirement in the form a data-driven peer would choose, and the form that also touches F2's whitespace. CASE delivery on JD content |
| A4 | "How would you know whether a land/adopt/expand/renew whitespace estimate is any good?" | JD | [generic] | Define each motion as a metric: land is new logos, adopt is activation or usage depth, expand is upsell and cross-sell ARR, renew is gross retention. Size bottom-up from the installed base: accounts × fit propensity × realistic price. Validate three ways: backtest against past expansion, sanity-check a sample with sales leaders, and run sensitivity on propensity. Name the weakest assumption, which is usually propensity, before they do. F2's slot applies if they ask whether you've done this before | F2 has no evidence, and the JD names this work directly, so the probe arrives either as "have you done it" or "how would you". JD-tagged because it scores a stated responsibility |
| A5 | "Walk me through how you set those annual volume targets, and how you'd know they were the right ones." | EXP | [grounded] "set annual volume targets with cross-org consensus" | The quote gives you the facts: annual, volume targets, you set them, and with cross-org consensus. Answer slot: the method is likely to be probed. If you built them from a model or inputs, describe it in your own words. If you saw how actuals landed against them, say so. If you don't know, or that part wasn't yours, say so plainly and stay with setting them and reaching consensus. Don't call them quotas (see Prohibited claims) | Target-setting is the part of F5 closest to sales planning, which as a role-family pattern is where a Sales Strategy peer compares notes with their own craft. EXP because it checks how much of the process was hers |

### B. Peer Evaluator (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams would sit side by side. Where's the seam between Sales Strategy and GTM for emerging products, and what happens when we disagree?" | JD | [generic] | Propose principles rather than pretending to know the seam. For example: the core sales plan and capacity belong to Sales Strategy; motion design for the new lines, and the asks it puts on the core plan, belong to this role; both teams share definitions and one data source; disagreements go data first, then to the VP as a joint recommendation, never as two competing ones. Then ask how it works today. A disagreement story from your own work follows H2's rules | The most predictable peer question there is. JD because it scores "strong cross-functional influence" with the person on the other side of the seam |
| B2 | "What would you need from my team in your first 90 days, and what would you give us back?" | JD | [grounded] "skilled in SQL/Tableau" | Needs: access to pipeline and bookings data, current segment and territory definitions, and how quota and comp touch new products. Ask about these, since F7 says this isn't your background. Gives: because you're skilled in SQL and Tableau, you'd run your own analysis rather than queue requests on their team, and share what you build. End by asking what would actually help them | Reciprocity is what a peer is pricing, and their answer shows the seam. Rests on F3 for the "give" side |
| B3 | "When work spans both teams, say your whitespace analysis ends up in my sales plan, how do you handle credit?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Principle first: the plan and its number belong to whoever owns the decision; the analysis is shared work and is named that way. If you use your own example, keep its verbs: you proposed the change, and the uplift was credited to it. Answer slot: if others built, tested or shipped that change, name their roles and say that part was theirs. If you don't know the full chain, say so plainly | A credit probe on a peer's turf, and a second, gentler attribution check on the A1 figure. JD for cross-functional influence |
| B4 | "Partner motions for new products tend to collide with direct reps. How would you design one for a new line without channel conflict with my team?" | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure: the partner's role by stage (sourcing, influence, delivery, resale); rules of engagement (deal registration, and comp neutrality so reps don't lose by bringing a partner in); which segments go partner-first versus direct; and metrics such as partner-sourced pipeline, attach rate and conflict escalations. If you mention your own work, keep it at its scope: you built a partner-level revenue model used in carrier negotiations, which gives you an economics lens on partners, not a designed motion. Close by asking how partners and reps work together today | Tests F4's required capability as a live problem on Dan's own turf. CASE delivery on JD content |

### C. Case / Strategist (medium weight, pricing tilt)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass, our AI copilot: bundle it into the platform or sell it as a paid add-on? Defend it." | CO | [grounded] | Compass and the three priorities come from the coach's research note. Clarify the objective first: adoption, revenue, or defence against the bundling vendor. Options: included in a tier, paid add-on, usage-based, or a hybrid (an included allowance plus metered overage). Tradeoffs: bundling blunts the larger vendor's bundle but delays revenue and strains profitability through inference cost; an add-on protects margin but risks thin adoption and hands the vendor its story. Take a position, for example a hybrid with an enterprise allowance that makes Compass an expansion lever, and name its weakest assumption: willingness to pay. Ask what pricing data exists | Two of the company's three stated priorities, plus its threat, in Dan's native language. CO first (strategy fluency), CASE delivery |
| C2 | "A much larger platform vendor bundles a competing capability for free. Which of our new product lines gets hurt first, and what's the GTM response?" | CO | [grounded] | Clarify what the two lines are, since the pack doesn't know. Diagnose where the bundle is "good enough" for a buyer and where depth still wins. Responses: differentiate on depth, change packaging or price, land through partners and integrations, focus on segments where the vendor isn't the default, and run renewal-defence plays. Data you'd pull: win/loss notes, discount trends and churn reasons, and say you'd pull them yourself | The named competitive threat, from the coach's note, applied to this role's product lines. CO because it scores whether you can think at the company's altitude |
| C3 | "You have a quarter. Size expansion whitespace for a new line in our installed base and tell me where to point the first reps." | CASE | [grounded] | Enterprise expansion is a stated priority (coach's note). Clarify, then set the objective, then segment by account size, current product footprint and industry. Size bottom-up: accounts × fit × price. Rank by propensity × size × ease. Pilot with a named set of accounts, then measure. Risks: propensity is a guess until the pilot comes back, and you'd say so. F2's slot applies if they ask whether you've done this before | The core JD mandate combined with the expansion priority, as the planning problem a sales-strategy peer would set. CASE |

### D. Skeptic (medium weight, holds the highest-ROI item)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This is a B2B SaaS GTM role. Your background is consumer tech, and you haven't set quotas or run sales ops. Why should I believe you can design GTM motions here?" **Highest-ROI prep** | JD | [grounded] "No classic sales-ops or quota-setting experience." "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" | **Name the limit before they finish:** "That's right, I haven't done classic sales-ops or quota-setting work." **Then what's actually yours, at its own scope:** two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company; you built a partner-level revenue model used in carrier negotiations; you set annual volume targets with cross-org consensus. **Then the ramp, said as a plan:** learn Northwind's quota and capacity mechanics from their team first, sit in on deal reviews, and rebuild the plan's logic in SQL yourself. **Follow-up 1, "volume targets aren't quotas":** agree, "They aren't," and hold only the quote: you set them with cross-org consensus. **Follow-up 2, "consumer isn't enterprise":** answer slot. If any of your consumer-tech work involved negotiating or planning with business counterparties beyond the carrier model, say what, in your own words. If not, say so and stay with the carrier model. **Follow-up 3, "so what's your day-one weakness?":** quota mechanics, and the plan above. Never say the targets were basically quotas, and never imply you ran the negotiations | F7 is the most predictable objection to this candidate, and it sits beside the interviewer's own function, so it comes up in some form. JD because it scores fitness for the stated role, and Skeptic because the test is honest self-assessment under cross-examination |
| D2 | "Partner-motion design is required. A revenue model for carrier negotiations isn't a partner motion. Which partner motion have you actually designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any term, tier or incentive in that partner work was yours to shape, say which and how, in your own words. If none was, say so plainly in your own words, and don't stretch the model into a motion. Then move to how you'd design one, using B4's structure, said as a plan | F4 is a transferability gap on a *required* line, and the interviewer's monetization background makes it easy for them to spot. JD because it scores the stated qualification directly |
| D3 | "Why leave a large consumer-tech company for emerging products at a 3,000-person B2B company, and why now?" | CO | [generic] | Selection scaffold, because no quote states a motivation: give your real reason in one sentence, tie it to something specific here (two new product lines, the Compass launch, the push to profitability), and say what you want to learn. If they ask "why not a startup?", answer honestly. If you have no settled reason yet beyond the role itself, say what drew you to the role rather than inventing a narrative | A standard Skeptic motivation check, sharpened by Dan's startup chapter. CO because a strong answer has to show homework on Northwind's priorities |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause. Hold the quote's claim: you proposed the change, and it was credited with roughly $400M in ARR uplift. Keep it under 60 seconds. Answer slot: if others built, tested or shipped it, say in role terms that those parts were theirs. If you don't know the full chain, say so. Hold through two follow-ups by repeating what you proposed, and concede specifics plainly. Never claim the number itself as yours | The classic attribution stem, landing on the biggest figure, from an interviewer who will ask for the denominator. EXP because attribution honesty is the thing being scored |
| E2 | "Sixty seconds: the new lines have almost no usage history and the data's messy. How do you get to a recommendation in two weeks?" | CASE | [grounded] "skilled in SQL/Tableau" | Name the decision first, then the minimum data it needs. Use proxies: pilot accounts, notes from sales calls, early product telemetry. Go directional over precise and state your confidence level out loud. You're skilled in SQL and Tableau, so you'd pull and shape the data yourself rather than wait for a dashboard. Name what would change your mind | Probes the scrappiness question that Dan's startup chapter makes likely, under a time box. CASE, with F3 as the "do it myself" support |

### G. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So walk me through the journey: consulting, consumer tech, and now here." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc. Two years of strategy consulting; nine years of product strategy and ops at a large consumer-tech company; three proof points, each in its own verb (built the partner-level revenue model used in carrier negotiations, set annual volume targets with cross-org consensus, proposed the store-surface change credited with roughly $400M ARR uplift); then why GTM for emerging products now, which is an answer slot in your own words. Stop at 90 seconds and let them pick a thread | Almost every conversation opens this way, and the arc decides which threads they pull. Mapped to F1, F4, F5 and F7. EXP because each proof point invites a follow-up |
| G2 | "What are you actually doing with AI tools these days?" | JD | [inferred] "uses AI tools daily" | Start with the quote: you use AI tools daily. Answer slot: name which tools and what you use them for, in your own words. If any of it touched an AI product or its go-to-market, say what. If none did, say so plainly and stay with daily use. Then turn it into curiosity: ask how Compass's GTM is being planned | The JD's "plus" asked casually, which is exactly when it's scored. JD-tagged, and `[inferred]` because F6 is low-confidence |

### H. Values / Behavioral (low weight, generic stems)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you brought leadership a conclusion they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you held your position, and a working relationship intact at the end. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | No published Northwind values were in hand, so this is a generic behavioural stem. VAL, unmapped; the upgrade menu says what would map it |
| H2 | "Tell me about a time you got a group that didn't report to you to agree on a number." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5. The beats are the ones the quote states: annual volume targets, set by you, with cross-org consensus. Answer slot: "strong cross-functional influence" in the JD makes a probe on *how* consensus was reached likely. If there was disagreement, say what happened and what part was yours, in your own words. If there wasn't, or that part wasn't yours, say so plainly and stay with setting the targets | F5's story, asked behaviourally. VAL first because the stem scores behaviour, with JD content |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | C2, C3, D1, B4 |
| "identify whitespace across land/adopt/expand/renew" | A3, A4, C3 |
| "run independent analysis in SQL and Tableau" | A3, E2, B2 |
| "partner-motion design experience required" | A2, B4, D2 |
| "strong cross-functional influence" | B1, B3, H2, A5 |
| "AI experience a plus" | G2, C1 |
| Role context: B2B SaaS GTM (F7) | D1, D3 |
| Company priorities: enterprise expansion, Compass, profitability, bundling threat | C1, C2, C3, D3 |

---

## Reverse questions

| # | Question | Basis | Why it lands |
|---|---|---|---|
| R1 | "You came up through pricing and monetization. How are you thinking about packaging Compass, and where does Sales Strategy weigh in?" | Dan's career spine and the Compass priority, both from the coach's notes | It's tied to their own path and gets them talking in their native language. Their answer also prepares you for C1 if it hasn't come up yet |
| R2 | "You spent time at an early-stage startup. What from that chapter do you still use here, and what didn't transfer?" | Dan's startup chapter, from the coach's notes | It's a peer-level question about their path, and their answer tells you how they'll judge your big-company background |
| R3 | "What could someone in this seat do in the first month that would genuinely help your team?" | The peer relationship | The reciprocity question: it shows you're pricing your own effect on their load |
| R4 | "Where do targets for new products live today, in your plan or with the product line, and where has that handoff been messy?" | The seam (bank B) | It shows where the real seam is, and it's the question a future partner asks |
| R5 | "When the larger platform vendor bundles, where does it show up in your data first: win rates, discounting, or renewals?" | The bundling threat, from the coach's research note | A data question for a data-driven interviewer, pointed at the company's named threat |
| R6 | "With profitability as a stated priority, what does a good first year look like for a new product line?" | The profitability priority, from the coach's research note | It ties success metrics to strategy and shows you're thinking at the company's altitude |
| R7 | "What does our shared VP need from this role that they aren't getting today?" | Same reporting line | Only a peer can answer this candidly, and the answer is the role's real brief |

---

## Prohibited claims

Built locally from the fit snapshot, since there was no dossier. These are the claims Priya is likely to reach for under pressure. No guidance in this pack asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove or delivered the ~$400M ARR uplift | Inflated form of F1's second quote | "I proposed a store-surface change that was credited with a roughly $400M ARR uplift." The limit is the pack's observation, not words for Priya: the material says "proposed" and "credited". A1 and E1 keep their slots inside that |
| Set sales quotas, or ran sales ops | A negative stated in F7, and an inflated form of F5 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting work." F5's quote stays at its own scope: annual volume targets, with cross-org consensus |
| Designed or ran a partner motion or partner programme | Inflated form of F4 | F4's quote at its own scope: "I built a partner-level revenue model that was used in carrier negotiations." The material says a model used in negotiations, not a designed motion. D2's slot stays inside that partner work |
| Led or ran the carrier negotiations | Inflated form of F4 (the verb and the relationship drift) | F4's quote: the model was *used in* the negotiations. A2's slot asks only what she saw of that use |
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. F1's slot asks which GTM decisions, if any, were hers |
| Has AI-product or AI-GTM experience | Inflated form of F6 (the kind of work drifts: using tools becomes building products) | F6's quote: "I use AI tools daily." G2's slot covers anything more |

---

## Sources

**Provided documents:** the coach's message, which held the JD highlights, the candidate's background, the interviewer's profile summary (title, relationship, self-description, career pattern) and the research note (three priorities, the bundling threat). No dossier was present.

**Searches sent (all refused by the host's permission settings):**

- `Northwind Data company values`: refused
- `Northwind Data interview process GTM strategy`: refused
- `Northwind Data Compass AI copilot launch`: refused. This was a check of the pasted research note
- `Dan Kovac Northwind Data Director of Sales Strategy`: refused

No fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Refused. It would have given official value names to theme bank H and to map stories to. H1 stays a generic stem |
| 2. `Northwind Data interview process` (GTM strategy) | unavailable | Refused. It wouldn't have changed this session, which the coach's words establish, but it could have shown whether a values or case round exists elsewhere in the loop |
| 3. `Northwind Data strategy` / recent news | unavailable | Refused. The call was a check of the pasted research note, to confirm Compass and the priorities are current. C1–C3 rest on the note as given |
| 4. `Dan Kovac Northwind Data` | unavailable | Refused. It would have extended the interviewer read beyond the coach's summary with their talks or posts and their recurring themes, possibly adding a reverse question |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights the coach supplied set the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search in this session**: runs targets 1–4. That brings in Northwind's published values (bank H mapped to official names), confirmation that the Compass and priority details are current (C1–C3), and Dan's public talks or writing (a sharper interviewer read and a tailored reverse question)
- **Deep research pass**: up to 6 more searches and 2 more fetches, several more minutes. It adds a grounding brief (Northwind's vocabulary, headline numbers, recent moves) and strategy cases sharper than C1–C3
- **The full JD text**: F1–F6 can quote whole lines, mid-list requirements get coverage, and any eligibility terms surface
- **Priya's CV**: her own lines replace the coach's summary in the evidence column, and more stories become available for D3, H1 and G1
- **An inspectable artefact from her field**: a sanitised version of the partner-level revenue model, a Tableau workbook she built, or the store-surface proposal. Any one of these raises F3, F4 or F1 from `medium` towards `high`
- **Priya's answers to the answer slots** in A1, A2, A5, D1, D2, E1, G2 and H2: each answer becomes quoted evidence, and those rows become story-mapped rather than slotted
- **The names of the two new product lines**: C2 and C3 become specific rather than generic
- **Prep time available**: adds a prioritised triage schedule
- **The rest of the loop, if there are more rounds**: per-round mini-packs with their own persona weights
- **A `tuesday-dossier.md` from an underwriting pass**: the highest-ROI objection would come from verified evidence rather than inference, and the prohibited claims would arrive verified rather than built locally
