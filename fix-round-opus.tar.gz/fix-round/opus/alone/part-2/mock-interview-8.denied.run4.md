I've built your prep pack for Ashgrove. It has three mini-packs, one for each round on 21 November, laid out the way the recruiter described. It's saved as:

/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-8-denied-920fc030/ashgrove_member-experience-lead_interview_pack.md

You'd already given me everything I needed, so I didn't run any web searches and I have no questions for you.

**What's in it:**
- **Fit check:** a table matching each requirement in the job description to what you actually told me, word for word.
- **Your two real gaps:** you haven't worked in a contact centre and you haven't presented above regional level. The pack gives you a plain way to say each one, then a plan.
- **Questions:** 29 likely questions, with notes on how to answer each.
- **Round 3:** a step-by-step plan for the 20-minute escalation case, and a cheat sheet for the four values.
- **Questions for them:** five for you to ask in each round.
- **Claims to avoid:** things the pack won't help you claim, like having coached supervisors or written the escalation script.

The most valuable thing to practise is question D1 in the round with the Head of Member Services: "You'd own complaints across branches and the contact centre, and you've never worked in a contact centre." Open by naming the gap, stand on only what you've actually done, then give your plan.

Where a strong answer needs something your background doesn't show, the pack gives you two honest options: one if you did it, one if you didn't. For example, it doesn't say whether your complaints spreadsheet was in Excel or tracks resolution times. Tell me the answers outside of practice and I'll rebuild the affected sections.

If you'd like to practise, I'll play the Head of Member Services on D1.
I can also save a tuesday-dossier.md file that records the gaps this prep turned up, for you to bring into later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of interviews:** 21 November 2026, three rounds back to back
**Who you meet:** the recruiter (30 min); the Head of Member Services, your would-be manager (45 min, "mostly behavioural"); a panel of two branch managers (60 min, including a 20-minute complaint-escalation case, scored against the four values). Names not yet assigned.
**Mode:** loop — one shared fit snapshot, then one mini-pack per round.

---

## How to use this pack

- **Personas** are how a question is asked (friendly, sceptical, time-boxed). **Types** are what is being scored. Each question carries one type:
  - **VAL** — does your past behaviour show Ashgrove's published values
  - **EXP** — does what you say about your experience survive close questioning
  - **JD** — can you do the listed job, gaps included
  - **CO** — do you know Ashgrove's strategy and can you think at its level
  - **CASE** — a live problem, reasoned out loud
- **Guidance is scaffolding, not a script.** Say it in your own words.
- **Your quotes are the floor and the ceiling.** Everything this pack says about your past comes from four sentences in your message, quoted in the fit snapshot. Where a strong answer needs more than those sentences carry, the pack gives an **answer slot**: two honest branches, one if you did the thing and one if you didn't. Both branches are good answers. Neither is for writing back to me unless you want the pack to improve.
- **Highest-ROI prep in this pack: D1** (round 2), the contact-centre objection. Rehearse it until it bores you.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. It's your own statement with nothing to inspect, so expect light probing on dates and titles. Say it in your own terms: six years in retail banking, the last three as a branch supervisor. Let the interviewer map that onto "customer operations". Don't relabel your history in the JD's words |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Pack's observation: your material says the log was formal. It doesn't say what rules it was kept under. Words: "I handled the branch's formal complaints log." Answer slot: the JD's word "regulated" makes a probe on the rules behind that log likely. If its complaints were handled to rules or deadlines set outside the branch, name them in your own words. If they weren't, or you don't know which rules applied, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Pack's observation: one branch's log is next to an end-to-end process across branches, not the same thing. Words: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint after it was logged likely. If any later steps were yours, say which and how, in your own words. If none were, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you have stated. Wording can't close it, and nothing should be added to make it feel smaller. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past: for example, sitting in on calls, reading the contact centre's complaint records next to the branches', asking its team leaders where escalations stall |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Pack's observation: the spreadsheet is monthly and about complaints. The quote doesn't say what it counts. Words: "I built the monthly complaints spreadsheet our regional manager uses." Keep its scope: one regional manager uses it. Answer slot: if it tracks volumes or resolution times, say what it counts and how, in your own words. If it doesn't, say plainly what it does track |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Pack's observation: "spreadsheet" doesn't name the tool. Answer slot: if you built it in Excel, say so and name the features you actually used, in your own words. If it was another tool, name it and say plainly that it wasn't Excel |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message, and "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Pack's observation: your material shows training new tellers on an escalation script, plus three years as a supervisor yourself. It doesn't show coaching supervisors. Words: "I trained new tellers on our escalation script," and "the last three of my six years were as a branch supervisor." Answer slot: the JD's coaching line makes a probe on how you trained likely. Say how you went about training tellers on the script, in your own words. If it was simply walking them through the script, say that plainly |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a time you took member problems into a digital or self-service change. Answer slot: if you have worked with a digital team, or on an online or app journey, say what it was and which part was yours, in your own words. If you haven't, say so plainly, then say how you would bring complaint data to a digital team |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you have stated. Words: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words. If not, say so plainly. Then a plan, never a past: how you would prepare your first senior readout |

---

## Grounding brief

Built from your summary of Ashgrove's July 2026 strategy brief. The recruiter sent it to you, so assume your interviewers know it well. Use one point to show you've read it, then add your own angle. Don't recite it back.

| Brief says | Provenance | What to be ready for (pack's reading) | Reading provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] | Complaints will start arriving through digital journeys, and digital journeys will create complaints of their own. This is where the JD's "self-service journeys" line comes from (E1, F8) | [inferred] |
| Consolidate eight branches into five hubs over 2027 | [grounded] | Change during consolidation is a likely source of complaints. It also tests "Neighbours, Not Numbers", and the branch managers on your panel are inside it (H3, G3) | [inferred] |
| Launch a small-business lending product in Q1 2027 | [grounded] | A new product means new complaint types the process has to be ready for (E3) | [inferred] |
| Main competitive pressure is app-only banks | [grounded] | Member experience, in branch and in app, is the obvious ground on which a credit union competes. Expect a "why would a member stay" angle (E1, reverse questions) | [inferred] |

---

## Graded deliverable — the 20-minute complaint-escalation case (round 3)

The recruiter announced "a 20-minute case on a complaint escalation", scored by two branch managers against the four values. The format isn't known yet (given in advance or in the room, discussed or presented). The upgrade menu says how to find out.

**What you can stand on about yourself** (quote at its own scope):
- F2 and F3: "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- F7: "6 years in retail banking, the last 3 as a branch supervisor."

**A 20-minute shape:**
1. **Clarify (2–3 min).** What the member wants. Which channel it came through. Whether it's a regulated complaint and which deadlines apply at Ashgrove. Any earlier contacts. Whether the member is in a vulnerable situation. Who already holds it.
2. **Member outcome (5 min).** What you'd do for this member today, and what you'd say to them.
3. **Escalation and ownership (5 min).** Who holds it, how it's handed over, what the branch supervisor does, and when it goes higher.
4. **Root cause (4 min).** Is this one member or a pattern? What you'd check in the monthly data.
5. **Close (2–3 min).** The member's benefit, what goes in the log and the monthly report, and the one thing you'd change.

**Three theses, each with its concession:**

| Thesis | Value it shows | Concession you say out loud | Provenance |
|---|---|---|---|
| Fix it for the member first, then fix the cause | Members First, Always; Own the Fix | A fast fix for one member can hide a pattern. Say how you'd catch that in the data | [grounded] |
| An escalation is a handover to a named person, not a pass-off | Own the Fix | Naming owners puts more load on supervisors who are already stretched, especially through the hub moves | [grounded] |
| The member's reply is written so they don't need it explained twice | Plain Words | Whatever a regulated response must contain still has to be in it. Plain words go around that content, they don't replace it. Ask what Ashgrove's response must include rather than assuming | [grounded] |

Provenance here marks the value text as Ashgrove's own. The theses are rehearsal positions, not claims about your past.

**Differentiation.** "Apologise, investigate, resolve" is the generic answer. Go past it in two ways: say the values' names at the moment you act on them, and treat the branch as part of its town (ask whether this branch is affected by the hub move). **The anti-pick:** don't promise the member an outcome or compensation before you've established the facts, and say that you wouldn't.

**What to avoid:** don't describe this as something you've done many times. Use the case to show how you reason. Your past enters only through the quotes above.

---

# Round 1 — Recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Conversational | Friendly walk-through, motivation, logistics | high — a recruiter screen leans on rapport, and a 30-minute slot leaves room for little else | A rehearsed 90-second arc built only from your quotes. Treat casual questions as scored | [generic] |
| Skeptic, light | Quick checks against the JD's requirements | medium — the JD lists requirements a recruiter can check off, and two of them are gaps you've stated (F4, F9) | Clean, short answers to the gap checks, then move on | [generic] |

### Bank A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, these beats only: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log. You trained new tellers on the escalation script. You built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words. Don't lead with the gaps. They come up if asked | Always asked, and it sets the frame the next two rounds inherit. EXP because each beat may be picked up later |
| A2 | "What draws you to a credit union, and to Ashgrove?" | CO | [grounded] | Name one value by its official name and one point from the strategy brief. Then give your actual reason, in your own words. If the member-owned model is part of it, say what about it matters to you. Claim no attachment you don't feel | A motivation check, and a chance to show you've read the brief. CO because it scores homework |
| A3 | "Why this move, and why now?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what you want to do more of: complaints, escalations, reporting. These are the threads in your quotes, said as direction rather than as a record of more than you did. Give your real reason in your own words. Keep it forward-facing and true | Recruiters check that the motivation story holds together. JD because the answer lands on the role's duties |
| A4 | "How comfortable are you in Excel?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the spreadsheet in the quote's own terms. Answer slot: if you built it in Excel, say so and name the features you actually used. If it was another tool, name it and say plainly that it wasn't Excel. Don't list features you haven't used | F6. A listed requirement asked casually is still scored. JD because it is the requirement |
| A5 | "Which of our values stands out to you?" | VAL | [grounded] | Pick one, give its exact name, and say in plain words what it means to you. Keep full stories for the panel. If you use one, take it from the values cheat sheet in round 3 | Recruiters often preview the values round. VAL because the value is scored by name |

### Bank B — Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre — have you worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "No, I haven't worked in a contact centre." Then one sentence of plan: how you'd learn it in your first weeks. Stop there. A clean no beats a padded one | F4. A screen checks the headline duty. JD because it is the duty |
| B2 | "You'd be presenting to senior leaders. What's your experience there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words. If not, say so plainly. Then one sentence on how you'd prepare your first senior readout, as a plan | F9. A listed requirement with a stated gap. JD because it is the requirement |
| B3 | "This role spans every branch and the contact centre. What in your background prepares you for that scope?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Give the two quotes at their own scope: the branch's log, and the spreadsheet your regional manager uses. Then say plainly that the wider scope is what you're stepping into, and how you'd approach it. Never "I've owned" | F3 and F5. A short version of D1, so a rehearsed answer here carries into round 2. JD because it scores the end-to-end mandate |

### Reverse questions — recruiter

| Question | Why it lands |
|---|---|
| "Is the 20-minute case given in advance or in the room, and is it a discussion or a presentation?" | Process clarity a recruiter can actually give, and it sharpens your case prep |
| "What made this role open now?" | Shows you're reading the context, and the recruiter can answer it |
| "How does the panel's values scoring sit alongside the other two rounds?" | Shows you're taking the values round seriously |
| "Is anything about the role likely to change with the hub consolidation in 2027?" | Ties to the brief without lecturing on it |
| "What do people who do well at Ashgrove have in common?" | Invites a description of the culture in their own words, which you can echo later |

---

# Round 2 — Head of Member Services, your would-be manager (45 minutes)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Values or Behavioral | "Tell me about a time…" | high — the recruiter called this round "mostly behavioural" | Story where a quote carries one, a selection scaffold where none does. "We" for context, "I" for what you did | [grounded] |
| Skeptic and Pressure | Probes the stated gaps, time-boxed challenges | high — a hiring manager's job is to de-risk the hire, and F4 and F9 are the gaps | Concede the gap first and plainly, hold on what your quotes carry, then a concrete plan | [generic] |
| Case or Strategist | A problem from their actual roadmap | medium — a hiring-manager round leans this way, but the recruiter's "mostly behavioural" pulls it down | Clarify, objective, segments, approach, metrics, risks, out loud | [generic] |

### Bank C — Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you dealt with a complaint that needed escalating." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick one complaint you were directly part of. It needs what the member raised, what you did, and what happened next. The log and the script are context, in the quote's own terms. If no single instance comes to mind, say so plainly and describe how the log and the escalation script worked | F2 and F3. The JD's escalation lines make this near-certain. JD content, behavioural delivery |
| C2 | "Tell me about a time you trained someone and it didn't land the first time." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The nearest material: training new tellers on the escalation script. Answer slot: if a teller's training ever didn't land, say what you changed, in your own words. If no such time comes to mind, say so plainly and describe how you trained them | F7. The JD's coaching line makes a training story likely. JD because it scores coaching |
| C3 | "Tell me about a time data changed how something was done." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The nearest material: the spreadsheet. Answer slot: if anything changed because of what it showed, say what, and which part was yours. If you don't know of a change, say so plainly. "Our regional manager uses it" is what you can stand behind | F5. The JD's monthly reporting duty raises the question of what reporting is for. EXP because it tests what the spreadsheet did |
| C4 | "Tell me about a time you put a member ahead of a process or a target." | VAL | [grounded] | Selection scaffold. It needs a named member situation, the process or target that pulled the other way, what you decided, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | "Members First, Always" is the first value, and the manager may test it before the panel does. VAL because it scores a published value |

### Bank D — Skeptic and Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You'd own complaints across branches and the contact centre, and you've never worked in a contact centre. Why should I trust you with a channel you haven't seen?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | **Highest-ROI rehearsal in this pack.** Name the limit first: "I haven't worked in a contact centre." Then hold only what your quotes carry: you handled the branch's formal complaints log, trained new tellers on the escalation script, and built the monthly complaints spreadsheet your regional manager uses. Then the plan, said as a plan: sit in on calls, read the contact centre's complaint records next to the branches', ask its team leaders where escalations stall. **Follow-up 1:** "So how would you know what good looks like there?" Answer with the plan and how you'd measure it, not with experience. **Follow-up 2:** "Their team leaders will know more than you." Concede it specifically ("on how the contact centre runs, yes"), and hold that your job would be the process across both. Never add a contact-centre-like story your material doesn't carry | F4 is a stated gap in the headline duty, so the objection will come in some form. Pressure delivery, JD content |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of your two stated gaps. Presenting is a strong pick, since this person may be your first senior audience. "I haven't presented to anyone above regional level." Then a concrete first step, as a plan: a one-page first readout, rehearsed with them. Don't offer a disguised strength | F9. A classic sceptic stem. A real gap, answered calmly, scores |
| D3 | "Sixty seconds: why you over someone who has run a contact-centre complaints team?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause, then 60 seconds: six years in retail banking, the last three as a branch supervisor, and the branch's complaints log and escalation training, in the quotes' terms. Concede that such a candidate knows the contact centre better than you. Don't criticise the hypothetical rival | F1 and F4. Time-boxed composure test. JD because it weighs your fit against the duty |
| D4 | "That spreadsheet — how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold your own verb: you built it. Answer slot: if others supplied data or shaped its design, say who did what, in your own words. If it was all yours, say so plainly. Keep "our regional manager uses" at its scope: one manager uses it | F5. Your one artifact, so expect a check on who did what. EXP because it tests attribution |

### Bank E — Case or Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're moving 40% of member service to digital by 2028. What does that do to complaints, and what would you want the digital team to know?" | CASE | [grounded] | Clarify what counts as "member service" in the 40%. Then work through it out loud: which complaints move channel, which new ones digital journeys create, how complaints feed back into journey design, what you'd report monthly, and the risk to members who won't go digital. Offer these as hypotheses to check in the data, not predictions | Grounded in the brief and the JD's self-service line (F8). CASE delivery on CO content |
| E2 | "Your first monthly complaints report lands on my desk. What's on page one?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Ask first what they read it for. Then: volumes and resolution times, the JD's own words, by channel and branch, the trend, top themes, and the actions with named owners. One page, Plain Words. You can mention that you built the monthly complaints spreadsheet your regional manager uses, at that scope, as your starting point | F5 and F9. This is the JD's monthly reporting duty, and it rehearses your first senior readout. CASE because it is a live design |
| E3 | "We launch a small-business lending product in Q1 2027. What would you want in place in the complaints process before launch day?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Clarify: who handles business members' complaints, and whether the same regulated rules apply. Ask rather than assume. Then: complaint categories in the log, a line in the monthly report, escalation guidance for frontline staff, and an early-weeks review. You can say you've trained new tellers on an escalation script, at that scope | From the brief. Tests whether you plan ahead of a launch. CASE because it is forward design |

### Reverse questions — Head of Member Services

| Question | Why it lands |
|---|---|
| "What would a strong first monthly report from this role tell you that you don't see today?" | Puts their real need on the table, and they are the report's reader |
| "Where do escalations stall today: between branches, the contact centre, or somewhere else?" | Shows you think in seams, and they know the answer |
| "How do you want to hear bad news from this role?" | Signals Own the Fix and a working relationship |
| "How will the 40% digital shift change what you need from member experience by 2028?" | Ties to the brief at their level |
| "What would make the first ninety days a success in your eyes?" | Gives you their scorecard |

---

# Round 3 — Panel of two branch managers, values round, including the case (60 minutes)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Values or Behavioral | One or more questions per value, scored | high — the recruiter said the panel "score against the four values" | A mapped story or a scaffold per value, with the value's exact name said once | [grounded] |
| Case or Strategist | The 20-minute escalation case | high — the recruiter announced it | See the graded deliverable section | [grounded] |
| Peer Evaluator | "You'd be coaching my supervisors…" | medium — this role coaches branch supervisors and works across branches, so branch managers judge what you'd add to or take from their load | Reciprocity: what you bring their branch. Propose principles for the seam, don't pretend to know it | [inferred] |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story | Question | Provenance |
|---|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote carries a story. Selection scaffold: a decision where the member's view outweighed the convenient one, with what you decided. If none comes to mind, say so plainly and say how you'd decide in the case | G1 | [grounded] |
| Plain Words | If it has to be explained twice, rewrite it | The nearest material is F2 and F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Use it only if a plain-words moment actually happened in that training (G2's slot) | G2 | [grounded] |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries a story. Selection scaffold: a time local knowledge of a member or the town changed what you did. If none comes to mind, say so plainly and say how you'd keep that through the hub moves | G3 | [grounded] |
| Own the Fix | Whoever finds the problem keeps it until solved | The nearest material is F5: "I built the monthly complaints spreadsheet our regional manager uses." Use it only if it answered a problem you found (G4's slot) | G4 | [grounded] |

### Bank G — Values

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold. It needs the member situation, the easier option, what you chose, and how it ended. Say "Members First" once, at the moment of the decision. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide | Uses the value's own words, so it is likely close to verbatim. VAL by definition |
| G2 | "Tell me about a time something had to be explained twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The nearest material: training new tellers on the escalation script. Answer slot: if explaining the script ever took a second go, say what you changed, in your own words. If it didn't, say so plainly and pick another moment, or say how you'd write a member letter so it doesn't need a second explanation | F7. Plain Words, from its own definition. VAL |
| G3 | "Tell me about a time you treated a member as a neighbour rather than a number." | VAL | [grounded] | Selection scaffold. A specific member, what you knew about them or the town, and what that changed. If no such time comes to mind, say so plainly and say how you'd protect this through the hub moves | Two branch managers going through a consolidation will care about this one. VAL |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The nearest material: the spreadsheet. Answer slot: if you built it because you found something missing, say what and how you kept hold of it. If it was asked of you, say so plainly and choose another problem you found, or use the scaffold: the problem, who else could have dropped it, and how it ended | F5. Own the Fix, from its own definition. VAL |

### Bank H — Case

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | The 20-minute complaint-escalation case | CASE | [grounded] | Use the shape, theses and anti-pick in the graded deliverable section. Name a value when you act on it, not as a list at the end | Announced by the recruiter, and graded. CASE |
| H2 | "A member's complaint involves both the contact centre and a branch. Who owns it?" | CASE | [grounded] | Answer from Own the Fix: whoever finds it holds it until it's solved or handed to a named person. Then the handover, what the member hears, and what goes in the log. Concede that you'd want to learn how the contact centre works today before fixing the rule (F4) | Tests the cross-channel seam this role owns. CASE |
| H3 | "Suppose my branch merges into a hub next year and complaints go up. What do you do with my supervisors?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Clarify which complaints are rising and why. Then: shared escalation guidance, regular reviews of escalated cases with the supervisors, what you'd report to the manager, and keeping local knowledge (Neighbours, Not Numbers). You can say the last three of your six years were as a branch supervisor, at that scope, as why you'd start by listening to them | From the brief and the JD's coaching line (F7). The panel live this. CO content, CASE delivery |

### Bank J — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You'd be coaching my supervisors. What happens when you and I disagree on how one of them handled an escalation?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Propose principles rather than claims: talk to the manager first, start from the member's outcome, settle it privately before it reaches the supervisor. You can say the last three of your six years were as a branch supervisor, so you know that seat. Never claim you've coached supervisors | F7. The JD's coaching duty, seen from the branch manager's side. JD |
| J2 | "What would you need from branch managers, and what would we get from you?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Reciprocity: what you'd give them first, such as a clear monthly view of their branch's complaints and a named owner on cross-channel cases. What you'd ask for: time with supervisors, and honest feedback on the report. You can say you built the monthly complaints spreadsheet your regional manager uses, at that scope | F5. Peers price what the hire adds. JD |
| J3 | "How do you handle credit when a fix spans branches?" | VAL | [grounded] | Selection scaffold. A fix that crossed teams, who did what, and how credit landed. If no such time comes to mind, say so plainly and say how you would share credit: the branch that found it is named in the report | Own the Fix, in peer form. VAL |

### Reverse questions — panel

| Question | Why it lands |
|---|---|
| "What does a complaint cost your branch today that the member never sees?" | Opens up the managers' own experience, and it's practical |
| "How are your supervisors handling escalations through the hub changes?" | Neighbours, Not Numbers, at their level |
| "What would you want from the monthly complaints report that you don't get now?" | Reciprocity, and real input for the job |
| "Where does a complaint go wrong between a branch and the contact centre?" | Shows you're thinking about the seam before you own it |
| "What would make you glad this role exists, a year from now?" | Lets them say what success looks like to them |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1, D3 |
| Experience handling regulated complaints | C1, H1, E3 |
| Own the complaints process end to end across branches and the contact centre | B1, B3, D1, H2 |
| Report monthly on complaint volumes and resolution times | C3, E2, J2 |
| Coach branch supervisors on escalations | C2, H3, J1 |
| Work with digital teams on self-service journeys | E1 |
| Confident presenting to senior leaders | B2, D2, E2 |
| Comfortable with Excel reporting | A4 |

No headline metric appears in your material, so the pack has no defend-the-number question. D4 checks attribution on your one artifact instead.

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process end to end | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." Pack's observation: the material says the branch's log, not a process. F3's slot stays inside the log |
| Worked in, or alongside, a contact centre | Negative you stated, F4 | "I haven't worked in a contact centre." No slot |
| Presented to senior leaders or executives | Negative you stated, F9 | "I haven't presented to anyone above regional level." F9's slot asks only about regional level |
| Coached supervisors | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script." F7's slot asks only how you trained tellers |
| Wrote or designed the escalation script | Inflated form of F7, a verb drift from "trained … on" | The same quote. The material says you trained on the script, not that you wrote it |
| Built the region's complaints reporting | Inflated form of F5, a scope drift from one manager using it | F5's quote: "I built the monthly complaints spreadsheet our regional manager uses." |

---

## Sources

**Provided documents**
- The JD, pasted in your message
- The Ashgrove values, pasted in your message (copied 12 November 2026 from ashgrovecu.org/about/values, which you named as the source, not a link to read)
- The recruiter's email about the three rounds, pasted in your message
- Your summary of the July 2026 strategy brief the recruiter sent you, pasted in your message
- Your background, from your message

**Searches and fetches sent:** none.
**Dossier:** none consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted this morning gives the four official names and definitions for the cheat sheet and bank G |
| 2. Ashgrove interview process | skipped | The recruiter's email sets out all three rounds, their length, interviewers and case, so it fixes the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief, under six months old, supplies the grounding brief and E1, E3 and H3 |
| 4. Interviewer names | n/a | No names have been assigned, so there was no query to form. The interviewer read is left out |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → a "reading the interviewer" section, persona weights from each person's public professional footprint, and at least one reverse question tied to each person's career path
- **Your CV** → more of your own sentences to quote. F2, F5, F6 and F8 could move off `discovery`
- **Your answers to the answer slots, told to me directly (not in a drill)** → F2, F3, F5, F6, F7, F8 and F9 regenerate, along with A4, B2, C1–C3, D4, G2 and G4
- **A copy of the monthly complaints spreadsheet's layout with every member detail removed, only if your employer's policy allows** → F5 and F6 can move from `medium` to `high`, since an inspectable report is the proof this field keeps
- **How much prep time you have before 21 November** → a prep triage schedule in priority order
- **One email to the recruiter** asking whether the case is given in advance or in the room, and whether it's discussed or presented → the case section tightened to its real format
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → recent news on the hub consolidation and the lending launch, plus candidate reports on this kind of loop, so the grounding brief is current beyond July
- **A tuesday-dossier.md from job-underwriter** → the highest-ROI objection derived from verified evidence rather than inferred here, and an underwriter-built prohibited list. Helpful, never required
