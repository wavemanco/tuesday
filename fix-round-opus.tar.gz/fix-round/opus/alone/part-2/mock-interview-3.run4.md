Web search was blocked by permissions, so I'm building the pack from what you gave me and labelling everything else generic. Writing it now.
I've built your prep pack, but it's general product-ops prep, not Stripe-specific yet. My web searches were blocked by this session's permissions, and I don't have a job description, your CV or the interviewers' names. So it assumes a final round of unknown structure and gives every interviewer style equal weight. It makes no claims about Stripe itself.

The pack has 21 practice questions across the seven interviewer styles you might meet. Each comes with answer guidance and a note on why it's in there. The one to rehearse hardest is **B1: "Which part of this role would you be weakest at on day one?"**

Since I haven't seen your background, most of the guidance tells you which of your own stories to pick for each question rather than telling you what to say. The fit snapshot near the top doubles as a worksheet: write in your own experience for each typical requirement. The pack ends with a list of what each missing input would add.

It's saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-3-denied-a9ec3236/stripe_product-operations-manager_interview_pack.md`.

Say the word and I'll play the Skeptic interviewer on B1 for a live practice run.
I can also save a tuesday-dossier.md recording the gaps this prep turned up, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final round (future manager, peers, a skip-level, a panel), and did the recruiter mention any focus areas or a presentation to prepare? The answer changes which interviewer styles get the most questions.
2. Can you paste the job description and your CV, or a few sentences about your relevant work? If you'd rather not, the pack stays a general worksheet, but with them every answer gets built on your real stories.
3. Would you allow web search? I'd use it to pull Stripe's published values, how Stripe describes its interview process, and current strategy into the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final-round prep pack

Role: Product Operations Manager. Company: Stripe. Round: final round. Interviewers: not known. Relationships: not known.

Built from the company name, the role title and "final round", and nothing else: no job description, no CV, no names. Web research was attempted and refused by this session's permissions, so nothing here comes from Stripe's own pages. Every row is labelled `[generic]`, which means it rehearses the role-family pattern and makes no claim about Stripe. The upgrade menu at the end lists what each missing input would change.

## How to use this pack

- **Personas** are how a question is asked: who is asking and in what register.
- **Types** are what the question scores:
  - **VAL**: whether your past behaviour shows the company's values
  - **EXP**: whether your stated experience holds up under scrutiny, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: how much homework you've done on the company's strategy and current moves
  - **CASE**: how you structure and reason through a live problem from the role
- Question IDs go letter by persona (A1, A2, B1…) so you can ask to drill a specific one.
- The guidance is scaffolding, not a script. Each cell shows the shape of a strong answer. The content has to come from things you actually did. I haven't seen your background yet, so most cells tell you which story to pick, not what to say.

## Fit snapshot

This is the worksheet version, because I have no CV. The requirements are typical product-operations duties written from the role family, not quoted from a Stripe posting. Fill in the Evidence column with your own sentences, either for yourself or by sending them to me, and the pack can be rebuilt around them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating product launches and launch readiness across support, sales, engineering and other teams. Role-family pattern | none given | none | [generic] | discovery | Strong evidence: a launch you helped get ready, with your own part named: the checklist, the go/no-go call, the comms, or the follow-up. Pick a launch where your role is easy to state in one sentence. It needs a named product, what "ready" meant, and what you did. If no launch comes to mind, say so plainly, then give the nearest cross-team rollout you worked on, or how you would run one |
| F2 | Designing and improving operational processes as a product and its user base grow. Role-family pattern | none given | none | [generic] | discovery | Strong evidence: a process you changed, with what it looked like before, what you changed, and how you knew it worked. Pick one where you can say which part of the change was yours. If none comes to mind, say so plainly, then give the nearest process you ran or improved, or how you would approach one |
| F3 | Turning customer and frontline feedback into input the product team can act on. Role-family pattern | none given | none | [generic] | discovery | Strong evidence: a time feedback from users or frontline teams reached a product decision through something you did. Pick one where you can name the feedback source and what happened to it. If none comes to mind, say so plainly, then give the nearest thing you did with customer feedback, or how you would set up the loop |
| F4 | Defining, tracking and analysing operational metrics. Role-family pattern | none given | none | [generic] | discovery | Strong evidence: a metric you defined or tracked and what you did when it moved. Pick one where you know how the figure was counted. If you can't say how it was counted, choose a different one. If none comes to mind, say so plainly, then say how you would pick and baseline one |
| F5 | Influencing cross-functional partners without direct authority. Role-family pattern | none given | none | [generic] | discovery | Strong evidence: a time you got another team to change course or commit to something they didn't own. It needs a named stake, the disagreement, and how it ended, including if it ended badly. If none comes to mind, say so plainly, then give the nearest cross-team work you did, or how you would handle it |
| F6 | Clear written communication: process docs, launch notes, proposals. Role-family pattern | none given | none | [generic] | discovery | Strong evidence: a document you wrote that others used or acted on. Pick one you could describe in two sentences. If none comes to mind, say so plainly, then say how you would write for busy readers |
| F7 | Operational tooling and automation that reduces manual work. Role-family pattern | none given | none | [generic] | discovery | Strong evidence: a tool or automation you set up or improved, and the manual work it removed. Pick one where you can say what was yours. If none comes to mind, say so plainly, then name a tool you use and what it changes |

## Persona table

None of my sources says how this final round is structured. "Final round" on its own doesn't establish it. So the weights below use the **generic archetype**: flat weights, chosen because nothing documented exists, not from a pattern specific to Stripe. Final rounds are often several sessions back to back. If yours is, send the schedule and you'll get one mini-pack per session.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems: plan a launch, diagnose a metric, design a process | Medium. Flat weight, no loop source. Product ops work is about live problems, so expect at least one case somewhere in a final | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise per case, respectfully |
| Skeptic | Quiet probing of gaps, plus "why leave, why here, why now" | Medium. Flat weight, no loop source. Final rounds tend to retest motivation and self-assessment | Rehearse the most predictable objection (B1) until it's boring. Build bridges only from things you actually did, and say the limit plainly where there's nothing to bridge from |
| Data-Driven Prober | Asks for denominators, inputs and how figures were counted | Medium. Flat weight, no loop source. The role usually lists metrics work | Know how every number you cite was counted. Name the weakest assumption before they do. Say plainly when you don't know |
| Pressure | Interrupts, plays devil's advocate, time-boxes | Medium. Flat weight, no loop source | Pause, restate the question, hold through two follow-ups, then concede something specific. Don't fold just to restore harmony |
| Values / Behavioral | Scenario probes, STAR-shaped stories | Medium. Flat weight, no loop source. Stripe's published values aren't in hand, so these questions use generic stems | One story per stem from your own material. Say "we" for context and "I" for your part. If the hard truth didn't land, say so |
| Conversational | Friendly openers, the biography question, "anything for me?" | Medium. Flat weight, no loop source | A pre-built 90-second arc. Treat casual questions as scored. Always have reverse questions ready |
| Peer Evaluator | Seams between teams, credit-sharing, "what would you need from me" | Medium. Flat weight, no loop source. A product ops role sits between teams by definition | Frame what you bring their team, not just what you need. Propose principles for the seam rather than pretending to know where it sits |

## Question banks

Weights are flat, so the banks run in the persona table's order. **Highest-ROI prep in this pack: B1.**

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch your plan for getting a new feature launch-ready across support, sales and engineering. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, whether the date is fixed, and what "ready" means to each team. Then the objective. Then who's affected and how. Then the approach: a readiness checklist with named owners, go/no-go criteria agreed in advance, and a comms plan for internal teams and users. Then week-one metrics. Then the risks, and what you'd cut if the date can't move. Challenge one premise, for example whether every team needs the same depth of readiness. The question makes no claim about your past, so the guidance makes none | F1's requirement asked as a live problem. CASE because it scores structure, not history |
| A2 | "Support tickets about one feature are up 20% this month. Diagnose it." | CASE | [generic] | Clarify the denominator first: raw tickets, or tickets per active user, since growth alone can do this. Segment it: new versus existing users, one region, one integration path, one plan type. Line the timeline up against releases and changes. Read a sample of tickets before you form a theory. Rank your hypotheses, say what you'd check first and why, and say how you'd close the loop with the product team. Name the assumption in your own diagnosis you'd defend least | A persona stem applied to F4 and F3. CASE because the reasoning is what's scored |
| A3 | "The product team gets more feature requests from the field than it can process. Design the intake." | CASE | [generic] | One front door. De-duplicate and tag. A small set of prioritisation criteria: how many users are affected, how severe, how often it comes up. A regular review with product managers. Closing the loop with whoever submitted the request, including when the answer is no. One metric that shows the intake is working. Name the trade-off between a heavier process and a faster one. Expect D2 as the follow-up | F2 and F3 together. CASE because you design it live |
| A4 | "How would you write up a process change so that busy teams actually read and follow it?" | JD | [generic] | Lead with what changes for the reader and when. Keep it to one page or less, with the decision first and the reasoning after. Name an owner for questions. Give a date to check whether it's being followed. Say how you'd find out it wasn't read: the questions that keep arriving, the errors that keep recurring. If you have a real document you wrote, you can mention it at the end, but only what you actually did | F6 would otherwise have no question. JD because it scores a role skill directly |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **The highest-ROI rehearsal in this pack.** To choose your answer, take the fit-snapshot row where your real story is thinnest. It has to be real, relevant to the role, and not a strength in disguise. Structure: name it plainly in one sentence. Say what you'd do in the first 30 days to close it, as a plan, not a past. Then stop. Follow-up 1, "why should we take that risk?": hold. Return to what you can do, using only stories you actually have, and don't shrink the gap or inflate it. Follow-up 2, "anything else?": give a second, smaller gap if there truly is one, or say plainly that this is the one that matters. If no gap comes to mind at all, treat that as the warning sign and use the thinnest snapshot row | The most predictable objection for any final-round candidate. With no CV it's inferred from the role family, not from your record, and your CV would sharpen it. JD because it scores self-assessment against the stated job |
| B2 | "Why product ops, and why here, why now?" | JD | [generic] | Three beats in about 90 seconds. Why this kind of work, from your own experience, honestly. Why this company, using only what you've read in its own published material and naming where you read it. Why now, in your own words about your own timing. Don't cite a fact about the company you couldn't point to | The Skeptic's motivation check. JD because it ties motivation to the role |
| B3 | "Suppose part of this role is new to you. How would you get up to speed?" | JD | [generic] | A ramp plan: who you'd learn from, what you'd shadow, what small thing you'd deliver first, and how you and your manager would know you're on track by day 30 and day 60. Keep it concrete and short. It's a plan, so it makes no claim about your past | Pairs with B1. The ramp plan is the second half of an honest answer about a gap |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You mentioned a number a moment ago. Walk me through how it was counted." | EXP | [generic] | A standing rule for any figure you cite today. Know four things, in your own words: how it was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part of it was yours. If you don't know how it was counted, say so plainly. That beats an explanation you can't repeat under a second question. If you can't answer any of the four, don't cite the figure | With no CV figures in hand this is a general rehearsal, not tied to any one number. EXP because it tests what you can stand behind |
| C2 | "What metrics would tell you an operational process is actually working?" | JD | [generic] | Separate input metrics from outcome metrics. Pair a leading signal with a lagging one. Add one quality guardrail so speed doesn't come at the cost of errors. Baseline before you change anything. Say how you'd spot the metric being gamed | F4's requirement, asked about process. JD because it scores a listed skill |
| C3 | "A month after a launch, how would you know it went well?" | JD | [generic] | Agree what success means with the product manager before launch, not after. Then adoption, support load, quality or incident signals, and qualitative feedback. Name your weakest assumption, for example that adoption reflects value. Say what you'd do if the signals disagree | F1 and F4 together. JD content with CASE delivery |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then restate it. Acknowledge their real advantage, which is context. Then give two or three things you'd bring, each from your own experience. Don't knock internal candidates. Keep to time, because the time-box is part of the test | A persona stem. JD because it asks you to price your own fit |
| D2 | "That intake process sounds heavy. Wouldn't it slow everyone down?" | CASE | [generic] | Hold then concede. Hold the core: say why the step exists and what breaks without it, and hold that through two pushes. Then concede something specific: which step you'd cut first and what you'd lose by cutting it. Don't drop the whole design to restore harmony | The follow-on to A3. CASE content with Pressure delivery |
| D3 | "Engineering says your launch checklist is bureaucracy and they're shipping Friday regardless. What do you do?" | CASE | [generic] | Restate their concern fairly. Split the checklist into what protects users and what's nice to have. Offer a minimal gate made only of the first group. Escalate only if a real user-facing risk remains, and say who you'd escalate to and how. Hold on the risk item and concede the rest | F1 and F5 under pressure. CASE because the decision is live |

### E. Values / Behavioral

Stripe's published values aren't in hand, so these use generic persona stems rather than Stripe's own value names. With web search allowed, this bank would be rebuilt with one question per published value.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you held a position with someone more senior. It needs a named stake, what you said and how you said it, and what happened next. Say "we" for context and "I" for your part. If it didn't land, say so, and don't supply a better ending. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A persona stem. It also probes F5. VAL because it scores behaviour, not skill |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a user's need and a number you were measured on pulled in different directions. It needs the trade-off, your part in the call, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would weigh it | A persona stem. It also touches F3. VAL for the same reason as E1 |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the turn towards operations or product work, what you do now, and why this role is the next step. Use only facts you'd stand behind under a follow-up. End on a line that points at the role, so the next question comes from where you want it | A persona stem, and almost always asked. EXP because each beat will be followed up |
| F2 | "What have you read about how we work that made you want to apply?" | CO | [generic] | Cite only what you've read in the company's own published material, such as its site, documentation or letters, and name where you read it. Give one specific thing and why it matters to this role. No numbers you can't source | CO coverage. It's generic because research couldn't run, which is the honest cost. With web search it becomes a question grounded in current strategy |
| F3 | "What tool or way of working are you excited about in ops these days?" | EXP | [generic] | Something you actually use. Say what it changed for you or your team, and one limitation. If nothing comes to mind, say so plainly, then name something you're learning and why | A persona stem applied to F7. EXP because they'll ask how you used it |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Propose principles: who decides which kind of question, a shared place where decisions get written down, and an escalation path you'd both agree to before you need it. Say how you'd want to hear disagreement: early, directly, with the data | A persona stem. CASE because you design the seam live |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Your principle, in your own words. If you have a real example, give it with "we" for context and "I" for your part. If none comes to mind, say so plainly, then say how you would handle it | A persona stem. It probes F5 from the peer's side |
| G3 | "What would you need from my team in your first 90 days, and what would we get from you?" | JD | [generic] | Answer both halves. What you'd need: access, context, a regular check-in. What they'd get: a concrete early thing that takes load off them. Ask what's currently costing them the most time | The reciprocity probe. JD because it scores how you'd work in the role |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launches and launch readiness | A1, C3, D3 |
| F2 Process design and improvement | A3, C2, D2 |
| F3 Feedback into product | A2, A3, E2 |
| F4 Operational metrics | A2, C1, C2, C3 |
| F5 Cross-functional influence | D3, E1, G1, G2 |
| F6 Written communication | A4 |
| F7 Tooling and automation | F3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a great first six months look like in this role, and what would make you say the hire didn't work?" | It asks for the actual scorecard, and the second half shows you can hear a hard answer |
| R2 | "Where does product ops sit relative to product, support and sales here, and where is that line still being worked out?" | It shows you're thinking about the seam before day one, and the answer tells you a lot about the role |
| R3 | "What's one process you'd most like the new person to fix, and why hasn't it been fixed yet?" | It turns the job into a concrete problem, and the "why not yet" part shows judgement |
| R4 | "How does feedback from the field reach product decisions today, and where does it get lost?" | It's the core of the role asked as a question. Their answer tells you whether the loop exists |
| R5 | "How do you decide when a process is heavy enough?" | It reveals the team's tolerance for process, which changes how you'd do the job |
| R6 | "What's something about working here that surprised you when you joined?" | It invites candour and works well in a final round with any interviewer |

## Prohibited claims

No entries. You haven't given me any sentences about your past yet, so there's no wording of yours this pack could stretch. Every requirement in the fit snapshot is silence on my side, and the pack handles it with selection scaffolds that end in an honest branch. Once you send a CV or your own descriptions of your work, this list will be built from them: the inflated versions of what you actually said, each with its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| none | No candidate sentences given | Not applicable |

## Sources

Provided inputs: the company name (Stripe), the role title (Product Operations Manager) and the round ("final round"), all from your message. No documents were provided and no dossier was used.

Searches sent, all refused by this session's permissions:

- "Stripe operating principles official": refused
- "Stripe interview process onsite final round operations": refused
- "Stripe Product Operations Manager job description": refused
- "Stripe 2026 annual letter strategy news": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | The search was refused. It would have added the values cheat sheet with Stripe's own value names, and VAL questions mapped one per value |
| 2. Stripe interview process, operations | unavailable | The search was refused. It would have replaced the generic archetype's flat weights with weights for the rounds Stripe documents, and settled whether there's a values round |
| 3. Stripe strategy and recent news | unavailable | The search was refused. It would have grounded F2 and the case questions in current priorities, instead of leaving them generic |
| 4. Interviewer name at Stripe | n/a | No name was given, so there was no query to form. There's no interviewer read, and the reverse questions are role-generic |
| 5. Representative Product Operations Manager JD | unavailable | The search was refused. It would have turned the fit snapshot's role-family requirements into quoted `[inferred]` ones, and the JD questions with them |

## Upgrade menu

- **Allow web search.** It would add Stripe's published values as a cheat sheet with mapped questions, persona weights for the documented loop, and case and CO questions grounded in current strategy. All five research rows above would come back to life
- **The job description text.** All seven fit-snapshot rows would become quoted `[grounded]` requirements, every JD requirement would get its own question, and any gate, such as location or authorisation, would be surfaced
- **Your CV or a few sentences about your work.** The worksheet would become a real fit snapshot. Guidance would point at your actual stories instead of telling you how to pick one, there'd be a defend-the-number question for each figure on your CV, and B1 would be aimed at your actual thinnest area
- **The final-round schedule: who you meet and in what role.** Persona weights would follow the real sessions, with one mini-pack per session if it's several back to back
- **Interviewer names.** You'd get a read of each interviewer from their public professional footprint, and at least one reverse question tied to their own path
- **The recruiter's prep email.** It would cover stated focus areas, plus a build section for any presentation or take-home they announced. That's usually one email to the recruiter
- **How much prep time you have.** It would add a prioritised schedule sized to that time
- **A deeper research pass, once search is allowed.** Up to 6 more searches and 2 more fetches, several more minutes. It would add a strategy brief, loop reports for this role family, and recent org context, which would sharpen the case and CO questions
- **A tuesday-dossier.md from an earlier evaluation of this role, if you have one.** It would add verified evidence, the objection it found to rehearse hardest, and its list of claims to avoid
