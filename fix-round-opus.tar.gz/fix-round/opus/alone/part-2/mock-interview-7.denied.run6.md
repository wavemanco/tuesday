Web searches were blocked, so I'm building the pack from your JD and background only. Writing it now.
I've saved your prep pack for Friday. Web search was blocked, so it's built only from the job description and the five sentences you gave me about your background. It assumes Tobias is your hiring manager. It covers 22 practice questions, a table matching each line of the job description against your experience, and questions to ask him at the end.

- **The question most worth rehearsing (A1):** "This role runs two titles' calendars and coordinates four teams — what says you're ready?" Answer with the calendar you ran for one title, and say "I haven't led a team" plainly if he asks.
- **In-app purchases:** the job description never mentions them, but he may still ask. Say "I haven't worked on a game with in-app purchases," give a plan for learning that side, and ask him how revenue fits into event planning (reverse question R4).
- **Your strongest match is the release checklist.** You wrote it and QA still uses it, which lines up directly with the job description's checklist line. Retention numbers and your content calendar are partial matches. The pack shows how to describe each one without stretching it.
- **Homework only you can do:** without search I couldn't look into Saltmarsh's two titles. Play them tonight if you can, and note one event you'd keep and one you'd change. That feeds your "why here" answer.

Files are in:
/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-denied-88d519e4/
- saltmarsh-games_live-operations-producer_interview_pack.md

If you'd like a practice run, I can play Tobias in sceptic mode on A1.
I can also save a tuesday-dossier.md recording the gaps this prep found, for you to use in later sessions.
If you'd like the pack as a Word document, I can convert it.

Is Tobias your future manager, and did the recruiter mention a format or any task to prepare? The answer changes how the question banks are weighted.
How much prep time do you have before Friday? I'll add a prioritised schedule sized to it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Format:** one 60-minute interview on Friday
**Assumption this pack is built on:** Tobias is the hiring manager for this role. Nobody has said so; it is the likeliest reading of his title. If he turns out to be a peer or a skip-level, the persona weights below change.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: the tone, the pressure, the follow-ups. **Types** describe *what* is being scored. Rehearse both.
- Type tags:
  - **VAL**: behavioural or values. Does your past behaviour show the values they care about?
  - **EXP**: experience deep-dive. Does what you said about your past hold up, and what was actually yours?
  - **JD**: role-driven. Can you do the job as written, including where you have gaps?
  - **CO**: company knowledge. Have you done your homework on Saltmarsh and its titles?
  - **CASE**: live problem. How do you structure and reason through a problem from this role, out loud?
- **Provenance labels:**
  - `[grounded]` means it comes from your JD or your own words.
  - `[inferred]` means it is a reasonable derivation, and the source is named.
  - `[generic]` means a role-family pattern with no claim about Saltmarsh or about you.
- **The guidance is scaffolding, not a script.** Every claim about your past rests on one of the five sentences you gave me, which are quoted in the fit snapshot. Where your material is silent, the guidance gives you an **answer slot**: answer it from what really happened, or say plainly that it didn't happen.
- Question IDs go by persona: A, B, C, D, E, G, H. The letter F is reserved for fit-snapshot rows.
- **The single highest-ROI rehearsal in this pack is A1.**

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a content-drop calendar for one title. It does not describe a live-events calendar for two titles. Keep the words at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "plan and run" makes a probe on planning decisions likely. If what went into each week's drop, or its order on the calendar, was yours to decide, say how you decided, in your own words. If it wasn't yours, or there was no such choice, say so plainly and describe how you ran the calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with. Answer slot: if you worked with design, art, engineering or community on the drops, name which and what you did with them, in your own words. If you didn't, say so plainly and say how you would set up that coordination here, framed as a plan |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a post-event review, but it is not the same thing. Keep the words at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: if any part of those numbers was yours to put together before you presented them, say which part and how, in your own words. If none was, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. It is still a single line with nothing behind it to inspect, so expect a probe. Lead with the quote's own terms: you wrote it, and QA still uses it. Answer slot: the JD says "manage... with QA", so expect a probe on how the checklist was used on each release. If you worked through it with QA on releases, say how. If QA ran it without you, say so plainly and stay with writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message. "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Four years is above the three asked for. Your material doesn't say whether the main title was run as a live-service game, so don't label it one unless it was. Answer slot: if the title was run as a live-service game, say what that meant day to day, in your own words. If it wasn't, say so plainly and describe the weekly drops as what they were. Keep "associate" in your title every time |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | A direct match in the JD's own terms. Lead with it in exactly those words. Expect a probe because nothing behind it can be inspected |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The quote touches retention metrics. It doesn't show which metrics they were or how they were counted. Answer slot: say which retention measures were in those monthly numbers, and how they were counted if you know. If you don't know how they were counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist that is still in use is written work, but it is indirect evidence of written communication. Answer slot: if you wrote other things for the team, such as briefs or write-ups, name what they were. If you didn't, say so plainly and let the checklist stand alone |
| F9 | Mobile live events commonly carry a monetization side, such as offers or paid passes. This is a role-family pattern and is not stated in this JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | You stated this gap yourself, and wording cannot close it. Words: "I haven't worked on a game with in-app purchases." Then say how you would learn that side here, framed as a plan, never as something you've done. The JD doesn't mention monetization, so ask about it rather than assuming it (reverse question R4) |

**Requirement coverage.** These are the questions that rehearse each JD line:

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A3, B1, B2 |
| Coordinate design, art, engineering, community | A1, B2, G1, G2 |
| Own the post-event review and its KPIs | B3, B5, C2, C3 |
| Manage the release checklist with QA | D2, E2, B4 |
| 3+ years producing live-service games or apps | A3, D1 |
| Experience running a content calendar | A1, B1, D1 |
| Comfortable with player-retention metrics | C1, C3, B5 |
| Clear written communication | B3, D2 |
| Monetization (role-family, not in the JD) | A2, E1 |

---

## Persona table

The loop comes from your own description: one 60-minute session with the Head of Live Operations. No values round is named in it, so this pack has no values cheat sheet. The weights below assume he is the hiring manager.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of scope: two titles instead of one, coordinating four disciplines, the monetization side | High. A hiring manager is de-risking the hire, and F1, F2 and F9 are where your material is thinnest | Rehearse A1 until it is boring. Hold on your quoted sentences, state your limits before he asks, and give a concrete ramp plan |
| Case / Strategist | "Plan this quarter", "diagnose this drop", "the update is late" | High. A Head of Live Ops is likely to test whether you can do his team's job live, and the JD lists responsibilities that read like cases | Clarify, then objective, segments, approach, metrics, risks. Think aloud and challenge one premise per case |
| Data-Driven Prober | Pushes on the retention numbers you presented: which metrics, how counted | Medium. "Comfortable with player-retention metrics" and "the KPIs it reports" are both in the JD | Know what you can and can't say about how the numbers were counted, and say "I don't know" where that's true |
| Conversational | "Walk me through your journey", what you're playing these days | Medium. Most 60-minute interviews open this way, and the opener is still scored | A pre-built 90-second arc made only from your five sentences (D1) |
| Pressure | Time-boxed "why you", "how much was actually you" | Low to medium. It is not the default for a hiring manager, but scope gaps invite it | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Peer Evaluator | Scenarios about working with community or engineering | Low. He isn't a peer, but coordination is central to the JD | Reciprocity: what you give the other team as well as what you need from them |
| Values / Behavioural | "Tell me about a time…" prompts | Low. No values round is named, and no published values could be read | Selection scaffolds, each with an honest branch |

---

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role runs the events calendar for two titles and coordinates design, art, engineering and community on every update. What in your background tells me you're ready for that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | **The highest-ROI rehearsal in this pack.** Open with the quote's own words: "For the last two years I ran the weekly content-drop calendar for our main title." Name the limit before he does: it was one title. Answer slot: the JD's coordinate line makes a follow-up on the four teams likely. If you worked with any of them on the drops, say which and what you did, in your own words. If you didn't, say so plainly and stay with the calendar. If he asks about leading people: "I haven't led a team." Then give a plan for two titles, framed as a plan: what you would want to learn in the first weeks and how you would keep both calendars visible. Hold through two follow-ups by coming back to the calendar you ran, never by adding to it | F1 and F2 are where the JD's scope presses hardest on your material, so this objection will come up in some form. JD because it scores the headline requirement directly |
| A2 | "I don't see in-app purchases in your background. How would you handle the revenue side of events?" | CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly first: "I haven't worked on a game with in-app purchases." Don't apologise and don't hint at any familiarity. Then give a plan: read the past post-event reviews, learn which revenue figures the review reports, and pair early with whoever owns monetization. End by asking how revenue figures in their event goals, which turns the gap into diligence | F9 is a gap you stated yourself, and a Head of Live Ops is likely to probe it even though the JD is silent on it. CASE because the answer is a forward plan, not a past |
| A3 | "You've been an associate producer. Why are you ready for a producer role?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say the title as it is, with "associate". Then the calendar, in the quote's words. Answer slot: the JD's "plan and run" makes a probe on decisions likely. If what shipped in each drop or when was yours to decide, give one example in your own words. If it wasn't, say so plainly and describe how you ran the calendar. Don't argue that the title understated you | F5 is the "3+ years producing" line, and the step up in title is an obvious seam for him to probe. JD because it scores a stated qualification |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick a real weakness and not a disguised strength. Your material lets you name one honestly without inventing anything: the calendar you ran was for one title, and the JD asks for two. Say that, then give a concrete first-month plan for the second title, framed as a plan | Your material makes the honest weak spot visible (F1), and naming it yourself scores better than having it extracted. JD because it is scored against the JD's list |
| A5 | "Why leave the puzzle studio, and why live ops here?" | CO | [grounded] "4 years as an associate producer at a puzzle-game studio." | Give your own reasons in your own words. This pack doesn't supply them. Don't criticise your current studio. The "why here" half needs homework tonight on Saltmarsh's two titles: play them if you can and note one live event you'd keep and one you'd change. Research was blocked, so the pack can't do this for you | A motivation check is near-certain in a hiring-manager round. CO because the "why here" half scores homework |

### B. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Plan the next quarter of live events across our two titles. What do you need to know first?" | CASE | [generic] | Clarify first: the goals for each title this quarter, which KPIs the review reports, team capacity, and the lead time each update needs. State the objective. Segment by title and by player group. Then the approach: a shared calendar skeleton, staggered peaks so the two titles don't compete for the same teams in the same week, and dependencies marked. Close with metrics and the top two risks. No claim about your past is needed | The headline responsibility, asked as a live problem. `[generic]` because it is a structure, not a fact about Saltmarsh |
| B2 | "Both titles need the same art team in the same week. How do you resolve it?" | CASE | [generic] | Find out which event is fixed and which can move. Ask what each one is for against its title's goals. Lay out the options: re-sequence, cut scope, reuse assets, or escalate. Make the trade-off visible to both leads, decide or escalate with a recommendation, and write it down. Challenge one premise, for example whether both events really need new art | Two titles means resource collisions. It tests coordination (F2's requirement) as a decision rather than a record |
| B3 | "Talk me through how you'd run a post-event review. What's in it, and who reads it?" | JD | [generic] | Cover four things: what the event was for, the KPIs against that aim, what went well and badly in production, and decisions for the next event. Say who it goes to and in what form: a short written summary up top, detail below. Keep a one-page format so it gets read. No claim about your past is needed | "Own the post-event review" is a JD line your material reaches only partly (F3), and the written form tests the communication requirement (F8) too. JD content, CASE delivery |
| B4 | "An update is due tomorrow and QA finds a blocking bug in the event content. What do you do?" | CASE | [generic] | Clarify the severity and what it affects. Lay out the options: fix and retest, ship without that content, or slip the date. Name who decides and who needs to know, community included, so players hear one story. Run the release checklist on whatever ships. Afterwards, decide what to add to the checklist so it is caught earlier next time | Tests the "release checklist with QA" line under pressure. `[generic]` because it is a pattern |
| B5 | "An event's day-7 retention came in well below the last one. Diagnose it." | CASE | [generic] | Clarify: is it measured the same way as last time, on comparable groups, at a comparable time? Then segment by title, platform, new versus returning players and acquisition source. Look for confounders such as a bug, a competing release or a calendar overlap. Form a hypothesis, then say what data you'd pull to test it, and what you'd change next event | Tests "comfortable with player-retention metrics" (F7) live. `[generic]` because the metric and scenario are illustrative |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. What was measured, and how?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beats the quote gives you: monthly, retention numbers, presented to the studio head. Answer slot: say which measures were in them and how they were counted, in your own words. If another team produced them, say so plainly and describe presenting them. Name the assumption behind them you'd defend least, or say plainly that you don't know how they were counted. Don't guess at a method | F7 is where a prober will push. EXP because it tests what was actually yours |
| C2 | "What changed after one of those presentations?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: the JD's "KPIs it reports" makes a probe on consequences likely. If a decision followed one of those presentations, say what it was and what your part was, in your own words. If none did, or you don't know, say so plainly and describe what the presentation covered | F3's gap between presenting and owning, rehearsed before the probe arrives. EXP because it tests the outcome, not the activity |
| C3 | "How did you tell whether a weekly content drop worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: the JD's KPI line makes this probe likely. If you measured the drops, say how, in your own words. If you didn't, say so plainly, then say what you would measure first and why | Connects F6 to F7, the spot where an interviewer can join your two strongest lines. EXP primary, JD second |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc using only these four beats, in this order: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title over the last two years, the release checklist QA still uses, and presenting the monthly retention numbers to the studio head. End on why live ops at Saltmarsh, in your own words | The opener is scored. This answer sets up every follow-up, so it must contain nothing you can't defend. EXP because it's your history |
| D2 | "Tell me about that release checklist." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Lead with the quote: you wrote it, and QA still uses it. Answer slot: describe what's on it in your own words. If you worked through it with QA on releases, say how. If QA ran it on their own, say so plainly. Bring a cleaned-up version only if your studio would be fine with that | F4 is your clearest match to a JD line, and F8 also leans on it. EXP primary, JD second |
| D3 | "What mobile games are you playing right now, and whose live events do you rate?" | CO | [generic] | Give a real answer. Pick one game and one live event, and say specifically what it did well and what you'd change. Mention Saltmarsh's titles only if you've actually played them | A casual question that scores genuine interest in the craft. `[generic]` because the pack couldn't research Saltmarsh's titles |

### E. Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live ops with monetization?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | Pause, then hold on the calendar: "For the last two years I ran the weekly content-drop calendar for our main title." Concede specifically: "I haven't worked on a game with in-app purchases." Close on what you'd do first to learn that side. Don't fold on the calendar and don't overclaim the gap away | F9 under time pressure. The hold-then-concede structure is what's being scored |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold on the quote: you wrote it. Answer slot: if others contributed to it, say who and what, plainly. If it was all yours, say so without padding. Either answer is fine; hesitating is what costs you | The classic attribution probe on F4. EXP because it tests ownership |

### G. Peer-style (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "I'm the community lead. An update lands badly with players. What do you need from me, and what do I get from you?" | CASE | [generic] | Reciprocity. What you need: early player sentiment and a channel for one shared message. What they get: advance notice of every update, a fix timeline they can repeat, and their input in the post-event review. Propose a principle for the seam rather than pretending to know how it works today | "Community" is one of the four teams in the JD (F2's requirement). CASE because it's a live collaboration scenario |
| G2 | "An engineer says the update scope won't fit the date. You think it will. How do you handle it?" | CASE | [generic] | Ask what they're seeing that you aren't. Separate scope from date, then lay out the options: cut, slip or add help. Agree a decision and who owns it, and record it on the calendar. Show you can disagree and still keep the working relationship | Tests disagreement style with a discipline you'd coordinate (F2's requirement) |

### H. Values / Behavioural (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered a number leadership didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a real stake, where you didn't soften the message and the relationship stayed intact. Your material shows who you presented to, but not whether any number was unwelcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, presenting the monthly retention numbers to the studio head, or say how you would handle it | A common behavioural prompt for anyone who reports KPIs (F3). VAL because it scores candour, not content |
| H2 | "Tell me about a time a plan didn't survive the schedule." | VAL | [generic] | Selection scaffold: pick a time a plan had to change, what you did about it, and what you changed afterwards. It needs a real constraint and your own decision in it. If no such time comes to mind, say so plainly, then say how you would handle it | "Plan and run the live-events calendar" makes replanning likely to come up. VAL because it scores ownership and adaptability |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here, and who reads it?" | You'd own it, so asking shows you're already thinking about the job. The answer also tells you which KPIs to learn first |
| R2 | "When the two titles' calendars collide, how is priority decided today?" | It shows you've thought about the two-title part of the role and tells you how much authority the role really has |
| R3 | "What's on the release checklist today, and what does it miss most often?" | It ties to your strongest match (F4) without bragging, and gives you something concrete to talk about |
| R4 | "How does monetization factor into event planning on these titles, and who owns that side?" | It addresses F9 head-on as diligence, and tells you whether that gap matters here |
| R5 | "What would make the first 90 days in this role a success, from where you sit?" | It turns his expectations into something you can answer to, and invites him to picture you in the role |
| R6 | "What changed after the most recent event review on your team?" | It tests whether the reviews drive decisions, and shows you care about the loop closing |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar | Inflated form of F1 | F1's quote at its own scope. As an observation, not words for you: your material says a content-drop calendar, not live events |
| Ran calendars across two or more titles | Inflated form of F1 | F1's quote: "our main title." The A1 and A3 slots stay within that one calendar |
| Producer, without "associate" | Inflated form of F5 | F5's quote, with the title as given: "associate producer" |
| Owned post-event reviews and their KPIs | Inflated form of F3 | F3's quote at its own scope. The C2 slot asks only about what followed the presentations |
| Led a team | A negative you stated | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | A negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |

---

## Sources

**Provided documents:**
- The JD text in your message
- Your background in your message (five sentences, quoted in the fit snapshot)
- Company size (about 350 people) and interviewer name and title, from your message

**Searches sent, all refused** (web search permission was not granted):
1. "Saltmarsh Games mobile studio values": refused
2. "Saltmarsh Games interview process producer": refused
3. "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused
4. "Saltmarsh Games news 2026": refused

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | The one call was refused. It would have themed the VAL questions (H1, H2) to Saltmarsh's own published values |
| 2. Saltmarsh Games interview process | unavailable | The one call was refused. It would have confirmed the round's format and Tobias's place in the loop, and so the persona weights |
| 3. Saltmarsh Games strategy and recent news | unavailable | The one call was refused. It would have grounded A5, D3 and one CASE question in the titles' current state; those stay `[generic]` |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The one call was refused. It would have given an interviewer read, adjusted the persona weights, and given a reverse question tied to his career path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Whether Tobias is your future manager, and any recruiter notes on format** → the persona weights are confirmed or recomputed, and a build section is added if the recruiter announced a task or presentation
- **How much prep time you have before Friday** → a prioritised prep schedule sized to that time
- **Allowing web search** → targets 1 to 4 above run: Saltmarsh's values, the interview format, the titles' current state, and Tobias's public professional footprint. That adds an interviewer read, strategy-grounded CO and CASE questions, and a reverse question tied to his path
- **A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and it needs search allowed)** → a strategy brief on the two titles, deeper material on Tobias's published talks or writing, reported interview loops, and recent studio context
- **Your answers to the slots in F1, F2, F3, F5, F7 and F8**, given here outside a drill → those rows move from slot to story-mapped, and A1, A3, C1, C2 and C3 get firmer guidance
- **A cleaned-up copy of the release checklist, if your studio allows it** → F4 and F8 can rise from `medium` and `low` toward `high`, because there is something real behind them to inspect
- **A tuesday-dossier.md from job-underwriter** → evidence-checked confidence bands and a highest-ROI objection taken from your confirmed evidence rather than inferred
