Quick update: web search was blocked when I tried it, so I'm building the pack from your message and the recruiter's email alone, and labelling what that leaves out.
I've saved your prep pack as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. Web search was blocked when I tried it, and there was no job description, so it's built only from your message and the recruiter's email.

What's in it:
- **A 4-hour prep plan.** Most of the time goes on building the POV and rehearsing it aloud. Next comes the hardest question you're likely to get: "you've never carried a quota and never sold into rail."
- **A build guide for the 15-minute POV.** It gives you a 5-part outline with timings and three thesis options, each with the drawback you should state yourself. The opening defines what you mean by "operator partnerships", and the last two minutes cover what changes for operators. It doesn't use facts from the market report because I haven't seen it, so those spots are left for you to fill.
- **24 practice questions**, sorted by who's likely to ask them. Ross's commercials questions are heavily covered, especially on the £4M figure.
- **A list of things not to claim.** For example, don't call the £4M "closed" revenue when it was influenced, and don't let your bus and light rail consulting stand in for train operator experience.

Say the word and I'll play Ross and push you on B1, the question the pack names as the most valuable to rehearse.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, or should I keep working without one? Wherever the fit table now relies on general role patterns, the JD's own wording would replace them.
If you allow web search, do you want me to run the research again, and optionally go deeper (up to 6 more searches and 2 more fetches, several more minutes)? That would add Kelverton's values, recent news and Deepa's and Ross's career backgrounds.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack — Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, Tuesday. 60-minute panel.
**Panel:** Deepa, VP Partnerships (your future manager), and Ross, Commercial Director.
**Format, from the recruiter:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."
**Built from:** your message and the recruiter's email only. No JD was supplied. Web search was refused when tried, so nothing here about Kelverton's values, strategy or the panel's backgrounds comes from research. The internal market report is something you have read and I have not, so wherever the pack needs its content, it leaves you a slot to fill.

---

## How to use this pack

**Personas** describe how a question gets asked (who, in what register). **Types** describe what is being scored:

- **VAL** — whether your past behaviour shows the company's stated values
- **EXP** — whether your claims hold up under scrutiny, and what was actually you
- **JD** — whether you can do the stated job, gaps included
- **CO** — homework depth: market, strategy, thinking at the company's altitude
- **CASE** — structure and reasoning on a live problem from the role

**Provenance labels:** `[grounded]` = traceable to your message or the recruiter's email. `[inferred]` = derived, with the derivation named. `[generic]` = a role-family pattern, useful rehearsal with no claim about Kelverton.

**An answer slot** is a spot where the strong version of an answer needs a fact your message doesn't give me. It names the likely probe and gives two honest branches. Fill it from what really happened, or say plainly that it didn't happen.

The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage — 4 hours

| Order | Time | Do this | Section / IDs |
|---|---|---|---|
| 1 | 20 min | Reread the market report. Pick the one finding you'd build on and the one you'd push back on, and write a sentence for each | Graded deliverable, step 2 |
| 2 | 70 min | Build the POV on the shape below. Choose one thesis and say its concession out loud. Run it standing up, timed, twice, aiming for 12–13 minutes | Graded deliverable |
| 3 | 45 min | Rehearse B1 aloud through all three follow-ups until it's boring. It's the highest-ROI prep in the pack | B1, then B4 and D2 |
| 4 | 40 min | Ross's commercials: fill the answer slots on the £4M and the 6-to-40 *before* Tuesday, then run C4 and D3 aloud | C1, C2, D1, D3, C4 |
| 5 | 30 min | Deepa's cases: structure only, out loud, two minutes each | A1, A2, A3, A5 |
| 6 | 15 min | Pick three reverse questions, two for Deepa and one for Ross | Reverse questions |
| 7 | 20 min | Polish your 90-second journey arc and the why-rail answer | E1, B2 |

Everything else is insurance.

---

## Fit snapshot

No JD was supplied. The rows sourced to the recruiter quote her email. The rest are role-family requirements, unquoted and labelled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Adjacent: a partner channel in payments, not operator partnerships in rail. Keep the words at the quote's own scope: you ran the ISV channel and took it from 6 partners to 40. Answer slot: the 18-month framing makes a probe on how the channel's direction was set likely. If that direction was yours to set, say what you chose and why, in your own words. If it was set for you, say so plainly and describe what you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Adjacent: bus and light rail, not train operating companies, and network planning, which is not the same work as selling scheduling software. Keep "from the other side" exactly as you said it. Answer slot: the operator-outcome close makes a probe on who your consulting clients were likely. Say who they were and which side of the table you sat on, in your own words. If any of the planning work touched timetables or schedules, say what. If none did, say so and stay with network planning |
| F3 | "Ross will push on commercials." — recruiter | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Keep both words that limit the figure, "roughly" and "influenced". Answer slots raised by the figure: how it was counted, what it is sensitive to, the assumption behind it you'd defend least, and which part was yours. Answer each in your own words. "I don't know exactly how it was counted" is an honest answer |
| F4 | "Ross will push on commercials." — recruiter | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | No wording closes this gap, and you have already said so. Words: "I haven't carried a direct quota. My numbers were influenced revenue." Then how you'd operate against a number here, said as a plan and never as a past |
| F5 | Selling into the rail operator market, a role-family requirement | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | Words: "I haven't sold into rail." Then your ramp plan, said as a plan. Never let F2 stand in for this. Bus and light rail planning is not rail sales |
| F6 | Building and scaling a partner channel, a role-family requirement | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap. It's a self-reported line with nothing behind it to inspect, so expect a probe. Lead with the counts in your own sentence's terms, 6 partners to 40 |
| F7 | Senior stakeholder management with customer executives, a role-family requirement | none given | none | [generic] | discovery | Strong evidence here is a named senior counterpart, a moment where interests diverged, and a relationship that survived it. Selection scaffold: pick a time from the payments channel or the consulting years that has all three. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F8 | Command of the company's own market and strategy, a role-family requirement | "She also attached the market report their strategy team circulated internally last quarter, which I've read." — your message | medium | [generic] | discovery | Reading the report is not the same as having a view on it. Selection scaffold: pick one finding you'd build on and one you'd challenge, each with a reason. If nothing in it strikes you as challengeable, say what you'd want to test first instead |

---

## Graded deliverable — the 15-minute POV

The recruiter announced this, so it's graded. She asked for three things: where you'd take "our operator partnerships over the next 18 months", no slides, and to "land on what it means for the operators themselves".

### Facts about you to build on

| Row | Sentence it rests on |
|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." |
| F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." |
| F8 | "She also attached the market report their strategy team circulated internally last quarter, which I've read." |

Use these sentences at their own scope. The POV is about what you'd do. Your history appears only as one line of why you see it this way, never as proof you've done it in rail.

### Shape — aim for 12–13 minutes, so you have buffer

| Block | Minutes | What goes in it | Provenance |
|---|---|---|---|
| 1. Define the term and give the thesis | 1 | Say which reading of "operator partnerships" you're using before you build on it, then give the thesis in one sentence. The phrase can be read two ways: operators as customers you build deeper commercial relationships with, or operators as co-development partners shaping the product. Say which you mean, so Deepa isn't scoring you against a reading you didn't choose | [inferred] from the recruiter's wording, which names operators as the people the plan should benefit |
| 2. Where things stand | 2 | One finding from the report you build on, which proves you've done the homework. Then one place you'd go further or differently, with your reason. Don't recite the report, because the panel wrote it | [grounded] on the report's existence. The content is yours to supply |
| 3. Three moves: 0–6, 6–12 and 12–18 months | 6–7 | One move per phase. Each gets what you do, who on the operator side it involves, and how you'd know it's working | [generic] structure |
| 4. How it pays | 2 | A preview for Ross: the commercial logic of each move, meaning who pays, for what and when. Use structure, not invented numbers. Say which figures you'd need from Kelverton to size it | [generic] |
| 5. What it means for operators | 2 | The close she asked for. Name two or three concrete changes an operator would notice, in their terms rather than Kelverton's | [generic] options below |

Say your signposts out loud ("three moves", "first", "the commercial side", "and for operators"). With no slides, your spoken structure is what the panel has to follow.

### Thesis options — pick one, and say its concession out loud

| Thesis | The case | Mandatory concession | Provenance |
|---|---|---|---|
| T1 Depth over breadth: a small number of operators become design partners on the roadmap, with commercial terms that reward co-investment | Partnerships that shape the product are harder to displace than ones that only buy it, and a few deep references can carry the wider market | Slower revenue visibility, and a real risk that one operator captures the roadmap or turns the partnership into paid bespoke work. Say how you'd guard against that | [generic] |
| T2 Ecosystem around the operator: partner with the other vendors operators already integrate with, so Kelverton's scheduling sits at the centre of their stack | The closest fit to F1's channel work, and it makes Kelverton easier to buy and harder to rip out | It assumes the product has the integration surface to support it, which you don't know. Say so, and make it your first question to Deepa. It also invites channel conflict with direct sales, which Ross will raise | [generic] |
| T3 Commercial model first: rework how operator partnerships are priced and structured before scaling them | It speaks Ross's language and ties every move to how it pays | Highest risk for someone with F4's gap, because you'd be proposing a commercial model without having carried a number. Only pick it if you can defend it through C4 and D4 | [generic] |

The candidate this pack is built for gets the most from T1 or T2. T2 uses F1's adjacency directly. T1 keeps the focus on operators, which is where the recruiter asked you to land.

### Differentiation from the consensus answer

| Move | What to do | Provenance |
|---|---|---|
| Consensus item | Every candidate got the same report. Use one of its findings to show you've done the reading, in a single sentence | [grounded] on your message. Its content is yours |
| Divergence | Make one point where you'd go further, differently or slower than the report implies, with a reason the panel can disagree with | [generic] |
| Anti-pick | Name one thing you would not do in the first 18 months, for example chasing a long tail of small partners, and why. In a partnerships role, a clear no shows judgement | [generic] |

### The close — what operators get

Pick two or three and say them as changes in an operator's working week, not as features. Anchor each one in a pain point the report names, if it names one.

| Option | Provenance |
|---|---|
| A seat at the roadmap table: their constraints show up in the product rather than in change requests | [generic] |
| Fewer integration headaches: the systems they already run work with scheduling without one-off projects | [generic] |
| Commercial terms that match how they buy and budget, not just how a vendor likes to sell | [generic] |
| Partner-delivered support or services close to them, from partners that understand their operation | [generic] |

---

## Reading the interviewer

Public career footprint: not established, because the search was refused. Everything below comes from the recruiter's email.

| Panel member | What the recruiter said | Practical implication | Provenance |
|---|---|---|---|
| Deepa | "VP Partnerships, your future manager" | She owns the partnerships strategy you'd be extending, so the POV is pitched at her. Ask her what "operator partnerships" means in her team today. She is also scoring whether you'd be easy to manage and quick to ramp | [grounded] |
| Ross | "Commercial Director" and "Ross will push on commercials" | Expect the £4M, the quota gap and the commercial logic of your POV to be pressed hard. Answer numbers questions with numbers or a plain "I don't know", never with adjectives | [grounded] |
| Both | A panel of the two | Turn your body and your answer to whoever asked the question. Bring Deepa back in at the end of a commercials answer, because she's your future manager and Ross's push isn't the whole interview | [generic] |

Mirror opportunities: none offered. Neither panellist's public path is in hand, so there's no shared career jump to point to.

---

## Persona table

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Deepa follows up the POV with "what first", "how would you decide" and "what if" | high | A hiring-manager prior. Your future manager plus a strategy deliverable puts live problems at the centre | Clarify, then objective, approach, metrics and risks. Think aloud and challenge one premise per case |
| Skeptic | Either panellist presses the stated gaps: rail, quota, why now | high | F4 and F5 are gaps you stated yourself, and a hiring manager's job is to derisk them | Rehearse B1 until it's boring. Name the limit before they do, then the plan |
| Data-Driven Prober | Ross takes the £4M and the 6-to-40 apart | high | The recruiter said "Ross will push on commercials", and F3's figure is the most obvious target | Know what you can and can't say about how each figure was counted, and say "I don't know" where it's true |
| Pressure | Ross interrupts, times your answers, or plays devil's advocate on the POV | medium | "Push" in the recruiter's words. It's a commercial director's natural register, not a known style of his | Pause and restate the question. Hold through two follow-ups, then concede one specific thing |
| Peer Evaluator | Ross asks where partnerships and his sales team meet, and who gets credit | medium | Commercial Director and partnerships share operator accounts in most firms of this shape `[generic]` | Offer principles for the handoff, not invented knowledge of how it works there. Frame it as reciprocity |
| Conversational | The opener and the warm-down | low | The POV takes the first 15 minutes, so small talk is short | Have a 90-second arc ready. Casual questions still get scored |
| Values / Behavioral | One or two behavioural probes in the Q&A | low | No values round is named in the recruiter's format, and Kelverton's published values weren't fetched | Have one or two real stories ready. Don't build scaffolds for values you haven't seen |

---

## Question banks

### A — Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've given us 18 months. What do you do in the first 90 days?" | CASE | [generic] | Listen first: name the operators and the internal owners you'd want to hear from. Then test the one assumption your thesis rests on hardest, for example T2's integration surface. Then one early, visible move with an operator. End with what you'd report back at day 90. The question needs no claim about your past, so the guidance makes none | It's the natural follow-up to any 18-month plan, and Deepa will be the one managing those 90 days. CASE because it scores how you sequence the work, not your past |
| A2 | "Pick one operator. How do you decide whether they're a partner or just a customer?" | CASE | [generic] | Criteria said aloud: what they bring beyond their subscription (data, a reference, co-development, reach), what they want from it, and what it costs Kelverton to give them partner treatment. Then the line you'd draw, and what happens to operators below it | It tests whether your POV's definition of "operator partnerships" holds up, which is where a no-slides plan is easiest to puncture. CASE because it's a live decision from the role |
| A3 | "An operator makes a bespoke feature the price of a partnership. Product says no. What do you do?" | CASE | [generic] | Separate the need from the feature they asked for. Ask product what the general version would cost. Look for terms where the operator co-funds or commits to being a reference. Know your walk-away point. Say who decides, and that it isn't only you | It's a classic partnerships trade-off and the concession T1 carries. CASE because it scores structure under conflicting stakeholders |
| A4 | "What in our market report would you challenge?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Your one challenge from prep step 1: the finding, why you'd push on it, and what evidence would change your mind. Keep it respectful, because the people in the room may have written it. If nothing in it seems challengeable, say which assumption you'd most want to test, and why | F8 is the only company-specific material in hand, and the panel knows you've had it. CO because it scores whether you can think at the company's altitude rather than repeat it |
| A5 | "At month 18, how would we know operator partnerships are working?" | CASE | [generic] | Three or four measures across three areas: commercial (revenue, retention or expansion with partner operators), relationship (roadmap inputs taken up, references given) and ecosystem (if you chose T2). Name one you'd watch early and one lagging one. Say which baselines you'd need from Kelverton | It bridges Deepa's strategy to Ross's commercials, and a plan without measures is the first thing a panel picks at. CASE because it's a design problem |

### B — Skeptic (either panellist)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota and you've never sold into rail. Why should we put you in front of operators on commercials?" **The highest-ROI rehearsal in this pack.** | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Name the limit first, plainly: "Both true. I haven't carried a direct quota, my numbers were influenced revenue, and I haven't sold into rail." Then what your sentences do carry, at their scope: you ran an ISV channel from 6 partners to 40, roughly £4M influenced, and before that five years of bus and light rail network planning. Then the plan, said as a plan: how you'd learn the operator buying cycle in the first months, and how you'd work against a number here. Never imply that F2 is rail sales or that influenced revenue is closed revenue. **Follow-up 1, "So who carried the number on those deals?"** Answer slot: say who did, in your own words. If you don't know how it was split, say so. **Follow-up 2, "Why not hire someone who's sold into rail?"** Hold on what F1 and F2 carry, then concede specifically: the rail buying cycle is what you'd have to learn, and you'd name who you'd learn it from. **Follow-up 3, "How would you behave against a quota here?"** Plan only. Answer slot: if any of your ISV work had targets you reported against, say what they were, in your own words. If none did, say so plainly and describe how you'd set yourself up | F4 and F5 are gaps you stated yourself, and the recruiter named commercials as Ross's focus, so this arrives in some form. JD because it scores the stated commercial requirement. Rehearsed to three follow-ups because a defensive answer here loses the room |
| B2 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot: your actual reason, in your own words. A strong answer connects to something real, which F2's quote may let you do ("I know the operator world from the other side"). Only make that connection if it's true for you. If the move is about the role rather than the sector, say that instead. Keep it short and forward-looking, and don't criticise your current employer | It's a standard Skeptic motivation probe, and your path has a visible sector change. EXP because it tests whether your story holds together |
| B3 | "Your consulting was bus and light rail. Train operators are a different world. What actually transfers?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Hold at the quote's scope: five years of bus and light rail network planning. Concede the difference without being asked. It wasn't train operating companies, and network planning isn't selling scheduling software. Answer slot: what transfers is whatever you actually did. Say who the clients were and what the work involved, in your own words. If none of it touched timetables or schedules, say so, and stay with how you learned to see things from an operator's side | F2 is your strongest link to the recruiter's close, which makes it the first thing a skeptic tests. EXP because it scores whether the link holds |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one, don't list. Rail selling is the cleaner choice because it's a ramp problem: "I haven't sold into rail." Then the concrete ramp plan. Choose it deliberately rather than leaving B1's quota point exposed twice | It's a Skeptic stem. Answering with a gap you've already named keeps you consistent across the hour. JD because it scores self-assessment against the job |
| B5 | "In payments your partners were software companies. Here, operators are our customers. Isn't that a completely different job?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Concede the real difference: an ISV partner and an operator customer stand on different sides of the relationship, with different incentives. Don't claim they're the same. Then hold on what F1's sentence carries: running a channel that grew from 6 partners to 40. Answer slot: if part of that work translates, such as how partners were chosen or supported, say which part was yours, in your own words. If it doesn't translate, say so and point to your POV's plan | The difference between who your partners were and who they'd be here is real, and a panel that knows rail will see it immediately. JD because it scores fit to this role specifically |

### C — Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the £4M. How was influenced revenue counted?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Keep "roughly" and "influenced". Answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you'd defend least (say this before Ross finds it), and which part was yours. "I don't know exactly how it was counted" is an honest branch. Never describe an attribution method you can't stand behind | F3's figure is the most obvious target for a commercial director. EXP because it's a defend-the-number probe |
| C2 | "Of the forty partners, how many actually produced revenue?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The forty are partners, not revenue-producing partners, so keep the number attached to its noun. Answer slot: if you know how the revenue was spread across the forty, say it plainly. If you don't, say so, and say how you'd track it here | Partner counts invite the denominator question, and F6 is a self-reported line with nothing behind it to inspect. EXP because it's a defend-the-number probe |
| C3 | "What would you put on the monthly dashboard I see?" | CASE | [generic] | Four or five lines Ross would care about: pipeline influenced by partners, revenue from partner operators, retention or expansion, time to close, and one health signal. Say which you'd publish from month one and which need a baseline first | It's Ross's version of A5. CASE because it's a design problem in his own terms |
| C4 | "What commercial model would you propose for an operator partnership? Who pays whom, for what?" | CASE | [generic] | Structure, not figures: what the operator gives (commitment, co-investment, being a reference, data), what Kelverton gives (pricing, roadmap influence, support) and how each side's value is measured. Name the figures you'd need from Kelverton before proposing numbers. Don't invent rates | The recruiter's "push on commercials" lands here, and it's the test of T3, or of block 4 of your POV. CASE because it's a live commercial design question |

### D — Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That £4M. How much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Pause. The figure is influenced revenue, which already says others closed it. Answer slot: which part was yours, in your own words. If you can't separate your share, say so plainly and return to what you ran: the channel, 6 partners to 40. Hold through two follow-ups by returning to that, never by adding to it | It's the Pressure stem aimed at F3, and "influenced" is exactly the word a commercial director pulls on. EXP because it scores attribution honesty |
| D2 | "Sixty seconds. Why you over someone who's sold to operators for a decade?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Don't argue that you're better at rail sales. Concede the point in one line: "I haven't sold into rail." Then what you bring that's different, from F1's sentence, plus the POV you've just given. Finish inside the 60 seconds | A time-boxed version of B1 to test composure. JD because it scores fit against the alternative |
| D3 | "Influenced revenue is a soft number. Convince me it's real." | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Don't defend it as harder than it is. Agree it's softer than closed revenue. Then the answer slots: how it was counted and the assumption you'd defend least, in your own words, or "I don't know exactly how it was counted". Hold on the parts you can stand behind, and concede the softness without folding on the channel | It pairs F3 with F4 and is the most likely way Ross pushes. EXP because it scores precision under pressure |
| D4 | "I think your POV is wrong. Operators won't pay for that." | CASE | [generic] | Restate his objection, then ask which part he means. Hold your thesis for one round with its reason. Then concede the specific risk, using your thesis's mandatory concession, and say what evidence would change your mind. Don't drop the whole plan to restore harmony | It's devil's advocate aimed straight at the deliverable. CASE because it scores holding a reasoned position on a live plan |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Ninety seconds, in order. Five years of transport consulting in bus and light rail network planning. Then partnerships, with the last four years running a payments ISV channel from 6 partners to 40 and roughly £4M influenced. Then why this role, from B2's honest answer. Keep every number exactly as you said it | It's the standard opener and is scored for economy. EXP because the arc gets checked against the CV |
| E2 | "What's caught your eye about rail since you started looking at us?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | One genuine observation, from the report or your own reading, with a sentence on why it interested you. If nothing has stood out yet, say what you're curious about instead | A casual question that's really scoring your homework. CO because it tests market interest |

### F — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you didn't soften it, and a relationship still intact afterwards. Use "we" for the context and "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It's a persona stem, and partnerships roles often involve telling the business what partners won't accept. VAL is flagged as generic because Kelverton's published values weren't fetched |
| F2 | "When did you put a customer or partner ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a real trade-off where the metric cost something visible and you can say why you chose as you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It's a persona stem that matches the recruiter's operator-first close. VAL is generic for the same reason as F1 |

### G — Peer Evaluator (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Partnerships and my sales team both touch operators. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than pretending to know their setup: one owner per operator relationship, clear rules for when partnerships leads versus supports, a shared view of the pipeline, and an escalation route. Offer something back to Ross's team, such as partner-sourced introductions or references | Commercial and partnerships overlap on accounts, and Ross is pricing what you'd add to or take from his team. CASE because it's a seam design problem |
| G2 | "How do you handle credit when a deal spans partnerships and direct sales?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Your quote already says your revenue was influenced, which means credit was shared by definition. Answer slot: if you have a time when credit was disputed, say what happened and what you did, in your own words. If you don't, say so and give the principle you'd work to | Credit-sharing is a peer stem, and F4's "influenced" makes it pointed. EXP because it scores how you've actually behaved |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" — recruiter | POV build, A1, A2, A3, A5, D4 |
| "Please land on what it means for the operators themselves." — recruiter | POV close, A2, B3, B5 |
| "Ross will push on commercials." — recruiter | B1, C1, C2, C3, C4, D1, D2, D3, G1 |
| Selling into the rail operator market, role-family | B1, B4, D2 |
| Building and scaling a partner channel, role-family | C2, E1, B5 |
| Senior stakeholder management, role-family | A3, F1 |
| Command of the company's market and strategy, role-family | A4, E2 |
| JD-specific requirements | none, because no JD was supplied. Each line of a pasted JD would get a row here |

---

## Reverse questions

| # | For | Question | Why it lands |
|---|---|---|---|
| R1 | Deepa | "When you say operator partnerships, what does that mean in your team today?" | It checks your POV's definition directly, and shows you're thinking about her model rather than imposing your own |
| R2 | Deepa | "What would make the first six months a clear success from where you sit?" | It's your future manager's own scorecard, and you can't get it anywhere else |
| R3 | Ross | "How do partnerships and direct sales share credit on operator deals today?" | It shows you've thought about the seam before he raises it, and it's the honest follow-on to F4 |
| R4 | Ross | "Where is the commercial model with operators under the most pressure right now?" | It invites him to teach you, and tells you where the role's real commercial load sits |
| R5 | Both | "Which part of the market report do you two see most differently?" | It's a sharp question that shows you've read it, and it reveals how the panel's priorities differ |
| R6 | Deepa | "What does the integration side of the product make easy or hard for partnerships?" | It closes T2's open assumption, and a product constraint is the thing a partnerships plan most often runs into |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a direct quota, or was accountable for closed revenue | A negative you stated, F4 | "I haven't carried a direct quota. My numbers were influenced revenue." No slot |
| Sold into rail, or has rail sales experience | A negative you stated, F5 | "I haven't sold into rail." No slot |
| Generated, closed or delivered £4M | Inflated form of F3 | F3's quote at its own scope, "roughly £4M of influenced revenue". The limit is the pack's own observation: the material says influenced and roughly, not closed or exact. C1 and D1's slots stay inside the influenced figure |
| Built the ISV channel from scratch | Inflated form of F1 | F1's quote at its own scope: took it from 6 partners to 40. The material says it started at six, not zero |
| Worked with train operating companies, or knows heavy rail operators | Inflated form of F2 | F2's quote at its own scope, five years of bus and light rail network planning, with "from the other side" as you said it. B3's slot stays inside that work |
| Network planning experience counts as scheduling software experience | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's own observation: network planning is not selling scheduling software. B3's slot asks only whether the planning work touched timetables |

---

## Sources

**Provided documents:** your message, including the recruiter's email as you quoted it. The internal market report was not provided to me: you have read it, and the pack leaves slots where its content belongs.

**Searches sent:**

| Query | Result |
|---|---|
| "Kelverton Rail" values | refused |
| "Kelverton Rail" scheduling software train operating companies news | refused |
| "Kelverton Rail" Deepa VP Partnerships | refused |
| Partnerships Manager rail software train operating companies job description UK | refused |

No fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The search was refused. Official value names would have themed bank F instead of leaving it on generic stems. A values cheat sheet would still be absent, because the recruiter's format names no values round |
| 2. Kelverton Rail interview process | skipped | The recruiter's email already fixes the loop: one 60-minute panel with named members, a 15-minute POV and then Q&A. The persona weights follow it |
| 3. Kelverton Rail strategy and recent news | unavailable | The search was refused. It would have grounded A4, E2 and the POV's "where things stand" block in current company facts instead of leaving them as slots for the report |
| 4. Interviewer footprint, Deepa and Ross | unavailable | The search for Deepa was refused, and no search was sent for Ross after that. It would have added career patterns to the interviewer read, persona adjustments, and a reverse question tied to their own paths |
| 5. Representative Senior Partnerships Manager JD | unavailable | The search was refused. It would have turned the role-family rows F5 to F8 into quoted `[inferred]` requirements and populated the JD row of the coverage table |

---

## Upgrade menu

- The JD text → the role-family rows F5 to F8 become quoted, `[grounded]` requirements, every JD line gets a coverage row, and any requirement the banks miss becomes visible
- Web search allowed → targets 1, 3, 4 and 5 run: official values for bank F, current company context for A4, E2 and the POV, and Deepa's and Ross's public career paths for the interviewer read and a tailored reverse question
- Deep research, offered once → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, the panel's talks and writing, and recent org context, which would add a grounding brief section and sharpen the CO and CASE questions
- The market report's key findings, pasted → A4, E2 and the POV's "where things stand" and operator-close blocks get grounded content instead of slots, and a differentiation line checked against what the report actually says
- Your answers to the answer slots in F1, F2 and F3 → those rows, B1, B3, C1, C2, D1 and D3 regenerate with your words in them
- A tuesday-dossier.md from job-underwriter → evidence-derived grading, a strategy for each weak area, and a dossier-level prohibited list. Not needed for this pack
