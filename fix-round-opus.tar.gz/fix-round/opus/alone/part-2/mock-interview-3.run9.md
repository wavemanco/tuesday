Web search was refused here, so I'm building the prep pack only from your one-line message. Every section that needed research or your CV is generic and marked that way.
I've saved your prep pack as `stripe_product-operations-manager_interview_pack.md`. It's built only from your one-line message. You didn't share a job description or CV, and the web searches for Stripe's principles, interview process and strategy were blocked in this session, so nothing in it comes from Stripe's own material. For now, the requirements are the ones typical for Product Operations roles and the answer guidance helps you choose which of your own stories to tell. Because I don't know who you're meeting, every interviewer style gets equal weight.

I can play the Skeptic on B1 ("Which part of this role would you be weakest at on day one?"), the question the pack names as the most valuable to rehearse.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Who are you meeting in the final round? How many sessions are there, and is each person your future manager, a peer, a skip-level or from another team? Did the recruiter mention any focus areas or something to prepare, like a case or presentation? The answer changes which question banks get the most depth.
2. Can you paste the job description and your CV, or a few lines about your background? I'll carry on without them if you'd rather, but with them the guidance can work from your own experience instead of general prompts.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — final-round prep pack

Round: final round. Interviewer(s), their relationship to the role, and the round's session structure: not known. Built from your one-line message only: no JD, no CV, and the web research this pack relies on was refused in this session, so nothing here is drawn from Stripe's own published material.

## How to use this pack

Two axes. **Personas** describe how a question arrives (who is asking, in what register). **Types** describe what is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values the company publishes, not generic virtue |
| EXP | Whether your own claims about your work survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework depth on the company, its strategy and its moves |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Because no CV was given, every answer cell about your past is a **selection scaffold**: it tells you what kind of story to pick and what it needs, and ends with an honest branch for when no such story exists. Pick the story yourself, and tell it in your own words.

Question IDs run by persona: A, B, C, D, E, G, H. The letter F is skipped so that F1–F7 always means a fit-snapshot row.

## Fit snapshot

Worksheet variant: no JD and no background were given, so the requirements below are typical Product Operations requirements written from no source (`[generic]`), and every evidence cell is empty. Use it as a self-assessment: for each row, pick the story you would tell, and note any row where none comes to mind.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating product launches and launch readiness across product, engineering, support and go-to-market teams | none given | none | [generic] | discovery | Strong evidence looks like a named launch, what readiness meant for it, which teams you aligned, and what you personally ran. Selection scaffold: pick a launch or rollout you coordinated, with a date that mattered and more than one team involved; if no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F2 | Building feedback loops that turn customer and internal signals into prioritized product input | none given | none | [generic] | discovery | Strong evidence looks like a signal source, how it was gathered and sorted, and one product decision it changed. Selection scaffold: pick a time feedback you gathered or organized reached a product decision; if no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F3 | Defining and tracking operational metrics, and analysing data to diagnose problems | none given | none | [generic] | discovery | Strong evidence looks like one metric you can define precisely, how it was counted, and a decision it drove. Selection scaffold: pick a metric you reported on or a number you investigated; if no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F4 | Designing and scaling repeatable processes, tooling and documentation | none given | none | [generic] | discovery | Strong evidence looks like a before and after: what was manual or broken, what changed, who used it after. Selection scaffold: pick a process you changed or set up that other people then followed; if no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F5 | Influencing cross-functional partners without formal authority | none given | none | [generic] | discovery | Strong evidence looks like a disagreement with a named stake, how you moved it, and a relationship still intact afterwards. Selection scaffold: pick a time you changed the mind of someone you did not manage; if no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F6 | Running several workstreams at once and prioritizing between them | none given | none | [generic] | discovery | Strong evidence looks like a moment you dropped or delayed something on purpose, and why. Selection scaffold: pick a time you had more work than capacity and chose what waited; if no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F7 | Familiarity with the company's product domain | none given | none | [generic] | discovery | Strong evidence looks like work in or next to the domain, or a concrete plan for learning it. Selection scaffold: pick the closest domain work you have done; if no such work comes to mind, say so plainly, then give a ramp plan, said as a plan and never as a past |

## Persona table

No loop source established how this final round is structured, so the weights below rest on a fallback archetype: **Generic** (screen, then hiring manager, then panel), with **flat weights, said plainly**. They do not rest on Stripe's documented process. If you know who you are meeting, the weights change, and the upgrade menu says how.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live role problems: plan a launch, diagnose a metric, design a process | Flat. A final round often includes the hiring manager, and hiring managers run cases, but no source says so for this loop | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps and of "why here, why now" | Flat. Final rounds test whether the story holds together, and with no CV the pack cannot tell where your gaps are | Rehearse B1 until it is boring. Name the limit before you are asked for it, then give a ramp plan |
| C. Values / Behavioral | STAR stories mapped to values | Flat. Stripe's published principles were not fetched, so these questions use generic values themes | "We" for context, "I" for your own part. Pick stories where the hard truth actually landed |
| D. Data-Driven Prober | Asks for denominators, definitions and assumptions | Flat. F3 is a typical core of the role, so expect metric probes | Know how each number you cite was counted, and say plainly when you don't know |
| E. Pressure | Time-boxes answers, interrupts, asks "how much was you" | Flat. Its likelihood is unknown, and it costs most when it comes unrehearsed | Pause, restate the question, hold through two follow-ups, then concede something specific |
| G. Peer Evaluator | Seams between teams, credit, disagreement with equals | Flat. Product ops sits between teams, so peers are plausible interviewers | Talk about what you bring their team, and propose principles for the seam rather than claiming to know it |
| H. Conversational | Friendly openers that are still scored | Flat. Almost every round opens this way | Have a 90-second arc ready, and treat casual questions as scored |

## Question banks

Weights are flat, so every persona gets three questions. They are listed in the order of the persona table.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're launching a new feature to business customers in six weeks. Sketch the launch-readiness plan — what do you need to know first?" | CASE | [generic] | Clarify first: who the customers are, what "launched" means (availability, enablement, support readiness), and what is fixed (the date or the scope). Then name the workstreams (product, engineering, support, sales enablement, docs, comms), a readiness checklist with owners, go/no-go criteria, and the metrics you would watch in launch week. Close with the one risk you would escalate early. The question asks nothing about your past, so the guidance claims nothing about it | Tests F1 as a decision, not a record. CASE because it is a live plan scored on structure |
| A2 | "Support ticket volume for a key product jumped 20% after a release. Diagnose it." | CASE | [generic] | Rule out counting first: did the ticket taxonomy, routing or customer base change? Segment next, by ticket category, customer segment, region and product surface. Line it up against the release timeline. Form one hypothesis and say what data would kill it. Separate the immediate fix (macros, docs, a hotfix ask) from the systemic one (a feedback channel into the PM's backlog) | Joins F2 and F3. The "metric moved" stem is the Strategist's standard. CASE because it is scored on how you diagnose |
| A3 | "Sales, support and three product managers all send you feature requests. Design the system that turns them into prioritized product input." | CASE | [generic] | Cover intake (one channel, a required template), dedup and tagging, weighting (customer impact, revenue or volume, strategic fit), a review cadence with PMs, and closing the loop with requesters, which is the part most systems skip. Name what you would measure to know the system works. Then challenge one premise, for example whether every request should get a response | Tests F2, F4 and F6 together, which is the core loop of most product ops roles. CASE because it asks for a design |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **The highest-ROI rehearsal in this pack.** Before the interview, go through F1–F7 and pick the row where your honest evidence is thinnest. Answer in three beats: (1) name it in one plain sentence, with no "I'm a perfectionist" dodge; (2) give the nearest thing you have actually done, at its true size, in your own words; if nothing is near it, say so; (3) give a concrete ramp plan for the first 90 days, said as a plan and never as a past. Hold through two follow-ups ("so how would you cope on a launch next month?") by going back to the plan, never by enlarging beat 2. If pressed a third time, concede specifically: "That's the part where I'd need the most support early" | Every final round probes the candidate's weakest fit row in some form, and a rehearsed, non-defensive answer changes how the interview goes. JD because it scores the role's requirements, F1–F7 |
| B2 | "Why leave where you are, why product operations, and why Stripe, why now?" | CO | [generic] | Three parts, about 30 seconds each, and each must be your real reason. Why leave: say what you want more of, not what you are escaping. Why product ops: name the part of the work you like, for example the space between product and the people who use it. Why Stripe: use reasons you can back with something you have read or used yourself; this pack holds no Stripe research, so it supplies none, and a reason the interviewer can probe has to be yours. Why now: what makes this the right step at this point in your path | The Skeptic's stock motivation probe. CO because the "why Stripe" part is a homework test. Rows F7 and B1 feed the "why product ops" part |
| B3 | "How would you get up to speed on our product domain in your first 90 days?" | JD | [generic] | Plan-shaped: weeks 1–3, use the product as a customer, read docs, and shadow support and sales calls; weeks 4–8, own one small, contained process end to end; by day 90, ship one improvement and report what you learned. Name the people you would ask first, by role. If you have done domain-adjacent work, mention only what you can stand behind | F7 is a common Skeptic target in specialist domains. JD because it scores a stated or typical requirement |

### C. Values / Behavioral

Stripe's published principles were not fetched, so these questions use the Values persona's generic themes rather than Stripe's named values. The upgrade menu covers this.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said and how, what happened next, and an intact relationship at the end. Use "we" for context and "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Tests F5 as a value. VAL because it scores behaviour against a values theme |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where what was right for a customer cost a number you were measured on. It needs the metric, the customer impact, the choice, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Joins F2 and F3 through a values lens. VAL because the scoring is on judgment, not results |
| C3 | "The launch date is fixed and you learn support isn't ready. Leadership wants to ship. What do you do?" | VAL | [generic] | VAL content, CASE delivery. Name the risk concretely (customer impact, ticket load), propose options rather than only a no (staged rollout, limited cohort, a date slip with its cost stated), say who decides, and say how you would escalate without going around anyone. The question asks nothing about your past | F1 under values pressure. Tagged VAL first because it scores candor and judgment more than plan structure |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a metric you've reported on regularly. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: pick a metric you can define precisely. Give its definition, numerator and denominator, source system, and what it excludes, in your own words. If you don't know how part of it was counted, say so plainly; that is better than reconstructing it on the spot. If no such metric comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would define one for this role | Tests F3 against your own material. EXP because it tests whether what you cite survives scrutiny |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | The weakest-assumption move: name it yourself, in your own words, before they do. Say why it is weak and what would test it. "I don't know how that part was counted" is an honest answer. The pack supplies no assumption, because it does not know your number | The Prober's standard follow-up to D1. EXP because it scores attribution and self-knowledge |
| D3 | "A launch had 1,000 eligible users, 300 activated in week one, and 120 were still active in week four. What do you conclude, and what would you ask for next?" | CASE | [generic] | Do the arithmetic aloud: 30% activation, and 40% of activated users retained to week four, which is 12% of eligible. Ask for definitions first (what counts as "active"), then a baseline or comparable launch, segmentation (who stayed), and qualitative signal (support tickets, feedback). Don't call it good or bad without a baseline, and say that out loud | F3 delivered live. CASE because the numbers are hypothetical and the scoring is on reasoning |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give two or three reasons, each tied to a row of F1–F7 where you have a real story, plus one thing an outsider brings (fresh eyes on process, say), said as an offer and not as a dig. Stop at 60 seconds. If challenged, hold once ("I'd still say…"), then concede specifically ("An internal candidate will know the tooling faster; I'd close that by…") | Pressure's stock stem. JD because it scores fit to the role |
| E2 | "Pick the result you're proudest of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a result where you can separate your part cleanly. Use "we" for the team's outcome and "I" for the specific things you did. Hold-then-concede: through two follow-ups, keep returning to what was yours. Then concede the shared parts explicitly, without shrinking your own. If no result comes to mind where your part is clear, say so plainly, then give the nearest thing your experience does carry | Attribution honesty under pressure. EXP because it is the inflation probe |
| E3 | "Your launch plan has eight workstreams. I'll fund three. Which three, and why — two minutes." | CASE | [generic] | Name your criterion first (customer risk, irreversibility, dependency), then the three, then what you would do cheaply about the other five (a doc, an owner, a later date). If interrupted, finish the sentence, then answer the interruption | F6 under a time box. CASE because it is a live prioritization, and Pressure because of the clock |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know the seam: who owns the decision and who owns the process, one shared metric, and a written default for handoffs. For disagreement, say how you would surface it early, escalate only together, and write the decision down. Close with what you would bring their team, not only what you need from it | F5 from a peer's side. CASE because the seam is a live design question |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a cross-team piece of work where credit was shared. It needs how you named others' contributions and how your own part stayed visible. If no such time comes to mind, say so plainly, then say how you would handle it | F5 again, scored on partnership. VAL because it is a working-style value |
| G3 | "Support says a new feature is driving confusing tickets; the PM says the data shows it's fine. You're in the middle. What do you do this week?" | CASE | [generic] | Reconcile the data before the people: are they measuring the same thing? Pull a ticket sample and the PM's metric side by side, then get both in a room with the evidence. Come out with an agreed next step and an owner. Show you can disagree with both sides without taking one | Joins F2 and F5. CASE because it is a live situation scored on judgment |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So — walk me through the journey." | EXP | [generic] | A pre-scripted 90-second arc: where you started, two or three turns that led toward product operations, and why this role is the next step. Each turn should be something you would be happy to be probed on. End on why you are here, not on your current job's to-do list | The opener in almost every round. EXP because everything you say becomes probe material for later rounds |
| H2 | "What does product operations mean to you — what's the job, really?" | JD | [generic] | Give your own definition in two sentences, then the part of it you most enjoy and one part you think is often done badly. It is casual in register and still scored, because it reveals whether your idea of the role matches theirs | Tests understanding of the role across F1–F6. JD because it scores fit to the job |
| H3 | "What's a process you'd want to look at in your first month, and how would you find it?" | CASE | [generic] | Don't name a broken Stripe process; you have no basis for one. Describe how you would find it: listen to support and sales, follow one request end to end, count handoffs and waiting time. Then say how you would earn the right to change it, by fixing something small first | F4 asked casually. CASE because it is a live approach, not a record |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | A1, C3, E3 |
| F2 Feedback loops | A2, A3, C2, G3 |
| F3 Metrics and analysis | A2, C2, D1, D2, D3 |
| F4 Process design | A3, H3 |
| F5 Cross-functional influence | C1, G1, G2, G3 |
| F6 Prioritization across workstreams | A3, E3 |
| F7 Domain familiarity | B2, B3 |

## Reverse questions

Role-generic, because no interviewer was named and no Stripe research ran.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make someone in this role clearly successful at six months, and what does a disappointing six months look like?" | It shows you are thinking about outcomes, and it gets you the real scorecard |
| R2 | "Where does product operations sit today relative to product, support and go-to-market, and where would you like it to sit?" | It asks about the seam directly, and the answer tells you what the role is really for |
| R3 | "What's one process the team knows is broken but hasn't had capacity to fix?" | It signals you will look for work, and it previews your first project |
| R4 | "How are priorities set when product and the field disagree?" | It tests how decisions get made, which is your daily environment |
| R5 | "What surprised you most when you joined?" | It turns the interview into a conversation, and the answer is unscripted information |
| R6 | "Is there anything in our conversation that makes you hesitate about me for this role?" | It lets you address the objection while you are still in the room. Ask it only if you are ready to answer calmly |

## Prohibited claims

Nothing is listed here. Your material so far contains no sentence about your past that could be stretched, and no gap you have stated. That is a sign the pack has nothing to check yet, not that nothing could be inflated. When you add a CV, this list will hold the stretched forms of its lines. The guidance above makes no claim about what you have done: every cell about your past is a scaffold you fill with your own story.

## Sources

Provided documents: your message ("I have a final-round interview at Stripe for a Product Operations Manager role").

Searches sent:

| Query | Result |
|---|---|
| Stripe operating principles | refused |
| Stripe interview process product operations final round | refused |
| Stripe Product Operations Manager job description | refused |
| Stripe 2026 annual letter strategy news | refused |

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | The search was refused. It would have supplied Stripe's principles by name, a values cheat sheet, and VAL questions themed on them |
| 2. Stripe interview process, product operations | unavailable | The search was refused. It would have replaced the Generic archetype fallback with Stripe's documented rounds, and reweighted the personas |
| 3. Stripe strategy and recent news | unavailable | The search was refused. It would have grounded at least one CO or CASE question in Stripe's current strategy and given B2's "why Stripe" part real material |
| 4. Interviewer name at Stripe | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | The search was refused. It would have turned F1–F7 from `[generic]` into quoted `[inferred]` requirements |

## Upgrade menu

- The JD text → F1–F7 rebuilt from the posting's own words as `[grounded]` rows, a JD-tagged question for every listed requirement, and coverage of any named tool or method
- Your CV, or a few lines about your background → selection scaffolds become story-mapped answers on your own sentences, B1 targets your actual thinnest row, and the prohibited list starts guarding real lines
- Who you are meeting and their relationship to the role (manager, peer, skip-level, cross-functional) → persona weights set from the relationship instead of flat, with deeper banks for the top personas
- If your final round is several sessions, the schedule → one mini-pack per session, each with its own weights, bank and reverse questions
- The recruiter's prep email, or any stated focus areas or deliverable (a case, a presentation, a take-home) → a build section per deliverable and coverage tuned to the stated focus
- Interviewer names → a public-footprint interviewer read, and a reverse question tied to their path
- Allowing web search in this session → the L1 targets above: Stripe's principles by name with a values cheat sheet, the documented loop, and current-strategy CO and CASE questions. A deeper pass is available on top: up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief and role-specific loop reports
- How much prep time you have → a prioritized prep schedule sized to it
- A `tuesday-dossier.md` from the job-underwriter skill → evidence-verified rows, the objection worth the deepest rehearsal taken from your evidence rather than inferred, and a prohibited-claims guardrail
