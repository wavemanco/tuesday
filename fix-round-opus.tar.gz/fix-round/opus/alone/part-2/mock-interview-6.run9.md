Reading the skill's rules for personas, question writing and research before I build your three-round pack.
I've saved your prep pack for all three rounds: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-6-denied-09d1e055/larkfield-systems_engineering-manager_interview_pack.md`

It's built only from your message: the role summary, the schedule and your four background sentences. The three web searches I tried on Larkfield (its values, its interview process, recent news) were blocked in this session. So the pack says nothing about the company itself, and there's no values cheat sheet for Monday.

The pack has one section on how you fit the role, used by all three rounds. Each round then gets its own question bank (28 questions in total), its own interviewer styles and its own questions for you to ask them. The question to rehearse most is B1 in the Tuesday bank: "You've never owned a hardware-adjacent roadmap, and this role partners with hardware on the roadmap." It comes back in the panel and the VP round (D2, H4), and your answer needs to be the same each time, because interviewers compare notes.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job description? The summary is three clauses, so any requirement past those has no question yet. Can you share your CV? It would turn several "pick a story" prompts into answers built from your actual history.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack — Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop, three scheduled rounds

| Round | When | Length | Who | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | 45 min | Director of Engineering | Hiring manager, your would-be boss |
| 2 | The Thursday after | 60 min | Two staff engineers and a product manager | Panel: senior ICs on or beside your squads, plus your product partner |
| 3 | The following Monday | 30 min | VP Engineering | Skip-level; the recruiter described it as "values and leadership philosophy" |

Built from your message alone: the role summary you pasted, the round schedule, and four sentences about your background. No full JD, no CV, and no research on Larkfield itself (web search was refused in this session). Every gap that leaves is labelled where it bites and listed in the upgrade menu at the end.

---

## How to use this pack

Two axes organise every question:

- **Persona** is how the question will feel: who is asking, in what register. Each round has its own persona table with the weights and the reasoning behind them, so you can recalibrate if you know something I don't.
- **Type** is what is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows the values or leadership philosophy being asked about |
| EXP | Whether your claims survive scrutiny: what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy homework: thinking at Larkfield's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels tell you how far to trust each row: `[grounded]` traces to something you told me or the role text; `[inferred]` is the pack's own derivation, named; `[generic]` is a role-family pattern with no claim about you or Larkfield.

An **answer slot** in the guidance is an instruction for the interview, not a question for me. It names a probe you are likely to get and gives you two honest branches. Either branch is a good answer; the second one is never a confession.

Guidance is scaffolding, not a script. Say it in your own words, and never say more than you actually did.

**Highest-ROI prep in the whole loop: B1**, the hardware-roadmap objection. It will come up in Round 1 and again in Rounds 2 and 3 in different forms (D2, H4).

---

## Fit snapshot (shared across all three rounds)

Your four sentences, used verbatim throughout:

- "9 years engineering, 3 as a team lead of 6, currently at a payments company."
- "I run our hiring loop for backend roles — about 40 interviews last year."
- "I've never managed managers and never owned a hardware-adjacent roadmap."
- "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure."

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role summary you pasted | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads, and the words stay at that scope: "I've spent three years as a team lead, with a team of six." If the squads have leads reporting to you, the stated negative gives you plain words: "I haven't managed managers." Answer slot: the two-squads line makes a probe on leading more than one team likely. If you have had responsibility across more than one team, say how, in your own words; if you haven't, say so plainly and stay with the team of six. Your material also does not say whether being team lead included line management; that is A-row and H3 material, below |
| F2 | "own delivery" for "11 engineers" — role summary you pasted | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your strongest delivery sentence, kept exactly as you said it: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Keep "after"; it is your word, and it does not say "because". The limit is the pack's observation: a team of six, not eleven. Expect the four defend-the-number probes on the 60%: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words, and if you don't know how it was counted, say so |
| F3 | "own … hiring … for 11 engineers" — role summary you pasted | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running the loop is adjacent to owning hiring, and the words stay at the loop: "I run our hiring loop for backend roles — about 40 interviews last year." The 40 counts interviews, not hires. Answer slot: "own hiring" makes a probe on what else in hiring was yours likely. If any part of hiring beyond running the loop was yours, say which and how, in your own words; if none was, say so plainly and stay with the loop |
| F4 | "own … growth for 11 engineers" — role summary you pasted | none given | none | [grounded] | discovery | Strong evidence here looks like a named engineer, where they started, what you did, and what changed. Answer slot: the role's growth line makes a probe on how you have grown the engineers you lead likely. If you have done this, say how, in your own words; if it wasn't part of your remit, say so plainly and say how you would approach it |
| F5 | "partner with hardware … on roadmap" — role summary you pasted | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Your sentence is about owning that roadmap; it says nothing either way about any other work alongside hardware teams, so the pack writes nothing there |
| F6 | "partner with … product on roadmap" — role summary you pasted | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote touches the roadmap without showing a partnership with product: it says there was roadmap pressure and that you pushed the quarter through. Answer slot: if you worked with product to make room for the reliability quarter, say who and how, in your own words; if the pressure came from somewhere else, or there was no such negotiation, say so plainly and stay with what your sentence says |
| F7 | "building device-management services" at an "industrial IoT" company — role summary you pasted | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | transferability | Engineering experience in another domain, and the words stay at that scope: "Nine years in engineering; I'm currently at a payments company." Answer slot: expect a probe on device management or IoT. If any of your work has touched device management, say what and what your part was; if none has, say so plainly and say how you would get up to speed |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Lead two squads | B2, H3, J2 |
| F2 Own delivery for 11 engineers | A1, A3, E1, E2, I2 |
| F3 Own hiring | A4, E3, F2 |
| F4 Own growth | B4, H2, J2 |
| F5 Partner with hardware on roadmap | B1, A2, D2, H4 |
| F6 Partner with product on roadmap | A3, D1, D2, F1 |
| F7 Device-management services, industrial IoT | B3, C2, J1, I1 |

The role summary is three clauses long. Mid-list requirements a full JD usually carries, such as on-call ownership, a named stack or a planning process, are not covered because they are not in hand.

---

## Sources

**Provided documents:** your message: the role summary, the round schedule with each interviewer's role and the recruiter's description of Round 3, and your background.

**Searches sent:**

- `Larkfield Systems values` → refused
- `Larkfield Systems industrial IoT interview process engineering manager` → refused
- `Larkfield Systems industrial IoT device management news 2026` → refused

**Fetches sent:** none.

**Loop:** established by your own words: three sessions, each with who runs it. No archetype fallback was needed. Round 3 is a values-style round because the recruiter's description, as you relayed it, names values and leadership philosophy.

No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Every call was refused. It would have supplied Larkfield's published values by name: the Round 3 values cheat sheet, and VAL questions mapped to each value. Without them the cheat sheet is dropped and the Round 3 VAL questions are themed only by the recruiter's words |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Every call was refused. Your message already establishes the three rounds; this would have checked format details, such as whether the panel includes a system-design or case segment, which would reshape the Round 2 bank |
| 3. `Larkfield Systems` strategy and recent news | unavailable | Every call was refused. It would have grounded C2 and J1, and one CASE question, in Larkfield's current priorities; they are `[generic]` instead |
| 4. Interviewer name at Larkfield | n/a | No names were given, so no query could be formed. No interviewer read; reverse questions are role-specific, not person-specific |
| 5. Representative Engineering Manager JD | skipped | The role summary you pasted fixes the fit snapshot's requirements and the JD-tagged questions |

---

# Round 1 — Tuesday, 45 min, Director of Engineering (hiring manager)

They are buying capability and pricing risk, and they will own your ramp, so expect live problems on their roadmap and a straight look at your gaps.

### Persona weights

| Persona | How it shows up | Likelihood | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | "Here's a situation on my team. What do you do?" | high | Hiring-manager prior; they want to see you run their actual problems: two squads, hardware dependencies, hiring | Clarify, then objective, then approach, then risks; think aloud; challenge one premise per case |
| Skeptic | Quiet probing of F1, F5 and F7 | high | Hiring-manager prior, and the two stated or visible gaps (F5, F1) are exactly what a would-be boss is accountable for if the hire doesn't work | Rehearse B1 until it is boring; plain acknowledgment, then a concrete ramp plan |
| Conversational | The opener and the "tell me about yourself" | low | No signal beyond the usual 45-minute opener, and it is still scored | A 90-second arc built only from your four sentences (C1) |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never owned a hardware-adjacent roadmap, and this role partners with hardware on the roadmap. Why should I believe you'll get there fast enough?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI rehearsal in the pack.** Open with the acknowledgment, flat and unsoftened: "I haven't owned a hardware-adjacent roadmap." No "not directly", no "sort of". Then the plan, said as a plan: what you would learn first (hardware's release rhythm and lead times, which of your squads' services wait on hardware, how the last slip was handled), who you would sit with in the first weeks, and the checkpoint you would want to agree with them. **Follow-up 1**, "What's the closest thing you've done?" Answer slot: if any of your work has involved partnering with hardware teams in any form, say what and what your part was, in your own words; if none has, say so plainly and return to the plan. **Follow-up 2**, "How long until you're useful?" Don't name a timeline you can't back; offer to agree checkpoints with them. **Follow-up 3**, "Isn't that a risk for us?" Concede it: "Yes, it's a real ramp, and I'd rather name it than have you find it." Then stop. Don't reach for a story to cancel the concession | F5 is a gap you stated, against a requirement the role names outright, asked by the person who would carry the risk. It will arrive in some form; a rehearsed, non-defensive answer changes the interview. JD because it scores a stated requirement; delivered in Skeptic register |
| B2 | "You've been a team lead of six. This is eleven engineers across two squads. What changes for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company."; "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold to what your sentence says: "I've spent three years as a team lead, with a team of six." Then what changes, as a plan: you are no longer in every conversation, so what you would set up per squad, what you would keep in one cross-squad view, and where you would rely on senior engineers. If they ask whether squad leads would report to you: "I haven't managed managers", followed by how you would approach it. Answer slot: if you have had responsibility across more than one team, say how, in your own words; if you haven't, say so plainly and stay with the team of six | F1's scope gap; the jump in headcount is the second most visible objection after B1. JD because "lead two squads" is the role's first clause |
| B3 | "Why leave payments for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Your real reason, in one sentence: the pack can't supply it, and a borrowed one sounds borrowed. Then "why here", using only what you know from the role summary and anything you have read or heard yourself: device-management services, partnering with hardware. Don't describe Larkfield's products or strategy beyond what you have actually read. Never run down your current employer | F7's domain shift makes motivation a standard Skeptic probe. JD because it tests fit with the stated role; Skeptic because it checks consistency |
| B4 | "Tell me about an engineer you helped grow." | JD | [generic] | Selection scaffold: pick one engineer whose trajectory changed in part because of something you did. It needs a named starting point, what you did, what changed, and what they would say about it. If no such person comes to mind, say so plainly, then say how you would approach growth for eleven engineers | F4 has no quote behind it, so this is a scaffold. JD because "growth" is an owned responsibility in the role summary |
| A1 | "You start in a month. What do your first 90 days with the two squads look like?" | CASE | [generic] | Clarify first: the squads' current state, open roles, known delivery or on-call pain, the next hardware milestone. Then: listen (1:1s with all eleven, sessions with the hardware and product partners), map (delivery health, on-call load, dependencies on hardware), decide (one or two early changes, and what you will deliberately not change in the first 30 days), and agree what success looks like with the director at day 90. The question needs no claim about your past, so the guidance makes none | The standard hiring-manager case; it checks whether you can take over someone's team without breaking it. CASE because it is a live plan |
| A2 | "Hardware tells you a board revision is slipping six weeks, and two services your squad committed to depend on it. Walk me through what you do." | CASE | [generic] | Clarify: what exactly depends on the revision, and which parts can move independently. Options: decouple (build and test against a simulator or the previous revision), resequence (pull forward work with no hardware dependency), re-commit (tell product early, with the new date and what it costs). Name who decides and when you tell them, and what you would change so the next slip shows up sooner. If you have never done this with hardware, it's fine to say so; B1 already covers that | Puts F5 into a live problem the role summary implies. `[generic]` because no Larkfield-specific process is in hand. CASE because it tests structure under a realistic constraint |
| A3 | "Product wants a new device-onboarding feature this quarter, and your on-call load is climbing. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure: what the on-call load is costing (in whatever measure the team trusts), what the feature is worth and to whom, the options in between (a slice of each, time-boxed reliability work, a partial feature), and who makes the final call. You can name the one time you have, exactly as you said it: "my team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Describe what you did and let them draw the conclusion. Don't call it proof of anything | F2's quote is your best delivery evidence, and F6 is where it meets product. CASE first, since the decision is live; the quote is optional support |
| A4 | "You've got three open roles across the two squads. How do you shape the hiring plan?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Structure: what each squad is missing, which hire unblocks the most, sequencing, and who from hardware or product sits on the loop. Ground it in what you do now: "I run our hiring loop for backend roles." Answer slot: if any part of the loop's design was yours to set, say which and how; if it wasn't, say so plainly and stay with running it | F3's adjacent evidence turned into the director's real problem. CASE because it is a plan, not a record |
| C1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company."; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc using only your sentences: nine years in engineering, three as a team lead of six, currently at a payments company; you run the hiring loop for backend roles, about 40 interviews last year; your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. End on why this role, in one line. Anything earlier in your career is yours to add in your own words; the pack has nothing on it | The opener sets the frame for the whole 45 minutes. EXP because they will pull threads from it |
| C2 | "What do you know about what we do here?" | CO | [generic] | Say only what you have read or heard yourself, and say where you heard it. No research ran for this pack, so it supplies nothing about Larkfield. Then turn it into a question: "From the outside I can see device-management services and a hardware partnership. What does the squads' work look like from the inside?" | A cheap homework check that gets asked casually. CO because it scores preparation; the upgrade menu says what research would add |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What does a great first six months look like for whoever takes this role, and what would make you worry at month three?" | Hands your future boss the success criteria to state, and shows you plan to be measured |
| "How do the two squads' roadmaps depend on hardware today, and where has that dependency hurt most recently?" | Shows you're already working on F5 instead of hoping it goes unmentioned |
| "Are there leads within the squads, or would all eleven report to me directly?" | A real structural fact, and it tells you whether the "managing managers" question applies |
| "How do you and the hardware leadership settle a roadmap conflict today?" | Asks about the seam you would inherit, at the level they work at |
| "What's the hiring plan for the squads over the next year?" | Connects to F3 and tells you whether hiring is a quarter of the job or most of it |
| "Why is this role open?" | Backfill, growth or a reorg each implies a different first 90 days; a straight question is diligence, not cheek |

---

# Round 2 — The Thursday after, 60 min, panel: two staff engineers and a product manager

Three people pricing what you would cost and contribute to their work. Persona blend: Peer Evaluator plus Data-Driven Prober from the staff engineers, Peer Evaluator plus Values/Behavioral from the PM. Interviewer names would let this become a per-person read.

### Persona weights

| Persona | How it shows up | Likelihood | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | "Where's the seam between us, and what happens when we disagree?" | high | All three panellists would work with you daily: the staff engineers on technical direction, the PM on the roadmap | Reciprocity: what you bring their work, not only what you need; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Two levels deeper on the 60% and the 40 | high | Staff engineers are the likeliest to test a headline number to its assumptions | Know what you can and can't say about how each figure was counted, and name your weakest assumption first |
| Values / Behavioral | "Tell me about a time…" from the PM | medium | Cross-functional prior: the interviewer outside engineering often scores behaviour | Stories only where a sentence of yours carries one; scaffolds with an honest branch elsewhere |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | (PM) "When I'm pushing a feature and you're pushing reliability work, how do we settle it?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Seam principles first: a shared view of what on-call is costing, trades made explicitly rather than by attrition, an agreed tie-breaker, and a date to revisit. Say what the PM gets from you: early capacity signals, honest estimates, reliability costs put in product terms. If you use your one example, keep it at its own scope: "I pushed a reliability quarter through against roadmap pressure; on-call dropped 60% after." Answer slot: if product was part of that negotiation, say who and how, in your own words; if it wasn't, say so plainly | F6 asked by the person on the other side of it. JD because "partner with product on roadmap" is stated; Peer because the PM is pricing how you fight |
| D2 | (PM) "Hardware, product and your squads all touch the roadmap. Where's the seam, and what do you need from me?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Reciprocity first: what you would give the PM (hardware-dependency risk flagged early, one view across both squads). Then what you need (priorities ranked, not just listed; early sight of commitments made to customers). Be consistent with B1: "I haven't owned a hardware-adjacent roadmap, so one of the first things I'd do is learn hardware's cadence with you, not after you." | F5 and F6 together, from the partner who would feel both. Consistency with Round 1 matters; panels compare notes |
| D3 | (Staff engineer) "How do you split what I decide technically from what you decide?" | JD | [generic] | Principles: technical direction sits with staff engineers; you own people, delivery and priority trade-offs; where they overlap, decide together and write it down; disagree-and-commit with a named escalation path. If you have an example from your own team, use it in your own words; if you don't, say how you would set it up in the first month | Staff engineers test whether an EM will crowd them or abdicate. JD because leading the squads includes this seam |
| D4 | (Staff engineer) "What would you take off my plate in your first month, and what would you need from me?" | JD | [generic] | Name things an EM can own: hiring logistics, cross-team negotiation with hardware and product, on-call health, keeping meetings off their calendar. Then the ask: their read on the squads' biggest technical risk, and their help learning the hardware dependencies. Don't promise specific changes before you've seen the work | A reciprocity question in a peer's mouth; it scores whether you reduce their load |
| E1 | (Staff engineer) "Your team's on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The four defend-the-number moves, all in your own words: how it was counted (what "on-call burden" measured, over which period); what it is sensitive to; the assumption you would defend least, named before they find it; and which part was yours. If you don't know exactly how it was counted, say so: that is a credible answer, and a reconstructed one is not | F2's headline metric; staff engineers will test it to its denominator. EXP because it checks a claim |
| E2 | (Staff engineer) "Did anything else change in that period besides the reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold your own word: you said the burden dropped *after* the quarter, not *because of* it. Answer slot: if you know of other things that changed in that period, name them and how much weight you'd give them; if you don't know, say so plainly. Don't claim all of the 60% for the quarter | The attribution follow-up to E1. EXP; prober register |
| E3 | (Staff engineer) "About 40 interviews last year: what counts as one, and which of them were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Defend the number: what counted as an interview, roughly how the 40 breaks down, and which part was yours, in your own words. Keep the number on interviews, not hires. Then what running the loop involves day to day, in your words | F3's figure; staff engineers often sit on loops and will know the difference between running one and interviewing in one |
| F1 | (PM) "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story map: the reliability quarter; you pushed it through; it went against roadmap pressure; on-call burden dropped 60% after. Those are the beats your sentence carries; tell them in your own words. Answer slot: the role's product-partnership line makes a probe on who you had to bring along likely. If product or leadership was part of it, say who and what you said; if not, say so plainly and stay with the quarter. "We" for context, "I" for what was yours | Your one quoted story with tension in it, in the PM's register. VAL; story mapped on F2 and F6 |
| F2 | (PM) "Tell me about a hiring decision where you disagreed with others on the loop." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Context you can give: "I run our hiring loop for backend roles." Then a selection scaffold: one candidate, the disagreement, what you argued and why, how it was settled, and what happened after. If no such case comes to mind, say so plainly, then describe how you would want disagreements on a loop to be settled | F3 is adjacent to owning hiring; this tests judgement inside it. VAL because it scores behaviour under disagreement |
| F3 | (PM) "Tell me about a time you worked with a team whose priorities conflicted with yours." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection scaffold: another team, a real conflict of priorities, what you did, how it ended, and what the relationship was like afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I pushed a reliability quarter through against roadmap pressure", or how you would handle it with hardware | F5 and F6 are both cross-team seams; the PM will want to know how you behave at one. VAL; scaffold, because no quote shows another team directly |

### Reverse questions

| Question | Why it lands |
|---|---|
| (to the staff engineers) "What could a new EM do in their first month that would genuinely help your work?" | The reciprocity question: it lets peers tell you the job |
| (to the staff engineers) "Where does technical direction get decided today, and is that working?" | Shows you will respect the D3 seam, and tells you whether it's healthy |
| (to the PM) "When hardware slips, who tells customers, and how early do you hear about it?" | Goes straight at the three-way seam you'd be inside |
| (to the PM) "What did the last quarter's planning look like, and what would you change about it?" | Invites candour about the process you'd join |
| (to all) "What's the on-call experience like on the squads right now?" | Connects to F2 without boasting, and the answer is a real input to your first 90 days |
| (to all) "What do the two squads do differently from each other?" | Signals that you will treat them as two teams, not one |

---

# Round 3 — The following Monday, 30 min, VP Engineering ("values and leadership philosophy")

Short, and at altitude. The recruiter's framing makes values and philosophy the core. The skip-level prior adds composure under pressure and some strategy. Larkfield's published values were not in hand, so there is no values cheat sheet; the upgrade menu says what would add one.

### Persona weights

| Persona | How it shows up | Likelihood | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | "What's your philosophy?" and "Tell me about a time…" | high | The recruiter named the round "values and leadership philosophy" | Two or three principles, each anchored to something you did or labelled as a belief |
| Pressure | Time-boxed, "how much was actually you" | medium | Skip-level prior: composure in 30 minutes | Pause, restate, anchor in what you said; hold through two follow-ups before conceding anything real |
| Case / Strategist | "Where should this go?" at org altitude | low | Skip-level prior, tempered by the round's stated focus and the lack of strategy research | Clarify, state what you don't know from the outside, then reason in hypotheses |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Give me your leadership philosophy in two minutes." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure."; "I run our hiring loop for backend roles — about 40 interviews last year." | Two or three principles, no more. Each either rests on something you did, said as you said it ("I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles"), or is labelled honestly as a belief you would bring ("something I believe but haven't yet had to prove at this scale"). Choose principles you would defend for an hour, not ones that sound good. End with one thing you're still working out | The recruiter's own description of the round, almost word for word. VAL |
| H2 | "What do you do when an engineer on your team is underperforming?" | VAL | [generic] | Selection scaffold: if you've handled this, pick one case with a clear expectation, the conversation, the support, a time frame, and an outcome, either way. Keep it anonymous and fair to the person. If you haven't handled it, or it wasn't part of your remit as team lead, say so plainly and walk through how you would: expectations, support, documentation, and when you would bring in HR | F4's growth line has a hard side, and VPs test it. Your material doesn't say whether your lead role included this, hence the honest branch |
| H3 | "What will you have to unlearn going from team lead to managing eleven engineers?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company."; "I've never managed managers and never owned a hardware-adjacent roadmap." | Self-awareness without self-deprecation. Start from what you said: "I've spent three years as a team lead, with a team of six." Name one or two habits a lead of six can keep that a manager of eleven can't, as your own reflection. Answer slot: the role's growth line makes a probe on line management likely. If your lead role included line management for the six (reviews, growth plans), say which parts; if it didn't, say so plainly and say what you would need to learn | F1's scope gap reframed as reflection, which is how a VP asks it. VAL |
| H4 | "How do you build trust with a hardware organisation you don't understand yet?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Consistent with B1 and D2: "I haven't owned a hardware-adjacent roadmap." Then the approach as a plan: learn their constraints before asking for anything, make your squads' commitments to them visible, and keep the first promises small and kept. No invented past | F5 for the third time, now as a values question. Your answer must match the one you gave the director, because they will compare notes |
| I1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company."; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, then hold on what you actually bring, in your words: three years as a team lead of six, running the hiring loop for backend roles, and the reliability quarter after which on-call dropped 60%. When they push ("they know our devices"), concede it without adding to it: "That's real, and I'd have to learn it." Then hold one more time: what an outside view of hiring and reliability adds. Don't run down a candidate you've never met | Pressure stem in a 30-minute skip-level round, aimed at F7's domain gap. JD because it scores fit; delivered under time pressure |
| I2 | "That 60% on-call drop: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold through two follow-ups, then concede precisely. The part your sentence gives you is pushing the quarter through: "I pushed a reliability quarter through against roadmap pressure." The drop came after, and it was the team's burden. Answer slot: which part of the reliability work itself was yours. If you know, say it in your own words; if the work was the team's and your part was getting the quarter, say exactly that. That is a leadership answer, not a weaker one | F2's figure under pressure; the attribution test the "how much was you" stem exists for |
| J1 | "Eighteen months from now, what should device-management services here look like?" | CO | [generic] | Clarify first and admit the limit: "From the outside I don't know your current priorities, so let me reason in hypotheses." Then a structure: the customers and what they need from device management, reliability and operability, how the squads' work lines up with hardware releases, and what you'd measure. End with what you'd want to learn in your first month to test it | The CO/strategy question a skip-level asks. `[generic]` because no strategy research ran; it becomes grounded if research is allowed |
| J2 | "Two of your engineers want to become managers, and there are no manager roles open. What do you do?" | CASE | [generic] | Structure: find out what each actually wants (people work, scope, title); create real leadership work short of a title (leading a project, mentoring, running part of the hiring loop); be honest about timelines; and advocate upward without promising. You can say you haven't managed managers; it's in your own words already, "I haven't managed managers", and the question is about growth, not that | F4 and F1 in one case at VP altitude. CASE because it is live |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What do you want engineering managers here to be known for in two years?" | Asks the VP's philosophy back, at the altitude of the round |
| "Where do you see the biggest gap between how engineering runs today and how you want it to run?" | Invites candour and shows you think about the org, not just the role |
| "How do you develop first-time managers of larger teams, and what does good look like at a year?" | Honest about F1, and positions your ramp as a shared investment |
| "How does engineering leadership work with hardware leadership at your level?" | F5 at skip-level: shows you know where the seam's real decisions get made |
| "What would make you glad, a year from now, that you hired this person?" | A clean close that hands them the criteria |

---

## Prohibited claims

What this pack will not coach, and why. Every guidance cell above is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated: "I've never managed managers and never owned a hardware-adjacent roadmap." | "I haven't managed managers." |
| Has owned a hardware-adjacent roadmap | Negative you stated, same sentence | "I haven't owned a hardware-adjacent roadmap." Then a plan, said as a plan |
| Has led multiple teams or two squads | Inflated form of F1 | F1's quote at its own scope: three years as a team lead, a team of six. The limit is the pack's observation; B2's and F1's slots stay at one team unless you say otherwise |
| Cut on-call by 60%, or the reliability quarter caused the 60% drop | Inflated form of F2: your sentence says the drop came "after", and that it was the team's burden | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." |
| Hired about 40 engineers, or owns hiring decisions | Inflated form of F3: the 40 counts interviews, and the sentence says you run the loop | "I run our hiring loop for backend roles — about 40 interviews last year." |
| Owned or set the product roadmap | Inflated form of F6: your sentence says you pushed a quarter through against roadmap pressure | F6's quote at its own scope; D1's and F1's slots ask only who else was involved |

---

## Upgrade menu

- **The full job description** → mid-list requirements get JD-tagged questions and coverage rows; F1–F7 are re-read against the full text
- **Your CV** → quotes for the evidence column; B4, F2, F3 and H2 can become story-mapped instead of scaffolds
- **Whether your team-lead role included line management (reviews, growth plans)** → resolves the slots in F1, F4 and H3, and sharpens B2 and H2
- **Any work you've done alongside hardware teams, in any form** → F5, B1, D2 and H4 gain a bridge row; if there is none, they stand as written
- **Who applied the roadmap pressure on the reliability quarter, and whether product was involved** → F6, D1 and F1 become story-mapped
- **Allowing web search (L1 targets 1–3)** → Larkfield's published values give Round 3 a values cheat sheet and VAL questions mapped to named values; current strategy grounds C2, J1 and A2; a process check could reshape Round 2
- **A deeper research pass (L2)**, up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and recent org context for the VP round and the CO and CASE questions
- **The interviewers' names** → an interviewer read per round, per-person persona weights on the panel, and reverse questions tied to each person's path
- **Any recruiter notes on the panel format** (system design, case, presentation) → the Round 2 bank reshaped, and a build section if a deliverable is declared
- **How much prep time you have before each round** → a prioritised schedule per round
- **A dossier from job-underwriter** → an evidence-derived highest-ROI objection and a confirmed prohibited-claims list in place of the locally built one
