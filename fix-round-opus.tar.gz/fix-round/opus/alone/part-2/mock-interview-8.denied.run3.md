Dara, your prep pack is ready: /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-8-denied-01108d36/ashgrove-credit-union_member-experience-lead_interview_pack.md

The recruiter's email describes all three rounds, so the pack has a separate section for each round, plus a shared comparison of the job description against your background. I didn't run any web searches. Your pasted job description, values, recruiter email and strategy brief already covered everything a search would have found.

- **Most important to prepare:** D1, the manager-round question "You haven't worked in a contact centre… why should I back you?" The pack gives you a three-step answer: admit it, stand on what you've actually done, then give your plan. It also has two follow-ups to practise against.
- **Your two real gaps** are the two you named yourself: no contact-centre work, and no presenting above regional level. All three rounds rehearse a plain one-sentence admission of each, followed by a plan, never pretend experience.
- **The 20-minute case** has its own section. It splits the time into steps, with a point where each of the four values fits naturally. It also gives three positions to argue, each with the weakness you should admit, and the mistakes to avoid in front of two branch managers.
- **Some answers only you can fill in:** whether the spreadsheet is in Excel and what it counts, which complaint rules your log followed, and any work with digital teams. Each has an "answer slot" with an honest way to answer whether or not you did it.

Say the word and I'll play your future manager on D1, the question the pack names as its most important prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of loop:** 21 November 2026, three rounds on the same day
**Round 1:** 30 minutes with the recruiter
**Round 2:** 45 minutes with the Head of Member Services, your would-be manager, "mostly behavioural"
**Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case; this is the values round, scored against the four values
**Mode:** loop — one shared fit snapshot, then a mini-pack per round. The rounds come from the recruiter's email, not from a guessed pattern. Interviewer names are not yet assigned, so there is no interviewer read.

---

## How to use this pack

- **Personas** describe how a question is asked — the register, the pressure, the follow-ups. **Types** describe what is being scored. Rehearse both: the same gap question sounds different from a friendly recruiter and from a skeptical manager.
- Question IDs run by persona across the whole loop: A and B are round 1, C to G round 2, H to L round 3. F1 to F9 are fit-snapshot rows.
- **Guidance is scaffolding, not a script.** Every clause about your past rests on one of the four sentences you gave me, quoted in the Provenance column. Where the pack doesn't know something, it gives you an **answer slot**: an instruction with two honest branches for the interview itself. Fill it from memory, in your own words, or say plainly that it wasn't you or didn't happen.
- All suggested wording in this pack is proposed language, pending your approval.

| Tag | Type | What it scores |
|---|---|---|
| VAL | Behavioural / values | Whether your past behaviour shows Ashgrove's four published values, not generic virtue |
| EXP | Experience deep-dive | Whether what you say about your work survives scrutiny, and what was actually yours |
| JD | Role-driven | Whether you can do the listed job, including the parts you haven't done |
| CO | Company and strategy | Whether you know where Ashgrove is going: digital shift, hubs, small-business lending, app-only banks |
| CASE | Live problem | Structure and reasoning on a problem from the role, worked out loud |

---

## Fit snapshot

Proposed language, pending your approval. The bridge column is what you'd say aloud, or the answer slot that stands in for it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD, the branch side of it | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how complaints moved through the log likely. If any step of that was yours to set, say which and how you decided, in your own words; if none was, or there was no such step, say so plainly and stay with the log you handled |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD, the contact-centre side of it | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | No wording closes this gap, and you've said so yourself. Words: "I haven't worked in a contact centre." Then say how you would learn it, framed as a plan and never as past experience. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your material doesn't show whether the spreadsheet you built is the reporting the JD describes, so don't stretch the bridge. Answer slot: the JD's monthly-reporting line makes a probe on what the spreadsheet counts likely. Say what it counts and how each figure is counted, in your own words, and who reports from it; if you don't know how a figure is counted, say so plainly |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and the branch's script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you trained likely. Say how you trained them, in your own words; if you followed up on how they escalated afterwards, say how; if you didn't, say so plainly and stay with how you trained them |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: if you have worked with a digital or online-banking team, or on how members use self-service, say what it was and what your part was, in your own words; if you haven't, say so plainly and say how you would start, framed as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. The quote reaches the requirement as written: six years in retail banking, the last three as a branch supervisor. Keep the three attached to "supervisor". Expect a probe on what the supervisor role covered, and answer it from the quotes in F1, F3 and F4 |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" is your word. Your material doesn't show whether those complaints fell under rules set outside the branch. Answer slot: if the log had to meet rules from outside the branch, say what they were and what they asked of you, in your own words; if it didn't, or you don't know which rules applied, say so plainly and describe the log as you handled it. Never name a rulebook you didn't work to |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | No wording closes this gap, and you've said so yourself. Words: "I haven't presented to anyone above regional level." Then say how you would prepare, framed as a plan. Your sentence doesn't say whether you have presented at regional level, so the pack doesn't either; B2 handles that as an answer slot |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says "spreadsheet", not Excel, and doesn't name any features. Answer slot: if you built it in Excel, say so and what it does, in your own words; if you used another tool, name it plainly. Never name a feature you didn't use |

**Reading the snapshot:** F2 and F8 are the two gaps you stated yourself, and the banks rehearse them most. F1 and F4 are real work at a narrower scope than the JD. F3, F5, F7 and F9 are open questions only you can answer, and each has an answer slot.

---

## Graded deliverable — the 20-minute complaint-escalation case (round 3)

The recruiter announced it, so expect it to be scored. Proposed language, pending your approval.

**What you have to build on**

| Fact | Source | Provenance |
|---|---|---|
| The case runs 20 minutes, is about a complaint escalation, and sits inside a 60-minute panel with two branch managers | Recruiter's email | [grounded] |
| The panel scores against the four values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Recruiter's email; values text you pasted | [grounded] |
| The role owns complaints end to end across branches and the contact centre, reports monthly on volumes and resolution times, and coaches branch supervisors on escalations | JD | [grounded] |
| Eight branches are being consolidated into five hubs over 2027, and Ashgrove wants 40% of member service on digital channels by 2028 | 2026 strategy brief | [grounded] |
| Your side, from F1 and F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your message | [grounded] |

**A 20-minute shape**

| Minutes | Step | What you do | Provenance |
|---|---|---|---|
| 0–3 | Clarify | Ask what the member said, in their words; what has happened so far; what the member wants; and which complaint rules and deadlines Ashgrove works to. Ask about the rules rather than assuming a regulator | [generic] |
| 3–8 | The member today | Say what the member needs before anything else. Name the value once: "Members First — I'm deciding from their side of the counter" | [grounded] |
| 8–11 | Who holds it | Name one owner who keeps hold of the complaint until it is solved, and say that's you as process owner. Name Own the Fix | [grounded] |
| 11–14 | Telling the member | Explain the outcome as you'd say it to the member, in two or three plain sentences. Name Plain Words | [grounded] |
| 14–17 | The branch | Work through the cause with the branch supervisor, not around them. If the branch is moving into a hub, ask how that's landing locally. Name Neighbours, Not Numbers | [grounded] |
| 17–20 | Record, report, coach | Log it. Say how it would show up in the monthly volumes and resolution times. Say what the supervisor takes away for next time | [grounded] |

**Theses, each with its concession**

| Thesis | Concession you say out loud |
|---|---|
| Fix the member's problem before you fix the process | Fixing one case can hide a cause that repeats, so you'd still log it and check for a pattern |
| One named person keeps hold of the escalation until it's closed | That costs time in a busy branch, and handing over cleanly matters as much as holding on |
| Every escalation is data for the monthly report | One case isn't a trend, so you wouldn't redesign the process off a single complaint |

**Standing out from the consensus answer**

| Move | Why | Provenance |
|---|---|---|
| The consensus answer is apologise, investigate, resolve, follow up. Do all four, and also name each value at the moment it applies | The panel is scoring the four values, so make them easy to hear | [grounded] |
| End with what the supervisor learns, not only with what the member gets | Coaching supervisors on escalations is a stated part of the job | [grounded] |
| Anti-picks: don't promise compensation or an outcome before you have the facts; don't blame the branch in front of two branch managers; don't steer an upset member to the app as the fix | Each one costs you a value: Members First, Neighbours, Not Numbers, and Plain Words | [generic] |
| Close: the recruiter didn't name a required close. End on the member's outcome plus the one change that stops it happening again | Ends on the fix, which is the value the panel will hear last | [generic] |

---

## Grounding brief — Ashgrove's own vocabulary

From the July 2026 strategy brief, the JD and the values text. The brief is about four months old, so confirm nothing has moved (reverse question R1.3).

| Item | Say it like this | Source | Provenance |
|---|---|---|---|
| Who they serve | "Members", never "customers". Ashgrove is member-owned, with about 900 staff | JD | [grounded] |
| Digital shift | 40% of member service moving to digital channels by 2028 | Strategy brief | [grounded] |
| Branch network | Eight branches consolidating into five hubs over 2027 | Strategy brief | [grounded] |
| New product | Small-business lending launching in Q1 2027 | Strategy brief | [grounded] |
| Competition | The main pressure is app-only banks | Strategy brief | [grounded] |
| JD vocabulary | "Self-service journeys", "escalations", "complaint volumes and resolution times" | JD | [grounded] |
| Values phrasing | "The member's side of the counter"; "if a member needs it explained twice, we wrote it wrong"; "every branch is part of its town"; "whoever finds the problem keeps hold of it until it is solved" | Values text you pasted | [grounded] |

---

# Round 1 — Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Chatty openers about your journey, motivation and why a credit union | High: this is the usual pattern for a recruiter screen, and 30 minutes leaves little room for depth | A rehearsed 90-second arc built from your four sentences. Treat casual questions about the contact centre and presenting as scored |
| Skeptic, light | Quick knockout checks against the JD: contact centre, senior presenting, regulated complaints | Mid: recruiters usually check obvious gaps lightly, and F2 and F8 are exactly the JD lines a recruiter can check against | Rehearse both plain acknowledgments until they're boring, then move straight on to what you do bring |

### Bank A — Conversational

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with three beats, each one a sentence you gave me: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log, and training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Answer slot: then say why member complaints is the work you want next, in your own words; if your real reason is something else, give that | Recruiters open this way, and the arc sets up every later round. F6, F1, F4 and F3 are the material. EXP because it's your own history told in sequence |
| A2 | "What draws you to a credit union rather than a bank?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start with the fact: six years in retail banking. Answer slot: if member ownership is part of why you're moving, say what it changes for you, in your own words; if it isn't, give your real reason plainly. You can quote one value by name, such as "Members First, Always", but only if it matches your reason | The JD leads with "member-owned", and F6 makes the bank-to-credit-union move obvious. CO because the answer shows whether you know what Ashgrove is |
| A3 | "Why this role, and why now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Keep it to two beats: the three years as branch supervisor, then the move. Answer slot: give your own reason for leaving now, in your own words; if part of it is about your current employer, say it neutrally or leave it out, and never invent a push factor | A standard motivation check, and F6 supplies the timeline. EXP because the answer has to match what you say in rounds 2 and 3 |
| A4 | "The role covers branches and the contact centre. What's your contact-centre exposure?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say it in one sentence: "I haven't worked in a contact centre." Then what you do carry: "I handled the branch's formal complaints log." Then a plan, framed as a plan: how you'd learn the contact-centre side in your first weeks, for example by sitting with agents and following a complaint from call to log. Don't apologise twice | F2 is a stated gap against a headline JD line, so it will come up in all three rounds. Rehearsing the short version here makes the long version in D1 easier. JD because it scores a listed responsibility |
| A5 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the fact: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it in Excel, say so and say what it does, in your own words; if you used another tool, name it plainly. Name only features you actually used | F9 is a listed requirement, and the evidence is one sentence that doesn't name a tool. JD because it scores a stated requirement directly |
| A6 | "Have you handled regulated complaints?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with the fact: "I handled the branch's formal complaints log." Answer slot: if the log had to meet rules set outside the branch, say what they were and what they asked of you, in your own words; if it didn't, or you don't know which rules applied, say so plainly and describe how you handled the log | F7 is a listed requirement, and "formal" doesn't settle it either way. Recruiters often check listed requirements literally. JD because it's a stated requirement |

### Bank B — Skeptic, light

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Six years in retail banking, three as a supervisor. What in that makes you ready for a role across the whole credit union?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Give three facts at their own size: the branch's formal complaints log, training new tellers on the escalation script, and the monthly complaints spreadsheet your regional manager uses. Your material shows one branch's log, so the wider part is a plan: what you'd do first across branches, framed as what you would do. Don't call any of it proof. Let the recruiter make that link | F6 covers the years requirement, and the step from F1 to the JD's end-to-end remit is the obvious challenge. JD because it scores fit against the stated scope |
| B2 | "How do you feel about presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and what about, in your own words; if you haven't, say so plainly. Then a plan, framed as a plan: how you'd prepare your first monthly report for senior readers | F8 is a gap you stated against a listed requirement. JD because "confident presenting to senior leaders" is in the requirements list |
| B3 | "This role will run through the branch consolidation. How do you feel about that?" | CO | [grounded] | Show you know the plan: eight branches into five hubs over 2027. Say what you'd watch in the complaints data while it happens, framed as a plan, for example complaint volumes and resolution times by branch before and after each move. Don't guess at staffing or at which branches are closing | The strategy brief makes this a live context for the role. CO because it tests whether you've read the brief. It makes no claim about your past |

### Reverse questions for the recruiter

| # | Ask | Why it lands |
|---|---|---|
| R1.1 | "For the panel's values scoring, is each of the four values scored separately?" | It shows you read the email closely, and the answer tells you how to spread your stories in round 3 |
| R1.2 | "Is the 20-minute case given on the day, or is there anything to read beforehand?" | It's a process detail that changes how you prepare, and the recruiter is the person who knows |
| R1.3 | "Has anything moved since the July strategy brief?" | It checks the four-month-old document you're building on, and it shows you read it |
| R1.4 | "What's prompted the role now?" | It tells you whether you'd be building something new or taking over from someone |
| R1.5 | "When will I know which branch managers are on the panel?" | Names let you tailor round 3. It's a reasonable logistics ask |

---

# Round 2 — Head of Member Services, 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "Tell me about a time…", STAR-shaped | High: the recruiter's email says this round is "mostly behavioural" | One story per prompt, chosen with the selection scaffolds. Use "we" for context and "I" for your part |
| Skeptic | Quiet probing of F2 and F8, plus "why should I back you" | Mid-high: hiring managers usually look hard at gaps, and this person would be your manager | D1 is the highest-ROI prep in the whole pack. Rehearse it until it's boring |
| Data-Driven Prober | "Walk me through that spreadsheet" | Mid-low: monthly reporting is in the JD, and F3 is your only reporting evidence | Know what each figure counts and how it's counted, and say plainly when you don't know |
| Case / Strategist | A short live problem on reporting or the digital shift | Low: hiring managers often use cases, but the email says this round is mostly behavioural | Clarify, then give a structure, then answer, using Ashgrove's own vocabulary |

### Bank C — Values / Behavioural

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you handled a complaint that needed escalating." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Choosing a story: the sentence gives you the log and the script, but no particular complaint, so pick one. Take a complaint from the branch's formal log that went to escalation. You need what the member raised, what you did, who it went to and how it ended. Use "I" for your part and "we" for the branch's. If no such case comes to mind, say so plainly, then describe how the log handled escalations, or how you would handle one | F1 is the core of your fit, and a behavioural round will ask for a case. EXP because it tests what you actually did |
| C2 | "Tell me about training someone on how to escalate." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Two beats, both from your sentence: new tellers, and the branch's escalation script. It's "our" script, so describe it as the branch's. Answer slot: the JD's coaching line makes a probe on how you trained likely. Say how you trained them, in your own words; if you followed up on how they escalated afterwards, say how; if you didn't, say so plainly and stay with how you trained them | F4 is the bridge to coaching supervisors, and your manager will test its reach. EXP because it's your history, scored for what was yours |
| C3 | "Tell me about a time you had to explain something difficult to a member." | VAL | [grounded] | Choosing a story: the theme is Ashgrove's Plain Words value. Pick a time a member had to understand something unwelcome. You need what had to be said, how you said it, and whether they got it the first time. If no such time comes to mind, say so plainly, then say how you would handle it | Behavioural rounds often borrow the values, and this one is published. VAL because it maps to Plain Words. The question presupposes nothing about your past |
| C4 | "Tell me about a time you found a problem and saw it through to the fix." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Choosing a story: the theme is Own the Fix. Answer slot: if the spreadsheet started as a fix for something, say what it fixed and how you kept hold of it, in your own words; if it didn't start that way, pick another time you spotted a problem and stayed with it. You need the problem, the moment you took it on, and how it was solved. If no such time comes to mind, say so plainly, then say how you would handle it | Own the Fix is published, and its wording ("keeps hold of it until it is solved") makes for an easy question. VAL because it maps to that value. F3 is the only built thing in your material |

### Bank D — Skeptic

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't worked in a contact centre, and this role owns complaints across every branch and the contact centre. Why should I back you for it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "6 years in retail banking, the last 3 as a branch supervisor." | **The highest-ROI rehearsal in this pack.** 1. Concede first, in one sentence: "That's right, I haven't worked in a contact centre." 2. Hold on what your sentences carry, at their own size: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. 3. Give a plan, framed as a plan: your first weeks with the contact centre, sitting with agents and following complaints from first contact to resolution. Follow-up "So you'd be learning on the job": hold. Yes, on the contact-centre side. The log, the training and the spreadsheet are what you bring. Add nothing. Follow-up "What if a contact-centre manager pushes back on you?": concede that you'd rely on their knowledge of the floor. Hold that you'd keep hold of the complaint process itself. Don't fold on the core claim to smooth the moment | F2 is the gap you stated, sitting against the JD's headline line, so your future manager is very likely to raise it in some form. JD because it scores the central responsibility. The question's negative is your own sentence |
| D2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick a real gap. D1 covers the contact centre, so use F8 here: "I haven't presented to anyone above regional level." Then a plan, framed as a plan: how you'd prepare the first monthly report and who you'd ask to review it. Don't offer a fake weakness or a strength in disguise | F8 is the other gap you stated. Managers ask this to test honest self-assessment. JD because it's scored against the listed requirements |
| D3 | "You've been a branch supervisor yourself. How would you coach other branch supervisors on escalations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from what you did: "I trained new tellers on our escalation script." Your material shows tellers, not supervisors, so the rest is a plan, framed as a plan: start from each branch's own escalations, agree with supervisors what a good escalation looks like, and review hard cases together. Don't present the plan as something you've done | F4 is a narrower version of this JD line. Your manager will test how far it reaches. JD because it's a listed responsibility. The premise is your role, not a coaching history |

### Bank E — Data-Driven Prober

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built. What does it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, all from your sentence: you built it, it's monthly, and your regional manager uses it. Answer slot: the JD's monthly-reporting line makes a probe on what it counts likely. Say what each column or figure counts and how it's counted, in your own words; if you don't know how a figure is counted, say so plainly. Name, in your own words, the figure you'd defend least before they ask | F3 is your only evidence for monthly reporting and Excel (F9), so expect it to be probed. EXP because it's a defend-your-artefact question |
| E2 | "What does your regional manager actually do with it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with what you know: the regional manager uses it. Answer slot: if you know of a decision it informed, say what it was, in your own words; if you don't know, say so plainly and describe what it holds. Don't guess at how it's used above you | The next step a prober takes from F3, and the place an invented impact would be easiest to slip in. EXP because it tests attribution |

### Bank G — Case / Strategist

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Resolution times at one branch have doubled over two months. Where do you start?" | CASE | [generic] | Clarify first: how "resolved" is counted, and whether the number of complaints changed too. Then break it down: by complaint type, by channel, by who's handling them. Talk to the branch supervisor before you conclude anything. Check whether anything changed locally, for example a hub move. Then the fix, and how you'd report it next month | Reporting resolution times is in the JD, so this is the likeliest live problem. CASE because it's worked out loud. `[generic]` because it's a standard diagnostic pattern |
| G2 | "We want 40% of member service through digital channels by 2028. What does that mean for complaints?" | CO | [grounded] | Treat complaints as a signal of where self-service journeys fail members. Make the digital route for complaining as plain as the branch route. Work with digital teams on the journeys that generate complaints. Measure volumes and resolution times by channel. Concede that some members will still want a person, and say that this is where Members First and Neighbours, Not Numbers apply | It uses the brief's own target and the JD's digital-teams line (F5). CO because it tests the strategy at the role's level. It makes no claim about your past |

### Reverse questions for the Head of Member Services

| # | Ask | Why it lands |
|---|---|---|
| R2.1 | "What would good look like at six months for whoever takes this on?" | It gives you their scoring sheet in their own words |
| R2.2 | "Where do complaints get stuck today between branches and the contact centre?" | It goes straight at F2 and shows you're thinking about the seam you haven't worked |
| R2.3 | "Who reads the monthly complaints report, and what do they do with it?" | It tells you who the senior audience is, which is your F8 gap, and how the report is used |
| R2.4 | "How do you expect the move to five hubs to change the complaints process?" | It uses the strategy brief and asks for their view rather than offering yours |
| R2.5 | "How does Member Services work with the digital team on self-service journeys today?" | It covers F5 and tells you how much of that partnership already exists |

---

# Round 3 — Panel of two branch managers, 60 minutes (values round + case)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One prompt per value, scored | High: the recruiter's email says the panel scores against the four values | One story per value, chosen from the cheat sheet below. Say the value's name once in the answer |
| Case / Strategist | The 20-minute escalation case, plus follow-ups | High: the recruiter's email names the case | Use the graded-deliverable shape above. Clarify first |
| Peer Evaluator | "What would you need from us?", or disagreement over an escalation | Mid: these managers run branches whose supervisors the JD says you'll coach, so they're pricing what you'll cost or bring them | Show what you'd give them as well as what you'd need. Propose principles for disagreement rather than pretending to know their branches |
| Pressure | Time-boxed "why you" and "how much was you" | Low: there's no signal for it, but it's included so the style isn't new to you on the day | Pause, restate the question, anchor in your own sentences, and hold through two follow-ups before conceding anything real |

### Values cheat sheet

Proposed language, pending your approval. None of your four sentences describes a particular moment that shows a value, so each row is a guide to choosing a story, with an honest fallback.

| Value (official name) | Working meaning | Your story |
|---|---|---|
| Members First, Always | Decide from where the member stands, not from what's convenient for the branch | Draw on F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", if a complaint in that log fits. Pick one where seeing the member's view changed what you did. You need the choice, what it cost the branch, and how it ended. If none comes to mind, say so plainly and say how you would decide |
| Plain Words | If someone needs it explained twice, the explanation was wrong | Possibly F4, "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if you changed how you explained the script to new tellers, say what you changed and why; if you taught it as written, say so and pick another time you made something clear for a member. If no such time comes to mind, say so plainly |
| Neighbours, Not Numbers | Each branch belongs to its town, so local context matters | F6, "6 years in retail banking, the last 3 as a branch supervisor.", gives you the setting only. Pick a time something about your branch's community shaped how you handled a member or a complaint. If none comes to mind, say so plainly and say how you'd keep a hub feeling local |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | Possibly F3, "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it started as a fix, say what it fixed; if not, pick another problem you spotted and stayed with. If none comes to mind, say so plainly. If you use the same story as C4 in round 2, tell it the same way |

### Bank H — Values

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a decision you made from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use the Members First row of the cheat sheet. You need the decision, what it cost the branch, and the member's outcome. Use "I" for your decision. If no such time comes to mind, say so plainly, then say how you would decide | The panel scores Members First, and the question borrows its wording. VAL because it maps to a published value |
| H2 | "Tell me about a time you made something simpler so it only had to be explained once." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use the Plain Words row. Answer slot: if you reworded how you taught the escalation script, say what changed, in your own words; if you didn't, pick another time. If none comes to mind, say so plainly, then say how you would handle it | Plain Words is scored. F4 is the nearest material. VAL because it maps to a published value |
| H3 | "Tell me about a time your branch's local community shaped how you handled something." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Use the Neighbours, Not Numbers row. You need the local detail, what you did differently because of it, and the result. If no such time comes to mind, say so plainly, then say how you'd keep hubs local through 2027 | Neighbours, Not Numbers is scored, and two branch managers will care about it through the hub consolidation. VAL because it maps to a published value |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Use the Own the Fix row. You need the moment you noticed the problem, the point where you could have handed it off, and how it ended. If no such time comes to mind, say so plainly, then say how you would handle it | Own the Fix is scored, and it's the value the job description most resembles. VAL because it maps to a published value |

### Bank J — Case / Strategist

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member's complaint has been escalated to you after the branch couldn't resolve it. Talk us through what you do." | CASE | [grounded] | Use the 20-minute shape in the graded-deliverable section: clarify, the member today, who holds it, telling the member, the branch, then record, report and coach. Say each value's name once where it applies. Give the three theses with their concessions | The recruiter announced this case. `[grounded]` because the format comes from the email. It presupposes nothing about your past |
| J2 | "One of our branches moves into a hub next year, and complaints from that town are rising. What do you do?" | CASE | [grounded] | Clarify: are the complaints about the move itself, or about service? Then separate the two. Work with that branch manager, not around them. Explain the change to members plainly. Watch volumes and resolution times for that town each month. Concede that some complaints about a closure can't be fixed, only handled well | The hub plan is in the strategy brief, and these managers live with it. CASE because it's worked out loud. The premise is hypothetical, not a claim about Ashgrove's data |
| J3 | "A supervisor keeps escalating complaints their own team could resolve. How do you coach them?" | CASE | [grounded] | Clarify first: is it confidence, unclear rules, or fear of getting it wrong? Look at their last few escalations together. Agree on what they can resolve themselves. Follow up after a month and check the escalation numbers. Let them keep ownership of the fix | Coaching branch supervisors on escalations is a JD line, and the panel's own supervisors are the people you'd be coaching. CASE because it's a live problem |

### Bank K — Peer Evaluator

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You'd be coaching our supervisors. What would you need from us, and what would you bring us?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with what you'd bring, framed as a plan: a clear escalation path, a monthly view of each branch's complaint volumes and resolution times, and time with their supervisors. You can mention the monthly complaints spreadsheet you built as something you've done before, at its own size. Then what you'd need: their supervisors' time, and their honest view of what goes wrong | It's the reciprocity test that branch managers usually run on a role that touches their teams. JD because coaching supervisors is a listed responsibility |
| K2 | "If one of us disagrees with how you want our branch to handle an escalation, what happens?" | CASE | [generic] | Offer principles rather than a past story: agree the facts first, keep the member's outcome as the test, keep hold of the complaint while you disagree, and agree up front who decides when you can't agree. Show both backbone and tact | Peers test how you handle disagreement with equals. CASE because it's hypothetical. `[generic]` because it's a pattern, not a claim about Ashgrove |

### Bank L — Pressure

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you over someone from our own contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Pause. Concede in one line: "I haven't worked in a contact centre." Hold on three facts: three years as a branch supervisor, the branch's formal complaints log and the teller training, and the monthly complaints spreadsheet. Don't run down the internal candidate. If they push twice, concede specifically that they'd know the contact centre better, and hold that you'd bring the branch side | F2 is the obvious angle for a pressure question. JD because it scores the role's scope. Hold, then concede, as the rubric requires |
| L2 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold on your sentence: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if others supplied data or shaped it, say who did what, in your own words; if it was all yours, say so plainly. Keep to that answer through two follow-ups | F3 is your one piece of built work, so it's the natural target for an attribution check. EXP because it tests what was yours |

### Reverse questions for the panel

| # | Ask | Why it lands |
|---|---|---|
| R3.1 | "What could someone in this role do in the first month that would genuinely help your branches?" | It's the reciprocity question for peers, and it makes the panel picture you helping them |
| R3.2 | "When a complaint escalates from your branch today, what happens next, and what would you change?" | It gets their view of the process you'd own |
| R3.3 | "Which of the four values is hardest to live by on a busy day in a branch?" | It shows you take the values seriously enough to ask where they're under strain |
| R3.4 | "How is the hub plan landing with your teams?" | It shows Neighbours, Not Numbers in action, and tells you what you'd walk into |
| R3.5 | "What does a supervisor in your branch need most when an escalation gets difficult?" | It goes to the coaching line in the JD and gives you material for your first 90 days |

---

## Requirement coverage

| JD line | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A4, B1, D1, J1, L1 |
| Report monthly on complaint volumes and resolution times | E1, E2, G1 |
| Coach branch supervisors on escalations | C2, D3, J3, K1 |
| Work with digital teams on self-service journeys | G2 (CO-tagged, because the question comes in through the 2028 target), R2.5 |
| 4+ years in financial-services customer operations | A1, B1 |
| Experience handling regulated complaints | A6 |
| Confident presenting to senior leaders | B2, D2 |
| Comfortable with Excel reporting | A5, E1 |

---

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before any bank was written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own size. The limit is the pack's observation, not words for you: the material says the branch's log, not a process across branches. B1 and D1 stay inside the log |
| Has contact-centre experience | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F8 | "I haven't presented to anyone above regional level." B2's slot asks only about regional level |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own size: you trained new tellers on the escalation script. The slots ask only how you trained them |
| Wrote or designed the escalation script | Inflated form of F4 ("our escalation script") | F4's quote at its own size. You trained new tellers on it |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own size. The slots ask only what the spreadsheet counts and who reports from it |
| Built reporting used beyond your regional manager | Inflated form of F3 | F3's quote at its own size: "our regional manager uses" |
| Six years as a branch supervisor | Inflated form of F6 | "6 years in retail banking, the last 3 as a branch supervisor." |

---

## Sources

**Provided documents**
- The JD for Member Experience Lead, pasted by you
- The values text, pasted by you, which you say you copied on 12 November 2026 from ashgrovecu.org/about/values. Not fetched
- The recruiter's email describing the three rounds on 21 November, pasted by you
- The 2026 strategy brief Ashgrove published in July 2026, as you summarised it
- Your background, from your message

**Searches and fetches:** none sent. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted fixes the values cheat sheet and bank H: all four values by name |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email sets out all three rounds, so it fixes the loop structure and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief, about four months old, fixes the grounding brief, B3, G2 and J2 |
| 4. Interviewer name at Ashgrove | n/a | No names have been assigned yet, so there was nothing to search. The interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once the recruiter assigns them** → an interviewer read, persona weights for each person from their public professional footprint, and a reverse question tied to each person's career path
- **Your answers to the answer slots in F3, F5, F7 and F9** (what the spreadsheet counts, any digital-team work, the rules the log followed, the tool you used) → those rows can be rebuilt from your words, A5, A6, E1 and G2 get stronger, and confidence can rise
- **One real complaint you'd be happy to tell, for each value** → the values cheat sheet and bank H move from story-choosing guides to stories mapped to your words
- **A version of the monthly complaints spreadsheet with no member data in it**, such as the column headers and the layout → it's the artefact that would raise F3 and F9 from low confidence, and you could walk the panel through it
- **A fuller CV or role history** → more of your own sentences to draw on, especially for C1, C3, H1 and H3
- **How many hours you have before 21 November** → a prep triage: a prioritised schedule tied to question IDs
- **The complaint rules Ashgrove works to** (one email to the recruiter) → a sharper clarify step in the 20-minute case and in A6
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes): role-family loop reports and recent org context, such as leadership or reorganisation news since July → round-specific question wording and fresher CO questions
- **A tuesday-dossier.md from job-underwriter** → evidence you've confirmed, a binding strategy for each weak area, and an evidence-derived lead objection in place of the inferred D1. It isn't needed for this pack
