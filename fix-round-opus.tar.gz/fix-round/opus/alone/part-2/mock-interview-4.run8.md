Still reading the skill's rule files before I write your pack — two left, then I'll build it.
Your prep pack for the 45-minute hiring-manager conversation is ready, built from the dossier: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-4-denied-a151b5c5/Quartzline_product-manager-platform-apis_interview_pack.md`

- **What's in it:** 21 questions across seven interviewer styles. The two styles a hiring manager tends to use most get the most questions: the skeptic probing your gaps, and the strategist setting live problems from the job.
- **Highest-value prep: A1.** That's the objection your dossier predicted ("You have never held the PM title or owned a roadmap…"). Concede it in exact words, give your three verified lines at their real size, then a plan for your first months. It also covers the two follow-up questions most likely to come next.
- **Claims it won't help you make:** the dossier's three prohibited claims, plus three stretched versions of your own lines, such as "shipped an API product." Each comes with the honest wording to use instead.
- **No web research ran.** All three searches were refused in this session. So the pack has nothing on Quartzline's values, strategy or interview process. The "why Quartzline" question tells you not to state company facts from memory.
- **Timing:** today is Thursday 12 November. If the interview is today rather than next week, practise A1 and C1 (defending the "30+ integrations" number) and stop there.
- **One caution on C2:** the integration playbook may be your employer's confidential material. Check what you're allowed to share before offering to show it.

If you want to practise out loud, I can play the skeptic on A1 and push back on whatever you say.
I can also add a `pack_feedback` section to your `tuesday-dossier.md`, recording the objections and weak spots this prep turned up.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview Prep Pack — Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager (your words). Interviewer name not given.
**Built from:** your job-underwriter dossier (v1.1, 14 Aug 2026). No web research ran: all three searches were refused in this session. See Sources.

---

## How to use this pack

- **Personas** describe *how* a question arrives (who's asking, in what style). **Types** describe *what* is being scored.
- Type key:
  - **JD**: can you do the listed job, gaps included
  - **EXP**: do your stated claims hold up under scrutiny; what was actually you
  - **CASE**: structure and reasoning on a live problem from the role
  - **CO**: company and strategy homework
  - **VAL**: whether your past behaviour shows the company's published values
- **Provenance**: `[grounded]` = traceable to your dossier or the role profile; `[inferred]` = this pack's derivation, with the derivation named; `[generic]` = a role-family pattern with no claim about you or Quartzline.
- **The guidance is scaffolding, not a script.** Every sentence about your past is one of the dossier's verified lines, quoted. Where your material doesn't say something, the guidance gives you an **answer slot**: two honest branches, and you fill in whichever one is true.
- **Highest-ROI prep in this pack: A1.** Your underwriter named that objection. Rehearse it until it bores you.

---

## Fit snapshot

The requirements are the dossier's `role_profile` lines, quoted. The evidence is the dossier's `verified_candidate_evidence`, quoted exactly (the underwriter's confidence notes go in the Confidence column and the bridge, not in the quote).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | transferability | The underwriter's binding strategy is **bridge**, and its condition is that the bridge is "positioned as adjacent (never as PM experience)". Your material shows integration leadership and roadmap-input sessions, not a product management role, and the words stay there. The plain acknowledgment comes from `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title." Then the two quotes, each at its own scope. The roadmap-input line is medium confidence (confirmed, limited inspectable proof), so mention that limit before a prober finds it |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as `acknowledge_gap` ("Owning a roadmap and prioritization authority", confidence none). No bridge, no slot. Your words come from `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, stated as a plan and never as something you've done |
| F3 | "Shipped API or platform products" — dossier R2 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | The quote is about integrating clients onto the vendor's APIs, not about shipping an API product, and the bridge stays at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Answer slot: R2 makes a probe on what shipped likely. If an integration you led changed the API itself, say what changed and which part was yours, in your own words; if none did, or that wasn't yours, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier R3 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | high | [inferred] | discovery | Both quotes are inspectable and close to this requirement, but neither says docs or schemas. Answer slot: R3 makes a probe on API docs and schemas likely. If you read, wrote or checked API docs or schemas during those integrations or in the playbook, say which and how, in your own words; if that wasn't part of the work, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4, customer side (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | presentation | The quote already covers clients, in integration terms rather than stakeholder terms. Keep its words when you say it: you led the integrations end to end, from scoping to go-live, with the client. Don't swap in "managed customer stakeholders"; let the interviewer make that connection |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier R4, engineering and sales side (important) | none given | none | [grounded] | discovery | Your material doesn't show engineering or sales stakeholders. Answer slot: R4 makes a probe on working across engineering and sales likely. If you worked with either during the integrations, say who and what you did together, in your own words; if you didn't, say so plainly and stay with the client side (F5) |
| F7 | "Agile delivery experience" — dossier R5 (preferred) | none given | low | [inferred] | discovery | The dossier's strategy is **clarify**: no verified line speaks to agile delivery. Answer slot: the interviewer may ask about agile delivery. If you've worked that way, say how, in your own words; if you haven't, say so plainly. Either way, close with what you'd want to confirm: "How do your squads define agile? I'd want to understand the cadence before I assume" |
| F8 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Bringing client evidence to product, and scoping integrations with clients, are adjacent to partner discovery but not the same thing. Keep both quotes at their own scope. The sessions line is confirmed with limited inspectable proof, so say up front that you don't have much documentation to show for it. Answer slot: if any client evidence from those sessions changed what product built, say what and how you know; if you don't know of a case, say so plainly |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Your material doesn't show any work with metrics. Answer slot: if you tracked anything about the integrations (go-lives, usage, anything else), say what you counted and how, in your own words; if you didn't, say so plainly and answer B2 as a plan |
| F10 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | "Requirements" is one of the stages the quote lists. It isn't specs written for an engineering squad, and it never implies setting a squad's priorities (prohibited). Answer slot: if you wrote the requirements for those integrations yourself, say what went into them and who used them, in your own words; if someone else wrote them, or there was no written document, say so plainly and stay with leading the integrations |

---

## Persona table

The weights start from the hiring-manager prior (Case/Strategist and Skeptic dominant: they're buying capability and checking the gaps). No interviewer profile was available to adjust them. Your own description fixes the loop: one 45-minute conversation with the hiring manager. So the weights don't rest on a guessed archetype. No values round is named, so values questions stay light.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent questions about the missing PM title and roadmap ownership | **Highest.** The underwriter named the objection (A1), and the hiring-manager prior puts Skeptic on top | Concede the title gap in its exact words, then give the quotes at their own scope, then a ramp plan. Don't bluff a capability the hiring manager owns personally |
| B. Case/Strategist | Live problems from the role: partner adoption, prioritization, specs | **High.** Hiring-manager prior, and the JD's responsibilities are all things you'd be doing from the first week | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and question one premise per case. It's a plan, not a past |
| C. Data-Driven Prober | "30+": how was that counted? What's in the playbook? | **Medium.** Your strongest evidence is numeric and inspectable, so it attracts probes | Know what you can and can't say about the 30+. Name your weakest assumption first. Say "I don't know" where that's true |
| D. Conversational | Friendly opener, "why us," a casual question on agile | **Medium.** Most 45-minute hiring-manager conversations open this way, and casual questions are still scored | A 90-second arc built from the three quotes. Treat casual questions on JD topics as scored |
| E. Pressure | Time-boxed "why you," "how much was actually you" | **Low.** Not this round's dominant style, but the title gap is where pressure would land | Pause, restate the question, hold through two follow-ups, then concede specifically |
| F. Values/Behavioral | "Tell me about a time…" | **Low.** No values round is named and no published values could be fetched | Pick a story your material actually carries. If you don't have one, say so |
| G. Peer Evaluator | How you'd work with the two squad leads | **Low.** The interviewer is the manager, not a peer, but decision authority versus the squad leads is the role's open question | Offer principles for the PM/squad-lead split instead of pretending to know it. Ask about it (reverse question RQ1) |

---

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"` | **Highest-ROI rehearsal in this pack. The underwriter named this objection.** (1) Concede first, plainly, with no "but" in the same breath: "That's right. I haven't held a product manager title, and I haven't owned a product roadmap." (2) What you have done, at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live. I wrote the internal integration playbook my team uses. And I ran quarterly roadmap-input sessions feeding client evidence to product." Then stop. Don't add a sentence that makes the sessions sound like decisions. (3) Volunteer the limit on the sessions: you can describe them, but there's not much documentation to show. (4) Ramp plan, as a plan: what you'd learn first (which roadmap decisions sit with this role and which with the squad leads, who the integration partners are, how adoption is measured today) and how. **Follow-up 1:** "So you've never made the call?" Hold by repeating step 1's words; add nothing. **Follow-up 2:** "Why not just hire the experienced PM?" Don't argue against the other candidate. Restate what you bring and the ramp. Let the interviewer judge the trade | F1 and F2 are the role's two biggest gaps, and the underwriter got to this objection from evidence you confirmed. JD because it scores R1 directly. It goes deepest because it's where you'll feel the most pull to stretch |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `prohibited_claims: "Having set prioritization for an engineering squad"` | Name a real gap, not a disguised strength: "Setting priorities for engineering squads. I haven't set prioritization for an engineering squad." Then the plan: how you'd learn the squads' current process and the decision boundaries before proposing changes. If they push on agile, use D3's clarify branch | F2 is the honest answer here, and a rehearsed one sounds like self-knowledge instead of a confession. JD because it asks you to grade yourself against the posting |
| A3 | "I don't see shipping an API or platform product in your background — how would you handle that part of this role?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Accept the observation without arguing. Then the quote at its own scope: "What I've done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Answer slot: if an integration you led changed the API itself, say what and which part was yours; if none did, say so plainly. Close with how you'd learn the product side: specs, release, adoption | F3 is a must-have with only adjacent evidence. JD because R2 is a must-have |
| A4 | "Why move from integration work into product management, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Give your real reason in your own words. The pack can't supply your motive. If the roadmap-input sessions are part of it, you can name them, in the quote's words. Then tie it to this role's actual line: "Own the roadmap for the partner-facing API platform". Keep it under 60 seconds and keep the reason consistent with A1 | The Skeptic's "why leave, why here, why now" stem, sharpened by F1. JD because it tests whether the move fits the posting |
| A5 | "Six months in, how would we know this hire was the right call?" | JD | [grounded] | Answer as a plan built on the role profile's own lines: partner discovery running, specs the squads can build from, adoption metrics defined and tracked against a baseline, and the roadmap owned. Say plainly that you'd want to agree the baseline first. The dossier notes none is stated | It turns the F1 doubt into success criteria the interviewer can hold you to. Grounded on the role profile. It makes no claim about your past |

### B. Case/Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A key integration partner tells us our API is hard to adopt. Where do you start?" | CASE | [generic] | Clarify first: which partner, how far into integrating, and what "hard" means (docs, auth, errors, time to first call). Objective: get them live, and learn whether the problem is this partner's or the platform's. Segment by partner type and integration stage. Approach: talk to the partner, look at where they stall, compare with partners who succeeded. Metrics: time to first successful call, how far integrations get. Risks: fixing one loud partner's problem at everyone else's expense | A live problem built on "Run discovery with integration partners" and "Define and track adoption metrics". CASE because it scores structure. `[generic]` because it's a pattern for the problem, not a fact about Quartzline |
| B2 | "How would you define and track adoption for the partner API platform?" | CASE | [generic] | Start by asking how it's measured today. The dossier lists this as an unknown, so don't assume a baseline. Then a simple funnel: partners signed, first successful call, in production, active over time, depth of use. Pick one headline metric and say why. Name the weakest assumption in your own proposal before they do (for example, that API call volume means value) | F9's gap rehearsed as a plan instead of a claim. CASE delivery on a JD responsibility |
| B3 | "There are more partner requests than two squads can build. How do you decide what goes on the roadmap?" | CASE | [generic] | Clarify decision rights first: which calls are yours and which belong to the squad leads. The dossier says that split isn't established. Then the criteria you'd use (partner impact, adoption effect, effort, strategic fit), how you'd make the trade-offs visible, and how you'd tell partners no. This is how you *would* do it. Don't describe it as something you've done | It tests F2's gap live. A plan is the honest form of an answer here, and it never implies prioritization you haven't done |
| B4 | "Walk me through how you'd write a spec for a new partner-facing endpoint." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure: the problem and the partner evidence behind it, the users, the request and response shape, errors, auth, versioning, docs, acceptance criteria, rollout, and how you'll measure adoption. Mention that requirements and UAT were stages of the integrations you led, in the quote's words. Answer slot: if you wrote the requirements for those integrations yourself, say what went into them; if not, say so plainly and go straight to the plan | Covers R3 and "Write specs…" (F4, F10). CASE because it scores how you structure the spec |

### C. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30-plus integrations — walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slots, each in your own words: how you counted (what counted as one integration); what the number is sensitive to; the assumption behind it you'd defend least, named before they find it; and which part was yours ("led" is the verb your material uses, so keep that one). "I'd need to check the exact count" is an honest answer. A rounded figure you can't back up is not | Your one headline number, so the coverage rule requires a defend-the-number question. EXP because it tests attribution on F3 and F10 |
| C2 | "Tell me about the integration playbook you wrote. What's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats are the quote's: you wrote it; your team uses it. Describe what's in it in your own words. It's inspectable, so you could offer to show it, but first check whether it's your employer's confidential material and what you're allowed to share. Offer a redacted outline or a description if you can't share the document | Your most inspectable evidence (F4). The prober will ask about something this concrete, and confidentiality is the trap to avoid |
| C3 | "Your roadmap-input sessions: what did product actually do with what you brought?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Volunteer the limit first: confirmed, with not much documentation to show. Then the quote's beats: quarterly, client evidence, to product. Answer slot: if you know of a case where that evidence changed what product built, say what and how you know; if you don't, say so plainly. Don't describe product's decisions as yours | F8's medium-confidence line. The underwriter flagged it for a probe, so the guidance has you raise the limit before they do |

### D. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: the integrations, the playbook, the sessions, each in its quote's words, then why this role (A4's reason). Don't call any of it "product management". The interviewer will hear the adjacency without your help, and saying it outright invites A1 early | Every conversation opens here, and it sets the frame for F1. EXP because it's your history, told briefly |
| D2 | "What drew you to Quartzline?" | CO | [generic] | Anchor on the role itself (partner-facing API platform, discovery with integration partners). Those come from the role profile. Mention nothing about Quartzline's products, strategy or values from memory: no research ran. If you've read their site yourself, use what you actually read. Otherwise say what about the role pulls you, and ask B-style questions back | CO coverage would normally rest on strategy research. Research was refused, so this stays generic, which is the honest cost. The upgrade menu says what research would add |
| D3 | "What does agile delivery look like for you?" | JD | [inferred] | The dossier's strategy is **clarify**: no verified line covers it. Answer slot: if you've worked in agile delivery, say how, in your own words; if you haven't, say so plainly. Then: "I'd want to understand how your squads run before I assume. What's the cadence?" | F7 (R5, preferred). A casual question on a JD item is still scored. `[inferred]` because the guidance comes from the dossier's clarify strategy |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate who already works as a PM here?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims: "Having held a product manager title or role"` | Pause. Don't argue against the internal candidate. Twenty seconds on the integrations in the quote's words, twenty on what you'd do first (from A1's ramp), and if they push, the concession in its exact words: "I haven't held a product manager title." Hold the integrations; concede the title | F1 under time pressure. JD because it's the same R1 question asked harder |
| E2 | "Those 30-plus integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "led", which is your material's verb. Answer slot: say who else was involved and which parts were yours, in your own words. If some stages belonged to others, say so; that makes you more credible, not less | An attribution probe on F3 and F10. Rehearse being exact under pressure |

### F. Values/Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a real stake, a moment where you didn't back down, and a working relationship still intact afterwards. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A persona stem. No values round is named, so it's light coverage. `[generic]` because no published values could be fetched |
| F2q | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, the metric it cost, why you made it, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | It fits a partner-facing role. A persona stem, with no claim about Quartzline's values |

### G. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When a squad lead disagrees with a priority you've set, how does it get resolved?" | CASE | [generic] | A plan, not a story: clarify who owns which decision (reverse question RQ1), bring the partner evidence, make the trade-off explicit, agree how you'll escalate before you need to, and commit once it's decided. Don't suggest you've done this with a squad before. That's a prohibited claim | The dossier's top unresolved risk is decision authority versus the squad leads. CASE delivery on F10 and F2 |
| G2 | "Tell me about a time you had to get engineering and sales aligned on what a customer needed." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold: pick one integration where engineering or sales were involved. It needs a named customer need, who disagreed, and what part was yours. Answer slot (F6): if you did work with engineering or sales on an integration, tell that story in your own words; if not, say so plainly and stay with the client side of the integrations you led | Covers R4's engineering and sales side (F6), where your material says nothing. JD because R4 is listed as important |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 "3+ years product management experience" | A1, A2, A4, E1 |
| R2 "Shipped API or platform products" | A3 |
| R3 "Technical fluency: API docs, schemas" | B4, C2 |
| R4 "Stakeholder management across engineering, sales, customers" | G2, C3, D1 |
| R5 "Agile delivery experience" | D3 |
| "Own the roadmap for the partner-facing API platform" | A1, B3 |
| "Run discovery with integration partners" | B1, C3 |
| "Write specs and drive delivery with two engineering squads" | B4, G1 |
| "Define and track adoption metrics" | B2, A5 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open question about decision authority. The JD says you'll own the roadmap, but nothing shows how much authority that carries. You need the answer before accepting, and asking it shows you know how platform teams actually split decisions |
| RQ2 | "How is partner API adoption measured today, and what's the current baseline?" | Adoption metrics are listed as a responsibility but no baseline is stated. The answer tells you whether you'd inherit a dashboard or build one, and it links to B2 |
| RQ3 | "Which integration partners are struggling most right now, and what have they told you?" | It sets up discovery with integration partners as something you'd start in week one, and it shows you think from the partner's side first |
| RQ4 | "What would a strong first six months look like to you in this role?" | It gets the success criteria said out loud, which you can echo back (A5). It's also a fair check on whether those expectations are realistic for an adjacent hire |
| RQ5 | "How do the two squads work today? Who writes specs now, and how do they want them?" | It covers the agile and spec unknowns (F7, F10) and shows you'll learn how they work before changing it |

---

## Prohibited claims

What this pack will not coach, and why. The first three come from your dossier's `prohibited_claims` and are absolute. The rest are inflated versions of your own verified lines, built here.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims: "Having held a product manager title or role"` | "I haven't held a product manager title." Then the F1 quotes at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims: "Having owned a product roadmap"`; `acknowledge_gap` area | "I haven't owned a product roadmap." Then a ramp plan. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims: "Having set prioritization for an engineering squad"` | "I haven't set prioritization for an engineering squad." Answer B3 and G1 as plans |
| Shipped an API product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's own observation: your material says client integrations of the vendor's APIs, not shipping the API. A3's slot stays inside the integrations |
| Designed the API architecture | Inflated form of F3: "architecture" is a stage of the integrations, not the API | F3's quote at its own scope. Architecture was one stage of the integrations you led |
| Ran product discovery, or decided what product built | Inflated form of F8: "roadmap-input sessions feeding client evidence to product" | F8's quote at its own scope. C3's slot asks only whether you know what changed |

---

## Sources

- **Provided:** `tuesday-dossier.md`, envelope v1.1, generated by job-underwriter on 2026-08-14. It supplied: `role_profile` (requirements and responsibilities, standing in for the JD), `handoff_to_mock_interview` (verified evidence standing in for the CV, weak areas with strategies, the A1 objection, risks and employer questions for the reverse bank, prohibited claims), and `decision` (context only). No `evidence_map`, `evidence_state` or `risk_register` section was present, so the fit snapshot's gap types come from the handoff's weak areas where it names them and from this pack's routing otherwise.
- **Your message:** round type and interviewer relationship (a 45-minute conversation with the hiring manager, on Thursday).
- **Searches sent:**
  - `Quartzline company values`: refused
  - `Quartzline interview process product manager`: refused
  - `Quartzline partner API platform strategy news`: refused
- **Fetches:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have supplied published value names to theme VAL questions (F1q, F2q). No values round is named, so there'd be no cheat sheet either way |
| 2. `Quartzline interview process` product management | unavailable | The search was refused. It would have confirmed or added to the loop. Your own description already fixes this round, so the persona weights stand |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have grounded D2 and given at least one CASE question in Quartzline's current priorities. Without it, those stay `[generic]` |
| 4. Interviewer name + Quartzline | n/a | No name was given. There's no interviewer read, and no reverse question tied to their career path |
| 5. Representative JD for the title | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allowing web search in this session** → Quartzline's published values to theme F1q and F2q, any public loop information, and a strategy sweep that would make D2 and one CASE question specific to Quartzline instead of `[generic]`
- **Deep research (L2)** → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, recent org context and role-family loop reports, which feed sharper CO and CASE questions. Only with your go-ahead, and only once search is allowed
- **The hiring manager's name** → an interviewer read from their public professional footprint, adjusted persona weights, and a reverse question tied to their career path
- **Any recruiter guidance** (focus areas, anything to prepare or present) → coverage of those areas, plus a build section for any pre-declared deliverable
- **How much prep time you have before Thursday** → a prioritized prep schedule sized to it
- **Your answers to the answer slots on F4, F6, F7, F9 and F10**, said here outside a drill → those rows quoted as your evidence, and A3, B4, C1, D3 and G2 rebuilt on your words
- **Notes or an agenda from one roadmap-input session**, if you're allowed to share them → F8 and C3 move from medium toward high confidence
- **Your full CV** → the fit snapshot can quote lines beyond the dossier's three verified claims, which may turn some `discovery` rows into grounded ones
