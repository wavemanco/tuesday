I've saved your prep pack as `saltmarsh-games_live-operations-producer_interview_pack.md`. I built it from your JD and background only, because my web searches were refused in this session. Anything about Saltmarsh's values, strategy or Tobias's background is marked generic, not researched.

The most important thing to rehearse is **B1**: "What in your background gets you there?" You've run a weekly content-drop calendar for one title. This role runs live events across two titles and four teams. The pack has you name that limit yourself first. Then you stand on what you actually did: the calendar, the QA checklist and the retention numbers you presented.

I've also written out plain, short answers for the two gaps you flagged: you've never led a team, and you've never worked on a game with in-app purchases.

Say the word and I'll play the Skeptic on B1, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Would Tobias be your direct manager, or is he more senior than that? I've assumed manager, and the answer changes which question styles the pack weights most.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi · **Interviewer:** Tobias Wrenfield, Head of Live Operations · **Format:** one 60-minute interview, Friday

**Relationship assumed:** hiring manager. This is my guess from his title. A Head of Live Operations most likely leads the team this role joins, but your note doesn't say so. If he would be your skip-level or a peer, the persona weights below change.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: the style, the pressure, the follow-ups. **Types** describe *what* the question is scoring.
- Type key:
  - **VAL**: behavioural or values fit, scored against the company's published values. None were in hand for this pack, so these rows are generic.
  - **EXP**: a deep-dive on your experience. Do your claims survive scrutiny, and what was actually you?
  - **JD**: the listed job. Can you do what the posting asks, gaps included?
  - **CO**: company knowledge, meaning homework on strategy and recent moves.
  - **CASE**: a live problem from the role, reasoned out loud.
- **Provenance labels:**
  - `[grounded]` traces to your JD or your own sentences.
  - `[inferred]` is a derivation, and the row names what it was derived from.
  - `[generic]` is a role-family pattern with no claim about Saltmarsh. It's useful for rehearsal but asserts nothing about the company.
- **The guidance is scaffolding, not a script.** Every clause about your past rests on one of five sentences you wrote, quoted in the Provenance column. An **answer slot** marks a spot where the JD makes a probe likely but your material doesn't say what happened. Answer it from your own memory, or say plainly that it wasn't so.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a weekly content-drop calendar for one title, not a live-events calendar for two, and your words should stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: this JD line makes a probe on what the calendar involved likely. If you can say what a drop held and what running the calendar involved week to week, say it in your own words. If any part of that sat with someone else, say so plainly and stay with the calendar you ran. Running a second title is a plan, so say it as a plan |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | Leading a team and coordinating teams are different things. Your sentence speaks to leading, and your material doesn't show whether working across these four disciplines was part of the calendar work. For the leading part, your words come from your own sentence: "I haven't led a team." Answer slot: if getting a content drop out meant working with design, art, engineering or community, say which teams and what your part was, in your own words. If it didn't, or that work sat with someone else, say so plainly and say how you would set it up here |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers isn't the same as owning a post-event review, and your words should stay at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: this JD line makes a probe on which part of those numbers was yours likely. If you put them together, say how, in your own words. If they came to you from someone else, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but nothing has been inspected behind the line, so expect a probe. Lead with the quote's own terms: you wrote it, and QA still uses it. Answer slot: the JD says "manage", so expect a probe on how the checklist is kept current. If you kept updating it, say how. If it hasn't changed since, or someone else maintains it, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The years clear the bar. Your material doesn't show whether the puzzle game is run as a live service. Keep the title exactly as it is: associate producer. Answer slot: if the game is run as a live service, say what makes it one, in your own words. If it isn't, say so plainly and stay with the four years you have |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote meets the requirement in its own words. Say it as written (weekly, main title, last two years) and expect a probe on how it ran |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement, but nothing has been inspected behind it, so expect a prober to ask which metrics and how they were counted (C1). Say it in the quote's terms: monthly, retention, presented to the studio head. What you can say about how they were counted is an answer slot in C1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote is written work a team relies on, so it reaches the requirement in other terms. Reword only that: "I wrote the release checklist, and our QA team still uses it." Let the interviewer draw the conclusion about clarity |
| F9 | Familiarity with in-app purchases in mobile live events. This is a role-family pattern; the JD doesn't name it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | You've stated this gap yourself, and the JD doesn't name it. Words: "I haven't worked on a game with in-app purchases." Then say how you would learn it, as a plan and never as something you've done. Add nothing to make the gap feel smaller |

**Highest-ROI prep in this pack: B1.** The likeliest objection to your candidacy sits where F1 and F2 meet. You've run a weekly content-drop calendar for one title, and this role runs live events across two titles and four disciplines.

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | B1, A1, A4 |
| Coordinate design, art, engineering and community | B2, A3, G1 |
| Own the post-event review and its KPIs | C3, A2 |
| Manage the release checklist with QA | A5, E1 |
| 3+ years producing live-service games or apps | B1, D1 |
| Experience running a content calendar | B1, A1, C2 |
| Comfortable with player-retention metrics | C3, C1, C2 |
| Clear written communication | D3 |

---

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Plan the next quarter's events", "this event underperformed, diagnose it" | High. Hiring managers buy capability, and every responsibility in the JD can be asked as a live problem | Clarify, set the objective, segment, then lay out the approach, metrics and risks. Think aloud, and challenge one premise per case |
| Skeptic | Quiet probing of the distance between F1 and F2 and the JD | High. A hiring manager has to derisk the gap between one weekly calendar and two titles' live events | Name the limit before he does, hold to your three strongest sentences, and give the ramp as a plan |
| Data-Driven Prober | "Which retention numbers? How were they counted?" | Medium. The JD names retention metrics and KPIs, and F7 is a claim he can test | Know what you can and can't say about how the numbers were counted, and say "I don't know" plainly where that's true |
| Conversational | "Walk me through your journey", "what are you playing?" | Medium. A 60-minute single interview usually has warm-up and close segments, and those are still scored | A 90-second arc built only from your five sentences. Treat casual questions as scored |
| Pressure | "How much of that was actually you?" | Low. Nothing in your inputs signals a stress format, but attribution probes are cheap to rehearse | Pause, restate, anchor in what you wrote, and hold through two follow-ups |
| Peer Evaluator | "Where's the seam between you and design?" | Low. He's probably not a peer, but a live-ops lead will price how you sit between teams | Propose principles for the seams. Show reciprocity: what you'd take off each team's plate |
| Values / Behavioural | Generic behavioural prompts | Low. Your words establish a single session with no values round, and Saltmarsh's published values weren't available | A selection scaffold with an honest branch. These rows become value-mapped once the values page is in hand |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Plan the next quarter's live-events calendar for two titles. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify before you plan. Ask each title's audience and lifecycle stage, the team capacity behind each, fixed dates (platform features, holidays, marketing beats), and what success means: retention, engagement or something else. Then structure it: cadence per title, which weeks share resources, buffer weeks, and how the review of one event feeds the next. If you anchor in your own experience, say only what the quote says: you ran the weekly content-drop calendar for your main title for two years | The core of the role, asked as a live problem. CASE because it scores structure; it touches F1 and F6 |
| A2 | "An event's retention came in well below the previous one. Walk me through your post-event review." | CASE | [generic] | Check the measurement first: same window, same cohort definition, any tracking change. Then segment by title, by new and returning players, and by platform. Then form hypotheses: content, timing, a clash with another update, a bug. Say what you would report, to whom, and the one change you would make to the next event. The question needs no claim about your past, so this guidance makes none | The JD's ownership of post-event review (F3's requirement) asked as a decision rather than a record |
| A3 | "Two days before an event, engineering says a feature won't make it. Art and community are already committed. What do you do?" | CASE | [generic] | Find out what exactly won't make it and whether a reduced version can ship. Lay out the options: cut scope, slip the date, or swap content. Say who decides, how you tell art and community the same day, and what the players hear. Finish with what you would change in the checklist or calendar so the risk shows up earlier next time | A coordination problem from the JD's four-team line (F2's requirement), asked so that no past is needed |
| A4 | "Both titles want an event in the same week and share an engineering team. How do you decide?" | CASE | [generic] | Clarify the stakes per title: player impact, revenue or retention at risk, how hard each date is. Lay out the options: stagger, scale one down, or move one. Name the decision-maker if it isn't you, and the data you would bring them. Say how you would prevent the collision in next quarter's calendar | The JD's "two titles" is the part F1's quote doesn't carry, so expect a live test of it |
| A5 | "What would you add to a release checklist for a live-event update that a standard build checklist wouldn't cover?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure it as before, during and after the event. Before: config and timing checks, server-side switches, localisation, store or notification copy. During: monitoring, and who can pull the event. After: turning it off cleanly and the hand-off into the review. Answer slot: if your own checklist covers live-content items, name them in your own words. If it doesn't, say so plainly and present these as what you would add. Don't describe what your checklist contains beyond what you remember | Puts F4's strength to work on the JD's checklist line. Typed JD because the checklist is a listed responsibility |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role runs live events across two titles and coordinates design, art, engineering and community on each. What in your background gets you there?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "4 years as an associate producer at a puzzle-game studio." | **The highest-ROI rehearsal in this pack.** Open by naming the limit yourself: what you've run is a weekly content-drop calendar, for one title. Then give your three sentences in your own words: for the last two years you ran the weekly content-drop calendar for your main title, you wrote the release checklist your QA team still uses, and you presented the monthly retention numbers to the studio head. That's four years as an associate producer. Answer slot: the JD's four-team line makes a probe on who you worked with likely. If drops meant working with design, art, engineering or community, say which and what your part was. If they didn't, say so plainly and stay with the calendar. **Follow-up 1, "That's one title":** concede plainly, then say how you'd approach the second, as a plan. **Follow-up 2, "So what would be new to you here?":** name what your material doesn't carry (the second title, and coordination if your slot answer was no), then the ramp plan. Hold by returning to the three sentences, never by adding to them | F1 and F2 are where the JD presses hardest against your material, and F6 is your strongest row, so this objection arrives in some form. Typed JD because it scores the listed responsibilities directly |
| B2 | "This role coordinates four disciplines. Have you led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it straight: "I haven't led a team." Don't soften it. Answer slot: the JD asks for coordination, not leadership. If running the content-drop calendar meant working with other disciplines, say which ones and what your part was, in your own words. If it didn't, say so plainly and describe how you'd run a weekly cross-team sync and an update brief here, as a plan | F2's stated negative. A clean acknowledgment followed by the coordination slot beats a hedge. JD because coordination is listed |
| B3 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | "I haven't worked on a game with in-app purchases." Then give a plan, as a plan: how you'd learn how Saltmarsh's titles earn, who you'd sit with in the first weeks, and what you'd read in past event reviews. Never imply monetisation experience, and add nothing to make the gap smaller | You raised F9 yourself. The JD doesn't name monetisation, but a rehearsed one-line acknowledgment costs nothing if it comes up |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick a real one rather than a disguised strength. The cleanest is the second title, since your quote covers one. Say what you'd do in the first month, as a plan. If your B2 slot answer was that coordination wasn't part of your role, that's an equally honest pick | A classic Skeptic stem, typed JD. F1 gives you an honest, bounded answer |
| B5 | "Why leave your current studio, and why Saltmarsh, now?" | CO | [generic] | Answer slot: give your own reasons in your own words. Possible reasons include wanting live events, more than one title, or the scope the JD describes. For "why Saltmarsh", only cite what you actually know about the studio and its games. Don't state facts about the company that you haven't checked | A motivation check every Skeptic runs. It's generic because research on Saltmarsh couldn't run (see Sources) |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Those monthly retention numbers you presented: which ones, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented, in the quote's terms. Then cover the four things a number raises, each in your own words: how it was counted, what moves it, the assumption behind it you'd defend least, and which part was yours. If you don't know how a figure was counted, say "I don't know how that was counted", which is an honest answer. Name the weakest assumption before he does | F7 and F3 rest on this sentence, and a prober tests it first. EXP because it checks what was yours |
| C2 | "Tell me about a time a number changed what went into the calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick an occasion where data led to a scheduling or content decision. It needs the number, the decision, and what was yours. If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry (you ran the calendar, and you presented the retention numbers) and how you'd connect the two here | The JD pairs a calendar with retention metrics. Your material has both (F6, F7) but doesn't show them linked, so this is a selection scaffold, not a story |
| C3 | "What KPIs would you put in a post-event review, and which would you trust least?" | JD | [generic] | Split them into tiers. Event-level: participation, completion, engagement. Retention against a baseline. Health: crashes, support tickets, community sentiment. Then name the one you'd trust least and why, for example a short-window measure that a holiday or a concurrent update could distort. Say what decision each one feeds | The JD's KPI ownership (F3's requirement) and retention comfort (F7's), asked as reasoning. Typed JD because both are listed |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built from these four sentences only: four years as an associate producer at a puzzle-game studio, running the weekly content-drop calendar for the main title for the last two, writing the release checklist QA still uses, and presenting the monthly retention numbers to the studio head. End on why live ops across two titles is the next step, in your own words | The opener that sets the frame for the whole hour. Rehearse it so the F-rows arrive in the right order and at the right scope |
| D2 | "What mobile games with live events are you playing at the moment?" | CO | [generic] | Answer slot: name only games you actually play, and one event you noticed in them, in your own words. If you're not playing any right now, say so plainly and name what you'd study first | A casual question that's still scored. A live-ops lead will notice whether you follow the genre |
| D3 | "How do you write an update brief so four teams actually read it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | The structure is to lead with the decision or ask, then what changes for each team, dates and owners, and where questions go. Anchor in the quote: you wrote the release checklist, and QA still uses it. Answer slot: if you've written other documents teams relied on, name them. If not, say so plainly and stay with the checklist | Covers the JD's written-communication requirement, which is F8's row |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Pause, then hold: you wrote it, and QA still uses it. Answer slot: if others contributed items or reviewed it, say who and what, in your own words. If not, say so. Hold through two follow-ups by repeating what the quote says, and concede only something specific and real | F4 and F8 both rest on this sentence. An attribution probe is the cheapest way to test it |
| E2 | "Sixty seconds: why you over someone who's already run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Don't argue with the premise. Concede it in one line: "I haven't worked on a game with in-app purchases." Then hold to two sentences: the calendar you ran for two years and the checklist QA still uses. Close with what you'd do in your first month, as a plan. Stay inside sixty seconds | A time-boxed test of composure on F1 and F9 together. The hold is the two quotes, never more |

### G. Peer Evaluator

*(Bank F is skipped so the question IDs don't collide with the fit-snapshot rows.)*

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You'd sit between design and community. Where's the seam, and what happens when they disagree about an event?" | CASE | [generic] | Propose principles rather than pretending to know Saltmarsh's seams. Design owns what the event is, community owns how players hear about it, and you own the timeline and the trade-offs. Disagreements get surfaced early with options and a named decision-maker. Ask how it works today | The coordination line (F2's requirement) asked collegially. CASE because no past is needed |
| G2 | "How do you handle credit when an update lands well and four teams built it?" | VAL | [generic] | Selection scaffold: pick a time you shared credit for shipped work, saying "we" for the context and "I" for your part. If no such time comes to mind, say so plainly and say how you'd do it here, for example by naming each team in the review | A Peer stem about whether you'd add to or reduce the load on the teams around you |

### H. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a named stake, the moment you said it, and what happened next. Your material shows you presented retention numbers to the studio head, but not that any of it was unwelcome, so don't supply that ending. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A persona stem. It's generic because Saltmarsh's published values weren't available to map it to |
| H2 | "When did you put players ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where player experience won over a number, with what you gave up and why. If no such time comes to mind, say so plainly and describe how you'd weigh it in an event decision | An adaptation of a stem for player-facing roles. It becomes value-mapped once the values page is in hand |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here: who reads it, and what decision does it feed?" | It goes straight at a JD responsibility you'd own, and the answer tells you how KPIs are used |
| R2 | "How do the two titles differ in event cadence and team, and would this role hold both calendars equally?" | The JD's "two titles" is the part your background doesn't carry yet, so asking about it shows you've read where the work is |
| R3 | "When design, art, engineering and community disagree on an update, who makes the call today?" | It tests the coordination seam the JD names, and it tells you how much decision authority the role has |
| R4 | "As Head of Live Operations, what would you want this person to have taken off your plate in the first 90 days?" | It's tied to his own role, and it gives you his success criteria in his words |
| R5 | "Which event KPI does your team trust least, and why?" | It mirrors the weakest-assumption habit back at him, and it's a conversation between practitioners |
| R6 | "What's the next step after this conversation, and is there anything you'd want me to prepare for it?" | It surfaces the rest of the loop, which your inputs don't describe |

---

## Prohibited claims

These are claims this pack will not coach. Don't say them, even under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Four years as a producer | An inflated form of F5 | F5's quote: "4 years as an associate producer at a puzzle-game studio." The title stays associate producer |
| Ran a live-events calendar, or calendars across two titles | An inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: a weekly content-drop calendar, one main title. B1's slot stays inside the drops |
| Owned post-event reviews or the KPIs they report | An inflated form of F3 | F3's quote at its own scope. C1's slots ask only how the numbers were counted and which part was yours |
| Built or analysed the retention numbers | An inflated form of F7 | F7's quote: you presented them. Which part was yours is C1's slot |
| Managed releases, or managed QA | An inflated form of F4 | F4's quote: you wrote the checklist QA still uses |
| Has led a team | A negative you stated, F2 | "I haven't led a team." No slot |
| Has worked on in-app purchases or monetisation | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |

---

## Sources

- **Provided documents:** the JD text pasted in your message, and your background in the same message.
- **Searches sent:**
  - `Saltmarsh Games values`: refused, because search permission isn't granted in this session
  - `Saltmarsh Games interview process producer`: refused
  - `Saltmarsh Games mobile studio news 2026`: refused
  - `Tobias Wrenfield Saltmarsh Games`: refused
- **Fetches:** none.
- **Loop:** your own words establish it as one 60-minute session run by Tobias Wrenfield, so no archetype fallback was used. No values-style round was detected.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. It would have supplied the values cheat sheet's names, and let H1, H2 and G2 be mapped to published values instead of generic |
| 2. `Saltmarsh Games interview process` | unavailable | The search was refused. Your words already fix this session's structure. It would have shown whether a values round or a case exercise comes later in the loop |
| 3. `Saltmarsh Games` strategy and recent news | unavailable | The search was refused. It would have grounded B5 and D2 and added a CO or CASE question on Saltmarsh's actual titles and recent moves |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. It would have added an interviewer read, tuned the persona weights to his public footprint, and tied a reverse question to his career path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Permission for web search, or paste Saltmarsh's careers or values page.** This adds a values cheat sheet, and H1, H2 and G2 get mapped to named values instead of staying `[generic]`.
- **The names of the two titles and any recent events you know about.** This turns A1, A4 and D2 into questions about Saltmarsh's actual games and adds a grounded CO question.
- **Tobias's public profile, for example a LinkedIn summary you paste.** This adds an interviewer read and persona weights tuned to his background, and ties R4 to his own career path.
- **Whether Tobias would be your manager.** This confirms or replaces the hiring-manager weights in the persona table.
- **The recruiter's invite or prep email.** This brings in any stated focus areas. Any announced exercise, such as a calendar plan, gets its own build section.
- **Your answers to the answer slots, given here rather than in the interview:**
  - what a drop held and what running the calendar involved
  - which teams you worked with
  - which part of the retention numbers was yours
  - whether the game is run as a live service

  These would upgrade F1, F2, F3, F5 and F7, and the guidance in B1, B2 and C1.
- **How much prep time you have before Friday.** This adds a prioritised prep schedule sized to it.
- **Deeper research (L2):** up to 6 more searches and 2 more fetches, several more minutes, and only if search permission is granted. It adds a strategy brief on Saltmarsh, a deeper look at Tobias's talks and writing, and candidate reports on the loop.
- **A `tuesday-dossier.md` from a job-underwriter session.** This would make the highest-ROI objection evidence-derived rather than inferred, and would add a verified claims list to guard the guidance.
