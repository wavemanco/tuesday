The web searches I tried were refused, so I'm building the pack from what you gave me and noting where that leaves gaps. Writing it now.
I've built the full mock-interview pack for Priya's hour with Dan. It's built on what you gave me and treats Dan as a peer in a single 60-minute conversation. My web searches were refused, so Northwind's published values, a check of your Compass notes and Dan's public profile are missing. The pack labels where that matters.

It's saved as /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-1-denied-18e62046/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md

- **Fit snapshot:** each JD highlight is set against Priya's background, quoted exactly as you wrote it, with how strong the evidence is and how to talk about the gap.
- **Questions:** 22, grouped by interviewer style and tagged by what they score. Each has answer guidance and a rationale for why it's included and how it's tagged.
- **Weighting:** Dan's "relentlessly data-driven" self-description and pricing background push the pack toward questions that probe her numbers and toward pricing cases on Compass and the bundling threat.
- **Highest-ROI prep:** D1 — "You haven't done classic sales-ops or quota-setting, and your background is consumer tech." It's rehearsed deepest, with exact wording for admitting the gap and two follow-ups.
- **Biggest number to defend:** the ~$400M uplift. A1 and E1 keep her to your verbs, "proposed" and "credited", and never "drove".
- **Also included:**
  - A table mapping each JD requirement to the questions that cover it
  - Six questions for her to ask Dan, two tied to his own career
  - A list of claims the pack won't coach

Where her background doesn't say something, the guidance leaves a slot for her to answer in her own words, including "no" or "I don't know." It never fills in details she hasn't given.

Say the word and I'll play the Skeptic on D1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste Priya's CV and the full JD? Her own lines would replace my summaries, several answer slots would become mapped stories, and any requirements the highlights left out would get their own questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview pack — Senior GTM Strategy Lead, Emerging Products · Northwind Data

**Candidate:** Priya · **Interviewer:** Dan Kovac, Director of Sales Strategy. He would be a **peer**, and both roles report to the same VP. · **Format:** a single 60-minute conversation

---

## How to use this pack

Questions are sorted two ways:

- **Personas** describe *how* a question is asked: the style and register Dan may use.
- **Types** describe *what* the question scores.

| Type | Scores |
|---|---|
| **EXP** | Whether the claims in her background hold up under questioning, and which parts were actually hers |
| **JD** | Whether she can do the job as listed, including the parts where she has gaps |
| **CO** | How well she knows the company: its strategy, competitors and recent moves, at Northwind's own level |
| **CASE** | How she structures and reasons through a live problem from the role |
| **VAL** | Whether past behavior shows the values in question (Northwind's published values could not be researched, so these use generic themes) |

**How to read the cells:**

- Fit-snapshot rows are numbered **F1–F8**.
- Question IDs use one letter per persona. The letter F is skipped so question IDs never collide with fit-snapshot rows.
- Square brackets are used only for provenance:
  - `[grounded]` means it traces to what you gave me.
  - `[inferred]` means it's this pack's own derivation, and the derivation is named.
  - `[generic]` means it's a pattern for this kind of role, with no claim about Northwind or Priya.
- Guidance is scaffolding, not a script. Any sentence about what Priya did uses only the words of her background as you gave it. Where her material doesn't say something, the cell holds an **answer slot**: an instruction for her to answer in her own words, with an honest branch if the answer is "no" or "I don't know".

---

## Fit snapshot

All quoted requirements come from the JD highlights in your message. All quoted evidence comes from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Her material shows product strategy & ops at a consumer-tech company. It does not show GTM ownership of product lines, and her words should stay at that scope: "Two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company." Answer slot: the JD's own-GTM line makes a probe on which go-to-market decisions were hers likely. If any were, she says which ones and how she decided, in her own words. If none were hers, or the role had no GTM remit, she says so plainly and stays with the product strategy & ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Her material shows one proposed change on a consumer store surface, credited with an uplift. It does not show whitespace analysis across a B2B customer lifecycle. Words at the quote's scope: "I proposed a store-surface change that was credited with about $400M in ARR uplift." Answer slot: the JD's whitespace line makes a probe on how the opportunity was found likely. If she found it through her own analysis, she says how, in her own words. If it reached her another way, she says so plainly and stays with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. It is a self-report with nothing inspected behind it, though, and a data-driven peer will test it. She leads with the quote's own terms (skilled in SQL and Tableau) and should be ready to work a problem out loud (A4) |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model used in negotiations is adjacent to designing a partner motion but is not the same work, and the JD marks this requirement as required. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of how partners were engaged, tiered or incented was hers to design, she says which part, in her own words. If none was, she says so plainly and stays with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote meets the requirement in its own terms. She leads with it: annual volume targets, set with cross-org consensus. Expect a probe on how the consensus was reached (B3) |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Daily tool use touches the requirement but doesn't show whether it extends to AI product or GTM work. The derivation: the JD's "AI experience" alongside the Compass launch in your research note. Answer slot: if any of her AI use is in product, launch or analysis work, she says what, in her own words. If it is personal productivity use, she says so plainly. For a requirement listed as a plus, that is still a real answer |
| F7 | "B2B data-infrastructure SaaS" — your description of Northwind | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Her material is consumer tech, and the setting is B2B infrastructure. Her words stay at F1's scope. Anything about learning the B2B side is said as a plan, never as past experience |
| F8 | Fluency in sales planning, which a Sales Strategy peer works in daily (a typical expectation for the role, not a JD line) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap your notes state outright. Her words: "I haven't done classic sales-ops or quota-setting." After that comes how she would ramp up, said as a plan and never as past experience. Nothing is added to make the gap feel smaller |

**Requirement coverage:**

| JD requirement | Covered by |
|---|---|
| Own GTM strategy for two new product lines (F1) | C2, D3, A2 |
| Whitespace across land/adopt/expand/renew (F2) | A4, C2 |
| Independent analysis in SQL and Tableau (F3) | A4, A5 |
| Partner-motion design, required (F4) | D2, C4, A2 |
| Strong cross-functional influence (F5) | B1, B3, B4 |
| AI experience, a plus (F6) | G2, C3 |
| Company priorities from your note: enterprise expansion, Compass, profitability, bundling | C1, C2, C3 |

---

## Reading the interviewer

All of this comes from your notes on Dan's profile. Nothing could be checked against his public footprint because the search was refused.

| Signal | What it implies for this hour | Provenance |
|---|---|---|
| Peer: same VP, adjacent team | He is judging whether she adds to his team's load or reduces it. Expect seam and credit questions in a collegial tone, and expect the other banks' objections to come back in friendlier form | [inferred] from your note on the reporting line, using the peer-relationship prior |
| Self-describes as "relentlessly data-driven" | Every number she mentions will be taken down to its assumptions. The ~$400M figure (F2) is the obvious target | [inferred] from his self-description, using the data-driven signal rule |
| Career built on pricing and monetization roles | Case questions will likely turn to packaging, pricing and unit economics. Compass pricing and the bundling response are his home ground | [inferred] from your note on his career path |
| One early-stage-startup chapter | Stories about building things tend to land with him. Expect probes on big-company pace and scrappiness | [inferred] from your note on his career path |

**Shared career moves to mirror:** none offered. No fit-snapshot quote carries Priya's side of a move like his (pricing/monetization, or a startup), so the pack doesn't invent one. His path is used in the reverse questions instead (R1, R6).

---

## Persona table

The relationship prior is peer, which makes the Peer Evaluator and the Data-Driven Prober the dominant personas. Dan's signals then adjust the weights: his self-description raises the Prober, and his pricing career tilts the Case questions toward pricing. Because you described the format as one 60-minute peer conversation, no separate values round is expected.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A · Data-Driven Prober | "How was that counted?" with follow-ups two levels deep | **High.** He calls himself data-driven, and the peer prior already includes this persona | She knows what she can and can't say about each number (F2) and says "I don't know" where she doesn't. She names her weakest assumption before he does |
| B · Peer Evaluator | Seam, reciprocity and credit questions | **High.** This is the base persona for a peer interviewer reporting to the same VP | She leads with what she brings his team, proposes principles for the seam rather than claiming to know it, and keeps any story about influence at F5's scope |
| C · Case / Strategist | Live problems on Compass pricing, bundling and GTM for a new product line | **Medium-high.** His pricing career and your research note give him obvious material | Clarify, then objective, segments, approach, metrics, risks. She challenges one premise per case and uses the vocabulary from your research note |
| D · Skeptic | "Why a consumer person for B2B GTM?" and "Where's the partner motion?" | **Medium.** F7, F8 and F4 are the visible gaps, and a peer in sales strategy will notice them | Rehearse D1 until it's boring. She states the F8 gap plainly, keeps the bridges at their quotes' scope, and presents a ramp plan as a plan |
| E · Pressure | "How much of that was actually you?" and time-boxed pitches | **Low-medium.** It's a peer conversation, but a data-driven interviewer may push on F2 | Pause, then hold on the quote's own verbs ("proposed", "credited"), then concede specifically |
| G · Conversational | The opener and an "AI these days?" aside | **Low,** but scored anyway | A 90-second background arc built from the quotes. She treats the AI aside as a scored question (F6) |
| H · Values / Behavioral | One or two behavioral questions | **Low.** No values round is documented, and Northwind's values couldn't be fetched, so these use generic themes | Selection scaffolds, each ending in its honest branch |

---

## Question banks

### A · Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | She opens at the quote's scope: "I proposed a store-surface change that was credited with about $400M in ARR uplift." Proposed and credited are her words, and she keeps both. Then four answer slots, each in her own words: how the figure was counted; what it is sensitive to; the assumption behind it she would defend least, named before Dan asks; and which part was hers. If she doesn't know how it was counted, she says so plainly and stays with the proposal and the credit. An honest "I don't know the method" holds up better than a method she can't defend | F2's figure is the headline number, and a self-described data-driven interviewer will go for it first. EXP because it tests whether the claim holds up and what part was hers |
| A2 | "Tell me about the partner-level revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, using the beats the quote states: a revenue model, at partner level, built by her, used in carrier negotiations. She walks through its inputs and structure in her own words. It's her work, so the pack doesn't supply them. Answer slot: the JD's partner-motion line makes a probe on what the negotiations did with the model likely. If she knows how it moved a term or a position, she says how, in her own words. If she doesn't know, or it didn't move anything, she says so plainly and stays with the model | F4 is the closest evidence for a requirement marked "required", and this question lets her show it on her own terms before the Skeptic version (D2) arrives. EXP because it is premised on a claim in her background |
| A3 | "How did you set the annual volume targets?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats from the quote: annual volume targets, set by her, with cross-org consensus. Answer slot: the method in her own words, plus the assumption she would defend least. If she tracked the targets against actuals, she says how they landed. If they weren't tracked, or she doesn't know, she says so plainly. She never calls them quotas (see the prohibited claims) | F5 is the closest thing in her background to Dan's daily work, so he will look closely at the method. EXP for the same reason as A2 |
| A4 | "Say you have account, contract and product-usage tables. Talk me through how you'd find expansion whitespace for a new product line, down to the SQL and the Tableau view." | CASE | [generic] | 1) Clarify the grain (account, product, contract) and what "whitespace" means for each motion. 2) Define the gaps: *land* = accounts that fit the target profile but have no contract; *adopt* = usage low against entitlement; *expand* = near limits, or not owning the adjacent product; *renew* = renewal date crossed with health. 3) Describe the joins and filters aloud. 4) Segment, then build a view Sales can act on. 5) Name the weakest assumption, most likely that usage predicts propensity to buy, and say how she'd check it with Sales. No claim about her past is needed | JD content (F2, F3) delivered as a live problem. It's the fastest way for Dan to test F3's self-report, so CASE first, with JD as the secondary tag |
| A5 | "Tell me about an analysis you ran end to end yourself in SQL and Tableau." | JD | [grounded] "skilled in SQL/Tableau" | Her material doesn't name a specific analysis, so this is a selection scaffold. She picks one she ran herself, from the query to the decision, with a question she was answering, a choice she made in the data, and what happened next. If no single analysis was hers end to end, she says so plainly and describes the part she did own | The JD stresses *independent* analysis, and F3 has nothing inspected behind it. JD because it scores a stated requirement |

### B · Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams would sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | She doesn't claim to know Northwind's seam. She proposes principles: each number has one owner, both teams work from one shared data source, disagreements go to a joint read of the data before going to the VP, and they agree in advance how a new line's targets get set. She closes on what she'd bring his team. No claim about her past is needed | This is the standard peer-seam question, and with a shared VP Dan has a direct stake in the answer. JD because the JD lists cross-functional influence |
| B2 | "Your GTM plan for a new product line will need things from my side. What would you need from me, and what do I get from you?" | CASE | [grounded] "skilled in SQL/Tableau" "built a partner-level revenue model used in carrier negotiations" | Lead with reciprocity. What she brings: analysis in SQL and Tableau, and experience building a partner-level revenue model, both at the quotes' scope and offered as future help. What she'd ask for: his team's capacity, segmentation and target-setting mechanics, framed as questions about how Northwind does it today. Close with "I'd want to co-sign the numbers with you, not hand them over" | Dan is measuring whether she adds to his load or lightens it. CASE because it's a live scenario, with JD (cross-functional influence) as the secondary tag |
| B3 | "How did you get cross-org consensus on the annual volume targets?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats from the quote: the targets, set by her, with consensus across orgs. Answer slot: the JD's cross-functional-influence line makes a probe on whether any group pushed back likely. If one did, she says what happened and what part of resolving it was hers, in her own words. If there was no pushback, she says so plainly and describes how she brought people along | F5 is her strongest match on influence, and a peer will ask how it actually worked. EXP because it's premised on her own claim |
| B4 | "How do you handle credit when work spans teams?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | She can use F2 at its own scope as a model of precise credit: "I proposed it. The uplift was credited to the change." Then the principle: say what was hers and name the people who did the rest. If she wants a different story, the criteria are a shared win, a moment where credit could have gone wrong, and what she did about it. If no such moment comes to mind, she says so plainly and states the principle | This is a stock peer question, and because F2's figure is large, how she shares credit is part of what's being scored. JD because it falls under cross-functional influence |

### C · Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much bigger platform vendor bundles a good-enough version of one of our new products for free. How do you respond in packaging and pricing?" | CASE | [grounded] your research note: main threat is bundling by a much larger platform vendor; priority on profitability | 1) Clarify which product, which buyer, and where the bundle actually wins (good enough, simpler procurement). 2) Don't price down to zero: profitability is a stated priority. 3) Segment: concede the low end, and defend where depth, interoperability or enterprise needs matter. 4) Packaging options: tiering, bundling Northwind's own products, an expansion path inside existing enterprise accounts. 5) Metrics: win rate against the bundle, discount depth, net revenue retention. 6) Name the weakest assumption: that the buyer values depth over a bundle that is "free" | This is Northwind's named threat and Dan's home ground in pricing. CASE as the primary tag, CO as the secondary, because it rests on the company's own competitive picture |
| C2 | "Sketch a GTM plan for one of the two new product lines across land, adopt, expand and renew. What do you need to know first?" | JD | [grounded] your research note: enterprise expansion is a stated priority | Clarify first: product readiness, target customer profile, how much of the existing customer base fits it. *Land*: in existing enterprise accounts first, tying to the priority. *Adopt*: activation metrics, and who owns them. *Expand*: triggers and packaging. *Renew*: health signals. Then owners at each stage (including where Dan's team sits), what role partners play, and the three numbers she'd review weekly | This is the core mandate (F1, F2) set as a problem. JD as the primary tag because it scores the listed job, with CASE as its delivery |
| C3 | "Compass is launching. Included, an add-on, or usage-based, given we also need to reach profitability?" | CO | [grounded] your research note: Compass launch and the profitability priority | Clarify what Compass does for which user and what it costs to serve. Weigh each option: included helps defend against bundling and drive adoption but squeezes margin; an add-on brings revenue but adds adoption friction; usage-based tracks cost but makes spend harder to predict. A defensible answer is a hybrid (a base level included, charging beyond it) with a test plan. She invites Dan's view, since pricing is his home ground. Her own AI use stays at F6's scope, if it comes up at all | This is a current company priority and sits squarely in Dan's pricing territory. CO as the primary tag because it tests homework on Compass, with CASE as its delivery |
| C4 | "Design a partner motion for an emerging product line: which partners, what they get, how you'd measure it." | CASE | [generic] | 1) The objective: reach, delivery capacity or credibility. 2) Partner types to weigh: systems integrators, cloud marketplaces, resellers. 3) The economics and what each partner gets. 4) Enablement. 5) Rules for when partners and direct sales collide, which is where Dan's team comes in. 6) Metrics: partner-sourced versus partner-influenced pipeline, and time to first deal. It's a live problem, so it needs no claim about her past. If he then asks whether she has done this before, that is D2 | Partner-motion design is a required item (F4). A live answer here lowers the stakes of D2. CASE because it scores structure, not record |

### D · Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting, and your background is consumer tech. Why would a Sales Strategy org trust your GTM numbers?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" | **The highest-ROI prep in this pack.** 1) **The limit, said first:** "I haven't done classic sales-ops or quota-setting." No apology and no padding. 2) **What she does have, at the quotes' scope:** nine years in product strategy and ops at a large consumer-tech company after two in consulting; annual volume targets set with cross-org consensus; skilled in SQL and Tableau. 3) **The plan, said as a plan:** learn Northwind's capacity and target-setting mechanics from his team early, and co-sign the GTM numbers with Sales Strategy instead of handing them over. **Follow-up 1:** "Volume targets aren't quotas." She holds: "Right. They were annual volume targets, set with cross-org consensus. I'm not calling them quotas." **Follow-up 2:** "So you'd learn B2B sales on our time?" She concedes specifically ("on sales mechanics, yes, I'd lean on your team") and holds the core point: annual volume targets set with cross-org consensus, and her SQL and Tableau skills. She never folds the core claim just to smooth things over | F8 is the gap your notes state, and F7 is the visible change of setting. A Sales Strategy peer is the person most likely to raise both. JD because it scores fitness for the listed job, delivered in the Skeptic's register |
| D2 | "The JD says partner-motion design is required. What partner motion have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | She holds what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of how partners were engaged, tiered or incented was hers to design, she says which part, in her own words. If none was, she says so plainly ("the model was my part"), then moves to how she'd approach the design (C4's structure, as a plan). Hold it through two follow-ups by returning to the model, never by adding to it | The JD marks partner-motion design "required", and F4 is adjacent work rather than a match. Second only to D1. JD because it scores a stated requirement |
| D3 | "Why leave product strategy at a large consumer company for emerging-products GTM at a 3,000-person B2B company? Why now?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Her reasons are hers, so the pack doesn't supply them. Answer slot: why leave, why this work, why now, each in her own words. For "why here", she can tie to what's grounded in your research note: two new product lines, enterprise expansion, the Compass launch. Expect a follow-up on pace (his startup chapter), and answer it with a real example or an honest "that's what I'm looking for" | The Skeptic's why-leave, why-here, why-now probe, made sharper by F7. JD because motivation is scored against this specific role |

### E · Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause first. Hold: "I proposed the change. The uplift was credited to it." Answer slot: which part was hers beyond proposing it, in her own words. If proposing was her part, she says so plainly, and that is a complete answer. Hold through two follow-ups on "proposed" and "credited". Concede specifically, without shrinking the proposal and without claiming the rollout | This is the pressure version of A1. A large figure attracts it, and the quote's own verbs are the honest answer. EXP because it tests attribution |
| E2 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" | Time-boxed answer with three beats, each at its quote's scope: the partner-level revenue model, the volume targets set with cross-org consensus, and SQL and Tableau, plus an outside view of the product lines. She doesn't argue against the internal candidate. Concede: "Someone internal knows Northwind's motions better. I'd close that fast with your team" | Pressure stem. Composure is scored over content. JD because it's fit for the listed role |

### G · Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc: two years in consulting, then nine in product strategy and ops at a large consumer-tech company. Three beats, each in the quote's words: the partner-level revenue model, the volume targets, and the store-surface proposal credited with about $400M. She ends with why this role, in her own words. Every number she mentions gets probed (A1), so she only says what she can defend | It's the near-certain opener, and it sets which numbers Dan probes. EXP because it scores the background as she tells it |
| G2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Answer slot: which tools and for what, in her own words. If the use is in analysis or product work, she says how. If it's personal productivity, she says so plainly. Then she turns it to Northwind: one real question about how Compass gets used. She never claims AI product work her material doesn't show | The JD lists AI as a plus and Compass is a stated priority, so even a casual question is scored (F6). JD tag. Provenance is `[inferred]` because F6's link to the Compass work is the pack's derivation |

### H · Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a senior audience, a moment she didn't fold, and the truth actually landing. "We" for context, "I" for her contribution. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she would handle it | A generic values theme. Northwind's published values could not be fetched, so this can't be mapped to them. VAL tag |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific metric, a specific customer cost, the decision, and what it cost her or the team. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she would handle it | A peer from a monetization background may test metric-versus-customer judgment. VAL tag, generic for the same reason as H1 |

---

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You've spent your career in pricing and monetization. How do you think Compass should be monetized, and where is that debate right now?" | Ties to his path and invites him to talk about his own field. It also shows her where the real decision is being made | [grounded] his career path and the Compass launch, from your notes |
| R2 | "What could someone in this role do in the first month that would genuinely help your team?" | The reciprocity question for a peer. It answers his unspoken "what does this hire cost me?" | [generic] |
| R3 | "Where does the line between Sales Strategy and Emerging Products GTM sit today, and where has it been messy?" | She learns the seam instead of guessing at it, and it follows on from B1 | [generic] |
| R4 | "On the bundling threat: where are deals actually being lost, and does the win/loss data show it?" | It speaks his data language, and it's diligence she genuinely needs | [grounded] the bundling threat, from your research note |
| R5 | "How does the push for profitability shape how much room a new product line gets? Are there payback or margin targets I'd inherit?" | It turns a company priority into the role's real constraints | [grounded] the profitability priority, from your research note |
| R6 | "What from your startup chapter do you still bring to launching something new inside a 3,000-person company?" | A second question tied to his path. It turns the pace probe (D3) into a two-way conversation | [grounded] his startup chapter, from your notes |

---

## Prohibited claims

None of these will be coached, in any cell, drill or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for product lines, or has B2B GTM experience | Inflated form of F1 and F7 | F1's quote at its own scope. The limit is the pack's observation, not words for her: her material says product strategy & ops at a consumer-tech company. The slot in F1 stays inside that role |
| Drove or delivered the ~$400M uplift | Inflated form of F2 ("proposed", "credited") | F2's quote at its own scope: proposed, credited. The slots in A1 and E1 ask only what part was hers |
| Designed partner motions or partner programs | Inflated form of F4 | F4's quote at its own scope: built a revenue model used in negotiations. The slot in D2 stays inside how partners were engaged around that work |
| Set quotas, or ran sales ops | A negative your notes state (F8) | The plain acknowledgment F8 gives: "I haven't done classic sales-ops or quota-setting." No slot. The volume targets are never relabeled as quotas |
| Built or launched AI products | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. The slot in G2 asks only what for |

---

## Sources

- **Provided:** your message, which included the JD highlights, the candidate background, your notes on the interviewer's profile, and your research note on Northwind's priorities and competitive threat. No dossier was consumed.
- **Searches sent (all refused by a permission prompt, nothing returned):**
  - "Northwind Data company values": refused
  - "Northwind Data Compass AI copilot launch" (a check of your research note): refused
  - "Dan Kovac Director of Sales Strategy Northwind Data": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The call was refused. Published values would have themed H1 and H2 and replaced their `[generic]` labels. A values cheat sheet still wouldn't appear, because no values round is expected in this format |
| 2. `Northwind Data interview process GTM strategy` | skipped | Your message already fixes the format: one 60-minute conversation with a peer. The persona weights rest on that |
| 3. `Northwind Data strategy` / recent news | unavailable | The call checked your research note on Compass and was refused. It would have confirmed or corrected the framing in C1, C3, R1, R4 and R5 |
| 4. `Dan Kovac Northwind Data` | unavailable | The call was refused. It would have checked your profile notes and could have surfaced talks or posts for the interviewer read and the reverse questions |
| 5. Representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you gave fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **The full JD text:** finds any mid-list requirements the highlights left out, and every one gets a question and a coverage row.
- **Priya's CV:** her own lines could replace your summaries in the evidence column, and some answer slots (A2, A3, B3, D2) could become story maps.
- **Her answers to the answer slots, sent here outside a drill:** they go into the fit snapshot verbatim and upgrade F1, F2, F4 and F6, along with the questions built on them.
- **An inspectable artifact for F2 or F4,** such as a performance review or a sanitized deck that credits the store-surface change, or a sanitized version of the partner-level model: raises those rows from `medium` toward `high`.
- **Allowing web search:** fills targets 1, 3 and 4. Published values would theme H1 and H2, the Compass and bundling facts would be checked, and Dan's public footprint would be read.
- **A deeper research pass (needs search allowed):** up to 6 more searches and 2 more fetches, several more minutes. It adds a strategy brief, recent org context and a section on the company's current vocabulary.
- **Recruiter guidance:** stated focus areas or any deliverable to prepare would add a build section.
- **Prep time available:** a prioritized schedule sized to the time she has.
- **A tuesday-dossier.md from job-underwriter:** the highest-ROI objection would be derived from confirmed evidence instead of inferred, with a guardrail on each weak area.
