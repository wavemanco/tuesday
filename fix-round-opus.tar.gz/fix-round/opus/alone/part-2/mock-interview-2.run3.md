Searches were blocked, so I'm building the prep pack from what you gave me. Writing it now.
I've built your prep pack: `AtlasFreight_operations-manager_interview_pack.md`. It's based only on your message. My web searches on Atlas Freight were blocked, so nothing in it comes from the company's own pages. Because I don't know who's interviewing you, every interviewer style gets equal weight.

- **The question most likely to come up (A1):** some version of "You lead 3 supervisors today; this job is 12 across four sites, so why are you ready?" Practise this one most. The answer says the gap out loud first ("Twelve is four times the span I lead today"), then stays on what you actually did and gives a 90-day plan in future tense.
- **Power BI (A2):** say plainly that you haven't used it, then give your learning plan. Don't make the gap sound smaller. If you start learning before the interview, you can truthfully say so then.
- **The "5+ years required" line (A3):** your message says 7 years in ops, not 7 years leading people. Know your actual number of leadership years and say it without rounding up.
- **The 40% mis-pick figure (C1, D2):** it's your only number, so expect detailed follow-ups. Know how it was counted, which part was yours, and the weakest assumption behind it.
- **On-time and cost-per-shipment (B1, B2):** your background says nothing about either metric yet, so these are practised as live problems you reason through rather than as stories.

Say the word and I'll play the Skeptic on A1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you know who you're meeting (hiring manager, a peer terminal manager, HR, or a panel), and did the recruiter mention any focus areas or a presentation? The answer changes which questions get the most practice.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** unknown, with no name or relationship given
**Built on:** the JD lines and background in your message. Web research was blocked in this session, so the round type is unknown and nothing here comes from Atlas Freight's own pages. Persona weights are flat (see the persona table).

---

## How to use this pack

- **Personas** describe *how* a question is asked: the style, the pressure, who is asking. **Types** describe *what* is being scored.
- Type key:
  - **JD**: can you do the job as listed, including its gaps
  - **EXP**: does your own experience hold up under follow-ups, and what was actually you
  - **CASE**: a live problem from the role, solved out loud
  - **VAL**: behavioral, showing values through what you did
  - **CO**: what you know about the company
- **Provenance labels:** `[grounded]` means traceable to your message or the JD. `[inferred]` means a derivation, which is named. `[generic]` means a common pattern for this kind of role, with no claim about Atlas Freight or about you.
- **Answer slots** are places where only you know the answer. Each one gives two honest branches. Pick the one that's true, and say it in your own words.
- Guidance is scaffolding, not a script. Each answer should take 90 to 120 seconds out loud.
- Question IDs go by persona: A, B, C, D, E, G, H. **F** is kept for the fit-snapshot rows.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message, "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material talks about warehouse and distribution ops and one site's surge plan. It doesn't mention terminals or four sites, and your words should stay at that scope: "Seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four sites make a probe on multi-site work likely. If you have worked across more than one site, say how, in your own words. If you haven't, say so plainly and return to the surge plan you ran |
| F2 | "drive on-time performance" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A mis-pick rate measures accuracy, not on-time performance. Don't stretch that bridge. Answer slot: if you have tracked or moved an on-time or service measure, say which one and what you did, in your own words. If you haven't, say so plainly and say how you would start measuring it |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material doesn't show cost work. Answer slot: if you have owned or influenced a cost, labor or overtime number, say which one and what part was yours. If you haven't, say so plainly and walk through how you would break the number down (B2) |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Words at the quote's own scope: "I'm currently a senior shift manager over three supervisors." Twelve is four times the span you lead today, and the pack doesn't shrink that. Answer slot: the JD makes a probe on leading supervisors likely, which is different from leading frontline staff. If you've coached, held accountable or developed your supervisors, say how. If not, say so and describe how you run the three today |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | low | [grounded] | discovery | "Solid Excel" is a skill, not reporting you've built. Answer slot: if you've built a report or tracker in Excel that others used, name it and who used it. If not, say so plainly and say what you use Excel for |
| F6 | "build reporting in … Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | No wording can close this gap, and you've already said so. Words: "I haven't used Power BI." Then how you'd learn it, said as a plan and never as something you've done. Don't claim Power BI work, and don't add anything to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops isn't the same as seven years leading. Your material doesn't say how many of those years were in leadership roles. Answer slot: say the number of years you've led people, plainly and without rounding, and name the roles. If it's under five, say the number and return to the current role |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but nothing has been inspected behind it, so expect a probe. Lead with the credential exactly as it is: green belt certified. Answer slot: if your certification included a project, name it. If it didn't, say so |

---

## Persona table

The round type is unknown, and no source describes Atlas Freight's interview process. Weights therefore fall back to a **generic loop pattern (screen → hiring manager → panel) with flat weights**. That pattern is an assumption, not Atlas Freight's documented process. Banks are ordered by where the fit snapshot's gaps sit, not by likelihood. If you learn who you're meeting, the weights change (see the closing question).

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of span (3 → 12 supervisors), sites (one → four) and Power BI | Equal (flat). Gaps F1, F4, F6 and F7 are the clearest targets in the material | Rehearse A1 until it's boring. Build bridges only from your quoted facts, state the limit plainly, and have a concrete ramp plan |
| Case / Strategist (B) | Live problems on on-time and cost-per-shipment, the two JD metrics | Equal (flat). These are the two outcomes the JD names, and F2 and F3 have no evidence behind them, so live reasoning carries the weight | Clarify → objective → segment → approach → metrics → risks. Think out loud |
| Data-Driven Prober (C) | Digs into the 40% mis-pick figure and your Excel claim | Equal (flat). It's the only number in your material, and numbers attract probes | Know what you can and can't say about how the 40% was counted. Name the weakest assumption first |
| Pressure (D) | Time-boxed "why you", "how much was you" | Equal (flat) | Pause, restate the question, anchor in what you actually did, hold through two follow-ups, then concede specifically |
| Conversational (E) | Friendly openers, "tell me about your green belt" | Equal (flat). Casual questions on the JD's "plus" item are still scored | A pre-built 90-second arc. Treat casual questions as scored |
| Values / Behavioral (G) | "Tell me about a time…" questions | Equal (flat). No published values were found, so these are generic themes | Pick real stories with a clear "I". If none fits, say so |
| Peer Evaluator (H) | Another terminal manager or a supervisor asking about seams and credit | Equal (flat). This is a multi-site role, so peers share resources | Propose principles for the seams rather than pretending to know them. Reciprocity |

---

## Question banks

**Highest-ROI prep in this pack: A1.** Some version of the span question will come up. A calm, non-defensive answer that names its own limit changes the interview.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead 3 supervisors today. This job is 12 supervisors across four sites. Why are you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | Hold only what the quotes carry: "Today I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Name the limit before they do: "Twelve is four times the span I lead today." Then give a plan in future tense: what you *would* do in the first 90 days, e.g. meet every supervisor one-to-one, learn each site's numbers, set one common daily review. Answer slot: the four sites make a multi-site follow-up likely. If you've worked across more than one site, say how, in your own words. If you haven't, say so plainly and return to the surge plan. Hold through two follow-ups by going back to these facts, never by adding to them | F4 and F1 are where the JD presses hardest, so this objection will come in some form. JD because it scores the stated span and site requirements. Deepest rehearsal, because it's the likeliest objection |
| A2 | "The role builds reporting in Excel and Power BI, and you haven't used Power BI. How would you handle that?" | JD | [grounded] "never used Power BI" "solid Excel" | Plain acknowledgment first: "I haven't used Power BI." Then the base, in your own words: solid Excel. Then a plan in future tense, e.g. a course before the start date and rebuilding one report you know in Power BI in the first month. If you actually start learning before the interview, you can truthfully say so then, and not before. Don't name Excel features or reports here unless they're true (see C3) | F6 is a gap you stated yourself, and the JD names the tool. JD because it scores a listed requirement. A gap stated plainly up front costs less than one that's found |
| A3 | "The posting says 5+ years of operations leadership. How many of your seven years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Answer slot: give the number plainly in your own words and name the roles that make it up. If it's five or more, say so and stop. If it's fewer, say the number plainly and return to the current role. Don't round up, and don't count non-leadership years as leadership | F7's quote gives years in ops, not years leading people, so the number is the open question. JD because it's the one "required" line |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four terminals dropped this month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is defined (pickup, departure, delivery), since when, and whether it's all lanes or some. Segment: by shift, lane, customer, carrier or driver, freight type. Check that the data is right before acting. Hypotheses: volume or mix change, staffing gaps, dock congestion, late inbound, equipment. Then contain the problem now, find the root cause, and say what you'd report back and when. This makes no claim about your past | The JD's on-time line, where F2 has no evidence behind it. CASE delivery, so reasoning stands in for a record |
| B2 | "Cost per shipment is up across the network. Where do you look first?" | CASE | [generic] | Start with the ratio. It rises if cost goes up or if shipments go down, so check both. Split cost into labor and overtime, equipment, linehaul or fuel, claims and damage. Compare sites. Look for mix shifts. Pick one or two levers, and say how you'd stop a cost cut from hurting on-time performance. This makes no claim about your past | The JD's cost line, where F3 has nothing behind it. The numerator-and-denominator move is what interviewers listen for |
| B3 | "Sketch your first 90 days across four terminals and 12 supervisors. What do you need to know first?" | CASE | [generic] | Learn: walk each site, hold one-to-ones with each supervisor, take baseline numbers on on-time and cost. Standardize: one daily review and one KPI set across the sites. Act: one quick win per site. Then set a reporting cadence (tie it to A2's Power BI plan). Future tense throughout | F1 and F4 asked as a plan rather than a record, which is where you can show readiness without claiming scale |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick figure was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer each part in your own words: how it was counted (what counted as a mis-pick, over what period, compared with what), what it's sensitive to, and which assumption behind it you'd defend least. Name that assumption before they do. Also say which part was yours: the quote says you redesigned the pick path, so if others contributed, say who. "I don't know exactly how it was counted" is an honest branch. Never supply a baseline you can't stand behind | It's the only figure in your material, and numbers attract probes. EXP because it tests the claim, not the job |
| C2 | "Tell me how you redesigned the pick path." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats the quote states: the pick path, which you redesigned, and mis-picks down 40%. Tell them in your own words. Answer slot: the JD's Lean/Six Sigma line makes a method follow-up likely. If you used a Lean or Six Sigma tool for it, name it and how. If you didn't, say so plainly and describe the redesign as you did it | F2 and F8 meet here. EXP because it tests what was actually done |
| C3 | "The role builds reporting in Excel. What have you built in Excel that other people relied on?" | EXP | [grounded] "solid Excel" | Answer slot: if you've built a report or tracker others used, name it, who used it and what it showed. If you haven't, say so plainly and say what you do use Excel for. Don't describe a report you didn't build | F5 is a skill claim, not reporting you've built. EXP with JD content |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who's already run multiple terminals?" | JD | [grounded] "ran the site's peak-season surge plan two years running" "cut mis-pick rate 40% by redesigning the pick path" | Pause, then give two facts in your own words: the surge plan two years running, and the pick path redesign that cut mis-picks 40%. Add one sentence on what you'd bring, in future tense. Don't run down the other candidate, and don't claim multi-site work. If pressed, concede their edge specifically ("they'd have run more sites") and hold on what you did | F1's scope gap delivered under time pressure. JD because it scores fit against the role's scale |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold what the quote says: you redesigned the pick path. Answer slot: if others built, tested or ran it, name them and their part. If the redesign was yours alone, say so plainly. Concede specifically, never vaguely ("the team helped") | Attribution probes exist to catch inflation, and this rehearses candor. EXP |
| D3 | "Running a surge plan twice sounds like following a template. What did you actually decide?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: if decisions in the plan were yours, name one and how you made it. If the plan was set above you and you carried it out, say so plainly. "Ran" stays "ran". Hold through two follow-ups, then concede the specific limit | F1's evidence, challenged on whose decisions they were. EXP with Pressure delivery |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc built only from these facts: seven years in warehouse and distribution ops, now senior shift manager over three supervisors, the pick path redesign, the surge plan two years running, green belt. Answer slot: end on why this role and why terminal ops now, in your own words | The biography question is near-certain and is scored for economy. EXP |
| E2 | "Tell me about your green belt. What did you do for it?" | JD | [grounded] "green belt certified" | Answer slot: if your certification included a project, name it and your part in it. If it didn't, say so plainly and say where you'd apply the method here, in future tense. Don't describe black-belt-level work | F8 is the JD's "plus" item, and casual questions on plus items are scored. JD |
| E3 | "What do you know about Atlas Freight?" | CO | [generic] | Research couldn't run for this pack, so read their website and careers page yourself before the interview. Say only what you read and where. Don't guess sites, customers or numbers. Then turn it into a question (see reverse questions) | A homework check. CO, and `[generic]` because the pack holds no facts about Atlas Freight |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time a supervisor on your team was underperforming. What did you do?" | VAL | [grounded] | Selection scaffold: pick a real case with a clear expectation, a conversation you had, and a follow-through. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the JD's "lead a team of 12 supervisors". VAL because it scores behavior, not credentials |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a named stake, the moment you said it, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem. No company values were found to theme it |
| G3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a real trade-off, what you chose and why, and the cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard stem. It fits an on-time and cost role, where metrics and customers can pull apart |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "If two terminals both need the same drivers on a peak day, how would you settle it?" | CASE | [generic] | Propose principles: agree priority rules ahead of time (customer commitments, service at risk), decide with data, escalate early, and review afterwards. Give before you take: say what you'd offer the other site. This makes no claim about your past | A multi-site role means shared resources. It scores partnership with equals |
| H2 | "How do you handle credit when an improvement spans shifts or teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use "we" for context and "I" for the redesign, as the quote says. Answer slot: if other shifts or people were part of it, name them and their share. If they weren't, say so and give how you'd share credit in future | Tests whether the hire adds to or reduces peers' load. VAL. Pairs with D2 |
| H3 | "What would you need from your supervisors in your first month, and what would they get from you?" | CASE | [generic] | Reciprocity: what you'd ask for (honest numbers, early warnings, their ideas) and what they'd get (clear priorities, cover at peak, a voice in the KPIs). Future tense | F4's span, asked from the other side of the relationship |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites (F1) | A1, B3, D1, D3 |
| Drive on-time performance (F2) | B1, C2 |
| Cost-per-shipment down (F3) | B2 |
| Lead a team of 12 supervisors (F4) | A1, B3, G1, H3 |
| Reporting in Excel (F5) | C3 |
| Reporting in Power BI (F6) | A2 |
| 5+ years operations leadership (F7) | A3 |
| Lean/Six Sigma a plus (F8) | E2, C2 |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is on-time performance measured here, and where does each terminal stand today?" | It goes straight to the JD's first metric and shows you'll ask for the definition before acting on it |
| "What goes into cost per shipment in your numbers?" | It shows you know the ratio has two halves, which is the same move as B2 |
| "Of the 12 supervisors, who's newer and who's ready for more?" | It signals you're already thinking about the team as people, not a headcount |
| "What reporting exists today, and how much of it lives in Power BI?" | It's honest about your gap and tells you how steep the learning curve will be |
| "What would make the first 90 days a clear success from your side?" | It gives you their own scorecard and lets you test your B3 plan against it |
| "Is there a Lean or continuous-improvement effort running across the sites?" | It connects your green belt to their operations without overselling it |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has run terminal or multi-site operations | Inflated form of F1 | F1's quotes at their own scope. The pack's observation, not words for you: your material says warehouse and distribution ops and the site's surge plan, not terminals or four sites. The A1 and D1 slots stay inside that scope |
| Has led a large supervisor team | Inflated form of F4 | "I'm currently a senior shift manager over three supervisors." |
| The 40% mis-pick cut as an on-time or cost result | Inflated form of the F2 quote | The quote at its own scope: mis-picks, cut 40%, by redesigning the pick path |
| Has built reporting or dashboards | Inflated form of F5 | "Solid Excel", as said. The C3 slot asks only what you've built |
| Has used Power BI | A negative you stated, F6 | "I haven't used Power BI." No slot |
| Seven years of operations leadership | Inflated form of the F7 quote | "Seven years in warehouse and distribution ops." The A3 slot asks for the leadership number |
| Has led Six Sigma projects, or holds a higher belt | Inflated form of F8 | "Green belt certified." The E2 slot asks only about your certification project |

---

## Sources

- **Provided:** your message, containing the JD lines and your background.
- **Searches sent:**
  - `Atlas Freight regional logistics company values`: refused
  - `Atlas Freight operations manager interview process`: refused
  - `Atlas Freight terminals news 2026`: refused
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Refused. It would have supplied official value names for a values cheat sheet and themes for the G bank. Without it, G is generic |
| 2. `Atlas Freight interview process operations` | unavailable | Refused. It would have named the rounds and set the persona weights. Without it, weights fall back to a generic, flat loop pattern |
| 3. `Atlas Freight strategy` / recent news | unavailable | Refused. It would have grounded E3 and a company-specific CASE question in current priorities. Without it, those stay generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form |
| 5. representative Operations Manager JD | skipped | The JD lines you supplied set the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Who you're meeting and in what round** (hiring manager, peer terminal manager, HR or recruiter, panel) → real persona weights instead of flat ones, and banks re-ordered and resized to match.
- **The interviewer's name** → a reading of their public professional profile, persona weights adjusted to it, and a reverse question tied to their own career path.
- **The recruiter's prep email**, or any note on focus areas or a presentation → coverage of anything pre-declared, plus graded-deliverable build sections.
- **The full JD text** → more requirements turned into fit rows and JD questions. The current rows rest on a short excerpt.
- **Web search allowed** → targets 1 to 3 run: Atlas Freight's values (and a values cheat sheet, if a values round shows up), its interview process, and recent news for a company-specific CO and CASE question. A deeper pass is also available: up to 6 more searches and 2 more fetches, taking several more minutes.
- **Your answers to the answer slots in F2, F3, F5 and F7** (on-time and cost work, Excel reports, years leading people) → those rows can move from `discovery` toward `grounded` evidence, and B1, B2, C3 and A3 become story-mapped.
- **Your green belt certificate, or the before-and-after mis-pick report** → F8 and the C1 figure move from `medium` toward `high`, because there's an artifact behind them.
- **A tuesday-dossier.md from the job-underwriter skill** → the highest-ROI objection based on checked evidence rather than inferred, plus a prohibited list it has verified.
