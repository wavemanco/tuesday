Searches done — Saltmarsh publishes its values and its interview format. I'm reading both pages now, then I'll write the pack.
I've built your prep pack. It's in your working folder as **Saltmarsh-Games_live-operations-producer_interview_pack.md**. I based it on the format Saltmarsh publishes on its careers page: the final interview is one 60-minute session with the hiring manager, called the "Outage Hour". You work through a simulated outage during a live event, and then there's a conversation about their values. There's no take-home.

What the research turned up, and what it means for you:
- **Strategy:** in September 2026 Saltmarsh announced Project Larkspur. From February 2027 both mobile titles move to a season pass with one shared events calendar. That runs straight into your stated gap ("never worked on a game with in-app purchases"). The pack expects this objection to come up in some form and gives it the deepest rehearsal (question B1).
- **Tobias:** he used to be a QA lead at a console studio. His GDC 2026 talk is "Patch Notes Are a Promise", and it lines up with the value "Ship the Patch Not the Promise". So the release checklist you wrote is your strongest match, and he's likely to ask about it in detail.
- **Values:** the three are Players Before Plans, Ship the Patch Not the Promise and Leave the Build Greener. The last one names the checklist in its own definition.

The pack includes a one-evening prep plan, since the interview is tomorrow. It also has a 22-question bank where every suggested answer is tied to your own sentences, and a list of claims it deliberately won't coach you to make.

If you want a live rehearsal, I can play the interviewer on B1, the season-pass objection.
I can also save a tuesday-dossier.md file that records the gaps this prep turned up, so you can bring it to later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The hiring manager, going by Saltmarsh's interviewing page (see Reading the interviewer)
**Session:** 60 minutes, Friday. Saltmarsh's careers page calls this the **Outage Hour**: "a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."

---

## How to use this pack

- **Personas** describe how a question is asked: who asks it and in what register. **Types** describe what is being scored.
- Type key:
  - **VAL**: whether your past behaviour shows Saltmarsh's *published* values
  - **EXP**: whether what you said about your work holds up under questioning, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: company and strategy knowledge (Project Larkspur, the season pass, the shared calendar)
  - **CASE**: a live problem from the role. In this loop that is the outage tabletop
- Provenance labels: `[grounded]` traces to your message, the JD, or research listed in Sources. `[inferred]` is derived, and the derivation is named. `[generic]` is a role-family pattern with no claim about Saltmarsh.
- **Answer slot** means the pack doesn't know the answer and won't make one up. It names a probe that is likely and gives you two honest branches. Fill it from your own memory, or say plainly that it didn't happen.
- Question IDs: A, B, C, D, E, G, H go by persona. **F1 to F9 are fit-snapshot rows, not questions.**
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage: one evening, because the interview is tomorrow

1. **B1, out loud, three times.** This is the season-pass and in-app-purchase objection, and it is the highest-ROI prep in the pack. Get your first sentence down until it's boring.
2. **A1 to A3, the tabletop.** Rehearse the structure (clarify, contain, communicate, decide, record) on one made-up outage. This is half the hour.
3. **C1 to C3.** One answer per published value. Know the three names exactly.
4. **D2 and G2, your release checklist.** Tobias came up through QA, so expect him to go deep on it.
5. **Reverse questions R1 and R3.**

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | The years are there, as an associate producer. Your material doesn't say whether the main title was run as a live service, so say your title exactly as it is. Answer slot: the JD's live-service line makes a probe on how the main title was run likely. If you'd call it a live-service game, say what made it one, in your own words. If you wouldn't, say so plainly and stay with the weekly content-drop calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. Lead with the sentence as written: "I ran the weekly content-drop calendar for our main title for the last two years." It's a statement with nothing inspected behind it, so expect a probe on how a week's drop was decided (D3 holds that slot) |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title's weekly content drops. It doesn't say live events across two titles, and the words stay there. Answer slot: the JD's two-title line makes a probe on running more than one title likely. If your calendar ever had to share dates, people or builds with another title, say how, in your own words. If it didn't, say so plainly and stay with the one title's calendar you ran |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | discovery | The JD asks for coordination. Your stated negative is about leading, and your material says nothing either way about coordinating. If asked about leading, the words are "I haven't led a team." Answer slot: if design, art, engineering or community work fed the calendar you ran, say which teams and what passed between you, in your own words. If it didn't, say so plainly and return to the calendar |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting monthly numbers isn't owning a post-event review or choosing its KPIs. The words stay at their scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "own the KPIs" line makes a probe on where the numbers came from likely. If you compiled them or chose what was shown, say how, in your own words. If someone else did, say so plainly and stay with presenting them |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap. Lead with the sentence: you wrote it, and your QA team still uses it. Nothing has been inspected behind it, and the interviewer came up through QA, so expect D2 and G2 |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in kind. Lead with the sentence. Answer slot: the JD's retention line makes a probe on which measures likely. Name the ones you presented and how they were counted, in your own words. If you don't know how they were counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | A checklist is written work. Your material doesn't show other writing, such as patch notes or reports, so the words stay at the checklist. Answer slot: if you wrote other things for your team or for players, say which, in your own words. If not, say so and stay with the checklist. A3 lets you show this skill live |
| F9 | Season-pass model on both titles from February 2027, per Saltmarsh's Project Larkspur announcement (September 2026). Not a JD line | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap that wording can't close, and you have already said so. Words: "I haven't worked on a game with in-app purchases." Then say how you'd learn it, as a plan, never as a past. This pack hasn't established whether Saltmarsh's pass is paid. Season passes in mobile games commonly are, and that's why this row exists |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles (F3) | A5, B4, D3 |
| Coordinate design, art, engineering, community (F4) | B3, H1, A1 |
| Own the post-event review and its KPIs (F5) | A4, D1 |
| Manage the release checklist with QA (F6) | D2, G2, H2, C3 |
| 3+ years producing live-service (F1) | B2, E1 |
| Running a content calendar (F2) | D3, A5 |
| Player-retention metrics (F7) | D1, A4 |
| Clear written communication (F8) | A3, C2 |
| Season pass and in-app purchases, from strategy not the JD (F9) | B1, G1 |

---

## Reading the interviewer

| What | Detail | Source |
|---|---|---|
| Role | Head of Live Operations, Saltmarsh Games | GDC 2026 talk listing |
| Career pattern | Previously a QA lead at a console studio | GDC 2026 talk listing |
| Public theme | Talk titled "Patch Notes Are a Promise". The listing summarises his argument as: a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk listing |
| Implication 1 | Release discipline will be probed in detail: what's on your checklist, and what happens when QA says no. See D2, G2, H2 | Reading of the rows above |
| Implication 2 | His talk's theme and the value "Ship the Patch Not the Promise" say the same thing: announce what is built. Expect it in the tabletop's comms step (A3) and in the values half (C2) | Reading of the rows above and the values page |
| Shared vocabulary | Release checklists and QA. Your material has one sentence on this, F6: "Wrote the release checklist our QA team still uses." Offer it in those words, no bigger | F6 |
| Shared jump | None offered. His path runs from QA to live ops, and nothing in your material puts you on the QA side, so the pack doesn't build a career parallel | — |

---

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | The outage tabletop, then follow-ups | **Highest.** He's the hiring manager, and Saltmarsh's own page puts a live-incident tabletop in this exact hour | Clarify, then contain, communicate, decide, record. Think aloud and challenge one premise respectfully |
| Skeptic (B) | "You haven't done X", season pass, associate-to-producer step | **High.** The hiring-manager prior plus F9, a stated gap that runs into the company's announced strategy | Name the limit first, in your own words, then give a ramp plan said as a plan |
| Values / Behavioural (C) | The second half of the hour | **High.** The careers page names a values conversation in this session, and the three values are published | One story or one honest scaffold per value, each value said by its exact name |
| Data-Driven Prober (D) | Checklist contents, retention numbers | **Medium.** Interviewer's QA background plus a JD that asks you to own KPIs | Say what you know about how numbers were counted. Say plainly what you don't |
| Conversational (E) | The opener, "why Saltmarsh" | **Low to medium.** It will happen, briefly, in a 60-minute session with two set halves | A 90-second arc built only from your four sentences |
| Pressure (G) | Time-boxed "why you", attribution | **Low.** No source signals it, but the tabletop's pace can feel like it | Pause, restate, hold through two follow-ups, then concede specifically |
| Peer (H) | Seams with QA, community and engineering inside the tabletop | **Low.** No peer is in the room, but the scenarios cross teams | Propose seam principles. Don't claim to know Saltmarsh's seams |

The weights rest on Saltmarsh's published interview format, not on a generic pattern.

---

## Question banks

### A. Case / Strategist: the Outage Hour tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a weekend event, and the event store won't load for a chunk of players. Walk me through your first fifteen minutes." | CASE | [inferred] | Clarify first: who is affected (platform, region, share of players), since when, and whether anything shipped recently. Contain: get the right engineer, open one incident channel, name who decides. Communicate: tell community what's known and when the next update comes. Decide: does the event clock keep running? Record: a timeline, starting now. Say the structure aloud before you fill it in. The question asks about no past, so the guidance claims none | The careers page says this session holds a live-incident tabletop on a simulated outage during a live event. The scenario wording is the pack's own, derived from that line. CASE because it scores live structure |
| A2 | "Engineering says the fix needs a client update — three days out. The event ends tomorrow. What do you do with the event?" | CASE | [inferred] | Name the options: extend, pause, compensate, or let it end. Weigh each against what players lose and what the extension costs the calendar after it. Then pick one and say why. "Players Before Plans" is the published value for exactly this tradeoff (when the calendar and the players disagree, the players win), so use the name if it fits. Say the risk of your pick out loud | The obvious follow-up to A1, and the place the values page and the tabletop meet. CASE |
| A3 | "Write me the player-facing message for the first hour, out loud. What goes in and what stays out?" | JD | [inferred] | Say what is broken, who is affected, what is being done, and when the next update comes. Leave out any fix time engineering hasn't confirmed, and any compensation not yet decided. That is the "Ship the Patch Not the Promise" line, and it matches the interviewer's talk title. Keep it short and plain | Scores the JD's "clear written communication" (F8), live. JD content with CASE delivery. Tagged JD so that requirement is covered by a JD-scored question |
| A4 | "The outage is fixed. Run the post-event review: who's in the room, what do you measure, what comes out of it?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Structure: timeline, impact (players affected, event participation, retention against an ordinary week), what went well, what didn't, owners and dates for each fix, and what changes on the checklist. If you want a reference point from your own work, use F5's sentence in its own words: you presented the monthly retention numbers to the studio head. Don't describe past post-event reviews your material doesn't mention | The JD's post-event-review line (F5) asked as a live problem. CASE because it asks for a plan, not a record |
| A5 | "From February both titles share one events calendar. Sketch how you'd plan a month of it." | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify: the season-pass cadence, whether the titles share players, and which people and builds are shared. Then structure: fixed beats first (season start and end), then events that avoid clashing on shared teams, then buffers for QA. One honest anchor: "I ran the weekly content-drop calendar for our main title for the last two years." That's one title, said as one title. Ask which constraint matters most to him | Project Larkspur (Sept 2026) is the company's current strategy and directly reshapes this role. CO because it tests whether you've done the homework. CASE delivery. F2 and F3 |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Both titles go to a season pass in February. You haven't worked on a game with in-app purchases — how do you get up to speed?" | CO | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | **Highest-ROI prep in this pack.** First sentence, before he finishes the point: "I haven't worked on a game with in-app purchases." Then what you did do, in its own words: you ran the weekly content-drop calendar for your main title for two years, and you presented the monthly retention numbers to the studio head. Don't claim either one prepares you for monetisation; let him draw that. Then the plan, in future tense: who you'd sit with first, what you'd read, and which past season you'd study. **Follow-up 1:** "So you'd be learning on our live game?" Hold: yes, that part is new, and the calendar is what you bring. **Follow-up 2:** "Why take that risk?" Concede the specific risk plainly, and don't fold on what you did | F9 is a gap you stated, and the company's announced strategy runs straight into it. Some form of this will be asked. CO because the premise is Larkspur, not the JD. It also scores honest self-assessment |
| B2 | "You've been an associate producer. This is a producer role. What's the step up?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say your title exactly: four years as an associate producer at a puzzle-game studio, and the last two running the weekly content-drop calendar for the main title. Answer slot: the JD's "plan and run" line makes a probe on whose decisions those were likely. If calendar decisions were yours to make, say which ones and how, in your own words. If they were made above you, say so plainly and describe how you ran it. Then say what you want to own next, as a want, not a record | F1's title and the role's title don't match, and the 3+ years requirement is where that gets tested. JD because it scores a stated requirement |
| B3 | "This role coordinates design, art, engineering and community. You haven't led a team — how does that work day to day?" | JD | [grounded] "Never led a team" | If he presses on leading: "I haven't led a team." Don't argue the premise. Answer slot: if design, art, engineering or community work fed the calendar you ran, say which teams and what passed between you, in your own words. If it didn't, say so plainly, return to the calendar, and say how you'd set up coordination as a plan | F4. The JD asks for coordination, your stated negative is about leading, and this question lives in the gap between them. JD |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" | Pick one real answer and say it plainly. The pack's observation is that your material thins out at two titles (F3) and at owning the post-event KPIs (F5), and you've already named in-app purchases yourself. Choose the one you actually believe, give a one-line plan, and stop. Don't pick a fake weakness | A Skeptic stem. The answer has to agree with B1, or the two will contradict each other in one hour. JD |

### C. Values / Behavioural: the second half of the hour

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Players Before Plans — tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a time a planned drop or date ran into what players were doing or saying. It needs what the plan was, what the players' side was, what you did, and what changed afterwards. Your material shows the calendar, not such a moment. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the weekly calendar you ran, in those words), or how you'd handle it | The value's own definition is "when the calendar and the players disagree, the players win." A values conversation is in this session. VAL |
| C2 | "Ship the Patch Not the Promise — tell me about a time you announced only what was actually built." | VAL | [grounded] | Selection scaffold: a time something was ready to announce before it was ready to ship, and you held the announcement back or cut it down. It needs what was promised or asked for, what was actually built, and what you said. If no such time comes to mind, say so plainly, then say how you'd handle it, using A3's approach | This is the published value that matches the interviewer's talk, so it's likely to get extra weight. VAL. No candidate claim, so the label stands alone |
| C3 | "Leave the Build Greener — what have you left better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story map, F6: you wrote the release checklist, and your QA team still uses it. Those are the two beats. Tell them in your own words. Answer slot: the value says "better than it found them," which makes a probe on what existed before likely. If there was an earlier checklist and yours replaced or changed it, say what changed. If there was none before, say so plainly and let "still uses" be the point | The value's definition names the checklist outright: "every release leaves the codebase and the checklist better than it found them." Your strongest match in the pack. VAL |
| C4 | "When did you tell leadership something they didn't want to hear?" | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: a named stake, the person senior to you, what you said, and how the relationship stood afterwards. Your material shows that you presented monthly retention numbers to the studio head. It doesn't show whether any month's news was unwelcome. If no such time comes to mind, say so plainly, then give that nearest sentence in its own words, or how you'd handle it | A Values-persona stem. It fits the "Ship the Patch Not the Promise" theme of saying what's true. VAL |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the retention numbers you presented to the studio head." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Start from the sentence: monthly retention numbers, presented to the studio head. Answer slot: the JD's retention and KPI lines make probes likely on which measures, how they were counted, and who compiled them. Answer each in your own words. If you didn't compile them or don't know how they were counted, say so plainly. That's a credible answer, and a guessed method isn't | F5 and F7. JD because it scores the retention-metrics requirement. EXP delivery |
| D2 | "Tell me about your release checklist. What's on it, and why does QA still use it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | You wrote it, and QA still uses it. Name its items from your own memory. The pack doesn't know them and won't supply them. On "why still": say what you actually know about why. If you don't know, say so plainly rather than guess. Offer to talk through how you'd adapt it for two titles, as a plan | F6 is your most specific claim, and the interviewer's QA background makes it a magnet. EXP |
| D3 | "How did you decide what went into a week's content drop?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: the JD's "plan and run" line makes this probe likely. If the contents of a week were yours to decide, say how you decided, in your own words. If they were decided by someone else, or there was no real choice, say so plainly and describe what running the calendar involved | F2. The JD asks you to plan, and your sentence says you ran it. This question tests the space between those two words. JD |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc from those four sentences only: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for the main title, the release checklist QA still uses, and presenting monthly retention to the studio head. End on why live ops and why now, in your own words | Opener for almost any session. It's scored on economy, and it sets the scope every later answer has to match. EXP |
| E2 | "Why Saltmarsh, and why now?" | CO | [grounded] | Answer slot for your motivation: say it in your own words. What you can lawfully cite is what you read: Project Larkspur's shared calendar and the three values, by name. Don't claim history with their titles unless you actually have it | Light-register, but scored on homework. CO. No claim about your past |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who's already run monetised live events?" | CO | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Pause. Concede first and specifically: "I haven't worked on a game with in-app purchases." Hold on what you did: two years running the weekly content-drop calendar, and a release checklist your QA team still uses. Stop at sixty seconds. If he pushes twice, hold the same two facts and don't add new ones | B1's objection under a time box. Rehearsing it once means it doesn't land as a surprise. CO, on the Larkspur premise |
| G2 | "That checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote it." Answer slot: if others contributed items or reviewed it, say who did what, in your own words. If it was yours alone, say so. Don't claim more about how widely it's used than "our QA team still uses" | An attribution probe on F6, from the persona's own stem. EXP |

### H. Peer (cross-team seams inside the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Community wants to announce next week's event; engineering hasn't confirmed the build. What do you do?" | CASE | [generic] | Find out what's confirmed and when it will be, and agree a holding message with community that announces only that. Set a decision time. Propose the principle (announce from what's built), not Saltmarsh's process, which you don't know | Coordination (F4's requirement) as a live seam. `[generic]`: a pattern for the problem, nothing about Saltmarsh's teams. CASE |
| H2 | "QA says the release isn't ready; design says it has to ship for the event. Your call." | CASE | [generic] | Clarify what QA found and how bad it is. Ask whether the event can run without the risky part, and what slips if it waits. Decide, say who you'd tell, and name what goes on the checklist afterwards. No claim about your past is needed | The release-checklist requirement (F6's) as a live conflict. Likely given the interviewer's QA background. CASE |

---

## Values cheat sheet

The values half of the Outage Hour is on Saltmarsh's careers page, and the values come from their published page.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players pull apart, the players come first | Selection scaffold (C1). F2's sentence is the nearest material: "I ran the weekly content-drop calendar for our main title for the last two years." It shows the calendar, not a disagreement. If no such time comes to mind, say so plainly and say how you'd handle it |
| Ship the Patch Not the Promise | Announce what exists, not what's hoped for | Selection scaffold (C2). If no such time comes to mind, say so plainly and walk through A3's approach instead |
| Leave the Build Greener | Each release leaves the code and the checklist better than before | F6: "Wrote the release checklist our QA team still uses." (C3) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your GDC talk you argued a live team is judged by how often its patch notes describe what actually shipped. How does your team track that today?" | Shows you researched him, not just the company, and opens his own theme |
| R2 | "You moved from QA lead into running live ops. What from QA do you still see paying off in how the team ships?" | Tied to his path. Turns the interview toward a peer conversation |
| R3 | "With both titles on one events calendar from February, what does this producer own before the merge, and what after?" | Shows you know Project Larkspur and are thinking about the role's real scope |
| R4 | "The JD mentions two titles, and the Larkspur announcement retires per-title event teams. How will this role sit inside the single live-ops group?" | Raises a real structural question from two public sources, without assuming the answer |
| R5 | "What KPIs does the post-event review report today, and which one do you wish it reported?" | Goes straight at a JD responsibility (F5) and invites his opinion |
| R6 | "What would a strong first 90 days look like for this producer?" | Gives you the success criteria, and his answer tells you where the season pass sits in his priorities |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on in-app purchases or monetisation | A negative you stated (F9) | "I haven't worked on a game with in-app purchases." Then a plan, said as a plan |
| Has led a team | A negative you stated (F4) | "I haven't led a team." |
| Producer title, or four years "producing live-service games" | Inflated form of F1 | F1's quotes at their own scope: an associate producer, and the weekly content-drop calendar. The pack's observation: your material doesn't say the title was run as a live service. B2's slot stays inside the calendar you ran |
| Ran live events across multiple titles | Inflated form of F3 | F3's quote at its own scope: one title, weekly content drops. F3's slot stays inside that calendar |
| Owned post-event reviews and their KPIs | Inflated form of F5 | F5's quote at its own scope: you presented the monthly retention numbers to the studio head. D1's slot asks only where those numbers came from |
| Wrote more than the checklist, or the checklist is used beyond your QA team | Inflated forms of F6 and F8 | F6's quote: "Wrote the release checklist our QA team still uses." |

---

## Sources

**Provided:** the JD and your background, both pasted in your message. No dossier was present.

**Searches sent:**
1. `Saltmarsh Games values` → saltmarshgames.com/values
2. `Saltmarsh Games interview process producer` → saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile studio news 2026` → saltmarshgames.com/news/project-larkspur (search snippet only, page not fetched)
4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` → talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only)

**Pages fetched:** saltmarshgames.com/values; saltmarshgames.com/careers/interviewing

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and C1 to C3: three values by official name and definition |
| 2. `Saltmarsh Games interview process` | yes | Loop established: the Outage Hour, one 60-minute hiring-manager session with a tabletop and a values conversation. Persona weights, bank A, values-round detection |
| 3. `Saltmarsh Games` recent news | yes | Project Larkspur: season pass, shared calendar from February 2027, single live-ops group. Moved F9, A5, B1, G1, R3, R4 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, R1, R2, Prober weight |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Deeper research, L2** (up to 6 more searches and 2 more fetches, several more minutes): the full Larkspur page and the full talk instead of snippets, the two titles' current events, and recent org context. Sharpens A5, B1 and R3 and adds a strategy brief section
- **The recruiter's prep note, or confirmation that Friday is the Outage Hour**: confirms the persona weights, which currently rest on the careers page
- **Your answers to the answer slots in F1, F3, F4, F5, F7 and F8**: each one becomes quoted evidence, and B2, B3, D1, D3 and the values scaffolds get story-mapped answers
- **The release checklist itself, or a sample week of the content calendar**: in producer work these are the artifacts an interviewer can actually look at, and they'd raise F2 and F6 from medium to high
- **Your CV**: dates, the title's name, and any lines your message didn't mention, so new rows are quoted from the CV
- **A tuesday-dossier.md, if you have one**: verified evidence and a checked objection list. It would sharpen the pack, but nothing here depends on it
