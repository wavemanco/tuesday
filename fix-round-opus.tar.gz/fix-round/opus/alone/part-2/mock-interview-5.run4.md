Running the L1 searches in parallel.
I've saved your prep pack to `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-5-denied-ed53c676/Kelverton-Rail_senior-partnerships-manager_interview_pack.md`. It's built from the recruiter's email and the background you gave me. I had no job description, and my web searches were all blocked by this session's permissions. So everything in it about Kelverton itself is generic, and that's where the market report comes in.

**Highest priority: the commercials question.** Ross is very likely to ask why they should trust you with a commercial number when you've never carried a direct quota. That's question B1 in the pack.
- **How to answer:** state the gap plainly first, in your own words from your message: "I haven't carried a direct quota. My number was influenced revenue, roughly £4M."
- **How to hold it:** then explain how that £4M was counted, and propose how you'd want to be measured at Kelverton.
- **Get ahead of it:** raise the difference between influenced and sourced revenue yourself in the POV, before Ross does.

**The 15-minute POV:**
- **Structure:** five timed beats. Define what "operator partnerships" means to you, pick one finding from the report to build on, set out two or three moves over the 18 months, cover commercials, and close on what changes for the operators themselves.
- **Moves to choose from:** three, each with the weakness you should admit out loud. There's also one thing to say you deliberately *wouldn't* do, which shows judgment.
- **The report:** Deepa and Ross have read it too, so repeating it back will sound like homework. Use one finding to show you've read it, then depart from it once and give your reason.

**Your four hours** are mapped out at the top of the pack. Roughly: 45 minutes pulling specifics from the report, 75 minutes building the POV and saying it aloud twice to time, then the commercials and rail-credibility questions.

**What not to say:** don't round "bus and light rail network planning" up to "rail experience", and don't call the £4M sourced revenue or an annual figure. The pack lists these phrasings and gives the accurate version of each.

If you'd like a practice run, I'll play Ross and push you on B1 with follow-ups.
I can also save a `tuesday-dossier.md` file recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, I can convert it.

Can you paste the job description, or your CV? Either would let me ground the generic rows in Kelverton's actual requirements and replace guesswork with your own lines.

Would you like to allow web search? Then I can run the standard research pass on their values, current strategy, and Deepa's and Ross's public professional profiles. I can also run a deeper pass if you want one: up to 6 more searches and 2 page reads, adding several minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel, Tuesday
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)
**Format, from the recruiter:** a 15-minute spoken POV with no slides, then Q&A, with "Ross will push on commercials"
**Built from:** the recruiter's email as you quoted it, and the background in your message. No JD. The market report is with you, not me. All web searches were refused by this host's permissions, so nothing in this pack about Kelverton, its market or its interviewers comes from research. Every company-level line is labelled `[generic]`, and the report is where you fill those lines in.

---

## How to use this pack

- **Personas** describe how a question is asked: who asks it and in what register. **Types** describe what the question is scoring.
- **Type key:**
  - **VAL**: values and behaviour, i.e. what past choices show about how you work
  - **EXP**: work-experience deep-dive, i.e. whether your claims hold up and what was actually yours
  - **JD**: role-driven, i.e. whether you can do this job, gaps included
  - **CO**: company and strategy, i.e. how well you know their market and whether you can think at their level
  - **CASE**: a live problem from the role, solved out loud
- **Provenance:** `[grounded]` means traceable to something you or the recruiter wrote. `[inferred]` means derived from such a source, with the derivation named. `[generic]` means a role-family pattern with no claim about Kelverton.
- **Guidance is scaffolding, not a script.** Say it in your own words. Anything the pack can't trace to your own sentences becomes an **answer slot**: an instruction with two honest branches. If it was yours, say how. If there was no such thing, say so plainly.
- Question IDs go by persona: A, B, C, D, E, G, H. Letter F is skipped so bank IDs don't clash with the fit-snapshot rows F1–F8.

---

## Prep triage: your four hours

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 45 min | Pull 3–4 specifics from the market report: one finding you'll build on, one you'd sequence differently, plus whatever it says about how operators buy and what they struggle with. Write each on one line | POV build, A4, E2 |
| 2 | 75 min | Build the POV from the frame below. Pick two theses, write the concession for each, then say the whole thing aloud twice with a timer. Hard stop at 14 minutes, leaving one minute spare | POV build |
| 3 | 45 min | Rehearse the highest-ROI question, B1 (quota versus influenced revenue), through both follow-ups. Then C1, defending the £4M. Fill in the answer slots out loud | B1, C1, D1 |
| 4 | 30 min | Rehearse the rail-credibility question and the transfer question | B2, B3 |
| 5 | 20 min | Commercial cases Ross is likely to run | C3, D3, G1 |
| 6 | 15 min | Pick three reverse questions, one aimed at each panellist plus one spare | Reverse questions |

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | A payments ISV channel is adjacent to operator partnerships in rail. It is not the same thing, and your words stay at the scale they were said: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the 18-month brief makes a probe on how you planned that growth likely. If the sequencing or the partner choices were yours, say which and how you decided, in your own words. If they weren't yours, or there was no plan, say so plainly and stay with the channel you ran |
| F2 | "Ross will push on commercials" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Influenced revenue sits next to the commercial accountability Ross will test, and it stays influenced: "roughly £4M of influenced revenue." Don't give a period for it unless you're sure of one. Answer slot: how it was counted, what it was sensitive to, the assumption behind it you'd defend least, and which part was yours. Give each in your own words, and if you don't know how it was counted, say so |
| F3 | Direct ownership of a revenue number, a common expectation in senior partnerships roles | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | You've said this gap plainly, and no rewording closes it. Words: "I haven't carried a direct quota. My number has been influenced revenue." Anything beyond that is a plan, said as a plan, never as experience. Nothing is added to make the gap look smaller |
| F4 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | This is adjacent work from the consulting side of the table, on bus and light rail rather than train operators. Words: "I spent five years in transport consulting on bus and light rail network planning, so I know the operator world from the other side." Answer slot: if any of that planning work put you alongside operators' own planners, say what you saw of how they plan or decide, in your own words. If it didn't, say so plainly and stay with network planning |
| F5 | Experience selling into rail, a common expectation in sector-specialist partnerships roles | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | You've said this gap plainly too. Words: "I haven't sold into rail." Then a ramp plan, said as a plan. Bus and light rail planning (F4) is the adjacent row. It doesn't count as rail selling, and neither does "rail experience" |
| F6 | Fluency in the company's strategy and market | "She also attached the market report their strategy team circulated internally last quarter, which I've read." — your message | medium | [grounded] | discovery | Having read the report doesn't yet show what you'll do with it, and that's the gap. Answer slot: name the finding you'd build on and the one you'd challenge, in your own words, taken from the report itself |
| F7 | Building and scaling a partner programme | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | none | No gap, but this is a self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you ran the channel and took it from 6 partners to 40. The channel had 6 partners when it became yours |
| F8 | Senior partnerships experience | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | none | Nine years, in your own figure. Let the work carry the seniority rather than the number of years |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| F1 — 18-month operator partnerships POV | POV build, A1, A2, A3, A5, B3 |
| F2 — commercials | B1, C1, C3, D1, D3, G1 |
| F3 — direct revenue ownership | B1, D1 |
| F4 — what it means for operators | POV close, A5, B2, H1 |
| F5 — rail selling | B2, D1 |
| F6 — strategy and market fluency | A4, E2 |
| F7 — scaling a partner programme | C2, D2, B3 |
| F8 — seniority | E1, H2, G2 |

---

## Graded deliverable: the 15-minute POV

**The brief, in the recruiter's words:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**Your facts to build on**

- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
- F4: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- F6: "She also attached the market report their strategy team circulated internally last quarter, which I've read."

**The consensus trap.** Deepa and Ross have the same report you do, so repeating its findings back scores as homework. Use one item from it to show you've done the reading, diverge from it once with a reason, and name one thing you'd deliberately *not* do. Of the three, the anti-pick is the one that shows judgment.

**Shape for 15 minutes, no slides.** Before you start, say there are three parts so the panel can follow without visuals.

| Minutes | Beat | Provenance |
|---|---|---|
| 0–1.5 | Define "operator partnerships" in one sentence and say which reading you're taking: partnering *with* operators, building partners *around* operators, or both in a set order. Then one line on where you're coming from, using F1's and F4's words only | [generic] |
| 1.5–3.5 | One finding from the report you'll build on, quoted or summarised from the report itself. Answer slot: pick it from what the report actually says, not from what a rail market usually looks like | [grounded] |
| 3.5–10.5 | Two or three moves across 0–6, 6–12 and 12–18 months, taken from the thesis table below, each with its concession said out loud | [generic] |
| 10.5–12.5 | Commercials, said before Ross asks: how each move earns money, what you'd want to be measured on, and the distinction between sourced and influenced revenue, named by you first (see B1) | [generic] |
| 12.5–15 | The close the recruiter asked for: what changes for an operator, in operator terms | [generic] |

**Thesis options.** Pick two, or three if they sequence cleanly. Every one is `[generic]`: none rests on a Kelverton fact, because research didn't run. Wherever the report says something about Kelverton's product, customers or competition, that replaces the generic wording.

| Thesis | The move | Mandatory concession | Provenance |
|---|---|---|---|
| T1 — An integration ecosystem around the scheduling product | Recruit and certify a small set of technology partners whose systems operators already run alongside scheduling, so plans flow into operations without manual re-keying. It's the closest match to your F1 work, said at that scale | If the buyer base is small, which you should check against the report, partner count is the wrong success measure. Measure operator adoption of each integration, not the number of logos | [generic] |
| T2 — A design-partner tier with a handful of operators | Formal co-development agreements: roadmap input and early access in exchange for reference rights, shared outcome measures and a commercial commitment | Design-partner programmes tend to build for the loudest customer. The guardrail is an exit criterion and a rule that a feature ships only if it generalises | [generic] |
| T3 — Delivery and consultancy partners to extend implementation capacity | Accredit implementation partners so operators get to value faster without the company growing headcount at the same rate | Partner-led delivery can erode margin and quality control, and Ross will ask about this. The answer is accreditation, a shared delivery standard, and keeping the operator relationship owned in-house | [generic] |
| Anti-pick | A broad reseller or referral programme in the first 18 months | Say why: in a market with few large buyers and long procurement cycles, which you should check against the report, a volume channel adds cost before it adds revenue. Be ready to concede the condition under which you'd revisit it | [generic] |

**The close: what it means for operators.** Make it three plain consequences, said from the operator's side of the table, and stop there.

| Operator consequence | Ties to | Provenance |
|---|---|---|
| Fewer manual hand-offs between the scheduling product and the systems they already run | T1 | [generic] |
| A real voice in the roadmap, with outcomes they helped define | T2 | [generic] |
| Faster time to value on implementation, with one accountable owner | T3 | [generic] |

Proposed wording for your one-line opener, pending your approval: *"I spent five years in transport consulting on bus and light rail network planning, and the last four running an ISV channel in payments, taking it from 6 partners to 40. So I'll come at this from two angles: what operators need, and how partner programmes actually scale."* Every clause traces to F1 or F4. Don't add "rail" to it.

---

## Reading the interviewers

These come from the recruiter's words only. The public-footprint search was refused, so there's no career pattern or published material behind them.

| Interviewer | What the recruiter said | Practical implication | Provenance |
|---|---|---|---|
| Deepa | "VP Partnerships, your future manager" | Scores the POV as your plan for her team. Expect sequencing, prioritisation and "what would you need from me" | [grounded] |
| Ross | "Commercial Director" and "Ross will push on commercials" | Expect the quota question (B1), defend-the-number probes (C1, C2) and partner economics (C3, D3). Say the commercials section of the POV before he asks for it | [grounded] |

---

## Persona weights

The recruiter's description is the loop source and covers this one session: a panel, a POV, then Q&A. Weights blend the hiring-manager prior for Deepa with the commercial-executive prior for Ross, shifted towards commercial pressure because the recruiter flagged it.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| A — Case/Strategist | POV follow-ups: "why that first", "how would you choose", "how do we know it worked" | High. The POV is a live case and Deepa is the hiring manager | Clarify, then objective, segmentation, approach, metrics, risks. Challenge one premise per case, starting with what "operator partnerships" means |
| B — Skeptic | Quiet probing of F3 and F5, the two gaps you've stated | High. Both gaps sit right where Ross was told to push | Rehearse B1 until it's boring. Use only F1, F2 and F4's words, and say each limit before you're asked |
| C — Data-Driven Prober | "How was the £4M counted?" and "how many of the 40 produced anything?" | Medium. Ross plus a headline figure makes this likely | Know what you can and can't say about how each number was counted. Name the weakest assumption first, and say "I don't know" where that's true |
| D — Pressure | Time-boxed challenges and "how much of that was you" | Medium. "Push on commercials" signals deliberate pressure | Pause, restate the question, hold through two follow-ups, then concede specifically |
| E — Conversational | The warm-up "walk me through your journey" and "what did you make of the report" | Low. Openers only, but still scored | A 90-second arc built only from F1, F4 and F8's quotes |
| G — Peer Evaluator | Ross on the seam between partnerships and direct sales | Low. A Commercial Director owns the other side of that seam | Propose principles for the seam rather than pretending to know it |
| H — Values/Behavioral | One behavioural question, probably about the operator focus | Low. No values round is named and the values page couldn't be read | Selection scaffolds below, each with its honest branch |

---

## Question banks

### A — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "When you say operator partnerships, do you mean partnering with operators or building partners around them?" | CASE | [generic] | Answer in one sentence, pick one, and give the reason in operator terms. If you're doing both, say the order and why. This premise decides every move after it, which is why you raise it in the first 90 seconds of the POV rather than waiting to be asked | The brief's wording is ambiguous, and clarifying before structuring is what this persona scores. CASE because it tests your framing live |
| A2 | "If you could do only one thing in the first six months, what would it be?" | CASE | [generic] | Name the move, the one result that tells you it's working by month six, and what you're deliberately deferring. The deferral is the anti-pick. Don't spread the answer across three things | Sequencing is the hiring manager's version of "can you prioritise". CASE because it's a decision on the role's real problem |
| A3 | "How would you decide which operators get a strategic partnership and which get a standard relationship?" | CASE | [generic] | Give two or three criteria said aloud, for example the operator's appetite for co-development, how far their needs generalise to other operators, and their commercial weight. Then say how you'd test the criteria in the first quarter. If the report segments operators, use its segments | Tests the segmentation step of T2. CASE because there is no right answer, only structure |
| A4 | "What in our market report would you push back on, or think is missing?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Answer slot: name a finding from the report you'd sequence differently or test before committing to, and give your reason in your own words. If you don't disagree with anything, say so plainly and name what you'd want validated first. Keep it about sequencing or evidence, never a correction of their strategy team | F6's discovery gap, rehearsed so the panel sees what you do with the report. CO because it's a homework-depth test on a document they wrote |
| A5 | "How will we know in 18 months that this worked, for us and for the operators?" | CASE | [generic] | Give two columns: company measures (partner-sourced and influenced pipeline kept separate, integration attach rate, time to revenue) and operator measures (time to value, adoption of the integrations, roadmap items delivered from operator input). Name one measure you'd be wary of, such as raw partner count | Lands the recruiter's operator close in measurable form. CASE because it's a metrics design problem |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep in this pack.** "You've never carried a direct quota, only influenced revenue. Why should we trust you with a commercial number?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | **Hold only what the quotes carry.** First: "I haven't carried a direct quota. My number at the payments company was influenced revenue, roughly £4M." Answer slot: say how that influence was counted and which part was yours, in your own words. If you don't know how it was counted, say so. Then give a forward-looking plan, said as a plan: what you'd propose to be measured on here and how sourced and influenced revenue would be kept separate. **Follow-up 1, "influenced is soft":** concede plainly that influenced attribution is weaker evidence than closed revenue, then come back to what the figure does cover. Don't upgrade it. **Follow-up 2, "would you take a quota?":** answer slot. If you would, say on what terms. If you'd want a different measure, say which and why. Either way, say it in your own words. **Limit named before asked:** say the distinction yourself in the POV's commercials section | F3 is a gap you stated and F2 is its adjacent row. "Push on commercials" makes this question close to certain in some form. JD because it scores commercial accountability directly |
| B2 | "You've never sold into rail. How do you get credible with operators quickly?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | First: "I haven't sold into rail." Then F4's words at their own scope: "I spent five years in transport consulting on bus and light rail network planning, so I know the operator world from the other side." Answer slot: if that planning work put you alongside operators' planners, say what you saw, in your own words. If not, stay with network planning. Then a 90-day ramp, said as a plan: whose meetings you'd sit in, which operators you'd listen to first, and what you'd ask Deepa for | F5 is stated and F4 is the only adjacent row. "Light rail" will be tested if it's stretched into "rail". JD because it scores a sector requirement |
| B3 | "Payments ISV partners and rail operators are very different. What doesn't transfer?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Lead with what doesn't transfer, framed as hypotheses you'd test, for example buyer count, procurement length and partner motivation. Check them against what the report says. Then what you would carry over, at F1's scope: running a channel that went from 6 partners to 40. Answer slot: if a specific practice from that channel is the thing that transfers, name it and say it was yours. If you can't point to one, say what you'd test first | F1's transferability gap is exactly where a skeptic splits the argument. Naming the limits first turns it from a probe into a credibility gain. JD because it tests fit to this role |
| B4 | "Why leave payments for rail, and why now?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot: give your actual reason, in your own words. If the consulting years are part of it, connect them with F4's sentence. If they aren't, don't force the link. Keep it to 60 seconds and finish on this role rather than on what you're leaving | Motivation consistency is the skeptic's other standard probe, and nothing in your material gives the reason, so the pack doesn't supply one. EXP because it tests your career narrative |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slots, each in your own words: how a deal came to count as influenced, what period the £4M covers, what the figure is most sensitive to, the assumption behind it you'd defend least (name it before Ross does), and which part of it was yours. If you don't know how it was counted, say so plainly. "Roughly" is your word, so keep it | Every headline figure gets a defend-the-number question, and F2 is the figure Ross is primed to probe. EXP because it tests attribution |
| C2 | "You went from 6 partners to 40. How many of the 40 actually produced revenue?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: give the number, or the shape of it, in your own words. If you don't know, say so and say how you'd find out. If most of the value came from a few partners, saying so plainly earns more credit than defending the 40 | Asking for the denominator behind F7's partner count is the prober's reflex. EXP because it tests whether the headline number holds up |
| C3 | "What's a partnership worth to us commercially? How would you model it?" | CASE | [generic] | Structure: the revenue mechanism (revenue share, referral fee, co-sell uplift, or retention effect), cost to serve the partner, time to first revenue, and which line is sourced versus influenced. Say each assumption out loud as you go, and say which one you're least sure of | Ross's native language. CASE because it's partner economics built live |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who's carried a rail sales quota?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Pause, then concede the premise in one sentence: you haven't carried a quota or sold into rail. Then say what you do bring, in F1's and F4's words only. Finish on the POV's first move. **Hold** if he interrupts. **Concede** only the specific thing he names, never the whole case | B1 delivered as a time-boxed challenge, which is how a pressure interviewer would ask it. JD because it's a fit comparison |
| D2 | "That growth from 6 to 40 partners: how much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Your sentence says you were running the channel and took it from 6 to 40. Answer slot: which parts of that growth were your decisions or your work, in your own words. If some came from other teams, the market or inbound demand, say so plainly. Use "we" for context and "I" for what you did. Hold through one more follow-up, then concede the specific share that wasn't yours | The classic attribution probe on F7. Rehearsing candour here is the whole point. EXP because it tests what was yours |
| D3 | "Your POV sounds nice, but where's the money in year one?" | CASE | [generic] | Hold your order of moves, then give the year-one commercial line for your first move. Concede plainly which moves are year-two money and why you'd still start them now. Don't reshuffle the POV on the spot to please him | Tests whether the POV survives commercial pressure. CASE because it defends a plan live |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey from consulting to payments to here." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc using only these beats: five years of transport consulting on bus and light rail network planning, then partnerships, with the last four years running the ISV channel at a payments company and taking it from 6 partners to 40. End on why this role, using your own reason from B4 | Biography openers are scored on economy. EXP because it's your history, told briefly |
| E2 | "What did you make of the report we sent?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Treat it as scored. Answer slot: give the one finding you'll build on, taken from the report itself, in a sentence, then one line on what you'd want to test. Don't pre-empt the whole POV | F6, asked casually, before the POV or after it. CO because it's a homework check |

### G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When a partner and my direct sales team both touch a deal, who gets credit, and who owns the operator?" | CASE | [generic] | Propose principles rather than claiming to know their setup: one owner of the operator relationship, rules for registering partner involvement early, sourced and influenced revenue tracked separately, and a named way to settle disputes. Then ask Ross how it works today | The Commercial Director owns the other side of this seam. CASE because it's an operating design problem |
| G2 | "Tell me about a time you disagreed with a sales leader over a partner deal." | EXP | [generic] | Selection scaffold: pick a real disagreement with a named stake, a position you held, and a working relationship still intact at the end. Use "I" for what you argued. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer persona's disagreement probe, aimed at the seam G1 opens. EXP because it asks for a past instance |

### H — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a partner's or customer's interest cost you against your own number. It needs the metric, the choice and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. This links to the POV's operator close | The recruiter asked for an operator-first ending. A values probe on the same theme is a natural follow-up. VAL because it scores behaviour |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named truth, who heard it, what you did when it landed badly, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The anti-pick in the POV is a small unpopular truth. A panel may test whether you do this in practice. VAL because it scores behaviour |

---

## Reverse questions

| # | Question | To | Why it lands |
|---|---|---|---|
| R1 | "What would a great first six months in this role look like from where you sit?" | Deepa | She is your future manager. Her answer tells you which POV move she'd actually fund |
| R2 | "How is partner-influenced revenue counted here today, and what would you want this role measured on?" | Ross | You raise the quota and influence question on your own terms before he closes the conversation (F3) |
| R3 | "Which findings in the market report has leadership acted on, and which have been parked?" | Either | It shows you read the report as a decision document, and tells you where the appetite is |
| R4 | "When a partner is involved, who owns the operator relationship today?" | Ross | It surfaces the seam from G1 and shows you've thought about where partnerships and sales collide |
| R5 | "What have operators asked you for that you couldn't give them on your own?" | Deepa | It lands the recruiter's operator focus as a question and may confirm which thesis fits |
| R6 | "Looking back in 18 months, what would make you say this hire didn't work?" | Either | It invites the real objection while there's still time to answer it |

---

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a direct or sales quota | Negative you stated, F3 | "I haven't carried a direct quota. My number has been influenced revenue." No slot |
| Has sold into rail, or "has rail sales experience" | Negative you stated, F5 | "I haven't sold into rail." No slot |
| £4M of sourced, closed or attributed revenue | Inflated form of F2 | F2's quote at its own scope: "roughly £4M of influenced revenue". The pack observes that your material says influenced, not sourced. C1's slots stay inside how the influence was counted |
| £4M a year | Inflated form of F2 by resolving an ambiguity upwards | Your material gives no period. C1's slot asks you to say the period you actually know |
| Built or founded the ISV channel | Inflated form of F7 | F7's quote: running the channel and taking it from 6 partners to 40. The pack observes that the channel had 6 partners already |
| Worked in rail, or knows train operators from the inside | Inflated form of F4, widened in both scope and side of the table | F4's quote: bus and light rail network planning, "from the other side". B2's slot stays inside the planning work |

---

## Sources

**Provided material**

- The recruiter's email, as quoted in your message
- Your background, as written in your message
- The market report you mentioned: you have it, I don't. Its contents are not in this pack

**Searches sent, all refused by host permissions**

- "Kelverton Rail values" — refused
- "Kelverton Rail interview process partnerships" — refused
- "Kelverton Rail scheduling software train operating companies news 2026" — refused
- "Deepa VP Partnerships Kelverton Rail; Ross Commercial Director Kelverton Rail" — refused
- "Senior Partnerships Manager rail software job description train operators UK" — refused

No dossier was consumed.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The only call was refused. It would have themed H1 and H2 on published values. No values round is named, so there would still have been no cheat sheet |
| 2. `Kelverton Rail interview process` | unavailable | The only call was refused. It would have checked persona weights against documented rounds. The recruiter's email already establishes this session |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The only call was refused. It would have turned the POV theses and A4, C3 and D3 from `[generic]` into grounded company context |
| 4. `Deepa` and `Ross` `Kelverton Rail` | unavailable | The only call was refused. It would have added career patterns and a reverse question tied to each panellist's path |
| 5. representative Senior Partnerships Manager JD | unavailable | The only call was refused. It would have turned the `[generic]` requirements in F3, F5, F6, F7 and F8 into `[inferred]` ones and possibly surfaced a gate |

---

## Upgrade menu

- **The market report's headline findings, pasted or summarised in your words.** The POV theses, the anti-pick, A4, E2 and R3 would go from `[generic]` to grounded in Kelverton's own analysis. This is the single biggest upgrade available
- **The JD text.** F3, F5, F6, F7 and F8 become `[grounded]`, the coverage table gets checked against Kelverton's actual list, and any gate surfaces
- **Web search allowed in this session.** The L1 pass would run: values, process, current strategy, and Deepa's and Ross's public professional footprint
- **A deeper research pass, at up to 6 more searches and 2 more fetches, several more minutes.** Competitive set, recent organisational context and the interviewers' talks or writing, all feeding the strategy cases
- **Your answers to the slots in B1, C1, C2 and D2**, i.e. how the £4M was counted, its period, and how many of the 40 partners produced revenue. These would become quoted evidence, and those rows plus F2 and F7 would be rewritten around them
- **Your full CV.** More of your own sentences means more story-mapped guidance and fewer selection scaffolds, especially G2, H1 and H2
- **A tuesday-dossier.md from job-underwriter** would add an evidence-derived highest-ROI objection and a prohibited-claims list confirmed with you. This pack is complete without one
