Quick update: web search was blocked on my end, so I'm building the pack from your JD and background alone. Writing it now.
I've saved your prep pack: **/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-2-denied-1e85fa34/atlas-freight_operations-manager_interview_pack.md**

Web search wasn't allowed on my side, so there's no research on Atlas Freight in it: no company values, nothing on their interview process, no recent news. Because I don't know who you're meeting, every interviewer style is weighted equally.

**What's in it:**
- **How you match the job:** each JD requirement next to your own words. Your green belt covers the Lean/Six Sigma plus. Leading 3 supervisors versus 12, and terminal operations versus warehouse work, are the two big stretches. Power BI is a gap you've already named. Four sites, on-time performance and cost per shipment have little or no evidence in what you told me.
- **22 practice questions** across seven interviewer styles, each with guidance on how to answer.
- **Questions to ask them, and claims to avoid.**
- **A list of what would make the pack better.**

**The question to practise most is A1:** "You manage three supervisors today; this job is twelve across four sites." Some version of it is almost certain.

**Two things to settle before the interview:**
- **Leadership years:** "5+ years operations leadership required" will probably be checked against your history. Count how many of your 7 years you actually had people reporting to you (A3).
- **The 40% figure:** know how it was counted and which part was yours (C1, D2). It's your only number, so expect them to dig into it.

Say the word and I'll play the Skeptic on A1 as a live practice round.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you know who you're meeting: the hiring manager, a peer, a panel, or an HR screen? Has the recruiter said anything about the format, or asked you to prepare something like a case or a presentation? The answer changes which questions to practise first.
2. If you turn on web search for me, do you want me to rerun the company research, and also do a deeper pass? The deeper pass is up to 6 more searches and 2 page reads, and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight. Interviewer: unknown. Round type: unknown, so this is a full-loop pack with flat persona weights. That makes it noticeably weaker than a pack built for a known round, and the upgrade menu says what fixes it.

## How to use this pack

Two axes. **Personas** describe how a question is asked (who is asking, in what style). **Types** describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's values. Here that means generic virtue only, because Atlas's published values could not be researched |
| EXP | Whether your claims hold up under close questioning: what you actually did |
| JD | Whether you can do the job as listed, gaps included |
| CO | Whether you've done your homework on the company |
| CASE | How you structure and reason through a live problem from the role |

Question IDs: A to H by persona. F is skipped because F1 to F9 are fit-snapshot rows. Guidance is scaffolding, not a script. Say it in your own words. An **answer slot** is an instruction for your answer in the interview. It has two honest branches, and either one is a good answer.

Provenance labels: `[grounded]` means it traces to your JD or your own words. `[inferred]` means it's this pack's reasoning from them. `[generic]` means it's a pattern for the role family, with no claim about Atlas or about you.

## Fit snapshot

The requirements are quoted from the JD you pasted. The evidence is quoted from your message, exactly as you wrote it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (terminal part) — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution, not terminal operations, and your words stay there: "I've spent seven years in warehouse and distribution ops." Answer slot: the JD's terminal line makes a probe on what carries over likely. Say which parts of your daily ops work you'd expect to carry over and which you'd need to learn, in your own words. If you don't yet know what differs, say so plainly and say how you'd find out |
| F2 | "Own daily terminal operations across 4 sites" (four-site part) — JD | none given | none | [grounded] | discovery | Strong evidence here would be work that spanned more than one location, with your part named. Answer slot: the JD's four-site line makes this probe likely. If any of your work has covered more than one site, say what and how, in your own words. If none has, say so plainly and stay with the site work your material carries |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The JD says twelve and your material says three, and your words stay at three: "I'm a senior shift manager over three supervisors." Getting to twelve is a plan, said as a plan and never as something you've done. Answer slot: if leading your three involves anything you'd expect to scale, say what, in your own words. If nothing comes to mind, say so plainly and go to the plan |
| F4 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops is not the same claim as seven years leading people, and your material doesn't say how many of the seven were in leadership roles. Answer slot: give the number of years you've led people, in your own words. If it's under five, say the number plainly and stay with what you lead now. This is not a gate, but "required" means you should expect it to be asked directly |
| F5 | "drive on-time performance and cost-per-shipment down" (on-time part) — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The surge plan may touch on-time performance, but your material doesn't show whether on-time was measured or moved. Answer slot: if on-time or ship-on-time was tracked during the surge, say what was tracked and which part of the result was yours. If it wasn't tracked, say so plainly and describe the plan you ran |
| F6 | "drive on-time performance and cost-per-shipment down" (cost part) — JD | none given | none | [grounded] | discovery | Strong evidence here would be a cost measure you tracked and moved, with your part named. Answer slot: if you've tracked or moved a cost measure in your ops work, say which one and how, in your own words. If you haven't, say so plainly and walk through how you'd attack cost per shipment (B2). Keep the mis-pick result separate: it is a mis-pick figure, not a cost figure |
| F7 | "build reporting in Excel/Power BI" (Excel part) — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill rating, not a report. Answer slot: if you've built a report other people use, say what it tracked and who read it. If you haven't, say so plainly and stay with "solid Excel" |
| F8 | "build reporting in Excel/Power BI" (Power BI part) — JD | "never used Power BI" — your message | none | [grounded] | capability | No wording closes this gap, and you've already said so. Your words: "I haven't used Power BI." Then how you'd learn it, said as a plan. If you start learning before the interview, say only what you've actually done by then. Add nothing to make the gap feel smaller |
| F9 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | none | Say it as you said it: "I'm green belt certified." Your material doesn't say the pick-path redesign was run as a green-belt or Lean project. Answer slot: the JD's Lean/Six Sigma line makes this probe likely. If the redesign used green-belt methods, name the steps you used, in your own words. If it didn't, say so plainly and keep the two separate |

## Persona table

No loop source establishes Atlas's interview process, because the research was blocked. Persona weights therefore rest on the **Generic** archetype (screen, then hiring manager, then panel) with flat weights. That is a pattern, not Atlas's documented process. No values-style round is detected, so there is no values cheat sheet.

| Persona | How it shows up here | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Probes the gaps between three supervisors and twelve, one site's work and four, and ops years and leadership years | Flat. It gets the deepest bank anyway, because F2, F3 and F4 are this candidacy's biggest gaps and the most predictable objection lives here | Rehearse A1 until it's boring. Hold only what your quotes carry, name the limit before they do, then give a concrete ramp plan |
| B. Case/Strategist | Live problems built from the JD's own metrics: on-time, cost per shipment, four sites | Flat. It's deep because the JD names two hard metrics, and those convert directly into cases | Clarify, then set the objective, segment, give the approach, name the metrics and the risks. Think aloud |
| C. Data-Driven Prober | Takes the 40% apart | Flat. Your one headline number makes this persona's questions near-certain whoever asks them | Know what you can and can't say about how the figure was counted, and say plainly where you don't know |
| D. Pressure | Time-boxes, asks "how much was you", pushes on Power BI | Flat | Pause, restate, anchor in what you stated, hold through two follow-ups, then concede the specific thing |
| E. Conversational | "Walk me through the journey", casual Lean chat, "why Atlas" | Flat. These are still scored | A 90-second arc built from your own sentences. Treat casual Lean questions as scored |
| G. Values/Behavioral | STAR-style stories on leading supervisors and hard conversations | Flat. There's no documented values round, so the themes are generic | Use the selection scaffolds below. "We" for context, "I" for what you did |
| H. Peer | Other ops or site managers asking about seams and reciprocity | Flat. This is more likely if a panel includes peer managers | Propose principles for working across seams rather than pretending to know Atlas's seams |

## Question banks

**Highest-ROI prep in this pack: A1.** Some version of "three supervisors to twelve, across four sites" will be asked.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage three supervisors today. This job is twelve supervisors across four sites. Why are you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "7 years in warehouse and distribution ops" | Open with what the quotes carry: "I'm a senior shift manager over three supervisors today, and I've spent seven years in warehouse and distribution ops." Name the limit before they do, in words that rest on that quote: "Twelve across four sites is a bigger span than my current three." Answer slot: if any of your work has covered more than one site, say what and how, in your own words. If none has, say so plainly and come back to the three supervisors you lead now. Then the plan, said as a plan: how you'd get to know four sites and twelve supervisors in your first weeks (B3). Follow-up 1 will push on scale and follow-up 2 on proof. Hold by returning to the three and to the plan, never by adding to either. The concession is the span itself. Don't apologise for it | F3 and F2 are where the JD presses hardest against the material, so this objection arrives in some form. JD because it scores the stated team size and site count head-on |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" "solid Excel" | Pick the real gap you've already named: "I haven't used Power BI." Then what you have, at its own size: "My Excel is solid." Then the ramp, said as a plan: what you'd learn first and how soon you'd want a usable report. A real, closable gap beats a disguised strength | F8 is the one gap you stated yourself, which makes it the honest and safest answer to this stem. JD because it scores the reporting requirement |
| A3 | "The posting says five-plus years of operations leadership, required. How many of your years were spent leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Don't let "seven years" stand in for leadership years. Answer slot: give the number of years you've had people reporting to you, in your own words. If it's under five, say the number plainly and stay with what you lead now: "I'm a senior shift manager over three supervisors." Never round up | F4. A titled-years requirement is likely screened literally, so a vague answer reads worse than an exact one. JD because the requirement is the premise |
| A4 | "Why move from warehouse and distribution into running terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: give your actual reason for wanting this role, in your own words. The JD's lines (four sites, on-time, cost per shipment) are fair things to name if they really are what draws you. Then what carries over, at the quote's own scope: "seven years in warehouse and distribution ops." Say what you'd need to learn about terminals rather than implying you know it | F1. This is the why-here, why-now probe aimed at the kind of operation. JD because it tests the terminal requirement through motivation |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four terminals dropped this month. How would you diagnose it?" | JD | [generic] | Clarify first: how on-time is measured, since when, one site or all, which customers or lanes. Then segment where lateness can enter: inbound arriving late, time on the dock, outbound departing late, staffing by shift. Name the data you'd pull, and give two hypotheses with the test for each. Separate today's containment from the root-cause fix. Close with how you'd report it. This needs no claim about your past | JD content (on-time), CASE delivery. It converts F5's requirement into a live problem, which is where hiring managers usually go |
| B2 | "Cost per shipment is up across the network. Where do you look first?" | JD | [generic] | Define the number first: what's in the cost and what counts as a shipment. Check whether volume or mix changed before blaming efficiency. Split by site and by cost bucket (labour, overtime, equipment, rework or claims). Pick one or two levers, and name the risk each one carries for on-time | JD content (cost per shipment), CASE delivery. F6 has no evidence, so a strong live answer here is your best counterweight |
| B3 | "First 90 days: four sites, twelve supervisors you've never met. What's the plan?" | CASE | [generic] | Days 1 to 30: see every site on every shift, a one-on-one with each supervisor, and a baseline of on-time and cost per shipment by site. Days 31 to 60: pick the one or two biggest gaps and set a common reporting rhythm. Days 61 to 90: first improvements live, measured against the baseline. Say what you'd *not* change early | This gives A1 its plan. CASE because nothing about your past is asked |
| B4 | "How would you build a weekly report for me on the four sites?" | JD | [grounded] "solid Excel" "never used Power BI" | Start with the reader. Which few numbers per site (on-time, cost per shipment), the trend against last week, and the exceptions worth a conversation. On the tool: "I'd build the first version in Excel. My Excel is solid. I haven't used Power BI, so here's how I'd get there." Design matters more than the tool | F7 and F8. JD because it scores the reporting requirement directly |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate 40%. Walk me through how that was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slots, each in your own words: how the 40% was counted; what it is sensitive to; the assumption behind it you'd defend least, said before they find it; and which part of the result was yours. "I don't know exactly how it was counted" is an honest branch, and far better than a method you can't repeat under a second question. Don't supply a baseline or a period you can't stand behind | This is the only number on your record, so it will be probed. EXP because it tests the claim itself |
| C2 | "What did redesigning the pick path actually involve, and what part of it was yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats your sentence states: the pick path, redesigned, mis-picks down 40%. Tell what the redesign was, in your own words. Answer slot: if others worked on it, say who did what and what was yours. If it was yours alone, say so plainly | It's the story behind C1, and the most natural place for "we" and "I" to blur. EXP because it scores attribution |
| C3 | "Tell me about the peak-season surge plan. What did it cover, and how did you know it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats your sentence states: the site's surge plan, which you ran, two peak seasons running. Describe what it covered, in your own words. Answer slot: if on-time or another measure was tracked, say which and what part of the result was yours. If nothing was measured, say so plainly and describe how you ran it | F5. This is your nearest material to the on-time requirement. EXP because it tests what "ran" covered |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "7 years in warehouse and distribution ops" "ran the site's peak-season surge plan two years running" "cut mis-pick rate 40% by redesigning the pick path" | Pause, then three beats in your own words: seven years in warehouse and distribution ops, the surge plan you ran two years running, and mis-picks cut 40% through a pick-path redesign. Say nothing about the internal candidate. The concession, if pushed: an insider already knows these terminals, and you'd have to learn them. Hold the three beats | A standard pressure stem. It tests composure, and whether you claim more than F1, F5 and F9 carry under time pressure |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede. Answer slot: say exactly which part was yours, in your own words. If others contributed, name what they did. Hold that through two follow-ups. Concede only what's true, and never fold the core claim to ease the tension | The attribution probe on your headline result. EXP because what's scored is honesty about your share |
| D3 | "You've never used Power BI, and we need reporting from week one. Isn't that a problem?" | JD | [grounded] "never used Power BI" "solid Excel" | Concede plainly: "I haven't used Power BI." Hold what you have: "My Excel is solid, and I'd have week-one reporting in Excel." Then the plan to learn Power BI. Don't promise a timeline you haven't thought through | F8 under pressure. The negative is one you stated, so they can fairly put it to you |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc from your own sentences: seven years in warehouse and distribution ops. Now a senior shift manager over three supervisors. Mis-picks cut 40% by redesigning the pick path. Ran the site's surge plan two peaks running. Green belt certified. Answer slot: add the roles and order in between in your own words, then your real reason for this role. End on the role, not the past | Near-certain opener in any round. EXP because each beat is a claim they may pull on |
| E2 | "Are you doing anything with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" "cut mis-pick rate 40% by redesigning the pick path" | "I'm green belt certified." Answer slot: if the pick-path redesign used green-belt methods, name the steps in your own words. If it didn't, say so plainly and keep them as two separate things | F9. A plus-skill asked casually is still scored. JD because Lean/Six Sigma is a listed plus |
| E3 | "What drew you to Atlas?" | CO | [generic] | Answer slot: your real reason, in your own words. Read Atlas's own website before the interview and use only what you've read there. This pack couldn't research the company, so it supplies no facts about it | CO homework question. `[generic]` because research was blocked, which is the honest cost |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you held your view, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A common behavioural stem. VAL, with generic themes because Atlas's values weren't researched |
| G2 | "Tell me about a time one of your supervisors was struggling. What did you do?" | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold, drawing on leading your three supervisors: a named issue, the conversation you had, what you did, and what changed. Keep the person anonymous. If no such time comes to mind, say so plainly, then say how you'd handle it | The theme comes from the JD's "lead a team of 12 supervisors". F3 is where it lands. VAL because what's scored is how you lead |
| G3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific trade-off, what each side cost, and why you chose. If no such time comes to mind, say so plainly, then say how you'd weigh it | Common stem, and relevant because the JD's two metrics (on-time and cost) can pull against each other |

### H. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know Atlas's seams. Propose principles: agree on shared numbers, raise issues early, escalate together rather than around each other. If asked for a disagreement story, pick one with a real disagreement and a working relationship after. If none comes to mind, say so plainly and describe how you'd handle one | A standard peer stem. CASE because it's a live working-style problem |
| H2 | "What would you need from the other managers in your first month, and what would you bring them?" | CASE | [generic] | Reciprocity: what you'd ask for (site context, honest read on the supervisors) and what you'd offer (a common report, help in peak). Offer only what you'd actually do | It tests whether you'd add to a peer's load or lighten it |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Daily terminal operations (F1) | A4, B1 |
| Across 4 sites (F2) | A1, B3 |
| Lead 12 supervisors (F3) | A1, B3, G2 |
| 5+ years operations leadership (F4) | A3 |
| On-time performance (F5) | B1, C3 |
| Cost per shipment (F6) | B2 |
| Excel reporting (F7) | B4 |
| Power BI reporting (F8) | A2, B4, D3 |
| Lean/Six Sigma plus (F9) | E2, C2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is on-time performance measured here today, and how much does it vary across the four sites?" | It speaks the JD's own metric and asks for the denominator, which signals ops judgment |
| "What goes into cost per shipment in your numbers?" | It shows you won't chase a number before you know how it's built |
| "Where do the twelve supervisors stand today? Any open seats, anyone new in the role?" | It shows you're already thinking about the team you'd inherit |
| "What reporting exists now, and what would you want built first?" | It turns the Power BI gap into a forward-looking question about what they actually need |
| "What would make the first 90 days a success for this role?" | It gives you their scoring sheet, and you can test it against B3 |
| "What's the biggest difference between the four sites?" | It invites them to teach you the operation, which most interviewers enjoy |
| "What does the rest of the interview process look like?" | It fills the gap this pack couldn't research, and you can bring the answer back to upgrade the pack |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run terminal operations | Inflated form of F1 | F1's quote at its own scope: "seven years in warehouse and distribution ops." The limit is this pack's observation: your material says warehouse and distribution, not terminals |
| Has led a team of twelve supervisors | Inflated form of F3 | F3's quote: "a senior shift manager over three supervisors." Getting to twelve is a plan, never a past |
| Has seven years of operations leadership | Inflated form of F4 | The material says seven years in ops, not seven years leading. A3's slot asks for the real leadership count |
| Improved on-time performance or cost per shipment through the pick-path redesign | Inflated form of the mis-pick sentence in F9 | "Cut mis-pick rate 40% by redesigning the pick path," and no more. It is a mis-pick figure |
| Built or designed the surge plan | Inflated form of F5 | "Ran the site's peak-season surge plan two years running." Ran, as you said it |
| Has built reporting other people rely on | Inflated form of F7 | "Solid Excel." B4 is about future design, not past reports |
| Led Lean or Six Sigma projects | Inflated form of F9 | "Green belt certified." E2's slot asks whether the pick-path redesign used those methods |
| Has used Power BI | Negative you stated, F8 | "I haven't used Power BI." No slot |

## Sources

- Provided: the JD text and the background in your message.
- Search `"Atlas Freight" values mission regional logistics` — refused (permission not granted).
- Search `"Atlas Freight" interview process operations manager` — refused.
- Search `"Atlas Freight" news 2026 terminals` — refused.
- No fetches sent. No dossier consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have moved the values cheat sheet (if a values round exists) and given the G bank Atlas's own value names |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have moved persona weights, which fall back to the Generic archetype with flat weights |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have moved E3 and given one case built on Atlas's current priorities |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting (hiring manager, peer, panel, HR screen) → real persona weights instead of flat ones, and banks reordered to that round
- Interviewer name(s) → a "Reading the interviewer" section, persona weights based on their public profile, and a reverse question tied to their career path
- The recruiter's email or invite → coverage of anything they asked you to prepare (a case, a presentation, a site walk) as its own build section
- Web search enabled → targets 1 to 3 rerun: Atlas's values (and a cheat sheet if there's a values round), its interview process, and a strategy-grounded CO and CASE question in place of E3's generic one
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Atlas's network, recent moves and leadership
- Your answers to the slots in F4, F5 and C1 (years leading people, whether on-time was tracked during the surge, how the 40% was counted) → those rows rebuilt on your own words, and A3, C1 and C3 story-mapped instead of slotted
- Your green-belt certificate, or a before-and-after mis-pick report → F9 and C1 can rise toward `high`, because those are the inspectable artifacts in ops
- Hours you have this week to prep → a prep triage: the few things to do well, in order
- A `tuesday-dossier.md` from job-underwriter → the highest-ROI objection taken from verified evidence rather than inferred, plus an independently built prohibited-claims list
