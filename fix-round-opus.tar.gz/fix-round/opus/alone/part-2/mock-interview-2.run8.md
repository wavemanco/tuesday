I've saved your prep pack as `AtlasFreight_operations-manager_interview_pack.md` in your working folder. It's built only from the job description and your background.

**Nothing in it comes from outside your message.** My web searches were declined, so I couldn't check Atlas Freight's values, interview process or recent news. Those parts are generic. You don't know who's interviewing you, so every interviewer style gets equal weight.

**Your strongest material:**
- the 40% cut in mis-picks
- running the peak-season surge plan two years running
- the green belt

**Expect pushback here:**
- **Scale is the biggest risk.** You lead 3 supervisors at one site; the role has 12 across 4 sites.
- **Power BI:** you've never used it. The pack says so plainly and adds a learning plan.
- **Leadership years:** the role requires 5+ years leading people. Count how many of your 7 years that covers, and be ready to state it straight.

**What's in the pack:** 22 practice questions, each with answer guidance, plus questions for you to ask them. It also lists claims it won't coach you to make because they'd stretch what you told me, like "ran multi-site operations".

The most valuable thing to rehearse is question A1, the scale objection. I can play the skeptical interviewer on it, follow-ups included.

I can also save a `tuesday-dossier.md` that records the gaps this prep found, so you can carry them into later sessions.

If you'd like the pack as a Word document, I'll convert it.

Do you know whether you're meeting HR or a recruiter, your future manager, peers, or a panel? That changes which questions matter most.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** unknown. Round type and relationship unknown.
**Built on:** the JD text and the background in your message. The web research was refused, so nothing company-specific comes from outside your message.

---

## How to use this pack

- **Personas** describe *how* a question gets asked (who's asking, in what style). **Types** describe *what* is being scored. One persona can ask any type.
- **Type key:**
  - **VAL**: behavioral or values. Does your past behavior show what the company says it values?
  - **EXP**: experience deep-dive. Do your claims survive scrutiny, and which part was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. Have you done your homework on them?
  - **CASE**: a live problem from the role. Is your reasoning structured when you think out loud?
- **Answer slot:** where your message doesn't say whether you did something an interviewer is likely to probe, the guidance gives you two honest branches instead of words. Answer whichever is true, in your own words.
- **Provenance:** `[grounded]` means it traces to your message or the JD. `[inferred]` means it's derived, and the derivation is named. `[generic]` means it's a role-family pattern with no claim about Atlas or about you.
- Guidance is scaffolding, not a script. Bank IDs skip the letter F so they never collide with fit-snapshot rows (F1, F2…).

---

## Prep triage (about a week)

1. **A1, with both follow-ups, out loud, three times.** This is the scale objection and the highest-ROI prep in the pack. Say A1's hold sentence until it bores you.
2. **C1 and C2.** Defend your 40%: know how it was counted and which part was yours. Where you don't know, practise saying so.
3. **A2.** Your Power BI answer: the plain acknowledgment, then a learning plan. If you actually open Power BI before the interview, you can then say only what you actually did.
4. **G4.** Know exactly how many of your seven years were in leadership roles, and say it straight.
5. **B1 and B2.** Run each case aloud once with a timer: clarify, structure, metrics, risks.
6. **G1.** Your 90-second journey arc.
7. **Pick three reverse questions.**

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution work and one site's surge plan. It doesn't mention terminals or four sites, and the words stay at that scope: "I've spent seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's terminal and four-site line makes a probe on both likely. If any of your work involved terminal operations or spanned more than one site, say what and how, in your own words. If none did, say so plainly and stay with the site you ran |
| F2 | "drive on-time performance … down" — JD (the JD says on-time performance and cost-per-shipment together; this row takes on-time) | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The figure belongs to the mis-pick rate. It is not an on-time figure, and it stays attached to that noun: "I cut our mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's on-time line makes a probe likely. If you know whether the redesign changed on-time shipping, say what you saw and how you knew. If you don't know, or it wasn't tracked, say so plainly and stay with the mis-pick result |
| F3 | "drive … cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | The mis-pick result touches cost but doesn't show whether any cost figure moved. The bridge is this pack's derivation, so it isn't stretched. Answer slot: if you've tracked or been accountable for a cost figure, say which one and what you did with it, in your own words. If you haven't, say so plainly and say what you would measure first |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors, and the words stay there: "I'm a senior shift manager over three supervisors." Answer slot: the JD's twelve-supervisor line makes a scope probe likely. If you have led more people than those three at any point, say when and how many, in your own words. If you haven't, say so plainly and give your approach to twelve as a plan |
| F5 | "build reporting in Excel/Power BI" — JD (Excel) | "solid Excel" — your message | low | [grounded] | discovery | "Solid Excel" doesn't say whether you've built reporting with it. Answer slot: if you've built reports or trackers in Excel, say what they tracked and who used them, in your own words. If you haven't, say so plainly and say what report you would build first |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI) | "never used Power BI" — your message | none | [grounded] | capability | A gap you stated yourself. Words: "I haven't used Power BI." Then how you'd learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in ops and a current leadership role, but not how many of those years you've led people. This is a length-of-experience requirement, not a gate, but "required" means it may be screened literally. Answer slot: say how many of the seven years you've been leading people, in your own words. If it's fewer than five, say so plainly and stay with what you've led |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. It's a self-reported credential with nothing inspected behind it, so expect a probe. Lead with it in its own terms: "I'm green belt certified." |

---

## Persona table

**Loop:** no loop source establishes Atlas Freight's process. The research was refused, and your message doesn't say which round this is. The weights below rest on the **Generic** archetype (screen → hiring manager → panel): flat weights, stated plainly. That's noticeably weaker than weights built from a known round. Tell me who you're meeting and they get reweighted.

| Persona | How it shows up here | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Skeptic | Presses on scale: three supervisors to twelve, one site to four, warehouse to terminal | Flat. Likelier in any hiring-manager round, because F1, F4 and F7 are the gaps a hiring manager is paid to derisk | Rehearse A1 until it's boring. Build bridges only from the quotes in F1 and F4, say the limits plainly, and give a concrete ramp plan |
| Case / Strategist | Live problems: a site's on-time performance drops, a cost target, a first-90-days plan | Flat. Likelier with a hiring manager or an executive. The JD's metrics make these the obvious cases | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud |
| Data-Driven Prober | Goes after your 40% | Flat. Likelier with a technical or senior ops interviewer. It's your only figure, so it draws fire | Know what you can and can't say about how it was counted. Name your weakest assumption first |
| Pressure | Time-boxed "why you" and "how much was actually you" | Flat. Likelier with a skip-level or a panel | Pause, restate, hold through two follow-ups, then concede something specific |
| Peer Evaluator | Fellow ops managers or sales/customer service asking about the seams | Flat. Likelier if a panel includes peers | Seam principles, reciprocity, disagreement with tact |
| Conversational | Friendly screen: the journey, years of leadership, Lean "these days" | Flat. Likeliest if this is a recruiter or HR screen | A 90-second arc. Treat casual questions on the JD's required and plus lines as scored |
| Values / Behavioral | STAR stories on accountability, bad news, customers | Flat. No values page was read and no values round was detected, so these are generic | Map a story where one of your sentences carries one. Otherwise use the selection scaffold and its honest branch |

---

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over three supervisors. This role leads twelve across four sites. Why are you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | **The highest-ROI rehearsal in this pack.** Name the scope before they do and hold only what your quotes carry: "Today I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: if you've led more people than those three at any point, say when and how many, in your own words. If you haven't, say so plainly. Then give your approach to twelve supervisors across four sites *as a plan*: what you'd learn first at each site, how you'd meet each supervisor, which numbers you'd review weekly. **Follow-up 1:** "Peak is one site." Hold on the surge plan as you stated it. Answer slot: if any part of the plan was yours to set, say which. If it was handed to you, say so and describe how you ran it. **Follow-up 2:** "So this would be your first multi-site role?" Don't argue the premise and don't add to your record. Answer slot: if any of your work spanned more than one site, say what. If none did, say so plainly and return to the plan. Concede the scale difference specifically and calmly, and don't fold on what you did | F4 and F1 are the widest gaps between the JD and your material, so this objection will arrive in some form. JD type, because it scores the stated supervisor and site requirements |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Answer it straight: "I haven't used Power BI. My Excel is solid." Then the learning plan, said as a plan: what you'd learn first, by when, and what first report you'd build. Answer slot: if you've built reports in Excel, name what they tracked. If you haven't, say so plainly and stay with the plan. Don't pick a fake weakness. The JD names Power BI, and they can see the gap | F6 is the one gap you stated outright, and naming it before they find it is a credibility gain. JD, because it scores the reporting line |
| A3 | "Our terminals aren't warehouses. Why would your experience carry over?" | JD | [grounded] "7 years in warehouse and distribution ops" | Describe what you did and let them draw the inference: "I've spent seven years in warehouse and distribution ops." Answer slot: if any of it involved terminal operations, say what, in your own words. If none did, say so plainly, then ask what a day at their terminals looks like and say what you'd want to learn first. Don't claim the work is the same kind | F1 is a kind-of-work gap as well as a scale gap. JD, because "terminal operations" is the role's first line |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four terminals dropped this month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is measured, how big the drop is, when it started, whether it's one site or all four. Segment: inbound vs outbound, by shift, by lane or customer, by carrier. Name the data you'd pull and two or three hypotheses. Contain the problem today, fix the root cause, and name the metric that tells you it's fixed. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time line (F2's requirement). Generic, because it's a pattern for the problem, not a fact about Atlas |
| B2 | "You're asked to take cost-per-shipment down across four sites within a year. Where do you start?" | CASE | [generic] | Ask what cost-per-shipment includes here and what each site's baseline is. Break cost into buckets and compare the sites against each other. Pick one or two levers, protect on-time performance while you pull them (say the trade-off aloud), pilot at one site, then roll out. End with how you'd report progress. No claims about your past | F3's requirement asked as a decision. Being ready here matters because F3 is thin |
| B3 | "First 90 days: four sites, twelve supervisors you've never met. What's the plan?" | CASE | [generic] | Days 1–30: listen and learn the numbers at each site, and meet each supervisor one-on-one. Days 31–60: pick a small number of priorities and agree targets. Days 61–90: first improvements and the reporting rhythm. Name the risks (spreading yourself thin, favoring one site) and how you'd manage them. A plan, not a record | Tests F1 and F4 forward-looking, where a plan is the honest form. CASE, because it scores structure |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State the result in its own terms: the mis-pick rate fell 40% after the pick path was redesigned. Answer slots, each in your own words: how the rate was counted, over what period it was compared, and what it's sensitive to. If you don't know how it was counted, say so plainly. That's an honest answer, and a better one than a method you can't repeat under a second question | It's your only headline figure, so it will be probed. EXP, because it tests whether the claim survives scrutiny |
| C2 | "What part of the pick-path redesign was yours, and which assumption behind the 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Attribution first. Answer slot: say which parts were yours and name anyone else's part plainly ("we" for context, "I" for your contribution). Then the weakest-assumption move. Answer slot: name, before they do, the assumption behind the figure you'd defend least, in your own words. If you don't know of one, say so plainly. This pack doesn't supply one | Defend-the-number coverage of the same figure. Attribution and assumptions are where probers go second |
| C3 | "How would you build reporting for four terminals? What's on it?" | JD | [grounded] "solid Excel, never used Power BI" | Build it from the JD: on-time performance and cost-per-shipment, by site and by week, with a short list of drivers under each. Say who reads it and how often. Tool honesty: "My Excel is solid. I haven't used Power BI." The Power BI piece is a learning plan. Answer slot: if you've built a report like this before, say what it tracked. If you haven't, say so plainly and stay with the design | F5 and F6 together. JD, because it scores the reporting requirement, with CASE delivery |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, then three beats in your own terms: seven years in warehouse and distribution ops, the 40% mis-pick reduction from the pick-path redesign, and running the site's peak-season surge plan two years running. Add that you're green belt certified. Concede the premise specifically: someone internal would know their terminals better on day one. Don't run down a person you've never met. Finish within the minute | A composure test built on F1. JD, because it scores fit against the stated role |
| D2 | "You say you 'ran' the peak plan. Did you write it, or execute someone else's?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Hold on the word you used: you ran it, two years running. Answer slot: if you wrote or shaped any of it, say which parts, in your own words. If it was handed to you, say so plainly and describe how you ran it. Hold through two follow-ups by returning to what you ran, never by adding to it | F1's strongest quote, under attribution pressure. EXP, because "how much was actually you" is the test |
| D3 | "Green belt isn't black belt. Is that enough to drive improvement across four sites?" | JD | [grounded] "green belt certified" | Hold: "I'm green belt certified." Answer slot: the JD's Lean/Six Sigma line makes a probe likely on whether you've used it. If you used green belt methods on the pick-path redesign or anything else, say which and how, in your own words. If you haven't, say so plainly. Don't argue the belt colours. Concede that you're not a black belt, which your own quote makes clear | F8 is the plus line, challenged. JD, because it scores the Lean/Six Sigma requirement |

### E — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sales promises customers times our terminals can't always hit. How would you handle that seam?" | CASE | [generic] | Propose principles rather than pretending to know their seam: a shared definition of on-time, an agreed escalation route, a regular review of misses together. Say what you'd bring their team, not only what you'd need from them | A peer seam on the JD's on-time line. Generic, because it's a pattern, not Atlas's actual org |
| E2 | "Tell me about work that spanned teams. How did you handle the credit?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Selection scaffold. If the pick-path redesign involved other people or teams, say who and what was theirs, in your own words. If it was yours alone, say so and pick another time you shared work across teams. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The credit-sharing probe draws on C2's ground. VAL, because it scores collaboration behavior |
| E3 | "Tell me about a time you disagreed with a peer manager." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, where you held your view with tact and the working relationship was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem. Your material carries no story for it, so it's a scaffold |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc in this order: seven years in warehouse and distribution ops, now senior shift manager over three supervisors, the 40% mis-pick reduction from the pick-path redesign, running the site's peak-season surge plan two years running, green belt certified. Answer slot: close with why this role and why Atlas, in your own words. This pack has nothing verified about Atlas to give you | The opener in almost every round. Rehearsing it stops you rambling when the register is relaxed |
| G2 | "What are you doing with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | A casual question on a JD plus line, and still scored. "I'm green belt certified." Answer slot: if you're using it in your current work, say how, in your own words. If you're not, say so plainly and say where you'd apply it first in this role | F8, asked casually. JD, because it scores the plus line |
| G3 | "Why leave your current role, and why now?" | VAL | [generic] | Selection scaffold. Give a reason that points toward this role's scope rather than away from your employer, in your own words, and keep it consistent across every round | A motivation check that comes up in every round. Your material carries no stated reason, so it's a scaffold |
| G4 | "How many of your seven years have been in leadership roles?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give the number of years you've led people, and in which roles, in your own words. If it's fewer than five, say so plainly, then stay with what you've led. Don't round up and don't count non-leadership years. "Required" may be screened literally, so a straight number beats a stretched one | F7 covers the one requirement the JD marks "required". Recruiters ask it early and casually |

### H — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you had to hold a supervisor accountable." | VAL | [grounded] | Selection scaffold. Pick a time with a clear standard that was missed, a direct conversation, and what changed afterwards. Situation, Task, Action, Result, with "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Its theme comes from the JD's "lead a team of 12 supervisors". Grounded on the JD, with no claim about your past |
| H2 | "Tell me about a time you delivered bad news to leadership." | VAL | [generic] | Selection scaffold. It needs a named stake, the moment you said it, and the outcome, including whether the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem. No values page was read, so it's generic |
| H3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. It needs a specific customer impact, the metric you let slip and why, and what you'd do again. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | On-time performance is customer-facing, so this trade-off is natural in freight. Generic |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B1, B3, D1 |
| "drive on-time performance" | B1, E1, C3 |
| "cost-per-shipment down" | B2, C3 |
| "lead a team of 12 supervisors" | A1, B3, H1 |
| "build reporting in Excel/Power BI" | A2, C3 |
| "5+ years operations leadership required" | G4, A1 |
| "Lean/Six Sigma a plus" | D3, G2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do you measure on-time performance today, and how does it differ across the four sites?" | Shows you'd own the headline metric from day one |
| R2 | "What does cost-per-shipment include here, and where has it moved most this year?" | Signals cost discipline and tells you which lever matters to them |
| R3 | "What reporting exists today? Is there a Power BI setup already, or would I be building it?" | Practical, and it tells you how much your Power BI gap matters in this job |
| R4 | "What would the twelve supervisors say is getting in their way most?" | Shows you lead through your supervisors, not around them |
| R5 | "What would make the first 90 days a success, and what would make the first year one?" | Gets the real scorecard. Use it to shape your answers in later rounds |
| R6 | "How is this role's time split across the four sites in a typical week?" | Shows you're thinking about the multi-site job concretely |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has run terminal operations, or operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is this pack's observation: your material says warehouse and distribution and "the site's", not terminals or four sites. A1 and A3's slots stay inside that |
| Has led a team of twelve supervisors, or a large team | Inflated form of F4 | F4's quote at its own scope: a senior shift manager over three supervisors. A1's slot asks only whether you've led more than those three |
| Improved on-time performance or cut cost-per-shipment with the pick-path redesign | Inflated form of F2 and F3 | The quote at its own scope: the 40% belongs to the mis-pick rate. The slots ask only what you saw or tracked |
| Has built reports or dashboards in Excel | Inflated form of F5 | F5's quote at its own scope: "solid Excel". The slot asks only what, if anything, you've built |
| Has used Power BI | A negative you stated, F6 | The plain acknowledgment: "I haven't used Power BI." Plus a learning plan, said as a plan. No slot |
| Seven years of operations leadership | Inflated form of F7 | F7's quotes at their own scope: seven years in warehouse and distribution ops, and a current leadership role. G4's slot asks for the actual number of leadership years |
| Designed the peak-season surge plan | Inflated form of F1's second quote | The quote at its own scope: you "ran" it. D2's slot asks which parts, if any, you set |
| Led Six Sigma projects, or holds a black belt | Inflated form of F8 | F8's quote at its own scope: "green belt certified". D3 and G2's slots ask only how you've used it |

---

## Sources

**Provided documents:** your message (the JD text and your background).

**Searches sent:**
- `"Atlas Freight" regional logistics company values`: refused
- `"Atlas Freight" interview process operations manager`: refused
- `"Atlas Freight" terminals news 2026`: refused

No fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Refused. It would have supplied value names for a values cheat sheet and VAL questions themed on them. H1–H3 stay generic |
| 2. `Atlas Freight interview process operations` | unavailable | Refused. It would have named the rounds and set the persona weights. They fall back to the Generic archetype, with flat weights |
| 3. `Atlas Freight strategy` / recent news | unavailable | Refused. It would have grounded a CO question and the B-bank cases in Atlas's current priorities. There's no CO question, and the cases are generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form. There's no interviewer read, and the reverse questions are role-generic |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Who you're meeting and their relationship to the role (recruiter, hiring manager, peer, panel)** → persona weights reweighted off the flat Generic fallback, and the top bank deepened to 4–5 questions
- **The interviewer's name** → a read of their public professional footprint, persona weights tuned to it, and a reverse question tied to their own path
- **The recruiter's prep email or process details** → the actual rounds in place of the archetype, plus a build section for any presentation or exercise they've announced
- **Permission for the web searches** (rerun of targets 1–3) → Atlas Freight's published values, with a cheat sheet if a values round turns up, plus a grounded loop structure and a CO question on current strategy. Name collisions are possible with a common company name, so anything that can't be attributed to this Atlas Freight won't be used
- **A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes)** → a strategy brief, recent org context and role-family loop reports. Each is offered once, on your say-so
- **Your answers to the answer slots, given here outside a drill** → F7 (leadership years), F1 (terminal or multi-site work), F4 (leading more than three) and F5 (Excel reporting) regenerate with your own words, which upgrades A1, A3, G4 and C3
- **Your green belt certificate, or the before-and-after mis-pick data** → F8 and F2 can move from medium to high confidence: a certificate is the inspectable proof for a credential, and the data for a figure
- **A job-underwriter dossier** → an evidence-derived highest-ROI objection and guardrails confirmed with you, in place of the ones this pack inferred from your message. It's not needed for this pack
