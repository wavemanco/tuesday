Web search was blocked by permissions, so I'm building the pack from your JD and background alone.
I've saved your prep pack as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-denied-be0e9c00/saltmarsh-games_live-operations-producer_interview_pack.md`. I assumed Tobias is your future manager and the interview is one conversation with him. Your web search permissions blocked the searches, so the pack uses only your JD and background, with nothing on Saltmarsh's values, games or news, or on Tobias himself.

Your interview is tomorrow, so these matter most tonight:
- **A1 is the question to rehearse hardest.** It's "what in your background shows you can coordinate design, art, engineering and community across two titles?" Your material doesn't show that coordination, and it's a headline duty in the JD.
- **Your strongest line is "Wrote the release checklist our QA team still uses."** Say it exactly like that.
- **Have plain answers ready for your two stated gaps:** "I haven't led a team" and "I haven't worked on a game with in-app purchases." Say each once and move on. The JD doesn't actually list either.
- **Play both titles before Friday.** I couldn't research them, so D2 ("what do you know about our games?") is down to you.

Say the word and I'll play the Skeptic on A1.
I can also save a tuesday-dossier.md listing the gaps this prep found, for you to use in later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias going to be your manager, and did the recruiter say what the 60 minutes covers, like a conversation, a case, or something to prepare? Either answer changes how the questions are weighted, and a prepared task would get its own section.
Would you like to allow web search so I can pull in Saltmarsh's values, their interview process, recent news and Tobias's public profile? I can also run a deeper pass (up to 6 more searches and 2 more fetches, several more minutes).

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Assumed to be the hiring manager; you didn't say.
**Format:** 60 minutes, Friday 13 November, which is tomorrow.
**Built from:** the JD and background you pasted. Every web search was refused by permissions, so nothing in here comes from research on Saltmarsh or Tobias.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: the tone, the pressure, the follow-ups.
- **Types** describe *what is being scored*:
  - **VAL**: behaviour and values. Do your past actions show how you work?
  - **EXP**: experience deep-dive. Does what you said survive scrutiny, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Have you done your homework on their games and direction?
  - **CASE**: live problem. Structure and reasoning on a problem from the actual job.
- **Provenance labels:** `[grounded]` traces to your JD or your own words, `[inferred]` is this pack's derivation, and `[generic]` is a role-family pattern that makes no claim about Saltmarsh.
- **Answer slots** are places where the pack doesn't know the answer and won't make one up. Each has two honest branches, and either one is a good answer.
- Guidance is scaffolding, not a script. Put every answer in your own words.
- Question IDs go A, B, C, D, E, G, H. F is skipped because F1 to F9 are the fit-snapshot rows.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are there. Your material doesn't say whether the title was run as a live service, or whether it was on mobile. Words: "I have four years as an associate producer at a puzzle-game studio." Keep "associate" every time. Answer slot: the JD's "live-service" and "mobile titles" make a probe on both likely. If the title was run as a live service, or shipped on mobile, say so in your own words; if not, say so plainly and stay with the weekly content-drop calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Nothing has been inspected behind this line, though, so expect a probe. Lead with its own terms: "For the last two years I ran the weekly content-drop calendar for our main title." The beats are weekly, two years and the main title |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Adjacent work: a weekly content-drop calendar for one title, where the job is a live-events calendar for two. Keep your words at the quote's scope: say "content-drop calendar", never "live-events calendar", and one title, not two. Answer slot: the JD's "plan" makes a probe likely on whether you also decided what went into the drops. If that was yours, say how in your own words; if it wasn't yours, or the content arrived already decided, say so plainly and stay with running the calendar. Running two titles is something you describe as a plan, never as a past |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | discovery | Your material doesn't show which teams you worked with on the drops. Coordinating isn't the same as leading, so the negative you stated answers a different question. Answer slot: if design, art, engineering or community work fed the drops and lining it up was part of your job, name the teams and what you did, in your own words; if it wasn't yours, say so plainly and return to the calendar you ran. Words for a question about managing people: "I haven't led a team." |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Adjacent work: monthly numbers presented upward, where the job is owning a review after each event. Words at their scope: "I presented the monthly retention numbers to the studio head." Never "owned" or "analysed". Answer slot: the JD's post-event review line makes a probe likely on whether drops were reviewed after they went out. If they were and that review was yours, say how in your own words; if there was no such review, or it wasn't yours, say so plainly and stay with the monthly numbers you presented |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | Presenting the numbers touches this requirement but doesn't show what was in them or how they were counted. Answer slot: name the retention measures those numbers held and how they were counted, in your own words; if you didn't know how they were counted, say so plainly, which is an honest answer and not a failure |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | This is your strongest row. Say it in its own terms: "I wrote the release checklist our QA team still uses." Say "wrote", not "owned" or "ran QA". Nothing has been inspected behind it, so expect a probe |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | The checklist is written work that people still use. It doesn't show the writing this role adds, such as a post-event review that several teams read. Answer slot: if you wrote other documents for teams or for leadership, name one in your own words; if not, say so and stay with the checklist |
| F9 | Live events on mobile titles are often paired with in-app purchase offers. This is a role-family pattern; the JD doesn't name it | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | You stated this gap, and the JD doesn't list it. Words: "I haven't worked on a game with in-app purchases." Then say how you'd learn it, as a plan and never as a past. Add nothing to make it feel smaller |

---

## Persona table

These weights assume a hiring-manager round and use the generic loop pattern, because no source on Saltmarsh's interview process was read. If you know more, recalibrate.

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Quiet probes on F4, F5 and F9: coordination across four teams, review ownership, in-app purchases | High | Hiring-manager prior. The pack's biggest gaps sit on JD headline duties | Rehearse A1 until it's boring. Stay inside your quotes, say limits plainly, then give a ramp plan |
| Case / Strategist | "Plan this calendar", "diagnose this dip", "art is late" | High | Hiring-manager prior. The JD's duties turn easily into live problems | Clarify, then objective, then structure, then metrics, then risks. Think aloud |
| Data-Driven Prober | "Which measures were in those numbers? How were they counted?" | Medium | The JD names retention metrics and KPIs, and you presented retention numbers | Know what you can and can't say about how the numbers were counted, and say plainly where you don't know |
| Conversational | Biography opener, "what do you know about our games?" | Medium | Generic pattern: openers are scored even when they feel casual | A pre-built 90-second arc taken from your four quoted sentences |
| Pressure | Time-boxed "why you over someone else?" | Low | Not signalled by anything in hand; included so the style isn't new on the day | Pause, anchor in a quote, concede the real gap once, then hold |
| Peer Evaluator | Cross-team conflict scenarios: community against design, engineering against QA | Low | The JD's coordination line makes collegial scenarios likely, though the interviewer isn't a peer | Propose principles for handling the seam rather than claiming to know it |
| Values / Behavioral | "Tell me about a time…" | Low | No values-style round detected: the generic fallback has none and no values page was read | Selection scaffolds that end in an honest branch |

---

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role coordinates design, art, engineering and community on every update, for two titles. What in your background shows me you can do that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team" | **The highest-ROI rehearsal in this pack.** Open with the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if design, art, engineering or community work fed those drops and lining it up was yours, name the teams and what you did, in your own words; if it wasn't yours, say so plainly and stay with the calendar you ran. Then two titles and four teams, as a plan: what you'd want to learn in the first weeks and how you'd set up the calendar. Follow-up 1 ("who actually got art to deliver?"): go back to your slot answer and add nothing to it. Follow-up 2 ("have you managed people?"): "I haven't led a team." Say it once, without apology, then go back to the calendar | F4 is `none given` against a headline JD duty and F3 is one title against two, so this objection will come in some form. JD type, because it scores the coordination requirement directly |
| A2 | "Have you managed people? If not, how will you get four disciplines to hit the same date?" | JD | [grounded] "Never led a team" "I ran the weekly content-drop calendar for our main title for the last two years." | Plain answer first: "I haven't led a team." Then: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's coordination line makes a probe likely on getting people you don't manage to hit dates. If you did that on the drops, say how in your own words; if you didn't, say so and describe how you'd approach it, as a plan | The negative comes from F4. Rehearsed so the honest answer comes out flat and short, not defensive |
| A3 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" "Presented the monthly retention numbers to the studio head." | "I haven't worked on a game with in-app purchases." Then the closest thing the JD does name: "I presented the monthly retention numbers to the studio head." Then how you'd get up to speed, as a plan: shadowing the people who own offers, reading past event reviews, playing both titles' events. Never suggest past monetisation work | F9 is a gap you stated. The JD doesn't name it, so this is a role-family probe, not a Saltmarsh requirement. JD type because it scores readiness for the job |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Pick one real item and say plainly what you have and haven't done on it, in your own words. Then a short ramp plan. Choose something the JD lists, not a fake weakness. If you name an item your material is silent on, describe it from your own experience; the pack won't supply what you did | A stock Skeptic stem. Scored on honest self-assessment, so the guidance makes no claim on your behalf |
| A5 | "You've been an associate producer. What makes you ready for a producer role on live-service games?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Three beats, each in its quote's own words: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist your QA team still uses. Answer slot: if the title was run as a live service, say so in your own words; if not, say so plainly and stay with the weekly drops. Then why now, in your own words | This covers the "3+ years live-service" line (F1) and the step from associate to producer. JD type because it tests the stated requirement |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Plan a three-month live-events calendar for two titles. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: each title's goals for the quarter, the audiences, each team's capacity, fixed dates and lead times, and what counts as success. Then lay out a cadence per title, the dependencies by discipline, buffers, review points and risks. One line of grounding is allowed, in the quote's words: "For the last two years I ran the weekly content-drop calendar for our main title." Then go back to the case | The JD's first duty (F3), asked live. CASE because it scores structure, not your record |
| B2 | "An event went live yesterday and day-1 retention for participants is down on the last one. Diagnose it." | CASE | [generic] | Check measurement first: same definition, same cohort, any tracking change. Then segment: new against returning players, platform, region. Then the event itself: difficulty, rewards, length. Then technical problems: crashes, bugs, the release. Then outside factors. Finish with what you'd do today and what goes into the post-event review | Tests the retention and KPI lines (F5, F6) as reasoning, with no claim about your past |
| B3 | "Art will be a week late on assets for the next update's event. The release date is fixed. What do you do?" | CASE | [generic] | Options: cut scope, reuse assets, swap the event order, or move the date. Say who you'd talk to and in what order, what you'd tell community, and how you'd stop it happening again. State your recommendation and the trade-off | Coordination (F4) as a live problem. Answers rest on judgment, not history |
| B4 | "What does a good post-event review look like to you, and how would you write it so every team reads it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: the goals set before the event, KPIs against target, what worked and what didn't by discipline, player feedback through community, and decisions with owners. Writing: a short summary up top, one page, decisions highlighted. Answer slot: the JD's post-event review line makes a probe likely on whether you've run one. If you have, say how in your own words; if there was no such review, or it wasn't yours, say so plainly and add that you presented the monthly retention numbers to the studio head | Covers F5 and F8 together. JD type because both are stated requirements |
| B5 | "Both titles want the same engineering week for their big event. How do you decide?" | CASE | [generic] | Clarify each event's goal and the cost of moving it, check the dependencies, and see whether the work can be split. Then bring a recommendation with its trade-off to whoever owns the call. Show that you'd decide with data and escalate with an option, not with a problem | The two-title part of F3, tested as prioritisation |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to your studio head. Which measures were in them, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: name the measures and how they were counted, in your own words. Then name the assumption behind them you'd defend least, before they ask. If you don't know how they were counted, say so plainly and say who did. Don't name a measure you didn't report | F6 is discovery. This is where "comfortable with retention metrics" gets tested |
| C2 | "Which part of those numbers was yours: pulling them, analysing them, or presenting them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The quote says you presented them. Answer slot: if any of the pulling or analysis was yours, say what, in your own words; if your part was presenting, say so plainly and stay with that. Precise attribution earns more credit here than a bigger claim | An attribution probe on F5 and F6. Rehearsed so the honest answer is ready |
| C3 | "What KPIs would you put on a post-event review, and why?" | JD | [generic] | Group them: participation, retention against your baseline, engagement depth, player sentiment from community, and stability. For each, say what decision it would drive. Name one metric you'd treat with caution and why | Covers the KPI line in F5 as judgment, not history |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc, one beat per quote, in this order: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist your QA team still uses; the monthly retention numbers you presented to the studio head. Close with why live operations and why Saltmarsh, in your own words | The opener is scored. Every beat is one of your sentences, so nothing in it can break under a follow-up |
| D2 | "What do you know about our games?" | CO | [generic] | Research didn't run, so do this yourself tonight: play the two titles you'd work on, including whatever event is live, and note one specific thing you saw as a player. Say what you saw, not what you assume about their numbers | Homework is tested even in casual questions. Generic because the pack has no Saltmarsh facts |
| D3 | "What are you playing at the moment?" | CO | [generic] | Name a live-service mobile game you actually play and one thing about its events that you'd keep or change. If you don't play one regularly, say so and name what you've been studying | A casual question about the job's core interest. Scored on genuine engagement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause. Concede once: "I haven't worked on a game with in-app purchases." Then hold on the two quotes: "For the last two years I ran the weekly content-drop calendar for our main title, and I wrote the release checklist our QA team still uses." Hold through two follow-ups by going back to those two lines and adding nothing new. Close with how fast you'd learn the part you're missing | F9 under time pressure. Scored on composure: hold, then concede |
| E2 | "That release checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it, and our QA team still uses it." Answer slot: if others contributed sections or changed it later, say what was theirs; if it was all yours, say so plainly. Don't add a result for it that you haven't stated | F7 is your strongest row, so it's the one a Pressure interviewer will push to see if it holds |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community says players are angry about an event's difficulty two days in. Design says it's working as intended. What do you do?" | CASE | [generic] | Get the facts first: what players are saying, what the data shows, how big the problem is. Get design and community in one conversation. Agree what would trigger a change, decide, then tell players what's happening. Show that you respect both sides and still reach a decision | Coordinating design and community (F4), asked as a seam conflict |
| G2 | "On release day, a fix hasn't passed QA. Design wants it shipped anyway. What happens?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Say who owns the call and what the risk is if it ships. Lay out options: ship, hold, ship behind a toggle, or move the date. Recommend one. One line of grounding is allowed: "I wrote the release checklist our QA team still uses." Don't claim you made release calls if you didn't | The QA checklist line (F7), turned into a judgment call |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, a moment you didn't back down, and a working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | A persona stem. Your material carries no story for it, so this is a scaffold only |
| H2 | "Tell me about a time an update didn't go to plan." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: look across the weekly content-drop calendar you ran for a drop where something slipped. It needs what happened, what you did, and what changed afterwards. If no such time comes to mind, say so plainly, then describe how you'd handle one | The JD's post-event review line makes "what did you learn" likely. Nothing here assumes a drop went wrong |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A1, B1, B5 |
| Coordinate design, art, engineering and community teams | A1, A2, B3, G1 |
| Own the post-event review and its KPIs | B4, C3, B2 |
| Manage the release checklist with QA | E2, G2 |
| 3+ years producing live-service games or apps | A5, D1 |
| Experience running a content calendar | A1, B1, H2 |
| Comfortable with player-retention metrics | C1, C2, B2 |
| Clear written communication | B4 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like on your team today, and who reads it?" | It's the JD item you'd own, and it shows you're already thinking about the reader |
| R2 | "Are the two titles' calendars planned together or separately, and where do they collide?" | It goes straight to the two-title part of the job |
| R3 | "Which retention measures matter most for these titles right now?" | It shows you're comfortable with metrics without claiming more than you have |
| R4 | "Where does handoff between design, art, engineering and community slip most often today?" | It signals that coordination is the job, and his answer tells you where you'd start |
| R5 | "What would you want this person to have taken off your plate in the first 90 days?" | It makes him picture you in the role, and gives you a target |
| R6 | "How did you come into leading live operations here, and what did you have to learn fast?" | It invites his own story. It's not built from his profile, because none was read |
| R7 | "What are the next steps after today?" | Practical, and it closes cleanly |

---

## Prohibited claims

The pack won't coach any of these claims.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated, F4 | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases or on monetised events | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says content drops for one title, not live events for two |
| Producer, with "associate" dropped | Inflated form of F1 | "4 years as an associate producer at a puzzle-game studio." Keep "associate" every time |
| Owned the retention KPIs | Inflated form of F5 | "Presented the monthly retention numbers to the studio head." C1 and C2 slots ask only what was in them and which part was yours |
| Ran QA, or owned the QA process | Inflated form of F7 | "Wrote the release checklist our QA team still uses." |

Coordinating the four disciplines isn't listed here. Your material is silent on it rather than stretched, so it's an answer slot (F4, A1).

---

## Sources

**Provided documents:** the JD text and your background, both pasted into your message.

**Searches sent (all four were refused by host permissions, so none returned anything):**
- "Saltmarsh Games mobile studio values": refused
- "Saltmarsh Games interview process producer": refused
- "Saltmarsh Games news 2026": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every call was refused. It would have themed VAL questions with their published values, and a values cheat sheet if a values round showed up |
| 2. Saltmarsh Games interview process, producer | unavailable | Every call was refused. It would have replaced the generic loop fallback with their documented rounds and reset the persona weights |
| 3. Saltmarsh Games strategy and recent news | unavailable | Every call was refused. It would have grounded D2 and added CO questions on their titles and direction |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Every call was refused. It would have added an interviewer read, adjusted the persona weights, and tied R6 to his actual path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Whether Tobias is your future manager, and anything the recruiter said about the 60 minutes** → reweighted personas, and a build section if there's something to prepare
- **Web search allowed** → targets 1 to 4 rerun: their values, the real loop, CO questions on their titles, and an interviewer read with a reverse question tied to his path
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, his talks or writing, loop reports and recent org context
- **How much prep time you have tonight** → a prioritised prep schedule sized to it
- **Your answers to the answer slots** (live service and mobile, the teams on the drops, post-event reviews, what was in the retention numbers) → F1, F3, F4, F5 and F6 upgrade, along with A1, A5, B4, C1 and C2
- **A document you can show, such as a redacted page of the release checklist** → F7 and F8 confidence can move from medium to high
- **A dossier from an earlier evaluation of this role** → an evidence-derived highest-ROI objection and an external guardrail list instead of a locally built one. The pack is complete without it
