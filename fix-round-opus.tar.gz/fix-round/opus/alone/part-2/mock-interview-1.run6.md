Quick status: my web searches were all blocked by permissions, so I'm building the pack from what you gave me and noting that in its Sources section. Writing it now.
I've built Priya's prep pack for the 60-minute conversation with Dan. Your message covered everything I needed, so it's built on that alone. My four web searches (Northwind's values, its interview process, a check on your research note, and Dan's public profile) were blocked by permissions. So the strategy questions rest on your research note, which nothing has verified, and the pack has no section on Northwind's published values.

**What's in the pack:**
- **Fit snapshot:** each JD requirement set against Priya's background, quoted exactly from your message, with how big the gap is and how to talk about it.
- **22 questions in seven interviewer-style banks**, tagged by question type (experience, role, company, case, behavioral). Each has answer guidance, the background line it rests on, and why it's included and categorized that way.
- **Reading Dan:** what his profile means for the conversation. He's a peer, calls himself data-driven, and comes from pricing.
- **Supporting sections:** a table mapping each JD requirement to the questions that cover it, six questions for Priya to ask Dan, a list of claims the pack won't coach, sources, and what more input would add.

**How it's weighted:** two styles dominate:
- **Numbers prober:** Dan is "relentlessly data-driven", so every figure will be pushed on how it was counted.
- **Peer evaluator:** he'd share a VP with Priya, so expect questions about where their teams meet and what she'd bring his.

Case questions lean toward pricing and partner economics, which is his background.

**Most important question to rehearse:** D1, "I see consumer-tech product strategy and no classic sales-ops or quota-setting. Why should I believe you can own GTM for two new B2B product lines?" Its guidance starts by stating the gap honestly, then gives three follow-ups with exact wording for what to concede.

**Where she must not overstate:**
- **The ~$400M:** she proposed the change and the change was credited with the uplift. She didn't drive it.
- **The revenue model:** it was used in carrier negotiations. She didn't necessarily negotiate.
- **Volume targets:** these aren't quotas.

Where your notes don't say what she did, the guidance leaves a marked spot for her to fill from her own experience, or to say plainly it wasn't hers.

If you want, I can play Dan and run Priya through D1 with live follow-ups, then give feedback against that question's guidance. I can also save a `tuesday-dossier.md` file recording the gaps this prep exposed, for later sessions, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Conversation:** one 60-minute conversation with Dan Kovac, Director of Sales Strategy. Dan is a **peer**: you would both report to the same VP.

---

## How to use this pack

- **Personas = how a question is asked.** They describe the style: a prober, a peer, a skeptic. **Types = what is being scored.** Rehearse both, because the same content lands differently when it comes as a collegial aside instead of a challenge.
- **Type key** (each question carries one primary type, and its rationale names any secondary one):
  - **EXP**: work-experience deep-dive. Does the claim hold up, and what part was actually yours?
  - **JD**: role-driven. Can you do the listed job, including the parts where you have gaps?
  - **CO**: company and strategy. Can you think at Northwind's level: its priorities, its competition?
  - **CASE**: live problem. Structure and reasoning on a problem from the actual role.
  - **VAL**: behavioral. Does your past behavior show the values in question?
- **Provenance labels:** `[grounded]` means traceable to what was provided. `[inferred]` means derived, with the derivation named. `[generic]` means a role-family pattern with no claim about Northwind or about you.
- **Answer slots** mark places where the material doesn't say what happened. A slot names the probe Dan is likely to make and gives two honest branches. Fill it only from what you actually did, or say plainly that it wasn't yours or didn't happen.
- **The guidance is scaffolding, not a script.** Every sentence about your past is built from the background lines in the fit snapshot and goes no further than they do. Put it in your own words, and don't add to it.

---

## Fit snapshot

Requirements come from the JD highlights in the coach's message. Evidence is the coach's description of your background, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message; "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | The material shows product strategy and ops, plus a proposal that was credited with an uplift. It does not show GTM ownership, so your words stay at that scope: "I spent nine years in product strategy and ops at a large consumer-tech company, and I proposed a store-surface change that was credited with roughly a $400M ARR uplift." Answer slot: the JD's "own GTM strategy" line makes a probe on launch or go-to-market decisions likely. If any of those decisions were yours, say which ones and how you decided, in your own words. If none were, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Your material does not show work across a land, adopt, expand and renew lifecycle. Strong evidence here would be a named base of accounts or partners, a lifecycle stage you sized, and a decision that sizing changed. Answer slot: the JD's whitespace line makes a probe on this likely. If any of your work touched adoption, expansion or renewal of an existing base, say which stage and what you did, in your own words. If none did, say so plainly and show the method instead (C2) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | There's no gap here. But nothing stands behind the line that Dan can inspect, and he calls himself data-driven, so expect to be asked to walk through an analysis. Lead with the skill in its own terms. If you have an analysis you ran yourself, have it ready (A4) |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Building a revenue model is next to designing a partner motion, but it is not the same work. Words at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's "required" line makes a probe on how partnerships were shaped likely. If any part of the terms discussed in those negotiations was yours to shape, say which part, in your own words. If none was, say so plainly and stay with the model and how it was used |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | This line already speaks to cross-functional influence, in other terms. Reword only the quote and add nothing: "I set annual volume targets, with consensus across orgs." |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | low | [inferred] | discovery | Daily use of AI tools touches the JD's AI line, but it doesn't show whether it meets it. The derivation is the JD's line set against a usage habit. Answer slot: expect a probe on what you use AI tools for. If any of that use is in analysis or strategy work, say what for, in your own words. If it is general productivity, say so plainly. Never present it as building or launching AI products |
| F7 | Fluency in quota, territory and sales-ops mechanics. This role-family expectation is sharpened by meeting the Director of Sales Strategy; it is not in the JD highlights | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | No wording can close this gap, and your material says so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as something you've done. Dan's team is the natural place to learn it (B2). Never let "set annual volume targets" stand in for quota-setting |

---

## Reading the interviewer

Everything here comes from your message's description of Dan's profile. The search that would have checked it was refused (see Sources), so none of it is independently verified.

| Signal | Source | What it means for this conversation |
|---|---|---|
| Director of Sales Strategy who would be your peer under the same VP | your message | He is weighing what you would add to his work and what you would cost it. Expect questions about where your two teams meet, plus a reciprocity question (bank B). The objections from other banks arrive in collegial form |
| Self-describes as "relentlessly data-driven" | your message, quoting his profile | Every number you mention will be pushed two levels deep: how it was counted, and what it is sensitive to. The Prober is the top-weighted persona (bank A) |
| Career built on pricing and monetization roles | your message | Cases will lean toward pricing, packaging, margin and unit economics, which is his native language. Answer cases in those terms (C1, C3) |
| One early-stage-startup chapter | your message | Expect some skepticism about big-company pace, and questions about working with thin data and no team (A4, A5). Your material shows no startup chapter, so this pack doesn't offer a shared career jump. The mirror available to you is vocabulary: price, package, margin |

---

## Persona table

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Asks for the denominator, the attribution and the assumptions behind every figure | **High.** The peer default leans this way, and his "relentlessly data-driven" self-description raises it further | Know what you can and can't say about how each figure was counted. Name your weakest assumption before he does. Say "I don't know" plainly where that's true (A1, A2) |
| B. Peer Evaluator | Where the teams meet, what you'd need from him, how credit is shared, how you'd disagree | **High.** This is the peer default, and you'd share a VP | Use reciprocity: say what you bring his team, not just what you need from it. Propose principles for the seam rather than pretending to know how it works today |
| C. Case / Strategist | Live problems in pricing, packaging and partner-economics language | **Mid.** His pricing background pulls cases in, but a peer probes more than a hiring manager sets cases | Clarify, then objective, then segments, then approach, then metrics, then risks. Think aloud, and respectfully challenge one premise per case |
| D. Skeptic | Pushes on the gap between consumer-tech product strategy and B2B GTM, and on sales-ops | **Mid.** F7 is exactly his area, and the JD marks partner-motion design as required (F4) | Rehearse D1 until it's boring. Build bridges only from what you actually did, then give a concrete ramp plan |
| E. Pressure | Quick "how much was you?" or "why you?" challenges | **Low.** Peers rarely stress-test, though a data-driven follow-up chain can feel like pressure | Pause and restate the question. Hold your position through two follow-ups, then concede the specific, true thing |
| F. Conversational | The opener, and casual asides about AI | **Low.** It's almost certainly the first five minutes, and it is still scored | Have a 90-second arc ready, and treat casual AI questions as scored |
| G. Values / Behavioral | One or two "tell me about a time" questions | **Low.** Your message describes a single conversation with a peer and names no values round | Map a story to each where you have one. Where you don't, use the selection criteria and the honest branch |

---

## Question banks

### A. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The store-surface change you proposed was credited with a ~$400M ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the sentence at its own scope: "I proposed a store-surface change, and it was credited with roughly a $400M ARR uplift." Keep "proposed" and "credited". Never upgrade them to "drove" or "delivered". Then four answer slots, each in your own words: how the figure was counted and who credited it; what it is sensitive to; which assumption behind it you would defend least; and which part beyond the proposal was yours. If you don't know how it was counted, say so plainly ("I don't know exactly how the attribution was done") and return to what you proposed | F1's headline figure is the first thing a self-described data-driven interviewer will pull on. EXP because it tests attribution and what was actually yours |
| A2 | "Which assumption behind that ~$400M would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | This is the weakest-assumption move, and the pack does not name the assumption for you. Answer slot: name it in your own words, then say what would change if it were wrong. If you don't know the assumptions behind the attribution, say so plainly and say what you would want to check. Through all of it, hold the core of the quote: the proposal was yours | This is the Prober's second level on F1, and Dan's style makes it near-certain. EXP for the same reason as A1. Rehearse it separately because the second follow-up is where candidates over-claim |
| A3 | "Walk me through the partner-level revenue model you built. What went into it, and how was it used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats the quote states: you built it, it was partner-level, and it was used in carrier negotiations. Describe what went into it in your own words. Answer slot on use: if you saw how it was used in those negotiations, say what it informed. If you didn't, say so plainly and stay with what the model did. Never say you negotiated with carriers; the quote says the model was used, not that you sat at the table | F4 is your only evidence for the required partner-motion line, and someone with a pricing background will go into the model's mechanics. EXP because it tests what was yours versus what others did with it |
| A4 | "Tell me about an analysis you ran yourself in SQL and Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" | Your material states the skill but names no specific analysis, so this is a selection scaffold. Pick one where you wrote the queries yourself, a decision was on the line, and you can name what changed. Walk through the question, the data, what you found and what was decided, using only your own details. If no analysis comes to mind that changed a decision, say so plainly, then give the nearest one you ran, or how you would approach one here | The JD's "independent analysis" line meets F3. Dan's data-driven style and his startup chapter both make "did you do it yourself?" likely. JD primary, EXP delivery |
| A5 | "For a new product line with little history, how would you set first-year volume targets, and how would you get Sales to agree to them?" | CASE | [grounded] "set annual volume targets with cross-org consensus" | Structure it. Clarify the product, the buyer and the motion (direct or partner). Then the anchors: comparable launches, pipeline, capacity, price point. Give a range rather than a point, plus the leading indicators you'd watch and a re-forecast cadence. Then the agreement process. One clause about your past, at the quote's scope: "I've set annual volume targets with cross-org consensus before." Don't call them quotas (see F7) | This is the JD's GTM ownership put as a live problem. It touches F5 and sits right on F7's border, which is why the guidance holds the line between volume targets and quotas. CASE because it asks about no past beyond the one quoted clause |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We'd both report to the same VP. Where do you see the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [generic] | Don't pretend to know the seam. Propose principles: one owner per number, shared data definitions, and when you disagree, go to the VP with one joint recommendation rather than two competing ones. Then ask how it works today. The question needs no claim about your past, so the guidance makes none | This is the classic peer question, and the JD's cross-functional influence line is what's being scored. JD primary. `[generic]` because it is a pattern for the seam, not a fact about Northwind's org |
| B2 | "What would you need from my team in the first 90 days, and what would my team get from you?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "skilled in SQL/Tableau" | Need: "I don't have classic sales-ops or quota-setting experience, so I'd lean on your team for quota and territory mechanics." Give, as a plan: doing your own data pulls rather than queueing on his analysts, since you're skilled in SQL and Tableau, and sharing what you build. Make the offer concrete and the ask modest | This is reciprocity, and it is the safest place to state F7 on your own terms before D1 arrives. F3 is what you offer in return. JD because it scores fit with the team |
| B3 | "Tell me about a time you got cross-org consensus on a number." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5. The beats the quote states: annual volume targets, set by you, with cross-org consensus. Answer slot: the JD's cross-functional influence line makes a probe on how the consensus was reached likely. If some orgs disagreed, say which (by role), what moved them and which part of that was yours, in your own words. If there was no real disagreement, say so plainly and describe how the consensus was reached | F5 is your best evidence for a stated JD requirement, and Dan has to get agreement on numbers himself. EXP because he will test what was yours |
| B4 | "How do you handle credit when work spans teams? Take the store-surface change you proposed." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the quote's verb: "I proposed it." Answer slot: who else built or shipped it, named by role. If you don't know the full chain, say so. Use "we" for the context and "I" only for the proposal. This answer is also your rehearsal for E1 | Peers probe how credit is shared, and F1's figure is the obvious place to ask. EXP. It also sets up a consistent answer before the Pressure version arrives |

### C. Case / Strategist (weight: mid, tilted toward pricing)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles a competing capability in at no extra cost. How should one of our new product lines respond: price, package, or partner?" | CO | [grounded] | Clarify which product line and segment first. Set the objective against the profitability priority. Lay out the options: compete on depth where the bundle is shallow; change packaging or pricing, possibly alongside Compass; or partner or integrate with the platform. Pick one and name the metric that would show it working: win rate against bundled deals, discount depth, gross margin. Challenge one premise: "free" in a bundle is rarely free to the buyer in total cost. No claim about your past | The bundling threat and the profitability priority both come from your research note, and his pricing background makes this his native case. CO primary, CASE delivery. `[grounded]` on the research note, which is unverified (see Sources) |
| C2 | "How would you find whitespace across land, adopt, expand and renew for one of the new product lines? What's the first query you'd write?" | CASE | [grounded] | Define the account universe. Tag each account's lifecycle stage. Cross-tab the installed base against adoption of the new line. Add propensity signals such as usage, renewal date and products held, and size the whitespace by segment. First query: accounts × current products × usage × renewal date, then a Tableau view by segment. Tie it to the enterprise expansion priority. No claim about your past | F2 is a discovery gap. This case lets you show the method without a past claim, and D2 covers the past. CASE. `[grounded]` on the JD line |
| C3 | "Design the partner motion for Compass: which partners, what's in it for them, and how do we measure it?" | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure it: partner types, the value each gets, the economics (margin or revenue share, which is Dan's language), enablement, rules for conflict with direct sales (his seam), metrics (partner-sourced and partner-influenced pipeline, time to first value), and risks (channel conflict; whether the bundling vendor is a partner or a rival). One clause about your past, at its scope: "Where I'd start is partner-level economics. I built a partner-level revenue model that was used in carrier negotiations." Don't present that as having designed a motion | This puts the required partner-motion line (F4) on a stated company priority. CASE. The quoted clause is the only past claim, and it stays inside F4 |
| C4 | "Enterprise expansion, Compass, profitability. If Emerging Products GTM could push only one hard in year one, which?" | CO | [grounded] | Pick one and defend it. One defensible line: treat Compass as an expansion lever into existing enterprise accounts, judged against a profitability bar. Name the trade-off you are accepting, then ask how the VP currently ranks them. Frame the three as the priorities you've read about, not as inside knowledge. No claim about your past | All three priorities come from your research note. A peer will want to see whether you think at the VP's level. CO |

### D. Skeptic (weight: mid; holds the highest-ROI question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I see consumer-tech product strategy and no classic sales-ops or quota-setting. Why should I believe you can own GTM for two new B2B product lines?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" | **The highest-ROI rehearsal in this pack.** Name the limit before he does: "I don't have classic sales-ops or quota-setting experience." Then what you did, at its own scope: "I spent nine years in product strategy and ops at a large consumer-tech company. I built a partner-level revenue model that was used in carrier negotiations, and I set annual volume targets with cross-org consensus." Stop there and let him draw the inference; don't call it GTM experience. Then the ramp, as a plan and never as a past: what you'd learn first from his team, and what you'd own from day one. **Follow-up 1, "So who owned go-to-market?"** Answer slot: if any launch or GTM decision was yours, say which in your own words. If not, say so plainly and return to product strategy and ops. **Follow-up 2, "Have you ever set a quota?"** "No. I've set annual volume targets, not quotas." **Follow-up 3, "Then why take the risk on you?"** Hold, and add nothing: repeat the three sentences plus the plan. Concede exactly the sales-ops gap and never the work you did | F7 is a gap you have stated yourself, F1 and F4 only bridge to the role, and Dan works in exactly the area of the gap. This objection will come in some form, probably collegially. JD because it scores the core mandate. The deepest rehearsal here means more follow-up levels and more exact concession wording, never more claims |
| D2 | "Land, adopt, expand, renew: where have you worked that lifecycle yourself?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Answer slot: if any of your product strategy and ops work touched adoption, expansion or renewal of an existing base, say which stage and what you did, in your own words. If none did, say so plainly, return to your nine years in product strategy and ops, and offer the method instead: "Here's how I'd find the whitespace" (C2) | F2 is silence in the material, and the JD names this lifecycle directly. The slot's second branch allows that the premise may simply be false. JD |
| D3 | "Partner-motion design is a hard requirement here. Which partner motion have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Answer slot: if any part of the terms discussed in those carrier negotiations was yours to shape, say which part, in your own words. If none was, say so plainly and stay with the model: you built it, it was partner-level, and it was used in carrier negotiations. If he follows up, return to the model rather than adding to it. Then show the design thinking live (C3) | The JD marks F4's requirement as required, and the bridge is thin. JD. It is paired with C3 so the honest limit is followed straight away by visible capability |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause first. Hold: "I proposed the change. It was credited with roughly a $400M ARR uplift." First push ("but you didn't build it"): answer slot. Say who built and shipped it, by role, or say plainly that you don't know the whole chain. Second push: concede specifically that the uplift was credited to the change, not to you, and that you can't claim more than proposing it. Don't fold on the core: the proposal was yours. Keep it consistent with B4 | This is the persona's signature attribution stem aimed at F1's figure. EXP. Hold-then-concede is the skill being scored |
| E2 | "Sixty seconds: why you over an internal sales-strategy person who already knows our customers?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "skilled in SQL/Tableau" | Concede the true part first: they know Northwind's customers and you don't yet. Then three things at their own scope: consulting followed by nine years in product strategy and ops; a partner-level revenue model you built that was used in carrier negotiations; and that you're skilled in SQL and Tableau and do your own analysis. Close with one line on the new product lines. Stay under 60 seconds | A time-boxed challenge on F1, F3 and F4 together. JD because it scores fit for the role over an alternative |

### F. Conversational (weight: low; still scored)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Add one or two proof points at their own scope: the partner-level revenue model, and the proposal credited with the uplift. Answer slot: why this move now isn't in your material. Say it in your own words and point it at this role | It is almost certainly the opener, and it frames everything after it. EXP because it is a biography being scored for economy and consistency. The ID carries a "q" so it isn't confused with fit-snapshot row F1 |
| F2q | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | This is a scored question asked casually. Answer slot: say concretely what you use AI tools for each day, in your own words. If it is general productivity rather than analysis or strategy work, say so plainly. Then give a view on Compass from a buyer's side, as opinion and not as experience. Never claim to have built or launched AI products (see Prohibited claims) | The JD's "AI a plus" line meets F6, which is low confidence. Compass makes the topic live. JD. `[inferred]` because F6's fit is a derivation |

### G. Values / Behavioral (weight: low)

No published values were in hand (the search was refused), so these use standard behavioral prompts rather than Northwind's own value names.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time when there was a named stake, you said something leadership didn't want to hear, and the truth actually landed, with the relationship intact afterward. Use "we" for the context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A standard behavioral stem that a peer may use to test your spine with a shared VP. VAL. `[generic]` because no Northwind values were in hand |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time when a specific metric pressure was in play, you chose the customer, and you can say what it cost and what came of it. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A data-driven interviewer may test whether you'll override a number. VAL. `[generic]` for the same reason as G1 |

**22 questions in total.**

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own GTM strategy for two new product lines | D1, A5, C4, E2 |
| Identify whitespace across land/adopt/expand/renew | C2, D2 |
| Run independent analysis in SQL and Tableau | A4, B2 |
| Partner-motion design experience (required) | D3, C3, A3 |
| Strong cross-functional influence | B3, B1, A5 |
| AI experience (a plus) | F2q, C3 |
| Company priorities and competitive threat (from your research note, not the JD) | C1, C3, C4 |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "You've spent your career in pricing and monetization. How is pricing for the new product lines being decided, and where does Sales Strategy sit in that?" | It connects to his own path and turns your interview into a conversation in his native language |
| R2 | "You've worked at an early-stage startup. What would you want an Emerging Products team to borrow from that, and what would you warn against?" | It connects to his path, and it gets ahead of any skepticism about big-company pace by inviting his view |
| R3 | "What could a new person in this seat do in the first month that would genuinely help your team?" | The reciprocity question. It signals that you intend to lighten his load, not add to it |
| R4 | "How are success metrics for the two product lines defined today, and who owns the number?" | It is data-driven, and it surfaces the seam between your teams before it becomes a problem |
| R5 | "Is the bundling pressure from the larger platform vendor showing up in your data yet? Where?" | It shows you've done the homework, and it asks for his evidence rather than asserting yours |
| R6 | "How do you and the VP expect Sales Strategy and Emerging Products to split the work on Compass?" | It names the priority and the shared reporting line, and it tells you how the seam actually works |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Drove, delivered or generated the ~$400M ARR uplift | Inflated form of F1 | F1's quote at its own scope: you proposed the change, and the change was credited with the uplift. A1, A2 and E1 keep their slots inside that |
| Owned GTM or led product launches | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation that the material shows product strategy and ops, not GTM ownership. The F1 and D1 slots stay inside that |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope: you built a partner-level revenue model that was used in carrier negotiations. The D3 slot asks only which negotiated terms, if any, were yours to shape |
| Negotiated with carriers | Inflated form of F4 (it changes which side of the table you were on) | F4's quote: the model was used in the negotiations. A3's slot covers what you saw of that use |
| Set sales quotas or did sales-ops work | A negative stated in your message (F7) | "I don't have classic sales-ops or quota-setting experience." Volume targets stay volume targets |
| Built, launched or sold AI products | Inflated form of F6 | F6's quote at its own scope: you use AI tools daily. The F2q slot asks only what for |

---

## Sources

**Provided documents:** the coach's message, which supplied the role and JD highlights, your background, Dan's profile details and the research note (Northwind's three priorities and the bundling threat). The research note was not independently checked.

**Searches sent (all refused by host permissions):**
- `Northwind Data company values`: refused
- `Northwind Data interview process GTM strategy`: refused
- `Northwind Data Compass AI copilot launch strategy`: refused
- `"Dan Kovac" Northwind Data sales strategy`: refused

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. Official value names would have themed bank G. No values round is named for this conversation, so a values cheat sheet stays out either way |
| 2. `Northwind Data interview process` | unavailable | The search was refused. Your message already establishes this session (one 60-minute conversation with a peer), so the persona weights stand. It would have shown whether other rounds exist and whether one is values-style |
| 3. `Northwind Data strategy` / recent news | unavailable | The search was refused. It would have checked that your research note is current. C1, C3, C4 and R5 rest on the note, unverified |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have verified the profile details in your message and surfaced any talks or posts to seed reverse questions |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights in your message fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** → targets 1–4 run: official Northwind value names, a check on the loop, verification of the research note, and Dan's public talks or posts for sharper reverse questions. A deeper pass is also available on request: up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief and the differentiator cases it feeds.
- **Full JD text** → every mid-list requirement gets checked against the coverage table, and the fit snapshot quotes the posting directly instead of the highlights.
- **Recruiter or HR guidance for this conversation** → if Dan's session has a stated focus or a deliverable (a POV, a case), the pack gets a dedicated build section for it.
- **Your answers to the answer slots** (F1, F2, F4, F6; A1–A3, B3, D1–D3, F2q) → they become quoted evidence, and those rows move from slots to story-mapped guidance.
- **A sanitized work artifact**, such as a redacted model structure, a dashboard screenshot or a strategy deck → F3 and F4 could move from `medium` toward `high` confidence.
- **Prep time available** → a prioritized prep schedule sized to it.
- **The schedule of any other rounds** → per-round mini-packs with their own persona weights.
- **A `tuesday-dossier.md` from an underwriting pass** → an evidence-derived highest-ROI objection and a prohibited-claims list confirmed with you, instead of built here from the coach's message.
