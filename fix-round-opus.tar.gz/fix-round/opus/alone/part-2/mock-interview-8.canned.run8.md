Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. The recruiter's email gave the structure for all three rounds on 21 November, so the pack has one shared fit snapshot and case plan, then a separate section for each round. Everything is built only from what you gave me; I didn't do any web research.

Where to focus first:
- **Hardest question (B4, round 2):** "You've handled complaints for one branch. This role covers the whole network and a contact centre, and reports to senior leaders. What makes you ready?" Practise saying what you haven't done before they ask. Then stick to what you have: the branch's formal complaints log, training new tellers, and the spreadsheet your regional manager uses.
- **The panel (round 3):** there's a cheat sheet matching each of the four values to your experience. It also has a plan for the 20-minute complaint case: ask clarifying questions first, deal with the member, name one owner, fix the handoff, close on what the member hears.
- **What not to claim:** a short list includes "ran the region's complaints reporting" and "handled regulated complaints". Your message supports neither yet, so the pack leaves room for you to fill in what you actually did.

Say the word and I'll play your future manager asking B4, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of loop:** 21 November 2026, three rounds on one day
**Rounds:** (1) 30 minutes with the recruiter; (2) 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural; (3) 60 minutes with a panel of two branch managers. This is the values round, and it includes a 20-minute complaint-escalation case.
**Interviewers:** not yet assigned beyond their roles
**Mode:** loop. One shared fit snapshot and case build, then a mini-pack for each round. The loop comes from the recruiter's email, not from a guessed pattern.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: a friendly aside, a quiet probe, a time-boxed challenge. **Types** describe *what* is being scored. Rehearse both.
- Question IDs use one letter per persona: **A** Conversational, **B** Skeptic, **C** Values/Behavioral, **D** Case/Strategist, **E** Peer Evaluator, **G** Data-Driven Prober, **H** Pressure. Fit-snapshot rows are **F1–F9**.
- **Answer slot** means the pack will not put words in your mouth there, because your material doesn't say. You have two honest options: if you did it, say how in your own words; if you didn't, or there was no such thing, say so plainly and go back to what you did do.
- The guidance is scaffolding, not a script. Say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's four published values |
| EXP | Whether what you say about your experience holds up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework: Ashgrove's strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material covers one branch's formal log, not a process across branches, so keep your words at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how the log worked likely. If any part of how it worked was yours to decide, say which part and how, in your own words. If it was set for you, or there was nothing to decide, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Wording can't close this gap, and you've said so yourself. Words: "I've never worked in a contact centre." Then say how you would learn it, framed as a plan, never as a past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says you built the spreadsheet and your regional manager uses it. It doesn't show what the spreadsheet counts or who reports from it. Answer slot: expect a probe on what's in it. Say what it counts each month and how each figure is counted, in your own words; if you don't know how a figure is counted, say so plainly. If you presented it to your regional manager yourself, say how; if you didn't, say so and stay with having built it |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says "spreadsheet" but not which tool. Answer slot: if it's built in Excel, say so and describe what you built in it, in your own words. If it's another tool, name it plainly and say what you did in it. Don't rate yourself with an adjective; describe what you built |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Training new tellers on a script isn't the same as coaching supervisors, so don't stretch it: "I trained new tellers on our escalation script." Answer slot: expect a probe on the training. If what it covered or how it ran was partly yours to shape, say which part, in your own words. If you delivered it as it was given to you, say so plainly and stay with the training |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital work either way. Answer slot: if you've worked with a digital or app team, or fed what members told you into an online or self-service change, say what you did and which part was yours. If not, say so plainly, then say how you would start, framed as a plan |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap: six years is more than four. Keep your own words, "six years in retail banking, the last three as a branch supervisor", and let the interviewer map them onto the JD. Don't relabel them as "customer operations" |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says the log was formal. It doesn't say whether the complaints in it came under regulatory rules. Answer slot: expect a probe on what made the log formal. If set rules governed how entries were recorded, timed or closed, say what they were, in your own words. If you don't know what sat behind it, say so plainly and describe the log as you handled it |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." That sentence doesn't say you have presented at regional level, and the pack won't say it either. Answer slot: if you have presented to your regional manager or at a regional meeting, say what and how it went, in your own words; if not, say so plainly. Then describe how you'd prepare your first senior-leader report, framed as a plan, never as a past |

None of the JD's requirements is a gate (a licence, location or similar term). The four-plus years is an experience requirement and is graded like the rest.

### Requirement coverage

| JD requirement | Row | Covered by |
|---|---|---|
| Own complaints end to end across branches | F1 | A3, B4, D1 |
| …and the contact centre | F2 | B1, B5, H1 |
| Report monthly on volumes and resolution times | F3 | G1, G2 |
| Comfortable with Excel reporting | F4 | A4, G1 |
| Coach branch supervisors on escalations | F5 | B7, C2, E1, E2 |
| Work with digital teams on self-service | F6 | A5, D2 |
| 4+ years in financial-services customer operations | F7 | A1, B3 |
| Experience handling regulated complaints | F8 | A3, G3, D1 |
| Confident presenting to senior leaders | F9 | B2, B6 |

**Highest-ROI prep in this pack: B4** (Round 2). The objection this loop is most likely to raise is that you have handled one branch's log, the role covers the whole network and the contact centre, and you've said you haven't worked in a contact centre or presented above regional level. Rehearse B4 until it bores you.

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter announced this case and the panel scores it against the four values. Its content is unknown, so this section builds the approach rather than an answer.

**Material from your background you can stand on** (quoted from the fit snapshot; say nothing beyond these):
- F1 and F8: "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- F3: "I built the monthly complaints spreadsheet our regional manager uses."
- F2: "Never worked in a contact centre, and I've never presented to anyone above regional level." If the case runs through the contact centre, say plainly that you'd ask how it works there.

**Opening move (2 minutes):** ask clarifying questions before structuring. Which channel did the complaint come in through and which channels has it touched, how long has it been open, has the member been told who owns it, and what has the member asked for?

**Three defensible theses. Each comes with a concession you say out loud:**

| Thesis | Values it shows | Mandatory concession |
|---|---|---|
| Fix it for this member first, then fix the cause, and own both until they're done | Members First, Always; Own the Fix | Speed doesn't skip the formal record or the complaint rules. Say you'd check the rules and deadlines that apply at Ashgrove rather than guess at them in the room |
| Escalations usually fail at the handoff, so name one owner the member can reach | Own the Fix | In a network with a contact centre, someone central may have to hold the end-to-end. You've never worked in one, so ask how handoffs work there before redesigning them |
| Write the final response so the member doesn't need it explained twice | Plain Words | Plain words still have to say everything the response is required to say. Clarity can't drop content |

**Differentiation:** the consensus answer is "apologise, investigate, resolve, follow up". Give that sequence in one sentence to show you know it. Then diverge: spend your time on where *this* complaint got lost, and on what you'd change in how supervisors escalate, so the next one doesn't get lost there. That last step is the part of the JD about coaching supervisors.
**The thing to avoid:** promising the member an outcome before the facts are in.
**Close:** the recruiter named no required close. Given the values scoring, end on the member: what they hear, from whom, and by when.

---

## Grounding brief: Ashgrove's 2026 strategy

These points come from your summary of the strategy brief Ashgrove published in July 2026. The reading of each point is the pack's own.

| Point from the brief | What it could mean for complaints | Used in | Provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | More complaints may start in, or be about, digital channels, and self-service journeys become a place to prevent complaints | A2, D2, F6 | [inferred] |
| Consolidate eight branches into five hubs over 2027 | Change is a moment when complaints can rise and local knowledge can get lost. This touches the panel's own branches | D3, E2, Round 3 reverse questions | [inferred] |
| Launch a small-business lending product in Q1 2027 | A new product needs a complaints route and reporting before launch, not after | D4 | [inferred] |
| Main competitive pressure is app-only banks | Speed and ease of resolution become part of why members stay | A2, D2 | [inferred] |

The consolidation sits awkwardly beside "Neighbours, Not Numbers", and two branch managers will be across the table. Be curious about what they want protected. Don't speculate about anyone's branch or role.

---

## Round 1: Recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly openers, motivation, logistics | High: the email describes a 30-minute conversation with the recruiter, and recruiter screens usually run in a friendly register [generic] | A 90-second arc built only from your own sentences. Treat casual questions about JD lines as scored |
| Skeptic (light) | Checks against the JD's requirement list | Medium: F2 and F9 are stated gaps against named JD lines, and screens often check stated requirements early [generic] | Have the plain acknowledgment and a one-line plan ready for each |

### Question bank: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in three beats, each one a sentence you gave: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Then close on why this role, in your own words. Keep your own labels ("branch supervisor") rather than the JD's | It opens most screens and sets up F7, F1 and F3 before anyone probes them. EXP because this is the version of your history rounds two and three will test |
| A2 | "What draws you to Ashgrove specifically?" | CO | [grounded] | Answer slot for the reason: give your real one, in your own words. Then tie it to one thing you can point to: a value by its exact name (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix), or a line from the July 2026 strategy brief the recruiter sent you, named as such. If member ownership is part of your reason, say why; if it isn't, don't claim it | Motivation gets heard in all three rounds, so it needs to be consistent from the first one. CO because it scores whether you did the homework, and the brief and values page are that homework |
| A3 | "Tell me a bit about the complaints side of your current job." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 and F8: you handled the branch's formal complaints log, in those words. Answer slot: if any part of how the log worked was yours to decide, say which part and how. If it was set for you, say so plainly and describe how you handled it. Keep "formal" as your word and don't upgrade it | F1 and F8 are the core of the JD, and the recruiter will want the headline before your future manager probes it. EXP first, JD second |
| A4 | "How are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the spreadsheet you built that your regional manager uses. Answer slot (F4): if it's in Excel, say so and describe what you built in it, in your own words; if it's another tool, name it. Describe what you did rather than rating yourself | Asked casually, but it's scored against a named JD line (F4). JD because it checks a stated requirement |
| A5 | "Have you done anything on the digital side: apps, online self-service?" | JD | [grounded] | Answer slot (F6): if you've worked with a digital team or fed member feedback into an online change, say what and which part was yours. If not, say so plainly, then give one line on how you'd start, framed as a plan | F6 is blank in your material and it's a named JD line, so the honest answer should be ready before a casual question catches you |

### Question bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This covers the contact centre too. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Words: "No, I've never worked in a contact centre." Pause for a beat and don't apologise. Then one line of plan, framed as a plan: how you'd learn it in your first weeks. Then return to the branch's formal complaints log | F2 is a gap you've stated against a named JD line, so it will come up somewhere. It's better to rehearse it at low stakes first |
| B2 | "The JD mentions presenting to senior leaders. What's your experience there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Words: "I haven't presented to anyone above regional level." Answer slot (F9): if you have presented at regional level, say what and how; if not, say so. The nearest thing you can say truthfully is that your regional manager uses the spreadsheet you built. Say only that it's used, not that you presented it | F9 is your other stated gap. Recruiters often check stated requirements early, and a clean answer here keeps it from becoming a screening flag |
| B3 | "Why leave a supervisor role in retail banking for a credit union?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Answer slot: give your real reason, in your own words, framed forward ("I want to…") rather than against your current employer. If the member-owned model is part of it, say why; if not, leave it out. Keep the facts at F7's scope | This is the Skeptic's "why leave" probe in a friendly register. What you say here is what rounds two and three will hear, so it needs to match |

### Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| "How does the panel score the four values: one question per value, or across the whole hour?" | Shows you read the email closely, and recruiters can usually answer process questions |
| "Is the 20-minute case given in the room, or shared beforehand?" | It changes how you prepare, and asking is fair |
| "Who would this role work with most closely in the contact centre?" | Faces your biggest gap (F2) head-on, as interest rather than worry |
| "Is the role new, or replacing someone? What's prompting it now?" | Tells you what the job is really for |
| "What happens after 21 November, and when will I hear?" | Logistics, which recruiters expect you to ask about |

---

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scale gap | High: the default for a hiring manager is to probe gaps, and F1, F2 and F9 are the largest | Rehearse B4 until it bores you; hold what the quotes carry, then concede what they don't |
| Values/Behavioral | "Tell me about a time…" questions, answered in STAR format | High: the recruiter says this round is "mostly behavioural" | "We" for context, "I" for your part. Use a selection scaffold where no sentence of yours carries the story |
| Data-Driven Prober | What the spreadsheet counts and how | Medium: the JD names monthly reporting, and F3 is your only reporting evidence | Know what you can and can't say about each figure, and say plainly when you don't know |
| Pressure | One time-boxed challenge | Low: nothing in the email suggests it. It's covered once so the style isn't new on the day [generic] | Pause, restate the question, hold, then concede only what's real |

### Question bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "You've handled complaints for one branch. This role owns them across the network, including a contact centre you haven't worked in, and reports to senior leaders. What makes you ready?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI rehearsal in this pack.** Name the limit before it's asked: "It's been one branch's log, and I've never worked in a contact centre." Then hold on what you have, in your words: three years as a branch supervisor, the branch's formal complaints log, training new tellers on your escalation script, and the monthly complaints spreadsheet your regional manager uses. *Follow-up 1, "one branch isn't a network":* hold your ground and don't add anything. Answer slot (F1): if any part of how the log worked was yours to decide, say which; if not, say so and stay with the log. *Follow-up 2, "and senior leaders?":* "I haven't presented to anyone above regional level." Then describe how you'd prepare your first monthly report, as a plan. *Follow-up 3, "so why take the risk?":* concede that the risk is real, then say what you'd do in your first 90 days, all as plans. Don't fold on the core point: the log, the training and the spreadsheet are real and yours, as you stated them | Every gap in the fit snapshot points at this one question, and your future manager is the person most likely to ask it. Deepest rehearsal means three follow-up levels and the limit named first, not more content than your sentences carry |
| B5 | "How would you get your arms round the contact centre in your first few months?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the acknowledgment once, then give a plan in order: learn how complaints arrive there, sit with the people who take them, map how they're handed to and from branches, then compare that against how the branch log works. All of it is what you *would* do | F2 is your largest stated gap, so the manager will want a ramp plan. This is JD content asked as a CASE, which is why a plan is what scores |
| B6 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick a real one you've stated, for example presenting: "I haven't presented to anyone above regional level." Then say how you'd close it, as a plan. Don't offer a fake weakness, and don't reopen F2 if B5 has already covered it | It's a standard Skeptic stem, and F9 gives you an honest answer that's already rehearsed. A real weakness, stated calmly, scores better than a polished non-answer |
| B7 | "You've trained tellers. This role coaches supervisors, people at your own level. How is that different?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold to the quotes: three years as a branch supervisor, and you trained new tellers on your escalation script. Then say what you think changes when the person is a peer, offered as a view, not as something you've done. Answer slot (F5): if you've helped another supervisor with an escalation, say what you did and which part was yours; if not, say so plainly | F5 is a transferability gap: you've trained tellers, and the role coaches supervisors. The probe is about that difference, and you're safer conceding it than blurring it |

### Question bank: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you dealt with a complaint that needed escalating." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | None of your sentences describes one particular complaint, so this is a selection scaffold. Pick a real complaint you were part of where escalating was a decision. It needs the member's problem, what you did, what happened, and what you'd do differently. "We" for the branch, "I" for your part. If no such case comes to mind, say so plainly, then give the nearest thing your material carries (the escalation script you trained tellers on) or how you would handle one | The JD is built around escalations, and a behavioural round will ask for a specific one. EXP first, JD second. It's a scaffold because your material names the log, not a case |
| C2 | "Tell me about a time someone you were training didn't get it first time." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story base: you trained new tellers on your escalation script. Selection scaffold: pick one real instance where it didn't land. It needs who they were (a role, not a name), what didn't land, what you did next, and how you could tell. If none comes to mind, say so plainly and describe how you ran the training | It tests coaching, the JD's line about supervisors (F5), through the only training you've named. EXP because the instance has to be real |
| C3 | "Tell me about a time you told a manager something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you didn't back down, and a relationship that stayed intact. If no such time comes to mind, say so plainly and say how you would handle it | Monthly reporting means bringing bad numbers upward, so this stem is a natural fit for the role. VAL because it scores candour, which sits under Own the Fix |

### Question bank: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through your monthly complaints spreadsheet. What goes in, what comes out, and who uses it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The question's premise is exactly F3: you built it, and your regional manager uses it. Answer slot: say what it counts each month and how each figure is counted, in your own words. If you don't know how a figure is counted, say so plainly. Name the figure you'd defend least before they ask. If you built it from scratch, say so; if you extended something that already existed, say that. "Built" is your word, so keep it at its scope | F3 is your only evidence for the reporting line, and a prober will go two levels into it. EXP because it tests what's really in the thing you built |
| G2 | "Say resolution times got worse three months running. How would you work out why?" | CASE | [generic] | Structure: first check how "resolution time" is counted, so you know whether the measure itself changed. Then split by channel (branches, contact centre, digital) and by complaint type. Check the data before the cause. Then name a fix and an owner who holds it until it's solved, and report it in plain words | A live problem straight from the JD's reporting line. CASE because it scores structure, not your history |
| G3 | "This role handles regulated complaints. How does that compare with what you've done?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with the branch's formal complaints log, in those words. Answer slot (F8): if set rules governed how entries were recorded, timed or closed, say what they were, in your own words. If you don't know what sat behind the log, say so plainly and describe it as you handled it. Don't name rules or deadlines you aren't sure of | F8 is a named requirement your material only touches. JD because it scores the stated requirement, and an honest "here's what I know" beats a guessed rulebook |

### Question bank: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over someone who has already run a contact centre's complaints?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause first. Concede in one clause: "I haven't worked in a contact centre." Then hold on what you have: the branch's formal complaints log, and training tellers on your escalation script. Stay inside the 60 seconds. If pushed again, hold once more before conceding anything else | It's the B4 objection, time-boxed. It's here so the pressure style isn't new on the day, and the hold-then-concede shape is what gets scored |

### Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| "What would good look like for the complaints process at the end of my first year?" | It asks your future manager to define success, which you'll need to know anyway |
| "How does complaints data reach you today, and what's missing from it?" | It shows you think about the monthly report from the reader's side |
| "With 40% of service moving to digital by 2028, where do you expect complaints to move?" | It uses the brief's own target and shows you think at strategy level |
| "How do branches and the contact centre hand complaints to each other now?" | It names your gap (F2) as curiosity, and the answer is what you'd need to learn first |
| "How would you like the monthly reporting brought to you: numbers first, or the story first?" | It's practical, it's about working with them, and it shows you intend to report in plain words |

---

## Round 3: Panel of two branch managers (60 minutes, values-scored, includes the 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Questions scored against each of the four values | High: the recruiter says "they score against the four values" | One story per value where a sentence of yours carries one, and a selection scaffold with an honest way out where none does |
| Case/Strategist | The 20-minute complaint-escalation case, plus strategy-linked problems | Certain for the case, since the recruiter names it | Clarify first, then the member, the fix, the cause, the record, the coaching |
| Peer Evaluator | Branch managers working out what you'd add to, or cost, their branches | Medium: the role coaches their supervisors (JD), and the hub consolidation touches their branches (brief) [inferred] | Say what you'd bring them, not only what you'd need. Propose principles for the handoff rather than claiming to know it |

### Values cheat sheet

Values copied from ashgrovecu.org/about/values on 12 November 2026.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Make the call from where the member is standing | No sentence of yours carries this, so use a selection scaffold. Pick a time you made a decision for a member's sake that cost the branch time or convenience. It needs the member's situation, the decision, and what it cost. If none comes to mind, say so plainly and say how you would decide (C4) |
| Plain Words | If it needs explaining twice, the writing was wrong | Nearest material is F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if you put the script into plainer words while training, say how; if not, pick another time you made something clearer, or say none comes to mind (C5) |
| Neighbours, Not Numbers | Every branch belongs to its town | No sentence of yours carries this, so use a selection scaffold. Pick a time local knowledge changed how you treated a member. If none comes to mind, say so plainly and say why it matters to you (C6) |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | Nearest material is F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because you found something missing, say what; if it was asked of you, say so plainly and pick another instance, or say none comes to mind (C7) |

### Question bank: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C4 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold, using the cheat-sheet row for Members First, Always. It needs a real member situation, your decision, and what it cost. If none comes to mind, say so plainly and say how you would decide | The panel scores this value by name. The wording mirrors the values page, so expect it close to verbatim |
| C5 | "Tell me about a time something had to be explained twice. What did you do about it?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Nearest material: you trained new tellers on your escalation script. Answer slot: if you made the script or its explanation plainer, say how, in your own words. If not, pick another real instance, or say none comes to mind and say how you'd write a complaint response that doesn't need explaining twice | Plain Words is scored, and complaint letters are where it bites. VAL because the value is quoted from the source |
| C6 | "Tell me about a time knowing the local community changed how you handled a member." | VAL | [grounded] | Selection scaffold: a real member, the local knowledge, and what it changed. If none comes to mind, say so plainly and say why it matters as branches become hubs | Neighbours, Not Numbers matters more to branch managers facing consolidation. VAL because it's scored by name |
| C7 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Nearest material: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if you built it because you found a gap, say what the gap was and how you kept hold of it. If it was assigned to you, say so plainly and pick another instance, or say none comes to mind | Own the Fix is the value closest to the JD's "end to end" line. VAL because it's scored by name |

### Question bank: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A member complained at their branch, was passed to the contact centre, and has rung back a week later angry that nobody owns it. You have 20 minutes." | CASE | [generic] | Use the case build above. Clarify (channel, time open, what the member wants), act for the member today, name one owner, find where the handoff broke, record it formally, and say you'd confirm the complaint rules and deadlines that apply at Ashgrove rather than guess. Then say what you'd coach supervisors to do differently. Close on what the member hears, from whom, and by when | It's a likely shape for the announced case, which tests F1, F2 and F8 live. The scenario is a pattern, not Ashgrove's actual case, hence `[generic]` |
| D2 | "We're moving 40% of member service to digital by 2028. What does that do to complaints?" | CO | [grounded] | Use the brief's figure. Then think aloud: complaints may move to digital channels, self-service journeys can prevent complaints or cause them, and app-only banks set members' expectations of speed. Say what you'd track, and how you'd bring complaint themes to the digital teams, as a plan. Answer slot (F6) if they ask what you've done digitally | The JD's digital line (F6), tied to the brief's headline target. CO because it scores whether you can think at Ashgrove's level |
| D3 | "Some branches will merge into hubs next year. How would you stop complaints spiking during the change?" | CO | [grounded] | Use the brief's eight-into-five. Structure: what members lose in a move (a familiar face, a familiar counter), how you'd watch complaints from the affected towns, and how branch supervisors would escalate during the change. Ask the panel what they'd want protected. Don't speculate about anyone's branch | Two branch managers are likely to bring up the consolidation, and Neighbours, Not Numbers is being scored. CO with CASE delivery |
| D4 | "We launch small-business lending in Q1 2027. What would you set up for complaints before launch?" | CO | [grounded] | Think aloud: how complaints about the new product would be logged and labelled so they appear in the monthly report from day one, who owns them, and how frontline staff would know the escalation route. Present it as a plan | It's the brief's nearest launch and a fair test of Own the Fix applied in advance. CO because it scores homework |

### Question bank: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You'd be coaching our supervisors on escalations. What would you need from us, and what happens when we disagree on a case?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start with what you'd bring them, then what you'd need. On disagreement, propose a principle (the member's outcome decides, and the disagreement goes into the record) rather than claiming you know their seam. You can say you've been a branch supervisor for three years. Don't claim to have coached supervisors | F5's gap, asked by the people whose supervisors you'd coach. JD because it scores the coaching line |
| E2 | "Our supervisors know their members. How would you coach them without it feeling like head office telling them what to do?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Lead with being a branch supervisor yourself for three years, in those words. Then a principle: coach from their cases, not from a script handed down. Add one concrete thing you'd do in your first month, as a plan | Neighbours, Not Numbers meets F5. VAL first, JD second, because the panel scores the value |

### Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would actually help your supervisors?" | It's the reciprocity question, about their load rather than your needs |
| "When a complaint goes from your branch to the contact centre today, where does it get stuck?" | It asks the people who see the problem first, and it's the case's real-world version |
| "As branches become hubs, what do you most want protected for members?" | It's Neighbours, Not Numbers turned into a question, and it shows you read the brief without asking about their jobs |
| "Which of the four values is hardest to live up to in a complaint?" | It invites a real answer about the values they're scoring you on |
| "What do members complain about that never makes it into the log?" | It shows you care about the complaints the numbers miss |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material covers one branch's formal log. The slots in A3 and B4 stay inside that log |
| Has worked in a contact centre | A gap you stated, F2 | "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | A gap you stated, F9 | "I haven't presented to anyone above regional level." F9's slot asks only about regional level |
| Ran the region's monthly complaints reporting | Inflated form of F3 | F3's quote: you built the spreadsheet and your regional manager uses it. G1's slot asks only what it counts and which part was yours |
| Coached supervisors on escalations | Inflated form of F5 | F5's quote: you trained new tellers on your escalation script. B7's slot stays inside that |
| Wrote or designed the escalation script | Inflated form of F5's quote ("our escalation script") | You trained tellers on it. Who wrote it isn't in your material |
| Handled regulated complaints | Inflated form of F8 | F8's quote: the branch's formal complaints log. G3's slot asks what governed the log, in your own words |

---

## Sources

**Provided documents**
- The JD for Member Experience Lead, pasted
- Ashgrove's values, pasted. You copied them on 12 November 2026 from ashgrovecu.org/about/values, and the page was not fetched
- The recruiter's email about the three rounds on 21 November, pasted
- Your summary of the July 2026 strategy brief the recruiter sent, pasted
- Your background, in your message

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | You pasted the values page text this morning. It fixes the values cheat sheet and C4–C7 |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email sets the three rounds, who runs each, the values scoring and the case. It fixes every persona weight |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 strategy brief is four months old and supplies the priorities and competitive frame. It fixes the grounding brief, A2 and D2–D4 |
| 4. Interviewer names at Ashgrove | n/a | No names have been assigned, so there was no query to form, and there is no interviewer read |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → a short read for each round from their public professional footprint, adjusted persona weights, and a reverse question tied to their own career path
- **Your answers to the answer slots in F1, F3, F4, F6, F8 and F9** → those rows' bridges become your own words, and A3, A4, A5, B4, B7, G1, G3 and the Own the Fix and Plain Words cheat-sheet rows upgrade from slots to story-mapped guidance
- **A description of the spreadsheet's columns and monthly outputs, with no member data** → F3 and F4 move toward `high` confidence, since a reporting artifact is what this kind of work keeps as proof, and G1 gets exact figures to defend
- **Your CV** → dates, titles and any lines your message didn't cover enter the fit snapshot, and more questions become story-mapped instead of scaffolded
- **The full strategy brief text, not a summary** → the grounding brief can quote it directly, and D2–D4 can use its own vocabulary and numbers
- **How much prep time you have before 21 November** → a prioritised prep schedule, built around B4 and the case
- **Whether the case is given in the room or beforehand** (one email to the recruiter) → the case build section becomes a timed plan or a pre-read approach
- **Deep research pass (L2)** → up to 6 more searches and 2 more fetches, several more minutes: Ashgrove's recent news and organisational context, and any published reports of its interview loop. It would sharpen D2–D4 and the reverse questions
- **A tuesday-dossier.md from a job-underwriter run** → verified evidence and an underwriter-built prohibited-claims list in place of this pack's local one. Useful, not required
