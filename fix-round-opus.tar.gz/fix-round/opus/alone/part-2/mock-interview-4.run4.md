I'm reading the prep skill's rules for building the pack. Two more reference files left, then I'll write it.
The searches I tried for company research were refused, so I'm building the pack from your dossier alone and labeling what that leaves generic. Writing it now.
I've saved your prep pack as `Quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the 45-minute hiring-manager conversation you described, using your dossier. It has 23 questions, a fit snapshot against all five requirements and the four responsibilities, and six reverse questions.

My searches on Quartzline's values, interview process and recent news were refused. So the case questions and anything about the company are marked as generic rather than researched, and the pack has no question on company strategy.

**Start with A1.** It's the objection your dossier names, and the pack's highest-value rehearsal. The answer has three parts:
1. **Concede first:** "I haven't held a product manager title, and I haven't owned a product roadmap."
2. **Make the case at its real size:** you led 30+ end-to-end client integrations of the vendor's REST APIs, and you ran the quarterly roadmap-input sessions that fed client evidence to product.
3. **Give a ramp plan, said as a plan:** what you'd learn first and how.

A2, A3 and E1 are the follow-ups to practise holding that line under.

**Today is Thursday.** If the interview is today rather than next week, do A1, then A2 and A3, then C1. Then have reverse questions RQ1 and RQ2 ready. Those two are the dossier's open questions about how much say the PM has versus the squad leads, and how adoption is measured today. Everything else is insurance.

If you want, I'll play the Skeptic on A1 and push back on your answers live.
I can also update your `tuesday-dossier.md` with what this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager (from your note). Interviewer not named.
**Built on:** your `tuesday-dossier.md` (v1.1, dated 2026-08-14). Web research was refused this session, so everything about Quartzline itself is labeled `[generic]`.

---

## How to use this pack

- **Personas** describe *how* a question is asked. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behavioral or values alignment. Does your past behavior show the company's published values?
  - **EXP**: work-experience deep-dive. Does what you said survive scrutiny, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. Did you do your homework?
  - **CASE**: a live problem from the role. Can you structure it and reason through it out loud?
- Provenance labels: `[grounded]` traces to your dossier; `[inferred]` is this pack's own derivation, with the derivation named; `[generic]` is a role-family pattern that makes no claim about Quartzline.
- **Answer slot**: an instruction for the interview with two honest branches. If you did the thing, say how in your own words. If you didn't, or it didn't exist, say so plainly. Both branches are good answers.
- Guidance is scaffolding, not a script. Say it in your own words.

The three verified sentences everything below rests on. They are quoted exactly from the dossier's `verified_candidate_evidence`:

- **Q1** "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier: high confidence, inspectable)
- **Q2** "Wrote the internal integration playbook her team uses" (dossier: high confidence, inspectable)
- **Q3** "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier: medium confidence, limited inspectable proof, expect a probe)

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier sets the bridge: position this as adjacent work, never as PM experience. Start with the plain acknowledgment its prohibited_claims field supports: "I haven't held a product manager title." Then give the two sentences at their own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, and you ran quarterly roadmap-input sessions feeding client evidence to product. The limit, which is the pack's observation and not your words: your material shows integration leadership and input into product, not a product role. The sessions are medium confidence, so if you have nothing from them to show, say so before you're asked |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | capability | The dossier marks this acknowledge_gap, so there is no bridge. Words: "I haven't owned a product roadmap." (prohibited_claims: "Having owned a product roadmap"). Then a ramp plan, said as a plan and never as a past: how you would learn which roadmap decisions are yours and which are the squad leads', and what you would want to know first. Nothing gets added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | The material says integrations of the vendor's REST APIs, not a product you shipped. That is the pack's observation. Words: the quote at its own scope, which is the integrations you led through to go-live. Answer slot: R2 makes a probe on what went live likely. If any go-live in those integrations was yours to call, say which and how you decided, in your own words. If none was, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | Derived: integration work on REST APIs touches docs and schemas, but the quotes don't show whether yours did. Answer slot: R3 makes a probe on API docs and schemas likely. If your integration work or your playbook involved reading or writing API documentation or schemas, say which and how, in your own words. If it didn't, say so plainly and talk about the REST API integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" (the customer part) — JD (dossier role_profile R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | presentation | Say it in the quote's terms: client integrations, 30+, which you led end to end from scoping to go-live. Use "client", the quote's word, rather than borrowing the JD's wording |
| F6 | "Stakeholder management across engineering, sales, customers" (the engineering and sales part) — JD (dossier role_profile R4, important) | none given | none | [grounded] | discovery | Your material doesn't show engineering or sales stakeholders. Answer slot: if your integrations involved working with engineering or sales, say who and what part was yours, in your own words. If they didn't, say so plainly and stay with the client side that F5 carries |
| F7 | "Agile delivery experience" — JD (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | The dossier marks this clarify. None of the verified sentences speaks to agile. Answer slot: R5 makes "agile delivery" a likely probe. If you have worked in agile delivery, say how, in your own words. If you never worked that way, say so plainly. Either way, add what you would want to confirm about how Quartzline's squads define it |
| F8 | "Run discovery with integration partners" — JD (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | Scoping and requirements for client integrations sit next to partner discovery, but they are a different kind of work. Words: the quote's scoping and requirements, as stages of integrations you led. Answer slot: if scoping those integrations taught you a way of finding out what clients needed, describe it in your own words. If not, say so plainly and present your discovery approach as a plan |
| F9 | "Write specs and drive delivery with two engineering squads" — JD (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | Words: the quote at its own scope, the requirements stage of integrations you led. The squad side gets the plain acknowledgment its prohibited_claims field supports: "I haven't set prioritization for an engineering squad." Answer slot: if the requirements stage produced a written document, say what it was and what part was yours. If it didn't, say so plainly |
| F10 | "Define and track adoption metrics" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | discovery | Your material doesn't show metrics work. Answer slot: if you tracked any measure of how clients used an integration after go-live, say what and how, in your own words. If you didn't, say so plainly and say what you would measure first |

---

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent questions about the missing PM title and roadmap ownership | **High.** Hiring managers lean on the Skeptic, and the dossier names the exact objection. This is where the interview is won or lost | Rehearse A1 until it's boring. Concede first, using the dossier-sourced acknowledgments, then give Q1 and Q3 at their own scope, then the ramp plan |
| Case / Strategist | Live problems from the JD: adoption, conflicting partner asks, two squads, API docs | **High.** Hiring managers buy capability with live problems. The JD's adoption-metrics and two-squad lines are natural case material | Clarify, then objective, segments, approach, metrics, risks. Think out loud. Question one premise respectfully per case |
| Data-Driven Prober | Asks for the denominator behind "30+" and walks through one integration | **Medium.** Q1's number and Q2's inspectable playbook invite it | Know what you can and can't say about how 30+ was counted. If you don't know, say so |
| Conversational | Friendly openers: "walk me through the journey", casual questions about agile or sales | **Medium.** Most 45-minute HM conversations open this way, and casual questions are still scored | A 90-second arc built only from Q1, Q2 and Q3 |
| Pressure | Time-boxed "why you" and "how much was you" | **Medium-low.** Nothing signals a stress interviewer, but the title gap invites a sharp version of A1 | Pause, restate, anchor in the quotes, hold through two follow-ups |
| Peer Evaluator | The seam with the squad leads, credit across teams | **Low.** This is not a peer round, but the dossier's unknown about squad-lead authority makes the seam question likely | Propose seam principles. Don't pretend to know the seam |
| Values / Behavioral | Classic behavioral stems | **Low.** Your note describes one conversation with the hiring manager and names no values round | Selection scaffolds with honest branches |

These weights come from the hiring-manager relationship and your description of the round. With no interviewer name and no loop research, there were no other signals to adjust them.

---

## Question banks

### A — Skeptic (highest weight)

**A1 is the highest-ROI prep in this pack.** The dossier names this objection itself (`likely_interviewer_objections`).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; plus prohibited_claims: "Having held a product manager title or role" and "Having owned a product roadmap" | **Concede first, calmly:** "That's right. I haven't held a product manager title, and I haven't owned a product roadmap." **Then the adjacent case, at its own scope:** "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live. I also ran quarterly roadmap-input sessions feeding client evidence to product." Let them draw the inference. Never say that this "is" PM work, and never call it equivalent. **Then a ramp plan, as a plan:** what you would learn first (which decisions are yours versus the squad leads', and how adoption is measured today) and how. **State the limit before they ask:** the sessions are where proof is thin, so if you have nothing from them to show, say so. **Hold through two follow-ups** (A2 and A3 are the likely ones) by returning to the quotes, never by adding to them | The dossier's named objection, and it targets the must-have R1 (F1) and the roadmap responsibility (F2). Every negative in the question is sourced by a dossier field, so it is asked as written. JD because it scores the stated requirement head-on |
| A2 | "In those roadmap-input sessions, what happened to the client evidence you brought?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Q3 at its own scope: you ran the sessions quarterly, and they fed client evidence to product. The dossier marks this medium confidence, so if there's nothing from the sessions you can show, say so first. Answer slot: the JD's roadmap line makes a probe on outcomes likely. If you know of any evidence from the sessions that became a roadmap item, say which, in your own words. If you don't know, or none did, say so plainly and return to the sessions themselves. Don't let this become a story about owning the roadmap (see Prohibited claims) | The usual first follow-up to A1. F1's medium-confidence sentence is the seam a prober finds, so coaching you to state its limit first turns the gotcha into credibility |
| A3 | "Have you set priorities for an engineering team before?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; plus prohibited_claims: "Having set prioritization for an engineering squad" | Plain acknowledgment: "I haven't set prioritization for an engineering squad." Then Q1 at its own scope: the integrations you led and their stages. Then a plan: how you would establish working rhythms and decision rights with two squad leads you don't manage. Asking them how it works today (reverse question RQ1) is a strong close | The JD's two-squads line (F9) against a dossier prohibition. It's the second likely follow-up to A1. JD because it scores the delivery responsibility |
| A4 | "What API or platform product have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer with Q1 at its scope: 30+ end-to-end client integrations of the vendor's REST APIs, which you led through to go-live. Don't relabel integrations as products. Answer slot: if any go-live was yours to call, say which and how you decided, in your own words. If none was, say so plainly and stay with the integrations you led | R2 is a must-have, and F3 is where its wording presses hardest. JD because it scores the requirement directly |
| A5 | "Why move from integration work into product management now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Give your real reason, in your own words. Answer slot: if your reason connects to the sessions where you fed client evidence to product, say how. If it doesn't, give the reason you actually have. Avoid "I've basically been doing PM already". That implies a listed claim | Motivation consistency is the Skeptic's other target, and F1's gap makes "why now" predictable. Typed JD because it scores fit to the stated role |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner adoption of our APIs has gone flat. How would you diagnose it?" | CASE | [generic] | Clarify first: how is adoption measured today, and over what window? Objective: which adoption matters (signups, first successful call, production traffic). Segment partners by stage and size. Hypotheses: onboarding friction, docs, a missing capability, commercial terms. Data to confirm each. Risks: a metric that rewards the wrong behavior. This question asks nothing about your past | The JD's adoption-metrics line, and the dossier notes no baseline is stated, so a hiring manager may well be living this problem. Generic because no Quartzline data was researched |
| B2 | "What would you put on a first adoption dashboard for the partner API?" | CASE | [generic] | A short funnel (activated, first call, production, retained) plus one quality signal (error rate or time to first success). For each metric, name the assumption you'd defend least. Answer slot: if you tracked any of these after an integration went live, say which. If not, say so plainly | Converts F10's discovery gap into a live demonstration. CASE delivery on JD content |
| B3 | "Two partners want conflicting changes to the same endpoint, and the squad can only take one this quarter. Walk me through it." | CASE | [generic] | First clarify whose call this is: yours, or the squad lead's. Then the criteria you'd use (partner impact, strategic fit, reversibility, cost), how you'd tell the partner who loses out, and what you'd write down. Don't describe it as something you've done before | Tests R4 and the two-squads line live, and surfaces the dossier's unresolved decision-authority question in a natural way |
| B4 | "How would you run discovery with integration partners in your first 60 days?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Give it as a plan: who you'd talk to first, what you'd ask, how you'd record and share it, and what would make you stop and change direction. Answer slot: if scoping those integrations gave you an approach you'd reuse, describe it in your own words. If not, say so plainly and present the plan as new. Never call your scoping "discovery" (see Prohibited claims) | The JD's discovery responsibility (F8). The plan is generic, but the one clause about your past rests on Q1 |
| B5 | "Here's a reference page for one of our endpoints. What would trip up a partner developer?" | CASE | [generic] | Read it in a fixed order out loud: authentication, request and response schema, required fields, error codes, pagination and rate limits, versioning, examples. Name the one gap you'd fix first and why. Answer slot: if you've read or written docs like this, say so in your own words. If not, say so plainly | R3 (F4) checked live, which is likelier than a question about it. Rehearse by reading any public API reference out loud for ten minutes |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How are you counting the 30+ integrations?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slots, in your own words: how the figure was counted, what it is sensitive to, which assumption behind it you'd defend least, and which part was yours. "I'd have to check exactly how that was counted" is an honest answer. Don't round it up or invent a breakdown | Every headline number gets a defend-the-number question. F1's and F3's whole case rests on this figure |
| C2 | "Pick one of those integrations and take me from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on Q1. The beats are the stages it names (scoping, requirements, architecture, UAT, go-live) and the fact that you led them. Pick one you know cold and tell it in your own words. Answer slot: the JD's spec line makes a probe on the requirements stage likely. If it produced a written document, say what it was and what part was yours. If it didn't, say so plainly | Tests whether "led" survives detail (F9). EXP because it checks what was actually yours |
| C3 | "Tell me about the integration playbook. What's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats from Q2: you wrote it, it's internal, and your team uses it. The dossier rates it inspectable, so you can offer to describe how it's organized. Answer slot: R3 makes a docs-and-schemas probe likely. If the playbook covers API documentation or schemas, say how. If not, say so plainly | Your strongest inspectable artifact. It's one of the few places you can show your work rather than describe it |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats only: the integrations you led, the playbook you wrote, and the roadmap-input sessions. Then your reason for this role, which is an answer slot: say it in your own words. Don't use any PM title or roadmap-ownership language | The likely opener, and it sets the frame for A1. Built only from the three verified sentences |
| D2 | "What's your experience with agile delivery?" | JD | [grounded] | The dossier marks this clarify, and no verified sentence speaks to it. Answer slot: if you have worked in agile delivery, say how, in your own words. If you never worked that way, say so plainly. Then add: "Here's what I'd want to understand about how your squads run it." Planning cadence and who owns the backlog are good examples | R5 (F7). It's a preferred requirement asked casually, which is how mid-list items usually arrive |
| D3 | "Tell me about a time you worked with a sales team on a client." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick an integration where sales was involved, if one was, and say what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the client integrations you led) or how you would work with sales | R4's sales clause is silent in your material (F6). This rehearses the honest branch before it's needed |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already a PM?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; plus prohibited_claims: "Having held a product manager title or role" | The 60-second version of A1: one sentence of concession ("I haven't held a PM title"), the two quotes at their scope, and one sentence of plan. Pause before answering. Hold through two follow-ups by returning to the quotes. Don't argue that the other candidate is weaker | A1 under time pressure. Same material, compressed delivery |
| E2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote's verb: you led them. Answer slot: say which part was yours and which was others', in your own words. If you're unsure on any of them, say so plainly. Concede specifics, not the core claim | An attribution probe on F3's headline figure |
| E3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] uncertain_or_weak_areas acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Choose the real one. Words: "I haven't owned a product roadmap." Then the ramp plan from F2. Don't swap in a softer weakness | F2 is the gap the dossier found genuinely absent. Naming it yourself is stronger than having it found |

### P — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "The squad leads have a lot of say today. Where's the seam between you and them, and what happens when you disagree?" | JD | [generic] | Propose principles, not a map you don't have: the PM owns the why and the what for partners, the squads own the how, and disagreements go to the evidence first. Then ask how it works today. That is reverse question RQ1. Make no claim about your past | The dossier's top unresolved risk, asked by the hiring manager on the squad leads' behalf |
| P2 | "Tell me about a time credit for an integration was shared across teams." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | If one of the integrations you led fits, pick it and say "we" for context and "I" for what was yours. If no such time comes to mind, say so plainly and say how you would handle it | Credit-sharing probes test whether "led" stays honest in a team story |

### G — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection criteria: a named stake, a moment you didn't fold, and a relationship intact at the end. If one of the roadmap-input sessions carried such a moment, use it in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | A behavioral stem, low weight. No published Quartzline values were researched, so this is not mapped to any |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a real trade-off and a decision that was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | A common behavioral stem. Customer framing fits a partner-facing role |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 "3+ years product management experience" | A1, A5, E1, D1 |
| R2 "Shipped API or platform products" | A4, C1, E2 |
| R3 "Technical fluency: API docs, schemas" | B5, C3 |
| R4 "Stakeholder management across engineering, sales, customers" | B3, D3, P1 |
| R5 "Agile delivery experience" | D2 |
| "Own the roadmap for the partner-facing API platform" | A1, A2, E3 |
| "Run discovery with integration partners" | B4 |
| "Write specs and drive delivery with two engineering squads" | A3, C2, P1 |
| "Define and track adoption metrics" | B1, B2 |
| Company strategy (CO) | none. Research was refused, and a CO question built without it would rest on memory |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier's questions for the employer. It tests its top open risk: authority is stated in the JD but not shown. It reads as diligence, and the answer tells you what the job really is |
| RQ2 | "How is partner API adoption measured today, and what's the current baseline?" | From the dossier. Adoption is listed as a responsibility with no baseline stated. If there's no baseline, your first quarter is building one, and you'll want to know that before accepting |
| RQ3 | "Where do integration partners get stuck most often today?" | It ties to the discovery responsibility and gives you live material for B1 and B4 if they come up later in the conversation |
| RQ4 | "How do sales and the squads hand partner requests to the PM today?" | It probes R4's three-way stakeholder line and shows you're thinking about the flow of work, not just the roadmap |
| RQ5 | "What would make you say this hire was a success at six months?" | It turns the conversation to their criteria and gives you the measure your ramp plan should target |
| RQ6 | "What made you open this role to someone from outside the PM track?" | Ask this only if the conversation has already acknowledged the title gap. It surfaces how they see the bridge, in their words |

---

## Prohibited claims

What this pack will not coach, and why. These hold under follow-up pressure too.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Q1 and Q3 at their own scope, plus "I haven't held a product manager title." |
| Having owned a product roadmap | Dossier prohibited_claims, and the acknowledge_gap area | Q3 at its own scope (sessions that fed client evidence to product), plus "I haven't owned a product roadmap." No bridge |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Q1 at its own scope, plus "I haven't set prioritization for an engineering squad." |
| Shipped an API or platform product | Inflated form of F3 | Q1 at its own scope. The limit is the pack's observation, not words for you: the material says integrations of the vendor's REST APIs. A4's slot stays inside go-live |
| Ran product discovery with partners | Inflated form of F8 | Q1's scoping and requirements, at their own scope. B4's slot stays inside scoping |
| Wrote product specs | Inflated form of F9 | Q1's requirements stage, at its own scope. C2's slot asks only what that stage produced |

---

## Sources

- **Provided:** `tuesday-dossier.md`, v1.1, generated 2026-08-14 by job-underwriter. Sections consumed: `role_profile` (the JD equivalent, including the requirements R1–R5 and the responsibilities), `decision` (context only), and `handoff_to_mock_interview` (the verified evidence Q1–Q3, the weak areas and their allowed strategies, the objection behind A1, the risks and employer questions behind R1 and R2, and `prohibited_claims`). The dossier has no `evidence_map`, `evidence_state` or `risk_register`. Its decision summary mentions "seven years of integration leadership", but no verified entry carries that figure, so this pack does not use it.
- **Your note:** the round is a 45-minute conversation with the hiring manager, on Thursday.
- **Searches sent:** "Quartzline company values" (refused), "Quartzline interview process product manager" (refused), "Quartzline partner API platform news 2026" (refused). No fetches.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have given official value names to theme the G bank. The values cheat sheet would still not apply, because no values round is in this session |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. It would have documented the wider loop. This session's structure rests on your own description of the round |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have grounded at least one CO or CASE question in current strategy. The B bank is `[generic]` as a result |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Permission to search → official values for the G bank and a strategy-grounded CO question in place of a `[generic]` B row. A deeper pass is also available: up to 6 more searches and 2 more fetches, several more minutes
- The current posting text → checks whether the August requirements still stand, and turns them into exact JD quotes
- Your CV → tenure and anything else the three verified sentences don't carry become quotable (the dossier's "seven years" included)
- Your answers to the answer slots in F3, F4, F6, F7, F8, F9 and F10 → those rows move from slots to story-mapped guidance
- A document from one roadmap-input session (an agenda, a summary sent to product) → raises Q3 from medium toward high and lets A2 show work rather than describe it
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- Any recruiter guidance (focus areas, a pre-declared exercise) → coverage aimed at what they said, and a build section for any deliverable
