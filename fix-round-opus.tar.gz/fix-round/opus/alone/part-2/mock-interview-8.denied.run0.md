I've finished your prep pack for 21 November and saved it as `AshgroveCreditUnion_member-experience-lead_interview_pack.md`. It covers all three rounds from the recruiter's email: one shared analysis of how your background fits the job, then a separate section for each round. Interviewers haven't been named yet, so the pack has no notes on individual interviewers.

- **What to rehearse first: question C1 in Round 2.** Your future manager is likely to say something like "I don't see contact-centre work in your background." Start with "I've never worked in a contact centre" before they press. Then mention what you did on the branch side: the complaints log, training new tellers, and the monthly spreadsheet. Finish with a plan for learning the contact-centre side.
- **Plan for the 20-minute case, not the answer.** The pack splits the 20 minutes into stages and gives you three positions to choose from. Each one comes with a concession you should say out loud. It also suggests how to stand out from the standard "apologise, investigate, resolve" answer.
- **Values round.** There's one prepared story or story outline for each of the four values, using their exact names.
- **Things to check before the day.** Several requirements depend on facts your notes don't settle:
  - whether your complaints log counted as regulated complaints;
  - what your spreadsheet tracks, and whether it's in Excel;
  - whether you've presented at regional level;
  - any work with digital or online banking teams.

  Each of these has a short "answer slot" with two honest ways to respond. If you tell me the facts, I'll turn those slots into stories in your own words.
- **No web searches.** Everything you pasted already covered what they would have found: the values, the round structure and the strategy brief.

If you'd like a live practice, I'll play the skeptical manager on C1 and push back on what you actually say. I can also save a `tuesday-dossier.md` file listing the gaps this prep found, for later prep sessions. And I can turn the pack into a Word document if that's easier to work from.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AshgroveCreditUnion_member-experience-lead_interview_pack.md -----
# Interview pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of loop:** 21 November 2026, three rounds on one day · **Pack built:** 12 November 2026
**Rounds:** (1) recruiter, 30 min · (2) Head of Member Services, your future manager, 45 min, mostly behavioural · (3) panel of two branch managers, 60 min, with a 20-minute complaint-escalation case, scored against the four values
**Interviewer names:** not yet assigned, so there is no interviewer read

---

## How to use this pack

- **Personas** describe *how* a question is asked: the register, the pressure, who's asking. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behavioural and values. Does what you've done show Ashgrove's *published* values?
  - **EXP**: work-experience deep-dive. Does what you said hold up, and how much of it was yours?
  - **JD**: role-driven. Can you do the listed job, including the parts you haven't done yet?
  - **CO**: company and strategy. Can you think at Ashgrove's level about Ashgrove's plans?
  - **CASE**: a live problem from the actual role.
- **Provenance labels:** `[grounded]` traces to something you or the recruiter gave me. `[inferred]` is my own reasoning from that material, and the reasoning is named. `[generic]` is a pattern common to roles like this one, with no claim about Ashgrove.
- **Answer slots** mark places where a strong answer needs a fact your material doesn't contain. Each one gives you two honest ways to answer. Fill it from memory, in your own words, or take the "say so plainly" branch. Never fill it with what sounds right.
- Guidance is scaffolding, not a script. Every phrase in it that describes your past is built from one of your own sentences, quoted in the fit snapshot.
- **Highest-ROI prep in this pack: C1** (Round 2), the contact-centre objection. After that, the case build (section "The 20-minute escalation case").

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material describes one branch's log, not a process across branches, and your words should stay at that size: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If you decided how complaints in it were resolved or closed, say which ones and how, in your own words. If handling it meant recording what others decided, say so plainly and stay with the log |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | No wording can close this gap, and you've said so yourself. Words: "I've never worked in a contact centre." Then say how you would learn it, framed as a plan, never as something you've done. This gap is behind C1, the highest-ROI rehearsal |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence covers "monthly" and "complaints". It doesn't cover volumes or resolution times. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counts volumes or resolution times, say how each one is counted, in your own words. If it counts something else, say what. If you don't know how a figure is defined, say that plainly. Never describe it as a report you presented |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers, not supervisors, and your words should stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you trained likely. If you chose how the training was run, say how, in your own words. If you delivered it the way someone else set it up, say so plainly and stay with the script |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. Answer slot: if you have worked with a digital team, or on how members use online or app banking, say what it was and what your part was, in your own words. If you haven't, say so plainly and describe how you would start working with one |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. It's a self-description with no document behind it, so expect a light check. State it as you wrote it: six years in retail banking, the last three as a branch supervisor. Let the interviewer map it to the requirement, and don't relabel it as "customer operations" |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your sentence says "formal". It doesn't say "regulated". Answer slot: if the complaints in that log came under your regulator's complaint-handling rules, say so and what those rules meant for how they were handled, in your own words. If you're not sure, or they didn't, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Your own words set the ceiling: "I've never presented to anyone above regional level." Say it as it is, then give your plan for the first update to senior leaders, framed as a plan |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence sets an upper limit. It doesn't say whether you have presented at regional level. And your regional manager using your spreadsheet is not the same as you presenting it. Answer slot: if you have presented at regional level, say to whom and about what, in your own words. If you haven't, say so plainly and stay with the spreadsheet |
| F10 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says "spreadsheet". It doesn't say Excel. Answer slot: if it's built in Excel, say so and describe the functions you actually use, in your own words. If it's another tool, name it plainly |

---

## Grounding brief: Ashgrove's current plans

Built from the four points you summarised from the July 2026 strategy brief. I haven't seen the brief itself, and that brief is about four months old, so treat progress since July as unknown: ask about it rather than state it.

| What Ashgrove has said | Where it bites in this role | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | The JD's "work with digital teams on self-service journeys" line. Complaints about digital journeys are likely to be a growing share of your report | [grounded] |
| Consolidate eight branches into five hubs over 2027 | The Round 3 panel are branch managers. Complaint volumes and escalation routes are likely to shift during 2027. "Neighbours, Not Numbers" is the value this tests hardest | [grounded] |
| Launch a small-business lending product in Q1 2027 | A new product and new members, so a new kind of complaint lands in the process you'd own within months of starting | [grounded] |
| The main competitive pressure is app-only banks | The likely "why a credit union" frame. The values ("Members First", "Neighbours, Not Numbers") read as what Ashgrove offers that an app-only bank doesn't | [inferred] |
| Member-owned, about 900 staff | From the JD. "Member", not "customer", is the house word. Use it | [grounded] |

---

## The 20-minute escalation case (Round 3, announced by the recruiter)

The recruiter pre-announced this, so it's a graded deliverable. You don't know the scenario yet. Rehearse a structure, not an answer.

**What you can build on from your own material.** Use only these sentences, quoted from the fit snapshot:
- F1: "I handled the branch's formal complaints log"
- F4: "trained new tellers on our escalation script"
- F3: "I built the monthly complaints spreadsheet our regional manager uses."

Use at most one of them, once, as context ("I handled the branch's formal complaints log, so I'd start with the record"). Don't build the case answer around them. The panel is scoring how you think about *their* complaint.

**A 20-minute shape** `[generic]`:

| Minutes | Move | Why |
|---|---|---|
| 0–3 | Clarify: what has the member been told so far? What does the record show? Has it been logged formally, and is a response deadline running? Does it count as a regulated complaint under the rules Ashgrove works to? | Clarifying before structuring is what case scorers look for, and you don't know Ashgrove's rules yet, so ask |
| 3–8 | This member, now: who contacts them, when, with what. Decide from the member's side | "Members First, Always", the value's own words |
| 8–13 | The escalation: who keeps hold of it, and what you do with the supervisor who escalated it | "Own the Fix" and the JD's "coach branch supervisors on escalations" |
| 13–17 | The cause: is it one person, one branch, or a process? What would show up in volumes and resolution times? | The JD's monthly-report line |
| 17–20 | Close on the member outcome, and what you'd write to them | "Plain Words" |

**Theses to choose from** (pick one and defend it; each carries a concession you must say out loud):

| Thesis | The concession you say | Provenance |
|---|---|---|
| T1: Fix it for this member first, then fix the cause, as two separate tracks | Root-cause work takes longer than the member should have to wait, so they run in parallel, and the member never waits on the investigation | [generic] |
| T2: The supervisor who escalated keeps hold of the complaint; I back them up rather than take it off the branch | Some complaints have to come to the centre, such as a deadline at risk, a regulated-complaint rule, or a conflict. Name where that line sits and ask how Ashgrove draws it | [inferred] from "Own the Fix" |
| T3: Write the final response so the member never needs it explained twice | Plain words aren't the same as admitting fault. Anything that accepts liability gets checked with whoever owns that call | [inferred] from "Plain Words" |

**How to stand out.** Every prepared candidate says "acknowledge, apologise, investigate, resolve, follow up". Say it in one breath to show you know it. Then spend your time on what most candidates skip: treating the escalation as a coaching moment for the supervisor, and saying what this complaint adds to the monthly volumes-and-resolution-times picture. Both come straight from the JD.

**What to refuse to promise:** an outcome for the member before you've seen the facts. In this case, saying "I'd want to see the record before promising anything" is a strength.

**End on** what the member hears, in one plain sentence.

---

# Round 1: recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers: "walk me through", "why us" | High. This is the usual register for a recruiter screen, and the recruiter already set up the process. The risk is treating it as unscored | A rehearsed 90-second arc built from your own sentences, and treating casual questions on JD topics as scored |
| Skeptic (light) | Quick checks against the stated requirements | Medium. Recruiters screen against the requirements list: years, regulated complaints, Excel | Short, true answers. A stated gap answered in one sentence, not defended |

### Question bank

**A: Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, and only these beats: six years in retail banking, the last three as a branch supervisor. In that role you handled the branch's formal complaints log, trained new tellers on your escalation script, and built the monthly complaints spreadsheet your regional manager uses. Close on why this role, which is motivation rather than history, in your own words | Almost certain to be the opener. F6, F1, F4 and F3 are the whole of your arc. EXP because it sets what the next two rounds will probe |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Use their own words: they say they "decide from the member's side of the counter". Pair that with one strategy point, such as app-only banks being the competition. Answer slot: give your real reason in your own words. If you have no personal link to credit unions, don't invent one. A reason drawn from the values is enough | Motivation is a standard screen check. CO because it tests whether you've read what they published |
| A3 | "Why move on from branch supervision now?" | EXP | [grounded] "the last 3 as a branch supervisor" | Point forward, not back. Name the part of this JD you want more of, and connect it to the log and the spreadsheet in your sentences' own words. Answer slot: your actual reason, in your own words. Don't criticise your current employer | Screens check that your motivation story is consistent before the manager round. EXP because it reads your recent role (F6) |
| A4 | "How comfortable are you in Excel — what do you build?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the spreadsheet as your sentence does: you built it, it's monthly, your regional manager uses it. Answer slot: if it's in Excel, say so and describe the functions you actually use. If it's another tool, name it plainly | The JD's Excel requirement (F10) is easy to screen on. JD because it is a listed requirement |

**B: Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for experience handling regulated complaints — tell me about yours." | JD | [grounded] "I handled the branch's formal complaints log" | Lead with your sentence: "I handled the branch's formal complaints log." Answer slot: if those complaints came under your regulator's complaint-handling rules, say so and what that meant for how they were handled. If you're not sure, or they didn't, say so plainly and stay with the log. Never call them regulated unless they were | F7 is a listed requirement, and the word "regulated" is exactly where a screen will check. JD because it scores the stated requirement |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Answer straight: "No, I've never worked in a contact centre." Then one sentence on how you'd learn it (a plan, not a past), and stop. The full version is C1. Here, a short, unbothered answer is the win | F2 is the most visible gap against a role that spans branches and the contact centre. JD because the JD names the contact centre |
| B3 | "The bar is four-plus years in customer operations — how does your background map?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | State it as written: six years in retail banking, the last three as a branch supervisor. Let the recruiter do the mapping. Don't rename your work "customer operations" | F6 meets the requirement on your own words. The risk is over-selling it. JD because it's the first listed requirement |

### Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| "What does the Head of Member Services most want this hire to fix first?" | Previews Round 2's priorities, and recruiters usually know |
| "For the 20-minute case, will I get the scenario in writing, and is there any reading time?" | A logistics question that shapes your case structure, and asking it shows you're preparing for it |
| "Is this a new role or a backfill?" | Tells you whether you'd be building the complaints process or inheriting one |
| "How is success measured in the first six months?" | Signals you think in outcomes, and gives you a target to speak to in Round 2 |
| "What happens after 21 November, and when would I hear?" | Practical, and it closes the screen cleanly |

---

# Round 2: Head of Member Services (your future manager), 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "Tell me about a time…" stories | High. The recruiter said this round is "mostly behavioural" | STAR shape, "we" for context and "I" for your part. Pick stories from your own memory, and where none fits, say so |
| Skeptic | Quiet probing of the gaps | Medium–high. A future manager is buying capability and de-risking the gaps, and F2 and F8 are visible ones | Rehearse C1 until it's boring. Name the limit before it's asked for, then a concrete ramp plan |
| Case / Strategist | Live problems drawn from the strategy | Medium. Hiring managers often test this, though the recruiter's "mostly behavioural" caps it | Clarify, then objective, segments, approach, metrics, risks. Use Ashgrove's vocabulary |
| Data-Driven Prober | "What does that spreadsheet actually count?" | Low–medium. Your spreadsheet (F3) is the one thing to probe, and you've given no figures | Know what you can and can't say about how it counts. Say plainly what you don't know |

### Question bank

**D: Behavioural**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you handled a complaint that needed escalating." | VAL | [grounded] "I handled the branch's formal complaints log" | The log is your context, not your story. Pick one complaint you were personally part of. It needs what the member raised, what you decided or did, and how it ended. "I" for your part, "we" for the branch's. If no single case comes to mind, say so plainly, then describe how the log was handled, in your sentence's terms | The JD's escalation line makes this near-certain. F1 gives context, not a story. VAL with EXP delivery, because it's a scored behavioural story about your actual part |
| D2 | "Tell me about a time you taught someone to handle a difficult member conversation." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers, on your escalation script. Those are the beats your sentence states, so tell them in your own words. Answer slot: the JD's coaching line makes a probe on how you trained likely. If you chose how the training was run, say how. If you delivered it as set by someone else, say so plainly and stay with the script | Coaching is a JD responsibility, and F4 is your nearest evidence. VAL because it's asked as a behavioural story, with JD content |
| D3 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [grounded] | Selection scaffold: pick a time with a named stake, a moment where you didn't back down, and a working relationship intact afterwards. Your regional manager is the most senior person your material mentions. If no such time comes to mind, say so plainly, then describe how you would handle it | Presenting to senior leaders is a requirement and F8 is the gap, so the manager will look for nerve with seniority. VAL, open prompt |
| D4 | "Tell me about a time a complaint showed you a process problem, not a people problem." | VAL | [grounded] | Selection scaffold: one complaint, the pattern behind it, what you did about the pattern, and whether it got solved. If no such time comes to mind, say so plainly, then describe how you would look for patterns in a complaints log | The JD asks you to own the process "end to end", and this tests whether you think past the single case. VAL, open prompt |
| D5 | "Tell me about a time you worked with a team outside your branch to fix something for members." | VAL | [grounded] | Selection scaffold: another team, a member problem, your part, the result. Answer slot (F5): if any of it involved a digital team or online or app banking, say so. If not, say so plainly. If no such time comes to mind, say so plainly, then describe how you would start working with a digital team | "Work with digital teams on self-service journeys" is in the JD and F5 is empty. VAL with JD content |

**C: Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see contact-centre work in your background, and this role owns complaints across branches and the contact centre. How would you handle that half of the job?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses." | **The highest-ROI rehearsal in this pack.** *Open with the limit, before they push:* "I've never worked in a contact centre." *Then hold on what your sentences carry, once each:* "On the branch side, I handled the branch's formal complaints log, trained new tellers on our escalation script, and built the monthly complaints spreadsheet our regional manager uses." *Then the plan, said as a plan:* in the first weeks, sit with contact-centre agents and team leaders, listen to complaint calls, read complaints from both channels side by side, and ask where escalations stall. *Follow-up 1, "phone complaints are different":* concede it — "They are, and I don't yet know how. That's what the first weeks are for." *Follow-up 2, "so you'd be learning on the job?":* "On the contact-centre side, yes." Hold the branch side and don't fold it. Never claim that complaints are the same whatever the channel | F2 against the JD's "across branches and the contact centre" is the most predictable objection to you, and your future manager owns both channels. A calm, rehearsed concession changes this round. JD because it scores a named responsibility |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" | Pick presenting, because C1 covers the contact centre. Words: "I've never presented to anyone above regional level." Then a plan: how you'd prepare your first update to senior leaders, for example one page, the monthly numbers, one ask, rehearsed with your manager first. Don't pick a fake weakness | A standard skeptic stem, and F8 is a real gap with your own words for it. JD because it maps you against the listed requirements |
| C3 | "This role reports complaint trends to senior leaders. What have you presented, and to whom?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot (F9): if you've presented at regional level, say to whom and about what, in your own words. If you haven't presented at all, say so plainly and stay with the spreadsheet your regional manager uses. Then the ceiling in your own words: "I've never presented to anyone above regional level." Don't say the spreadsheet drives regional decisions. Your sentence says the manager uses it, nothing more | The JD's presenting line together with F8 and F9. The manager will press here because they'll be the one sending you into those meetings. JD |

**E: Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We want 40% of member service on digital channels by 2028. What does that mean for complaints, and what would you do first?" | CO | [grounded] | Clarify first: today's channel mix and how digital complaints are logged now. Objective: members can complain as easily in the app as at the counter. Split by channel, complaint type and member group. First moves: read complaints from digital journeys, then work with the digital team on the journeys that generate the most. Use their words: "self-service journeys", "Plain Words". Name your weakest assumption, which is that you don't know the current mix | Built from the strategy brief. Your future manager will own this target. CO content with CASE delivery |
| E2 | "Eight branches become five hubs over 2027. How do you keep complaints from spiking, and how would you know?" | CO | [grounded] | Clarify: the timeline, which branches, and what members are told. Approach: watch volumes and resolution times by branch before, during and after each move (the JD's own monthly report), and give the affected branches' supervisors a clear escalation route. Risk: members who lose their branch complain about the change itself, which is a "Neighbours, Not Numbers" moment. Say what you'd need to know | Consolidation happens over the year you'd start. CO with CASE delivery |

**G: Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through that monthly complaints spreadsheet — what does it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Describe it in your sentence's terms: you built it, it's monthly, your regional manager uses it. Answer slot (F3): if it counts volumes or resolution times, say how each is counted, in your own words. If it counts something else, say what. If you don't know how a figure is defined, say so | F3 is your strongest match to the reporting line, so it's the first thing a prober opens. EXP because it tests what the spreadsheet actually is |
| G2 | "How do you know the numbers in it are right?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you check the figures, say how, in your own words. If there's no check, say so plainly and say what you would add. Name the weakest point in how it's counted yourself, before they find it | A standard second-level probe on any report. EXP |

### Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| "Where do complaints stall today: at the branch, in the contact centre, or between them?" | Shows you're thinking about the cross-channel seam C1 is about, and it tells you the real job |
| "How will the move to five hubs change who handles an escalation?" | Uses their own strategy, and it's the biggest process change you'd inherit |
| "When a complaint starts in the app and ends in a branch, who owns it?" | Their "Own the Fix" value applied to their own digital target. It reads as having done the homework |
| "What would you want in front of senior leaders from this role in the first quarter?" | Addresses F8 head-on as a planning question, and gives you their format |
| "How does this role work with the digital teams — embedded, or by request?" | Practical, and it tests how real the "self-service journeys" line is |
| "Will the new small-business lending product's complaints come through this process?" | A Q1 2027 launch inside your first months. Few candidates will connect it |

---

# Round 3: panel of two branch managers, 60 minutes: values round plus a 20-minute case

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One story prompt per value | High. The recruiter said the panel "score against the four values" | The cheat sheet below. One story per value, in their exact value names |
| Case / Strategist | The 20-minute escalation case | High. Announced by the recruiter | The build section above |
| Peer Evaluator | "What does this mean for my branch?" | Medium. The JD has you coaching branch supervisors, so these managers are judging what you'd add to or take from their branches | Lead with what you'd bring, then what you'd need. Propose principles, not a rulebook |
| Pressure | Push-back inside the case, time-boxed asks | Low–medium. Two interviewers and a timed case make it likely in places | Pause, restate the question, hold through two follow-ups, then concede what's real |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's point of view | Selection scaffold: a time you chose what was right for the member over what was easier for the branch. It needs a decision that was yours and a member outcome. If no such time comes to mind, say so plainly, then describe how you'd decide in the case |
| Plain Words | If it needs explaining twice, the writing failed | F4: "trained new tellers on our escalation script". Answer slot: if you ever reworded the script, or how you taught it, because it wasn't landing, say what and why. If not, say so plainly and stay with training them on it, or pick a member story using the same test |
| Neighbours, Not Numbers | Each branch belongs to its town, and members are people, not cases | Selection scaffold: a time you treated a member as a person rather than a ticket. It needs a specific member (anonymised), what you did differently and why. If no such time comes to mind, say so plainly, then describe how you'd do it. Tread carefully, because consolidation affects these managers' branches |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because of a problem you noticed, say what the problem was and whether it got solved. If you were asked to build it, say so plainly and choose a different story with the same shape |

### Question bank

**H: Values**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a call from the member's side of the counter, even though it was harder for the branch." | VAL | [grounded] | The Members First scaffold above. Say the value's name once, near the end, and let the story carry it | Every published value gets one question in a scored values round. The wording comes from their own value |
| H2 | "Tell me about a time you had to make something simpler so it landed first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: training new tellers on your escalation script, as your sentence puts it. Answer slot: if you reworded the script, or how you taught it, because it wasn't landing, say what and why. If not, say so plainly and stay with the training, or switch to a member story | Plain Words. F4 is your nearest material. VAL |
| H3 | "Tell me about a time you treated a member as a neighbour, not a number." | VAL | [grounded] | The Neighbours, Not Numbers scaffold above. Keep it about one member and one branch, and keep it specific | Their value, in their own phrase. The panel are branch managers, so this one is close to home. VAL |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The Own the Fix slot above. If the spreadsheet wasn't a fix, use a different story. Don't force it | Own the Fix, in their wording. VAL with EXP probing likely |

**K: Case (the 20-minute case: rehearse the build section, then these follow-ups)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "A member has complained twice at her branch about a fee and now says she'll take it further. The supervisor has escalated it to you. Go." | CASE | [generic] | Run the 20-minute shape: clarify, then this member now, the escalation, the cause, and close. Pick one thesis (T1–T3) and say its concession out loud | A practice scenario. The real one is unknown. `[generic]` because it's a pattern, not Ashgrove's actual case |
| K2 | "The branch manager thinks the member is wrong. What do you do?" | CASE | [generic] | Separate the facts from the relationship: check the record, hear the manager out, decide from the member's side of the counter, and explain the decision in plain words to both. Hold the decision if the facts support it | A likely follow-up from a panel of branch managers. Peer pressure delivered through the case. CASE |
| K3 | "How would you stop this happening again?" | CASE | [generic] | Cause, then fix, then check: is it a single case, a branch pattern or a process issue? What would show up in monthly volumes and resolution times? Who keeps hold of the fix until it's solved? | The JD's process and reporting lines, plus "Own the Fix". CASE |

**P: Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You'd be coaching my supervisors. What would you need from me, and what would you bring my branch?" | JD | [grounded] "the last 3 as a branch supervisor" "trained new tellers on our escalation script" | Bring first, need second. Bring: "I've spent the last three years as a branch supervisor, and I trained new tellers on our escalation script." Let them draw the inference. Need: their read on where escalations go wrong, and time with their supervisors. Propose a principle, for example that the person who finds the problem keeps hold of it, with backup. Don't claim to know their supervisors' problems | F4 and F6 meet the JD's coaching line from the branch side. The panel are pricing what you'd add to their branches. JD with Peer delivery |
| P2 | "Some branches become hubs next year. A member complains she's losing her branch. How do you handle it?" | CASE | [grounded] | Listen first. The complaint is about the change, so it may not be "fixable". Decide what you can do for her (her new route, a named contact), explain it in plain words, log it so the volume shows up in the monthly report, and pass the pattern on to whoever runs the consolidation. "Neighbours, Not Numbers" | Consolidation is in the strategy brief, and these managers will live it. CASE with CO content |

**Q: Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Sixty seconds: why you over one of our own branch supervisors?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." | Pause, then 60 seconds on your sentences only: six years in retail banking, three as a branch supervisor, the formal complaints log, the monthly complaints spreadsheet. Then one line of fresh eyes, as a reading rather than a claim. Don't run down internal candidates, and don't claim to know who they are | A standard pressure stem with a timer. Hold on F6, F1 and F3. JD |
| Q2 | "Honestly, you've never worked in a contact centre. Isn't this a branch person applying for a cross-channel job?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | A short version of C1. Concede first: "I've never worked in a contact centre." Hold: "I handled the branch's formal complaints log." Then the plan, in one sentence. If they push a second time, keep the concession the same size. Don't shrink the branch side to make peace | F2 again, in a harsher register. Rehearsing it twice is cheap insurance. JD |

### Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "Where do escalations from your branch go wrong today?" | They'd be your partners, and it tells them you'll listen before coaching |
| "What would make this role a help to your supervisors rather than another layer?" | A reciprocity question, which suits a panel judging what you'd add to their load |
| "How are your branches thinking about the move to hubs, from the members' side?" | Uses the strategy and "Members First" without presuming anything about their branches |
| "What does 'Neighbours, Not Numbers' look like on a busy Saturday?" | Their value, made concrete. Branch managers will have an answer |
| "What's one complaint you wish had been handled differently, and what would have fixed it?" | Invites "Own the Fix" stories from them, and gives you real material for the role |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches | D1, D4, K1, K3, A1 |
| …and the contact centre | B2, C1, Q2 |
| Report monthly on volumes and resolution times | G1, G2, E2, K3 |
| Coach branch supervisors on escalations | D2, P1, K2 |
| Work with digital teams on self-service journeys | D5, E1 |
| 4+ years in financial-services customer operations | B3, A1 |
| Experience handling regulated complaints | B1, K1 |
| Confident presenting to senior leaders | C2, C3, D3 |
| Comfortable with Excel reporting | A4, G1 |

---

## Prohibited claims

What this pack won't coach, built from the fit snapshot. These are the claims most likely to slip out under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." My observation of the limit: your material describes one branch's log, not a process across branches. The D1 and B1 slots stay inside the log |
| Any contact-centre experience | A gap you stated yourself, F2 | "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | A gap you stated yourself, F8 | "I've never presented to anyone above regional level." |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script". My observation of the limit: your material says tellers. The D2 and P1 slots stay inside the training |
| Produced or presented the region's complaints reporting | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." My observation of the limit: your material says nothing about presenting it or about what it's used to decide |

---

## Sources

**Provided documents:** the JD (pasted). The values text, which you pasted after copying it on 12 November 2026 from ashgrovecu.org/about/values (pasted, not fetched). The recruiter's email describing the three rounds. Your four-point summary of Ashgrove's July 2026 strategy brief (the brief itself wasn't shared). Your background, in your message.

**Searches and fetches sent:** none.

**Dossier:** none present. The pack was built from raw inputs.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values you pasted this morning already fix the values cheat sheet and the H bank |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email sets out all three rounds, so it fixes the persona weights and round structure |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief you summarised (under six months old) supplies the grounding brief and the E, P2 and reverse-question strategy hooks |
| 4. Interviewer names | n/a | No names have been assigned, so there's nothing to search |
| 5. Representative JD | skipped | You supplied the JD |

---

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read, persona weights for each panel member, and a reverse question tied to each person's career path
- **Your answers to the answer slots** (were the log's complaints regulated, F7; what the spreadsheet counts and in what tool, F3 and F10; any presenting at regional level, F9; any digital or self-service work, F5; how the teller training was run, F4) → those rows' bridges become your own quoted words, and B1, A4, G1, G2, C3, D2, D5 and H2 move from answer slots to story maps
- **How much prep time you have before 21 November** → a prioritised prep schedule, tied to question IDs
- **The full strategy brief text** → the grounding brief in Ashgrove's own numbers and vocabulary, and sharper E1, E2 and P2
- **One email to the recruiter about the case format** (written scenario? reading time?) → the 20-minute case build tuned to how it's actually run
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → Ashgrove news since July, any published complaints information, and candidate reports on their loop, mainly sharpening the CO questions. Offered once
- **A tuesday-dossier.md from job-underwriter** → the highest-ROI objection taken from evidence you've confirmed rather than inferred by me, a binding strategy for each weak area, and an underwriter-built prohibited list. Not needed for this pack
