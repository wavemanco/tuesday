Your inputs cover everything the pack needs, so I'm writing the full three-round prep pack now.
I've built your prep pack and saved it as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-8-canned-696a09bd/Ashgrove_member-experience-lead_interview_pack.md`. It covers all three rounds on 21 November, set up the way the recruiter's email describes them. Everything came from what you gave me, so I didn't do any web research.

- **The question to rehearse most is C1, in the manager round.** It's the jump from handling one branch's complaints log to owning complaints across all branches and the contact centre. The pack scripts the answer: what you can stand on, the gap you admit before they ask, a plan for learning the rest, and three likely follow-ups. L2 in the panel round is the same objection asked more sharply.
- **Your two stated gaps get plain words, not spin.** You said you haven't worked in a contact centre and haven't presented above regional level. The pack has you say exactly that, then give a plan for each.
- **The 20-minute complaint case has its own section.** It gives a structure for the 20 minutes, three opening arguments with the weakness you should admit for each, ways to stand out from the standard answer, and what not to do in front of branch managers.
- **Each of Ashgrove's four values has a story to tell.** For Plain Words it uses your teller training. For the other three it gives a checklist for picking a story from your own experience. Your note doesn't show a specific story for those yet.
- **Some answers are left for you to fill in.** For example: whether the spreadsheet tracks complaint volumes and resolution times, whether it's in Excel, and whether the complaints log followed a regulator's rules. Each one gives you an honest way to answer whichever is true. If you tell me the answers, I'll rewrite those questions around what you actually did.
- **The strategy points come from your summary of the July brief, not the brief itself.** If you mention them in the interview, credit them to the brief the recruiter sent.

If you want to practise, I'll play the sceptical manager on C1.
I can also save a tuesday-dossier.md that records the gaps this prep found, for you to bring to later sessions.
If you'd like the pack as a Word document, I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of loop:** 21 November 2026 · **Mode:** loop (three scheduled rounds)

| Round | Who | Length | What the recruiter said it holds |
|---|---|---|---|
| 1 | The recruiter | 30 min | A conversation with the recruiter |
| 2 | Head of Member Services (your future manager) | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | "a 20-minute case on a complaint escalation"; "The panel is also the values round — they score against the four values" |

Interviewer names have not been assigned yet, so this pack has no interviewer read. Persona weights below come from the roles the recruiter named.

---

## How to use this pack

- **Personas** describe *how* a question arrives (friendly aside, quiet probe, time-boxed challenge). **Types** describe *what is being scored*. Rehearse both.
- **Type key:**
  - **VAL** — behaviour against Ashgrove's four published values
  - **EXP** — whether what you've said about your own work survives follow-up
  - **JD** — can you do the listed job, gaps included
  - **CO** — Ashgrove's strategy and where it's heading
  - **CASE** — a live problem from the role, reasoned out loud
- **Provenance labels:** `[grounded]` = traceable to something you or the recruiter supplied; `[inferred]` = this pack's derivation, named; `[generic]` = a role-family pattern, with no claim about you or Ashgrove.
- **Answer slots** are places where a strong answer would need a detail your material doesn't give. Each slot has two honest branches. Answer whichever one is true, in your own words. Neither branch is the wrong one.
- Guidance is scaffolding, not a script. Each answer should take 90–120 seconds to say aloud.
- **Highest-ROI prep in this pack: C1** (Round 2). It covers the jump from one branch's complaints log to owning complaints across branches *and* the contact centre. Some version of it will come up in every round. L2 is the same objection in a sharper form.

---

## Fit snapshot

Your evidence is the four sentences from your message. Everything this pack says about your past draws on these quotes and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branch side) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on the stages a complaint goes through likely. If any stage of how complaints moved through your branch was yours to set or change, say which and how, in your own words. If none was, say so plainly and stay with the log you handled |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact-centre side) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this gap yourself, and no wording closes it. Words: "I haven't worked in a contact centre." Then say how you would learn it, as a plan and never as something you've done. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | A monthly complaints spreadsheet you built touches this requirement. Your material doesn't say whether it tracks volumes or resolution times, so the words stay at the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet tracks. If it tracks either, say which, in your own words. If it tracks other things, say what they are. Never describe a measure it doesn't hold |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on an escalation script you call "our" script. It says nothing about coaching supervisors or writing the script. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you train people likely. If any part of how that training ran was yours to shape, say which part and how. If you followed a set format, say so plainly and describe the training as you gave it. Coaching supervisors is then a plan, said as a plan |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show any work with digital teams or on self-service. Answer slot: the JD names it, so expect a question. If you've worked with a digital or online-banking team, or on anything members use to serve themselves, say what it was and which part was yours. If you haven't, say so plainly, then say how you would put complaints data in front of a digital team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The quote meets the requirement in its own words. Say it in those terms: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer map that onto their requirement. Don't restate your history in the JD's vocabulary |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal complaints log" touches this requirement, but your material doesn't say whether the log ran under a regulator's rules. Answer slot: the JD says "regulated", so expect a probe on which rules applied. If the log worked to rules a regulator set, name them and say what they required of you, in your own words. If it didn't, or you don't know which rules applied, say so plainly and describe the log as you handled it |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this gap yourself. Words: "I haven't presented to anyone above regional level." Then say how you would prepare for it, as a plan. Don't claim confidence you can't back with something you've done |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material says "spreadsheet", not Excel. Answer slot: if you built it in Excel, say so, and describe what you built in it in your own words. If you used another tool, name it plainly |

### Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own the complaints process end to end across branches and the contact centre | F1, F2 | B1, C1, L2, J1 |
| Report monthly on complaint volumes and resolution times | F3 | A4, G1, E3 |
| Coach branch supervisors on escalations | F4 | C3, J2, K1 |
| Work with digital teams on self-service journeys | F5 | E1, E2 |
| 4+ years in financial-services customer operations | F6 | A1, B3 |
| Experience handling regulated complaints | F7 | C2 |
| Confident presenting to senior leaders | F8 | B2, C4, L2 |
| Comfortable with Excel reporting | F9 | A4, G2 |

---

## Graded deliverable — the 20-minute complaint-escalation case (Round 3)

The recruiter announced this, so expect it to be scored. The panel is also the values round, so expect your case to be read against the four values too.

**Grounded facts to build on**

| Fact | Where it comes from | Provenance |
|---|---|---|
| 20 minutes, a complaint escalation, run by two branch managers | Recruiter's email: "including a 20-minute case on a complaint escalation" | [grounded] |
| Scored against the four values | Recruiter's email: "they score against the four values" | [grounded] |
| Your own material, where it fits naturally | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | [grounded] |
| Your reporting, if the case reaches "what would you do with this afterwards" | F3: "I built the monthly complaints spreadsheet our regional manager uses." | [grounded] |

Say either quote only at its own scope, and only where it answers something the case asks.

**A structure for 20 minutes** `[generic]` — a pattern for the problem, not a fact about Ashgrove's process:

1. **Clarify (2–3 min).** What happened, to whom, and through which channel. What's already been done. Is there a deadline on the response? The JD says the complaints are regulated, so check before you assume.
2. **The member, now.** What does this member need today, and who tells them, in plain words?
3. **One owner.** Who holds the case until it's fixed, and how the branch knows that.
4. **The cause.** Is this a one-off, or a pattern? A branch problem, or one between channels?
5. **The supervisor.** What you'd say to the branch supervisor who escalated it: coaching, not blame.
6. **What it changes.** What goes into the monthly report, and what you'd raise with whom.
7. **Close.** The member's outcome, then the one thing that changes so it doesn't happen again.

**Thesis options (pick one to lead with)**

| Thesis | Mandatory concession | Value it speaks to | Provenance |
|---|---|---|---|
| T1 — One owner, start to finish: once the case reaches you, you keep hold of it until the member has an answer | Owning it doesn't mean doing every step yourself, and one owner can become the bottleneck. Say how you'd stop that happening | Own the Fix | [grounded] value text; [generic] reasoning |
| T2 — Fix the member's case before the process | If the same failure is hitting other members right now, the process fix can't wait behind one case. Say how you'd tell which situation you're in | Members First, Always | [grounded] value text; [generic] reasoning |
| T3 — Treat the escalation as information about the system, not as a failure by the branch | Some escalations are the right call and some reveal a coaching gap. Say which one this looks like before deciding | Neighbours, Not Numbers | [grounded] value text; [generic] reasoning |

**Differentiation.** The consensus answer is "apologise, investigate, resolve, follow up", and every prepared candidate will give it. `[generic]` Go further on three points:
- End on what changes in the monthly report and what you'd say to the supervisor.
- Write the member's reply out loud, in plain words. That's Plain Words, demonstrated rather than claimed.
- Name a value only where it decides something.

**The anti-pick: say what you would not do.** Don't promise the member an outcome before you know it's yours to give. Don't take a case off a branch without telling its manager. Both panellists are branch managers.

**Close.** The recruiter named no required close. End on the member's outcome, then the one change.

---

## Grounding brief — Ashgrove's strategy, in their terms

This comes from your four-line summary of the July 2026 strategy brief the recruiter sent you, not from the brief's full text. Use the figures exactly as you relayed them.

| What the brief says | Provenance | How it shows up in your interviews |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] strategy brief, July 2026 | Complaints will start in more places. The JD's "self-service journeys" line sits right on this (E1, E2) |
| Consolidate eight branches into five hubs over 2027 | [grounded] strategy brief, July 2026 | The Round 3 panel are branch managers. "Neighbours, Not Numbers" and consolidation pull against each other, so be honest about that rather than smoothing it over (H3, H5) |
| Launch a small-business lending product in Q1 2027 | [grounded] strategy brief, July 2026 | A new product brings new complaint types early in its life (J3) |
| Main competitive pressure is app-only banks | [grounded] strategy brief, July 2026 | The reason digital service matters. Member experience is where a credit union competes (A3, H5) |
| Values copied from ashgrovecu.org/about/values on 12 November 2026 | [grounded] values page, pasted | Learn the four names exactly: Members First, Always · Plain Words · Neighbours, Not Numbers · Own the Fix |

Don't present these as your own inside knowledge. Say "the strategy brief the recruiter shared" when you cite them.

---

# Round 1 — Recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers, the "walk me through" question, why Ashgrove | High: this is the default for a recruiter screen, and 30 minutes leaves room for little else | Have a pre-scripted 90-second arc built from your four sentences. Treat every casual question as scored |
| Skeptic (light) | Checks against the JD's requirements: contact centre, presenting, years | Medium: recruiters screen against the listed requirements, and F2 and F8 are the two you've stated you don't have | Give the plain acknowledgment once, calmly, then move to what your material does carry |

### Bank A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc made only of your sentences: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log, which you handled; training new tellers on your escalation script; the monthly complaints spreadsheet you built, which your regional manager uses. Answer slot: then say in your own words why you want to move into this role. If it's the complaints work itself, say that. Don't borrow the JD's phrasing for your history | The biography question is guaranteed. It's also the first place a history gets inflated, so F6, F1 and F3 are rehearsed at their own scope. EXP because it sets what you'll be held to later |
| A2 | "Why Ashgrove — and why a credit union?" | CO | [grounded] | Answer slot: if member ownership or one of the four values is genuinely your reason, name it by its exact title ("Neighbours, Not Numbers") and say why in your own words. If your reason is the role itself, say that plainly. Don't recite all four values | A standard recruiter check on motivation. CO because a good answer uses Ashgrove's own words |
| A3 | "What do you know about where we're heading?" | CO | [grounded] | Four points in plain words, credited to "the strategy brief you sent": 40% of service to digital by 2028; eight branches into five hubs over 2027; small-business lending in Q1 2027; app-only banks as the main pressure. Then one sentence of your own view on what that means for complaints, framed as your view | You have the brief and most candidates won't use it well. CO, and it sets up Rounds 2 and 3 |
| A4 | "Tell me about the complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the quote gives: you built it, it's monthly, and your regional manager uses it. Answer slot: the JD names volumes and resolution times, so if it tracks either, say which. If it tracks other things, say what. If it's in Excel, say so; if not, name the tool | F3 and F9 both rest on this sentence. The recruiter may check the Excel line literally. EXP because it's your own artefact |
| A5 | "How do you handle a member who's really upset?" | VAL | [generic] | Selection scaffold: pick one member conversation you actually had. It needs what they were upset about, what you did first, and how it ended. Say it in plain words. If no single conversation comes to mind, say so plainly, then describe how you approach it, framed as how you'd handle it | "Members First, Always" and "Plain Words" can be scored casually. VAL because the values are the scoring sheet in Round 3 |

### Bank B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre too. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment, once, without apologising: "I haven't worked in a contact centre." Then one line of plan, framed as a plan: how you'd learn how complaints arrive there in your first weeks. Then stop. Don't fill the silence with near-misses | F2 is a stated gap, and a recruiter may check it literally. JD because it scores a listed requirement |
| B2 | "How comfortable are you presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words. If you haven't, say so plainly. Then the plan: how you'd prepare for a first leadership report. Use the recruiter's own reverse question (R1-4) to learn what that reporting looks like | F8 is stated, and it's the other listed requirement a screen can catch. JD |
| B3 | "The role asks for four-plus years in financial-services customer operations. How does your experience fit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it in the quote's terms: "Six years in retail banking, the last three as a branch supervisor." Let them map it onto the requirement. Don't rename it "customer operations" | F6 needs only a clean statement. Restating your history in JD vocabulary is the one way to weaken it |

### Reverse questions — Round 1

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1-1 | "Is there anything in my background you'd want me to address before the next two rounds?" | Surfaces objections while you still have days to prepare for them | [generic] |
| R1-2 | "For the 20-minute case, will I get a written scenario on the day, or is it discussed live?" | The recruiter announced the case. Knowing its format is legitimate and changes how you prepare | [grounded] recruiter's email |
| R1-3 | "How does the panel score the four values — question by question, or across the whole conversation?" | The recruiter said the panel scores against the four values, and this tells you how to pace the hour | [grounded] recruiter's email |
| R1-4 | "Who receives the monthly complaints report, and what do they do with it?" | It turns the presenting gap (F8) into something specific you can prepare for in Round 2 | [grounded] JD |
| R1-5 | "Is this a new role, or is someone moving on?" | Tells you whether you'd inherit a process or build one, which reshapes how you answer C1 | [generic] |

---

# Round 2 — Head of Member Services, your future manager (45 minutes, "mostly behavioural")

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gap between one branch and an end-to-end remit | High: a hiring manager is buying capability and removing risk, and F1, F2 and F8 are the visible gaps | Rehearse C1 until it's boring. Each bridge comes only from your quotes, with the limit said plainly, plus a concrete plan for learning the rest |
| Values / Behavioural | "Tell me about a time…" questions | High: the recruiter said this round is "mostly behavioural" | Pick stories ahead of time using the scaffolds. "We" for context, "I" for your own part |
| Case / Strategist | Live problems on the manager's own agenda: digital shift, resolution times | Medium: it's the hiring-manager default, turned down because the recruiter said the round is behavioural | Clarify, then structure, then answer. Use Ashgrove's own words from the brief |
| Data-Driven Prober | Questions on the spreadsheet: what's in it and how it's counted | Low to medium: monthly reporting is in the JD, and F3 invites the probe | Know what you can and can't say about how it's built. Say plainly what you don't know |

### Bank C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role owns complaints end to end, across eight branches and the contact centre. Your experience is one branch. Why should I believe you can do it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI rehearsal in this pack.** Hold: "I handled the branch's formal complaints log, and I trained new tellers on our escalation script." Concede before they ask: "I haven't worked in a contact centre." Then the plan, framed as a plan: what you'd do first to learn how complaints reach the contact centre and move between it and the branches. Answer slot (F1): if any stage of how complaints moved through your branch was yours to set or change, say which and how. If none was, say so plainly and stay with the log. **Follow-up 1, "One branch's log isn't a process":** agree in one sentence ("That's right, it was one branch's log") and don't upgrade it. Then go back to the plan. **Follow-up 2, "What would you get wrong first?":** concede specifically: the contact-centre side is where you'd be learning. **Follow-up 3, "How long until you're useful?":** answer with the plan's first steps, not a promise. Never fold on the core fact that you handled the log | F1 and F2 are where the role's headline remit meets the biggest gap, so this objection will arrive in some form. JD because it scores the first listed responsibility. Skeptic delivery |
| C2 | "How did regulation shape the way you handled complaints?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the quote: the branch's formal complaints log, which you handled. Answer slot (F7): if the log worked to rules a regulator set, name them and say what they required of you, in your own words. If it didn't, or you don't know which rules applied, say so plainly and describe how you handled the log. Don't name rules you can't explain | F7 is low-confidence. This question's premise comes from the JD, and the guidance doesn't adopt it |
| C3 | "Coaching branch supervisors on escalations is part of this. What's the closest thing you've done, and how would you approach it?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Closest thing, at its own scope: "I trained new tellers on our escalation script." You can also say you've been a branch supervisor for the last three years. Let the interviewer draw the connection. Answer slot (F4): if any part of how that training ran was yours to shape, say which part and how. If you followed a set format, say so plainly. Then the approach, as a plan: how you'd coach a supervisor on one escalation | F4 is a transferable bridge with a clear limit. JD content, partly CASE delivery |
| C4 | "Presenting to senior leaders is part of this, and you haven't done that yet. What makes you confident?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I built the monthly complaints spreadsheet our regional manager uses." | Hold-then-concede. Concede plainly: "I haven't presented to anyone above regional level." Hold on what's true: "I built the monthly complaints spreadsheet our regional manager uses." Say it as building, not presenting. Then the plan: how you'd prepare your first report for leadership, and offer to walk them through how you'd lay it out. If you feel confident, say why in your own words. Don't claim confidence your history doesn't show | F8 is stated, and this manager owns the leadership reporting. Pressure-style hold, JD |

### Bank D — Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. The complaints log you handled is the natural place to look. Pick one complaint where you stayed with it after the first contact. It needs the problem, what you did after the first step, the point it was resolved, and anything you did so it didn't happen again. If no such case comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | This is "Own the Fix" asked in a behavioural round. The manager will want it before the panel does. VAL |
| D2 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold. It needs a named stake, the moment you said it, and how the relationship stood afterwards. Choose one where the message actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | The role reports complaint data upward, and bad news is part of that. VAL, on a Values/Behavioural stem |
| D3 | "Tell me about an escalation that went wrong." | EXP | [generic] | Selection scaffold. It needs what happened, which part was yours, and what changed afterwards. "We" for context, "I" for your own part. If no such time comes to mind, say so plainly, then describe how you'd handle one | Escalations are in the JD. EXP, because a failure story is where an interviewer checks what was really yours |

### Bank E — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We want 40% of member service in digital channels by 2028. What does that do to complaints, and what would you do about it?" | CO | [grounded] | Clarify first: which services move first, and what members complain about now. Then reason, as your view: complaints start arriving through new channels; some branch complaints fall away; members who don't want to go digital become a complaint source of their own. Then what you'd do: tag complaints by channel in the monthly report, and send the top digital themes to the digital team. Name one risk out loud, tied to "Members First, Always" | A CO question grounded in the published strategy. It's the differentiator most candidates won't have prepared |
| E2 | "A self-service journey is generating complaints. How would you work with the digital team on it?" | CASE | [generic] | Structure: what the complaints actually say; where in the journey members get stuck; what the digital team needs from you (themes and volumes, in plain words); how you'd check whether a fix worked. Answer slot (F5): if you've worked with a digital team before, say what you did and which part was yours. If you haven't, say so plainly and stay with the plan | F5 has no evidence, so the role's version of it gets rehearsed live. CASE |
| E3 | "Complaint resolution times have gone up 20% over two months. Diagnose it." | CASE | [generic] | Clarify how "resolution time" is counted before anything else. Then split it: by branch, by channel, by complaint type. Did the number of complaints change, or the time per complaint? Is anything in the timing, like a consolidation step? Then the fix, and what you'd report and to whom | Monthly reporting on resolution times is in the JD, so expect a diagnosis question. CASE |

### Bank G — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built: what goes in, and how is it counted?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The quote's beats: you built it, it's monthly, your regional manager uses it. Answer slot: say in your own words what it tracks, where its data comes from, and how a complaint gets counted. Name the part you'd defend least before they ask. If you don't know how a part is counted, say so plainly | F3 is the main reporting evidence, and a manager who owns reporting will probe it. EXP |
| G2 | "How comfortable are you in Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot (F9): if the spreadsheet is in Excel, say so, and describe in your own words what you built in it. If it's another tool, name it plainly. Don't list features you haven't used | It's a listed requirement, so it may be checked directly. JD |

### Reverse questions — Round 2

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R2-1 | "What would a good first six months in this role look like to you?" | Your future manager defines success, and you hear it in their words | [generic] |
| R2-2 | "Where do complaints most often get stuck today: in branches, in the contact centre, or between them?" | Invites their diagnosis and shows you're thinking end to end, which is C1's gap | [grounded] JD |
| R2-3 | "As eight branches become five hubs, how do you expect escalations from branch supervisors to change?" | Ties the role to the published strategy, and to the coaching part of the JD | [grounded] strategy brief |
| R2-4 | "Who sees the monthly complaints report, and what decision has it changed recently?" | Shows you think of reporting as decision support, and prepares you for the senior-presenting gap | [grounded] JD |
| R2-5 | "How does the contact centre's complaint handling connect to the branches today?" | Shows you'll learn the side you haven't worked in, rather than hiding it | [grounded] JD |
| R2-6 | "Which part of my background would you want me to build on first?" | Brings any remaining objection out while you're still in the room to answer it | [generic] |

---

# Round 3 — Panel of two branch managers (60 minutes, values round + 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One or more questions per value, scored | Dominant: the recruiter said "they score against the four values" | Use the values cheat sheet below. Choose a story for each value before the day |
| Case / Strategist | The 20-minute complaint-escalation case | High: announced by the recruiter. See the graded-deliverable section above | Clarify, then structure, then answer. Write out the member's reply in plain words |
| Peer Evaluator | "What would you bring my branch?" and where your role meets theirs | Medium: branch managers are the people whose supervisors you'd coach | Talk about what you'd bring their branch, not only what you'd need. Propose working principles rather than claiming to know the seam |
| Pressure | Time-boxed "why you" challenges | Low: a two-person panel can still push, especially on the gaps | Pause, restate, hold through two follow-ups, then concede what's real |

### Bank H — Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [generic] | Selection scaffold for "Members First, Always". It needs the member, the easier option you didn't take, what you chose, and how it turned out. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Every value gets a question in a values round. This one uses the value's own wording. VAL |
| H2 | "Tell me about a time you explained something so someone got it the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story mapped on F4: training new tellers on your escalation script, which are the beats the quote gives. Tell it in your own words. Answer slot: "Plain Words" says "if a member needs it explained twice, we wrote it wrong", so expect a probe on what you changed when someone didn't get it. If you changed how you explained something, say what. If you didn't, say so plainly and describe the training as you gave it | "Plain Words" has your closest quoted story. VAL |
| H3 | "Every branch is part of its town. When has that mattered in your work?" | VAL | [generic] | Selection scaffold for "Neighbours, Not Numbers". It needs a specific local connection and what it changed about what you did. If no such time comes to mind, say so plainly, then say how you'd keep it in mind. Two of the brief's moves are moving branches into hubs and service into digital, and this panel runs branches. Acknowledge that tension rather than smoothing it over | The value and the strategy pull against each other in front of the people it affects most. VAL |
| H4 | "Tell me about a problem you found that wasn't strictly yours, and what you did with it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for "Own the Fix" ("whoever finds the problem keeps hold of it until it is solved"). The log you handled is a place to look. It needs the problem, why it wasn't yours, what you did, and when it was solved. If no such time comes to mind, say so plainly, then give the nearest thing, or how you'd handle it. If you used D1's story with your manager, pick a different one here if you can | Own the Fix is the value closest to the job itself. VAL |
| H5 | "Members First, Always — so how do you square that with closing branches into hubs and pushing service digital?" | CO | [grounded] | Don't attack the strategy, and don't pretend it's painless. As your view: digital serves the members who want it; some members will lose a nearby branch; complaints data is one of the clearest ways to see who's being left behind; and how the change is explained to members is a Plain Words job. Credit the facts to the strategy brief | A branch-manager panel is the likeliest place for this tension to come up. CO, scored as values |

### Bank J — Case / Strategist (warm-ups for the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member has complained three times about the same issue: once in branch, once by phone, once in the app. Nobody has resolved it, and now it's landed with you. Walk us through it." | CASE | [generic] | Use the seven-step structure in the graded-deliverable section. Lead with one owner (T1). Write the member's reply out loud in plain words. End on what changes so the next member's complaint doesn't need three attempts | A cross-channel case sits on the JD's "end to end" line. CASE |
| J2 | "A branch supervisor escalated a complaint you think they should have resolved themselves. What do you do?" | CASE | [generic] | Fix the member's case first (T2). Then a coaching conversation with the supervisor: what they saw, what stopped them, what they'd do next time. Then whether the escalation rules themselves are unclear. Take care not to criticise a branch in front of branch managers | Coaching supervisors is in the JD, and the panel will picture their own supervisors. CASE |
| J3 | "Six weeks after the small-business lending launch, a business member complains about how their application was handled. How do you deal with it, and what do you do with what it tells you?" | CASE | [grounded] | Clarify: what went wrong, and was it one member or a pattern? Resolve the case, then send the theme to whoever owns the product, framed as early warning. Say plainly that a new product means new complaint types and you'd watch for them in the monthly report | Grounded in the Q1 2027 launch from the brief. CASE |

### Bank K — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "My supervisors already handle complaints. What would you bring my branch that we don't have?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I built the monthly complaints spreadsheet our regional manager uses." | Don't contest their premise. Offer what's true: you've been a branch supervisor for the last three years, and you built the monthly complaints spreadsheet your regional manager uses. Then what you'd bring, as a plan: a view across branches that no single branch has, and a coaching approach. End by asking what would actually help them | Reciprocity is what a branch manager is pricing. JD, with a Peer Evaluator's delivery |
| K2 | "If you and I disagree about whether my branch handled a complaint well, how does that go?" | VAL | [generic] | Selection scaffold: a disagreement with a peer or a manager where you held your view and the working relationship survived. If no such time comes to mind, say so plainly, then propose a principle: agree on the facts with the branch first, then the member outcome, then the fix, and never escalate around the manager | Tests "Own the Fix" against working relationships. VAL |

### Bank L — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you, and not one of our own branch supervisors?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | Pause, then 60 seconds made of your three sentences at their own scope: the years and the supervisor role; the complaints log and the teller training; the spreadsheet. Concede what's fair: someone internal would know Ashgrove's towns and systems better than you would on day one. Then one line on how you'd learn them | The standard pressure stem, and a panel of branch managers may well have someone internal in mind. JD |
| L2 | "You've never worked in a contact centre and you've never presented above regional level. That's two big pieces of this job. Convince us." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Don't argue with the premise. It's yours. "That's right: I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then hold on the branch-side work (C1's hold), and give the plan for each gap in one sentence. If they push twice, don't add claims. Repeat the plan and ask what they'd want to see in your first three months | C1's objection in its sharpest form. Hold-then-concede. JD |

### Values cheat sheet (Round 3)

| Value (official name) | Working meaning (paraphrased) | Your mapped story | Provenance |
|---|---|---|---|
| Members First, Always | Decisions start from what it's like to be the member | Selection scaffold: one decision where the member's view changed what you did. If none comes to mind, say so plainly and say how you'd apply it (H1) | [grounded] values page, pasted |
| Plain Words | If it needs explaining twice, the explanation was the problem | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Tell the teller training at its own scope, plus the answer slot in H2 | [grounded] values page, pasted |
| Neighbours, Not Numbers | Each branch belongs to its town, not to a spreadsheet | Selection scaffold: one local connection that changed what you did. If none comes to mind, say so plainly. Acknowledge that consolidation is the hard edge of this value (H3, H5) | [grounded] values page, pasted |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The log is a place to look for one complaint you kept hold of. If none comes to mind, say so plainly (D1, H4) | [grounded] values page, pasted |

### Reverse questions — Round 3

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R3-1 | "What would a new Member Experience Lead do in their first month that would genuinely help your branch?" | Reciprocity: it treats them as the people the role serves | [generic] |
| R3-2 | "When a complaint escalates out of your branch today, where does it go, and how do you hear how it ended?" | Shows you're thinking end to end from their side | [grounded] JD |
| R3-3 | "As branches become hubs in 2027, what do you most want protected for members?" | Engages "Neighbours, Not Numbers" and the consolidation tension honestly | [grounded] strategy brief; values page |
| R3-4 | "Which of the four values do you see tested hardest in complaints?" | Lets them tell you what they score on, in their words | [grounded] values page |
| R3-5 | "What would you want from me when one of your supervisors escalates something?" | A working-principles question about the seam between your role and theirs | [grounded] JD |

---

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the question banks were written. No guidance cell, slot, hold or story mapping in this pack asserts, softens or implies any of these claims.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process, or ran complaints across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says one branch's log, not a process across branches. C1's slot stays inside the branch |
| Contact-centre experience of any kind | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Coached supervisors, or wrote the escalation script | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: the material says tellers, and "our" script. The H2 and C3 slots ask only about how the teller training ran |
| Presented to senior leaders | A negative you stated, F8 | "I haven't presented to anyone above regional level." No slot |
| Reports complaints to regional leadership, or runs the region's complaints reporting | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material says your regional manager uses it, not that you present it or that it covers the region. The G1 slot asks only what it tracks |

---

## Sources

**Provided documents**
- Job description (pasted in your message)
- Ashgrove values text: you copied it on 12 November 2026 from ashgrovecu.org/about/values. It was pasted, not fetched
- The recruiter's email describing the three rounds (pasted)
- The July 2026 strategy brief, which the recruiter sent: used through your four-point summary of it in your message
- Your background (four sentences in your message)

No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted this morning fixes the cheat sheet and the VAL themes |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email sets out all three rounds, the case and the values scoring, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief is under six months old and supplies the priorities and competitive frame the CO and CASE questions use |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewers are assigned, so there was no query to form. The upgrade menu says what names would unlock |
| 5. Representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → a reading of each interviewer's public professional profile, persona weights for each panel member, and a reverse question tied to each person's own career path
- **Your answers to the answer slots, told outside a drill** (what the spreadsheet tracks and whether it's in Excel; whether the complaints log ran under a regulator's rules; any work with a digital team; how the teller training ran) → rows F3, F4, F5, F7 and F9 regraded, and the matching questions (A4, C2, C3, E2, G1, G2, H2) rewritten as story maps instead of slots
- **A specific complaint you kept hold of, a member-side decision, or a local connection, told outside a drill** → the scaffolds in D1, H1, H3 and H4 and the values cheat sheet become mapped stories
- **Your CV** → any further roles, figures or responsibilities on it enter the fit snapshot, and a figure gets a defend-the-number question
- **The strategy brief's full text, rather than the four-point summary** → a fuller grounding brief in Ashgrove's own vocabulary, and sharper CO and CASE questions
- **How much prep time you have before 21 November** → a prioritised prep schedule sized to it
- **A deeper research pass (L2: up to 6 more searches and 2 more fetches, several more minutes)** → recent Ashgrove news on the consolidation (which towns, what timing), candidate reports on how Ashgrove interviews, and any leadership changes that shape what this role is for. Offered once
- **A tuesday-dossier.md from a job-underwriter session** → the highest-ROI objection derived from evidence you confirmed rather than inferred here, binding strategies for each weak area, and an underwriter-checked prohibited-claims list
