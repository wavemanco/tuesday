Reading the skill's reference files so the prep pack follows its rules. Next I'll run a few targeted searches on Quartzline and write the pack.
I'm making one last cleanup in the pack (renaming the reverse-question IDs so they don't clash with requirement IDs), then I'll present it.
Your prep pack is saved as `Quartzline_product-manager-platform-apis_interview_pack.md`. It covers your 45-minute hiring-manager conversation and is built from your dossier: the requirements, your three verified evidence lines, the objection it expects, and its prohibited claims.

- **Research didn't happen.** The web searches were refused, so nothing in the pack about Quartzline itself comes from research.
- **Where to start.** Prep the objection your dossier named first: you've never held the PM title or owned a roadmap (question A1). The pack gives you a script: concede it plainly, then describe your integration work without stretching it, then offer a 90-day plan for learning to own the roadmap.
- **If Thursday is today,** rehearse A1 out loud, then pick three reverse questions, starting with RQ1 and RQ2. Everything else is insurance.

Say the word and I'll play the skeptical hiring manager on A1 and give you feedback after.
I can also update your `tuesday-dossier.md` with the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview Prep Pack — Product Manager, Platform APIs at Quartzline

**Round:** Hiring manager, one 45-minute conversation, Thursday. Interviewer name not given.
**Built from:** your `tuesday-dossier.md` (v1.1, generated 2026-08-14). Web research was attempted and refused, so nothing here about Quartzline itself comes from research. See Sources.

---

## How to use this pack

Two separate things label each question:

- **Persona** = *how* it gets asked (the tone and style of the person asking).
- **Type** = *what* is being scored:
  - `VAL`: behavior and values. Do your past actions show the values they care about?
  - `EXP`: experience deep-dive. Does what you claim hold up, and which part was actually yours?
  - `JD`: the job description. Can you do the listed job, gaps included?
  - `CO`: company and strategy. Have you done your homework on where Quartzline is headed?
  - `CASE`: a live problem. How do you structure and reason through it on the spot?

Provenance labels: `[grounded]` = traceable to your dossier; `[inferred]` = this pack's own derivation, with the reasoning named; `[generic]` = a common pattern for this kind of role, with no claim about you or Quartzline.

**Guidance is scaffolding, not a script.** Every sentence about your past is quoted from your dossier. Where the pack doesn't know something, the guidance has an **answer slot**: two branches, and you answer whichever one is true.

**Highest-ROI prep in this pack: A1.** Your dossier already named this objection. Rehearse it out loud until it bores you.

---

## Fit snapshot

Your evidence comes from the dossier's `verified_candidate_evidence`. The code names E1 to E3 below are only shorthand:

- E1 = "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"
- E2 = "Wrote the internal integration playbook her team uses"
- E3 = "Ran quarterly roadmap-input sessions feeding client evidence to product"

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | Your dossier says this is a bridge: present it as adjacent work, never as PM experience. Words at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." The pack's observation: your material shows integration leadership and input to product, not product management. Answer slot: the "3+ years" line makes a question about duration likely. Give the span in your own words, and make it the span of the integration work, not of product management |
| F2 | Owning a roadmap and prioritization authority (R1 sub-claim) — dossier uncertain_or_weak_areas | none given | none | [grounded] | capability | The dossier records this as `acknowledge_gap`, which rules out a bridge. Words, sourced from `prohibited_claims`: "Having owned a product roadmap": "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as past experience (see A2). Don't use E3 to cover this gap |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | The pack's observation: your material describes integrations of the vendor's APIs, not shipping an API product. Words: "I took 30+ client integrations of the vendor's REST APIs end to end, through go-live." Answer slot: R2 makes a question about the APIs themselves likely. If any change to those APIs came out of your integration work, say what changed and which part was yours, in your own words. If none did, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | E1 is close to this requirement but doesn't show docs or schema work. Answer slot: if you worked from or wrote API docs or schemas on those integrations, say which and how, in your own words. If you didn't, say so plainly and stay with the integrations |
| F5 | "Stakeholder management across engineering, sales, customers" (the customers part) — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | presentation | Your clients are the customers in this requirement. Words: "I led 30+ client integrations end to end, from scoping through go-live." Say "clients," and let the interviewer map it to the requirement |
| F6 | "Stakeholder management across engineering, sales, customers" (the engineering and sales parts) — dossier role_profile R4 | none given | none | [grounded] | discovery | Your material says nothing about engineering or sales. Answer slot: if you worked with engineering or sales on the integrations, say who and how, in your own words. If you didn't, say so plainly and return to E1's client work |
| F7 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's strategy is `clarify`. None of the verified entries covers agile. Answer slot: if you've worked in an agile cadence, say how, in your own words. If you haven't, say so plainly. Either way, end with what you'd want to confirm about how Quartzline defines agile delivery |
| F8 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | The pack's observation: scoping and requirements for client integrations sit next to product discovery but aren't the same thing. Words: "On each integration I led the scoping and requirements with the client." Don't call it product discovery |
| F9 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Confirmed, but with little you can show, so expect a probe. Volunteer the limit before you're asked: the sentence says you fed client evidence to product. It doesn't say what product did with it. Answer slot: if any of that evidence changed what got built, say what and how you know. If you don't know, or nothing changed, say so plainly |
| F10 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | The pack's observation: integration requirements through UAT and go-live sit next to writing specs for product squads but aren't the same thing. Words: "I wrote requirements and led integrations through UAT and go-live." Answer slot: if engineers built against requirements you wrote, say how you worked with them, in your own words. If not, say so plainly |
| F11 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Your material doesn't mention metrics. Answer slot: if you tracked anything on the integrations (counts, timelines, usage), say what, in your own words. If you didn't, say so plainly and say what you would measure first (see B3) |

---

## Prohibited claims

This pack won't coach the claims below, and no answer in it implies them. The first four come from your dossier. The rest are stretched versions of your own sentences, built here.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | "I haven't held a product manager title." Then E1 and E3 at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area | "I haven't owned a product roadmap." Then a ramp plan, said as a plan. No answer slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." In case questions (B1), answer as a plan for this role, never as "when I did this before" |
| Owning a roadmap and prioritization authority | Dossier `acknowledge_gap` area | Same honest form as the two rows above. No bridge, no slot |
| Shipped an API or platform product | Stretched version of E1 (F3) | E1 at its own scope. The pack's observation: integrations of the vendor's APIs, not an API product. F3's slot stays inside the integrations |
| Shaped or influenced the product roadmap | Stretched version of E3 (F9) | E3 at its own scope: you fed client evidence to product. F9's slot asks only what happened to that evidence |
| Ran product discovery | Stretched version of E1 and E3 (F8, F9) | Each sentence at its own scope: scoping and requirements on integrations, and roadmap-input sessions |
| Wrote product specs for engineering squads | Stretched version of E1 (F10) | E1 at its own scope: "requirements" on client integrations |
| The playbook is used across the company | Stretched version of E2 | E2 at its own scope: your team uses it |

---

## Persona table

The loop comes from your own words: one 45-minute conversation with the hiring manager. Weights start from the usual pattern for a hiring-manager round and are then adjusted for the dossier's objection. Quartzline's own interview process couldn't be researched.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Asks about the missing PM title and the roadmap gap: "why you, why now" | **High.** Hiring managers usually probe gaps, and your dossier names a specific objection (A1) | Rehearse A1 until it's boring. Concede first, then the quotes at their own scope, then a ramp plan |
| Case / Strategist | Live problems from the role: squad priorities, discovery, adoption, specs | **High.** Hiring managers usually test whether you can do the job. Four of the role's responsibilities make natural cases | Clarify, then objective, then structure, then metrics, then risks. Think aloud. Never present a case answer as past experience |
| Data-Driven Prober | Digs into "30+" and into what was actually yours | **Medium.** E1 has a number in it, and numbers attract probes | Know what you can say about how "30+" was counted, and say plainly where you don't know |
| Conversational | A casual opener, "walk me through your background," a friendly "why us" | **Medium.** Most 45-minute conversations open this way, and casual questions are still scored | A 90-second arc built only from E1 to E3 |
| Pressure | A time-boxed version of the objection, "how much was actually you" | **Low to medium.** Nothing points to a stress-style interviewer, but the objection can arrive sharply | Pause, restate the question, hold through two follow-ups, concede only what's real |
| Peer Evaluator | How you'd work with the two squad leads, sales, and partners | **Low to medium.** The dossier flags the squad-lead relationship as unknown | Talk about working principles, not a pretended seam. Show what you'd bring the squads |
| Values / Behavioral | One "tell me about a time" story | **Low.** No values round was identified, and Quartzline's values couldn't be fetched | Have a selection scaffold ready |

---

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Ran quarterly roadmap-input sessions feeding client evidence to product" | **Highest-ROI prep, and the objection your dossier named.** (1) Concede first, plainly. Sourced from `prohibited_claims`: "Having held a product manager title or role" and "Having owned a product roadmap": "That's right: I haven't held the PM title, and I haven't owned a roadmap." (2) Your adjacent work, at its own scope: "I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live. And I ran quarterly roadmap-input sessions feeding client evidence to product." Don't add "which is basically PM work." Let them draw the inference. (3) Volunteer E3's limit: you fed the evidence in. Answer slot: if any of it changed what got built, say what and how you know. If you don't know, say so. (4) Close with the ramp plan from A2, as a plan. **Follow-up 1**, "but a PM has made the tradeoff calls": hold on E1, concede "I haven't made those calls as the owner," then the plan. **Follow-up 2**, "so why not hire them?": don't argue against the other candidate. Return to what you did and stop | Your dossier names this as the likely objection, and it targets F1 and F2, the biggest gaps. JD because it scores the must-have R1. Every negative in the question is sourced from `prohibited_claims`, so it can be rehearsed exactly as written |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] | Name the real one. Sourced from the `acknowledge_gap` area and from `prohibited_claims`: "Having owned a product roadmap": "Owning the roadmap. I haven't owned one, and I haven't set prioritization for an engineering squad." Then the ramp plan, as a plan: first month, learn the current roadmap and which decisions are yours versus the squad leads'. Second month, run a discovery round with partners and agree on an adoption baseline. Third month, bring a prioritized roadmap proposal with its reasoning to your manager for review. Don't pick a fake weakness | The Skeptic stem aimed at F2. A rehearsed, specific answer turns the gap into a show of self-awareness. JD because it scores the role's core responsibility |
| A3 | "We need someone who's shipped API or platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | "I've taken 30+ client integrations of the vendor's REST APIs end to end, through go-live." Answer slot: if any change to the APIs themselves came out of that work, say what changed and which part was yours, in your own words. If none did, say so plainly and stay with the integrations. Never call the integrations "API products" | R2 is a must-have and F3 is adjacent, so this is the second-likeliest gap question. JD because it quotes the requirement |
| A4 | "Why move into product management now?" | JD | [generic] | The pack has no sentence of yours on motivation, so here is how to choose your answer. It should be specific, point forward, and connect to the role's "Own the roadmap for the partner-facing API platform." Give your real reason in your own words. If you can't put it in one sentence yet, work on that before Thursday. Don't frame it as escaping your current job | Hiring managers usually ask "why now" when a candidate is changing roles. JD because the answer is tested against the role's ownership line |
| A5 | "Have you worked in an agile product org?" | JD | [grounded] | The dossier's strategy is `clarify`. Answer slot: if you've worked in sprints or another agile cadence, say how, in your own words. If you haven't, say so plainly. Then: "What I'd want to confirm is how you run delivery here: the cadence, who owns the backlog, and how the two squads plan together" | R5 is preferred, and F7 has no evidence either way. A question back to them is the honest form. JD because it scores a stated requirement |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're 90 days in and the two squad leads want conflicting things next quarter. How do you decide?" | CASE | [generic] | Clarify first: which decisions are the PM's and which are the squad leads'. That's also reverse question RQ1. Then: what partner outcome are we optimizing for? Put both options against the same criteria (partner impact, adoption effect, cost, risk). Make the tradeoff visible to both leads. Decide or escalate according to the decision rights. Write down the reasoning. Answer as a plan for this role only. Don't start with "when I prioritized before" | The "drive delivery with two engineering squads" line, plus the dossier's open question about decision authority. CASE because it's a live problem with nothing presupposed about your past |
| B2 | "How would you run discovery with our integration partners in your first quarter?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Plan: pick partners across segments, interview on what blocks them from integrating and going to production, review support tickets and docs feedback, and turn it into ranked problems with evidence. You may open with one line at its own scope: "On each integration I led the scoping and requirements with the client." Don't call that discovery | A core responsibility, and F8 gives you a scoped opening line. CASE because the plan is the scored part |
| B3 | "How would you define adoption for a partner-facing API, and what would you measure first?" | CASE | [generic] | Clarify: what's measured today, and what's the baseline? (The dossier says no baseline is stated.) A funnel: partner signs up or gets keys, then first successful call, then production traffic, then sustained or growing usage. Split by partner segment. Separate leading signals (time to first call) from lagging ones (production volume). Name the weakest assumption out loud, for example that call volume reflects value. Make no claim about having tracked metrics before (F11) | The "define and track adoption metrics" line, plus the dossier's open question about the baseline. The structure is a common pattern, not Quartzline's practice |
| B4 | "Partner API adoption dropped 20% last quarter. Diagnose it." | CASE | [generic] | Check the metric first: did the definition or instrumentation change? Then split it: which partners, which endpoints, new versus existing. Line the timeline up against releases, deprecations, doc changes and pricing changes. Then talk to two or three affected partners. Form one hypothesis, test it, and say what would disprove it | The Case persona's diagnosis question, set in this role. The 20% is the interviewer's hypothetical, not a Quartzline figure |
| B5 | "Sketch the outline of a spec for a new partner-facing endpoint." | CASE | [generic] | Problem and evidence. Target partners. Success metric. API surface: resources, request and response schema, auth, errors, versioning, rate limits. Docs and samples. Rollout and deprecation plan. Open questions for the squad. This also tests R3 live | The "write specs" line and R3 technical fluency, tested without needing a claim about your past |

*No CO question: Quartzline's strategy couldn't be researched, so any such question would be generic. See the upgrade menu.*

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 30+ integrations. What was yours, end to end?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The points the sentence gives you: you led them, there were 30+, end to end, through scoping, requirements, architecture, UAT and go-live. Tell it in your own words. Answer slots for the number: how "30+" was counted, which part of each integration was yours, and the assumption behind the count you'd defend least. Say each in your own words, and if you don't know how it was counted, say so. Keep "30+" attached to integrations | Your headline number, and the most likely target for a prober. EXP because it tests attribution |
| C2 | "When you start a new integration, how do you work with the API docs and schemas?" | EXP | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: R3 makes this probe likely. If you worked from or wrote docs or schemas on those integrations, say which and what you checked, in your own words. If you didn't, say so plainly and stay with the integrations. Then offer to reason through a spec live, as in B5 | F4 is a discovery gap. `[inferred]` because the link from integrations to schema fluency is this pack's derivation |
| C3 | "Tell me about the playbook. What's in it, and how do you know the team uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Points from the sentence: you wrote it, it's internal, your team uses it. Answer slot: what's in it, in your own words, and how you know it's used. If you have no measure of that, say so. Check whether it's shareable before offering to show it. Don't widen "your team" to "the company" | E2 is your one inspectable artifact. EXP because a prober will test how far it actually reached |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Wrote the internal integration playbook her team uses" "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from these three sentences: the integrations, the playbook, the roadmap-input sessions. Then one line on why this role, from A4. Answer slot: if you mention tenure, give it in your own words. Don't add titles or scope the sentences don't carry | The most likely opener. It sets the frame for A1, so it should preview the adjacent framing honestly |
| D2 | "What did you learn from running those roadmap-input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Confirmed, but with little you can show. Volunteer the limit: you fed client evidence to product. Answer slot: what you heard, and what happened to it afterwards. If you don't know what product did with it, say so plainly | F9 is medium confidence, and a casual question is where the stretched "I influenced the roadmap" slips out |
| D3 | "What drew you to Quartzline?" | CO | [generic] | The pack couldn't research Quartzline. Name something specific you've read yourself about its partner API platform, and connect it to the role's ownership line. If you haven't read anything yet, do it before Thursday rather than improvising | A common rapport question that's still scored. `[generic]` because no research ran |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Ran quarterly roadmap-input sessions feeding client evidence to product" | A1 compressed. One-line concession, sourced from `prohibited_claims`: "Having held a product manager title or role": "I haven't held the title." Then the two sentences at their own scope, and one forward-looking line from the ramp plan. Pause before you start. Don't disparage the other candidate | The same objection as A1, time-boxed. Rehearsing both versions means the delivery style can't throw you |
| E2 | "Those 30+ integrations: how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold on the verb in your sentence: you led them. Answer slot: who else was involved and what was theirs, in your own words. Never upgrade "led" to "built" or "engineered." Hold through two follow-ups, then concede specifically what wasn't yours | The Pressure stem aimed at your headline claim. EXP because it tests attribution |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "The squad leads here have strong views. How would you work with them?" | JD | [generic] | Principles: agree on decision rights early, bring evidence rather than opinions, make tradeoffs visible, protect their focus. Answer slot: if you worked with engineering teams on the integrations, say how, in your own words. If you didn't, say so plainly and stay with the plan | R4's engineering part (F6) and the dossier's open question about squad authority |
| F2 | "Sales promises a partner something that isn't on the roadmap. What do you do?" | CASE | [generic] | Find out what the partner actually needs. Check it against the evidence and the roadmap. Give sales a clear yes, no or not-yet, with the reason. Close the loop with the partner. Agree on how future commitments get made | R4's sales part (F6), asked as a live problem with nothing presupposed about your past |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unwelcome message to a client." | VAL | [generic] | Choosing your story: it needs a named stake, a moment where you didn't fold, and an intact relationship at the end, and you should be clear about which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values stem, set in R4's customer part. No values round was identified and no values page was fetched, so this is a scaffold |
| G2 | "When did you put a client ahead of an internal deadline or metric?" | VAL | [generic] | Choosing your story: a real tradeoff, what you chose and why, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values stem. Partner-facing roles test this tradeoff |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A2, E1 |
| R2: Shipped API or platform products | A3 |
| R3: Technical fluency: API docs, schemas | C2, B5 |
| R4: Stakeholder management across engineering, sales, customers | F1, F2, G1 |
| R5: Agile delivery experience | A5 |
| Own the roadmap for the partner-facing API platform | A1, A2, B1 |
| Run discovery with integration partners | B2, D2 |
| Write specs and drive delivery with two engineering squads | B5, B1 |
| Define and track adoption metrics | B3, B4 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From your dossier. Your conditional go depends on the answer: if the squad leads hold the real authority, the role is narrower than the job description says |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | From your dossier. The job description asks you to own adoption metrics without stating a baseline. The answer tells you whether you'd inherit a metric or have to build one |
| RQ3 | "What would make the first six months a clear success in your eyes?" | Gets the hiring manager's real success criteria, and lets you check your ramp plan (A2) against them |
| RQ4 | "How does partner feedback reach the roadmap today?" | Right next to E3, so it's a natural place for you to have a view. It also shows you where discovery actually sits |
| RQ5 | "Where do partner integrations get stuck today, if anywhere?" | It's a diligence question, and the answer tells you which problem you'd start on |
| RQ6 | "What's the biggest decision on the API roadmap in the next two quarters?" | Shows you're thinking in roadmap terms without claiming you've owned one |

---

## Sources

- **Provided:** `tuesday-dossier.md` (envelope v1.1, generated 2026-08-14). Sections used: `role_profile` (in place of the job description: requirements, responsibilities, unknowns), `handoff_to_mock_interview` (verified evidence, weak areas and their strategies, the objection, risks, employer questions, prohibited claims), and `decision` (context only). Not present: `evidence_map`, `evidence_state`, `risk_register`.
- **Searches sent:**
  - "Quartzline company values": refused (permission not granted)
  - "Quartzline interview process product manager": refused (permission not granted)
  - "Quartzline partner API platform news 2026": refused (permission not granted)
- **Fetches:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The call was refused. Would have given G1 and G2 Quartzline's own value themes. No values round was identified, so there is no values cheat sheet either way |
| 2. `Quartzline interview process product manager` | unavailable | The call was refused. Your own words set up this session, so the persona weights don't depend on it. Would have shown what comes after this round |
| 3. `Quartzline strategy` / recent news | unavailable | The call was refused. Would have moved D3, a CO question, and Quartzline-specific framing for B3 and B4 |
| 4. `interviewer name Quartzline` | n/a | No name given, so there was no query to run |
| 5. Representative job description for the role | skipped | Your dossier's `role_profile` supplies the requirements and responsibilities |

---

## Upgrade menu

- **Allow web search** → research targets 1 to 3 run. D3 and a new CO question get grounded in Quartzline's current platform, and G1 and G2 get its published values
- **Deeper research pass**, if search is allowed: up to 6 more searches and 2 more fetches, several more minutes → a Quartzline strategy brief and context on the org and the role
- **The hiring manager's name** → a section on reading the interviewer, persona weights based on their public profile, and a reverse question tied to their career path
- **The current job posting text** → a check that `role_profile`, written 2026-08-14, still matches. Any changed lines would update the fit snapshot rows and the JD-tagged questions
- **The recruiter's prep note** → any stated focus areas or expected deliverables get their own sections
- **How long you've done integration work, in your own words** → F1 and D1 can include it. The dossier's summary mentions years, but no verified entry does, so the pack doesn't use it
- **Your answers to the answer slots in F4, F6, F7, F9 and F11** → those rows move from discovery to quoted evidence, and A5, C2, D2, F1 and B3 become story-based
- **Your raw CV** → more evidence rows beyond the three verified sentences
- **Whether the playbook can be shared** → C3 can include an offer to walk through it
