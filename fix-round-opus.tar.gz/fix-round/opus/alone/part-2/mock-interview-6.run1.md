Reading the skill's evidence rules, then running research and building the three-round pack.
I've built one prep pack covering all three rounds: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-6-denied-2b411fa8/larkfield_engineering-manager_interview_pack.md`

It's based only on the role text and background in your message. My three web searches on Larkfield (values, interview process, recent news) were blocked, so the pack has no company research. That means there's no cheat sheet of Larkfield's published values for Monday, and the "why Larkfield" questions are written generically.

- **What's shared:** one table matching each line of the role text to what you told me, with the gaps marked. You have two stated gaps, managing managers and a hardware-adjacent roadmap. Three things your message doesn't show yet: owning delivery, growing engineers, and device or IoT exposure.
- **Each round** has its own question bank (8–10 questions), the interviewer styles to expect, and five questions for you to ask them:
  - **Tuesday (Director):** questions about why you're ready, plus live problems like prioritising across two squads or a firmware slip.
  - **Thursday (panel):** the staff engineers digging into the 60% on-call drop and your hiring numbers, and the PM pushing on how you'd split roadmap decisions with them.
  - **Monday (VP):** questions on your leadership philosophy and values, plus fast pressure questions.
- **Most important thing to prepare:** B1, "You've led a team of six; this is two squads and eleven engineers — why are you ready?" Some form of it will likely come up in all three rounds.
- **What the pack won't help you claim:** three things you could easily overstate under pressure:
  - that the reliability quarter *caused* the 60% drop (you said it dropped *after*)
  - that you've led more than one team
  - that you personally ran all 40 interviews

  It also keeps "I haven't managed managers" and "I haven't owned a hardware-adjacent roadmap" as plain answers.

The pack ends with a list of what would improve it. The main items are the full JD, your CV, interviewer names, the recruiter's prep notes, and allowing web search.

If you like, I'll play the Director on B1 as a live practice round.
I can also save a `tuesday-dossier.md` recording the gaps this prep found, to carry into later sessions.
I can convert the pack to a Word document if you'd prefer.

Can you paste the full Larkfield job description and your CV? Either one would turn several of the "not shown yet" rows into specific stories; if not, I'll keep working from what you've given me.
Web search was blocked this session. If you allow it, should I run the standard research pass (values page, interview format, recent news)? That's what would make the Monday values cheat sheet possible.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager: three-round prep pack

**Candidate:** Yusuf · **Mode:** loop (three scheduled rounds, one shared fit snapshot)

| Round | When | Who | Relationship | Length |
|---|---|---|---|---|
| R1 | Tuesday | Director of Engineering | Hiring manager, your would-be boss | 45 min |
| R2 | The Thursday after | Two staff engineers + a product manager | Panel: technical peers and a cross-functional partner | 60 min |
| R3 | The following Monday | VP Engineering | Skip-level; the recruiter's framing is "values and leadership philosophy" | 30 min |

Interviewer names were not given, so there is no interviewer read. The loop structure comes from your message, not from research.

---

## How to use this pack

- **Personas** describe how a question is asked (the register, the pressure). **Types** describe what is being scored. Rehearse both.
- Type key:
  - **VAL** — values and behaviour: does your past behaviour show what they say they value
  - **EXP** — experience deep-dive: does what you've said survive scrutiny, and what was actually you
  - **JD** — role-driven: can you do the listed job, including its gaps
  - **CO** — company and strategy: homework depth, thinking at the company's altitude
  - **CASE** — live problem from the role: structure and reasoning, out loud
- **Provenance** on every row: `[grounded]` traces to your message or the role text, `[inferred]` is this pack's derivation (named), `[generic]` is a role-family pattern with no claim about you or Larkfield.
- **Answer slots** mark the places where the pack does not know what happened. They are instructions for the interview, not questions for you now. Each has two honest branches; either one is a good answer.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Highest-ROI prep in the whole pack: B1** (R1, Skeptic). It is the scale objection, and some version of it will come up in all three rounds.

---

## Fit snapshot (shared across all three rounds)

All evidence is from your message. All requirements are from the role text you quoted in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | One team of six is adjacent to two squads, and it does not reach them. The words stay at the quote's scope: "For three years I've been a team lead, of a team of six." Answer slot: the two-squads line makes a probe on running more than one team likely. If you have been accountable for parallel work across separate groups, say what it was and what part was yours, in your own words; if not, say so plainly and stay with the team of six |
| F2 | Leading through squad or tech leads, if Larkfield's two squads have them (plain prose: the role text does not say) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [inferred] | capability | Derived from "two squads": whether leads sit between you and the eleven engineers is unknown, so it goes to the Director as a reverse question (R1 reverse question 1). If it comes up, the words are yours: "I haven't managed managers." Then how you would approach it, said as a plan and never as a past |
| F3 | "own delivery" — role text, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote touches delivery (it is about what a quarter was spent on) without showing whether delivery was yours to own. Answer slot: the "own delivery" line makes a probe on how delivery is planned and tracked on your team likely. If that is yours, say how, in your own words; if it sits with someone else, or there is no such process, say so plainly and return to the reliability quarter you pushed through |
| F4 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role text, your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap in kind, but a self-report with nothing inspected behind it and a figure in it, so expect a probe. Lead in the quote's own terms: you run the hiring loop for backend roles, about 40 interviews last year. Keep "about 40 interviews" attached to the loop the way you said it; the pack does not read it as interviews you personally conducted |
| F5 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role text, your message | none given | none | [grounded] | discovery | Your material says nothing about growing engineers. Answer slot: the "growth" line makes a probe on developing people likely. If someone on your team got better at something because of what you did, say who (role, not name), what they needed and what you did, in your own words; if no such example comes to mind, say so plainly and say how you would approach growth for eleven |
| F6 | "partner with hardware and product on roadmap" (the hardware part) — role text, your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "partner with hardware and product on roadmap" (the product part) — role text, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote has roadmap pressure in it but does not say who applied it or how you worked with them. Answer slot: if product was on the other side of that pressure, say how the conversation went and what was agreed, in your own words; if the pressure came from elsewhere, or there was no such conversation, say so plainly and stay with what you pushed through |
| F8 | "building device-management services" (the domain) — role text, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | The quote places you at a payments company and says nothing about devices, fleets or IoT. Answer slot: the device-management line makes a probe on domain exposure likely. If any of your work has touched devices, firmware or fleets, say what, in your own words; if none has, say so plainly and stay with the work you have done |

### Requirement coverage

| Requirement | Rows | Covered by |
|---|---|---|
| Lead two squads | F1, F2 | B1, B4, H1, A3 |
| Building device-management services | F8 | B3, A2, F1, I1 |
| Own delivery | F3 | A4, A1, I2 |
| Own hiring | F4 | D3, G4 |
| Own growth for 11 engineers | F5 | C2, I2 |
| Partner with hardware on roadmap | F6 | B2, E3, A2 |
| Partner with product on roadmap | F7 | E2, A1, F2 |
| Your headline figure (60% on-call drop) | F3, F7 | D1, H2 |

---

## R1 — Tuesday: Director of Engineering (45 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Why are you ready for this?" asked quietly and returned to | High: a hiring manager is derisking gaps, and F1, F2 and F6 are the gaps this role presses on | Rehearse B1 until it is boring; bridges only from what you actually said; name the limit before it is asked for |
| Case / Strategist | Live problems from the role: prioritisation across squads, hardware slips, first 90 days | High: the hiring-manager prior, and a would-be boss wants to see how you'd run their teams | Clarify, then objective, options, metrics, risks; think aloud; challenge one premise per case |
| Conversational | Friendly opener, "walk me through your career" | Medium: almost every hiring-manager conversation opens this way, and it is still scored | Pre-scripted 90-second arc (C1) |

### Question bank — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've led a team of six. This is two squads and eleven engineers. What makes you ready for that jump?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI rehearsal in the pack.** Hold only what the quote carries: "For three years I've been a team lead, of a team of six." Name the limit yourself, before they do, in your own words: one team, not two. Answer slot (F1): if you have been accountable for parallel work across separate groups, say what it was and what part was yours; if not, say so plainly. The honest branch is a limit, not a confession. Then a plan, said as a plan: how you would spend the first months across two squads. Follow-up 1, "Have you managed managers?": "I haven't managed managers", then ask whether the squads have leads today. Follow-up 2, "So you'd be learning this on my team?": concede the specific thing you would be learning, and don't fold on the three years leading six. Never trade up to "I effectively ran two teams" | F1 and F2 are the largest structural gap, and the Director is buying exactly this scale. JD because it scores the two-squads line, Skeptic delivery. It returns as H1 in R3 |
| B2 | "Partnering with hardware on the roadmap is a big part of this job. Where does your experience there come from?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Say it first, plainly, without apology: "I haven't owned a hardware-adjacent roadmap." Then a plan, never a past: who you would sit with in month one, how you would learn the hardware team's calendar and constraints, what you would ask before committing a date. Don't reach for payments work as a stand-in for hardware experience | F6 is a gap you stated, and the role text names hardware partnership directly. A prepared, unhedged acknowledgment is stronger than a stretched bridge |
| B3 | "Why leave payments for industrial IoT, and what do you actually know about devices?" | CO | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | The reasons are yours, and the pack cannot supply them: what pulls you toward devices and this role, and what (if anything) pushes you from where you are, kept neutral. Answer slot (F8): if any of your work has touched devices, firmware or fleets, say what; if none has, say so plainly and say what you have done to learn the domain so far, or what you would do first | The "why leave, why here, why now" stem, plus F8's domain gap. CO because it scores homework; the "why Larkfield" half stays thin until research runs (upgrade menu) |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick a real one you have stated: the hardware-adjacent roadmap is the cleanest, because it is in your own words. Say it, then the ramp plan. Avoid a disguised strength; this interviewer will hear it | Persona stem aimed at F6 and F2; JD because the answer is scored against the role text |

### Question bank — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have one quarter of capacity across two squads. Product wants new device-management features; on-call load is climbing. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Clarify first: what is driving the on-call load, which product commitments are fixed, what hardware dates constrain the plan. Then objective, options (split, sequence, a reliability slice), how you would bring product and hardware into the decision, what you would measure, the risks. You may point to the one time your material shows this call, at its scope: you pushed a reliability quarter through against roadmap pressure, and the on-call burden dropped 60% after. Keep "after". Answer slot (F3): if planning and tracking delivery for that quarter was yours, say how; if not, say so and stay with what you pushed through | Prioritisation across squads is the core of the role. CASE because it is a live problem; anchored on the one story your material carries for it |
| A2 | "A firmware release your squad's launch depends on is slipping four weeks. Walk me through the next 48 hours." | CASE | [generic] | Structure it: what exactly depends on the firmware, what could ship without it, who needs to know and in what order (product, other teams, customers if any), the re-plan options, and how you keep the relationship with the hardware team intact. Ask clarifying questions about how devices and releases work here rather than asserting how they work. The question needs no claim about your past, so make none | Hardware partnership (F6) asked as a decision rather than a record, which is the fairest ground for a gap you have stated |
| A3 | "You inherit eleven engineers across two squads. What do you do in your first 90 days?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | A plan, not a past: one-to-ones with everyone, a map of delivery and on-call health per squad, the hardware and product calendar, open roles, one visible early improvement. Your material shows one piece you already do; say it at its scope: you run the hiring loop for backend roles. Don't claim to have done a 90-day plan at this scale | F1's scale gap rehearsed as a forward plan; CASE delivery |
| A4 | "How does delivery work on your team today, and which part of it is yours?" | JD | [inferred] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot (F3): if planning, tracking and unblocking delivery are yours, describe how you do it, in your own words; if they sit with someone else, or the process is informal, say so plainly and describe what you do own, with the reliability quarter as your one example at its scope | F3 is a low-confidence row: "own delivery" is in the role text and your material doesn't show it, so the honest answer needs rehearsing before the probe |

### Question bank — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your career so far." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc in your words: nine years in engineering, the last three as team lead of a team of six, currently at a payments company. Two things you want remembered: the hiring loop you run for backend roles (about 40 interviews last year) and the reliability quarter you pushed through against roadmap pressure, with the on-call drop that came after. End on why this role, in your own words. Nothing beyond those beats | Every opener is scored. EXP because the arc sets what the Director will probe next; keep it to what you can defend |
| C2 | "Tell me about someone on your team you helped grow." | JD | [generic] | Selection scaffold (F5): pick a time a specific person got better at something because of something you did. It needs a starting point, what you did, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach growth for eleven | "Growth for 11 engineers" is in the role text and F5 has no evidence, so the scaffold is all the pack can honestly give |

### R1 reverse questions

| Question | Why it lands |
|---|---|
| "Do the two squads have their own leads today, and how do you see this role working with them?" | Resolves F2 honestly, and shows you are thinking about structure, not just headcount |
| "Six months in, what would good delivery look like for these squads, in your eyes?" | Gets the Director's scoring sheet for "own delivery" (F3) directly from them |
| "How do hardware and software roadmaps get reconciled today, and where does it hurt?" | Turns your stated F6 gap into curiosity about their real problem |
| "What's the biggest people challenge across the eleven right now: hiring, growth, or something else?" | Ties to hiring and growth; tells you which of F4 and F5 matters most |
| "How do you like to work with the managers who report to you: cadence, autonomy, what you want escalated?" | You are interviewing your future boss too; this is the question they would expect a ready manager to ask |

---

## R2 — Thursday: panel, two staff engineers + a product manager (60 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Staff engineers digging into the 60% and the hiring figure, two levels deep | High: technical specialists probe, and both your figures are magnet targets | Know what you can and cannot say about how each figure was counted; say plainly when you don't know |
| Peer Evaluator | "Where's the line between your call and ours?" from staff engineers; "how do we settle it?" from the PM | High: the peer prior for the staff engineers, and the PM is a cross-functional partner on the roadmap seam the role text names, so I weighted partnership over pure values for them | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Case / Strategist | A technical or incident scenario on device-management services | Medium: staff engineers often test judgment live, and an incident is the natural ground | Clarify, structure, think aloud; ask rather than assert how their systems work |

### Question bank — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your on-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend-the-number slots, each in your own words: how the 60% was counted (pages, hours, incidents, something else), over what period it was measured, what it is sensitive to, and the assumption behind it you would defend least. Name that weakest assumption before they do. If you don't know how it was counted, say so plainly. What was yours, per your sentence: pushing the reliability quarter through. Your sentence says the drop came after; keep "after" | Your headline figure; staff engineers will press it. EXP because it tests attribution and counting, not the story |
| D2 | "What actually went into the reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The pack knows only the beats your sentence carries: a reliability quarter, pushed through by you, against roadmap pressure, with the on-call burden dropping 60% after. Everything beyond that is yours to say, and the pack supplies none of it. Which part was yours: say which parts of the work you did or decided and which the team did; if you weren't close to the technical detail, say so and say what you were close to | The natural follow-up to D1; staff engineers will want the substance. EXP, with the attribution slot the figure raises |
| D3 | "How do you run the hiring loop, and what does 'about 40 interviews' mean exactly?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Lead with the quote: you run the hiring loop for backend roles, about 40 interviews last year. Defend the figure: say how it was counted (yours personally, or the loop's total) in your own words. Answer slot (F4): the "own hiring" line makes a probe on how the loop is designed likely. If you set parts of it (what is assessed, how decisions are made), say which; if it was designed by others and you run it, say so plainly and stay with running it | F4 is your strongest row, and a figure invites the denominator question. JD primary because it scores the hiring requirement; EXP delivery |
| D4 | "How hands-on technically are you these days?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | In your own words; the nine years in engineering are in your sentence, and what you do now is yours to say. Selection scaffold: pick a recent technical decision you were part of and say what part was yours; if nothing recent comes to mind, say so plainly and say how you stay close to the technical work. Neither overclaim nor underclaim | Staff engineers price how much technical judgment the EM brings to their work. EXP because it tests what is actually you |

### Question bank — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | (Staff engineer) "Staff engineers here set technical direction. Where's the line between your call and ours, and what happens when we disagree?" | CASE | [generic] | Propose principles, don't pretend to know their seam: they own technical direction, you own priorities, people and delivery, and disagreement goes to data and a time-boxed decision. Then ask how it works here today. If you use a past disagreement, scaffold: one with a named stake, where you held or changed your view for a reason, and the relationship stayed intact; if none comes to mind, say so and stay with the principles | The seam the staff engineers care about most. CASE because it is a live working-agreement problem |
| E2 | (PM) "When I want features and you want reliability work, how do we settle it?" | JD | [inferred] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your one example, at its scope: you pushed a reliability quarter through against roadmap pressure, and on-call dropped 60% after. Answer slot (F7): if product was on the other side of that pressure, say how the conversation went and what was agreed; if not, say so plainly. Then reciprocity, as a plan: what you would give the PM (early warning, honest dates, data behind any reliability ask) | F7: product partnership is in the role text, and the PM will test whether "pushed through" means "pushed past them". JD because it scores the partnership line |
| E3 | (PM) "How would you work with hardware and me on a roadmap when hardware timelines move?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | "I haven't owned a hardware-adjacent roadmap." Then seam principles as a plan: shared calendar, agreed decision points, early signal when dates move. Then ask the PM how it works today; their answer is the real material | F6 again, now from the partner who would live with it. Practising it a second time in a different register is the point |
| E4 | "What would you need from us in your first month, and what would we get from you?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Reciprocity first. What you bring, at each quote's scope: you run a hiring loop for backend roles; you pushed a reliability quarter through. What you need: context on the services and devices, the hardware and product calendar, their view of the squads' pain points | A reciprocity question is near-certain from peers; CASE because it is a forward working plan |

### Question bank — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "A bad config push from our service takes a slice of devices offline. Run the incident, then the week after." | CASE | [generic] | Stabilise (stop the push, roll back), communicate (who, how often), then a blameless review and what changes. Ask the device-specific facts (how rollback works on devices, what "offline" means for the customer) rather than asserting them. The question needs no claim about your past, so make none | Device-management services (F8) asked as a live problem; staff engineers judge incident instincts directly |
| F2 | "If on-call turned out to be heavy on these squads, how would you make the case for reliability work here?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Clarify the data first; then the case you would make and to whom, including product and hardware. Your example at its scope, "after" intact. Then what you would do differently where hardware dates constrain the roadmap, said as a plan | Your strongest story moved into their context; F7's partnership gap is the follow-up to expect |

### R2 reverse questions

| Question | Why it lands |
|---|---|
| (Staff engineers) "What could a new EM do in the first month that would genuinely help your work?" | The reciprocity question; tells peers you are pricing what you add to their load |
| (Staff engineers) "Where's the line today between staff engineers' technical calls and the EM's?" | Shows you know the seam matters and that you'll learn theirs rather than impose one |
| (Staff engineers) "What does on-call look like for the device-management services today?" | Connects to the one story your material carries, without claiming you know their answer |
| (PM) "When product and engineering disagree on priorities here, how does it usually get settled?" | Shows the PM you expect disagreement and want a working process, not a turf line |
| (PM) "How early do you see hardware timeline changes, and how do they reach the software squads?" | Puts your stated F6 gap to work as curiosity about the PM's real problem |

---

## R3 — Monday: VP Engineering (30 min, "values and leadership philosophy")

Larkfield's published values are not in hand (research was blocked), so this round has no values cheat sheet and the VAL questions are themed from the recruiter's words. See the upgrade menu.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?", "tell me about a time…" | High: the recruiter named "values and leadership philosophy", which makes this a values-style round | Two or three principles you actually hold, each with one real example; "we" for context, "I" for contribution |
| Pressure | Time-boxed challenges in a 30-minute slot: "why you", "how much was actually you" | Medium: the skip-level prior, and 30 minutes leaves no room for long answers | Pause, restate, anchor in what you stated, hold through two follow-ups |
| Case / Strategist | Altitude questions: where the domain is heading, how you would measure success | Medium-low: the skip-level prior, tempered by the stated values focus | Think at the company's altitude; ask the VP's view rather than asserting Larkfield facts |

### Question bank — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What's your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | Two or three principles you actually hold, one sentence each; the principles are yours and the pack does not supply them. Tie each to something your material shows you did, at its scope: the reliability quarter you pushed through; the hiring loop you run. For a principle no example of yours carries, say it is something you believe and are still testing. Under two minutes | The recruiter's own framing makes this near-certain. VAL because it is scored on whether behaviour backs the philosophy |
| G2 | "Tell me about a time you pushed back on leadership or delivered an unpopular truth." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on your sentence: the reliability quarter, pushed through by you, against roadmap pressure, and the on-call drop that came after. Tell those beats in your own words. Whether it fits "leadership" depends on who the pressure came from, which only you know. If it doesn't fit, choose another time with a named stake, a moment you didn't fold, and an intact relationship at the end; if none comes to mind, say so plainly | Persona stem for a values round, and the one story your material carries for it |
| G3 | "Tell me about a time you got something wrong as a leader." | VAL | [generic] | Selection scaffold: a real mistake that was yours, what it cost, what you changed afterwards. Pick one where the change is visible. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | Leadership-philosophy rounds test self-awareness; the material holds no story for this, so the scaffold is the honest form |
| G4 | "How do you decide who to hire, and what would you never compromise on?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Anchor at the quote's scope: you run the hiring loop for backend roles, about 40 interviews last year. Your non-negotiables are yours to name; for each, say one thing in how you run the loop that reflects it, if one does. Where none does, say it is a principle you hold rather than one you have built in | F4 is your strongest evidence and hiring is in the role text, so expect values to be tested through it |

### Question bank — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Thirty seconds: why you over someone who's already run two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause, then anchor in what you stated: nine years in engineering, three as team lead of a team of six, the hiring loop you run. Hold that through two follow-ups. If pressed, concede specifically, "I haven't managed managers", and don't fold on the three years leading six. No adjectives you can't back | B1's objection at executive speed. JD because it scores readiness for the two-squads line; Pressure delivery |
| H2 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold what your sentence claims: you pushed the reliability quarter through, and the burden dropped 60% after. Concede the rest in your own words: say which part of the work was the team's. Don't upgrade "after" to "because of" under pressure | Pressure stem aimed at your headline figure; EXP because it tests attribution |

### Question bank — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Where do you think device management is heading in industrial IoT, and what would that mean for your squads?" | CO | [generic] | Without research, don't assert facts about Larkfield or its market. Reason out loud from what the role text says (two squads, device-management services, hardware partnership), name one or two forces you would watch, and turn it back to the VP's view | Executives test altitude. CO, honestly generic until research runs (upgrade menu) |
| I2 | "A year in, how would you know you'd done this job well?" | CASE | [generic] | A short scorecard tied to the role text: delivery the squads and partners can predict, on-call health, roles filled well, engineers growing, and hardware and product partners who trust your dates. A plan, not a past | Covers delivery (F3) and growth (F5) at VP altitude; CASE because it is forward reasoning |

### R3 reverse questions

| Question | Why it lands |
|---|---|
| "What separates the engineering managers who thrive here from the ones who struggle?" | Asks the VP for the values in practice, which you can't get from a values page |
| "What would you want this role to have changed a year from now?" | Shows you think in outcomes at their altitude |
| "How does engineering leadership handle the tension between hardware timelines and software delivery?" | Your F6 gap turned into the executive version of the question |
| "How much of the hiring bar is set centrally, and how much by each team?" | Connects to F4, your strongest area, and to how the VP runs the org |
| "Is there a value here you think is hardest to live by in practice?" | A values round invites it, and the answer tells you more than the values themselves |

---

## Prohibited claims

What this pack will not coach, in any round, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F2 | "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." No slot |
| Has led two teams, or eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says one team of six. B1's slot stays inside the work you were accountable for |
| The reliability quarter caused the 60% drop | Inflated form of F3 and F7 (logical form: "after" read as "because") | Your sentence as you said it: the on-call burden dropped 60% after you pushed the quarter through. D1 and H2 are where you say, in your own words, how the figure was counted |
| Personally conducted about 40 interviews | Inflated form of F4 (ambiguity resolved downward) | F4's quote as you said it: you run the hiring loop for backend roles, about 40 interviews last year |

---

## Sources

**Provided:** your message (the role text, the three-round schedule, your background).

**Searches sent:**

1. "Larkfield Systems industrial IoT values" — refused
2. "Larkfield Systems engineering manager interview process" — refused
3. "Larkfield Systems IoT news 2026" — refused

**Fetches:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Refused. Would have supplied a values cheat sheet for R3 and themed G1 to G4 on Larkfield's own published values |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Refused. The loop itself comes from your message, so persona weights stand; it would have added any documented format details (for example, whether the panel includes a design or case exercise) |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Refused. Would have grounded B3 and I1 in Larkfield's current priorities instead of `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role text in your message supplies the requirements the fit snapshot quotes; the real Larkfield JD (upgrade menu) would beat a representative one |

---

## Upgrade menu

- **The full Larkfield JD** → mid-list requirements become new fit-snapshot rows and JD-tagged questions, and the coverage table becomes complete
- **Your CV** → more sentences in the evidence column; F3, F5, F7 and F8 may move off `discovery` into story-mapped answers
- **Allowing web search (standard pass)** → R3 values cheat sheet from Larkfield's published values, B3 and I1 grounded in current strategy, and a check on loop format
- **Deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and a differentiator bank for R1 and R3
- **Interviewer names** → an interviewer read per round, per-member persona weights for the panel, and reverse questions tied to each person's path
- **The recruiter's prep notes** (focus areas, anything to prepare for the panel) → coverage of any pre-declared deliverable as its own build section
- **How much prep time you have before Tuesday** → a prioritised prep schedule across the three rounds
- **Your own answers to the answer slots in F1, F3, F5, F7 and F8, told outside a drill** → those rows become quoted evidence and B1, A4, C2, E2 and B3 become story-mapped
- **Whether "about 40 interviews" means interviews you conducted** → F4's quote can carry the larger reading in D3 and G4
- **A tuesday-dossier.md from job-underwriter** → an evidence-derived highest-ROI objection and an underwriter-built prohibited-claims list, in place of the ones this pack inferred
