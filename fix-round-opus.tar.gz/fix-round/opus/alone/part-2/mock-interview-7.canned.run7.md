I'm reading the prep-pack spec now. Next I'll run a few quick searches on Saltmarsh Games and Tobias Wrenfield, then build your pack.
Your prep pack is ready: 23 practice questions with answer guidance, a fit map of the JD against your background, and reverse questions to ask Tobias.

**What the research found (public sources):**
- **The interview format.** Saltmarsh's careers page says every loop has one 60-minute interview with the hiring manager, called the "Outage Hour". The first half is a tabletop exercise where you handle a simulated outage during a live event. The second half is a conversation about their values. There's no take-home. I built the pack assuming Tobias is that hiring manager, so the outage questions (bank A) carry the most weight.
- **Their three values:** Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. The third one is about leaving the release checklist better than you found it, which lines up with the checklist you wrote.
- **Tobias's background.** A search result lists a GDC 2026 talk by him called "Patch Notes Are a Promise", and says he used to be a QA lead. I didn't open the talk itself. That background is why the pack expects close questions on your release checklist.
- **A strategy change.** A news result says that from February 2027 both titles move to a season pass and share one events calendar. That sharpens your two biggest gaps: you've run one title's calendar, and you haven't worked with in-app purchases.

**The single most useful thing to practise is B1:** "Our events are monetised and run across two titles. You've run one title's calendar and never worked with in-app purchases. Why should I hand you this calendar?" The pack shows you how to stand firm on the two years of weekly calendar you did run, say the gap plainly before he presses, and give a ramp-up plan.

The pack has no answers for parts of your history you haven't told me about, like whether you planned the calendar or only ran it, or who calculated the retention numbers. In those places it gives you a "say whichever is true" prompt instead of a scripted answer. It also lists claims you shouldn't make (that you led a team, ran a calendar across several titles, or worked with in-app purchases) and how to say the true version of each.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-canned-335adbd7:
- SaltmarshGames_live-operations-producer_interview_pack.md

Say the word and I'll play Tobias as the skeptic on B1 and push back on your answers.
I can also save a tuesday-dossier.md recording the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Will Tobias be your manager, and did the recruiter tell you anything about the outage exercise or what to focus on? Either answer would change how the question sets are weighted.
Do you want me to dig deeper? That's up to 6 more searches and 2 more page reads, a few more minutes, mainly to read Tobias's talk and the season-pass announcement properly.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: SaltmarshGames_live-operations-producer_interview_pack.md -----
# Interview Prep Pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interview:** Friday, 60 minutes, with Tobias Wrenfield, Head of Live Operations
**Built for:** Saltmarsh's "Outage Hour". Its careers page describes it as one 60-minute interview with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation. This pack assumes Tobias is that hiring manager.

---

## How to use this pack

- **Personas** describe *how* a question gets asked (calm case, quiet skeptic, interruption under time pressure). **Types** describe *what* is being scored.
- **Type key:**
  - **VAL** — does your past behaviour show Saltmarsh's *published* values
  - **EXP** — do your own claims hold up when probed; what was actually you
  - **JD** — can you do the listed job, including its gaps
  - **CO** — do you know the company's current strategy and can you think at its level
  - **CASE** — live problem, scored on structure and reasoning
- **Provenance labels:** `[grounded]` = traceable to what you told me or to a source in Sources. `[inferred]` = a derivation, named. `[generic]` = a role-family pattern with no claim about Saltmarsh or you.
- **IDs:** fit-snapshot rows are F1–F8. The question banks use A, B, C, D, E, G and H. **F is skipped** so a bank ID can't be confused with a fit row.
- **The guidance is scaffolding, not a script.** Say it in your own words. Wherever a cell says *answer slot*, give whichever branch is true for you, including "that wasn't mine" or "that didn't exist".

---

## Prep triage

Your interview is tomorrow, so this is sized for one evening.

1. **B1 out loud, three times.** This is the highest-ROI prep in the pack. Time the hold and the concession.
2. **A1 → A2 → D1 as one chain.** This is the tabletop half of the hour. Rehearse the structure until it's automatic: clarify, stabilise, owners, comms, decision, review.
3. **C1, C2, C3.** Pick a real story for each value, or decide the honest "nothing comes to mind, here's how I'd handle it" for each. Do it tonight, not in the room.
4. **E1.** Before you go in, know what you can and can't say about how the monthly retention numbers were counted.
5. **Play Tidepool Tactics and Lantern Row** for 20 minutes each if you haven't already. Search results name them as the two titles moving to the shared calendar. G1, A3 and the reverse questions all get better if you have.
6. **Pick three reverse questions** (section 11). Make R1 or R2 one of them.

Everything else is insurance.

---

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes one title's weekly content drops. It doesn't describe live events across two titles, so the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Your material also doesn't say which platform the title was on. Answer slot: the JD's "plan and run" makes a probe on planning likely. If deciding what dropped when was yours, say how you decided, in your own words. If the schedule was set for you and your part was running it, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | Running a calendar may have meant working with these teams, but your material doesn't show it. Coordinating is not leading, so the "never led a team" sentence doesn't decide this row either way. Keep the two apart in the room. Answer slot: if running the calendar meant working with any of design, art, engineering or community, say which and how, in your own words. If it didn't, say so plainly and say how you would start |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers. It doesn't say you owned a post-event review or chose its KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "own" makes a probe on who produced the numbers likely. If you pulled them, calculated them or wrote the analysis, say which, in your own words. If someone else produced them and you presented them, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. There's nothing inspectable behind the sentence, though, so expect a probe, especially from an interviewer with a QA background (section 7). Lead with the quote's own terms: you wrote it, and QA still uses it. Answer slot: the JD's "manage" makes a probe on upkeep likely. If you kept the checklist updated after writing it, say how. If you didn't, say so plainly and stay with writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The four years were as an associate producer. Your material doesn't say whether the puzzle title was live-service for all four, and the weekly drops cover the last two. A years requirement isn't a gate; it's graded on fit like any other line. Answer slot: if the title was live-service for the whole four years, say how, in your own words. If it became live-service partway through, or the earlier years were other work, say so plainly and stay with the two years of weekly drops |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement in its own terms: retention numbers, monthly, presented to the studio head. Expect a Prober to go two levels deep on how they were counted (E1). F3's slot on who produced them applies here too |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist a team still uses is writing that held up, but it is one kind of writing. The role's post-event review is another, and your material doesn't mention that kind. Words: "I wrote the release checklist our QA team still uses." Answer slot (G2): if you've written other things people relied on, such as post-event write-ups, say what, in your own words. If not, say so plainly and stay with the checklist |
| F8 | Monetised events: both titles move to a season-pass model from February 2027 (Saltmarsh news, via search result; not a JD line) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You said this, so the pack can give it back to you: "I haven't worked on a game with in-app purchases." Follow it with how you would learn it, said as a plan and never as a past. Add nothing to make the gap feel smaller |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A3, A5, B1 |
| Coordinate design, art, engineering and community | A5, H1, H2, B2 |
| Own the post-event review and its KPIs | A4, E1, E2 |
| Manage the release checklist with QA | E3, D2, C3 |
| 3+ years producing live-service games or apps | B3, G1 |
| Experience running a content calendar | B1, A3 |
| Comfortable with player-retention metrics | E1, E2, A4 |
| Clear written communication | G2, D1 |

---

## 7. Reading the interviewer

Public professional footprint only. Everything here comes from one search result for a GDC 2026 talk listing. I did not fetch the talk itself.

| Signal | What it says | Provenance |
|---|---|---|
| Role | Head of Live Operations at Saltmarsh Games | [grounded] |
| Career pattern | Previously a QA lead at a console studio | [grounded] |
| Published talk | "Patch Notes Are a Promise" (GDC 2026). His argument, per the listing: a live team is judged by how often its patch notes describe what actually shipped | [grounded] |
| Echo in company values | Saltmarsh's value "Ship the Patch Not the Promise" makes the same point in different words | [grounded] |

**Practical implications**

1. **Precision beats polish with this interviewer.** His public thesis is about claims matching what shipped. An answer that claims more than you did fails his own test, so the hold-then-concede structure in B1 and D2 is the right register for him.
2. **Expect the checklist to get probed** (E3, D2). Someone from QA will want to know what's on it and what it catches.
3. **In the tabletop, don't promise times you don't have** (D1). That is the talk and the value at once.

**Mirror opportunity, a shared professional path:** he moved from QA into live ops. Your side of that seam is F4: "Wrote the release checklist our QA team still uses." That's the only quote that touches his path, so R2 is built on it.

---

## 8. Persona table

Weights start from the hiring-manager prior (Case/Strategist + Skeptic). The documented format (tabletop, then values) and his QA background adjust them.

| Persona | How it shows up in the Outage Hour | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | The tabletop: a simulated outage during a live event, worked through live | **Very high.** The careers page names a live-incident tabletop as the first half. 5 questions | Clarify, then stabilise, then owners, then comms, then decision, then review. Think out loud. Challenge one premise per case |
| Skeptic (B) | Quiet probes on one title vs two, no IAP, never led a team, associate-to-producer step | **High.** Hiring-manager prior, plus the F1, F2, F5 and F8 gaps. 4 questions | Rehearse B1 until it's boring. Bridges only from your quotes, with limits said plainly, plus a ramp plan |
| Values / Behavioral (C) | The second half: three published values | **High.** The careers page names a values conversation in this same hour. 4 questions | One story or one honest branch per value, chosen tonight. "We" for context, "I" for your part |
| Pressure (D) | Interruptions and time boxes inside the tabletop ("community wants an ETA now") | **Medium.** A simulated outage is time pressure by design. 3 questions | Pause, restate, hold through two follow-ups, then concede something real and specific |
| Data-Driven Prober (E) | "How was that retention number counted?" and "What's on your checklist?" | **Medium.** The QA-lead background and the patch-notes thesis both point to verification. 3 questions | Know what you can and can't say about how each number was counted, and say "I don't know" plainly where that's true |
| Conversational (G) | The opener and the chat between sections | **Low**, but scored. 2 questions | A 90-second arc made only from your own sentences |
| Peer-style collaboration (H) | "How do you get four disciplines to one date?" | **Low.** Not a peer round, but the JD's coordination line will come up. 2 questions | Propose working principles rather than claiming a history. Use reciprocity framing |

---

## 9. Question banks

### A — Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event on one title. Players are reporting that event rewards aren't granting, and support tickets are climbing. You're the producer on shift. Walk me through your first 30 minutes." | CASE | [grounded] | Structure it out loud. **Clarify:** which title, all players or a segment, since when, is anything else broken. **Stabilise:** what stops the damage now, e.g. pausing or extending the event timer. **Owners:** who in engineering reproduces it, who in QA confirms it, who in community talks to players. **Comms:** a holding message that says what you know and nothing you don't, plus when the next update comes. **Decision point:** what you need to know before choosing between a fix, an extension and compensation. **After:** what goes into the review. The question needs no claim about your past, so the guidance makes none | The careers page names a live-incident tabletop on a simulated outage during a live event. The scenario wording here is illustrative, not Saltmarsh's actual case. CASE because it scores structure under a live problem |
| A2 | "Engineering says the fix needs six hours plus store review. The event ends in four. Extend, end on time, or compensate?" | CASE | [generic] | Name the trade-off before choosing. Players who can't earn rewards vs the cost of moving the calendar (what's scheduled next on that title). Which choice is reversible. What you'd say to players. A defensible answer extends or compensates and says why. This is the value "Players Before Plans" applied live. Concede one real cost of your choice | The natural second follow-up to A1. It tests a decision under constraint rather than a process |
| A3 | "From February both titles share one events calendar under a season pass. How would you plan the first season?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Clarify:** season length, who owns pass pacing and rewards, how much the two titles' audiences overlap. **Principles:** avoid two peaks colliding, decide which beats are shared and which belong to one title, protect lead time for art and engineering, put QA checklist gates in the schedule. **Measures:** what the post-event review would read. **Concession, in your own words:** "I haven't worked on a game with in-app purchases, so I'd want the monetisation side's read on pass pacing." That says your gap plainly without making it the answer | A search result reports Project Larkspur: a season pass and one shared calendar for both titles from February 2027. This is the role's near future, which makes it the strongest CO question available. CO first, CASE delivery. The concession rests on F8 |
| A4 | "An event ended last week. Participants' retention looks up and revenue is flat. What's in the post-event review?" | CASE | [generic] | Structure: goal vs result, the KPIs and how each was measured, what went to plan, what didn't, what you'd change, and the decisions you need from leadership. The weakest-assumption move: players who join events may have been more engaged to begin with, so "participants retained better" doesn't show the event caused it. Say so before he does | Tests the JD's "own the post-event review" (F3's requirement) as a live problem rather than a record. That keeps it honest given F3's gap |
| A5 | "Art for an event on one title is a week late. The other title's update is on time. What moves, and who do you tell first?" | JD | [generic] | Clarify what is actually late and whether anything partial can ship. Options: move the event, ship a smaller version, swap in another calendar beat. Who decides, who needs to know, and in what order (art, engineering, QA, community). What changes in the release checklist. Pick one and name its cost | Hits two JD lines at once, two titles and coordinating teams. The F2 gap means a live problem is a safer place to show this than a past claim |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our events are monetised and run across two titles. You've run one title's calendar and you've never worked on a game with in-app purchases. Why should I hand you this calendar?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | **This is the highest-ROI rehearsal in the pack.** Hold on what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Then the plain acknowledgment, said before he presses: "I haven't worked on a game with in-app purchases." Then a ramp plan for the first weeks, said as a plan: what you'd read, who you'd sit with, which events you'd shadow before owning one. **Follow-up 1, "How fast can you learn monetisation?":** stay with the plan, and don't claim speed you haven't shown. **Follow-up 2, "Weekly drops aren't events":** answer slot. If the drops had event-like structure (timed, rewarded, announced), say how, in your own words. If they were content-only, say so plainly and stay with running a weekly calendar for two years. Concede the two-title and monetisation gaps exactly, and never fold on the calendar you did run | F1 and F8 together are the most predictable objection, and Project Larkspur makes them sharper. Skeptic delivery. JD because it scores the calendar requirement directly. The negative in the question is one you stated |
| B2 | "This role coordinates design, art, engineering and community. Have you led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't led a team." Then separate leading from coordinating, as an observation rather than a claim. Answer slot: if running the calendar meant working across any of those disciplines, say which and how, in your own words. If it didn't, say so plainly and describe how you'd set up working with them (see H2) | F2 is silent and the team negative is stated, so this rehearses saying the negative cleanly without letting it swallow the coordination question |
| B3 | "You're an associate producer. What makes you ready for producer?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Keep "associate producer" as the title. Don't round it up. The beats you can stand on are the calendar for two years and the checklist QA still uses. Answer slot: if any of that work was beyond what an associate producer did at your studio, say what and how you know, in your own words. If it wasn't, say so plainly and make the case on what you did, not on scope you didn't have | F5. A title step-up is a standard skeptic probe. EXP because it tests what was actually yours |
| B4 | "Why leave puzzle games, why Saltmarsh, and why now?" | JD | [generic] | Selection scaffold: three short reasons that are actually yours. One about the work (live events at a bigger scale), one about Saltmarsh specifically (the shared calendar, or a value you mean), one about timing. If you can't name a Saltmarsh-specific reason after playing the games, say what drew you to the role instead. Don't borrow one from this pack | Motivation consistency is the Skeptic's standard close. No quote covers your reasons, so the pack supplies none |

### C — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [generic] | Selection scaffold: a time a planned drop or date conflicted with what players needed or were saying. It needs the plan, the player signal, what you did and the outcome. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (running the weekly calendar), or how you would handle it, using A2 as your example | First of three published values, and the values conversation is in this hour. No quote carries a story here, so it's a scaffold |
| C2 | "Ship the Patch Not the Promise: tell me about a time you had to decide what to announce before it was built." | VAL | [generic] | Selection scaffold: a moment where something was planned but not finished, and what got said to players or leadership about it. It needs the pressure to announce, what you chose and what happened. If no such time comes to mind, say so plainly, then say how you'd handle it: announce what's built, and give a date only when you have one | Second published value, and the same theme as Tobias's GDC talk, so expect it to be pressed. Scaffold, because no quote carries a story |
| C3 | "Leave the Build Greener: you wrote a release checklist. What did it leave better?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and QA still uses it. Those are the beats the quote states, so tell them in your own words. Answer slot: the value asks whether each release leaves the checklist better than it found it. If there was a checklist before yours, or you've updated yours since, say what changed and why, in your own words. If there was nothing before and it hasn't changed, say so plainly and stay with what it is now | Your strongest values match, and F4 lines up with the value's own wording about the checklist. Premised only on the quote |
| C4 | "Tell me about a time you delivered numbers leadership didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot on F3/F6: if any month's retention numbers were bad news, say what you presented and how it went, in your own words. If none were, or you don't remember one, say so plainly, then pick another unwelcome-truth story if you have one. Otherwise say how you'd present bad numbers | A standard values stem that lines up with the post-event review the role reports. The quote gives the setting but not the story |

### D — Pressure (inside the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds. Community wants to post a fix ETA right now. Yes or no, and what does the post say?" | CASE | [generic] | Pause, then answer: no ETA you don't have. Say the post out loud in two lines: what's wrong, that you're on it, when the next update comes. Hold if he pushes ("players are angry"), because a missed ETA costs more trust than no ETA. Concede that silence costs something too, which is why the update time matters | The value "Ship the Patch Not the Promise" and his talk, applied to a live incident. It also covers the JD's written-communication line |
| D2 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold on the quote: you wrote it, and QA still uses it. Answer slot: if others contributed items or reviewed it, say who and what, in your own words. If it was yours alone, say so plainly. Hold through two follow-ups by returning to what you wrote, never by adding to it | F4 is your most direct match, so it will be tested. Pressure stem, EXP because it scores attribution |
| D3 | "Sixty seconds: why you over an internal candidate who already knows our titles?" | JD | [generic] | Three beats, timed. What you've done (the calendar and the checklist, in your quotes' words), what you'd bring from outside, and a plain concession that an internal candidate knows the titles, plus how you'd close that. Don't knock the internal candidate | Standard pressure stem. It tests composure and economy more than content |

### E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The monthly retention numbers you presented: which metric, and how was it counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slots, in your own words. Which retention metric it was. How it was counted. What it was sensitive to (a big content drop, a store feature, a holiday). The assumption behind it you'd defend least. Which part was yours: pulling, calculating or presenting. "I don't know how it was counted" is an honest branch if it's true. The pack supplies no method, so don't use one you can't explain twice | F6 and F3 are where a QA-minded interviewer will go two levels down. EXP because it tests attribution and understanding |
| E2 | "Did you ever look at what a content drop did to retention?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Answer slot: the JD's post-event review raises this. If you compared retention around drops, say how and what you saw, in your own words. If you didn't, or that analysis wasn't yours, say so plainly, then say how you'd set it up here (A4's weakest-assumption point applies) | Connects your two quotes the way the JD's review requirement does. The slot lets the link be absent |
| E3 | "Walk me through the release checklist. What's on it, and which item would you defend least?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: name the sections or items as they actually are, in your own words. Then name the item you'd defend least and why (the weakest-assumption move). If you can't remember it item by item, say so and describe its structure. Read it tonight if you can | His QA background makes this the likeliest deep probe on F4. EXP because it verifies the work behind the claim |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made only from these four sentences: associate producer for four years at a puzzle-game studio, the weekly calendar for the last two, the checklist QA still uses, presenting monthly retention to the studio head. Then one line on why this role, from B4. Nothing beyond what the sentences say | Every interview opens with this, and it's scored for economy. Your quotes make a clean arc without stretching |
| G2 | "What have you written at work that people actually used?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Lead with the checklist in the quote's terms. Answer slot: if you've written other things people relied on, such as post-event write-ups, say what, in your own words. If not, say so plainly and stay with the checklist | F7. Written communication is a JD requirement, and a casual question about it is still scored |

### H — Collaboration (cross-team)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Community wants an event moved because of player sentiment. Engineering says the date is locked. How do you settle it?" | CASE | [generic] | Clarify what each side is protecting. Separate what's actually fixed from what's habit. Propose the option that serves players without breaking the build ("Players Before Plans" without abandoning "Leave the Build Greener"). Say who decides if they can't agree, and how you'd write the decision up | A seam problem from the JD's coordination line, asked as a live problem because F2 is silent |
| H2 | "How do you get design, art, engineering and community to the same date when none of them report to you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Working principles, said as how you'd work rather than a history: one shared calendar everyone can see, early dependency check-ins, clear cut-off dates tied to the release checklist, and what each team gets from you. Answer slot: if you've done any of this in your current role, say what, in your own words. If not, say so plainly. Don't describe managing anyone, because "I haven't led a team" is the line here | F2's coordination requirement. Reciprocity framing (what you give each team) works better than authority you don't have |

---

## 10. Values cheat sheet

From Saltmarsh's published values page. You may get asked about them by name.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players conflict, the players win | Selection scaffold (C1): a time a planned date and player need conflicted, what you did and what happened. If none comes to mind, say so plainly and walk through how you'd handle it (A2) |
| Ship the Patch Not the Promise | Announce what's built, not what's hoped for | Selection scaffold (C2): a moment you chose what to say about unfinished work. If none comes to mind, say so plainly and say how you'd handle it (D1) |
| Leave the Build Greener | Every release leaves the code and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Use C3's answer slot for whether it improved on something earlier |

---

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How do you track that here?" | Tied to his own published work. It shows you researched *him*, and the answer tells you how the team is measured |
| R2 | "You moved from QA into live operations. What from the QA side do you most want a producer on your team to bring?" | Ties to his path and to F4. It invites a peer conversation about the seam you already work on |
| R3 | "With Project Larkspur combining the event teams into one live-ops group, how will this role split across the two titles, and what does success look like at six months?" | Shows you know the current strategy, and you genuinely need the answer |
| R4 | "Who owns season-pass pacing and rewards: live ops, or a separate monetisation team?" | Real diligence given F8. It tells you where you'd need to ramp, and it reads as planning rather than a weakness |
| R5 | "What does a post-event review look like today, and which number do you read first?" | The JD says you'd own it, and his answer tells you what he values |
| R6 | "Which event in the last year would you run differently, and why?" | Invites candour and gives you a real picture of the job |

---

## 13. Prohibited claims

What this pack will not coach, and why. Hold these lines under follow-up pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated | Plain acknowledgment: "I haven't led a team." No slot |
| Has worked on in-app purchases, season passes or monetised events | Negative you stated, F8 | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a ramp plan, said as a plan |
| Ran a live-events calendar across multiple titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material describes one title's weekly content drops. B1's slot stays inside those drops |
| Owned post-event reviews or set the KPIs | Inflated form of F3 | F3's quote at its own scope. E1's slot asks only who produced the numbers you presented |
| Four years of live-service producing, or the title "producer" | Inflated form of F5 | F5's quotes as they stand: four years as an associate producer, and the weekly drops for the last two |
| Managed the release process, or ran QA | Inflated form of F4 | F4's quote: you wrote the checklist QA still uses. The upkeep slot stays inside the checklist |

---

## 14. Sources

**Provided:** the JD text and your background, both pasted in your message.

**Searches sent:**

1. `Saltmarsh Games values` → https://saltmarshgames.com/values
2. `Saltmarsh Games interview process producer` → https://saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile studio news 2026` → https://saltmarshgames.com/news/project-larkspur (search result only, not fetched: Project Larkspur, September 2026. Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, and per-title event teams are replaced by a single live-ops group)
4. `Tobias Wrenfield Saltmarsh Games` → https://talks.gdconf.example/2026/patch-notes-are-a-promise (search result only, not fetched)

**Pages fetched:**

1. https://saltmarshgames.com/values → the three values and their definitions
2. https://saltmarshgames.com/careers/interviewing → the Outage Hour format

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet (section 10) and C1–C3, with the three values by official name |
| 2. `Saltmarsh Games interview process` | yes | Loop established: one 60-minute hiring-manager session, tabletop then values. Bank A leads, and a values round is detected |
| 3. `Saltmarsh Games` strategy / recent news | yes | Project Larkspur: A3, B1's framing, F8, R3, R4 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read (section 7), Prober weight, R1, R2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you pasted already covers the fit snapshot and the JD-tagged questions |

No dossier was provided, so this pack is built from your message and the research above.

---

## 15. Upgrade menu

- **Your answers to the answer slots** (planning the calendar, which teams you worked with, who produced the retention numbers, whether the title was live-service for all four years) → rows F1, F2, F3 and F5 and questions B1, B2, B3, E1 and H2 move from slots to mapped stories
- **The release checklist itself, a calendar snapshot or a retention deck you presented** (redacted is fine) → F4, F1 and F6 move from `medium` toward `high`, and E3 gets real items to rehearse
- **Your CV** → more sentences to map, which could turn the C1, C2, C4 and H2 scaffolds into stories
- **The recruiter's prep email, if there was one** → any stated focus areas or tabletop details reshape banks A and D
- **A tuesday-dossier.md from job-underwriter** → verified evidence and a named objection would replace the pack's own inference on B1 and the prohibited list
