I'm reading the prep skill's rules, then I'll build your pack.
Dara, your prep pack is ready. It's organised by round, since the recruiter's email laid out all three for 21 November. Your message, the JD, the values page and the strategy brief covered everything I needed, so I didn't do any web research.

**The most important thing to practise is C1, in the round with the Head of Member Services.** It's the question I'd expect most: "You've handled one branch's complaints log, and you haven't worked in a contact centre. Why can you run this across every branch and the contact centre?" The pack gives you an answer in three steps:
1. Say the gap yourself first.
2. Stand on what you've actually done: the complaints log, training new tellers on escalations, and the monthly spreadsheet.
3. Give a plan for your first 90 days.

**What's in the pack:**
- **One table matching each JD line to what you told me about yourself.** Several lines need an honest answer from you. For example, whether the complaints in your log were regulated, what your spreadsheet tracks, and whether it's built in Excel. The pack shows how to answer both ways: if you did it, and if you didn't.
- **Recruiter round:** 8 questions, mostly about your background, why Ashgrove, and the JD requirements. Saying "I haven't worked in a contact centre" and "I haven't presented above regional level" calmly here sets you up for the later rounds.
- **Head of Member Services round:** 12 questions. This round is mostly about past situations, plus probing on your gaps and your spreadsheet.
- **Panel round:**
  - One story or story-picking guide for each of the four values.
  - A plan for the 20-minute escalation case: an outline to follow, three positions to choose from (each with what you'd concede), and what you'd avoid doing.
  - A practice scenario, plus two cases on the hub move and the digital shift.
  - Two questions on how you'd work alongside branch managers.
- **Claims to avoid:** a short list of things you shouldn't say, such as "owned the process end to end", "coached supervisors" or "have contact-centre experience", each with the honest wording to use instead.
- **Questions to ask them:** five for each interviewer.

Before 21 November, it's worth asking the recruiter whether you'll get the case in advance and when the interviewers will be named.

Say the word and I'll play the sceptical interviewer on C1, with follow-ups that react to what you say.
I can also save a tuesday-dossier.md file noting the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 21 November 2026. (1) 30 minutes with the recruiter. (2) 45 minutes with the Head of Member Services, your would-be manager, mostly behavioural. (3) 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case. The panel is also the values round.
**Mode:** loop. The recruiter's email sets out all three rounds, so you get one shared fit snapshot and then a mini-pack for each round. Interviewer names haven't been assigned yet, so there is no interviewer read.

---

## How to use this pack

- **Personas** describe *how* a question is asked: a friendly opener, a sceptical probe, a timed challenge. **Types** describe *what is being scored*.
- **Type key:**
  - **VAL** checks whether your past behaviour shows Ashgrove's four published values.
  - **EXP** checks whether your own experience holds up when someone digs into it.
  - **JD** checks whether you can do the job as the JD lists it, gaps included.
  - **CO** checks how well you know Ashgrove's strategy and current situation.
  - **CASE** is a live problem from the role, scored on structure and reasoning.
- **Provenance labels:**
  - **[grounded]** traces to something you gave me: your message, the JD, the values page, the recruiter's email or the strategy brief.
  - **[inferred]** is my own derivation, and the derivation is named.
  - **[generic]** is a general pattern for this kind of role, with no claim about Ashgrove or about you.
- **Answer slots.** In some cells you'll see "Answer slot: if X, say how; if not, say so plainly." This is where your material doesn't show something an interviewer is likely to ask about. Either branch is a good answer. The second branch is a limit, not a confession.
- The guidance is scaffolding, not a script. Rehearse it in your own words. Each question ID (A1, C1…) can be used to ask for a drill.
- The **highest-ROI prep in this pack is C1**, the contact-centre and scope objection in Round 2.

---

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | discovery | The three supervisor years read as branch customer operations. Your material names no role for the first three years, so it doesn't show whether those years count. Words: "Six years in retail banking, the last three as a branch supervisor." Answer slot: the JD's "4+ years" line makes a probe on the earlier years likely. If they were in a member- or customer-facing role, name that role in your own words. If they weren't, say so plainly and stay with the six years in banking and the three as supervisor |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal complaints log. It doesn't say whether those complaints fell under regulatory rules, or what those rules asked of you. Words: "I handled the branch's formal complaints log." Answer slot: if the complaints in that log came under regulatory rules, say which rules you worked to and what part was yours, in your own words. If they didn't, or you don't know, say so plainly and describe how the log worked |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's log, not a process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: "end to end" makes a probe on which stages were yours likely. If any stage beyond keeping the log was yours to do (looking into a complaint, replying to the member, closing it), say which in your own words. If none was, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | No wording closes this gap, and you have already said so. Words: "I haven't worked in a contact centre." Then say how you would learn it, as a plan and never as a past. Never claim contact-centre work, and don't add anything to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | "Monthly" and "complaints" match. Your material doesn't say whether the spreadsheet tracks volumes and resolution times. It also says the regional manager uses it, not that you report from it. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it tracks volumes and resolution times, say how each is counted, in your own words. If it doesn't, say so plainly and say what it does track |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not Excel. Answer slot: if you built it in Excel, say so. If you built it in another tool, name the tool plainly and don't let "spreadsheet" become "Excel" |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material shows training new tellers on a script. That's a different audience (tellers, not supervisors) and different work (training, not coaching). Words: "I trained new tellers on our escalation script." Answer slot: coaching supervisors makes a probe likely on whether you have guided anyone at or above your own level. If you have, say when, in your own words. If not, say so plainly and stay with the tellers |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I haven't presented to anyone above regional level." Then describe how you would prepare, as a plan and never as a past |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | low | [inferred] | discovery | Your sentence draws its line above regional level. It doesn't say whether you have presented at regional level or below, so don't imply that you have. Answer slot: if you have presented to your regional manager or at a regional meeting, say what and to whom, in your own words. If not, say so plainly |
| F10 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence would look like this: a named journey, what members struggled with, and what you passed back to the team that built it. Answer slot: if you have worked with a digital team or on a self-service journey, say what it was and your part in it. If you haven't, say so plainly and say how you would start |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | A5, C1, G1, J1 |
| "report monthly on complaint volumes and resolution times" | E1, E2, G2 |
| "coach branch supervisors on escalations" | D2, D3, K1 |
| "work with digital teams on self-service journeys" | C3, C4, J3 |
| "4+ years in financial-services customer operations" | A1, B1 |
| "experience handling regulated complaints" | B2, D1 |
| "confident presenting to senior leaders" | B3, C2 |
| "comfortable with Excel reporting" | E1 |

---

## Prohibited claims

These are claims the pack won't coach, even under pressure. The banks below were written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end, or across branches | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's own observation, not words for you: the material says one branch's log, not a process. C1's slot stays inside the log |
| Has worked in a contact centre | Negative you stated, F4 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders above regional level | Negative you stated, F8 | "I haven't presented to anyone above regional level." No slot |
| Has coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's own observation: the material says tellers, and training |
| Runs or presents the region's complaints reporting | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's own observation: you built it, and they use it |

---

## Grounding brief

These are the points from Ashgrove's July 2026 strategy brief that you gave me. Use the brief's own vocabulary. "Hubs" and "self-service journeys" are their words.

| Item | What the source says | Why it matters for this role | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | The JD's "self-service journeys" line sits inside this target. Complaints show where a digital journey fails a member | [grounded] |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | The JD's "across branches" scope will change shape during your first year. It also sits awkwardly beside "Neighbours, Not Numbers — every branch is part of its town" | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" | A new product launching early in your tenure. My reading is that it could bring a new kind of complaint, so ask about it rather than assert it | [inferred] |
| Competition | "the main competitive pressure is app-only banks" | It frames why the digital shift matters to them. Your answers can stay on the member's experience rather than on market talk | [grounded] |

---

# Round 1: Recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, motivation and logistics | High. The recruiter-screen prior, and the recruiter runs this round | Have a 90-second arc ready (A1). Treat casual questions about the JD's headline lines as scored |
| Skeptic (light) | Checks you against the JD's listed requirements | Medium. Recruiters screen against the requirements list, and F1, F4 and F8 are the visible ones | Answer each one plainly, at its own scope, and move on without apologising |

### Question bank

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in three beats, each one a sentence you gave me. Six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log and trained new tellers on the escalation script. You built the monthly complaints spreadsheet your regional manager uses. Close with why this role is the next step, in your own words. Don't add titles or scope | F1, F2, F3, F5 and F7 all start here, and this opener sets the frame for every later round. EXP because the recruiter will check it against what you say later |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Name one value by its official name and say what it means to you in your own words. "Members First, Always" or "Own the Fix" fit the job's complaints focus. Then link it to one strategy item, such as the move to digital service. Answer slot: your reason for wanting a member-owned organisation is yours to give. Give it plainly, and don't invent a connection you don't have | Motivation consistency is checked in every round, so set the line here. CO because it scores whether you've read their material |
| A3 | "What do you know about where we're heading?" | CO | [grounded] | Name the four items from the brief in its own words: 40% of service digital by 2028, eight branches becoming five hubs over 2027, small-business lending in Q1 2027, and app-only banks as the pressure. Then one sentence on what that means for complaints, framed as something you'd want to learn rather than a claim: "I'd want to understand how complaints move as service moves to digital and branches become hubs." | The recruiter sent you the brief, so they'll expect you to have read it. CO because it tests homework |
| A4 | "What are you looking for in your next role?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Anchor it in what you've done: the complaints log, training tellers on escalations, and the monthly spreadsheet. Then say you want the wider version of that work, which this JD describes. Answer slot: what draws you to the wider scope is yours to say, in your own words | It's casual in register but scored on whether your wants match the JD. JD because the answer should echo the role's scope without claiming it |
| A5 | "The role covers branches and the contact centre. How do you feel about that breadth?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Give the gap first, plainly: "I haven't worked in a contact centre." Then what you do bring: you handled the branch's formal complaints log. Then one sentence of plan: how you'd learn the contact centre's side, such as sitting with advisers and following a complaint from first call to close. Say it as a plan | F4 is the first gap a recruiter will spot. Naming it first takes the edge off it in Round 2. JD because it scores the headline responsibility |

**Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for 4+ years in financial-services customer operations. Walk me through how you meet that." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Hold what the quote carries: "Six years in retail banking, the last three as a branch supervisor." Answer slot: if the earlier three years were in a customer-facing role, name it in your own words. If they weren't, say so plainly and stay with the six years in banking and the three supervising a branch | F1 is a requirements-list check, and recruiters run those literally. JD because it is the stated requirement |
| B2 | "Have you handled regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with what you did: "I handled the branch's formal complaints log." Answer slot: if those complaints came under regulatory rules, say which rules you worked to and what part was yours. If they didn't, or you don't know, say so plainly and describe how the log worked. Don't name a rule you can't explain | F2 is a listed requirement, and "regulated" is the word your material doesn't reach. JD because it scores that line directly |
| B3 | "The role presents to senior leaders. What's your experience there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan: how you'd prepare for a senior audience, such as leading with the number that matters and one recommendation. Answer slot (F9): if you have presented at regional level, say what and to whom. If not, say so plainly | F8 is a gap you stated, so rehearse saying it early and calmly. JD because "confident presenting to senior leaders" is a listed requirement |

### Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| "For the 20-minute case: will I get the scenario in advance, or in the room?" | It shapes how you prepare, and recruiters can usually answer it |
| "The panel scores against the four values. Is there anything about the format I should know?" | It shows you read the email closely and take the values round seriously |
| "Is this a new role or a backfill?" | It tells you whether you'd be building the complaints process or inheriting one |
| "Where does the role sit between branches and the contact centre?" | It is the reporting line behind "end to end", and the answer feeds your C1 rehearsal |
| "When will the panel members be confirmed?" | It gets you names before 21 November, which unlocks a sharper pack |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scope jump and the contact centre | High. The hiring-manager prior, and F3, F4 and F8 are where a manager takes on risk | Rehearse C1 until it's boring: the limit said first, then what you carry, then a plan |
| Values/Behavioral | "Tell me about a time…" prompts on the JD's duties | High. The recruiter said this round is "mostly behavioural" | Use "we" for context and "I" for your part. Use a quoted story where one exists and the honest branch where none does |
| Data-Driven Prober | Digs into the monthly spreadsheet | Medium. Monthly reporting is in the JD, and F5 and F6 are open | Know what the spreadsheet tracks and how it is counted, and say plainly what you don't know |
| Pressure | A timed "why you" challenge, and a "how much was you" probe | Low to medium. Not signalled, but managers often test composure on the gap | Pause, restate, hold through two follow-ups, then concede the specific thing |
| Case/Strategist | One strategy question | Lowered from the hiring-manager prior because the case sits with the panel | Use C4 as the one strategy rehearsal for this round |

### Question bank

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've handled one branch's complaints log. This role owns the process across every branch and the contact centre, and you haven't worked in a contact centre. Why should I believe you can make that jump?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | **The highest-ROI rehearsal in this pack.** (1) Name the limit before they finish: "I haven't worked in a contact centre, and I've handled one branch's log, not a whole process." (2) Hold only what the quotes carry: "I handled the branch's formal complaints log, I trained new tellers on our escalation script, and I built the monthly complaints spreadsheet our regional manager uses." (3) Plan, said as a plan: in the first 90 days, sit with contact-centre advisers, follow complaints from both channels to close, and map where they enter and leave the log. Answer slot: if any stage beyond the log was yours (looking into a complaint, replying to the member, closing it), say which. If none was, say so plainly. Follow-up 1, "the contact centre's volume is a different world": don't claim volume, concede it, and ask what it looks like. Follow-up 2, "so we'd be training you?": concede the specific ("on contact-centre operations, yes") and hold on the log, the training and the spreadsheet | F3 and F4 together are the biggest distance between your material and the JD's first line, so a manager will raise it in some form. JD because it scores the headline responsibility directly |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one you stated, rather than a humble-brag. Presenting fits well because C1 already covers the contact centre: "I haven't presented to anyone above regional level." Then a plan: how you'd prepare your first monthly report for senior leaders, such as a dry run with your manager. Keep it under a minute and don't follow it with "but really I'm great at it" | A standard sceptic stem. F8 gives you an honest answer that is ready to use. JD because it maps to a listed requirement |
| C3 | "What have you done with digital teams on self-service journeys?" | JD | [grounded] | Answer slot (F10): if you have worked with a digital team or on a self-service journey, say what it was and your part. If you haven't, say so plainly. Then give a plan, not a past: you'd want complaints classified so the digital team can see which journeys send members back to a branch or the phone. Don't describe a journey you didn't work on | F10 has no evidence, and the 40% digital target makes this line important to them. JD because it is a stated responsibility |
| C4 | "We're moving 40% of member service to digital by 2028. How do complaints change when the branch isn't the front door?" | CO | [grounded] | Structure it: (1) where complaints will arrive, now more through digital channels and the contact centre; (2) what they'll be about, such as journeys that fail or members who want a person; (3) how you'd see it, through categories in the monthly report that separate channel from cause; (4) one risk, members who struggle with digital, which links to "Members First, Always". Frame each as your thinking, not as fact about Ashgrove | CO grounded in the brief, and the one strategy item a member-services head owns. The question asks about the future, not your past |

**Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you handled an escalated complaint that was hard to resolve." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one from the formal complaints log you handled, if one comes to mind. It needs the member's situation, what made it hard, what you did yourself, how it ended, and what changed afterwards, if anything did. "We" for the branch, "I" for your part. If no such complaint comes to mind, say so plainly, then describe how you handled the log | F2 and F3 are the core of the JD, and behavioural rounds start there. VAL because the manager will hear it against "Own the Fix" |
| D2 | "Tell me about training new tellers on your escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7: you trained new tellers, and the script was the branch's escalation script. Those are the beats the quote states, so tell them in your own words. Answer slot: the JD's "coach branch supervisors on escalations" makes a probe likely on whether you checked the training stuck. If you checked, say how. If you didn't, say so plainly and describe how you trained them | F7 is your nearest evidence to coaching supervisors, so the manager will test how far it reaches. EXP because it is a direct deep-dive on a claim you made |
| D3 | "Tell me about a time you had to coach someone who didn't report to you." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: it needs a person who didn't report to you, what you wanted them to change, how you raised it, and whether it changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you trained new tellers on the escalation script. Don't present that as coaching supervisors | The JD's coaching line is aimed at branch supervisors, who won't report to you. VAL because it is behavioural, scored on how you influence people |
| D4 | "Tell me about a time you told your manager something they didn't want to hear." | VAL | [generic] | Selection scaffold: it needs a named stake, what you said, and how the relationship held up afterwards. Choose a time the hard truth actually landed. If no such time comes to mind, say so plainly, then say how you would raise one | The role reports bad complaint numbers upwards every month. VAL because it is a standard behavioural stem |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built. What does it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5: you built it, it's monthly, it covers complaints, and your regional manager uses it. Answer slot: the JD's "volumes and resolution times" makes a probe on those likely. If it tracks them, say how each is counted, in your own words. If it doesn't, say so plainly and say what it does track. Answer slot (F6): if it's in Excel, say so. If it's in another tool, name the tool | F5 and F6 are your strongest match to the reporting line, so the manager will probe them. EXP because it checks a specific claim |
| E2 | "How confident are you in the numbers in that spreadsheet? Which part would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The weakest-assumption move, in your own words. Answer slot: say how the figures are counted, what they depend on (for example who records each complaint), and the assumption you'd defend least. If you don't know how a figure was counted, say so plainly. Name the weakness before they do. Don't invent a checking step | A spreadsheet that someone senior uses invites a "how do you know it's right" probe. EXP because it tests whether you know your own data |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds. Why you over an internal candidate who already knows our contact centre?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause, then hold: the log, the teller training on escalations, and the monthly spreadsheet. Concede plainly: "I haven't worked in a contact centre. They'd know it better on day one." Then close on why you, in your own words, on the branch side. Hold that through two follow-ups. Don't claim to know their contact centre | C1 in a time-boxed form. JD because it scores the role's scope, with pressure delivery |
| G2 | "That spreadsheet. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold: "I built it. Our regional manager uses it." Answer slot: if others decided what it tracks or added to it, say where your part ended. If it was all yours, say so plainly. Don't claim the decisions made from it as yours | The attribution probe is aimed at F5. EXP because it tests what was actually yours |

### Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| "When you read the monthly complaints report today, what question does it not answer for you?" | It turns the reporting line into their problem, which you'd solve |
| "Where do complaints get stuck between branches and the contact centre today?" | It is the seam C1 is about, and you learn the real scope |
| "As 40% of service moves to digital, how do you see complaints changing?" | It shows you read the brief and links your role to the strategy |
| "How will the move from eight branches to five hubs change what supervisors escalate?" | It shows you're thinking about the first year you'd actually work in |
| "What would a strong first 90 days look like to you?" | It gives you their success measures in their own words |

---

# Round 3: Panel of two branch managers (60 minutes: values round plus a 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Story prompts scored against the four values | Very high. The recruiter said the panel "score against the four values" | One prepared story or honest scaffold per value, shown in the cheat sheet below |
| Case/Strategist | The 20-minute complaint-escalation case, plus follow-ups | Certain. The recruiter stated it | Clarify, then member first, then owner, then fix, then record, then coach. Use their value words |
| Peer Evaluator | "What happens when you and I disagree?" The branch managers are the people whose supervisors you'd coach | Medium. Branch managers will judge whether you add to their load or take away from it | Frame it as reciprocity: what you bring their branches, not only what you need from them |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Make decisions from the member's point of view | Selection scaffold: a time you changed what you would have done because of how it looked to the member. It needs the member's situation, your choice, and what changed. If none comes to mind, say so plainly, then give the nearest thing F3 carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." |
| Plain Words | If something needs explaining twice, the writing failed | F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beats are that you trained new tellers, on the escalation script. Answer slot: the value's "explained twice" line makes a probe likely. If a teller didn't get the script first time and you changed how you explained it, say what you changed. If that didn't happen, say so plainly and describe how you trained them |
| Neighbours, Not Numbers | Each branch belongs to its town, and members aren't figures | Selection scaffold: a time you treated a member, or your branch's local situation, as more than a figure. If none comes to mind, say so plainly and say how you would. Be ready for the tension: you built a numbers tool (F5) and the value says "not numbers". Say how a number points you to a person |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | F5: "I built the monthly complaints spreadsheet our regional manager uses." The beat is that you built it, and your regional manager uses it. Answer slot: the value makes a probe likely on whether you found the problem it fixed. If you built it because you spotted a gap and kept at it until it worked, say what the gap was. If it was assigned to you, say so plainly and describe what you built |

### Graded deliverable: the 20-minute complaint-escalation case

**Grounded facts to build on.** The recruiter said it is a "20-minute case on a complaint escalation", run by two branch managers who also score the four values. About you: F3 ("I handled the branch's formal complaints log and trained new tellers on our escalation script.") and F5 ("I built the monthly complaints spreadsheet our regional manager uses."). The format (advance or in the room, written or verbal) isn't known. Ask the recruiter in Round 1.

**A structure to use out loud** [generic]:
1. Clarify: what the complaint is, who the member is, how long it has been running, what has been promised, and what rules or deadlines apply to it.
2. Member first: what the member needs today, said in plain words.
3. Owner: who holds it until it's closed.
4. Fix: the member's case first, then the cause.
5. Record: log it so the monthly report can show whether it is one case or a pattern.
6. Coach: what the escalating supervisor takes from it.

**Theses to choose from, each with a concession you must say:**

| Thesis | Concession |
|---|---|
| Fix it for the member before fixing the process. "Members First, Always" puts the member's case ahead of the root-cause work | Speed can't skip the rules. You wouldn't promise an outcome before checking what process the complaint has to follow |
| Whoever takes the escalation keeps hold of it, and the lead's job is to make that possible ("Own the Fix") | Some complaints have to go to a specialist team. Owning it then means tracking it and keeping the member updated, not doing everything yourself |
| Every escalation is data. Classify it so the monthly report shows whether it is a one-off or a pattern, for example tied to a hub move or a digital journey | One case isn't a trend. You wouldn't redesign a process because of one complaint |

**Differentiation.** The consensus answer is "apologise, investigate, resolve, follow up". Any prepared candidate gives it. Differentiate in three ways. Use the panel's own value words at each step. Say what you'd need from the branch manager and what you'd give their supervisor, because these panellists *are* branch managers. Close the loop into the monthly report.

**The anti-pick: say what you would not do.**
- Offer compensation before the facts are known.
- Go over the branch manager's head without telling them.
- Promise the member a fix you can't own.

### Question bank

**Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold from the cheat sheet: it needs the member's situation, your choice, and what changed. If none comes to mind, say so plainly, then give the nearest thing you have: you handled the branch's formal complaints log. Don't build a story around the log that you didn't tell me | "Members First, Always" is scored, and its wording is the panel's likely prompt. VAL by definition |
| H2 | "Tell me about a time you had to explain something so it landed the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7: you trained new tellers on the escalation script. Answer slot: if a teller didn't get the script first time and you changed how you explained it, say what you changed, in your own words. If that didn't happen, say so plainly and describe how you trained them | "Plain Words" is scored, and F7 is the nearest story your material carries. VAL |
| H3 | "Our branches are part of their towns. Tell me about a time you treated a member as a neighbour rather than a number." | VAL | [generic] | Selection scaffold: it needs a named member situation (no personal details), what you did beyond the transaction, and why it mattered locally. If none comes to mind, say so plainly, then say how you would. If they push on the tension with your spreadsheet work, say how a number points you to a person | "Neighbours, Not Numbers" is scored. Your material carries no story for it, so this is a scaffold. VAL |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5: you built it, and your regional manager uses it. Answer slot: if you built it because you found a gap and kept at it until it worked, say what the gap was and what "solved" meant. If it was assigned to you, say so plainly, then pick a different time you found a problem, or say that none comes to mind | "Own the Fix" is scored. F5 is a candidate story, but only if you found the problem yourself. VAL |
| H5 | "When did you put a member ahead of an internal target?" | VAL | [generic] | Selection scaffold: it needs the target, the member, what you chose, and what it cost. Choose one where the choice was actually yours. If no such time comes to mind, say so plainly, then say how you'd weigh it | A standard values stem, and a sharp one for branch managers working through the hub changes. VAL |

**Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | Practice scenario: "A member has been passed between a branch and the contact centre three times about the same problem and now wants to speak to someone senior. The branch supervisor has escalated it to you. Talk us through it." | CASE | [generic] | Use the build section's structure out loud: clarify, member first, owner, fix, record, coach. Pick one thesis and say its concession. Name one value at each step where it fits naturally. End with what you'd give back to the supervisor. It's a live problem, so the guidance makes no claim about your past | A practice version of the declared 20-minute case. The real scenario is unknown, so this is a rehearsal pattern, not a prediction. CASE |
| J2 | "One branch is merging into a hub next year, and its supervisor tells you complaints have doubled since the announcement. What do you do?" | CASE | [grounded] | Clarify first: which complaints, which channel, and since when. Separate the member's worry about losing their branch from service failures. Fix for members in plain words. Track it as its own category in the monthly report. Work with the branch manager, not around them. Concede that some of this is the change itself and won't go to zero | Built on the brief's "eight branches into five hubs" and "Neighbours, Not Numbers". CASE, with CO content from the brief |
| J3 | "A member says the app journey didn't work for them and they had to come into a branch to finish it. What happens to that complaint?" | CASE | [grounded] | Resolve it for the member at the branch first. Log it as a digital-journey cause, not a branch complaint. Pass it to the digital team with the member's words, so the pattern is visible. Concede that one case won't move the journey on its own | The JD's "self-service journeys" line and the 40% digital target, put in front of branch managers. CASE |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You'd be coaching our supervisors on escalations. What happens when you and I disagree about how my branch handled one?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Propose principles, not a turf claim. Talk to the branch manager first, never around them. Agree on the facts before the judgement. Keep the member's outcome as the shared test. You can say you've supervised a branch for three years, so you know the supervisor's side. Don't claim you've coached supervisors | F7 is where these panellists' interest lies, and this is its collegial form. JD because it scores the coaching responsibility |
| K2 | "What would you need from us, and what would you bring our branches?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | What you'd bring: a clear monthly view of complaints. You built a monthly complaints spreadsheet before, so offer to show them their branch's picture. What you'd need: early warning on escalations and their read on local context. Keep it two-way | A reciprocity probe, scored on whether you reduce or add to their load. JD because it is about how the role works with branches |

### Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would genuinely help your branches?" | The reciprocity question. It shows you'd work for them, not only check on them |
| "When a complaint escalates today, what do you wish happened that doesn't?" | You learn the real problem, and they hear you listening |
| "How are your teams feeling about the move to hubs, and where do you expect member complaints to come from?" | It ties "Neighbours, Not Numbers" to the change they're living through |
| "Which of the four values is hardest to live by on a busy day in a branch?" | It invites honesty and shows you see the values as work, not slogans |
| "How would you like to hear from me when I spot a pattern in your branch's complaints?" | It settles how you'd work together before you start |

---

## Sources

**Provided documents:**
- The JD text, pasted.
- Ashgrove's values, copied by you on 12 November 2026 from ashgrovecu.org/about/values. Not re-fetched: the pasted text is what's in hand.
- The recruiter's email about the three rounds.
- Your summary of the 2026 strategy brief published in July 2026, sent to you by the recruiter.
- Your background, from your message.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values you pasted, copied this morning, already supply the four official names and wording for the cheat sheet and bank H |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email sets out all three rounds, so persona weights follow those rounds |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 strategy brief, under six months old, already supplies current priorities for the grounding brief, C4, J2 and J3 |
| 4. Interviewer names | n/a | No names have been assigned, so there was no query to form. There is no interviewer read, and the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned:** a read of each person's public professional background, persona weights per panellist, and a reverse question tied to each person's own path.
- **Your answers to the answer slots:** the earlier three years' roles, whether the log's complaints were regulated, what the spreadsheet tracks and in which tool, any regional-level presenting, and any digital-team work. These upgrade F1, F2, F5, F6, F9 and F10, and turn B1, B2, B3, C3 and E1 from slots into story-mapped answers.
- **Your CV:** more sentences to map, especially for H1, H3, H5, D3 and D4, which are scaffolds today.
- **The spreadsheet itself, anonymised, or a screenshot:** the one inspectable artifact for complaints reporting. F5 and F6 would rise from medium towards high.
- **The full strategy brief text, not just the four points:** C4, J2 and J3 built on its own numbers and wording.
- **The case format from the recruiter (in advance or in the room, written or verbal):** the case build section retuned to the actual format.
- **How much prep time you have:** a prioritised prep schedule across the nine days before 21 November.
- **Deep research, up to 6 more searches and 2 more fetches, several more minutes:** recent Ashgrove news and organisation context, such as hub announcements and leadership changes, plus any public reports of its interview loop, which could sharpen C4 and J2.
- **A tuesday-dossier.md from job-underwriter:** the C1 objection derived from verified evidence rather than inferred, and a checked list of claims to avoid. Optional; this pack is complete without it.
