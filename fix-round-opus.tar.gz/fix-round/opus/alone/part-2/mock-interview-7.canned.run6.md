I've built your prep pack. Your interview is tomorrow, so it's sized for one evening.

Saltmarsh's own interviewing page describes this exact 60-minute interview. It's called "the Outage Hour": a role-play of an outage during a live event, then a values conversation. Since Tobias is the hiring manager, I didn't need to ask you anything else.

- **Highest-ROI prep (B1):** "You've never worked on a game with in-app purchases." In September, Saltmarsh announced that both games move to a season pass and a single shared events calendar from February 2027. Admit it plainly, then point only to the three things you've actually done.
- **The outage role-play (A1, A2, E2):** this is half the hour, so the structure needs to be automatic. Ask what's broken, decide how to contain it, tell players only what's known, make it up to affected players, then review.
- **Values:** Saltmarsh has three published values. Your checklist is the strongest match, for "Leave the Build Greener". For the other two you'll need to pick a real story tonight, or say plainly that you don't have one.
- **About Tobias:** he was a QA lead before this job, and his GDC talk is about patch notes matching what actually shipped. Expect close questions on your release checklist. Hold it at what you said: you wrote it, and QA still uses it.

I didn't fill in the gaps your background leaves open, like whether you planned the calendar or prepared the retention numbers. Where those come up, the pack gives you two honest ways to answer.

If you want a live rehearsal, I'll play Tobias as the Skeptic on B1.
I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-canned-b036a1da:
- saltmarsh-games_live-operations-producer_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. He is the hiring manager for this round (see the Persona table's reasoning and Sources S2).
- **Format:** one 60-minute session, Friday 13 November 2026, which is tomorrow

## How to use this pack

- **Personas** describe how a question is asked: the interviewer's style and pressure. **Types** describe what's being scored.
- **Type key:**
  - **VAL:** whether you show Saltmarsh's published values in how you've behaved
  - **EXP:** whether what you say about your past holds up, and what was actually you
  - **JD:** whether you can do the job as the job description lists it, gaps included
  - **CO:** whether you know Saltmarsh's current strategy and can think about it
  - **CASE:** a live problem from the role, worked through out loud
- **Provenance** is how far each line can be trusted:
  - `[grounded]` traces to your words, the job description or a cited source
  - `[inferred]` is a derivation, and the derivation is named
  - `[generic]` is a pattern for this kind of role, not a fact about Saltmarsh
- **Answer slots** are spots where the pack doesn't know what happened. Each one gives two honest branches, and you fill it from memory in your own words. The pack never fills it for you.
- The guidance is a scaffold, not a script.

## Prep triage: one evening

1. **B1 out loud, three times.** This is the highest-ROI prep in the pack: the in-app-purchase objection, set against the move to a season pass. (20 min)
2. **A1 out loud with a 10-minute timer.** The outage tabletop is half the hour, and the structure has to be automatic. Then A2 and E2 as follow-ups. (30 min)
3. **The values cheat sheet (C1–C4).** For each value, pick your story now, or settle on the honest branch. (20 min)
4. **D1's answer slot.** Know what your monthly retention numbers contained, and whether you prepared them or presented them. (10 min)
5. **Pick three reverse questions.** Include R1 or R2. (5 min)

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a weekly content-drop calendar for one main title. It doesn't describe a live-events calendar across two, so your words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Don't rename the drops as live events. Answer slot: the JD's "plan and run" makes a probe on planning likely. If choosing what went into each drop and when was yours, say how you decided, in your own words. If there was no such step, or it wasn't yours, say so plainly and stay with running the calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | Your material doesn't say how the calendar involved design, art, engineering or community. Separately, it says you haven't led a team. Coordinating isn't leading, and the JD asks for coordinating. Answer slot: if a drop depended on any of those teams' work and getting it landed was part of your job, say which teams and what your part was. If not, say so plainly and stay with running the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly retention numbers isn't the same as owning a post-event review. Your words: "I presented our monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe likely. If you reviewed a drop after it ran, say how and what the review reported. If there was no such review, or it wasn't yours, say so plainly and stay with the monthly numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap here, but there's nothing to inspect behind the line, and the interviewer's QA background makes a probe likely. Lead with the quote's own terms: you wrote it, and QA still uses it. Answer slot: the JD says "manage the release checklist with QA". If you also ran the checklist with QA on releases, say how. If that was someone else's job, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Your material gives four years as an associate producer and a weekly drop calendar. It doesn't say the title was run as a live service. Keep "associate" in the title. Answer slot: if the game was run as a live service, say so in your own terms. If it wasn't, say so plainly and stay with the weekly drops |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Your quote meets this requirement word for word. Say it as written, because a specific cadence and a two-year run beat any adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but expect the Prober (D1). Answer slot: the JD's retention line makes a probe on the numbers likely. If you prepared them, say which measures they held and how they were counted. If someone else prepared them, say so plainly and stay with presenting them. "I don't know how they were counted" is an honest branch |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A document that's still in use is the strongest writing evidence your material holds. Reworded only: "The release checklist I wrote is still the one our QA team uses." |
| F9 | Season-pass model for two titles from February 2027. This isn't in the JD; it comes from the Project Larkspur announcement (Sources S3) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You've stated this gap yourself, and no wording closes it. Your words: "I haven't worked on a game with in-app purchases." Then explain how you would learn it, said as a plan and never as something you've done. Never claim monetisation work, and add nothing to make the gap look smaller |

## Reading the interviewer

| What the public record shows | What it means for Friday | Provenance |
|---|---|---|
| Tobias Wrenfield is "Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio." (GDC 2026 talk listing, S4) | Expect him to probe release discipline. H2 and C3 are where your checklist line gets tested, so hold it at the quote's scope | [grounded] |
| His GDC 2026 talk "Patch Notes Are a Promise" argues that "a live team is judged by how often its patch notes describe what actually shipped." (S4) | In the tabletop (A1), player messaging that says only what is known will land, and an optimistic fix time won't | [grounded] |
| The talk's argument and the value "Ship the Patch Not the Promise" (S1) make the same point | He'll probably give honest communication real weight in the values half too (C2) | [inferred] |
| Mirror opportunity: he and you share the vocabulary of release checklists and QA. Your side is F4: "Wrote the release checklist our QA team still uses." | Say the checklist line plainly and let him ask. His career move from QA lead to Head of Live Ops isn't a move you've made, so don't present it as shared | [grounded] |

Limit: the talk was read only as a listing description. Neither the talk itself nor his profile was opened.

## Persona table

| Persona | How it shows up on Friday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The outage tabletop, plus planning and diagnosis follow-ups | **Highest.** Saltmarsh's interviewing page says the 60 minutes open with "a live-incident tabletop on a simulated outage during a live event" (S2), and the hiring-manager prior is also case-heavy | Clarify, then contain, communicate, make good and review. Think aloud and ask for the data you'd want |
| Values / Behavioral | The second half: "then a values conversation" (S2), built on three published values (S1) | **High.** The loop source names the round | Use the cheat sheet. Where none of your stories fits, take the honest branch rather than stretching one |
| Skeptic | Probing two titles against one, coordinating without having led, and the season pass against your lack of in-app-purchase experience | **Mid.** Hiring-manager prior, plus F1, F2 and F9 | Concede what you stated, hold what your quotes carry, and offer the ramp as a plan |
| Data-Driven Prober | Retention numbers and post-event KPIs | **Mid.** The JD's KPI and retention lines (F3, F7) | Know what you can and can't say about how your numbers were counted |
| Pressure | Time pressure inside the simulated outage | **Low to mid.** Inferred: an outage tabletop is time-pressured by design. Nothing documents a stress style | Pick one first action, give the reason, then the next one |
| Conversational | Openers and the casual stretches between the two halves | **Low.** Short session | A pre-built 90-second arc |
| Peer Evaluator | Cross-team friction scenarios | **Low.** No peer is in this round, but the JD's coordination line brings the theme in | Reciprocity and seam principles |

## Question banks

IDs run A to H. F is skipped so bank IDs don't collide with the fit snapshot's F1–F9.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Saturday night, day two of a weekend event. Players say event rewards aren't arriving, and the event ends in six hours. Walk me through the next hour." | CASE | [inferred] | Clarify first: how many players, which platform, what changed last (a config, a build, a server deploy), and whether the fault is server-side or in the client. Contain: state the options (extend the timer, pause the event, roll back the last change) and the test you'd decide by. Communicate: get the community team a holding message that says what's known and promises no fix time you don't have. Make good: decide how affected players are compensated. Close: say what goes into the incident review and onto the checklist. Ask the interviewer for the data at each step | The interviewing page documents this exact format (S2). The scenario is a practice stand-in, so the label is `[inferred]`. It makes no claim about your past |
| A2 | "Engineering says the fix needs a client update, and store review will take longer than the event has left. Now what?" | CASE | [generic] | Separate server-side levers (timer, reward grants, event config) from the client fix. Extend the event or reissue rewards server-side, then ship the client fix on its own schedule. Say you'd check current review times with engineering rather than quoting a number. Message players with the honest timeline | The most likely escalation of A1 on a mobile title. A role-family pattern, not a Saltmarsh fact |
| A3 | "Plan next quarter's events calendar for two titles sharing one live-ops team. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify the goal per title (retention, re-engagement), capacity in art, engineering and QA, release and certification windows, and community beats. Then cadence, avoiding collisions between the two titles, and decision points. You may name your calendar once, as the quote says it: weekly drops, your main title, two years. Don't describe how you planned it unless that's true, which is F1's answer slot | This is F1's requirement asked as a live problem. CASE because it scores structure, not your record |
| A4 | "From February, both titles share one events calendar and move to a season pass. What breaks first?" | CO | [grounded] | Offer these as hypotheses and ask which ones he's already seen. A fixed season length makes slips more expensive. Art and QA become a shared bottleneck. Both titles' events compete for the same team's attention. Post-event KPIs need definitions that compare across titles. Ask before asserting anything about how a pass is priced | Project Larkspur (S3) is the strategy question most candidates won't prepare. CO because it scores homework and the ability to think about it |
| A5 | "Retention over the event window is down against the last event. Diagnose it." | CASE | [generic] | Confirm the measure and the comparison: same cohort definition, same days of the week, any seasonality. Segment by new and returning players, platform and title. Rule out incidents and bugs, then event design changes and competing releases. Name the comparison you'd trust least before he does. End with what the post-event review would record | Covers the JD's review and KPI line (F3) and the retention line (F7) as reasoning. Generic because it's a diagnostic pattern |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "From February we're on a season pass. You've never worked on a game with in-app purchases. Why should I bet on you?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | **This is the highest-ROI rehearsal in the pack.** Concede first, plainly: "I haven't worked on a game with in-app purchases." Then hold only what your quotes carry: you ran the weekly content-drop calendar for your main title for two years, you wrote the release checklist QA still uses, and you presented the monthly retention numbers to the studio head. Then the ramp, said as a plan: what you would learn first, and from whom (the design and data people who own the pass). **Follow-up 1:** "So what do you know about season passes?" Don't bluff. Say what you'd want to understand first. **Follow-up 2:** "Isn't that a big hole?" Hold: name it as the gap to close fastest, and go back to the calendar, the checklist and the numbers. Never add to them | F9 is a gap you stated, and Larkspur (S3) puts it in the middle of this team's next year. EXP because it scores honest self-assessment of what was actually you |
| B2 | "Your calendar covered your main title. This role runs two. Why would that scale?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote at its own scope: weekly, your main title, two years. Answer slot from F1: if choosing what went into each drop and when was yours, say how you decided. If not, say so plainly and stay with running it. On the second title, say how you'd approach it, as a plan. Never claim to have run more than one | F1 is the headline requirement and the clearest scope gap. JD because it scores the stated responsibility |
| B3 | "You've never led a team. This job coordinates design, art, engineering and community on every update. How?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Concede plainly: "I haven't led a team." Hold: the JD asks for coordination, and you ran the weekly content-drop calendar. Answer slot from F2: if a drop depended on any of those teams and landing it was part of your job, say which teams and what your part was. If not, say so plainly and describe how you'd coordinate without line authority, as a plan. Hold through two follow-ups, and never upgrade coordination into leadership | F2 is thin and your stated negative invites the pairing. JD because coordination is a listed duty |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: a time a planned drop changed, or should have, because of how players responded. It needs the plan, the player signal, what you did or recommended, and the outcome. If no such time comes to mind, say so plainly. Then give the nearest thing your material carries, the weekly calendar you ran, or how you would handle it | The value states "when the calendar and the players disagree, the players win" (S1). VAL because it's scored against that wording |
| C2 | "Ship the Patch Not the Promise: tell me about a time you had to say something wasn't ready." | VAL | [grounded] | Selection scaffold: a time you said a drop or release wasn't ready, or corrected what was being announced. It needs the stake, what you said and to whom, and what shipped. If no such time comes to mind, say so plainly. Then give the nearest thing your material carries, or how you'd handle it | The value states "we announce what is built, not what is hoped" (S1), and his talk makes the same point (Reading the interviewer). No story of yours is assumed |
| C3 | "Leave the Build Greener: tell me about the release checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story mapped on F4: you wrote it, and QA still uses it. Tell those two beats in your own words. Answer slot: the value says every release leaves "the checklist better than it found" it, so expect a probe on whether you changed it over time. If you changed it after a release, say what you changed and why. If not, or it wasn't yours to change, say so plainly and stay with having written it | Your strongest match to a published value, and the one this interviewer is best placed to probe. VAL first, EXP in delivery |
| C4 | "Community says players hate the new event. Design wants to finish the run. It's your call." | VAL | [grounded] | Treat it as a values dilemma with a case structure. Find out what "hate" means in data (participation, sentiment, churn signals), what finishing the run costs, and what a change could be (tune, shorten, add a make-good). Decide, say which value tipped it, and say what you'd tell players, honestly | Tests "Players Before Plans" (S1) live. Presupposes nothing about your past |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. What was in them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start from the quote: monthly, retention, to the studio head. Answer slot: say which measures they held, in your own words. If you prepared them, say how they were counted and which assumption behind them you'd defend least. If someone else prepared them, say so plainly. "I don't know how they were counted" is an honest branch. Never name a measure the numbers didn't hold | F7 and F3 rest on this line, and "presented" is the verb a prober tests. EXP because it's about attribution |
| D2 | "Which retention measure would you put at the top of a post-event review, and what would fool you about it?" | JD | [generic] | Name one measure and why it fits an event, for example returning players over the event window compared with a matched baseline. Then name what fools it: event participants were already your most engaged players, seasonality, and cohorts that don't match. Say that the selection effect is the one you'd distrust first | The JD's retention and KPI lines, scored as judgment. A role-family pattern |
| D3 | "How do you know an event worked?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Define success before launch: a goal, a KPI and a target. Afterwards: the result against the target, what you learned, actions, and who owns them. Answer slot from F3: if you reviewed a drop after it ran, say how. If not, say so plainly and stay with presenting the monthly numbers | The JD's post-event review line, the one you own on day one |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds. The job asks for three-plus years producing live-service games. Make your case." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, then say it in this order: four years as an associate producer at a puzzle-game studio, and for the last two years the weekly content-drop calendar for your main title. Keep "associate". Answer slot from F5: if the game was run as a live service, say so in your own terms. If not, say so plainly and stay with the weekly drops. Stop at sixty seconds | F5 is the listed years requirement. Graded as fit, not a gate. JD because it's the stated requirement |
| E2 | "That's too slow, players are leaving now. What's the one thing you do first?" | CASE | [generic] | Don't restart. Pick one action (stop the bleed: extend the timer, or grant rewards server-side), give one reason, then name the next step. Composure is the score here | The likeliest interruption inside A1 |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in four beats, each as your quote says it: four years as an associate producer, the weekly calendar, the checklist QA still uses, and the monthly retention numbers. Close with why this role, in your own words. The pack can't supply your reason | Likely opener. Casual, but still scored |
| G2 | "How do you keep everyone in the loop on an update? What do you actually write?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Lead with F8's words: the release checklist you wrote is still the one QA uses. Answer slot: the JD asks for clear written communication. If you also wrote status notes or updates for the calendar, say what they were. If not, say so plainly and stay with the checklist | Covers the JD's writing requirement in a casual register |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Art says the event assets are a week late. Engineering won't move the release. What do you do?" | CASE | [generic] | Find out what's actually late and whether a reduced version could ship. Get art and engineering in the same conversation. Lay out the options (slip the event, ship with placeholders, swap in a ready event) with what each costs players. Decide or escalate with a recommendation, then tell community | The JD's coordination line as a live seam problem |
| H2 | "How do you work with QA on a release?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story mapped on F4: you wrote the checklist, and QA still uses it. Answer slot from F4: if you also ran it with QA on releases, say how. If that was someone else's job, say so plainly and stay with having written it | The interviewer was a QA lead (Reading the interviewer). JD because it's a listed duty |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A3, B2 |
| Coordinate design, art, engineering and community | B3, H1, A1 |
| Own the post-event review and its KPIs | D3, A5, D2 |
| Manage the release checklist with QA | H2, C3 |
| 3+ years producing live-service games or apps | E1, G1 |
| Experience running a content calendar | B2, A3 |
| Comfortable with player-retention metrics | D1, D2, A5 |
| Clear written communication | G2, A1 |

## Values cheat sheet

| Value (official name, S1) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | Player response overrides the schedule | Selection scaffold (C1): a drop that changed, or should have, because of player response. If none comes to mind, say so plainly, then give the nearest thing: F2/F6's "I ran the weekly content-drop calendar for our main title for the last two years." |
| Ship the Patch Not the Promise | Announce only what's actually built | Selection scaffold (C2): a time you said something wasn't ready. If none comes to mind, say so plainly, then explain how you would handle it |
| Leave the Build Greener | Each release improves the code and the checklist | F4: "Wrote the release checklist our QA team still uses." Whether you improved it over time is C3's answer slot |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from QA lead to running live ops. What from QA do you still lean on most when you plan an event?" | It's tied to his own career path, and it opens the checklist conversation on his terms |
| R2 | "Your GDC talk is described as judging a live team by how often its patch notes match what shipped. How does that show up in a post-event review here?" | It shows you researched him, and it connects his idea to the review you'd own |
| R3 | "With Larkspur putting both titles on one calendar in February, which titles does this role cover, and how does the job change after February?" | Current homework, and it clarifies the JD's "two of our mobile titles" |
| R4 | "What does a good post-event review look like today, and which KPIs does it report?" | It's the part of the job you'd own, asked as someone ready to run it |
| R5 | "Who owns the release checklist now, and what would you want changed in it in the first quarter?" | It speaks to Leave the Build Greener and your strongest evidence |
| R6 | "What would make the first 90 days a success for you?" | It gives you his scorecard in his own words |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar, or ran one across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says a weekly content-drop calendar for your main title. B2's slot stays inside that calendar |
| Owned post-event reviews and their KPIs | Inflated form of F3 | F3's quote at its own scope. D3's slot asks only whether you reviewed a drop |
| Built or calculated the retention numbers | Inflated form of F3 and F7 ("presented") | The quote as written. D1's slot asks whether you prepared them |
| Managed the release checklist with QA on every release | Inflated form of F4 ("wrote") | F4's quote at its own scope. H2's slot covers the rest |
| Four years producing live-service games, or "producer" without "associate" | Inflated form of F5 | F5's quotes as written. E1's slot asks about live service in your own terms |
| Has led a team | A negative you stated (F2) | "I haven't led a team." No slot |
| Has worked on in-app purchases, monetised events or a season pass | A negative you stated (F9) | "I haven't worked on a game with in-app purchases." No slot |

## Sources

- **Provided:** the JD and your background, both from your message
- **S1:** search "Saltmarsh Games values" returned https://saltmarshgames.com/values. Fetched: three values with one-line definitions
- **S2:** search "Saltmarsh Games interview process producer" returned https://saltmarshgames.com/careers/interviewing. Fetched: a recruiter call, then "the Outage Hour", a 60-minute interview with the hiring manager made up of a live-incident tabletop and then a values conversation, with no take-home
- **S3:** search "Saltmarsh Games mobile studio news 2026" returned https://saltmarshgames.com/news/project-larkspur (September 2026). Snippet only: Tidepool Tactics and Lantern Row move to a season pass with one shared events calendar from February 2027, and per-title event teams give way to a single live-ops group
- **S4:** search "Tobias Wrenfield Saltmarsh Games Head of Live Operations" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise. Snippet only: the talk listing and his prior QA-lead role
- **Loop:** S2 establishes the loop (one session with the hiring manager, tabletop then values), so no fallback archetype was used. A values-style round is detected

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | The values cheat sheet, the C bank and value names quoted from the official page |
| 2. `Saltmarsh Games interview process` | yes | The loop: Case and Values weighted highest, A1's format, and no deliverable section because there's no take-home |
| 3. `Saltmarsh Games` recent news | yes | Project Larkspur: A4, B1, F9 and R3 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, R1, R2 and the QA tilt on H2 and C3 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **A deeper research pass,** up to 6 more searches and 2 more fetches and several more minutes. It would read Tobias's talk and the full Larkspur announcement, and would add a strategy-grounded brief and sharper A4 and B1 material
- **Any recruiter notes on the Outage Hour** (which title the tabletop uses, and what is scored) would let A1 and A2 be retuned to the real scenario
- **Your answers to the answer slots** (F1, F2, F3, F5, F7, and C3's question about changes over time) would upgrade F1, F2, F3, F5 and F7 and the B, C, D and E rows that draw on them from slots to mapped stories
- **A copy of the release checklist you're allowed to share, even redacted,** is the inspectable artifact for a producer's writing. It would raise F4 and F8 from medium
- **A tuesday-dossier.md from job-underwriter** would replace this pack's inferred highest-ROI objection with an evidence-derived one, and would add a verified prohibited-claims list. This pack doesn't need one
