Reading the skill's research and evidence rules, then I'll build your pack.
I've built your prep pack for Thursday's 45-minute conversation with the hiring manager. It's 22 practice questions across the interviewer styles you're likely to meet, each with answer guidance.

**The one to rehearse most is A1**, the objection your dossier named: "You have never held the PM title or owned a roadmap — why should we hire you into one…?" The guidance works in four steps:

1. **Concede plainly:** you haven't held the title and haven't owned a roadmap.
2. **Bridge, as adjacent work:** quote your verified evidence at its own scope, the 30+ client integrations and the quarterly roadmap-input sessions.
3. **Give a ramp plan:** say what you'd learn first, framed as a plan, not as something you've done.
4. **Stop:** let the hiring manager decide what it adds up to.

**Other things the pack does:**
- **Gaps:** every sentence about your past is quoted from your dossier's verified evidence. Where it doesn't settle something (API docs and schemas, engineering and sales stakeholders, agile delivery), you get two honest branches to answer in your own words. Nothing is filled in for you.
- **Claims to avoid:** it lists your dossier's three ruled-out claims, plus four stretched versions of your own evidence I added. "Shipped an API product" and "shaped the roadmap" are two of them.
- **Questions to ask them:** it carries your dossier's two open risks, the squad leads' authority and the adoption baseline, into the questions you ask at the end. There are four more besides.

**No company research ran.** All three web searches were refused because search permission isn't granted. So the Quartzline-specific questions (why Quartzline, and the live problems on adoption, partners and specs) are general to the role, not specific to Quartzline. The pack has no values section, because I couldn't read their values page. If you grant search permission, I can re-run those three searches and update the affected sections.

Files are in the working directory:
- Quartzline_product-manager-platform-apis_interview_pack.md

Say the word and I'll play the hiring manager on A1, the Skeptic question, with live follow-ups.
I can also update your tuesday-dossier.md with the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday. Interviewer's name not given.
**Built from:** your `tuesday-dossier.md` (v1.1, generated 2026-08-14). No web research ran: all three searches were refused (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question arrives: the tone, the pressure, who is asking. **Types** describe *what* it scores.
- **Type key:**
  - **VAL**: values and behaviour, meaning whether your past conduct shows what the company says it values
  - **EXP**: experience deep-dive, meaning whether your claims hold up and which part was actually yours
  - **JD**: role-driven, meaning whether you can do the listed job, gaps included
  - **CO**: company and strategy, meaning how much homework you did and whether you can think at the company's level
  - **CASE**: a live problem from the role, scored on structure and reasoning
- **Provenance labels:** `[grounded]` means it traces to your dossier. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` is a role-family pattern with no claim about you or Quartzline.
- **The guidance is scaffolding, not a script.** Every sentence about your past is quoted from your dossier's verified evidence. Where the material doesn't settle something, you get an **answer slot** instead: an instruction with two honest branches that you fill in your own words during the interview.
- Question IDs go letter by persona. **F** is skipped because F1–F8 are the fit-snapshot rows.

---

## Fit snapshot

The requirements are from your dossier's `role_profile`, which stands in for the JD. The evidence is quoted exactly from `verified_candidate_evidence`. The confidence notes the dossier attached to each entry are in the Confidence column, not in the quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (must have) — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | transferability | The dossier sets the strategy as bridge, with one condition: position this as adjacent work, never as PM experience. Open with the plain acknowledgment that `prohibited_claims` supports: "I haven't held a product manager title." Then the two quotes at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping, requirements and architecture through UAT and go-live. I also ran quarterly roadmap-input sessions feeding client evidence to product." The dossier marks the roadmap sessions as confirmed but with limited inspectable proof. Say yourself what you can and can't show for them, before you're asked. Don't tell the interviewer what this proves. Let them draw the inference |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibility; dossier area "Owning a roadmap and prioritization authority (R1 sub-claim)" | none given | none | [grounded] | capability | The dossier records this as `acknowledge_gap`, so there is no bridge and no answer slot. Words, sourced from `prohibited_claims`: "I haven't owned a product roadmap." Follow it with a ramp plan, said as a plan and never as something you've done. For example: learn which roadmap calls belong to this role and which belong to the squad leads, get the current adoption baseline, and sit in on partner discovery early. Don't add anything to make the gap feel smaller |
| F3 | "Shipped API or platform products" (must have) — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | high | [grounded] | transferability | High confidence: the dossier marks it inspectable, with the integration playbook provided. The material shows integrations of the vendor's APIs, not shipping an API product, and your words stay at that scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through go-live." Answer slot: the shipped-products line makes a probe on what those go-lives involved likely. If requirements from an integration went back to the team that built the API, say which and how, in your own words. If none did, or that wasn't yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" (important) — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [inferred] | discovery | Derived from the quotes: integration architecture on REST APIs touches docs and schemas, but neither quote says you worked with them. Answer slot: if your scoping or architecture work, or the playbook, had you reading or writing API docs or schemas, say which and how, in your own words. If it didn't, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" (important) — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | discovery | Derived from the quotes: they name clients and product, and they don't name engineering or sales. Answer slot: for each group the requirement names, if your integrations or the roadmap-input sessions had you working with them, say who, and what you handled, in your own words. If a group wasn't part of the work, say so plainly and stay with the clients and product that the quotes carry. The roadmap-input sessions carry the dossier's medium-confidence caveat, so expect a probe on them |
| F6 | "Agile delivery experience" (preferred) — dossier role_profile R5; dossier area "Agile delivery inside a product org (R5)" | none given | low | [grounded] | discovery | The dossier sets the strategy as clarify. No verified entry speaks to agile delivery itself. Answer slot: the JD's agile-delivery line makes the probe likely. If you have worked in an agile way, say how, in your own words. If you haven't, say so plainly. Either way, add: "Here's what I'd want to confirm about how your squads define it" |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibility | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | high | [grounded] | transferability | The material shows scoping and requirements for client integrations, not product discovery with partners, and the words stay at that scope: "I led the scoping and requirements on 30+ client integrations." Answer slot: if scoping meant you ran the sessions with clients that worked out what they needed, say how, in your own words. If scoping worked differently, say so plainly and describe it as it was |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibility | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | high | [grounded] | transferability | The material shows integration requirements and a playbook, not product specs, and the words stay at that scope: "I led requirements on 30+ client integrations, and I wrote the internal integration playbook my team uses." Answer slot: if requirements you wrote went to engineers who built from them, say how that handoff worked, in your own words. If it didn't work that way, say so plainly and stay with the requirements and the playbook |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years PM experience | A1, A2, A4, E1 |
| R1 sub-claim: roadmap ownership | A1, A2, B4 |
| R2: shipped API or platform products | A3 |
| R3: technical fluency, API docs and schemas | D3, C2, B5 |
| R4: stakeholder management | H2, H1 |
| R5: agile delivery | A5 |
| Discovery with partners | C3, B3 |
| Specs and delivery with two squads | B5, H1 |
| Adoption metrics | B1, B2 |

---

## Persona table

The loop comes from your own words: one 45-minute conversation with the hiring manager. There is no interviewer profile, so the weights start from the hiring-manager prior (Case/Strategist plus Skeptic). Your dossier adjusts them.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the PM-title gap and of roadmap ownership | **High.** The hiring-manager prior, plus your dossier names this objection outright. A manager hiring into a PM title will test the gap | Rehearse A1 until it's boring. Acknowledge, bridge with the quotes at their scope, then give the ramp plan. Never bluff a roadmap |
| Case / Strategist | Live problems on adoption metrics, partner conflicts, specs, your first 90 days | **High.** Hiring managers buy capability by watching you think on their actual roadmap, and the JD names adoption metrics and specs | Clarify, then objective, segments, approach, metrics, risks. Think out loud. Challenge one premise respectfully per case |
| Data-Driven Prober | "30+ — how was that counted?" and "What's in the playbook?" | **Medium.** A specific figure and an inspectable artifact draw probes | Know how the 30+ was counted, or say plainly that you don't. Offer to walk through the playbook |
| Conversational | "Walk me through the journey" and "What drew you here?" | **Medium.** You described it as a conversation, so expect casual questions that are still scored | A pre-built 90-second arc (D1). Treat casual API questions as scored |
| Pressure | Time-boxed "why you" and "how much was actually you" | **Low.** Nothing points to a stress-style interviewer, but the title gap invites one sharp moment | Pause, restate the question, hold on the quotes, concede only something real |
| Values / Behavioral | "Tell me about a time…" prompts | **Low.** You named no values round, and Quartzline's values page could not be researched | Selection scaffolds with honest branches (G1, G2) |
| Peer Evaluator | The squad-lead seam, coming from the manager | **Low as a persona, but the topic matters.** Authority between this PM and the two squad leads is the dossier's open risk | Propose seam principles and ask the authority question. Never claim you've set a squad's priorities |

---

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | **The highest-ROI prep in this pack. Your dossier named this objection.** 1) Concede first, plainly: "That's right. I haven't held the PM title, and I haven't owned a roadmap." 2) Bridge, positioned as adjacent: "What I have done: I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live. And I ran quarterly roadmap-input sessions feeding client evidence to product." Say yourself what you can and can't show for those sessions. 3) Ramp plan, as a plan: what you'd learn first (which calls are yours and which are the squad leads'), the adoption baseline, partner discovery. 4) Stop. Let them decide what it adds up to. **Follow-up 1** ("Wouldn't a three-year PM be safer?"): hold. Go back to the same two quotes. Don't add to them and don't argue. **Follow-up 2** ("So who decided what got built?"): concede specifically: "I haven't set prioritization for an engineering squad." Then offer your question about which roadmap decisions this PM makes alone | F1 and F2 are the role's must-have gap, and the underwriter named this exact objection. The negatives in it all trace to `prohibited_claims`, so it is asked as written. JD because it scores R1 directly |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap" | Name it before they do: roadmap ownership. "I haven't owned a product roadmap." Then the F2 ramp plan, as a plan: the first decisions you'd want to understand, who you'd learn them from, and how you'd know you were getting it right. Don't follow it with a bridge, because there isn't a credible one for this gap and inventing one live is how candidates get caught | F2 is an `acknowledge_gap` area. Naming your own weakest point is the most credible answer this question allows. JD because it scores self-assessment against the listed duties |
| A3 | "I don't see shipped API products in your background — how would you approach shipping one here?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Don't dispute the observation. Give the quote at its scope: "I led 30+ client integrations of the vendor's REST APIs, through go-live." Answer slot: if requirements from those integrations went back to the team that built the API, say which and how, in your own words. If none did, say so plainly and stay with the integrations. Then answer the forward-looking half as a plan: how you'd approach the first release, what you'd check with partners first, and what would count as shipped | F3 is the second must-have, with adjacent evidence only. "Shipped an API product" is on the prohibited list as an inflated form, so the slot stays inside the integrations |
| A4 | "Why move into product management now?" | JD | [generic] | This is your motivation, and only you can supply it. Pick the reason that's actually true for you and give it in two or three sentences. A strong answer names a pull towards the PM work itself, not only a push away from the current role. If the roadmap-input sessions are part of the reason, describe them in the dossier's words ("feeding client evidence to product") and don't call them product decisions | The Skeptic tests whether your motivation holds together. No quote states your motivation, so the guidance is a scaffold. JD because it tests fit with the role's direction |
| A5 | "What's your experience of agile delivery inside a product org?" | JD | [grounded] | Answer slot: the JD lists agile delivery as preferred, so expect this. If you have worked in an agile way, say how, in your own words. If you haven't, say so plainly. Either way, follow with: "Here's what I'd want to confirm about how your squads define it", then ask about their cadence and where the PM sits in it | F6, a `clarify` area. No verified entry speaks to it, so the cell coaches a question-shaped answer. It's only preferred, so keep it short |

### B. Case / Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner adoption of our APIs has gone flat. Diagnose it — what do you need to know first?" | CASE | [generic] | Clarify first: how adoption is measured, and against what baseline. Then segment partners (new or established, by integration type). Walk a funnel: access, first successful call, production traffic, sustained use. Form hypotheses at each drop (docs, onboarding friction, missing capability, partner priorities). Say what you'd look at to test each one, then name one risk. Think out loud | The JD names adoption metrics and the dossier says there's no stated baseline, so this is a natural live problem. `[generic]` because the structure is a pattern, not a claim about Quartzline |
| B2 | "How would you define and track adoption metrics for this platform?" | CASE | [generic] | Tie each metric to a decision it would inform. Use a small set: a leading indicator (time to first successful call), a core one (active partners with production traffic), and a quality check (error or support rates). Name the metric you'd trust least and why. Close by asking what they track today | It's a listed responsibility, and the dossier flags that no baseline is stated. JD content delivered as a CASE. `[generic]`, as above |
| B3 | "Two integration partners want conflicting changes to the same endpoint. How do you decide?" | CASE | [generic] | Clarify what each partner actually needs, as opposed to what they asked for. Look at the impact on other partners and on backward compatibility. Look for an option that serves both (versioning, a new field, a config flag). If there's still a real trade-off, set out the decision criteria, say who you'd bring in (including the squad leads), and say how you'd tell the partner who loses | It tests discovery and stakeholder handling live. It asks about no past, so it makes no claim about yours. `[generic]` |
| B4 | "Sketch your first 90 days in this role — what do you need to know first?" | CASE | [generic] | First 30 days: learn the platform, the partners and the squads, and get clear on which roadmap decisions are yours and which belong to the squad leads. Days 30–60: partner discovery conversations and the adoption baseline. Days 60–90: a first prioritised proposal, reviewed with the squad leads. All of it said as a plan. This is where your ramp plan for F2 lives | It gives the F2 ramp plan a natural place to land. `[generic]` because it's a planning pattern |
| B5 | "Walk me through how you'd write a spec for a new partner-facing endpoint." | CASE | [generic] | The problem and the partner evidence behind it, use cases, request and response schema, errors and edge cases, auth, versioning and deprecation, docs and examples, acceptance criteria, rollout, and the success metric. Say that the schema and the docs are part of the spec itself | It covers the specs responsibility and R3 live. If they ask how this compares with what you've done, use F8's bridge and its slot |

### C. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slots, each in your own words. First, how the figure was counted. Second, what it's sensitive to, meaning what would move the number. Third, the assumption behind it you'd defend least. Fourth, which part was yours, keeping to the quote's verb: led. If you don't know how it was counted, say so plainly. Give the number you can actually stand behind | Rule: every headline figure gets a defend-the-number question. F1, F3, F7 and F8 all rest on this quote, so it has to hold |
| C2 | "Tell me about the integration playbook you wrote — what's in it, and how is it used?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the quote gives: you wrote it, it's internal, and your team uses it. The dossier marks it inspectable, so offer to show it if that's appropriate. Answer slot: if the playbook covers API docs or schemas, say how, in your own words. If it doesn't, say so plainly and describe what it does cover | It's your one inspectable artifact, so it's the strongest place to show depth. The slot gives F4's discovery gap a place to be answered |
| C3 | "Tell me about those quarterly roadmap-input sessions — how did they work?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats from the quote: you ran them, they were quarterly, and they fed client evidence to product. The dossier marks them confirmed but with limited inspectable proof, so say yourself what you can and can't show. Answer slot: if you gathered the client evidence yourself, say how, in your own words. If it came from elsewhere, or there was no set method, say so plainly. If you're asked what product did with it, say only what you actually know, and don't tell it as a roadmap you shaped | It's the medium-confidence entry the dossier says to expect a probe on. "Shaped the roadmap" is on the prohibited list, so the guidance stays at the quote's scope |

### D. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc. Your path in your own words, with dates and titles exactly as your CV has them. Then the three quoted pieces of work, each at its own scope. Then one sentence on why this role is the next step. Don't put a total number of years on it unless you've checked it against your CV | The usual opener in a conversational round. It sets up A1 calmly, before the objection arrives |
| D2 | "What drew you to Quartzline specifically?" | CO | [generic] | No research ran, so this pack can't give you facts about Quartzline. Use only what you've actually read or heard yourself, and name where it came from. Connect it to the partner API platform the JD describes. If your interest is the role more than the company, say that honestly and ask them what's next for the platform | Asked in nearly every round. It's `[generic]` because the company research was refused. The upgrade menu shows how to fix that |
| D3 | "What are you working with on the API side these days?" | JD | [generic] | Pick something you're genuinely working with or reading about: tooling, specs, a pattern you've seen in integrations. If nothing current comes to mind, say so plainly, then give the nearest thing your material does carry, which is the integrations, or what you'd want to learn about Quartzline's API docs and schemas | R3 asked in a casual register, which is still scored. Selection scaffold with an honest branch |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate the question. Then one quote-backed point: the integrations, at their scope. Then one honest concession. An insider knows the platform, and you'd need to learn it, so include the ramp plan. Finish inside the time. Don't run down the internal candidate | A time-boxed form of the R1 gap. It rehearses holding your ground without getting defensive |
| E2 | "Thirty-plus integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold on the quote's verb: you led them. Answer slot: which parts of the scoping, requirements, architecture, UAT and go-live you did hands-on, and which you led others through, in your own words. If you're asked about a stage you didn't do yourself, say so plainly. Don't upgrade "led" into "built" or "designed" | It's an attribution probe on your headline figure, and the honest answer rehearsed here is the defence |

### G. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a real stake, a moment where you didn't back down, and a relationship that was still intact afterwards. Use "we" for the context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem. Quartzline's values could not be researched, so it isn't mapped to any published value |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a named customer need, a metric or target it conflicted with, and a decision you can say was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem that suits a partner-facing role. Scaffold only |

### H. Peer seam (low weight, asked by the manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "This PM works with two squad leads — where's the seam, and what happens when you disagree?" | CASE | [generic] | Propose principles rather than pretending to know their setup. For example: the PM owns the what and the why, backed by partner evidence, and the leads own the how and delivery. Disagreements get settled on criteria agreed in advance, and there's a clear escalation path. Then ask your authority question (reverse question 1). Don't claim you've set a squad's priorities | The dossier's main risk is authority versus the squad leads, and the manager may raise it before you do |
| H2 | "Tell me about a time you managed stakeholders across engineering, sales and customers." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F5. Clients, through the integrations you led, and product, through the roadmap-input sessions, are the groups the quotes carry. Answer slot: for engineering and for sales, if you worked with them on those integrations or sessions, say who, and what you handled, in your own words. If a group wasn't part of it, say so plainly and stay with clients and product | R4 is a high-priority requirement in the dossier handoff. The theme comes straight from the JD line, and the slot covers what the quotes don't |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From your dossier. The JD asserts decision authority but nothing shows it. To them, the question reads as diligence. For you, it tests whether the PM title comes with real authority |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | From your dossier. The JD names adoption metrics but states no baseline. The answer tells you whether you'd inherit a measurement system or have to build one |
| 3 | "What would make you say, six months in, that this hire was the right call?" | It shows you what success actually looks like and gives you something to tune the rest of the conversation to |
| 4 | "Where do partners get stuck most often right now: getting started, the docs, or missing capability?" | It makes you sound like someone already doing discovery, and the answer feeds straight into how you'd approach B1 |
| 5 | "How do this PM and the sales team handle commitments made to partners?" | It addresses the sales side of R4 head-on and shows whether roadmap promises get made around the PM |
| 6 | "What would someone coming from the integration side need to learn fastest here?" | It invites them to name the gap themselves, on your terms, after you've already addressed it in A1 |

---

## Prohibited claims

These are the claims this pack won't coach, in any answer, slot or follow-up.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | "I haven't held a product manager title or role." Then F1's quotes at their own scope, positioned as adjacent |
| Having owned a product roadmap | Dossier `prohibited_claims`; dossier `acknowledge_gap` area | "I haven't owned a product roadmap." Then the ramp plan, as a plan. No bridge, no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | An inflated form of F3 | F3's quote at its own scope. The pack's observation: the material shows integrations of the vendor's APIs, not shipping the API. A3's slot stays inside the integrations |
| Ran product discovery with partners | An inflated form of F7 | F7's quote at its own scope. The material shows scoping and requirements for client integrations |
| Wrote product specs, or drove delivery with engineering squads | An inflated form of F8 | F8's quotes at their own scope: integration requirements and the playbook |
| Shaped or set the product roadmap through the input sessions | An inflated form of the third verified-evidence entry | The quote at its own scope: sessions feeding client evidence to product. What product did with that evidence is said only as far as you actually know |

---

## Sources

**Provided documents**
- `tuesday-dossier.md`, envelope v1.1, generated 2026-08-14. Sections consumed:
  - `role_profile`: stood in for the JD (R1–R5, the responsibilities, and the unknowns)
  - `decision`: context only. Its summary prose is the underwriter's analysis and is not used as facts about you
  - `handoff_to_mock_interview`: every field
- `evidence_map`, `evidence_state` and `risk_register` were not in the copy you pasted, so the grading of F3, F4, F5, F7 and F8 is this pack's own.

**Searches and fetches**
- "Quartzline company values": refused (web search permission not granted)
- "Quartzline interview process product manager": refused
- "Quartzline partner API platform news 2026": refused
- No fetches sent.

**Target accounting**

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Search refused. It would have themed G1 and G2 on published values, and enabled a values cheat sheet if a values round were known |
| 2. Quartzline interview process, PM | unavailable | Search refused. Your own words establish this session, so the persona weights didn't depend on it. It would have shown what other rounds the loop holds |
| 3. Quartzline strategy and recent news | unavailable | Search refused. It would have grounded D2 and given B1 to B4 Quartzline's own vocabulary and current priorities |
| 4. Interviewer name and Quartzline | n/a | No name was given, so there was no query to form |
| 5. Representative PM, Platform APIs JD | skipped | The dossier's `role_profile` already supplies the requirements |

---

## Upgrade menu

- **Web search permission:** re-run targets 1–3. Gets you Quartzline's values by name, the loop structure, and current strategy, so D2 and the B bank stop being `[generic]`.
- **A deeper research pass (L2):** up to 6 more searches and 2 more fetches, several more minutes. Adds a strategy brief, the interviewer's talks and writing, PM loop reports for Quartzline, and recent org context. That gives you sharper CO and CASE questions.
- **The hiring manager's name:** persona weights read from their public profile, a reverse question tied to their own career path, and the interviewer-read section.
- **The recruiter's prep email:** stated focus areas, and a build section for any pre-declared deliverable.
- **How much prep time you have before Thursday:** a prioritised prep schedule tied to question IDs.
- **Your answers to the answer slots, said outside a drill:** they become quoted evidence and upgrade F3, F4, F5, F6, F7 and F8, along with the questions that draw on them.
- **Your raw CV:** dates and titles for D1's arc, and a check on every quote in this pack against the original wording.
