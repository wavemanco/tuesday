Reading the prep skill's rules before I build Dara's pack. Next, the evidence and wording checks, then I'll write it.
I've written your prep pack for the three rounds on 21 November: `ashgrove-credit-union_member-experience-lead_interview_pack.md`. There's a separate section for each round, sized to what the recruiter told you about it. I built it from what you pasted and did no web searches, because your material already covered everything I would have looked up.

- **Main objection:** your future manager (the Head of Member Services) is likely to say you've handled one branch's complaints log, haven't worked in a contact centre, and this job runs complaints across all branches and the contact centre. That's question C1, and it's the one most worth practising. The guidance is to admit the contact-centre gap before they push, stick to what you actually did, and give a plan for learning the rest. It returns under time pressure in the panel round as L1.
- **The four values:** the panel scores you on these, so the pack gives one practice question for each. None of your sentences fully supplies a story for any of them. For each value it gives a way to pick a true story from your own experience, and what to say if nothing fits.
- **The 20-minute case:** there's a rough plan for the time, three positions to argue, each with the point you should concede, and two things not to do in front of branch managers. One is taking the complaint off the branch supervisor, which goes against "Own the Fix".
- **Gaps to admit, not stretch:** you told me you haven't worked in a contact centre and haven't presented above regional level. The pack gives you plain wording for both. It also lists claims it won't help you make, like saying you ran the complaints process or coached supervisors. Your material doesn't say those things.
- **Your own detail:** your material doesn't settle five things the job description asks about:
  - what your spreadsheet tracks
  - whether it's built in Excel
  - whether the complaints on your log were regulated ones
  - whether you've helped another supervisor with an escalation
  - any work with digital teams

  Each has two honest ways to answer, depending on what's true. If you tell me the facts, I'll update those parts.

If you'd like, I'll play your future manager and ask you C1, with follow-ups that respond to what you say.
I can also save a `tuesday-dossier.md` file recording the gaps this prep found, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of interviews:** 21 November 2026, three rounds on the same day
**Round 1:** Recruiter, 30 minutes
**Round 2:** Head of Member Services (your future manager), 45 minutes, mostly behavioural
**Round 3:** Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. This is also the values round, scored against the four values.
**Interviewers:** names not assigned yet, so this pack works from their roles.

This is a loop-mode pack. The fit snapshot, coverage table and strategy vocabulary are shared. After them comes a mini-pack for each round, each with its own persona weights, questions and reverse questions. The prohibited claims, sources and upgrade menu close the pack.

---

## How to use this pack

- **Personas** describe how a question is asked: friendly, sceptical, pressured, case-led.
- **Types** describe what the interviewer is scoring:
  - **VAL**: behaviour that shows Ashgrove's published values
  - **EXP**: whether what you say about your past holds up when they probe it
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: what you know about Ashgrove's strategy and position
  - **CASE**: how you structure a live problem from the role
- **Provenance labels:**
  - **[grounded]**: traceable to something you gave me
  - **[inferred]**: this pack's own working from your material, with the derivation named
  - **[generic]**: a common pattern for roles like this, with no claim about Ashgrove or you
- **Answer slots** are instructions for your answer in the room. Use one branch or the other. They are not questions for you to answer here.
- The guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material describes one branch's formal complaints log, not a process run across branches, and your words should stay there: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" line makes a probe on how far your handling went likely. If any stage of a complaint, from arrival to close, was yours to decide, say which stage and how you decided, in your own words. If none was, or those stages sat with someone else, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | No wording closes this gap, and you have said so yourself. Words: "I haven't worked in a contact centre." Follow with how you would learn it, always as a plan and never as a past: time with contact-centre staff in your first weeks, and following how a complaint moves when it starts on the phone. Never add anything to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote is monthly and about complaints, but it doesn't say what the spreadsheet counts. Your regional manager uses it; the quote doesn't say it covers the region. Answer slot: if it tracks volumes, resolution times or both, say which, in your own words. If it tracks something else, say what it does track and how you would add the two the JD names |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message, and "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Keep it at the quotes' own scope: you trained new tellers, not supervisors, and the script was "our escalation script", not one the quote says you wrote. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on coaching peers likely. If you have helped another supervisor with an escalation, say what happened and what your part was, in your own words. If you haven't, say so plainly and say how you would adapt teller training for supervisors who already know the basics |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way here. Answer slot: if you have worked with a digital or app team, or on how members use self-service options, say what you did and which part was yours. If you haven't, say so plainly, then say what you would want to look at first: which complaints show members getting stuck when they try to serve themselves |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. This is self-reported with nothing to inspect, so expect a probe. Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor. Describe the roles in your words and let them map it onto "customer operations". Don't relabel your history in the JD's vocabulary |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | "Formal" doesn't show whether the log was a regulated process, so this row is the pack's inference and nothing more. Answer slot: if those complaints were handled under regulatory rules, say which of those rules touched your work and how, in your own words. If the log was not a regulated process, or the regulated part sat with someone else, say so plainly and describe the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You stated this one. Words: "I haven't presented above regional level." The quote doesn't say you have presented at regional level either, so don't stretch it in either direction. Then give a plan: how you would prepare the first monthly report for a senior audience, and who you would ask for a dry run |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | "Spreadsheet" doesn't name the tool. Answer slot: if it was built in Excel, say so and which parts of Excel you used, in your own words. If it was another tool, name it and say plainly how comfortable you are in Excel |

### Requirement coverage

| JD requirement | Fit row | Question IDs |
|---|---|---|
| Own the complaints process end to end across branches | F1 | A1, C1, J1 |
| Across the contact centre | F2 | B2, C1, C2, L1 |
| Monthly reporting on volumes and resolution times | F3 | G1, G2, E2 |
| Coach branch supervisors on escalations | F4 | C3, J3, K1 |
| Digital teams and self-service journeys | F5 | C4, E2 |
| 4+ years in financial-services customer operations | F6 | A1, B1 |
| Regulated complaints | F7 | G3, D1 |
| Presenting to senior leaders | F8 | B3, C2, L1 |
| Excel reporting | F9 | B4, G1 |

---

## Grounding brief: Ashgrove's own vocabulary

Each row comes from what you pasted. Use these words because they are Ashgrove's, not to recite them.

| Item | What it means for this role | Source | Provenance |
|---|---|---|---|
| "member-owned, about 900 staff" | Say "members", never "customers" | JD | [grounded] |
| "move 40% of member service to digital channels by 2028" | Self-service journeys are where this role meets the strategy. Complaints show where members get stuck | 2026 strategy brief, July 2026, as you summarised it | [grounded] |
| "consolidate eight branches into five hubs over 2027" | Branch changes during your first year in the role. Expect the panel of branch managers to care about this | Strategy brief | [grounded] |
| "launch a small-business lending product in Q1 2027" | A new product line can mean new kinds of complaint. Mention it lightly and don't over-claim | Strategy brief | [grounded] |
| "the main competitive pressure is app-only banks" | Members who are unhappy have an easy alternative, which raises the stakes of every complaint | Strategy brief | [grounded] |
| The four values, by exact name | "Members First, Always", "Plain Words", "Neighbours, Not Numbers", "Own the Fix". Learn the names word for word, because the panel scores against them | ashgrovecu.org/about/values, pasted by you on 12 November 2026 | [grounded] |

The brief is four months old, and the pack has seen only your summary of it. Quote it as "the July strategy brief" so nobody hears it as inside knowledge.

---

# Round 1: Recruiter (30 minutes)

### Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Conversational / Rapport | Friendly openers, "walk me through", why us | High. Recruiter screens run on this register. Your recruiter said "30 minutes with me" | A prepared 90-second arc. Treat every casual question as scored | [generic] |
| Skeptic (light) | Quick checks against the JD's requirements | Medium. Recruiters screen the listed requirements before passing you on | Short, plain answers on the gaps. Don't over-explain | [generic] |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log and trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in the order your sentences give: six years in retail banking, the last three as branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Close with one sentence on why this role, giving the reason you actually have | The opener of every screen. F1, F3, F4 and F6 all sit in it, so a clean arc tells the recruiter you fit the shape of the JD; EXP because everything in it can be probed later |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Name one thing from their published material that genuinely matters to you, a value by its exact name or a strategy item, and say why in one sentence. If your honest reason is mainly the role, say that. It is a fine answer | Motivation questions are scored for specificity. CO because it tests whether you read their material |
| A3 | "Why move on from the branch now?" | EXP | [generic] | Your real reason, stated forward: what you want to do next, not what you are leaving. Keep it under 30 seconds | A standard screen question. The risk is a long or negative answer |
| A4 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name two strategy items in the brief's words, for example the move to 40% digital service by 2028 and the eight branches into five hubs over 2027. Then connect one of them to complaints in one sentence. Say you read the July brief the recruiter sent | Shows you did the reading. CO, and it sets up Rounds 2 and 3 |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for 4+ years in financial-services customer operations. How does your experience line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it in your words: six years in retail banking, the last three as a branch supervisor. Stop there and let them map it. Don't relabel your past as "customer operations" | F6 is a checkbox for the recruiter, and a short answer clears it |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | "No, I haven't worked in a contact centre." Then one sentence of plan: how you would get to know it in your first weeks. Then stop. Don't fill the silence | F2 is a stated gap. A clean "no" plus a plan reads as self-aware, while a hedged answer reads as hiding |
| B3 | "Have you presented to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | "I haven't presented above regional level." Answer slot: if you have presented at regional level, say briefly what and to whom. If you haven't, say so plainly and say how you would prepare to present to senior leaders | F8 is a JD requirement you have stated you lack. It should be rehearsed before Round 2, where it returns harder |
| B4 | "How comfortable are you in Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot (F9): if the spreadsheet was built in Excel, say so and which parts of Excel you used, in your own words. If it was another tool, name it and say plainly how comfortable you are in Excel | A listed requirement, usually checked quickly at this stage. JD because it scores the requirement directly |

### Reverse questions: Round 1

| Question | Why it lands |
|---|---|
| "For the 20-minute case, will I get materials in the room, or is it spoken?" | It is practical, it shows you are preparing for the case, and the answer changes how you prepare |
| "Will I know the panel's names before the day?" | A fair process question. Names would let you sharpen your prep for the panel |
| "Is this a new role or a backfill?" | It tells you whether you would be building the complaints process or inheriting one |
| "What happens after 21 November, and when would I hear?" | Standard, and it shows you are serious |
| "Is there anything in my background you'd want me to address with the Head of Member Services?" | Brings the screen's objections to the surface while you still have time to prepare for them |

---

# Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scope gap and the contact-centre gap | High. A hiring manager is de-risking a hire, and F1, F2 and F8 are the visible gaps | Rehearse C1 until it bores you. Concede plainly, hold what you did, give a ramp plan | [inferred] |
| Values / Behavioural | "Tell me about a time…" questions | High. The recruiter said this round is "mostly behavioural" | Pick stories ahead of time using the scaffolds below. Use "I" for your part and "we" for the team | [grounded] |
| Data-Driven Prober | Pulls on the spreadsheet and the reporting | Medium. Monthly reporting is a core duty in the JD, and F3 is your nearest evidence | Know what you can and can't say about the spreadsheet. Say "I don't remember" rather than invent | [inferred] |
| Case / Strategist | A strategy question or two from their roadmap | Low to medium. It is a manager's round, but the recruiter called it mostly behavioural | Clarify, then structure, then use their vocabulary | [inferred] |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've handled one branch's complaints log and you haven't worked in a contact centre. This role owns the process end to end across branches and the contact centre. Why should I believe you can do it?" | JD | [grounded] "I handled the branch's formal complaints log" "Never worked in a contact centre" | **The highest-ROI prep in this pack.** Concede first, before they push: "I haven't worked in a contact centre." Then hold only what your words carry: "I handled the branch's formal complaints log." Answer slot: if any stage of a complaint from arrival to close was yours to decide, say which and how. If none was, say so plainly and stay with the log. Then give a ramp plan as a plan: map how a complaint moves from each branch and from the phone, spend time with contact-centre staff, and read the complaints data across branches. **Follow-up 1:** "So why would one branch scale?" Don't claim it does. Say what you would need to learn and how. **Follow-up 2:** "Wouldn't someone from a contact centre be safer?" Concede that they would know the phone side better. Hold that you know the branch side from three years as a supervisor. Don't argue that the other candidate is worse | F1 and F2 together are the most predictable objection to you. They come from your future manager, who owns the gap if you are hired. JD because it scores the headline responsibility |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Pick one and own it: "I haven't worked in a contact centre" or "I haven't presented above regional level." Then the ramp plan for that one. Don't pick a fake weakness, because they have read the JD against your background | A standard Skeptic stem. F2 and F8 are both honest answers, and choosing one shows judgement |
| C3 | "How would you coach a branch supervisor on escalations, especially one who's been doing it longer than you?" | JD | [grounded] "trained new tellers on our escalation script" "6 years in retail banking, the last 3 as a branch supervisor" | Start with what you did: "I trained new tellers on our escalation script," and you have been a branch supervisor for three years. Answer slot: if you have helped another supervisor with an escalation, say what happened and your part. If you haven't, say so plainly. Then give your approach as a plan: ask before telling, work from a real case, and agree when they should call you | F4 is a transferability gap from tellers to peers. The probe is whether you can coach people at your own level |
| C4 | "You'd be working with digital teams on self-service. What would you bring to that?" | JD | [grounded] | Answer slot (F5): if you have worked with a digital team or on self-service, say what and your part. If you haven't, say so plainly. Then give a plan tied to the brief's 40% target: which complaints show where members get stuck, and how you would bring that to the digital team monthly | F5 is silent in your material, and the strategy makes it live. JD because the responsibility is listed |

### Bank D: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a member's complaint put the rules and the member's interest in tension." | VAL | [grounded] | Selection scaffold. Choose a complaint where you had to decide something, where there was a real tension, and where you can say what you did and why. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle it | Combines "Members First, Always" with the JD's regulated-complaints line (F7). Behavioural, as the recruiter described this round |
| D2 | "Tell me about a time you found a problem nobody had asked you to fix." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot drawn from "Own the Fix": if you built the spreadsheet because something was missing or broken, that may be your story, so say what was missing and what you did, in your own words. If it wasn't built for that reason, pick another time using the same test: you found it, you kept hold of it, and it got solved. If none comes to mind, say so plainly | This tests "Own the Fix" ahead of the panel. F3 is the nearest material, but it doesn't say why the spreadsheet was built |
| D3 | "Tell me about a time you had to escalate something above your branch." | EXP | [generic] | Selection scaffold. Choose a time with a clear reason to escalate, a clear point where you handed it on, and an outcome you know. If none comes to mind, say so and describe how you would decide when to escalate | Escalation runs right through the JD. EXP because the manager will probe what your part was |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're consolidating eight branches into five hubs over 2027. What does that mean for complaints, and what would you do?" | CASE | [grounded] | Clarify first: the timing, which towns are affected, and how members will be told. Then give hypotheses, labelled as hypotheses: complaint types may shift around access and travel. Plan: brief the supervisors in affected branches before each change, watch those branches in the monthly report, and write member communications in plain words. Tie it to "Neighbours, Not Numbers" in one sentence. Make no claim about your past | Built on the brief, so it is a differentiator question. CASE, with CO content |
| E2 | "We're moving 40% of member service to digital by 2028. How should complaints data shape that?" | CASE | [grounded] | Structure: what to measure (complaints that start in, or come from, digital journeys), how to feed it monthly to the digital teams, and one risk, members who don't want to move channel. Name the weakest assumption in your own plan: complaints only capture the members who bother to complain | Links F3 and F5 to strategy. CASE because it is a live problem from the role |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built. What's in it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what you built and who uses it, in those terms. Answer slot (F3): if it tracks volumes, resolution times or both, say which. If not, say what it does track. Answer slot (F9): name the tool. Don't describe columns or formulas you can't remember. "I'd have to check" is an honest answer | Your strongest JD-adjacent artefact, and a prober will go straight to it. EXP because it tests what the spreadsheet actually contains |
| G2 | "How would you measure resolution times across branches and the contact centre?" | JD | [generic] | Give a definition as a plan: when the clock starts and stops, and what counts as resolved. Then name your weakest assumption before they do: a phone complaint and a branch complaint may not start the clock at the same moment. Make no claim that you have measured this before | The JD names resolution times outright. JD because it scores the reporting duty |
| G3 | "This role handles regulated complaints. What's your experience of that?" | JD | [inferred] "I handled the branch's formal complaints log" | Say what you handled, in those words. Answer slot (F7): if those complaints were handled under regulatory rules, say which rules touched your work and how. If the log wasn't a regulated process, or that part sat elsewhere, say so plainly and say how you would get up to speed on Ashgrove's obligations | A hard requirement, and F7 is thin. Rehearsing the honest version here stops you stretching "formal" into "regulated" live |

### Reverse questions: Round 2

| Question | Why it lands |
|---|---|
| "Where does the complaints process break today between branches and the contact centre?" | Turns C1 around. It shows you are already thinking end to end, and the answer tells you the real job |
| "What would you want from this role during the move to hubs in 2027?" | Ties you to their biggest operational change |
| "Who sees the monthly report, and what do they do with it?" | Brings F8 into the open on your terms, and tells you who the senior audience is |
| "What would good look like at six months?" | It is your manager, so set expectations early |
| "How do complaints and the digital teams work together today?" | Shows you read the self-service line and the 40% target |

---

# Round 3: Panel of two branch managers (60 minutes, includes the 20-minute case and the values round)

### Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Values / Behavioural | Questions themed on the four values, scored | High. The recruiter said "they score against the four values" | Choose one story per value ahead of time, using the cheat sheet below. Use the value names lightly | [grounded] |
| Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter named it | Use the case build below: clarify, member, supervisor, pattern, close | [grounded] |
| Peer Evaluator | "What would you need from our branches?" Seam and credit questions | Medium. These managers' supervisors are the people you would coach | Offer something back to them. Propose working principles rather than pretending to know their branches | [inferred] |
| Pressure | Time-boxed pushback during or after the case | Low. A case round commonly adds pressure in the follow-ups | Pause, restate, hold through two follow-ups, then concede what is real | [generic] |

### Values cheat sheet

| Value (official name) | Working meaning | Your story |
|---|---|---|
| Members First, Always | Decide from the member's side, even when that is harder for the branch | Selection scaffold. Choose a complaint or member decision where the easier option for the branch was not the right one for the member, and you chose the member's side. If none comes to mind, say so plainly and describe how you would decide |
| Plain Words | If it needs explaining twice, rewrite it | F4: "trained new tellers on our escalation script". Answer slot: if training tellers on it ever meant rewording something until it landed, that is your story, told in your own words. If not, choose another time you made something clearer for a member or colleague, or say so plainly |
| Neighbours, Not Numbers | A branch belongs to its town | Selection scaffold. Choose a time you treated a member as a person in your community rather than a case. If none comes to mind, say so, and say what this value means to you for the hub consolidation |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3: "I built the monthly complaints spreadsheet our regional manager uses". Answer slot: if you built it because something was missing, say what, and how you saw it through. If not, choose another problem you found and kept hold of, or say so plainly |

### Bank H: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Use the cheat-sheet scaffold for "Members First, Always". Give what was at stake, what you chose and why, and how it turned out. If no such time comes to mind, say so and give the nearest thing you have | The value's own wording. The panel scores this value directly |
| H2 | "Tell me about a time you had to explain something so that it landed the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Answer slot: if training tellers on the script involved rewording or simplifying it, tell that, keeping your part to what was yours. If not, choose another time, or say so plainly | Tests "Plain Words". F4 is the nearest material, but it doesn't carry the story's middle, so the slot holds it |
| H3 | "Tell me about a time you treated a member as a neighbour, not a number." | VAL | [grounded] | Use the cheat-sheet scaffold for "Neighbours, Not Numbers". Make it specific and small. If no such time comes to mind, say so and say how you would protect this during the move to hubs | Branch managers will weigh this value heavily, with branches closing |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Use the cheat-sheet slot for "Own the Fix". The beats are that you found it, you kept it, and it got solved. Never claim more than the spreadsheet quote carries | It is the value the case will test too, so get the story clean first |

### Graded deliverable: the 20-minute complaint-escalation case

**What is grounded:** the recruiter said "a 20-minute case on a complaint escalation" and that the panel "score against the four values". The panel is two branch managers. Branches move to five hubs over 2027, and app-only banks are the main competitive pressure. **[grounded]**

**What you can say about yourself:** F1, "I handled the branch's formal complaints log", and F4, "trained new tellers on our escalation script". Use them as context only, at their own scope.

**Rough shape for 20 minutes** **[generic]:**

1. About 2 minutes clarifying:
   - What does the member want?
   - How long has the complaint been open?
   - Is it already formal?
   - Which channel did it start in?
   - Is there any sign the member is vulnerable?
   - Is a deadline close?
2. About 4 minutes on the member now.
3. About 5 minutes on the supervisor and who owns the complaint.
4. About 5 minutes on whether this is a pattern.
5. About 2 to 3 minutes closing, leaving room for their questions.

| Thesis | Mandatory concession | Provenance |
|---|---|---|
| Put the member first, with the process alongside: contact the member quickly, in plain words, and say what happens next | Regulated steps can't be skipped to move faster. Run both at once | [grounded] |
| "Own the Fix" means the supervisor keeps hold of the complaint, and your job is to coach them through it, not take it off them | Some escalations do need you to step in, for example a deadline at risk or a vulnerable member. Name your triggers rather than pretending you never would | [grounded] |
| One escalation is a data point. Check the log across branches before changing the process, and put it in the monthly report | If it is a clear harm, fix it now and don't wait for a trend | [inferred] |

**How to differentiate** **[generic]:** the consensus answer is to apologise, investigate, resolve and follow up. Say that in one line to show you know it, then go further on three things:

- who keeps hold of the complaint
- what you would check in the data
- how the reply to the member is written

**What not to do** **[generic]:**

- Don't promise an outcome or compensation in the room before you have the facts.
- Don't take the case off the branch by reflex. That is the opposite of "Own the Fix", in front of two branch managers.

**Close:** they score against the four values. In the last minute, say in one sentence each which values your plan acted on. Use their names once each and don't recite the slogans. **[inferred]** This close is the pack's reading of the recruiter's note; the recruiter named no requested close.

### Bank J: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member's complaint has escalated from one of our branches. Take us through what you'd do." | CASE | [grounded] | Use the case build above: clarify, then the member, the supervisor, the pattern check and the close on the values. Think aloud. Challenge one premise politely, for example whether the complaint has been made formal | A rehearsal of the announced case. CASE is the format, and the values are scored inside it |
| J2 | "Midway through, the member says they're moving to an app-only bank. What changes?" | CASE | [grounded] | Don't panic or bargain. Keep fixing the actual problem, in plain words. Say what you would note for the monthly report. You can name app-only banks as the pressure the strategy brief describes | A likely twist, given that the brief names app-only banks |
| J3 | "The branch supervisor says they followed the escalation script. What do you say to them?" | CASE | [generic] | Coach, don't blame. Ask what the script told them to do and where it didn't fit the case. Agree what you will both do next. If the script itself is the problem, say you would take that on, which is "Own the Fix" | Tests F4's duty live, in front of the supervisors' managers |

### Bank K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You'd be coaching our supervisors. What would you need from us, and what would you give us?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Lead with what you would give: support on escalations, and a monthly view of complaints by branch. What you would need: time with their supervisors, and an agreed point where they call you. You can say you have been a branch supervisor for three years, which is all the quote says, and let them draw the connection | Branch managers are weighing whether you add to their load or take some off it. JD because it is the coaching line |
| K2 | "What happens when you and a branch manager disagree about how a complaint should be handled?" | VAL | [generic] | Selection scaffold. Choose a time you disagreed with someone more senior, held your view, and kept the relationship. If none comes to mind, say so plainly and describe your approach: the member's side first, then the facts, then escalate together, not around them | Tests whether you have both spine and tact. VAL because it reads against "Members First, Always" |

### Bank L: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Thirty seconds: you haven't worked in a contact centre and you haven't presented above regional level. Why you?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" "6 years in retail banking, the last 3 as a branch supervisor" | Pause. Concede both plainly in one breath. Then hold: six years in retail banking, the last three as a branch supervisor, and the branch's complaints side. If they push twice, keep the same position and concede nothing new. "Those are real gaps, and here is how I'd close them" is the honest close | C1 again under a time limit. A pressure answer is scored on holding without getting defensive |

### Reverse questions: Round 3

| Question | Why it lands |
|---|---|
| "What could the Member Experience Lead do in the first month that would genuinely help your branches?" | A reciprocity question. Branch managers are pricing what you cost them and what you give them |
| "When a complaint escalates from your branch today, where does it get stuck?" | Grounds you in their reality, and it is the case they set you, turned back to them |
| "How are you thinking about members during the move to hubs?" | Shows "Neighbours, Not Numbers" in action and respects that this is their change |
| "What do your supervisors find hardest about escalations?" | Tells you the real coaching job and signals you would listen first |
| "Which of the four values is hardest to live by on your busiest day?" | Invites candour, and it fits a panel scoring the values |

---

## Prohibited claims

Each line below is wording the pack won't coach. The honest form shows what to say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process, across branches or end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's own observation is that this covers one branch's log, not a process. Every slot stays inside the log |
| Coached or trained supervisors | Inflated form of F4 | "trained new tellers on our escalation script." The slot asks only whether you have helped another supervisor |
| Wrote or designed the escalation script | Inflated form of F4 | The quote says "our escalation script", and that you trained new tellers on it |
| Built or owns the region's complaints reporting | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." Your regional manager uses it; the quote doesn't say it covers the region |
| Has contact-centre experience | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | "I haven't presented above regional level." No slot |

---

## Sources

**Provided documents:**

- the JD, pasted
- Ashgrove's four values, pasted, copied on 12 November 2026 from ashgrovecu.org/about/values (not fetched by me)
- the recruiter's email describing the three rounds, pasted
- your summary of Ashgrove's 2026 strategy brief, published July 2026 and sent by the recruiter
- your background, in your message

**Searches and fetches:** none sent. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values you pasted, copied from the official page this morning, fix the cheat sheet and Bank H |
| 2. Ashgrove interview process for member-services roles | skipped | The recruiter's email establishes all three rounds, including the case and the values scoring, and so fixes the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 strategy brief is under six months old and fixes the grounding brief, E1, E2 and J2 |
| 4. Interviewer names | n/a | No names have been assigned, so there was no query to form. The interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

---

## Upgrade menu

- **Interviewer names, once assigned:** an interviewer read for each person, persona weights for each panel member, and at least one reverse question tied to each person's career path.
- **Your answers to the answer slots in F3, F4, F5, F7 and F9:** say them here, outside a drill, and those rows regenerate. A confirmed answer on F7 or F3 could turn G1, G3 and C1 into fully story-mapped answers.
- **Which regulator and complaint rules apply to Ashgrove:** a recruiter email or a deeper research pass would let the case build name the actual deadlines and steps rather than "whatever applies".
- **The strategy brief itself, not just your summary:** exact figures and wording for the grounding brief, and possibly more CO questions.
- **A deeper research pass, L2:** up to 6 more searches and 2 more fetches, several more minutes. It covers recent news about Ashgrove's branch changes and leadership, and published loop reports for this role family. It would sharpen E1, J2 and the reverse questions.
- **A blank layout of your complaints spreadsheet, with no member data and only if your employer's rules allow:** this is the artefact that would raise F3 and F9 from medium, and it gives you something concrete to describe in G1.
- **A dossier from job-underwriter:** verified evidence and a named top objection to replace this pack's inferred ones. It is not needed for this pack.
