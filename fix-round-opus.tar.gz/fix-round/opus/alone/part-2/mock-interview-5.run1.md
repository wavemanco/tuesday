Building your prep pack now. I've read the skill's rules, and next I'm running a few targeted searches on Kelverton Rail and the panel.
I've saved your prep pack at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-5-denied-41493193/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it from your message and the recruiter's email only. I don't have the job description, your CV or the contents of the market report, and the web searches I tried were blocked. So anything about Kelverton or the rail market is marked as a general pattern for you to check against the report, not a fact about Kelverton.

**How the pack is set up:**
- **Format and weighting:** the pack follows the format the recruiter described. Deepa will mostly probe your gaps and the move from payments. Ross will take your numbers apart and push on commercials.
- **Your 4 hours:** the prep plan in the pack puts 75 minutes into building the 15-minute talk and saying it out loud. Next come the hardest question, then defending your two numbers.
- **The talk itself:**
  - **Opening:** start by saying how you read "operator partnerships". It could mean partnerships with the operators themselves, the partners who help Kelverton reach them, or both.
  - **The report:** pick one point from it you agree with and one you'd do differently. Their own strategy team wrote it, so reciting it back scores as homework.
  - **What not to propose:** a high-volume reseller programme copied from payments. There aren't many buyers and deals take a long time.
  - **Ending:** close on what actually changes for an operator, as the recruiter asked.
- **The question most worth rehearsing (A1):** "You've never sold into rail and never carried a quota." Say both plainly and early. Then stick to what you actually did: taking the channel from 6 partners to 40, and the five years of bus and light rail planning. Then give a 90-day plan.
- **Wording to watch for Ross:**
  - **The £4M:** always call it "roughly £4M of influenced revenue". Never say "closed" or "generated", and don't call it annual unless you know it was.
  - **Deal terms:** don't claim you set partner commercial terms unless you did.
- **Check your years:** your note says 9 years in partnerships, the last 4 at the payments company, and 5 years of consulting before that. Make sure the story you tell adds up (question E1).

If you want to practise, I'll play Deepa and ask A1, with follow-ups that react to what you say.
I can also save a `tuesday-dossier.md` file listing the gaps this prep found, so you can reuse it in later sessions.
If you'd like the pack as a Word document, I'll convert it.

Can you paste the job description and your CV? Either one would change the requirements and evidence the pack is built on, and I'll keep working without them if they're not to hand.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round prep pack

**Round:** 60-minute panel, Tuesday. **Deepa**, VP Partnerships and your future manager. **Ross**, Commercial Director. The first 15 minutes are your spoken POV on operator partnerships over 18 months. The rest is Q&A, and Ross will push on commercials.
**Built from:** your message and the recruiter's email as you quoted it. No JD and no CV. All web searches were refused (see Sources), so nothing here comes from research. Any claim about Kelverton or the rail market is labelled `[generic]`, or is something for you to check against the market report you've read.

---

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Use the guidance as scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Scores |
|---|---|
| VAL | Whether your past behaviour shows the company's published values |
| EXP | Whether claims about your experience hold up, and what was actually yours |
| JD | Whether you can do the role, gaps included |
| CO | Homework depth on the company, its market and strategy |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` means traceable to your message or the recruiter's email. `[inferred]` means derived, and the derivation is named. `[generic]` means a role-family pattern with no claim about Kelverton.

---

## Prep triage: 4 hours

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV, then say it out loud twice against a 13-minute timer. Cut whatever runs over | Section: The POV build |
| 2 | 40 min | Rehearse A1 out loud until it's boring. This is the highest-ROI prep in the pack | A1, then A2 |
| 3 | 35 min | Defend the £4M and the 6-to-40 figures. Write down your own answer to each defend-the-number probe | B1, B2, D3 |
| 4 | 35 min | Ross's commercial cases | B3, B4, D2 |
| 5 | 25 min | POV follow-ups | C1, C3, C5 |
| 6 | 15 min | Re-read the market report with your POV beside it. Pick one point you agree with and one you'd do differently | C4, POV step 2 |
| 7 | 15 min | Pick 3 reverse questions, one for each panellist plus one spare | Reverse questions |

Everything else in this pack is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "running the ISV channel — took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material describes an ISV channel at a payments company, not partnerships with or around rail operators, and your words should stay at that scope: "I ran the ISV channel and took it from 6 partners to 40." Answer slot: the 18-month framing makes a probe on how the channel grew likely. If the plan for that growth was yours, say what it was, in your own words. If it wasn't yours, or there was no plan as such, say so plainly and stay with the 6 to 40 |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Bus and light rail network planning sits next to a rail operator's scheduling but isn't the same work. Your material also doesn't say whose side "the other side" was. At the quote's own scope: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: the operator-benefit line makes a probe on what operators need likely. If that work showed you how an operator planned or ran services, say what you saw, in your own words. If it didn't, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials." — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure touches commercials but doesn't show whether you set deal terms, pricing or partner economics. Answer slot: expect the four defend-the-number probes, each answered in your own words: how the £4M was counted, what it is sensitive to, which assumption behind it you'd defend least, and which part was yours. "I don't know exactly how it was counted" is an honest answer. Your material doesn't say whether the £4M was one year or four, so say "roughly £4M of influenced revenue" unless you know. Second answer slot, from Ross's commercial brief: if you set or negotiated partner commercial terms, say which and how. If you didn't, say so plainly and return to the influenced revenue |
| F4 | Accountability for partner-led revenue, possibly a number of the role's own (role-family requirement, no source) | "never carried a direct quota, only influenced revenue" — your message | none | [generic] | capability | Words: "I've never carried a direct quota. My number was influenced revenue." Then say how you'd take on a number here, as a plan and never as a past. Your material doesn't say whether this role carries a quota, so ask (reverse question R2) |
| F5 | Knowing the UK rail buyer, the train operating companies Kelverton sells to (role-family requirement, from your description of the company) | "Never sold into rail specifically" — your message | none | [generic] | capability | Words: "I've never sold into rail." Then a plan for learning the operator buyer in the first 90 days, said as a plan. F2 is network planning, not selling, so it can't stand in for this |
| F6 | Building and scaling a partner programme (role-family requirement, no source) | "took it from 6 partners to 40" — your message | medium | [generic] | none | No gap. Nothing has been inspected behind the line, though, so expect a probe. Lead with the count in the quote's own terms, 6 to 40, because a number beats an adjective |
| F7 | Fluency in the market view Kelverton's strategy team wrote, inferred because the recruiter sent you the report | "the market report their strategy team circulated internally last quarter, which I've read" — your message | medium | [inferred] | discovery | Your panel's own colleagues wrote this report, so reciting it scores as homework and departing from it with reasons scores as judgement. Answer slot: if the report shaped your thesis, name the section and say where you agree and where you'd sequence things differently, in your own words. If you found nothing to disagree with, say so plainly and say which part you'd prioritise |

**Gate check:** nothing in the recruiter's email or your message names an eligibility term such as location, right to work, travel or a credential, so no gate rows.

---

## The POV build (graded deliverable, 15 minutes)

**The brief, in the recruiter's words:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it." "Please land on what it means for the operators themselves."

**Facts about you it can rest on**, at their own scope:
- F1: "running the ISV channel — took it from 6 partners to 40"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- Use F3, "roughly £4M of influenced revenue", only if Ross asks. It's his to probe, and leading with it invites B1 before you're ready.

**Shape (about 13 minutes, leaving 2 for interruptions):**

| Step | Time | What you say |
|---|---|---|
| 1. Frame | 1 min | Define "operator partnerships" in one sentence and state your assumption: partnerships with operators themselves, the partners who help Kelverton serve operators, or both. Then say that's how you've read it and invite correction. The term is ambiguous, and naming the ambiguity scores as judgement |
| 2. What you see | 2 min | One point from the strategy team's report that you agree with, named as theirs. That proves grounding. Then the one place you'd weight or sequence things differently, with your reason |
| 3. The thesis | 5 min | One thesis from the table below, run as three phases: months 0–6, 6–12, 12–18. Each phase gets one move and one measure |
| 4. What it costs | 1.5 min | The thesis's concession, said before they find it, plus the anti-pick |
| 5. For operators | 2.5 min | The close the recruiter asked for (below) |
| 6. Hand-off | 1 min | How you'd want the plan measured. This hands Ross his opening on your terms (see B4) |

**Thesis options.** Pick one and keep another as a fallback.

| Thesis | The 18-month arc | Mandatory concession | Provenance |
|---|---|---|---|
| T1. Partner with operators, not just sell to them: a small design-partner group of operators who shape the roadmap and act as references | 0–6: pick two or three operators on clear criteria (see C2). 6–12: joint roadmap and a live pilot. 12–18: published outcomes that become the sales story | It slows near-term revenue, and it risks building bespoke for one operator. Say how you'd stop a design partner from turning into a custom project | [generic] |
| T2. Build the ecosystem around the operator's stack: integration partners whose systems sit next to scheduling, so operators get fewer hand-offs | 0–6: map which adjacent systems operators complain about. 6–12: two or three integration partnerships with shared commercials. 12–18: joint propositions sold into operators | A small buyer market may support only a few partners. Partners can also clash with direct sales (see G1). Size the ecosystem honestly | [generic] |
| T3. Follow the buyer: if the report shows who buys for operators changing or consolidating, build partnerships with whoever holds the decision | 0–6: map the buying centre from the report. 6–12: relationships at that level. 12–18: a framework-level partnership | It depends on policy timing outside Kelverton's control. Use it only if the report supports it, and only in its language | [generic] |

**Differentiation.** The consensus answer is to recite the report's opportunities back to the panel, and any prepared candidate can do that. Bring one consensus item to show you read it, then one divergence of your own. **Anti-pick** `[generic]`: don't propose a volume, reseller-style partner programme. A market with few large buyers and long cycles doesn't reward breadth. Saying so out loud also shows you know which parts of a payments playbook don't transfer (A5, C3).

**The operator close** `[generic]`, which the recruiter explicitly asked for. End in an operator's terms, not Kelverton's: what changes in a planner's week, on a disruption day, or around a timetable change. Choose one or two concrete differences your thesis makes and say how an operator would notice them. If the report or Kelverton's own material names operator outcomes, use those words, not yours. Last sentence: what the operator gets in month 18 that they don't have today.

---

## Persona table

The recruiter's email describes this session: one 60-minute panel, its two members and what it holds. So the weights below follow Tuesday's actual format, not an archetype. Neither panellist's public footprint could be researched, so there is no interviewer section.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Deepa probes the rail and quota gaps and the move from payments | High. She's your future manager, and the prior for a hiring manager is Skeptic plus Case. F4 and F5 are visible gaps | Rehearse A1 until it's boring. Concede early, hold only what your quotes carry, then give a plan |
| B. Data-Driven Prober | Ross takes your figures to their assumptions | High. The recruiter said "Ross will push on commercials", and F3's figure is the obvious target | Know what you can and can't say about how each figure was counted, and name the weakest assumption first |
| C. Case / Strategist | Both of them follow up on the POV with "what first", "which operator", "what would you stop" | High. The POV is the session's first 15 minutes, and Q&A grows out of it | Clarify, then structure, then answer. Use the report's vocabulary and challenge one premise politely |
| D. Pressure | Ross time-boxes answers or plays devil's advocate on the thesis | Medium. "Push on commercials" signals pressure, but nothing says the style will be hostile | Pause and restate. Hold through two follow-ups, then concede something specific |
| E. Conversational | The warm opener and "what caught your eye" | Medium. Most panels open with one, and it's still scored | A 90-second arc, prepared |
| G. Peer Evaluator | Ross on the seam between partnerships and the commercial or sales team | Low to medium. A Commercial Director has a stake in who owns operator relationships | Offer seam principles and reciprocity |
| Values / Behavioural | Not banked | Low. The recruiter named no values round, and none of the five types is VAL here | Covered indirectly by A3 and G2 |

---

## Question banks

### A. Skeptic (mostly Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never sold into rail and you've never carried a quota. Why are you the right person for this?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "took it from 6 partners to 40" "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **The highest-ROI rehearsal in this pack.** Concede first and early, in your own words: "I've never sold into rail, and I've never carried a direct quota. My number was influenced revenue." Then hold only what the quotes carry: you were running an ISV channel and took it from 6 partners to 40, and you spent five years in transport consulting on bus and light rail network planning. Let them draw the inference. Don't call either one proof. Then the plan, said as a plan: what you'd learn in the first 90 days and who you'd learn it from. Follow-up 1, "bus isn't heavy rail": agree, and return to what the planning work was. Follow-up 2, "so you'd learn on our time": yes, name the ramp, then stop. Never fold on the 6 to 40 | Both negatives are ones you stated (F4, F5), and both sit exactly where a partnerships VP and a Commercial Director will press. JD because it scores fit to the role; delivered in Skeptic style |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Pick the true one: knowledge of the rail buyer. In your own sentence's words: "I've never sold into rail." Then the plan for closing it. Don't pick a safe fake weakness, because this panel can already see the real one | F5 is the gap they've already noticed, so naming it first turns it into self-awareness. Skeptic stem; JD |
| A3 | "Why leave payments for rail, and why now?" | EXP | [generic] | Selection scaffold. Your material says where you've been, not why you're moving, so the reason is yours to give. It needs a pull towards this work, not just a push away from payments. If the consulting years are part of the pull, say how, in your own words. If they aren't, don't reach for them. If you can't name a pull yet, say so plainly and say what you hope to learn on Tuesday | Motivation consistency is scored in a Skeptic "why here, why now" probe. `[generic]` because no quote states a motive |
| A4 | "Your consulting was bus and light rail. How much of that carries over to national rail operators?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Describe the work in the quote's terms: five years, transport consulting, bus and light rail network planning. Then the limit, plainly: it wasn't heavy rail. Answer slot: the recruiter's operator line makes this probe likely. If that work showed you how an operator planned or ran services, say what you saw, in your own words. If it didn't, say so plainly and stay with the network planning. Don't make "the other side" bigger than you meant it | F2 is your strongest operator-side evidence and the easiest to over-read. EXP because it tests what the work actually was |
| A5 | "Payments ISV partners and rail operators are very different. What from your channel doesn't transfer?" | CASE | [grounded] "running the ISV channel — took it from 6 partners to 40" | Answer as analysis, not autobiography. Name two or three differences you'd expect, such as the number of buyers, sales-cycle length, who signs, and whether a partner resells or integrates, and say what you'd drop because of each. Mention the channel only in the quote's terms. End on what you'd keep | F1 is a transferability row, so this seam is obvious. Asking what doesn't transfer is a common Skeptic move. CASE delivery |

### B. Data-Driven Prober (mostly Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" "never carried a direct quota, only influenced revenue" | Defend the number in your own words: how it was counted, what it is sensitive to, which assumption behind it you'd defend least, and which part was yours. Name the weakest assumption before Ross does. If you don't know exactly how it was counted, say so plainly. That's an honest answer. Keep "roughly" and "influenced" in every sentence. Never let it become closed, sourced or annual revenue unless you know it was | F3's figure is your headline metric and Ross's stated brief. Prober delivery; EXP because it tests attribution |
| B2 | "6 partners to 40. How much of that was you?" | EXP | [grounded] "running the ISV channel — took it from 6 partners to 40" | Start with the sentence as you said it: you were running the channel and took it from 6 partners to 40. Answer slot, the which-part-was-yours probe: say which part was yours, in your own words. If parts of it were other people's, say so plainly. Use "we" for context and "I" for your share. The number counts partners, not deals or revenue | The count behind F1 and F6 is the second figure a prober reaches for. Uses the Pressure stem "how much was actually you" with Prober delivery |
| B3 | "How would you structure the commercials of an operator partnership? Who pays whom, for what?" | CASE | [generic] | Structure it aloud. First clarify the partnership type: co-development with an operator, an integration partner, or a reseller. Then the value each side gets. Then the commercial levers for each type: licence credits or discounts for a design-partner operator, a revenue share or referral fee for a channel partner, joint go-to-market for an integration partner. Then how you'd protect margin and what you'd measure. This is a live problem, so make no claim about your past | Ross's brief from the recruiter's line, asked as a decision. `[generic]` because these are role-family patterns, not Kelverton's terms |
| B4 | "Influenced revenue is soft. How should we measure you?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Agree the risk is real rather than defending softness. Then propose a mix and give the reasons: partner-sourced pipeline and closed revenue, influenced revenue under an attribution rule agreed in writing with sales up front, and one operator-outcome measure from your POV. If the role carries a number, say you're willing to take one. Say it as willingness, not experience | Turns the F3 and F4 gap into a design question Ross can respect. JD content, CASE delivery |
| B5 | "What did a typical partner deal look like commercially in your ISV channel?" | EXP | [grounded] "running the ISV channel" "took it from 6 partners to 40" | Answer slot. Ross's commercial brief makes this probe likely. If you set or negotiated partner commercial terms, say what they were and what your part was, in your own words. If commercial terms weren't part of the channel, or weren't yours, say so plainly and return to running the channel and taking it from 6 partners to 40 | F3's discovery gap. A premised question whose guidance allows the premise to be false |

### C. Case / Strategist (both, following the POV)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've said 18 months. What happens in the first 90 days?" | CASE | [generic] | Listen, map, pick. Who you'd meet: operators, and Kelverton's sales and product leads. What you'd map: current partners, live operator relationships, and where deals stall. The one decision you'd make by day 90: which partnership type to double down on. Tie it to phase one of your POV | The natural follow-up to the deliverable. CASE |
| C2 | "Which operator would you start with, and why?" | CASE | [generic] | Don't name an operator you can't defend. Give criteria instead: an existing customer with a strong relationship, a live pain the product addresses, and an executive sponsor willing to be a reference. If the report segments operators, use its labels. Then: "I'd want your view on who fits that best." | Tests judgement while your rail-buyer knowledge is thin (F5). CASE |
| C3 | "What would you say no to?" | CASE | [generic] | The anti-pick from the POV build: a volume reseller programme. Explain why: few buyers and long cycles. Then one more: no design partner that turns into custom development | The role includes saying no, and this shows which parts of the payments playbook you'd leave behind. CASE |
| C4 | "What in our strategy team's report do you disagree with?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Selection scaffold. Pick one thesis from the report you'd weight or sequence differently, name the section, give your reason, and hold it politely. If you found nothing to disagree with, say so plainly and say which part you'd prioritise and why. Never present the report's points as your own ideas, because the panel's colleagues wrote it | F7. CO because it tests homework depth. Both panellists have the report too, so judgement beats recital |
| C5 | "Make it concrete. What changes for an operator's planning team in 18 months?" | CASE | [generic] | Answer in operator terms: a planner's week, a disruption day, a timetable change. Pick one or two differences your thesis makes, such as fewer manual hand-offs between systems or quicker re-plans, and say how an operator would notice. If the report names operator outcomes, use its words. No claims about your past | The recruiter's explicit close: "Please land on what it means for the operators themselves." CASE |

### D. Pressure (mostly Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's sold to operators for ten years?" | JD | [grounded] "took it from 6 partners to 40" "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "Never sold into rail specifically" | Pause, then three beats inside 60 seconds: you took a channel from 6 partners to 40; you spent five years in transport consulting on bus and light rail network planning; and the plan you've just presented. Concede the rail gap in one clause ("I haven't sold into rail") without apologising. Stop at 60 | A Pressure stem testing composure under a time box. F5 makes the comparison obvious |
| D2 | "Operators don't want partners, they want cheaper software. Convince me." | CASE | [generic] | Hold, then concede. Hold: partnerships matter where they cut an operator's cost or risk, and say how your thesis does that. Follow-up 1: give the operator example from your close. Follow-up 2: concede something specific, such as "for some operators price will win, and partnership isn't the lever there". Don't drop the core thesis just to restore harmony | Ross's push, aimed at the operator close the recruiter asked for. CASE content, Pressure delivery |
| D3 | "How much of the £4M would have happened without you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Hold, then concede on attribution. Hold: it is influenced revenue, so call it that. Answer slot: the figure raises the which-part-was-yours probe, so answer it in your own words. If you don't know how much would have happened anyway, say so plainly. Concede that the counterfactual is uncertain, and say so before Ross does | F3's figure under pressure. EXP |

### E. Conversational (opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your background." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc in time order: transport consulting on bus and light rail network planning, then partnerships, finishing with the last four years running the ISV channel at a payments company, 6 partners to 40, roughly £4M influenced. Answer slot: your note gives 9 years in partnerships, the last 4 at the payments company, and 5 years of consulting before that. Tell the years the way they actually happened. If the consulting years were partnerships work, say how. If they weren't, don't count them as partnerships. Close with one sentence of your own on why this role | A rapport opener is still scored, and the years arithmetic is the first thing a careful listener will check (F1, F2) |
| E2 | "What's caught your eye in rail lately?" | CO | [generic] | Treat it as scored. Give one point from the market report and anything you've read yourself this weekend, and say why it matters to operators. If you haven't followed rail news, say the report is where you started | A casual CO probe. `[generic]` because no research ran |

### G. Peer Evaluator (Ross, on the commercial seam)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Partnerships and my team both touch operators. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Offer principles, not a turf map: who owns the operator relationship, when a partner is brought in, and how credit is agreed before the deal rather than after it. Add reciprocity: what partnerships gives his team, such as references, pipeline and integrations that shorten his deals | If the Commercial Director owns direct sales, partnerships meets his team at every operator. `[generic]` because the org chart is unknown |
| G2 | "How do you handle credit when a partner-influenced deal closes through sales?" | EXP | [grounded] "roughly £4M of influenced revenue" | Selection scaffold: pick a time when credit on an influenced deal had to be agreed or was contested. The story needs a named stake and a relationship that survived. If no such time comes to mind, say so plainly and give the rule you'd propose here. Don't supply a dispute that didn't happen | Influenced revenue (F3) makes credit-sharing a live question for a commercial leader. Open prompt from the Peer stem |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" (F1) | POV build, A5, C1, C2, C3 |
| "Please land on what it means for the operators themselves." (F2) | POV close, A4, C5, D2 |
| "Ross will push on commercials." (F3) | B1, B2, B3, B4, B5, D2, D3 |
| Partner-led revenue accountability, generic (F4) | A1, B4 |
| UK rail buyer knowledge, generic (F5) | A1, A2, C2, D1 |
| Partner programme scale, generic (F6) | B2, E1 |
| The strategy team's report (F7) | POV step 2, C4, E2, R5 |

---

## Reverse questions

| # | To | Question | Why it lands |
|---|---|---|---|
| R1 | Deepa | "If this role goes well, what's different for operators in 18 months that isn't true today?" | It mirrors the brief she set, and her answer tells you how close your POV landed |
| R2 | Ross | "How is partnerships measured today: sourced, influenced, or a number of its own? Is that changing?" | It goes straight at F3 and F4 without being defensive, and gives you the facts B4 needs |
| R3 | Ross | "Where do partner-led and direct deals collide today, and how does that get settled?" | It shows you see the G1 seam before it bites, and it's his territory |
| R4 | Deepa | "Which partnerships do you most want to exist in 18 months that don't exist now?" | Her answer is the real brief. Ask it after the POV so you're not fishing |
| R5 | Either | "Where does the partnerships team see the strategy team's report differently?" | It uses the shared document as a peer conversation and surfaces internal debate |
| R6 | Deepa | "What would you need to see at six months to know this hire was right?" | A manager's success criteria, in her words. It's also your 90-day plan, checked |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold to, or worked with, train operating companies | A negative you stated, F5 | "I've never sold into rail." |
| Has carried or hit a revenue quota | A negative you stated, F4 | "I've never carried a direct quota. My number was influenced revenue." |
| Generated, closed or sourced £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: the material says influenced, and that's the word to keep |
| £4M a year | Inflated form of F3, resolving an ambiguity upward | Say "roughly £4M of influenced revenue" without a period unless you know it |
| Personally recruited the 40 partners | Inflated form of F1 | F1's quote: "took it from 6 partners to 40". B2's slot stays inside that |
| Worked inside operators, or knows heavy-rail scheduling | Inflated form of F2 | F2's quote at its own scope. The pack's observation: the material says bus and light rail network planning, in consulting. A4's slot stays inside that |
| Set partner commercial terms or pricing | Inflated form of F3 and F1 | F1's quote, "running the ISV channel", at its own scope. B5's slot lets the premise be false |
| Facts about Kelverton, its operators or the market that aren't in the report | No research ran | Use the report's own words, attributed to it, or say you don't know |

---

## Sources

**Provided:** your message, and the recruiter's email as you quoted it in that message. The market report is mentioned but its content wasn't shared, so nothing in this pack draws on it. Every report reference is a prompt for you to fill.

**Searches sent:**
- `Kelverton Rail values`: refused
- `Kelverton Rail interview process partnerships`: refused
- `Kelverton Rail scheduling software train operating companies news 2026`: refused
- `Deepa VP Partnerships Kelverton Rail; Ross Commercial Director Kelverton Rail`: refused
- `"Senior Partnerships Manager" rail software job description UK`: refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Refused. It would have given official value names, but with no values round named, no cheat sheet would have followed. It would only have themed questions |
| 2. `Kelverton Rail interview process` | unavailable | Refused. The recruiter's email already describes Tuesday's session, so the persona weights stand without it |
| 3. Kelverton Rail strategy and recent news | unavailable | Refused. It would have grounded C4, E2 and the POV theses in current facts. They are `[generic]` instead |
| 4. Deepa and Ross at Kelverton Rail | unavailable | Refused. It would have added a reading-the-interviewer section, per-person persona weights and a reverse question tied to each person's career path |
| 5. Representative Senior Partnerships Manager JD | unavailable | Refused. It would have replaced F4 to F6's generic requirements with quoted, `[inferred]` ones |

---

## Upgrade menu

- **The JD text** → F4 to F6 become `[grounded]` on the JD's own words, and every JD requirement gets checked for a question.
- **Your CV** → evidence beyond your message, the E1 years question settled, and more story-mapped answers in place of scaffolds.
- **The market report's main theses, pasted or in your own summary** → the POV theses, C4 and E2 move from scaffolds to specific, `[grounded]` picks for consensus and divergence.
- **One email to the recruiter: what "operator partnerships" means here, and whether the role carries a number** → POV step 1 framing, F4 and B4.
- **Web search allowed** (all five were refused this time) → Kelverton's published values, recent news for the CO and Case banks, and Deepa's and Ross's public professional footprint for a reading-the-interviewer section and tailored reverse questions. A deeper pass, up to 6 more searches and 2 more fetches and several more minutes, can run on top if you want it.
- **Your own answers to the answer slots in F1, F2, F3 and F7** → A4, B1, B2, B5, C4 and D3 move from slots to story-mapped guidance.
- **A job-underwriter dossier** → a highest-ROI objection and a prohibited-claims list taken from verified evidence, instead of the ones inferred here.
