Reading the skill's research and evidence rules, then I'll build the pack.
I've built the full mock-interview pack for Priya. It has 23 questions across seven interviewer personas. Every question has a type tag, answer guidance and a rationale for why it's included and categorized that way.

**One limit to know first:** my web searches were refused, because search permission wasn't granted in this session. So nothing about Northwind or Dan comes from the web. All company and interviewer content rests on your notes: Dan's profile, the three priorities, Compass and the bundling threat. Northwind's official values, the shape of the rest of the interview process, and Dan's public talks or posts are not in the pack. The values questions are therefore generic rather than tied to Northwind's own wording.

**How it's built:**
- **Weighting:** because Dan is a peer who calls himself "relentlessly data-driven", the pack leans hardest on two personas: a numbers prober and a peer testing how your two teams would work side by side. Each gets 5 questions. His pricing background tilts the 4 strategy cases toward bundling, pricing Compass, and choosing which product line to fund first under the profitability goal.
- **Fit snapshot:** each JD requirement is set against Priya's evidence, quoted from your notes.
- **Coverage:** every JD requirement and every item in your research note has at least one question.
- **Answer slots:** where your notes don't say what Priya actually did, the guidance gives two honest branches rather than filling in the story. It doesn't invent how the ~$400M was counted, what her role in the carrier negotiations was, or any B2B experience. A "won't coach" list near the end names the claims she shouldn't drift into, such as presenting her volume targets as sales quotas.

**Highest-value prep is question D1:** "Your background is consumer tech, and there's no sales-ops or quota-setting in it. Why should I believe you can build a B2B GTM motion my team can carry a number against?" Dan's team would absorb the cost of that gap, so he's very likely to ask it in some form. The guidance has her say the gap plainly first, then stand on what she really did, then give a ramp plan.

The pack also covers Dan's background and what it means for the hour, 7 questions for Priya to ask him, and a list of what each missing input would add. Your notes didn't mention any prep work set by the recruiter or the time Priya has to prepare, so I left out sections for those.

If you want, I'll play Dan on D1 with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-1-denied-ae0194da:
- northwind-data_senior-gtm-strategy-lead_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack — Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. He would be your **peer**: you would both report to the same VP.
**Format:** one 60-minute conversation.

---

## How to use this pack

Read the pack along two axes.

- **Personas** describe *how* a question arrives: who is asking, and in what style. One hour with a peer who calls himself "relentlessly data-driven" will feel different from an hour with a hiring manager, even when the content is the same.
- **Types** describe *what* is being scored.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's values, not generic virtue |
| EXP | Whether your claims hold up under scrutiny, and what was really yours |
| JD | Whether you can do the job as listed, including the parts you're missing |
| CO | Whether you can think at Northwind's level: its strategy, its competition, its priorities |
| CASE | How you structure and reason through a live problem from the role |

**Provenance labels.** Every row carries one of three labels:

- **[grounded]** means it traces to your notes.
- **[inferred]** means it is a derivation, and the pack names it.
- **[generic]** means it is a role-family pattern that claims nothing specific about Northwind.

**Answer slots** mark the places where your material doesn't say enough. Each slot gives two branches. Answer it from what you actually did, or say plainly that it wasn't yours, or that it never happened.

The guidance is scaffolding, not a script. Rehearse it in your own words.

---

## Fit snapshot

Each requirement below comes from the JD highlights in your notes. Each evidence quote comes from your description of Priya, cited as "the coach's notes".

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy & ops and a proposed store-surface change. It doesn't show ownership of GTM for a new B2B product line. Keep the words at that scope: "I spent nine years in product strategy and ops at a large consumer-tech company, and I proposed a store-surface change that was credited with about $400M in ARR uplift." Answer slot: the JD's line about two new product lines makes a probe on go-to-market work likely. If some of your work took a product or surface to market and part of it was yours to decide, say which part and how, in your own words. If there was no such step, or it wasn't yours, say so plainly and stay with the product strategy & ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | none | [grounded] | discovery | The material doesn't show customer-lifecycle or whitespace analysis. Answer slot: if any analysis you've done sized untapped segments, adoption or renewal across a customer or partner base, say what you looked at and what came of it, in your own words. If none did, say so plainly, then walk through how you would build the first whitespace cut here (see A5) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. But it's a self-reported skill with nothing inspected behind it, and the interviewer is a data-driven peer, so expect a probe. Lead with the quote's own terms: skilled in SQL and Tableau. Answer slot: the JD's word "independent" makes "did you write the queries yourself?" a likely follow-up. If you did, say what you queried and built, in your own words. If others did the querying, say so plainly and say what you did with the output |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material describes a revenue model built at partner level and used in carrier negotiations. That is a model, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD marks partner-motion design as required, so a probe on how partners were engaged, structured or incentivised is close to certain. If any of that was yours to shape, say which part and how, in your own words. If none was, say so plainly and stay with the model and how it was used. The quote says the model was used in the negotiations. It doesn't say who negotiated |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already reaches this requirement. Lead with its own terms: annual volume targets, set with cross-org consensus. Answer slot: expect a probe on how the consensus was reached. If you can name who disagreed and what moved them, say so in your own words. If there was no real disagreement, say so plainly and describe how the targets were set. These were volume targets. Never present them as quotas (see F7) |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | transferability | Using tools daily isn't AI product or AI GTM work, and the bridge shouldn't be stretched. The words are "I use AI tools daily." Answer slot: the JD's AI line makes "what have you done with AI beyond using it?" likely. If some of that use is part of your analysis or strategy work, name the tool and what you use it for, in your own words. If it's mainly personal productivity, say so plainly. Derivation: the low band is because the quote is general, and the bridge is the pack's reading of the JD line |
| F7 | Fluency in the sales-strategy work a Sales Strategy peer does every day: quota, territory and coverage design. This is a role-family requirement with no JD source, so it raises no answer slot | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | No wording can close this gap, and it has been stated. The words are "I don't have classic sales-ops or quota-setting experience." Then say how you would learn it, starting with the interviewer's own team, framed as a plan and never as a past. Add nothing that makes the gap feel smaller |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own GTM strategy for two new product lines (F1) | D1, C2, C4, D3 |
| Whitespace across land/adopt/expand/renew (F2) | A5, C4 |
| Independent analysis in SQL and Tableau (F3) | A3, A5, B2 |
| Partner-motion design, required (F4) | D2, A4, B5, F2 |
| Strong cross-functional influence (F5) | B1, B4, B3, G1 |
| AI experience a plus (F6) | E2, C3 |
| Sales-strategy fluency: role-family, the interviewer's home turf (F7) | D1, B4, F1 |
| Research note: enterprise expansion | C4 |
| Research note: Compass AI copilot launch | C3 |
| Research note: reaching profitability | C2, C1 |
| Research note: bundling by a larger platform vendor | C1 |

---

## Reading the interviewer

Everything here comes from the interviewer notes in your message. Web search was refused in this session, so nothing has been added from his public footprint (see Sources).

| # | Signal | Provenance | What it means for this hour |
|---|---|---|---|
| I1 | Director of Sales Strategy, reporting to the same VP as this role | [grounded] | He is pricing what this hire costs and adds to *his* team's work. Expect questions about where the two teams meet, about credit, and "what do you need from me" |
| I2 | Self-describes as "relentlessly data-driven" | [grounded] | The Prober weight goes up. Every number Priya gives will be followed two levels down, to how it was counted and what it rests on. Name your weakest assumption before he does |
| I3 | Career spine is pricing and monetization roles | [grounded] | Case questions tilt toward pricing, packaging and unit economics: bundling, Compass pricing, profitability trade-offs. That is his native language. A shared-vocabulary opening comes from F4's quote, "built a partner-level revenue model used in carrier negotiations". Tell it at its own scope and let him draw the inference |
| I4 | One early-stage-startup chapter | [grounded] | Builder stories land well with him. Expect some scepticism about big-company pace, and a possible "how scrappy are you?" probe. No row of the fit snapshot carries a startup or 0→1 chapter for Priya, so no shared jump is offered. Reverse question R2 uses his chapter instead |

---

## Persona table

The relationship is the starting point: for a peer interviewer, Peer Evaluator and Data-Driven Prober dominate. The I2 to I4 signals then adjust the weights. Your notes establish the loop for this session: one conversation, with Dan. Nothing is known about other rounds.

| Persona | How it shows up with Dan | Questions | Reasoning shown | Counter-strategy | Provenance |
|---|---|---|---|---|---|
| Data-Driven Prober | Asks for denominators, counting method and model inputs | 5 (A) | The peer starting point, raised by I2's "relentlessly data-driven" | Know what you can and can't say about how each number was counted. Name the weakest assumption first. Say "I don't know" plainly when you don't | [grounded] |
| Peer Evaluator | Where the teams meet, credit, what you need from him and what you give back | 5 (B) | The peer starting point, plus I1 | Frame things as reciprocity. Propose principles for where the teams meet rather than pretending to know where they meet today. Show spine and tact together | [grounded] |
| Case / Strategist | Live problems: bundling, sequencing the two lines, pricing Compass | 4 (C) | I3's pricing spine pushes the cases toward packaging and unit economics, and the research note supplies the problems | Clarify, then objective, segmentation, approach, metrics and risks. Think aloud. Respectfully challenge one premise per case | [grounded] |
| Skeptic | The consumer-to-B2B jump and the stated sales-ops gap | 3 (D) | Lower weight in a peer round, but it holds the single most predictable objection (D1) and I4's scrappiness lens | Concede the stated gap first. Hold only with what the quotes carry. Have a concrete ramp plan | [grounded] |
| Conversational | Openers and the casual AI question | 2 (E) | Present in any 60-minute conversation. Casual questions are still scored | A rehearsed 90-second story of the journey. Treat the AI question as scored | [generic] |
| Pressure | Time-boxed "why you", and "were you in the room?" | 2 (F) | Not a strong signal for a peer. Included so the style isn't met for the first time live | Pause, restate the question, hold through two follow-ups, then concede what's real | [generic] |
| Values / Behavioral | Unpopular truth; customer over metric | 2 (G) | No values-style round is detected for this session, and Northwind's values weren't fetched. A brief brush only | Pick the story using selection criteria. Use "we" for context and "I" for your contribution | [generic] |

---

## Question banks

### A — Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the ~$400M ARR uplift from the store-surface change. How was that number counted?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the sentence's two verbs: you *proposed* the change, and it was *credited* with about $400M in ARR uplift. Then fill the defend-the-number slots, each in your own words: how the figure was counted and by whom; what it's sensitive to; the assumption behind it you'd defend least (name it before he asks); and which part was yours beyond the proposal. If you don't know how it was counted, "I don't know exactly how it was counted" is an honest answer, and it beats a reconstruction you can't defend. Expect "ARR" itself to be probed by someone from monetization. Say what the figure measured, or that you'd need to check | This is the headline metric in F1, and any data-driven interviewer goes for it first (I2). It is EXP because it tests attribution and counting, not strategy |
| A2 | "How do you know the uplift came from the store-surface change and not from something else?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Stay with the word "credited". The quote says the change was credited with the uplift; it doesn't say how that credit was established. Answer slot: if you know how the effect was isolated, say how, in your own words. If you don't, or if the credit was assigned by someone else, say so plainly and say what you would want to check. Don't re-size the number or invent a method on the spot. The move that scores is naming what the figure is sensitive to, in your words | This is the second level of A1. A Prober asks for the denominator and the counterfactual. It is a separate row so it can be drilled as its own follow-up, and it is EXP for the same reason as A1 |
| A3 | "You're skilled in SQL and Tableau. Walk me through an analysis you ran end to end yourself." | JD | [grounded] "skilled in SQL/Tableau" | Lead with the quote. Answer slot: the JD's "independent analysis" premise raises this. If you have such an analysis, walk through the question, the data, what you wrote, what the view showed and what changed because of it, in your own words. If your SQL/Tableau work has mostly meant using or adapting other people's work, say so plainly, then say the first thing you'd build here | F3 is a self-reported skill and the interviewer is a data-driven peer. It is JD because it scores the stated requirement directly, with EXP delivery |
| A4 | "Walk me through the partner-level revenue model that was used in the carrier negotiations. Which input would you trust least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Tell only the beats the quote states: you built it, it was partner-level, and it was used in carrier negotiations. Answer slot: say what it modelled and what went into it, in your own words, and which input you'd trust least. If you weren't in the negotiations themselves, say so plainly, because the quote says the model was used in them. Expect pricing follow-ups (I3), such as which lever moved the most. Answer only from what you know | F4 is the only partner evidence and it sits in the interviewer's pricing territory. It is EXP because it tests the model's real scope and Priya's real role in it |
| A5 | "Say you have account-level usage and renewal data for an installed enterprise base. What's the first whitespace query you'd write?" | JD | [generic] | No claim about the past is needed. Define the unit (the account) and stage each account as land, adopt, expand or renew. Find accounts that use the core product heavily but have none of the new line. Compare them with look-alike accounts that have adopted. Use proximity to renewal as a timing flag. Say aloud what the denominator is and which proxy you'd trust least. Offer to sketch the query and the resulting view | F2 has no evidence, so this lets Priya show the capability live rather than claim it. It is JD because it scores the whitespace requirement, delivered as a CASE. It is [generic] because it's a pattern for the problem, not a fact about Northwind's data |

### B — Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We'd sit side by side under the same VP. Where does Sales Strategy end and emerging-products GTM begin, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose principles for where the teams meet, as proposals. For example, his team owns how the core motion is covered and paid, this role owns the GTM hypotheses for the new lines, and the two decide together how a new line shows up in reps' plans. Then ask where he sees it. On disagreement: agree the decision rule before looking at the data, then let the data settle it. For evidence, stay with the quote: annual volume targets, set with cross-org consensus. Answer slot: if you can name a disagreement in that process and how it resolved, say so in your own words. If there wasn't one, say so plainly and describe how the consensus was reached | This is the peer interviewer's defining question (I1). It is JD because it scores the cross-functional influence requirement (F5) |
| B2 | "What would you need from my team in your first 90 days, and what would you give back?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with what you'd give, not with what you'd ask for. Give: a first whitespace cut for the new lines his team can use, and analysis you run yourself in SQL and Tableau, so it doesn't add to his team's load. Ask for: access to the data his team trusts, how coverage and quota currently work, and pricing guardrails. Close by asking what would help his team most. That is the reciprocity move | The peer's load question (I1). It is JD because it tests how independent analysis (F3) and influence play out in practice |
| B3 | "How do you handle credit when work spans teams? Take the ~$400M. Whose number was that?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use "we" for context and "I" for your contribution: "I proposed the change, and it was credited with about $400M." Answer slot: if you know which other functions built, shipped or measured it, name them in your own words and say what part was yours beyond the proposal. If your part was the proposal, say so plainly and let it stand at its own size | Credit-sharing is a standard peer probe, and the biggest number in F1 is where it lands. It is EXP because it tests attribution honesty |
| B4 | "You set volume targets. How is that different from setting quota?" | JD | [grounded] "set annual volume targets with cross-org consensus" "No classic sales-ops or quota-setting experience." | Don't treat the two as the same thing. Say what the first quote says: you set annual volume targets, with cross-org consensus. Then give the plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Answer slot: say what the volume targets measured and who carried them, in your own words. If you're not sure where they differ from quota mechanics, say so and ask him how quota is set at Northwind. That turns a test into a peer exchange | This is where F5 meets F7, on the interviewer's home turf. A peer will check whether the target-setting gets passed off as quota-setting. It is JD because it scores the sales-motion side of the GTM requirement |
| B5 | "If partner-sourced deals and direct reps collided on the same accounts for a new line, how would you set the rules of engagement?" | CASE | [generic] | Clarify which type of partner: resell, referral, or technology/SI alliance. Clarify the objective: reach, margin or speed. Then the rules: deal registration, how segments or territories are carved up, whether reps' pay stays neutral or gets an overlay for the new line, and an escalation path. Metrics: partner-sourced versus partner-influenced pipeline, and how often conflicts arise. Risk: margin erosion, which is his pricing lens. Ask for his view on the pay question. No claim about your past is needed | It tests partner-motion design (F4) live, framed as a question about where the teams meet. It is CASE because it's a live problem, and [generic] because it describes no Northwind practice |

### C — Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles a good-enough version of one of our new lines into its platform. What do you do in the first quarter?" | CASE | [grounded] | Clarify which line and which segments are exposed. Objective: protect lands, or protect expansion? Segment accounts into those where the bundle is good enough and those where depth matters. Responses: compete on depth and differentiation where it counts; consider an entry package and attaching the line to the core; consider a partner route; don't race to zero. Name the tension with the stated profitability priority, since discounting fights it. Metrics: win rate against the bundler, and the rate at which customers switch. Challenge one premise, for example whether the bundle really reaches enterprise buyers | This is the competitive threat named in your research note, and it is pricing-heavy, which suits I3. It is CASE, with the CO content coming from the note |
| C2 | "Two new product lines and a profitability mandate. How do you decide which one gets GTM investment first?" | CASE | [grounded] | Clarify what each line is and who buys it. Criteria: how well it attaches to the existing base (expansion), time to revenue, payback, which motion fits (self-serve, sales-led or partner), and exposure to bundling. Recommend a sequence, with kill criteria and the data you'd pull to decide | It ties the JD's two lines (F1) to the profitability priority in the research note. It is CASE because the answer is scored on structure, not on a right pick |
| C3 | "How would you price and package Compass?" | CO | [grounded] | Start by asking what Compass does and who buys it. Don't pretend to know. Options: include it in tiers as a defence against bundling, sell it as a per-seat add-on, price it on usage, or mix these. Tie each option to enterprise expansion and to profitability, and ask whether cost rises with usage. Propose a pilot to test willingness to pay. Metrics: attach rate, usage, expansion revenue, gross margin | Compass is named in your research note, and the interviewer's spine is pricing (I3). It is CO because it tests fluency in Northwind's current strategy, delivered as a CASE, and it covers the AI-plus line (F6) |
| C4 | "Enterprise expansion is the priority. Build me the land-adopt-expand-renew plan for a new line into the existing enterprise base." | CASE | [grounded] | Structure the plan by stage. **Land:** a whitespace-ranked target list (A5) and an entry offer. **Adopt:** leading indicators of usage. **Expand:** the triggers for an expansion conversation. **Renew:** attach the line to renewal dates. Add the partner role at each stage. Ask who carries the number for the new line, which is his territory. Close with three metrics | This combines the expansion priority in the research note with the JD's lifecycle line (F2). It is CASE because it's a live plan, with JD content |

### D — Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | **Highest-ROI prep in this pack.** "Your background is consumer tech, and there's no sales-ops or quota-setting in it. Why should I believe you can build a B2B GTM motion my team can carry a number against?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "skilled in SQL/Tableau" | **1. Concede first, plainly, before the follow-up:** "I don't have classic sales-ops or quota-setting experience." **2. Hold only with what the quotes carry:** two years of strategy consulting, nine years of product strategy and ops at a large consumer-tech company, a partner-level revenue model you built that was used in carrier negotiations, and skill in SQL and Tableau. Describe these and don't call them proof. Let him draw the inference. **3. Answer slot:** if any of your consulting or consumer-tech work had a B2B or partner-facing side, say what it was, in your own words. If none did, say so plainly. **4. Ramp plan, framed as a plan:** spend the first weeks learning quota, coverage and the reps' motion from his team, then bring the whitespace and partner analysis back to them. **5. Turn it into an exchange:** say which part you'd lean on him for most. **Follow-ups to rehearse:** "So you've never designed a partner programme?" Return to F4's quote and its slot, and add nothing. "What would you get wrong in month one?" Name one thing in your own words. Hold through two follow-ups by returning to the quotes, never by adding to them | This is the single most predictable objection. It is built from the stated gap in F7 and the scope limit in F1, and it comes from the person whose team would absorb the cost of that gap (I1). It is JD because it scores the core GTM requirement against the gap |
| D2 | "Partner-motion design is listed as required. Your partner example is a revenue model. What part of a partner motion have you designed yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold with the quote: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of how carriers were engaged, structured or incentivised was yours to design, say which part and how, in your own words. If none was, say so plainly. That is a limit, not a confession. Then show the capability live: offer to sketch how you'd design the partner motion for a new line (see B5) | F4 is the gap against the one requirement the JD marks as required. It is JD because it scores that requirement directly |
| D3 | "Why leave consumer tech after nine years, and why emerging products at Northwind now?" | CO | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | **Why leave:** answer slot. Give your real reason, in your own words. The pack can't supply it. **Why here:** connect to what Northwind has stated: two new product lines, enterprise expansion, the Compass launch and profitability. **Why now:** answer slot, in your own words. Keep it consistent with E1 | This is the Skeptic's motivation-consistency check. A startup-minded interviewer (I4) may add "why not somewhere smaller?" It is CO because the strongest "why here" runs through the company's priorities |

### E — Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second story: two years of strategy consulting, then nine years of product strategy and ops at a large consumer-tech company. Pick two highlights, each told at its own scope: the partner-level revenue model, which was used in carrier negotiations, and the store-surface change you proposed, which was credited with about $400M in ARR uplift. Then the bridge to this role (answer slot: why this move, in your own words). Every number here will be followed up (A1), so say only what you can defend | It's the near-certain opener, and it sets up every probe that follows. It is EXP because the interviewer will mine it for claims to test |
| E2 | "What are you actually doing with AI tools these days?" | JD | [inferred] "uses AI tools daily" | Say "I use AI tools daily." Answer slot: name which tools you use and what for, in your own words, especially anything in your analysis or strategy work. If it's mainly personal productivity, say so plainly. Then turn to Compass with curiosity rather than claims: say what you'd want to learn about its buyer. Don't describe AI product work you haven't done | It's the casual way the JD's AI plus gets scored (F6). It is JD because the casual register still tests a listed requirement, and [inferred] because F6's evidence band is low |

### F — Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who's already run sales strategy at a SaaS company?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "built a partner-level revenue model used in carrier negotiations" "skilled in SQL/Tableau" | Pause and restate the question. Concede in one line: "I don't have classic sales-ops or quota-setting experience." Hold with what's yours: you built a partner-level revenue model that was used in carrier negotiations, and you're skilled in SQL and Tableau. Close with what you'd do in the first 90 days (C4, A5). If he pushes twice, keep the concession as it is and don't fold on the rest | This is the time-boxed form of D1, so composure gets rehearsed separately from content. It is JD because it scores fit against the role |
| F2 | "Your model was used in carrier negotiations. Were you in the room?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold, then concede what's real. The quote says you built the model and that it was used in the negotiations. Answer slot: if you were in the negotiations, say what you did there, in your own words. If you weren't, say so plainly, then describe how the model was used, as far as you know. Don't let the pressure push the answer up the scale | This is the "how much of that was really you" stem applied to F4. It is EXP because it tests attribution |

### G — Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose the story using these criteria: a named stake, a moment where you didn't soften the message, and an outcome where the truth actually landed, with the relationship still intact. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | This is a peer's way into disagreement style (I1). It is VAL and [generic] because Northwind's published values weren't fetched |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Choose the story using these criteria: a real metric you could have hit, a customer cost if you did, and what you chose and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | Even a data-driven interviewer probes whether metrics get gamed. It is VAL and [generic] for the same reason as G1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've come up through pricing and monetization. How does that lens shape how Sales Strategy here thinks about packaging new lines against a much larger vendor's bundling?" | It ties to his own career (I3) and to the threat named in your research note |
| R2 | "You've had an early-stage chapter. Which habits from it do you think an emerging-products team inside a 3,000-person company needs most?" | It uses his startup chapter (I4) and turns the scrappiness probe into a peer conversation |
| R3 | "What could I do in my first month that would genuinely help your team?" | The reciprocity question for a peer. It shows Priya would reduce his load, not add to it |
| R4 | "Is Compass one of the two product lines this role covers, or a separate launch the new lines need to fit around?" | It clears up something the pack can't establish, and it shows close reading of the company's priorities |
| R5 | "Where do you expect the line between your team and this role to blur, and how would you want us to handle it?" | It invites him to draw that line himself, which is the B1 question asked from the other side |
| R6 | "With profitability as a stated priority, how are new-product bets judged here: payback, attach rate, something else?" | It speaks his language and tells Priya which metric she'd be measured on |
| R7 | "Which data would I start from on day one, and is there a source of truth our two teams share?" | It signals independent SQL and Tableau work (F3) and an intent not to queue on his team |

---

## Prohibited claims

Each entry below is something this pack won't coach. The honest form is what to say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove, owned or delivered the ~$400M ARR uplift | Inflated form of F1 | F1's quote at its own scope: proposed the change; it was credited with the uplift. The limit is the pack's observation: the material says "proposed" and "credited". A1, A2 and B3 keep their slots inside that scope |
| Designed a partner motion or partner programme | Inflated form of F4 | F4's quote at its own scope. The material says a revenue model, not a motion. D2's slot asks only which part of the carrier engagement was Priya's to shape |
| Led or ran the carrier negotiations | Inflated form of F4 | The model was "used in carrier negotiations". F2's slot asks whether she was in the room, and the honest answer may be no |
| Has set sales quotas or done sales ops | Negative stated in your notes, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |
| The volume targets were quotas | Contradicted by F7's quote, and an inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". Never equate the targets with quota (B4) |
| Has AI product or AI GTM experience | Inflated form of F6 | F6's quote: "uses AI tools daily". E2's slot asks what the tools are used for |
| Owned GTM for a launched product line | Inflated form of F1 | F1's quotes at their own scope. F1's slot asks which go-to-market decisions, if any, were hers |

---

## Sources

**Provided material:** your message, which contained the role and the JD highlights, Priya's background, the interviewer notes and your research note (the three stated priorities and the bundling threat). No dossier was consumed.

**Searches sent:**

- "Northwind Data company values data infrastructure SaaS". Refused: web search permission was not granted.
- "Northwind Data interview process GTM strategy". Refused: web search permission was not granted.
- "\"Dan Kovac\" Northwind Data sales strategy". Refused: web search permission was not granted.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Every call was refused. It would have given the G bank Northwind's official value names in place of [generic] themes. Section 10 stays out either way, because no values-style round is detected for this session |
| 2. Northwind interview process | unavailable | Every call was refused. It would have shown whether other rounds exist and what they hold. This session's persona weights already rest on your own description of the conversation |
| 3. Northwind strategy and recent news | skipped | Your research note already supplies the priorities and the competitive threat that feed C1 to C4, D3 and the reverse questions. How old the note is isn't known |
| 4. Dan Kovac at Northwind | unavailable | Every call was refused. It would have added his talks or posts to the reading of the interviewer, and their recurring themes to the banks and reverse questions |
| 5. Representative JD | skipped | The JD highlights you supplied determine the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text:** requirements beyond the six highlights get quoted rows, and any mid-list tool, method or metric gets its own JD question.
- **Priya's answers to the answer slots, in her own words** (especially F1, F2, F4 and F6): those rows, and A3, A4, D1, D2 and E2, become story-mapped guidance instead of two-branch slots.
- **How the ~$400M was counted, in Priya's words:** A1, A2 and B3 become ready to defend, with the weakest assumption written in.
- **Web search allowed in this session:** Northwind's official values for the G bank, the shape of the loop, and Dan's public talks or writing for the reading of the interviewer and R1/R2.
- **A deeper research pass:** up to 6 more searches and 2 more fetches, taking several more minutes. It adds a grounding brief and sharper C1 and C3 cases on the bundling vendor and Compass.
- **The recruiter's prep email:** any announced deliverable (POV, presentation, case) gets its own build section, and any stated focus areas reweight the banks.
- **The rest of the interview schedule:** a mini-pack per round, each with its own persona weights.
- **Prep time available:** a prioritised schedule sized to it.
- **A tuesday-dossier.md from job-underwriter:** an objection derived from evidence instead of inferred, a strategy constraint for each gap, and a guardrail list of prohibited claims from verification. This pack doesn't need one.
