Quick update: I've read the prep method's rules and am now checking what's published about Atlas Freight (values, interview process, recent news) before I build your pack.
I've saved your prep pack as `atlas-freight_operations-manager_interview_pack.md`. You don't know who's interviewing you, so I gave equal weight to all seven interviewer styles. I tried three web searches on Atlas Freight but they weren't permitted in this session. That means everything in the pack comes from the JD and background you gave me, and nothing in it claims a fact about the company.

What's in it:
- **A fit snapshot** matching each JD line to what you told me.
- **21 practice questions** with answer guidance.
- **Six questions for you to ask them.**
- **A list of claims to avoid.**

The question most worth rehearsing is **A1**: "you lead 3 supervisors today, this role leads 12 across four sites." Some version of it is almost certain to come up. The other two gaps to have answers ready for:
- **Power BI:** you've never used it.
- **Leadership years:** the JD asks for "5+ years operations leadership," and seven years in ops doesn't answer that by itself. Have your real count ready.

If you want, I'll play the Skeptic and put you through A1 with follow-ups, then give feedback.
I can also save a `tuesday-dossier.md` recording the gaps this prep turned up, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you know what kind of round this is (HR screen, hiring manager, panel or site visit), and has the recruiter mentioned any focus areas or a presentation or case? This would change how the questions are weighted, and it's usually one email to the recruiter.
2. Would you like me to research Atlas Freight if you allow web search? That means up to 6 searches. I can also run a deeper pass of 6 more searches, which takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack — Operations Manager, Atlas Freight

- **Role:** Operations Manager — own daily terminal operations across 4 sites, lead 12 supervisors
- **Company:** Atlas Freight (regional logistics, 800 employees, per the JD you pasted)
- **Interviewer:** unknown; round type unknown
- **Built on:** the JD text and the background in your message. Web research was attempted and refused by this session's permissions, so nothing here about Atlas Freight comes from outside your message.

## How to use this pack

Two axes. **Personas** are how a question arrives — the tone and pressure of the person asking. **Types** are what the answer is scored on:

- **JD** — can you do the listed job, gaps included
- **EXP** — does what you said about your past survive close questioning, including what was actually yours
- **CASE** — a live problem from the role; scored on structure and reasoning, not one right answer
- **CO** — homework on the company: strategy, recent moves, competition
- **VAL** — past behaviour against the company's values or general behavioural themes

Every bank row carries a Provenance label: `[grounded]` traces to your message or the JD; `[inferred]` is this pack's derivation, named; `[generic]` is a pattern for this kind of role with no claim about Atlas Freight or you. Where guidance rests on something you said, your exact words sit in the Provenance cell beside it.

**Answer slots** are places the material you gave me doesn't say what happened. Each one names the likely probe and gives two honest branches. Fill them from memory, in your own words, or say plainly that it wasn't so. Never fill them from what the job "usually involves."

Guidance is scaffolding, not a script. Each answer should run 90–120 seconds out loud.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and the site's surge plan. It doesn't say terminal operations or several sites, and the words stay at that scope: "I've spent seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's daily-operations line makes a probe on what you run day to day likely. Say which parts of the operation are yours to run each shift, in your own words. If a part isn't yours, say so plainly and stay with what is |
| F2 | "drive on-time performance … down" (on-time half) — JD | none given | none | [grounded] | discovery | Your material doesn't mention on-time performance. Answer slot: if you track or answer for on-time or service numbers today, say which and how, in your own words. If you don't, say so plainly and say what you'd look at first here |
| F3 | "drive … cost-per-shipment down" (cost half) — JD | none given | none | [grounded] | discovery | Your material doesn't mention cost per shipment, labour cost or budget. Answer slot: if any cost number is yours to manage or report today, say which. If none is, say so plainly and walk through how you'd learn this one |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The likeliest objection in the pack: three supervisors today against twelve in the role. Words at the quote's own scope: "Today I'm a senior shift manager over three supervisors." Answer slot: the JD's supervisor line makes a probe on how you lead them likely. If you have a way you set expectations for, coach or hold your three supervisors accountable, describe it in your own words. If there's no set way, say so plainly and describe the role as it is |
| F5 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops isn't the same as seven years leading, and your material doesn't say when you started having people report to you. This isn't an eligibility gate, but it's the kind of line a screener may check literally, so have the count ready. Answer slot: say what your roles were across the seven years and when you first had people reporting to you, as it was. If that's under five years, say the real number plainly and point to the three supervisors you lead now |
| F6 | "build reporting in Excel/Power BI" (Excel half) — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill level, not reporting you built. The material doesn't show whether it reaches the requirement. Answer slot: if you've built a report, tracker or schedule in Excel that other people use, say what it tracks and who uses it. If you haven't, say so plainly and say what you'd build first |
| F7 | "build reporting in Excel/Power BI" (Power BI half) — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording can't close, and you've said so. Words: "I've never used Power BI." Then how you'd learn it, said as a plan and never as a past. Nothing added to make the gap look smaller |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but nothing has been inspected yet, so expect a probe. Lead with the credential in its own words: "I'm green belt certified." Answer slot: the JD's Lean/Six Sigma line makes a question on using the methods likely. If any of your work used them, say which piece and how, in your own words. If none did, say so plainly and stay with the certification |

## Persona table

No loop source told me how Atlas Freight interviews, so these weights use the **generic archetype** (screen → hiring manager → panel). That means flat weights, and they rest on a pattern, not on Atlas Freight's process. Tell me who you're meeting and they'll reweight.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Probes the scale jump: three supervisors to twelve, the site to four sites, warehouse to terminal | Flat weight, but this is where the pack's highest-ROI question lives (A1, from F4). One extra question because F5's leadership-years line needs a JD-tagged probe | Rehearse A1 until it bores you. Bridge only from what you said; give the limit before they ask; add a concrete ramp plan |
| Case/Strategist (bank B) | Live problems: an on-time drop, a cost target, peak planning across sites | Flat. The JD's two named outcomes, on-time and cost per shipment, are natural case material for any ops-leadership interviewer | Clarify → objective → segment → approach → metrics → risks, out loud |
| Data-Driven Prober (bank C) | Takes the 40% apart: baseline, period, who did what | Flat. A headline number in your background always draws this | Know what you can and can't say about how the 40% was counted, and say plainly where you don't know |
| Pressure (bank D) | Time-boxed "why you," "how much was you," the Power BI gap pushed hard | Flat | Pause, restate, anchor in what you said, hold through two follow-ups, then concede what's real |
| Values/Behavioral (bank E) | Behavioural "tell me about a time" questions | Flat, but two questions instead of three: the generic archetype has no dedicated values round, and no published values were in hand | STAR shape; "we" for context, "I" for your part |
| Conversational (bank G) | Friendly opener, "why us," a casual question on Lean | Flat. Present in almost any round, and it's scored even when it feels like small talk | A rehearsed 90-second arc; treat casual questions on JD topics as scored |
| Peer Evaluator (bank H) | Existing supervisors or fellow managers testing whether you'd help or add work | Flat. A panel or site visit could include them | Reciprocity framing; propose working principles rather than pretend to know their seams |

There's no bank F, so question IDs don't clash with fit-snapshot rows F1–F8.

## Question banks

### Bank A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads 12 supervisors across four sites. You're over three supervisors today. Why are you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | **The highest-ROI rehearsal in this pack.** Open with the fact at its real size, with no rounding and no apology: "Today I'm a senior shift manager over three supervisors." Then the surge plan as stated: "I ran the site's peak-season surge plan two years running." Answer slot: the probe will be how you lead supervisors. If you have a way you set expectations for, coach or hold your three accountable, describe it in your own words. If there's no set way, say so plainly and stay with the role as it is. Then the ramp plan, stated as a plan: how you'd learn four sites and twelve supervisors in your first 90 days. Name the limit before they do: "Twelve is four times the three I lead today." Hold through two follow-ups by returning to what you lead now, never by adding to it | F4 is the biggest gap between the JD and your material, so some form of this will come. JD because it scores a stated requirement directly |
| A2 | "I don't see freight terminal work in your background. How would you handle terminal operations here?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say what you have, in its own words: seven years in warehouse and distribution ops. Don't relabel it as terminal work. Answer slot: the probe will be what you run day to day. Say which parts of the operation are yours each shift, in your own words. If a part isn't yours, say so and stay with what is. Then the plan: how you'd learn a terminal's flow, such as time at each site, its cut-offs and its exceptions, and what you'd ask the supervisors first | F1's kind-of-work gap. JD because terminal operations is the first line of the role |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" "solid Excel" | Name it plainly: "I've never used Power BI." Then what you do have: "My Excel is solid." Then a learning plan with a date, stated as a plan, for example a course and your first dashboard by a set week. Don't choose a fake weakness. A real one, named calmly, scores higher | F7 is the one gap you stated yourself, which makes it the honest answer to this stem. JD because it maps to the reporting requirement |
| A4 | "Of your seven years, how many have you actually been leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Answer slot: say your roles across the seven years and when you first had people reporting to you, with the real number. If it's under five, say so plainly and point to the three supervisors you lead now. Don't count ops years as leadership years | F5's literal-screen risk. JD because the 5+ years line is marked required |

### Bank B — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our sites dropped 10 points last month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: how on-time is measured here, which customers or lanes, and when the drop started. Segment by shift, lane, carrier, day of week and cause code. Form hypotheses: volume spike, staffing, dock congestion, missed cut-offs, or a data or measurement change. Then the data you'd pull, a short-term containment step, the root-cause work, and how you'd report progress. Think out loud | F2's requirement, asked as a live problem. `[generic]` because no Atlas Freight facts went into it |
| B2 | "You need cost-per-shipment down 5% this year without hurting on-time. Where do you look first?" | CASE | [generic] | Decompose the number: what goes into cost per shipment here (labour, overtime, handling, linehaul, claims and rework) and what the denominator is. Get the baseline by site. Find the biggest controllable lever, name the on-time trade-off for each, pilot at one site, then roll out. Ask how they calculate it, because that question itself scores | F3's requirement as a case. CASE delivery on JD content |
| B3 | "Peak is coming and you're responsible for four terminals. What does your plan look like?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Solve the live problem first: forecast, labour plan, equipment, dock schedule, carrier capacity, contingencies, and a daily review rhythm across sites. Then anchor in the quote: "I ran the site's peak-season surge plan two years running." Answer slot: say which parts of the plan you ran you'd reuse and which you'd rebuild for four sites, in your own words. If you're unsure what carries over, say so | Your strongest story against the multi-site requirement in F1, used as an anchor and not stretched to four sites |

### Bank C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-picks 40%. Walk me through how that was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State the result as you said it. Then the four defend-the-number slots, each in your own words: how it was counted (rate of what, over what period, against what baseline); what it's sensitive to; the assumption behind it you'd defend least, named before they ask; and which part was yours. For any you don't know, say "I don't know exactly how it was counted." That's an honest answer, and a guessed method breaks on the second question | The headline number in your background. EXP because it tests whether the figure survives close questioning |
| C2 | "What did the pick-path redesign actually change, and who else worked on it?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: describe what changed in the pick path, in your own words. Say who else was involved and what part was theirs. If it was all yours, say so; if parts were others', name them. "We" for the team, "I" for your part | C1's follow-up level. It's attribution honesty, rehearsed before anyone asks |
| C3 | "Which numbers do you look at every day, and what do you do when one goes red?" | JD | [grounded] | Open prompt. Name the numbers you actually look at today, in your own words. If you don't have a daily set, say so plainly and say which you'd watch here; the JD names on-time and cost per shipment. Then one real example of acting on a bad number, if you have one; if none comes to mind, say how you would handle it | F2, F3 and F6 together. JD because the role is measured on those numbers |

### Bank D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal supervisor who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" "cut mis-pick rate 40% by redesigning the pick path" | Pause, then about 60 seconds built only from the four quotes: seven years in warehouse and distribution ops, senior shift manager over three supervisors, the site's surge plan two years running, the 40% mis-pick cut through the pick-path redesign. Don't run down the internal candidate. Hold, then concede: "They'd know your terminals better on day one." Hold on what you bring; don't fold into "you should probably hire them" | Time-boxed composure test. JD because it's really asking whether you meet the role |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede. Answer slot: say which part was yours and which was others', in your own words, as in C2. Keep it calm and specific. If you're pushed twice, concede only what's real ("the team did X") and keep the part that was yours | The classic attribution probe, aimed at the figure C1 defends. Pressure delivery, EXP scoring |
| D3 | "You've never used Power BI, and the job says build reporting in it. Why should we wait while you learn?" | JD | [grounded] "never used Power BI" "solid Excel" | Don't argue the premise: "I've never used Power BI." Then: "My Excel is solid." Answer slot: if you've built Excel reports others rely on, name one and what it tracks. If not, say so plainly. Then the plan with dates. Hold: the reporting need is real and you have a plan; concede: there's a ramp | F7 pushed hard, with F6 as the bridge you can actually stand on |

### Bank E — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supervisor on your team wasn't performing. What did you do?" | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick a real case from leading your supervisors. It needs what the problem was, the conversation you had, what you did next and how it ended. Use STAR, "I" for your actions. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's 12-supervisor line (F4) makes supervisor performance a likely behavioural theme |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, what you said and to whom, the reaction, and what happened after. Pick one where the message actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem. `[generic]` because no Atlas Freight values were in hand |

### Bank G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your background." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc from these five quotes only: seven years in warehouse and distribution ops; now senior shift manager over three supervisors; the 40% mis-pick cut through the pick-path redesign; the site's surge plan two years running; green belt certified. End on why this role, in your own words. Rehearse it out loud three times | The opener in almost every round. A loose answer here costs the first impression |
| G2 | "What do you know about Atlas Freight, and why us?" | CO | [generic] | This pack has no company facts, because research didn't run. Before the interview, read their website and any recent news yourself and pick one specific thing to mention. Mention only what you've read. For "why us," answer in your own words; the JD's scope (four sites, twelve supervisors) is a fair thing to point to as the step you're after, if it is | CO coverage with research missing. `[generic]` because nothing about the company was verified |
| G3 | "Do you actually use your green belt day to day?" | JD | [grounded] "green belt certified" | Answer slot: if any of your work used the methods, name the piece and how, in your own words. If none did, say so plainly and stay with the certification. Don't recast the pick-path redesign as a belt project unless it was one | F8, asked casually because it's a JD plus |

### Bank H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You'd be over supervisors who've run these terminals for years. How do you earn their trust?" | CASE | [generic] | Plan, not a past: learn before changing anything (time on each site, one-to-ones, ask what they'd fix first), make a few early commitments and keep them, give credit visibly. Then what you bring them, such as removing a blocker or backing them upward | F1 and F4 from the supervisors' side. CASE because it's a forward-looking scenario |
| H2 | "Two of your site supervisors disagree on how to share labour or dock space during a crunch. What do you do?" | CASE | [generic] | Clarify the constraint and the goal (on-time, cost), hear both sides, decide on the data, explain the decision, and agree a rule for next time so it doesn't come back to you every crunch | Multi-site leadership is mostly arbitration between sites; peers test it |
| H3 | "What would you need from the rest of us to hit on-time?" | JD | [generic] | Reciprocity: what you'd give first (clear daily numbers, early warning on capacity) and what you'd ask for (accurate volume forecasts, quick escalation paths). Propose working principles; don't pretend to know their processes | F2's requirement from a peer's seat |

### Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own daily terminal operations across 4 sites | F1 | A2, B3, H1 |
| Drive on-time performance | F2 | B1, C3, H3 |
| Drive cost-per-shipment down | F3 | B2, C3 |
| Lead a team of 12 supervisors | F4 | A1, E1, H1, H2 |
| 5+ years operations leadership | F5 | A4, D1 |
| Build reporting in Excel | F6 | C3, D3 |
| Build reporting in Power BI | F7 | A3, D3 |
| Lean/Six Sigma a plus | F8 | G3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured across the four sites today, and where is it weakest?" | Shows you ask for the definition before the number, which is how a strong ops manager starts |
| R2 | "How is cost-per-shipment calculated here, and what's driving it at the site furthest from target?" | Ties straight to the role's second named outcome and tells you what you'd be walking into |
| R3 | "What's the reporting setup now? Is Power BI already in place, and who looks after it?" | Turns your known gap into a practical question and shows you've planned for it |
| R4 | "Tell me about the 12 supervisors: how long they've been in role, and the biggest development need?" | Signals you see leading supervisors as the core of the job |
| R5 | "How are the four sites different from each other?" | Shows you won't run four sites as one; you'd learn each |
| R6 | "What would a successful first 90 days look like to you?" | Gets their own success criteria, which you can then speak to directly |

## Prohibited claims

What this pack won't coach, and why. Built from the fit snapshot above.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run terminal operations, or operations across several sites | Inflated form of F1 | F1's quotes at their own scope: "7 years in warehouse and distribution ops", "ran the site's peak-season surge plan two years running". The limit is the pack's observation, not words for you: the material says warehouse and distribution ops and the site's surge plan, not terminals or several sites. The F1 slot stays inside what you run each shift |
| Has led a large team of supervisors, or more than the three stated | Inflated form of F4 | F4's quote at its own scope: "currently a senior shift manager over 3 supervisors". The A1 slot stays inside how you lead those three |
| Has five-plus years of people leadership | Inflated form of F5 (ops years read as leadership years) | "7 years in warehouse and distribution ops" at its own scope. The A4 slot asks when people first reported to you, with the real number |
| Has used or built anything in Power BI | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used Power BI." No slot |

## Sources

- **Provided:** your message — the JD text and your background, quoted in the fit snapshot.
- **Searches sent:**
  - `"Atlas Freight" values mission regional logistics` — refused (web search not permitted in this session)
  - `"Atlas Freight" interview process operations manager` — refused
  - `"Atlas Freight" news 2026 terminals` — refused
- No fetches were sent. No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have supplied published values to theme the VAL questions in bank E, and a values cheat sheet if a values round were known |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have tried to establish the loop and replace the generic-archetype flat weights |
| 3. `Atlas Freight` strategy / recent news | unavailable | Every call was refused. It would have grounded G2 and added CO or CASE questions on current priorities |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Who you're meeting and what kind of round** (hiring manager, HR screen, panel, site visit) → persona weights from that relationship instead of flat ones, and banks resized to match.
- **Web search allowed** → targets 1–3 above run: published values for bank E, the interview loop, and recent news for real CO and CASE questions in place of G2's homework note.
- **A deeper research pass** (with search allowed) → up to 6 more searches and 2 more fetches, several more minutes: strategy, recent org changes and any candidate reports on their interviews.
- **The interviewer's name** → an interviewer read, persona weights from their public professional footprint, and a reverse question tied to their path.
- **Any recruiter email or prep notes** → coverage of a declared presentation, case or site walk, and the round's stated focus areas.
- **How much prep time you have** → a prioritized prep schedule sized to it.
- **Your answers to the slots** (how the 40% was counted and who did what; when people first reported to you; Excel reports you've built; whether your work used green belt methods) → upgrades C1, C2, D2, A4, D3, G3 and fit rows F5, F6, F8 from slots to grounded story maps.
- **Your green belt certificate, or a before-and-after mis-pick report** → the artifacts that would let F8 and the 40% figure be inspected, so they can be coached with more confidence.
- **A tuesday-dossier.md from job-underwriter** → evidence-graded objections and a binding list of claims to avoid. Optional; this pack stands without it.
