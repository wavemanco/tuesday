Reading the skill's rules for building your prep pack; next I'll do a quick company search, then write the pack.
I've built your prep pack and saved it as `AtlasFreight_operations-manager_interview_pack.md`. You didn't say who you're meeting, so I prepared you for every common interviewer style at the same depth instead of tuning it to one person.

- **What to rehearse most (A1):** "You lead three supervisors today, and this role leads twelve across four sites. What makes you ready?" Some version of this question is almost certain. The pack shows you how to state the limit yourself, stand on the surge plan you ran, and offer a 90-day plan.
- **Your clear gap is Power BI.** The answer is simple: say plainly that you haven't used it, then say how you'll learn it. If you start learning before the interview, mention only what you've actually done.
- **Two things your notes don't settle**, and interviewers will check both:
  - how many of your 7 years were spent leading people (the job requires 5+)
  - whether your 40% mis-pick reduction did anything to cost per shipment

  The pack gives you an honest way to answer each.
- **I couldn't research Atlas Freight.** My searches were blocked in this session, so the "why Atlas Freight?" answers rest only on what you've read yourself.

The pack also has 21 practice questions with answer notes, a list of claims not to make, and six questions for you to ask them.

If you'd like, I'll play the skeptical interviewer on A1 for a live practice round.
I can also save a tuesday-dossier.md listing the gaps this prep turned up, so you can carry them into later sessions.
If you want the pack as a Word document, I'll convert it.

Who are you meeting (the hiring manager, a panel, HR, a site leader), and did the recruiter mention focus areas or anything to prepare, like a presentation? The answer changes how much weight each set of questions deserves.
If you allow web search, should I run a basic company check (values, interview process, recent news: up to 6 searches and 2 page reads), or also a deeper one (up to 6 more searches and 2 more page reads, several more minutes)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack — Operations Manager, Atlas Freight

Interviewer: unknown, and so is the round type. Persona weights are flat and the banks cover every persona at the same depth. That is a weaker pack than one built for a known interviewer, and the upgrade menu says what would sharpen it.

## How to use this pack

- **Personas** describe *how* a question arrives (a quiet skeptic, a numbers prober, a time-boxing stress interviewer). **Types** describe *what* is being scored.
- Type key:
  - **JD** — can you do the listed job, gaps included
  - **EXP** — does your background hold up under close questioning; what was actually you
  - **CASE** — a live problem from the role, solved out loud
  - **VAL** — behavioral stories ("tell me about a time…")
  - **CO** — what you know about the company and why it
- Provenance labels: `[grounded]` = traceable to what you told me or the JD; `[inferred]` = this pack's own derivation, named; `[generic]` = a common pattern for this kind of role, not a fact about Atlas Freight.
- An **answer slot** is a point where your material is silent. It tells you what the interviewer will probably ask and gives you two honest branches. Fill it from your own memory, or say plainly that it wasn't you or didn't happen.
- The guidance is scaffolding, not a script. Say it in your own words.
- Question IDs use letters A–E, G and H. F is skipped so they can't be confused with the fit-snapshot rows F1–F8.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution ops and one site's surge plan. It does not describe freight-terminal work or more than one site, and the words stay at that scope: "Seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on your scope likely. Say which parts of the site's operation were yours day to day, in your own words. Where a part wasn't yours, say so plainly and stay with what was |
| F2 | "drive on-time performance" — JD | none given | none | [grounded] | discovery | Strong evidence here would be an on-time measure you answered for, what it showed, and what you did about it. Answer slot: the JD names on-time performance, so expect a probe. If you tracked or answered for an on-time measure, say which one and what you did with it, in your own words. If you didn't, say so plainly and say how you would start measuring it |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | Your material ties the redesign to the mis-pick rate, not to cost, and the bridge shouldn't be stretched. Answer slot: the JD's cost-per-shipment line makes a cost probe likely. If you know what the pick-path change did to cost, say what was counted and how. If cost wasn't tracked, or you don't know, say so plainly and stay with the mis-pick rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I'm a senior shift manager over three supervisors." The gap between three and twelve is this pack's observation, not something to apologize for. Answer slot: the JD's twelve-supervisor line makes a probe on how you lead supervisors likely. If you have a way of developing, coaching or holding your three supervisors accountable, describe it as you actually run it. If there's no set way, say so plainly and describe how you would set one up |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill rating, and the material doesn't show what you use it for. Answer slot: the JD's reporting line makes a probe on your Excel work likely. Say what your Excel work covers, in your own words, with an example only if you have one. If none comes to mind, say so plainly and stay with "solid Excel" |
| F6 | "Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | Wording can't close this gap, and you've said so yourself. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. If you start learning it before the interview, say only what you've actually done so far. Nothing gets added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops is in your material. How many of those years were in a role leading people is not. The JD marks this as required, so expect it to be checked. Answer slot: say how many years you've led people and in which roles, counted plainly. If the count is under five, say the number plainly and stay with what those years held |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. It's a self-reported credential with nothing inspected behind it, so expect a probe. Lead with the certification in the quote's own terms. Answer slot: the JD's Lean/Six Sigma line makes "where have you used it?" likely. If you used green-belt methods on a piece of work, name which and how. If you haven't, say so plainly |

## Persona table

No loop source establishes Atlas Freight's interview process: the searches for it were refused (see Sources). The pack falls back to the **Generic** archetype (screen → hiring manager → panel) with flat weights, as stated here, rather than on a documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scale and domain jump: one site to four, three supervisors to twelve, warehouse to terminal | Flat, like every row. Banked first because F1, F4 and F6 are its natural material, and A1 is the highest-ROI rehearsal in the pack | Rehearse A1 until it's boring. Say the limit before you're asked. Bridge only from what F1 and F4 quote, then give a concrete ramp plan said as a plan |
| Data-Driven Prober | Goes two levels deep on the 40% figure and the years count | Flat. F3's figure and F7's count are the magnets | Know what you can and can't say about how the 40% was counted, and say "I don't know" where that's the truth |
| Case / Strategist | Live problems: an on-time drop, rising cost per shipment, a 90-day plan | Flat. A hiring manager for an operations role is the likeliest source if one is in the room | Clarify → objective → break it down → approach → metrics → risks. Think aloud |
| Pressure | Interrupts, time-boxes, "how much was actually you" | Flat. Common in operations interviews where composure on the floor matters `[generic]` | Pause, restate, anchor in what you actually stated, hold through two follow-ups, then concede the specific thing |
| Conversational | Friendly openers, "walk me through your journey", "why us" | Flat. A recruiter or HR screen is often the first round `[generic]` | A pre-built 90-second arc from your own facts. Treat casual questions as scored |
| Values / Behavioral | "Tell me about a time…" stories | Flat. No published values were in hand, so the questions are themed from the JD and common stems | Pick real stories with a clear "I". Where none comes to mind, say so plainly and give the nearest real one |
| Peer Evaluator | A site manager or peer asking how you'd work alongside them | Flat. Plausible in a panel with other site leads | Offer reciprocity (what you bring them) and propose working principles rather than pretending to know their seams |

## Question banks

Highest-ROI prep in this pack: **A1**, the scale-jump objection. It will come in some form.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today, and this role leads twelve across four sites. What makes you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | Name the limit first, in the quote's terms: "Today I'm a senior shift manager over three supervisors." Then the fact the quotes carry: "I've run the site's peak-season surge plan two years running." Then the plan, said as future: how you'd learn four sites in the first 90 days. Answer slot: the JD's twelve-supervisor line makes a follow-up on how you lead supervisors likely. If you have a way of developing or holding your three accountable, describe it as you actually run it. If there's no set way, say so plainly and stay with the surge plan. Hold through two follow-ups by returning to those two facts, never by adding to them. Concede the jump is real, and say specifically what you'd need to learn | F1 and F4 are where this role presses hardest on this background, so the objection is near-certain. JD because it scores the headline scope requirement. Deepest rehearsal, because the pull to make the gap sound smaller is strongest here |
| A2 | "I don't see Power BI in your background. How would you handle the reporting side of this role?" | JD | [grounded] "solid Excel, never used Power BI" | Plain first: "I've never used Power BI." Then "solid Excel", at that scope and no wider. Then a learning plan said as a plan. If you've started learning before the interview, say only what you've actually done. Don't fill the silence with claims about reports you've built. F5's answer slot covers what your Excel work is | F6 is the one stated capability gap. The interviewer's negative is sourced by your own sentence. JD because the reporting line is a stated responsibility |
| A3 | "This is a freight-terminal role and your background is warehouse and distribution. Why would that carry over?" | JD | [grounded] "7 years in warehouse and distribution ops" | Describe what you did in your own words and let the interviewer draw the connection. Don't assert that the two are the same work. Answer slot: say which parts of warehouse and distribution ops were yours day to day. If a part wasn't yours, say so plainly. Then turn it into curiosity: ask what they see as the biggest difference at their terminals | F1's transferability gap, which is a domain question as well as a scale one. JD because it tests the stated terminal-operations scope |

### B — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot, in your own words: how the 40% was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours. Name that weakest assumption before they do. "I don't know exactly how it was counted" is an honest branch, so use it if it's true. This pack supplies no baseline or method, and you shouldn't improvise one | F3's figure is the headline metric in the background, and every headline metric gets a defend-the-number question. EXP because it tests the claim itself |
| B2 | "What exactly did you change in the pick path, and which part of that was you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | The beats the quote states: the redesign of the pick path, and the mis-pick rate it cut. Fill in what changed from memory, in your own words. Answer slot, which part was yours: say it precisely, "we" for the team and "I" for you. Answer slot: the JD's Lean/Six Sigma line makes "did you use your green-belt training on it?" likely. If you did, name which methods and how. If you didn't, say so plainly, because the redesign stands on its own | F3 and F8 meet here, and an interviewer who sees both will connect them. EXP because it probes attribution |
| B3 | "The JD asks for five-plus years of operations leadership. How many of your seven years were leading people?" | JD | [inferred] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give the count plainly, with the roles. If it's under five, say the number plainly and stay with what those years held. Don't round up, and don't relabel individual-contributor years as leadership | F7: the requirement is marked required and the material doesn't settle it. JD because it scores a stated qualification |

### C — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance at one of our terminals dropped sharply last month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is defined, which lanes or shifts, and when it started. Then split it: volume change, staffing and attendance, dock and door flow, inbound arrival timing, outbound departure, and system or data changes. Say what data you'd pull for each and in what order. Then the fix, and how you'd keep it from coming back. The question needs no claim about your past, so the guidance makes none | The JD's on-time line (F2's requirement) asked as a live problem. Generic because it's a pattern for the problem, not a fact about Atlas Freight |
| C2 | "Cost per shipment is up across the four sites. Where do you look first?" | CASE | [generic] | Clarify the measure: what's in the cost, and what counts as a shipment. Then check whether it's every site or one, and whether volume or mix moved, because a falling denominator raises cost per shipment without any cost going up. Then break down the main cost buckets by site and look for the outlier. Close with one quick win and one structural fix | The JD's cost-per-shipment line (F3's requirement). CASE because it scores structure on the role's own metric |
| C3 | "Your first 90 days across four sites and twelve supervisors: what's the plan?" | CASE | [generic] | Learn → measure → standardize. Visit every site, meet all twelve supervisors one to one, agree one shared set of measures (on-time and cost per shipment, the JD's two), find the biggest gap between sites, and fix one thing visibly by day 90. Say what you'd *not* change in the first month, and why | F1 and F4's scale questions, answered with a plan rather than a past, which is the honest place to show readiness |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over one of our internal supervisors?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, then three facts at their own scope: you cut the mis-pick rate 40% by redesigning the pick path, you ran the site's peak-season surge plan two years running, and you're green belt certified. Concede the one thing an insider has, which is knowing their sites, and say how fast you'd close it. Don't run down internal candidates | Draws on F3, F1 and F8. JD because it's a fit judgment against the role, delivered under a time box |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold, then be precise. Answer slot: which part of the redesign and the result was yours, in your own words. Others who were involved get named as "we". If the interviewer pushes twice, keep returning to your part. Concede the shared parts specifically, and don't give up the part that was yours just to ease the tension | F3's figure under attribution pressure. EXP because it scores honesty about contribution |
| D3 | "Running one site's peak plan isn't running four terminals every day. Convince me." | JD | [grounded] "ran the site's peak-season surge plan two years running" | Restate it, then agree with the true part: it's a different scope. Hold on what the quote carries: you ran the site's peak-season surge plan two years running. Then switch to C3's plan for the scale. Don't claim the plan was bigger than one site, and don't describe it as something you built unless you did | F1's scope gap delivered as a challenge. JD because it scores the headline requirement |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | A 90-second arc from those facts: seven years in warehouse and distribution ops, now a senior shift manager over three supervisors, the pick-path redesign that cut mis-picks 40%, and the green belt. End with why this role is the next step, in your own words | The opener in almost any round. EXP because it's your history, and it sets the frame for everything after |
| E2 | "What draws you to Atlas Freight?" | CO | [generic] | This pack has no research on Atlas Freight because the searches were refused. Use only what you've actually read yourself, and say where you read it. Anchor on the JD's own scope: four sites, on-time performance, cost per shipment, Lean a plus. Don't repeat anything about the company you can't point to a source for | CO questions go generic without research, and that's the honest cost of the blocked searches. Asked casually, but scored |
| E3 | "Are you using any Lean tools these days?" | EXP | [grounded] "green belt certified" | Answer slot: if you're using green-belt tools in your current work, say which and on what. If you're not, say so plainly and say where you'd apply them in this role | F8's plus-skill, asked casually. EXP because it tests whether the credential is in use |

### G — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to correct a supervisor's performance." | VAL | [generic] | Selection scaffold: pick a time with a named problem, a conversation you led, and a result you can state. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Themed from the JD's twelve-supervisor line (F4's requirement). VAL because it scores past behavior, and no published Atlas values were in hand to map it to |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a stake, a moment you said it anyway, and a relationship that held up afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common behavioral stem. Operations managers for multiple sites carry bad news upward, so it tests candor |
| G3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a real trade-off where you chose the customer, say what it cost internally and why it was right. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common stem that sits close to the JD's on-time line (F2's requirement), where customer and cost pull against each other |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Two sites want the same people or equipment on the same day. How do you settle it with the other manager?" | CASE | [generic] | Propose principles: agree the rule before the conflict (customer commitments first, then cost), escalate together rather than around each other, and look back afterwards. Describe the principle, not a story you don't have | Peer seam question for a multi-site role. CASE because it's a live problem, not a record |
| H2 | "What would you need from me in your first month, and what would you bring my team?" | CASE | [generic] | Reciprocity first: what you'd bring them, such as a shared measure set and a fresh pair of eyes on flow. Then what you'd need: their site's norms, and an honest read on the supervisors. Keep it specific to the JD's scope | Peer evaluators price what you'll cost and contribute. CASE because it's forward-looking |
| H3 | "If you had to build a weekly report for four sites tomorrow, what would it show?" | JD | [grounded] "solid Excel, never used Power BI" | Content first: on-time and cost per shipment by site, trend lines, and the one exception each supervisor owns. Tool second: you'd build it in Excel now, since that's "solid Excel" in your own words, and you'd learn Power BI on a stated plan. Don't describe past reports as built unless F5's answer slot says you built them | F5 and F6 in one question. JD because it scores the stated reporting responsibility |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, C3, D3 |
| Drive on-time performance | C1, G3 |
| Cost-per-shipment down | C2 |
| Lead a team of 12 supervisors | A1, C3, G1 |
| Build reporting in Excel/Power BI | A2, H3 |
| 5+ years operations leadership required | B3 |
| Lean/Six Sigma a plus | B2, E3 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is on-time performance measured today, and how much do the four sites differ on it?" | Shows you think in the role's headline metric and want the baseline before you promise anything |
| "What goes into cost per shipment in your numbers?" | Signals rigor about definitions, which is the same move as C2's case |
| "Where are the twelve supervisors in their development? Are any new to the role?" | Tells you what the leadership job actually is and shows you're thinking about the team |
| "What reporting exists today, and how much of it is in Excel versus Power BI?" | Gets the real tooling picture so you can size your Power BI ramp honestly |
| "What would make the first six months a clear success for this role?" | Gets their scoring sheet in their own words |
| "What's the biggest difference between the four sites today?" | Opens the multi-site conversation on their terms and gives you material for follow-ups |

## Prohibited claims

What this pack won't coach, and the honest form for each. These are the claims a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations, or ran operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution ops and one site. F1's slot stays inside the site |
| Designed or built the peak-season surge plan | Inflated form of F1 ("ran", not "built") | "I ran the site's peak-season surge plan two years running" |
| Led a team of twelve, or a large supervisory team | Inflated form of F4 | "I'm a senior shift manager over three supervisors." A1's slot stays with the three |
| Seven years of operations leadership | Inflated form of F7 | "Seven years in warehouse and distribution ops." B3's slot asks only for the plain count |
| Built reporting in Excel | Inflated form of F5 | "Solid Excel", at its own scope. F5's slot asks only what your Excel work covers |
| Has used Power BI | Negative you stated, F6 | "I've never used Power BI." No slot |

## Sources

- Provided documents: the JD text and your background, both in your message.
- Searches sent:
  - `"Atlas Freight" logistics company values`: refused
  - `"Atlas Freight" interview process operations manager`: refused
- Fetches sent: none.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The one call sent was refused. It would have given the official value names, the VAL bank's themes and, if a values-style round were found, a values cheat sheet |
| 2. `Atlas Freight interview process operations manager` | unavailable | The one call sent was refused. It would have named the actual rounds and moved persona weights off flat |
| 3. `Atlas Freight` strategy / recent news | unavailable | Not sent, because search was refused in this session. It would have grounded E2 and given one CO or CASE question on current priorities |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. No interviewer read |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting and what kind of round it is → persona weights move off flat, and the banks are reweighted and resized around that interviewer
- The recruiter's prep note (focus areas, anything to prepare) → a build section for any announced presentation or case, and coverage keyed to their stated focus
- Interviewer name(s) → a read of their public professional background, and at least one reverse question tied to their path
- Web search allowed in this session → official Atlas Freight values (and a cheat sheet if a values round turns up), the real loop structure, and a grounded E2 and strategy question. A deeper pass is also available on request: up to 6 more searches and 2 more page reads, several more minutes, for a strategy brief and recent company context
- Your green belt certificate or a project write-up in hand → F8 moves from `medium` to `high`
- Your answers to the answer slots in F2, F3, F5 and F7 (on-time measures, cost effect, Excel work, leadership years) → those rows and A1, B1, B3, C1 and H3 become story-mapped instead of slots
- How much prep time you have → a prioritized prep schedule sized to it
- A `tuesday-dossier.md` from the job-underwriter skill → evidence-checked claims, a verified highest-ROI objection and a ready-made prohibited list. This pack doesn't need one
