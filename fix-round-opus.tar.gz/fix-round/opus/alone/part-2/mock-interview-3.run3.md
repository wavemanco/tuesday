Your prep pack is saved as `stripe_product-operations-manager_interview_pack.md`. It has 21 practice questions, each with answer guidance, plus a self-assessment worksheet and reverse questions. It isn't tailored to Stripe yet. You didn't include a job description, your CV or who you're meeting, and web search wasn't allowed. So it uses typical Product Ops requirements and gives every interviewer style equal weight. Each answer is a framework for you to fill with your own stories, not a script.

Say the word and I'll play the skeptical interviewer on A1, "Which part of this role would you be weakest at on day one?" The pack names that as the most valuable thing to rehearse.
I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is on your final-round schedule (your future manager, peers, people from other teams, someone more senior), and did the recruiter mention focus areas or anything to prepare, like a presentation or case? The answer changes how each set of questions is weighted.
Can you paste the job description and your CV, or a few lines about your background? Or say skip and I'll keep this general version.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — Final-round prep pack

Round: final round. Interviewers and their relationship to the role: not yet known. Built from your one-line request alone: no JD, no CV, and web research was declined, so every row is labeled `[generic]` and every answer is a scaffold for you to fill with your own stories.

## How to use this pack

Two axes. **Personas** describe how a question will be asked: who, in what register. **Types** describe what is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behavior shows a value through a specific decision, not generic virtue |
| EXP | Whether your account of your own work survives scrutiny, and what was actually yours |
| JD | Whether you can do the stated job, gaps included |
| CO | Homework depth on the company and whether you can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Because I have nothing about your background yet, no cell tells you what you did. Each one tells you what a strong story needs and how to say so plainly if you don't have one. Rehearse aloud, in your own words.

## Fit snapshot (worksheet)

With no JD, the requirements below are typical product-operations requirements, not Stripe's. With no CV, this is a self-assessment worksheet: fill in the evidence column yourself before the interview.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running launch readiness across functions such as support, sales, docs and risk, typical of product-ops roles | none given | none | [generic] | discovery | Strong evidence is a named launch, what readiness meant for it, which pieces were yours, and what happened after release. Pick a launch where you coordinated more than one team toward a date. If no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Building feedback loops that carry customer, support and sales signal back to product teams, typical of product-ops roles | none given | none | [generic] | discovery | Strong evidence is a loop with a source, a route, an owner on the product side, and a decision it changed. Pick a time customer signal reached a product decision through something you set up or ran. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Defining and tracking operational metrics, with hands-on data work, typical of product-ops roles | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: what it counted, its denominator, and what it would miss. Pick a number you tracked or reported and can defend at that depth. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Designing and scaling processes, playbooks and tooling, typical of product-ops roles | none given | none | [generic] | discovery | Strong evidence is a before and after: what broke, what you changed, who adopted it. Pick a process change that other people kept using. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influencing product, engineering and go-to-market teams without direct authority, typical of product-ops roles | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team, your position, how it was settled, and the relationship afterwards. Pick a time you moved a team you did not manage. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritizing between competing requests under ambiguity, typical of product-ops roles | none given | none | [generic] | discovery | Strong evidence is a real trade-off you made, the criteria you used, and who you told no. Pick a time two asks collided and you had to choose. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Communicating operational status and risk clearly to leadership, typical of product-ops roles | none given | none | [generic] | discovery | Strong evidence is a message you wrote or delivered that changed a decision, including bad news. Pick a time you told leadership something they did not want to hear. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

No loop source establishes how your final round is structured, so the weights fall back to the **Generic** archetype: flat weights, said plainly. Every persona gets three questions, so you meet every style in rehearsal before you meet it live. When you know who is on your schedule, these weights get recomputed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of fit and motivation: why this, why now, where you are weakest | Flat. Carries the pack's highest-ROI question, A1, so it is listed first | Rehearse A1 until it is boring; bridge only from work you actually did; give a concrete ramp plan |
| Case / Strategist | Live problems from the role: plan a launch, diagnose a metric, design a loop | Flat. F1 to F4 are all problem-shaped, so this is where those requirements get tested | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise per case |
| Values / Behavioral | "Tell me about a time…" stories, and scenarios where the right answer costs something | Flat. Stripe's published values were not researched, so this bank uses standard prompts rather than Stripe's own value names | Pick stories where the hard truth actually landed; "we" for context, "I" for your part |
| Peer Evaluator | Seams between teams, what you would need from them, credit and disagreement | Flat. F5 is the requirement a peer prices most directly | Offer reciprocity: what you bring their team, not just what you need; propose seam principles, don't pretend to know the seam |
| Data-Driven Prober | Asks for denominators, assumptions, and what a number misses | Flat. F3 is tested here, and any number you say aloud today becomes a target | Know what you can and can't say about how each number was counted; name your weakest assumption first |
| Pressure | Time-boxes, interrupts, forces a call | Flat. Tests composure on F6 | Pause, restate, answer in the time given; hold your position through two follow-ups before conceding anything real |
| Conversational | Friendly openers that are still scored | Flat. The biography question and "what did you look at" are cheap to fumble | Have a scripted 90-second arc; treat casual questions as scored |

## Question banks

Every row is `[generic]`: no row rests on a sentence of yours, because I have none yet. Where a question asks about your past, the guidance is a selection scaffold. Where it is a live problem, the guidance is a structure.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI rehearsal in this pack.** Choose one real requirement from F1 to F7 where your worksheet evidence is thinnest, and name it plainly in one sentence. Then the nearest work you actually did, at its real size, then a concrete 30-day ramp: who you would learn from, what you would read, what you would ship first. Hold-then-concede: if pushed ("isn't that core to the job?"), hold that the ramp is credible, and concede the specific thing you have not done yet in exact words. Don't fold into "I'd be weak at everything", and don't name a fake weakness | A Skeptic objection to some version of this is close to certain in a final round where someone is derisking a hire, so a rehearsed, non-defensive answer moves the interview. JD because it scores your read of the stated job against yourself. It becomes candidate-specific once your CV fills the worksheet |
| A2 | "Why this role, and why now?" | JD | [generic] | Three beats, 60 to 90 seconds: what draws you to product operations as work, what about this role specifically, and why the timing is right for you, in your own words. Every reason should be one you'd still give if the interviewer asked "and what else?" Avoid reasons that only flatter the company | It tests whether your motivation holds up under cross-examination. JD because it is anchored to the role, not the company's strategy |
| A3 | "Product ops means different things at different companies. What do you think it means here?" | CO | [generic] | Give your working definition of the function first: the work between product and the teams who launch, sell and support it. Then say what you would expect it to own here and what you would expect it not to own. Close by saying you would confirm the boundary in the first weeks, and offer reverse question R1. Don't claim knowledge of Stripe's org you haven't read in its own published material | It tests whether you can think about the role's scope rather than recite a title. CO because the answer has to sit at the company's level; it stays generic until Stripe research runs |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We're launching a new feature to existing users in six weeks. Sketch the launch-readiness plan. What do you need to know first?" | CASE | [generic] | Clarify: which users, what risk if it fails, what is fixed (date or scope). Objective: what "ready" means. Workstreams: support (training, macros, escalation path), go-to-market (messaging, enablement), docs, risk or compliance review if money or regulated data moves, and a rollback plan. Cadence: a readiness review at fixed checkpoints with clear go/no-go owners. Metrics for after launch. Risks: the one workstream most likely to slip, and what you would do about it | Tests F1 directly as a live problem. CASE because it asks for no past, only structure |
| B2 | "Support contacts about one product area rose 20% last month. Diagnose it." | CASE | [generic] | Clarify first: 20% of what base, which channel, new or repeat contacts, did volume or user count change. Segment: by contact reason, user segment, release date, region. Hypotheses: a release, a docs gap, a policy change, a bug, seasonality. Say which data tells them apart, and what you would do this week versus after confirming. Name the metric you would watch to know it's resolved | Tests F3 and F2 through the classic diagnose-a-metric format. CASE because it is a live problem |
| B3 | "Product teams say they never hear the customer feedback that sales and support collect. Design the loop." | CASE | [generic] | Sources and their bias (sales hears prospects, support hears pain). Intake: one place, light tagging. Synthesis: who turns raw tickets into themes, and how often. Route: a named owner on each product team and a regular forum. Close the loop: tell the teams that sent it what happened. Success measure: decisions changed, not tickets logged. Expect E1 as the follow-up | Tests F2. CASE because it is design, not history; E1 is written to follow it |

### C — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a named stake, what you said and to whom, why it was unpopular, and what happened next, including whether it landed. "We" for context, "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F7 and composure. VAL because it scores behavior through a specific decision. It gets re-themed onto Stripe's own principles once they are fetched |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: it needs the metric, the customer situation, the choice you made, what it cost, and what you'd do again. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F2 from the values side. VAL because the scoring is on the trade-off you chose |
| C3 | "Leadership has fixed a launch date. You believe support isn't ready. What do you do?" | CASE | [generic] | Separate facts from worry: what exactly isn't ready, and what is the customer impact if you launch anyway. Options: launch with mitigations, a staged rollout, or a delay with a date. Bring a recommendation, not just a concern, in writing, with the risk quantified as far as you honestly can. Escalate once, clearly; then commit to the decision made and work the mitigations | Tests F1 and F7 under a values tension. CASE because it is a live scenario; the values persona uses it to see whether you hold a line and still commit |

### D — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't guess their org. Offer seam principles: one owner per decision, written agreements on handoffs, and disagreement handled first between the two of you, with data, before escalating together. Then ask them where the seam rubs today. Asking that here shows curiosity, not evasion | Tests F5 as a peer prices it. CASE because it asks for principles, not history |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your principle in a sentence, then back it with a story. Selection scaffold: a piece of shared work where you named others' contributions, or where credit went wrong and you fixed it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests partnership fit. VAL because it scores behavior, not skill |
| D3 | "Say I run one of the teams you'd support. What would you need from me in your first 90 days, and what would I get from you?" | JD | [generic] | Reciprocity first: what they get (fewer surprises at launch, a clear intake, feedback that's already sorted). Then what you need: access to their roadmap, a named contact, and one early problem to fix together. Keep it concrete and short | Tests whether the hire adds to or lightens the peer's load. JD because it scores how you read the role's job |

### E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "For the feedback loop you just designed, how would you know in three months it's working? Which metric, and what's the denominator?" | CASE | [generic] | One leading metric (share of themes with a product owner's response within a set time) and one lagging metric (decisions or roadmap items that cite the loop). Give the denominator explicitly. Name what each metric misses, for example volume can rise because tagging improved, not because the pain did | Tests F3 at depth on your own in-interview design. CASE because it extends B3 |
| E2 | "In the plan you just gave me, which assumption would you defend least?" | CASE | [generic] | Name it before they do: one assumption, said plainly, why it's the weakest, and how you'd test it cheaply in the first weeks. This is the weakest-assumption move, and it turns a gotcha into a credibility gain | Can follow any CASE answer here, especially B1 and G3. CASE because it probes your live reasoning, not your past |
| E3 | "A dashboard shows launch adoption up 30% quarter over quarter. Before you report it upward, what do you check?" | CASE | [generic] | Definition (what counts as adopted), denominator (did the eligible base grow), the comparison window and seasonality, data pipeline changes, and whether a few large users drive it. Then how you'd say it to leadership: the number, its caveat, and what it does and doesn't mean | Tests F3 and F7 together. CASE because it is a live judgment call |

### F — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Don't attack the internal candidate. Three beats inside 60 seconds: an outside view the team doesn't have, the thing from your own work that transfers most directly, and how fast you'd be useful. Stop at sixty seconds. Finishing on time is part of what's scored | Tests composure and a short answer under a time-box. JD because it asks you to price yourself against the role |
| F2 | "You've had fifteen minutes on this case and haven't landed a recommendation. Give me one now." | CASE | [generic] | Pause for a beat, then give one recommendation in one sentence, the one reason, and the one risk you'd watch. If pushed again, hold it once with your reason; concede only something specific and new, and say exactly what would change your mind | Tests F6 and F7 under pressure. CASE because it lands on whatever case is running |
| F3 | "Two product teams both want the ops support for their launches in the same week. You have one minute — choose." | CASE | [generic] | State the criteria you'd use out loud first (customer impact, risk, reversibility, date flexibility), pick one, and say what the other team gets instead and who tells them. Hold-then-concede: hold the choice through a challenge; concede only if a criterion you named actually flips | Tests F6 directly. CASE because it is a live trade-off |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [generic] | A 90-second arc you've scripted ahead of time: where you started, the two or three moves that matter for this role and why you made each, and the line that lands on product operations at Stripe. Every claim in it should be one you'd happily be probed on, at its real size | Cheap to fumble and almost always asked in some form. EXP because the arc gets cross-examined later in the loop |
| G2 | "What have you looked at or used of Stripe's products while getting ready for today?" | CO | [generic] | Only what you actually did: name it, what struck you, and one operational question it raised for you. If you haven't used anything hands-on, say so and say what you read instead | A casual question that scores your homework. CO because it measures company preparation |
| G3 | "You inherit a manual process that three teams depend on and that breaks every week. What do you do in your first month?" | CASE | [generic] | Week one: map it and talk to all three teams; don't change anything yet. Then stop the bleeding with the cheapest fix for the most frequent break. Then decide what to redesign versus what to automate, with owners and a success measure. Communicate the plan before you change the process | Tests F4. CASE delivered in a casual register, which is exactly where it's easy to under-answer |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | B1, C3, A1 |
| F2 Feedback loops | B3, E1, C2 |
| F3 Metrics and data | B2, E1, E3 |
| F4 Process design and scaling | G3, E2 |
| F5 Cross-functional influence | D1, D2, D3 |
| F6 Prioritization | F3, F2 |
| F7 Communicating to leadership | C1, C3, E3, F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Where does product ops end and product management begin on this team today?" | Shows you're thinking about scope and turf before day one, and the answer tells you what the job really is |
| R2 | "What's one launch from the last year that went less well than you wanted, and what changed afterwards?" | Invites a real story instead of a pitch, and shows whether the team learns from misses |
| R3 | "What would make you say, six months from now, that this hire was clearly the right call?" | Turns the interviewer's private scorecard into something you can hear and plan against |
| R4 | "Which team does this role lean on most, and which leans on it most?" | Reveals the real stakeholders and where the friction is, which is the core of product ops |
| R5 | "What's the biggest operational problem you'd want the new person to take off your plate first?" | Reciprocity framing: it shows you're thinking about their load, and it gives you your first-90-days story |
| R6 | "How are decisions written down and shared here?" | Asks how the team communicates, which you'll live inside every day, without assuming the answer |

## Prohibited claims

Nothing is listed, and that's not because nothing was checked. This list is built from your own sentences: stretched versions of what you said, or things you said you haven't done. You haven't given me any sentences about your background yet, so there's nothing to stretch and no gap you've stated. Every row above is therefore a scaffold rather than a claim. When you add your CV, this list gets built from it before the banks are rewritten.

## Sources

- Provided documents: your message, "Final-round interview at Stripe for a Product Operations Manager role."
- Searches sent, each refused (web search permission was not granted):
  - `Stripe operating principles` — refused
  - `Stripe interview process onsite final round operations` — refused
  - `Stripe 2026 strategy news stablecoins agentic commerce` — refused
  - `Stripe "Product Operations" manager job description` — refused
- No fetches sent.
- No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | The one search was refused. It would have supplied Stripe's published principles by name, a values cheat sheet, and C-bank questions themed on them |
| 2. `Stripe interview process` (operations) | unavailable | The one search was refused. It would have established the loop and replaced the flat Generic weights |
| 3. `Stripe strategy` / recent news | unavailable | The one search was refused. It would have grounded A3, G2 and at least one CASE question in Stripe's current priorities |
| 4. interviewer name + Stripe | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | The one search was refused. It would have turned F1 to F7 into quoted `[inferred]` requirements |

## Upgrade menu

- The JD text → F1 to F7 become the posting's own quoted requirements, `[grounded]`; JD-tagged questions and the coverage table are keyed to its real list
- Your CV, or a few paragraphs about your background → the worksheet becomes a real fit snapshot; scaffolds become story-mapped guidance on your own sentences; A1 becomes the objection specific to you; the prohibited list gets built
- Who's on your final-round schedule and their relationship to the role → persona weights read from those relationships instead of flat; if your final is several sessions, a mini-pack per session
- The recruiter's prep email → their stated focus areas, plus a build section for any presentation, case or take-home they announced
- Interviewer names → a reading-the-interviewer section and at least one reverse question tied to each person's path
- Allowing web search → Stripe's published principles (cheat sheet plus re-themed C bank), the documented loop, current strategy for the CO and CASE banks, and a representative JD; a deeper pass beyond that costs up to 6 more searches and 2 more fetches, several more minutes
- Prep time available → a prioritized triage schedule sized to it
- A tuesday-dossier.md from job-underwriter → verified evidence, an evidence-derived top objection, and a prohibited-claims guardrail; this pack is complete without one
