Researching Stripe's operating principles, interview loop, and a current Product Operations job posting so the pack is built on real sources. After that I'll write it up.
I've saved your prep pack as `stripe_product-operations-manager_interview_pack.md`. It has 21 practice questions across seven interviewer styles, each with answer guidance, plus a fit worksheet, reverse questions and a "what to add next" list.

It's built without Stripe research, your job description or your CV. The web searches for Stripe's values, interview process, strategy and job postings were refused because search permission wasn't granted. So the pack states nothing about Stripe as fact, and every question is a general product-operations pattern. I also didn't know who's in your final round, so every interviewer style gets equal weight.

**Where to start:** question A1, "Which part of this role would you be weakest at on day one?" Some version of it comes up in most interviews, so it gets the deepest rehearsal.

**What to do first:** fill in the evidence column of the fit worksheet yourself, one real example per product-ops skill. Wherever a question asks about your past, the guidance tells you how to pick a story; it never writes one for you.

**What's missing:**
- Stripe's published values
- The structure of their interview loop
- Questions tied to Stripe's current strategy

Allowing web search, or pasting the job description, fills most of that in.

I can play the Skeptic interviewer on A1 with live follow-ups and give you feedback afterwards.
I can also save a `tuesday-dossier.md` recording the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Who are you meeting in the final round: how many sessions, and is each with your future manager, a peer, a skip-level, or a cross-functional partner? If your recruiter sent prep notes, such as focus areas or a presentation to prepare, paste those too.
2. Can you paste the job description and your CV, or a few lines about your background? I'll keep going without them, but they let me base the questions on your own experience instead of general patterns.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — Final-round prep pack

**Round:** final round. Interviewer names, relationships and number of sessions not yet known.
**Built from:** your one-line request. No job description, no CV, and no research: web search was denied in this session, so this pack says nothing about Stripe as fact. Every row is a role-family pattern, labeled `[generic]`. The upgrade menu at the end says exactly what each missing input turns into.

---

## How to use this pack

- **Personas** describe *how* a question arrives (who is asking, in what register). **Types** describe *what is being scored*.
- **Type key:**
  - **VAL** — behavioral or values alignment: does past behavior show the company's published values
  - **EXP** — work-experience deep-dive: what you actually did, and whether your claims hold up
  - **JD** — role-driven: can you do the listed job, including its gaps
  - **CO** — company and strategy knowledge: your homework, and whether you can think at the company's level
  - **CASE** — a live problem from the role, worked through out loud
- **Provenance labels:** `[grounded]` traces to something you gave me or to cited research. `[inferred]` is derived from a representative source. `[generic]` is a role-family pattern with no claim about you or Stripe. Every row here is `[generic]` for now.
- **Guidance is scaffolding, not a script.** Where a question asks about your past, the pack gives you criteria for *choosing* a story, never the story itself. Fill it only with things you actually did.

---

## Fit snapshot (self-assessment worksheet)

With no JD and no CV, this is a worksheet. The requirements are typical product-operations duties written from no source, so they're plain prose labeled `[generic]`. Fill in the evidence column yourself before the interview. That exercise is the prep.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Turning frontline signals (support tickets, sales feedback, user complaints) into structured product input. Role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a specific feedback channel, what you did with what came through it, and what changed in the product as a result. Selection scaffold: pick a time you took recurring input from customers or frontline teams to the people building the product. It needs a source, a step you took, and an outcome you can name. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set it up |
| F2 | Getting a product launch operationally ready across support, sales, risk or compliance, and documentation. Role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a launch where you can say which readiness pieces were yours and which were someone else's. Selection scaffold: pick a launch or rollout you worked on. Be ready to name your part exactly, at its real size. If none comes to mind, say so plainly and walk through how you would plan one (B1 rehearses this) |
| F3 | Defining and tracking operational metrics, and analyzing data to find problems. Role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a metric you can explain end to end: what it counted, where the data came from, and its weakest assumption. Selection scaffold: pick a number you reported or used to make a decision, and check you can say how it was counted. If you don't know how it was counted, that's an honest answer, so say it plainly |
| F4 | Designing or scaling a process: runbooks, tooling, intake, escalation paths. Role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a before-and-after you can describe without adjectives. Selection scaffold: pick a process you changed or set up. It needs what was broken, what you did, and what happened next. If none was yours, say so plainly and give the nearest thing you did, or how you would approach it |
| F5 | Influencing teams you don't manage (product, engineering, support, legal). Role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a disagreement with a peer team that you resolved and that left the relationship intact. Selection scaffold: pick a time you needed another team to do something they hadn't planned to do. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritizing competing requests from several stakeholders. Role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a decision rule you actually used and a request you turned down. Selection scaffold: pick a time you had more asks than capacity. Be ready to say what you chose not to do. If none comes to mind, say so plainly and describe the rule you would use (B3) |
| F7 | Clear written communication of decisions, status and trade-offs. Role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a document you wrote that someone acted on. Selection scaffold: pick a written piece (a proposal, a postmortem, a launch brief) and be ready to say who read it and what happened next. If none comes to mind, say so plainly |

---

## Persona table

No source says how many sessions your final round has or who runs each one. So the weights below use the **Generic archetype: flat weights**. That's a pattern, not Stripe's documented process. Every persona gets three questions. Banks are ordered by rehearsal priority, not by weight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of gaps; "why here, why now"; "what would you be weakest at" | Equal. The relationship is unknown, but some form of the weakest-area question shows up across most relationship types, so this bank goes first | Rehearse the most predictable objection until it's boring. Bridge only from work you actually did; where there isn't any, say the limit plainly and give a ramp plan |
| Case / Strategist | Live problems from the role: plan a launch, design a feedback loop, prioritize | Equal. Final rounds often include the hiring manager, and the hiring-manager prior favors this persona, but no source confirms that for your round | Clarify, then objective, segmentation, approach, metrics, risks. Think out loud. Challenge one premise politely per case |
| Values / Behavioral | "Tell me about a time…" probes, expecting STAR-shaped stories | Equal. No source shows whether Stripe runs a dedicated values session, so this bank uses persona stems rather than Stripe's values | "We" for context, "I" for your contribution. Choose stories where the hard truth actually landed. Where your material doesn't show one, say so |
| Peer Evaluator | Probing the boundaries between teams, "what would you need from me", credit-sharing | Equal. Product ops sits between several teams, and peers are a common final-round slot. Unconfirmed for yours | Talk about what you'd bring their team, not just what you need from it. Propose principles for dividing the work rather than claiming to know where the lines fall |
| Data-Driven Prober | Asks for denominators, data sources, assumptions; follow-ups go two levels deep | Equal. Operational metrics are a core product-ops duty (F3) | Know what you can and can't say about how each number was counted. Name your weakest assumption before they do |
| Conversational | Friendly openers, the biography question, "any questions for me?" | Equal. Almost every session opens or closes this way | A 90-second biography arc you've practiced. Treat casual questions as scored. Never say "I think you've covered everything" |
| Pressure | Interrupts, time-boxes, plays devil's advocate | Equal. It can show up in any session, and with no interviewer signal it can't be ruled out | Pause, restate the question, anchor in what you actually said. Hold through two follow-ups before conceding anything real |

---

## Question banks

**Highest-ROI prep in this pack: A1.** Without your CV I can't tell which gap an interviewer will push on. But some version of "which part of this would you be weakest at" is the objection most likely to arrive in some form, and a rehearsed, non-defensive answer changes the room.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The deepest rehearsal here. Choose one real area from your F1–F7 worksheet where your evidence is thinnest. Say it in one sentence, without apologizing. Then give the nearest thing you've actually done, at its true size. Then a concrete 30-day plan to close it. Name the limit before they ask for it. Follow-up 1 ("Isn't that core to the job?"): hold on the plan, don't shrink the gap. Follow-up 2 ("What if you can't close it?"): concede specifically what would still be hard, and say how you'd know early. If you can't find a weak area, that is itself the weak answer, so pick one | Asked in some form across most relationship types, and the one a candidate most often fumbles by naming a disguised strength. JD because it scores self-assessment against the role's requirements |
| A2 | "Why Stripe, why this role, and why now?" | CO | [generic] | Three beats, about 30 seconds each. Why Stripe: something specific you've read or used yourself. Name where you read it, because this pack can't supply Stripe facts. Why this role: which product-ops duties (F1–F7) you want to do more of. Why now: what in your own situation makes this the right moment, in your own words. Keep the three consistent with each other, because the Skeptic is listening for contradictions | The Skeptic tests whether your motivation holds together. CO because the "why Stripe" beat is a homework signal, and with no research it's only as strong as your own reading |
| A3 | "Say you join and get a product area you don't know. What do your first 30 days look like?" | JD | [generic] | JD content, CASE delivery. Structure it as: who you'd meet (product, engineering, support, sales, risk) and what you'd ask each; which data you'd pull first (ticket volume, top drivers, launch backlog); one quick win you'd look for; and what you would *not* change in month one. Make no claim about your past. This is a plan | It turns the gap objection into a ramp plan, which is the Skeptic's counter-strategy. JD because ramping across teams is the role |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A new product launches in six weeks. Walk me through how you'd make sure support, sales and risk are ready." | CASE | [generic] | Clarify first: who the users are, which markets, is it beta or general availability, what's the risk profile. Objective: no customer meets an unprepared team. Workstreams: support (documentation, macros, escalation path, staffing), sales (positioning, FAQs, what they can't promise), risk or compliance (review sign-off, monitoring), internal tooling. Then a readiness checklist with named owners and a go/no-go meeting. Metrics: tickets per new user, time to resolve, escalation rate in the first two weeks. Risks: the date slips but the enablement doesn't. Challenge one premise, for example whether six weeks is fixed | Covers F2 and F4. CASE because it scores structure on a live problem and needs no claim about your past |
| B2 | "Support keeps hearing the same complaint, but it never reaches the roadmap. Design the loop that fixes that." | CASE | [generic] | Diagnose why it doesn't reach the roadmap: is it uncaptured, untagged, uncounted, or counted but not trusted? Then the loop: consistent tagging at intake, a regular digest with volume and customer impact, a named owner on the product side, a "closed the loop" signal back to support. Measure it by time from first report to decision, and the share of top drivers with a decision attached. Say what you'd *not* build: a dashboard nobody reads | Covers F1, the central product-ops loop. CASE because you design rather than recall |
| B3 | "Three teams each want your help this quarter and you can only do one well. How do you choose, and how do you tell the other two?" | CASE | [generic] | State a decision rule out loud: customer impact × reach × reversibility, or whatever you'd actually defend. Apply it to made-up options and pick one. Then the communication, which is what's really being scored: a short written note to all three with the rule, the choice, what the other two get instead, and when you'll revisit. Offer to sketch the note's outline | Covers F6 and F7 together. CASE because the choice is live; the written follow-up tests communication |

### C — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, the moment you said it, what happened after, and a relationship that survived. Use "we" for context and "I" for what you said and did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem, not Stripe's values, which this pack doesn't have. VAL because it scores behavior. Once Stripe's published values are in hand, this maps to one of them by name |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's need and a number you were measured on pointed different ways. It needs the metric, the customer situation, your choice, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. It fits product ops, where support metrics and customer outcomes can pull apart (F1, F3). VAL because the decision is the evidence |
| C3 | "A large customer asks for an exception to a process you own. Walk me through how you decide." | CASE | [generic] | Clarify what the exception is and what the process protects (risk, fairness, cost). Then: can the need be met inside the process? If not, what does the exception cost and who carries the risk? Who has to sign off? How is it recorded? And does this request mean the process itself should change? End with how you'd tell the customer either way | Covers F4. CASE delivery of a values theme, so it needs no story from you |

### D — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their team's boundaries. Propose principles: one named owner per decision, disagreements raised early and in writing, escalate with a joint recommendation rather than two separate ones. Then ask them where the seam is today. Make no claim about past disagreements here. If they ask for one, use the D2 scaffold | Covers F5. CASE because it asks how you would work, not what you did |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: if you pick a story, it needs a piece of shared work where you can name your own part exactly and what you did to make the others' parts visible. If no such time comes to mind, say so plainly and describe how you'd handle it. Either way, the answer should make your share precise, not larger | Persona stem, and a credit probe that tests attribution honesty. VAL because it scores behavior with peers |
| D3 | "What would you need from me in your first 90 days, and what would I get from you?" | CASE | [generic] | Reciprocity first: what you'd bring their team, such as clearer intake, cleaner launch handoffs, or data they don't have time to pull. Then two or three specific asks of them. Keep it a proposal, and ask what would actually help | The peer is weighing whether you add to their load or take from it. CASE because it's forward-looking |

### E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a metric you've reported on and walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a number from your own work you can trace. Where the data came from, what was included and excluded, who else touched it, and what part was yours, all in your own words. If you don't know how part of it was counted, say so plainly. That beats a guessed method. If no such number comes to mind, say so plainly and use E3 to show how you'd build one | Persona stem, covers F3. EXP because it tests whether a number you'd use survives scrutiny |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | The weakest-assumption move: name it yourself, in your own words, before they push. Say what would change if it were wrong and how you'd check it. Don't invent an assumption you never thought about. If you don't know one, say that and say how you'd find out | Follow-up to E1 from the persona stem. Volunteering the weak spot turns a gotcha into credibility |
| E3 | "Support tickets for one product jumped 30% week over week. Diagnose it." | CASE | [generic] | Clarify first: one product or several, new users or existing, did anything ship, and is the spike in raw tickets or tickets per user? Then segment: by issue tag, channel, market, user cohort. Separate a real problem from a counting change (new tagging, a new channel). Then: what you'd check in the first hour, who you'd call, and what you'd tell product today versus after the root cause is known | Persona stem form, covers F3 and F1. CASE because it's live diagnosis |

### F — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc you've practiced, in your own words, built only from what you've actually done: where you started, the one or two turns that matter for this role, and why product ops at Stripe is the next step. End on the role, not on the past | Persona stem. Usually the first question, and casually scored. EXP because it's your own history |
| F2 | "Is there a Stripe product you've used or read about? What would you change about how it runs?" | CO | [generic] | Only use something you've actually used or read, and say which. Pick one operational point, not a feature wish: onboarding, documentation, support handoff, a confusing error. Give one concrete change and how you'd measure it. If you haven't used one, say so and pick something you've read about, naming the source | A casual homework check. CO, and with no research it's only as strong as your own reading, so do that reading |
| F3 | "What questions do you have for me?" | CO | [generic] | Use two from the reverse-questions section below, chosen to fit who you're talking to. Never "I think you've covered everything" | Casual, but heavily weighted as a sign of preparation |

### G — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then three beats: what an outsider brings that this role needs, one real thing you've done that shows it (only from your worksheet), and one honest concession, such as "an internal candidate knows the systems on day one, and here's how I'd close that." Don't run over the time box | Persona stem. Tests composure under a time box. JD because it scores fit to the role |
| G2 | "That result, how much of it was actually you?" | EXP | [generic] | Asked about whatever story you just told. Hold-then-concede: restate exactly what was yours at its real size, then credit others by role. If pushed a second time, keep the same claim and don't add to it. If it was mostly a team result, say so. Precision is the win, not size | Persona stem, testing attribution. It follows any story from banks C, D or E, so those stories need their exact share settled first |
| G3 | "I think your launch plan from earlier is wrong. Convince me in one minute." | CASE | [generic] | Don't defend everything. Restate your objective, say the one part you'd hold and why, and ask which part they think fails. If their objection is good, concede that specific point and adjust it. Don't drop the whole plan | Devil's-advocate follow-up on B1 (F2, F4). CASE because it scores holding and adjusting a position |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Frontline signal to product input | B2, E3, C2 |
| F2 Launch readiness | B1, G3 |
| F3 Operational metrics and analysis | E1, E2, E3 |
| F4 Process design and scaling | B1, C3, G3 |
| F5 Cross-functional influence | D1, D2 |
| F6 Prioritization | B3 |
| F7 Written communication | B3 |

These requirements are generic. Any requirement the real JD lists that isn't here (a named tool, or a domain such as payments or risk) has no question until you paste the JD.

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a great first six months look like in this role, and what would make you say the hire was a mistake?" | Gets the real scorecard, and shows you're thinking about outcomes, not just getting the offer |
| R2 | "Where does product ops sit relative to product and support here, and where does that boundary cause friction today?" | Asks about the seam directly, and the answer tells you what the job really is |
| R3 | "What's the most recent launch where operations readiness went well or badly, and what changed after it?" | Invites a real story and signals you think in terms of launch readiness (B1) |
| R4 | "Which metrics does this team own today, and which ones does it wish it trusted more?" | Shows comfort with data, and surfaces how mature the metrics are (E1–E3) |
| R5 | "What's something a new person could do in their first month that would genuinely help your team?" | The reciprocity question. Use it with a peer |
| R6 | "Is there anything in our conversation that gives you a concern about my fit? I'd rather address it now." | Invites the objection while you can still answer it. Pairs with A1 rehearsal |

---

## Prohibited claims

No entries yet. This list is built from your own sentences: claims your words would be stretched into, and gaps you've told me about. You haven't given me any, so there's nothing to list. That means the pack found nothing to check, not that it checked and found nothing. Once you share a CV or describe your background, this section fills in, and every guidance cell is written against it.

---

## Sources

**Provided documents:** your message ("Final-round interview at Stripe for a Product Operations Manager role"). Nothing else.

**Searches sent:**

- `Stripe operating principles`: refused (search permission not granted)
- `Stripe interview process final round onsite operations`: refused
- `Stripe Product Operations Manager job`: refused
- `Stripe news 2026 strategy stablecoins agentic commerce`: refused

**Fetches sent:** none.

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` / operating principles | unavailable | Every call was refused. It would have supplied Stripe's published values by name, mapped VAL questions (C1, C2, D2) to them, and enabled a values cheat sheet if a values-style round is detected |
| 2. `Stripe interview process` product ops | unavailable | Every call was refused. It would have named the final round's sessions and replaced the flat Generic-archetype weights |
| 3. `Stripe strategy` / recent news | unavailable | Every call was refused. It would have turned A2 and F2 into current, strategy-grounded CO and CASE questions |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to run. The interviewer read is absent |
| 5. representative Product Operations Manager JD | unavailable | Every call was refused. It would have turned the seven `[generic]` worksheet rows into quoted `[inferred]` requirements |

---

## Upgrade menu

- **The job description text** → the seven `[generic]` worksheet rows become quoted `[grounded]` requirements, any tool or domain requirement gets its own JD question, and the coverage table is checked against the real list
- **Your CV, or a few lines about your background** → the worksheet becomes a real fit snapshot with your own sentences quoted, story-mapped guidance replaces the selection scaffolds in banks A, C, D, E and G, A1 targets your actual thinnest area, and the prohibited-claims list gets built
- **The final round's schedule and who you're meeting** (manager, peer, skip-level, cross-functional) → real persona weights instead of flat ones, and a mini-pack per session if there are several
- **Interviewer names** → a public-footprint read of each, tailored reverse questions, and adjusted persona weights
- **Your recruiter's prep email** (focus areas, any presentation or case to prepare) → a build section for any announced deliverable, and coverage matched to stated focus areas
- **Allowing web search** → the five research targets above run (Stripe's published values, loop structure, recent strategy, a representative JD), adding a values cheat sheet where the loop calls for it and strategy-grounded CO questions
- **Deep research** (up to 6 more searches and 2 more fetches, several more minutes, only if you want it) → a strategy brief: priorities, competitive set, recent organizational context, and the "why Stripe over competitor X in 60 seconds" drills
- **How much prep time you have** → a prioritized schedule saying what to rehearse first and what's insurance
- **A `tuesday-dossier.md` from an earlier session, if you have one** → evidence-based objections instead of inferred ones, plus verified claims and a prohibited-claims list carried in
