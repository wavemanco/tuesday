Reading the skill's rules before I build Priya's pack; a few reference files are left.
I've built Priya's prep pack for the one 60-minute peer conversation with Dan Kovac. It rests only on what you gave me. I tried four web searches (Northwind's values, its interview process, Dan's profile, and a check on your Compass note), but the permission prompt wasn't approved, so none of it was checked against outside sources.

It's saved as `Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`. What's in it:

- **Fit snapshot:** each JD line set against your exact words about Priya, with how strong the evidence is, what kind of gap it is, and wording she can use for it.
- **23 questions in 7 tables, one per interviewer style.** Each row has the question, what the answer is scored on, where its claims come from, answer guidance and why the question is included.
  - The banks are weighted for a data-driven peer with a pricing background, so most questions push on how her numbers were counted and where their two teams overlap.
  - The case questions lean on pricing and packaging: the bundling threat and how to price Compass.
- **Interviewer read:** what Dan's background means for how he'll ask.
- **Coverage table:** which questions cover each JD requirement.
- **Reverse questions:** six for Priya to ask, including two tied to Dan's pricing and startup background and one about what she can do for his team.
- **Claims not to coach:** the main ones are "drove $400M" (your note says she *proposed* the change and it was *credited* with the uplift), "negotiated carrier deals" (the model was *used in* negotiations), and treating volume targets as if they were quota.

**The most valuable thing to rehearse is B1:** "I don't see sales-ops or quota-setting in your background." Dan runs sales strategy, so this objection is almost certain to come up in some form. The guidance has her say the gap plainly first ("I haven't done classic sales-ops or quota-setting work"), then propose how their two teams would split the work, and hold that line through two follow-ups.

Where your notes don't say what Priya actually did (how the ~$400M was counted, whether she shaped the carrier deals, any whitespace or AI product work), the guidance gives her two honest answers rather than inventing a story for her: one if she did it, one if she didn't. Allowing web search, the full JD, her CV, or her answers on those points would firm up those rows. The upgrade menu at the end of the file lists exactly what each would change.

If you want, I can play Dan on B1 with live follow-ups, then give feedback against that question's guidance.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, so they carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. He would be Priya's **peer**, and both would report to the same VP.
**Format:** one 60-minute conversation.

---

## How to use this pack

Questions are sorted along two axes:

- **Persona** is *how* a question gets asked: who is asking and in what style. Banks are ordered by how likely each persona is in this conversation.
- **Type** is *what* the answer is scored on:

| Tag | What it scores |
|---|---|
| VAL | Behavior: whether past actions show the working values the company cares about |
| EXP | Work-experience deep-dive: whether the claims survive scrutiny, and what was actually Priya's own work |
| JD | Role fit: can she do the listed job, including its gaps |
| CO | Company and strategy: can she think at Northwind's altitude (priorities, competition, launches) |
| CASE | Live problem: structure and reasoning on a problem from the actual role |

The guidance is scaffolding, not a script. Every suggested wording in this pack is **pending Priya's approval**: she should say it in her own words, and only where it is true.

**Provenance labels:**
- `[grounded]` means the row traces to what you gave me: the JD highlights, your notes on Priya, your notes on Dan, or your research note.
- `[inferred]` means it is derived, and the row names what it was derived from.
- `[generic]` means it is a role-family pattern with no claim about Northwind or Priya.

**Question IDs** use a letter per persona (A, B, C, D, E, G, H). The letter F is skipped so that question IDs never collide with fit-snapshot rows F1–F8.

**Highest-ROI prep in this pack: B1.** It is the sales-ops and quota objection, asked by a peer whose own job is sales strategy.

---

## Fit snapshot

Evidence quotes are your words about Priya, copied exactly. Everything the pack later says about her past draws only on these quotes. *Bridge language is pending Priya's approval.*

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy and ops, plus one proposal credited with an outcome. It does not show owning GTM for a product line. The words stay at that scope: nine years in product strategy and ops, and a store-surface change she proposed. Answer slot: the JD's "own GTM strategy" line makes a probe likely on which decisions in that work were hers. If some were, she names them and says how she decided, in her own words. If none were, she says so plainly and describes the product strategy and ops work as it was |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | The material says nothing either way about customer-lifecycle whitespace analysis. Answer slot: if she has sized untapped demand or expansion room in any setting, she says where and how, in her own words. If she has not, she says so plainly and walks through how she would do it at Northwind (A3, C4) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but this is a one-line claim with nothing inspected behind it. From a self-described data-driven interviewer, expect a live test of it. She leads with the skill as stated and offers to walk through an analysis end to end |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | She built a model that was used in negotiations. That is not the same as designing a partner motion or running the negotiations. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's "partner-motion design" makes a probe likely on how the carrier arrangements were structured. If any part of that structure was hers to shape, she says which, in her own words. If none was, or there was no such design step, she says so plainly and stays with the model she built |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | none | Both quotes reach influence in role-relevant terms: consensus across orgs, and a proposal that was adopted and credited. Keep the verbs exactly: she *set* volume targets *with consensus*, and she *proposed* a change that was *credited*. Expect a probe on how consensus was reached |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Daily use of AI tools is adjacent to "AI experience" but does not reach AI product or AI go-to-market work. Words at that scope: she uses AI tools daily. Answer slot: if she has worked on an AI product, its pricing or its launch, she says so in her own words. If not, she says so plainly and talks about what daily use has taught her as a user |
| F7 | Northwind is "B2B data-infrastructure SaaS" — role brief, your message | "11 years" — the coach's notes; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material shows consulting and consumer tech, not B2B data infrastructure. She names the difference before Dan does (D1) and keeps her history in its own terms |
| F8 | Working fluency in sales-ops mechanics such as quota, coverage and capacity, for a role that sits beside sales strategy (role-family expectation, not a JD line) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap that wording cannot close, and one that was stated plainly. Words: "I haven't done classic sales-ops or quota-setting work." After that comes how she would learn Northwind's model, said as a plan and never as a past. "Volume targets" are not quota and must never be offered as a stand-in for it |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| Own GTM strategy for two new product lines (F1) | B1, D3, C4, G1 |
| Whitespace across land/adopt/expand/renew (F2) | B2, A3, C4 |
| Independent analysis in SQL and Tableau (F3) | A3, A5, A2 |
| Partner-motion design (required) (F4) | C2, D2 |
| Strong cross-functional influence (F5) | B3, B4, A1 |
| AI experience a plus (F6) | C3, G2 |
| Northwind's three priorities and the bundling threat (your research note) | C1, C3, C4 |
| Sales-ops adjacency (F8, the stated gap) | B1, E2 |

---

## Reading the interviewer

Everything here comes from the notes you provided. It covers public professional footprint only and was **not independently verified**: the search to check it was refused (see Sources).

| Signal | Source | Implication for Priya |
|---|---|---|
| Peer: he and Priya would both report to the same VP | your message | He is pricing what this hire adds to his team's work, and what it costs it. Seam and credit questions come collegially but are scored |
| Self-describes as "relentlessly data-driven" | your message, quoting his profile | Every number gets traced back to its assumptions. The ~$400M (F5) and the revenue model (F4) will be followed two levels down |
| Career spine is pricing and monetization roles | your message | His native language is pricing, packaging and unit economics. Expect the case questions (the bundling threat, Compass) to lean that way, and answer in margin and packaging terms |
| One early-stage startup chapter | your message | Building-from-scratch stories tend to land, along with probes on scrappiness and on big-company pace. Emerging products are where this shows up |
| Shared vocabulary | your message; F4 and F5 | "Revenue model" and "ARR" are already in Priya's quoted material and in his world. Use them at their stated scope. No shared career jump is offered, because the notes on Dan do not show one matching hers |

---

## Persona table

Starting weights come from the relationship (peer, so Peer Evaluator and Data-Driven Prober lead). They were then adjusted for the interviewer signals above. The format comes from your words: one 60-minute conversation, and no other rounds are known.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | "How was that counted?", "show me the denominator", a live SQL or metrics problem | **High.** The peer prior, plus his "relentlessly data-driven" self-description | Know what she can and cannot say about how each number was counted. Name her weakest assumption first. Offer to walk through one analysis end to end |
| Peer Evaluator | "Where's our seam?", "what do you need from me?", credit sharing | **High.** The peer prior, and they would share a VP | Frame it as reciprocity, meaning what she brings his team. Propose principles for the seam rather than claiming to know it |
| Case / Strategist (pricing-tilted) | Bundling response, Compass packaging, expand whitespace | **Medium-high.** His pricing and monetization spine, plus the three priorities in your research note | Clarify, then objective, segmentation, options, metrics, risks. Challenge one premise per case |
| Skeptic | Consumer-to-B2B, GTM ownership, the weakest part of the JD | **Medium.** The F7 and F1 gaps, and the startup chapter's scrappiness lens | Rehearse the predictable objection until it is boring. Build bridges only from quoted evidence, with the limit stated |
| Pressure | "How much of that was you?", "sixty seconds: why you?" | **Low-medium.** It is not the peer register, but a direct data person may push | Pause, restate, anchor in what she actually said, hold through two follow-ups, then concede specifically |
| Conversational | The opening "walk me through it", "what are you doing with AI?" | **Low-medium.** The likely opener in a peer chat, and it is still scored | Have a 90-second arc ready. Treat the casual AI question as scored |
| Values / Behavioral | "A time you disagreed", "an unpopular truth" | **Low.** No values round was named, and Northwind's values were not established | Use selection scaffolds with honest branches |

---

## Question banks

*All answer guidance is pending Priya's approval.*

### A: Data-Driven Prober (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The store-surface change credited with ~$400M ARR uplift: walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Tell it at the quote's own attribution. She proposed the change, and the change was credited with about $400M ARR uplift. Keep "proposed" and "credited" and keep the tilde. Answer slot, in her own words: how the figure was counted, what it is sensitive to, the assumption behind it she would defend least, and which part was hers. If she doesn't know how it was counted, she says so plainly ("the attribution was done by the team that owned the number") only if that is true. Otherwise "I don't know the method" is enough, and she returns to what she proposed. She never says she drove or delivered it | F5's headline figure is the biggest target on the CV for a self-described data-driven interviewer. EXP because it tests attribution and counting, not the idea |
| A2 | "Walk me through the partner-level revenue model: what went into it and how did you know it was right?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4. The beats are the ones the quote states: she built it, it was a partner-level revenue model, and it was used in carrier negotiations. Answer slot: the JD's "independent analysis" line makes a probe on inputs and validation likely. If she can describe the inputs and how the model was checked, she does so in her own words. If checking wasn't a step, or wasn't hers, she says so plainly and returns to the model and how it was used. She offers to sketch its structure on a whiteboard only if she can | F4 is her closest evidence for both the analysis requirement and the partner requirement, so a prober goes here second. EXP because the scoring is on what she actually built |
| A3 | "Say I give you a table of accounts with product usage and ARR. How would you find whitespace for a new product line, in SQL and then in Tableau?" | JD | [grounded] "skilled in SQL/Tableau" | Think aloud. First define whitespace: accounts that fit the new product but don't own it. Then the grain (one row per account), the joins (accounts to products to usage), and the filters for fit signals. Segment by lifecycle stage: land, adopt, expand, renew. Then the Tableau view: a whitespace-by-segment matrix with ARR at stake. Then sanity checks: totals reconcile, no duplicate accounts. Say plainly what the query assumes, for example that "fit" is defined by firmographics. This is a method for the problem and makes no claim about her past | It tests F3's claim live against F2's requirement, which is exactly what a data-driven peer does. JD-tagged because it scores a listed requirement, with CASE-style delivery |
| A4 | "Six months in, how would you know the GTM strategy for one of these product lines is working? Give me the metric tree." | CASE | [generic] | Start with the objective (adoption within profitable growth). Then leading indicators: pipeline created, attach rate in target segments, time to first value. Then lagging ones: net-new ARR, expansion, gross margin. Name the denominator for each, and say which metric could be gamed and how she would guard against that | A prober wants to see how she thinks in denominators. `[generic]` because it is a pattern for the problem, not a Northwind fact |
| A5 | "Tell me about the last analysis you built end to end yourself, and what decision it changed." | EXP | [grounded] "skilled in SQL/Tableau" | Selection scaffold. She picks an analysis where she wrote the query, built the view, and a decision moved because of it. The story needs a question, her method, the result, and who acted on it. If no such analysis comes to mind, she says so plainly, then gives the nearest one she does have, or how she would approach one at Northwind | It tests "independent" in F3's requirement. An open prompt, because no quoted sentence names a specific analysis |

### B: Peer Evaluator (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see sales-ops or quota-setting in your background. Our teams would sit side by side. How do you own GTM strategy for these product lines without that?" **Highest-ROI rehearsal.** | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau" | **Open with the limit before he presses:** "I haven't done classic sales-ops or quota-setting work." Do not soften it with "but volume targets are basically quota." **Then what is true:** "I've set annual volume targets with cross-org consensus, and I'm skilled in SQL and Tableau." She says these as what they are, not as equivalents. **Then the seam, as a proposal:** quota, capacity and comp mechanics sit with his team. New-product GTM strategy needs those as inputs, and she would want them from him early. **Then a ramp plan, said as a plan:** learn Northwind's quota and coverage model with his team in the first weeks. **Follow-up 1:** "But GTM for a new product lives or dies on comp and quota." Hold: that is why the seam matters. Concede specifically: "You're right that I'd depend on your team there." **Follow-up 2:** "So what do you add that my team doesn't?" She answers only from F3, F4 and F5's quotes, at their scope | F8 is a stated gap, and the interviewer's own function is sales strategy, so this objection arrives in some form. JD because it scores fit to the role, delivered as a peer seam probe. Deepest rehearsal because a non-defensive answer here changes the whole conversation |
| B2 | "Whitespace across land, adopt, expand and renew sounds a lot like what sales strategy does. Where's the line between us?" | JD | [grounded] | Propose principles, not turf. One option: her role sizes and prioritizes whitespace for the two new product lines, his team turns that into coverage and targets, and they share one data definition. Ask how it works today. Answer slot (F2): if she has done lifecycle whitespace analysis anywhere, she says where, in her own words. If not, she says so plainly and points to how she would do it (A3) | It tests F2's requirement on the exact seam a peer cares about. JD because the line comes straight from the JD highlights |
| B3 | "Tell me about a time you disagreed with a peer on a number. How did it resolve?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold, with the one candidate story flagged. If the volume-target consensus involved a real disagreement, she can tell that story: what each side wanted, what she did, and where it landed, in her own words. If it didn't involve a real disagreement, or the disagreement wasn't hers, she picks another time that has a named stake, shows spine and tact, and keeps the relationship intact. If no such time comes to mind, she says so plainly and describes how she would handle one with Dan | F5's requirement, tested in the register a peer uses. VAL as behavioral, not mapped to published values, because Northwind's values were not established |
| B4 | "The store-surface change: who else was involved, and how did the credit get shared?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start from the quote: she proposed it, and it was credited with the uplift. Answer slot: she says who else was involved and what each did, in her own words. If she doesn't know how credit was assigned, she says so plainly. Use "we" for the build and "I" only for the proposal. A peer listens for whether she leaves room for other teams | F5's figure, seen from the credit angle a peer would use. EXP because it tests attribution honesty |
| B5 | "What would you need from my team in your first 90 days, and what would you give us back?" | JD | [grounded] "skilled in SQL/Tableau" | Needs: his quota and coverage model, deal data on the new product lines, and a standing sync. Gives back: independent analysis he can reuse, built in SQL and Tableau and stated at that scope. She asks which question his team never has time to answer, and offers to take one on | A reciprocity probe from the peer persona. JD because it scores how she would do the job beside him |

### C: Case / Strategist, pricing-tilted (medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much bigger platform vendor bundles a competing capability. How should one of our new product lines respond?" | CO | [grounded] | **Clarify:** which product line, how much it overlaps with the bundle, and which segments the bundle reaches. **Objective:** profitability is a stated priority, so she would not buy share at a loss. **Segment:** where the bundle is good enough and where depth wins. **Options:** compete on depth in the segments the bundle underserves, package with the core platform or Compass, use value-based pricing, or a partner route. **Metrics:** win/loss against the bundle, discount depth, net revenue retention. **Risks.** Then challenge one premise: maybe the bundle grows the market. All of this is about the problem, with nothing claimed about her past | Built on your research note (the bundling threat plus profitability). It is the differentiator question most candidates cannot answer, and it is Dan's pricing language. CO because it scores strategy fluency, with CASE-style delivery |
| C2 | "Design a partner motion for one of the new product lines: who the partners are, why they'd sell it, and how they get paid." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | **Structure:** partner types and the role of each, the partner's economics (margin, co-sell, deal registration), and channel conflict with direct sales (his team, so name it). Tie it to profitability. On her past, only at the quote's scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how the carrier arrangements were structured was hers to shape, she says which, in her own words. If none was, she says so plainly and stays with the model | F4 is a required JD line and her biggest bridge. JD because it scores the stated requirement, with CASE-style delivery |
| C3 | "Compass is launching. How would you price and package it, and does it help or hurt the push to profitability?" | CO | [grounded] "uses AI tools daily" | **Options:** an add-on versus a bundle, and seat-based versus usage-based pricing. Inference costs affect gross margin. Compass can be the lever that drives adoption, which feeds expansion. She picks one option and names its risk. On her past: she uses AI tools daily, as a user. Answer slot (F6): if she has worked on an AI product, its pricing or its launch, she says so in her own words. If not, she says so plainly and brings what she knows as a user | It covers the Compass priority from your research note and F6's requirement, in Dan's pricing language. CO because it scores strategic fluency |
| C4 | "Enterprise expansion is a priority. For a brand-new product with no usage history, where do you look first for expansion whitespace?" | CASE | [grounded] | Proxy signals in place of usage: the installed base on core products, adjacent workloads, firmographics, and contracts coming up for renewal. Then a prioritization screen, a small pilot set, and a feedback loop with sales. State the assumption she would defend least | Covers the enterprise-expansion priority from your research note and F2's whitespace requirement. CASE because it is a live problem |

### D: Skeptic (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You're coming from consumer tech. What breaks when you bring that to B2B data infrastructure?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Name the difference first: buying committees, long cycles, and account-level land and expand. On her past, at the quote's scope: two years in consulting, then nine in consumer-tech product strategy and ops. Then a ramp plan as a plan: learn from his team's deal reviews and customer calls. She does not claim B2B SaaS experience | F7 is the background mismatch a skeptic opens with. JD because it scores fit to the listed role |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations" | She picks one honestly rather than a humble-brag. Two candidates: sales-ops mechanics, using F8's words ("I haven't done classic sales-ops or quota-setting work"), or partner-motion design, with F4's quote at its own scope. Name it, give the plan, then stop talking | It tests self-assessment, using F8 and F4. JD because the answer must name a JD line |
| D3 | "Product strategy and ops isn't GTM. Have you actually owned a go-to-market strategy?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the quotes' scope: nine years in product strategy and ops, and a store-surface change she proposed that was credited with the uplift. Answer slot: if any decisions in that work were hers to make, she names them and says how she decided, in her own words. If none were, she says so plainly and describes the work as it was | F1's gap, asked bluntly. The same objection as B1 in skeptic packaging, which is why it gets a second rehearsal |

### E: Pressure (low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause. **Hold:** "I proposed the change; it was credited with around $400M ARR uplift." **Follow-up 1** ("but who built it?"): she holds, and says who else did what only if she knows. **Follow-up 2** ("so it wasn't really yours"): she concedes specifically ("the attribution wasn't mine to do"), then returns to the proposal. She does not fold to "it was a team thing" if the proposal was hers | F5's figure under stress. The hold-then-concede structure is what gets scored. EXP because it tests attribution |
| E2 | "Sixty seconds: why you over someone from my team who already knows our quota model?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Concede the premise in one line: "They'd know the quota model better; I haven't done classic sales-ops or quota-setting work." Then give two facts from the quotes: skilled in SQL and Tableau, and a partner-level revenue model she built that was used in carrier negotiations. Close on the role being about new product lines, not the existing quota model. Stay under 60 seconds | F8 is the predictable lever for pressure. JD because it scores fit to the role |

### G: Conversational (low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc: consulting, then nine years in consumer-tech product strategy and ops, with two proof points at their own scope (the revenue model she built, the change she proposed). Answer slot: why she wants B2B emerging products now, in her own words. The pack supplies no motive | The near-certain opener. Its economy is scored. EXP because it previews the claims Dan will probe |
| G2 | "What are you actually doing with AI these days?" | JD | [grounded] "uses AI tools daily" | She names the tools and what she uses them for, in her own words, at user scope. Then one thought on what Compass might mean for buyers. She treats this as scored | F6's "plus" requirement, asked casually. JD because it scores a listed requirement |

### H: Values / Behavioral (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. The story needs a named stake, the moment she said it, and how it landed. Use "we" for context and "I" for contribution. If no such time comes to mind, she says so plainly, then gives the nearest thing, or how she would handle one | Low probability but cheap insurance. `[generic]` because Northwind's values were not established |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. The story needs the metric, the customer, the choice, and the outcome. If no such time comes to mind, she says so plainly and gives how she would decide | A peer from a pricing background may test whether she optimizes the number or the business. `[generic]` for the same reason as H1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Coming from pricing and monetization, how do you see packaging decisions for the new product lines splitting between your team and this role?" | It is tied to his career spine (your notes) and opens the seam conversation on his own terms |
| R2 | "What could someone in this seat do in the first month that would genuinely help your team?" | The reciprocity question: it signals she wants to reduce his load, not add to it |
| R3 | "From your startup chapter, what do new product lines here need that feels more like a startup than the core business?" | It is tied to his path and invites him to talk about building |
| R4 | "How does the bundling pressure from the larger platform vendor show up in your team's deal data?" | It shows she has done the homework (your research note) and asks him in his data-driven register |
| R5 | "How should the two of us and our VP decide when a new-product number lives inside the core quota versus a separate target?" | It names the hardest seam directly and shows she knows F8 is real |
| R6 | "What does Compass change about how your team thinks about expansion motions?" | It ties the AI priority to his function |

---

## Prohibited claims

These are claims the pack will not coach, because Priya might reach for them under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | An inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for Priya: the material says product strategy and ops, not GTM ownership. D3's slot stays inside that work |
| Designed a partner motion, or negotiated carrier deals | An inflated form of F4 ("used in carrier negotiations" is not "negotiated") | "I built a partner-level revenue model used in carrier negotiations." C2's slot stays inside that work |
| Drove or delivered ~$400M ARR | An inflated form of F5's quote ("proposed … credited with") | "I proposed a store-surface change credited with a ~$400M ARR uplift." |
| Has set quotas or run sales ops, including "volume targets are basically quota" | A negative stated in your notes (F8) | "I haven't done classic sales-ops or quota-setting work." No answer slot |
| Has B2B SaaS GTM experience | An inflated form of F7's quotes | F7's quotes at their own scope: consulting, then consumer-tech product strategy and ops |
| Has built or launched AI products | An inflated form of F6 | "I use AI tools daily." C3's slot allows the honest no |

---

## Sources

**Provided documents** (all from your message):
- JD highlights
- Candidate summary
- Interviewer summary
- Research note on Northwind's priorities and its competitive threat

**Searches sent.** All four were refused, because web search permission was not granted:
- `Northwind Data company values`: refused
- `Northwind Data interview process GTM strategy`: refused
- `Dan Kovac Northwind Data Director of Sales Strategy`: refused
- `Northwind Data Compass AI copilot launch`: refused. This was a check on your research note

**Not verified:** the strategy facts (C1, C3, C4, R4, R6) and the interviewer read rest on your notes alone. They were not checked against any outside source.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Refused. It would have themed H1 and H2 with official value names. No values cheat sheet would appear either way, because your description of the format names no values round |
| 2. `Northwind Data interview process` | unavailable | Refused. Your words already establish this session (one 60-minute peer conversation). The search could have shown which other rounds exist |
| 3. `Northwind Data strategy` / recent news | unavailable | Refused. It was a check that your research note is current and genuine. It would have confirmed or updated C1, C3 and C4 |
| 4. `Dan Kovac Northwind Data` | unavailable | Refused. It would have verified the interviewer read, and could have turned up published talks for the reverse questions |
| 5. Representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied already fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** → verifies your research note and Dan's profile, adds Northwind's official value names to H1 and H2, and checks for other rounds. The rows in Sources marked unavailable become yes.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Northwind's segmentation language, recent moves and the bundling competitor, plus any talks or writing by Dan.
- **Full JD text** → requirement quotes from the posting itself, and coverage for any mid-list requirements the highlights left out.
- **Priya's CV** → evidence from her own lines instead of your summary. A5, B3, H1 and H2 move from selection scaffolds to story maps.
- **Priya's own answers to the answer slots** (how the ~$400M was counted, her part in structuring the carrier arrangements, any whitespace work, any AI product work) → upgrades F1, F2, F4, F5 and F6 and the rows that draw on them.
- **Any recruiter guidance** (focus areas, a pre-declared exercise) → a build section for any deliverable that will be graded.
- **Prep time available** → a prioritized prep schedule.
- **A `tuesday-dossier.md` from job-underwriter** → a highest-ROI objection derived from evidence Priya has confirmed, and a prohibited-claims list she has approved rather than one built here.
