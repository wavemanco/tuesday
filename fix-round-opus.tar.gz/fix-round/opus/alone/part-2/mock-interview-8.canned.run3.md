I've put together your prep pack for 21 November, Dara: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-8-canned-9e6fa230/ashgrove-credit-union_member-experience-lead_interview_pack.md`. Your message already covered everything I needed, so I ran no web searches and have no questions for you. It's built only from your JD, the values text, the recruiter's email, your summary of the strategy brief and your background.

**What's in it:**
- **Your fit against the JD:** a table matching each requirement to your own sentences, with honest wording for the gaps.
- **The 20-minute case:** a minute-by-minute structure for the complaint-escalation case, organised around the four values.
- **Questions for each round:** 28 practice questions split across the three rounds, with guidance for each and questions for you to ask them.
- **The panel's four values:** each value with a story prompt.
- **Claims to avoid:** things the pack deliberately won't coach you to say.

**Practise D1 first** (round 2, your future manager). It's the question you're most likely to get: "you've handled one branch's complaints log, and this role owns complaints across every branch and a contact centre you've never worked in." The guidance has you name that limit first, then give your evidence, then a plan, and gets you through two follow-ups without overclaiming.

**Two things to fill in before the day:**
- **Your answers to the "answer slots."** Where the guidance says Answer slot, it's because your notes don't say. For example, it isn't clear what your spreadsheet tracks or whether it's in Excel, or whether the complaints in your log were regulated ones. Answer from what actually happened. If you tell me, I'll update the affected questions.
- **Your future manager's or panellists' names,** once the recruiter assigns them. With names I can add a section on each interviewer and tailor your questions for them.

If you want to rehearse, I'll play your future manager and run D1 with real follow-ups. I can also save a `tuesday-dossier.md` file of the gaps this prep turned up, for future sessions, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date:** 21 November 2026, three rounds back to back (from the recruiter's email)
**Rounds:** 1, recruiter, 30 min. 2, Head of Member Services (your future manager), 45 min, mostly behavioural. 3, panel of two branch managers, 60 min, with a 20-minute complaint-escalation case, scored against the four values.
**Interviewer names:** not assigned yet, so there is no interviewer read.
**Mode:** loop. One shared fit snapshot, a shared case build, then a mini-pack for each round.

---

## How to use this pack

- **Personas** describe *how* a question is asked: the interviewer's style. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: values and behaviour, scored against Ashgrove's four published values.
  - **EXP**: deep dive on your experience. Tests whether what you say holds up, and what was actually yours.
  - **JD**: tests a stated requirement of the role, including the gaps.
  - **CO**: company and strategy. Tests whether you've read the strategy and can think at Ashgrove's level.
  - **CASE**: a live problem from the job, solved out loud.
- Question IDs use a letter for each persona in each round: A and B in round 1; C, D, E and G in round 2; H, J and K in round 3. F is kept for fit-snapshot rows (F1 to F9).
- **The guidance is scaffolding, not a script.** Where it gives you words, they're your own sentences played back to you. Where it says **Answer slot**, the pack doesn't know the answer and won't guess. Answer from what actually happened, and if the thing never happened, say so.
- **The highest-ROI prep in this pack is D1** (round 2). Rehearse it until it bores you.

---

## Fit snapshot

Everything the pack says about your past comes from the four sentences you wrote, quoted below. Nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD), branch side | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log, not an organisation-wide process, and your words should stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If handling it involved steps that were yours to decide, say which and how you decided, in your own words. If there were no such steps, or they weren't yours, say so plainly and describe the log as it was |
| F2 | "across branches and the contact centre" (JD), contact-centre side | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this gap yourself, and wording can't close it. Words: "I haven't worked in a contact centre." Then say how you'd learn it, as a plan and never as a past. Never claim contact-centre experience, and never call anything you've done "similar to" a contact centre |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | This gets close to the requirement, but it doesn't show whether the spreadsheet tracks volumes, resolution times or both. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it tracks volumes, resolution times or both, say which and how each is counted, in your own words. If it tracks something else, say what and stay with that |
| F4 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on "our" script. It doesn't say supervisors, and it doesn't say you wrote the script. Words: "I trained new tellers on our escalation script," and "for the last three years I've been a branch supervisor." Answer slot: if you chose how the training on the script was done, say how, in your own words. If the training was set for you, say so plainly and describe what you did |
| F5 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. Answer slot: if you have worked with a digital team or on a self-service journey, say what it was and which part was yours. If you haven't, say so plainly and say what you would do first in this role |
| F6 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Lead with the sentence in its own terms: six years in retail banking, the last three as a branch supervisor. Let the interviewer map that onto "customer operations"; don't relabel your history in the JD's words. Self-reported with nothing inspected, so expect a probe on what the supervisor role covered |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [grounded] | discovery | A "formal complaints log" touches this requirement but doesn't show whether those complaints were regulated. Answer slot: if the complaints in that log came under the regulator's complaint-handling rules, say so, and say what you did with the log, in your own words. If they didn't, or you don't know, say so plainly and describe the log |
| F8 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I haven't presented to anyone above regional level." Answer slot, inside that sentence's scope: if you have presented at regional level, say to whom and what, in your own words. If you haven't, say so plainly. Then say how you would prepare, as a plan |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says "spreadsheet" but doesn't name the tool. Answer slot: if you built it in Excel, say so and what you built into it, in your own words. If you used another tool, name it plainly and stay with what you built |

The suggested words in this table are pending your approval. Change anything that isn't how you'd say it.

**Most predictable objection:** F1 together with F2. The role covers complaints across all branches *and* the contact centre, and your material shows one branch's log and no contact-centre experience. F8 comes second. It's rehearsed as D1, with lighter versions at B2, B3 and D2.

---

## Graded deliverable: the 20-minute complaint-escalation case (round 3)

The recruiter's email says it's a 20-minute case on a complaint escalation, run by two branch managers who also score the four values. It doesn't say whether you get the case in advance or what the scenario is. That's a question for the recruiter (round 1 reverse question 2).

**Facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| A 20-minute case on a complaint escalation, inside a 60-minute panel of two branch managers | Recruiter's email | [grounded] |
| The panel scores against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Recruiter's email; values text you pasted | [grounded] |
| The role owns complaints end to end across branches and the contact centre, and coaches branch supervisors on escalations | JD | [grounded] |
| The role reports monthly on complaint volumes and resolution times, and works with digital teams on self-service journeys | JD | [grounded] |
| Eight branches consolidating into five hubs over 2027; 40% of member service moving to digital by 2028 | 2026 strategy brief, as you summarised it | [grounded] |
| What you can say about your own past in the case: F4, "I handled the branch's formal complaints log and trained new tellers on our escalation script." If the contact centre comes up: F2, "Never worked in a contact centre, and I've never presented to anyone above regional level." So say "I haven't worked in a contact centre," and ask how complaints move between it and the branches | Fit snapshot F4, F2 | [grounded] |

**A 20-minute shape.** Say it out loud at the start, so the panel can follow your structure.

| Minutes | Step | Value it shows |
|---|---|---|
| 0–3 | Clarify: who the member is, what went wrong, what they've already been told, what they want, and which complaint rules and time limits apply. Ask about the rules rather than guessing them | Members First, Always |
| 3–8 | The member in front of you: what you'd do for them today, and how you'd explain it in one plain sentence | Plain Words |
| 8–13 | The escalation: who keeps hold of it, what the branch supervisor does next, and how you'd coach them through it rather than take it off their desk | Own the Fix |
| 13–17 | The cause behind it: is this one member or a pattern across branches? Where it would show up in the monthly report, and whether it belongs with the digital team | Own the Fix; Neighbours, Not Numbers |
| 17–20 | Close: what you'd tell the member, the supervisor and the branch manager, and what you'd check a week later | Plain Words |

**Theses to choose from.** Each comes with its concession. The concession is mandatory, so say it.

| Thesis | Concession you say aloud |
|---|---|
| Fix it for the member first, then fix the process | Some fixes can't happen the same day. Where complaint rules set steps or time limits, you follow them and tell the member plainly what happens when |
| Escalation isn't a hand-off: the person who found the problem stays on it, with support | Some complaints have to leave the branch, for example ones needing specialist or formal regulatory handling. Then the job is a clean handover and keeping the member informed |
| A repeat complaint is data: count it, report it, and take it to whoever owns the cause, including the digital team where it's a self-service journey | One complaint isn't a trend. Don't redesign a process because of a single case |

**Differentiation.** Most candidates will say "apologise, escalate, follow the procedure." Give one piece of that to show you know the basics, then diverge: treat the escalation as a coaching moment for the supervisor, and close the loop into the monthly report. **The pick to avoid:** escalating just to get it off the branch's desk, or promising the member a fix you don't own. Both fail Own the Fix in front of two people who run branches. Don't invent Ashgrove policies or time limits; ask about them.

The suggested wording in this section is pending your approval.

---

## Grounding brief

| Item | What your material says | Source | Provenance | Use it in |
|---|---|---|---|---|
| Ownership and size | Member-owned, about 900 staff | JD | [grounded] | A2, round 3 framing |
| Digital shift | Move 40% of member service to digital channels by 2028 | 2026 strategy brief, July 2026 | [grounded] | G1, J3, round 2 reverse questions |
| Branch consolidation | Eight branches into five hubs over 2027 | 2026 strategy brief | [grounded] | K2, round 3 reverse questions |
| New product | A small-business lending product launching Q1 2027 | 2026 strategy brief | [grounded] | Round 2 reverse question 5 |
| Competition | App-only banks are the main competitive pressure | 2026 strategy brief | [grounded] | A2, G1 |
| Vocabulary to use | "member" (not customer), "self-service journeys", "hubs", "branches and the contact centre", the four value names exactly | JD, values text, strategy brief | [grounded] | Every round |
| The panel and consolidation | The panel is two branch managers, and the brief plans to consolidate branches into hubs during 2027. Treat consolidation as a live topic for them, not an abstraction. Don't speculate about their branches or their jobs | Reasoning over the recruiter's email and the brief | [inferred] | K2, round 3 reverse question 1 |
| How current this is | The brief is from July 2026, and I have your four-point summary, not the brief itself. If an interviewer describes the plan differently, follow their version and ask about it. Don't correct them | Your message | [grounded] | Every round |

---

## Round 1: recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly questions: your background, why Ashgrove, logistics | High. The recruiter's email names a 30-minute round with the recruiter, and recruiter screens run conversational | A rehearsed 90-second arc. Casual questions are still scored |
| Skeptic, light | Quick checks against the JD's requirements | Medium. The JD lists four requirements that can be checked in a sentence each | Plain, unhedged answers on F2, F7, F8 and F9. A clean "no" beats a vague "sort of" |
| Pressure, Prober, Case | Unlikely in 30 minutes | Low. Nothing in the recruiter's email points to them | Covered in rounds 2 and 3 |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, three beats, each from your own sentences: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words. Leave out anything you wouldn't want followed up | F6, F1 and F3 are the spine of your case. A recruiter will reuse this answer to brief the next two interviewers, so it sets the frame for the whole day |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Use their own words: member-owned, Members First, Always, and Neighbours, Not Numbers. Then why you, in your own words. Your material shows no credit-union history, so don't imply one. Keep app-only banks in reserve in case they ask what members are choosing between | Motivation is checked in every screen. CO because a good answer uses the values and the strategy brief, which most candidates only skim |
| A3 | "Why are you looking to move on?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Look forward, not back, and don't criticise your current employer. The move is from one branch's complaints log to a role that owns complaints across a whole organisation. Say why that move appeals, in your own words | F1 is the honest version of the step up. Saying it plainly here stops it turning into a surprise objection in round 2 |
| A4 | "What are your salary expectations and notice period?" | JD | [generic] | Have a range ready from your own research and your current package, plus your actual notice period. This pack gives no figure, because it has no source for one | Standard for a recruiter screen. JD because it checks the terms of the role, not your story |
| A5 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it's in Excel, say so and what you built into it, in your own words. If it's another tool, name it plainly and stay with what you built. Don't list Excel features you haven't used | F9. The JD names Excel, so it's a quick check |
| B1 | "The role needs experience handling regulated complaints. Is that what you've done?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with your own words: "I handled the branch's formal complaints log." Answer slot: if those complaints came under the regulator's complaint-handling rules, say so and what you did with the log, in your own words. If they didn't, or you don't know, say so plainly and describe the log | F7 is a listed requirement your material only partly shows. A recruiter screening against the JD can ask it word for word |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't worked in a contact centre." Stop for a beat, then give one sentence on how you'd learn it in the first weeks, as a plan. Don't pad the "no" | F2. The JD names the contact centre, so a recruiter will check it. A short, unbothered no is the strongest answer you have here |
| B3 | "You'd be reporting monthly to senior leaders. What's the most senior audience you've presented to?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and what, in your own words. If you haven't, say so. Then one sentence on how you'd prepare for your first leadership report, as a plan | F8. The JD puts presenting to senior leaders among its requirements, so expect a screen to check it |

Suggested wording in this bank is pending your approval.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How does the panel score against the four values: one score per value, or an overall view?" | It shows you read their email closely, and the answer tells you how to spread your round 3 stories |
| 2 | "Is the 20-minute case shared in advance or given on the day, and is it spoken or written?" | It's logistics they expect to be asked about, and it changes how you prepare the case build |
| 3 | "Once interviewers are assigned, could you share their names?" | It's a normal request, and names change how you prepare for rounds 2 and 3 |
| 4 | "Is this a new role or a backfill, and does it have a team?" | It tells you what the Head of Member Services is trying to solve before you meet them |
| 5 | "What would make someone stand out in the round with the Head of Member Services?" | Recruiters often share this when asked, and it costs nothing |

---

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "Tell me about a time…" questions, expecting STAR-shaped answers | High. The recruiter says this round is mostly behavioural, which raises it above the hiring-manager default | One story per question, with "we" for context and "I" for what you did. Use the scaffolds where your material has no story |
| Skeptic | Probes the scope gap and the gaps you stated yourself | Medium. Hiring managers reduce risk on gaps, and F1, F2 and F8 are the visible ones | D1 rehearsed until it's boring. Limit first, then evidence, then a plan |
| Data-Driven Prober | Asks what your spreadsheet actually tracks | Low to medium. The JD names monthly reporting on volumes and resolution times, and F3 is your nearest evidence | Know what you can and can't say about how it's counted, and say plainly when you don't know |
| Case / Strategist | One strategy question on digital or hubs | Low. Hiring-manager default, reduced because the round is mostly behavioural and the case sits in round 3 | Clarify, then structure, then answer |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pick a time, for example from your work on the branch's complaints log. It needs the problem, what you did, and how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme is Own the Fix, word for word. Your future manager will want to know what you do with problems before the panel does |
| C2 | "Tell me about a time you escalated something, or decided not to." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pick a time it was your call. It needs what you knew, what you decided and why, and what happened. If none comes to mind, say so plainly and walk through how you'd make that call today | F1 and F4: escalations are the heart of the JD. VAL first because this round is behavioural; it also feeds the coaching requirement |
| C3 | "Tell me about a time you had to explain something complicated to a member." | VAL | [grounded] | Pick a time the first explanation didn't land and you changed how you said it. It needs the thing being explained, what changed, and how you knew it landed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | The theme is Plain Words. Grounded because the value is published; the guidance makes no claim about your past |
| C4 | "Tell me about a time you trained someone and it didn't land the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pick a time from training new tellers on your escalation script if it fits. It needs what you were teaching, what went wrong, and what you changed. If no such time comes to mind, say so plainly and describe how you trained them | F4 is your evidence for the coaching requirement. Your future manager will test whether training tellers stretches to coaching supervisors |
| D1 | "You've handled one branch's complaints log. This role owns complaints end to end, across branches and a contact centre you've never worked in. Why should I believe you can make that jump?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI rehearsal.** Name the limit before they press: "It's one branch, and I haven't worked in a contact centre." Then what you have, in your own words: you handled the branch's formal complaints log, trained new tellers on your escalation script, and built the monthly complaints spreadsheet your regional manager uses. Answer slot: if that spreadsheet covers more than your own branch, say what it covers. If it's your branch only, say so. Then a plan, said as a plan: the first weeks spent learning how complaints move through the contact centre and the other branches. **Follow-up 1** ("One branch isn't 900 staff"): hold, by going back to the log and the spreadsheet without adding to them, and concede precisely: "The scale is new to me." **Follow-up 2** ("So what would you actually do in week one?"): the plan, with no past claims in it. Never say "effectively" or "in practice I ran…" | F1 plus F2 is the gap any reader of the JD and your background will see, so it will be asked in some form. JD because it scores the end-to-end requirement directly |
| D2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of the two gaps you stated and own it: "I haven't presented to anyone above regional level," or "I haven't worked in a contact centre." Then a concrete ramp plan. Don't pick a fake weakness; they already have your background | F8 and F2. A manager asking this wants candour. JD because it maps to stated requirements |
| D3 | "Sixty seconds: why you over someone from a contact-centre complaints team?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause, then hold your ground: six years in retail banking, the last three as a branch supervisor, and the branch's formal complaints log. Concede plainly: "I haven't worked in a contact centre, so they'd know that side better." Don't argue the other candidate down | A time-boxed version of D1, this time on F6 and F2. It stands in for the Pressure persona, which nothing in the loop suggests directly |
| E1 | "Walk me through your monthly complaints spreadsheet. What goes in it, and what does your regional manager use it for?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say what it tracks and how each figure is counted, in your own words. If there's a figure whose counting you'd defend least, name it first. If you don't know what your regional manager uses it for, say so. Don't describe columns or uses you can't stand behind | F3 is your nearest evidence for the monthly reporting line. EXP because it tests what was actually yours |
| E2 | "This role reports monthly on complaint volumes and resolution times. How would you build that report?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | As a plan: what you'd count, how you'd define "resolved", how you'd split it by branch and contact centre, and what the leaders reading it would need first. Answer slot: if your current spreadsheet already does any of this, say which parts. If not, say so plainly and present it as a plan | F3 and F9. JD because it's the stated reporting duty, asked as a live build |
| G1 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints, and how would you work with the digital team?" | JD | [grounded] | A structure: clarify which services move first; where complaints shift (fewer at branches, new ones about digital journeys); complaints data as an input to self-service design; Plain Words applied to digital screens; members who still want a branch. Answer slot, for F5: if you have worked with a digital team or on a self-service journey, say what and which part was yours. If you haven't, say so plainly and present the structure as how you'd start | F5 is your thinnest requirement. JD because it scores the digital-teams line; CO content, from the strategy brief |

Suggested wording in this bank is pending your approval.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first six months look like in this role?" | Asking for your manager's own measure is ownership language, and it frames your ramp plan |
| 2 | "Who sees the monthly complaints report today, and what decisions has it changed?" | It connects to the JD's reporting line and to F3, and tells you how senior the audience is (F8) |
| 3 | "Where do complaints get stuck between the branches and the contact centre today?" | It goes straight at end-to-end ownership, and it shows you know which side you need to learn |
| 4 | "How do you expect the move to hubs in 2027 to change complaint volumes?" | It shows you read the strategy brief, and it's a real planning question for this role |
| 5 | "Will the small-business lending product in Q1 2027 bring its complaints into this process?" | A second strategy-brief signal, and a scope question you need answered before accepting |

---

## Round 3: panel of two branch managers (60 minutes, values-scored, includes the case)

A values round is detected because the recruiter's email says the panel "score against the four values".

### Persona weights

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One question per value, scored | High. The recruiter's email says the panel scores against the four values | The values cheat sheet below: one story or scaffold per value |
| Case / Strategist | The 20-minute case, plus follow-ups | High for the case itself. The recruiter's email names it | The case build above. Clarify first and name the structure out loud |
| Peer Evaluator | Where this role and the branches meet, and what you'd need from them | Medium. Both panellists run branches whose complaints this role would own and whose supervisors it would coach | Show what you'd bring their branches, not just what you'd ask for. Propose principles for the seam rather than pretending to know it |

### Values cheat sheet

| Value (official name) | Working meaning | Your story | Rehearse as |
|---|---|---|---|
| Members First, Always | Decide from the member's point of view | Selection scaffold, from F6 ("6 years in retail banking, the last 3 as a branch supervisor."): a time you made or argued for a decision because of how it would land for the member. It needs the situation (no identifying details), the decision, what it cost or risked internally, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | H1 |
| Plain Words | Needing to explain it twice means it was written badly | Selection scaffold, nearest material F4 ("I handled the branch's formal complaints log and trained new tellers on our escalation script."): a time something you explained, the escalation script to new tellers included, needed explaining again, and what you changed. If none comes to mind, say so plainly, then give the nearest thing, or how you'd handle it | H2, C3 |
| Neighbours, Not Numbers | Each branch belongs to its town | Selection scaffold, from F6 ("6 years in retail banking, the last 3 as a branch supervisor."): a time something about your branch's local community shaped what you did. If none comes to mind, say so plainly, then give the nearest thing, or how you'd handle it | H3, K2 |
| Own the Fix | Whoever finds the problem stays on it until it's solved | Selection scaffold, nearest material F3 ("I built the monthly complaints spreadsheet our regional manager uses."). Answer slot: if you built it because you found a problem, say what the problem was. If it was asked of you, say so plainly and pick another time you kept hold of a problem. If none comes to mind, say so plainly and say how you'd handle it | H4, C1 |

Suggested wording in this table is pending your approval.

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Follow the Members First scaffold in the cheat sheet. Make the member's position explicit and the internal cost honest. If no such time comes to mind, say so plainly and give how you'd handle it | The panel scores this value. The question is built from the value's own wording |
| H2 | "Tell me about a time something had to be explained twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Follow the Plain Words scaffold. Say what changed in the wording, not just that you "made it clearer". If no such time comes to mind, say so plainly, then give the nearest thing, or how you'd handle it | Plain Words is scored. F4 is the nearest place a story might sit |
| H3 | "Tell me about a time your branch's community shaped how you handled something." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Follow the Neighbours, Not Numbers scaffold. Be specific about the place without identifying members. If no such time comes to mind, say so plainly and say how you'd keep branches local through the move to hubs | The value is scored, and the panel run branches facing consolidation |
| H4 | "Tell me about a time you found a problem that wasn't strictly yours and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Follow the Own the Fix scaffold and answer slot. If the spreadsheet story doesn't fit, use another; if none fits, say so plainly | Own the Fix is scored, and it's the value most often tested on someone who would own a process across teams |
| J1 | "Before you start the case: what would you want to know?" | CASE | [generic] | Clarify for two or three minutes: the member, the history, what they've been told, what they want, which complaint rules and time limits apply, and who is involved so far. Ask, don't assume | The case is announced. Clarifying first is what a case is scored on |
| J2 | "The member wants it fixed today, and your process takes longer. What do you do?" | CASE | [generic] | Members First and Plain Words together: what you can do today, what you can't and why, in one plain sentence. Follow any rules that apply. Hold the position, concede precisely, and don't promise what you don't control | A likely follow-up that puts two values in tension. Labelled generic because it describes a pattern, not Ashgrove's process |
| J3 | "The same complaint has come up at three branches this month. What now?" | CASE | [generic] | Own the Fix as a system: count it, check whether it's the same cause, find who owns that cause (a branch, the contact centre, or a digital journey), and put it in the monthly report. Brief the supervisors, and follow up | It connects the case to the JD's reporting and digital lines. CASE because it's live reasoning |
| K1 | "You'd be coaching our supervisors on escalations. What would you need from us, and what would you bring?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with what you bring: you've been a branch supervisor for the last three years, and you trained new tellers on your escalation script. Say plainly that your training was with new tellers. Then what you'd need: time with their supervisors, and their view of where escalations go wrong today | F4 at its honest scope. JD because it scores the coaching line; Peer register because these are the supervisors' managers |
| K2 | "We're moving into hubs next year. How do you stop complaints falling through the cracks while that happens?" | CO | [grounded] | A structure: map where complaints are logged today; set one clear owner per complaint through each move; watch volumes and resolution times by branch during the transition; tell members plainly what's changing. Neighbours, Not Numbers: keep each town's link to a named person | It's the strategy-grounded question this round needs, from the brief, aimed at the panel's own situation |
| K3 | "A branch manager disagrees with how you've resolved a complaint at their branch. How do you handle it?" | CASE | [generic] | Principles: listen first, go back to the member's position, be clear about who owns the decision, write down what you agreed, and follow up. Firm on the member's outcome, flexible on how. Don't claim a past disagreement your material doesn't show | Peer-style seam question. Both panellists are branch managers |

Suggested wording in this bank is pending your approval.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do you see complaints changing in your branches as you move to hubs?" | It asks about their world, it's grounded in the brief, and it doesn't presume anything about their jobs |
| 2 | "What would help your supervisors most from this role in the first few months?" | A reciprocity question. It shows you'd reduce their load, not add to it |
| 3 | "From your side of the counter, what does a well-handled complaint look like?" | It mirrors Members First and the panel's own vocabulary |
| 4 | "Which of the four values is hardest to live day to day in a branch?" | It shows you take the values seriously, and the answer is useful to you |
| 5 | "Where do escalations from your branches get stuck today?" | It goes straight to the JD's escalation coaching, and it's what you'd ask in your first week anyway |

---

## Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own complaints end to end, branches | F1 | D1, A3, C2, J1, J2, J3 |
| Own complaints end to end, contact centre | F2 | B2, D1, D2, D3 |
| Monthly reporting on volumes and resolution times | F3 | E1, E2, J3 |
| Coach branch supervisors on escalations | F4 | K1, C4, C2 |
| Work with digital teams on self-service journeys | F5 | G1, J3 |
| 4+ years in financial-services customer operations | F6 | D3, A1 |
| Experience handling regulated complaints | F7 | B1, J1, J2 |
| Confident presenting to senior leaders | F8 | B3, D2 |
| Comfortable with Excel reporting | F9 | A5, E2 |

---

## Prohibited claims

Claims this pack won't coach, built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran or owned the branch's complaints process | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation is that your material says the log, not the process. F1's slot stays inside the log |
| Resolved regulated complaints | Inflated form of F7 | The same quote at its own scope. B1's slot asks only whether the log's complaints were regulated and what you did with the log |
| Coached supervisors on escalations, or wrote the escalation script | Inflated form of F4 | "I trained new tellers on our escalation script." Your material says tellers and "our" script |
| Branch manager, or ran a branch | Inflated form of F6 | "6 years in retail banking, the last 3 as a branch supervisor." Matters in front of a panel of branch managers |
| Built reporting for senior leadership | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Contact-centre experience, including "something like a contact centre" | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." The only slot stays at regional level |

Digital and self-service work (F5) is not listed: your material is silent on it rather than inflated, so it's handled as an answer slot.

---

## Sources

**Provided documents**
- The JD, pasted.
- Ashgrove's values text, pasted, which you copied on 12 November 2026 from ashgrovecu.org/about/values. Not re-fetched.
- The recruiter's email about the process, pasted.
- The 2026 strategy brief (July 2026), as your four-point summary. I haven't seen the document itself.
- Your background, in your message.

No searches or fetches were sent. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The pasted values text, copied this morning, already fixes the cheat sheet and the VAL themes |
| 2. Ashgrove Credit Union interview process | skipped | The recruiter's email sets out all three rounds, who runs each, and the case, so it already fixes the loop and the persona weights |
| 3. Ashgrove Credit Union strategy and recent news | skipped | The July 2026 brief is under six months old and already fixes the CO questions and the grounding brief |
| 4. Interviewer names | n/a | No names given, so no query to form. The interviewer read is absent; the upgrade menu says what names would add |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for each round, persona weights adjusted to their public professional footprint, and at least one reverse question tied to each interviewer's own career path.
- **Your answers to the answer slots, told to me outside a drill** → the rows that draw on them regenerate as quoted evidence. Most valuable first: what the spreadsheet tracks and what it's built in (F3 and F9, upgrading A5, E1, E2, D1); whether the log's complaints were regulated (F7, upgrading B1); whether you've presented at regional level (F8, upgrading B3, D2); any digital or self-service work (F5, upgrading G1).
- **The spreadsheet itself, with no member data, if your employer allows** → in reporting work the report is the inspectable proof. F3 and F9 could rise from medium to high, and E1 becomes a walk-through you can show.
- **Case details from the recruiter (shared in advance or not, spoken or written)** → a case build tailored to the actual format.
- **The full strategy brief** → the grounding brief carries its real numbers and wording, and G1 and K2 sharpen.
- **Deep research, up to 6 more searches and 2 more fetches, several more minutes** → recent Ashgrove news and organisational context (leadership changes, consolidation updates) and any published interview reports, so your answers sound current on the day.
- **How much prep time you have before 21 November** → a prioritised prep schedule built around D1 and the case.
- **A tuesday-dossier.md from an earlier evaluation of this role, if you have one** → a highest-ROI objection derived from evidence you've confirmed, plus a checked list of claims to steer clear of.
