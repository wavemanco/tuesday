Reading the skill's reference rules before building your pack — a couple more files, then research and drafting.
Research is done (Saltmarsh's values page, its interviewing page, a recent studio announcement, and a public talk by Tobias). Now I'm writing the pack.
I've written your prep pack for Friday. It's built around the format Saltmarsh describes on its careers page: a 60-minute interview with the hiring manager that opens with a live tabletop exercise on a simulated outage during a live event, then moves to a values conversation. I've assumed Tobias is that hiring manager and that Friday is tomorrow, so the prep plan fits one evening.

Pack: /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-canned-d73f9337/saltmarsh-games_live-operations-producer_interview_pack.md

The most important things it found:

- **Rehearse question C1 most.** In September 2026 Saltmarsh announced it is moving two titles to a season pass on one shared events calendar. You told me you've never worked on a game with in-app purchases, so expect that gap to come up. The pack has you say so plainly first. Then you point to the calendar and retention work you did, and give a plan for learning the rest.
- **Your release checklist is your strongest point with this interviewer.** Tobias was a QA lead before running live ops and gave a GDC talk called "Patch Notes Are a Promise". Expect to be asked in detail what's on the checklist and how much of it was yours (D2, E2).
- **Learn the three value names:** Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener. Leave the Build Greener names the checklist directly, so it fits your checklist story (B3).
- **Some answers are left for you to fill in.** Your notes don't say whether you worked with design, art, engineering or community on the content drops. They also don't say whether your title was a live-service game, or who prepared the retention numbers. Where that matters, the pack gives you two honest ways to answer rather than guessing.

It also lists the claims it won't coach, such as running a calendar for two titles or leading a team.

If you want to practise, I can play the sceptical interviewer on C1. I can also save a tuesday-dossier.md recording the gaps this prep found, for you to use in later sessions. If you'd like the pack as a Word document, I'll convert it.

One extra the pack doesn't include: a one-page playbook for the outage exercise covering the first 15 minutes, a template for posting updates to players and an outline for the review afterwards. The exercise is half the hour, so it could be worth having.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Treated as the hiring manager, because Saltmarsh's interviewing page says the 60-minute interview is with the hiring manager (Sources)
**Round:** Friday, 60 minutes. Built as Saltmarsh's documented "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation (Sources)

---

## How to use this pack

- **Personas** = *how* a question is asked (who, in what register). **Types** = *what* is being scored.
- Type key:
  - **VAL** — behaviour against Saltmarsh's *published* values
  - **EXP** — whether what you said about your past holds up under probing
  - **JD** — can you do the listed job, gaps included
  - **CO** — company and strategy homework
  - **CASE** — a live problem from the role, reasoned out loud
- Provenance labels: `[grounded]` = traceable to your words, the JD, or research in Sources; `[inferred]` = a derivation the row names; `[generic]` = a role-family pattern with no claim about Saltmarsh or you.
- **Answer slot** = a place where the pack does not know the answer. It gives you two honest branches. Pick the true one, in your own words. It is not a question for me.
- Guidance is scaffolding, not a script. Question IDs skip the letter F, which is used for fit-snapshot rows (F1–F9).

## Prep triage — assumes one evening (Friday is tomorrow)

1. **C1 out loud three times.** It is the highest-ROI rehearsal in this pack: the season-pass gap, conceded first and then held.
2. **A1 and A2 out loud.** The tabletop is the first half of the hour. Practise the structure, not a script.
3. **Memorise the three value names** (section "Values cheat sheet") and run B1–B3 once each.
4. **D2 and E2.** The release checklist is the line most likely to get a deep probe from this interviewer.
5. **Pick three reverse questions** and keep R1 among them.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title, not a live-events calendar for two. The words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title line makes a probe on juggling more than one schedule likely. If your calendar had to fit around another title's or team's schedule, say what and how, in your own words. If it did not, say so plainly and say how you would plan two |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Coordinating is not leading, and your material speaks only to leading. For that the words are "I haven't led a team." Your material says nothing either way about working with design, art, engineering or community on a drop. Answer slot: if you worked with any of those teams on the content drops, say which and what you did with them, in your own words. If you did not, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting numbers is not owning a post-event review. The words stay at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's ownership line makes a probe on what came after the numbers likely. If a decision or change that was yours came out of those presentations, say what, in your own words. If none did, or it was not yours, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | Writing it is on the record. Managing it release by release is not shown either way. Words: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage … with QA" makes a probe on the checklist's life after you wrote it likely. If you ran it with QA on releases or changed it over time, say how, in your own words. If QA ran it without you once it was written, say so plainly and stay with writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Four years as an associate producer is on the record. Your material does not say whether the main title was run as a live service. Answer slot: if it was, say what made it one, in your own words. If it was not, say so plainly and stay with the four years and the calendar. A years requirement is not a gate, but expect it to be checked literally |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but nothing has been inspected behind it, so expect a probe. Lead with the quote's own terms: the weekly content-drop calendar, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in words, and a probe is close to certain: what was in the numbers. Stay with the quote's terms: you presented them, monthly, to the studio head. Answer slot: if you also prepared or analysed them, say which part, in your own words. If someone else produced them, say so plainly and stay with presenting them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already shows written work in other terms. Reworded only: "I wrote the release checklist, and our QA team still uses it." Describe it and let the interviewer draw the conclusion about your writing |
| F9 | Monetisation on a season pass. Not in the JD. Raised by Saltmarsh's Project Larkspur announcement (Sources) | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. That this role touches the season pass is the pack's inference from Larkspur. The JD does not say it |

## Reading the interviewer

Public professional footprint only.

| Read | Provenance |
|---|---|
| Career pattern: a QA lead at a console studio, then Head of Live Operations at Saltmarsh Games | [grounded] GDC 2026 talk listing (Sources) |
| Public theme: the GDC 2026 talk "Patch Notes Are a Promise", whose argument is that a live team is judged by how often its patch notes describe what actually shipped | [grounded] GDC 2026 talk listing (Sources) |
| Implication: release-and-QA talk is this interviewer's native ground. Expect D2 and E2 to go two levels deeper than with a generalist | [inferred] from the QA-lead background |
| Implication: in the tabletop's comms beat (A2), precision will land better than reassurance. The talk's thesis and the value "Ship the Patch Not the Promise" point the same way | [inferred] from the talk and the values page |
| Implication: an overstated answer cuts directly against the talk's argument. The prohibited list below matters more than usual with this interviewer | [inferred] from the talk |
| Mirror opportunity (shared vocabulary, not a shared jump): the release checklist with QA. Draws on F4: "Wrote the release checklist our QA team still uses." No row in your material carries a QA-to-live-ops career move, so none is offered as a shared path | [grounded] F4 and the talk listing |

## Persona table

The loop rests on Saltmarsh's own interviewing page, not on a guessed pattern.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The outage tabletop, a shared-calendar plan, a retention diagnosis | Highest. A hiring-manager prior, and the interviewing page puts a live-incident tabletop at the start of the hour | Clarify → objective → who's affected → approach → what you'd measure → risks. Think aloud, and challenge one premise respectfully |
| Values / Behavioral | "Tell me about a time…" mapped to Saltmarsh's three values | High. The interviewing page names a values conversation in the same hour | Know the three names cold. Use "we" for context and "I" for your part, and only tell stories your material carries |
| Skeptic | Season pass, two titles, coordinating four teams | High. A hiring-manager prior, and F9, F1 and F2 are the visible gaps | C1 until it's boring. Concede first, hold on what you said, then give a ramp plan |
| Data-Driven Prober | "What was in the retention numbers?" "What's on the checklist?" | Medium, raised from baseline by the QA-lead background (Reading the interviewer) | Know what you can and can't say about each item, and say plainly when you don't know |
| Pressure / Stress | Time-boxed "why you", attribution on the checklist | Low to medium. A simulated outage is built to add time pressure | Pause, restate, anchor in what you actually said. Hold through two follow-ups before conceding anything |
| Conversational | Opener and "why Saltmarsh" | Low, but certain to appear briefly | A pre-built 90-second arc (G1). Treat the casual opener as scored |
| Peer Evaluator | Seams between engineering, community and QA, asked collegially | Low. The interviewer is not a peer, but tabletop follow-ups often take this shape | Propose seam principles, and say what you give each side |

## Question banks

### A — Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's Saturday of a weekend event on one of our titles and the event server goes down. Walk me through your first fifteen minutes." | CASE | [grounded] | Clarify first: what's down, for whom, since when, and whether purchases or progress are at risk. Then who you pull in and in what order, what players hear and when, what you decide about the event itself, and what you write down as you go. Think aloud. The question needs no claim about your past, so make none | The interviewing page names a live-incident tabletop on a simulated outage during a live event, so some version of this is near-certain. CASE because it scores structure, live |
| A2 | "Forty minutes in, players are asking on social whether the event will be extended. Engineering can't give you a fix time yet. What do you post?" | CASE | [grounded] | Say only what is known: what's broken, that the team is on it, and when the next update comes. Promise no extension until it's decided. Draft the post aloud in two or three sentences, then say who signs it off and when you'd decide on the extension | "Ship the Patch Not the Promise" — "we announce what is built, not what is hoped" — is this exact tension, and the JD names community and clear writing. CASE, with VAL scoring underneath |
| A3 | "The outage is fixed and the event is over. How do you run and write up the post-event review — who reads it, and what's in it?" | JD | [generic] | Structure: a timeline, impact in the KPIs the review reports, what went well, what to change (each with an owner), and what goes onto the checklist so it can't recur. Name the audience and length. If asked whether you've run one, that is F3's answer slot, not a yes | The JD makes the post-event review and its KPIs yours and asks for clear writing. JD because it scores a stated responsibility, with CASE delivery. Generic because this is a common structure, not Saltmarsh's template |
| A4 | "From February, both titles share one events calendar. How would you plan the first month?" | CO | [grounded] | Clarify: which dates are fixed, what each title's players expect, which teams are shared. Then one calendar holding each title's beats, a rule against two big beats in the same window, a review point after week two, and what you'd measure. Respectfully test one premise: does "shared calendar" mean shared events, or shared planning? Don't claim to have run a two-title calendar (F1) | Project Larkspur (Sources) moves Tidepool Tactics and Lantern Row to one shared events calendar from February 2027. A Head of Live Operations will check whether you've read it. CO because it scores strategy homework, with CASE delivery |
| A5 | "Retention for players who joined during the event came in below the last event. Diagnose it." | CASE | [generic] | Pin down the measure before guessing: same cohort definition, same window, same audience. Segment by new vs returning, title, platform and acquisition source. Check outside causes (the outage, a competing release, a store change), then the event itself (difficulty, reward pacing). Say what data you'd ask for and what would change your mind | The JD asks for comfort with retention metrics, and this tests it live rather than on your record. CASE. Generic because it's a diagnostic pattern |

### B — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time on that calendar when player response pushed against the plan. It needs what the plan said, what players were telling you, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — the weekly content-drop calendar you ran — or how you would handle it | Tests "Players Before Plans" ("when the calendar and the players disagree, the players win"). F6 is the only row that touches it, so this is a scaffold rather than a mapped story |
| B2 | "Tell me about a time you held back an announcement, or chose not to announce something that wasn't ready." | VAL | [grounded] | Selection scaffold: it needs what was on the table to announce, why it wasn't ready, what you did, and what happened next. If no such time comes to mind, say so plainly, then say how you would handle it — A2 is the live version | Tests "Ship the Patch Not the Promise", the value closest to the interviewer's talk. No row carries a story for it, so the honest branch matters |
| B3 | "Tell me about something you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the release checklist, and your QA team still uses it. Those are the beats the quote states. Answer slot: the value's "leaves … the checklist better than it found them" makes a probe on what came before likely. If there was a checklist before yours, say what yours changed, in your own words. If there was none, say so plainly and stay with writing it and its still being used | "Leave the Build Greener" names the checklist itself, and F4 is your strongest row for it. VAL |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: it needs a named stake, what you said, and how it was received. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — you presented the monthly retention numbers to the studio head — or how you would handle it. Don't turn those presentations into a hard-truth story unless one of them was one | A common values stem. F3 is the nearest row, and the risk is supplying a story's middle that it doesn't hold. VAL |

### C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Both our titles are moving to a season pass. I don't see monetisation in your background — how would you handle that side of this role?" | CO | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | **Highest-ROI rehearsal in the pack.** Concede first, before they press: "I haven't worked on a game with in-app purchases." Then hold on what you did: for the last two years you ran the weekly content-drop calendar for your main title, and you presented the monthly retention numbers to the studio head. Then the ramp, said as a plan: who you'd sit with in your first weeks (whoever owns pricing and the store), what you'd read (past seasons' data and event reviews), and what you'd want to understand first. Follow-up 1, "so you'd learn on our time?": hold. Calendar, release and review work is what the JD lists, and the season pass is a layer you'd learn. Follow-up 2, "what makes a season pass work?": concede specifically — you haven't run one — and say how you'd find out, rather than reciting theory | F9 is the gap Larkspur makes most visible, and a Head of Live Operations moving two titles to a season pass will raise it in some form. CO because the premise is the studio's strategy, not the JD |
| C2 | "This role runs two titles. You've run one. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote at its scope — the weekly content-drop calendar, your main title, two years — and don't widen it. Then answer as a plan: what doubles (stakeholders, collision risk, review load), what you'd standardise across both, what stays title-specific. Answer slot: if your calendar had to fit around another title's or team's schedule, say what and how, in your own words. If it did not, say so plainly and stay with the one calendar | F1 is a transferability gap that the JD's first line exposes. JD because it scores the headline responsibility and F6's content-calendar line |
| C3 | "You'll coordinate design, art, engineering and community on every update. Who have you worked with to get a drop out the door?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team" | The drops are yours to name. Who you worked with is not in your material, so this is F2's answer slot: if you worked with any of those teams on the drops, say which and what you did with them, in your own words. If you did not, say so plainly and stay with the calendar. If leading comes up: "I haven't led a team." Don't let that answer stand in for the coordination question — they are different asks | F2 is discovery on a central JD line. JD because it scores a stated responsibility |
| C4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick a real one and give a plan. The one your material supports is running two titles, since your calendar was for your main title (F1). Name it, then two or three concrete first-month steps. The season pass isn't in the JD. If you raise it here, use C1's wording | The classic Skeptic stem. Rehearsed so the answer is an honest gap with a plan, not a disguised strength. JD |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. What was in them?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Beats: you presented them, monthly, to the studio head. Answer slot: say which numbers were in them and who prepared them, in your own words. If someone else produced them, say so plainly and stay with presenting them. If a figure comes up, know how it was counted, what it's sensitive to, and the assumption behind it you'd defend least — or say plainly that you don't know how it was counted | F7 has no wording gap and nothing inspected behind it, which is exactly where a prober goes. JD content, EXP delivery |
| D2 | "Walk me through the release checklist you wrote. What's on it, and how does QA use it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Beats: you wrote it, and your QA team still uses it. Then what's on it, in your own words. Answer slot: if you ran it with QA on releases or changed it, say how. If QA ran it without you once it was written, say so plainly and stay with writing it | F4 meets the interviewer's QA background (Reading the interviewer), so expect two levels of follow-up. JD as a stated responsibility |
| D3 | "Was your main title run as a live service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | F5's answer slot: if it was, say what made it one, in your own words. If it wasn't, say so plainly and stay with four years as an associate producer and the weekly content-drop calendar. Don't call it "live-service" unless that's your own description of it | F5 is discovery on the JD's years line, which is likely checked literally. JD |

### E — Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live events on a monetised game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "never worked on a game with in-app purchases" | Pause, then three beats in under a minute: the weekly content-drop calendar you ran for your main title for the last two years; the release checklist you wrote that your QA team still uses; and the plain line, "I haven't worked on a game with in-app purchases," with one sentence on how you'd close that gap. Don't argue the other candidate down | The time-boxed comparison stem, applied to F1, F4 and F9 together. JD because it scores fit to the stated role |
| E2 | "That checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it." Return to that through follow-ups. If others gave input, say who and what, in your own words. If it was yours alone, say so plainly. Never widen it to a release process you ran | F4 is the line most likely to interest this interviewer, so it is also the most likely to be tested for attribution. EXP |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from these: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title for the last two years; the release checklist your QA team still uses; the monthly retention numbers you presented to the studio head. Close on why live ops at Saltmarsh, in your own words | The opener of almost any hiring-manager hour. Casual register, still scored. EXP |
| G2 | "What made you apply to Saltmarsh?" | CO | [grounded] | Say what's true for you. If it's Larkspur or a value, name it accurately: one shared events calendar from February, or "Ship the Patch Not the Promise". Don't claim to play the titles unless you do | Motivation asked casually. CO because naming the studio's current move accurately shows homework |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Engineering says the fix needs another day; community wants a date now. How do you handle the gap?" | CASE | [generic] | Name the seam principle: engineering owns the fix estimate, and you own what players hear and when. Post what's known plus the next update time. Never give a date engineering hasn't given. Say what you give each side: engineering gets cover to fix, community gets a reliable cadence | Tabletop follow-ups often take this shape, and the JD names both teams. CASE. Generic because it's a seam pattern |
| H2 | "Tell me about a time a release date and the checklist collided." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time a release date pushed against the checklist you wrote. It needs what was at stake, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing — you wrote the checklist your QA team still uses — or how you would handle it | Tests F4's ongoing side through a story rather than a direct probe. EXP |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | C2, A4, C4 |
| Coordinate design, art, engineering and community on each update | C3, A2, H1 |
| Own the post-event review and the KPIs it reports | A3, A5 |
| Manage the release checklist with QA | D2, E2, H2 |
| 3+ years producing live-service games or apps | D3 |
| Experience running a content calendar | C2, G1 |
| Comfortable with player-retention metrics | D1, A5 |
| Clear written communication | A3, A2 |

## Values cheat sheet

A values conversation is part of the hour (interviewing page). Names and definitions come from Saltmarsh's values page (Sources).

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and what players are telling you conflict, the players win | Selection scaffold on F1: "I ran the weekly content-drop calendar for our main title for the last two years." Pick a time on that calendar when player response pushed against the plan. If none comes to mind, say so plainly and say how you would handle it (B1) |
| Ship the Patch Not the Promise | Announce only what is actually built | No row carries a story. Selection scaffold: something held back or not announced because it wasn't ready. If none comes to mind, say so plainly and say how you would handle it (B2, A2) |
| Leave the Build Greener | Every release leaves the code and the checklist better than before | F4: "Wrote the release checklist our QA team still uses." (B3) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How would that show up in how you judge this role's first event?" | Ties to the interviewer's own published thinking, and turns their thesis into your success criteria |
| R2 | "With per-title event teams moving into one live-ops group under Larkspur, what will this role own in February that nobody owns today?" | Shows you've read the studio's current move, and gets at the real scope |
| R3 | "What does a post-event review look like here today, and which KPI does it lead with?" | Goes straight at a responsibility the JD makes yours |
| R4 | "How does the release checklist work with QA across the two titles now, and what would you want changed?" | Your strongest row, asked as curiosity rather than a claim. It also mirrors "Leave the Build Greener" |
| R5 | "Three months in, what would make you say this hire was the right call?" | Gives you the scorecard, and shows you plan to be measured |
| R6 | "From the outside, what's the hardest part of moving two titles onto one calendar?" | Invites them to teach, which suits an hour run by the person who owns the change |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run a live-events calendar, or one for more than one title | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for one title. C2's slot stays inside that calendar |
| Has led a team | Negative you stated, F2 | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Owned the post-event review or the retention KPIs | Inflated form of F3 and F7 | The quote at its own scope: you presented the monthly retention numbers to the studio head. F3's and D1's slots ask only what came of those presentations and who prepared the numbers |
| Managed the release checklist with QA, or ran the release process | Inflated form of F4 | The quote at its own scope: you wrote the release checklist your QA team still uses. D2's slot asks only about its life after you wrote it |
| Has produced a live-service game | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio" at its own scope. D3's slot asks only how the title was run |

## Sources

**Provided:** the JD text and your background, both from your message.

**Searches and fetches sent:**

| Call | Query or URL | Came back |
|---|---|---|
| Search | Saltmarsh Games values | https://saltmarshgames.com/values |
| Search | Saltmarsh Games interview process producer | https://saltmarshgames.com/careers/interviewing |
| Search | Saltmarsh Games mobile studio news | https://saltmarshgames.com/news/project-larkspur (September 2026, Project Larkspur) |
| Search | Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise (GDC 2026 talk listing) |
| Fetch | https://saltmarshgames.com/values | Three values with definitions |
| Fetch | https://saltmarshgames.com/careers/interviewing | Recruiter call, then the Outage Hour: one 60-minute interview with the hiring manager, a live-incident tabletop, then a values conversation. No take-home |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B1–B3: three values by official name |
| 2. `Saltmarsh Games interview process` | yes | Established the loop. Persona weights follow the tabletop-then-values hour, and a values-style round is detected |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur. Moved A4, C1, G2, R2, R6 and fit row F9 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer, the Prober weight, R1 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Your answers to the answer slots** (F2, F4, F5, F7: who you worked with on drops, the checklist's life after you wrote it, whether the title was live-service, who prepared the retention numbers) → C3, D1, D2 and D3 move from slots to story-mapped answers, and F2 and F5 may move off `discovery`
- **A sanitised copy of the release checklist or a past content calendar** → the artifacts a producer keeps. F4, F6 and F8 could move from `medium` to `high`, and D2 gets concrete
- **A note or email from the recruiter** confirming Friday is the Outage Hour, plus any hint about the tabletop's scenario → confirms the persona weights, and could add a build section if they name a format
- **Deep research (L2): up to 6 more searches and 2 more fetches, several more minutes** → the content of Tobias's GDC talk (sharper A2, R1), a Larkspur strategy brief (deeper A4 and C1), and candidate reports on the Outage Hour
- **A tuesday-dossier.md, if you have one** → evidence-derived objections and a stricter prohibited list, instead of the ones inferred here
