Still reading the prep skill's rules (rubric and personas next), then I'll build your pack.
Now the remaining mirrored references.
I've built your prep pack for Thursday's 45-minute hiring-manager conversation. It's saved as `Quartzline_product-manager-platform-apis_interview_pack.md`. It has 24 questions. Every claim it lets you make about your past comes from the three verified entries in your dossier.

**No company research ran.** All three web searches were refused because search permission wasn't granted. So anything about Quartzline itself, like "why Quartzline" (D2), is generic for now. Don't state anything about the company that you haven't checked yourself.

**Highest-priority prep:** A1, the objection your dossier named: "never held the PM title or owned a roadmap." The pack scripts a plain concession, then your three verified points at their actual size, a ramp plan, and holds for two follow-ups.

**Things I kept out on purpose:**
- **"Seven years":** the dossier's summary says "seven years of integration leadership", but none of your verified entries says that. Give your real tenure from your own record.
- **The input sessions:** they don't count as roadmap experience. Where the dossier says "acknowledge the gap", the pack doesn't bridge it with them.
- **"Shipped an API product":** your integrations reached go-live on the vendor's APIs. The pack doesn't call that shipping an API product.

**If Thursday is today:** today is Thursday 12 November. If you mean today, rehearse A1, then C4 (the probe on the roadmap-input sessions), then the six reverse questions.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also update your `tuesday-dossier.md` with what this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs at Quartzline

**Round:** one 45-minute conversation with the hiring manager (interviewer not named) · **Built from:** your `tuesday-dossier.md` (v1.1) · **Research:** none ran; web search was refused in this session, so everything about Quartzline itself is `[generic]`

**Start here:** A1 is the highest-ROI prep in this pack. Your dossier named that objection, and it will come up in some form.

---

## How to use this pack

- **Personas** describe how a question gets asked (who's asking, in what style). **Types** describe what's being scored.
- Type key:
  - **VAL**: values and behaviour. Does your past behaviour show what they care about?
  - **EXP**: experience deep-dive. Do your claims hold up, and which part was you?
  - **JD**: the job description. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Have you done your homework on Quartzline?
  - **CASE**: a live problem from the role. They score how you structure it, not the "right" answer.
- **Your evidence is three sentences.** Every claim this pack lets you make about your past rests on one of the three verified entries in your dossier, numbered here in their order:
  - **V1**: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"
  - **V2**: "Wrote the internal integration playbook her team uses"
  - **V3**: "Ran quarterly roadmap-input sessions feeding client evidence to product"

  When you say V2 out loud, say "my team", not "her team".
- **Answer slots** mark places where your material is silent. Each one gives you two honest branches: if you did the thing, say how in your own words; if you didn't, or the step never existed, say so plainly. Either branch is a good answer.
- Guidance is scaffolding, not a script. Say it in your own words.
- Question IDs go by persona: A, B, C, D, E, G, H. F is skipped because the fit-snapshot rows use it.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | low | [inferred] | transferability | The dossier's condition is that this is presented as adjacent work and never as PM experience. Open with the plain acknowledgment `prohibited_claims` supports: "I haven't held a product manager title." Then give V1 and V3 at their own scope. Our observation, not words for you: your material shows integration work and input to product, not product management. Answer slot: the "3+ years" line makes a probe on duration likely. Give the figure from your own record. This pack supplies none because no verified entry states one, and that includes the "seven years" in the dossier's summary line |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities; R1 sub-claim) | none given | none | [grounded] | capability | Dossier `acknowledge_gap`. Words: "I haven't owned a product roadmap." Then a ramp plan, always said as a plan and never as a past. No bridge: the underwriter looked and found none, so V3 is not stretched to cover this |
| F3 | "Shipped API or platform products" — JD (dossier R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | Use V1 at its own scope: integrations of the vendor's REST APIs for clients, taken through to go-live. Our observation: the material shows integrating the vendor's APIs, not shipping an API product. Answer slot: the shipped-products line makes a probe on what reached go-live likely. Say which parts of the go-lives were yours, in your own words. If a stage was not yours, say so and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | discovery | REST APIs and architecture touch this requirement without showing docs or schemas. Answer slot: if you read or wrote API docs or schemas during those integrations, say which and how, in your own words. If you didn't, say so plainly and stay with the integrations. B5 tests this live either way |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier R4), customers | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | presentation | The clients in V1 are the customer side of this requirement. Lead with that wording: 30+ client integrations, end to end, from scoping to go-live |
| F6 | "Stakeholder management across engineering, sales, customers" — JD (dossier R4), engineering | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | discovery | Architecture and UAT touch engineering, but they don't show who you worked with. Answer slot: if engineers were part of those stages with you, say who and how you worked together, in your own words. If not, say so plainly and stay with the stages you led |
| F7 | "Stakeholder management across engineering, sales, customers" — JD (dossier R4), sales | none given | none | [grounded] | discovery | Answer slot: if sales were part of any integration, say how and what part was yours. If they weren't, say so plainly |
| F8 | "Agile delivery experience" — JD (dossier R5, preferred) | none given | low | [grounded] | discovery | Dossier `clarify`. Answer slot: if you have worked in agile delivery, say how, in your own words. If you never worked that way, say so plainly. Then ask what you'd want to confirm: how the two squads define and run it |
| F9 | "Run discovery with integration partners" — JD (dossier role_profile responsibilities) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | medium | [grounded] | transferability | Use V3 and V1 at their own scope: quarterly sessions feeding client evidence to product, plus scoping and requirements on the integrations. Say "clients", which is your word. Don't switch to "partners" when describing your own past. The dossier marks V3 as confirmed with little to show for it, so say what you can and can't show before you're asked. Answer slot: if the session format was yours to design, say how it ran. If it wasn't, say so and stay with what the sessions fed to product |
| F10 | "Write specs and drive delivery with two engineering squads" — JD (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | Use V1 at its own scope: you led requirements through UAT and go-live. Plain acknowledgment from `prohibited_claims`: "I haven't set prioritization for an engineering squad." Answer slot: if the requirements you led were what engineers built against, say who used them and how. If not, say so plainly |
| F11 | "Define and track adoption metrics" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | discovery | Answer slot: if you counted or tracked anything about the integrations once they were live, say what was counted. If you didn't, say so plainly and say what you would measure first. The employer has no stated baseline either (see the reverse questions) |

---

## Persona table

The session is the one you described: a 45-minute conversation with the hiring manager. Your own description settles which session this is, so no fallback pattern is needed. No values round was named, so no values cheat sheet appears.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Why hire someone without the title?" asked quietly and persistently | Highest. Hiring managers are de-risking gaps, F1 and F2 are the biggest gaps in the snapshot, and the dossier named this exact objection | Rehearse A1 until it's boring. Concede plainly, bridge only with V1 to V3 at their own scope, close with a ramp plan |
| Case / Strategist | Live problems: flat adoption, three requests for two squads, a breaking change | High. A hiring-manager round usually tests the actual job, and the role's responsibilities (roadmap, adoption metrics, squads) all suit a case | Clarify, then objective, segments, approach, metrics, risks. Think aloud. Challenge one premise per case |
| Data-Driven Prober | "30+ — how did you count that?" and "What changed because of the sessions?" | Medium. V1 carries a figure and V3 is medium confidence; the dossier says to expect a probe | Know what you can and can't say about each number. Name the weakest point before they do |
| Conversational | "Walk me through your journey" at the start, "Why PM?" mid-way | Medium. Nearly every hiring-manager conversation opens this way, and the motivation answer is scored | A pre-built 90-second arc from V1 to V3. Treat casual questions as scored |
| Pressure | Time-boxed "why you over a real PM", or "how much was actually you" | Low to medium. Not the norm for this round type, but your gap invites it | Pause, restate, hold through two follow-ups, then concede something specific |
| Peer Evaluator | Squad-lead seam questions | Low. Not a peer round, but the squad-authority question is open and the manager may test it | Propose principles for the seam, not knowledge of it. Ask about decision rights |
| Values / Behavioral | A customer-versus-metric story, or an unpopular truth | Low. No values round was named, and Quartzline's published values could not be fetched | Have one scaffolded story ready for each |

---

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role", "Having owned a product roadmap"; `acknowledge_gap`: roadmap ownership | **Highest-ROI rehearsal in the pack.** Your dossier named this objection. Concede first: "That's right — I haven't held a product manager title, and I haven't owned a product roadmap." Then say what you did, in the quotes' own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live; you wrote the internal integration playbook your team uses; you ran quarterly roadmap-input sessions feeding client evidence to product. Say what you can and can't show from those sessions before they ask. Don't tell them what any of it proves. Let them draw the conclusion. On "why you over a three-year PM", say in your own words why you want this job; don't claim to be the better PM. Close with the ramp plan, said as a plan: map decision rights with the two squad leads first, sit through one full prioritisation cycle before owning one, then take a scoped decision with a review. **Follow-up 1** ("inputs aren't decisions"): hold with "Right — I fed client evidence to product; the roadmap wasn't mine." **Follow-up 2** ("so you'd be learning the core of the job"): concede specifically that roadmap ownership and prioritisation are what you'd be learning, then go back to the plan, not to new claims | F1 and F2 are where R1 presses hardest, and the dossier named this objection, so it will come up. JD because it scores R1 directly. It's asked with Skeptic patience, and E1 rehearses the time-boxed version |
| A2 | "I don't see roadmap ownership in your background — how would you handle owning the roadmap here?" | JD | [grounded] `acknowledge_gap`: roadmap ownership; `prohibited_claims`: "Having owned a product roadmap" | Plain and short: "I haven't owned a product roadmap." Then spend the time on the plan: who you'd learn the current roadmap from, how you'd learn what partners need before changing anything, and what you'd want agreed with the squad leads before your first call. No bridge here. Don't reach for the input sessions to cover this one | F2 is a capability gap the underwriter found nothing for. JD because the first responsibility listed is to own the roadmap |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `prohibited_claims`: "Having owned a product roadmap" | Pick a real one: roadmap ownership (F2). "Owning the roadmap. I haven't owned a product roadmap." Then a plan in two sentences. Dodging with a fake weakness costs more than the gap does | The standard Skeptic stem. A candid answer here builds credibility for everything else. JD because it scores self-assessment against the listed job |
| A4 | "This role needs someone who's shipped API or platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what went live, in the quote's own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, through to go-live. Don't call it shipping a product. Answer slot: expect a probe on the go-lives. Say which stages were yours and how, in your own words; if a stage wasn't yours, say so and stay with the integrations | F3 is a must-have answered by adjacent work. JD because it reads R2 almost word for word |
| A5 | "You'd be writing specs and driving delivery with two engineering squads. What's your experience setting priorities for an engineering team?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having set prioritization for an engineering squad" | "I haven't set prioritization for an engineering squad." Then V1 at its own scope: you led requirements, UAT and go-live on those integrations. Answer slot: if engineers built against the requirements you led, say who and how; if not, say so plainly. Then a forward line: how you'd want to work with the squad leads on priorities | F10 sits next to a prohibited claim, so the honest answer needs rehearsing before the pressure arrives. JD because it scores the specs-and-squads responsibility |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner adoption of our API has gone flat. Where do you start?" | CASE | [generic] | Clarify first: how is adoption measured today, and what counts as an adopted partner? Then segment (new, integrating, live, dormant), walk the funnel from sign-up to first successful call to production traffic, form two or three hypotheses (onboarding friction, docs, a missing capability, partner economics), and say what you'd look at first and what would change your mind. Name the risks. No claim about your past is needed | The adoption-metrics responsibility (F11) and the unknown baseline make this the likeliest live case. CASE because it's scored on structure |
| B2 | "What adoption metrics would you set up for a partner-facing API platform?" | CASE | [generic] | A short, layered set: activation (time to first successful call), production integrations live, active partners by call volume, retention or churn, error and support load per integration. Then name the metric you'd trust least and why. Ask how it's measured today. This doubles as reverse question 2 | F11 has no evidence, so the case is where you show the thinking. CASE delivery on JD content |
| B3 | "One quarter, two squads, three partner requests that each need a full squad. How do you decide?" | CASE | [generic] | Clarify the objective and who decides (this touches the squad-authority unknown). Compare impact, effort, strategic fit, how many partners each request serves and dependencies. Make the call, say what you'd tell the partner who loses, and how you'd bring the squad leads in. Don't present this as something you've done | Tests the prioritisation core of the role without assuming a past. CASE |
| B4 | "A large partner asks for a breaking change to an endpoint others depend on. Walk me through it." | CASE | [generic] | Clarify the partner's need behind the request. Look for non-breaking options first (new field, new version). Weigh the impact on other partners, then cover the versioning and deprecation path, the communication plan, the migration guide and the timeline. Close with how you'd say no if it came to that | Platform-API judgment and technical fluency (F4) in one live problem. CASE |
| B5 | "Here's an API reference page. What would you change for a partner integrating for the first time?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure it: auth and getting started, a quickstart, request and response examples, error codes and what to do about them, schema clarity, versioning notes. You may open with V1 in its own words to explain why you read docs from the integrator's side. What you saw on those integrations is an answer slot: if specific doc problems came up, name them in your own words; if you can't recall any, don't invent one | F4 is discovery, so a live doc review is a plausible test of R3. CASE delivery on JD content |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30+ integrations — how are you counting those?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words. Answer slots: how the figure was counted; what it's sensitive to; the assumption behind it you'd defend least; which part was yours. Name the weakest one before they do. If you don't know exactly how a part was counted, say so | Every figure on a CV gets probed. EXP because it tests attribution |
| C2 | "Walk me through one of those integrations end to end." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Use the beats the quote gives: scoping, requirements, architecture, UAT, go-live. Pick one real integration and tell those stages in your own words. Answer slot: the JD's docs-and-schemas line makes a probe likely. If you worked from or wrote API docs or schemas on it, say which; if not, say so and stay with the stages | Deep-dive on F3 and F4's evidence. EXP |
| C3 | "Tell me about the integration playbook." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats: you wrote it, and your team uses it. What's in it is yours to describe, in your own words. Answer slot: if asked how you know it's used, say what you've seen; if you have no measure, say so. The dossier says the playbook was provided and inspected, so offer to share a page only if your employer's rules allow it | V2 is high-confidence and inspectable, your strongest artifact. EXP |
| C4 | "Those roadmap-input sessions — what changed in the product because of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say what the quote carries: you ran them quarterly and they fed client evidence to product. Get ahead of the limit: say plainly what you can and can't show from them. Answer slot: if you know of a change that came from that evidence, say what and how you know, in your own words; if nothing you can point to changed, or you don't know, say so. Don't claim you decided anything | The dossier flags V3 as medium and says to expect a probe. This is it. EXP, and the guidance stays clear of "Having owned a product roadmap" |
| C5 | "What does your agile delivery experience look like?" | JD | [grounded] | Dossier `clarify`. Answer slot: if you've worked in sprints or a similar agile setup, say how, in your own words; if you never worked that way, say so plainly. Then ask how the two squads run delivery today and where the PM fits | F8, the preferred requirement. JD because R5 needs a rehearsed answer even as a nice-to-have |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through your journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: the integrations, the playbook, the input sessions, and why that leads you to this role. Titles and dates come from your own record. Answer slot: give your actual titles and durations, and don't round up | The opener sets the frame for A1. Pre-built so it's tight. EXP because the arc is a claim |
| D2 | "What draws you to Quartzline specifically?" | CO | [generic] | Your reasons, in your own words. This pack holds no facts about Quartzline because research didn't run. Use only what you've read yourself on their site or in their API docs, and don't repeat anything you haven't checked | Almost certain to come up. CO, and generic for now; see the upgrade menu |
| D3 | "How do you like to work with engineers?" | JD | [generic] | Treat it as scored (R4). Pick a real working pattern you've had with engineers; it needs a specific situation and what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you'd work with the squads | F6 is discovery. Asked casually, scored on R4 |
| D4 | "Why product management, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your reasons, in your own words. If the input sessions are part of why, you can say so using the quote's own wording. If the reason lies elsewhere, give that one. Keep it forward-looking | Motivation is a Skeptic question asked in a friendly register. JD because it's checked against R1 |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role" | A1 compressed. One sentence of concession ("I haven't held a product manager title"), one sentence each for V1, V2 and V3 in their own scope, one sentence of plan. Then stop. Pause before starting; restating the question buys you a breath | The time-boxed version of the named objection. JD, Pressure delivery |
| E2 | "Those 30+ integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold on what the quote says: you led them, end to end. Answer slot: who else did what, in your own words. If others owned stages, say which. Hold through two follow-ups, then concede the specific part that wasn't yours rather than retreating on "led" | The attribution stem. EXP, Pressure delivery |

### G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "The squad leads have strong views on the roadmap. What happens when you disagree with one of them?" | CASE | [generic] | Offer principles, not knowledge of the setup: agree decision rights up front, bring partner evidence to the disagreement, decide on a fixed timeline, write down the call and the reasoning, commit together once it's made. Ask who breaks a tie here. That's reverse question 1 | The squad-authority unknown, tested as a scenario. CASE because it asks about no past |
| G2 | "Tell me about a time you had to get engineering and sales aligned." | EXP | [generic] | Selection scaffold: a real occasion with both groups, a point of disagreement, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (the client integrations, in V1's words) or how you'd handle it | F6 and F7 are discovery. An open prompt on R4's thinnest parts |

### H — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a named customer need, the internal number it went against, the call you made, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | A persona stem that fits a partner-facing role. Generic because Quartzline's values couldn't be fetched |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a specific truth, who heard it, a moment you held to it, and a relationship still intact afterwards. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | Product roles carry bad news upward. Generic for the same reason as H1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience (F1) | A1, A3, D1, D4, E1 |
| R1 sub-claim: roadmap ownership (F2) | A1, A2, A3 |
| R2: Shipped API or platform products (F3) | A4, C2, E2 |
| R3: Technical fluency, API docs and schemas (F4) | B4, B5, C2 |
| R4: Stakeholder management across engineering, sales, customers (F5, F6, F7) | D3, G1, G2, C2 |
| R5: Agile delivery experience (F8) | C5 |
| Run discovery with integration partners (F9) | C4, B1 |
| Write specs and drive delivery with two squads (F10) | A5, B3, G1 |
| Define and track adoption metrics (F11) | B1, B2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From your dossier. The job description says the PM owns the roadmap, but nothing shows it. The answer tells you whether the job is the one advertised, and asking it shows you think about decision rights |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | From your dossier. Adoption metrics are a stated responsibility with no baseline given. If there's no baseline, defining one is your first win and a fair 90-day goal |
| 3 | "What's the first decision you'd want this PM to own outright, and by when?" | Turns your ramp plan into a shared one, and shows you're thinking about earning authority rather than assuming it |
| 4 | "Where do partner integrations most often stall today?" | Invites the integrator's view that V1 gives you, without you having to claim anything |
| 5 | "How do the two squads run delivery — cadence, rituals — and where does the PM plug in?" | Settles F8 honestly and shows how the squads actually work |
| 6 | "What would make you say, six months in, that this hire worked?" | Gets the real scorecard, which may differ from the job description |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | "I haven't held a product manager title." Then V1 and V3 at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the dossier's `acknowledge_gap` area | "I haven't owned a product roadmap." Then a ramp plan, never a bridge |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." Then V1's requirements stage at its own scope |
| Shipped an API or platform product | Inflated form of F3 | V1's quote at its own scope. The limit is our observation, not words for you: the material shows integrating the vendor's APIs, not shipping an API product. A4's slot stays inside the go-lives |
| Shaped or decided what went on the product roadmap | Inflated form of F9 (V3) | V3's quote at its own scope: sessions feeding client evidence to product. C4's slot asks only what you know changed |
| Wrote the API documentation | Inflated form of V2 (C3) | V2's quote at its own scope: the internal integration playbook |
| Any tenure figure for this work, including "seven years" | The dossier's summary line, not a verified entry (F1) | Your own titles and dates from your own record (D1's slot). The pack gives no figure |

---

## Sources

**Provided document:** `tuesday-dossier.md`, envelope v1.1, generated 2026-08-14 (three months before this pack). Sections consumed:
- `role_profile`: stands in for the job description. Requirements R1 to R5 and the responsibilities are quoted in the fit snapshot.
- `handoff_to_mock_interview`:
  - V1 to V3 come from `verified_candidate_evidence`.
  - Strategies per weak area: F1 bridge, F2 acknowledge_gap, F8 clarify.
  - The A1 objection.
  - Reverse questions 1 and 2.
  - `prohibited_claims`.
- `decision`: context only. Its summary line is not used as evidence about you.

Not in the dossier: `evidence_map`, `risk_register`, `evidence_state`. This pack did its own grading where those would have supplied it.

**Searches sent:**
- `Quartzline company values`: refused (permission not granted)
- `Quartzline interview process product manager`: refused (permission not granted)
- `Quartzline partner API platform news 2026`: refused (permission not granted)

**Fetches:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have given value names to theme the VAL questions (H1, H2). No values cheat sheet either way, since no values round was named |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. Your description already settles this session. It would have shown whether a values or case round sits elsewhere in the loop |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have made D2 company-specific and added a CO or CASE question on current strategy |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there's no interviewer read and no reverse question tied to their path |
| 5. Representative job description | skipped | The dossier's `role_profile` supplies the requirements |

---

## Upgrade menu

- **Allow web search** → targets 1 to 3 run. D2 becomes company-specific, a strategy-grounded CO or CASE question gets added, and H1 and H2 are themed on Quartzline's published values
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes, on top of the above) → a strategy brief, the competitive picture and recent organisational context, for sharper B-bank cases
- **The hiring manager's name** → an interviewer read from their public professional footprint, persona weights adjusted for them, and a reverse question tied to their career path
- **Your answers to the answer slots** (C1's counting, C4's outcomes, F4 docs and schemas, F6 and F7 engineering and sales, F8 agile, F11 metrics) → those rows become story-mapped answers instead of slots
- **How much prep time you have** → a prioritised prep schedule tied to question IDs
- **The recruiter's prep notes** → coverage of any stated focus areas or set deliverable
- **Something that shows what the input sessions produced** (for example, the summaries you sent to product) → could raise V3 from medium, and gives C4 something concrete to point to
- **Your actual CV with titles and dates** → D1's arc gets real dates, and the tenure question gets an exact answer
- **The dossier's `evidence_map`** → the underwriter's grading for each requirement replaces this pack's own grading of F3 to F11
