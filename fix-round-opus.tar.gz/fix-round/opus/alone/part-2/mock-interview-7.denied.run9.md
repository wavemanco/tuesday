Reading the skill's rules is done. Next I'll do a short round of research on Saltmarsh Games and Tobias Wrenfield, then build your prep pack.
Femi, your prep pack is ready: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-denied-2914fabb/saltmarsh-games_live-operations-producer_interview_pack.md`

I built it assuming Tobias Wrenfield would be your manager, since he's Head of Live Operations. My web searches on Saltmarsh and on Tobias were blocked by this session's permissions, so the pack uses only your message and the JD. That means it can't use Saltmarsh's published values, the names of their two games, or Tobias's background.

What it contains:
- **Fit snapshot:** each JD requirement against your own words. Your strongest rows are running the content calendar (F6) and the release checklist (F4).
- **The question to practise most:** B1, "you've been an associate producer — what's the closest you've come to coordinating design, art, engineering and community?" It includes a plain admission ("I haven't led a team") and two likely follow-ups.
- **In-app purchases (B2 and E1):** you admit the gap plainly, then give a plan for learning it. Nothing in the pack makes it sound smaller.
- **22 questions** across seven interviewer styles, plus six questions for you to ask Tobias.
- **A list of claims not to make:** for example, owning KPIs when you presented the retention numbers, or planning the calendar when you ran it.
- **A one-evening plan,** because the interview is tomorrow. It includes playing both of Saltmarsh's games tonight.

If you want to practise B1 out loud, I'll play a skeptical interviewer and push back.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and did the recruiter mention any focus areas or something to prepare, like a sample event plan? Either answer would change which questions the pack prioritises.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interview:** Friday, 60 minutes, one-to-one with Tobias Wrenfield, Head of Live Operations
**Assumed relationship:** hiring manager. This is inferred from his title, since a Head of Live Operations would most likely manage this role. You didn't say so directly. If he isn't your future manager, the persona weights below change.

---

## How to use this pack

Each question has two labels. The **persona** describes how the question is asked: who is asking and in what style. The **type** describes what your answer is being scored on.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values the company publishes |
| EXP | Whether your stated experience holds up under detail, and which parts were actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its games |
| CASE | How you structure and reason through a live problem from the role |

**Provenance labels:** `[grounded]` means it traces to the JD or your own words. `[inferred]` means it is derived, and the derivation is named. `[generic]` means it is a standard pattern for the role, with no claim about Saltmarsh.

The guidance is scaffolding, not a script. An **answer slot** tells you how to answer a likely follow-up honestly whichever way the truth goes. It is not a question for me.

Persona banks are lettered A to H. **F is skipped** so that question IDs never clash with the fit-snapshot rows F1 to F9.

---

## Prep triage

Today is Thursday and the interview is tomorrow, so this assumes you have about one evening.

1. **B1**, the coordination objection. This is the highest-ROI rehearsal in the pack. Say it out loud twice, including both follow-ups. (25 min)
2. **B2 and E1**, the in-app-purchase gap. Rehearse the acknowledgment and then the ramp plan, so the concession doesn't throw you. (15 min)
3. **Play both of Saltmarsh's mobile titles** for at least 20 minutes each, and note one live event or update you see in each. This feeds D2, A1 and your reverse questions. (40 min)
4. **A1, A2 and A4**, the core live-ops cases. Practise the structure, not a full script. (20 min)
5. **C1 and C2**, your retention numbers and your checklist. Know exactly what you can and can't say about each. (15 min)
6. Pick three reverse questions. (5 min)

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material mentions one title and content drops. The JD mentions two titles, live events and planning. Use the quote at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: "Plan and run" makes a probe on planning likely. If deciding what went into the calendar was yours, say how you decided, in your own words. If it was set by someone else, or there was no such step, say so plainly and stay with running it |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Leading a team and coordinating teams are different things. Your material doesn't show whether you coordinated other disciplines. Plain acknowledgment, from your own words: "I haven't led a team." Answer slot: if other disciplines' work fed the weekly drops and getting it lined up was partly yours, say which teams and what you did, in your own words. If not, say so plainly and stay with running the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a post-event review, not the same thing. Your words: "Every month I presented our retention numbers to the studio head." Answer slot: if you reviewed how a content drop performed after it went out, say how, in your own words. If you didn't, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. This is still a statement with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you wrote it, and QA still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | The weekly drops show live content for two years. Your material doesn't say whether all four years were on a live game. Answer slot: if the main title was live for the whole four years and you worked on it, say so in your own words. If part of the time was something else, say what, plainly, and count the years you can stand behind |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. This is your strongest row. Say it in the quote's terms: weekly, main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote reaches the requirement in other words. Say it as: "Every month I presented our retention numbers to the studio head." Don't go beyond presenting unless the rest is yours. C1 rehearses the probe |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [inferred] | transferability | A checklist is one kind of writing, and a lasting one. Your words: "I wrote the release checklist our QA team still uses." Answer slot: if you also wrote other things that went to other people, such as updates, briefs or reviews, name them in your own words. If not, say so plainly and stay with the checklist |
| F9 | Live events on mobile titles often run alongside in-app purchases and revenue goals (role-family pattern, not stated in the JD) | "never worked on a game with in-app purchases." — your message | none | [generic] | capability | This is a gap no wording can close, and you have said so yourself. Words: "I haven't worked on a game with in-app purchases." Then explain how you would learn it, as a plan and never as a past. Nothing should be added to make the gap feel smaller |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Plan and run live-events calendar, two titles (F1) | A1, B1, C3 |
| Coordinate design, art, engineering, community (F2) | B1, A3, G1, G2 |
| Own the post-event review and KPIs (F3) | A4, B4, A2 |
| Release checklist with QA (F4) | C2, A5, E2 |
| 3+ years live-service (F5) | B3 |
| Running a content calendar (F6) | A1, C3, D1 |
| Player-retention metrics (F7) | C1, A2 |
| Clear written communication (F8) | D3, A4 |
| In-app purchases gap, role-family (F9) | B2, E1 |

---

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Plan the next quarter", "diagnose this drop" | High. The hiring-manager prior puts this first, and a Head of Live Ops can test calendar and KPI thinking live | Clarify, then objective, then structure, then metrics, then risks. Think aloud |
| Skeptic | Quiet probes on F2, F3 and F9 | High. The hiring-manager prior, plus three clear gaps against the JD | Rehearse B1 until it's boring. Use bridges built only from your own quotes, then a ramp plan |
| Data-Driven Prober | "What did those retention numbers measure?" | Medium. The JD names retention metrics and KPIs, and F7 is a magnet for this | Know what you can and can't say about how the numbers were counted. Say "I don't know" where that's true |
| Conversational | A friendly opener, "have you played our games?" | Medium. Most 60-minute rounds open and close casually | Have a 90-second arc ready (D1). Treat casual questions as scored |
| Pressure | A time-boxed "why you" | Low. Nothing signals a stress round. It is rehearsed because F9 invites it | Pause, hold your position through two follow-ups, then concede specifically |
| Peer Evaluator | Seams between teams | Low. He isn't a peer, but coordination is central to the JD, so seam questions may arrive in a collegial tone | Propose principles for handling seams. Don't pretend to know Saltmarsh's seams |
| Values / Behavioral | "Tell me about a time…" | Low. No values-style round is detected: Saltmarsh's values couldn't be researched, and your description of the round names none | Choose stories by the scaffolds in H1 and H2 |

The loop is one 60-minute session with Tobias Wrenfield, as you described it. The weights come from the hiring-manager prior, which is inferred from his title.

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Say you inherit both titles' event calendars on day one. How would you plan the next quarter?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: what's already locked, team capacity, and each title's goals. Then the objective for each title, the cadence, the cross-discipline dependencies and lead times, the QA and release gates, and how you'd measure each event. As context you can say, "for the last two years I ran the weekly content-drop calendar for our main title." Don't stretch that to two titles or to planning. F1's slot covers planning | F1 and F6 at the scale of this role. CASE because it's a live plan, not a record |
| A2 | "An event's retention came in well below the previous one. Diagnose it." | CASE | [generic] | Check the data first: tracking, cohort definition, dates. Segment: new or returning players, platform, region, spend tier if one exists. Then look at what changed: content difficulty, event length, overlap with other events, a release bug, outside factors. Form a hypothesis, test it, decide, and record the result in the post-event review. This makes no claim about your past | Tests the JD's retention and KPI lines (F3, F7) as reasoning rather than record |
| A3 | "Art says a key asset will be a week late, and the event goes live in ten days. What do you do?" | CASE | [generic] | Clarify what's late and why. Options: rescope the asset, swap in reused art, move the date, or split the event. Name who decides with you (design, engineering, community). Explain how you'd tell the community if the date moves, and what goes in the review. This makes no claim about your past | The JD's coordination line (F2) asked as a decision, so you can show judgement without a past claim |
| A4 | "Design the post-event review for one of our events. What's in it, who reads it, and which KPIs does it report?" | CASE | [generic] | Structure: the goal set before launch; results against it (participation, retention, plus whatever else the title tracks); what went well and what didn't, across design, art, engineering, QA and community; decisions for the next event; owners and dates. Keep it short and written for its readers. This makes no claim about your past | F3 is a transferability gap, so show the shape you would build. Also covers F8 |
| A5 | "QA finds a serious bug two hours before an update goes live. Walk me through your call." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Severity and reach first, then who has the decision, then the options: hold, ship with the feature disabled, or ship and hotfix. Communication to the community, and what changes in the checklist afterwards. You can mention as context that you wrote the release checklist your QA team still uses. Don't claim you've made a ship or hold call unless that's yours | F4 under pressure. CASE because it's a live decision |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates design, art, engineering and community on every update, across two titles. You've been an associate producer. What's the closest you've come to that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Never led a team" | **Highest-ROI prep in this pack.** Hold: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if other disciplines' work fed those drops and lining it up was partly yours, say which teams and what you did, in your own words. If not, say so plainly and stay with the calendar. Name the limit before he does: "I haven't led a team." Then the ramp, stated as a plan. Follow-up 1, "Who actually made the calls?": answer only what was yours, and stop. Follow-up 2, "What happens when engineering says no?": answer as a plan, framed as "here's how I'd handle it," not as a past event | F2 is where the JD presses hardest, against a stated negative, so some form of this will come. JD because it scores a listed responsibility |
| B2 | "You haven't worked on a game with in-app purchases. If our events carry revenue targets, how would you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open plainly: "I haven't worked on a game with in-app purchases." Don't apologise and don't pad it. Then the plan, all future tense: read past post-event reviews, learn each title's economy and store, sit with analytics or monetisation in the first weeks, and pick out the revenue KPIs the review reports. Close on what you'd bring in, from your quotes only: the content calendar and the retention reporting | F9. Whether this role carries revenue goals is a role-family pattern, not a Saltmarsh fact, so the question is conditional. JD because it scores readiness for the role |
| B3 | "The JD asks for three-plus years producing live-service games. How much of your four years was live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Lead with what the quotes carry: four years as an associate producer, and two years running the weekly content-drop calendar. Answer slot: if the title was live for the whole four years and you worked on it, say so. If not, say what the earlier time was and count only the years you can stand behind | F5. The years requirement is often checked literally, so get the number right before he asks |
| B4 | "Post-event reviews and their KPIs would be yours here. Have you owned a review like that?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you reviewed how drops performed after they went out, say how, in your own words. If not, say so plainly. Then: "Every month I presented our retention numbers to the studio head." Offer A4's structure as how you would run one. Never say you owned KPIs | F3, a transferability gap. "Presented" mustn't drift into "owned" under a direct question |
| B5 | "Why leave now, and why Saltmarsh?" | JD | [generic] | Scaffold: one honest reason for moving now, one specific thing about this role (two titles, owning the review), and one observation from playing their games (triage step 3). If you don't have a specific reason for Saltmarsh yet, say what drew you to the role rather than inventing one | The Skeptic's standard motivation probe. It makes no claim about your past |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Beats from the quote: monthly, retention, presented to the studio head. Answer slot: the JD's retention line makes questions about the numbers likely. If you know what they measured and how they were counted, say it in your own words. Say which part of preparing them was yours, and name the assumption behind them you'd trust least. If you don't know, or someone else prepared them, say so plainly and stay with presenting them | F7 is the evidence for the metrics requirement and a natural target for this persona. EXP because it tests what was yours |
| C2 | "You wrote the release checklist your QA team still uses. What's on it, and why those items?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | You wrote it, so name the items from memory in your own words, and give the reason behind two or three of them. Answer slot: the JD's "with QA" makes a probe on how you worked with QA likely. If you ran it with them on releases, say how. If your part ended at writing it, say so plainly | F4. Your one "none" gap row, so make it concrete |
| C3 | "How did you decide what went into each weekly drop?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if choosing what went into each drop was yours, say how you decided, in your own words. If it was decided by others or by a fixed plan, say so plainly and describe how you ran the calendar week to week | F1's planning gap. "Ran" must not turn into "planned" by itself |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc using only these four facts, in this order: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar; you wrote the release checklist QA still uses; you presented the monthly retention numbers to the studio head. Then why this role. No embellishment | The likely opener. Sets the frame he'll judge everything else by (F5, F6, F4, F7) |
| D2 | "Have you played our games? What did you notice?" | CO | [generic] | Scaffold: play both titles tonight. Give one specific thing you noticed about how each runs events or updates, then one question it raised. If you couldn't play one, say so. Don't assert anything about their numbers or plans | The only CO question possible with no research, and the cheapest way to sound prepared |
| D3 | "How do you like to write things up for the team?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Lead with the checklist: you wrote it, and QA still uses it. Answer slot: if you also wrote updates, briefs or reviews for other people, name one and who read it. If not, say so plainly and describe how you would write a post-event review for different readers | F8, asked casually but still scored |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "never worked on a game with in-app purchases." | Pause first. Hold: two years running a weekly content calendar, which is the core of this role. Concede specifically: "I haven't worked on a game with in-app purchases." Then one line on the plan from B2. If he pushes twice, keep the concession exactly the same size. Don't shrink it and don't fold on the calendar | F9 under time pressure. Hold-then-concede is the skill being tested |
| E2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it. Answer slot: if others added to it or reviewed it, say who and what, plainly. If it was yours alone, say so calmly. Don't claim it's used beyond your QA team | F4's attribution probe. The rehearsal is precise ownership, not modesty |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community wants to announce an event date before engineering has confirmed it. How do you handle it?" | CASE | [generic] | Principle: no public date without the owners' confirmation. Find out what community needs (a teaser, a window rather than a date) and what engineering needs to confirm. Agree a decision point and record it. This makes no claim about your past | The JD's coordination line (F2) asked as a seam question |
| G2 | "What would you need from the other producers and me in your first month?" | JD | [generic] | Reciprocity: access to past post-event reviews, the release history, introductions to the leads in each discipline. Then what you'd give back early, such as a pass over the release checklist with QA (F4's ground). This makes no claim about your past beyond F4 | Tests whether you'd reduce his load or add to it |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: you need a specific moment, what was unwelcome, what you said, and what happened next. If one of those monthly presentations carried bad news, tell it in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona-stem open prompt. Saltmarsh's values couldn't be researched, so it isn't mapped to them |
| H2 | "Tell me about a time something went wrong on a release." | VAL | [generic] | Selection scaffold: what broke, what your part was, what you did, and what changed afterwards. If no such time comes to mind, say so plainly, then explain how you'd handle one | Release management is in the JD (F4), and failure stories are standard in a live-ops round |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a great post-event review look like here? Is there one that changed a decision?" | It points at a responsibility you'd own (F3) and shows you care about the review being used |
| "How are the two titles' calendars run today: shared teams, or separate?" | It goes straight to the hardest part of the JD and helps you judge the role |
| "Which KPIs does live ops watch most closely, and who reads the review?" | It shows comfort with metrics and shows you want to learn their specific set |
| "Where does the release process tend to break down at the moment?" | It invites him to describe a problem you're positioned to help with (F4) |
| "What would you want this person to have taken off your plate by month three?" | It's a reciprocity question that shows you're thinking about his load |
| "How does live ops work with the community team when plans change late?" | It takes the coordination seam seriously without claiming to know it |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | A negative you stated, F2 | "I haven't led a team." |
| Worked on monetised events or in-app purchases | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Planned and ran a live-events calendar across multiple titles | Inflated form of F1 | F1's quote at its own scope. As the pack's observation, not words for you: the material says one main title and content drops. C3's slot stays inside the calendar |
| Owned the KPIs or ran post-event reviews | Inflated form of F3 | F3's quote at its own scope. B4's slot asks only whether you reviewed drops after they went out |
| Analysed or built the retention numbers | Inflated form of F7 | F7's quote at its own scope: you presented them. C1's slot asks what was yours |
| Managed releases or ran QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist QA still uses |

---

## Sources

Provided documents: the JD text and your background, both from your message.

Searches sent. Each one was refused by this session's permissions and returned nothing:

- `Saltmarsh Games values`: refused
- `Saltmarsh Games interview process producer`: refused
- `Saltmarsh Games mobile studio news 2026`: refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. It would have given official value names to theme the VAL questions, and a values cheat sheet if a values round turned up |
| 2. `Saltmarsh Games interview process` | unavailable | The search was refused. It would have confirmed the round's structure and the persona weights |
| 3. `Saltmarsh Games` strategy and recent news | unavailable | The search was refused. It would have let CO and CASE questions name their two titles and recent moves |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. It would have provided an interviewer read, adjusted the persona weights, and given a reverse question tied to his career path |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Allow web search in this session → Saltmarsh's published values by name, questions that name their two titles, and a read on Tobias Wrenfield's public career path with a reverse question tied to it
- Deep research, if wanted after that → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief and grounding section for sharper CO and CASE questions
- Confirm whether Tobias is your future manager → the persona weights stop being inferred
- The recruiter's invite or prep email → coverage of any stated focus areas, or a build section if they've asked you to prepare something such as a sample event plan
- Your CV → more of your own sentences to quote, which strengthens D1, B3 and any row now relying on an answer slot
- Your answers to the slots in F1, F2, F3, F5 and F8 → those rows and B1, B3, B4, C3 and D3 become story-mapped instead of slotted
- A sanitised copy of the release checklist, or another written document → F4 and F8 move from medium toward high confidence, since that is the artifact this field can inspect
- A tuesday-dossier.md, if you have one → verified evidence and a sourced highest-ROI objection instead of an inferred one
