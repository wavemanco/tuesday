I've loaded the pack spec and I'm now doing the default light research: Northwind's published values, its interview process, and Dan's public profile.
I've built Priya's prep pack for the 60-minute peer conversation with Dan: 22 questions in tables, each with answer guidance and the rationale for including and categorizing it. It's saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-1-denied-78d4683b/Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`.

**Web research didn't run.** I tried three searches (Northwind's values, its interview process, Dan's public profile) and permission wasn't granted. So the pack rests only on what you gave me:
- The two behavioral questions are generic, not mapped to Northwind's published values.
- The read on Dan comes from your summary of his profile.
- The Compass and bundling cases come from your research note.

**How the questions are spread:**
- **Most weight goes to the data-driven prober and the peer evaluator.** That's the usual pattern for a peer interviewer, made stronger by Dan describing himself as "relentlessly data-driven."
- **The live cases lean toward pricing**, to match his pricing and monetization background.
- **There's no values cheat sheet**, because no values round was named and the values page couldn't be fetched.

**Most important question to rehearse: B1.** Dan asks how she can own go-to-market for new products without sales-ops or quota-setting experience. That gap is in his own area, so it will come up in some form. The guidance has her state the gap plainly, then follows it through three escalating follow-ups.

**Two things it won't let her claim:**
- **The ~$400M figure:** she *proposed* the change and it was *credited with* the uplift. The pack never says she drove or delivered it.
- **The partner work:** the JD's one "required" item is partner-motion design. Her nearest evidence is a revenue model used in carrier negotiations. The pack doesn't present that as designing a partner motion or running the negotiations.

The full list of claims it won't coach is in a section near the end of the pack.

I can play Dan and run B1 with live follow-ups, then give feedback against that question's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so they carry into later sessions. And if you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Session:** one 60-minute conversation with **Dan Kovac, Director of Sales Strategy**, who would be a **peer**: you'd both report to the same VP.
**Built from:** the JD highlights, the coach's notes on your background, the coach's summary of Dan's profile, and the coach's research note. Web research was attempted and refused (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question gets asked: who is asking, and in what style. **Types** describe *what* is being scored. A question can arrive in any persona's voice, so rehearse both the content and the delivery.
- **Guidance is scaffolding, not a script.** Answer in your own words. Every claim about your past here rests on a sentence quoted from the coach's notes, shown in the Provenance column. Where the notes say nothing, the guidance gives you an **answer slot**: a likely probe with two honest branches. Either branch is a good answer.
- **Highest-ROI prep: B1.** Rehearse it until it bores you.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's values, not generic virtue |
| EXP | Whether your claims hold up under scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework depth: strategy, competition, recent moves, thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, the coach's message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy & ops, not GTM ownership, and the words stay there: "I spent two years in strategy consulting, then nine at a large consumer-tech company in product strategy and ops." Answer slot: the JD's own-GTM line makes a probe on go-to-market work likely. If any of that work shaped how a product went to market, say which part was yours, in your own words. If none did, say so plainly and stay with the product strategy & ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, the coach's message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | A consumer store-surface change is adjacent to B2B lifecycle whitespace but doesn't reach it. Words at the quote's scope: "I proposed a store-surface change that was credited with roughly a $400M ARR uplift." Keep both verbs as they are: you *proposed* it, and it was *credited with* the uplift. Answer slot: the land/adopt/expand/renew line makes a lifecycle probe likely. If you have worked with a customer lifecycle like that, say where, in your own words. If not, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, the coach's message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but a skill claim with nothing inspected behind it, and Dan will probe it. Lead with the skill in plain terms. Answer slot: "independent" makes "walk me through one" likely. If there is an analysis you built yourself, pick it and walk it end to end. If none was yours alone, say so and describe the part you built |
| F4 | "partner-motion design experience required" — JD highlights, the coach's message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A model used in negotiations is adjacent to designing a partner motion but isn't the same thing, and this is the JD's one stated "required". Words at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on the model's role likely. If anything beyond building the model was yours, say which, in your own words. If nothing was, say so plainly and stay with the model you built |
| F5 | "strong cross-functional influence" — JD highlights, the coach's message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already speaks to influence in the JD's terms. Lead with it: "I set annual volume targets with cross-org consensus." The probe will be on how you got that consensus, which is the answer slot in B3 |
| F6 | "AI experience a plus" — JD highlights, the coach's message | "uses AI tools daily" — the coach's notes | medium | [grounded] | discovery | Daily tool use touches the requirement without showing whether it reaches it. Answer slot: if any of that use is part of your analysis or strategy work, say which tools and what for, in your own words. If it is mostly personal productivity, say so plainly |
| F7 | Sales-strategy fundamentals next to the interviewer's own team, such as sales ops and quota setting. This is a role-family pattern, not in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | The coach has stated this gap, and wording can't close it. Words: "I haven't done classic sales-ops or quota-setting work." Then say how you would learn it, as a plan and never as a past. Never equate the volume targets in F5 with quota, and don't pad the gap to make it feel smaller |

---

## Reading the interviewer

Source: the coach's summary of Dan's profile. Public footprint was not independently researched, because the search was refused.

| Signal | What it implies for this session | Provenance |
|---|---|---|
| Self-describes as "relentlessly data-driven" | Every number you say gets probed down to its assumptions, which is why the Prober bank is the heaviest. Say "I don't know how that was counted" before you guess | [grounded] |
| Career spine is pricing and monetization roles | His case questions are likely to tilt toward pricing, packaging and unit economics (C1, B5). That's his native language, so name the price lever explicitly in any case | [grounded] |
| One early-stage-startup chapter | Builder stories tend to land with people like him. Expect a scrappiness probe and some skepticism about big-company pace (D1, E1) | [grounded] for the chapter; [generic] for the implication |
| He is a peer, not your manager | He is pricing what your hire costs and contributes to *his* team. Reciprocity framing matters more than achievement framing (B bank) | [grounded] |
| Mirror opportunity, shared vocabulary | Monetization is his domain, and F4 gives you a sentence in it: "built a partner-level revenue model used in carrier negotiations". Use it in his language, at its own scope | [grounded] |
| Mirror opportunity, shared jump | None offered. No row of the fit snapshot shows a career jump matching his path | [grounded] |

---

## Persona table

The coach's description establishes the loop as one 60-minute peer conversation. Weights start from the peer prior (Peer Evaluator plus Data-Driven Prober) and are then adjusted for Dan's signals.

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | "How was that counted?", denominators, two levels of follow-up | **High.** Peer prior, plus his self-description, plus a headline number (F2) on the table | Know what you can and cannot say about how each number was counted. Name your weakest assumption first. Offer to walk through one analysis end to end |
| B. Peer Evaluator | Seam-splitting between Emerging Products GTM and Sales Strategy, credit, "what do you need from me" | **High.** Peer prior, and the two roles overlap on targets and pricing | Reciprocity: what you bring his team. Propose seam principles rather than pretending to know the seam |
| C. Case/Strategist | Live pricing, packaging or GTM problems on Compass and the bundling threat | **Medium.** Not the peer prior, but his pricing spine makes a live problem likely | Clarify, then objective, segmentation, approach, metrics, risks. Name the price lever. Challenge one premise |
| D. Skeptic | Consumer-to-B2B, partner-motion "required", why now | **Medium.** The biggest gaps (F7, F4, F2) sit exactly in his territory | Calibrated candor. Bridge only from what your quotes carry, and pair it with a ramp plan |
| E. Pressure | Time-boxed "why you over my team's internal candidate", "how much was actually you" | **Low.** Not his style signal, but a peer who might have backed an internal candidate can turn sharp | Pause, restate, hold through two follow-ups, then concede what's real |
| F. Conversational | "Walk me through the journey", casual AI chat | **Low.** The opener and the plus-skill aside. Casual, but still scored | A 90-second arc. Treat the AI question as scored |
| G. Values/Behavioral | One or two behavioral probes | **Low.** No values round is named, and Northwind's values weren't retrieved | Generic selection scaffolds with honest branches |

---

## Question banks

### A. Data-Driven Prober (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ~$400M ARR uplift: walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | State it at its own scope: you proposed the change, and the change was credited with roughly $400M ARR uplift. Then the defend-the-number slots, each in your own words: how it was counted, what it is sensitive to, and which part was yours. "Credited with" doesn't say by whom, so if you know who did the crediting and how, say so. If you don't know how it was counted, say that plainly. That's an honest answer, and a better one than a method you can't repeat under a second question | F2's figure is the one headline number in the material, and Dan's self-description makes a counting probe close to certain. EXP because it tests attribution and survival under scrutiny |
| A2 | "Which assumption behind that $400M would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, in your own words, the assumption you'd defend least, before he finds it. The pack names none because the notes state none. If you don't know what the figure assumed, say so and say what you would check first. Volunteering a soft spot buys credibility with a prober | The follow-up level behind A1. Rehearsed separately because a prober asks it even after a clean A1 answer. EXP for the same reason as A1 |
| A3 | "Take me through the partner-level revenue model. What went in, and how was it validated?" | EXP, JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Start with the model at its own scope: you built it, and it was used in carrier negotiations. Answer slot: inputs and validation are the likely probe. Name the inputs in your own words. If it was validated, say how. If there was no validation step, or it wasn't yours, say so plainly and return to what the model was used for | F4 is the evidence nearest the JD's one stated requirement, so Dan will test it as both a model and a partner signal. EXP first (attribution), JD second (partner-motion) |
| A4 | "Pick one analysis you built yourself in SQL and Tableau and walk me through it end to end." | JD, EXP | [grounded] "skilled in SQL/Tableau" | Answer slot: if there is an analysis you built yourself, choose one with a decision at the end and walk it through: the question, the data, how you built it, what changed because of it, all in your own words. If none was yours alone, say so and describe the part you built. Don't claim a query you couldn't rewrite on a whiteboard | The JD's "independent analysis" line, asked in Prober style. F3 has no gap but nothing inspected behind it. JD content, EXP delivery |
| A5 | "How did you set the annual volume targets, and how did you know afterward whether they were right?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Start with the quote: you set annual volume targets, with cross-org consensus. Answer slot: the method and the after-the-fact check are the likely probe. If you had a method, describe it in your own words. If targets were checked against actuals, say how. If there was no such check, or it wasn't yours, say so plainly. Don't call these quotas (see F7) | F5 is the nearest thing in the material to Dan's own work, so he'll compare methods. EXP because it tests what was actually yours |

### B. Peer Evaluator (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep.** "You haven't done classic sales ops or set quota, and my team lives in that world. How do you own GTM for two new product lines without it, and what would you need from me?" | JD, EXP | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" "built a partner-level revenue model used in carrier negotiations" "skilled in SQL/Tableau" | **Name the limit first:** "I haven't done classic sales-ops or quota-setting work." Then what you bring, at its own scope: "I set annual volume targets with cross-org consensus" and "I built a partner-level revenue model that was used in carrier negotiations." Then reciprocity, framed as a plan: you'd want his team's view of quota and capacity mechanics, and you'd offer analysis capacity in SQL and Tableau to his team in return. **Follow-up 1:** "Volume targets are basically quota, right?" Hold the line: they are different things, so don't claim they're the same. Answer slot: describe what the targets were, in your own words. **Follow-up 2:** "So who sets targets for the new lines?" Propose a seam principle, not an answer: his team owns quota mechanics, you own the GTM thesis and its analysis, and the two of you agree the handoff up front. **Follow-up 3:** "Why not just give this to my team?" Concede the overlap is real. Point him to the reverse question about what would help his team | F7 is the gap the coach has stated, and it sits in Dan's own domain, so it will come up in some form. A rehearsed, non-defensive answer changes the interview. JD because it scores the GTM requirement. EXP because the follow-ups test attribution. It gets the most follow-up levels in the pack |
| B2 | "Our teams sit side by side. Where's the seam between Emerging Products GTM and Sales Strategy, and what happens when we disagree?" | CASE | [generic] | Propose principles, not a map you can't know yet: one owner per decision, a shared data source, and an agreed way to escalate to the VP. Say you'd want to learn where the seam actually sits before proposing one. The question asks about no past, so the guidance makes no claim about yours | The persona's signature probe, made sharper by the shared VP. CASE because it's a live working-model problem, not a record |
| B3 | "Tell me about a time you got other orgs to sign up to targets you set." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5. The beats are the quote's: annual volume targets, set by you, with cross-org consensus. Answer slot: the JD's "strong cross-functional influence" line makes "how did you get there" likely. Say how you got consensus, in your own words. If some disagreement didn't resolve, say so, because a clean story invites a probe | F5 is your evidence for the influence requirement, and a peer will test how you treat other teams. EXP because it tests what was yours |
| B4 | "How do you handle credit when work spans teams? Take the $400M." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the quote's own split: you proposed the change, and the change was credited with the uplift. Answer slot: which part of making it happen was yours and which was other teams'. Say it in your own words, using "we" for context and "I" for your contribution. If you don't know who else's work went into the result, say so | A credit-sharing probe aimed at F2's number, the persona's natural way of reaching the Prober's target. EXP for attribution honesty |
| B5 | "When the bundling threat hits a deal, my reps want to discount and your new lines want full price. How do we resolve that?" | CASE, CO | [grounded] | Clarify first: is the discount defending the core product or the new line? Then the lever options: give in packaging rather than price, use time-bound terms, attach the new line to the renewal. Then guardrails tied to the profitability priority, and the data the two of you would watch together. No claim about your past is needed | It combines the research note's bundling threat and profitability priority with Dan's pricing spine and the peer seam. CASE delivery on CO content. Provenance is the coach's research note |

### C. Case/Strategist (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching. Sketch the GTM: who do we land first, how do we price it, and how does it serve enterprise expansion?" | CO, CASE | [grounded] | **Clarify:** is Compass standalone or an add-on, and is it aimed at the installed base or new logos? **Objective:** expansion revenue under a profitability constraint. **Segmentation:** existing enterprise accounts by usage and readiness. **Packaging:** add-on, inclusion in a tier, or usage-based. Name the trade-off of each in Dan's terms. **Metrics:** attach rate, expansion ARR, margin. **Risk:** the bundling vendor offering a copilot at no extra price. Challenge one premise, for example whether Compass should be priced at all at launch | Two of the research note's three priorities in one question, and a pricing angle for Dan. The one CO question the pack can ground. CO content, CASE delivery |
| C2 | "A much larger platform vendor bundles a near-equivalent into their suite. What do we do with the two new product lines?" | CO, CASE | [grounded] | Structure: where the bundle falls short (depth, neutrality, segments), then the options: compete on depth, partner or integrate with the bundler (a partner-motion angle), reprice, or focus on segments. Then what you'd need to know first, and how you'd test it. No claim about your past | The research note names bundling as the main competitive threat, so a strategy-adjacent peer is likely to raise it. CO content, CASE delivery |
| C3 | "How would you find expansion whitespace for the new lines across land, adopt, expand and renew, starting from our customer data?" | JD, CASE | [generic] | Define each stage as something you can observe in data. Cut the base by core usage against new-line adoption. Look for accounts with high core usage and low new-line adoption. Build a view in Tableau that sales can act on. Agree the definitions with Sales Strategy first. A method, not a past: no claim about yours | The JD's whitespace line, asked live. `[generic]` because the method is a role-family pattern, not a fact about Northwind's data. JD content, CASE delivery |

### D. Skeptic (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see B2B SaaS in your background: nine years in consumer tech. Why would that translate to enterprise data infrastructure?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | State the background as it is. Answer slot: if any of your work involved business customers or partners, say where, in your own words. If none did, say so plainly. Then a concrete ramp plan: what you'd learn in your first 90 days and from whom. Don't tell him your consumer work "proves" you can do B2B. Describe it and let him draw the inference | F1 and F2 both bridge from consumer to B2B, and a skeptic will name that seam directly. JD because it scores fit to the stated role |
| D2 | "The JD says partner-motion design is required. Talk me through partner work you've done." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Open with the quote at its own scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if anything beyond building the model was yours, say which, in your own words. If nothing was, say so plainly and stay with the model. Then a plan for how you would approach partner-motion work here | F4 is the one "required" line with only an adjacent bridge, so it is the second most likely objection after B1. JD because it scores a stated requirement |
| D3 | "Why leave after nine years, why Northwind, and why now?" | CO, EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The notes don't state your motivation, so this is an answer slot: give your real reasons, in your own words. For "why Northwind", anchor in the research note's priorities (enterprise expansion, the Compass launch, profitability) and say which one draws you and why | A motivation-consistency probe, standard for a Skeptic. CO first because "why Northwind" is scored on homework, EXP second for the tenure premise |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone on my team who already knows our sales motion?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "skilled in SQL/Tableau" "built a partner-level revenue model used in carrier negotiations" | Pause, then concede what's true: "I haven't done classic sales-ops or quota-setting work." Then hold on what your material carries: SQL and Tableau, and the partner-level revenue model, at its own scope. Close with the reciprocity point from B1. If he pushes twice, keep holding the same points. Don't add new claims to win | B1's objection in a time-boxed register. Rehearsed because composure under a peer's turf pressure is its own skill. JD because it scores fit |
| E2 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the quote: you proposed the change. Concede explicitly what wasn't yours, using the answer slot from B4. Never fold on the proposal itself just to ease the tension, and never claim the uplift was delivered by you | The persona's stem pointed at F2, the only headline number. EXP because it scores attribution honesty |

### F. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc: the consulting years, the nine years in product strategy and ops, and why this role is next (your own words, see D3). Plant one hook from F4 or F5 for him to pull on | The standard opener. It sets the frame for the whole hour. EXP because he will listen for what you claim |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Start from the quote: you use AI tools daily. Answer slot: say which tools and what you use them for, in your own words. If you use them in analysis work, name one example. If you mostly use them for productivity, say so plainly. Then show curiosity about Compass, for example who it's for, rather than claims about it | The JD's AI plus-skill, asked casually. F6 is a discovery row, and a casual question on a JD plus-skill still counts. JD because it scores a stated plus |

### G. Values/Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you didn't fold, and an intact relationship afterward, in which the truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common behavioral stem. Northwind's values weren't retrieved, so it can't be mapped to a published value. VAL, labeled `[generic]` |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, the metric you gave up, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tension with the profitability priority makes the theme plausible, but it has no published-values source. VAL, `[generic]` |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | B1, C1, D1, E1 |
| "identify whitespace across land/adopt/expand/renew" | C3, A1, A2 |
| "run independent analysis in SQL and Tableau" | A4, C3 |
| "partner-motion design experience required" | D2, A3, C2 |
| "strong cross-functional influence" | B3, B2, A5 |
| "AI experience a plus" | F2, C1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could someone new in this seat do in their first month that would genuinely help your team?" | The reciprocity question for a peer. It answers B1's worry before he has to say it again |
| R2 | "With your pricing and monetization background: how will packaging decisions for Compass get made, and where does Sales Strategy sit in them?" | Tied to his own path, and it maps the seam you'd share |
| R3 | "Where is the bundling threat actually showing up in deals today, and is it visible in the data yet?" | Speaks to his data-driven self-description and the research note's main threat |
| R4 | "Is there a partner motion for these product lines today, or would it be built from scratch?" | Tells you what F4's requirement really means, and reads as diligence |
| R5 | "How do you expect the VP to judge the new lines in year one, and does the profitability goal change that bar?" | Shows you're thinking at the shared boss's altitude, and gives you the real success metric |
| R6 | "What from your startup chapter still shows up in how you run sales strategy here?" | Tied to his path. Opens a peer conversation rather than an interrogation |

---

## Prohibited claims

Nothing in this pack coaches these. Built from the fit snapshot, since no dossier was provided.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed a partner motion, or ran the carrier negotiations | Inflated form of F4 | F4's quote at its own scope: "built a partner-level revenue model used in carrier negotiations". The limit is the pack's observation, not words for you to say: the material says you built the model and that it was used in negotiations, nothing more. A3 and D2 keep their slots inside the model |
| Drove or delivered the ~$400M ARR | Inflated form of F2 | F2's quote: you *proposed* the change, which was *credited with* the uplift. A1, A2, B4 and E2 ask only how it was counted and which part was yours |
| Has set quota, or "volume targets were quota" | A gap the coach stated, F7 | The plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." No slot |
| Owned GTM for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy & ops. F1's slot asks only which part shaped how a product went to market |
| Has AI product experience | Inflated form of F6 | F6's quote: "uses AI tools daily". F2's slot asks only what the use is |

---

## Sources

**Provided material:** the coach's message, containing the JD highlights, the candidate's background notes, the summary of the interviewer's profile, and the research note on Northwind's priorities and competitive threat. No dossier was provided.

**Searches sent:**
- `"Northwind Data" company values`: refused (permission not granted)
- `"Northwind Data" interview process strategy`: refused (permission not granted)
- `"Dan Kovac" "Northwind Data"`: refused (permission not granted)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have themed VAL questions on published values by name. G1 and G2 stay `[generic]` |
| 2. `Northwind Data interview process` | unavailable | The search was refused. The coach's description already establishes this session's loop. It would have added any documented case format or later rounds |
| 3. `Northwind Data strategy` / recent news | skipped | The coach's research note supplies current priorities and the competitive threat that feed C1, C2, B5 and D3. The note's age wasn't stated |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have added his talks or posts to the interviewer read and the reverse questions. The read rests on the coach's summary |
| 5. Representative `Senior GTM Strategy Lead` JD | skipped | The supplied JD highlights fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text** → checks every fit-snapshot row against the full wording, and gives a JD question to any mid-list requirement the highlights left out.
- **Permission for web search** → runs targets 1, 2 and 4: Northwind's values by name (VAL questions mapped to them), any documented interview format, and Dan's public talks or posts (a sharper interviewer read and reverse questions). A deeper pass is also available: up to 6 more searches and 2 more fetches, several more minutes. It would build a grounding brief on Compass, the bundling vendor and the profitability push, and sharpen C1, C2 and B5.
- **Your own answers to the answer slots** in F1, F2, F4 and F6 (said outside a drill) → those rows and the questions that draw on them (A1–A3, B1, D1, D2, F2) move from slots to story-mapped guidance.
- **A work sample you can show, such as a sanitized dashboard or a query you wrote** → raises F3 from `medium` toward `high`.
- **Recruiter guidance** (focus areas, anything to prepare in advance) → coverage keyed to stated focus areas, plus a build section for any pre-declared deliverable.
- **Prep time available** → a prioritized prep schedule sized to it.
- **A `tuesday-dossier.md` from job-underwriter** → an evidence-derived highest-ROI objection, strategy constraints per weak area, and an underwriter-built prohibited-claims list.
