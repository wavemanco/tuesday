Reading the skill's rules for evidence and research before building your three-round pack. Two reference files left, then I'll research and write.
I've saved a prep pack covering all three rounds as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-6-denied-16459d63/Larkfield-Systems_engineering-manager_interview_pack.md`.

It's built from your message alone: the role summary, the three rounds and your four sentences about yourself. I don't have your CV or the full job description. My web searches for Larkfield's values, its interview process and recent news were blocked, so nothing in the pack comes from Larkfield's own published material. That's also why there's no values cheat sheet for Monday.

The pack has one shared table comparing the job's requirements with what you told me. Each round then gets its own 9–12 questions, guidance on how that interviewer is likely to ask, and five questions for you to ask them.

Two things matter most:
- **The question most worth practising is A1:** "You've led a team of six. This is two squads and 11 engineers. Why are you ready?" Some version of it is likely in all three rounds. K3 is the same objection coming from the VP, so practise them together.
- **Your 60% figure says the on-call drop came *after* your reliability quarter, not *because of* it.** Keep it that way under follow-up questions, which C1, F1 and K2 cover.

If you'd like to practise, I'll play your would-be manager on A1 and push back on your answers.
I can also save a `tuesday-dossier.md` recording the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, I'll convert it.

1. Can you paste the full job description and your CV, or a few lines on what you actually did as a lead? I can carry on without them, but they would turn the delivery, growth, hardware and domain rows into answers built on what you've done.
2. Shall I research Larkfield if you allow web search here? The standard pass would get their value names for Monday and a better company-strategy question. There's also a deeper pass on their strategy, people and organisation news: up to 6 more searches and 2 more page fetches, taking several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Loop (from your message):**
- Round 1, Tuesday: 45 min with the hiring manager, a Director of Engineering (your would-be manager)
- Round 2, the Thursday after: 60-min panel with two staff engineers and a product manager
- Round 3, the following Monday: 30 min with the VP Engineering, described by the recruiter as "values and leadership philosophy"

Interviewer names: not given.

---

## How to use this pack

**Personas** describe how a question will feel: who's asking and in what style. **Types** describe what's being scored. Each question carries one type tag:

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows the values or leadership approach the round is about |
| EXP | Whether what you say about your own work holds up under follow-ups, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its level |
| CASE | How you structure and reason through a live problem from the role |

**Provenance labels:** `[grounded]` means it traces to your message. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a role-family pattern with no claim about Larkfield or about you.

**Answer slots.** Where your material doesn't show something the role will ask about, the guidance gives you an *answer slot* with two honest branches. Answer it from your own experience in the interview. If the practice wasn't yours, or never existed, saying so is a full answer.

The guidance is scaffolding, not a script. Rehearse in your own words, and only what you actually did.

**The pack is shaped by three things:**
- **No web research ran.** The searches were refused in this session (see Sources). Nothing here comes from Larkfield's published values, loop documentation or recent news. The CO question is generic, and there's no values cheat sheet.
- **The loop rests on your own description of the three rounds**, not on a pattern for companies like this one.
- **No CV and no full JD.** The fit snapshot uses the role summary and the four sentences about yourself from your message. That's why several rows are answer slots rather than mapped stories.

---

## Fit snapshot (shared across all three rounds)

All requirements are quoted from the role summary in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | Your material shows one team of six. The role is two squads and 11 engineers. Keep the words at the quote's scope: "I've spent three of my nine years as a team lead, of a team of six." What two squads would need from you goes in as a plan for this role, in the future tense, never as a past. The role text doesn't say whether these squads have their own leads. If they do, the words come from your message: "I haven't managed managers." |
| F2 | "own delivery, hiring and growth for 11 engineers" (delivery) — role text in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | Pushing one quarter through is not the same as owning delivery, and your material doesn't show how delivery ran on your team. Answer slot: "own delivery" makes a probe on how your team planned and shipped work likely. If that planning was yours, say how it worked, in your own words. If it sat with someone else, or there was no settled practice, say so plainly and come back to the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring) — role text in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | Your sentence covers a loop for backend roles. The role asks you to own hiring for your own teams. Keep the words at the quote's scope: "I run our hiring loop for backend roles — about 40 interviews last year." Answer slot: the 40 raises the defend-the-number probes: how it was counted, and which part of it was yours. Answer each in your own words. "I'm not sure of the exact count" is an honest answer. If any decisions in the loop were yours, say which and how you made them. If none were, say so plainly and describe how you run the loop |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — role text in your message | none given | none | [grounded] | discovery | Strong evidence here would be one engineer (anonymised), where they started, what you did, and what changed. Answer slot: "growth for 11 engineers" makes a probe on how you've grown engineers likely. If you've done this as a lead, say how, in your own words. If you haven't, say so plainly and say how you'd start |
| F5 | "partner with hardware and product on roadmap" (owning a hardware-related roadmap) — role text in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap that wording can't close, and you've said so yourself. The words: "I haven't owned a hardware-adjacent roadmap." Then how you'd learn it, as a plan and never as a past. Your sentence is about owning such a roadmap, so don't widen it into "I've never worked with hardware" (see F6) |
| F6 | "partner with hardware and product on roadmap" (working alongside hardware teams) — role text in your message | none given | none | [grounded] | discovery | Your material says nothing either way about working alongside a hardware or device team. Answer slot: "partner with hardware" makes a probe on this likely. If you've worked alongside a hardware or device team in any form, say what it was, in your own words. If you haven't, say so plainly and go to how you'd learn the partnership |
| F7 | "partner with hardware and product on roadmap" (product) — role text in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | "Against roadmap pressure" touches roadmap work, but it doesn't show who was on the other side of it or how you worked with them. Answer slot: if you know where that pressure came from and how it was resolved, say so in your own words. If not, say so plainly and stay with the quarter you pushed through and what followed |
| F8 | "building device-management services" (the domain) — role text in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Your material shows engineering at a payments company and nothing either way about devices or IoT. Answer slot: if you've built or run anything involving devices, say what, in your own words. If you haven't, say so plainly, then give your nine years of engineering and how you'd learn the domain |

Your strongest material is your own sentence: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure". It shows up across the banks: C1, B3, E5, F1, J1, J2 and K2. It says *after*, not *because*. Keep it that way (see Prohibited claims).

---

## The highest-ROI prep in this pack: A1

**A1** (Round 1, Skeptic): one team of six against two squads and 11 engineers. It will come up in some form in every round, so it gets the deepest rehearsal. Practise it until it's boring.

---

# Round 1: Tuesday, Hiring manager (Director of Engineering), 45 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Calm, persistent probing of the scale step (F1) and hardware (F5, F6) | High. Hiring managers are buying capability and reducing risk on gaps (relationship prior), and F1 and F5 are the gaps the role text points at directly | The A1 rehearsal. Bridges only from your quoted sentences. Stated limits said plainly, then a concrete ramp plan in the future tense |
| Case / Strategist | "You inherit two squads. What do you do?" Live problems set in the role | High. A hiring-manager prior. No interviewer profile adjusts it | Clarify, objective, approach, risks. Think aloud, and challenge one premise per case, respectfully |
| Data-Driven Prober | "How was the 60% counted?" | Mid-low. Your two numbers (60% and about 40) are the obvious targets for anyone who reads your background closely | Know what you can and can't say about how each figure was counted. Name your weakest assumption first |
| Conversational | Opening "walk me through your journey" and the closing reverse-question slot | Low, but it's always there. A relaxed tone is still scored | A rehearsed 90-second arc. Never say "I think you've covered everything" |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've been a team lead of six. This is two squads and eleven engineers. Why are you ready for that?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | **The highest-ROI rehearsal in the pack.** Hold only what the quote carries: "I've spent three of my nine years as a team lead, of a team of six." Don't make it sound bigger, and don't apologise for it. Then switch to the future tense: how you'd spend the first 90 days across two squads. Cover how you'd learn each squad's way of working, where you'd spend your 1:1 time, and what you'd want to know by day 30. Follow-up 1 is likely "So it's a step up?" Agree in the pack's own terms: two squads and eleven is a bigger scope than the six you've led, so the plan matters. Follow-up 2 may be "Will the squads have leads? Have you managed managers?" Answer with your own words, "I haven't managed managers", then ask how the squads are structured today (reverse question R1-1). Hold through both. Never add scope the quote doesn't carry | F1 is the widest gap between the role text and your material, and a would-be manager has to reduce that risk. JD, because it scores the role's headline requirement directly |
| A2 | "Our roadmap is set with hardware. What's your experience there?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Say it plainly first: "I haven't owned a hardware-adjacent roadmap." Answer slot (F6): the role's "partner with hardware" makes this probe likely. If you've worked alongside a hardware or device team in any form, say what it was, in your own words. If you haven't, say so plainly. Then a learning plan, in the future tense: what you'd ask hardware partners about their release cycle and constraints in your first weeks, and how you'd make those constraints visible to your squads. Don't present a payments analogy as hardware experience | F5 and F6 sit on the role's partnership line, so the Director will want a candid answer on them. JD, because it's a stated responsibility |
| A3 | "Why leave payments for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold. Give one specific thing about *this* role that draws you: the device-management services, the two squads, or the hardware partnership. Then one honest reason about timing in your own career. If part of the reason is about leaving rather than joining, say it in one sentence and turn back to the role. Never criticise your current employer | The standard Skeptic motivation probe, sharpened by the change of domain (F8). JD, because it tests fit with this particular role |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Use your real one rather than a disguised strength: "I haven't owned a hardware-adjacent roadmap." Then one concrete step you'd take in month one. Keep it to about 60 seconds, then stop talking | A persona stem that rewards candour. Your own stated negative (F5) is an honest, ready answer. JD, because it maps to a stated responsibility |
| B1 | "Say you start in January. Two squads, eleven engineers. Walk me through your first 90 days." | CASE | [generic] | Start by clarifying what you'd ask the Director: each squad's charter, current delivery health, the hardware dependencies, and any open hiring. Then a sequence: listen (1:1s with all eleven, sitting in on each squad's rituals), diagnose (where work gets stuck, where on-call hurts, where the squads overlap), one visible small fix, and a plan by day 90 agreed with product and hardware. Name a risk: changing too much before you understand it. The question makes no claim about your past, so the guidance makes none | F1's requirement asked as a live problem. Hiring managers use it to see how you structure your thinking. CASE, because it's set in the role |
| B2 | "Hardware slips a release by six weeks. Your squad's feature depends on it, and product has promised a customer a date. What do you do?" | CASE | [generic] | Clarify first: is the date fixed, and what exactly depends on the hardware? Options: decouple (simulators, feature flags, shipping the software-only part), re-scope, or re-sequence other work. Who decides: you, the PM and the hardware lead together. Tell everyone early. Record what changes and why. Name the trade-off you'd recommend and its cost | It combines the role's hardware, product and delivery lines (F2, F5, F7). CASE, because it's a live problem set in the role |
| B3 | "Your roadmap is full and on-call is hurting. How do you decide whether to stop feature work for reliability?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Give a decision framework first: what on-call is costing (people, incidents, slowed delivery), what pausing features costs, and who has to agree. Then your story in the quote's own terms: you pushed a reliability quarter through against roadmap pressure, and afterwards on-call burden dropped 60%. Answer slot (F7): "partner with product on roadmap" makes a probe on how that went likely. If you made the case to someone, say who and how, in your own words. If there was no such case, or it wasn't yours to make, say so plainly and stay with the quarter and what followed | Your strongest sentence, asked as a judgement call. A Director will want the reasoning, not just the outcome. CASE, because the question is a live problem, and your story is evidence inside it |
| C1 | "On-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slots, each in your own words. **How it was counted:** pages, hours, incidents, or something else. **What it's sensitive to:** what else changed over the same period. **The assumption you'd defend least:** name it before they do. **Which part was yours:** the quote says you pushed the quarter through. "I don't know exactly how it was counted" is an honest branch. Your sentence says *after*, so don't turn it into *because* | Every headline figure gets a defend-the-number question. This is your only one with a percentage. EXP, because it tests a claim about your own work |
| C2 | "About 40 interviews last year. Tell me about the loop and what part of it was yours." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start with the quote: you run the hiring loop for backend roles, about 40 interviews last year. Answer slots: how the 40 were counted, and which part was yours, in your own words. "About" is your word, so keep it. If any decisions in the loop were yours, say which and how you made them. If none were, say so plainly and describe how you run the loop | F3's figure and the scope it leaves open. The role asks you to own hiring. EXP, because it tests what was actually you |
| D1 | "Walk me through your journey so far." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles — about 40 interviews last year" | 90 seconds. Beats from the quotes: nine years of engineering, three of them as a team lead of six, now at a payments company. Then the two things you'd point to: the reliability quarter you pushed through (on-call dropped 60% afterwards) and the hiring loop you run. End on why this role. Each beat is one sentence. Fill in the arc with your own words, not with this cell's | The near-certain opener, and the first impression of how concise you are. EXP, because the interviewer will follow up on anything you say here |
| D2 | "How have you helped engineers on your team grow?" | JD | [grounded] | Selection scaffold. Pick one engineer (no names), where they started, what you did, and what changed for them. A good story has a specific action of yours and a visible change. If no such example comes to mind, say so plainly, then give the nearest thing you do have, or how you'd approach growth across eleven people. Don't present the hiring loop as growth work | F4 is silent, and "growth for 11 engineers" is in the role text. JD, because it's a stated responsibility |

### Reverse questions: Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "How are the two squads structured today? Do they have tech leads or line managers under this role?" | It settles F1's open question and shows you've thought about the shape of the job |
| R1-2 | "What does a great first six months look like to you, and what would worry you?" | It gives you the Director's actual scorecard for the rest of the loop |
| R1-3 | "How is the roadmap set between hardware, product and engineering, and where does it break down most often?" | It goes straight at the partnership line (F5, F6, F7) and shows you'll engage with it rather than avoid it |
| R1-4 | "What's the biggest delivery risk the squads carry right now?" | It invites the Director to describe the real problem, which you can then refer back to in rounds 2 and 3 |
| R1-5 | "How do you support managers who are newer to a larger scope?" | An honest way of acknowledging F1 that turns it into a question about support |

---

# Round 2: the Thursday after, Panel (two staff engineers and a product manager), 60 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | PM: "Where's the seam between us?" Staff engineers: "Who owns technical direction?" | High. For a panel, blend each member's top personas. All three would work alongside you as partners rather than reports, so peer framing dominates | Frame around what you bring each of them. Propose principles for the seams rather than claiming to know them already. Disagreement stories that show both firmness and tact |
| Data-Driven Prober | Staff engineers go two levels into the reliability quarter and the domain | Mid. The peer prior pairs Peer Evaluator with Prober, and staff engineers judge depth | Say plainly what you know and don't know technically. Name your weakest assumption first |
| Case / Strategist | An incident or trade-off scenario set in device management | Mid-low. A 60-minute panel has room for a live problem, and staff engineers often bring one | Clarify, then structure. Think aloud and bring both the engineering and product sides in |
| Values / Behavioural | PM asks "tell me about a time" questions on feedback and hiring | Low. Cross-functional interviewers lean behavioural (relationship prior), but here that's one member of three | One story per question, "we" for context and "I" for your part |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | (PM) "We'd own the roadmap together. Where's the seam between you and me, and what happens when we disagree?" | JD | [generic] | Propose principles rather than claiming to know their seam. For example, product leads on what and why, you lead on how, when and team health, and dates are agreed jointly. When you disagree: put the trade-off in writing, agree who makes the call, and commit afterwards. Ask the PM how it works today. The question makes no claim about your past | The role text's product partnership (F7), asked by the actual partner. JD, because it scores a stated responsibility |
| E2 | (Staff engineer) "Who owns technical direction for the squads: you or us?" | JD | [generic] | Principles: staff engineers own technical direction and quality. You own making room for it, the staffing and the trade-offs against the roadmap, and you step in when a decision is stuck. Ask how decisions get made today. Don't describe a past arrangement unless you had one | Staff engineers test whether the hire will add to their load or take some off it. JD, because leading the squads covers this boundary |
| E3 | (PM) "What would you need from me in the first month, and what would I get from you?" | JD | [generic] | Answer the reciprocity half first: what you'd give (clear capacity, early warning on risk, honest estimates), then what you'd need (the customer context behind the commitments, and their read on the hardware dependencies). Keep it specific and short | A peer stem, and the PM's real question. JD, because it scores the product partnership |
| E4 | (Staff engineer) "How do you handle credit when work spans both squads, or hardware?" | JD | [generic] | Principles: name the people who did the work in public, credit across teams by default, and in reviews describe your own part precisely. Don't present a past cross-team story unless you have one | A peer stem that fits a two-squad role with a hardware partner. JD, because it's part of leading two squads |
| E5 | (PM) "Tell me about a time you pushed back on the roadmap." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story map from the quote: there was roadmap pressure, you pushed a reliability quarter through against it, and on-call burden dropped 60% afterwards. Tell those beats in your own words. Answer slot (F7): the PM will probe who was on the other side. If you know where the pressure came from and how it was resolved, say so in your own words. If you don't, say so plainly and stay with the quarter. Expect the PM to ask how the relationship held up. Answer only from what happened | Your strongest sentence, heard by the role you pushed against. Delivering it without making the PM the villain is the test. EXP, because the follow-ups will press on what was actually yours |
| F1 | (Staff engineer) "Walk us through the reliability quarter." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Start with the quote's beats. Answer slot: staff engineers will ask what changed technically. If you know, say it in your own words, at the level you actually worked at. If the detail sat with the engineers and you don't know it, say so plainly, name who did, and stay with pushing the quarter through. Name the weakest assumption behind the 60% before they do (see C1). The quote says *after*, not *because* | The figure will be tested more technically here than in Round 1. EXP, because it's attribution under expert questioning |
| F2 | (Staff engineer) "What experience do you have with device-management services, or anything like them?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot (F8): if you've built or run anything involving devices, say what, in your own words. If you haven't, say so plainly, then give your nine years of engineering and what you'd do in the first weeks to learn the domain. Don't present payments systems as equivalent to devices. Let the interviewer draw any parallel | F8 is silent, and staff engineers are the people most likely to probe it. JD, because the role text names the domain |
| F3 | (Staff engineer) "Six months in, how would you know whether a squad is healthy? What would you measure?" | CASE | [generic] | Name two or three signals: delivery flow, on-call load, and attrition or engagement. For each, say how it could mislead, which is the weakest-assumption move applied to metrics you're proposing. Add a qualitative signal: what the engineers say in 1:1s. No claim about your past is needed | F2's delivery requirement, asked as a live problem. Engineers want to know whether a manager's metrics will be gamed. CASE, because it's set in the role |
| G1 | "Hypothetically: an update rolled out by your squad's service leaves a few percent of field devices unresponsive overnight. Walk us through the first 24 hours." | CASE | [generic] | Stop the rollout. Establish how many devices are affected and whether it's still spreading. Assign incident roles. Bring in hardware and product early, and agree what customers are told. Recover, find the root cause, then run a blameless review with actions. Say what you'd do yourself and what you'd delegate. It's a hypothetical, so make no claim about Larkfield's systems | A live problem joining the role text's device-management and hardware lines. CASE, because it's set in the role |
| G2 | "Product wants a new feature this quarter. The staff engineers say a core service needs reworking first. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Framework: the cost of delay on each side, the risk if the rework waits, partial options (staging the rework, shipping the feature behind it), and who decides. If it's useful, bring in your reliability quarter in the quote's own terms as the nearest case, without adding to it | The panel's three seats in one dilemma. CASE, because it's a live trade-off, with your story as optional evidence |
| H1 | (PM) "Tell me about a time you gave an engineer difficult feedback." | VAL | [grounded] | Selection scaffold. Pick a case with a specific thing you said, how it was received, and what changed afterwards. "We" for context, "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | The role text's "growth" line (F4) asked as a behavioural question. VAL, because it scores how you lead, not what you know |
| H2 | "Tell me about a time you said no to a candidate others liked, or a hire didn't work out." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The loop you run is the natural place to look for an example, at its own scope. Selection scaffold: a specific candidate (no names), what you saw, what you said, and what happened. If no such time comes to mind, say so plainly and describe how you keep the loop's standard consistent | The role text's hiring line (F3). The panel's hiring bar is affected by yours. VAL, because it scores judgement and firmness |

### Reverse questions: Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | (to the PM) "What could a new engineering manager do in their first month that would genuinely help you?" | The reciprocity question. It hands the PM the chance to describe their real pain |
| R2-2 | (to staff engineers) "Where do you most want a manager to stay out of your way, and where do you most want one to step in?" | It shows you respect the staff engineer role and gives you their exact boundary |
| R2-3 | "What's the last thing that went wrong between software and hardware, and how was it handled?" | A concrete incident tells you more about the partnership (F5, F6) than a description of it |
| R2-4 | "How is on-call shared across the two squads today?" | It links naturally to your reliability quarter without you having to bring it up |
| R2-5 | "What do the squads disagree about most?" | It invites honesty and shows you're looking for the seams |

---

# Round 3: the following Monday, VP Engineering, "values and leadership philosophy", 30 min

**Values cheat sheet: not included.** The recruiter's description makes this a values-style round. But Larkfield's published values aren't in hand, because the values search was refused. VAL questions here are themed on the recruiter's words, "values and leadership philosophy", and not on any named Larkfield value.

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "What's your philosophy?" "Tell me about a time…" | High. The recruiter named the round's focus, which outweighs the skip-level prior | Two or three principles, each tied to something you actually did. Stories that end with the hard truth landing |
| Pressure | "Sixty seconds: why you?" "How much of that was actually you?" | Mid. Skip-level prior. In 30 minutes, short time-boxed answers are tested | Pause, restate the question, hold your position through two follow-ups, and concede specifically, never fold |
| Case / Strategist | "Where is this space going?" "What does your org look like in a year?" | Low. Skip-level prior, kept short because the recruiter's framing points elsewhere | Clarify, structure, and be honest that you haven't seen Larkfield's strategy |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy, in a minute?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Two or three principles, in your own words. Back each one with something you did, or offer it as a principle without evidence. One can rest on the reliability quarter in the quote's own terms: you pushed it through against roadmap pressure, and on-call burden dropped 60% afterwards. Don't attach a principle to the story that the story doesn't show. Rehearse to 60 seconds | The recruiter named this round's subject in these words. VAL, because it's the round's scoring sheet |
| J2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: if the roadmap pressure behind the reliability quarter came from leadership and you made the case to them, tell that story in your own words. If it didn't, or the case wasn't yours, say so plainly and use the selection scaffold instead: a time you said something senior people didn't want to hear, what you said, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | A persona stem, and a likely probe in a "leadership philosophy" round. VAL, because it's the standard values question |
| J3 | "How do you decide who to hire, and what will you never compromise on?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The loop you run gives your standing in the quote's own terms. Then your non-negotiables, which are yours to state. Answer slot: if one of them came from something that happened in the loop, say what, in your own words. If none did, give them as principles | Hiring is a third of the role text's people line (F3), and VPs care about the hiring bar. VAL, because it asks what you stand for |
| J4 | "Tell me about a mistake you made as a lead, and what changed afterwards." | VAL | [grounded] | Selection scaffold. A real mistake with a real cost, what you did about it, and what you do differently now. Give your own part plainly. If no such time comes to mind, say so plainly, then give the nearest thing you do have | A near-universal leadership-round question, themed by the recruiter's words. VAL, because it scores self-awareness |
| K1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles — about 40 interviews last year" | Pause. Then three short beats from the quotes: three years leading a team of six, the reliability quarter you pushed through, and the hiring loop you run. Then one line on the outside perspective you'd bring. Hold under "but they know the hardware". Agree in your own words, "I haven't owned a hardware-adjacent roadmap", then back to your three beats. Don't run past 60 seconds | A Pressure stem made for a short skip-level round. JD, because it scores fit for the role |
| K2 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold what the quote says was yours: you pushed the quarter through. Answer slot: which part of the work and the result was yours, in your own words. If the engineering was the team's, say so plainly and name them as a group. Concede specifically on *after* versus *because* if they push, and don't fold on the part that was yours | A Pressure stem aimed at your headline figure. The honest answer is the strong one. EXP, because it's attribution under pressure |
| K3 | "You've never managed managers or owned a hardware-adjacent roadmap. Why should I bet on you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Agree without hedging: "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Then what you do have, from your quotes: three years leading a team of six, and the reliability quarter. Then your plan to learn both, in the future tense. Hold through "isn't that a big risk?" by restating the plan, not by adding experience. This is A1 at VP level, so rehearse them together | Both negatives are yours, so a VP can state them. F1 and F5 together. JD, because it scores the role's stated scope |
| L1 | "Where do you think industrial IoT is heading, and what should a team like ours be doing about it?" | CO | [generic] | Be honest about how much homework you've done. Don't claim knowledge of Larkfield's strategy you haven't read. Structure: one or two trends you can actually speak to, what they'd mean for device-management services, and a question back to the VP about what they see. Do the reading before Monday if web research becomes possible | Research was refused, so this CO question can't be grounded. It's generic, and that's the honest cost. CO, because it tests whether you can think at the company's level |
| L2 | "If you joined, what would your part of the org look like a year from now?" | CASE | [generic] | Clarify what success means to the VP. Then a year-end picture: delivery predictability, on-call load, hiring done, people growing, and working well with hardware. Name the risks, and the one thing you'd need from the VP. No claim about your past | A skip-level altitude question. CASE, because it's a forward-looking plan set in the role |

### Reverse questions: Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What do you see good managers here do that average ones don't?" | It asks for the VP's own leadership philosophy, which is what the round is about |
| R3-2 | "Where does engineering's relationship with hardware need to be in two years?" | A strategic question about the partnership line, at the VP's level |
| R3-3 | "What's a decision you made that the org disagreed with, and how did you handle it?" | It invites the VP's values in action, and it mirrors J2 |
| R3-4 | "How do managers here grow? Is there a path toward managing managers?" | It's honest about F1 and signals ambition without overclaiming |
| R3-5 | "What would make you say, a year from now, that this hire was a mistake?" | Direct, and it shows you can hear hard feedback, which fits a values round |

---

## Requirement coverage

| Requirement (role text) | Covered by |
|---|---|
| "Lead two squads building device-management services" | A1, B1, E2, E4, K1, K3 |
| "building device-management services" (domain) | A3, F2, G1, L1 |
| "own delivery" | B2, B3, F3, G2, L2 |
| "hiring" | C2, H2, J3 |
| "growth for 11 engineers" | D2, H1 |
| "partner with hardware" | A2, A4, B2, G1, K3 |
| "partner with … product on roadmap" | B2, B3, E1, E3, E5 |
| Recruiter's "values and leadership philosophy" | J1, J2, J3, J4 |

---

## Prohibited claims

Things this pack won't coach, because each one goes further than what you said.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated, F1 | "I haven't managed managers." No answer slot |
| Has owned a hardware-adjacent roadmap | A negative you stated, F5 | "I haven't owned a hardware-adjacent roadmap." No answer slot |
| Has led two teams, or eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not something for you to say: your material shows one team of six. A1 and K3 move from the quote to a plan in the future tense |
| Owned hiring for a team | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop for backend roles. C2's answer slot stays inside the loop |
| The reliability quarter *caused* the 60% drop | Inflated form of F2's quote (*after* turned into *because*) | The quote's own word: on-call dropped 60% *after* you pushed the quarter through. C1's "what it's sensitive to" slot covers the rest |
| Designed or led the reliability work itself | Inflated form of F2's quote | "I pushed a reliability quarter through." The F1 and K2 answer slots ask only what was yours |
| Owned or set the roadmap | Inflated form of F7's quote | "Against roadmap pressure", at its own scope. The E5 and B3 answer slots ask only about the pressure and how it was resolved |

---

## Sources

**Provided:** your message, which gave the role summary, the three rounds and the four sentences about your background.

**Searches sent:**
1. `"Larkfield Systems" values`: refused
2. `"Larkfield Systems" interview process engineering manager`: refused
3. `"Larkfield Systems" industrial IoT news 2026`: refused

**Fetches:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have supplied the official value names for a Round 3 cheat sheet and value-specific VAL questions |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. The loop still stands on your description of the three rounds. It would have added documented formats, such as whether the panel includes a prepared exercise |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The search was refused. It would have grounded L1, and given B1 and B2 real context |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was nothing to search for. There's no interviewer read |
| 5. representative Engineering Manager JD | skipped | The role summary in your message sets the fit-snapshot requirements and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text:** any requirement the summary leaves out gets its own fit-snapshot row and question. Mid-list items like on-call ownership or a named methodology are the ones that usually go missing.
- **CV, or a few lines on what you actually did as lead:** F2, F4, F6, F7 and F8 change from answer slots to mapped stories, along with the questions that draw on them (B3, D2, E5, F1, F2, H1, J2, J4).
- **Answers to any answer slot, given outside a drill:** I'll quote them into the fit snapshot and regenerate the affected rows. For example, how the 60% was counted upgrades C1, F1 and K2.
- **Web search allowed in this session:** targets 1 to 3 run. That gives a Round 3 cheat sheet with Larkfield's value names, a documented loop, and a grounded L1.
- **Interviewer names (Director, staff engineers, PM, VP):** an interviewer read per round, persona weights based on their public professional footprint, and a reverse question tied to each person's career path.
- **The recruiter's prep notes, usually one email away:** if the panel has a prepared exercise or a system-design segment, it gets its own build section.
- **How many hours you have for prep before Tuesday:** a prioritised prep schedule across the three rounds.
- **Before-and-after on-call figures for the reliability quarter, sanitised:** you can show what the 60% rests on, which raises it from medium to high confidence and makes C1 and K2 much easier to hold.
- **A tuesday-dossier.md from job-underwriter:** the most likely objection would come from inspected evidence rather than inference, and its prohibited claims would bind this pack.
