I've built your prep pack. It covers each of the three rounds on 21 November separately, plus a section on the 20-minute case. It's built only from what you sent me. You'd already pasted the values, the strategy points and the recruiter's process, so I didn't need to search the web.

**The most important thing to practise is question D1:** *"You haven't worked in a contact centre, and this role owns complaints there too."* The contact centre is half the job's scope and you've already told me it's a gap. Expect some version of this question in all three rounds. The pack scripts it in three parts:
- **Say the gap first:** "I haven't worked in a contact centre."
- **Stand on what you've actually done:** you handled your branch's formal complaints log and trained new tellers on the escalation script.
- **Give a learning plan:** describe how you'd get up to speed, as something you will do.

It also includes two follow-ups, with one specific concession and the point to hold.

**Other things the pack sets up for you:**
- **Round 3 values:** a cheat sheet for the four values, by their exact names. Two of them can use your own experience: "Plain Words" (your teller training) and "Own the Fix" (the spreadsheet you built). For "Members First, Always" and "Neighbours, Not Numbers" there's nothing in what you told me, so the pack gives you a way to choose a story from your own experience.
- **The case:** a 20-minute outline, three possible arguments each with a weakness you should admit, and two answers to avoid.
- **Senior presenting:** your plain statement, "I haven't presented above regional level." Your sentence doesn't say you've presented at regional level, so don't turn it into that.
- **Claims not to make:** a list of things you might be tempted to say under pressure, each with an honest version. For example, your six years were in retail banking, not six years in complaints. And you trained tellers on the escalation script; your message doesn't say you wrote it.

**Four things the pack can't answer from what you told me.** It leaves you an honest answer either way for each:
- whether your branch's complaints came under regulatory rules
- what your spreadsheet tracks
- whether the spreadsheet is in Excel
- whether you've worked with a digital team

Files are in this folder:
- Prep pack: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-8-canned-41e27a40/Ashgrove-Credit-Union_member-experience-lead_interview_pack.md`

If you want to rehearse, I can play your future manager and run D1 with follow-ups that react to what you say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of loop:** 21 November 2026, three rounds on one day · **Mode:** loop (one shared fit snapshot, then a mini-pack per round)

| Round | Who | Length | What the recruiter said it holds |
|---|---|---|---|
| 1 | The recruiter | 30 min | Not specified beyond the conversation |
| 2 | Head of Member Services, your would-be manager | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | "a 20-minute case on a complaint escalation"; "they score against the four values" |

Interviewer names have not been assigned, so there is no interviewer read; personas rest on each round's role.

---

## How to use this pack

- **Personas** are *how* a question is asked (friendly aside, quiet probe, live case). **Types** are *what* is being scored:
  - **VAL** — behaviour that shows Ashgrove's published values
  - **EXP** — what you actually did; whether your account survives follow-ups
  - **JD** — whether you can do the listed job, gaps included
  - **CO** — Ashgrove's strategy and competitive pressures
  - **CASE** — a live problem from the role, worked out loud
- **Provenance labels:** `[grounded]` traces to something you or Ashgrove supplied; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about you or Ashgrove.
- **Answer slots** are instructions for the interview, not questions for you now. Each has two honest branches: if you did the thing, say how in your own words; if you didn't, or it wasn't yours, say so plainly.
- Guidance is scaffolding, not a script. Everything this pack says about your past is one of four sentences you wrote; they are quoted in the fit snapshot below.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already meets the requirement, just in different words. Say it in its own: "Six years in retail banking, the last three as a branch supervisor." Expect a probe, since there's nothing behind it they can check. Your material gives six years of retail banking, not six years of complaints work; keep the two apart |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Your material says formal complaints and a log you handled. It doesn't say whether those complaints came under a regulator's complaint-handling rules, and this pack names no regime because your inputs don't say which one applies. Answer slot: the JD's word "regulated" makes a probe on the rules likely. If the complaints in that log came under regulatory requirements, name which and what they meant for how you handled the log, in your own words. If they didn't, or you don't know, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | One branch's log, not a process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: "end to end" makes a probe on what else you did with the branch's complaints likely. If any step beyond the log was yours, such as investigating, replying to the member or closing the complaint, say which, in your own words. If none was, say so plainly and describe how you handled the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this gap yourself, and no rewording closes it. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past: for example, sitting in on complaint calls and reading the contact centre's own complaint records in your first weeks. Don't add anything to make the gap sound smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | You built a monthly spreadsheet. The material doesn't say what it tracks or who reports from it. Answer slot: the JD's volumes-and-resolution-times line makes a probe on what's in it likely. If it tracks volumes or resolution times, say which and how each is counted, in your own words. If it doesn't, say what it does track. If you don't know how the regional manager uses it, say so |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | New tellers, not supervisors; training on a script, not coaching judgement calls. The words stay at that scope: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you trained likely. Describe how you trained the tellers on the script, in your own words. If the training was mainly walking them through the script as written, say so plainly |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show this either way. Answer slot: if you have ever worked with a digital or online-banking team, or passed member problems on to one, say what happened and which part was yours, in your own words. If not, say so plainly, then say how you would use complaints data with a digital team |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this gap yourself. Words: "I haven't presented above regional level." Your sentence doesn't say you have presented at regional level, so don't turn it into that. Then the plan, said as a plan: how you would prepare a monthly report for a senior audience. The interview day itself is a live sample, and the panel will see it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The material doesn't say which tool the spreadsheet is in or what you set up in it. Answer slot: if it's in Excel, say so and describe what you set up in it, in your own words. If it's another tool, name it plainly |

**Requirement coverage**

| JD requirement | Fit row | Question IDs |
|---|---|---|
| Own complaints end to end across branches | F3 | A1, D3, K1, L2 |
| …and the contact centre | F4 | B2, D1, L2 |
| Report monthly on volumes and resolution times | F5 | G1, G2 |
| Coach branch supervisors on escalations | F6 | C3, L1 |
| Work with digital teams on self-service journeys | F7 | E2, M2 |
| 4+ years financial-services customer operations | F1 | A1 |
| Regulated complaints | F2 | A4, C1 |
| Presenting to senior leaders | F8 | B3, D2 |
| Excel reporting | F9 | A3, G1 |

**Highest-ROI prep in this pack: D1**, the contact-centre objection. It is the JD's headline scope, you've stated the gap yourself, and some version of it will come up in all three rounds (B2, D1, L2).

---

## Prohibited claims

What this pack will not coach, and why. These are the claims people reach for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process across branches | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says one branch's log |
| Six years of complaints handling | Inflated form of F1 | F1's quote: "6 years in retail banking, the last 3 as a branch supervisor." The pack's observation: the material doesn't say how much of that was complaints |
| Wrote or designed the escalation script | Inflated form of F6 | F6's quote says "our escalation script", and you trained tellers on it. Use it at that scope |
| Coached supervisors on escalations | Inflated form of F6 | F6's quote at its own scope; F6's slot asks only how you trained the tellers |
| Reports monthly to leadership on complaint volumes and resolution times | Inflated form of F5 | F5's quote: you built the spreadsheet your regional manager uses. F5's slot asks only what it tracks |
| Contact-centre experience of any kind | Negative you stated, F4 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders or executives | Negative you stated, F8 | "I haven't presented above regional level." No slot |

---

## Grounding brief (shared)

Built from the strategy brief summary and the values text you supplied. Use the exact names: the panel scores against them.

| Fact | Use it for | Provenance |
|---|---|---|
| Values, by name: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Panel values scoring (sheet in round 3); motivation answers | [grounded] values page text you copied on 12 November 2026 |
| "Own the Fix — whoever finds the problem keeps hold of it until it is solved" | Matches the JD's "own the member complaints process end to end"; frame escalation answers around one named owner | [grounded] values text and JD |
| Move 40% of member service to digital channels by 2028 | Digital-team work (F7); CO questions E2, M2 | [grounded] July 2026 strategy brief, via the recruiter |
| Consolidate eight branches into five hubs over 2027 | Branch-manager panel; complaint risk during consolidation (E1, K2) | [grounded] July 2026 strategy brief |
| Small-business lending product launching Q1 2027 | A new product means new kinds of complaint; a good reverse question | [grounded] July 2026 strategy brief |
| Main competitive pressure: app-only banks | Why the complaints experience is a differentiator (M2) | [grounded] July 2026 strategy brief |
| Member-owned, about 900 staff | Say "members", never "customers" | [grounded] JD |

You have the brief's headlines but not its numbers or wording. Talk about these as Ashgrove's stated plans and don't add figures they didn't publish.

---

# Round 1 — Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, motivation, logistics | High. A recruiter screen has this as its standard pattern; the email describes no other content | A 90-second arc built from your quoted sentences; treat casual questions about JD topics as scored |
| Skeptic (light) | Knockout checks on the JD's gaps, asked lightly | Medium. Recruiters screen against the JD, and F4 and F8 are visible gaps | Short plain acknowledgment plus a one-line plan; save the full version for round 2 |

### Bank A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, in this order, in your own words: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log and training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Close with why this role, which is yours to supply. About 90 seconds | F1, F3 and F5 are your strongest rows, and the recruiter will repeat this arc to the next two rounds; EXP because it's your account of your own work |
| A2 | "What draws you to a credit union — and to Ashgrove?" | CO | [grounded] | Name one value by its exact name and say, in your own words, why it matters to you. Name one stated plan, the hub consolidation or the digital shift, and why owning complaints matters during it. The motivation has to be your own; the pack doesn't supply one | Credit-union motivation is a common screen question; CO because the answer shows whether you've read the values and the brief |
| A3 | "How are you with Excel?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the quote. Answer slot: if it's in Excel, say so and describe what you set up in it, in your own words. If it's another tool, name it plainly. Don't claim a feature you wouldn't be happy to demonstrate | F9 is a JD line a recruiter can tick off; a casual question, but scored |
| A4 | "Tell me a bit about the complaints you've handled." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with the log, in the quote's words. Answer slot: if those complaints came under regulatory rules, name which and what they meant for you; if you don't know, say so plainly. Keep it at one branch | F2 is the JD's "regulated" line; recruiters often screen on it literally |
| A5 | "What are your salary expectations and notice period?" | JD | [generic] | Bring a range you've researched yourself and your real notice period. The pack supplies neither | A standard part of recruiter screens; JD because it's a logistics check against the role |

### Bank B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why are you looking to move now?" | EXP | [generic] | Your real reason, said looking forward. Don't criticise your current employer. If the reason is wanting to own complaints beyond one branch, say that in your own words | A standard motivation probe; EXP because it's checked against your story in the next rounds |
| B2 | "The role covers the contact centre too — what's your contact-centre experience?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The 30-second version of D1: "I haven't worked in a contact centre." Then one sentence of plan and one sentence on what you bring, from F3's quote. Don't stretch it to fill time | F4 is a visible gap; JD because it's a stated scope line. Rehearsed short here so it doesn't spiral |
| B3 | "The role presents monthly to senior leaders — how do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't presented above regional level." Then a plan: how you would prepare. Calm and brief; the composure is part of the answer | F8 is a stated JD requirement and a stated gap |

### Reverse questions — Round 1

| Question | Why it lands |
|---|---|
| "What made the panel decide to score against the four values — is that standard for Ashgrove's leadership roles?" | Shows you read the email closely, and the answer helps you prepare for round 3 |
| "Is the role new, or replacing someone?" | Tells you whether you'd be building the complaints process or inheriting one |
| "Will I know the panel's names before the 21st?" | A practical question that could unlock a better round 3 |
| "How does the role split time between branches and the contact centre?" | Tests the F4 gap without drawing attention to it |
| "What's the timeline after the 21st?" | A logistics question recruiters can answer, and it shows you plan ahead |

---

# Round 2 — Head of Member Services, your would-be manager, 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time…" about escalation, coaching and working with other teams | High. The recruiter said "mostly behavioural", which raises this above the hiring-manager norm | Stories built from your quoted sentences, or a selection scaffold with its honest branch; "we" for context, "I" for your part |
| Skeptic | Quiet probing of F4 and F8: can you scale from one branch to the whole organisation | High. A manager is taking on the risk of your gaps; this is where D1 lands hardest | Plain acknowledgment, what the quotes do carry, then a concrete ramp-up plan |
| Case/Strategist | Short live problems from the manager's actual plans, like hubs and digital | Medium. The usual hiring-manager pattern, reduced because the round is mostly behavioural | Clarify → objective → approach → measures → risks, out loud |
| Data-Driven Prober | "What's in that spreadsheet, and how is it counted?" | Medium. The monthly report is a core duty, and F5 is the closest evidence you have | Know what you can and can't say about how it's counted; say so when you don't know |
| Pressure | Interrupting, time-boxing | Low. Nothing in the inputs suggests it; covered by D1's follow-ups | Pause, restate the question, hold through two follow-ups |

### Bank C — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a complaint escalated and you had to step in." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: choose a complaint from the branch you can tell truthfully. It needs the member's problem, what you did, how it ended, and anything that changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing: how you handled the log, or how you would handle an escalation | Escalation is the JD's core; F2 and F3 are the nearest rows but neither holds a story, so this is a scaffold. VAL first, EXP second |
| C2 | "Tell me about a time you worked with another team to get a member's problem fixed." | VAL | [generic] | Selection scaffold: one problem, the other team, what you asked of them, what you did yourself, and the outcome for the member. If no such time comes to mind, say so plainly, then say how you would approach it | Tests the JD's cross-team side (branches, contact centre, digital) and "Own the Fix"; [generic] because no quote carries such a story |
| C3 | "Tell me about a time you trained someone on how to handle an escalation." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story mapped on F6: new tellers, the escalation script, your training. Answer slot: describe how you trained them in your own words; if it was mainly walking them through the script as written, say so plainly. Don't call it coaching supervisors | The JD's supervisor-coaching line, with F6 as the nearest evidence; VAL with EXP behind it |
| C4 | "Tell me about a time you disagreed with your manager on how something should be handled." | VAL | [generic] | Selection scaffold: a named stake, what you said, whether you held or changed your position and why, and a working relationship intact afterwards. If no such time comes to mind, say so plainly and say how you would raise it | Your manager will be checking how you push back upward; built from the Values/Behavioral stem |

### Bank D — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't worked in a contact centre, and this role owns complaints there too. Why should I trust you with that half of the job?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack.** State the limit before they push on it: "I haven't worked in a contact centre." Hold on what the quote carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then a plan, said as a plan: what you would learn first about how contact-centre complaints are recorded and escalated, and who you would learn it from. **Follow-up 1** ("Contact centres are a different world"): concede specifically. You don't yet know how complaints are logged on calls at Ashgrove, and that's the first thing you'd learn. **Follow-up 2** ("So you'd be learning on the job?"): hold. "On the contact-centre side, at first, yes," then return to the quote, without adding to it. Don't fold, and don't claim parity | F4 is a gap you stated yourself, in the JD's headline line, and your future manager carries the risk. JD because it scores the stated scope |
| D2 | "This role reports to senior leaders every month. Have you presented at that level?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't presented above regional level." Then the plan: how you would build and rehearse a monthly report for that audience, and what you'd ask your manager about format. Keep it calm and short. The 45 minutes in this room are the evidence they'll actually weigh | F8 is a gap you stated, on a stated requirement; a manager asks because they'd be the one sending you into that room |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name a real one, F4 or F8, using its plain acknowledgment and plan. Don't offer a disguised strength. Then one sentence on F3's quote as what you'd start from | The standard Skeptic stem; a real weakness that matches what you told them earlier keeps your story consistent |

### Bank E — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're consolidating eight branches into five hubs during 2027. What happens to complaints, and what would you do?" | CASE | [grounded] | Clarify first: which towns, what timeline, what members are told. Then hypotheses, said as hypotheses: complaints about travel, waiting and losing familiar staff. Approach: watch complaint volumes for affected branches before and after, brief supervisors on likely escalations, and give each affected town one owner. Measures and a risk. Name "Neighbours, Not Numbers" once, naturally | A live problem from the brief that your manager will own; CASE delivery, CO content |
| E2 | "We want 40% of service on digital channels by 2028. How should complaints shape that?" | CASE | [grounded] | Structure: complaints as a signal for which self-service journeys fail members, a regular hand-off to the digital team, and members who can't or won't go digital as a risk to name. Answer slot from F7: if you have worked with a digital team, say what was yours; if not, say so plainly and keep it as a plan | The JD's digital line and the brief's headline target; F7 is silent, so this is the safe way to show you can work at the company's level |

### Bank G — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built — what's in it and how is it counted?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the quote. Answer slot: say what it tracks and how each column is counted, in your own words; name the figure you'd defend least, before they ask; and if you don't know how the regional manager uses it, say so. Offer to walk through its structure if you'd be comfortable doing so, with no member data | F5 and F9 are the closest evidence for the monthly reporting duty, so expect this probe two levels deep |
| G2 | "How would you measure resolution time, and what could make that number misleading?" | CASE | [generic] | Structure: when the clock starts and stops, how reopened complaints count, average vs median, and splitting by channel. Then one thing that could mislead: a quick close that leaves the member unhappy. These are standard measurement choices, not a claim about anything you've done | The JD names resolution times outright; [generic] because it's a reasoning pattern |

### Reverse questions — Round 2

| Question | Why it lands |
|---|---|
| "What does the monthly complaints report look like today, and what would you change about it?" | Your manager owns the report you'd produce, so this shows you're already thinking about the work |
| "Where do complaints get stuck right now — between branches, the contact centre, or somewhere else?" | Asks your manager to name the real problem the role exists to fix |
| "What would a strong first 90 days look like to you?" | Shows you'd work to their measure of success |
| "How will the hub consolidation change what branch supervisors need from this role?" | Draws on the brief, and links coaching to the 2027 changes |
| "Who on the digital side would I work with most?" | Covers the F7 area as a forward-looking question rather than a gap |

---

# Round 3 — Panel of two branch managers, 60 minutes (values round, 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scored questions mapped to the four values | High. The recruiter said they "score against the four values" | One story or scaffold per value, using the value's exact name; see the cheat sheet |
| Case/Strategist | The 20-minute complaint-escalation case | High. Announced by the recruiter; see the case build below | Clarify → member first → owner → fix → log → learn |
| Peer Evaluator | "How will you work with our branches without adding to our load?" | Medium. Branch managers' supervisors are the people you'd coach; they're weighing what you add and what you cost | Reciprocity: what you bring their branches, principles for where the boundaries sit |
| Skeptic | "Head-office person" and branch-future probes | Medium. Two of three rounds touch consolidation, and branch managers are living through it | Talk about branches as you know them from F1, said at the quote's scope |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's point of view, not the branch's convenience | Selection scaffold: a time you chose what was right for the member when another option was easier for the branch. It needs the choice, what it cost, and the outcome. If none comes to mind, say so plainly and say how you would decide (J1) |
| Plain Words | If something needs explaining twice, the explanation was the problem | F6: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if training tellers on the script ever meant changing how something was explained, say what and why; if not, say so and choose another story (J2) |
| Neighbours, Not Numbers | Every branch belongs to its town; treat members as people, not cases | Selection scaffold: a time knowing a member or the local community changed how you handled something. If none comes to mind, say so plainly and say how you would keep that during the hub consolidation (J3) |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | F5: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because you spotted a problem, say what the problem was and whether it got solved; if not, use a different story where you kept hold of a problem (J4) |

### Bank J — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Cheat-sheet scaffold for Members First, Always. Use the value's own phrase once. "We" for context, "I" for your choice. Honest branch if no story fits | Scored value 1; phrased in Ashgrove's own words because that's how the panel holds it |
| J2 | "Tell me about a time something had to be explained twice — what did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story mapped on F6 if the slot's first branch is true for you: what you changed and why, in your own words. Otherwise pick a different story using the same scaffold shape, or use the honest branch | Scored value 2; F6 is the only quote close to explaining things to people |
| J3 | "Tell me about a time knowing a member or your town changed how you handled something." | VAL | [grounded] | Cheat-sheet scaffold for Neighbours, Not Numbers. A specific member situation, kept anonymous; what local knowledge changed; the outcome | Scored value 3; branch managers live this value and will hear quickly whether a story is real |
| J4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story mapped on F5 only if its slot is true for you: the problem, why you built the spreadsheet, and whether the problem got solved. Don't claim a result you didn't see. Otherwise pick another story and use the scaffold | Scored value 4; also echoes the JD's "own… end to end" |

### Bank K — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | Practice case: "A member's complaint about a fee has gone back and forth between a branch and the contact centre for three weeks. They've now said they'll leave. Walk us through what you do." | CASE | [generic] | Use the case build below. The practice scenario is invented, so don't treat its details as Ashgrove's | Rehearses the announced case format on an invented scenario; [generic] because the real case's content isn't known |
| K2 | "One of our branches closes into a hub next year and older members are already complaining. What do you do?" | CASE | [grounded] | Clarify which complaints and how many, then member first: what members are told, and in plain words. Name one owner for that town's complaints and brief the supervisors. Measure volumes before and after. Risk: members who can't travel and won't go digital | Consolidation is in the brief, and these panellists may be affected by it themselves; CASE delivery, CO content |

### Bank L — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Our supervisors are stretched. How would you coach them on escalations without adding to their load?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Reciprocity first: what supervisors would get from you, in your own words. You can say you were a branch supervisor for the last three years, and nothing beyond that. Propose principles, not a full programme: short, regular, built on their real cases. Ask what they'd find useful | The JD's coaching line from the point of view of the people whose staff would be coached; JD because it scores that duty |
| L2 | "When a complaint goes wrong between a branch and the contact centre, who owns it — and what if we disagree with your call?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Principle: "Own the Fix", meaning one named owner until it's closed. Disagreement: listen, decide, explain in plain words, and review afterwards. If the contact-centre side comes up, use F4's plain acknowledgment once; don't claim to know how the contact centre works | Where branch and contact-centre responsibilities meet is the JD's scope; F4 is likely to come up again here, from peers' point of view |

### Bank M — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "How do we know you won't become just another head-office voice telling branches what to do?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Hold on F1's quote, said at its own scope. Then what you'd actually do: time in branches, and listening before changing anything, said as a plan. Echo "Neighbours, Not Numbers" | A natural panel worry when the job title sits above them; scored against the values |
| M2 | "App-only banks fix things in-app in minutes. Why would a member put up with our complaints process?" | CO | [grounded] | Don't concede the premise or argue with it. Say how Ashgrove can compete: a fast route in the app for simple issues, plus a person and a branch when it matters. Complaints show where the digital route is failing members (F7's slot applies if you mention digital work). Plain words | Competitive pressure is named in the brief; a CO question where most candidates have nothing specific to say |

### Graded deliverable — the 20-minute complaint-escalation case

**What you're building on:** the JD's "own the member complaints process end to end"; the four values by name; hubs and digital from the brief; and, about you, F3's quote, "I handled the branch's formal complaints log and trained new tellers on our escalation script."

**Shape for 20 minutes:** 2 min clarifying questions → 3 min the member's immediate outcome → 5 min owner and fix → 4 min root cause and record → 4 min what changes (supervisor briefing, report, digital) → 2 min risks and summary.

| Thesis | Concession you must make | Values it shows |
|---|---|---|
| Fix the member's problem first, then the process | Resolving the case fast can hide a cause that affects many members, so the fix has to feed the log | Members First, Always; Own the Fix |
| One named owner from escalation to close, whichever channel the complaint came in through | A single owner can become a bottleneck, especially in branches going through consolidation | Own the Fix |
| Every escalation is data: categorise it, report it monthly, and pass journey failures to the digital team | Logging adds to supervisors' workload; keep it light or it won't get done | Plain Words; Neighbours, Not Numbers |

**Standing out from the consensus answer:** most candidates will say "apologise, resolve, follow up". You add who owns the complaint across channels and what the monthly report learns from it.

**Answers to avoid:** don't promise the member an outcome before checking policy and whatever regulatory rules apply. Answer slot from F2: if you know which rules applied in your branch's log, use that knowledge; if not, say you would check. And don't make "use the app" the fix for a member whose complaint is about the app.

### Reverse questions — Round 3

| Question | Why it lands |
|---|---|
| "What would a new person in this role do in their first month that would actually help your branches?" | A reciprocity question for the people you'd be working alongside |
| "Where do escalations from your branches get stuck today?" | Asks them for the real problem, the one they live with |
| "How are your teams preparing members for the hub changes?" | Shows you know about consolidation and care how it affects them |
| "Which of the four values is hardest to keep during a busy week?" | Turns the values scoring into a conversation, and the answer tells you something real |
| "What would you want the monthly complaints report to tell you that it doesn't now?" | Treats them as people who use your report, not just as interviewers |

---

## Sources

**Provided documents:** the JD; the values text you copied on 12 November 2026 from ashgrovecu.org/about/values (pasted, not fetched); the recruiter's email; your summary of the July 2026 strategy brief; your background in your message.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted, copied this morning, already fixes the cheat sheet and the J bank |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email establishes all three rounds, including the values scoring and the case, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief, under six months old, already supplies priorities and the competitive frame for the CO and CASE questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names assigned yet, so there's nothing to search; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for each round, persona weights from their public professional background, and reverse questions tied to their career path
- **Your CV** → more of your own sentences to quote, so more scaffolds (C2, C4, J1, J3) can become stories built on your real experience
- **Your answers to the slots, told to me outside a drill** → F2, F5, F7 and F9 regraded, and G1, A3, A4 and E2 rebuilt on what you actually did
- **Whether you have presented at regional level** → F8's plan can draw on it, if you say so
- **A copy of the spreadsheet's structure, with no member data** → F5 and F9 move from medium to high confidence, since it's the one thing in your field an interviewer could actually look at
- **How much prep time you have** → a prioritised prep schedule
- **The full strategy brief text** → the grounding brief gains Ashgrove's own wording and figures
- **A deeper research pass**, up to 6 more searches and 2 more fetches, several more minutes → news since July, any published candidate reports on Ashgrove's loop, and recent organisational changes. Say if you want it
- **A tuesday-dossier.md from job-underwriter** → verified evidence and a prohibited-claims list from that review, and an evidence-based highest-ROI objection instead of one this pack inferred
