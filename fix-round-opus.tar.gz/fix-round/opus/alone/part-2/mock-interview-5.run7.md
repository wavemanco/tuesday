Quick update: I've read the prep method and am now running a few targeted searches on Kelverton Rail and the panel before I build your pack.
I've built your prep pack for Tuesday: **/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-5-denied-9b560e7b/kelverton-rail_senior-partnerships-manager_interview_pack.md**

It has no web research behind it: the searches were refused because search permission wasn't granted. It's built only from your message and the recruiter's email. I also haven't seen the market report, so the Kelverton-specific parts of the POV are spaces for you to fill from your copy.

- **The POV (section 3):** a 15-minute outline, three theses to pick two from, and one thing to say you wouldn't do. Each thesis comes with the downside you should admit out loud. It ends on what operators get, as the recruiter asked. The strategy team who wrote the report work for the panel, so the advice is to agree with one point from it, then spend most of your time on one you'd weigh differently. Don't recite it.
- **Most important question to rehearse:** B1, "You've never carried a direct quota. How do we know you can deliver commercially?" Ross is the likely one to ask it. Say the limit before he presses, and keep "influenced" attached to the £4M every time.
- **Prep plan (section 2):** your four hours, split into seven blocks. The POV comes first, then B1, then Ross's numbers.
- **One thing to get right:** your 9 years is 4 at payments plus the 5 in consulting before that. Don't let it be heard as 14 years.

I can play Ross and run B1 with live follow-ups.
I can also save a tuesday-dossier.md of the gaps this prep turned up, for future sessions.
I can convert the pack to a Word document if that's easier to work from.

Can you paste the job description? It's the input that would change the pack most: most of the requirement rows are my guesses for this kind of role until I see it.

If you allow web searches, do you also want a deeper research pass (up to 6 more searches and 2 more page reads, several more minutes) on Kelverton's strategy, competitors and the panel's backgrounds?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, 60-minute panel. A 15-minute POV with no slides, then Q&A.
**Panel:** Deepa, VP Partnerships (your future manager), and Ross, Commercial Director ("Ross will push on commercials").
**Built from:** your message and the recruiter's email as you quoted it. No JD, no CV file. The market report is not in this pack because I haven't seen it. Web research was attempted but the searches were refused, so nothing here comes from the web.

---

## 1. How to use this pack

- **Personas** describe *how* a question gets asked (who is asking and in what style). **Types** describe *what* is being scored.
- **Type key:**
  - **VAL**: whether your past behaviour shows the company's values.
  - **EXP**: whether your stated experience holds up under questioning, and what was actually yours.
  - **JD**: whether you can do the job as stated, gaps included.
  - **CO**: whether you know the company's strategy and market.
  - **CASE**: a live problem from the role, reasoned out loud.
- **Provenance labels:**
  - `[grounded]`: traceable to your message or the recruiter's email.
  - `[inferred]`: derived from those, with the derivation named.
  - `[generic]`: a role-family pattern that makes no claim about Kelverton.
- **Answer slots** are places where only you know the answer. Each one gives two honest branches. Fill them in your own words. Don't let the pack fill them for you.
- The guidance is scaffolding, not a script.
- Question IDs go by persona: A, B, C, D, E, G, H. There's no bank F, so bank IDs don't collide with the fit-snapshot rows F1 to F8.

---

## 2. Prep triage: your four hours

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV. Pick 2 of the 3 theses, fill the report slots from your copy, choose your anti-pick, and say it out loud twice against a timer. Aim for 13 minutes so you have 2 minutes of slack | Section 3 |
| 2 | 45 min | The highest-ROI question, B1, then D1 and D3. Say each answer aloud until the concession wording feels boring | Bank B, Bank D |
| 3 | 40 min | Ross's numbers. Fill the C1 to C3 slots in your own words (how the £4M was counted, and what part was yours). Then C4 and D2 on partner economics | Bank C, Bank D |
| 4 | 30 min | Deepa's cases, A1 to A5 | Bank A |
| 5 | 20 min | The 90-second journey (E1), plus B2 and B3 | Banks E, B |
| 6 | 15 min | Choose 3 reverse questions: one for Deepa, one for Ross, one for both | Section 8 |
| 7 | 15 min | One full timed 15-minute run-through on Sunday evening, without notes | Section 3 |

Everything else in this pack is insurance.

---

## 3. Graded deliverable: the 15-minute POV

**The brief, in the recruiter's words:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

### What you're building on

| Fact | Source | Provenance |
|---|---|---|
| UK rail-tech, ~600 staff, sells scheduling software to train operating companies | Your message | [grounded] |
| The audience is the VP who owns partnerships today, plus the Commercial Director | Recruiter's email | [grounded] |
| The report was circulated internally by Kelverton's own strategy team | Your message | [grounded] |
| F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Fit snapshot F1 | [grounded] |
| F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Fit snapshot F2 | [grounded] |
| F8: "the market report their strategy team circulated internally last quarter, which I've read" | Fit snapshot F8 | [grounded] |

**The differentiation problem.** Kelverton's own strategy team wrote the report, so the panel has read it too. If you recite it, it scores as homework. If you depart from it with reasons, it scores as judgment.

Use exactly **one consensus point** from the report to show you're grounded in it. Then spend most of your time on **one divergence**: a conclusion you'd weight differently, said respectfully, because someone in the room may have written it.

### A 15-minute shape

| Minutes | Beat |
|---|---|
| 0–2 | Frame. Say where you're coming from, in F1's and F2's own words, then state your one-sentence thesis |
| 2–4 | The consensus point from the report, and why you agree with it |
| 4–11 | Your 2 chosen theses from the table below, each with its concession said out loud |
| 11–12 | The anti-pick: what you would *not* do in 18 months |
| 12–14 | What it means for operators. This is the requested close |
| 14–15 | What you'd want to learn in the first 90 days to test all of this. It hands the Q&A to you |

### Thesis options (pick two)

| # | Thesis | Mandatory concession | What to fill from the report | Provenance |
|---|---|---|---|---|
| T1 | **Partnerships should reduce work for operators, not add vendors.** Prioritise partners whose products have to connect to scheduling anyway (rostering, crew, passenger information, asset or maintenance systems), so each partnership removes an integration project an operator would otherwise run itself | Operator buying cycles in a regulated sector can outrun 18 months. Say plainly that month 18 may show signed integrations and pipeline rather than booked revenue | Which adjacent systems the report says operators run, or struggle to connect | [generic] |
| T2 | **Depth over count.** Commit to a small number of deep partnerships with joint roadmaps and named operator outcomes, instead of maximising the partner count | Fewer partners means slower coverage, and some operators will want a partner you didn't prioritise. Name how you'd handle requests that fall outside the tier | Whether the report describes a concentrated or fragmented buyer base. This thesis only stands if it's concentrated, so check before you choose it | [generic] |
| T3 | **Measure partnerships in operator terms.** Agree success metrics with operators up front, such as time to go live or fewer manual schedule changes, so that each partnership earns its renewal in the customer's own language | Some of the metrics operators care about are outside Kelverton's or the partner's control. Admit that some of those numbers won't move however good the partnership is | Any operator outcomes or pain points the report names | [generic] |

**Your own experience in the theses.** F1's quote is the only past you bring into them: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40."

Answer slot: if the channel taught you something about breadth versus depth, say what, in your own words. If it didn't, say so plainly, and present T2 as a choice you'd make here rather than a lesson from there.

**The anti-pick.** Name one thing you'd decline to do in the first 18 months, for example a reseller programme or signing partners for logo count. Give the reason in one sentence.

Answer slot: choose the anti-pick you actually believe. If the report argues for the thing you'd decline, say you've read that argument, then give your reason.

**Ross's minute on economics** (fold it into T1 or T2). For each partner type, name the commercial model you'd use: referral fee, resale margin, co-sell with no fee, or technical integration with a joint roadmap and no money changing hands. State which one you'd default to and why. Ross will push here, so have one sentence ready on what partners cost Kelverton in margin or effort, and what Kelverton gets back. `[generic]`

### The close: what it means for operators

| What operators would get | Provenance |
|---|---|
| Fewer integration projects of their own, because partners arrive already connected to scheduling | [generic] |
| One accountable answer when something across two systems breaks | [generic] |
| Partnerships judged on the operator's own metrics, so they can tell at renewal whether it worked | [generic] |

These are hypotheses about what operators value. Say them as hypotheses ("what I'd expect operators to want, and what I'd test first"), not as findings.

Your link to operators is F2's own words: "I spent five years in transport consulting on bus and light rail network planning."

Answer slot: if that work put you alongside operators' own teams, say in your own words what you saw them need. If it didn't, say so plainly, and present the close as what you'd go and test with operators in the first 90 days.

---

## 4. Fit snapshot

No JD was supplied. The `[grounded]` requirements are the recruiter's own words. The `[generic]` ones are role-family patterns for this title and raise no answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material shows a payments ISV channel, not rail operator partnerships, and the words stay at that scope: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the 18-month framing makes a probe on how that growth was planned likely. If you set the plan for that channel, say how, in your own words. If there was no such plan, or it wasn't yours to set, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Bus and light rail network planning, from the consulting side, is next to the train operators Kelverton sells to, but it isn't the same thing. Words: "I spent five years in transport consulting on bus and light rail network planning." "From the other side" is your phrase, so use it the way you meant it. The pack doesn't know which side that was and won't guess. Answer slot: if that work put you alongside operators' own teams, say what you saw them need, in your own words. If it didn't, say so plainly and stay with the network-planning work |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure touches commercials, but the material doesn't show how it was counted or what part of it was yours. Answer slots, in your own words: how the £4M was counted; what it's sensitive to; the assumption behind it you'd defend least; and which part was yours. "I don't know exactly how it was counted" is an honest answer if it's true. Keep "roughly" and "influenced" attached to the number every time you say it |
| F4 | Carrying a direct revenue target. This is a role-family pattern; whether this role carries one isn't established | "never carried a direct quota, only influenced revenue" — your message | none | [generic] | capability | You've stated this gap, so the pack can give your words back: "I haven't carried a direct quota; my number has been influenced revenue." Then say how you would take one on, as a plan and never as a past. Add nothing that makes the gap sound smaller |
| F5 | Commercial experience selling to train operating companies. A role-family pattern for this seat | "Never sold into rail specifically" — your message | none | [generic] | capability | Words: "I haven't sold into rail." F2 is the adjacent bridge. Don't let F2 be heard as rail sales |
| F6 | Recruiting and scaling a partner base. A role-family pattern | "took it from 6 partners to 40" — your message | medium | [generic] | none | No gap, but this figure has nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you took it from 6 to 40. Answer slot (the figure raises it): which part of that growth was yours, in your own words |
| F7 | Seniority in partnerships, implied by a Senior title. A role-family pattern | "9 years in partnerships" — your message | medium | [generic] | none | No gap. One caution: your message gives 4 years at payments plus 5 years in consulting before that, which adds up to 9. Say the total the way it's true. Don't stack the 9 on top of the 5 |
| F8 | Company and market fluency for the POV. A role-family pattern | "the market report their strategy team circulated internally last quarter, which I've read" — your message | medium | [grounded] | none | No gap in your preparation. The pack hasn't seen the report, so every Kelverton-specific point in section 3 is a slot for you to fill from it |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 POV on operator partnerships | Section 3, A1, A2, D2 |
| F2 What it means for operators | Section 3 close, A3, A4, B2 |
| F3 Commercials | B1, C1, C3, D3 |
| F4 Direct revenue target | B1, B4, C4 |
| F5 Rail commercial experience | B2, B4, D1 |
| F6 Scaling a partner base | C2, C3 |
| F7 Seniority | E1 |
| F8 Company and market fluency | A5, E2 |

---

## 5. Reading the panel

The recruiter's email is the only source here. No search ran, so nothing below covers career history or public writing.

| Panellist | What's established | Implication for you | Source |
|---|---|---|---|
| Deepa | VP Partnerships, your future manager | Your POV is about the area she runs today. Present it as building on what exists, and ask what's already been tried (reverse question 1) instead of implying a blank slate | Recruiter's email |
| Deepa | She'll be deciding whether to hand you the plan | Expect Case/Strategist and Skeptic questions: can you do the job, and where are you thin | Recruiter's email |
| Ross | Commercial Director, "will push on commercials" | Expect the Prober and Pressure personas: your £4M, partner economics, quota. Banks C and D are mostly his | Recruiter's email |
| Both | "Please land on what it means for the operators themselves" | The close of your POV is explicitly being scored. Don't let time pressure cut it | Recruiter's email |

---

## 6. Persona table

The weights come from a panel blend. Deepa's relationship (hiring manager) gives Case/Strategist and Skeptic. Ross's stated focus (commercials) gives Prober and Pressure.

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa extends your POV: first 90 days, partner selection, operator objections | High. She's the hiring manager and the POV invites follow-ups | Clarify, then state the objective, segment, give your approach, name the metric and the risk. Use the operator's vocabulary |
| Skeptic | No quota, no rail sales, why move | High. Both gaps are in your own message, and a hiring manager is there to reduce risk | Rehearse B1 until it's boring. Bridge only from F2 and F3 at their own scope |
| Data-Driven Prober | Ross takes apart the £4M and the 6 to 40 | High. He's been flagged for commercials, and those are your only figures | Know what you can and can't say about how each figure was counted, and say plainly where you don't know |
| Pressure | Ross challenges the partner model, or asks why you over a rail seller | Medium. "Push on" suggests challenge, but not hostility | Pause, restate the question, hold for two follow-ups, then concede something specific |
| Conversational | The opener, or reactions to the report | Medium-low. The POV replaces most small talk | Use a 90-second arc built only from your quotes |
| Peer Evaluator | Ross on the seam between partnerships and direct sales | Low-medium. He isn't a peer, but he owns the commercial side your partners will touch | Propose seam principles, not knowledge of their current seam |
| Values / Behavioural | One "tell me about a time" question | Low. No values round is documented and Kelverton's values weren't available | Use the selection scaffolds in bank H |

---

## 7. Question banks

### A. Case / Strategist (mostly Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Of everything in your POV, what would you actually do in the first 90 days?" | CASE | [generic] | Three moves, in order. First, listen: meet operators and the existing partners. Second, pick: tier the current and prospective partners against a stated set of criteria. Third, prove: one partnership pushed to a measurable operator outcome. End with what you'd show Deepa at day 90. The question needs no claim about your past, so the guidance makes none | The natural follow-up to any 18-month POV, and the test of whether it's actionable. CASE because it's a live plan |
| A2 | "How would you decide which partners to go after first?" | CASE | [generic] | State your criteria out loud: operator pull (are operators asking for it), integration depth with scheduling, the partner's own route to operators, and how much effort each side has to put in. Then rank one or two example partner categories from your POV. Admit that the weighting is a judgement you'd test with Deepa | Tests structure behind T1 and T2. CASE because there's no single right answer |
| A3 | "An operator tells us they don't want a third party anywhere near their scheduling data. What do you do?" | CASE | [generic] | Clarify first: is it data protection, a contract, or trust? Then options: a partner that works without seeing scheduling data, contract terms, or respecting the no. Close on whether the operator's no should change the partner plan | Tests whether your operator focus survives real resistance. It's drawn from the recruiter's operator close |
| A4 | "What does a good partnership look like from the operator's side, 18 months in?" | CASE | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Give the operator outcomes from your close, as hypotheses. Your link is the quote at its own scope: five years on bus and light rail network planning. Answer slot: if that work showed you what operators need from suppliers, say what, in your own words. If it didn't, say so plainly and say how you'd find out | F2 is your adjacent operator evidence. CASE delivery on the recruiter's stated close |
| A5 | "Is there anything in our market report you'd push back on?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Use your POV's divergence: one conclusion, why you'd weight it differently, and what evidence would change your mind. Say it with respect, because a panellist may have written it. Answer slot: pick the point from your own reading. If you don't disagree with anything, say so plainly, and name the conclusion you'd most want to test | F8. Their own strategy team wrote it, so reciting it isn't enough. CO because it scores market judgement |

### B. Skeptic (Deepa, or Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. How do we know you can deliver commercially?" | JD | [grounded] "never carried a direct quota, only influenced revenue" "roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Say the limit before they press: "I haven't carried a direct quota; my number has been influenced revenue, roughly £4M of it." Hold on exactly that, and don't upgrade "influenced" to anything stronger. Answer slot: if part of that £4M was tracked against you or reported as yours, say how, in your own words. If none was, say so plainly. Then give a plan, said as a plan: what you'd want to be measured on here, and how quickly you'd accept a number. Hold through two follow-ups by coming back to the quote, never by adding to it. Concede specifically: "carrying a number myself would be new to me" | F3 and F4 together are the gap a Commercial Director is most likely to press, and you stated both. JD because it scores the commercial requirement |
| B2 | "You haven't sold into rail. Why would operators take you seriously?" | JD | [grounded] "Never sold into rail specifically" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Open with "I haven't sold into rail." Then give F2's scope: five years of bus and light rail network planning in consulting. Don't stretch it into rail selling or rail operators. Answer slot: if that work gave you something operators recognise, such as their vocabulary or their planning constraints, say what, in your own words. If it didn't, say so plainly and stay with the quote. Close on how you'd earn credibility in the first months: listening, and bringing partners that save the operator work | F5 is a stated gap. F2 is the adjacent bridge, and it's the one most at risk of being stretched |
| B3 | "Why leave payments for rail, and why now?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The two chapters are your context, in their own words: the payments ISV channel, and transport consulting before it. Answer slot: your reason for this move is yours, and the pack has none from you. Say it in your own words. If it's partly practical, say that plainly. A credible "why now" is one sentence long | Motivation consistency is the Skeptic's core test, and your history spans two sectors. EXP because it's checked against your record |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one of the two gaps you've stated, the one you'd rather discuss, and name it plainly in the quote's terms. Then give the ramp: what you'd do in the first 60 days to close it. Don't pick a fake weakness | The gaps are already in the room. Choosing one yourself shows calibrated self-assessment |

### C. Data-Driven Prober (mostly Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Lead with the quote: roughly £4M, influenced. Answer slots, each in your own words: how it was counted, what it's sensitive to, and which part was yours. Name the assumption you'd defend least before Ross finds it. If you don't know exactly how it was counted, say so plainly and say what you do know. Never supply a method you didn't use | F3. The only revenue figure you have, in front of a Commercial Director. EXP because it tests the claim itself |
| C2 | "Of the move from 6 partners to 40, how much was you?" | EXP | [grounded] "took it from 6 partners to 40" | "Took it" is your verb, so keep it. Answer slot: which part of the growth was yours (sourcing, signing, onboarding, or something else), in your own words. If some of it came through others or inbound, say so plainly. Use "we" for the team and "I" for your part | F6. The Pressure persona's attribution question, asked as a probe |
| C3 | "Was that £4M spread across the 40 partners, or concentrated in a few?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | This is the "what is it sensitive to" slot. If you know the split, give it. If you don't, say so plainly. Don't estimate a split you can't stand behind. If it was concentrated, say so, because that answer supports T2 | F3 and F6 together. The denominator question a prober asks |
| C4 | "If we gave you a number for year one, what would you want it measured on, and why?" | CASE | [generic] | Propose a short scorecard: partner-sourced or partner-influenced pipeline, operator go-lives through partners, and one operator-outcome metric. Say which you'd accept as a hard target and which as a lead indicator. No claim about your past is needed | F4's forward-looking form. It turns the quota gap into a design conversation |

### D. Pressure (mostly Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's already sold to operators?" | JD | [grounded] "Never sold into rail specifically" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause, then three beats inside 60 seconds. Concede: you haven't sold into rail. State what you do bring, in the quote's words: a channel taken from 6 partners to 40, roughly £4M influenced. Then give your POV's operator-first thesis in one line. Hold if pushed; don't attack the hypothetical rival | F5 under time pressure. Pressure because the clock is the test |
| D2 | "Partners take margin and add complexity. Why shouldn't we just sell direct to operators?" | CASE | [generic] | Hold your thesis: partners earn their place where they remove work for the operator or open a door direct sales can't. Concede where direct is better, such as core scheduling deals Kelverton can win alone. Hold through two pushes, then concede something specific ("for X, you're right, direct wins") without dropping the core | Tests whether your POV survives the Commercial Director's natural objection. CASE content, Pressure delivery |
| D3 | "Your influenced revenue — how much of that would have closed anyway?" | EXP | [grounded] "roughly £4M of influenced revenue" | Don't get defensive, because this is a fair question about any influenced figure. Answer slot: if there was a way of separating influenced from would-have-closed, describe it in your own words. If there wasn't, say so plainly ("I can't prove how much would have closed anyway"), then go back to the quote as stated. Hold the "influenced" label. Don't retreat from it, and don't inflate it | F3's weakest point, raised by the figure itself. Hold-then-concede is the rehearsal |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | 90 seconds, in order: transport consulting on bus and light rail network planning, then four years running the ISV channel at a payments company, 6 partners to 40, roughly £4M influenced, then why Kelverton (B3's slot, in your words). Give the total years the way it's true (see F7) | The opener is still scored. A pre-built arc stops it eating POV time |
| E2 | "What did you make of the market report?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Casual tone, but it's scored. One line on what you agreed with, one on what you'd test (from A5). Answer slot: both points come from your own reading | F8. A casual question about the brief is a preparation check |

### G. Peer Evaluator (Ross on the commercial seam)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When a partner and our direct sales team both claim the same deal, how do you settle it?" | CASE | [generic] | Propose principles, not knowledge of their current rules: agree attribution rules before the deal, give one owner per account, and be transparent with the partner. Ask how credit works today (reverse question 3) | The seam between partnerships and commercial is Ross's turf |
| G2 | "What would you need from the commercial team in your first three months?" | CASE | [generic] | Reciprocity first. Say what you'd bring the commercial team (partner-sourced intros, integrations that unblock deals), then what you'd need: account context, and a shared view of pipeline | Shows that you'd lighten the commercial team's load, not add to it |

### H. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, a moment you didn't fold, and a relationship still intact at the end, ideally from the channel or consulting years. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing you can stand behind, or how you would handle it | A common behavioural question, and Kelverton's own values weren't available to theme it |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a time when a partner's or client's interest cost you a number, with the trade-off you made and what happened. If no such time comes to mind, say so plainly, then give the nearest thing you can stand behind, or how you would handle it | It fits the operator-first close the recruiter asked for |

---

## 8. Reverse questions

| # | Question | For | Why it lands |
|---|---|---|---|
| 1 | "What has the operator partnerships motion tried in the last couple of years that you wouldn't repeat?" | Deepa | It respects that she owns the area today, and it shows your POV was built to add to that work, not replace it |
| 2 | "Six months in, what would make you say this hire was the right call?" | Deepa | It gets her scorecard into the open from your future manager |
| 3 | "How does commercial credit work today when a partner touches a deal, and is that something you'd want changed?" | Ross | It goes straight to the seam he cares about and shows you think in economics |
| 4 | "Would this role carry a number, and if so, what kind?" | Ross | It addresses F4 head-on, on your terms. That reads as confidence, not avoidance |
| 5 | "Which operator would you most want a partnership story with in 18 months, and what's stopped it so far?" | Both | It keeps the operator close going into Q&A and gets you real context on the market |
| 6 | "Which conclusion in the market report is the team still debating?" | Both | It shows you read the report closely, and it invites them to share inside context |

---

## 9. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or to train operating companies | A negative you stated (F5) | "I haven't sold into rail." No slot |
| Has carried or hit a direct quota | A negative you stated (F4) | "I haven't carried a direct quota; my number has been influenced revenue." No slot |
| £4M of revenue, closed revenue, or booked revenue | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The pack's observation: the material says influenced, not closed or booked |
| Knows train operating companies from the inside, or has worked with rail operators | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning, in consulting. The pack's observation: the material says bus and light rail, not train operating companies |
| Personally signed every partner in the 6 to 40 growth | Inflated form of F6 | F6's quote: "took it from 6 partners to 40". C2's slot covers which part was yours |
| 14 years of experience | Inflated form of F7 | Your message gives 4 years plus 5 years before that. Say the total the way it's true |

---

## 10. Sources

- **Your message**, including the recruiter's email as you quoted it.
- **Not seen by this pack:** the attached market report. You've read it. Its contents aren't here, so every Kelverton-specific thesis is a slot for you to fill.
- **Searches sent**, all refused because search permission wasn't granted:
  - `Kelverton Rail values`: refused
  - `Kelverton Rail scheduling software train operating companies news`: refused
  - `Senior Partnerships Manager rail software job description UK`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have themed bank H with Kelverton's own values by name |
| 2. `Kelverton Rail interview process partnerships` | skipped | The recruiter's email already sets this session: the panel, 60 minutes, POV then Q&A |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The search was refused. It would have grounded the CO questions and the POV theses in Kelverton's current moves. The market report would cover this, but its contents aren't in hand |
| 4. `Deepa` / `Ross` `Kelverton Rail` | unavailable | No search was sent because search permission wasn't granted. It would have added career pattern to section 5 and a reverse question tied to each panellist's path |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | The search was refused. It would have turned the `[generic]` rows F4 to F7 into `[inferred]` ones |

---

## Upgrade menu

- **Headline findings from the market report, pasted:** the T1 to T3 slots become theses grounded in it, A5 and E2 get real content, and the POV's divergence can be pressure-tested.
- **The JD text:** rows F4 to F7 become `[grounded]` requirements, every mid-list requirement gets a JD question, and any gates (location, travel, right to work) get surfaced.
- **Search permission:** Kelverton's published values for bank H, a current-news sweep for the CO questions, and Deepa's and Ross's public career paths for section 5.
- **A deeper research pass, on top of that:** strategy, competitors and recent org changes for the POV's differentiation.
- **Your own answers to the slots in F1, F2, F3 and C2:** those rows become story-mapped answers instead of slots.
- **A tuesday-dossier.md, if you have one:** a verified evidence map and an explicit list of claims to stay away from. Useful, never required.
