Research is back: values, the loop format (the "Outage Hour"), Project Larkspur, and Tobias's GDC talk. Next I'm fetching the values and interviewing pages so the pack quotes them directly.
I've built your prep pack: saltmarsh-games_live-operations-producer_interview_pack.md

Friday is tomorrow, so I sized it for one evening of prep. Saltmarsh's careers page describes this exact interview, and two findings shape most of the pack:

- **The format.** Saltmarsh calls it the "Outage Hour." In 60 minutes Tobias runs a tabletop exercise where a live event has a simulated outage, then a values conversation. There's no take-home. Banks A and B are built for those two halves.
- **The biggest risk.** In September Saltmarsh announced Project Larkspur. From February 2027 both titles move to a season pass on one shared events calendar. That makes your "never worked on a game with in-app purchases" the objection most likely to come up. Question C1 is the most valuable thing to rehearse tonight.

The pack also has your evidence mapped against each line of the JD, a short read on Tobias from his GDC talk, Saltmarsh's three values with what you can say for each, reverse questions, and the claims the pack won't coach you to make.

If you want, I'll play the Skeptic on C1 with live follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep turned up, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Saltmarsh's interviewing page describes this interview as the hiring-manager round (see Sources, target 2).
**Format:** 60 minutes, Friday. Saltmarsh calls it the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home.

---

## How to use this pack

- **Personas** describe how a question is asked: who is asking, and in what register.
- **Types** describe what is being scored:
  - **VAL**: whether your past behaviour shows Saltmarsh's *published* values
  - **EXP**: whether what you say about your work holds up, and what was actually yours
  - **JD**: whether you can do the job as the posting lists it, gaps included
  - **CO**: whether you know the company's current direction (here, Project Larkspur)
  - **CASE**: a live problem from the role, worked out loud
- **Provenance labels:** `[grounded]` means it traces to something you told me or something the research found; `[inferred]` is this pack's own derivation, with the source named; `[generic]` is a role-family pattern that makes no claim about you or about Saltmarsh.
- **The guidance is scaffolding, not a script.** Every suggested wording in this pack is pending your approval. Say it in your own words, and cut anything you can't back up.
- Question IDs go by persona: A, B, C, D, E, G, H. The letter F is kept for fit-snapshot rows.

---

## Prep triage: one evening

Friday is tomorrow, so this plan assumes one evening plus a short warm-up on the day.

1. **C1 out loud, three times.** This is the season-pass and in-app-purchase question, and it is the highest-ROI prep in this pack. Time it, and practise the two follow-ups. (30 min)
2. **A1–A3, the tabletop.** Practise the incident structure out loud on A1 until you can run it without notes, then do A2 and A3 quickly. Half of the hour will be this. (40 min)
3. **Learn the three values by name, then do B3.** Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener. B3 is the one value your material maps to directly. Then pick your stories, or your honest branches, for B1 and B2. (25 min)
4. **D1.** Know what you can and can't say about the retention numbers you presented. (10 min)
5. **Pick two reverse questions,** one of them R1 or R2. (5 min)
6. **Friday morning:** H1's 90-second arc and C1, once each.

Everything else is insurance.

---

## Fit snapshot

*Proposed wording in the last column is pending your approval.*

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | The years are there, and the content-drop calendar shows live content. Words: "Four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Keep the title as "associate producer". The title is part of the claim |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes one title's weekly content-drop calendar. It does not describe live events across two titles, and your words should stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title line makes a probe on handling more than one schedule likely. If the calendar you ran ever had to fit around another title's or another team's dates, say how, in your own words. If it didn't, say so plainly and stay with the one calendar you ran |
| F3 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap: the quote says it in almost the JD's own words. Expect a probe, because nothing has been inspected behind it. Lead with the beats the sentence states: the calendar, weekly, your main title, two years |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Running a calendar touches coordination, but your material doesn't show which teams you worked with or how. Answer slot: the JD names four teams, so expect a probe on who you had to get things from. If you worked with any of those teams to land a drop, name which ones and what you did, in your own words. If you didn't, say so plainly and say how you would set it up here |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting numbers is not owning a review, so keep the words at presenting: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe on reviews likely. If you ran or contributed to a review after a content drop, say what it covered and which part was yours. If there was no such review, or it wasn't yours, say so plainly and say what you would put in one |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist isn't the same as managing it from one release to the next, so keep the words at writing: "I wrote the release checklist our QA team still uses." Answer slot: if you kept it updated after you wrote it, say how. If you didn't, or someone else maintains it, say so plainly and stay with having written it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap. Lead with the quote. Answer slot: the JD's retention line makes "which numbers were they?" likely. Say which retention numbers they were and whether you compiled them, in your own words. If someone else produced them and you presented them, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The checklist is written work, so it reaches this requirement in other terms. Words: "I wrote the release checklist our QA team still uses." Describe the checklist and let the interviewer draw the conclusion about your writing. Don't call it proof of anything |
| F9 | Project Larkspur: both titles move to a season-pass model with one shared events calendar from February 2027. Source: Saltmarsh news page, not the JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I haven't worked on a game with in-app purchases." Then say how you would learn the season-pass side, as a plan and never as past experience. Add nothing to make the gap look smaller |

---

## Reading the interviewer

Public professional footprint only, from one search result. The talk itself was not fetched.

| Fact | Provenance |
|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | [grounded] GDC 2026 talk listing, Sources target 4 |
| Gave a GDC 2026 talk called *Patch Notes Are a Promise*. Its argument: a live team is judged by how often its patch notes describe what actually shipped | [grounded] same listing |

**What this implies for Friday** `[inferred]`, from the two rows above and Saltmarsh's values page:

- **Accuracy matters more than polish.** His talk and the value Ship the Patch Not the Promise make the same point. An answer that overstates what you did is exactly what he is primed to notice, so being precise is the strategy, not a constraint on it.
- **Checklists and QA are his home ground.** Expect a sharp follow-up on anything you say about the release checklist (B3, E2, G1). Describe it plainly and don't oversell it.
- **Mirror opportunity, vocabulary only.** Your F6 evidence, "Wrote the release checklist our QA team still uses.", is in his language. There is no shared career jump to offer, because nothing in your material shows a move like his from QA into live ops.

---

## Persona weights

The loop is established by Saltmarsh's interviewing page (Sources, target 2): one session with the hiring manager, made up of a tabletop and a values conversation. The weights below follow those named parts rather than a generic archetype.

| Persona | How it shows up on Friday | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The tabletop: a simulated outage mid-event, played forward | **Highest.** The interviewing page names it as the first half of the hour, and hiring-manager rounds lean toward case work | Clarify, set the objective, triage, decide, communicate, review. Think aloud and challenge one premise per case |
| B. Values / Behavioral | The second half: one question per published value | **High.** The interviewing page names a values conversation, and the values page publishes three values | Where one of your quotes carries a story, use it. Where none does, use the scaffold and its honest branch |
| C. Skeptic | Gap probes: season pass and in-app purchases, one title versus two | **Mid.** The prior for a hiring manager. Larkspur makes F9 visible to him | Rehearse C1 until it feels boring. Hold on what you did, concede what you didn't, then give the plan |
| D. Data-Driven Prober | Follow-ups on retention numbers and how you judge a drop | **Mid.** The JD names retention metrics and KPIs, and his talk is about checking claims against what shipped | Know what you can and can't say about the numbers you presented |
| E. Pressure | The tabletop clock, and "how much was actually you?" | **Low–mid.** A live-incident format is time-boxed by nature | Pause, restate the question, anchor on your quote, hold through two follow-ups |
| G. Peer Evaluator | Seams between design, QA and community inside the incident | **Low.** He is not a peer, but the JD's coordination line will arrive in collegial form | Propose a principle for the seam instead of pretending to know it |
| H. Conversational | The opener and the warm-down | **Low.** Short in a 60-minute two-part format, but still scored | A 90-second arc, and never say "you've covered everything" at the end |

---

## Question banks

*Proposed answer wording in every bank is pending your approval.*

### A. Case / Strategist: the tabletop (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Hour two of a weekend live event. Players on one title say the event won't load. Walk me through your first fifteen minutes." | CASE | [generic] | Structure it out loud. Clarify first: which title, how many players, since when, and whether anything was released. State the objective: protect the players and the event. Assign owners: engineering on the fault, QA reproducing it, community on a holding message. Decide what players hear now and what they hear later. Set the next check-in time and say it. The question asks nothing about your past, so the guidance makes no claim about it | The interviewing page names a live-incident tabletop as the first half, so a question of this shape is close to certain. CASE because it scores structure in real time. Generic because the scenario is a pattern, not Saltmarsh's actual exercise |
| A2 | "Engineering says the fix needs a client update that won't land before the event ends in 36 hours. Extend the event, compensate players, or leave it?" | CASE | [grounded] | Lay out the three options, then your decision rule: what players lose under each, what each costs the calendar, and who has to agree. Use the published value as your stated criterion: "when the calendar and the players disagree, the players win." Then name the cost you are choosing to accept. Pick an option. Don't hedge across all three | The tabletop will push past diagnosis into a call. The value text comes from the fetched values page, which is why this row is grounded. CASE first, with a VAL thread because it applies Players Before Plans |
| A3 | "Players are asking on social what happened. Draft the first community post, out loud, now." | CASE | [grounded] | Four beats: what you know, what you don't know yet, what players should do, and when the next update will come. Promise only what is built. The value reads "we announce what is built, not what is hoped." So give no fix time you couldn't stand behind | Covers the JD's written-communication line inside the tabletop, and Tobias's talk is about exactly this gap between what is said and what ships. CASE delivery, JD content |
| A4 | "It's fixed and the event is over. What goes in the post-event review, and which KPIs does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | A plan, not a past: timeline, player impact, cause, what changes in the release checklist (Leave the Build Greener), and the numbers you would report, such as participation, retention around the event, and the cost of any compensation. If you draw on your own background, keep it at the quote: you presented the monthly retention numbers to the studio head. Answer slot: if you ran or contributed to a review after a drop, say which part was yours. If you didn't, say so plainly and stay with the plan | F5 is the JD line your material reaches least directly, and the tabletop naturally ends here. JD because "own the post-event review" is a stated duty |
| A5 | "From February, both titles share one events calendar. How would you plan the first month?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Clarify first: how much the two titles' players overlap, and which events tie to the season pass. Then give principles for collisions between the titles, a cadence, a dependency map across design, art, engineering and community, and one release checklist per drop. Say where you'd ask rather than guess, especially on how the season pass shapes events. If your background comes up, keep it at F9's words: "I haven't worked on a game with in-app purchases." | The Larkspur announcement (Sources, target 3) is the company's own stated direction for this role's calendar. CO because it tests whether you're current on Larkspur, delivered as a CASE |

### B. Values / Behavioral: the values conversation (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans. Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. Pick a time a planned drop or date changed, or should have changed, because of how players were responding. A good story needs four things: what the plan said, what players were telling you, what you did, and what it cost. If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years.", and say how you would handle that kind of disagreement | One question per published value is the core of this half. Your quote gives the setting but no event, so this is a scaffold, not a story map |
| B2 | "Ship the Patch Not the Promise. When have you held back an announcement because the thing wasn't built yet?" | VAL | [generic] | Selection scaffold. Pick a time something was about to be announced, to players or inside the studio, before it was ready. A good story needs what was at stake, what you said or did, and what happened. If no such time comes to mind, say so plainly, then say how you would decide what goes in an announcement | The second published value, and the theme of Tobias's talk. None of your quotes carries an event, so this is a scaffold only |
| B3 | "Leave the Build Greener. Walk me through the release checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story map on F6, using the two beats the sentence states: you wrote it, and QA still uses it. Describe what's in it in your own words. Answer slot: the value says every release leaves "the checklist better than it found them", so expect a probe on whether yours has changed since. If you revised it after a release, say what changed and why. If it hasn't changed, or someone else revises it, say so plainly and stay with having written it. Describe it; don't call it proof of anything | Your strongest direct match to a published value, aimed at an interviewer with a QA background. VAL first, EXP second, because he will probe how much of the checklist was yours |
| B4 | "Tell me about a time what players were told didn't match what shipped." | VAL | [generic] | Selection scaffold. It needs what was said, what shipped, how the gap was found, and what you did about it. If no such time comes to mind, say so plainly, then say how you would check patch notes against the build before release | The theme comes from the interviewer's own published talk, so it is a likely question. A scaffold because none of your quotes carries an event |

### C. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We're moving both titles to a season pass. What's your experience with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI rehearsal in this pack.** Beat 1, the acknowledgment, first and without padding: "I haven't worked on a game with in-app purchases." Beat 2, what you do bring, kept at its scope: "For the last two years I ran the weekly content-drop calendar for our main title." Beat 3, a plan said as a plan: what you'd learn first about how the pass and the events feed each other, which numbers the team watches, and who you'd learn it from. Name the limit before he does: the monetisation side would be new to you. Follow-up 1, "So you'd be learning on our live games?": hold on the calendar work, and concede plainly that the season-pass side is new. Follow-up 2, "Why not hire someone who's done it?": don't argue that in-app purchases don't matter, and don't apologise. Return to the calendar and the plan. Never hint at "similar" experience | F9 is the one gap you stated yourself, and Larkspur is the company's announced direction, so this objection will arrive in some form. JD first, CO second, because it scores the role as the company says it will become |
| C2 | "You've run one title's calendar. This is two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold on the quote at its scope: one calendar, weekly, main title, two years. Answer slot (F2): if your calendar ever had to fit around another title's or another team's dates, say how. If it didn't, say so plainly. Then the plan: what two titles add, such as audience overlap, competing events and shared teams, and how you would surface collisions early | F2 is the JD's headline duty measured against one-title evidence. Premised only on what your quote states |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick a real one. F9's acknowledgment is the honest candidate: "I haven't worked on a game with in-app purchases." Or choose the post-event review, but only if it's true that you haven't run one. Then give a one-month plan for closing it. Avoid a fake weakness, because this interviewer is primed for gaps between claim and reality | A standard Skeptic stem in a hiring-manager round. A rehearsed honest answer here also protects C1 |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story map on F7, using the beats the sentence states: monthly, retention, presented, to the studio head. Answer slot: say which numbers they were, who compiled them, and how they were counted, in your own words. If you don't know how they were counted, say so plainly. If you know the assumption behind them you'd defend least, name it before he asks | F7 is your evidence for the retention requirement, and this is where the Prober goes first. EXP because it tests what you actually did with the numbers |
| D2 | "A content drop goes out. Which number tells you first whether it worked, and what could fool you?" | JD | [generic] | Pick one number and say why. Then name what could mislead it, such as a seasonal dip, another change released at the same time, or a store feature. A plan, not a past | Covers the JD's KPI line as live reasoning. JD content, CASE delivery |
| D3 | "On the calendar you ran, how did you know whether a weekly drop had worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you checked how drops performed, say what you looked at and what you did with it, in your own words. If there was no such check, or it wasn't yours, say so plainly and say what you would look at here | Joins F3 to F5, and tests whether running the calendar included judging it. The slot allows that no such check existed |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone already on our live-ops team?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause, then three beats from the quotes: four years as an associate producer, two years running the weekly content-drop calendar, and the release checklist QA still uses. Don't run down an internal candidate you know nothing about. Finish inside sixty seconds | Time-boxed answers fit the outage format. JD because it compresses F1, F3 and F6 |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it." Answer slot: if others contributed sections or reviewed it, say who and what, in your own words. If you wrote it alone, say so. Hold through a second push by repeating the scope, and don't add claims to win the exchange | His QA background makes this the natural attribution probe. Hold-then-concede on F6 |

### G. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design wants a fix in Saturday's event. QA says the checklist isn't clear. What happens?" | CASE | [generic] | Give a principle, not a guess at Saltmarsh's process: the checklist decides what ships, and the producer's job is to turn the disagreement into options with costs (ship later, ship smaller, ship with a named risk and who signs it off). Then say who decides and how quickly | JD's QA line plus Leave the Build Greener, asked as a seam between teams. CASE because it is a live decision |
| G2 | "Community heard about a change after players did. How do you stop that happening twice?" | CASE | [generic] | A principle and a mechanism: community is on the release checklist, with a fixed point at which they see what's shipping. Say how you would check it worked next time | JD's community line. A seam question with no claim about your past |

### H. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made only of those four sentences, in order: the role, the calendar, the checklist, the retention numbers. Answer slot: give your own reason for wanting live ops at Saltmarsh, in your own words. Don't borrow one from this pack | The opener is scored too. EXP because every beat is a claim he can follow up on |
| H2 | "Which live event in a mobile game has caught your eye lately?" | CO | [generic] | Pick one you have actually played. Say what it did and one thing you would change. If you haven't played one recently, say so and talk about one event from your own calendar instead | A casual question on the JD's core topic, and still scored |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | C2, A5 |
| Coordinate design, art, engineering and community | A1, G1, G2 |
| Own the post-event review and its KPIs | A4, D2, D3 |
| Manage the release checklist with QA | B3, E2, G1 |
| 3+ years producing live-service games or apps | H1, E1 |
| Experience running a content calendar | C2, D3 |
| Comfortable with player-retention metrics | D1, D2 |
| Clear written communication | A3 |
| Larkspur season pass (research, not JD) | C1, A5 |

---

## Values cheat sheet

The three values come from saltmarshgames.com/values, fetched. *Proposed mappings are pending your approval.*

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and player response conflict, players win | Scaffold, B1. Setting from F2/F3: "I ran the weekly content-drop calendar for our main title for the last two years." No event is in your material, so use B1's honest branch if none comes to mind |
| Ship the Patch Not the Promise | Say only what's built, never what's hoped | Scaffold, B2, with its honest branch. None of your quotes carries an event |
| Leave the Build Greener | Each release improves the codebase and the checklist | F6: "Wrote the release checklist our QA team still uses." See B3 for the answer slot on revisions |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your GDC talk you argued a live team should be judged by how often its patch notes match what shipped. How does the team track that today?" | Shows you researched *him*, and it's his own theme |
| R2 | "You came to live ops from QA. What from QA do you still find missing in how live teams release?" | Ties to his career path, and to your checklist work, without claiming a shared jump |
| R3 | "With per-title event teams being folded into one live-ops group under Larkspur, where does this role sit?" | Current on the announcement, and it clarifies the real scope of the job |
| R4 | "When the two titles' events collide on the shared calendar, who makes the call?" | Shows you're already thinking about the job's hardest seam |
| R5 | "What does a post-event review look like today, and what would you want this role to change about it?" | Goes straight at a JD duty you would own |
| R6 | "What's a recent call the team made under Players Before Plans?" | Shows you read the values, and gets you a real story about the team |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on a game with in-app purchases, or on a season pass | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative you stated, F9 | "I haven't led a team." Only if it comes up. The JD asks for coordination, not team leadership |
| "Producer" without "associate" | Inflated form of F1 | F1's quote at its own scope: "4 years as an associate producer at a puzzle-game studio." |
| Ran live-event calendars for more than one title | Inflated form of F2 | F2's quote at its own scope. The pack's observation: your material describes one main title's weekly calendar. C2's slot stays inside that calendar |
| Owned the retention KPIs or the post-event review | Inflated form of F5 | F5's quote at its own scope: you presented the monthly retention numbers to the studio head. A4's slot stays inside what you did |
| Managed QA, or owned the QA process | Inflated form of F6 | F6's quote at its own scope: you wrote the release checklist QA still uses |

---

## Sources

**Provided:** the JD and your background, both pasted in your message.

**Searches sent:**
1. `Saltmarsh Games values` → saltmarshgames.com/values
2. `Saltmarsh Games interview process producer` → saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile studio news 2026` → saltmarshgames.com/news/project-larkspur (September 2026)
4. `Tobias Wrenfield Saltmarsh Games` → talks.gdconf.example/2026/patch-notes-are-a-promise (search-result listing only, not fetched)

**Fetches:** saltmarshgames.com/values; saltmarshgames.com/careers/interviewing.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B1–B4: three values by name, quoted from the fetched page |
| 2. `Saltmarsh Games interview process producer` | yes | Established the loop: a 60-minute hiring-manager round with a tabletop then a values conversation, no take-home. Set the persona weights, bank A and bank B |
| 3. `Saltmarsh Games` strategy / recent news | yes | Project Larkspur: row F9, C1, A5, R3, R4 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, B4's theme, R1, R2 |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Deeper research (L2):** up to 6 more searches and 2 more fetches, several more minutes. Adds a fuller Larkspur brief, the full text of Tobias's talk, candidate reports on the Outage Hour, and recent org context. A5 and C1 become more specific.
- **Your answers to the answer slots in F2, F4, F5 and F6, given here outside a drill.** They become quoted evidence. C2, A4, D3, B3 and E2 change from slots to story maps, and F4 can rise above `low`.
- **The checklist itself, or a calendar or post-event document you can share without breaking confidentiality.** In production work these documents are the inspectable proof. F6 and F8 could rise to `high`.
- **Anything the recruiter said about the tabletop's focus.** The A bank would be tuned to it.
- **A tuesday-dossier.md from the job-underwriter skill.** It would bring verified evidence and a checked list of prohibited claims, in place of the list this pack built locally.
