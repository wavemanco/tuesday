I've saved a prep pack at `stripe_product-operations-manager_interview_pack.md`. It's generic for now: web search was blocked in this session and I have no job description or CV, so it rests on what's typical for Product Operations roles rather than on Stripe's own pages or your background. I also assumed the final round mixes a hiring manager, peers and partners from other teams, since I don't know who you're meeting.

The pack has:

- **21 practice questions**, grouped by the style of interviewer most likely to ask them. Each comes with answer guidance and a note on why it's likely.
- **A self-assessment worksheet** with eight typical requirements for the role. For each one, it says what a strong example looks like and how to pick one of your own.
- **The question to rehearse first:** "Which part of this role would you be weakest at on day one?" (B1). It shows up in some form in most final rounds, so the pack gives it the deepest preparation.
- **Seven questions to ask them**, each with a note on why it works.

I can play a skeptical interviewer and run you through B1 with live follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep turned up, to carry into later sessions. If you'd like the pack as a Word document, I'll convert it.

1. Who are you meeting in the final (hiring manager, peers, partners from other teams, a panel), and did the recruiter name any focus areas or something to prepare, like a case, presentation or written exercise? That changes which questions matter most.
2. Can you paste the job description and your CV, or a few lines about your background? With those, the worksheet becomes real fit analysis and the answers are built from your own experience. If you'd rather skip it, the pack still works as is.
3. If you allow web search, should I look up Stripe's published operating principles, its interview process and its current strategy? That adds a values section and makes the "Why Stripe?" and strategy questions specific.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

- **Role:** Product Operations Manager
- **Company:** Stripe
- **Round:** Final round. Who you're meeting is unknown, so this pack assumes the round could include a hiring manager, peers and cross-functional partners, and blends the persona weights to match.
- **Built from:** your one-line request only. No JD, no CV, no interviewer names. Web search was refused in this session, so nothing here comes from Stripe's own pages either. That makes this the most generic version of the pack. Each section says what it is missing, and the upgrade menu at the end says what fixes it.

---

## How to use this pack

Two axes organize every question:

- **Personas** = *how* a question is asked: who asks it, in what style. The same question sounds different from a friendly peer and from a skeptic, and you should practise both.
- **Types** = *what* is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behavior shows the company's *published* values |
| EXP | Whether your experience survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy homework, and thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

**Provenance labels:** `[grounded]` traces to something you gave me or to cited research. `[inferred]` is derived from a representative source, and the derivation is named. `[generic]` is a role-family pattern that makes no claim about Stripe or about you. In this version almost everything is `[generic]`.

**The guidance is scaffolding, not a script.** Because I have none of your background, every answer cell is a *selection scaffold*: it tells you which of your own stories to pick and what a strong answer needs. Each one ends in an honest branch for when you have no such story. Fill the scaffolds with what you actually did, in your own words.

Question IDs are lettered by persona: A, B, C, D, E, G, H. F is skipped so it doesn't collide with the fit snapshot's F1–F8.

---

## Fit snapshot (self-assessment worksheet)

With no JD and no CV, this is the worksheet version. The requirements are the ones typical of Product Operations roles, written from no Stripe source, so they are plain prose labeled `[generic]`. Before the interview, fill the evidence column yourself: for each row, write down the one real example you would use.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running product launches and release readiness across teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a specific launch, what you coordinated, which teams, what readiness checks existed and who set them. Selection scaffold: pick one launch where you were the person keeping the cross-team pieces moving. It needs a named launch, your specific part in it, and one thing that went differently than planned. If no launch was yours to coordinate, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F2 | Building feedback loops from customers, support and sales back into product decisions (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a channel of customer signal you collected or organised, and a product decision it demonstrably fed. Selection scaffold: pick a time customer feedback changed what a team built or fixed. It needs the source of the signal, what you did with it, and what changed. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would set one up |
| F3 | Defining and tracking product and operational metrics, comfortable working with data (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a metric you defined or tracked, how it was counted, and a decision it moved. Selection scaffold: pick one number you can defend two levels deep, meaning how it was counted and its weakest assumption. If you can't defend any number that far, say so plainly, then describe the nearest analysis you did do, or how you would build the measure |
| F4 | Turning ad hoc work into repeatable processes, tooling or systems that scale (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a manual or messy workflow, the process or tool that replaced it, and who used it afterwards. Selection scaffold: pick a process you built or changed that other people relied on. It needs the before, your change, and the after. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would approach it |
| F5 | Influencing engineering, product, support, sales and other partners without formal authority (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a cross-team outcome you moved where nobody reported to you, with the disagreement and how it resolved. Selection scaffold: pick a time you got a team you didn't manage to change course. It needs a named stake, the pushback, and an intact relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F6 | Prioritizing competing requests and running programs to a deadline (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a queue or backlog you triaged, the criteria you used, and something you said no to. Selection scaffold: pick a time you had more asks than capacity and had to choose. It needs the competing asks, your criteria, and the cost of what waited. If the choosing was never yours, say so plainly, then describe how the choosing worked around you, or how you would do it |
| F7 | Clear written communication: docs, launch notes, decision memos (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a document you wrote that others acted on. Selection scaffold: pick one piece of writing that changed a decision or unblocked a team. It needs the audience, the ask, and what happened next. If none comes to mind, say so plainly, then say how you would approach writing one for this role |
| F8 | Partnering with risk, legal or compliance functions on product changes (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence: a product or process change where a risk or compliance requirement shaped what shipped, and your part in it. Selection scaffold: pick a time a constraint you didn't control changed a plan you were running. It needs the constraint, what you adjusted, and the outcome. If none comes to mind, say so plainly, then say how you would work with those partners |

No gate rows (work authorization, location, schedule) appear because there is no posting to name any. If the JD lists one, it will be added.

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | A1, E2 |
| F2 Customer feedback loops | A3, D2 |
| F3 Metrics and data | A2, A4, E1, E3 |
| F4 Process and systems | A3, A4, D3 |
| F5 Cross-functional influence | A1, C1, C3, D1 |
| F6 Prioritization | A3, C2 |
| F7 Written communication | — none, and why: written skill is usually judged through a written exercise or the clarity of your spoken answers, not a question. If the recruiter names a written exercise, it gets a build section |
| F8 Risk and compliance partnering | A1, D3 |

---

## Persona table

**These weights rest on a fallback, not on Stripe's documented process.** No loop source was read: search was refused, and "final round" by itself doesn't say how many sessions there are or who runs them. So the pack uses the *Generic* archetype and blends the priors for a hiring-manager session, a peer session and a cross-functional session. If you know who you're meeting, tell me and the weights change.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live problems from the job: plan a launch, diagnose a spike, design an intake system | High | A hiring-manager session's dominant persona, and Product Ops is an execution role, so live operational problems are the natural test | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud, and challenge one premise respectfully per case |
| Skeptic | Quiet probing of gaps and motivation: why ops, why now, why here, where you'd be weak | High | A hiring manager's second persona, and final rounds exist to derisk. Without your CV, the pack can't tell where your gap is, which makes the generic weakest-area question the safest bet | Rehearse the most predictable objection until it's boring. Bridge only from work you actually did, name limits plainly, and attach a concrete ramp plan |
| Peer Evaluator | Seam questions between product ops and PMs or engineering, reciprocity, disagreement with equals | Medium | A peer session's dominant persona. Product Ops sits between teams by design | Offer reciprocity (what you bring them), propose seam principles rather than pretending to know the seam, and tell disagreement stories that show spine and tact |
| Values / Behavioral | "Tell me about a time…" scenarios, STAR-shaped | Medium | The prior for a cross-functional session. Stripe's published principles could not be read, so no question here is mapped to them by name | "We" for context, "I" for your contribution. Choose stories where the hard truth actually landed, and say so when it didn't |
| Data-Driven Prober | Asks how a number was counted, two levels deeper than your answer | Medium | The peer prior's second persona, and metrics sit at the core of most Product Ops roles | Know how each number you cite was counted, and say plainly when you don't. Name your weakest assumption before they do |
| Pressure | Time-boxed, devil's advocate, "how much was actually you" | Low | No signal points to it. It's included so the style isn't met for the first time live | Pause, restate, anchor in what you actually did. Hold through two follow-ups, then concede what's real |
| Conversational | Friendly openers, "walk me through the journey", the questions-for-me slot | Low | The cross-functional prior's second persona. Casual questions are still scored | Keep a 90-second arc ready. Treat the casual question as scored, and never say "you've covered everything" |

---

## Question banks

### A. Case / Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A feature launches next month to customers in several countries. Support says they aren't trained, sales hasn't seen it, and legal has open questions in two markets. You own launch readiness. What do you do?" | CASE | [generic] | Clarify first: what "not ready" means for each team, why the date is fixed, and which markets legal is worried about. Separate hard blockers (legal, anything that harms customers) from comfort gaps (training, sales enablement). Propose go/no-go criteria agreed with each owner *before* the date, a phased rollout that holds back the contested markets, and named owners with dates. Metrics: support contacts per adopting customer, errors, and time to resolve in the first two weeks. Challenge one premise: is the date actually fixed, and what would moving it cost? The question asks about no past, so the guidance makes no claim about yours | Covers F1, F5 and F8 in one live problem, which is why it leads the bank. CASE because it scores structure on a role-shaped scenario, not your history |
| A2 | "Support tickets for one product area rose 30% over a quarter. Diagnose it." | CASE | [generic] | First ask whether it's real: did usage grow by as much, which would mean the rate per customer is flat? Then segment by ticket category, customer cohort, country, channel and new versus existing customers, and line the curve up against releases and policy changes. Form a hypothesis and say what data would kill it. Close with fix-at-source versus deflect, and how product hears about it. Name the assumption you'd trust least, for example that tickets are tagged consistently | Tests F3 under time pressure. Diagnosis cases are the standard way to see whether someone checks the denominator before the story |
| A3 | "Our product teams get a couple of hundred feature requests a quarter from sales and support, with no consistent intake. Design the system." | CASE | [generic] | Intake: one front door with a minimal required form. Triage: deduplicate, tag by product area and problem, and size by customers or revenue affected. Cadence: a regular review with PMs, with clear outcomes (yes, not now, no, need more data). Close the loop: requesters hear the decision and the reason. Measure time-to-decision and the share of requests that got an answer. Say what you'd deliberately *not* build at first, such as heavy scoring models before there's data | Covers F2, F4 and F6. A common shape of Product Ops work, so a plausible hiring-manager case |
| A4 | "Six months in, how would we know product operations is working?" | CASE | [generic] | Split it into outcomes for product teams (launch cycle time, fewer late surprises), for customers (support contacts after launches, time to fix) and for the business (decisions made with data that wasn't there before). Add one qualitative signal: do PMs ask for product ops earlier in the process? Name the weakest measure, for example that cycle time can improve for reasons unrelated to ops | Tests whether you can hold your own function to account, and covers F3 and F4. Final rounds often probe how a hire defines success |

### B. Skeptic (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Pick one row of the fit snapshot where your honest evidence is thinnest. A real weakness, not a disguised strength. Structure: (1) name it in one plain sentence, in your own words; (2) the nearest work you actually did, at its real scope, with nothing added; (3) a concrete plan for the first 30–60 days to close it: who you'd learn from, what you'd ship small first. Follow-up 1, "Why should we take that risk?": hold on the plan and the adjacent work; don't re-shrink the gap or inflate the adjacent work. Follow-up 2, "What if it takes longer?": concede the timeline is uncertain, and say what you'd do if the 30-day mark slipped. Never claim the gap is closed. If you can't find a weakness, that is the answer to fix before the interview, not in it | Some version of this question arrives in almost every final round, and without your CV the pack can't name your specific gap, so the generic version gets the deepest rehearsal. JD because it scores self-assessment against the listed job. Once a CV arrives, this row is rebuilt around your actual biggest gap |
| B2 | "Why product operations, and why now?" | JD | [generic] | Selection scaffold: two or three sentences linking a real thread in your work to the parts of product ops you want more of. It needs one concrete moment from your past that pointed you here, and one thing about the role you want that your current role doesn't give you. If there's no single moment, say so plainly, then give the honest pattern instead. Keep it forward-looking: no complaints about your current job | Motivation consistency is the Skeptic's core check, and a final-round interviewer may have heard your earlier answers from the recruiter |
| B3 | "Why Stripe, specifically, and not another product ops role?" | CO | [generic] | This pack has no researched Stripe facts, because search was refused. Don't take company specifics from it. Bring two things you've read on Stripe's own site or public writing, and tie each to something you want to do in this role. Avoid answers any company could hear ("great brand", "fast growth"). If you haven't read anything specific yet, that is tonight's homework | The CO question most candidates answer generically. It stays generic here until research runs, which is an upgrade-menu item |
| B4 | "Where's the line between product ops, program management and product management?" | JD | [generic] | A structural answer, no claim about your past: PMs decide what and why; product ops makes the how repeatable (launches, feedback, data, tooling) so PMs decide better and faster; program management drives a specific cross-team initiative to a date. Add that the line moves by company, and ask how it's drawn here, which turns the answer into a conversation | Tests whether you understand the role you'd be stepping into. A muddy answer reads as not knowing what you're signing up for |

### C. Peer Evaluator (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where's the seam between product ops and the PMs, and what happens when we disagree?" | JD | [generic] | Propose principles rather than guessing their org: the PM owns the decision, product ops owns the process and the data that informs it, and disagreements get escalated with the data on the table, not around each other. Then say how you'd agree the seam in your first weeks: ask, write it down, revisit it | Covers F5. A persona stem from the peer model, and the seam is the most likely peer friction point for this role |
| C2 | "What would you need from me in your first month, and what would you take off my plate?" | JD | [generic] | Lead with what you'd take on: a recurring operational burden the peer names. Ask for context, introductions and their honest view of what's broken. Selection scaffold: if you have a real example of taking work off a partner team, use it. If not, say so plainly and describe how you'd find the right burden to take | Reciprocity is what a peer is pricing. Covers F6 |
| C3 | "Tell me about a time you pushed back on a peer's plan." | EXP | [generic] | Selection scaffold: pick a disagreement with someone at your level. It needs the plan, your concern, how you raised it, what happened, and the relationship afterwards. "We" for context, "I" for what you said and did. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Disagreement with equals is in the peer persona's stem. EXP because it scores what you actually did, and it covers F5 |

### D. Values / Behavioral (medium)

Stripe's published operating principles could not be read, so none of these questions is mapped to them by name. Once the principles are in hand, this bank gets VAL questions against each one.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold: it needs a named stake, the truth you delivered and how, the reaction, and whether it landed. If it didn't land, say so; don't supply the ending. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A values-persona stem. Product ops often surfaces bad news about launches and data, so it covers F5 |
| D2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | Selection scaffold: it needs the metric, the customer issue, the call you made or argued for, and the cost. Your part only, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would weigh it | A values-persona stem, and it covers F2 |
| D3 | "A senior leader wants a process change shipped this week that you think will hurt customers. What do you do?" | CASE | [generic] | Clarify the goal behind the change. Quantify the customer risk as best you can. Propose the smallest version that meets the goal (a pilot, a limited rollout), bring in risk or compliance if relevant, and escalate openly if you still disagree. Commit fully once the decision is made, or say plainly why you can't | A live scenario that tests judgment under seniority pressure without assuming your past. Covers F4 and F8 |

### E. Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how that number was counted." (asked of any result you cite) | EXP | [generic] | For every figure you plan to say aloud, prepare four things in your own words: how it was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours. "I don't know how it was counted" is an honest answer, and far better than a method you can't repeat under a second question. If you won't cite numbers, this question won't come | A persona stem. Any number you offer in a final round is a magnet for it. Covers F3 |
| E2 | "What would you put on a launch-readiness dashboard, and which metric on it would you trust least?" | CASE | [generic] | Three or four measures across readiness (open blockers by owner, training completion), early health (errors, support contacts per adopter) and adoption. Name the least-trusted one and why, for example self-reported training completion. Then say what you'd add to cross-check it | Combines F1 and F3, and rehearses the weakest-assumption move on a neutral problem |
| E3 | "If the dashboard you need doesn't exist, what do you do?" | JD | [generic] | Say how you would actually get the data: query it yourself, pair with an analyst, or build a rough manual pull first. Be exact about your real level with data tools. Selection scaffold: if you have a time you built a measure from scratch, use it. If not, say so plainly and describe how you'd approach it | Tests self-sufficiency on F3. Overstating data skills is easy to catch with a single follow-up |

### G. Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then three beats: what you'd bring that an insider might not, said only from what you actually did; how fast you'd learn the internal context; and a concession that an insider has a real head start on context. Hold on the first beat through one more push. Don't knock the hypothetical insider | A pressure stem. Tests composure and time-boxing |
| G2 | "That result you mentioned: how much of it was actually you?" | EXP | [generic] | Prepare this for whichever story you lead with: "we" for the team's work, "I" for the specific things you did, and name who else did what. Hold your real part through two follow-ups, then concede the rest plainly. Shrinking gracefully reads as strength; inflating gets caught | A pressure stem. Attribution honesty is what this probe exists to test |

### H. Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, two or three turns that each lead toward product ops, and why this role is the next step. Selection scaffold: each turn needs a real role or project and one sentence on what you took from it. Cut anything that doesn't point here | A conversational stem, and it's often the first question. Scored on economy even when it feels casual |
| H2 | "So, what questions do you have for me?" | CO | [generic] | Pick two or three from the reverse questions below, chosen for the person you're actually talking to. Never "I think you've covered everything" | Rapport-style interviewers weigh this slot as a preparation signal. CO because it scores your homework |

**Count:** 21 questions.

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a great first 90 days look like for this role, and what would make you say it hasn't worked?" | Gets the real success criteria, and lets you tune your closing answers to them |
| "Where does product ops sit relative to the PMs here, and where has that line been contested?" | Shows you understand the role's central seam, and invites an honest answer |
| "What's one recurring operational problem the team has tried to fix and hasn't yet?" | Surfaces the real job, and gives you a concrete thing to react to |
| "How do product decisions get made here when the data is incomplete?" | Tests decision culture, which you'd be working inside every day |
| "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question. Best with a peer, since it shows you'd reduce their load |
| "What's changed about this role since it was opened?" | Often reveals new priorities the JD doesn't show |
| "What made you choose to work here, and what's kept you?" | Turns the conversation personal and peer-to-peer. Swap in a question tied to their own career path once you know who they are |

---

## Prohibited claims

Nothing is listed yet, because you haven't shared anything about your background. With no quoted material, there is no sentence for an answer to stretch. That is different from a pack that checked your material and found nothing to inflate. The standing rule still applies to every scaffold above: say only what you actually did, at its actual scope. Once you share a CV or background, this section lists the specific stretched versions of your own lines that the pack will not coach.

---

## Sources

**Provided documents:** your message ("Final-round interview at Stripe for a Product Operations Manager role"). No JD, CV, interviewer names or recruiter guidance.

**Searches sent:**

- "Stripe operating principles official" → refused
- "Stripe interview process operations role final round onsite" → refused
- "Stripe 2026 strategy news stablecoins agentic commerce annual letter" → refused
- "Stripe \"Product Operations\" manager job description" → refused

No fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values / operating principles | unavailable | Search refused. Would have supplied the principles by name, a values cheat sheet, and VAL questions in bank D |
| 2. Stripe interview process, operations role family | unavailable | Search refused. Would have named the final round's actual sessions and set persona weights from them instead of the Generic fallback |
| 3. Stripe strategy / recent news | unavailable | Search refused. Would have made B3 and at least one case strategy-specific rather than generic |
| 4. Interviewer name + Stripe | n/a | No name was given, so there was no query to form. No interviewer read |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. Would have replaced the eight `[generic]` fit-snapshot rows with quoted `[inferred]` requirements |

---

## Upgrade menu

- **The JD text** → the eight `[generic]` fit-snapshot rows become `[grounded]` requirements quoted from Stripe's posting, any gate terms (location, authorization, schedule) appear as rows, and the JD-tagged questions are retargeted to the listed responsibilities
- **Your CV, or a few paragraphs about your background** → the worksheet becomes a real fit snapshot, scaffolds become story-mapped answers in your own words, B1 is rebuilt around your actual biggest gap, and the prohibited list gets real entries
- **Who you're meeting, and their roles** → persona weights from the real relationships instead of the Generic blend. If your final is several sessions, send the schedule and you get a mini-pack per session
- **Interviewer names** → an interviewer read from their public professional footprint, plus a reverse question tied to their own path
- **The recruiter's prep email** → coverage of any pre-declared deliverable (a case, presentation or written exercise) as its own build section, plus their stated focus areas
- **Permission for web search** → the L1 pass above: Stripe's principles by name with a values cheat sheet, the documented loop, current strategy for B3 and a strategy case, and a representative JD if you don't have one
- **Deep research (L2)** → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, a grounding brief section so you sound current, and differentiator cases
- **How much prep time you have** → a prioritized prep schedule sized to it
- **A tuesday-dossier.md from job-underwriter** → an objection drawn from your evidence instead of B1's generic one, a strategy for each weak area, and a prohibited-claims guardrail. Optional; this pack is complete without it
