I'm working through the prep skill's rules and about to run a few quick web searches on Saltmarsh Games and Tobias Wrenfield before building your pack.
I've saved your prep pack as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-canned-fc6b8682/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, because Saltmarsh's careers page says every loop has a single 60-minute "Outage Hour" with the hiring manager.

**What the research turned up:**
- **The interview format:** the hour starts with a tabletop exercise on a simulated outage during a live event, then moves to a values conversation. There's no take-home.
- **Company values:** there are three: *Players Before Plans*, *Ship the Patch Not the Promise* and *Leave the Build Greener*. Your release checklist fits *Leave the Build Greener* directly, so that's your strongest values story.
- **Project Larkspur:** a search result I didn't open says both titles move to a season pass on one shared events calendar from February 2027. You've said you haven't worked on a game with in-app purchases, so that will almost certainly come up. Practising that answer (C1 in the pack) is the most valuable prep you can do tonight.
- **Your interviewer:** Tobias Wrenfield used to be a QA lead, and he gave a GDC 2026 talk called *Patch Notes Are a Promise*. Expect detailed questions on your release checklist (E2), and expect the tabletop to test whether you announce only what's actually known.

The pack has 22 questions in all, plus a one-evening prep plan, six questions for you to ask Tobias, and a list of claims it won't coach you to make (like having led a team).

Next steps, if you want them:
- I can play Tobias as the Skeptic on C1 so you can rehearse it live.
- I can save a `tuesday-dossier.md` file recording the gaps this prep found, for future sessions.
- I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations — read as the hiring manager, because Saltmarsh's careers page says this 60-minute interview, the "Outage Hour", is with the hiring manager
**Format (from saltmarshgames.com/careers/interviewing):** "a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."
**When:** Friday — tomorrow

---

## How to use this pack

- **Personas** describe *how* a question arrives (the style of whoever is asking). **Types** describe *what* is being scored.
- Type key:
  - **VAL** — behaviour against Saltmarsh's *published* values
  - **EXP** — does what you said about your past hold up when someone digs into it
  - **JD** — can you do the listed job, gaps included
  - **CO** — company knowledge: strategy, recent moves
  - **CASE** — a live problem from the role, solved out loud
- Provenance labels: `[grounded]` traces to your message, the JD, or a source listed under Sources; `[inferred]` is this pack's own derivation, and the derivation is named; `[generic]` is a common pattern for the role with no claim about Saltmarsh or you.
- **Answer slots** are places where the pack can't know the answer. Each one gives two honest branches. Fill them from your own memory, and never with what the slot names as a likely probe.
- Guidance is scaffolding, not a script. Say it in your own words.
- Question IDs skip the letter F so they can't be confused with fit-snapshot rows (F1–F9).

---

## Prep triage (one evening, assuming the interview is tomorrow)

1. **C1 out loud, three times**: the season-pass / in-app-purchase objection. This is the highest-ROI prep in the pack (~30 min).
2. **A1 → A4 as one run-through**: the outage tabletop from first alert to post-event review, using the structure in the persona table. Time yourself (~45 min).
3. **B1–B3**: choose a real story for each value, or decide on your honest "no such time" answer (~30 min).
4. **D1**: write down which retention numbers you presented and what you know about how they were counted. Also note what you don't know (~15 min).
5. **G2**: play each title for ~15 minutes if you can (~30 min).
6. **Reverse questions**: pick three (~10 min).

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes one title's weekly content-drop calendar. It doesn't describe a live-events calendar for two titles, so keep the claim at that size: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a question about scale likely. If your calendar included events as well as content drops, say what they were, in your own words. If it didn't, say so plainly and stay with the weekly drops. Talk about running two titles as a plan, in the future tense |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show any work with these four teams. Answer slot: if running the calendar meant working with any of them on a drop, say which teams and what your part was. If it didn't, say so plainly and describe how you ran the calendar. Coordinating teams is not the same as leading them, so keep the two separate |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Presenting monthly numbers is not the same as owning a post-event review, so don't stretch this one. Answer slot: if you ran or wrote any review after a content drop, say what it covered. If none existed, or it wasn't yours, say so plainly, then say how you would run one (A4) |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. But nothing backs this line up yet, so expect to be asked about it, especially by an interviewer whose public career includes QA (see Reading the interviewer). Describe it in the sentence's own terms: you wrote it, and QA still uses it. "Manage" is the JD's word, so don't use it for your own past |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The years are there. Your title was associate producer, and your material doesn't say whether the puzzle game ran as a live service. Answer slot: if it did, say so in your own words. If it didn't for all four years, say which part did, or say so plainly. Give your title exactly as it was |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | A direct match, in the JD's own terms. Nothing backs it up yet, so expect "walk me through it". Describe what you did in your own words |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Say it as it was: you presented the monthly retention numbers to the studio head. Expect questions on which numbers they were and how they were counted (D1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Your written evidence is the release checklist: you wrote it, and QA still uses it. Say that and let the interviewer draw the conclusion. Don't call it proof that you write well |
| F9 | Season-pass model on both Project Larkspur titles from February 2027. This comes from company research, not from the JD (see Sources) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You said this yourself. Words: "I haven't worked on a game with in-app purchases." Then give your ramp-up as a plan, never as something you've done. Don't add anything to make the gap feel smaller |

**Highest-ROI objection:** F9, rehearsed as C1. Both titles are reportedly moving to a season pass, and you have stated you haven't worked on a game with in-app purchases. Expect it in some form.

---

## Reading the interviewer

Public professional footprint only. All of it comes from one search result that this pack did not open (see Sources).

- **Career pattern:** Head of Live Operations at Saltmarsh; previously a QA lead at a console studio.
- **Public theme:** a GDC 2026 talk, *Patch Notes Are a Promise*. Its stated argument is that a live team is judged by how often its patch notes describe what actually shipped. That theme sits close to Saltmarsh's published value "Ship the Patch Not the Promise".
- **What this means for you:**
  1. Your release-checklist evidence (F4) is in territory he knows from QA. Expect questions about depth (E2, D3). Describe exactly what you wrote and nothing more.
  2. Accurate player communication is likely to come up in the tabletop (A3, E1). Announce what is known, not what is hoped.
  3. If you mention the talk, say exactly how you know it. If you've only seen the summary, say that. Watch it tonight if you can find it.
- **Mirror opportunities:** none offered as a shared career jump, because none of your evidence matches his move from QA into live ops. What you share is vocabulary: the release checklist (F4: "Wrote the release checklist our QA team still uses.").

---

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The outage tabletop | **Highest.** The careers page says the hour opens with a live-incident tabletop, and the hiring-manager prior puts Case first | Clarify → stabilise → communicate → decide → recover → review. Say each step aloud before you take it. Challenge one premise per scenario, politely |
| Values / Behavioral | The second half of the hour | **High.** The careers page names a values conversation, and the values page lists three values by name | One real story per value where you have one. Where you don't, give an honest "not yet" plus the nearest thing you do have. Use "we" for context and "I" for your own part |
| Skeptic | Probing the step up: one title to two, associate producer to producer, no in-app purchases | **High-mid.** The hiring-manager prior, plus the gaps at F9, F2 and F3 | Rehearse C1 until it's boring. Acknowledge, hold what's true, then give a ramp plan. Calibrated candor beats bluffing |
| Data-Driven Prober | Retention numbers, KPIs, patch-note accuracy | **Mid.** The JD's retention and KPI lines (F3, F7), plus the interviewer's public theme of measuring whether notes match what shipped | Know what you can and can't say about how each number was counted. "I don't know how it was counted" is an allowed answer |
| Pressure | The simulated outage itself: time pressure, someone senior wanting an ETA | **Mid-low.** The tabletop format builds the pressure in | Pause, restate the question, hold through two follow-ups, then concede something specific |
| Conversational | The opener and the end | **Low.** The hour is mostly structured | A 90-second biography. Treat casual questions about the titles as scored |
| Peer Evaluator | Larkspur merging the per-title teams into one group | **Low.** Single interviewer, but Larkspur makes working across teams a live topic | Frame it as what you bring as well as what you need. Propose principles for where team responsibilities meet rather than pretending to know the org chart |

---

## Question banks

### A — Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a weekend event. Logins fail for a big share of players. Walk me through your first 30 minutes." | CASE | [inferred] | Clarify first: which title, which platforms, how many players, is the event still running. Stabilise: who leads the engineering incident, who owns player comms, where the war room is. Communicate: a first player post saying only what you know, with a time for the next update. Decide what to do with the event's timers. Log decisions as you go for the review. This question asks about no past, so the guidance makes no claim about yours | The careers page names this format, so a version of this question is near-certain. It's inferred because the scenario details are this pack's; it's CASE because it scores live structure |
| A2 | "The fix needs a client update and store review could take a day. The event ends Sunday. What happens to the event?" | CASE | [grounded] | Lay out the options out loud: extend the event server-side, pause and resume, or let it end and make it good for players. Weigh them against player fairness and the calendar that follows. Pick one and name its cost. Link it to "Players Before Plans" only by the value's own words: when the calendar and the players disagree, the players win | Follows A1 in any realistic run of the scenario. Grounded on the fetched values page; CASE delivery |
| A3 | "What goes in the first community post — and what do you leave out?" | CASE, VAL | [grounded] | In: what's affected, that the team is on it, when the next update comes, what players should do (or don't need to do). Out: any ETA or make-good you can't stand behind yet, because the value reads "we announce what is built, not what is hoped." Keep it to three or four sentences | Tests the JD's written-communication line under pressure and Saltmarsh's published value. Grounded on the JD and the values page |
| A4 | "The outage is fixed. Run the post-event review — what do you look at and what do you report?" | JD, CASE | [grounded] | Structure: timeline, player impact, event participation against what was planned, retention for the affected group, root cause, what went well, actions with owners and dates, and the checklist change that would have caught it. Report the KPIs plainly, including what you can't yet measure. Your past isn't asked about here; if a review you ran comes up, see F3's answer slot | Covers the JD's "own the post-event review and the KPIs it reports", where your material is thinnest (F3). Better to show the method live than claim a past. JD content, CASE delivery |
| A5 | "Both titles are moving to one shared events calendar. How would you plan the first quarter?" | CO, CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify: which beats are fixed (season starts and ends), how much design, art, engineering, QA and community capacity is shared, what each title's players expect. Principles: don't put both titles' big beats on the same shared team in the same week; stagger releases through QA; publish the calendar to community only once content is built. Anchor in your experience at its real size: "I ran the weekly content-drop calendar for our main title for the last two years." Present two titles as a plan | The Larkspur announcement (Sources) makes this the role's near-term job. CO because it needs company context; CASE because it's solved live |

### B — Values / Behavioral (the values conversation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold, set within the calendar you ran. Pick a time players' response changed what went on it. It needs the plan, what players did or said, what you changed, and your part in it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Built directly on "Players Before Plans". F6 is the obvious place to look, but the material doesn't show a disagreement, so this is a scaffold, not a story map |
| B2 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped: you wrote the release checklist, and QA still uses it. Those are the two parts the sentence gives you; tell them in your own words. Answer slot: the value says releases leave "the checklist better than it found them", so expect a question about revisions. If you changed the checklist after a release, say what changed and why. If you didn't, say so plainly and stay with writing it | "Leave the Build Greener" names the checklist outright, and F4 is your strongest match to any published value. This is your best values story |
| B3 | "Tell me about a time something was announced before it was ready." | VAL | [grounded] | Selection scaffold: a time an announcement or date got ahead of the build. It needs what was promised, what was actually ready, and what you did or said. If no such time comes to mind, say so plainly, then say how you'd keep announcements matched to builds | Built on "Ship the Patch Not the Promise", which also echoes the interviewer's public theme. The theme is grounded on the values page; no past is assumed |
| B4 | "Which of our three values would be hardest for you to live, and why?" | VAL | [grounded] | Pick one honestly and say why, in your own words. Then say what you'd do about it. Don't pick a fake weakness. A good answer names a real tension, for example between keeping a calendar and changing it, as long as that's genuinely how you see it | Common in values conversations. Tests whether you've read the values rather than heard of them. Grounded on the values page |

### C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never worked on a game with in-app purchases, and both our titles are moving to a season pass. Why bet on you?" | JD, CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | **The highest-ROI rehearsal in this pack.** Name the limit before he presses on it: "I haven't worked on a game with in-app purchases." Hold on what's true, at its real size: "I ran the weekly content-drop calendar for our main title for the last two years," and you wrote the release checklist QA still uses. Then the ramp, in the future tense: how you'd learn both titles' season-pass structure in the first weeks, and who you'd sit with. **Follow-up 1** ("so you've never planned around revenue?"): give no more than your statement, then return to the ramp. **Follow-up 2** ("why not hire someone who has?"): concede that the experience gap is real, and say plainly what you'd bring. Don't argue the experience is equivalent, and don't fold | F9 is a negative you stated, and Larkspur makes it impossible to avoid. That's why it gets the deepest rehearsal. JD because it scores fit for the role as it will be; CO because it needs Larkspur |
| C2 | "This role coordinates design, art, engineering and community on every update. Where have you done that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | Start from the calendar you ran. Answer slot: if running it meant working with any of those teams on a drop, say which teams and what your part was, in your own words. If it didn't, say so plainly and describe how you ran the calendar. If he asks about leading: "I haven't led a team." Keep coordinating and leading apart | F2 has no evidence behind it and is a core JD line, so it will be asked. JD because it scores a stated responsibility |
| C3 | "You were an associate producer. What makes you ready for producer?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Give your title as it was. Then the three things you did, each in its own words: ran the weekly content-drop calendar, wrote the release checklist, presented the monthly retention numbers to the studio head. Answer slot: the JD asks for live-service experience. If the puzzle game ran as a live service, say so; if not for all four years, say which part did, or say so plainly | F5's title-and-scope gap. JD because it tests the stated years requirement |
| C4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose one honestly. The pack reads the JD lines where your material is thinnest as F2 (coordinating teams) and F3 (post-event review). Whichever you name, say what you have done nearby only in your own sentences' terms, then give the ramp. In-app purchases is a safe acknowledgment, but it isn't a JD line, so it can read as dodging | A standard Skeptic question. JD because it asks you to grade yourself against the JD |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented monthly retention numbers. Which metrics, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot, in your own words: which retention numbers they were; how they were counted, or "I don't know how they were counted"; the assumption behind them you'd defend least; and which part was yours. If you pulled or calculated them, say how. If another team produced them, say so plainly and stay with presenting them | F7 is the JD's retention line, and the word "presented" is where a follow-up digs. EXP because it tests a claim from your past |
| D2 | "Tell me about a time a retention number changed what went on the calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Selection scaffold, set within those two sentences. It needs the number, the calendar change, and your part. If no such time comes to mind, say so plainly, then say how you'd use retention data in planning | Joins F6 and F7, the JD's calendar and retention lines. The material doesn't show the link, so this is a scaffold |
| D3 | "How would you know whether an event's patch notes matched what actually shipped?" | CASE | [inferred] | A method, not a past: check each patch-note item against the release checklist and QA sign-off before publishing; after release, compare player reports against the notes; track how many items needed a correction. Keep it simple and make it measurable | Inferred from the interviewer's public talk theme (Sources), so it's a likely question rather than a certain one. CASE because you design the method live |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds. The studio head wants an ETA posted to players right now. What do you post?" | CASE, VAL | [grounded] | Hold: post what is known and when the next update comes, not an ETA engineering hasn't given you. Follow-up 1 (pushback): restate why, briefly. Follow-up 2: offer a specific concession, such as an earlier next-update time or a promise to give a window as soon as engineering commits to one. Don't fold into a made-up ETA | Pressure built into the tabletop, tied to "we announce what is built, not what is hoped". Grounded on the values page |
| E2 | "That release checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold on what the sentence says: you wrote it, and QA still uses it. Answer slot: if QA or anyone else contributed items, or it built on an earlier list, say so plainly and name your part. If it was all yours, say that. Hold through two follow-ups, and concede the specifics without shrinking the core | F4 is your strongest match, so it will be tested hardest, and the interviewer's background is QA. EXP because it's a who-did-what question |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | 90 seconds: four years as an associate producer at a puzzle-game studio; for the last two, you ran the weekly content-drop calendar for the main title; you wrote the release checklist QA still uses; you presented the monthly retention numbers to the studio head. Answer slot: why live ops and why Saltmarsh, in your own words | Near-certain opener, and scored even when it's casual. EXP because it sets up everything that follows |
| G2 | "Have you played Tidepool Tactics or Lantern Row?" | CO | [grounded] | Say plainly how much you've played. If you play tonight, have one concrete observation about each title's events. Don't make up play history | Both titles are named in the Larkspur announcement (Sources). A casual question that's really a homework check |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Larkspur folds the per-title event teams into one group. What would you need from them in your first month — and what would you give back?" | CASE, CO | [grounded] | Need: how each title's events are run today, what has broken before, who to ask for what. Give back: one shared view of the calendar across both titles, and a release checklist everyone can see. Offer principles, not a pretend org chart | Larkspur's team merge (Sources) is a live seam this role sits on. CASE because it's a scenario; CO because it needs Larkspur |
| H2 | "Design wants the event moved a week later; community has already teased the date. How do you settle it?" | CASE | [generic] | Clarify what's actually late and why. Lay out the options: hold the date with less scope, or move it and tell players straight away. Bring design and community together for the decision. Apply "announce what is built" going forward. No claim about your past is needed | Directly tests the JD's coordination line (F2) as a live problem. Generic because the conflict is a common pattern, not a Saltmarsh fact |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A5, B1, C1 |
| Coordinate design, art, engineering and community | C2, H1, H2 |
| Own the post-event review and its KPIs | A4, D1, D2 |
| Manage the release checklist with QA | B2, E2, D3 |
| 3+ years producing live-service games or apps | C3 |
| Experience running a content calendar | A5, B1, D2 |
| Comfortable with player-retention metrics | D1, D2, A4 |
| Clear written communication | A3, E1, B2 |

---

## Values cheat sheet

Source: saltmarshgames.com/values (fetched).

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | If player response and the schedule conflict, change the schedule | Selection scaffold (B1), set within F6: "I ran the weekly content-drop calendar for our main title for the last two years." Pick a time players changed the plan. If none comes to mind, say so plainly and say how you'd handle one |
| Ship the Patch Not the Promise | Only tell players about what is built | Selection scaffold (B3): a time an announcement got ahead of the build. If none comes to mind, say so plainly, then describe how you'd prevent it |
| Leave the Build Greener | Every release improves the code and the checklist | Mapped to F4: "Wrote the release checklist our QA team still uses." Answer slot on revisions is in B2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from QA lead into live operations. What from QA do you still lean on most when an event goes wrong?" | Tied to his own career path, and it turns the interview into a conversation between peers |
| R2 | "Your GDC talk argued a live team is judged by whether its patch notes describe what shipped. How does Saltmarsh check that today?" | Shows you've done your homework on him, and the answer tells you how this role will be measured. Only claim as much familiarity with the talk as you actually have |
| R3 | "Are the two titles in this role the two in the Larkspur announcement, and what does the role own before and after February?" | Confirms the role's scope rather than assuming it, and shows you know about Larkspur |
| R4 | "When the calendar and the players last disagreed here, who made the call, and how?" | Asks about the value in practice. A specific answer tells you how decisions really get made |
| R5 | "What does a great post-event review look like at Saltmarsh? Is there one I could read?" | Goes straight at the JD line where your material is thinnest (F3) and signals you want to meet the standard |
| R6 | "What would make you say, at 90 days, that this hire was right?" | Gets you his own success criteria, which you can then speak to before the hour ends |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated, F9's evidence sentence | "I haven't led a team." |
| Has worked on in-app purchases, monetization or a season pass | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." |
| Ran a live-events calendar, or live ops, for multiple titles | Inflated form of F1 | F1's sentence at its own size. The limit is the pack's observation: your material says one title's weekly content-drop calendar |
| Owned post-event reviews or retention KPIs | Inflated form of F3 and F7 | "Presented the monthly retention numbers to the studio head." D1's answer slot stays within presenting |
| Held the producer title | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." |
| Managed QA or the QA process | Inflated form of F4 | "Wrote the release checklist our QA team still uses." E2's answer slot stays within writing it |

---

## Sources

**Provided documents:** the JD text and your background, both pasted in your message.

**Searches and fetches:**

- Search `Saltmarsh Games values` → https://saltmarshgames.com/values
- Fetch https://saltmarshgames.com/values → three values with their definitions (used in the values cheat sheet, B1–B4, A2, A3, E1)
- Search `Saltmarsh Games interview process producer` → https://saltmarshgames.com/careers/interviewing
- Fetch https://saltmarshgames.com/careers/interviewing → the Outage Hour format (title block, persona weights)
- Search `Saltmarsh Games mobile studio news 2026` → https://saltmarshgames.com/news/project-larkspur. Search result only, not opened: Project Larkspur (September 2026) moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and replaces the per-title event teams with a single live-ops group
- Search `Tobias Wrenfield Saltmarsh Games` → https://talks.gdconf.example/2026/patch-notes-are-a-promise. Search result only, not opened: the GDC 2026 talk, his role, and his previous QA-lead role

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet; B1–B4; A2, A3, E1 |
| 2. `Saltmarsh Games interview process` | yes | Established the loop: one 60-minute hour with the hiring manager, tabletop then values. Persona weights follow it, and a values-style round is detected |
| 3. Saltmarsh strategy / recent news | yes | Larkspur: F9, C1, A5, H1, G2, R3 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer; D3, E2, R1, R2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied already fixes the fit snapshot and the JD questions |

---

## Upgrade menu

- **Answers to the answer slots in C2, D1, C3 and B1** → rows F2, F3, F5 and F7 could move from `discovery` or `low` to grounded story maps, and the Skeptic bank would get real stories instead of scaffolds
- **The release checklist itself (redacted), or a sample retention deck** → the kind of evidence this field keeps on file. F4 and F7 could move from `medium` towards `high`
- **Any recruiter-call notes or prep email** → confirms that the Outage Hour format applies to this role, plus any focus areas they named
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → open the Larkspur announcement and the GDC talk in full, and look for public reports of past Saltmarsh outages to sharpen the tabletop questions
- **A tuesday-dossier.md from an earlier evaluation of this role** → would carry checked evidence and an objection based on that evidence into C1, instead of the one this pack inferred
