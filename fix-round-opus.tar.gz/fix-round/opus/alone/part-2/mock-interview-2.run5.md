Web searches for Atlas Freight were blocked by permissions, so I'm building the pack from your JD and background alone.
I've saved your prep pack as `AtlasFreight_operations-manager_interview_pack.md`. I had no word on who you're meeting, so it prepares for the whole interview process and treats every interviewer style as equally likely. That's weaker than a pack built for one known round. The three web searches I tried for Atlas Freight (company values, interview process, recent news) were blocked by permissions, so nothing in the pack comes from company research.

**What it contains:**
- **A requirement-by-requirement fit check:** each line of the job description against your own words.
- **21 practice questions** across seven interviewer styles, each with answer guidance and why it's likely.
- **Six questions for you to ask them.**
- **A short "don't claim this" list.**

**The most important thing to practise (question A1):** "Today you lead three supervisors. This role leads twelve, across four sites. What makes you ready?"
- Open with the fact as it stands: "Today I'm a senior shift manager over three supervisors."
- Name the gap yourself, before they do: "Twelve is four times what I lead today."
- Close with a 30/60/90-day plan for learning four sites.

**Two other things to settle before the interview:**
- **Leadership years (A3).** The job asks for 5+ years of operations leadership. Your seven years are in operations, but it isn't clear how many were in leadership roles. Have that exact number ready.
- **Power BI (A2).** You've never used it, so say so plainly and follow it with a learning plan.

The 40% mis-pick reduction is your strongest number, and you should expect detailed questions on it. Know how it was measured and which part was yours. If you don't know how it was counted, saying so is better than guessing.

If you'd like a rehearsal, I can play the skeptical interviewer on A1.
I can also save a `tuesday-dossier.md` file recording the gaps this prep turned up, so you can carry them into later sessions.
I can convert the pack to a Word document if you want one.

1. Who are you meeting: your future manager, HR, a site lead, or a panel? And did the recruiter mention focus areas or anything to prepare, like a presentation? The answer changes how the question sets are weighted.
2. If you allow web search, should I rerun the three Atlas Freight searches? I can also do a deeper pass on their strategy and recent news if you want it: up to 6 more searches and 2 page reads, which takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Round and interviewer not known, so this pack covers the full loop with flat persona weights. That is noticeably weaker than a pack built for a known round; see the upgrade menu.

## How to use this pack

- **Personas** are how a question gets asked: who is asking and in what style. **Types** are what the answer is scored on.
- Type key:
  - **JD**: can you do the job as listed, gaps included
  - **EXP**: does your background hold up when someone digs in; what was actually you
  - **CASE**: a live problem from the role, solved out loud
  - **VAL**: behavioral stories against the company's values
  - **CO**: company and strategy knowledge (none in this pack: company research could not run, see Sources)
- Provenance labels: `[grounded]` means traceable to what you gave me; `[inferred]` means the pack's own derivation, named; `[generic]` means a role-family pattern with no claim about Atlas or about you.
- An **answer slot** is the spot in an answer where only you know the truth. Each one has two honest branches. Fill it from your own experience, or say plainly that it wasn't yours or didn't happen.
- The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material covers warehouse and distribution work and one site's surge plan. It does not cover terminal operations across four sites, so your words stay at their own scope: "Seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's terminal line makes a probe on the surge plan likely. If parts of the plan were yours to set, say which and how you decided, in your own words. If it was handed to you to run, say so plainly and describe how you ran it. For four sites, give how you would learn them, said as a plan and never as a past |
| F2 | "drive on-time performance and cost-per-shipment down" — JD (the on-time half) | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | Mis-pick rate is not on-time performance, and the 40% stays with mis-picks. Answer slot: if your site tracked on-time or another service measure and you worked on it, say which measure and what you did, in your own words. If not, say so plainly and say what you would look at first (B1) |
| F3 | "drive on-time performance and cost-per-shipment down" — JD (the cost half) | none given | none | [grounded] | discovery | Strong evidence here would be a cost measure you tracked and what moved it. Answer slot: if you have tracked or worked on any cost measure at your site, say which one and what you did, in your own words. If not, say so plainly and walk through how you would break cost per shipment down (B2) |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Words: "Today I'm a senior shift manager over three supervisors." The JD's twelve is four times that, and the pack says no more than that. Answer slot: the JD's line makes a probe on how you lead supervisors likely. Describe how you lead your three, in your own words, and then what you would change at twelve, said as a plan |
| F5 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" doesn't say what you build or who uses it. Answer slot: if you build reports in Excel, say which ones and who reads them, in your own words. If your Excel work is something else, or you don't build reports, say so plainly and describe what you do use it for |
| F6 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | You have said this gap yourself, and no wording closes it. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. No claim to Power BI work, and nothing added to make the gap look smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | A years requirement, not a gate. Seven years in ops is not shown to be seven years leading, and the reading that claims less wins. Answer slot: say how many years you have held leadership roles and what those roles were, in your own words. If the number is under five, say it plainly. An honest number with what you led beats a rounded one |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. Lead with the certification in its own terms. Nothing has been inspected behind it, so have the certificate ready if asked, and expect a probe on where you've applied it (E2) |

## Persona table

No loop source establishes Atlas Freight's interview structure: your note didn't say, and the search for it was refused. The weights below fall back to the generic archetype (screen, then hiring manager, then panel), which means flat weights. Every persona gets three questions. The bank order is a rehearsal order, not a likelihood ranking: Skeptic first because it holds the highest-ROI question, then the personas most likely to probe the JD's metrics.

| Persona | How it shows up for this role | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the scale step in F4 and F1, the years line in F7, and the Power BI gap in F6 | Flat: round unknown. In practice, any hiring manager reading the JD against your background reaches F4 first | Rehearse A1 until it's boring. Use only the bridges your quotes carry, then a concrete ramp plan said as a plan |
| B. Case / Strategist | Live problems on the JD's own metrics: on-time, cost per shipment, a team across four sites | Flat: round unknown. The JD names two metrics, which makes them natural case material | Clarify, objective, segment, approach, metrics, risks. Think out loud. Ask what's in the metric before fixing it |
| C. Data-Driven Prober | Digs into the 40% and into what your Excel reporting really is | Flat: round unknown. A headline figure in your background attracts this persona | Know what you can and can't say about how the 40% was counted. Name the weakest assumption you know of before they do |
| D. Pressure | Time-boxed "why you", "how much was actually you" | Flat: round unknown | Pause, restate the question, anchor in what you actually stated, hold through two follow-ups, then concede specifically |
| E. Conversational | Friendly openers. The Lean/Six Sigma plus asked casually | Flat: round unknown. Likeliest in a screen | A 90-second arc built from your own sentences. Treat casual questions on JD topics as scored |
| F. Values / Behavioral | Tell-me-about-a-time on supervisors, trade-offs, hard truths | Flat. Without Atlas's published values, these are themed on the JD and persona stems, not company values | We for context, I for contribution. Pick stories where you can name what was yours |
| G. Peer Evaluator | Another site or function lead asking what you'd need and give | Flat: round unknown. Likeliest in a panel | Reciprocity framing. Propose principles for working across sites rather than claiming to know Atlas's seams |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Today you lead three supervisors. This role leads twelve, across four sites. What makes you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **The highest-ROI rehearsal in this pack.** Open with the fact at its own scope: "Today I'm a senior shift manager over three supervisors." Name the limit before they do: "Twelve is four times what I lead today." Then answer slot: if part of how you lead your three would carry to twelve, say what it is, in your own words. If you're not sure it would, say so. Close on a 30/60/90-day plan for learning four sites and twelve supervisors, said as a plan. Follow-up 1 will push on size again: return to the three, add nothing to them. Follow-up 2 may push on sites: describe the site work you've done in its own terms, then the learning plan. Never fold on the three, and never inflate them | F4 and F1 are the widest gaps between the JD and your material, so some form of this question is close to certain. JD because it scores the stated team-size requirement. It gets the deepest rehearsal because a calm, specific answer here changes the interview |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" and "solid Excel" | Pick the gap you've already named: "I've never used Power BI." Then the plan for learning it, as a plan: what you'd learn first and by when. Then return to "solid Excel" at its own scope, without claiming Power BI is the same thing. Choosing a real gap reads as self-awareness. A fake weakness reads as evasion | F6 is the one gap you've stated yourself, so it's the honest pick, and F5 is the nearest bridge your material carries. JD because it asks against the listed requirements |
| A3 | "The JD asks for 5+ years of operations leadership. How many of your seven years were in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" | Answer slot: give the number of years you've held leadership roles and name the roles, in your own words. If it's under five, say the number plainly, then go to what you lead today: a senior shift manager over three supervisors. Don't let "seven years in ops" become "seven years leading" | F7 is the requirement most likely screened literally. The interviewer can do the arithmetic, so an exact answer protects credibility. JD because it scores the stated requirement |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our terminals dropped this month. Diagnose it." | JD | [generic] | Clarify first: how is on-time defined (pickup, delivery, dock departure), against what baseline, and since when. Segment: which lanes, shifts, customers, and whether it's one cause or many. Hypotheses: inbound arrival times, dock or door capacity, labor coverage, load errors, carrier issues. Verify with data before acting. Then a fix, an owner, and how you'd keep it from coming back. This question needs no claim about your past, so the guidance makes none | The JD names on-time performance as a mandate, and F2 shows your material doesn't speak to it directly, so a case is where you can show reasoning. JD content with CASE delivery |
| B2 | "Cost per shipment is up across the network. Where do you look first?" | JD | [generic] | Split the ratio: is cost up, or shipment count down, or mix shifted? Then decompose cost: labor hours and overtime, rehandling and damage, equipment, and anything else in the measure. Ask what the metric includes before you fix it. Pick the biggest driver, test it, then act. Name one risk: cutting cost in ways that hurt on-time | The cost half of F3 has no evidence in your material, so structured reasoning is your best showing. JD content with CASE delivery |
| B3 | "You inherit twelve supervisors across four sites. What do your first 90 days look like?" | CASE | [generic] | Days 1–30: visit every site and shift, meet each supervisor one on one, learn how on-time and cost are measured today. Days 31–60: pick one or two problems the data supports, agree on a common daily report. Days 61–90: first measurable change, with a plan to spread what works. Say it as a plan. Nothing here claims you've done this before | F1 and F4 together. A plan is the honest way to answer a scale question your history doesn't yet reach. CASE because it's a live planning problem |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slots, each in your own words: how the rate was measured and over what before and after periods; what the number is sensitive to (volume, season, staffing); the assumption behind it you'd defend least, named before they ask; and which part of it was yours. If you don't know how it was counted, say so plainly. That is an honest answer, and a better one than an explanation you can't back up | Your headline figure, behind F2's evidence. Probers go two levels deep on any number. EXP because it tests whether the figure survives scrutiny |
| C2 | "Tell me about the pick-path redesign itself." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats your sentence carries: the pick path, redesigned, mis-picks down 40%. Tell them in your own words. Answer slot: which decisions in the redesign were yours and who else was involved. If others shaped it, say so and say what your part was. Describe what you did and let the interviewer draw the conclusion | The same claim from the story side, because interviewers who heard the number ask for the work. EXP for attribution |
| C3 | "What reporting do you build in Excel today, and who uses it?" | JD | [inferred] "solid Excel" | Answer slot: if you build reports, name one, who reads it, and what decision it feeds. If your Excel work is something else, or you don't build reports, say so plainly and describe what you do use it for. Never describe a dashboard you haven't built | F5's thin evidence against the JD's reporting line. Inferred because the pack derives the probe from the JD, not from anything you said. JD because it scores the stated requirement |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" and "cut mis-pick rate 40% by redesigning the pick path" and "ran the site's peak-season surge plan two years running" | Pause, then two or three facts at their own scope: you're a senior shift manager over three supervisors, you cut the mis-pick rate 40% by redesigning the pick path, and you ran the site's peak-season surge plan two years running. Don't run down the internal candidate. Concede what's true: they know the terminals, and you'd have to learn them. Then one line on how fast you'd do it, as a plan | Pressure personas time-box the "why you" question. Draws on F4, F2 and F1. JD because it's scored against fit to the role |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: restate the sentence as it stands. Answer slot: say which parts were yours and which were others', in your own words. If others contributed, name their part plainly. Precise credit-sharing reads as strength. Hold the core claim through two follow-ups, and concede specifics, never the whole | F2's evidence under attribution pressure. EXP for attribution, delivered as a stress probe |
| D3 | "You ran the surge plan two years running. Why should I believe it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Hold on the fact: two years running. Answer slot: if peak was measured (orders shipped, overtime, service, anything), name the measure and what it showed, in your own words. If nothing was tracked, say so plainly and come back to the fact that you ran it two years running. Don't invent a result to win the moment | F1's evidence carries no outcome, and a pressure interviewer will go straight there. EXP because it tests the claim |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your background." | EXP | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" and "cut mis-pick rate 40% by redesigning the pick path" and "ran the site's peak-season surge plan two years running" and "green belt certified" | A 90-second arc in your own words: seven years in warehouse and distribution ops; now a senior shift manager over three supervisors; two things you'd point to, the pick-path redesign that cut mis-picks 40% and running the site's peak surge plan two years running; green belt certified. Answer slot: why this role now, in your own words. End there and let them pick the thread | Opens almost every round, and it's scored on economy. Draws on F1, F2, F4 and F8 at their own scope |
| E2 | "What are you actually doing with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: if you've applied green-belt tools on the job, name which tools and where, in your own words. If you haven't used it on a project yet, say so plainly and say where you'd apply it first here. Don't link the pick-path redesign to green belt unless it was a green-belt project | F8 is the JD's "plus", the kind of topic asked casually and still scored. JD because it scores the listed plus |
| E3 | "Why terminal operations, coming from warehousing?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: your actual reasons, in your own words. Then name the limit plainly: your work has been in warehouse and distribution, and terminal operations is the step you're applying for. Don't claim terminal experience. Say what you'd want to learn first | F1's transferability gap asked as motivation. JD because it scores fit to the role's core |

### F. Values / Behavioral

Atlas Freight's published values could not be fetched, so these are themed on the JD's lines and the persona stems, not on company values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a clear message you delivered yourself, and an outcome you can state. We for context, I for what you said. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle it | Common behavioral stem. Leading twelve supervisors means carrying bad news both up and down. VAL because it's a behavioral story |
| F2q | "Tell me about a time a supervisor on your team was struggling. What did you do?" | VAL | [generic] | Pick a time with a specific problem, what you did about it, and how it turned out. Leave out anything that identifies the person. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle it | Themed on the JD's "lead a team of 12 supervisors" (F4). VAL because it's scored on how you behaved |
| F3q | "Tell me about a time you had to trade off cost against service." | VAL | [generic] | Pick a time with a real tension, the call you made and why, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle it | Themed on the JD's on-time and cost mandate (F2, F3), which can pull in opposite directions. VAL for judgment under a trade-off |

(Values questions carry a "q" so their IDs don't clash with fit-snapshot rows F1 to F8.)

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "With four sites, what would you need from the other site leads, and what would you give them?" | CASE | [generic] | Reciprocity first: what you'd bring them (a shared daily report, early warning on volume or staffing). Then what you'd need. Propose a principle for disagreements, like data first and escalation last, rather than claiming to know Atlas's seams | F1's multi-site scope from a peer's side. CASE because it's a working-relationship scenario, not a record |
| G2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use the pick-path work as the example. Answer slot: who else contributed and what their part was, in your own words. If it was mostly yours, say what part was, and name anyone who helped. If you can't place an example here, say so and describe how you'd share credit | Peer persona stem, and F2's claim is the one a peer would test for credit-sharing. EXP for attribution |
| G3 | "What would you need from me in your first month?" | CASE | [generic] | Be specific and modest: how their site measures things, the one problem they'd fix first, and how they like to be kept informed. Offer something back | Peers judge whether a hire adds to or reduces their load. CASE because it's a live scenario |

### Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| Own daily terminal operations across 4 sites | F1 | A1, B3, E3, G1 |
| Drive on-time performance | F2 | B1, F3q |
| Drive cost per shipment down | F3 | B2, F3q |
| Lead a team of 12 supervisors | F4 | A1, B3, F2q |
| Build reporting in Excel | F5 | C3 |
| Build reporting in Power BI | F6 | A2 |
| 5+ years operations leadership | F7 | A3 |
| Lean/Six Sigma a plus | F8 | E2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is on-time performance measured across the four sites today, and where does it fall short most?" | Shows you think in the JD's own metric, and tells you what you'd inherit |
| "What does the team of twelve look like: how are they split across sites and shifts, and how long have they been in role?" | Turns the F4 scale question into planning. You need the answer anyway |
| "What reporting exists today, and what would you want the Excel or Power BI work to produce in the first six months?" | Puts your F6 gap in a diligence frame and shows what the reporting is really for |
| "What's the biggest driver of cost per shipment you'd want this person to go after first?" | Shows you think like the owner of the cost mandate |
| "What would make the first 90 days a success in your eyes?" | Gives you the scorecard. Pairs with your B3 plan |
| "What's changing about this role, or why is it open now?" | Shows whether you're inheriting a fix-it job or a steady one, which shapes your first 90 days |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team of twelve supervisors, or managed at the JD's scale | Inflated form of F4 | F4's quote at its own scope: "currently a senior shift manager over 3 supervisors." The limit is the pack's observation: your material says three. A1 holds there |
| Has run terminal or multi-site operations | Inflated form of F1 | F1's quotes at their own scope: "7 years in warehouse and distribution ops" and "ran the site's peak-season surge plan two years running." The limit is the pack's observation: your material describes warehouse and distribution work and one site's plan. Four sites are covered only as a plan |
| Seven years of operations leadership | Inflated form of F7 | F7's quote at its own scope: "7 years in warehouse and distribution ops." A3's slot asks only how many of those years were in leadership |
| The 40% applied to on-time performance or cost | Inflated form of F2 | The number stays with mis-picks: "cut mis-pick rate 40% by redesigning the pick path" |
| Has used Power BI, or is familiar with it | A negative you stated, F6 | The plain acknowledgment: "I've never used Power BI." No slot |

## Sources

Provided documents: the JD text and your background, both from your message.

Searches sent:

- `"Atlas Freight" regional logistics company values`: refused (search permission not granted)
- `"Atlas Freight" interview process operations manager`: refused (search permission not granted)
- `"Atlas Freight" terminals news 2026`: refused (search permission not granted)

No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Search refused. It would have themed the F bank on Atlas's published values, and added a values cheat sheet if a values round turned up |
| 2. Atlas Freight interview process | unavailable | Search refused. It would have replaced the flat persona weights with the documented rounds |
| 3. Atlas Freight strategy and recent news | unavailable | Search refused. It would have added CO questions and grounded at least one case in current priorities |
| 4. Interviewer name at Atlas Freight | n/a | No name given, so there was no query to form. The interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting and how they relate to the role (future manager, HR, a site lead, a panel) → persona weights move from flat to that round's priors, and the top persona's bank deepens to 4–5 questions
- The interviewer's name → an interviewer read from their public professional footprint, and a reverse question tied to their own path
- The recruiter's prep note or invite → coverage of any announced presentation or exercise, plus their stated focus areas
- Permission for web search → the three refused searches rerun: Atlas's values, interview process and recent news, with CO questions and a values cheat sheet if a values round shows up
- Your answers to the slots in F2, F3, F5 and F7 → those rows move from discovery to graded evidence, and B1, B2, C3 and A3 become story-mapped
- A sample report you've built in Excel, and your green belt certificate → F5 and F8 rest on something inspectable, which is what raises confidence in operations roles
- How much prep time you have → a prioritized prep schedule sized to it
- A tuesday-dossier.md from job-underwriter → the highest-ROI objection drawn from evidence you confirmed rather than inferred, plus its prohibited-claims guardrail
