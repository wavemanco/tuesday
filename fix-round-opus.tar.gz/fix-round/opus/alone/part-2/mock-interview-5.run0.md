Reading the prep-pack rules is done. Next I'm running a few web searches on Kelverton Rail, then I'll build your pack.
I've built your prep pack and saved it as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. None of it comes from research on Kelverton: all five web searches were refused because search permission isn't granted in this session. It rests only on the recruiter's email as you quoted it and your background. I haven't seen the market report.

- **The 15-minute POV:** this is the main prep. The pack gives you three possible theses, each paired with a weak point you should admit yourself. It also gives you one thing to say you *wouldn't* do: set a target for number of partners. Your 6→40 growth was what a payments channel looked like, and that may not carry over to train operators.
- **The panel wrote the report, so don't read it back to them.** Pick one finding to build on and one conclusion you'd want to test with operators first. The pack leaves those two spots blank for you to fill from the report.
- **The question to rehearse most:** "You've never carried a direct quota. Why should we trust you with a number?" (A1). Say it yourself before Ross raises it. Keep the word "influenced" every time you mention the £4M, through both follow-ups.
- **Your four hours:** the pack has a schedule. 90 minutes go on the POV and 40 on the quota and attribution questions. The rest goes on the rail-credibility questions, Ross's commercial questions, your opening story and the questions you'll ask them.

Say the word and I'll play Ross on A1, with live follow-ups.
I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I'll convert it.

1. Can you paste the job description? Without it, three of the six rows in the fit table are general assumptions about the role, not this posting. I'm happy to carry on without it.
2. If you allow web search, should I rerun the basic searches: their values, strategy and Deepa's and Ross's public profiles? I can also run a deeper pass: up to 6 more searches and 2 page reads, several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, 60-minute panel. A 15-minute spoken POV with no slides, then Q&A.
**Panel:** Deepa, VP Partnerships, your future manager. Ross, Commercial Director, who "will push on commercials" (recruiter's email).
**Built from:** the recruiter's email as you quoted it, and the background in your message. No JD and no CV were supplied. The web searches were refused in this session, so nothing here comes from research about Kelverton. Your copy of the strategy team's market report was never shared with me, so none of its content is used. You will need to fill those slots yourself.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who asks it and in what register. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behaviour and values, scored against what you actually did.
  - **EXP**: deep dive on your experience. Does the claim survive scrutiny, and what was actually yours?
  - **JD**: can you do the listed job, including where you have gaps?
  - **CO**: company and market knowledge. Can you think at their altitude?
  - **CASE**: a live problem from the role, solved out loud.
- Provenance labels: **[grounded]** means it traces to your message or the recruiter's email. **[inferred]** means it is derived, and the derivation is named. **[generic]** means it is a role-family pattern and says nothing specific about Kelverton.
- **Answer slots** are places where only you know the true answer. Each one gives two honest branches. Answer in your own words. They are not questions for me.
- The guidance is scaffolding, not a script.

---

## Prep triage: about 4 hours over the weekend

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV. Pick your two report anchors, choose your theses, then say it out loud against a timer twice. Cut until it lands at 14 minutes | Section: Graded deliverable |
| 2 | 40 min | Rehearse the quota objection out loud, both follow-ups, until it bores you. Then the attribution question and the £4M walk-through | A1, D2, C1 |
| 3 | 30 min | The rail-credibility pair: never sold into rail, and bus or light rail is not mainline | A2, A3, D1 |
| 4 | 30 min | Ross's commercials bank: denominators, deal structure, how you would be measured | C2, C3, C4, B5 |
| 5 | 20 min | The 90-second journey arc, and pick 3 reverse questions, one for each panellist plus one spare | E1, Reverse questions |
| 6 | 30 min | Full run: POV, then 15 minutes of A and C questions read aloud by a friend, or a drill with me | — |

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material shows an ISV channel at a payments company, not partnerships with train operators. Keep your words at that scope: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: an 18-month POV makes a probe on how you planned that growth likely. If you set the channel's plan or priorities, say how, in your own words. If that was set for you, or there was no such plan, say so plainly and stay with the growth from 6 to 40 |
| F2 | "land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says consulting on bus and light rail network planning. It does not say mainline rail, and it does not say working inside an operator. "From the other side" is your phrase, so keep it yours. Words: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: closing on operators makes a probe on what you know about how operators work likely. If your consulting work had you working with operator teams, say on what, in your own words. If it didn't, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure is yours. Keep "roughly" and "influenced" attached to it. Your material does not show how the figure was counted, or over what period. Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, all in your own words. Where you don't know, say so plainly |
| F4 | Owning a revenue number. Senior partnerships roles at software vendors often carry one. This is a role-family pattern, not a line from this posting | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | You have said this plainly, so the words come from your statement: "I've never carried a direct quota, only influenced revenue." Then say how you would want to be measured here, as a proposal and never as past experience. Add nothing to make the gap feel smaller |
| F5 | Selling into rail operators. This is a role-family requirement for a rail-software partnerships role | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | Words: "I haven't sold into rail specifically." Then a ramp plan, said as a plan. F2 is the adjacent evidence, and it stays at its own scope: bus and light rail network planning, in consulting |
| F6 | Building and scaling a partner programme. Role-family requirement | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [generic] | none | No gap. But nothing has been inspected behind this line, so expect a probe. Lead with the quote's own terms: you ran the ISV channel and took it from 6 partners to 40 |

**Requirement coverage**

| Requirement | Question IDs |
|---|---|
| F1: 18-month POV on operator partnerships | Graded deliverable, B1, B2, B3, B4 |
| F2: what it means for operators | Graded deliverable, A3, B5, E2 |
| F3: commercials | C1, C2, C3, C4 |
| F4: owning a revenue number | A1, A5, C4 |
| F5: selling into rail | A2, A5, D1, D3 |
| F6: scaling a partner programme | C2, D2, E1 |

---

## Graded deliverable: the 15-minute POV

**What was asked** (recruiter's email): "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**The trap.** The panel's own strategy team circulated the report. Reading it back to them is the consensus answer that every prepared candidate gives. Use it to prove you did the homework, then show judgment by departing from it:

- **One anchor from the report.** Answer slot: pick the one finding you would build on and quote its own words. If the report does not discuss operator partnerships directly, say so and name the finding nearest to them.
- **One divergence.** Answer slot: pick a point where you would test the report's conclusion before acting on it, and give your reason. Frame it as what you would want to test with operators, never as "the report is wrong". These are the people who commissioned it.

**Facts about you that the POV can stand on.** Use only these, at their own scope:

- F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"
- F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- F4 and F5: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." Name this yourself, early and briefly. Ross will raise it otherwise.

**Thesis options.** Pick two, or all three if time allows. Every thesis carries a concession. Say the concession out loud, because that is where you show judgment.

| # | Thesis | What you'd say | Mandatory concession | Builds on | Provenance |
|---|---|---|---|---|---|
| T1 | Organise operator partnerships around operator outcomes, and bring in other suppliers only where they serve those outcomes | Start from what an operator needs the scheduling product to connect to. Partnerships exist to close those gaps, not to grow a partner count | Integration partnerships pay back slowly. Most of the first six months is groundwork, and there is little revenue to show for it | The report anchor, plus F1 at its own scope as the place you learned how a channel grows | [generic] |
| T2 | Go deep with a small group of design-partner operators before going broad | A few operators co-shaping the product give you references and roadmap evidence that you can then take wider | Favouring a few operators can bend the product toward them, and design-partner terms often mean discounted revenue. Expect Ross to push on this | The report anchor. F2 only as your phrase "from the other side", nothing wider | [generic] |
| T3 | Agree the commercial scoreboard in month one: what counts as partnership-sourced and what counts as influenced | Name the attribution rules before the work starts, so partnerships and sales are not arguing over credit in month twelve | Influenced revenue is contestable. Say it as someone who has stood on that side: "I've never carried a direct quota, only influenced revenue." | F3, F4 | [generic] |

**The anti-pick.** Say what you would *not* do. "I wouldn't set a partner-count target. Going from 6 to 40 was the shape of an ISV channel in payments, and I wouldn't assume that shape carries over to operators." This is a stance about the future, and it keeps F1 at its own scope.

**Suggested running order** (15 minutes, spoken):

| Minutes | Beat |
|---|---|
| 0–1 | Your one-line POV, plus the honest framing: what you bring, and that you haven't sold into rail |
| 1–3 | Your report anchor and your divergence |
| 3–10 | Your two or three theses as months 0–6, 6–12 and 12–18, each with its concession |
| 10–12 | Commercials: the T3 scoreboard, and what you would want to be measured on |
| 12–15 | The operator close, below |

**The requested close: what it means for the operators.** Put it as hypotheses you would test with operators, not as promises:

| Close beat | Provenance |
|---|---|
| Less of their own time spent stitching systems together around the scheduling product | [generic] |
| A real say in what gets built, through the design-partner group | [generic] |
| Commercial terms they can plan around, because partnership pricing is agreed up front | [generic] |
| Answer slot: the one operator pain point from the report that you would name, in its own words. If the report names none, say so and say how you would find out in your first 90 days | [grounded] |

With no slides, bring one handwritten page for yourself with the five beats on it. Don't read from it.

---

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Mostly Deepa. Probes the background mismatch: rail, quota, why now | **High.** She is the hiring manager on a panel, and that relationship's dominant personas are Case/Strategist and Skeptic. F4 and F5 are the two visible gaps | Rehearse A1 until it is boring. Bridges come only from what you stated. Name the limit before it is pushed |
| Case/Strategist | Deepa, mostly as follow-ups on the POV: prioritisation, first 90 days, trade-offs | **High.** The recruiter pre-declared the POV, and the rest is Q&A on it | Clarify, objective, segmentation, approach, metrics, risks. Challenge one premise respectfully |
| Data-Driven Prober | Ross, on commercials: denominators, how the £4M was counted, deal structure | **High for Ross.** The recruiter said outright that "Ross will push on commercials". F3 is the obvious target | Know what you can and can't say about how each figure was counted. Name the weakest assumption first |
| Pressure | Ross. Devil's advocate on whether a payments playbook works in rail, and on attribution | **Medium.** A commercial director pushing on commercials often comes with pressure, but nothing confirms that register | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Conversational | Either of them at the start. "Walk me through the journey" | **Low to medium.** It is likely only as the opener, since the POV takes the first 15 minutes | A pre-built 90-second arc |
| Values/Behavioral | Scattered "tell me about a time" questions | **Low.** The recruiter's email names no values round, and no values page was read | Selection scaffolds with honest branches |
| Peer Evaluator | Deepa as your future manager, on how partnerships and sales split the work | **Low.** There are no peers on the panel. The seam questions still come from a manager | Propose principles for the seam. Don't pretend to know it |

The weights rest on the recruiter's email, which establishes this session. No public profile was read for either panellist.

---

## Question banks

Bank letters skip F so they don't clash with the fit-snapshot IDs.

### A. Skeptic (mostly Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never carried a direct quota. Why should we trust you with a commercial number here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | **This is the highest-ROI rehearsal in the pack.** Open with the limit, before anyone pushes: "I've never carried a direct quota, only influenced revenue." Then say what the quote carries: you ran the ISV channel at a payments company and took it from 6 partners to 40, roughly £4M of influenced revenue. Answer slot: Ross's push on commercials makes a probe on what you were held to likely. If there were targets or measures you worked against, say what they were, in your own words. If there were none, say so plainly and stay with the channel's growth. Follow-up 1, "So nobody held you to a number?": hold. Repeat the distinction, and never upgrade "influenced" to "owned". Follow-up 2, "Would you take a quota here?": give your honest position as your own, then ask how this role is measured. Concession wording: "It's a real difference, and I'd rather name it than blur it." | F4 is a stated gap, and the recruiter flagged a commercial push, so this objection arrives in some form. JD-tagged because it scores whether you can own the commercial side of the job |
| A2 | "You haven't sold into rail. How do you get credible with operators fast?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Acknowledge it: "I haven't sold into rail specifically." Then the adjacent evidence at its own scope: five years in transport consulting, on bus and light rail network planning. "From the other side" is your phrase. Answer slot: if any of that work put you in front of operator teams, say on what. If not, say so and stay with the planning. Then a 90-day ramp, said as a plan: listen to operators before pitching them, and learn from whoever at Kelverton already holds those relationships | F5 is the second visible gap. JD because operator credibility is the core of the role |
| A3 | "Bus and light rail aren't mainline rail. What actually transfers?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Grant the premise first. Your material says bus and light rail network planning, in consulting. Answer slot: if parts of that planning work are close to what Kelverton's software does for operators, say which ones and how, in your own words. If none are, say so plainly and name what you would need to learn. Never call it "rail experience" without the "light" | It tests F2's scope directly, and it is where a stretched claim would break. EXP because it is about what the consulting years actually were |
| A4 | "Why move from payments into rail tech, and why now?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Your material doesn't state your reasons, so this is an answer slot. Give your real reasons in your own words, with a pull toward this role and not only a push away from the last one. Bring in the consulting years only if they really are part of why. If they aren't, leave them out | A Skeptic's motivation stem, sharpened by the industry switch between F1 and F2. EXP because it tests whether your career story holds together |
| A5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one of the two gaps you stated, either rail selling or the quota, and name it in your own sentence. Give the ramp plan as a plan. Don't name both unless asked. One honest gap with a plan beats a list | A persona stem, and the fit snapshot hands it F4 and F5. JD because it scores self-assessment against the job |

### B. Case/Strategist (Deepa, following up on the POV)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've got 18 months. What do you actually do in the first 90 days?" | CASE | [grounded] | Clarify what is already in flight. Then: listen to a handful of operators, map the existing partner relationships, agree the T3 scoreboard with Ross, and choose the design-partner shortlist. End on what you would bring back to Deepa at day 90. The guidance makes no claim about your past | It comes straight from the recruiter's "next 18 months" and is the natural first follow-up to the POV |
| B2 | "How would you decide which operator partnerships to prioritise?" | CASE | [generic] | Say your criteria out loud: operator need, fit with the product, commercial upside, ease of reference, and effort to integrate. Then the trade-off you'd accept and the one you wouldn't. Challenge one premise, for example whether every operator should be treated as a partner at all | It tests whether the POV has a selection logic behind it. CASE because it is a live prioritisation |
| B3 | "Partnering directly with operators versus with other suppliers to operators: where does your effort go?" | CASE | [generic] | Answer from your chosen theses. T1 puts operators first and other suppliers in service of them. Name what you would give up by choosing. Answer slot: if the report weighs this, cite its own words. If it doesn't, say so | It probes the premise underneath any operator-partnerships POV. CASE delivery, with CO content where the report speaks to it |
| B4 | "Where would you push back on our strategy team's market report?" | CO | [grounded] | This is your POV divergence, asked straight. Answer slot: the point you would test, in the report's own words, and why. Frame it as what you'd test with operators. Agree with something first | The report came from them. Saying what you'd test rather than reciting it is the differentiation move |
| B5 | "An operator says they'll partner only if we build them bespoke features. What do you do?" | CASE | [generic] | Clarify what the request is and who else would benefit from it. Separate what goes into the core product from what stays bespoke. Price the bespoke part, or decline it. Bring in product before committing. Say what you'd tell the operator and when | It tests the T2 concession live, and it sits where partnerships meets commercials, which is Ross's ground |

### C. Data-Driven Prober (Ross, commercials)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that £4M of influenced revenue was counted." | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Keep "roughly" and "influenced". Answer slot, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Say the weakest assumption before he asks for it. If you don't know how it was counted, say so plainly. That is a full answer, and a better one than a guessed method | F3's headline figure is the obvious target for a commercials push. EXP because it tests whether the claim survives scrutiny |
| C2 | "Of the 40 partners, how many actually produced revenue?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | This is the denominator question. Answer slot: if you know the split, give it and say how you know it. If you don't, say so plainly, and say what you would track here from day one | A prober always asks for the denominator behind a count like F6's. EXP for attribution |
| C3 | "How would you structure the commercials of an operator partnership? Who pays whom?" | CASE | [generic] | Clarify the partnership type first. Then lay out the options as options: referral or revenue share with other suppliers, design-partner pricing for operators, joint investment. For each, say what Kelverton gives and gets, and the term that would worry you. Make no claim about having structured these before | It is Ross's native question. CASE because it is a live design problem with no right answer |
| C4 | "How should we measure you, and what would make the first 18 months a commercial success?" | CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Propose the T3 scoreboard: sourced pipeline, influenced revenue under agreed rules, and design-partner references. Be upfront: "I've never carried a direct quota, only influenced revenue." Then say what you'd be willing to be held to here, as your own position | It meets F4 head-on and is likely from both panellists. CASE because it asks you to design your own scorecard |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, over someone who's spent ten years selling into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause first. Concede in one line: "I haven't sold into rail specifically." Then hold on what the quote carries, the ISV channel from 6 partners to 40, and on your POV. Don't run down the hypothetical rival. If he pushes twice, concede specifically ("they'd know the operators faster than me") and don't fold on the rest | A persona stem built on F5. JD because it scores fit against the role |
| D2 | "That 6 to 40: how much of it was actually you?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold the quote: "I ran the ISV channel and took it from 6 partners to 40." Answer slot: if other people or teams brought in or signed partners, say who and which part was yours. If it was you, say so plainly. Concede the exact share, no more and no less | The attribution stem aimed at F6. EXP because it tests what was actually yours |
| D3 | Interrupting the POV: "This sounds like a payments playbook. Rail doesn't work like that." | CO | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Don't defend the playbook. Agree with the part that's fair: "I haven't sold into rail specifically, so tell me where it breaks." Then point to your anti-pick, no partner-count target, as evidence that you aren't copying the playbook across. Hold your theses and take his correction on the specifics | It is the likeliest interruption, given F5. CO because it tests whether you can think in their market's terms |

### E. Conversational (either panellist, opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | 90 seconds. Beat one: five years in transport consulting, on bus and light rail network planning. Beat two: four years running the ISV channel at a payments company, 6 partners to 40, roughly £4M of influenced revenue. Beat three, as an answer slot: why Kelverton, in your own words | It is the standard opener. A casual question that is still scored |
| E2 | "What did you make of the report we sent over?" | CO | [grounded] | It sounds casual, but it is scored. Answer slot: your anchor and your divergence from the POV, in two sentences. Don't summarise the report back to them | A rapport-register question on the panel's own document |

### G. Values/Behavioral (scattered)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you told a partner something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a moment with a named partner, a stake on both sides, a message you delivered yourself, and a relationship that survived it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem. Partnerships roles get asked it. No values page was read, so it is generic |
| G2 | "When did you put a partner's or customer's outcome ahead of your own number?" | VAL | [generic] | Selection scaffold: a specific decision, what it cost your number, and what you got for it. Keep "influenced" wherever your number comes up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem that fits the "what it means for operators" close. Generic for the same reason as G1 |

### H. Peer Evaluator (Deepa, as your future manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "If an account manager and you both want the same operator conversation, how do you split it?" | CASE | [generic] | Propose principles: one relationship owner per operator, partnerships joining on defined topics, and credit rules agreed in advance (T3). Ask how it works today rather than assuming | A seam stem, asked as a hypothetical. CASE because it is a live design question |
| H2 | "How do you handle credit when a deal spans partnerships and sales?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if your ISV channel had rules for splitting credit with sales, describe them in your own words. If it didn't, say so plainly. Then give the principle you'd propose here | A credit-sharing stem that connects to the "influenced" in F3. EXP because it asks how it actually worked |

---

## Reverse questions

| # | Question | To | Why it lands |
|---|---|---|---|
| R1 | "What would you want operator partnerships to look like in 18 months that they don't today?" | Deepa | It puts your POV next to hers and invites her to correct it. You leave knowing her actual brief |
| R2 | "How is partnerships' commercial contribution measured today: sourced, influenced, or something else?" | Ross | It takes his push seriously and meets F4 on your terms rather than his |
| R3 | "Which parts of the strategy team's report has leadership actually put resources behind?" | Either | It separates the report's analysis from real priorities, which tells you which POV points matter |
| R4 | "What do people new to rail tend to underestimate about operators?" | Deepa | It names F5 before they do and shows you expect a learning curve |
| R5 | "What's changed that makes this role a priority now?" | Deepa | It surfaces the real reason the role exists, which is what you'll be judged against |
| R6 | "Where do partnership deals most often stall commercially here?" | Ross | It gets you his live problem and gives you a natural moment to reply with T3 |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Generated", "closed" or "owned" £4M of revenue | A claim your own quote contradicts: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue", with "influenced" and "roughly" kept. Plus the plain acknowledgment: "I've never carried a direct quota, only influenced revenue." |
| Has carried or hit a quota | A negative you stated, F4 | "I've never carried a direct quota, only influenced revenue." No slot |
| Has sold into rail, or knows operators' buying processes from the selling side | A negative you stated, F5 | "I haven't sold into rail specifically." No slot |
| Has rail or mainline rail experience | Inflated form of F2. Light rail and bus planning widened into "rail" | F2's quote at its own scope. The limit is the pack's own observation, not words for you: the material says bus and light rail network planning. A3's slot stays inside that planning work |
| Worked inside an operator, or ran operator networks | Inflated form of F2, crossing from the consultant's side of the relationship to the operator's | F2's quote at its own scope, with "from the other side" kept as your phrase. A2's and F2's slots ask only whether the consulting work involved operator teams |
| Personally recruited or signed the 34 new partners | Inflated form of F1 and F6. The quote says you ran the channel and took it from 6 to 40, not who signed each partner | F1's quote at its own scope. D2's slot asks which part was yours |
| Set the channel's strategy or the plan behind its growth | Inflated form of F1 | F1's quote at its own scope. F1's slot asks only whether the plan was yours to set |

---

## Sources

**Provided material**
- The recruiter's email, as you quoted it in your message. It is the source for the round format, the panel, the POV brief and the commercials push.
- Your background, as written in your message.
- The strategy team's market report. It was attached to the recruiter's email and has not been shared with me, so none of its content is used.

**Searches sent.** All five were refused, because web search permission was not granted in this session:
- "Kelverton Rail values": refused
- "Kelverton Rail scheduling software train operating companies": refused
- "Kelverton Rail interview process partnerships": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Senior Partnerships Manager rail software job description UK train operators": refused

**Target accounting**

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The search was refused. It would have themed G1 and G2 on published values. The values cheat sheet is absent either way, because the recruiter's email names no values round |
| 2. Kelverton Rail interview process | unavailable | The search was refused. The recruiter's email already establishes this session, so it would only have added context on later rounds |
| 3. Kelverton Rail strategy / recent news | unavailable | The search was refused. It would have moved B2, B3 and the POV theses from generic patterns toward Kelverton's actual priorities |
| 4. Deepa and Ross at Kelverton Rail | unavailable | The search for Deepa was refused, and none was sent for Ross after that. It would have added an interviewer read, adjusted the persona weights from their public profiles, and given one reverse question tied to each person's path |
| 5. Representative Senior Partnerships Manager JD | unavailable | The search was refused. It would have turned F4, F5 and F6 from generic into inferred requirements, quoted from a real posting |

---

## Upgrade menu

- **The JD text**: F4, F5 and F6 become grounded rows quoted from the posting, the coverage table checks against the real requirement list, and any gates such as location or travel are surfaced.
- **The market report's key points**, pasted or summarised in your words: the POV's anchor, divergence and operator close are built on its actual claims, B3, B4 and E2 get specific guidance, and a grounding brief section is added.
- **Web search allowed**: values, strategy, and Deepa's and Ross's public profiles. That gives an interviewer read, persona weights read from their footprints, tailored reverse questions, and a CO bank grounded in Kelverton's current moves.
- **Deep research**: up to 6 more searches and 2 more fetches, several more minutes, covering the strategy brief, the panellists' talks and writing, loop reports and recent org changes.
- **Your answers to the slots**, said outside a drill: how the £4M was counted, how many of the 40 partners produced revenue, and whether the consulting work involved operator teams. C1, C2, D2, A2, A3 and F1 to F3 become story-mapped rather than slotted.
- **An artifact you can cite figures from**, such as a partner-programme performance report or a deal sheet, without sharing anything confidential: F3 and F6 could move from medium to high confidence.
- **A dossier**: a tuesday-dossier.md from job-underwriter would replace the inferred highest-ROI objection with an evidence-derived one and add an underwriter-checked list of prohibited claims. It is optional; this pack is complete without it.
