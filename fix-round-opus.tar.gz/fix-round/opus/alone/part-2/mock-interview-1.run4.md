I've saved the full mock-interview pack: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-1-denied-f73a7216/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`

It's built only from what you gave me. The four web searches I tried (Northwind's values, its interview process, Dan's public profile, and a check that your research note is current) were all blocked by permissions. So Dan's profile and the company priorities are used as you described them, unchecked.

- **Questions:** 24 in total, grouped by seven interviewer styles and tagged by what each one is scoring. Each has answer guidance and a rationale for including and tagging it. The heaviest weight goes to Dan as a data-driven prober and as a peer under the same VP. The case questions lean toward pricing and packaging, which is his background.
- **Highest-priority prep:** question D1, "consumer-tech product strategy, no sales-ops or quota-setting — why you for B2B GTM?" It goes after the one gap your notes state, in the area Dan himself owns. Its guidance has Priya concede that gap first, then hold on her real experience, and it rehearses three follow-ups.
- **Tightest wording:** the ~$400M figure is kept exactly as your notes put it: she *proposed* the change, and it was *credited with* the uplift. The carrier work stays "built a revenue model", not "designed a partner motion". A short table lists the inflated versions the pack won't coach.
- **Questions for Dan:** six, including one on his pricing background, one on his startup chapter, and one asking how she could help his team.

If you enable web search, the values-themed questions and the strategy questions can be checked and sharpened against Northwind's own pages.

Say the word and I'll play Dan as the skeptic on D1, the question the pack names as its highest-priority prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for Priya to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya · **Interviewer:** Dan Kovac, Director of Sales Strategy. He is a **peer**, and both of you would report to the same VP · **Format:** one 60-minute conversation

---

## How to use this pack

- **Personas** describe *how* a question is asked: the style, register and pressure. **Types** describe *what* is being scored. Each question carries both, so you rehearse the content and the delivery.
- **Type key:**
  - **VAL**: behavioral or values alignment. Does past behavior show the company's values?
  - **EXP**: work-experience deep-dive. Do the claims hold up, and what was actually yours?
  - **JD**: role or JD-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. Can you think at Northwind's altitude about its priorities and competitors?
  - **CASE**: a live problem from the actual role, scored on structure and reasoning.
- **Provenance labels:** `[grounded]` traces to your inputs. `[inferred]` is a named derivation from them. `[generic]` is a role-family pattern with no claim about Priya or Northwind.
- **Answer slots** mark where the pack does not know what Priya did. Each slot gives her two honest branches to answer from in the interview. They are instructions for the interview, not questions for you.
- **The guidance is scaffolding, not a script.** Every clause about Priya's past rests on a sentence from your notes, quoted in that row. She should say it in her own words and add nothing she didn't do.
- Question IDs use one letter per persona: A, B, C, D, E, G, H. The letter F is skipped so the IDs don't collide with fit-snapshot rows F1 to F7.

---

## Fit snapshot

The requirements are quoted from the JD highlights in your message. Evidence is quoted exactly from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The notes say product strategy and ops, not GTM ownership. Her words stay at that scope: "Nine years in product strategy and ops at a large consumer-tech company, after two in strategy consulting." On the store-surface change, the verbs are hers: she *proposed* it, and it was *credited with* the uplift. Answer slot: the JD's "own GTM strategy" line makes a probe on go-to-market decisions likely. If any of her product-strategy work set how a product went to market, she says which part and how she decided, in her own words. If none did, she says so plainly and stays with the product strategy and ops she did. No inspectable artifact, so expect a probe |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Your material doesn't show whitespace or account-lifecycle analysis either way. Answer slot: if she has found untapped segments, accounts or uses in past work, she says what she looked at and what she found, in her own words. If she hasn't, she says so plainly and moves to how she would approach it, as a plan (rehearsed in A4 and C3) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. But a skill claim with nothing inspected behind it invites a live test, so expect one (A4). She says it plainly: SQL and Tableau are tools she is skilled in. Then she shows it by working the problem aloud rather than describing her skill |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model used in negotiations is adjacent to designing a partner motion. It isn't the same work. Her words stay at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD marks partner-motion design as required, so expect a probe on whether any part of the partner arrangement was hers to shape. If any part was, she says which and how, in her own words. If none was, or the model fed decisions others made, she says so plainly and stays with the model she built |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already speaks to the requirement. She leads with it in its own terms: she set annual volume targets, with cross-org consensus. Expect a probe on how the consensus was reached, which is an answer slot in B1. Note that volume targets are not quotas (see F7 and the prohibited list) |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Using AI tools daily is adjacent to AI product or GTM experience, which Northwind's Compass launch makes relevant. Her words: "I use AI tools daily." Answer slot: expect "which tools, for what". She answers in her own words. If her use is her own analysis and productivity rather than shipping or selling AI, she says so plainly |
| F7 | Fluency in classic sales-strategy mechanics (quota setting, sales ops), a role-family expectation for a GTM lead who sits beside a Director of Sales Strategy | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | This is a stated gap, and wording can't close it. Her words: "I haven't done classic sales-ops or quota-setting." After that comes how she would work with Dan's team on it, said as a plan and never as a past. No claim to quota work, and "volume targets" is never offered as a substitute |

---

## Reading the interviewer

Everything below comes from the profile summary in your message. The search to check Dan's public footprint was refused, so nothing here is independently verified.

| Signal | What it implies for this conversation | Provenance |
|---|---|---|
| Director of Sales Strategy; same VP as the role; a peer | He is weighing what Priya costs and adds to *his* team's work. Expect questions about the seam, collaboration and credit. Expect gaps probed collegially rather than adversarially, and plan a reciprocity reverse question | [grounded] your message |
| Self-describes as "relentlessly data-driven" | Every number gets taken back to its assumptions. The ~$400M figure will be probed, and so will any number Priya uses in a case. Naming the weakest assumption first is the single best delivery move with him | [grounded] your message |
| Career spine in pricing and monetization roles | Cases will likely tilt toward pricing, packaging and unit economics. Compass packaging and the response to bundling are his home ground. Expect him to know more than Priya does about the pricing mechanics, so calibrated candor beats bluffing | [inferred] from the career pattern in your message |
| One early-stage-startup chapter | Builder stories tend to land with people who have done 0→1 work. Expect a scrappiness probe aimed at a big-company background (D4) | [inferred] from the career pattern in your message |
| Mirror opportunity: shared vocabulary | Monetization is common ground. F4: "built a partner-level revenue model used in carrier negotiations". Priya can describe that model in plain revenue-model terms: what went in, what it was used for. That is his native language. A shared career *jump* isn't offered, because no fit-snapshot row shows her side of a startup or pricing-role move | [grounded] your message |

---

## Persona table

**The loop.** Your message describes one 60-minute conversation with Dan. That defines the loop for this pack, and no archetype was assumed. No values-style round is detected, so the values cheat sheet section is dropped. Values questions stay in the pack at low weight.

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | "Walk me through how that was counted." He goes two levels deeper on every figure | **High.** A peer prior, plus his self-described "relentlessly data-driven" style | Know what she can and can't say about how the ~$400M was counted. Name the weakest assumption before he does. Offer to work a SQL problem aloud |
| Peer Evaluator (B) | The seam between the two teams, "what do you need from me", how disagreements and shared credit are handled | **High.** He is a peer under the same VP. This is the core of what a peer is scoring | Use reciprocity framing. Propose seam *principles* rather than claiming to know the seam. Use only disagreement stories her material carries, or answer slots |
| Case / Strategist (C) | Live pricing, packaging and partner problems on Compass, the new lines and bundling | **Medium-high.** His pricing and monetization spine, plus three stated company priorities | Clarify → objective → segmentation → approach → metrics → risks. Think aloud. Challenge one premise respectfully per case |
| Skeptic (D) | Quiet probing of the move from consumer-tech product strategy to B2B sales strategy, the partner-motion requirement, and motivation | **Medium-high.** F7 is a stated gap in exactly the area Dan owns, and F4 is the JD's only "required" | Rehearse D1 until it's boring. Concede the stated gap plainly, hold on the quotes, and give a ramp plan said as a plan |
| Pressure (E) | "How much of that was actually you?" and time-boxed "why you" questions | **Low-medium.** Peers rarely run stress interviews, but a data-driven interviewer will press on a big number | Pause, restate, anchor in the quote, and hold through two follow-ups before conceding anything |
| Conversational (G) | Opening "walk me through your journey", or casual AI talk | **Low-medium.** Likely as the opener and the close of a 60-minute chat | A pre-built 90-second arc. Treat casual questions on the JD's AI line as scored |
| Values / Behavioral (H) | "Tell me about a time…" questions on unpopular truths or customer trade-offs | **Low.** Not a values round, and Northwind's values weren't retrievable | Use selection scaffolds with honest branches |

---

## Question banks

### A — Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background mentions a store-surface change you proposed that was credited with about $400M in ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the quote's verbs exactly: she *proposed* the change, and it was *credited with* a ~$400M ARR uplift. Don't upgrade them to "drove" or "delivered". Answer slot, the four things a figure raises: how the figure was counted; what it is sensitive to; the assumption behind it she would defend least; which part was hers. She answers each in her own words. If she doesn't know how it was counted, she says plainly that the figure was credited by others and she can speak to the proposal itself. That is an honest branch, not a weakness. Don't explain a method she can't repeat under a second question | The headline metric on her profile, in front of a self-described data-driven interviewer, is the most likely first probe. EXP because it tests attribution and the integrity of the number, not role fit |
| A2 | "Which assumption behind that $400M would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | This is the weakest-assumption move, and she should make it before he asks. Answer slot: she names, in her own words, the assumption she trusts least, and says what would change if it were wrong. If she doesn't know the assumptions behind the credited figure, she says so plainly and names what she *would* check first. Volunteering a limit earns credibility with this interviewer | It's the natural second level of A1 and tests whether she knows her own number's soft spots. EXP for the same reason as A1. Kept separate so it gets its own rehearsal |
| A3 | "Tell me about the partner-level revenue model you built for carrier negotiations. What went into it?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4 with the beats the quote states: she built it; it was partner-level; it was a revenue model; it was used in carrier negotiations. Answer slot: the JD's partner-motion line and Dan's style make a probe on the model's inputs and how it was checked likely. If she can describe them, she does, in her own words. If parts were inherited or never validated, she says so plainly. Answer slot: if she was in the negotiations or shaped the terms, she says what her part was. If she wasn't, she says the model was used by the people negotiating | F4 is her closest evidence to the JD's only "required" item, and a model is something a pricing-minded interviewer can take apart. EXP because it verifies what the model was and what was hers |
| A4 | "Say you have an accounts table, a product-usage table and contract renewal dates. How would you find expand whitespace for one of the new product lines? Talk me through the SQL logic and what you'd show in Tableau." | CASE | [generic] | Structure it before writing any logic. First the definition: whitespace means accounts that fit the new line's profile and don't yet have it. Then the joins: accounts to usage to contracts. Then filters for fit signals, such as usage of adjacent products, size and segment. Then sequence by renewal date, so the expand play lines up with the renew motion. Sanity checks: row counts after each join, duplicate accounts, and how you treat parent and child accounts. Tableau view: a whitespace matrix of segment by product held, with a renewal-timing slice. Say out loud where the data is likely messy. That makes the answer speakable and asks nothing about her past | Covers the SQL and Tableau and whitespace requirements (F3, F2) as a live test, which is how a data-driven peer checks a skill claim. CASE because it scores reasoning delivered live. Generic because it is a problem pattern, not a fact about Northwind's data |
| A5 | "Tell me about a time an analysis you ran turned out to be wrong, or nearly was." | EXP | [generic] | Selection scaffold. Pick an analysis, ideally in SQL or Tableau, where something was wrong or nearly wrong. It needs the moment she noticed, what she checked, and what changed in the decision. If no such time comes to mind, she says so plainly, then describes how she checks her work before a number reaches leadership, as a practice she would follow | Data-driven interviewers test humility about data as well as skill. The theme comes from the JD's "independent analysis" line. EXP because it asks for her history. Generic because no quote carries such a story |

### B — Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams would sit side by side under the same VP. Where's the seam between Emerging Products GTM and Sales Strategy, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam *principles* rather than claiming to know the seam: one shared data source for pipeline and bookings; clear decision rights by product line; disagreements go to the VP jointly, as one memo with both views, never separately. Then the evidence: she set annual volume targets with cross-org consensus. Answer slot: expect "how did you get consensus". If there was real disagreement along the way, she says what it was and what her part in resolving it was, in her own words. If consensus came without a fight, she says so plainly | This is the core peer question: turf awareness and disagreement style with an equal. F5 is the evidence. JD type because it scores "strong cross-functional influence", with a CASE-style principles section |
| B2 | "What would you need from my team in your first 90 days, and what would you give back?" | JD | [inferred] | Give both halves, and the "give" half carries more weight. *Need:* access to bookings and pipeline data, the current coverage model, and pricing guardrails. Phrase these as asks, not as claims about what exists at Northwind. *Give:* whitespace analysis on the new lines that his team can use; a partner motion designed to complement his direct sellers rather than collide with them; a shared definition of land, adopt, expand and renew. Close by asking what would be most useful to him | Reciprocity is the peer evaluator's central test: does the hire add to or subtract from his load? Inferred because the needs are derived from the JD's scope, not from knowledge of Dan's team |
| B3 | "How do you handle credit when the work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Her own quote shows the right attribution: she proposed the change, and the change was credited with the uplift. Use "we" for context and "I" for her contribution. Answer slot: if other teams built or launched the change, she says who did what, in her own words. If she doesn't know how the work was split, she says she can speak to the proposal | It's a peer stem, and her headline figure is exactly where credit questions arrive. VAL because it scores collaboration behavior. The figure links it to A1 and E1 |
| B4 | "The new lines will need a partner motion. How do you keep partner-sourced deals from colliding with my direct sellers?" | CASE | [generic] | Structure: segment where partners lead versus where direct leads (by size, region or use case); rules of engagement and deal registration; keep comp roughly neutral so reps don't fight partners; a joint escalation path; metrics for partner-sourced versus partner-influenced deals, plus conflict incidents. Ask what rules exist today before proposing new ones. That respects his turf and clarifies before structuring | Channel conflict is where partner-motion design and Sales Strategy meet, so a peer is likely to raise it. CASE because it is a live design problem. Generic because it doesn't depend on Northwind's actual channel rules |
| B5 | "If Compass ends up bundled into the core products, who owns the pricing call: Emerging Products or Sales Strategy?" | CO | [grounded] research note in your message: AI copilot launch "Compass"; main threat is bundling by a larger platform vendor | Don't claim the turf, and don't give it away either. Suggested framing: pricing is a joint call with a single owner, and Dan's function is the natural owner of core pricing. Emerging Products brings adoption and whitespace data on Compass and a view on attach versus include. Then ask how pricing decisions get made today | It tests turf awareness on his home ground, pricing, using a stated company priority. CO because it requires knowing Compass and the bundling threat |

### C — Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles a comparable capability for free. How do you price and package one of our new product lines against that?" | CASE | [grounded] research note in your message: main competitive threat is bundling by a larger platform vendor | Clarify first: which line, which segment, and where we win on depth today. Options: compete on depth and charge a premium for it; build an entry tier to land, then expand; partner-led distribution; selective free elements to protect renewals. Choose by segment. Metrics: win rate against the bundle, discount depth, net revenue retention. Risk: chasing the bundle on price works against the profitability priority. Name that tension aloud, because Dan will | This is the competitive threat in your research note, and pricing and packaging is Dan's native ground. CASE delivery on CO content. The strongest differentiator question available without further research |
| C2 | "Compass is launching. Paid add-on, tier upgrade, or included? How would you decide, and what data would you pull?" | CASE | [grounded] research note in your message: AI copilot launch "Compass"; goal of reaching profitability | Objective first: adoption, revenue, or defense against the bundle. These conflict, and the profitability priority weighs on the choice. Data: usage of comparable features, willingness-to-pay tests, cost to serve per query, and the effect on renewals. A plausible structure: include a limited tier, sell the full capability as an add-on, and revisit at renewal. Give this as a hypothesis to test, not a verdict. Name the assumption she would defend least | Two stated priorities collide in this question, and it's a monetization question for a monetization-minded interviewer. CASE, with CO and the JD's AI line in the content |
| C3 | "Design year one for a new product line across land, adopt, expand and renew. Where's the whitespace, and what would you measure?" | JD | [grounded] JD highlights in your message: "identify whitespace across land/adopt/expand/renew" | One stage at a time. Land: which accounts and entry offer. Adopt: activation milestones. Expand: whitespace from the existing install base, as in A4. Renew: risk signals and timing. One metric per stage, such as new logos, activation rate, expansion pipeline and gross retention. Tie it to the enterprise-expansion priority. Say what she would want to learn from Dan's team first. On her past, F2 is a discovery gap: if she cites prior work, it is her own instance, answered per F2's slot | It is the JD's own responsibility, asked as a case. JD type because it scores a stated requirement directly; CASE delivery |
| C4 | "Design the partner motion for one of the new lines: which partner types, what they're paid for, and how you'd know in two quarters whether it's working." | JD | [grounded] JD highlights in your message: "partner-motion design experience required" | Partner types: resellers, systems integrators, and technology or marketplace partners, ranked by fit for the line. Economics: what partners get paid for (sourcing, influence, delivery) and margin limits given the profitability goal. Enablement and rules of engagement (see B4). Two-quarter signals: partner-sourced pipeline, time to first deal, and conflict rate. If she references her model, the quote's scope applies: she built a partner-level revenue model used in carrier negotiations. Nothing more | It covers the JD's only "required" item as a live design, which is how she can show partner thinking without claiming a past she doesn't have (F4). JD type because it scores the requirement; CASE delivery |

### D — Skeptic (4)

**D1 is the highest-ROI prep in this pack.** It is the single most predictable objection to Priya, and it targets exactly the competency Dan owns.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've come from consumer-tech product strategy, and you haven't done classic sales-ops or quota-setting. Why should I believe you can run GTM strategy for B2B data-infrastructure products?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" | **Concede first and plainly:** "I haven't done classic sales-ops or quota-setting." **Then hold on what her material carries:** nine years in product strategy and ops at a large consumer-tech company, after two in strategy consulting; she built a partner-level revenue model used in carrier negotiations; she set annual volume targets with cross-org consensus. She lists these as facts, not as proof, and lets Dan draw the inference. **A ramp plan, said as a plan:** in the first weeks, learn his team's coverage and quota model from his team; pull bookings data herself in SQL; sit in on deal reviews for the new lines. **Follow-up 1**, "Volume targets aren't quotas": agree, they are different work, and don't argue the point. **Follow-up 2**, "So how would you set a quota for a new line?": she doesn't bluff. Say that's his team's discipline, and that she would bring the new line's whitespace and adoption data to that conversation. **Follow-up 3**, "Why not hire someone who's done it?": hold on the role as the JD scopes it, which is GTM strategy for new lines, with partner design and whitespace analysis. Then ask what he would want in that seat. Never fold to "you're right, I'm not a fit" | F7 is a stated gap sitting directly on Dan's own competency, and F1 is a transferability gap. A peer pricing what the hire adds will raise it in some form. JD type because it scores the role's core requirement against her background; it gets the deepest rehearsal because the concession has to be exact and calm |
| D2 | "Partner-motion design is listed as required. What partner motion have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of the partner arrangement was hers to design (structure, terms, incentives), she says which part and how, in her own words. If none was, or the model fed decisions others made, she says so plainly. That is a limit, not a confession. Then offer to show her thinking live: "Here's how I'd design one for your new line" (C4). Hold through two follow-ups by returning to the model, never by adding to it | F4 is the JD's only "required" item and a transferability gap, so it's the second most predictable objection. JD type because it scores a stated requirement directly |
| D3 | "Why leave a large consumer-tech company for a 3,000-person B2B infrastructure company, and why now?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Her material doesn't state her motivation, so this is all answer slot. She gives her real reasons for B2B, for emerging products, and for now, in her own words. They should be consistent with what she told the recruiter. What lands with a peer: a reason tied to the work itself (new lines, partner design, AI) rather than escape from the old job. If the honest reason includes something about the old role, she says it briefly and without blaming anyone | "Why leave, why here, why now" is the Skeptic's standard motivation probe. A nine-year tenure (F1) makes it more likely. JD type because it scores fit for this role |
| D4 | "Emerging products here won't have the resources you're used to. Tell me about a time you got something done with almost no resources." | EXP | [generic] | Selection scaffold. It needs a real constraint (people, budget or data), something she did herself to get around it, and an outcome. Her consulting years may hold one, but only if she has a real instance. If no such time comes to mind, she says so plainly, then gives the leanest project her material does carry, or how she would run the new lines lean | Dan's startup chapter makes a scrappiness probe likely for someone coming from a large company. EXP because it asks for her history. Generic because no quote carries such a story |

### E — Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M. Honestly, how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause first. **Hold:** "I proposed the change. The uplift was credited to the change." **First push:** repeat the same two facts calmly, without adding to them. **Second push, concede specifically:** answer slot. If others built, tested or launched it, she names that plainly, in her own words. If she doesn't know how the credit was assigned, she says so. Never fold to "it was a team thing" if the proposal was hers, and never claim the build | This is the persona stem aimed straight at her headline figure. A data-driven peer may press harder than he means to. EXP because it scores attribution honesty under pressure |
| E2 | "Sixty seconds: why you over an internal candidate who already knows our sales motion?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "skilled in SQL/Tableau" | Time-box to 60 seconds. Hold on what she brings that the JD asks for: partner work, at the quote's scope (she built a partner-level revenue model used in carrier negotiations); independent analysis (she is skilled in SQL and Tableau); and a view from outside the current motion. Concede, unprompted, that an insider knows the motion. She would learn it from Dan's team. Don't disparage internal candidates | It's a likely time-boxed pressure probe, and her stated gap (F7) is exactly what an internal candidate wouldn't have. JD type because it scores fit against the requirements |

### G — Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc. Two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company. Two moments: she built a partner-level revenue model used in carrier negotiations, and she proposed a store-surface change credited with a ~$400M ARR uplift. End on why this role, in her own words (see D3). Rehearse it until it's 90 seconds, and stop there. Dan will pick the thread he wants | Almost certainly the opener in a 60-minute peer chat, and casual questions are still scored. EXP because it sets up every later probe. The quotes keep the arc from inflating |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | She says plainly that she uses AI tools daily. Answer slot: which tools and for what, in her own words. If that is analysis and productivity rather than building or selling AI, she says so. Then bridge to Compass as a forward-looking view, not experience: how she would think about its adoption and packaging (C2) | The JD lists AI as a plus and Compass is a stated priority, so a casual AI question is scored. JD type because it covers the plus-skill |

### H — Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. It needs a named stake, the moment she said it, how it was received, and what happened after, with the relationship intact. Her material doesn't show whether any of her quoted work involved an unpopular message, so she should pick only a real instance. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she would handle it | It's a persona stem that tests spine with seniors, which matters for "strong cross-functional influence". VAL because it scores behavior. Generic because Northwind's values weren't retrieved and no quote carries such a story |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. It needs the metric, the customer interest it conflicted with, her decision, and its cost. If no such time comes to mind, she says so plainly, then explains how she would weigh customer interest against targets in the new lines | It's a persona stem, and the tension between profitability and adoption in your research note makes trade-off judgment relevant. VAL and generic for the same reasons as H1 |

### Requirement coverage

| Requirement (JD highlights, your message) | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | D1, C3, G1, D3 |
| "identify whitespace across land/adopt/expand/renew" | C3, A4 |
| "run independent analysis in SQL and Tableau" | A4, A5 |
| "partner-motion design experience required" | D2, C4, B4, A3 |
| "strong cross-functional influence" | B1, B3, H1 |
| "AI experience a plus" | G2, C2 |
| Company priorities from your research note (enterprise expansion, Compass, profitability, bundling threat) | C1, C2, C3, B5 |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "Coming from pricing and monetization, how do you think about packaging Compass against a bundled competitor?" | It's tied to his career spine and invites him to talk about his own expertise. It also shows she knows the threat |
| R2 | "What could someone in this role do in the first month that would genuinely help your team?" | The reciprocity question. It answers the peer's real scoring question (load added or reduced) and lets him define success |
| R3 | "Where do Sales Strategy and Emerging Products step on each other today, if anywhere?" | It shows seam awareness without claiming to know the seam, and the answer tells her where to tread carefully |
| R4 | "Your startup chapter: what from it do you still use in a company of 3,000?" | It's tied to his path and turns the scrappiness probe (D4) into a peer conversation |
| R5 | "How does the VP decide between growth and profitability when they conflict on a new product line?" | It shows she has absorbed the stated priorities, and it reveals how decisions really get made above them both |
| R6 | "What data do you wish you had on the install base that you don't have today?" | It speaks to the data-driven way he describes himself, and it points to the SQL and whitespace work she would bring |

---

## Prohibited claims

Built from the fit snapshot. These are claims this pack will not coach, because each one breaks on the first follow-up.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove, delivered or owned the ~$400M ARR uplift; implemented the store-surface change | Inflated form of F1 | F1's quote at its own scope: she proposed the change, and it was credited with the uplift. The pack observes that the material says she proposed it, not that she built it. A1, A2 and E1 keep her answer slots inside the proposal |
| Designed a partner motion; ran carrier negotiations | Inflated form of F4 | F4's quote at its own scope: she built a partner-level revenue model used in carrier negotiations. The pack observes that the material says model, not motion. A3's and D2's slots stay inside the model |
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. Her F1 slot stays inside that work |
| Has sales-ops or quota-setting experience; annual volume targets were quotas | A negative stated in F7, plus an inflated form of F5 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting." F5's quote stays as volume targets with cross-org consensus |
| Has built, launched or sold AI products | Inflated form of F6 | F6's quote at its own scope: she uses AI tools daily. G2's slot stays inside her use of them |

---

## Sources

- **Provided documents:** your message, which gave the JD highlights, your notes on Priya, Dan's profile summary, and your research note on Northwind's priorities and competitive threat.
- **Searches sent:**
  - "Northwind Data company values": refused
  - "Northwind Data interview process GTM strategy": refused
  - "Dan Kovac Northwind Data sales strategy": refused
  - "Northwind Data Compass AI copilot launch" (a freshness check on your research note): refused
- No fetches were sent. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The call was refused. Official values would have themed the H bank by name and made its scaffolds Northwind-specific. A values cheat sheet would still not apply, since no values-style round is detected |
| 2. `Northwind Data interview process GTM strategy` | unavailable | The call was refused. It would have shown whether Dan's conversation is a documented case or peer round. The loop is still set by your description of one 60-minute conversation |
| 3. `Northwind Data strategy` / recent news | unavailable | The call checking your research note was refused. The note is used as given for C1, C2, B5 and R1, but its freshness and the Compass details are unverified |
| 4. `Dan Kovac Northwind Data` | unavailable | The call was refused. A footprint check would have confirmed or sharpened the interviewer read and might have surfaced talks or posts for R1 and R4. The read rests only on your summary |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied set the fit snapshot's requirements and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search, then rerun L1:** targets 1 to 4 become live. You'd get Northwind's official values to theme H1 and H2, a check that the Compass and priorities details are current for C1, C2 and B5, and a confirmed public profile for Dan that sharpens the interviewer read and R1 and R4.
- **Deep research (L2):** up to 6 more searches and 2 more fetches, several more minutes. It would add a grounding brief with Northwind's current numbers and language, Dan's talks or writing, and loop reports for this role family. With it, C1 and C2 move from your note to sourced strategy.
- **The full JD text:** mid-list requirements and tools the highlights may omit, each turned into a question. The coverage table becomes a check against the real list.
- **Priya's CV, or her own answers to the answer slots:** her own sentences replace the coach's-notes quotes. The slots in A1, A2, A3, B1, D2, D3, E1 and G2 become story-mapped guidance, and F2 can move from `discovery`.
- **An inspectable artifact for her strongest claims**, such as a redacted outline of the partner-level revenue model or a write-up of the store-surface proposal: F1 and F4 can rise from `medium` to `high`, with her own talking points on how the ~$400M was counted.
- **Recruiter guidance** (focus areas, any case or presentation expected in Dan's hour): coverage of any graded deliverable, and persona weights reset to the stated format.
- **Prep time available:** a prioritized triage schedule at the top of the pack.
- **A dossier from job-underwriter:** an evidence-derived highest-ROI objection instead of an inferred one, and a binding prohibited-claims list from verified evidence. Never required.
