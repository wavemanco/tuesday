Status: I've read the skill's rules for the prep pack and the dossier handoff. Next I'm reading the evidence rules, then running a few searches on Quartzline, then I'll build and save the pack.
I've built your prep pack and saved it as a file. It assumes a 45-minute conversation with the hiring manager, built from your dossier. The three company searches I tried were blocked because search permission wasn't granted. So the company and case questions are built from the job description in your dossier, not from anything about Quartzline itself, and they're labeled `[generic]`.

**What the pack holds:**
- **22 practice questions** across seven interviewer styles.
- **A fit snapshot** comparing each job requirement with your confirmed evidence.
- **Six questions to ask the hiring manager.** The first two come from the dossier's open risks: who decides what versus the two squad leads, and how adoption is measured today.
- **A list of claims the pack won't coach**, with the honest version of each.

**Where to spend your time:**
- **Rehearse A1 most.** It's the objection your dossier named: you've never held the PM title or owned a roadmap. The coached answer is to admit both plainly first, then describe the 30+ integrations and the quarterly sessions at their actual scope. The fallback lines for each follow-up are written in the pack.
- **Don't use "seven years."** That figure appears only in the dossier's summary, not in any confirmed entry, so the pack leaves it out. State your tenure in your own words.
- **Today is Thursday, November 12.** If that's the interview day, rehearse A1, A2, E2 and the first two questions to ask the hiring manager before anything else.

I can play the Skeptic on A1 for a live practice round.
I can also save an updated `tuesday-dossier.md` recording the objections and gaps this prep found, for later sessions.
If you'd like the pack as a Word document, I'll convert it.

Files are in this folder:
- quartzline_product-manager-platform-apis_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview Prep Pack — Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager, Thursday. Interviewer name not given.
**Built from:** your `tuesday-dossier.md` (v1.1). Web research was attempted and blocked, so nothing here about Quartzline itself comes from outside your dossier.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who is asking and in what register. **Types** describe *what is being scored*.
- **Type key:**
  - **VAL**: behavioral or values alignment. Does past behavior show the company's published values?
  - **EXP**: work-experience deep-dive. Do your claims hold up, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. How deep did your homework go?
  - **CASE**: live problem from the role. Structure and reasoning, out loud.
- **Provenance labels:** `[grounded]` traces to your dossier. `[inferred]` is this pack's derivation, and the derivation is named. `[generic]` is a role-family pattern with no claim about you or Quartzline.
- **Answer slots** are instructions for the interview, not questions for you to answer now. Each has two honest branches. Answer the one that's true.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Highest-ROI prep in this pack: A1.** Your dossier named this objection. Rehearse it until it's boring.

---

## Fit snapshot

Requirements are quoted from your dossier's `role_profile`. Evidence is quoted exactly from `verified_candidate_evidence`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | transferability | Bridge, with its limit named, as your dossier's condition says: adjacent work, never PM experience. Give the limit first and plainly: "I haven't held the PM title" (from prohibited_claims: "Having held a product manager title or role"). Then the two quotes at their own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live, and you ran quarterly sessions feeding client evidence to product. The sessions are medium confidence: confirmed, but with limited inspectable proof. Before anyone asks, say that they were input to product. Derivation: the dossier rates the transfer to R1 low. |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area. Words: "I haven't owned a product roadmap" (from prohibited_claims: "Having owned a product roadmap"). Then a ramp plan, said as a plan and never as a past (A2). No bridge and no answer slot. The dossier already looked and found nothing. |
| F3 | "Shipped API or platform products" — dossier role_profile R2 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | Your material shows integrations built on the vendor's APIs. It doesn't show the API product being shipped, and your words stay at that scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: R2 makes a probe on the API itself likely. If any requirement you scoped in those integrations went back and changed the vendor's API, say what changed and what part was yours, in your own words. If none did, or you don't know, say so plainly and stay with the integrations. |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | discovery | The quote names architecture on REST API integrations. It doesn't show whether you worked from the API docs and schemas. Answer slot: R3 makes a probe on docs and schemas likely. If you read, wrote or worked from them in those integrations, say how, in your own words. If you didn't, say so plainly and describe the architecture step as you did it. |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | discovery | The quote covers clients, from scoping to go-live. It says nothing about engineering or sales. Answer slot: R4 makes a probe on engineering and sales likely. If you worked with either during those integrations, say who and what you handled between them, in your own words. If you didn't, say so plainly and stay with the clients. |
| F6 | "Agile delivery experience" — dossier role_profile R5 (preferred) | none given | low | [grounded] | discovery | Clarify strategy (dossier). No verified entry mentions agile. Answer slot: R5 makes a probe on agile delivery likely. If your work ran in sprints or another agile cadence, say how, in your own words. If it didn't, say so plainly. Then say what you'd want to confirm about how Quartzline's squads run: cadence, and who owns the backlog. |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The material shows sessions feeding evidence to product. It doesn't show discovery for a product you owned, and your words stay there: "Every quarter I ran roadmap-input sessions that fed client evidence to product." Medium confidence, so expect a probe, and name the limit yourself first: input, not decisions. Answer slot: the discovery line makes a probe on how the sessions ran likely. If the format was yours, describe it in your own words. If someone else set it, say so plainly and describe what you ran. |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | The quote says requirements for client integrations, not specs for a squad. Hold the line: "I haven't set prioritization for an engineering squad" (from prohibited_claims: "Having set prioritization for an engineering squad"). Answer slot: the specs line makes a probe likely. If engineers built against the requirements you wrote during scoping, say who and how, in your own words. If they weren't build specs, or nobody built against them, say so plainly and stay with the integrations. |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Your material is silent here, which makes this a discovery gap, not a capability gap. Answer slot: the JD line makes a probe on adoption measures likely. If you have tracked any usage or adoption measure, say what was counted, in your own words. If you haven't, say so plainly and say what you'd measure first (B3). |

---

## Persona table

The loop for this session comes from your own words: one 45-minute conversation with the hiring manager. Nothing in your material documents a values round, so this pack has no values cheat sheet.

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the missing PM title and roadmap | **High.** Hiring-manager rounds put Skeptic among the dominant personas [generic], and your dossier named the objection outright (A1) | Rehearse A1 until it's boring. Concede what the dossier says you haven't done before they say it. Bridge only from the quoted rows (F1, F3, F7, F8) |
| Case / Strategist | Live problems from the JD: roadmap, adoption metrics, a partner request against full squads | **High.** Hiring managers bring live problems from their actual roadmap [generic]. The JD lists four responsibilities that turn naturally into cases | Clarify, then objective, segmentation, approach, metrics, risks. Think out loud. Challenge one premise per case, and decision rights is the natural one |
| Data-Driven Prober | "30+ — how was that counted?" and "what's in the playbook?" | **Mid.** F1, F3 and F8 rest on a single quoted figure, and the playbook in C3 is inspectable. Both invite depth | Know what you can say about how the 30+ was counted, and say plainly where you don't know |
| Conversational | "Walk me through the journey," "why product, why now" | **Mid.** A 45-minute conversation leaves room for a biography opener, and it still gets scored [generic] | A 90-second arc built only from the quoted rows (D1) |
| Pressure | Time-boxed "why you over a real PM" | **Low.** Not the hiring-manager prior, but it's the same objection as A1 at speed | Pause, restate, hold on the quotes, concede only what the dossier says is true |
| Values / Behavioral | Competing-stakeholder story | **Low.** No values round detected. R4 still invites a behavioral question | Pick a story from your quoted work, or say plainly that none fits |
| Peer Evaluator | "How will you work with the squad leads?" | **Low.** The squads aren't in the room, but the decision-rights unknown makes the hiring manager likely to ask on their behalf | Propose principles for the seam instead of claiming to know where it sits |

---

## Question banks

### A. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Ran quarterly roadmap-input sessions feeding client evidence to product" | **Highest-ROI rehearsal. Your dossier named this objection.** (1) Concede first, plainly, without apologizing: "That's right. I haven't held the PM title, and I haven't owned a product roadmap" (from prohibited_claims: "Having held a product manager title or role" and "Having owned a product roadmap"). (2) What you have, at the quotes' scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live, and you ran quarterly roadmap-input sessions feeding client evidence to product. Describe these and let them draw the inference. Don't say they prove you can do the job. (3) Name the limit of the sessions yourself: they were input to product. (4) Close with a plan, said as a plan: how you'd learn decision rights with the squad leads, run partner discovery, and set an adoption baseline in the first 90 days. **Follow-up 1:** "So you've never made a prioritization call?" Hold: "Not for an engineering squad" (from prohibited_claims: "Having set prioritization for an engineering squad"). Then return to the integrations. **Follow-up 2:** "Did those sessions change the roadmap?" Answer slot: if you know of a case where product acted on evidence from the sessions, say what it was, and leave the decision with whoever made it. If you don't know of one, say so plainly and stay with the sessions. **Follow-up 3:** "Then isn't this a bet?" Concede that it is, and name what makes it a bet you've thought through: the plan in (4). Never fold into "I've basically been doing PM work." | The dossier lists it as the likeliest objection, and both negatives in it come from your prohibited_claims, so it's asked exactly as written. JD because it scores R1 head-on (F1, F2) |
| A2 | "I don't see roadmap ownership in your background — how would you handle owning the roadmap for our partner API platform?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap" | Acknowledgment, then a ramp plan. No bridge. "I haven't owned a product roadmap." Then the plan: first 30 days, learn which decisions are yours and which belong to the squad leads, and what partners are asking for. By 60 days, set an adoption baseline (B3) and synthesize discovery. By 90 days, a first roadmap draft reviewed with the hiring manager and both squad leads. Keep every step in future tense. | F2 is an acknowledge_gap area, so the dossier forbids bridging it. The rehearsal is a clean acknowledgment that moves straight into a credible plan |
| A3 | "Integrating clients onto a vendor's API isn't the same as shipping an API product. What's the difference, as you see it?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Agree that there's a difference, and say it in your own terms: you were on the integration side of the vendor's APIs. Then the integrations at their scope, from scoping to go-live. Answer slot: if any requirement you scoped went back and changed the vendor's API, say what changed and what part was yours. If none did, or you don't know, say so plainly and stay with the integrations. Never "I shipped an API product." | F3 is R2's must-have gap. Its premise is carried by its own quote |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having set prioritization for an engineering squad" | Pick a real weakness from the dossier's list rather than a disguised strength: "I haven't set prioritization for an engineering squad." Say how you'd close it: agree decision rights with the squad leads early, and get the hiring manager's read on the first trade-offs. A rehearsed, specific weakness lands better than a vague one [generic]. | A Skeptic stem that lands directly on F8. Rehearsed so you name a sourced gap instead of reaching for something you'd have to invent |
| A5 | "Tell me about your experience with agile delivery." | JD | [grounded] | Clarify strategy. Answer slot: R5 makes this probe likely. If your work ran in sprints or another agile cadence, say how, in your own words. If it didn't, say so plainly. Either way, end with what you'd want to know: how the two squads plan, and who owns the backlog. | F6 is a dossier clarify area. R5 is preferred, so a short, honest answer is enough |

### B. Case / Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're three months in. Sketch how you'd build the first roadmap for the partner API platform — what do you need to know first?" | CASE | [generic] | Clarify: who decides what, between you and the squad leads, and what's measured today. Objective: adoption, partner retention, revenue, or reliability. Ask which one they weight. Segmentation: partner types by size, integration depth and use case. Approach: discovery interviews, usage data, squad capacity, then a draft with explicit trade-offs. Risks: thin data, partner concentration. Challenge one premise: whether "the roadmap" sits with one PM or is shared with the squad leads. | JD responsibility 1 asked as a live problem. Hiring managers often case their own roadmap [generic]. No claim about your past is needed, so none is made |
| B2 | "A large partner wants a new endpoint this quarter; both squads are full. What do you do?" | CASE | [generic] | First: is this call yours or a squad lead's? That's the open question about decision rights. Then: what does the partner actually need, and is there a smaller version or an existing endpoint that covers it. Then the cost: what drops if it goes in, who else is affected, and the revenue or adoption stake. Then the decision path, and how you'd tell the partner. State your recommendation and the assumption you'd defend least. | Tests specs, delivery and prioritization judgment live. Rehearsing it as a CASE keeps you away from the prohibited prioritization claim |
| B3 | "How would you measure partner API adoption?" | CASE | [generic] | A funnel: keys issued, first successful call, production traffic, active partners over time, depth (endpoints or use cases per partner), retention. Pair a leading measure with a lagging one. Name the weakest assumption in your own definition, for example what counts as an "active" partner. Ask what's measured today. Your dossier lists the baseline as unknown. | The JD line "Define and track adoption metrics" (F9). Metric answers should name their weakest assumption |
| B4 | "Adoption of a new endpoint is 20% below target after launch — diagnose it." | CASE | [generic] | Clarify what the target was based on, and the time window. Segment by partner type and funnel stage. Hypotheses: discoverability (docs), integration friction (errors, auth), wrong problem (demand), or measurement (instrumentation). Name the cheapest test for each, and how you'd decide. | A diagnostic case on the same responsibility as B3. The number is the case's premise, not a claim about Quartzline |
| B5 | "How would you run discovery with our integration partners?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure: who to talk to (segments from B1), what to learn (jobs, friction, workarounds), how to capture it, and how it reaches decisions. Then the sessions you ran, at the quote's scope: you ran them quarterly, and they fed client evidence to product. Name the limit before they ask: those were input to product. Answer slot: the discovery line makes a probe on the format likely. If the format was yours, describe it. If someone else set it, say so plainly and describe what you ran. | F7. CASE delivery with one grounded anchor, plus the medium-confidence caveat volunteered |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Thirty-plus integrations — walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words. Answer slots: how it was counted (what made something one integration); what it's sensitive to; the assumption behind it you'd defend least; and which part was yours, in a sentence that keeps "led." If you don't know how one of these would be counted, say so plainly. The 30+ counts integrations. Keep it attached to that word. | The one headline figure in your material, so it will be probed. The pack supplies no counting method |
| C2 | "Pick one of those integrations and walk me through it, scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The stages are the beats the quote names: scoping, requirements, architecture, UAT, go-live. Tell them in your own words, for one integration you remember well. Answer slot: R3 makes a probe on docs and schemas likely. If you worked from the API docs and schemas, say how. If you didn't, say so plainly and describe the architecture step as you did it. Be precise about which stages you did yourself and which you led others through. | F4 and F3. The most likely deep-dive into your strongest evidence |
| C3 | "Tell me about the integration playbook you wrote. What's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats from the quote: you wrote it, and it's internal. Your team uses it. Describe what it covers in your own words. If you can share a sanitized excerpt, offer it. That turns a claim into something they can inspect. | High-confidence, inspectable evidence. Rehearsed so you stay at its scope: your team uses it, and nothing wider |

### D. Conversational (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Wrote the internal integration playbook her team uses" "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc from the three quotes: you led the client integrations (30+, scoping to go-live), you wrote the internal integration playbook your team uses, and you ran the quarterly sessions feeding client evidence to product. End with why this role, in your own words. Don't add a tenure figure unless it's yours to state (see the upgrade menu). | The likeliest opener [generic]. It sets up A1 on your terms if you tell it straight |
| D2 | "Why move into product management now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: give your own reason, in your own words. If it connects to the sessions, say how. You ran them and fed client evidence to product. Keep it that way, and never "I've already been doing product work." | Motivation, which the Skeptic tests when the background doesn't match. Tied to F1 |
| D3 | "Why Quartzline?" | CO | [generic] | Build it from the JD's own lines: a partner-facing API platform, discovery with integration partners. Add your own reason. Research couldn't run, so check Quartzline's site yourself before Thursday and use only what you read there. | Always asked in some form [generic]. Labeled generic because nothing about Quartzline was researched |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate who's already a PM?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate the question. Concede: "An internal PM has held the title. I haven't" (from prohibited_claims: "Having held a product manager title or role"). Hold: the integrations, at their scope. Describe them and don't argue for them. Hold that through two pushes, and don't trade it away for a softer story. | A1 at speed. Rehearsing the short version protects the long one |
| E2 | "Those roadmap sessions — how much of what product shipped actually came from you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold: you ran the sessions, and they fed client evidence to product. Concede, specifically: "I didn't own the roadmap" (from prohibited_claims: "Having owned a product roadmap"). Answer slot: if you know of a case where product acted on evidence from the sessions, say what it was, and leave the decision with whoever made it. If you don't know of one, say so plainly. | F7 is medium confidence. A pressure interviewer will find that seam, so you volunteer the limit first |

### F. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to manage competing asks from engineering, sales and a customer." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold. Pick an integration where those groups genuinely pulled in different directions. It needs a named stake, what you did, and how it ended. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (the client side of the integrations), or how you'd handle it. | R4's theme (F5). The scaffold picks from your work without supplying the event |
| F2 | "Tell me about a time you delivered an unpopular truth to a client or to leadership." | VAL | [generic] | Selection scaffold. It needs a hard truth that actually landed, a relationship that survived, and your part named precisely. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it. | A common behavioral stem [generic]. Not tied to any published Quartzline value, since none were researched |

### G. Peer Evaluator, voiced by the hiring manager (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You'd write specs and drive delivery with two squads whose leads have their own views. How would you work with them?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Principles first: agree decision rights early; specs that state the problem and the partner evidence, not only the solution; disagree in the doc, decide in the room. Answer slot: the specs line makes a probe on your requirements likely. If engineers built against requirements you wrote during scoping, say who and how. If they weren't build specs, say so plainly and stay with the integrations. Never "I set the squad's priorities." | F8, plus the dossier's open question about decision rights. Seam principles beat pretending to know the seam |
| G2 | "What would you need from the squad leads in your first month, and what would you give them?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Need: their view of the platform, their pain points with partners, how they want specs. Give: partner evidence, and the practice of writing down what teams repeat. Mention that you wrote the internal integration playbook your team uses, and offer to do the equivalent for partner onboarding if it helps. | A reciprocity question. R4 (F5) and responsibility 3 (F8) |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 — 3+ years product management experience | A1, A2, A4, D2, E1 |
| R2 — Shipped API or platform products | A3, C2 |
| R3 — Technical fluency: API docs, schemas | C2 |
| R4 — Stakeholder management across engineering, sales, customers | F1, G2 |
| R5 — Agile delivery experience | A5 |
| Own the roadmap for the partner-facing API platform | A1, A2, B1 |
| Run discovery with integration partners | B5 |
| Write specs and drive delivery with two engineering squads | B2, G1 |
| Define and track adoption metrics | B3, B4 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Straight from your dossier's open risk: the JD claims decision authority but nothing shows it. It reads as diligence, and you need the answer before accepting |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | Your dossier's second open risk. A missing baseline means your first quarter is building one, which is worth knowing up front |
| RQ3 | "What would make the first six months a clear success, from your side?" | Turns the hiring manager's bar into something concrete you can answer to |
| RQ4 | "How do partner requests reach the roadmap today — through sales, support, the squads, or directly?" | Shows you're already thinking about discovery (F7), and reveals where the friction is |
| RQ5 | "How do the two squads split the platform, and where do they overlap?" | Gets at the seam G1 asks you to work across, before you inherit it |
| RQ6 | "What's the hardest trade-off this roadmap has faced in the last year?" | Brings up the real tensions without asking anyone to criticize the team |

---

## Prohibited claims

What this pack won't coach, and the honest version of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | "I haven't held the PM title." Then F1's quotes at their own scope |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap area | "I haven't owned a product roadmap." Then a ramp plan in future tense (A2). No answer slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set prioritization for an engineering squad." No answer slot |
| Shipped an API product | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says integrations of the vendor's APIs, not shipping the API. A3's slot stays inside the integrations |
| Decided what went into product's roadmap through the quarterly sessions | Inflated form of F7 | F7's quote at its own scope. The pack's observation: the sessions fed evidence to product. The slots in A1 and E2 leave each decision with whoever made it |
| Wrote specs for and drove delivery of an engineering squad | Inflated form of F8 | F8's quote at its own scope. The pack's observation: the quote says requirements for client integrations. G1's slot stays inside the integrations |

One thing to watch: the dossier's decision summary mentions "seven years of integration leadership," but no verified entry carries that figure. This pack doesn't use it, and you should state your tenure in your own words.

---

## Sources

- **Provided:** `tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14. Sections used: `role_profile` (requirements and responsibilities, quoted as the JD), `decision` (context only), and `handoff_to_mock_interview` (verified evidence, weak areas with their strategies, the A1 objection, the reverse-question risks and employer questions, prohibited_claims). Not in this dossier: `evidence_map`, `evidence_state`, `risk_register`.
- **Searches sent:**
  - "Quartzline company values" — refused (search permission not granted)
  - "Quartzline interview process product manager" — refused (search permission not granted)
  - "Quartzline API platform partners news 2026" — refused (search permission not granted)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The one call was refused. It would have given F2 and D3 published values to work from. No values round was detected, so the cheat sheet wouldn't apply either way |
| 2. `Quartzline interview process product management` | unavailable | The one call was refused. It would have shown the rest of the loop and whether a values round sits elsewhere in it. This session's weights rest on your own words, so they stand |
| 3. `Quartzline strategy` / recent news | unavailable | The one call was refused. It would have moved B1 to B4 and D3 from generic to grounded in Quartzline's current priorities |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** → targets 1 to 3 run. Quartzline's published values can theme F2. The documented loop shows the other rounds. Current strategy turns B1 to B4 and D3 from generic to grounded.
- **Deep research, once search is allowed** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, loop reports for this role family, and recent org context, for sharper case questions.
- **The hiring manager's name** → an interviewer read, persona weights based on their public footprint, and a reverse question tied to their career path.
- **Any recruiter prep notes** → coverage of stated focus areas or any pre-declared deliverable.
- **Your tenure in your own words** → D1 and F1 can quote it. Right now no verified entry carries a figure.
- **Your own answers to the slots in F3, F4, F5, F6, F8 and F9** → those rows, and A3, A5, C2, F1 and G1, become story-mapped instead of slots.
- **A sanitized summary or agenda from one quarterly session** → F7 can move from medium toward high, and A1, B5 and E2 stop needing the caveat.
- **How much prep time you have** → a prep-triage schedule sized to it.
