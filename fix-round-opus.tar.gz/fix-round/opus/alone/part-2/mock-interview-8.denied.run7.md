Reading the skill's reference files before I build your pack. Next I'll check Ashgrove's published values page and interview process.
Dara, I've saved your prep pack: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-8-denied-370016d2/ashgrove_member-experience-lead_interview_pack.md`

It has a separate section for each of your three rounds on 21 November, based on the recruiter's email. Each round gets its own interviewer styles, practice questions and questions to ask them. The shared parts are:

- **Fit check:** each JD requirement against your four sentences.
- **Values sheet:** the four values, for the panel.
- **The 20-minute case:** a structure you can use on whatever scenario they give you.
- **Claims not to make:** things to avoid saying because your background doesn't support them.

I didn't run any web searches. Your pasted values page, the recruiter's email and your summary of the strategy brief already covered everything a search would have found.

**The most important one to practise is B4, in your round with the Head of Member Services.** It's the question of how you step up from one branch's complaints log to complaints across every branch and the contact centre, plus reporting to senior leaders. Some version of it will almost certainly come up.

**The biggest gap is the values panel.** Your notes don't include a story about a particular member or a particular fix. So for each value, the pack tells you how to choose a story rather than giving you one. If you tell me one or two real stories, I'll build them in.

If you want to practise out loud, I can play your future manager and ask you B4, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep turned up, for you to bring to later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds, all on 21 November 2026, as the recruiter's email sets them out
1. Recruiter, 30 minutes
2. Head of Member Services (your future manager), 45 minutes, "mostly behavioural"
3. Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. This is also the values round, "scored against the four values"

No interviewer names have been assigned yet, so the pack works from their roles. This is loop mode: one shared fit snapshot, then a mini-pack for each round, then shared sections at the end.

---

## How to use this pack

- **Personas** describe how a question is asked: who is asking, and in what style. **Types** describe what the answer is scored on. The same question can feel like small talk from the recruiter and like a cross-examination from the panel.
- **Type key**
  - **VAL**: whether your past behaviour shows Ashgrove's *published* values
  - **EXP**: whether what you say about your experience holds up under follow-up questions, and what was actually yours
  - **JD**: whether you can do the listed job, including the parts where you have gaps
  - **CO**: company and strategy knowledge (digital shift, hubs, small-business lending, app-only competitors)
  - **CASE**: a live problem from the role, which you reason through out loud
- **Question IDs** use one letter per persona: A Conversational, B Skeptic, C Values/Behavioural, D Case/Strategist, E Data-Driven Prober, G Peer Evaluator, H Pressure. F is kept for fit-snapshot rows (F1–F9).
- **Answer slots.** When a cell says "Answer slot", the pack doesn't know the answer from your material. Answer it in the interview from your own experience. If the thing it names never happened, or wasn't yours, say so plainly. That is a complete answer.
- **The guidance is a starting structure, not a script.** Every claim it makes about your past rests on one of the four sentences you wrote, and nothing beyond them.

---

## Fit snapshot (shared across all rounds)

All evidence comes from your message. There is no CV, so the only evidence is these four sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material covers one branch's formal complaints log, not a process across branches, and your words should stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If any stage of a complaint, from arrival to close, was yours to decide, say which stage and how you decided, in your own words. If your part was keeping the log, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | No wording closes this gap, and you have said so yourself. Words: "I haven't worked in a contact centre." Then say how you would learn it, framed as a plan and never as a past: for example, sitting with contact-centre staff and listening to complaint calls in your first weeks. Never claim contact-centre exposure, and add nothing to make the gap sound smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The spreadsheet is monthly and about complaints. Your material doesn't show whether it counts volumes or resolution times, or who reports from it. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on what it measures. If it counts volumes or resolution times, say what it counts and how, in your own words. If it tracks something else, name that plainly. On who reports from it, say only what was yours. Expect follow-up questions, because nothing has been inspected behind this line |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the branch's escalation script and have been a supervisor yourself for three years. It does not say you have coached supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on coaching peers likely. If you have ever helped another supervisor with an escalation, say what happened and what your part was. If you haven't, say so plainly and stay with the teller training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way about this requirement. Answer slot: if you have worked with an online-banking or app team, or on any change that let members serve themselves, say what it was and what your part was, in your own words. If you haven't, say so plainly and describe what you would bring to a digital team from the complaints side |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap: six years against a four-year ask. Lead with the quote in its own terms, six years in retail banking and the last three as a branch supervisor. Let the interviewer map it onto "customer operations" rather than relabelling your own history in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | "Formal" is your word and "regulated" is the JD's. Your material doesn't show which rules the log was run against. Words: "I handled the branch's formal complaints log." Answer slot: expect a probe on which rules governed those complaints and what they required of you. If you know, say it in your own words. If the log wasn't run against regulatory rules, or you weren't the one applying them, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated this gap yourself. Words: "I haven't presented to anyone above regional level." Then give a plan, never a past. Your sentence sets a ceiling; it isn't a record, so don't turn it into a claim that you *have* presented at regional level unless you have. Note that rounds 2 and 3 are themselves 45 and 60 minutes in front of senior people, so composure there is direct evidence |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says "spreadsheet", not which tool. Answer slot: the JD names Excel, so expect a probe on it. If you built it in Excel, describe what you built into it, in your own words. If you used another tool, name it plainly |

**The highest-ROI prep in this pack is B4 (round 2).** F1, F2 and F8 all point at the same objection: one branch's log, no contact centre, never presented above regional level, against a role that is organisation-wide and reports to senior leaders. It will come up in some form, most likely from your future manager.

---

## Grounding brief: Ashgrove's strategy, from the brief the recruiter sent

This is built only from your summary of the July 2026 brief. Reread the full document before the 21st for its own figures and wording, such as which branches are involved, where the hubs will be, and the timelines.

| Point (your summary of the brief) | Vocabulary to use | Where it shows up in this pack |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | digital channels, self-service journeys (the JD's phrase) | D1, F5, B6, reverse questions |
| "consolidate eight branches into five hubs over 2027" | hubs; members whose branch is changing | D3, G2, C6, the round 3 case |
| "launch a small-business lending product in Q1 2027" | small-business members; a new product, so new kinds of complaint | Reverse questions R2-4 and R3-5 |
| "the main competitive pressure is app-only banks" | app-only banks; what a member-owned credit union offers that an app doesn't | A2, D1 |

There is a tension in this material worth noticing: "Neighbours, Not Numbers — every branch is part of its town" sits beside a plan to consolidate eight branches into five hubs. The panel are branch managers living through that change. Don't present it as a contradiction you have spotted. Show that you would handle the complaints it produces from the member's side of the counter.

---

## Round 1: Recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly walk-through of your background, motivation, logistics | High. A recruiter screen's default register; 30 minutes leaves room for little else | A 90-second arc built only from your four sentences; treat casual questions about the JD as scored |
| B Skeptic, light | Knockout-style checks on JD requirements: contact centre, regulated complaints, Excel | Medium. Recruiters screen against the requirement list before passing you to the manager | Short, honest, unhedged answers; on F2 and F8, say the limit plainly and move on to the plan |

### Question bank

**A — Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, in this order: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log and trained new tellers on the escalation script. You built the monthly complaints spreadsheet your regional manager uses. Close with one sentence on why complaints work across a whole organisation is the next step, in your own words. Add no extra responsibilities to make the arc fuller | Every round opens with some version of this, and the recruiter's version sets what they write up for the manager. EXP because it's the first test of whether your account stays the same size under follow-up |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Name one published value by its exact name, for example "Members First, Always", and say in your own words why it matters to you. If being member-owned matters to you, say why. If you have read the strategy, one sentence showing you know about the digital shift or the competition from app-only banks shows you've done the homework. Don't invent a personal connection to Ashgrove that you haven't got | Grounded in the pasted values and the strategy brief; CO because it scores homework, not experience |
| A3 | "Why move on from branch supervision now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Give your real reason, in your own words. If what draws you is taking complaints from one branch to the whole organisation, say that. Keep it forward-looking ("what I want to do more of") and say nothing negative about your current employer | Motivation consistency starts here, and the manager will compare your answer with what you say in round 2. EXP because it rests on F6's history |
| A4 | "What's your understanding of what this role does?" | JD | [grounded] | Restate the four duties in plain words: run the complaints process across branches and the contact centre, report on it every month, coach supervisors on escalations, and work with digital teams on self-service. Then ask which of the four matters most in the first six months | Checks that you've read the JD. Asking back gets you information for rounds 2 and 3 |
| A5 | "What are you looking for on salary, and what's your notice period?" | JD | [generic] | Give a range you have decided on before the call, and your actual notice period. If you haven't researched the pay band, ask the recruiter for the role's range before you name a number | A standard recruiter-screen item; generic because nothing in your material sets a figure |

**B — Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for experience handling regulated complaints. Tell me about yours." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with the quote: you handled the branch's formal complaints log. Answer slot: if you know which rules governed those complaints and what they required of you, say so in your own words. If the log wasn't run against regulatory rules, or you weren't the one applying them, say so plainly and stay with the log you handled | F7 is a mid-list requirement that recruiters check off literally. JD because it scores a stated requirement |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't worked in a contact centre." Then one sentence of plan, framed as the future: how you would learn the contact centre's side of complaints in your first weeks. Don't pad it and don't apologise | F2 is a stated gap against the JD's headline line, so the recruiter may screen on it. A clean, short answer here keeps it from turning into a knockout |
| B3 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the quote: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it's in Excel, say what you built into it, in your own words. If you used another tool, name it plainly. Don't list Excel functions you haven't used | F9 and F3. JD because Excel is named in the requirements, which is exactly the kind of item that gets checked |

### Reverse questions: round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What's the Head of Member Services hoping this hire changes in the first six months?" | Tells you what round 2 is really scoring |
| R1-2 | "For the 20-minute case, is it a written scenario I'll read on the day, or will one of the panel play the member?" | You're not asking for the answer, only the format, which shapes how you rehearse |
| R1-3 | "Is this role new, or am I stepping into someone's existing process?" | Tells you whether "own end to end" means building or inheriting |
| R1-4 | "Will the panel interviewers' names be shared before the day?" | Practical, and it gets you their names for the interviewer read |
| R1-5 | "How do branch staff and the contact centre handle complaints today: one process or two?" | Shows you have already started on the F1 and F2 seam |

---

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioural | "Tell me about a time…" questions on complaints, escalations, training, fixes | High. The recruiter called this round "mostly behavioural" | Pick stories from your real experience before the day. Use "we" for context and "I" for your part. Where you have no story, say so and give the nearest one your material carries |
| B Skeptic | Probes on the scope jump (one branch to the whole organisation), the contact centre, presenting upward | High. A hiring manager is buying capability and reducing the risk of the gaps; F1, F2 and F8 are the obvious targets | B4 rehearsed until it bores you; hold on your quotes, then concede the stated limits and give a plan |
| E Data-Driven Prober | Close questions on the monthly spreadsheet | Medium. The JD's monthly reporting line, and F3 is your one artefact | Know what you can and can't say about what it counts; say plainly when you don't know |
| D Case/Strategist | One "how would you…" on the digital shift | Medium-low. Behavioural-led round, but a manager often asks one roadmap question | Clarify, then structure, then answer; use Ashgrove's vocabulary |
| H Pressure | One time-boxed challenge | Low. No signal for a stress style, but rehearse it once so it isn't new on the day | Pause, restate the question, hold, then concede only what's real |

### Question bank

**C — Values/Behavioural**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint you handled that needed escalating." | VAL | [generic] | Choose a real complaint from your branch, with no member names. It needs a member's problem, the point where you escalated it, your part, and the outcome. Use "I" for what you did and "we" for the branch. If no single complaint comes to mind, say so plainly and walk through how the escalation script worked in your branch, or how you would handle one | Escalation runs through the whole JD. Generic because none of your sentences describes one particular complaint. VAL because a manager will listen for "Members First" and "Own the Fix" in how you tell it |
| C2 | "Tell me about training someone on how to escalate." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4. The beats are the ones the quote states: new tellers, the branch's escalation script, and you trained them. Tell it in your own words. Answer slot: the JD's coaching line makes "how did you know it had landed" a likely follow-up. If you checked how they were doing afterwards, say how. If you didn't, say so plainly and stay with the training. "Our" escalation script: don't claim you wrote it unless you did | F4 is your nearest material to "coach branch supervisors", so the manager will test how far it stretches. EXP because it checks what was actually yours |
| C3 | "Tell me about a time you disagreed with how something was being handled and said so to someone senior." | VAL | [generic] | Choose a time with a real disagreement, a senior person, what you said, and where the relationship stood afterwards. If the disagreement didn't land, say that; don't supply a happy ending. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would raise it | The role reports to senior leaders (F8), and the manager will want to know you'll bring bad news upward. The theme comes from the Values persona's "unpopular truth" stem |

**B — Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "You've handled one branch's complaints log. This role owns complaints across every branch and the contact centre, and reports to senior leaders. What makes you ready for that jump?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in the pack.** Open by holding only what your quotes carry: "I handled the branch's formal complaints log, trained new tellers on our escalation script, and built the monthly complaints spreadsheet our regional manager uses." Name the limits before you're asked: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then give a plan for the first 90 days, framed as the future: learn the contact centre's side, meet each branch's supervisors, and get the monthly report in front of leadership. Answer slot: if any stage of a complaint was yours to decide, say which. If your part was keeping the log, say so. **Expect follow-up 1:** "But you've never seen a contact centre." Hold: same words, same plan, no extra padding. **Follow-up 2:** "Presenting to execs is half this job." Concede specifically ("that's the newest part for me"), then the plan. Don't fold on the parts that are true, and don't turn a branch log into a process | F1, F2 and F8 combine into the single most predictable objection to your background. The manager owns this risk if they hire you, so they'll press on it. JD because it scores the headline requirements directly |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of the two gaps you have actually stated, not a fake weakness. "I haven't presented to anyone above regional level" is the more honest choice, since presenting to senior leaders is a requirement. Give the plan straight after. Keep it under a minute | Skeptic stem, aimed at F8 or F2. A real answer here earns trust you'll need for B4 |
| B6 | "The role works with digital teams on self-service journeys. What have you done there?" | JD | [grounded] | Answer slot (F5): if you have worked with an online-banking or app team, or on any change that let members serve themselves, say what it was and what your part was. If you haven't, say so plainly. Then say what complaints tell a digital team: where members get stuck and what they had to ring or come in about. That last part is a view about the job, not a claim about your past | F5 has no evidence, and the 40% digital target makes this a live requirement for the manager. JD because it's a stated duty |

**E — Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built. What does it measure?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the quote: you built it, it's monthly, your regional manager uses it. Answer slot: say what it counts and how, in your own words. If it tracks volumes or resolution times, say so. If it doesn't, name what it does track. Then name the figure in it you would trust least and why, before they ask. If you don't know how a figure is counted, say so | F3 is your only artefact against the monthly reporting duty, and probers dig into artefacts. EXP because it tests whether the line holds up |
| E2 | "What does your regional manager actually use it for?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what you know they use it for. If you don't know, say so plainly. Don't describe decisions it fed into unless you saw them. If someone else presents from it, say that; the building was yours | The quote's "uses" invites this follow-up. It also separates building a report from presenting one (F3 against F8) |

**D — Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "We're aiming to move 40% of member service to digital channels by 2028. How should complaints handling change as that happens?" | CO | [grounded] | Clarify first: does the 40% include complaints, or only routine service? Then structure it in three parts. First, members who complain digitally still need a person to own it, which is Own the Fix. Second, complaints are the best map of where self-service journeys fail, so feed them to the digital team every month. Third, members who don't go digital mustn't get worse service, which is Members First. Name one risk: the app-only banks set members' expectations on speed. Use their vocabulary throughout: members, channels, self-service journeys | Grounded in the strategy brief and the JD's digital line; at least one strategy question is mandatory. CO because it tests whether you can think at the company's level |

**H — Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you, over someone from our contact centre who already knows our systems?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause, then hold on what's yours: six years in retail banking, three supervising a branch, the formal complaints log, and training tellers on escalation. Concede plainly: "I haven't worked in a contact centre." Then the branch angle: the role spans the branches, and you know the branch side of the counter. Don't run down the hypothetical internal candidate | F2 made pressure-shaped. Rehearsed once so the time-box doesn't rattle you |

### Reverse questions: round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would make you say, a year from now, that this hire worked?" | The manager defines the scorecard, and you hear it in their words |
| R2-2 | "Who sees the monthly complaints report today, and what do they do with it?" | Ties to F3 and F8, and shows you already think about who reads the report |
| R2-3 | "How will complaints be handled while branches move to hubs in 2027?" | Shows you have read the strategy and see where the risk sits |
| R2-4 | "What new kinds of complaint are you expecting when small-business lending launches?" | Shows you're looking ahead to Q1 2027, not just the current process |
| R2-5 | "How much of the contact centre's complaints work would sit with this role from day one?" | Turns your F2 gap into a scoping conversation, not a weakness |

---

## Round 3: Panel of two branch managers, the values round plus a 20-minute case (60 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioural | One or more questions per value, scored against "Members First, Always", "Plain Words", "Neighbours, Not Numbers" and "Own the Fix" | High. The recruiter says the panel "score against the four values" | Use the values cheat sheet; say the value's name once, then tell the story |
| D Case/Strategist | The announced 20-minute complaint-escalation case, plus a possible follow-on | High. The recruiter named the case; see the build section below | Clarify, put the member first, decide who owns it, find the root cause, then close |
| G Peer Evaluator | Where the line falls between what a branch resolves and what this role takes; what happens when you disagree | Medium. Branch managers' supervisors are the people you would coach, so they will judge whether you'd add to their workload or reduce it | Say what you would bring their branches; suggest principles for where the line falls rather than pretending to know it |
| B Skeptic | One probe on why branches should take coaching from you | Low-medium. The question sits naturally with branch managers | Hold on F6 and F4's quotes; don't claim seniority you haven't got |

### Values cheat sheet

From the values page you copied on 12 November 2026. None of your four sentences carries a story about a particular member or event, so every row below is a way to choose a story, not a story. This is the biggest gap for round 3 (see the upgrade menu).

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side, even when the process points another way | Selection scaffold: choose a time you did what was right for a member when the easy route pointed elsewhere. It needs the member's situation, what you chose, and why. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." |
| Plain Words | If a member needs it explained twice, the explanation was wrong | Selection scaffold: choose a time you rewrote or re-explained something so a member, or a new colleague, understood it first time. If none comes to mind, say so, then give the nearest thing you have: F4, where training new tellers on the escalation script was explaining a process to others |
| Neighbours, Not Numbers | Each branch is part of its town | Selection scaffold: choose a time local knowledge about a member or the community changed how you handled something. It needs the local detail and what it changed. If none comes to mind, say so plainly and say how you'd keep that local knowledge when branches become hubs |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | Selection scaffold: choose a problem you found and stayed with to the end, including chasing other people. If the spreadsheet in F3, "I built the monthly complaints spreadsheet our regional manager uses.", was built to fix a problem, say what the problem was, in your own words. If it wasn't, don't present it as a fix; choose another story or say plainly that you don't have one |

### Question bank

**C — Values/Behavioural**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C4 | "Tell us about a time you made a decision from the member's side of the counter." | VAL | [generic] | Use the Members First scaffold above. A strong answer has a real member (no names), a choice, and why the member's side won. If no time comes to mind, say so plainly, then give the nearest thing you have, or how you'd decide | Asked in the value's own published words; the panel scores each value |
| C5 | "Tell us about a time something had to be explained twice. What did you change?" | VAL | [generic] | Use the Plain Words scaffold. Your nearest material is F4, the teller training. Only tell a "what I changed" ending if one actually happened. If nothing changed, say so and say what you'd change now | Mirrors the published definition of Plain Words almost word for word, so expect something close to it |
| C6 | "Every branch is part of its town. How have you seen that in your own branch?" | VAL | [generic] | Use the Neighbours scaffold. Choose a real local detail; don't generalise about "the community". If no example comes to mind, say so and say how you'd protect local knowledge through the hub changes | The panel are branch managers, and with consolidation coming this value is the one closest to them right now |
| C7 | "Tell us about a problem you found and kept hold of until it was solved." | VAL | [generic] | Use the Own the Fix scaffold. It needs the moment you spotted the problem, who you had to chase, and the point it was actually solved. If you can't point to a solved end, say so; "still open, and here is what I'd do next" is honest | Published definition of Own the Fix. It is also the JD's "own end to end" in values language |

**D — Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D2 | The 20-minute complaint-escalation case | CASE | [grounded] | Use the build section below. Spend the first two minutes on clarifying questions out loud | Announced by the recruiter; a scored part of round 3 |
| D3 | "Next year eight branches become five hubs. A member who has banked at a closing branch for decades complains to you. What do you do?" | CASE | [grounded] | Start from the member's side of the counter. Listen, then acknowledge the loss in plain words, not policy language. Separate what you can fix (getting to the hub, digital help, a named contact) from what you can't (the decision itself), and be straight about the second. Log it so the volume of consolidation complaints is visible in the monthly report. Tell the member who owns it and when you'll come back to them. Name the values as you go, once each | Combines the hubs plan with "Neighbours, Not Numbers"; the panel will be dealing with exactly this. CASE because it's a live problem and asks nothing about your past |

**G — Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You'd be coaching our supervisors on escalations. What would you need from us, and what happens when we disagree with how you've handled one of our complaints?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start with what you'd bring them: fewer complaints bouncing between branch and centre, and clear rules on when to escalate. What you'd need from them: time with their supervisors, and to hear early when a complaint is getting worse. On disagreement, suggest a principle: talk it through first, decide by the member outcome, and escalate together if needed. You can say you've been a branch supervisor for three years, which is the quote. Don't claim you've managed a branch | The JD's coaching duty, seen from the branch managers' side. Peer Evaluator because they are judging whether you add to their workload or reduce it |
| G2 | "Where's the line between what a branch should fix itself and what comes to you?" | CASE | [generic] | Don't pretend to know Ashgrove's current line. Suggest principles: the branch keeps what it can resolve quickly and in the member's favour; central ownership takes regulated deadlines, repeat patterns and anything crossing channels. Then ask how it works today. End with "whoever finds the problem keeps hold of it", worded as Own the Fix | Seam-splitting is the Peer persona's core question. Generic because Ashgrove's current process isn't in your material |

**B — Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B7 | "You've spent the last three years as a branch supervisor. Why would our supervisors, and we, take escalation coaching from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold on the quotes: three years as a supervisor means you have been in their supervisors' position yourself; you handled the complaints log; you trained new tellers on escalation. Concede honestly that coaching supervisors would be a step on from training tellers. Frame the coaching as working with peers, not top-down. Don't claim authority you haven't got | F4's transferability gap, asked by the people whose teams you would coach |

### Graded deliverable: the 20-minute complaint-escalation case

The recruiter announced the case but didn't give the scenario. Everything below is a structure to bring to whatever scenario you get.

**What to build on**
- Requirement: "Own the member complaints process end to end across branches and the contact centre" and "coach branch supervisors on escalations" — JD
- The four values by name, which the panel are scoring
- Strategy: hubs in 2027, the 40% digital target, app-only competition — the brief, from your summary
- About you, if relevant: F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." Only refer to what that sentence says

**Suggested 20-minute shape**
Clarify (2 minutes), then the member first (5), then ownership and escalation (5), then root cause and reporting (5), then close (3). Think out loud.

**Three possible theses, each with its concession**

| Thesis | Concession you name yourself |
|---|---|
| 1. Resolve the member's problem before fixing the process: own the member outcome first, then trace the cause. This is Members First plus Own the Fix | Moving fast for the member can mean acting before the facts are complete; say what you'd check before committing to an outcome |
| 2. Treat the escalation as a coaching moment for the branch: handle it *with* the supervisor, not around them | In a serious or regulated case, the central owner may have to take it over, and the branch may feel overruled; say how you'd explain that |
| 3. Treat every escalation as a data point: ask whether this is one complaint or the tenth like it, and make it visible in the monthly report | In 20 minutes the member comes first; don't let the analysis crowd out the person |

**How to stand out from the obvious answer.** Most candidates will say: apologise, investigate, resolve, follow up. Do that too, but add three things. Ask early what deadlines or rules apply to this complaint; ask, don't assert Ashgrove's specifics. Write any member-facing line in plain words, and say one aloud. Name what changes so it doesn't happen again, and who owns that change.

**What to avoid:** promising compensation or an outcome before you know the facts, and quietly taking the complaint away from the branch.

**Close** (none requested by the recruiter): end on the member's outcome, then the one change you would own. That is the Own the Fix sentence the panel is listening for.

### Reverse questions: round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What could someone in this role do in their first month that would genuinely help your branches?" | A reciprocity question for people who would be your peers; it shows you'd reduce their workload |
| R3-2 | "When a complaint goes wrong today, where does it usually get stuck: branch, contact centre, or between them?" | Lets them tell you the real problem, and shows you think in terms of the handover between teams |
| R3-3 | "How are your teams and members feeling about the move to hubs?" | Neighbours, Not Numbers, asked with care rather than as a challenge |
| R3-4 | "What do your members say when they compare you with the app-only banks?" | Ties to the strategy, and branch managers hear this first-hand |
| R3-5 | "Which escalations do your supervisors find hardest today?" | Gives you material for the coaching duty, and shows you'd start by listening |

---

## Requirement coverage (shared)

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches | B4, C1, D2, G2 |
| …and the contact centre | B2, B4, H1, R1-5, R2-5 |
| Report monthly on complaint volumes and resolution times | E1, E2, D3, R2-2 |
| Coach branch supervisors on escalations | C2, G1, B7, D2 |
| Work with digital teams on self-service journeys | B6, D1 |
| 4+ years in financial-services customer operations | A1, H1 |
| Experience handling regulated complaints | B1, D2 |
| Confident presenting to senior leaders | B4, B5, E2, C3 |
| Comfortable with Excel reporting | B3, E1 |

---

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's formal complaints log, not a process. The B4 and F1 answer slots stay inside the log |
| Has contact-centre experience | A negative you stated, F2 | "I haven't worked in a contact centre." No answer slot |
| Has presented to senior leaders | A negative you stated, F8 | "I haven't presented to anyone above regional level." No answer slot |
| Has presented at regional level | Reading your F8 sentence the flattering way; it sets a ceiling and doesn't say you presented | Say only what you've actually done; the sentence itself makes no claim |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the escalation script |
| Wrote or designed the escalation script | Inflated form of F4: "our escalation script" | Say you trained tellers on it. Say who wrote it only if you know, and only if it was you |
| Reports complaint performance to regional leadership | Inflated form of F3: you built the spreadsheet, and the regional manager uses it | F3's quote at its own scope: you built it, they use it |
| Handled regulated complaints | Inflated form of F7: "formal" swapped for the JD's word "regulated" | F7's quote, "the branch's formal complaints log." The B1 slot asks only which rules governed it |

---

## Sources

**Provided documents**
- The job description, pasted
- Ashgrove's values, pasted (copied by you on 12 November 2026 from ashgrovecu.org/about/values)
- The recruiter's email describing the three rounds, pasted
- Your summary of the 2026 strategy brief (published July 2026, sent by the recruiter)
- Your background, from your message

**Searches and fetches:** none were sent. Every L1 target was already answered by your inputs, or had no name to search for. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values you pasted, copied that morning from the official page, already settle the cheat sheet and the VAL banks |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email establishes all three rounds, who runs them, the case and the values scoring, so it settles the persona weights and loop structure |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Your summary of the July 2026 brief, about four months old, already supplies the priorities behind D1, D3 and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names have been assigned, so there was nothing to search for; the interviewer read is left out |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied settles the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names** (when the recruiter assigns them) → an interviewer read from their public professional profiles, per-person persona weights on the panel, and a reverse question tied to each person's career path
- **One or two real stories per value** (told to me outside a drill) → the four values cheat-sheet rows and C1, C3–C7 change from ways of choosing a story into stories built on your own words. This is the biggest improvement available for round 3
- **Your answers to the answer slots on F3, F7 and F9** (what the spreadsheet counts, which rules governed the log, which tool it's built in) → those rows, and B1, B3, E1 and E2, would rest on your own sentences instead of open slots
- **A copy of the spreadsheet's structure** (only the column headings and layout, no member data, and only if your employer allows it) → F3 and F9 could rise from `medium` to `high`, since an inspectable artefact is what raises that band
- **Your CV** → more quoted evidence, possibly some for F5 (digital work) and for the values stories
- **The full strategy brief text** instead of your summary → the grounding brief, D1 and D3 would use Ashgrove's own figures and wording
- **How much prep time you have before the 21st** → a prioritised prep schedule sized to it
- **Deeper research** (up to 6 more searches and 2 more fetches, several more minutes) → recent Ashgrove news since July (hub locations, the lending launch) and any public candidate reports on its interviews, for sharper CO questions
- **A `tuesday-dossier.md` from job-underwriter** → evidence-checked stories and a fixed list of claims not to make, to tighten B4 and the prohibited list. It's optional, and the pack is complete without it
