Web search was refused, so I'm building the pack from what you gave me. Writing it now as one shared fit snapshot plus a mini-pack for each round.
I've saved your prep pack for all three rounds: `Larkfield-Systems_engineering-manager_interview_pack.md`. All three rounds share one fit snapshot, and each round gets its own question bank and reverse questions.

I built it from your role description and the four sentences you wrote about yourself. Web search was refused, so the pack contains nothing from Larkfield's own website. That means there's no values cheat sheet for Monday, and the company-strategy questions are generic, not specific to Larkfield.

- **Biggest risk:** your own line that you've "never owned a hardware-adjacent roadmap". That gap sits on Larkfield's core business, so question B1 on Tuesday gets the deepest rehearsal. The same objection comes back from the PM on Thursday (K2) and from the VP on Monday (N1). Keep your answer the same each time: say the limit first, then give a plan.
- **Second risk:** the jump from leading 6 to leading 11 across two squads. That's B2 on Tuesday, and A4 covers the follow-up about whether you've managed managers.
- **The 60% figure:** expect "how was that counted" and "how much of it was you" in every round. Your own sentence says on-call dropped "after" the reliability quarter, not "because of" it. Keep that wording.
- **Before Tuesday:** fill in the answer slots on delivery (F3), developing engineers (F4) and device experience (F7) in your own words. Right now your material doesn't cover any of them.

Say the word and I'll play the Director and run B1 live, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste your CV and the full job description? The CV would turn the current scaffolds into answers built from your real stories, and the job description would add any requirements the one-line summary leaves out. Also, do you want to allow web search and a deeper research pass (up to 6 more searches and 2 fetches, several more minutes)? That would give Monday a cheat sheet built on Larkfield's published values.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview pack — Engineering Manager, Larkfield Systems

**Candidate:** Yusuf · **Mode:** loop, three scheduled rounds
**Round 1:** Tuesday, 45 min, hiring manager (Director of Engineering, your would-be boss)
**Round 2:** Thursday, 60 min, panel (two staff engineers and a product manager)
**Round 3:** the following Monday, 30 min, VP Engineering ("values and leadership philosophy", per the recruiter)

Built from the role description you quoted and the four sentences you wrote about yourself. No CV and no full JD. Web research was refused this run (see Sources), so nothing here comes from Larkfield's own pages.

---

## How to use this pack

- **Personas** describe how a question is asked: who is asking, and in what style. **Types** describe what is being scored. Rehearse both.
- **Type key:**
  - **VAL**: behavioral and values. Does your past behavior show what this company says it values?
  - **EXP**: experience deep-dive. Do your claims hold up, and what part was actually you?
  - **JD**: role-driven. Can you do the job as listed, gaps included?
  - **CO**: company and strategy. Can you think at the company's level?
  - **CASE**: a live problem from the role, worked out loud.
- **Provenance:** `[grounded]` means it traces to what you gave me. `[inferred]` means a derivation, and the derivation is named. `[generic]` means a role-family pattern with no claim about Larkfield.
- **Answer slots** are instructions for the interview, not questions for me. Each gives two honest branches: if you did the thing, say how, in your own words; if you didn't, or it wasn't yours, say so plainly.
- **Guidance is scaffolding, not a script.** Every claim about your past here uses your own sentences. Don't let a rehearsed answer grow past them.
- **Highest-ROI prep in the pack: B1** (Tuesday). Its objection comes back in K2 (Thursday) and N1 (Monday), so one rehearsed answer covers all three rounds.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description you quoted | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads, and the words stay there: "I've been a team lead for three years, of a team of six." Answer slot: the two-squads line makes a probe likely on running more than one stream of work at once. If you ran parallel workstreams inside that team of six, say how, in your own words. If not, say so plainly and stay with the team you led |
| F2 | "own ... hiring ... for 11 engineers" — role description you quoted | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but it's a message line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you run the hiring loop for backend roles. Keep "about" on the 40. Answer slot for the figure: say whether the 40 are interviews you sat in or interviews the loop ran, and which part was yours. If you don't know the exact count, say so |
| F3 | "own delivery ... for 11 engineers" — role description you quoted | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote touches delivery (a quarter of work pushed through) but doesn't show whether you owned the team's delivery commitments. Answer slot: if you set or negotiated delivery dates and scope for your team, say how, in your own words. If they were set elsewhere, or there were none, say so plainly and describe the reliability quarter you pushed through |
| F4 | "own ... growth for 11 engineers" — role description you quoted | none given | none | [grounded] | discovery | Strong evidence looks like a named engineer you helped grow, what you did, and what changed. Answer slot: the growth line makes a probe likely on how you develop engineers. If you run career conversations, feedback or promotion cases for your six, say how, in your own words. If those sit with someone else, say so plainly and say how you'd approach growth for 11 |
| F5 | "partner with hardware ... on roadmap" — role description you quoted | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording can't close, and you've said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you'd learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "partner with ... product on roadmap" — role description you quoted | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your quote is about holding a quarter against roadmap pressure. It isn't about running a roadmap with a product partner, and the words stay there: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if product was on the other side of that pressure, say what happened and what part of it was yours, in your own words. If it wasn't, or there was no negotiation, say so plainly and stay with the quarter |
| F7 | "building device-management services" — role description you quoted | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | Your material doesn't show whether any of your nine years touched devices or fleets of them. Answer slot: if any of your work did, say what and what part was yours, in your own words. If none did, say so plainly and stay with what your payments work was |

**Reading the snapshot:** F5 is the one gap you stated yourself, and it sits on the company's core domain, which is why B1 gets the deepest rehearsal. F1 (one team of six against two squads of 11) is the second objection. F3, F4 and F7 are answer slots, not weaknesses. Fill them in your own words before Tuesday.

---

## Round 1 — Tuesday · Director of Engineering (hiring manager) · 45 min

### Persona weights

The loop is established by your own description of the three rounds, so these weights rest on that, not on a guessed archetype.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "You inherit two squads — what do you do?" type problems drawn from the role | high: hiring managers are buying capability and test it on their own roadmap; this is your would-be boss | Clarify, then objective, approach, metrics, risks. Think aloud, and challenge one premise politely |
| Skeptic | Quiet probing of F5 and F1 | high: a Director takes on the risk of the hire, and the gaps are visible from your own description | Rehearse B1 until it's boring. Name the limit before you're asked, then give a concrete ramp plan |
| Conversational | A friendly opener, then "walk me through your journey" | mid: 45 minutes usually opens with a biography question, and it is still scored | A 90-second arc built only from your four sentences |
| Data-Driven Prober | "How was the 60% counted?" | low here, high Thursday: a Director may test one number, and the staff engineers will test all of them | Know how each figure was counted, or say plainly that you don't |

### Question bank

**A — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit two squads, 11 engineers, building device-management services. What do you do in your first 90 days?" | CASE | [generic] | Clarify first: what each squad owns, current commitments, on-call load, open roles, and which work depends on hardware. Then a sequence: 1:1s with all 11 and with your hardware and product partners in the first weeks; a map of what's in flight and what's at risk; one visible early fix chosen with the team. Name the measures you'd check at 90 days and the risk of changing too much too early. The question needs no claim about your past, so the guidance makes none | The JD's headline line asked as a live problem, and the most predictable question a future boss asks. CASE because it scores structure, not a record; `[generic]` because it's a pattern for the problem, not a fact about Larkfield |
| A2 | "One squad keeps missing commitments to the hardware team. How do you diagnose it?" | CASE | [generic] | Separate the causes before fixing anything: estimation, dependency on hardware or firmware timing, scope changing mid-flight, staffing, unclear ownership. Say what data you'd ask for and who you'd talk to first (the squad, then the hardware lead together with them, not around them). Close with one change you'd try and how you'd know it worked. Ask what hardware's release rhythm looks like here, because that's real information you don't have | Brings together the JD's delivery and hardware-partnership lines (F3, F5) in a problem that doesn't need hardware history to answer well. CASE because reasoning is scored |
| A3 | "Product wants features for a customer rollout, and on-call is burning your people. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure it live: the cost of incidents to customers and the team, what in the rollout can move, what you'd trade, and who you'd decide it with. Then offer your one real instance in its own words: "I pushed a reliability quarter through against roadmap pressure; my team's on-call burden dropped 60% after." Keep "after"; don't upgrade it to "because". Answer slot: the JD's product-partnership line makes a probe on how you got agreement likely. If you negotiated it with product or leadership, say how, in your own words. If there was no negotiation, or the call was someone else's, say so plainly and stay with the quarter you pushed through | Your strongest quoted story, and it fits this live problem exactly (F3, F6). CASE first because the decision is scored; the story is supporting evidence, not the answer |
| A4 | "How would you structure 11 engineers across two squads — would you put a lead in each?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Lay out the trade-off: one manager with two tech leads, against squads that each have a lead who carries some people work. Cover what each costs in your time, in the leads' growth, and in how much context you lose. Say what you'd want to know first (the squads' maturity, any leads ready to step up). If the follow-up asks whether you've managed leads before, the plain acknowledgment: "I haven't managed managers." Then say how you'd approach it, as a plan | The step from one team of six to two squads (F1) is where a Director's structural question lands. CASE because it asks about the future; the acknowledgment rests on a negative you stated |

**B — Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see hardware in your background — how would you handle partnering with hardware on roadmap here?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company." | **Highest-ROI rehearsal in this pack.** Name the limit before you're pushed: "I haven't owned a hardware-adjacent roadmap. I'm currently at a payments company." Then give the plan, as a plan: what you'd learn first (hardware's release rhythm and lead times, what can't be fixed after a device ships, where device-management services depend on firmware), who you'd sit with in month one, and how you'd treat a dependency you can't move. Answer slot: the device-management line makes a probe likely on any device or physical-world dependency in your nine years. If any of your work touched one, say what and what part was yours, in your own words. If none did, say so plainly and return to the plan. **Follow-up 1** ("so what carries over?"): describe what you did in your own sentences (the team of six, the hiring loop, the reliability quarter) and let them draw the conclusion. Don't call it proof of anything. **Follow-up 2** ("why should I take that risk?"): hold. Add nothing new, and concede specifically: "The hardware side is the part I'd be learning, and that's real." Don't fold into vague reassurance | F5 is the gap you stated, sitting on Larkfield's core domain, so it arrives in some form in every round. JD because it scores a stated requirement. Deepest because it has the most follow-ups, the most exact concession wording, and the limit named before it's asked for |
| B2 | "You've led six. This is 11 across two squads. What breaks for you at that size?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Start with the fact at its own scope: "I've been a team lead of six for three years." Then answer as a forecast, not a history: what you expect to strain (1:1 time, context across two backlogs, becoming a bottleneck on decisions) and what you'd change first. Answer slot from F1: if you ran parallel workstreams inside your team of six, say how, in your own words. If not, say so plainly and stay with the team you led. Hold through one follow-up on the forecast, then concede specifically: you haven't run 11 | F1 is the second-most predictable objection. JD because it tests the team-size line; asked by the Skeptic because the numbers are visible |
| B3 | "Why leave payments for industrial IoT — and why now?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: your motivation isn't in your material, so it has to be yours. If there's a specific pull toward device management or physical-world systems, say what it is, in your own words. If the honest answer is mostly the step up to two squads, say that plainly; it's a legitimate reason. Keep the same answer in all three rounds, because the VP may ask it again. Don't run down your current company | The classic Skeptic motivation test, almost certain from a future boss. VAL because it scores whether your story stays consistent, not whether you can do the job |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick the real one and make it match B1: "I haven't owned a hardware-adjacent roadmap." Then one sentence of plan. Don't pick a fake weakness; a Director will notice it against B1 | A Skeptic stem that tests honest self-assessment. JD because it maps directly onto F5; it has to agree with B1 or both lose credibility |

**C — Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc with only these beats: nine years in engineering, three as team lead of six, currently at a payments company; you run the hiring loop for backend roles, about 40 interviews last year; you pushed a reliability quarter through against roadmap pressure and on-call burden dropped 60% after. Close with your B3 answer. Fill in the middle in your own words, and add nothing you wouldn't defend under a second question | The near-certain opener. EXP because the arc gets cross-checked against everything after it |
| C2 | "What does a good week look like for you as a lead?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Describe your real week as lead of six, in your own words. Answer slot from F4: the growth line makes a probe likely on how you develop engineers. If your week includes career conversations, feedback or promotion work for your six, say how. If those sit with someone else, say so plainly and describe what your week does hold | A casual question that is really scoring F4 (growth). JD because the growth line is a stated requirement |

**D — Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your team's on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, each in your own words: what was counted, and over what period; what the figure is sensitive to; the assumption behind it you'd defend least, named before they find it; and which part was yours. "I don't know exactly how it was counted" is an honest answer. Keep "after"; if other things changed in the same period, say so before you're asked | The headline metric in your material gets a defend-the-number question. EXP because attribution is what's being scored |
| D2 | "You run the hiring loop — what does that actually involve?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what running the loop involves, in your own words. Figure slot: say whether "about 40" counts interviews you sat in or interviews the loop ran, and keep "about". Answer slot for the JD's hiring line: if you designed the loop or own the hire/no-hire calls, say which and how. If not, say so plainly and stay with running the loop | F2 is your closest match to the role, so it's where a probe checks the edges. JD because it maps onto the hiring line |

### Reverse questions — Round 1

| Question | Why it lands |
|---|---|
| "Six months in, what would make you say this hire worked?" | Gets your boss's own scoring criteria into the open, and you can echo them in Rounds 2 and 3 |
| "How do the two squads split device-management work today, and where do they collide?" | Shows you're already thinking about structure (A4), and the answer prepares you for Thursday |
| "How does roadmap get negotiated between hardware, product and engineering, and who breaks ties?" | Goes straight at F5 and F6 with curiosity rather than defensiveness |
| "What's the on-call picture for these squads right now?" | A natural opening for your reliability quarter, if it hasn't come up yet |
| "Are there open roles on the 11, and how is hiring run today?" | Puts your strongest match (F2) on the table as a question, not a pitch |
| "Is this a new seat or a backfill, and what's hardest about it?" | Shows you the real job without assuming its history |

---

## Round 2 — Thursday · panel: two staff engineers + product manager · 60 min

### Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | The PM tests partnership; staff engineers test whether you'll add to their load or reduce it | high: the PM is the product partner the JD names, and the staff engineers will work under or alongside you | Frame it as reciprocity: what you bring their work, not only what you need. Propose principles for where the seams sit rather than pretending to know them |
| Data-Driven Prober | Staff engineers go two levels deeper on the 60% and the reliability quarter | high: technical peers check whether your numbers and stories hold up | Know your figures' limits; say plainly what you don't know |
| Case / Strategist | Incident and delivery problems set in device management | mid: a panel with this mix usually includes one technical-leadership scenario | Clarify first; think aloud; ask what's true here |
| Skeptic | "How technical are you?" and the hardware objection in collegial form | low, but certain to appear: objections from Tuesday come back politely | Keep the same answer as B1, word for word in substance |

### Question bank

**G — Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | PM: "We'd be partners on roadmap. Where's the seam between you and me, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Propose principles for the seam: product owns the what and the why; you own the how, the when, team capacity and team health; trade-offs get decided together. On disagreement: bring the cost in numbers, decide together, and never escalate around them. Your one quoted instance, in its own words: you pushed a reliability quarter through against roadmap pressure. Answer slot from F6: if product was on the other side, say what happened and what part was yours. If not, say so plainly and stay with the quarter | F6 tested by the actual partner. JD because product partnership is a stated line |
| G2 | Staff engineer: "How do you decide what you weigh in on technically, versus what you leave to staff engineers?" | CASE | [generic] | Principles, not a history: you weigh in where delivery, risk or people are at stake; you leave design to the people who own it; you ask for written trade-offs on decisions that are hard to reverse. Ask them where they'd want the line drawn | The seam staff engineers care most about. CASE because it scores judgment; `[generic]` because it makes no claim about your past |
| G3 | PM: "Hardware slips a firmware release by six weeks and our launch depends on it. What do you do this week?" | CASE | [generic] | Clarify: what's committed to customers, what can ship without the firmware, and what's fixed versus negotiable. Then: re-plan with the PM, tell stakeholders early, look for an option that splits the dependency, and agree the next checkpoint with hardware. Ask how often this happens here | Combines F5 and F3 in a problem you can reason through without hardware history. CASE because it's delivered live |
| G4 | Staff engineer: "What would you need from us in your first month, and what would you give back?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Need: context on the system and the hardware seam, and their honest read of the team. Give: clear priorities, protected focus time, and fast decisions. On hiring, say it in the quote's own terms: you run the hiring loop for backend roles, so you can take hiring work off their plate. Don't promise outcomes | Reciprocity is what peers score. JD because it touches hiring (F2) and growth |

**H — Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | Staff engineer: "On the reliability quarter — what was actually in it, and how was the work picked?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what was in it, in your own words. Answer slot: if you chose the work, say how. If the team or someone else chose it, say so plainly and describe what you pushed through. The quote says you pushed it through; keep that verb, and don't widen it to designed or built | Staff engineers will dig past the headline. EXP because they're scoring what was actually yours |
| H2 | Staff engineer: "How do you know the 60% held after the quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The "sensitive to" slot, in your own words: whether you know it held, and over what period. "I don't know whether it held" is an honest answer. Name the assumption you'd defend least before they do | A second level on D1's figure, which is what Probers do. EXP for attribution and durability |
| H3 | PM: "How do you own delivery today — who sets the dates your team commits to?" | JD | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot from F3: if you set or negotiated delivery dates and scope for your team of six, say how, in your own words. If they were set elsewhere, or there were none, say so plainly and describe what you did own: the reliability quarter you pushed through. Don't describe a planning process you didn't run | F3 is a low-confidence row, so it's rehearsed with the honest branch ready. JD for the delivery line |

**J — Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | Staff engineer: "A config rollout from a device-management service breaks some field devices. How do you run the incident, and what changes after?" | CASE | [generic] | Stop the rollout; work out how far the damage reaches; set up communication with hardware, product and support; find a recovery path, including for devices you can't reach remotely. Afterwards, a blameless review, then structural fixes such as staged rollouts and rollback. Say these are patterns you'd check against how Larkfield already works, and ask | A plausible failure mode for this domain, asked as a live problem. `[generic]`: role-family pattern, no claim about Larkfield's systems |
| J2 | Staff engineer: "How would you set up on-call for services that talk to devices on customer sites?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure: what pages and why, who's on the rotation, escalation to hardware, and limits on the load. Cite your instance in its own words only: you pushed a reliability quarter through and on-call burden dropped 60% after. Ask what the current rotation looks like | Brings your strongest story into their domain without stretching it. CASE because it's scored as design |
| J3 | Staff engineer: "How would you interview for a staff engineer here?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Structure the loop: what a staff engineer means here (ask them), which signals each stage tests, and how you'd calibrate. Anchor in the quote: you run the hiring loop for backend roles. Answer slot: if you designed parts of your current loop, say which. If not, say so plainly and stay with running it | F2 in a form the panel cares about directly. CASE because it's a design problem |

**K — Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | Staff engineer: "How technical are you still?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: your material doesn't show your current hands-on depth. If you still review designs or write code, say how much, in your own words. If you don't, say so plainly and say how you'd stay close enough to judge trade-offs. Don't overstate it; they'll test it on the spot | The standard peer probe of a manager candidate. EXP because it checks a claim live |
| K2 | PM: "How do I know you won't treat firmware like just another backend dependency?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The same answer as B1, kept consistent: "I haven't owned a hardware-adjacent roadmap." Then describe what you understand to be different (dependencies that can't be patched once shipped, longer lead times) as things you'd check with them, and ask what has caught people out before | B1's objection in collegial form. If your Thursday answer drifts from Tuesday's, the debrief will notice |

### Reverse questions — Round 2

| Question | Why it lands |
|---|---|
| "What could a new manager do in the first month that would genuinely help your work?" | The reciprocity question; it signals you're there to reduce their load |
| Staff engineers: "Where do you want more technical say than you have now, and where less?" | Opens the G2 seam on their terms |
| PM: "The last time engineering and product disagreed, how did it get settled?" | Tells you how the F6 partnership really works |
| "What does the hardware team need from this team that it doesn't get today?" | Turns F5 into curiosity |
| "What do you wish new people understood earlier about device-management work?" | Gives you domain insight from the people who do the work |

---

## Round 3 — Monday · VP Engineering · "values and leadership philosophy" · 30 min

The recruiter's description makes this a values-style round. A values cheat sheet would normally go here, but it needs Larkfield's published values in hand, and the search that would have found them was refused. The VAL questions below take their themes from the recruiter's words and from standard behavioral prompts instead.

### Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" prompts and "what's your philosophy" | high: the recruiter named values and leadership philosophy as the subject | Stories where the hard truth actually landed; "we" for context and "I" for your contribution |
| Case / Strategist | Questions at org level and about what a good hire looks like | mid: an executive tests whether you think beyond your team | Clarify, then structure; ask what's true here |
| Pressure | Short time-boxed challenges in a 30-minute slot | mid: at this level they check composure under a short clock | Pause, restate, anchor in your quotes, and hold twice before conceding |
| Conversational | Warm-up and the reverse-question slot | low: 30 minutes leaves little room for small talk, but the close is still scored | Have your reverse questions ready, and never say "you've covered everything" |

### Question bank

**L — Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | Two or three principles you actually hold, each tied to something real. If they're genuinely yours: one about protecting the team's health against roadmap pressure, anchored in the quarter you pushed through; one about hiring, anchored in running the backend hiring loop. For growth, use an answer slot: if you have a growth practice for your six, name it in your own words; if not, say how you'd approach it. Principles you can't anchor are slogans, so cut them | The recruiter named this round's subject, so this question is close to certain. VAL because it scores whether your stated beliefs match what you've done |
| L2 | "Tell me about a time you pushed back on leadership or the roadmap." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the quote: roadmap pressure, you pushed the reliability quarter through, and on-call burden dropped 60% after. Tell those beats in your own words. Answer slot: if you made the case to leadership yourself, say what you said and how it landed, including whether the relationship held. If the pressure came from elsewhere, or there was no such conversation, say so plainly and tell the quarter as it happened | Your single best values story, tested against "leadership philosophy". VAL; the bar is that the hard truth actually landed |
| L3 | "Tell me about a time you dealt with an engineer who wasn't performing." | VAL | [generic] | Selection scaffold: pick a real case from your three years as lead with a named situation, what you did, and how it ended, good or bad. Use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The growth line (F4) asked as a values story. `[generic]` because no quoted sentence carries this story yet |
| L4 | "How do you decide who gets promoted, and how do you keep it fair?" | VAL | [generic] | Principles: clear expectations written down in advance, evidence over impressions, and checking your own bias with peers. Answer slot from F4: if you've written or argued promotion cases, say how, in your own words. If not, say so plainly and say how you'd do it for 11 | F4 at the VP's level. VAL because fairness is the value being tested |

**M — Case / Strategist (executive)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Device-management services sit between hardware and the cloud. Where would you expect this org to be fragile?" | CO | [generic] | No research ran, so don't claim any knowledge of Larkfield. Reason from the role: hand-offs between hardware and software teams, release timing, field support, and on-call. Then turn it around: "Where is it actually fragile today?" | CO question at executive level; `[generic]` because no strategy research reached this pack. The upgrade menu says what would fix that |
| M2 | "In a year, how would I know you were a good hire?" | CASE | [generic] | Propose measures: delivery predictability, on-call health, retention and growth of the 11, hiring hit rate, and how hardware and product rate the partnership. Ask which of these matter most to them | Executives test whether you define success the way they would. CASE because you're structuring an answer |
| M3 | "One squad loses its strongest engineer mid-quarter. What do you do?" | CASE | [generic] | The people side first (why they left, what others now fear), then delivery (re-plan with product, spread the knowledge), then a backfill plan. Mention what you'd change so one departure isn't a single point of failure | Tests leadership under a real constraint. CASE, with no past claimed |

**N — Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| N1 | "Sixty seconds: why you over an internal candidate who already knows our hardware?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, then concede first: "I haven't owned a hardware-adjacent roadmap." Hold on what your quotes carry: three years leading a team of six, running the backend hiring loop, and pushing a reliability quarter through. Let them draw the conclusion. Never run down the hypothetical candidate. Second push: hold, and don't add new claims | B1's objection on a clock. JD because it scores the hardware line under pressure |
| N2 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the quote: "I pushed a reliability quarter through; on-call burden dropped 60% after." Answer slot: say which part was yours, in your own words. If other things changed in the same period, name them before they do. If you don't know, say so. Concede on causation if pushed; don't concede the part that was yours | The attribution stem, aimed at your headline figure. EXP because it's honesty under pressure |

**P — Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You run a hiring loop — what has it taught you that you'd bring here?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | One or two lessons you actually took from running the loop, in your own words. Answer slot: if you changed the loop because of what you learned, say what. If not, say so and state the lesson | A casual question that's really about values in hiring (F2). VAL because the VP is scoring what you value in people |
| P2 | "What are you thinking about in leadership right now?" | VAL | [generic] | Answer slot: one real thing you're working through, such as the step to two squads or partnering with hardware, said honestly. Don't name a book you haven't read | A rapport question that still gets scored. `[generic]`, with no past claimed |

### Reverse questions — Round 3

| Question | Why it lands |
|---|---|
| "What leadership behavior do you most want more of across your managers?" | Asks the VP's values directly, which this pack couldn't research |
| "How do you see this org changing over the next year or two?" | Thinking at executive level, without claiming to know Larkfield's strategy |
| "When a team here pushes back on roadmap for reliability reasons, how does it usually go?" | Connects to L2 and tests the culture you'd be working in |
| "What's one decision you'd want a manager in this seat to escalate, and one you'd want them to just make?" | Shows you're thinking about trust and autonomy |
| "How do managers here grow? What does good look like for someone stepping up to more?" | Honest ambition, and it fits your stated gap on managing managers without turning it into a confession |

---

## Requirement coverage

| Requirement (role description) | Question IDs |
|---|---|
| Lead two squads (F1) | A1, A4, B2 |
| Building device-management services (F7) | A1, B1, J1, M1 |
| Own delivery (F3) | A2, A3, G3, H3 |
| Own hiring (F2) | D2, G4, J3, P1 |
| Own growth for 11 engineers (F4) | C2, L3, L4 |
| Partner with hardware on roadmap (F5) | B1, B4, A2, G3, K2, N1 |
| Partner with product on roadmap (F6) | A3, G1 |
| Defend-the-number: the 60% figure | D1, H2, N2 |
| Defend-the-number: about 40 interviews | D2 |

---

## Prohibited claims (shared)

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F5 evidence | "I haven't managed managers." |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | "I haven't owned a hardware-adjacent roadmap." |
| Led two squads, or a team of 11 | Inflated form of F1 | F1's quote at its own scope: team lead of six for three years. The limit is this pack's observation: your material says one team of six. B2's slot stays inside that team |
| The reliability quarter caused the 60% drop | Inflated form of the F3/F6 quote ("after" turned into "because") | The quote as written: on-call burden dropped 60% after you pushed the quarter through. Which part was yours is D1's and N2's slot |
| Designed or built the reliability work | Inflated form of the same quote ("pushed through" turned into "designed") | "I pushed a reliability quarter through against roadmap pressure." H1's slot asks who chose the work |
| Personally conducted 40 interviews | Inflated form of the F2 quote ("about 40", with the count's subject unclear) | "I run our hiring loop for backend roles — about 40 interviews last year." D2's slot asks whose interviews they were |

---

## Sources

- **Provided:** the role description you quoted; your four sentences about yourself; the round schedule and the recruiter's description of Monday's round, from your message.
- **Searches sent:**
  - "Larkfield Systems values": refused (search permission not granted)
  - "Larkfield Systems interview process engineering manager": refused
  - "Larkfield Systems industrial IoT news": refused
- No fetches. No dossier consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The call was refused. It would have supplied Monday's values cheat sheet and VAL questions mapped to Larkfield's own named values |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The call was refused. Your message already establishes the three rounds, so persona weights stand. It would have added documented case formats or panel structure |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The call was refused. It would have grounded M1 and a CO question for each round in Larkfield's current priorities, instead of `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form; there's no interviewer read |
| 5. representative Engineering Manager JD | skipped | The role description you quoted fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Web search permission** → targets 1–3 rerun: a Monday values cheat sheet mapped to Larkfield's published values, CO questions grounded in current strategy (M1 and one per round), and any documented panel format
- **Deep research pass (up to 6 more searches and 2 more fetches, several more minutes, once search is allowed)** → a strategy brief and recent org context, for a grounding section on how Larkfield talks about itself
- **Your CV** → richer evidence in every F row, and stories for L3 and L4, which are currently selection scaffolds
- **The full JD text** → any requirements missing from the one-line description become fit rows, each with a JD question
- **Interviewer names (Director, staff engineers, PM, VP)** → an interviewer read per round, persona weights read from their public professional footprint, and a reverse question tied to each one's career path
- **Your answers to the slots in F1, F3, F4, F6 and F7** → B2, H3, C2, L4, G1 and B1 rebuilt as story-mapped answers in your own words
- **The report or dashboard the 60% came from** → F3 and F6 move toward `high` confidence, and D1, H2 and N2 can be answered from the source
- **The recruiter's prep notes for Thursday** → a build section, if the panel expects a presentation or exercise
- **How many prep hours you have** → a prioritized triage schedule across the three rounds
- **A tuesday-dossier.md from job-underwriter** → evidence verified against documents and a prohibited-claims list from that review, instead of the one this pack built locally; never required
