I'm reading the prep skill's rules; next I'll run a few targeted searches on Larkfield, then write your three-round pack.
I've built one prep pack for all three rounds. It shares a fit snapshot across rounds, and each round gets its own question bank (10, 11 and 8 questions) and its own questions to ask them. The web searches were blocked in this session, so nothing in the pack about Larkfield's values, strategy or interview process comes from research. It's built only from your message, so the company-knowledge questions are generic and there's no values cheat sheet for Monday.

The pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-6-denied-d45f385b/larkfield-systems_engineering-manager_interview_pack.md`.

**What runs through all three rounds:**
- **The objection to rehearse most (question A1):** "You've led six; this is two squads and eleven." It will come up in every round in some form:
  - Tuesday as A1.
  - Thursday as the staff engineers' "where's the line between your calls and ours".
  - Monday as a 60-second challenge.

  Name the limit yourself before they do: "For three years I've led a team of six." Then give a plan.
- **Hardware:** You said you've "never owned a hardware-adjacent roadmap", so the pack doesn't try to close that gap. The words are yours ("I haven't owned a hardware-adjacent roadmap"), followed by a ramp plan said as a plan, not as past experience.
- **The 60% figure:** Keep your own wording: on-call dropped 60% *after* you pushed the reliability quarter through. Don't let it become "I cut on-call by 60%". Expect the staff engineers to ask how it was counted. If you don't know exactly, saying so is a credible answer.
- **Hiring:** This is your best match to the role. Keep "about 40 interviews" as interviews; never let it become 40 hires.
- **Gaps the pack doesn't fill:** Delivery ownership, growing people, partnering with product and device experience aren't covered by what you told me. Those questions have "answer slots": say what you did if you did it, and say so plainly if you didn't.
- **Questions for Tuesday:** Ask the Director whether the squads have leads reporting into this role. The answer tells you whether "I haven't managed managers" is even relevant to the job.

Say the word and I'll play the Director and run A1 with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I'll convert it.

Can you paste the full job description and your CV, or a few lines about your current role? I'll keep working from your message if not, but it would turn several answer slots into your own stories. Did the recruiter say whether Thursday's panel includes a design exercise, a case or a presentation? If it does, I'd add a section to build it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack — Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop — three scheduled rounds, one shared fit snapshot, one mini-pack per round
**Rounds (from your message):**

| Round | When | Length | Who | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | 45 min | Director of Engineering | Hiring manager, would-be boss |
| 2 | The Thursday after | 60 min | Two staff engineers and a product manager | Panel: technical peers plus cross-functional partner |
| 3 | The following Monday | 30 min | VP Engineering | Skip-level; recruiter described it as "values and leadership philosophy" |

No interviewer names were given, so there is no interviewer read. Web search was refused in this session, so nothing here about Larkfield's values, strategy or process is researched — see Sources.

---

## How to use this pack

- **Personas** describe *how* a question arrives (a friendly opener, a quiet skeptic, a time-boxed challenge). **Types** describe *what* is being scored.
- **Type key:**
  - **VAL** — behavioral / values: does your past behavior show the values they care about
  - **EXP** — experience deep-dive: do your claims survive scrutiny; what was actually you
  - **JD** — role-driven: can you do the listed job, gaps included
  - **CO** — company and strategy knowledge
  - **CASE** — a live problem from the role, solved out loud
- **Provenance labels:** `[grounded]` rests on your own words, quoted; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about you or Larkfield.
- **Answer slots** are places where the pack does not know what happened. Each one has two honest branches: if you did it, say how in your own words; if you didn't, or it didn't exist, say so plainly.
- Guidance is scaffolding, not a script. Say it in your words.

---

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description you gave. Evidence is quoted from your message, and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message. "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | One team of six is adjacent to two squads of eleven, and the words stay at that scope: "For three years I've led a team of six." Answer slot: the two-squad line makes a probe on leading more than one team likely. If you have led work that spanned more than one team, say what it was and which part was yours; if not, say so plainly and stay with the team of six. If asked about managing through leads, the words are yours already: "I haven't managed managers." |
| F2 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote shows one prioritization call; it does not show whether delivery commitments for the team were yours. Answer slot: if you set or owned your team's delivery commitments, say how, in your own words; if that sat with someone else, say so plainly and return to the reliability quarter |
| F3 | "own ... hiring" — role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you run the hiring loop for backend roles, about 40 interviews last year. Keep the 40 attached to interviews. Answer slot: the "own hiring" line makes a probe on the final hire decision likely. If that decision was yours, say how you made it; if it was not, say plainly who made it and stay with running the loop |
| F4 | "growth for 11 engineers" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | Leading a team touches growth but does not show it. Answer slot: if you have grown someone on your team, name one case in your own words and what part was yours; if not, say so plainly and say what you would do first with eleven people |
| F5 | "partner with hardware ... on roadmap" — role description | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "partner with ... product on roadmap" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote shows you pushing against roadmap pressure; it does not say where the pressure came from or whether product was the partner. Answer slot: if you worked that through with a product counterpart, say how, in your own words; if the pressure came from elsewhere, or there was no product partner in it, say so plainly and stay with what you pushed through |
| F7 | "building device-management services" — role description | none given | none | [grounded] | discovery | Your material does not show work on device-management or IoT services. Answer slot: if any of your work has managed devices or device fleets, say what in your own words; if none has, say so plainly and say how you would ramp on the domain |

**Gates:** none. The role description names no location, authorization, credential or schedule term.

**The highest-ROI prep in this pack is A1** — "This is two squads and eleven engineers; you've led six." It is the most predictable objection to you, it will come in some form in all three rounds (A1, J1, and the panel's collegial version in D1), and F1 is where the role presses hardest on your material.

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Lead two squads | A1, B2, J1, K2 |
| F2 Own delivery | A5, B1, G2 |
| F3 Own hiring | B3, D3, E3 |
| F4 Growth for 11 engineers | B2, G3, H4 |
| F5 Partner with hardware on roadmap | A2, A4, B1, D4 |
| F6 Partner with product on roadmap | D2, D4, G2 |
| F7 Device-management services | C2, G1, K1 |

---

## Round 1 — Tuesday, 45 min, Director of Engineering (hiring manager)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Why you, at this scope, with no hardware?" — quiet, persistent | High. A hiring manager is derisking gaps, and F1 and F5 are the two visible ones | Name the scope step yourself before it's asked; bridge only from F1's and F5's quotes; give a ramp plan said as a plan |
| Case / Strategist | Live problems from the job: a hardware slip, a staffing call | High. Hiring managers buy capability through live problems on their own roadmap | Clarify, then objective, then options, then risks; think aloud |
| Conversational | Friendly opener, "walk me through your path" | Medium. Most 45-minute manager rounds open this way, and it is still scored | A rehearsed 90-second arc built only from your quotes |

### Bank

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led a team of six. This is two squads and eleven engineers. What changes for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI rehearsal.** Name the limit before they do: "For three years I've led a team of six." Answer slot: if you have led work that spanned more than one team, say what and which part was yours; if not, say so plainly. Then the plan, said as a plan: two or three things you expect to change, in your own words — where your time goes, who you lean on in each squad, how you keep one view of delivery across both. Follow-up 1, "But you haven't done it": concede it in one sentence and return to the plan. Follow-up 2, "Have you managed managers?": "I haven't managed managers." Then ask whether the squads have leads reporting to this role (reverse question R1-1). Never round six up | F1 is the visible scope gap and the role's core; JD because it scores the stated two-squad mandate |
| A2 | "I don't see hardware in your background. How would you partner with a hardware team on a roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | "I haven't owned a hardware-adjacent roadmap." Then the plan, as a plan: what you would learn first from the hardware team (their release cadence, lead times, what can't change after a device ships), who you would sit with in week one, how you would make cross-team dependencies visible. End by asking how hardware and software plan together today. Do not borrow any hardware vocabulary as experience | F5 is a capability gap you stated; a Director who owns this partnership will test it directly |
| A3 | "Why leave payments for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Three beats: where you are (a team lead at a payments company), what draws you to this role, and why now. Answer slot: the second and third beats are yours alone; say them in your own words, and if the honest answer is mostly about the scope step rather than the domain, say that — it's a fine answer. Avoid criticizing your current employer | F7 and F1 make motivation the Skeptic's natural follow-on; JD because it tests fit with this role's domain |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick the real one, not a disguised strength: "I haven't owned a hardware-adjacent roadmap." Then the first two steps of your ramp, as a plan. Stop there — a long answer to this question reads as anxiety | F5 is the honest answer, and you already hold its words; JD because it scores self-assessment against the listed job |
| A5 | "How does delivery work on your team today, and what part of it is yours?" | JD | [inferred] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: if you set or own your team's delivery commitments, describe how in your own words; if they sit with someone else, say so plainly and say what you do own. Then the one prioritization call the quote carries: you pushed a reliability quarter through against roadmap pressure, after which on-call burden dropped 60%. Keep "after" — don't turn it into "caused" | F2 is thin and "own delivery" is a headline duty; `[inferred]` because the link from the quote to delivery ownership is this pack's |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Hardware tells you a device revision slips six weeks, and one of your squads' releases depends on it. Walk me through your next 48 hours." | CASE | [generic] | Clarify first: what exactly slips, what's fixed and what's movable, who outside the squad is affected. Then options (decouple, re-sequence, ship partially, hold), who you tell and when, what you'd write down. Name the premise you'd challenge: whether the dependency is as hard as it looks. Make no claim about your past here | F5 and F2 meet in this problem; CASE because it scores structure, not history |
| B2 | "You inherit two squads. One is shipping well; one is buried in on-call. What do you do in your first 60 days?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure: listen and measure first, then decide what each squad needs, then sequence. You may bring in the one story your quote carries, at its own words: you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Don't add how you ran it unless you're ready for the follow-up. Say how you'd keep the healthy squad from being starved of your attention | F1 and F4 in one problem, and the one place your strongest quote fits a live case; CASE delivery, with an optional EXP tie |
| B3 | "You have one open req and both squads want it. How do you decide?" | CASE | [generic] | Clarify what each squad's problem is and whether a hire solves it; set criteria (risk, roadmap, team health); decide, and say how you'd tell the squad that didn't get it. Keep hiring claims out — the question asks for judgment | F3's requirement asked as a decision; CASE because it is a live staffing call |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through your path." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc, only these beats: nine years in engineering, three of them leading a team of six, now at a payments company; you run the hiring loop for backend roles, about 40 interviews last year; your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. Close with one line on why this role. Rehearse it out loud until it lands under two minutes | Every round may open this way; EXP because each beat is a claim they can probe |
| C2 | "What do you know about what we build?" | CO | [generic] | Say only what you were told: industrial IoT, about 600 people, device-management services. Then say what you'd want to learn and ask one question back. Do not fill the gap from guesswork — this pack could not research Larkfield, and an invented fact about their product is worse than a plain "here's what I'd want to understand" | F7's domain, asked casually; CO, and `[generic]` because research could not run — see the upgrade menu |

### Reverse questions — Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Do the two squads have leads reporting into this role, or are all eleven direct reports?" | It turns F1's question into a fact you need, and tells you whether managing managers is actually in the job |
| R1-2 | "How do hardware, product and software engineering set the roadmap together today, and where does it hurt?" | It gets you the real shape of F5 from the person who owns it, before Thursday's panel |
| R1-3 | "What would a strong first 90 days look like to you?" | It's the Director's own success criteria — and your answer to K2 on Monday |
| R1-4 | "What's the biggest delivery risk in the device-management services right now?" | It shows you're already thinking like the owner, and it feeds your panel prep |
| R1-5 | "Why is this role open?" | New role, backfill or a split team each change what the first year is for |

---

## Round 2 — The Thursday after, 60 min, panel: two staff engineers and a product manager

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | "Where's the line between your calls and ours?" (staff); "How do we settle trade-offs?" (PM) | High. Every panelist will work beside you and is pricing what you add to or take off their load | Reciprocity framing; propose seam principles rather than pretending to know their seam |
| Data-Driven Prober | Staff engineers taking your numbers apart | High. Your 60% and your 40 interviews are the two figures in your material, and engineers probe figures | Know what you can and can't say about how each was counted; name the weakest assumption first; say "I don't know" where you don't |
| Case / Strategist | A live reliability or prioritization problem | Medium. Panels with a PM often run one shared scenario | Same structure as Round 1; bring both perspectives in the room into the answer |

The panel blends two relationships, so weights are shown per member: staff engineers lean Prober and Peer; the PM leans Peer and Case.

### Bank

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | (Staff engineer) "Where do you draw the line between your decisions and ours on technical direction?" | JD | [generic] | State a principle, not a rule: what you'd expect them to decide, what you'd want to be consulted on, and how you'd break a deadlock. If you have a real example of handing a decision to a senior engineer, use it only in your own words; if not, keep it as a principle. This is also where A1's scope worry returns politely — two squads means you can't be in every design review | The collegial form of F1's objection; JD because it scores how you'd lead two squads alongside staff engineers |
| D2 | (PM) "When product wants features and engineering wants reliability work, how do we settle it?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story beats, only what the quote states: there was roadmap pressure; you pushed a reliability quarter through; on-call burden dropped 60% after. Answer slot: the PM will ask who you were pushing against and how you made the case. If it was a product partner, say how you worked it through, in your own words; if the pressure came from elsewhere, say so plainly. Then the forward-looking principle: how you'd want to make that call with this PM | F6 is thin and the PM is your roadmap partner; JD because it scores the product partnership directly |
| D3 | (Staff engineer) "What would you need from us in your first month, and what would you take off our plates?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Ask for little and offer something concrete: context, their view of the riskiest service, one honest read of each squad. On taking things off them, the offer your material supports is hiring: you run a hiring loop today. Say what you'd want to learn about their loop before changing anything | Reciprocity question for peers; F3 is the one strength that directly lightens a staff engineer's load |
| D4 | (PM) "Hardware, product and your squads all shape the roadmap. How do you keep the three in step?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plan first: a shared view of dependencies, a regular forum, an escalation path. If pressed on hardware experience: "I haven't owned a hardware-adjacent roadmap." Then what you learned from the Director on Tuesday about how it works today — use only what you were actually told | F5 and F6 together, the job's three-way seam; JD because it is the stated partnership requirement |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your team's on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slots, all in your own words: how the 60% was measured; what it is sensitive to; the assumption behind it you'd defend least, named before they ask; and which part was yours. If you don't know exactly how it was counted, say so plainly — that is a credible answer to a staff engineer, and a reconstructed method is not | The headline metric in your material; EXP, and the Prober's first target |
| E2 | "How much of that drop was the reliability quarter, and how much was other things?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold what the quote says: the drop came after the reliability quarter. Don't upgrade "after" to "because of". Answer slot: if you know of other changes in the same period, name them; if you don't, say so. Hold through two follow-ups by returning to what you pushed through; concede attribution uncertainty specifically, never the fact that you pushed it | F2's quote under attribution pressure; EXP because it scores what was actually you |
| E3 | "Your hiring loop — what does it actually test for, and how do you know it works?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slots: what the loop tests, in your own words; whether you designed it or inherited it; whether you track anything about how hires turn out, and if you don't, say so. On the 40: say plainly whether that counts interviews you ran or interviews across the loop, and don't let it become 40 hires | F3 is your strongest requirement match; engineers will check it's real |
| E4 | "Tell me about a technical decision on your team you disagreed with. What happened?" | EXP | [generic] | Pick a real one: a named stake, what you argued, what was decided, and how the relationship ended. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you'd handle it. Staff engineers are checking whether you still argue on technical merits | Tests technical credibility with peers who'll judge it; open prompt, so the pack supplies no story |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | (Staff engineer) "Suppose a device-management service your squads own pages someone three nights a week. You own it now. What do you do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Clarify: what pages, why, who's carrying it. Then triage, then the case for dedicated reliability time, then how you'd measure progress. You may bring in your quote at its own words. Ask one question about device fleets you'd need answered — that shows F7 honestly rather than hiding it | Your strongest story placed in their domain; CASE because it is a live problem |
| G2 | (PM) "A big customer escalation and a committed roadmap date land in the same sprint. Walk us through it." | CASE | [generic] | Clarify severity and who decided the date; options; who you bring into the call (the PM is in the room — include them); how you communicate the trade-off. Make no claim about your past | F2 and F6 as a live call with your future partner watching |
| G3 | (Staff engineer) "An engineer on one squad is strong technically but keeps clashing with peers. How do you handle it?" | CASE | [generic] | Structure: gather facts privately, give direct feedback with examples, agree what changes, follow up, and what you'd do if it doesn't. If you have a real case, use it only in your own words | F4's growth requirement asked as a problem |

### Reverse questions — Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | (Staff engineers) "What could a new manager do in the first month that would genuinely help you?" | Reciprocity: it puts their load first |
| R2-2 | (Staff engineers) "Which decisions do you most want a manager to stay out of?" | Shows you'll respect their lane, and tells you where it is |
| R2-3 | (PM) "Where does the hardware schedule constrain you most?" | It gets you the seam from the product side, complementing R1-2 |
| R2-4 | (PM) "How are roadmap trade-offs between features and reliability made today?" | It's your D2 story's real question, asked of the person who lives it |
| R2-5 | (All) "What's on-call like for the device-management services?" | Invites the topic where your material is strongest, without claiming anything |

---

## Round 3 — The following Monday, 30 min, VP Engineering ("values and leadership philosophy")

A values-style round is detected here: the recruiter's description names it. Larkfield's published values could not be fetched, so this pack has **no values cheat sheet** and VAL questions are themed from the recruiter's words, not Larkfield's value names.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…", "what's your philosophy" | High. The recruiter named it, which outweighs the usual skip-level tilt | Stories only from your quotes, or a scaffold with its honest branch; "we" for context, "I" for your part |
| Pressure | Time-boxed "why you" challenges | Medium. Skip-level rounds test composure, and 30 minutes forces short answers | Pause, restate, hold the position your quotes carry through two follow-ups |
| Case / Strategist | Altitude checks: "how would I know you were a good hire" | Low-medium. A VP still checks you can think at org level | Structured, short, measurable |

### Bank

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | Two or three principles, each in a sentence, in your own words. Back each one either with something your quotes carry — the reliability quarter you pushed through against roadmap pressure, the hiring loop you run — or say plainly it's a belief you'd act on here. A philosophy with no example sounds rehearsed; one with an invented example breaks on the follow-up | The recruiter's own description of this round; VAL because it scores leadership values |
| H2 | "Tell me about a time you pushed back on leadership's priorities." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story beats, only what the quote states: roadmap pressure; you pushed a reliability quarter through; on-call burden dropped 60% after. Answer slot: if the pressure came from leadership, say who and what you said, in your own words; if it came from elsewhere, say so. Then how the relationship stood afterwards — if you know, say it; don't supply a happy ending | Your one story where the hard call landed; VAL, harmony-with-spine |
| H3 | "Tell me about a call you got wrong as a leader." | VAL | [generic] | Pick a real one: what you decided, what went wrong, what you changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing, or how you'd handle it. A VP is scoring self-awareness, so a small honest mistake beats a polished non-mistake | A staple of leadership-philosophy rounds; open prompt, so no story is supplied |
| H4 | "How do you balance growing people with delivering?" | VAL | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | State your view in your own words. Answer slot: if you've grown someone on your team of six, give one case and your part; if not, say so plainly and say what you'd do first with eleven. Don't present growth practices as ones you've run unless you have | F4 is thin and growth is a named duty; `[inferred]` because the link from leading a team to growing people is this pack's |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you over someone who's already managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Pause. Concede first, in one line: "I haven't managed managers." Hold on what your quotes carry: three years leading a team of six, and running the hiring loop. Then one sentence on why the step makes sense for you now. Hold through two follow-ups; concede the gap, never your record | A1 at VP altitude and time-boxed; JD because it scores the role's scope |
| J2 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: you pushed the reliability quarter through. The team did the work, and the drop came after. Answer slot: if you know what else changed, say it; if not, say so. Concede attribution precisely; don't fold on the decision you made | The Pressure stem aimed at your headline metric; EXP because it scores attribution honesty |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What do you think is the hardest part of device management at industrial scale?" | CO | [generic] | Be honest about altitude: say what you'd expect to be hard from an engineering view, frame it as a hypothesis, and say what you learned in Rounds 1 and 2 — only what you were actually told. Don't present guesses as knowledge of Larkfield | F7 at VP altitude; CO, `[generic]` because strategy research could not run |
| K2 | "A year from now, how would I know you were a good hire?" | CASE | [generic] | Three or four measurable outcomes across delivery, team health, hiring and the hardware partnership. Tie them to what the Director said success looks like (R1-3) | F1 to F5 framed as outcomes; CASE because it scores how you define success |

### Reverse questions — Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What leadership behavior do you want more of in your managers?" | It's the round's own topic, asked back |
| R3-2 | "What separates the managers who thrive here from the ones who struggle?" | You learn the real bar, and it shows you plan to meet it |
| R3-3 | "How does the org handle the tension between roadmap and reliability?" | Your strongest story's theme, asked at org level |
| R3-4 | "What would you want someone coming from payments to unlearn?" | Shows openness and names the domain switch before they do |
| R3-5 | "How do you see the engineering manager role changing here over the next two years?" | Altitude question for a VP |

---

## Prohibited claims (shared)

What this pack will not coach, in any round.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | "I haven't owned a hardware-adjacent roadmap." No slot |
| Has led two squads or a team of eleven | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material says a team of six for three years |
| "I cut on-call by 60%" | Inflated form of F2 — "after" becomes "caused", and "I pushed" becomes "I cut" | F2's quote as written: on-call burden dropped 60% after you pushed a reliability quarter through |
| Owns hiring decisions, or hired 40 people | Inflated form of F3 — running a loop becomes owning hiring, and 40 interviews becomes 40 hires | F3's quote at its own scope: you run the hiring loop for backend roles, about 40 interviews last year |

---

## Sources

**Provided:** your message (the role description, the three rounds, and your background).

**Searches sent:**
- "Larkfield Systems values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT news 2026" — refused

**Loop basis:** your own words establish the loop — three rounds, each with who runs it — so persona weights follow your schedule, not an archetype. The VP round counts as a values-style round because the recruiter described it that way.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Every call was refused. Would have moved: a values cheat sheet for Round 3, and H1 to H4 mapped to Larkfield's own value names |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Every call was refused. The loop itself comes from your words; this would have added format detail, such as whether the panel includes a design exercise |
| 3. Larkfield Systems strategy and recent news | unavailable | Every call was refused. Would have moved C2 and K1 from generic to company-grounded, and added a strategy-grounded case |
| 4. Interviewer names | n/a | No names were given, so no query could be formed; there is no interviewer read |
| 5. Representative engineering manager JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text** → mid-list requirements this short description leaves out (tools, methods, on-call or travel expectations) get their own fit rows and questions
- **Your CV, or a few lines on your current role** → more of your own sentences to quote; F2, F4, F6 and F7 may move from answer slots to story maps
- **Your answers to the answer slots in F2, F4, F6 and F7**, told to me outside a drill → those rows and A5, D2, H2, H4 regenerate with your words in them
- **Larkfield's values page, pasted, or web search allowed** → a values cheat sheet for Monday, with each value mapped to one of your quoted stories
- **Web search allowed** → company-grounded C2 and K1, and a case built on Larkfield's current direction; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available on request after that
- **Interviewer names** → a public-footprint read per interviewer, per-panelist persona weights for Thursday, and reverse questions tied to each person's path
- **Recruiter's note on the panel format** (whether it includes a design exercise, a case or a presentation) → a build section for any graded deliverable
- **How much prep time you have** → a prioritized schedule across the three rounds
- **A tuesday-dossier.md from the job-underwriter skill** → evidence-verified rows, a named strategy for each weak area, and an underwriter-sourced prohibited list instead of this locally built one
