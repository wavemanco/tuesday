Reading the skill's rules before building your Stripe pack — next, research and drafting.
I built your prep pack: **Stripe_product-operations-manager_interview_pack.md**. I only had your one-line message, and this session blocked all four web searches I tried. So I assumed a final round with a mix of sessions. Every row is a general pattern for product operations roles, not a claim about Stripe or about you, and I didn't use anything I remember about Stripe in its place.

What's in the pack:
- **22 practice questions**, grouped by interviewer style. Live cases and values questions carry the most weight.
- **A worksheet of 8 typical requirements** for this kind of role. Fill it in with your own examples before the interview; that's the single most useful thing you can do with it.
- **Six questions to ask your interviewers.**
- **One question to rehearse hardest:** C1, "Which part of this role would you be weakest at on day one?" It comes with an answer structure and two follow-ups.

If you want to practise, I'll play the skeptical interviewer on C1.
I can also save a tuesday-dossier.md that records the gaps this prep found, so you can bring it to later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Who are you meeting, and what is each person's relationship to the role (future manager, peer, skip-level, cross-functional)? Did the recruiter mention focus areas or anything to prepare, like a case or a presentation? This changes how every question set is weighted.
2. Can you paste the job description and your CV, or a few sentences about your background? Then I can quote the real requirements and match the advice to your own experience. I can keep going without them if you'd rather.
3. Do you want me to research Stripe? You'd need to allow web search when it asks. That would add Stripe's published values by name, how its interviews are structured, and questions about its current strategy.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack — Product Operations Manager, Stripe

**Round:** final round. **Interviewer(s):** not known. **Relationship:** not known.
**Built from:** your one-line message only. No job description, no CV and no interviewer names were provided, and every web search was refused by this session's permissions, so nothing in this pack comes from Stripe's own pages. Every row is labelled `[generic]`: useful rehearsal, no claim about Stripe or about you. The upgrade menu at the end says exactly what each missing input would turn into.

---

## 1. How to use this pack

- **Personas** describe *how* a question arrives (the register, the pressure). **Types** describe *what* is being scored. Rehearse both: the same content delivered into a different style is a different answer.
- **Type key**
  - **VAL** — behavioral / values: does your past behavior show the company's published values
  - **EXP** — experience deep-dive: do the claims you make survive scrutiny, and what was actually yours
  - **JD** — role-driven: can you do the listed job, including its gaps
  - **CO** — company and strategy: homework depth, thinking at the company's altitude
  - **CASE** — live problem: structure and reasoning on a problem from the role, delivered aloud
- **Question IDs** are letter-by-persona (A, B, C, D, E, G, H). The letter F is reserved for fit-snapshot rows (F1–F8) so the two never collide.
- **Guidance is scaffolding, not a script.** Because the pack holds none of your own sentences yet, every guidance cell about your past is a *selection scaffold*: what a strong story needs, and an honest branch for when you don't have one. Pick your real stories; never borrow the shape of a good story as if it were yours.
- **Highest-ROI prep in this pack: C1** ("Which part of this role would you be weakest at on day one?"). See the Skeptic bank.

---

## 2. Fit snapshot (worksheet)

With no CV or JD in hand, this is a self-assessment worksheet. The requirements are role-family patterns for product operations roles, written without a source, so they are plain prose and `[generic]`. Fill the evidence column with your own sentences before the interview; that is the single most useful thing you can do with this table.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-functional programs across product, engineering and go-to-market teams, such as launches — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence names the program, the teams involved, what part was yours, and how it ended. Pick a program you personally coordinated across at least two other functions; if no such program comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Design and run operational processes and tooling: intake, launch readiness, feedback loops — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence names a process, the problem it answered, what you changed, and how you knew it worked. Pick a process you designed or rebuilt yourself; if no such process comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Work with data: define metrics, pull and read them, size a problem — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence names a metric, where it came from, what you did with it, and the assumption you trust least. Pick an analysis you ran yourself end to end; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one |
| F4 | Turn user, support and sales feedback into product input — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence names the feedback source, how it was gathered, and what changed because of it. Pick a time feedback you handled reached a product decision; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence without authority, including with senior leaders — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence names the stake, who disagreed, what you did, and the relationship afterwards. Pick a time you moved a decision you did not own; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritize and make tradeoffs under ambiguity — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence names the competing asks, how you decided, what you said no to, and what it cost. Pick a real tradeoff you made; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide |
| F7 | Work with risk, legal or compliance partners on launches, common in regulated products — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence names the partner, the concern raised, and how the launch changed. Pick a time you worked through a risk or compliance concern; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F8 | Scale a manual process as volume grows: fix it, tool it, or automate it — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence names the process, the volume problem, the option you chose and why. Pick a process you scaled yourself; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide |

---

## 3. Persona table

The loop is not established: "final round" says nothing about how many sessions it holds or who runs them, and the search that would have looked for Stripe's documented process was refused. So the weights below rest on a **fallback archetype — big-tech structured — and not on Stripe's documented process.** That archetype tilts Case and Values up. If you learn who you are meeting, these weights change; tell me and I'll recompute.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Case / Strategist | Live problems from the role: plan a launch, diagnose a drop, design a process | High (5 questions). Big-tech structured fallback tilts Case up, and a final round for an operations role is likely to include a hiring-manager-style session, whose prior is Case plus Skeptic | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case | [generic] |
| Values / Behavioral | STAR-shaped stories mapped to company values | High (4). The fallback archetype reads yes for a values-style round, but Stripe's published values are not in hand, so these are themed by persona stems and the role, not by Stripe's own words | "We" for context, "I" for contribution; choose stories where the hard truth actually landed; where you have none, say so | [generic] |
| Skeptic | Quiet probing of gaps; why here, why now | Mid (3). Hiring-manager prior; also the persona that carries the highest-ROI question | Rehearse C1 until it is boring; bridges built only from what you actually did, plus a concrete ramp plan | [generic] |
| Data-Driven Prober | Asks for denominators and assumptions | Mid (3). Operations roles are usually measured on metrics, so metric probes are likely in some session | Know what you can and cannot say about how each number you cite was counted; name your weakest assumption first | [generic] |
| Peer Evaluator | Seams with product, engineering, support; credit-sharing | Mid (3). Final rounds commonly include a partner-team session; unknown here | Reciprocity framing; propose seam principles rather than pretending to know the seam | [generic] |
| Pressure | Interrupts, time-boxes, questions attribution | Low (2). Not dominant in any prior that applies, but rehearse once so it is never new | Pause, restate, anchor in what you actually said; hold through two follow-ups before conceding anything real | [generic] |
| Conversational | Friendly openers that are still scored | Low (2). Shows up as the opener of almost any session | Pre-scripted 90-second biography arc; treat casual questions as scored | [generic] |

---

## 4. Question banks

Every row is `[generic]`: no JD, no CV and no research reached this pack. Where guidance is about your past, it is a selection scaffold; where the question is a live problem, it presupposes nothing about you.

### A — Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for launching a new product feature in several new markets at once — what do you need to know first?" | CASE | [generic] | Clarify first: which markets, what is fixed (date, scope, budget), who owns what. Then objective and the one metric that says launch worked. Segment markets by what differs (regulation, language, support, partners). Plan: readiness checklist per market, owners, a go/no-go gate, a rollback. Close with risks and what you would watch in week one. The question needs no claim about your past, so the guidance makes none | Launch coordination is the core of F1 and F2; CASE because it scores structure delivered live |
| A2 | "Activation for a newly launched product dropped 20% month over month — diagnose it." | CASE | [generic] | Before hypotheses: is the data right (definition change, tracking break, denominator shift)? Then segment: by market, channel, cohort, device, user type. Separate internal causes (a release, a pricing or onboarding change) from external ones (seasonality, a competitor, a partner outage). Say which you would check first and why, and what result would change your mind | A prober-style metric problem tests F3 without needing your history; CASE because the reasoning is the score |
| A3 | "Product and support both want you on their top priority this quarter, and you can staff one. How do you decide?" | CASE | [generic] | Name your criteria aloud before choosing: user impact, revenue or risk exposure, reversibility, who else could cover it. Make the call, say what the other team gets instead (a smaller fix, a date, a handoff), and how you would tell them. Concede what your choice costs | F6 asked as a live decision; CASE because it scores a stated tradeoff, not a story |
| A4 | "Design a feedback loop that gets what users tell support and sales into the product roadmap. What would you build first?" | CASE | [generic] | Clarify who consumes it (PMs, leadership) and what decision it feeds. Build the smallest version first: one intake, one tagging scheme, one regular review with an owner. Say how you would measure whether it changed decisions, not just whether it collected feedback. Name one failure mode (noise, loudest-customer bias) and your guard | F4 is a staple of product operations; CASE because it is a design problem |
| A5 | "A manual operational process is breaking as volume grows. How do you decide whether to fix the process, add tooling, or ask engineering to automate it?" | CASE | [generic] | Clarify volume trend, error cost, and how stable the process is. Simple rule: don't automate a process you don't understand; fix the process first, tool what is stable, automate what is stable and expensive. Say what engineering time costs and how you would make the case for it | F8; CASE because it scores a decision framework |

### B — Values / Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they did not want to hear: it needs a named stake, what you said, how it landed, and the relationship afterwards. "We" for context, "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5; a Values-persona stem that a big-tech structured loop is likely to ask in some form |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time the right thing for a user and a number you were measured on pointed in different directions. It needs the metric, the customer impact, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4; a Values-persona stem, and customer-versus-metric is a common values probe |
| B3 | "Leadership has set a launch date, and your readiness review says it isn't ready. What do you do?" | VAL | [generic] | Structure it: what exactly is not ready and what it risks, what options exist (launch smaller, delay, launch with mitigations), who decides and how you put the options to them, what you do once they decide. Holding a concern and then committing to the decision is the beat. The question needs no claim about your past, so the guidance makes none | F5 and F6 asked as a values dilemma; VAL primary, CASE delivery |
| B4 | "A risk or compliance partner raises a concern the day before a launch. What do you do?" | VAL | [generic] | Take the concern seriously before defending the date: understand it, size it, ask what would resolve it. Lay out options with the partner, not around them. Escalate with both views if you cannot agree. The question needs no claim about your past, so the guidance makes none | F7 as a values dilemma; VAL primary, CASE delivery |

### C — Skeptic (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **The highest-ROI rehearsal in this pack.** Pick one real area from F1–F8 where your own evidence is thinnest. Name it plainly and first, before you're asked about it. Then: what you have done that sits nearest to it, said at its true size; and a concrete ramp plan for the first 60–90 days (who you'd learn from, what you'd ship small first). Follow-up one, "Isn't that core to the job?": hold, and say why the ramp is realistic, without making the nearby work bigger. Follow-up two, "So how would you cover it until then?": name who or what covers it and when you'd be independent. If you cannot name a weakness, choose the area you'd most want to grow in; "none" is not an answer | Without a CV the objection cannot be read from your evidence, so this is the objection every final round can ask; it gets the deepest rehearsal because a rehearsed, non-defensive answer changes the session. Once your CV arrives it is replaced by the real one |
| C2 | "Why Stripe, and why this role now?" | CO | [generic] | Three short parts: why product operations (what you like doing, in your own words), why now (where you are in your path), and why Stripe, naming one specific thing you read in Stripe's own materials, not a slogan. Keep it under 60 seconds; it is a consistency check across sessions, so say the same thing to everyone | Skeptic's "why here, why now" probe; CO because the "why Stripe" part scores homework, which this pack could not do for you |
| C3 | "I don't see payments or financial-services experience in your background — how would you handle that in this role?" | JD | [generic] | If your background does include it, say where, in your own words. If it doesn't, say so plainly, then what you would do to learn the domain fast and who you'd lean on; do not stretch adjacent work into domain experience | A Skeptic stem applied to the domain gap a payments company may probe; JD because it scores fit to the role |

### D — Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that number was counted." | EXP | [generic] | Asked about any number you cite. For each number you plan to use, prepare, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you don't know how it was counted, say so plainly; that beats an explanation you cannot repeat under a second question | Every figure you mention will be probed; EXP because it tests whether your claims survive scrutiny |
| D2 | "Suppose you introduce a launch-readiness review. How would you know a quarter later whether it worked?" | CASE | [generic] | Name the outcome it should move (fewer post-launch incidents, fewer rollbacks, faster time to fix), the denominator (incidents per launch, not raw counts), a baseline, and what else could explain a change. Say the weakest assumption in your own measurement plan | F2 and F3; CASE because it scores measurement design |
| D3 | "Support tickets about a newly launched feature doubled week over week. What do you check first?" | CASE | [generic] | Normalize first: did usage also double? Then segment the tickets by type, market and user group, read a sample, and check for a recent change. Say what you'd tell product today and what you'd wait to confirm | F3 and F4; CASE because it is a live diagnosis |

### E — Peer Evaluator (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side — where's the seam between product ops and product management, and what happens when we disagree?" | CASE | [generic] | Don't claim to know their seam. Propose principles: who owns the decision, who owns the process, how disagreements get raised early and settled. Ask what the seam looks like today. Say what your team would take off their plate | Peer stem; CASE because it tests seam reasoning, not a past |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Principles first: name contributors specifically, in their hearing and their manager's. If you have a real example, pick one where you shared or gave credit; if none comes to mind, say so plainly and say how you would handle it | Peer stem; VAL because it scores collaboration behavior |
| E3 | "What would you need from me in your first 90 days — and what would I get from you?" | CASE | [generic] | Reciprocity: name two things you'd need (context, a seat in a planning forum) and two things you'd give (a cleaner intake, a launch checklist they don't have to chase). Keep it concrete and small | Peer evaluators price your cost to them; CASE because it is a plan, not a story |

### G — Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then three beats in under a minute: what you'd bring from outside, how fast you'd ramp, one thing you'd do in month one. Don't run down internal candidates. If interrupted, finish your sentence and keep the order | Pressure stem; JD because it scores fit to the role under time |
| G2 | "That result — how much of it was actually you?" | EXP | [generic] | Asked after any result you describe. Answer at the scope of what you said: what the team did, what you did, in separate sentences. Hold your share through two follow-ups; if pushed, concede specifically what others did rather than shrinking your part vaguely. Never grow your share to end the pressure | Attribution under pressure is the probe that catches inflation; EXP because it tests what was yours |

### H — Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So — walk me through the journey." | EXP | [generic] | A 90-second arc you've said aloud before: where you started, two or three moves and why you made each, why product operations, why now. Every step is your real path in your own words; end where this role starts | The opener of almost every session, and it is scored on economy |
| H2 | "What's a product you think has great operations behind it, and why?" | CO | [generic] | Pick a product you actually use. Name what you notice as a user (onboarding, how problems get fixed) and what you think must be happening behind it, said as a guess, not a fact | Casual register, scored for genuine interest and operational instinct; CO because it tests how you think about products |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 cross-functional programs | A1 |
| F2 processes and tooling | A1, D2 |
| F3 data and metrics | A2, D1, D2, D3 |
| F4 feedback into product | A4, B2, D3 |
| F5 influence without authority | B1, B3 |
| F6 prioritization | A3, B3 |
| F7 risk and compliance partners | B4 |
| F8 scaling manual processes | A5 |

---

## 5. Reverse questions

| Question | Why it lands | Provenance |
|---|---|---|
| "What does a great first 90 days look like in this role, and what would make you say it was a mistake?" | Shows you're already thinking in outcomes, and the second half tells you what they fear | [generic] |
| "Where does product ops sit relative to product and engineering here, and where are the seams today?" | Gets you the real seam instead of guessing it, and signals you know seams are where this job lives | [generic] |
| "Which operational process would you most like to see rebuilt in the next year?" | Turns the interview into a working session on their actual problem | [generic] |
| "How does the team measure whether product operations is working?" | Shows you expect to be measured, and tells you whether the role is valued for outcomes or for activity | [generic] |
| "What's something someone in this seat did that changed how the team works?" | Invites a story about what good looks like here, and tells you the ceiling of the role | [generic] |
| "Is there anything about my background you'd want me to address before we finish?" | In a final round, it surfaces the live objection while you can still answer it; ask it calmly and answer the way you rehearsed C1 | [generic] |

---

## 6. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| No entries yet | This pack holds none of your sentences, so there is nothing yet for it to stretch or for you to inflate | Once your CV or own words arrive, this table lists the stretched wordings to avoid, each with the sentence that limits it |

---

## 7. Sources

**Provided documents:** your message ("final-round interview at Stripe for a Product Operations Manager role"). No JD, CV, recruiter note or interviewer names.

**Searches sent:**

- `Stripe operating principles` — refused
- `Stripe interview process product operations final round` — refused
- `Stripe strategy news 2026` — refused
- `Stripe "Product Operations" manager job description` — refused

No fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Search refused. Would have supplied Stripe's published values by name: a values cheat sheet and VAL questions themed on them |
| 2. `Stripe interview process` product operations | unavailable | Search refused. Would have let persona weights follow documented rounds instead of the big-tech structured fallback |
| 3. `Stripe strategy` / recent news | unavailable | Search refused. Would have grounded C2, H2 and at least one CASE question in current strategy |
| 4. interviewer name at Stripe | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Product Operations Manager JD | unavailable | Search refused. Would have turned F1–F8 into quoted `[inferred]` requirements |

---

## 8. Upgrade menu

- **The job description text** → F1–F8 replaced by the JD's own quoted requirements, `[grounded]`, with a JD-tagged question for every listed requirement
- **Your CV, or a few sentences about your background** → the worksheet becomes a real fit snapshot; guidance becomes story-mapped on your own sentences; the prohibited list fills in; C1 becomes the objection your actual evidence invites
- **Who you're meeting and how they relate to the role** (manager, peer, skip-level, cross-functional) → persona weights recomputed from the real relationship instead of the fallback archetype
- **If your final is several sessions, the schedule** → one mini-pack per session, each with its own weights, bank and reverse questions
- **Interviewer names** → a reading of their public professional footprint and a reverse question tied to their own path
- **The recruiter's prep email** → a build section for any pre-declared deliverable (a case, a presentation, a take-home) and coverage of their stated focus areas
- **Permission for web search** → Stripe's published values by name, its documented loop, and current-strategy questions, with the target table above re-run
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, role-family loop reports and recent org context, feeding a grounding brief and sharper CO and CASE questions
- **Your prep time** → a prioritized schedule sized to it
- **A tuesday-dossier.md, if you have one** → verified evidence and an evidence-derived highest-ROI objection in place of the inferred one
