Web search was refused, so I'm building the pack from what you gave me (company, role and round) and labelling everything as generic.
I've built a first prep pack for your Stripe final round. It's generic for now: I only had your one-line message, and web search was blocked, so nothing in it comes from your background, Stripe's job description, Stripe's values or how its final round is run. I treated your final as a mix of interviewer styles and weighted them all equally, since I don't know who you're meeting.

What's in it:
- **20 practice questions** across seven interviewer styles, from a skeptical interviewer and a high-pressure one to live problems, a numbers-focused prober, values questions, peers and a casual chat. Each comes with notes on how to approach it. Since I don't know your background, the notes help you choose which of your own stories to tell rather than telling you which one.
- **The one question to rehearse most** is A1: "Which part of this role would you be weakest at on day one?" Without your CV I can't name your gap for you, so the pack has you name it yourself and practise holding that answer under follow-ups.
- **Six questions to ask your interviewers**, each with a note on why it works.
- **A self-assessment worksheet** listing seven responsibilities typical of product operations roles, with what strong evidence looks like for each.

The pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-3-denied-fc7987b5/stripe_product-operations-manager_interview_pack.md`.

Say the word and I'll play the skeptical interviewer on A1, with real follow-ups and feedback afterwards.
I can also save a `tuesday-dossier.md` listing the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who is in your final round (how many sessions, and whether each is with your future manager, peers, another team or an executive), and did the recruiter mention focus areas, a case or presentation to prepare, or how much time you have?
2. Can you paste the job description and your CV, or a few lines about your background? Without them, the pack stays a worksheet.
3. Web search was blocked this time. Once you allow it, do you want me to rerun the standard pass (up to 6 searches and 2 page reads), or that plus a deeper one (up to 6 more searches and 2 more page reads, several more minutes) for Stripe's values, how the final is run and its current strategy?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — Final-round prep pack

**Round:** final round. Interviewer(s) and relationship not yet known.
**Built from:** your one-line request only. No JD, no CV, no recruiter guidance, and web search was refused this session. So every row is `[generic]`: a role-family pattern for product operations, not a claim about Stripe. The upgrade menu at the end lists what turns each part into something specific to you.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who asks it, and in what style. **Types** describe *what* is being scored. Rehearse both, because the same content lands differently from a friendly aside than from a time-boxed challenge.
- **Type key:**
  - **VAL**: behavioral and values. Does your past behavior show the company's values?
  - **EXP**: work-experience deep-dive. Do your claims survive scrutiny, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. How deep was your homework?
  - **CASE**: live problem. Structure and reasoning, delivered out loud.
- **Provenance labels:** `[grounded]` traces to something you provided or to cited research. `[inferred]` is derived from a representative source. `[generic]` is a role-family pattern with no claim about you or Stripe. Every row here is `[generic]` for now.
- **The guidance is scaffolding, not a script.** Since I have nothing about your background yet, the guidance tells you *how to pick* a story, never *which* story. Every pick ends with an honest branch, because "I haven't done that, but here's how I'd approach it" beats a stretched story that breaks on the first follow-up.

---

## Fit snapshot (worksheet)

You haven't shared a CV or background yet, so this works as a self-assessment worksheet. For each row, read "what strong evidence looks like", then find your own instance before the interview. The requirements are typical product-operations responsibilities, written from no source, so they are plain prose and `[generic]`. Stripe's actual JD may differ.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running launch and readiness processes across product, engineering, support and go-to-market teams — role-family pattern | none given | none | [generic] | discovery | Strong evidence: a launch where you coordinated readiness across functions, with a named outcome. Selection scaffold: pick a launch or rollout where several teams had to be ready at once. It needs your specific role in it and one thing that would have gone wrong without that work. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Building feedback loops from customers, support and sales into product prioritization — role-family pattern | none given | none | [generic] | discovery | Strong evidence: a feedback channel you set up or ran, and a product decision it changed. Selection scaffold: pick a time customer or frontline input reached a product decision through work you did. It needs the input, the route it took, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Defining and tracking operational metrics, with hands-on data analysis such as SQL — role-family pattern | none given | none | [generic] | discovery | Strong evidence: a metric you can explain end to end, meaning how it was counted, what it is sensitive to, and the part that was yours. Selection scaffold: pick a number you reported on that you can defend through two follow-ups. If you don't know how a figure was counted, say so, and pick one you do know. If no such number comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Designing and scaling processes: documentation, tooling and automation — role-family pattern | none given | none | [generic] | discovery | Strong evidence: a process you changed, the before and after, and who used it afterward. Selection scaffold: pick a time a manual or messy process changed because of work you did. It needs what was broken, what you changed, and who relied on it after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influencing cross-functional stakeholders without direct authority — role-family pattern | none given | none | [generic] | discovery | Strong evidence: a disagreement with a team you didn't manage, how you moved it, and a relationship still intact at the end. Selection scaffold: pick a time you needed another team to change course and could not instruct them. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Familiarity with payments, fintech, or risk and compliance constraints — role-family pattern | none given | none | [generic] | discovery | Strong evidence: work in payments, financial services, or a regulated product, described at its real scope. Selection scaffold: if you have such work, pick the instance closest to merchant-facing operations. If you have none, say so plainly and give a concrete learning plan, said as a plan and never as a past |
| F7 | Clear written and spoken communication of operational trade-offs to product and leadership — role-family pattern | none given | none | [generic] | discovery | Strong evidence: a document, review or proposal you wrote that changed a decision. Selection scaffold: pick a written artifact you authored that people acted on. If no such artifact comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

**Requirement coverage:**

| Requirement | Covered by |
|---|---|
| F1 Launch and readiness | C1, F3 |
| F2 Feedback loops | C2, B3, E2 |
| F3 Metrics and data | D1, D2, D3 |
| F4 Process design and tooling | C3, G2 |
| F5 Cross-functional influence | F1, F2, E1 |
| F6 Payments domain | A3 |
| F7 Communication | G1, B1, G3 |
| Self-assessment across all rows | A1, A2 |

---

## Persona table

**Why the weights are flat:** you said "final round", but that doesn't say how many sessions there are or who runs each. Search was refused, so no source for Stripe's loop was read. The pack therefore uses the **Generic** fallback archetype: flat weights, and no values-style round assumed. This is noticeably weaker than a pack weighted to your real schedule. Send the schedule and the weights will be recomputed.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of gaps; why leave, why here, why now | Even (flat). Placed first because it holds the highest-ROI question, A1 | Rehearse your weakest-area answer until it's boring. Bridge only from work you actually did; name the limit plainly; give a concrete ramp plan |
| B. Pressure | Interrupts, time-boxes, questions attribution | Even (flat). Final rounds often include a challenge-style session, but nothing here confirms one | Pause, restate, anchor in what you actually did. Hold through two follow-ups, then concede specifically |
| C. Case / Strategist | Live ops problems: plan, diagnose, prioritize | Even (flat). A role-family pattern for product ops loops, not a confirmed Stripe round | Clarify, objective, segment, approach, metrics, risks. Think aloud; challenge one premise |
| D. Data-Driven Prober | Asks for denominators, how a number was counted | Even (flat) | Know how each figure you'll cite was counted, and say plainly when you don't. Name your weakest assumption first |
| E. Values / Behavioral | STAR-shaped stories against values | Even (flat). Stripe's published values couldn't be fetched, so these questions use generic themes | "We" for context, "I" for contribution. Pick stories where the hard truth actually landed |
| F. Peer Evaluator | Seam-splitting, credit-sharing, what you'd need from me | Even (flat) | Lead with reciprocity; propose seam principles rather than pretending to know the seam |
| G. Conversational | Friendly openers that are still scored | Even (flat) | A pre-built 90-second arc; treat casual questions as scored; always have reverse questions |

---

## Question banks

**Highest-ROI prep in this pack: A1.** In some form, "where would you be weakest" will come up. Without your CV the pack can't name your gap for you, so A1 makes you name it yourself, and that rehearsal is worth more than any other single item here.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The deepest rehearsal in the pack. Pick the row in F1–F7 where your own evidence is thinnest: a real gap, not a strength in disguise. Name it in one plain sentence. Mention something you have already done to close it only if you actually did it. Then give a ramp plan, said as a plan: what you'd learn in the first 30 days, from whom, and how you'd know you'd closed it. Follow-up one ("isn't that core to the job?"): hold, and restate the plan rather than shrinking the gap. Follow-up two: concede exactly, e.g. "yes, that's where I'd lean on the team most early on." Never trade the gap for a vaguer one mid-answer | The Skeptic's own stem. With no CV, the one objection the pack can predict is the one you must name yourself. JD because it scores self-assessment against the role's requirements |
| A2 | "Why product operations, why Stripe, and why now?" | CO | [generic] | Three beats, one or two sentences each. Why the work: pick the moment you first found yourself doing operations-to-product work; if no such moment comes to mind, say so plainly and say what draws you to it. Why Stripe: name one thing from Stripe's own recent published material that you read yourself. This pack couldn't research Stripe, so it supplies none, and a reason you can't source is worse than none. Why now: the step this is in your career. Keep all three consistent with what you said in earlier rounds | Motivation consistency is the Skeptic's core probe, and a final round compares your answer against earlier rounds. CO because the Stripe beat tests homework depth |
| A3 | "How would you get up to speed on the payments domain in your first few months?" | JD | [generic] | If you have payments, fintech or regulated-product experience, state it at its real scope, in your own words. If you don't, say so plainly. Then a plan: read the product docs a merchant would read, shadow support and risk teams, review a sample of real merchant tickets, and keep a glossary of terms you had to look up. Said as a plan, never as something you've done | F6 is the domain requirement most likely to be probed for a payments company. JD because it scores a stated-style requirement |

### B. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate: "Why me over someone who already knows the systems." Then two beats: the one thing you'd bring from outside, which must be a fact from your own history that you can back, and the honest concession: an internal candidate knows the systems faster, and here is your ramp plan. Hold the first beat if pushed; concede only the ramp time | A Pressure stem built for time-boxed composure. JD because it scores your fit claim against the role |
| B2 | "That result you just described — how much of it was actually you?" | EXP | [generic] | For every story you plan to tell, rehearse the split in advance: "we" for the team's work, "I" for your exact contribution, and who else did what. Volunteer the part that wasn't yours before you're asked. Hold the part that was yours through two follow-ups; don't give it away just to restore harmony | The Pressure stem for attribution. EXP because it tests what was actually yours |
| B3 | "I'm not convinced product ops isn't just project management. Convince me." | JD | [generic] | Hold a definition you'd defend: product ops connects product decisions to operational reality through feedback loops, launch readiness, tooling and metrics. Concede the real overlap ("yes, coordination is part of it"), then draw the line: project management delivers a plan, while product ops changes what gets built and how it runs. If you have an instance of that from your own work, use it; if not, keep it at the level of how you'd work | Devil's-advocate framing tests whether you can hold a position without getting defensive. JD because it scores your understanding of the role itself |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new payments feature launches to merchants in a new country next quarter. Sketch the readiness plan — what do you need to know first?" | CASE | [generic] | Clarify first: which merchants, what changes for them, what local regulatory or compliance constraints apply, and who supports them. Then the objective: a launch with no surprise operational load. Workstreams: support training and macros, documentation, sales enablement, risk review, internal tooling. Go/no-go criteria agreed in advance. Post-launch metrics such as ticket volume per new merchant and time to first successful payment. Close on the top risk and how you'd monitor it. Challenge one premise, e.g. whether next quarter is fixed | A live problem in the role, aimed at F1. CASE because it scores structure, not a past |
| C2 | "Support tickets about onboarding rose 20% month over month. Diagnose it." | CASE | [generic] | Check the denominator first: did signups also rise? Then segment by merchant type, region and channel. Lay the timeline against releases and policy changes, and read the ticket tags and a sample of the tickets themselves. Form two or three hypotheses, say what data would separate them, and say what you'd do this week versus this quarter | The Case stem for a metric drop, aimed at F2 and F3. CASE because it scores live diagnosis |
| C3 | "Three product teams all want your time next quarter and you can take one. How do you decide?" | JD | [generic] | State your criteria aloud before you pick: merchant impact, operational risk if it isn't done, reversibility, and how dependent the team is on ops support. Say how you'd tell the two teams you didn't pick, and what they'd get instead. Name what would change your mind | Prioritization sits at the centre of F4 and F5. JD content with CASE delivery; tagged JD because it scores a core responsibility |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a metric you've reported on and walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a figure you can defend two levels deep, covering how it was counted, what it is sensitive to, and which part of it was yours. If you don't know how a figure was counted, say so plainly and choose one you do know. If no such figure comes to mind, say so, then describe how you'd set up a metric for a process you've run | The Prober's stem. Any number you cite in the final will get this treatment. EXP because it tests whether your claims survive |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before you're asked, in your own words: the assumption behind your D1 figure that you're least sure of, and what it would change if it were wrong. A named weakness turns a gotcha into credibility | The Prober's second stem, always the follow-up to D1. EXP because it tests whether you know your own assumptions |
| D3 | "How would you measure whether a product operations team is doing its job?" | CASE | [generic] | Separate input metrics from outcome metrics. Inputs: time for feedback to reach a product owner, readiness checklist completion. Outcomes: post-launch ticket volume, time to resolve operational issues, how often product teams act on ops input. Name the weakest assumption out loud: attributing outcomes to ops work is hard, so you'd pair the numbers with a qualitative read | Tests F3 as a live design problem. CASE because it presupposes nothing about your past |

### E. Values / Behavioral

Stripe's published values couldn't be fetched this session, so these questions use generic themes. Once search is allowed, they can be mapped to Stripe's own published values by name.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, what you said, and what happened next, including whether the truth actually landed. "We" for context, "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values stem for candor. VAL because it scores behavior, not knowledge |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer's interest and a number your team tracked pointed different ways. It needs the metric, the customer, your call, and its cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values stem for customer focus, which also touches F2. VAL because it scores a past decision |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know the seam; propose principles instead. Who owns the decision versus who supplies the input, a regular sync, and a named escalation path. For disagreement: bring the data first, agree the decision-maker, then commit once it's decided. End with reciprocity: what your work would take off their plate | The Peer stem. CASE because it asks you to design a working relationship live, without presupposing a past |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick an instance of cross-team work you were part of. Name others' contributions specifically, then your own exactly. If no such instance comes to mind, say so plainly, then say how you would handle credit | The Peer stem on credit. EXP because the honest answer is an attribution exercise |
| F3 | "What would you need from me in your first month, and what would I get from you?" | CASE | [generic] | Two halves of equal length. What you'd need: context, access to their backlog and tickets, and a standing slot. What they'd get: a specific early deliverable, such as a map of where operational pain reaches their team today. Keep the second half as long as the first | Tests whether you'd reduce a peer's load or add to it. CASE because it is a forward plan |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the turn toward operations and product work, what you're best at, and why this role now. Every beat is only what you actually did, in your own words. End on why here, so it hands off to A2 cleanly | The Conversational stem, and nearly certain to come up somewhere in the final. EXP because it is the first test of how you describe your own history |
| G2 | "What are you actually playing with in operations tooling these days?" | JD | [generic] | Name a tool or approach you actually use, and what you use it for. If you aren't using anything new right now, say so plainly and say what you're curious about and why. A casual question is still scored | The Conversational stem with the role's tooling theme, aimed at F4. JD because it probes a working skill casually |
| G3 | "Anything else you'd like us to know?" | EXP | [generic] | One sentence restating the strongest fit point you actually made today, then hand off to your reverse questions. Never answer "I think you've covered everything" | A closing slot that rapport-style interviewers weight. EXP because it asks you to summarize your own case |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a great first 90 days look like in this role, and what would make you say the hire was a mistake?" | It shows you are already thinking about how you'll be judged, and the second half gets an honest answer you can use |
| R2 | "Where does product operations sit relative to product, support and go-to-market here, and where does that seam cause the most friction today?" | It tests the real shape of the role, which no generic JD tells you, and invites the interviewer to talk about their own pain |
| R3 | "Which operational problem would you most want this person to have solved a year from now?" | It turns the job into a concrete outcome you can respond to before the conversation ends |
| R4 | "How does feedback from merchants and support reach product decisions today, and where does it get lost?" | It goes straight at F2, the heart of product ops, and shows you've thought about the mechanics |
| R5 | "What's something about working here that surprised you when you joined?" | Rapport with substance, and the answer often reveals culture better than any official page |
| R6 | "What could a new person on this team do in their first month that would genuinely help yours?" | The reciprocity question, for any peer in the final |

---

## Prohibited claims

No entries. Every entry on this list is built from something you said: an inflated wording of one of your own sentences, or a negative you stated. You haven't shared either yet, so there is nothing to list. That's different from a pack that checked your material and found nothing to inflate. Once you share a CV or background, this list gets built before the banks are rewritten. Until then, the standing rule covers every row: tell only what you actually did, at its real scope.

| Not coached | Basis | Honest form |
|---|---|---|

---

## Sources

**Provided documents:** your message, which named the company, the role and the round. No JD, no CV, no recruiter guidance, no dossier.

**Searches sent:**

| Query | Outcome |
|---|---|
| Stripe operating principles official | refused |
| Stripe interview process final round onsite operations | refused |
| Stripe Product Operations Manager job description | refused |
| Stripe annual letter 2026 strategy stablecoins agentic commerce | refused |

No fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | The search was refused. It would have supplied Stripe's published values by name, which would theme bank E and, if your final has a values session, a values cheat sheet |
| 2. Stripe interview process, product operations | unavailable | The search was refused. It would have supplied the final round's structure, which sets the persona weights; they are flat instead |
| 3. Stripe strategy, recent news | unavailable | The search was refused. It would have grounded A2 and a strategy-led CASE question in Stripe's current priorities; they stay generic |
| 4. Interviewer name at Stripe | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | The search was refused. It would have turned F1–F7 into quoted, `[inferred]` requirements |

---

## Upgrade menu

- **The JD text** → F1–F7 become `[grounded]` requirements quoted from Stripe's own posting, and the JD-tagged questions retarget to what Stripe actually listed
- **Your CV, or a few lines about your background** → the worksheet becomes a real fit snapshot, the guidance maps to your actual stories, the prohibited list gets built, and the highest-ROI objection is derived from your real gaps rather than left for you to name
- **Who's in the final, and their relationship to the role** → persona weights computed from your actual sessions instead of flat
- **Interviewer names** → a read of each interviewer's public professional footprint, persona weights tuned per person, and a reverse question tied to each one's career path
- **Recruiter guidance: focus areas, or a case or presentation you were told to prepare** → a dedicated build section for any graded deliverable
- **Web search permission** → Stripe's published values mapped into bank E, the loop structure, and CO and CASE questions grounded in Stripe's current strategy
- **If your final is several sessions, send the schedule** → one mini-pack per session, each with its own weights and reverse questions
- **How much prep time you have** → a prioritized prep schedule sized to it
- **A tuesday-dossier.md from job-underwriter** → evidence already checked against the role, a named objection to rehearse, and guardrails on claims; the pack works fine without one
