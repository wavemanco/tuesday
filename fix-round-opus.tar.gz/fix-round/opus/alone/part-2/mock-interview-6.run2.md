Web search was blocked by permissions, so I'm building the pack from your message alone and labelling what would have come from research.
I've built a prep pack covering all three rounds: one shared fit snapshot, then a separate question bank and set of reverse questions for each round. It's saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-6-denied-403d35dc/larkfield-systems_engineering-manager_interview_pack.md`.

It uses only the role description and background in your message. The web searches for Larkfield's values, interview process and recent news were blocked by this session's permissions. So the Monday values round has no values cheat sheet, and the strategy and case questions are general patterns for this kind of role rather than Larkfield-specific.

The question to prepare hardest is B1 in the pack: the would-be boss asking about owning a hardware-adjacent roadmap, which you've said you haven't done. It's likely to come up in some form in at least two of the three rounds. I'm happy to play the Director and run it as a live practice with follow-ups.

I can also save a `tuesday-dossier.md` file that records the gaps this prep exposed, so you can carry them into later sessions. If you'd like the pack as a Word document, I can convert it.

1. Can you paste the full job posting and your CV? The summary gives me five requirements, and a CV would let me build answers around your actual stories for growth, device-management work and partnering with product.
2. Did the recruiter say how Thursday's panel is split, or whether you need to prepare anything for it, like a presentation or a system-design segment?
3. Do you want me to retry the research if you allow web searches? It would add Larkfield's values for Monday and real company context for the strategy questions. A deeper pass is also available: up to 6 more searches and 2 page fetches, taking several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop. Three scheduled rounds, one shared fit snapshot, then a mini-pack for each round.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel: technical peers plus a cross-functional partner |
| 3 | The following Monday | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

No interviewer names were given, and web research was refused by this session's permissions. So there's no interviewer read, the company-specific sections are absent, and every CASE and CO question is labelled `[generic]`. The upgrade menu says what would fix each of these.

---

## How to use this pack

**Personas** describe how a question arrives: who asks it and in what style. **Types** describe what is being scored:

| Tag | Scores |
|---|---|
| VAL | Whether your past behaviour shows the values the company publishes. Larkfield's are not in hand, so here these questions are themed on the recruiter's "values and leadership philosophy" |
| EXP | Whether what you say about your experience holds up under scrutiny, and what was actually yours |
| JD | Whether you can do the job as the role description lists it, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, reasoned out loud |

Every fit row and every question carries a provenance label. `[grounded]` means traceable to your message or the role description you pasted. `[inferred]` means derived by this pack, with the derivation named. `[generic]` means a role-family pattern with no claim about Larkfield or about you.

The guidance is scaffolding, not a script. Wherever it says **Answer slot**, the pack doesn't know the answer and won't make one up. Answer from your own experience. If the thing it names never happened, say so plainly.

**Highest-ROI prep in this pack: B1**, the hardware-roadmap objection. It is where the role description presses hardest on a gap you named yourself. It will come up in some form in at least two of the three rounds (B1, G2, L1).

---

## Fit snapshot

Requirements are quoted from the role description in your message. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says one team of six, and the words stay at that scope: "I've spent three of my nine years as a team lead of six." Answer slot: the two-squads line makes a probe on how you lead likely. If there were decisions in leading the six that were yours, say which and how you made them, in your own words. If you can't point to one, say so plainly and stay with the three years. A separate stated negative sits beside this row: "I've never managed managers" (F1 does not assume the squads have leads; ask, see reverse question R1-1) |
| F2 | "building device-management services" — role description | none given | none | [grounded] | discovery | Strong evidence would be services you built or ran that manage, configure or update devices outside your own data centre. Answer slot: if you've built or run anything like that, say what it was and what your part was, in your own words. If not, say so plainly and say what you'd need to learn first |
| F3 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote shows a priority call you pushed through. It doesn't show you owning a delivery plan, and the words stay at its scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after it." Keep "after"; the sentence doesn't say "because". Answer slot: if you had a hand in what the reliability quarter contained, or in how it was tracked, say what, in your own words. If not, say so plainly and stay with getting it through |
| F4 | "own … hiring" — role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running a loop is adjacent to owning hiring, and the words stay at the loop's scope: "I run our hiring loop for backend roles; about 40 interviews last year." The 40 counts interviews, not hires. Answer slot: if any part of how the loop works was yours to set, say which, in your own words. If not, say so plainly and stay with running it |
| F5 | "growth for 11 engineers" — role description | none given | none | [grounded] | discovery | Strong evidence would be a named engineer, by role and not by name, whose skills or scope grew, and what you did to help. Answer slot: if you've grown an engineer's skills or career, say how, in your own words. If not, say so plainly and say how you'd start with eleven |
| F6 | "partner with hardware … on roadmap" — role description | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording can't close, and you've said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you'd learn it, said as a plan and never as a past. Your negative is about owning. The role asks about partnering, and your material is silent on that, so add nothing to make the gap feel smaller |
| F7 | "partner with … product on roadmap" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote touches the roadmap but doesn't say who the pressure came from or whether product was your partner in resolving it. Answer slot: if getting the reliability quarter through involved working it out with product, say how, in your own words. If it didn't, or that part wasn't yours, say so plainly and stay with what you pushed through |

No row is a gate. The role description names no location, authorisation, credential or schedule term.

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Lead two squads | A1, B2, H1, L1 |
| F2 Device-management services | B4, D4 |
| F3 Own delivery | A3, A4, D2 |
| F4 Hiring | B5, D3, J4 |
| F5 Growth for 11 engineers | C2 |
| F6 Partner with hardware on roadmap | B1, A2, G2 |
| F7 Partner with product on roadmap | A2, E2, E3, G1 |

---

## Prohibited claims

This list was built from the fit snapshot before any question was written. Nothing in this pack coaches these claims, and you shouldn't drift into them under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 and F6 evidence | "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." No slot |
| Has led more than one team | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a team of six. F1's slot stays inside the six |
| The reliability quarter caused the 60% drop | Inflated form of F3's quote (its logical form: "after", not "because") | The quote as stated: the burden dropped 60% after you pushed the quarter through. D1 and D2 keep the causal question as a slot inside the figure |
| Owned delivery for the team | Inflated form of F3 | F3's quote at its own scope. F3's slot stays inside the reliability quarter |
| Owned hiring for backend roles | Inflated form of F4 | "I run our hiring loop for backend roles." F4's slot stays inside the loop |
| Made about 40 hires | Inflated form of F4 (the number slid from interviews to hires) | "About 40 interviews last year." The figure counts interviews |

---

# Round 1: Hiring manager (Director of Engineering), Tuesday, 45 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Here's a situation on my roadmap, what do you do?" Live problems about running two squads next to hardware | High. A hiring manager is buying capability and expects you to work their problems (the hiring-manager prior in this pack's persona model) | Clarify, then objective, then approach, then metrics, then risks. Think aloud, and challenge one premise respectfully |
| Skeptic | Quiet probing of F1 and F6: six against eleven, no hardware roadmap | High. The would-be boss carries the risk of the hire, and the gaps in F1 and F6 are visible straight from the role description | Rehearse B1 until it's boring. Use only bridges your quotes carry, name the limit plainly, then give a ramp plan said as a plan |
| Conversational | "Walk me through your journey." Easy openers that are still scored | Medium. The opening minutes of a 45-minute conversation | A 90-second arc built only from your quoted sentences (C1) |

### Bank

**A. Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit two squads building device-management services. Walk me through your first 90 days." | CASE | [generic] | Clarify first: what the squads own, who leads each day to day, what's on fire, and what the Director needs from you by day 90. Then a sequence: listen (one-to-ones with all 11, the hardware and product partners), make one visible fix, then set a rhythm for delivery and hiring. Name how you'd know it was working. This question needs no claim about your past, so the guidance makes none. If you reach for an example, use only what C1's quotes say | The canonical first question for a would-be boss buying a new EM; CASE because it scores structure on the role's own shape (F1) |
| A2 | "Hardware tells you a board revision is slipping six weeks, and a device-management release depends on it. Product wants the date held. What do you do?" | CASE | [generic] | Structure it: what exactly depends on the revision, and what can ship without it. Which customers or commitments are behind product's date. The options: decouple, re-scope, or move the date. Who decides. How you tell everyone. Say aloud that you'd get hardware and product in the same conversation rather than relaying between them. No claim about your past | Hits F6 and F7 as a live problem, where your material is thinnest, and lets you show judgement without claiming history you don't have; `[generic]` because the scenario is a role-family pattern, not Larkfield's |
| A3 | "How do you decide between roadmap features and reliability work?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Give your decision principle in a sentence, then the one story your quote carries: you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after it. Keep "after". Answer slot: the "own delivery" line makes a probe on how you made the case likely. If you can say how you got it through, say so in your own words. If you can't reconstruct it, say so plainly and stay with the decision and what followed | F3's evidence is your strongest delivery-adjacent sentence, and a Director will want the principle behind it; JD content, CASE delivery |
| A4 | "As your director, how would I know whether your squads are on track?" | JD | [generic] | Forward-looking: what you'd report and how often, what counts as early warning, and when you'd escalate rather than absorb. Offer to agree the format with them in the first month. Make no claim about how you report today unless you can say it truthfully in your own words | Tests "own delivery" (F3) from the boss's side of the table; `[generic]` because it's a practice pattern, not your history |

**B. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't owned a hardware-adjacent roadmap. This role partners with hardware on the roadmap. Why should I bet on you here?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | **Highest-ROI rehearsal.** Concede first, plainly, before they push: "I haven't owned a hardware-adjacent roadmap." Don't soften it. Then the one adjacent thing your quotes carry: you pushed a reliability quarter through against roadmap pressure. Describe that, and let them draw the inference; don't tell them it proves anything. Then a ramp plan, said as a plan: who you'd sit with in hardware first, what you'd want to learn about their cycles, and how you'd test your understanding in the first month. Hold through two follow-ups by going back to the concession and the plan, never by adding experience. Concede specifically: "What I don't yet know is how hardware timelines constrain software sequencing. That's the first thing I'd learn." | F6 is the role description's line that presses on a gap you named yourself, so this objection arrives in some form; JD because it scores the stated requirement. Deepest rehearsal because the pull to thicken the answer is strongest here |
| B2 | "You've been a team lead of six. This is eleven engineers across two squads. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold the quote's scope: three of your nine years as a team lead of six. Then what you expect to change at eleven, said as expectations, not experience: less hands-on, more delegation, more time with partners. Ask whether the squads have leads. If they do, and only if asked, the plain acknowledgment is "I haven't managed managers." Follow it with how you'd approach it, as a plan | F1 is the visible size gap, and the "managed managers" question rides on it if the squads have leads; JD because it scores "lead two squads" |
| B3 | "Why leave payments for industrial IoT? Why here, why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold: give two reasons that are true for you, one about the role (two squads, partnering with hardware) and one about the domain. Say nothing about your current company you wouldn't say to them. If you don't yet have a domain reason beyond curiosity, say so plainly and give the role reason. A reason you can't expand under a follow-up is worse than a short true one | The motivation check every Skeptic runs on a domain switch (F1's "payments company"); JD because the switch is defined by the role's domain |
| B4 | "Have you built services that manage devices in the field?" | JD | [grounded] | Answer slot (F2): if you have, say what and what your part was, in your own words. If not, say so plainly and say what you'd learn first: the device lifecycle the services cover, and where your backend experience applies. Don't describe experience you haven't stated | F2 is silent in your material, so it's a discovery gap; JD because "device-management services" is the squads' remit |
| B5 | "You'd be hiring for both squads. What's your experience with hiring?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Lead with the quote's own terms: you run the hiring loop for backend roles, about 40 interviews last year. Keep "interviews". Answer slot (F4): if any part of how the loop works was yours to set, say which, in your own words. If not, say so plainly and stay with running it | F4 is your strongest direct sentence and a Director will test its edge; JD because it scores "hiring" |

**C. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc with only these beats: nine years in engineering, three of them as a team lead of six, now at a payments company; you run the hiring loop for backend roles; you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after it. End on why this role, using B3's true reasons | The casual opener is scored on economy; every beat is a quoted sentence so the arc can't drift (F1, F3, F4) |
| C2 | "Tell me about helping an engineer grow." | JD | [grounded] | Selection scaffold (F5): pick a time you helped an engineer's skills or scope grow. It needs the starting point, what you did, and what changed, with credit kept with them. If no such time comes to mind, say so plainly, then say how you'd approach growth for eleven | "Growth for 11 engineers" is a stated requirement and your material is silent on it, so it needs a rehearsed honest answer; JD because it scores that line |

### Reverse questions, Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Do the two squads have their own leads today, and would they report to this role?" | It turns an assumption into a fact for both of you, and it decides whether "managing managers" is even on the table |
| R1-2 | "What does a great first six months look like to you, specifically?" | It hands your would-be boss the success criteria, which you can play back in rounds 2 and 3 |
| R1-3 | "Where does the hardware/software seam cause the most friction today?" | It goes straight at F6 with curiosity instead of defensiveness |
| R1-4 | "How is delivery reported up to you now, and what would you change about it?" | It shows you're already thinking about A4 from their side |
| R1-5 | "What's the hiring plan for these squads over the next year?" | It connects to your strongest sentence (F4) without restating it |
| R1-6 | "What made this role open?" | Context on whether you'd be backfilling, splitting, or building |

---

# Round 2: Panel (two staff engineers and a product manager), the Thursday after, 60 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Staff engineers taking the 60% and the 40 interviews apart | High. Technical-specialist members probe depth, and your two figures are the obvious targets (the specialist prior in the persona model) | Know what you can and can't say about how each figure was counted, and say plainly when you don't know. Name your weakest assumption before they do |
| Peer Evaluator | "Where's the line between your call and mine?" from the staff engineers; "what happens when we disagree?" from the PM | High. All three would work beside you, not under you, so they're pricing what you add to and take from their load (the peer prior) | Reciprocity: what you'd bring them as well as what you'd need. Propose seam principles rather than pretending to know their seam |
| Values / Behavioral | The PM's "tell me about a time" questions about roadmap and disagreement | Medium. A cross-functional member tends to score behavioural stories (the cross-functional prior) | Map stories only to what your quotes carry. Use "we" for context and "I" for contribution |
| Pressure | One time-boxed "why you" | Low. Panels blend styles, and one member may play devil's advocate | Pause, restate the question, anchor in your quoted facts |

### Bank

**D. Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "On-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend the number in your own words, four slots. How it was counted: say what "on-call burden" measured, if you know. What it's sensitive to: say what would move it apart from the work. The assumption you'd defend least: name it before they do. Which part was yours: the quote says you pushed the quarter through, so stay with that unless you can truthfully say more. "I don't know exactly how it was counted" is an honest answer. Never supply a baseline or method you can't repeat under a second question | Your headline figure, and staff engineers are the likeliest to take it apart (F3); EXP because it tests what the number is and what was yours |
| D2 | "How much of that drop came from the reliability quarter, and how much from other things?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the quote's logic: it dropped after the quarter. Answer slot: if you know what else changed in that period, say so. If you know the quarter's work drove most of it, say how you know, in your own words. If you can't separate them, say so plainly: "it dropped 60% after the quarter; I wouldn't claim all of it." That concession buys credibility | Probers go for the causal link the sentence doesn't make (F3); the prohibited list bars the causal version, so this is where it gets tested |
| D3 | "About 40 interviews last year. What do you actually look for in a backend loop?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what you look for, in your own words; that's a view, not a claim. Answer slot (F4): if any part of how the loop works was yours to set, say which and why. If not, say so plainly and stay with running it. "About 40" counts interviews; the defend-the-number slot is how you counted them and which ones you sat in on | F4's figure and its edge; engineers on a panel care how you hire their future teammates |
| D4 | "Suppose the fleet update service keeps having flaky rollouts. As EM, when do you stop feature work to fix it?" | CASE | [generic] | Structure it: the cost of the flakiness (failed updates, support load, on-call), the trigger you'd agree on in advance, who decides with you (staff engineer, PM), and how you'd protect the date that matters most. You may mention A3's principle. Any story stays as A3's quote says it | Hits F2's domain as a live problem without claiming history; `[generic]` because it's a role-family scenario |

**E. Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the line between an EM's decisions and a staff engineer's?" | CASE | [generic] | Propose principles rather than claiming their seam: architecture and technical direction with the staff engineer; people, staffing and delivery commitments with you; disagreements worked out early and in the open. Ask how it works at Larkfield now. No claim about your past | Staff engineers are pricing whether you'll step on their remit; CASE because it's a design question about the role |
| E2 | "I want a feature for a big customer; your squad says reliability debt comes first. How do we resolve it?" (PM) | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure: get the customer's need and the debt's cost on the same page, find what can be cut or sequenced, and agree who decides. If you mention the reliability quarter, use the quote's terms: pushed through against roadmap pressure, on-call burden down 60% after. Answer slot (F7): if product was involved in that call, say how, in your own words. If not, say so plainly | F7 played out live with the person you'd partner with; CASE delivery, with F3's quote as optional support |
| E3 | "What would you need from product, and what would we get from you?" (PM) | JD | [generic] | Reciprocity framing: what you'd give (early warning on risk, honest estimates, a voice for reliability) and what you'd ask (context behind dates, one prioritised list). Forward-looking, with no claim about your past | Partnership fit is what a peer scores (F7); JD because "partner with product" is a stated line |
| E4 | "How do you handle credit when work spans squads and hardware?" | VAL | [generic] | Selection scaffold: pick a time credit for shared work had to be split. It needs who did what and how you made it visible. If no such time comes to mind, say so plainly and give your principle and how you'd apply it here | A peer-evaluator stem; VAL because it scores behaviour, not capability |

**G. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you pushed back on the roadmap." (PM) | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the quote. Its beats are the reliability quarter, the roadmap pressure, pushing it through, and on-call burden dropping 60% after. Tell them in your own words. Answer slot (F7): the role description's product-partnering line makes a probe on who you worked it out with likely. If product was part of it, say how and what part was yours. If it wasn't, or that part wasn't yours, say so plainly and stay with the quarter | F7's thin bridge and F3's best story, from the person who'd sit across that table; VAL because it scores how you hold a position |
| G2 | "How do you work with a hardware team whose timelines you can't change?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | B1's concession, shorter: "I haven't owned a hardware-adjacent roadmap." Then how you'd approach it, as a plan: learn their cycle, plan software around their fixed points, raise conflicts early. Don't add experience. If you've worked with hardware or another fixed-timeline team in some other way, say so only in your own words | F6 returns in collegial packaging; it's the same objection as B1, and the answers must match across rounds |

**H. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal staff engineer moving into management?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." | Pause, then two facts and one claim about the future: three of your nine years as a team lead of six; you run the hiring loop for backend roles. Then what you'd bring as an outsider, framed as a view, not as a slight on them. Don't run over sixty seconds | A Pressure stem applied to F1; JD because it scores fit to "lead two squads" |

### Reverse questions, Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What could a new EM do in the first month that would genuinely help your work?" | The reciprocity question, which matters to peers |
| R2-2 | "Where does an EM help you most, and where do they get in the way?" (staff engineers) | It shows you heard E1 and respect their remit |
| R2-3 | "How does the roadmap get negotiated between product, hardware and engineering today?" (PM) | It goes straight at F6 and F7 with curiosity |
| R2-4 | "What's the on-call load like for these squads right now?" | It ties to your strongest story without restating it |
| R2-5 | "What's the one technical bet in device management you'd want the new EM to back?" (staff engineers) | It invites them to pitch to you, which turns the panel into a conversation |
| R2-6 | "What did the Director tell you this role most needs?" | It lets you calibrate against Round 1 |

---

# Round 3: VP Engineering, "values and leadership philosophy", the following Monday, 30 min

A values-style round was detected from the recruiter's words. Larkfield's published values aren't in hand (the search was refused), so this round has no values cheat sheet and VAL questions are themed on the recruiter's phrase. Paste the values page, or allow the search, and every VAL row below can be mapped value by value.

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?" "Tell me about a time…" | High. The recruiter named the round's focus as values and leadership philosophy | Two or three principles stated as beliefs, each attached only to a story your quotes carry, or to a selection scaffold |
| Case / Strategist | Altitude questions: where the domain is going, what success looks like at the org level | Medium. The skip-level prior in the persona model, weighted down by the recruiter's stated focus | Clarify, then structure. Say plainly where you don't know the domain yet |
| Pressure | Time-boxed challenges on F1 and F3 | Medium. The skip-level prior; a 30-minute slot forces short answers | Hold through two follow-ups, then concede specifically |

### Bank

**J. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection scaffold: choose two or three principles you actually hold, stated as beliefs, not as achievements. Attach a story only where a quote carries one. The reliability quarter fits a principle about the team's operating health, told as the quote says it. For any principle no quote carries, say how you'd apply it here rather than inventing a past. Don't tell the VP what your work proves | The round's stated focus in its plainest form; VAL because the recruiter framed the round as values and leadership philosophy |
| J2 | "Tell me about a time you held a position under pressure." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the quote: the roadmap pressure, pushing the reliability quarter through, and on-call burden dropping 60% after. Tell them in your own words and keep "after". Answer slot: if you can say who the pressure came from and how you held the position, do it in your own words. If you can't, say so plainly and stay with the decision and what followed. Keep the story consistent with G1: the VP may have heard the panel's notes | F3's story is the one your material carries for this theme; VAL because it scores behaviour under pressure |
| J3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, what you said, and how the relationship came out. If the reliability quarter is honestly that story, tell it as the quote says it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A values-round stem in the persona model; your material doesn't show this, so the honest branch matters |
| J4 | "How do you decide who to hire, and what makes you say no?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Give your hiring principles as beliefs, then the quote as your context: you run the hiring loop for backend roles, about 40 interviews last year. Answer slot (F4): if a no-hire call was yours, say how you made it, in your own words. If those calls weren't yours, say so plainly and say what you look for when you interview | Hiring is where a VP sees values in action (F4); VAL because the question is about judgement |

**K. Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Where do you think device-management software is heading in industrial IoT, and what would that mean for your squads?" | CO | [generic] | Say plainly that you're coming from payments and are still learning the domain. Then offer a structured view you can defend, and ask how the VP sees it. Don't present industry trends as facts unless you've read them yourself and can name the source. This question is generic because company and strategy research was refused; it's the bank most improved by research | The skip-level altitude test; CO because it scores domain and strategy thinking |
| K2 | "A year from now, how would I know you've succeeded?" | CASE | [generic] | Three or four outcomes across delivery, people and partnership (hardware, product), each with how you'd see it. Tie back to what the Director said in Round 1, if you asked R1-2 | Lets you show you think at the VP's level and that you listened in earlier rounds |

**L. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "You haven't managed managers. If this group grows, you'd need to. Why should I believe you can?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Concede first, plainly: "I haven't managed managers." Then hold on what your quotes carry: three of your nine years as a team lead of six. Then a plan, said as a plan: how you'd learn it and what support you'd ask for. Hold through two follow-ups by going back to the plan, never by stretching the six | A skip-level is likely to look past this role to the next one; JD because it scores F1's leadership line from above |
| L2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Short: it was the team's burden and the team's work, and you pushed the reliability quarter through. That's your part as the quote states it. Keep "after". Answer slot: if more of it was yours, say what, in your own words. If not, stay there. Match what you said to the panel in D1 and D2 | The Pressure stem on your headline figure (F3); EXP because it tests attribution |

### Reverse questions, Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What's a leadership value you hold that you'd want an EM here to share, and how do you see it when it's missing?" | It mirrors the round's own framing back at the VP |
| R3-2 | "What does the engineering org need most from its managers over the next year?" | It's an altitude question that invites the VP to set your agenda |
| R3-3 | "How do engineering and hardware leadership make roadmap trade-offs at your level?" | F6 again, one level up |
| R3-4 | "What do your strongest EMs do that others don't?" | It gives you a concrete bar, and a check on fit |
| R3-5 | "Is there anything from my earlier rounds you'd want me to address?" | It invites the objection while you still have the room |

---

## Sources

**Provided documents:** your message (the role description, round schedule and background).

**Searches sent:**

| Query | Outcome |
|---|---|
| `"Larkfield Systems" values` | refused |
| `"Larkfield Systems" interview process engineering manager` | refused |
| `"Larkfield Systems" industrial IoT news 2026` | refused |

**Loop:** established by your own words: three scheduled rounds, each with who runs it and its length.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have supplied the published values for a Round 3 values cheat sheet and value-by-value VAL questions |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have checked the panel's format and any case style; the rounds themselves are fixed by your message |
| 3. `Larkfield Systems strategy / recent news` | unavailable | The search was refused. It would have grounded K1 and the CASE questions in Larkfield's current priorities rather than `[generic]` patterns |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form. There's no interviewer read, and reverse questions are round-specific but not person-specific |
| 5. representative `Engineering Manager` JD | skipped | The role description you pasted fixes the fit snapshot's requirements and the JD-tagged questions |

---

## Upgrade menu

- Allow web search → the values page gives Round 3 a values cheat sheet and VAL questions mapped value by value; loop research checks the panel's format; strategy news turns K1, A2 and D4 from `[generic]` into Larkfield-specific CO and CASE questions
- A deeper research pass (L2: up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and recent org context for a stronger Round 3, plus public talks or writing by the VP or Director if you share their names
- The full job posting → requirements beyond the five lines in the summary become fit rows, and the coverage table checks against the full list
- Your CV → F2, F5 and F7 may gain quoted evidence, and story-mapped guidance replaces selection scaffolds where a CV line carries the story
- Interviewer names → persona weights read from their public professional footprint, plus a reverse question tied to each one's own path
- The recruiter's prep notes → coverage of any pre-declared deliverable (a presentation or a system-design segment in the panel) and the panel's actual split of topics
- Your answers to the answer slots in F2, F3, F5 and F7, given here outside a drill → those rows gain your own sentences, and the questions that rest on them (B4, C2, A3, E2, G1, J2) become story-mapped
- Prep time per day → a prep schedule across the two weeks, ordered by round
- A dossier from job-underwriter → the highest-ROI objection would be derived from verified evidence rather than inferred here, and its prohibited-claims list would bind this pack alongside the local one
