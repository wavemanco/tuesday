Research turned up a lot: the studio's values, its interview format, a recent strategy announcement and a talk by Tobias. I'm reading the two official pages in full before I build the pack.
I've built your prep pack and saved it. I treated Tobias as your hiring manager, because Saltmarsh's careers page says the 60-minute interview is with the hiring manager. I also planned it around tonight, since Friday is tomorrow.

**What the research changes:**
- **The format is published.** Saltmarsh calls it the "Outage Hour": you'll work through a simulated outage during a live event, then have a values conversation. There's no take-home. The pack spends most of its questions on the outage scenario (A1–A5) and the studio's three values (B1–B4).
- **The two games are changing business model.** In September Saltmarsh announced it is moving both titles to a season pass with one shared events calendar from February 2027. That makes your "never worked on a game with in-app purchases" the objection most likely to come up. **C1** is the question to rehearse hardest: say that gap yourself, before Tobias does.
- **Tobias came from QA.** Their GDC 2026 talk says they were a QA lead before running live ops, and argues that patch notes should describe only what actually shipped. That makes your release checklist your strongest point, and also the one they'll question most closely. Keep it to exactly what you told me: you wrote it, and your QA team still uses it.
- **Several gaps are things your notes don't say either way.** For example, whether your main title counted as a live-service game, and how the retention numbers you presented were worked out. The pack marks these as "answer slots": you fill them with whatever really happened, even if that's "no" or "that wasn't me".

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-canned-075f631d:
- saltmarsh-games_live-operations-producer_interview_pack.md

If you want, I can play Tobias and put C1 to you live, with follow-ups that react to your answers.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The role reports into live ops, and Saltmarsh's careers page says the 60-minute interview is with the hiring manager, so this pack treats Tobias as your hiring manager.
**Format:** the "Outage Hour". Saltmarsh's careers page describes it as one 60-minute interview: a live-incident tabletop on a simulated outage during a live event, then a values conversation. There's no take-home.
**When:** Friday, which is tomorrow.

---

## How to use this pack

Each question has two labels:

- **Persona** is the style the question is asked in: a live case, a values probe, a skeptical push, and so on.
- **Type** is what the question is actually scoring.

| Type | What it scores |
|---|---|
| VAL | Whether what you've done shows Saltmarsh's published values |
| EXP | Whether your stated experience holds up, and which parts were actually yours |
| JD | Whether you can do the job as the JD describes it, gaps included |
| CO | Whether you understand Saltmarsh's strategy and recent moves |
| CASE | How you structure and reason through a live problem from the role |

Question IDs go by persona: A, B, C, D, E and G. There is no F bank, because **F1–F9 are the fit-snapshot rows** and the question tables point back to them.

The guidance is scaffolding, not a script. An **answer slot** marks a place where your material doesn't say what happened. Fill it with what really happened, in your own words, including "that wasn't me" or "we didn't have that".

---

## Prep plan for tonight

I've assumed you have one evening of about two hours. If you have more, skip this section and work through everything.

1. **C1, out loud, three times (25 min).** This is the pack's highest-value rehearsal. Say the concession first, until it comes out calmly.
2. **The tabletop: A1, A2, A3, then E2 (35 min).** It's half the hour. Practise the order "clarify, decide, tell players, record" out loud with a timer.
3. **The values cheat sheet, then B1–B3 (25 min).** There are three values. Have the official names memorised.
4. **Fill your answer slots on F2, F3, F5 and F7 (20 min).** Write one honest sentence for each, so D1, C3 and C5 don't catch you by surprise.
5. **Pick three reverse questions (5 min).** Include R1 or R2.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material covers one title's weekly content-drop calendar. It doesn't cover live events across two titles, and your words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on scale likely. If drops on that calendar ran as timed events, say so and how, in your own words. If they didn't, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team" — your message | low | [inferred] | discovery | Leading a team and coordinating teams aren't the same thing, and your material doesn't show coordination either way. If you're asked about leading, these words are yours: "I haven't led a team." Answer slot: the JD's coordination line makes a probe on cross-discipline work likely. If people from design, art, engineering or community worked with you on the content drops, say who and what you did together, in your own words. If they didn't, or the coordinating was someone else's job, say so plainly and return to the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a post-event review, but it isn't the same work. Your words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's ownership line makes a probe on reviews likely. If you ran or wrote a review after a content drop, say what it covered and which part was yours. If there was no such review, or it wasn't yours, say so plainly and stay with the monthly numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist is adjacent to managing it with QA. This is your strongest row, so keep it at its own scope: "I wrote the release checklist our QA team still uses." Answer slot: "manage" makes a probe on ongoing upkeep likely. If you've kept it updated or worked through releases against it with QA, say how, in your own words. If you haven't, say so plainly and stay with writing it and QA still using it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [inferred] | discovery | Your material shows four years as an associate producer. It doesn't say whether the main title was a live-service game. Your words: "Four years as an associate producer at a puzzle-game studio." Answer slot: if the main title was a live-service game, say so in your own words. If it wasn't, say so plainly and stay with the four years and the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: weekly, the main title, two years. It's a claim with nothing behind it that the interviewer can inspect, so expect a probe on it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap. Expect a probe on what the numbers measured. Answer slot: if you know which retention measures were in them and how they were counted, say so in your own words. If you didn't produce them or don't know how they were counted, say so plainly and stay with presenting them monthly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already shows written work that people still use, and it only needs saying in those terms: "The release checklist I wrote is one our QA team still uses." Nothing should be added to it |
| F9 | "moves Tidepool Tactics and Lantern Row to a season-pass model" — Saltmarsh news, Project Larkspur | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | The JD doesn't ask for this. The row is here because Saltmarsh has announced the season-pass move, so it's likely to come up, and this is a gap you've stated yourself. Your words: "I haven't worked on a game with in-app purchases." Follow it with how you would learn it, said as a plan and never as a past. Never claim monetisation work, and don't add anything that makes the gap sound smaller |

**What each column means:** Confidence grades your evidence. Provenance grades what this pack wrote about it. Gap type says what kind of gap the row has.

---

## Reading the interviewer

Tobias's public professional footprint: the GDC 2026 talk listing, nothing else.

| Signal | Source | What it means for you | Provenance |
|---|---|---|---|
| Head of Live Operations at Saltmarsh, previously a QA lead at a console studio | GDC 2026 talk page, "Patch Notes Are a Promise" | Release checklists and QA are the work Tobias came from. That makes F4 the claim most likely to be probed in depth, so keep it exactly at your own words (E1, B3, D4) | [inferred] |
| The talk's argument: "a live team is judged by how often its patch notes describe what actually shipped" | Same page | This is close to the value "Ship the Patch Not the Promise", so expect it in the tabletop's player-comms moment (A2) and in the values half (B2) | [grounded] |
| Wording you share: the release checklist with QA | F4: "Wrote the release checklist our QA team still uses." | Talk about the checklist the way your sentence does. There's no career jump the two of you share, so don't present one | [grounded] |

---

## Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | The tabletop: a simulated outage during a live event | **Highest.** Saltmarsh's careers page documents this as half the hour, and a hiring-manager round leans this way anyway | Work through it in order: clarify, objective, decision, player comms, internal comms, record. Think aloud. Challenge one premise respectfully |
| Values / Behavioral (B) | The documented values conversation, built on three published values | **High.** It's the second half of the hour, and Tobias's talk theme lines up with one of the values | Know the three value names exactly. Map stories only where your quotes carry them, and use the honest branch where they don't |
| Skeptic (C) | Pushes on the gaps: monetisation, two titles, coordination | **Medium-high.** A hiring manager is paying to remove risk from the hire, and the Larkspur move makes F9 topical | Rehearse C1 until it's boring. Concede plainly and give a ramp plan. Never bluff |
| Data-Driven Prober (D) | KPIs, post-event review, the retention numbers | **Medium.** The JD names KPIs and retention metrics, and F3 and F7 will draw follow-ups | Know what you can and can't say about how the numbers were counted. "I didn't build them" is an answer |
| Conversational (G) | The opener and "why Saltmarsh" | **Medium-low.** Expect it in the first few minutes. It's still scored | A 90-second arc made only of your own sentences |
| Pressure (E) | Interruptions and time-boxes inside the tabletop, plus "how much was you" | **Low-medium.** A simulated outage invites time pressure. No source says Tobias interviews in a stress style | Pause and restate the question. Hold a position through two follow-ups, then concede something specific |
| Peer Evaluator | Not expected | **Not plausible.** It's one hiring-manager interview, so no peer is in the room | No bank |

---

## Question banks

### A. Case / Strategist: the Outage Hour tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's the Saturday of a weekend event and the event servers go down. Talk me through your first thirty minutes." | CASE | [grounded] | Clarify first: what's down, which title and platforms, since when, and who is already on it. Name the one decision you need now, whether to pause the event or let it run, and the facts that decide it. Say who you'd pull in: on-call engineering, QA, community. Draft the first player message: what's known, what's being done, and when the next update comes. Never give a fix time you don't have. Set an internal update rhythm. Close with what you'd write down for the review. Think aloud the whole way. This question makes no claim about your past | The careers page names a live-incident tabletop as the first half of the interview, so a version of this is close to certain. The structure is a pattern rather than Saltmarsh's own playbook |
| A2 | "Engineering thinks the fix might be live in two hours. Community wants to post that. What goes out?" | CASE | [grounded] | Post what's true now, not what's hoped: the problem is found, the team is on it, and the next update will come at a set time. Hold back the two-hour estimate until the fix is built and checked. Give your reason in one line: a missed time breaks trust twice. If you're pushed, hold through one follow-up, then accept a compromise that keeps the next-update time and drops the fix time | The value "Ship the Patch Not the Promise" and Tobias's talk both make this the moment the tabletop is most likely to test. CASE is the primary type because it's a live decision. Its values content comes up again in B2 |
| A3 | "The event ended and a lot of players lost progress. Extend the event, compensate them, or neither?" | CASE | [grounded] | Clarify the scale and what the data can show about who was affected. Lay out the options, and judge them against what players lost and what each option costs the calendar, including the next event it might collide with. Make a call and name its cost. The value "Players Before Plans" says that when the calendar and the players disagree, the players win. Use that as your reason, not as a slogan | It's the natural follow-on to an outage, and it tests one published value under a real trade-off. CASE because you're scored on the reasoning, not on a right answer |
| A4 | "From February both titles share one events calendar. How would you plan it so Tidepool Tactics and Lantern Row events don't collide?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: shared or separate player bases, how much capacity the single live-ops group has, and how much QA each update needs. Then structure it: fixed windows per title, a rule for when two releases may overlap, QA load as a hard limit, and one shared comms plan. Challenge one premise respectfully. If you mention your own calendar, stay with its words: "I ran the weekly content-drop calendar for our main title for the last two years." Keep everything else framed as a plan, not as something you've done | Project Larkspur, announced September 2026, is the change this role is being hired into. CO because it tests whether you're current on the company's direction. It's also the strongest CASE-delivered strategy question in the pack |
| A5 | "After that outage, give me the three headlines of your post-event review. Which KPIs go in it?" | CASE | [generic] | Three headlines: what happened and when, what it cost players, and what changes before the next event, with an owner for each change. For KPIs, name a small set you can define out loud, such as participation in the event, retention of affected players against unaffected ones, and support contacts, and say why each one matters. Say which number you'd trust least and why. Present this as how you'd do it. F3 keeps you from claiming you've owned one | It covers the JD's post-event review line through the scenario rather than through your record. It's `[generic]` because the KPI set is a role-family pattern |

### B. Values conversation

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. Pick a time a planned content drop changed because of what players were doing or saying. It needs what was planned, what the players showed, what changed, and your part in the change, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the calendar you ran, or how you would handle it | This is the published value "Players Before Plans", nearly word for word. F1 and F6 are the only rows that touch it, and neither carries a disagreement, so this is a scaffold |
| B2 | "Tell me about a time something was announced before it was actually built. What happened?" | VAL | [grounded] | Selection scaffold. Pick a time an announcement ran ahead of the work, whether yours or a team's. It needs what was said, what was actually built, the gap between the two, and what you did about it. If no such time comes to mind, say so plainly, then say how you would handle it, using the A2 approach | This covers "Ship the Patch Not the Promise" and the theme of Tobias's talk. No fit-snapshot row carries such a story |
| B3 | "Tell me about the release checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats are the ones the quote states: you wrote it, and your QA team still uses it. Tell them in your own words. Answer slot: the value "Leave the Build Greener" talks about leaving "the checklist better than it found them", so expect a probe on what came before. If there was an earlier checklist that yours replaced, say what changed. If there wasn't one, say so plainly and describe what yours covers | It's your best match to a published value, and Tobias's QA background makes it a likely deep-dive. VAL first because the values half is where it's scored. E1 rehearses the attribution probe on it |
| B4 | "Tell me about a time you had to give leadership numbers they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F3 and F7, as far as the quote goes: you presented the monthly retention numbers to the studio head. Answer slot: if a month's numbers were bad news, say what you said, how you framed it and what happened next, in your own words. If none was, or you didn't frame them, say so plainly and pick another time, or say how you would handle it | This is a persona stem for values rounds, aimed at F7. It tests whether presenting the numbers ever involved a hard truth |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "From February we're on a season pass. You haven't worked on a game with in-app purchases, so why should I bet on you for that?" | CO | [grounded] "never worked on a game with in-app purchases" | **Highest-value rehearsal in this pack.** Say the limit first, before anyone presses for it: "I haven't worked on a game with in-app purchases." Don't shrink it or add qualifiers. Then say the part you have done, in its own words: "I ran the weekly content-drop calendar for our main title for the last two years," and "I wrote the release checklist our QA team still uses." Then give a ramp plan, framed as a plan: learn from whoever owns the season pass how it's priced and measured, before the first season goes live. **Follow-up 1:** "So someone has to carry you on that?" Hold: the monetisation side is what you'd be learning, and the calendar and the checklist are what you've done. **Follow-up 2:** "What would you get wrong first?" Name one risk as something you'd guard against, not as experience, then stop | F9 is a gap you've stated yourself, and Larkspur makes it topical for this exact team. CO because it scores whether you've connected yourself to the company's announced direction. A calm concession here changes the rest of the hour |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Pick a real one, not a disguised strength. The post-event review is honest: say what you have done in its own words, "I presented the monthly retention numbers to the studio head," then that owning the review would be new, then the plan (A5's structure). If F2's slot came out as "no", coordination is the other honest pick | The JD lists four duties, and F2 and F3 are the thinnest rows. JD because it scores self-assessment against the stated requirements |
| C3 | "I don't see cross-team coordination in your background. How would you coordinate design, art, engineering and community on each update?" | JD | [grounded] "Never led a team" | If leading comes up, the words are yours: "I haven't led a team." Answer slot: if people from those disciplines worked with you on content drops, say who and what you did together, in your own words. If they didn't, say so plainly. Then give the plan: one owner per discipline for each update, a fixed check-in rhythm, the release checklist as the shared gate, and one written update everyone reads | F2 is silent on coordination, and the JD names four disciplines. Hiring managers tend to press exactly here. Keeping "haven't led" separate from "haven't coordinated" is the move |
| C4 | "You've run one title's calendar. We're asking for two titles on one calendar. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold at your scope: one title, weekly drops, two years. Then explain, as reasoning rather than experience, what changes: capacity shared across two teams, collision rules, QA load doubling at peak, and two player communities to brief. Concede plainly that two titles would be new | F1 is the transferability gap on the JD's headline duty. JD because it scores that duty directly |
| C5 | "Was your main title a live-service game?" | JD | [inferred] "4 years as an associate producer at a puzzle-game studio." | Answer slot: if it was, say so in your own words, with the weekly drops as your example. If it wasn't, say so plainly, then stay with the four years and the weekly content-drop calendar. Don't let the JD's words describe your title for you | F5 is silent on this, and the JD's 3+ years requirement is likely to be checked literally. Saying it plainly costs less than having it found out |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. What did they measure?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot, in your own words: which retention measures were in them, how they were counted, what moved them, and which part was yours. "I didn't build them" and "I don't know exactly how they were counted" are honest answers. Say them before you're caught on them. Name the assumption behind the numbers you'd defend least, if you know one | F7 is the evidence for the retention requirement, and presenting numbers reliably draws a "how were they counted" follow-up |
| D2 | "Who built those numbers, and what did the studio head do with them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | This is the attribution check. Answer slot: say who built them, which might be you, an analyst or a dashboard, and anything that changed because of a presentation, in your own words. If nothing visibly changed, or you don't know, say so plainly | It separates presenting from analysing (F7). EXP because it tests what was actually yours |
| D3 | "How would you know a weekend event worked?" | JD | [generic] | Define success before the event starts. Pick three measures, such as participation, retention against a comparable weekend, and in-event engagement. Choose a baseline, and name the weakest assumption out loud, for example that the comparison weekend really is comparable. Frame it as how you'd do it | This covers the JD's KPI ownership line as a method question. It's `[generic]` because it's a role-family pattern |
| D4 | "How do you run a release checklist with QA week to week?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Start from what you did: "I wrote the release checklist our QA team still uses." Answer slot: if you've gone through releases against it with QA, or updated it as things changed, say how, in your own words. If you haven't, say so plainly and describe how you'd manage it going forward | This covers the JD's "manage the release checklist with QA" line (F4), and it's the line closest to Tobias's own background |

### E. Pressure (expect this inside the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it, and our QA team still uses it." Answer slot: if others contributed sections or reviewed it, say who and what, in your own words. If it was yours alone, say so. Hold through two follow-ups, and concede only what's specifically true | F4 is your strongest row, so it's the one that gets tested hardest. EXP because it scores attribution |
| E2 | "Stop. Sixty seconds. The fix takes four hours and the event ends in two. Your call." | CASE | [generic] | Pause for a beat and restate it. Give one decision, one reason and one cost. Say what players are told, with no fix time promised. Then stop talking. A clear call with its cost named beats a hedge | A time-box like this is a common tabletop move. It's `[generic]` because no source says Saltmarsh uses one |

### G. Conversational (the opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made only of these four sentences, in this order: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title for the last two years, the release checklist QA still uses, and the monthly retention numbers you presented to the studio head. Answer slot: why live ops, and why now, in your own words | It's the near-certain opener, and it sets up everything after it. Every clause is in your material, so none of it will collapse under a follow-up |
| G2 | "How do you like to keep teams in the loop on an update?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick something you wrote that other people relied on. Your material's example is "I wrote the release checklist our QA team still uses." If you have another, use it. Then describe how you'd keep four disciplines informed, framed as a plan | It covers the JD's written-communication line (F8), asked casually but still scored |
| G3 | "Why Saltmarsh, and why now?" | CO | [grounded] | Answer slot: your real reason, in your own words. Anchor it to something you actually read: the three values, Project Larkspur's move to one shared calendar, or Tobias's patch-notes talk. One specific beats three general ones | Rapport questions are still scored, and naming a real Saltmarsh fact shows preparation. CO because it tests homework |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | C4, A4, B1 |
| Coordinate design, art, engineering and community on each update | C3, A1 |
| Own the post-event review and its KPIs | D3, A5, C2 |
| Manage the release checklist with QA | D4, B3, E1 |
| 3+ years producing live-service games or apps | C5, G1 |
| Experience running a content calendar | C4, A4 |
| Comfortable with player-retention metrics | D1, D2, D3 |
| Clear written communication | G2 |
| Season-pass move (not in the JD; from Saltmarsh news) | C1 |

---

## Values cheat sheet

Source: https://saltmarshgames.com/values

| Value (official name) | What it means at Saltmarsh, paraphrased | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, the players win | Selection scaffold (B1): a time a planned drop changed because of players. If you have none, say so plainly, then give the calendar you ran (F1: "I ran the weekly content-drop calendar for our main title for the last two years.") or how you'd handle it (A3) |
| Ship the Patch Not the Promise | Announce what's built, not what's hoped | Selection scaffold (B2): a time an announcement ran ahead of the work. If you have none, say so plainly and show it live in A2 instead |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Tell only the beats in that sentence, plus B3's answer slot on what came before |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your GDC talk you argued a live team is judged by how often its patch notes describe what actually shipped. How do you track that on your team now?" | It's tied to Tobias's own published argument. It shows you researched them, and it invites them to talk about their own practice |
| R2 | "You came to live ops from QA. How has that shaped the way the release checklist works here?" | It connects their career path to the JD's checklist line, which is also your strongest area, without claiming the two of you share a path |
| R3 | "With one live-ops group from February, how will this role split its time between Tidepool Tactics and Lantern Row?" | It shows you know about Larkspur, and the answer tells you what the job really is |
| R4 | "What would a strong first post-event review from a new producer look like to you?" | It goes straight at your thinnest JD row (F3) and gets you their standard before you start |
| R5 | "When did the calendar and the players last disagree here, and what did the team do?" | It asks them for a "Players Before Plans" story. Their answer shows how the value works in practice |
| R6 | "What should the person in this role have taken off your plate by month three?" | It's a concrete success measure, and it makes them picture you in the job |

---

## Claims this pack won't coach

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated (F2) | "I haven't led a team." |
| Has worked on a monetised or season-pass game | A negative you stated (F9) | "I haven't worked on a game with in-app purchases." |
| Ran live events, or calendars across multiple titles | The inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one title's weekly content-drop calendar. C4's slot stays inside that calendar |
| Owned post-event reviews or set event KPIs | The inflated form of F3 | F3's quote at its own scope. The material says you presented monthly retention numbers. A5 and D3 stay framed as plans |
| Built or analysed the retention numbers | The inflated form of F7 ("presented") | F7's quote at its own scope. D1 and D2's slots ask only what was yours |
| Manages the QA process | The inflated form of F4 ("wrote") | F4's quote at its own scope. D4's and E1's slots stay inside the checklist you wrote |

---

## Sources

**Provided:** your message (the JD text, your background, and the interviewer's name and title).

**Searches and fetches:**

- Search `Saltmarsh Games values` returned https://saltmarshgames.com/values
- Fetch https://saltmarshgames.com/values: the three values with their definitions
- Search `Saltmarsh Games interview process producer` returned https://saltmarshgames.com/careers/interviewing
- Fetch https://saltmarshgames.com/careers/interviewing: the format of the Outage Hour
- Search `Saltmarsh Games mobile studio news 2026` returned https://saltmarshgames.com/news/project-larkspur (Project Larkspur, September 2026; search snippet only, page not fetched)
- Search `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (GDC 2026 talk listing; search snippet only, page not fetched)

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, the B bank, A2 and A3. Three values, by their official names |
| 2. `Saltmarsh Games interview process producer` | yes | It established the loop: one 60-minute session with the hiring manager, a tabletop then values. That set the persona weights, made the A bank the largest, and detected the values-style round |
| 3. `Saltmarsh Games` strategy / recent news | yes | Project Larkspur: A4, C1, F9, R3, G3 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, R1, R2, and the B2 and A2 emphasis |
| 5. Representative `Live Operations Producer` JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Deeper research** (up to 6 more searches and 2 more fetches, a few more minutes) → a grounding brief on Saltmarsh's titles and recent moves, more of Tobias's published themes, and candidate reports on the Outage Hour.
- **Your answers to the slots in F2, F3, F5 and F7** (coordination on drops, any post-drop reviews, whether the main title was live-service, how the retention numbers were counted) → those rows get your quoted words, and C3, C5, D1 and A5 become story-mapped instead of scaffolds.
- **A redacted copy of the release checklist or a calendar sample** → F4 and F6 move from medium to high confidence, and B3 and E1 get specifics you can stand behind.
- **The recruiter's prep notes** → confirmation that the Outage Hour applies to this role, plus any focus areas they named.
- **A `tuesday-dossier.md` from an earlier evaluation of this role** → an evidence-graded main objection and a fixed list of claims not to make, in place of the ones this pack built itself.
