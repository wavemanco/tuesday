Web search was blocked (all three searches were refused), so I'm building the pack from what you gave me and labeling that clearly. Writing it now.
Renaming the question IDs that clash with fit-snapshot row IDs (Conversational becomes G, Values becomes H).
I've saved Priya's prep pack as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-1-denied-9aa95c2f/Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. It treats the meeting as one 60-minute peer conversation with Dan.

My three web searches were refused: Northwind's values, its interview process, and Dan's public profile. So everything in the pack comes from your notes. The pack lists those searches as not run, and the questions that would have drawn on Northwind's published values are general ones.

- **What's in it:** 23 questions under 7 interviewer personas, each tagged by what it scores (work experience, the job description, company knowledge, live case, or behavioral). Every question has answer guidance and a rationale for including and tagging it.
- **Weighting:** heaviest toward Dan probing her numbers (because he calls himself "relentlessly data-driven") and toward him as a peer weighing what she adds to his team.
- **Cases:** tilted toward pricing and packaging to match his background, including pricing Compass and defending a product line against the bundling vendor.
- **Highest-priority prep is C1:** "consumer tech, no sales-ops or quota-setting — why trust you with B2B go-to-market?" It's rehearsed through two follow-ups. The script has her concede the gap first, then stand on what she has actually done, then give a ramp plan.
- **Claims the pack won't coach,** because they stretch what your notes say:
  - that she drove the ~$400M (your notes say she *proposed* the change and it was *credited* with the uplift)
  - that she designed a partner motion or negotiated the carrier deals (your notes say her model was *used in* those negotiations)
  - that her annual volume targets were quotas
- **Also included:** a table of what your notes say about her against each job requirement, a read on Dan, a table showing which questions cover each requirement and priority, and 7 questions for her to ask him. The upgrade menu at the end lists inputs that would sharpen it. Priya's CV and the full job description would help most.

I can play Dan and run C1 with Priya as a live practice round, then give feedback against that question's guidance.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Session:** one 60-minute conversation with **Dan Kovac**, Director of Sales Strategy. He would be Priya's **peer**, and they would report to the same VP.
**What this pack was built from:** the coach's notes only: JD highlights, a summary of Priya's background, a summary of Dan's profile, and a research note on Northwind. Every web search was refused in this session (see Sources), so nothing here comes from the web.

---

## How to use this pack

- **Personas describe how a question is asked.** Dan is one person, but over 60 minutes he will switch registers: a collegial peer question, then a probe into the numbers, then a live case. Each bank below rehearses one register.
- **Types describe what is being scored:**

| Tag | What it scores |
|---|---|
| **EXP** | Whether the claims on the CV hold up: what Priya actually did, and how the numbers were counted |
| **JD** | Whether she can do the listed job, gaps included |
| **CO** | Company knowledge: Northwind's priorities, the threat from bundling, Compass |
| **CASE** | Structure and reasoning on a live problem from the role |
| **VAL** | Behavioral evidence: how she worked with people and under pressure |

- **Provenance labels:** `[grounded]` means traceable to the coach's notes. `[inferred]` means a derivation, and the derivation is named. `[generic]` means a role-family pattern that asserts nothing about Northwind or Priya.
- **An answer slot** is an instruction for the live answer, not a question for this chat. It has two honest branches: if you did it, say how, in your own words; if you didn't, or it wasn't yours, say so plainly.
- **The guidance is scaffolding, not a script.** Every answer should be in Priya's own words and should claim only what she actually did.
- **Highest-ROI prep: C1.** It is the objection most likely to come up in some form, and the answer works best rehearsed until it sounds boring.

---

## Fit snapshot

Requirements are quoted from the JD highlights in the coach's notes. Evidence is quoted from the coach's summary of Priya's background. Her own CV would replace those quotes with her exact lines (see Upgrade menu).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, the coach's notes | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy & ops at a consumer-tech company. It doesn't show GTM ownership for B2B product lines, so the words stay at that scope: nine years in product strategy and ops at a large consumer-tech company, plus a store-surface change she proposed that was credited with roughly $400M ARR uplift. Keep both verbs, *proposed* and *credited*. Answer slot: the JD's "own GTM strategy" line makes a probe likely on which go-to-market decisions were hers. If any were, name which and how she decided, in her own words. If none were, say so plainly and stay with the product-strategy work and the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, the coach's notes | none given | none | [grounded] | discovery | The material says nothing about customer-lifecycle or whitespace analysis. Answer slot: if any of her consulting or product-strategy work broke a customer or partner base down by where growth could come from, say what was broken down and what it showed, in her own words. If none did, say so plainly and say how she would build the first whitespace cut at Northwind |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, the coach's notes | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. But this is a self-description with nothing inspected behind it, and Dan calls himself "relentlessly data-driven", so expect him to test it. Lead with it in the quote's own terms: skilled in SQL and Tableau. Answer slot: if a specific analysis she ran herself in them comes to mind, walk through it end to end. If not, say what she uses them for |
| F4 | "partner-motion design experience required" — JD highlights, the coach's notes | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model that was used in negotiations is adjacent to designing a partner motion, but it isn't the same work, and the quote doesn't say she negotiated. The words stay at the model: she built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: the JD's "required" line makes a probe likely on whether any part of how the carrier partnerships were structured was hers to design. If any was, say which part and what she decided. If none was, or the model fed decisions other people made, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, the coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap. Lead in the quote's own terms: annual volume targets, set with cross-org consensus. Answer slot: the JD's influence line makes a probe likely on how the consensus was reached. If there was resistance she worked through, say what it was and what part was hers. If there wasn't, say so plainly and describe how the targets were agreed |
| F6 | "AI experience a plus" — JD highlights, the coach's notes | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Using AI tools every day is adjacent to AI product experience, but it isn't the same thing, so the words stay at use: she uses AI tools every day. Answer slot: with Compass among Northwind's priorities, expect a probe on what she does with them. Say what she actually uses them for, in her own words. If none of it touched an AI product's strategy or launch, say so plainly |
| F7 | Sales-strategy mechanics such as quota setting and sales ops. This is Dan's own lane and isn't in the JD highlights | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | No wording closes this gap, and the notes state it. Words: "I haven't done classic sales-ops or quota-setting." Then how she would learn it, framed as a plan and never as a past. Setting annual volume targets (F5) stays exactly what the quote says and is never presented as quota-setting |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines (F1) | C1, C3, D3, E1 |
| identify whitespace across land/adopt/expand/renew (F2) | A4, D3 |
| run independent analysis in SQL and Tableau (F3) | A4, B3 |
| partner-motion design experience required (F4) | C2, D4, A3 |
| strong cross-functional influence (F5) | A5, B1, B2, H2 |
| AI experience a plus (F6) | G2, D2 |
| Sales-ops and quota mechanics, Dan's lane (F7) | C1, B3, E1 |
| Research note: enterprise expansion | A4, D3 |
| Research note: Compass AI copilot launch | D2, B3, G2 |
| Research note: reaching profitability | D1, D2 |
| Research note: bundling by a larger platform vendor | D1, R2 |

---

## Reading the interviewer

Everything below comes from the coach's summary of Dan's profile. The search for his public footprint was refused, so no talks or posts were read.

| # | Signal | Provenance | What it means for this conversation |
|---|---|---|---|
| I1 | Self-describes as "relentlessly data-driven" | [grounded] the coach's notes | The Prober is his dominant register. Expect every figure, especially the ~$400M, to be followed two levels down to how it was counted and what was hers. A clean "I don't know how that was counted" will land better with him than a confident method she can't stand behind |
| I2 | Career spine is "pricing and monetization roles" | [grounded] the coach's notes | Expect live cases to tilt toward pricing, packaging and unit economics: how to monetize Compass, how to respond to a bundled competitor without giving the product away. Lead with the economics, such as margin, attach and expansion, before the narrative |
| I3 | "one early-stage-startup chapter" | [grounded] the coach's notes | Builder stories land well with someone like this. Expect a probe on whether big-company habits survive a scrappy new product line with thin data (C4) |
| I4 | Peer: "both reporting to the same VP" | [grounded] the coach's notes | He is weighing what Priya adds to, or takes from, his own team's work. Expect questions about the seam between their roles, reciprocity and credit-sharing. He knows quota and sales-ops mechanics firsthand, so bluffing F7 would fail with him in particular |

**Mirror opportunities.** The shared vocabulary is revenue and monetization, and the one line of Priya's material that speaks it is F1's quote: "proposed a store-surface change credited with a ~$400M ARR uplift". Use it in its own terms only. No shared career jump is offered, because nothing in her material corresponds to Dan's startup chapter.

---

## Persona table

The loop is set by the coach's own words: one 60-minute conversation with Dan. So no archetype fallback is used, and no values-style round is documented for this session.

| Persona | How it shows up with Dan | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Follows the $400M, the revenue model and SQL claims two levels down | **High (5 questions).** The peer prior puts it near the top, and I1 raises it further | Know what she can and can't say about how each figure was counted, and say "I don't know" plainly where that's true. Name her weakest assumption before he does. Offer to walk through an analysis she did herself end to end |
| Peer Evaluator | Seam between the roles, "what would you need from me", credit across teams | **High (4).** The peer prior, plus I4 | Lead with reciprocity: what she brings his team, not only what she needs. Propose principles for the seam rather than claiming to know where it is. Use "we" for context and "I" for her contribution |
| Case / Strategist | Live problems on pricing, packaging, bundling defense and whitespace | **Medium-high (4).** I2 tilts the cases toward monetization, and the research note supplies live material | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Respectfully challenge one premise per case |
| Skeptic | B2B and quota gaps, partner-motion "required", why now, scrappiness | **Medium (4).** The gaps in F1, F4 and F7 are plain to anyone in sales strategy, and I3 adds the scrappiness probe | Rehearse C1 until it's boring. Build bridges only from what her quotes carry, then give a concrete ramp plan. Be candid about anything Dan personally owns |
| Pressure | Time-boxed "why you", "how much was actually you" | **Low (2).** Peers rarely run stress rounds, but data-driven follow-ups can feel like pressure | Pause, restate the question, anchor in what she actually said. Hold through two follow-ups, then concede the specific limit |
| Conversational | The opener, AI tools, the closing "any questions?" | **Low (2).** The opener is likely, and the AI-plus line gets asked casually | A rehearsed 90-second arc. Treat the casual AI question as scored |
| Values / Behavioral | Disagreement and influence stories | **Low (2).** No values round is documented, and Northwind's values weren't fetched | Use a story where her quotes carry one. Otherwise use a selection scaffold, with the honest branch |

---

## Question banks

### A. Data-Driven Prober (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift credited to the store-surface change was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F1. She proposed the change, and it was credited with roughly $400M ARR uplift. Keep both verbs, *proposed* and *credited*, and keep the "~". Answer slots, each in her own words: how the figure was counted; what it's sensitive to; the assumption behind it she would defend least; which part was hers. If she doesn't know how it was counted, she should say so plainly. That's an honest branch, and with Dan it beats a reconstructed method. Name the weakest assumption before he asks, if she knows one | This is the headline metric, and I1 makes it the first number Dan pulls. EXP because it tests attribution and how the figure was counted, not GTM skill |
| A2 | "What would that number be sensitive to? If you had to defend one assumption least, which?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The second level of A1. Use the sensitivity and weakest-assumption slots only, in her own words, and the pack supplies no assumption for her. If she doesn't know, she should say so and say what she would want to check. Don't let the answer drift from "credited" to "I generated" | The Prober's stem goes two levels deep, and a peer who works in pricing will. Kept separate from A1 so she rehearses the second follow-up, which is where improvised methods break |
| A3 | "Walk me through the partner-level revenue model you built for the carrier negotiations: inputs, structure, what it was used for." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, with the beats the quote states: she built it, it was partner-level, and it was used in carrier negotiations. Answer slot: the inputs and structure, in her own words; if any piece wasn't hers, say so. Name the assumption in it she'd defend least, if she knows one. The quote doesn't say she negotiated, so she shouldn't imply she did | F4 is the bridge to the "required" partner-motion line, and a pricing peer will want the model's mechanics. EXP primary. It also prepares the ground for C2 |
| A4 | "Say I hand you account, usage and contract tables. How would you find expansion whitespace, in SQL, live?" | CASE | [generic] | Clarify the grain (account or product line) and the time window. Define land, adopt, expand and renew as states the data can detect. Join accounts, usage and contracts. Build a few signals, such as product attach, depth of usage and days to renewal. Segment the output and say what the Tableau view shows a seller. State her assumptions and what she'd validate with Sales Strategy. The question needs no claim about her past, so the guidance makes none | It turns F2 and F3 into a live test, which is the likeliest way a data-driven peer checks "skilled in SQL/Tableau". CASE delivery on JD content. `[generic]` because it's a method, not a fact about Northwind's data |
| A5 | "You set annual volume targets with cross-org consensus. How were those targets built?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5. She set annual volume targets, and they were agreed with cross-org consensus. Answer slot: how they were built, and which part of the method was hers, in her own words. If parts came from other teams, say so. These were volume targets, and she should never call them quotas (F7) | This is the closest thing in her material to Dan's lane, so he will probe it. EXP because it tests what the method was and who owned it |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our roles sit side by side under the same VP. Where's the seam between Emerging Products GTM and Sales Strategy, and what happens when we disagree?" | JD | [generic] | Propose principles rather than claiming to know the seam: "My first cut, which I'd want to check with you: Emerging Products GTM owns the hypotheses for the new lines and the whitespace analysis; Sales Strategy owns how those lines enter coverage, targets and seller plans; the seam is the hand-off and the shared data." On disagreement: agree on one dataset first, frame the choice together, and take one framed option to the VP rather than two competing ones | The canonical peer question, made sharper by I4's shared VP. JD because it tests how she would run the role next to his. `[generic]` because the seam is offered as a hypothesis, not a fact about Northwind |
| B2 | "Tell me about a time you and a peer disagreed on the numbers and had to land on one answer." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, where she held her view on the data, the answer converged, and the relationship stayed intact. If F5's volume-target consensus involved a disagreement like that, use it and describe only what happened. If no such time comes to mind, say so plainly, then give the nearest thing her material does carry, or how she would handle it | The Peer Evaluator's disagreement stem, aimed at a data-minded peer. VAL as behavioral evidence. `[generic]` because the material doesn't say a disagreement happened |
| B3 | "If Compass or the new lines need our sellers to carry them, what would you need from my team, and what would you give back?" | CO | [grounded] "No classic sales-ops or quota-setting experience" "skilled in SQL/Tableau" "built a partner-level revenue model used in carrier negotiations" | Lead with what she gives. Whitespace analysis on the installed base, done independently in SQL and Tableau, the tools her notes say she's skilled in. Partner economics, framed by her experience building a partner-level revenue model that was used in carrier negotiations. What she needs: his team's knowledge of coverage and quota mechanics, said plainly: "I haven't done classic sales-ops or quota-setting, so that's where I'd lean on you." Then seller feedback loops on the new lines | Reciprocity is what a peer scores, and Compass is a stated Northwind priority (research note). CO because it puts the launch in the frame. F7's plain acknowledgment works best said here, unprompted |
| B4 | "That $400M crossed a lot of teams. How do you handle credit on work like that?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use "we" for the context and "I" for the contribution, and the contribution her quote carries is the proposal. Answer slot: which part was hers beyond proposing it, in her own words. If the rest belonged to other teams, say so and name the teams generically. Giving credit away precisely is the signal a peer is looking for | It's the Peer Evaluator's credit probe on her biggest figure. Dan will hear how she would treat shared work with his team. EXP because it tests attribution |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **Highest-ROI.** "Your background is consumer tech, and you haven't done sales ops or quota-setting. Why should we trust you with B2B GTM for two new product lines?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "No classic sales-ops or quota-setting experience" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" | **Concede first, in one line:** "That's right: I haven't done classic sales-ops or quota-setting." **Then hold on only what the quotes carry:** nine years of product strategy and ops at a large consumer-tech company; a partner-level revenue model she built that was used in carrier negotiations; annual volume targets set with cross-org consensus. Describe what she did and let Dan draw the inference. Don't tell him what it proves. **Answer slot:** the JD's land/adopt/expand/renew line makes a B2B probe likely. If any of her consulting or product-strategy work involved selling to businesses, say which and what part was hers. If none did, say so plainly and stay with the partner model. **Ramp plan, said as a plan:** learn Northwind's sales motion from his team in the first weeks, sit in on deal reviews, build a whitespace baseline in SQL. **Follow-up 1** ("Carriers aren't enterprise buyers"): hold on what the model was, which is partner-level and used in negotiations, and don't equate the two. **Follow-up 2** ("So what would you get wrong in month one?"): name the limit before he does. Quota and sales-ops mechanics are the parts she hasn't done, and that's where she'd lean on him | Both negatives come from the material (F1's consumer-tech quote, F7's stated gap), and F4's "required" line is tied to them. A peer in sales strategy can see all three at a glance, so the question arrives in some form, perhaps collegially. JD because it scores fit against the stated role. Rehearsed deepest: two follow-ups, the concession wording, and the limit named before it's asked for |
| C2 | "The JD says partner-motion design is required. What partner motion have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold at the model: she built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: if any part of how those partnerships were structured was hers to design, say which and what she decided, in her own words. If none was, or the model fed decisions others made, say so plainly and stay with the model. Then pivot to how she would design one for Northwind, which is D4's structure, framed as an approach rather than a past | F4 is a transferability gap on a "required" line, and the question is premised on a practice the quote doesn't carry, so the slot's second branch lets the premise be false. JD because it scores the stated requirement |
| C3 | "Why leave product strategy at a big consumer company for emerging-products GTM here, and why now?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Her own reasons, in her own words; the pack supplies none. Answer slot: if part of the pull is building something new, say what, concretely. Tie "why here" to what is actually known about Northwind: enterprise expansion, the Compass launch, the push to profitability, and the threat of bundling (research note). Keep the motivation consistent with C1. Pick one reason and give it depth | A Skeptic staple. With a consumer-to-B2B move (F1) it is close to certain. JD because it tests whether her motivation fits the role, with a CO element in "why here" |
| C4 | "New lines here run scrappy: thin data, small team, no playbook. How do you work when the big-company machinery isn't there?" | JD | [generic] | Selection scaffold. Pick a time she built an answer from thin or messy data without a team behind her. It needs a real constraint, what she did herself, and a result or a lesson. If no such time comes to mind, say so plainly, then give the nearest thing her material does carry, or how she would handle it in the first month here. Don't characterize her past employer's pace. Describe what she did | I3's startup chapter makes a scrappiness probe likely, and "Emerging Products" invites it. JD because thin data is the job's actual condition. `[generic]` because no quote carries a scrappy story |

### D. Case / Strategist (pricing tilt)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A much larger platform vendor starts bundling a comparable capability at no extra cost. How do you defend one of our new product lines?" | CASE | [grounded] research note: main competitive threat is bundling by a much larger platform vendor | Clarify which line, which segments overlap, and whether the bundle is good enough for them. Objective: retention, new logos or margin. Profitability is a stated priority, so don't race to zero. Segment where the bundle wins and where depth wins, framed as hypotheses to test with data. Levers: packaging (pair with the core, tiering), pricing (value metric, not discounting), partner motion (who benefits from Northwind staying independent), proof (total cost and switching). Metrics: win rate against the bundler, churn in overlapping segments, expansion rate. Risks. Challenge one premise: is the threat uniform across segments? The case asks about no past, so the guidance claims none | It's Northwind's own stated threat, and I2's monetization lens makes it his natural case. CASE delivery, CO content |
| D2 | "How would you price and package Compass, given we're pushing toward profitability?" | CASE | [grounded] research note: AI copilot launch, Compass; reaching profitability | Clarify Compass's job first: monetize it directly, or use it to drive adoption and defend against bundling? Options: included in a tier, a paid add-on, or usage-based. Weigh the cost to serve AI features against the profitability goal, framed as something to check. Map to the lifecycle: included to drive adoption, paid tier for expansion. Metrics: attach rate, margin per account, expansion revenue. Challenge one premise. Don't assert any detail of Compass that the research note doesn't give | Two of Northwind's three priorities meet in this question, and pricing is Dan's native ground (I2). CASE, with CO content |
| D3 | "You've just taken over GTM for a new product line. Sketch your first 90 days. What do you need to know first?" | CASE | [grounded] JD highlights: "own GTM strategy for two new product lines" "identify whitespace across land/adopt/expand/renew" | Clarify the line's stage (pre-launch or early revenue) and who sells it. First 30 days: data and interviews with Sales Strategy, product and partners, and a whitespace baseline across land, adopt, expand and renew. Days 30 to 60: target segments, the motion (direct, partner or both), pricing hypotheses. Days 60 to 90: pilot, metrics, and how the line enters seller plans with Dan's team. A plan, framed as a plan | The JD's headline responsibility, made live. CASE because it scores structure. It also covers F2, the whitespace requirement, which no other bank tests in a planning frame |
| D4 | "Design a partner motion for one of the new lines: who are the partners, what's in it for them, and how would you measure it?" | CASE | [generic] | Clarify the line, the buyer and the gap a partner fills. Partner types: resellers, integrators, technology partners. For each, the value exchange: margin, influence on the deal, or product fit. Rules of engagement with direct sales, which is the seam with Dan. Metrics: partner-sourced and partner-influenced pipeline, time to first deal, partner retention. Draw on her own work only as far as F4's quote goes. The approach is presented as an approach, not as something she has done before | It turns F4's "required" line into a live case, so she has an answer beyond C2's limit. CASE delivery on JD content. `[generic]` because it's a method, not a fact about Northwind's partners |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone from our sales-ops team?" | JD | [grounded] "No classic sales-ops or quota-setting experience" "skilled in SQL/Tableau" "built a partner-level revenue model used in carrier negotiations" | Pause, then three beats. She's skilled in SQL and Tableau and does independent analysis. She built a partner-level revenue model that was used in carrier negotiations. And she brings an outside view on new lines. If pressed: "I haven't done classic sales-ops or quota-setting. Someone from your team would know that better, and I'd lean on them." Hold the three beats through two follow-ups, and concede only the F7 gap | A time-boxed form of C1. Rehearsed so the concession doesn't swallow the pitch. JD because it scores fit |
| E2 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: she proposed the change, and it was credited with roughly $400M ARR uplift. Answer slot: which part was hers beyond the proposal, in her own words. If the build and the attribution belonged to others, say so plainly. Concede that the credit was shared, and never fold on the proposal itself | The persona's attribution stem on the headline figure. Paired with A1, A2 and B4 so that four angles on one number all give the same answer. EXP |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Pick two beats from the quotes, the partner revenue model and the store-surface proposal, each in its own verbs. End on why this role, consistent with C3. Rehearse it out loud so it doesn't sprawl | Almost certainly the opener. Casual, but it's scored on economy. EXP because it sets up every later probe, so nothing in it can outrun the quotes |
| G2 | "What are you actually doing with AI tools these days?" | JD | [grounded] "uses AI tools daily" | Story-mapped on F6: she uses AI tools every day. Answer slot: what she uses them for, concretely, in her own words. If one use touches analysis or GTM work, lead with it. If none touched an AI product's strategy or launch, say so plainly. Connect it to Compass only as a question: "I'd want to understand how sellers are positioning Compass" | The JD's "plus" item, asked casually, and Compass makes it live. JD because the AI line is a stated preference |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. It needs a named stake, the hard message, how she delivered it, and whether it landed. "We" for context, "I" for her part. If no such time comes to mind, say so plainly, then give the nearest thing her material does carry, or how she would handle it | A persona stem, and a peer sharing a VP may ask how she manages up. VAL as behavioral. `[generic]` because Northwind's values weren't fetched and no quote carries such a story |
| H2 | "Tell me about getting a decision through when you didn't have authority over the people involved." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: annual volume targets, set with cross-org consensus. Answer slot: the JD's influence line makes a probe likely on how the consensus was reached. If there was resistance, say what it was and what she did. If there wasn't, say so plainly and describe how the targets were agreed. If a better story comes to mind, use it on the same terms | The JD names "strong cross-functional influence", and F5 is her one direct quote on it. VAL delivery, with JD content as the secondary tag |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could someone in my seat do in the first month that would genuinely help your team?" | A reciprocity question for a peer. It shows she's thinking about adding to his load, not taking from it |
| R2 | "From the pricing side, how do you think about Compass: monetize it directly, or use it to defend the core against bundling?" | It's tied to his pricing and monetization path (I2) and two of Northwind's stated priorities. It invites him to teach, which turns the interview into a peer conversation |
| R3 | "You've worked early-stage too. What from that do you find yourself using on new products at a company this size?" | It's tied to his startup chapter (I3). It also tells her what scrappiness means here |
| R4 | "Which two product lines does this role cover, and where is each one, pre-launch or early revenue?" | The notes don't name them. The answer changes how she would frame D3 if it comes up later in the conversation |
| R5 | "Where does Sales Strategy's work stop and Emerging Products GTM start today, and where has that been messy?" | It surfaces the real seam behind B1 and shows she's thinking about it before day one |
| R6 | "What data would I be working from for whitespace? Is there a clean installed-base view, or is building it part of the job?" | It speaks to his data-driven self-description (I1) and tests the "independent analysis" line |
| R7 | "How will our VP judge whether the two of us are working well together: shared metrics or separate ones?" | It frames the relationship as a partnership under the same VP |

---

## Prohibited claims

What this pack won't coach, and why. It was built before the banks were written, so the banks are written to respect it.

| Not coached | Basis | Honest form |
|---|---|---|
| Led, built or drove the store-surface change or the $400M | Inflated form of F1 | F1's quote at its own scope: she proposed the change, and it was credited with a ~$400M ARR uplift. The limit is the pack's observation, not words for her: the material says *proposed* and *credited*. The slots in A1, A2, B4 and E2 stay inside "which part was yours" |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope: a partner-level revenue model she built, used in carrier negotiations. The C2 slot asks only whether any part of how those partnerships were structured was hers |
| Negotiated the carrier deals | Inflated form of F4 | The quote says the model was used in negotiations, not that she was at the table. Stay with the model |
| Owned GTM strategy for product lines | Inflated form of F1 | F1's quote: product strategy & ops at a large consumer-tech company. The C1 and G1 slots stay inside that |
| Has done quota-setting or sales ops, or presenting the volume targets as quotas | Negative stated in the notes, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting." No slot |
| Has built or launched AI products | Inflated form of F6 | F6's quote: she uses AI tools every day. The G2 slot asks only what she uses them for |

B2B or enterprise experience isn't on this list because her material is silent on it, not inflated. It's handled as an answer slot in C1.

---

## Sources

**Provided documents:** the coach's message, covering the role and JD highlights, the summary of Priya's background, the summary of Dan Kovac's profile, and the research note on Northwind's priorities and competitive threat.

**Searches sent:**
- `Northwind Data company values`: refused (permission not granted)
- `Northwind Data interview process GTM strategy`: refused (permission not granted)
- `"Dan Kovac" Northwind Data sales strategy`: refused (permission not granted)

No dossier was provided.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have supplied Northwind's published value names to theme H1 and H2, which stay `[generic]`. No values round is documented for this session, so no cheat sheet would have run either way |
| 2. `Northwind Data interview process GTM strategy` | unavailable | The search was refused. The coach's description already sets this session (one 60-minute conversation with Dan), so the persona weights don't depend on it. It would have shown whether the wider loop contains a values or case round |
| 3. `Northwind Data strategy` / recent news | skipped | The coach's research note already supplies the three priorities and the bundling threat that D1, D2, B3 and C3 draw on |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have supplied his public talks or posts, giving likely question themes and a sharper reverse question. The interviewer read rests only on the coach's summary |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied in the coach's notes fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text →** exact requirement quotes, plus JD questions for mid-list items (named tools, methods, metrics) that the highlights may have dropped.
- **Priya's CV →** F1 to F7 quote her own lines instead of the coach's summary, and H1, B2 and C4 can become stories mapped to her material instead of selection scaffolds.
- **Priya's own answers to the slots →** how the ~$400M was counted and what was hers (A1, A2, B4, E2, G1), any part of the carrier partnerships she designed (fit row F4, C2), and any B2B exposure (C1, fit row F2) would replace slots with quoted evidence.
- **Permission for web search →** Northwind's published values (to theme the VAL questions), its loop structure, and Dan's public talks or posts (for interviewer themes and a sharper R2 or R3).
- **A deeper research pass, if search is enabled →** up to 6 more searches and 2 more fetches, taking several more minutes. It adds a grounding brief: Northwind's segmentation language, recent moves, and the bundling competitor, to sharpen D1 and D2.
- **Recruiter guidance →** whether Dan's session has a stated focus or an expected deliverable (a POV, a case), which would add a build section for it.
- **Prep time available →** a prioritized prep schedule sized to the hours Priya actually has.
- **A tuesday-dossier.md from an earlier job evaluation →** verified evidence and a prohibited-claims list confirmed by Priya, so C1's objection would come from evidence rather than inference.
