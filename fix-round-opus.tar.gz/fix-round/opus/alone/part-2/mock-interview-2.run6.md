Web search was refused, so I'm building the prep pack from what you gave me and writing the file now.
I've built a full prep pack from the job description and background you gave me, with 22 practice questions, each with answer guidance. I couldn't look up Atlas Freight: the web searches I tried were refused permission. So nothing in the pack is based on their published values, how they run interviews, or recent news, and anything about the company itself is labeled general-pattern.

Since I don't know who you're meeting, every interviewer style gets equal weight. That's weaker than tuning it to one person.

Things to know before you rehearse:

- **The question you'll most likely face (B1):** "You lead 3 supervisors today; this job has 12 across four sites." Say the limit yourself before they do. Then point to the site's peak-season surge plan you ran, and finish with a plan for how you'd ramp up. The pack scripts two likely follow-ups.
- **The 5+ years requirement (B4):** your background says 7 years in operations, not 7 years leading people. Count your actual leadership years by title before the interview, and say the real number.
- **Power BI:** say plainly that you haven't used it, mention your solid Excel, and give a learning plan you'd commit to.
- **The 40% mis-pick result:** expect "how was that counted?" and "how much of it was actually you?" Have the honest answer ready, including "I don't know exactly" if that's true.
- **On-time and cost-per-shipment:** nothing you told me shows a number you tracked for either. The pack doesn't make those links for you, and it has a list of other overstated claims it won't coach.

The pack's final section lists what extra information you could give me, such as the interviewer's name or anything the recruiter said, and how each would sharpen it.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-2-denied-79da1646:
- atlas-freight_operations-manager_interview_pack.md

If you like, I'll play the skeptical interviewer on B1 and push back on your answers live.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I can convert it.

Who are you meeting: your future manager, the recruiter, a panel, or someone else? And did the recruiter mention any focus areas or anything to prepare? The answer changes how every question is weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack — Operations Manager, Atlas Freight

Regional logistics, 800 employees. Interviewer and round type not known, so this is a full-loop pack with flat persona weights. That is noticeably weaker than a pack tuned to the person you're meeting, and the upgrade menu at the end says what would fix it.

## How to use this pack

- **Personas** are how a question gets asked: the style, the pressure, the follow-ups. **Types** are what the answer is scored on. Rehearse both.
- Type key:
  - **VAL**: behavioral and values. Does your past behavior show what they value?
  - **EXP**: experience deep-dive. Do the claims in your background hold up, and what was actually you?
  - **JD**: role-driven. Can you do the job as listed, including the parts you haven't done?
  - **CO**: company knowledge. Have you done your homework on Atlas Freight?
  - **CASE**: live problem. How do you structure and reason through a problem from the job?
- Provenance labels: `[grounded]` traces to what you told me or the JD text you pasted. `[inferred]` is this pack's derivation, with the reasoning named. `[generic]` is a role-family pattern that says nothing specific about Atlas Freight.
- **Guidance is scaffolding, not a script.** Every claim about your past is quoted from your message. If a suggested line says more than you did, cut it.
- Question IDs use letters A to E and G to H. **F is reserved for fit-snapshot rows**, so F1 always means a fit row and never a question.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution work at one site. It does not mention terminal operations or more than one site. Keep the words at their own scope: "I've had seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's terminal and four-site line makes a probe likely. If any of your work was terminal operations or covered more than one site, say what it was and which part was yours, in your own words. If none was, say so plainly and stay with the site you ran |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Your material shows no on-time figure, and a surge plan is not the same thing as an on-time result. Answer slot: if your shift or the surge plan tracked on-time or service levels, say what was tracked and what moved, in your own words. If nothing was tracked that way, say so plainly and say what you would measure first |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | An accuracy result is not a cost-per-shipment result, so don't stretch this bridge. Answer slot: if you tracked or were accountable for any cost figure, say which one and what you did with it, in your own words. If you weren't, say so plainly and say how you would learn what drives cost-per-shipment here |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows 3 supervisors, not 12. The words stay there: "Today I'm a senior shift manager over 3 supervisors." Answer slot: if you have led more than three supervisors at any point, say when and how many. If you haven't, say so plainly and stay with the three |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a self-rating and doesn't show reports you built. Answer slot: if you have built reports in Excel that other people used, say which ones and who read them, in your own words. If you haven't, say so plainly and describe what you do use Excel for |
| F6 | "build reporting in ... Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | You stated this gap yourself, and no wording closes it. Words: "I haven't used Power BI." Then describe how you would learn it, framed as a plan and never as past experience. Don't claim any Power BI work, and don't add anything to make the gap sound smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Your material gives seven years in ops and your current title. It doesn't say how many of those years were in a leadership role. Because the posting says "required", expect the count to be checked literally. Answer slot: count your leadership years in your own words, naming the titles. If the count is under five, say the real number plainly and lead with what you run today |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. It's a self-reported credential with nothing inspected behind it, so expect a probe on where you have applied it. Name the certification in its own terms, a Six Sigma green belt, and let the follow-up questions (C2, G2) carry the rest |

## Persona table

No loop source establishes how Atlas Freight runs this interview: you didn't say, and the research that might have shown it was refused. So the weights below fall back to the **generic archetype (screen → hiring manager → panel), with flat weights**. They rest on a pattern, not on this company's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | "Here's a problem at one of our terminals — what do you do?" | Flat. Likely in any hiring-manager round for a role that owns on-time and cost targets (F2, F3) | Clarify, then objective, segment, approach, metrics, risks. Think aloud. Ask how they define the metric before you try to move it |
| B. Skeptic | Quiet, persistent probing of the span-of-control and terminal gaps | Flat, but it holds the pack's highest-ROI question (B1), because the F1 and F4 gaps are visible from your background alone | Rehearse B1 until it's boring. Bridge only from what you said, name the limit before they do, then give a concrete ramp plan |
| C. Data-Driven Prober | "How was that 40% counted?" | Flat. Your one headline number (F3's quote) is exactly the kind of thing a prober targets | Know what you can and can't say about how the figure was counted. Name your weakest assumption first. Say "I don't know" where you don't |
| D. Pressure | Interrupts, time-boxes, asks "how much was actually you?" | Flat. Common in ops-leadership loops where composure is part of the job | Pause, restate the question, anchor in what you actually did, hold through two follow-ups, then concede specifically |
| E. Values / Behavioral | "Tell me about a time…" | Flat. No published Atlas Freight values were read, so these questions are themed by the JD and generic stems, not by company values | Pick real stories with a named stake. Use "we" for context and "I" for your part. Where you have no such story, say so |
| G. Conversational | "So, walk me through your journey" | Flat. Usually the opener in every round, and still scored | Have a 90-second arc ready. Treat casual questions about Lean/Six Sigma (a JD plus) as scored |
| H. Peer Evaluator | Another site lead asking how you'd work across sites | Flat. Likely if a panel includes managers from the other terminals | Lead with what you'd bring them, not only what you'd need. Propose working principles rather than pretending to know their site |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of our four terminals dropped this month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is measured here, when the drop started, whether it's one terminal or the trend everywhere, and which customers or lanes it hits. Then segment: inbound against outbound, by shift, by dock or carrier. Form two or three hypotheses, name the data you'd pull for each, and separate same-week containment from root cause. Close with how you'd report it upward. The question makes no claim about your past, so the guidance makes none | The JD's on-time mandate (F2's requirement) set as a live problem. CASE because it scores structure. `[generic]` because it's a diagnostic pattern, not a fact about Atlas Freight |
| A2 | "Your first 90 days: how would you bring cost-per-shipment down across four sites?" | CASE | [generic] | Start by asking what cost-per-shipment includes here and what the baseline is at each site. Spend the first stretch listening and measuring before cutting anything. Then segment the cost into its drivers per site, pick one or two where the sites differ most, and pilot at one site before rolling out. Name the risk out loud: a cost cut that damages on-time is not a win. The guidance makes no claim about your past | F3 is the thinnest-evidenced mandate, so a forward-looking plan is your strongest ground here. CASE delivery, JD content |
| A3 | "Build me the weekly report you'd want on your desk for four terminals. What's on it, and what would you build it in?" | JD | [grounded] "solid Excel" "never used Power BI" | Content first: the few metrics you'd run the network on, the same definitions at every site, trend against target, and an owner for each line. On the tool, be straight: you have solid Excel, and "I haven't used Power BI." Describe how you'd learn it, framed as a plan, for example starting from the Excel version and moving it over. Answer slot: if you have built reports in Excel that other people used, say which ones in your own words. If you haven't, say so plainly and describe what you do use Excel for | Covers the reporting requirement (F5, F6) in the form the job uses it. JD-tagged because it scores a stated responsibility, with CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're over three supervisors today. This role has twelve, across four terminals. Why should I believe you can make that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | **The highest-ROI rehearsal in this pack.** Name the limit before they do: "Today I'm a senior shift manager over 3 supervisors. Twelve across four sites is a bigger span than I run now." Then the strongest thing your material carries, at its own scope: "I ran the site's peak-season surge plan two years running." Answer slot: if you have led more than three supervisors at any point, or worked across more than one site, say when and what part was yours. If not, say so plainly and stay with what you run. Then the ramp plan, framed as a plan: how you'd learn four sites and twelve supervisors in your first months. Follow-up 1, "Surge is temporary": hold, don't add to the surge story. Follow-up 2, "So you've never managed managers at this scale?": concede the scale plainly, then return to the ramp plan. Never fold on what you did run | F4 and F1 are the gaps visible from your title alone, so this objection will come in some form. JD because it scores the stated span of control. It gets the deepest rehearsal, two follow-ups deep, because a rehearsed, non-defensive answer here changes the interview |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" "solid Excel" | Pick a real one, not a humble-brag. Power BI is the honest pick: "I haven't used Power BI." Add that you have solid Excel, then a specific learning plan framed as a plan. Stop there. Don't volunteer a second weakness to look candid | F6 is a gap you stated yourself, so it's the cleanest honest answer. JD because it asks about the listed requirements directly |
| B3 | "Your background is warehouse and distribution. How is a freight terminal different, and how would you close that gap?" | JD | [grounded] "7 years in warehouse and distribution ops" | Hold on your scope: seven years in warehouse and distribution ops. Don't claim terminal experience. Answer slot: if any of your work was terminal operations or close to it, say what, in your own words. If none was, say so plainly. Then, as a plan: what you would want to learn first on the terminal floor and from whom | F1's transferability gap, asked head-on. JD because "terminal operations" is the role's first line |
| B4 | "The posting asks for five-plus years of operations leadership. How many of your seven years were in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Answer slot: give the count in your own words, naming each title and roughly when. If the count is under five, say the real number plainly and lead with what you run today. Don't round "seven years in ops" up into seven years of leadership | F7: the posting says "required", so this is likely checked literally. JD because it scores a stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-picks 40%. How was that counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend the number in your own words, covering four things. **How it was counted**: what the rate was measured against, and over what periods. **What it's sensitive to**: what else changed at the same time. **The assumption you'd defend least**: name it before they ask. **Which part was yours.** If you don't know how the figure was counted, say "I don't know exactly how it was counted," which is better than an explanation you can't repeat under a second question. The pack supplies none of these for you | Your one headline figure, and the first thing a prober reaches for. EXP because it tests whether the claim survives scrutiny |
| C2 | "Walk me through the pick-path redesign itself." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" "green belt certified" | Stay with the beats your sentence states: the pick path was redesigned, and the mis-pick rate fell 40%. Tell it in your own words. Answer slot: the JD's Lean/Six Sigma line makes a probe likely. If you used green belt methods on this project, say which ones and how, in your own words. If you didn't, say so plainly and describe what you changed | Connects the headline result to F8 without assuming the link. EXP because it tests what you actually did |
| C3 | "How would you make on-time numbers comparable across four sites?" | CASE | [generic] | Same definition everywhere: what counts as on time, which timestamp is the source of truth, and what's excluded and who decides. Audit a sample at each site before trusting the roll-up. Show trend and distribution, not only the average. The guidance makes no claim about your past | A prober's favorite move is "how do you know the number's right". JD content (F2), CASE delivery. `[generic]` because it's a measurement pattern |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, then hold: the result came from redesigning the pick path. Answer slot: say exactly which part was yours and who else was involved, in your own words. If it was a team effort, say "we" for the team and "I" for your part. Concede specifically, never vaguely, and don't fold to "it was really the team" if it wasn't | D1 pressures the same claim C1 probes, in a hostile register. Rehearse both, because the honest answer has to survive either tone |
| D2 | "Sixty seconds: why you over an internal supervisor who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" "ran the site's peak-season surge plan two years running" "cut mis-pick rate 40% by redesigning the pick path" | Time-box it to about 60 seconds. Concede up front that they'd know the terminals better than you on day one. Then three facts at their own scope: seven years in warehouse and distribution ops, running the site's peak-season surge plan two years running, and cutting the mis-pick rate 40% by redesigning the pick path. Close with what an outside view brings to four sites, framed as what you'd do, not as a claim about them | Tests composure and economy. JD because it compares you against the role's requirements. It draws on F1, F3 and F4 without stretching any of them |
| D3 | "You've never used Power BI, and this job builds reporting in it. Isn't that a problem?" | JD | [grounded] "never used Power BI" "solid Excel" | Hold, don't apologize: "I haven't used Power BI. I have solid Excel." Concede that it's a real ramp, then give the plan with a timeline you'd commit to. Answer slot: if you've built Excel reports other people used, name one in your own words. If not, say so plainly and stay with the plan. Two follow-ups: hold the plan, don't inflate the Excel | F6 under pressure. Your own words supply the negative, so the interviewer can fairly state it |

### E. Values / Behavioral

No Atlas Freight values were read, so these questions are themed by the JD and generic stems.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supervisor on your team was underperforming. What did you do?" | VAL | [generic] | Pick a real case. It needs a named problem, what you did first, a conversation you actually had, and an outcome, good or bad. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's "lead a team of 12 supervisors" (F4) makes supervisor-performance stories likely. VAL because it scores how you behave, not what you know |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a real stake, a moment you didn't soften the message, and a relationship still intact afterward. "We" for context, "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem. Ops managers routinely carry bad news on service and cost upward |
| E3 | "Tell me about a time you had to choose between a cost target and a service commitment." | VAL | [generic] | Pick a real trade-off: what was at stake on each side, what you decided and why, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD sets on-time and cost-per-shipment side by side (F2, F3), and they pull against each other. VAL delivery, JD theme |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc built only from these: seven years in warehouse and distribution ops; senior shift manager over 3 supervisors today; the mis-pick rate cut 40% by redesigning the pick path; the site's peak-season surge plan, two years running; green belt certified. End on why this role is the next step, in your own words. Don't add titles or dates you haven't confirmed | The opener in almost every round, and it sets the frame for everything after. EXP because it's your background, asked casually |
| G2 | "So what are you actually doing with Lean and Six Sigma these days?" | JD | [grounded] "green belt certified" | Name the credential: Six Sigma green belt. Answer slot: if you have applied it to a project, say which one and what you did, in your own words. If you haven't, say so plainly and say where you would apply it first here | F8 is a JD plus, and casual questions about a plus are still scored. JD-tagged for that reason |
| G3 | "Why Atlas Freight, and why now?" | CO | [generic] | Your motivation in your own words: why regional logistics, why multi-site, why now. **Don't state facts about Atlas Freight you haven't checked yourself.** This pack couldn't research the company, so read their own site before the interview and use only what you've read there | Asked in nearly every loop. CO because it tests homework. `[generic]` because no company research reached this pack |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Four sites means four sets of habits. How do you handle disagreeing with another site's lead about how something should be done?" | CASE | [generic] | Propose principles, not a verdict: agree on the metric first, pilot the disputed approach at one site, let the data settle it, and escalate only what the data can't. Show spine and tact together. The guidance makes no claim about your past | Four-site ownership (F1's requirement) puts you between sites. CASE because it asks how you would act, not what you did |
| H2 | "What would you need from the other site leads in your first month, and what would you bring them?" | JD | [grounded] "ran the site's peak-season surge plan two years running" "green belt certified" | Reciprocity first, what you'd bring: you ran the site's peak-season surge plan two years running and you're green belt certified, so offer to compare surge planning and improvement methods. Then what you'd need: their read on each site's constraints and their people. Keep the offer at the scope of what you did | Peers price what a new hire adds to their load. JD because it touches multi-site ownership |
| H3 | "When an improvement spans shifts or teams, how do you handle credit?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use the pick-path result as the example. Answer slot: say who else was involved and how you credited them, in your own words. If it was yours alone, say so plainly, and say how you'd handle shared credit in a four-site role | A collegial version of D1's attribution probe. EXP because it tests what was actually yours |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites (F1) | B1, B3, H1, H2 |
| Drive on-time performance (F2) | A1, C3, E3 |
| Cost-per-shipment down (F3) | A2, E3 |
| Lead a team of 12 supervisors (F4) | B1, E1 |
| Build reporting in Excel/Power BI (F5, F6) | A3, B2, D3 |
| 5+ years operations leadership required (F7) | B4 |
| Lean/Six Sigma a plus (F8) | C2, G2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is on-time performance measured here, and where does each terminal sit against target today?" | Shows you start from the definition and the baseline, which is the habit the job needs |
| "What's included in cost-per-shipment in your numbers, and which site is hardest to move?" | Signals you won't chase a number you don't understand. The answer also tells you where the real problem is |
| "Of the twelve supervisors, where is the team strongest and where is it thinnest right now?" | Shows you're already thinking about the people side of the span, which is your biggest gap (F4) |
| "What reporting exists today? Is there a Power BI setup already, and who maintains it?" | Turns your Power BI gap (F6) into a practical onboarding question instead of a weakness |
| "A year from now, what would make you say this hire worked?" | Gets their success criteria in their words, which is useful for the rest of the interview |
| "How is time split between the four sites? Is there a home terminal?" | A practical question that shows you've pictured the actual job |

## Prohibited claims

What this pack will not coach, and why. These are the inflated versions a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Seven years of operations leadership | Inflated form of F7 ("7 years in warehouse and distribution ops") | F7's quote at its own scope. The pack's observation: your material gives seven years in ops, not seven years in leadership. B4's slot asks only for the real count |
| Has led a team of 12 supervisors, or managed multiple sites | Inflated form of F4 and F1 | "Currently a senior shift manager over 3 supervisors" at its own scope. The pack's observation: your material shows 3 supervisors and "the site's" surge plan, one site. B1's slot stays inside what you have run |
| Has run terminal operations | Inflated form of F1 | "7 years in warehouse and distribution ops" at its own scope. Warehouse and distribution is a different kind of operation from a freight terminal. B3's slot covers this |
| Drove on-time performance or cut cost-per-shipment through the pick-path work | Inflated form of F3's quote. The quote states an accuracy result | "Cut mis-pick rate 40% by redesigning the pick path", no more. F2's and F3's slots ask what you actually tracked |
| Designed or built the surge plan | Inflated form of F1's quote ("ran") | "Ran the site's peak-season surge plan two years running": ran, not built or designed |
| Has used Power BI or built Power BI reports | A negative you stated, F6 | "I haven't used Power BI." No slot |
| Black belt, or led a Lean program | Inflated form of F8 | "Green belt certified" at its own scope. C2's and G2's slots ask where you've applied it |

## Sources

- **Provided:** your message, including the JD text you pasted and your background.
- **Searches sent, all refused** (permission not granted):
  - `"Atlas Freight" regional logistics company values`: refused
  - `"Atlas Freight" interview process operations manager`: refused
  - `"Atlas Freight" terminals news 2026`: refused
- No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have supplied official value names for E-bank themes and, if a values-style round turned up, a values cheat sheet |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have supplied the loop structure. Persona weights stay flat on the generic archetype instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have grounded G3 and added CO and CASE questions on Atlas Freight's current priorities. Those stay `[generic]` |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD text you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and your relationship to the interviewer (future manager, peer, skip-level, recruiter, panel) → reweights every bank from flat. For a hiring-manager round, the Case and Skeptic banks would grow to 4–5 questions each
- Interviewer's name → their public professional footprint, an interviewer read, personas tuned to them, and a reverse question tied to their career path
- Anything the recruiter told you (focus areas, a presentation or case to prepare, the schedule) → coverage of any graded deliverable, and per-round mini-packs if there are several sessions
- Allowing web search → Atlas Freight's published values, loop structure and recent news. Rows 1–3 of the target accounting would run, G3 would become grounded, and the pack would get CO questions on their actual priorities
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief and recent org context
- Your answers to the slots in F2, F3, F5 and F7 (what you tracked on on-time and cost, which Excel reports others used, your leadership-year count) → those rows move off `discovery` and the related questions become story-mapped
- Your green belt certificate → raises F8 from medium to high, since a certificate is the inspectable proof for that line
- How much prep time you have → a prioritized prep schedule
- A tuesday-dossier.md from the job-underwriter skill → evidence-graded objections and an underwriter-checked list of claims to avoid, in place of this pack's locally built one
