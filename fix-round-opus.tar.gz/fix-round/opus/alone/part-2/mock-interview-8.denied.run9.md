Quick note: the pack is drafted. I'm fixing a clash where question IDs reused the fit-snapshot labels, then I'll hand it over.
Dara, I've saved your prep pack as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. It has a separate section for each of the three rounds on 21 November, set up the way the recruiter's email describes them. I didn't run any web searches, because what you pasted already covered Ashgrove's values, the round structure, its strategy and the job description.

- **Prepare this question first.** The Head of Member Services is likely to ask some version of: "You've handled one branch's complaints log and never worked in a contact centre. Why should I trust you to own the whole process?" The pack goes deepest on this one (question C1). It shows you how to say the limit before they do, stick to what you've actually done, and then give a plan for the gaps.
- **The panel case.** The 20-minute complaint-escalation case has its own section: a structure you can say out loud, timings, and three positions you can defend, each with a trade-off you admit. Because the same panel scores you against the four values, the structure shows you where each value fits into your decisions.
- **Your two gaps.** You told me you've never worked in a contact centre and never presented above regional level. The pack gives you those gaps back in your own plain words, followed by a plan. It doesn't try to make them sound smaller.
- **Story prompts instead of ready-made stories.** For the four values, and for questions like what your spreadsheet tracks or whether your complaints were regulated, you didn't tell me enough to write the story for you. So the pack gives you a guide for choosing a story, plus an honest "if not, say so" option.
- **Check one thing early.** I don't know which complaints regulator Ashgrove works under, so the pack doesn't quote any deadlines. One of the round 1 questions for the recruiter asks about it.

If you'd like a practice run, I can play the sceptical Head of Member Services on C1, with follow-ups that react to what you actually say. I can also save a `tuesday-dossier.md` that records the gaps this prep turned up, so you can carry them into later sessions. And if you want the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of interviews:** 21 November 2026, three rounds on one day (loop mode)
**Round 1:** 30 minutes with the recruiter
**Round 2:** 45 minutes with the Head of Member Services, your would-be manager, "mostly behavioural"
**Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation. This is also the values round, scored against the four values
**Interviewer names:** not assigned yet

---

## How to use this pack

Two ideas organise everything here.

- **Personas** describe *how* a question is asked: the friendly recruiter, the sceptical manager, the branch manager who works next to the role.
- **Types** describe *what* is being scored.

| Tag | What it scores |
|---|---|
| VAL | Whether what you have done shows Ashgrove's four published values, by name |
| EXP | Whether what you say about your past holds up under follow-up, and how much of it was you |
| JD | Whether you can do the job as written, gaps included |
| CO | Whether you know where Ashgrove is going: digital, hubs, small-business lending, app-only competitors |
| CASE | How you structure a live problem from the role |

**Provenance labels.** `[grounded]` means the row comes from something you or Ashgrove provided. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a common pattern for this kind of role, useful to rehearse but not a fact about Ashgrove.

**Answer slots.** Where your message doesn't say whether you did something the role asks about, the guidance gives you an *answer slot* instead of words. It has two honest branches: say what you did, in your own words, or say plainly that it wasn't yours or never happened. Both are good answers. The answer that loses is one you can't back up when they follow up.

**Guidance is scaffolding, not a script.** Every claim about your past in this pack rests on one of six sentences from your message, quoted in the fit snapshot. If the pack ever seems to say more than those sentences, trust the sentences.

Question IDs: A and B are round 1; C, D, E and P are round 2; G to J are round 3. Fit-snapshot rows are F1 to F9.

---

## Fit snapshot

Shared by all three rounds. Every question bank draws on it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material describes one branch's log, not a process across branches, so the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If parts of it were yours, such as looking into a complaint, deciding the outcome or replying to the member, say which ones, in your own words. If the log was a record you kept while others decided, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | No wording closes this gap, and you have already said so. Words: "I haven't worked in a contact centre." Then say how you would learn it, framed as a plan and never as past experience. Don't add anything to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The spreadsheet is monthly and covers complaints. Your message doesn't say what it counts. Answer slot: expect "what's in it?" If it tracks volumes, resolution times or both, say which, and how a figure gets into it, in your own words. If it tracks something else, say what, plainly. Keep "our regional manager uses" exactly as it is: *uses*, not "reports from" or "presents to leadership" |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your message says "spreadsheet" but not which tool. Answer slot: if it's built in Excel, say so and name a feature you actually used in it. If it's another tool, name that tool plainly |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | You trained new tellers, not supervisors, and you trained them on a script. Coaching people through judgment calls is a different thing. Words at their own scope: "I trained new tellers on our escalation script." Keep it "our" script: your message doesn't say you wrote it. Answer slot: the JD's coaching line makes a follow-up about a real escalation likely. If you remember a time a teller you trained had to use the script, tell it. If you don't, say so and describe how you trained them, in your own words |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't mention digital channels. Answer slot: if you have had any part in an app, online banking or self-service change, say what your part was, in your own words. If you haven't, say so plainly, then describe how you would start working with a digital team, framed as a plan |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. Say it in your own sentence's terms: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer match that to "customer operations" rather than describing your past in the JD's words |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | "Formal" and "regulated" are different words, and your material doesn't say which rules the log came under. That is the derivation behind `[inferred]`. Answer slot: if those complaints came under a regulator's rules, say which rules and which part of meeting them was yours, in your own words. If you don't know, or they didn't, say so plainly and stay with the log you handled |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Answer slot: your sentence doesn't say whether you have presented *at* regional level. If you have, say what you presented and to whom. If you haven't, say so plainly. Then describe how you would prepare to present to senior leaders, framed as a plan |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches | A1, C1, H1, G4 |
| ...and the contact centre | B1, C1, C2 |
| Report monthly on volumes and resolution times | A4, E2, P1 |
| Coach branch supervisors on escalations | C4, H2, I1, J1 |
| Work with digital teams on self-service journeys | E1, A3 |
| Confident presenting to senior leaders | C2, C3 |
| 4+ years in financial-services customer operations | B2 |
| Experience handling regulated complaints | B3, P2, H1 |
| Comfortable with Excel reporting | A5, P1 |

---

## Graded deliverable: the panel's 20-minute complaint-escalation case

The recruiter's email named this in advance ("a 20-minute case on a complaint escalation"), so expect it to be scored. The same panel also scores you "against the four values", so treat the case as a values exercise as well.

**Facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| The case runs for 20 minutes, inside a 60-minute panel of two branch managers | Recruiter's email | [grounded] |
| The panel scores against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Recruiter's email and the values page text you pasted | [grounded] |
| Eight branches are being consolidated into five hubs over 2027, and the panel members are branch managers | Strategy brief (July 2026), recruiter's email | [grounded] |
| F1: "I handled the branch's formal complaints log" | Your message | [grounded] |
| F5: "trained new tellers on our escalation script" | Your message | [grounded] |
| Which regulator's complaint rules apply to Ashgrove | Not established | Upgrade menu. Don't quote a deadline you haven't confirmed |

**A structure you can say out loud.** Spend about 2 minutes clarifying, 12 walking through, 3 on risks and trade-offs and 3 taking questions.

1. **Clarify** (Members First). Ask who the member is, what they've lost or how they've been harmed, what has happened so far, and what they want. Ask whether there is a deadline or any vulnerability involved.
2. **Contain** (Members First, Own the Fix). Say who will contact the member, by when, and what that person can promise right now and what they can't. Say who holds the complaint from here.
3. **Investigate.** List the facts you need, where they are held, and who you would ask: the branch, the log, any contact-centre notes.
4. **Decide and explain** (Plain Words). Give the outcome, and say how you would write it so the member doesn't need it explained twice.
5. **Record.** Say what goes in the log, plus any regulatory step. Say "whatever the regulator's rules require" rather than naming a rule you haven't confirmed.
6. **Fix the cause** (Own the Fix, Neighbours, Not Numbers). Ask whether this is a one-off or a pattern. Say what changes, and who owns the change until it's done.
7. **Coach.** Say what the branch supervisor takes away from this, framed as a coaching conversation rather than blame.
8. **Report.** Say where this shows up in the monthly complaint numbers.

**Three positions you can defend, each with its concession**

| Position | The concession you say out loud |
|---|---|
| A complaint isn't fixed until its cause is fixed (Own the Fix) | Root-cause work competes with clearing the queue. Prioritise it by how much harm members suffer, not by how many complaints there are |
| The outcome letter should never need a second explanation (Plain Words) | Regulated letters may need required wording. Plain words go around that wording, not in place of it |
| Fix it at the first point of contact where you safely can, and treat escalation as a signal to learn from | Some complaints need to be escalated for independence or regulatory reasons. Pushing everything back to branches can pressure staff into settling complaints too cheaply |

**How to stand out.** Most candidates will list process steps. You stand out by naming the value where it shapes the decision: say "this is where Plain Words bites" at step 4, not as a slogan at the end. Then close on two things, what changes for the member and what the supervisor learns.

**What not to do:**

- Don't promise the member an outcome before you have the facts.
- Don't blame branch staff in front of two branch managers.
- Don't present your own branch's practice as Ashgrove's.

**Close.** The recruiter didn't name one. End on the member's outcome and what stops the problem happening again.

**Your history inside the case.** Only the F1 and F5 sentences, and only at their own scope: "I handled the branch's formal complaints log" and "I trained new tellers on our escalation script". If the panel asks "have you done this?", F1's answer slot applies.

---

## Grounding brief

These are the strategy brief's points, so you sound current. Learn the vocabulary. Don't recite it back to them.

| Point | Brief's wording, as you gave it | Where it comes up | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | E1, A3. Complaints will start coming from digital journeys | [grounded] |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | I2, the case. Your panel are branch managers living through this | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" | A new product brings new complaint types. This makes a good reverse question | [grounded] |
| Competition | "the main competitive pressure is app-only banks" | A3. Complaint handling as a reason members stay | [grounded] |
| Consolidation and the values pull in different directions | Reading of the brief beside "Neighbours, Not Numbers — every branch is part of its town" | I2, G3. Acknowledge the tension. Don't pretend to know how they will resolve it | [inferred] |

---

## Round 1: Recruiter, 30 minutes

**Personas**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, "why us", logistics | High. The usual pattern for a recruiter screen, and this one is short | Have a 90-second arc ready, built only from F7, F1 and F3. Treat every casual question as scored. Have your notice period and salary range ready |
| Skeptic, light | Checks on must-haves: contact centre, years, regulated complaints, Excel | Medium. Recruiters screen against the JD's requirements list | Say the plain sentences from F2 and F7 calmly. A calm, plain answer to a knockout question passes. Bluffing doesn't |

**Bank A: Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with three beats, each at its own scope: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log, which you handled; the monthly complaints spreadsheet, which you built and your regional manager uses. End by linking to why this role (A2). Say "handled", not "managed" or "ran" | Almost certain to open the call. EXP because the recruiter will use it to check F7, F1 and F3 against the JD |
| A2 | "Why this role, and why Ashgrove?" | VAL | [grounded] | Give your own reason. It lands when it names something specific you actually read: a value by name, or "member-owned" from the JD. General praise doesn't land. Don't explain the move as escaping your current job | Motivation is checked in every round, so set the version you will repeat later. VAL because it is the first chance to name a value |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name two points from the brief in its own words, such as "40% of member service to digital channels by 2028" and "eight branches into five hubs over 2027". Link them to complaints with a question rather than a claim, for example "I'd want to know how complaints from digital journeys are tracked". If app-only banks come up, the point to make is that handling complaints well is a reason members stay. Say it as your view, not as Ashgrove's | Recruiters check homework. CO because it tests the brief, and the grounding brief gives you the vocabulary |
| A4 | "Tell me about the complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Describe it in your sentence's terms: monthly, complaints, built by you, used by your regional manager. Answer slot: if asked what it tracks, say what it counts, in your own words. If you don't know how a figure was counted, say that plainly | F3 is your closest match to the monthly-reporting duty, and the recruiter will pass on what you say. EXP because the claim will be checked again in round 2 (P1) |
| A5 | "How comfortable are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | F4's answer slot: if the spreadsheet is in Excel, say so and name one feature you actually used. If it isn't, name the tool and say plainly how comfortable you are with Excel itself | A requirement from the JD's list that recruiters often check in one line. JD because it scores the stated requirement |

**Bank B: Skeptic, light**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre too. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then one plan sentence, such as how you would get to know it in the first weeks. Say it calmly and move on. Don't tack on an apology | F2 is a stated gap against a named part of the remit. Rehearsing the plain line now makes the round 2 version (C1) easier |
| B2 | "The JD asks for 4+ years in financial-services customer operations. How does your background fit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | "Six years in retail banking, the last three as a branch supervisor." Stop there and let them map it. If they ask what that involved, use F1 and F5 at their own scope | F7 is a requirement that gets checked literally. JD because it is a stated qualification |
| B3 | "Have you handled regulated complaints?" | JD | [inferred] "I handled the branch's formal complaints log" | Say "I handled the branch's formal complaints log." F8's answer slot: if those complaints came under a regulator's rules, say which rules and which part was yours. If you don't know, say so plainly. Don't turn "formal" into "regulated" | F8 is the JD's named requirement where your words and theirs don't yet meet. `[inferred]` because the link from "formal" to "regulated" is the pack's |

**Reverse questions for the recruiter**

| Question | Why it lands |
|---|---|
| "What does the Head of Member Services most want from this role in its first six months?" | Prepares you for round 2, and recruiters usually know |
| "For the panel's case, will I see the complaint beforehand or on the day, and can I take notes in?" | A logistics question that helps you prepare for the graded part |
| "Which complaints regulator or scheme does Ashgrove work to?" | Closes F8's open question before round 3, and shows you take the regulated side seriously |
| "Who looks after contact-centre complaints today, and would they sit with this role or alongside it?" | Shows you have read the remit, including the part that's new to you |
| "As the eight branches become five hubs, does this role's remit change during 2027?" | Shows you've read the brief and are thinking about the role over time |
| "When will I hear back after the 21st?" | A plain logistics question that recruiters expect |

---

## Round 2: Head of Member Services, 45 minutes

**Personas**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the jump from one branch to the whole process, the contact centre and senior audiences | High. The usual pattern for a hiring manager is to probe the risk in a hire, and F1, F2 and F9 are where that risk sits | Rehearse C1 until it feels routine. Hold on F1, F5 and F3 at their own scope. Concede F2 and F9 in their plain words, then give a plan |
| Values / Behavioral | "Tell me about a time…" questions | High. The recruiter said "mostly behavioural" | Pick stories with the selection guides in D1 to D4. Use "we" for context and "I" for what you did. Where no story comes to mind, say so |
| Case / Strategist | "What would you do…" questions about the roadmap and the monthly report | Medium. Usual for a hiring manager, but behavioural questions come first in this round | Clarify, then set out the structure, then answer. Use the brief's vocabulary |
| Data-Driven Prober | Where do the spreadsheet's numbers come from | Low to medium. The JD's monthly-reporting duty makes F3 a natural target | Know what you can and can't say about how each number was counted, and say "I don't know" where you don't |

**Bank C: Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've handled one branch's complaints log and never worked in a contact centre. Why should I trust you to own the whole process?" | JD | [grounded] "I handled the branch's formal complaints log" "Never worked in a contact centre" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" "6 years in retail banking, the last 3 as a branch supervisor" | **The highest-return prep in this pack.** Name the limit before they do: "That's fair. I haven't worked in a contact centre, and my complaints experience is one branch." Then hold with only what your sentences carry: you handled the branch's formal complaints log, you trained new tellers on your escalation script, and you built the monthly complaints spreadsheet your regional manager uses, over three years as a branch supervisor. Then give a plan, framed as a plan: how you would learn the contact centre and the other branches early on. **Follow-up 1:** "But one branch isn't eight." Hold: "Right, it's one branch's log." Don't widen it to the region. **Follow-up 2:** "So what's your first month?" Answer with the plan, not the past. If F1's answer slot has an honest first branch (you decided outcomes or replied to members), use it here in your own words. If it doesn't, stay with the log | F1 and F2 together are the largest gap between your material and the remit. The hiring manager owns that risk and will raise it in some form. JD because it scores the headline responsibility, and Skeptic delivery calls for holding a position and then conceding |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" "Never worked in a contact centre" | Choose one real gap, not a disguised strength. F9 is the honest pick for this audience: "I've never presented to anyone above regional level." Follow it with a plan for building that confidence, and stop | Very likely. A rehearsed honest answer scores better here than a clever one. F9 is the gap that matters to the person you'd report to |
| C3 | "This role reports to senior leaders every month. Tell me about presenting to senior people." | JD | [grounded] "I've never presented to anyone above regional level" | Hold, then concede. Concede first and specifically: "I've never presented to anyone above regional level." F9's answer slot: if you have presented at regional level, say what and to whom. If you haven't, say so. Then give the plan. If they push ("so you'd be learning on the job?"), agree to the specific part ("Yes, for senior audiences") without giving up anything your sentences do carry | F9 is a stated gap against a named requirement, and the person asking is likely to be who you'd present to. JD content, delivered under pressure |
| C4 | "Escalations come up with branch supervisors. Have you coached a supervisor through one?" | JD | [grounded] "trained new tellers on our escalation script" "6 years in retail banking, the last 3 as a branch supervisor" | Start with what you did: "I trained new tellers on our escalation script." Answer slot: if you have helped another supervisor with an escalation, tell that story in your own words. If you haven't, say so plainly and stay with training tellers. Don't call the tellers "staff I coached" and don't call the script yours | F5 is the closest your material comes to the coaching duty, and the question assumes something your sentences don't, so the answer slot allows for "no". JD because it scores the stated duty |

**Bank D: Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you found a problem and kept hold of it until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Pick a story with a named problem, the moment you could have handed it on, what you did instead, and how it ended. If the spreadsheet in F3 began as a fix for a problem, that could be your story, but only if it did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Its theme is Own the Fix from the values page. The panel scores values, but the hiring manager is likely to test them as well |
| D2 | "Tell me about a time you put a member ahead of a rule or a target." | VAL | [grounded] | Pick a story with a named member need, the rule or target it pushed against, what you decided, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Its theme is Members First, Always, and the question is a Values persona stem |
| D3 | "Tell me about a complaint that went badly before it went well." | EXP | [grounded] "I handled the branch's formal complaints log" | Pick a complaint from the log you handled (F1), with what went wrong, what was yours to put right, and what changed. Keep your own part at its real size. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A behavioural question themed on the JD's complaints remit. EXP because the follow-up will be "what did *you* do?" |
| D4 | "Tell me about explaining something so it landed the first time, with a member or with a new teller." | VAL | [grounded] "trained new tellers on our escalation script" | Nearest material: you trained new tellers on your escalation script. Answer slot: if a specific moment with a teller or member comes to mind, tell it in your own words. If one doesn't, say so and describe how you trained them | Its theme is Plain Words. F5 is the one sentence close to it |

**Bank E: Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints, and what would you want from the digital team?" | CO | [grounded] | Clarify which journeys move first. Then cover four things: new kinds of complaint from digital journeys, how they get logged the same way as branch complaints, sharing complaint themes with the digital team, and members who won't move (Members First). If asked about past digital work, use F6's answer slot | CO because it uses the brief's headline target. It tests whether you can think at the level of the strategy |
| E2 | "Your first monthly complaints report lands on my desk. What's on it?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | A structure you can talk through: volumes by branch and by channel, resolution times against whatever deadlines apply, the oldest open cases, recurring themes, and the actions taken. Your past comes in only as "I built the monthly complaints spreadsheet our regional manager uses". Don't say "like mine" unless F3's answer slot showed it tracks the same things | A live problem taken from the JD's reporting duty. CASE delivery, with F3 as the evidence nearby |

**Bank P: Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through that spreadsheet. Where does each number come from?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slots, in your own words: how each figure is counted; what would make it wrong; the assumption behind it you'd defend least, named before they ask; which parts were yours. "I'm not sure how that figure is counted" is an honest answer. A made-up method is not | F3 is the claim closest to a figure in your material, and probers go two levels deep. EXP because it checks a claim about your past |
| P2 | "How did you know the complaints log caught every complaint?" | EXP | [grounded] "I handled the branch's formal complaints log" | Answer slot: if you checked whether it was complete, say how. If you didn't, or couldn't know, say so plainly. That gap is exactly what someone owning the whole process would need to close, so say it as an observation | F1 and F8 meet here. An honest "we couldn't know" scores better than a confident gap that falls apart |

**Reverse questions for the Head of Member Services**

| Question | Why it lands |
|---|---|
| "What would tell you, a year in, that this hire was the right one?" | Asks what success looks like. This is your future manager |
| "Where are complaints hardest today: in branches, in the contact centre or between them?" | Points straight at F2 and asks for the real map |
| "Who would I present the monthly report to, and what do they currently find missing from it?" | Shows you know F9 is the growth area and are already preparing for it |
| "How will complaints about the new small-business lending product be handled?" | Shows you've read the brief to its Q1 2027 launch |
| "How do complaints feed the move to 40% digital today?" | Links the role's remit to the headline strategy |

---

## Round 3: Panel of two branch managers, 60 minutes (values round and case)

**Personas**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One question or more per value, scored against the four | High. The recruiter said the panel "score against the four values" | One prepared story or selection guide per value (cheat sheet below), with each value named the way Ashgrove names it |
| Case / Strategist | The 20-minute escalation case | High. Announced by the recruiter | The structure in the graded-deliverable section |
| Peer Evaluator | "Our supervisors, your coaching": where the role meets their branches | Medium. Their supervisors are who the role would coach, so the panel is pricing what you'd add to their load (pack reading) | Talk about give and take: what branches get from you, and principles for disagreements |
| Pressure | "Why would supervisors listen to you?" | Low to medium. A panel can play devil's advocate on F5 | Hold on F5 at its own scope, then concede the difference |

**Bank G: Values (one per value)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "We decide from the member's side of the counter. Tell me about a decision you made that way." | VAL | [grounded] | Pick a story with a named member, what the branch's side of the counter would have chosen, what you chose, and what it cost or saved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always, using the value's own wording. Scored |
| G2 | "If a member needs it explained twice, we wrote it wrong. When have you made something plainer?" | VAL | [grounded] "trained new tellers on our escalation script" | Nearest material: you trained new tellers on your escalation script. Answer slot: if you ever reworded or simplified something, for a teller or a member, tell it in your own words. If you didn't, say so plainly and describe how you trained. Don't say you wrote the script | Plain Words, using its own wording. F5 is the nearest material. The answer slot is there because your sentence says "trained on", not "wrote" |
| G3 | "Tell me about a time the numbers said one thing and the member in front of you said another." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Pick a story with a figure, a member, the gap between them, and which one you acted on. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. With your F3 spreadsheet in the background, expect "are you a numbers person?". Answer it in the value's terms, without claiming a story you don't have | Neighbours, Not Numbers. It is also where F3 could count against you with this panel |
| G4 | "Tell me about a problem that wasn't strictly yours that you kept hold of until it was solved." | VAL | [grounded] | Pick a story with whose problem it was, why you kept it, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use a different story from D1 if you have one, because the panel may hear about round 2 | Own the Fix, using its own wording. Paired with D1 because both rounds may test it |

**Bank H: Case**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | The 20-minute complaint-escalation case | CASE | [generic] | Use the graded-deliverable section: clarify, contain, investigate, decide and explain, record, fix the cause, coach, report. Name a value at the decision where it bites. Hold one defensible position and state its concession | Announced by the recruiter. `[generic]` because the case's details aren't known. The structure is a pattern, not Ashgrove's procedure |
| H2 | "The supervisor followed the script and the member is still unhappy. What do you say to the supervisor?" | CASE | [generic] | Structure: what went right, where the script stopped helping, what the supervisor could try next time, and whether the script itself needs changing (Own the Fix). Frame it as coaching, not blame. It's a live problem, so it needs no claim about your past | Likely to follow the case. Tests the coaching duty (F5's requirement) as a decision |

**Bank I: Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You'd be coaching my supervisors. What happens when your view of an escalation differs from mine?" | JD | [generic] | Offer principles, not a turf claim: the member's outcome decides, the branch manager runs their branch, disagreements are settled privately before anything reaches the supervisor, and you write down what was agreed. It's hypothetical, so make no claim about your past | Where the role meets their job. JD because it scores the coaching duty |
| I2 | "Some of our towns will lose a branch as we move to hubs. What does that mean for complaints there?" | CO | [grounded] | Acknowledge that this is their reality and that you don't know the plan. Cover four things: complaints about the change itself, members who relied on the branch (Neighbours, Not Numbers), watching those towns' complaints separately in the monthly report, and listening to branch staff about what members are saying | The brief's consolidation set against the panel's own work. CO because it tests the brief, and VAL comes through in the delivery |
| I3 | "What would you need from branch managers, and what would we get from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I built the monthly complaints spreadsheet our regional manager uses" | Give and take. You've worked as a branch supervisor for three years, so say that plainly and let them draw the link. Offer, framed as a plan: a monthly view of each branch's complaints, and coaching that cuts escalations. Ask for: early warning on recurring issues, and time with supervisors | A question about load and partnership. JD because it scores the coaching and reporting duties |

**Bank J: Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You'd be coaching supervisors at your own level. Why would they listen?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "trained new tellers on our escalation script" | Pause, then hold: "I've been a branch supervisor for three years, and I trained new tellers on our escalation script." Concede the specific difference before they push: training tellers on a script isn't coaching supervisors. Then describe how you'd earn their trust, framed as a plan. Hold through a second push without claiming more | F5 under pressure. JD content, Pressure delivery. Hold, then concede |

**Reverse questions for the panel**

| Question | Why it lands |
|---|---|
| "What could someone in this role do in their first month that would genuinely help your branch?" | A give-and-take question for the people the role works beside |
| "Where do escalations from your branches get stuck today?" | Asks them for the real map. Branch managers know where it hurts |
| "How are members in your towns reacting to the move to hubs so far?" | Neighbours, Not Numbers, asked sincerely |
| "Which of the four values is hardest to live up to in a complaint?" | Asks them to talk about the thing they are scoring you on, peer to peer |
| "What do your supervisors find hardest about escalating today?" | Connects to the coaching duty and invites them to say what supervisors need |

---

## Values cheat sheet (round 3, and round 2's behavioural questions)

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide as the member would see it | No sentence from your message carries a decision story here. Pick one with a named member, the branch's easier option, and what you chose. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. G1, D2 |
| Plain Words | If it has to be explained twice, it was written badly | Nearest: F5, "trained new tellers on our escalation script". This covers training only, not writing. Answer slot as in G2. G2, D4 |
| Neighbours, Not Numbers | Each branch belongs to its town, so don't treat it as a statistic | No sentence carries this. Pick a story where a member mattered more than a figure. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Be ready for the tension with F3 ("I built the monthly complaints spreadsheet our regional manager uses"). G3, I2 |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | No sentence states a problem kept until fixed. F3 qualifies only if the spreadsheet began as a fix. Otherwise pick a story with a named problem, the moment you could have handed it on, and the end. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. D1, G4 |

---

## Prohibited claims

This pack does not coach the following claims. You may be tempted to make them under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material describes one branch's log, not a process |
| Has worked in or with a contact centre | Negative you stated, F2 | "I haven't worked in a contact centre." No answer slot |
| Has presented to senior leaders | Negative you stated, F9 | "I've never presented to anyone above regional level." |
| Coached supervisors | Inflated form of F5 | F5's quote at its own scope: "trained new tellers on our escalation script". C4's answer slot stays within your actual experience |
| Wrote or designed the escalation script | Inflated form of F5 (the verb drifts) | "our escalation script". You trained people on it |
| Handled regulated complaints | Inflated form of F8 | F8's quote, "I handled the branch's formal complaints log". The answer slot asks only which rules applied to that log |
| Produces the region's complaints reporting, or reports to leadership | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses", where *uses* stays *uses* |
| Excel expert | Inflated form of F4 | "spreadsheet", with the tool named only if the answer slot confirms it |

---

## Sources

**Provided documents**

- The JD, as pasted
- Ashgrove's values text, which you pasted and said you copied on 12 November 2026 from ashgrovecu.org/about/values. Not fetched
- The recruiter's email on the process
- The points you gave from the 2026 strategy brief Ashgrove published in July 2026, which the recruiter sent you
- Your background, as written in your message

No dossier was consumed.

**Target accounting**

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted, copied today, already fixes the values cheat sheet and the G bank |
| 2. Ashgrove interview process | skipped | The recruiter's email establishes all three rounds, who runs them and what they hold, which fixes the round structure and persona weights |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief, under six months old, already supplies the CO questions and the grounding brief |
| 4. Interviewer name and Ashgrove | n/a | No names have been assigned yet, so there was no query to form |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Which complaints regulator or scheme Ashgrove works to.** F8 and step 5 of the case become specific, and you can name real deadlines. One question to the recruiter (round 1's reverse questions include it).
- **Your answers to the answer slots in F1, F3, F4, F6, F8 and F9.** Each one you tell me outside a drill goes into the fit snapshot as your own words, and C1, A4, A5, E1, E2, B3 and C3 regenerate from it.
- **What the spreadsheet tracks.** F3 and F4 currently rest on one sentence with nothing to look at behind it. A redacted look at the spreadsheet itself, the artifact this field keeps, would let those rows go from `medium` to `high`. You wouldn't need to bring it to the interview.
- **The interviewers' names, once assigned.** Adds a "reading the interviewer" section, panel personas assigned per member, and reverse questions tied to their own careers.
- **How much prep time you have before the 21st.** Adds a prioritised prep schedule. Without one, start with C1 and the case.
- **The case format, if the recruiter will share it.** Whether it's written or verbal, and whether you get it beforehand, would sharpen the graded-deliverable section.
- **A deeper research pass (L2).** Up to 6 more searches and 2 more fetches, several more minutes. It covers recent Ashgrove organisational news and any candidate reports on its interviews, which would add context to round 3 and the reverse questions. Run it only if you want it.
- **A `tuesday-dossier.md` from job-underwriter.** Would grade your evidence after it has been verified and name the objection most likely to come up from it, rather than leaving the pack to infer it. Optional; this pack is complete without one.
