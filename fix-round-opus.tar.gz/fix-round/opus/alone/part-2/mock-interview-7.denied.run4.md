Web search was declined, so I'm building the pack from your JD and background alone and will note what research would have added.
I've built your prep pack: 22 practice questions sorted by interviewer style, with answer guidance written from what you told me. It assumes Tobias would be your manager, since you didn't say. Web search permission was declined, so nothing about Saltmarsh, its values or Tobias himself is researched. Questions about the company are generic.

Your interview is tomorrow. Tonight, the pack's prep list starts with these:

- **Practise A1 out loud three times. It's the question most likely to come up in some form:** you've never led a team, and the role coordinates design, art, engineering and community across two games. Start with "I haven't led a team," with no "but effectively…". Then give the two-year content-drop calendar and the release checklist QA still uses, then a plan for your first month.
- **Write down your honest answers to the probes your background doesn't settle:**
  - Was your main title a live-service game?
  - Which calendar decisions were yours?
  - Who produced the retention numbers you presented?
  - Did you run the checklist with QA, or only write it?

  Each has a "yes" and a "no, and here's what I did" version. Use whichever is true.
- **Prepare the in-app purchases answer.** The JD doesn't mention in-app purchases, but mobile live ops often involves them. The pack gives a one-line answer and a reverse question about which KPIs the post-event review reports.

The pack also lists claims it won't coach you to make, such as dropping "associate" from your title or calling coordination "leadership".

If you like, I'll play the sceptical interviewer on A1 and push back on your answers.
I can also save a `tuesday-dossier.md` file listing the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and did the recruiter mention an exercise or focus areas for Friday? The answer changes which questions come first.
If you allow web search, should I also run a deeper research pass on Saltmarsh and Tobias (up to 6 more searches and 2 page fetches, several minutes)?

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-7-denied-9458d69f:
- saltmarsh-games_live-operations-producer_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Built as a hiring-manager round, on the assumption that this is the person you would report to.
**Format:** one 60-minute session, Friday 13 November 2026.

---

## How to use this pack

**Personas** describe *how* a question is asked: the style, the pressure, the follow-ups. **Types** describe *what* is being scored. Each question has both.

| Tag | What it scores |
|---|---|
| **JD** | Can you do the job as listed, gaps included |
| **EXP** | Whether what you said about your past holds up, and what was actually yours |
| **CASE** | How you structure a live problem from the role |
| **CO** | What you know about Saltmarsh and how its live ops are run |
| **VAL** | Whether your past behaviour shows values the company has published |

Provenance labels: **[grounded]** means traceable to your JD or your message; **[inferred]** means derived by this pack, with the derivation named; **[generic]** means a role-family pattern that says nothing specific about Saltmarsh or about you.

**Answer slots** appear wherever the JD is likely to raise something your material doesn't show. Each slot has two honest branches. Answer the one that's true. The guidance is scaffolding, not a script: say it in your own words.

---

## Prep triage

Your interview is tomorrow, so this assumes one evening.

1. **A1, out loud, three times** (15 min). This is the highest-ROI prep in the pack.
2. **Fill in your answer slots** for A3, A4, C1 and E2 by writing one honest sentence for each branch that's true (20 min). These are the probes most likely to catch you improvising.
3. **B1 and B4 out loud**, using the case structure (20 min).
4. **D1, your 90-second arc** (10 min).
5. **If you know which two titles this role covers, play both** (30 min). D2 and every case question get better.
6. **Pick three reverse questions** (5 min).

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and a weekly content-drop calendar. It doesn't say whether the main title was run as a live-service game. Words: "Four years as an associate producer at a puzzle-game studio." Answer slot: the JD's live-service line makes this probe likely. If it was a live-service game, say so and what that meant day to day, in your own words. If it wasn't, say so plainly and stay with the weekly content drops |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. Nothing has been inspected behind the line, though, so expect a probe on what running it meant (A3). Lead with the quote's own terms: weekly, main title, last two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one main title and content drops. The role says two titles and live events. Keep the words at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on handling more than one title likely. If the calendar ever covered more than the main title, say how. If it didn't, say so plainly and stay with the main title. A second slot, from the JD's "mobile": if the main title was on mobile, say so; if it wasn't, say so plainly |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show who you worked with to get each drop out. Answer slot: if running the calendar meant working with design, art, engineering or community people, say which and how, in your own words. If it didn't, or that was someone else's job, say so plainly and describe how you would set it up here, as a plan. Coordinating is not leading. Keep the two apart (see Prohibited claims) |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a review of each event, but it isn't the same thing. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe likely. If you ever reviewed a content drop after it went out, written or spoken, say what it covered and which part was yours. If there was no such review, say so plainly and stay with the monthly numbers |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote already speaks the JD's language. Expect a probe on which numbers they were and who produced them (C1). Answer slot: if you pulled or calculated them yourself, say how, in your own words. If someone else produced them, say so plainly and stay with presenting them |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | Lead with the quote: you wrote it, and QA still uses it. Writing and managing are different verbs. Answer slot: if you also kept the checklist up to date or ran it with QA on release days, say so. If you didn't, say so plainly and stay with having written it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A checklist people still use is a written document. Whether it shows clear writing is the interviewer's call, so don't claim it on your own behalf. Answer slot: if you wrote other things regularly in the role, say what they were, in your own words. If you didn't, let the checklist stand on its own |

No row is a gate. "3+ years" is an experience requirement, not an eligibility term, and the JD names no location, authorization or credential terms.

**Highest-ROI objection:** that the role asks you to coordinate four disciplines across two titles, and you have told me you've "Never led a team". The deepest rehearsal for it is **A1**.

---

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the step up: associate title, one title, coordination across four disciplines | High. The hiring-manager prior is Case/Strategist plus Skeptic, and F3, F4 and F5 are where the JD reaches past your material | Rehearse A1 until it's boring. Build bridges only from your quotes, say the limits plainly, then give a concrete ramp plan |
| Case / Strategist | Live problems from the job: build a calendar, diagnose a retention dip, rescue a late asset | High. Same hiring-manager prior, and the JD's verbs (plan, run, coordinate, own) all invite cases | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise per case |
| Data-Driven Prober | "Which retention numbers? Counted how? Who produced them?" | Medium. The JD names retention metrics and KPIs, and F6 is a line that gets drilled | Know what you can and can't say about how the numbers were counted. Say plainly when you don't know |
| Conversational | Friendly opener, "walk me through the journey", "why us" | Medium. Most 60-minute sessions open and close this way, and casual answers are still scored | A pre-built 90-second arc. Treat casual questions on live ops as scored |
| Pressure | Time-boxed "why you", "how much was actually you" | Low. Nothing points to a stress format, but one sharp attribution probe is likely | Pause, anchor in what you said, and hold through two follow-ups before conceding anything real |
| Peer Evaluator | Seam questions about design, engineering and community | Low as a persona, but the coordination line in the JD makes seam scenarios likely | Use reciprocity framing and propose seam principles rather than pretending to know their seams |
| Values / Behavioral | "Tell me about a time…" scenarios | Low. You described a single session with Tobias, no values round is named, and Saltmarsh's published values weren't researched | Choose stories your material carries, and say plainly when none fits |

All weights are set by the relationship prior and by your description of the session. No interviewer signals were applied because research didn't run.

---

## Question banks

Bank letters run A–E, then P (Peer) and V (Values), so that they don't collide with the fit-snapshot IDs.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never led a team. This role coordinates design, art, engineering and community on every update, across two titles. Why should I believe you can run that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment and don't soften it: "I haven't led a team." Then say what you did, in the quotes' own terms: "For the last two years I ran the weekly content-drop calendar for our main title, and I wrote the release checklist our QA team still uses." Answer slot: the JD's coordination line makes "who did you work with to get each drop out?" almost certain. If running the calendar meant working with design, art, engineering or community people, say which and how, in your own words. If it didn't, or that was someone else's job, say so plainly and stay with the calendar and the checklist. Close with what you would do in the first month here, said as a plan and never as a past. Hold through two follow-ups by returning to the calendar and the checklist. Concede plainly that four disciplines across two titles would be new for you. Never call coordination "leadership". If the second follow-up is "what happened when a drop slipped?": if one did on your watch, say what you did; if none comes to mind, say so | F4 is blank and the stated negative sits next to the JD's coordination line, so this objection will arrive in some form. JD because it scores the stated responsibility against your stated limit |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Pick one real answer, name it in a sentence, then give a plan. The honest candidates are your two stated negatives, or a JD line the fit snapshot shows your material doesn't reach: two titles (F3), the post-event review (F5) or cross-discipline coordination (F4). Don't offer a disguised strength. Say it plainly, then say how you would close it in your first months, as a plan | A standard Skeptic stem. Rehearsing it stops the candidate from reaching for a fake weakness under pressure |
| A3 | "Your title was associate producer. On that content-drop calendar, what decisions were actually yours?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Keep the title exact: associate producer. Answer slot: the JD's "plan and run" line makes this probe likely. If you decided what went into which week, the order, or what got cut, say which and how you decided, in your own words. If those calls sat with someone else, say so plainly and describe how you ran the calendar | F2 and F3 hold the core evidence, and an associate title invites the "what was yours" question. EXP because it tests attribution |
| A4 | "Was your main title a live-service game? Everything here is live ops." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot, from F1. If it was a live-service game, say so in one sentence and describe what the weekly drops meant for the team, in your own words. If it wasn't, say so plainly and describe the weekly drops as they were. Don't relabel the game to fit the JD | F1 is the experience requirement, and the material doesn't settle it. JD because "live-service" is the JD's own word |
| A5 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" | "No, I haven't worked on a game with in-app purchases." Then one or two sentences on how you would get up to speed, as a plan. Don't follow it with "but I understand monetization", because nothing in your material carries it | The JD doesn't mention monetization. Mobile live events are often tied to in-app revenue, though ([generic], a role-family pattern, not a claim about Saltmarsh), so the question may come up. Rehearsing the one-sentence answer keeps it from turning into a ramble |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you'd build a quarter's live-events calendar for two titles. What do you need to know first?" | CASE | [generic] | **Clarify:** each title's audience and current health, team capacity per discipline, fixed dates (holidays, platform or store events), and what the last reviews said. **Objective:** what each event is for, such as re-engaging lapsed players or holding a cohort. **Approach:** a cadence per title, staggered so shared people don't peak on both at once; content-lock and QA dates working back from each launch; buffer slots. **Metrics:** one primary KPI per event, agreed before launch. **Risks:** a late asset, a store-review delay, a bug escaping QA. Challenge one premise, e.g. whether both titles need the same cadence. If you draw on your own calendar, use only what you actually did | A direct test of the JD's first line. CASE because it's a live plan, not a record. [generic] because no Saltmarsh specifics were researched |
| B2 | "Retention for the cohort that joined during our last event came in below the event before. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify what is being compared: the same day-N window, similar acquisition, the same day of week and season. Rule out data first (tracking or definition changes). Then the release: crashes or bugs in the update, store timing. Then the event itself: difficulty, rewards, length. Then outside factors: holidays, other launches. Segment new and returning players and platforms. Say what you would do today and what goes into the post-event review | Hits retention metrics and the post-event review. The "metric dropped" stem is a Case staple |
| B3 | "Two days before an update, art tells you a key event asset won't be ready. What do you do?" | CASE | [generic] | Find out the facts first: what exactly is late and by how much. Then options: descope the event, swap it with the next one, ship with an alternative, or delay. Lay out each option's cost to players and to the other teams. Name who makes the call and by when. Then the release checklist and the QA impact, and what the community team tells players. Afterwards, record it in the post-event review | Tests coordination and the QA checklist under time pressure, which is the job's daily texture |
| B4 | "What goes into a post-event review, and who is it for?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Structure: the goal versus the result on the agreed KPI; supporting metrics (participation, retention around the event, engagement, plus revenue if the game monetizes, which is worth asking about); production (plan versus actual, bugs that escaped, late assets); community sentiment; then decisions for the next event, stated first. Keep it short, decisions up top, written for people who won't read past the first screen. You can say "I presented the monthly retention numbers to the studio head." Answer slot: if you ever wrote a review of a single drop, say what it covered; if not, say so plainly and stay with the monthly numbers | The JD's "own the post-event review" line, and the best place to show written communication (F8). Grounded because the guidance offers the F5 quote |
| B5 | "If both titles draw on the same art and engineering people, how do you stop one calendar starving the other?" | CASE | [generic] | Make capacity visible: one view of both calendars with each discipline's load. Agree priorities in advance with whoever owns the titles. Stagger the heavy builds. Have a rule for conflicts, i.e. who decides and how fast. Escalate early, with options. Ask whether the people are actually shared, without assuming it | The JD says two titles. Phrased as a hypothetical because the pack doesn't know how Saltmarsh staffs them |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to your studio head. Which numbers, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the metrics you presented, in your own words. Answer slot: the JD's retention line makes "how were they counted" likely. If you know how the cohorts and day-N windows were defined, say so in your own words; if you don't, say so plainly. If you pulled or calculated them yourself, say how; if someone else produced them, say so and stay with presenting them. Name, before he does, the part of the numbers you'd be least sure how to defend. Never describe a method you didn't use | F6 is the line a Prober drills. EXP because it tests what was yours |
| C2 | "Tell me about a time retention numbers changed what went on your content calendar." | EXP | [grounded] "Presented the monthly retention numbers to the studio head"; "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if the numbers ever changed a drop, its timing or its content, say what changed and which part was yours, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: running the calendar and presenting the numbers. Or describe how you would connect the two here | The JD pairs the calendar and retention, and this joins F2 and F6. An open prompt, so it supplies no event |
| C3 | "Which retention metric would you trust least for judging a single event, and why?" | CASE | [generic] | Pick one and name its weakness: event-period retention gets confused by seasonality, overlapping updates and acquisition mix. Say what you'd compare against (a matched earlier period or a holdout, if one exists) and what you would want to know before calling an event a success | Tests whether you are "comfortable with" metrics beyond presenting them. CASE because it's reasoning, not history |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | 90 seconds. Four years as an associate producer at a puzzle-game studio. For the last two years, the weekly content-drop calendar for the main title. Wrote the release checklist QA still uses. Presented the monthly retention numbers to the studio head. Then why this role and why now, in your own words. Stop there and let him pick a thread | Almost certainly the opener. Each beat is one of your sentences, so nothing in it can be probed into collapse |
| D2 | "Why Saltmarsh?" | CO | [generic] | Answer slot: if you've played their titles, say what you noticed about how they run events, in your own words. If you haven't, play them tonight. Then tie it to the role: live events across two titles is the next step from one title's calendar. Don't cite facts about Saltmarsh you haven't checked | CO, generic because research didn't run. The upgrade menu says what would ground it |
| D3 | "What's a live event in a mobile game you've played recently that you thought was well run?" | CO | [generic] | Pick one you actually played. Say what it was, why it worked (cadence, rewards, how it was announced) and one thing you'd change. If none comes to mind, say so plainly and talk about a content drop you'd change in your own title | A casual question that's still scored: it tests genuine interest in live ops |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate who already knows our titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Pause. Concede the true part: they know the titles. Then your two lines in their own terms: the weekly calendar for the main title for two years, and a release checklist QA still uses. Close with one sentence on what you would do in the first month. Don't knock the internal candidate | Composure and economy. Rehearse it to time |
| E2 | "That release checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote it, and QA still uses it." Keep "still uses" as it is and don't widen it to "the whole studio". Answer slot: if QA contributed items or reviewed it, say who did what. If you also ran it on release days, say so; if not, say so plainly and stay with having written it. Be ready to describe what's in it, in your own words | F7 is your clearest match to the JD, so it will be tested. Pressure because the stem challenges attribution |

### P — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "The community team hears about a broken event before you do. What do you need from them, and what do they need from you?" | CASE | [generic] | Reciprocity first. They need early warning of what's shipping, known issues and approved player messaging. You need a fast channel for player reports and their read of sentiment. Agree in advance who posts what when something breaks, and bring them into the post-event review | The JD names the community team. Scores partnership fit |
| P2 | "Design wants to add a feature to an event a week before content lock. Engineering says no. You're in the middle — what happens?" | CASE | [generic] | Get the cost and the value of the addition into one view. Ask whether it can ship in the next event. Make clear who decides and by when. Protect the QA window. Write down the decision. Propose the principle, not just the ruling: changes after a date need a named owner and a cut | Seam-splitting between disciplines the JD asks you to coordinate |

### V — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if a month's numbers were bad news when you presented them, say what they showed, how you delivered it and what happened next, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard behavioral stem, and F6 is where your material sits nearest to it. No Saltmarsh values were researched, so this can't be mapped to theirs |
| V2 | "Tell me about a time you put players ahead of an internal deadline." | VAL | [generic] | Pick a time it was actually your call or your recommendation. It needs a named stake, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing, or how you would decide | Live-ops tension in a behavioral wrapper |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A1, A3, B1, B5 |
| Coordinate design, art, engineering and community teams | A1, B3, P1, P2 |
| Own the post-event review and its KPIs | B2, B4, C3 |
| Manage the release checklist with QA | B3, E2 |
| 3+ years producing live-service games or apps | A4, D1 |
| Experience running a content calendar | A3, C2, D1 |
| Comfortable with player-retention metrics | B2, C1, C2, C3 |
| Clear written communication | B4. Mostly shown in how you write any follow-up, not in a question |

No CO or CASE question is grounded in Saltmarsh's current strategy, because research didn't run. D2 and D3 are generic for the same reason.

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "Which KPIs does the post-event review report today, and who reads it?" | You'd own it. The answer also tells you whether monetization metrics are in scope, so you can address A5's gap with facts |
| "How do the two titles share design, art and engineering: the same people, or separate teams?" | Shows you're already thinking about B5's capacity problem |
| "Where does the current release process with QA tend to break?" | Connects directly to the checklist work you did |
| "How does the community team feed into planning an event, not just into reacting after it?" | Signals cross-team thinking about an interviewer's own team |
| "What would a strong first 90 days in this role look like to you?" | Gives you his yardstick, and lets you answer A1's ramp-plan follow-up on his terms |
| "What's the one thing about the live-events calendar you'd most like the new producer to fix?" | Turns the close into a working conversation |

None is tied to Tobias's own career path, because his public profile wasn't researched.

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team, or "effectively led" one | Negative you stated: "Never led a team, and never worked on a game with in-app purchases" | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases, or has monetization experience | Negative you stated, same sentence | "I haven't worked on a game with in-app purchases." No slot |
| Producer, without "associate" | Inflated form of F1's quote | "4 years as an associate producer at a puzzle-game studio", at its own scope |
| Ran live-events calendars across multiple titles | Inflated form of F3's quote | F3's quote at its own scope. The limit is the pack's observation: your material says the main title. F3's slot stays inside the calendar |
| Owned post-event reviews and their KPIs | Inflated form of F5's quote | F5's quote at its own scope. The limit is the pack's observation: your material says you presented monthly numbers. B4's slot asks only whether you reviewed a drop |
| Built or analysed the retention numbers | Inflated form of F6's quote | "Presented the monthly retention numbers to the studio head." C1's slot asks only who produced them |
| Managed releases or ran QA | Inflated form of F7's quote | "Wrote the release checklist our QA team still uses." E2's slot stays with the checklist |

---

## Sources

**Provided:** the JD text and your background, both from your message. No dossier was used.

**Searches sent:**
- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio news 2026": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Search refused. It would have given the official value names to theme V1 and V2; a values cheat sheet would follow only if a values round were found |
| 2. Saltmarsh Games interview process, live ops | unavailable | Search refused. It would have shown whether other rounds follow this one, and any case format. This session's weights rest on your description |
| 3. Saltmarsh Games strategy and recent news | unavailable | Search refused. It would have grounded D2 and given a strategy-based case question |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Search refused. It would have added an interviewer read, interviewer-signal persona adjustments, and a reverse question tied to his path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Allow web search → targets 1–4 run. D2 becomes grounded, a strategy-based case is added, and you get a "Reading the interviewer" section on Tobias plus a reverse question tied to his career
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a company grounding brief, Tobias's talks or writing if any exist, and reported interview loops for this role family
- Confirmation that Tobias would be your manager, and which round this is → persona weights recomputed. A peer or skip-level round would change the bank order
- The recruiter's prep email, if there is one → coverage of any pre-declared exercise (a calendar plan, say), plus any stated focus areas
- Your answers to the answer slots in F1, F3, F4, F5, F6 and F7 → those rows gain evidence, and A1, A3, A4, B4, C1 and E2 move from answer slots to story-mapped guidance
- The names of the two titles → B1, B5, D2 and D3 tuned to the actual games
- A redacted copy of the release checklist you wrote, or a deck of the monthly retention numbers → F6 and F7 could rise from medium to high confidence
- A dossier from job-underwriter → the highest-ROI objection derived from verified evidence rather than inferred, plus a prohibited-claims list checked against it. Optional; this pack is complete without one
