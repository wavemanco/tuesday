I've built your prep pack and saved it here: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-8-canned-9591994b/ashgrove-credit-union_member-experience-lead_interview_pack.md`

It follows the recruiter's three rounds. A shared fit snapshot comes first, then a short pack for each round: the recruiter screen, the Head of Member Services, and the branch-manager panel. The panel section includes a build-out for the 20-minute case and a cheat sheet for the four values. I made no web searches, because what you pasted already covered the values, the round structure and the strategy.

What matters most:
- **Highest-ROI prep (question E1, Round 2):** "No contact centre, and you haven't presented above regional level, so why take the bet?" The pack works out the wording for owning those two gaps first, then what you bring at its real size, then a plan.
- **Things your material doesn't settle:** whether your log held regulated complaints, whether your spreadsheet tracks volumes and resolution times, whether it's Excel, and what handling the log involved. The pack gives you two honest answers for each, but decide privately which one is true before the 21st.
- **Hub consolidation:** the panel are branch managers, and "Neighbours, Not Numbers" meets the eight-to-five hub plan head on. Question H3 prepares you for that.

If you want, I'll play the sceptical hiring manager on E1 and follow up on whatever you say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

- **Candidate:** Dara
- **When:** 21 November 2026, three rounds on one day
- **Round 1:** 30 minutes with the recruiter
- **Round 2:** 45 minutes with the Head of Member Services, who would be your manager. The recruiter describes it as "mostly behavioural"
- **Round 3:** 60 minutes with a panel of two branch managers. It includes a 20-minute case on a complaint escalation, and the panel scores you against Ashgrove's four values
- **Interviewers:** names not assigned yet, so this pack has no interviewer read
- **Mode:** loop. All three rounds share one fit snapshot, prohibited list and sources section, and each round gets its own mini-pack. The rounds come from the recruiter's email, not from a guessed pattern

---

## How to use this pack

**Personas** describe how a question is asked: the interviewer's style. **Types** describe what the answer is scored on. Each question has exactly one type:

| Type | What it scores |
|---|---|
| VAL | Whether things you have actually done show Ashgrove's published values |
| EXP | Whether what you say about your own background holds up when probed, and what was really yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and the pressures it faces |
| CASE | How you structure and reason through a live problem from the role |

The guidance is scaffolding, not a script. Each row's **Provenance** cell quotes the sentences of yours that the guidance rests on. If a guidance cell ever seems to say more than those quotes, trust the quotes. Where your material is silent, you'll see an **answer slot**: an instruction for the interview with two honest branches. Either branch is a good answer.

Question IDs: Round 1 is A–C, Round 2 is D, E, G and Round 3 is H, J, K. F is left out so that F1–F9 always refer to fit-snapshot rows.

---

## Prep triage: 9 days to 21 November

You haven't said how many hours you have, so this is a priority order rather than a timetable. Do these well, in this order:

1. **E1 out loud, three times on separate days.** It's the highest-ROI prep in this pack. Rehearse the concession wording until it sounds boring.
2. **Work through the answer slots privately** for F1, F3, F5, F8 and the regional-level slot in E1. Decide which branch is true for you before anyone asks. This is thinking time, not writing time.
3. **The Round 3 case build, run twice against a 20-minute timer.** Use K1 as the practice prompt.
4. **One story per value, H1–H4**, picked using the values cheat sheet's scaffolds.
5. **A1, the 90-second arc**, timed.
6. **Read the grounding brief twice** so the strategy vocabulary comes out naturally.

Everything else in this pack is insurance.

---

## Fit snapshot

Shared by all three rounds. Every claim the pack makes about your past is drawn from the quotes in the Evidence column.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | This is one branch's log, not an end-to-end process across branches, and your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If you investigated or resolved complaints yourself, say which parts and how, in your own words. If handling the log meant recording and tracking, or if resolution sat with someone else, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | This is a gap wording can't close, and you've said so yourself. Words: "I haven't worked in a contact centre." Follow it with how you would learn the contact-centre side, said as a plan and never as a past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The spreadsheet is monthly and about complaints. Your material doesn't show whether it counts volumes or resolution times. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it tracks volumes, resolution times or both, say which, in your own words. If it tracks something else, say what it tracks and what you would add to cover these two |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Training new tellers is close to coaching supervisors, but the audience is different, and your words should stay with the tellers: "I trained new tellers on our escalation script," and the last three of your six years have been as a branch supervisor. Answer slot: coaching supervisors means coaching people at your own level, so expect a probe on whether you've done that. If you've helped another supervisor with an escalation, say how, in your own words. If you haven't, say so plainly and stay with the teller training |
| F5 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The log held formal complaints. Your material doesn't say whether they were regulated or which rules applied. Answer slot: if those complaints fell under a regulator's complaint rules, say which rules and what they required of you, in your own words. If you don't know which rules applied, or none did, say so plainly and stay with the log |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital work either way. Strong evidence here would be a named piece of work with a digital or online-banking team and the part that was yours. Answer slot: if you've worked with a digital team, say on what and which part was yours, in your own words. If you haven't, say so plainly, then say how you would start working with one |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your evidence meets the bar, just in different words. Say it as written, "six years in retail banking, the last three as a branch supervisor", and let the interviewer map it onto "customer operations" |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says "spreadsheet", not "Excel". Answer slot: if you built it in Excel, say so, and describe what you built in it in your own words. If you used another tool, name it plainly |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | This is a gap you've stated yourself. Words: "I haven't presented to anyone above regional level." Follow it with how you would build the skill, said as a plan, for example a first monthly report taken through with the Head of Member Services before it goes higher. Never claim a senior audience |

### Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own the complaints process end to end across branches | F1 | B2, D1, D4, E1, K1 |
| ...and the contact centre | F2 | E1, E2, K1 |
| Report monthly on volumes and resolution times | F3 | G1, G2, J2 |
| Coach branch supervisors on escalations | F4 | D2, E3, J1 |
| Work with digital teams on self-service journeys | F6 | E2, K2, C1 |
| 4+ years in financial-services customer operations | F7 | B1 |
| Experience handling regulated complaints | F5 | A3, K1 |
| Confident presenting to senior leaders | F9 | E1, E2 |
| Comfortable with Excel reporting | F8 | A4, G1 |

---

## Grounding brief

Everything here comes from what you pasted. You described the strategy brief rather than pasting it in full, so this is the vocabulary you gave, not the brief's own wording.

| Fact | Source | Provenance | Where it is likely to come up |
|---|---|---|---|
| Member-owned, about 900 staff | JD | [grounded] | C2, A2. Use "members", never "customers" |
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, July 2026 | [grounded] | C1, K2, reverse questions. It's the backdrop to the JD's self-service line |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief, July 2026 | [grounded] | H3, J1, J3. The panel are branch managers, and the plan describes their next year |
| Small-business lending product launching Q1 2027 | 2026 strategy brief, July 2026 | [grounded] | C1, Round 2 reverse questions. A new product is a likely new source of complaints |
| Main competitive pressure is app-only banks | 2026 strategy brief, July 2026 | [grounded] | C2. Answer it from the member's side of the counter |
| Four values, by their exact names: Members First, Always · Plain Words · Neighbours, Not Numbers · Own the Fix | ashgrovecu.org/about/values, copied by you on 12 November 2026 | [grounded] | Round 3 scoring. Learn the names exactly as written |

The brief is about four months old. Anything Ashgrove has announced since July isn't in this pack, so don't present the brief as the latest word.

---

# Round 1: Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly openers, "walk me through", logistics | High. The usual pattern for a recruiter screen, and 30 minutes leaves little room for depth | A rehearsed 90-second arc. Treat casual questions on JD items as scored |
| Skeptic (light) | Quick checks against the stated requirements | Mid. A screen tests the listed requirements (4+ years, regulated complaints, Excel) before passing you on | Short, exact answers at the scope of your quotes |
| Case / Strategist (light) | "What do you know about us?" | Low. A homework check rather than a case | The four strategy moves in Ashgrove's own words |
| Prober, Pressure, Peer, Values | Rare in a screen | Covered in Rounds 2 and 3 | Not needed here |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds. Start with six years in retail banking, the last three as a branch supervisor. Then three things, in your own words: you handled the branch's formal complaints log, you trained new tellers on the escalation script, and you built the monthly complaints spreadsheet your regional manager uses. Close with why this role: say what draws you, in your own words. The JD's end-to-end complaints line is the natural link from the log | The opener of every screen. F7, F1, F4 and F3 together are your whole evidence pool, so practise saying each at its own scope before anything harder arrives. EXP because it sets what you'll be probed on later |
| A2 | "What made you apply to Ashgrove specifically?" | CO | [grounded] | Name one thing from Ashgrove's own material, such as member-owned, a value by its exact name, or one of the strategy moves, and connect it to your real reason in your own words. If your reason is the role rather than the company, say so honestly. Don't borrow a value as a reason you don't actually hold | A motivation-consistency check that comes back in Round 2. CO because it shows whether you've done the homework |
| A3 | "Have you handled regulated complaints before?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer with the quote: "I handled the branch's formal complaints log." Answer slot: if those complaints fell under a regulator's rules, say which rules and what they required of you, in your own words. If you don't know, or none applied, say so plainly. That's a limit, not a confession | F5 is the JD requirement most likely to be screened literally. JD because it checks a stated requirement |
| A4 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the quote, then the F8 slot: if it's Excel, say so and describe what you built in it, in your own words. If it's another tool, name it. Don't grade yourself with an adjective like "advanced"; say what you built and let them grade it | F8 is a stated requirement, and recruiters often check it in one line. JD because it maps one-to-one to the listed requirement |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for 4+ years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | One sentence, as written: six years in retail banking, the last three as a branch supervisor. Stop there and let the recruiter map it. Don't relabel your history as "customer operations" | F7 is a presentation gap and the easiest to close. JD because it's the length-of-experience requirement |
| B2 | "This role covers complaints for the whole credit union, and you've handled one branch's log. Why now?" | JD | [grounded] "I handled the branch's formal complaints log" | Accept the scope without shrinking or stretching it: "I handled the branch's formal complaints log." Then why now, in your own words. Don't claim you've already done the wider version | F1's scope jump is the objection behind this whole loop. This is its light first appearance before E1. JD because it scores the end-to-end requirement |

### Bank C: Case / Strategist (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Give the four moves in their words: 40% of member service on digital channels by 2028, eight branches into five hubs over 2027, small-business lending in Q1 2027, and app-only banks as the main pressure. Then one sentence on what you'd want to understand about how complaints change through each, framed as a question you bring rather than a conclusion | It shows you've read what the recruiter sent. CO because it's homework on strategy |
| C2 | "Our main pressure is app-only banks. What does a credit union have that they don't?" | CO | [grounded] | Answer in Ashgrove's own words: member-owned, Neighbours, Not Numbers, Own the Fix. A member whose complaint is held by someone who keeps hold of it is the contrast worth making. Concede what you don't know, for example how Ashgrove's resolution times compare, rather than guessing | The strategy brief names this pressure, so expect it in some round. CO because it tests competitive framing at Ashgrove's level |

### Reverse questions: Round 1

| Question | Why it lands |
|---|---|
| "For the 20-minute case, will I get the scenario in advance, on paper, or verbally on the day?" | It's logistics that changes how you prepare, and it's fair to ask |
| "The panel scores against the four values. Is there a scoring guide candidates can see, or is it the values page itself?" | It shows you took the values round seriously before you arrived |
| "What's made people succeed in this role, or in roles like it at Ashgrove?" | It invites the recruiter to tell you what the hiring manager values, in their words |
| "How does this role sit relative to the contact-centre leadership?" | It's a real question for you, given F2, and asking it reads as diligence |
| "What's the timeline after 21 November?" | It's expected, it's easy, and leaving it out reads as passive |

---

# Round 2: Head of Member Services, your would-be manager, 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" | High. The recruiter says this round is "mostly behavioural", which shifts the usual hiring-manager pattern toward behavioural questions | STAR stories. "We" for context, "I" for your own part. Use the honest branch where no story exists |
| Skeptic | Quiet probing of the gaps you've named | Mid. A hiring manager is managing risk on the hire, and F2 and F9 are the gaps the JD exposes most | E1 rehearsed until it's boring. Concede first, then your evidence at its scope, then a plan |
| Data-Driven Prober | Questions about the spreadsheet and the numbers | Low to mid. Monthly reporting would go to this person, and your spreadsheet is the nearest evidence | Know what you can and can't say about it, and say "I don't know" where that's true |
| Case / Strategist | A short live problem | Low here. Behavioural focus is stated, and the case sits in Round 3 | G2 covers it |

### Bank D: Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a complaint that needed escalating, and what you did." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one complaint from the log you can tell start to finish. Say what the member raised, what you did, what happened next, and what you'd change. If the escalation was taken over by someone else, say where your part ended. If no single case comes to mind, say so plainly, then walk through how the escalation script you trained tellers on is meant to run | The escalation line is in the JD and the Round 3 case. Rehearse a real one here first. JD because it scores the escalation requirement in behavioural form |
| D2 | "Tell me how you've helped someone learn to handle a difficult member conversation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers, and it was on the escalation script, which is the branch's script. Answer slot: the JD's coaching line makes a probe on how you trained them likely. Describe how you did it in your own words. If the training was mostly walking through the script, say so plainly and stay with that | F4 is your evidence for the coaching requirement. JD because it scores coaching on escalations |
| D3 | "Tell me about a time you told someone more senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you didn't fold, and a working relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The role reports to senior leaders (F9), so composure upward is a natural behavioural probe. VAL because it reflects Members First when the bad news is about members |
| D4 | "Tell me about a time a member's problem fell between two people or teams." | JD | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick an instance from your branch years where ownership was unclear. Say what you did to make sure someone held it, and what happened. If none comes to mind, say so plainly and describe how you'd stop it happening across branches and the contact centre | The JD's end-to-end line is about exactly these handoffs. JD because it scores ownership across channels |

### Bank E: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "I don't see a contact centre in your background, and you haven't presented above regional level. This role owns complaints across branches and the contact centre and reports to senior leaders. Why should I take that bet?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses." | **The highest-ROI rehearsal in this pack.** Concede first, in these words: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then what you bring, at its own scope: you handled the branch's formal complaints log, trained new tellers on the escalation script, and built the monthly complaints spreadsheet your regional manager uses. Then a plan, said as a plan: time alongside contact-centre staff early on, and a first monthly report taken through with this manager before it goes higher. Answer slot: if you have presented at regional level, say to whom and on what, in your own words. If you haven't presented at any level, say so plainly. **Follow-up 1** ("So what would you actually do on the contact-centre side?"): stay with the plan, listening before changing, and don't describe how a contact centre works as if you knew. **Follow-up 2** ("Presenting is learnable on the job, isn't it?"): hold. The gap is real, and the plan is how you'd close it. Don't agree it's trivial, and don't promise a speed you can't know | F2 and F9 are the two stated capability gaps, and F1 is the scope jump. Together they make the single most predictable objection to you for this role, so it gets the deepest rehearsal. JD because it scores the role's headline mandate against those rows |
| E2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick a real one, either the contact centre or presenting, in the plain words above, then the plan. Don't offer a fake weakness. Answer slot: if you haven't worked with a digital team (F6), that's a candidate too. Say so plainly and say how you'd start | It's a standard Skeptic opener, and you have stated gaps to answer it with. JD because it scores self-assessment against the listed requirements |
| E3 | "You've been a supervisor, and this role coaches supervisors, so your peers. Why would they listen to you?" | JD | [grounded] "the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | You know the supervisor's seat because you've had it for the last three years. Then the teller training, at its scope. Answer slot: if you've helped another supervisor with an escalation, say how. If not, say so plainly. Don't claim authority; say how you'd earn it, as a plan | F4's audience gap. The panel in Round 3 will press the same point in peer terms. JD because it scores the coaching requirement |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet. What's in it, and how does your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the quote gives you: you built it, it's monthly, it's about complaints, and your regional manager uses it. Then the slots. F3: if it tracks volumes or resolution times, say which; otherwise say what it tracks. F8: name the tool. Third slot: if you know how the regional manager uses it, say so in your own words. If you don't, say so plainly. Don't describe uses you haven't seen | This is your only reporting evidence (F3, F8), and this manager would own the monthly report, so expect two levels of probing. EXP because it tests what was really yours |
| G2 | "Complaint volumes jump 20% one month. How do you tell whether it's real?" | CASE | [generic] | Structure, not history. First check the counting: did anything change in how complaints were logged. Then split by branch, channel and category. Look at resolution times alongside volumes. Ask whether something happened that month, then ask the supervisors. Name your weakest assumption aloud, for example that every channel logs complaints the same way | The JD's monthly volumes line, as a live problem. It makes no claim about your past. CASE because it scores reasoning |

### Reverse questions: Round 2

| Question | Why it lands |
|---|---|
| "What would you want this role to have changed in the first 90 days?" | Your would-be manager defines success here, and it tells you what E1's plan should aim at |
| "Today, how do complaints from the contact centre and from branches reach the same place, if they do?" | It goes straight at F2 and shows you're thinking end to end |
| "Who reads the monthly complaints report now, and in what form?" | It's practical, given F9, and tells you what senior presenting would actually involve |
| "How will the move to five hubs change escalation routes for branch supervisors?" | It uses the strategy brief's own move and ties it to the coaching duty |
| "With small-business lending launching in Q1 2027, how are complaints about it expected to be handled?" | A new product is a likely new source of complaints, and few candidates will connect the two |
| "How do you like to be kept informed by the people who report to you?" | It's a manager-relationship question that's genuinely useful to you |

---

# Round 3: Panel of two branch managers, 60 minutes (20-minute case and values scoring)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One or more questions per value, scored | High. The recruiter says this is the values round, scored against the four values | One story or honest branch per value, using the value's exact name |
| Case / Strategist | The 20-minute complaint-escalation case | High for the case segment. It's announced, so it's graded | The case build below: clarify, objective, approach, ownership, close |
| Peer Evaluator | "What would you need from my branch?" and questions about where your work and theirs meet | Mid. Branch managers would work with this role, and its coaching duty lands on their supervisors | Frame it as reciprocity: what you bring their branches, not only what you need from them |
| Pressure | Time-boxed case, devil's advocate | Low to mid. Twenty minutes is tight | Pause, restate, hold through two follow-ups |

## Graded deliverable: the 20-minute complaint-escalation case

The recruiter announced it, so it's graded. You don't know the scenario yet, so prepare the structure and run it against K1.

**Grounded facts to build on**

- The JD's own mandate: "Own the member complaints process end to end across branches and the contact centre", and "coach branch supervisors on escalations".
- The values the panel scores: Members First, Always, which means deciding from the member's side of the counter. Plain Words, which means that if a member needs it explained twice, it was written wrong. Neighbours, Not Numbers. Own the Fix, which means whoever finds the problem keeps hold of it until it's solved.
- Your own side, from F1 and F4: "I handled the branch's formal complaints log", and "trained new tellers on our escalation script". You can say you know the branch end of an escalation, but only at that scope.

**A 20-minute shape** `[generic]`

- **Minutes 0–3: clarify.** Who is the member? What have they already been told? Which channel did it come through? Is anyone vulnerable? What regulatory clock applies? What authority does the branch have?
- **Minutes 3–5: objective.** Fix it for this member, keep the rules, and stop it happening again.
- **Minutes 5–14: approach.** Contact the member first. Name one owner who keeps hold of it. Agree a dated next step. Write the reply in plain words.
- **Minutes 14–18: what the case teaches.** Find the cause, route it into the monthly report, and decide whether the supervisor needs coaching.
- **Minutes 18–20: close.** What the member experiences.

**Three defensible theses, each with its concession**

| Thesis | Concession you must say |
|---|---|
| One named person keeps hold of the escalation until it's solved. It's handed on, never passed off. This is Own the Fix applied to the process | In a five-hub model one person can't hold everything. Ownership needs a named handover, and the person finding the problem may not have the authority to fix it |
| Decide from the member's side first: contact them, say plainly what happens next and by when, then work the file. This is Members First and Plain Words | Speed can't override the facts or the rules. You won't promise an outcome before you know what happened |
| Every escalation is data. The cause goes into the monthly report and, if relevant, to the digital team's journey | One case isn't a trend, so say what you'd watch for before calling it one |

**Differentiation.** The standard answer is apologise, escalate, resolve, follow up. Go beyond it in three places: name who holds the escalation at each step, say the member-facing words out loud in plain language, and close the loop into reporting.

**The anti-pick, the thing to say no to:** closing the complaint as "resolved" to protect a resolution-time number when the member doesn't agree it's resolved. That's Neighbours, Not Numbers, said as a refusal.

**Close.** The recruiter didn't name a required close. End on what the member experiences.

## Values cheat sheet

The value names and definitions come from the text you copied from ashgrovecu.org/about/values on 12 November 2026. None of your quoted sentences tells a values story on its own, so each row is a selection scaffold that points at where in your material to look.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1, "I handled the branch's formal complaints log". Look for a complaint in that log where you can say what the member needed and what you decided. If none comes to mind, say so plainly and say how you would decide from the member's side in the K1 case |
| Plain Words | If a member needs it explained twice, the wording failed | F4, "trained new tellers on our escalation script". If, while training, you changed how something in the script was said so members understood it, that's your story; tell it in your own words. If not, say so plainly and show it live instead, by speaking plainly in the case |
| Neighbours, Not Numbers | Each branch belongs to its town | F7, "6 years in retail banking, the last 3 as a branch supervisor". Pick a time from those years when a member's situation mattered more than a target. If none comes to mind, say so plainly and answer H3, the hub question, from this value |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | F3, "I built the monthly complaints spreadsheet our regional manager uses." If you built it because you spotted a problem, say what the problem was and how you kept hold of it, in your own words. If you built it because you were asked to, say so plainly and pick another time you kept hold of a problem, or say none comes to mind |

### Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold from the log: what the member needed, what you decided, and what it cost or risked. Use "I" for your own part. If none comes to mind, say so plainly, then give how you would decide it | Members First, Always, in its own words. Expect the panel to use the value's phrasing. VAL because it's scored against the value |
| H2 | "Tell me about a time something had to be explained to a member twice." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: a time from your branch years, or from the teller training, when the words didn't land first time and what changed after. If none comes to mind, say so plainly and say what you'd check in a member letter | Plain Words, taken from its own definition. VAL because it's scored against the value |
| H3 | "We're moving from eight branches to five hubs. How does 'Neighbours, Not Numbers' survive that?" | VAL | [grounded] | It asks nothing about your past. Hold the tension honestly: you don't know their towns, so say what you'd ask first. Members whose branch closes are likely to complain, so complaints from those towns are worth tracking separately and reading by town. Concede that consolidation is decided, and that your job is how members experience it, not whether it happens | Two branch managers living through the 2027 consolidation are a likely source of this question. VAL because it tests the value under strategic pressure |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Use the Own the Fix row of the cheat sheet. If the spreadsheet started as a problem you spotted, tell that in your own words. If not, pick another instance, or say plainly that none comes to mind. Don't present the spreadsheet as a fix unless a problem came first | Own the Fix, in its own words. It's also the value the case is built on. VAL because it's scored against the value |

### Bank J: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You'd be coaching my supervisors on escalations. What would you need from me, and what would I get?" | JD | [grounded] "the last 3 as a branch supervisor" | Reciprocity first. What they'd get: someone who has been a branch supervisor for the last three years, plus a plan for coaching. What you'd need: time with their supervisors and their read on where escalations go wrong. Propose principles rather than pretending to know their branches | F4's requirement, asked by the people it lands on. JD because it scores the coaching duty |
| J2 | "When a complaint is the branch's fault, how does it show up in your report without becoming a league table?" | CASE | [generic] | Principles: report causes, not culprits; show branch figures to the branch first; pair any number with what's being done about it. This is Neighbours, Not Numbers applied to the JD's monthly report. Concede that some comparison between branches is unavoidable | Branch managers have the most at stake in a monthly complaints report. CASE because it scores live judgement, with values content |
| J3 | "Your team says a complaint is resolved and my branch says it isn't. What happens?" | CASE | [generic] | Go to the member: what do they say? Then agree on what "resolved" means before arguing about the case. Own the Fix: one person holds it until both sides agree, and the disagreement itself goes into the learning. Show spine and tact together: you won't close it just to end the argument | Disagreement between equals is the Peer persona's core probe. CASE because it's a live problem, not a past one |

### Bank K: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | Practice prompt: "A member has complained about the same issue at a branch and then by phone, and now wants someone senior. Walk us through what you do." | CASE | [generic] | Run the 20-minute shape from the case build: clarify, objective, approach with one named owner, what the case teaches, close. Name your clarifying questions aloud, including which regulatory clock applies. Say the member-facing words in plain language | A stand-in for the real case, which isn't known. It's built from the JD's branches-and-contact-centre line. CASE because it's the announced deliverable |
| K2 | "A self-service journey in the app is generating complaints. What do you do?" | CASE | [grounded] | Clarify: which journey, since when, and how many members. Then what the complaints say in members' own words. Then take that to the digital team as evidence, not as blame, and agree what changes and how you'd see whether it worked. The goal is to move service to digital without the self-service move costing members. Answer slot for F6: if you've worked with a digital team, mention it in your own words; if not, don't imply it | The JD's self-service line plus the 40%-by-2028 move. CASE because it's a live problem, and it covers F6 |

### Reverse questions: Round 3

| Question | Why it lands |
|---|---|
| "What would make this role useful to your branch in its first three months?" | It's reciprocity, aimed at peers who'd live with the role |
| "Where do escalations from your branch most often go wrong today?" | It lets them show you their real problem, which you can then reflect back |
| "How are you preparing members for the move to hubs?" | It respects that they're living the 2027 change and links it to complaints |
| "How do your supervisors feel about escalating today: quick to escalate, or slow?" | It tells you the coaching starting point, and it's practical |
| "Which of the four values is hardest to live up to in a branch day to day?" | It invites candour and shows you take the values beyond slogans |

---

## Prohibited claims

This pack won't coach the claims below. Each entry is built from the fit snapshot, because these are the claims a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the branch's complaints process | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation is that your material says the log, not the process. The F1 slots stay inside the log |
| Investigated or resolved regulated complaints | Inflated form of F1 and F5 | The same quote at its scope. Your material doesn't show who resolved complaints or which rules applied, so F5's slot stays inside the log |
| Wrote or designed the escalation script | Inflated form of F4, which says "our escalation script" | "I trained new tellers on our escalation script." |
| Coached supervisors | Inflated form of F4 | The same quote. Your material says tellers, not supervisors. E3's slot stays with what you have done |
| Produces the region's complaints reporting | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." Your material says you built it and the regional manager uses it, not that you report with it |
| Advanced or expert Excel | Inflated form of F8 | The same quote. Your material says spreadsheet, so F8's slot names the tool |
| Has worked in a contact centre | Negative you stated, F2 | "I haven't worked in a contact centre." |
| Has presented to senior leaders | Negative you stated, F9 | "I haven't presented to anyone above regional level." |

F6, digital work, isn't listed because your material says nothing about it either way. It stays an answer slot.

---

## Sources

**Provided documents**

- The JD you pasted
- The Ashgrove values text you pasted, copied from ashgrovecu.org/about/values on 12 November 2026. Not fetched by this pack
- The recruiter's email describing the three rounds
- Your summary of Ashgrove's 2026 strategy brief, published July 2026
- Your background, in your message

**Searches and fetches:** none were sent. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted, copied today, fixes the values cheat sheet and Bank H |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email establishes all three rounds: who runs each, the case and the values scoring. It fixes the loop and every persona weight |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 strategy brief, under six months old, supplies the priorities and the competitive frame for C1, C2, H3 and K2 |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names have been given or assigned, so there was no query to form. That's why there's no interviewer read |
| 5. representative `Member Experience Lead` JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-type questions |

---

## Upgrade menu

- **Interviewer names, once the recruiter assigns them:** a read of each interviewer's public professional footprint, persona weights tuned per person, and at least one reverse question tied to each interviewer's career path
- **Your own answers to the answer slots, stated here outside a drill:** F1, F3, F5 and F8 become fuller rows, and the questions that draw on them (A3, A4, D1, G1, H1, H4) become story-mapped instead of scaffolded
- **A sanitised sample of the monthly complaints spreadsheet, with column headers only and no member data:** an inspectable artifact behind F3 and F8 that could raise their confidence, plus concrete material for G1
- **The full text of the 2026 strategy brief, not a summary:** the grounding brief uses its own vocabulary and figures, and C1, C2 and K2 sharpen
- **Your CV:** dates, titles and any lines your message didn't carry join the evidence pool, which could open new fit rows
- **Hours available for prep:** the triage becomes a day-by-day schedule
- **A deeper research pass (L2), up to 6 more searches and 2 more fetches, several more minutes:** Ashgrove news since July 2026, public material on the Head of Member Services role once a name is known, and candidate reports on Ashgrove's loop
- **A tuesday-dossier.md from job-underwriter:** an evidence-verified version of E1's objection and a confirmed prohibited list. It's useful but not needed; this pack is complete without it
