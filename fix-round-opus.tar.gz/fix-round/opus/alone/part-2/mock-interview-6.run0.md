Reading the skill's reference files before building your three-round pack; a few more to go.
I've read everything I need. The web searches were refused by this session's permissions, so I'm building the pack from what you told me and labeling what that leaves out.
I've built one prep pack covering all three rounds: `larkfield-systems_engineering-manager_interview_pack.md`. It uses only the role description and the four sentences about yourself from your message. My web searches for Larkfield's published values, interview process and recent news were blocked by this session's permissions, so nothing in it comes from research.

- **Shared across all rounds:** a fit table matching the role's requirements against your own words, and a list of claims the pack won't coach. That list includes "I've managed managers" and "the reliability quarter caused the 60% drop", because your sentence says the drop came *after* the quarter, not because of it.
- **Per round:** persona weights with the reasoning shown, 9–12 practice questions, and reverse questions for that interviewer.
- **Highest-priority prep is A1, for Tuesday:** "You've led a team of six; this is two squads, eleven engineers and a hardware roadmap — why are you ready now?" L3 is the same objection as the VP will put it on Monday.
- **No values cheat sheet for Monday yet:** Larkfield's published values aren't in hand, so those questions are based on the recruiter's wording and standard behavioral questions.

Say the word and I'll play the Skeptic on A1 as a live mock interview, with real follow-ups and feedback.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job posting and your CV? Either one would let me check the requirements against the actual posting and turn several "pick a story" prompts into answers built on your real record. Without them, I'll keep working from what's here.
Would you like to allow web search so I can pull Larkfield's published values and current strategy? That would add the Monday values cheat sheet and replace the generic strategy questions with Larkfield-specific ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Loop:** three scheduled rounds (loop mode)

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel: technical peers plus a cross-functional partner |
| 3 | The following Monday | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

Built from your message only: the role description, the three rounds and four sentences about your background. No CV, no full job posting, and no web research (all three searches were refused in this session; see Sources). Interviewer names weren't given.

---

## How to use this pack

- **Personas** describe *how* a question is asked: the register, the pressure, who's asking. **Types** describe *what* gets scored.
- Type key:
  - **VAL**: behavioral and values. Does your past behavior show what this company says it values?
  - **EXP**: work-experience deep-dive. Do your claims hold up, and what was actually yours?
  - **JD**: role-driven. Can you do the job as listed, including its gaps?
  - **CO**: company and strategy knowledge. Can you think at the company's level?
  - **CASE**: a live problem from the role, structured and reasoned out loud.
- **Provenance labels:** `[grounded]` means traceable to what you told me. `[inferred]` means derived from it, with the derivation named. `[generic]` means a role-family pattern with no claim about you or Larkfield.
- **Answer slots** are instructions for the interview, not questions for this conversation. Each one names a probe you're likely to get and gives two honest branches. Either branch is a good answer.
- **Guidance is scaffolding, not a script.** Say it in your own words. Every claim about your past in this pack comes from one of the four sentences you wrote. Anything beyond those is yours to supply truthfully, or to decline.

---

## Prep triage

The calendar gives you three prep windows. Spend each one on the few things that pay off, in this order:

1. **Before Tuesday:** rehearse **A1** out loud until it's boring. It's the highest-ROI prep in the pack (see Round 1). Then **D1** (the 60% figure), **B1** (first 90 days) and **C1** (your 90-second arc).
2. **Before Thursday:** **D1** again, because staff engineers will go deeper on the 60%. Then **E1** (product versus reliability with the PM in the room) and **H1** (fleet incident). Fold in anything Tuesday surprised you with.
3. **Before Monday:** draft and rehearse **K1** (your leadership philosophy in two minutes), then **L3**, the pressure version of A1.

Everything else is insurance.

---

## Fit snapshot

Shared across all three rounds. Requirements are quoted from the role description in your message. The evidence column holds only your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (leading two squads) — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads, and the words stay there: "For three years I've been team lead of a team of six." It doesn't say how those six were organised. Answer slot: the two-squads line makes a probe on leading more than one group likely. If any of those three years meant leading across more than one group, say what it was and how, in your own words. If not, say so plainly and stay with the team of six. If asked about leading through other leads, the words are yours already: "I haven't managed managers." |
| F2 | "own delivery, hiring and growth for 11 engineers" (delivery) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote touches delivery, through a quarter you pushed through against roadmap pressure. It doesn't show how delivery was planned or tracked on your team. Words that stay inside it: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the "own delivery" line makes a probe on how you plan and track delivery for your team likely. If that's yours, say how, in your own words. If it sits with someone else, or there's no such practice, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | Your material says you run the loop for backend roles. The 40 counts interviews, not hires. Words: "I run our hiring loop for backend roles — about 40 interviews last year." Answer slot: the "own … hiring" line makes a probe on hire decisions and headcount likely. If hire or no-hire calls, or headcount planning, were yours, say which and how, in your own words. If they sat with someone else, or there was no such step, say so plainly and stay with the loop you run |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Three years leading a team of six touches growth but doesn't show it. Answer slot: the "growth for 11 engineers" line makes a probe on how you've grown engineers likely. If you've done that for your team, say what you did and how, in your own words. If not, say so plainly and say what you would do first |
| F5 | "partner with hardware and product on roadmap" (product) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote touches roadmap, a quarter pushed through against roadmap pressure. It doesn't say who you worked with on it. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if a product partner was part of that decision, say who it was and how it went, in your own words. If not, say so plainly and stay with the quarter as you described it |
| F6 | "partner with hardware and product on roadmap" (hardware roadmap) — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording can't close, and you've said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. Your negative is about *owning* such a roadmap. Whether you've worked alongside hardware teams at all is F7 |
| F7 | "partner with hardware and product on roadmap" (working with hardware teams) — role description in your message | none given | none | [grounded] | discovery | Your material doesn't say whether you've worked with hardware or firmware teams. Answer slot: the "partner with hardware" line makes a probe on this likely. If you've had any such working relationship, say what it was and what your part was, in your own words. If not, say so plainly and move to how you'd build one |
| F8 | "Lead two squads building device-management services" (the domain) — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Nine years in engineering, currently at a payments company. That isn't device management, and the words stay there. Answer slot: the "device-management services" line makes a probe on relevant system experience likely. If any of your work has touched device management, say what it was and your part. If none has, say so plainly and stay with what your nine years were |

**The 60% figure.** F2 and F5 rest on your on-call sentence. Its logical form is "dropped 60% *after* I pushed a reliability quarter through". That's a sequence, not a cause. Every bank below keeps it as "after" unless you know more.

### Requirement coverage

| Role requirement | Covered by |
|---|---|
| Lead two squads (F1) | A1, A2, B1, K3, L3 |
| Device-management services domain (F8) | C2, G3, H1, M1 |
| Own delivery (F2) | B2, B3, H2, M2 |
| Own hiring (F3) | D2, G2, J2 |
| Own growth for 11 engineers (F4) | B1, K4 |
| Partner with product on roadmap (F5) | B2, E1, E4, H2, J1 |
| Partner with hardware on roadmap (F6, F7) | A1, A4, B2, E4, H2 |
| Industrial IoT context (role description, not a requirement) | A3, C2, M1 |

---

## Round 1: Tuesday, hiring manager (Director of Engineering, 45 min)

### Persona weights

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of scale (six to eleven), the hardware roadmap, and why you're leaving payments | High. Hiring managers buy capability and de-risk gaps, and F1 and F6 are the visible gaps | Rehearse A1 until it's boring. Name the limit before it's asked for, then give a concrete ramp plan |
| Case / Strategist | Live problems from the role: first 90 days, a hardware slip, reliability versus features | High. The hiring-manager prior is case plus skeptic, and this person will be managing your delivery | Clarify, then objective, then approach, then risks. Think out loud and use the role's own words: squads, device-management, hardware partners |
| Conversational | Friendly opener: "walk me through your journey" | Mid. A 45-minute first round usually opens warm, and casual questions are still scored | A rehearsed 90-second arc built only from your four sentences |
| Data-Driven Prober | One or two pokes at the 60% and the 40 interviews | Low here, high on Thursday. A director may test one number | Know what you can and can't say about how each figure was counted |

### Bank

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led a team of six. This role is two squads, eleven engineers, and a roadmap shared with hardware. Why are you ready for that now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year" "I've never managed managers and never owned a hardware-adjacent roadmap" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | **The highest-ROI rehearsal in this pack.** **Beat 1, what you have, at its own scope:** three years as team lead of a team of six. You run the backend hiring loop, about 40 interviews last year. Your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. **Beat 2, the limits, named before they're asked for:** "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." **Beat 3, a plan, said as a plan:** what you'd learn first from the hardware side, and how you'd set up the two squads. **Follow-up 1:** "So the hardest parts are the ones you haven't done." Hold by going back to Beat 1 without adding to it. Concede specifically that the hardware side is where you'd be learning. **Follow-up 2:** "Why not hire someone who has?" Concede that someone who has owned a hardware-adjacent roadmap would start ahead on that part, then hold on Beat 1 and the plan. Never fold by inflating, so no "effectively two teams" | F1 and F6 are where the role presses hardest against what you wrote. A would-be boss will ask this in some form. JD because it scores the role's stated scope against your stated record |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pick a real one, not a disguised strength. Your own words give you two: "I haven't owned a hardware-adjacent roadmap" or "I haven't managed managers." Choose the one you actually expect to struggle with. Then give one sentence on why it matters in this role, and two or three concrete steps you'd take in the first months, framed as a plan | The Skeptic's signature stem. F6 and F1 give you honest answers, so there's no reason to reach for a fake weakness. JD because it scores self-assessment against the listed job |
| A3 | "Why leave payments for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | The pack doesn't know your reasons, and shouldn't supply them. Structure: what in this role draws you (name the lines of the role you actually care about), why this step now, and what you'd bring from payments. If your interest in industrial IoT is recent, say it's recent. A recent, specific reason beats a manufactured long-standing one | Motivation consistency is the Skeptic's other target, and F8 makes the domain move visible. JD rather than CO because without research the question scores fit to the role, not company knowledge |
| A4 | "This role partners with hardware on roadmap. Have you worked with hardware or firmware teams before?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | F7's answer slot: if you've had any working relationship with hardware or firmware teams, say what it was and your part, in your own words. If not, say so plainly. Either way, keep F6's words: "I haven't owned a hardware-adjacent roadmap." Then the plan: how you'd learn the hardware team's release rhythm and constraints, and where you'd want to be in the room early | F6 and F7 split one requirement into a stated negative and a silence, and the director will want both answered. JD because "partner with hardware and product on roadmap" is a listed responsibility |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your first 90 days with two squads and eleven engineers. What do you do?" | CASE | [generic] | Clarify first: what state are the squads in, are there squad leads, what's committed, and where are the hardware dependencies? Then structure: listen (one-to-ones with all eleven, sit in on each squad's rituals, meet hardware and product counterparts), learn the delivery picture, pick one visible fix agreed with the director, and set up growth conversations. Close with how you'd know it's working. This is a plan, so it makes no claim about your past | The most common hiring-manager case for a new EM. It also covers F4 (growth) and F1 (two squads) without leaning on your record. `[generic]` because it's a role-family pattern, not Larkfield's practice |
| B2 | "Hardware slips a release by six weeks. One of your squads' device-management features depends on it, and product still wants the date. What do you do?" | CASE | [generic] | Clarify: is the date customer-facing or internal, and what exactly depends on the hardware? Options: decouple (ship what doesn't depend on it, behind a flag), re-sequence the squad's work, or move the date with a clear trade-off written down. Name who decides: you bring options to product and hardware together rather than choosing alone. Name the risk you'd watch: the squad absorbing the slip as overtime | Tests the "partner with hardware and product on roadmap" line (F5, F6) live, which matters more given F6's gap. CASE because it's a decision, not a record |
| B3 | "On-call load is high and product wants features. How do you decide when a quarter goes to reliability?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Open with your one real example at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Keep "after", not "because", unless you know more. Then give the decision criteria you'd use going forward, said as how you'd decide, not as what you did: what signal says reliability is costing delivery, what you'd put in front of product, what you'd protect. Answer slot: if you used specific criteria to make that case, name them in your own words. If you didn't, say so plainly and give the criteria you'd use now | Your strongest story and the director's likely case meet here, so rehearse them joined up. CASE first, with EXP delivery for the example |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your journey so far." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | 90 seconds, built from these beats: nine years in engineering; the last three as team lead of a team of six; currently at a payments company; you run the backend hiring loop, about 40 interviews last year; your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. Close with why this role, which is A3's answer in one sentence. Fill in the early years in your own words, adding nothing you wouldn't defend under a follow-up | The opener of almost every hiring-manager round. EXP because a casual arc is still read against your record, and every beat here will be probed later |
| C2 | "What are you actually curious about in industrial IoT these days?" | CO | [generic] | Scored casually. Your material says nothing about IoT exposure, so don't fake depth. Say what you've read, looked into, or want to understand, in your own words. If it's new to you, say it's new and what you've done to learn it so far. Then turn it into a question back about their device-management services | A rapport-style question on the company's own domain. CO, and `[generic]` because research didn't run, so the pack can't supply Larkfield specifics |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the 60% on-call drop. How was it measured?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number slots, each in your own words: **how it was counted** (what "on-call burden" meant: pages, hours, incidents, or something else); **what it's sensitive to** (the comparison window, team changes); **the assumption behind it you'd defend least**, named before they do; **which part was yours** ("I pushed the quarter through" is what your sentence says). If you don't know exactly how it was counted, say so plainly. That's an honest answer, not a failure. Hold to "after". Claim cause only if you can show it | Every headline figure gets probed, and the director may start the probing that Thursday's staff engineers will finish. EXP because it tests attribution |
| D2 | "About 40 interviews last year. What does that loop look like, and what was yours to decide?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start at the quote: you run the hiring loop for backend roles, about 40 interviews last year. Describe the loop's stages in your own words. Answer slot: the role's "own … hiring" line makes a probe on decisions likely. If hire or no-hire calls, or changes to the loop's design, were yours, say which and how. If not, say so plainly and stay with running it. On the 40: say whether that's interviews you ran or interviews through the loop, as you actually know it | F3 is your most role-relevant management evidence, and a director hiring for "own … hiring" will test its edges. EXP because it scores what was actually yours |

### Reverse questions for the Director

| Question | Why it lands |
|---|---|
| "What would make you say, a year from now, that this hire was clearly right?" | Gets your future boss's scorecard in their own words, and shows you're thinking about outcomes rather than the offer |
| "How are the two squads set up today: do they have leads, and how do they split the device-management work?" | Directly settles the F1 question about leading through other leads, and shows you're already planning the structure |
| "Where does the partnership with hardware work well today, and where does it rub?" | Names your F6 gap as something you're actively investigating, not avoiding |
| "What's the biggest delivery risk the squads carry into next year?" | Signals that you'll own delivery, and gives you material for Thursday's panel |
| "How do you like to work with your EMs: cadence, what you want escalated, what you'd rather not see?" | The relationship question a would-be boss weights heavily, and the real answer tells you whether you want this job |
| "What does the rest of the loop focus on, so I can prepare well?" | Recruiter-safe, and it may surface whether the panel has a technical or case element |

---

## Round 2: Thursday, panel (two staff engineers and a product manager, 60 min)

### Persona weights

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Staff engineers test the seam between their technical leadership and yours. The PM tests whether you'll be a roadmap partner or a blocker | High. A panel blends each member's top personas, and both of these relationships are peer-like | Reciprocity framing (what you bring their work), seam principles rather than pretending to know the seam, disagreement with spine and tact |
| Data-Driven Prober | Staff engineers go two levels deeper on the 60% and the hiring loop | High. Technical peers price credibility by probing numbers | D1's slots, deeper. "I don't know" said plainly beats a reconstructed method |
| Case / Strategist | Live incident or planning problems from device-management work | Mid. A 60-minute panel has room for one or two scenarios | Clarify before structuring. Say who you'd pull in, including hardware |
| Values / Behavioral | The PM, as the cross-functional member, asks STAR-style stories about conflict and collaboration | Low to mid. Cross-functional interviewers tend to use behavioral questions | Use "we" for context and "I" for your contribution. Tell only endings that actually happened |

### Bank

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | (PM) "Product needs a feature, and your engineers want to pay down reliability. How do we sort that out together?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Lead with the principle, not the war story: shared visibility of the cost (on-call load as a delivery cost), a joint decision, and a trade-off written down. If you use your example, keep it at its scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." With a PM in the room, "against roadmap pressure" can sound adversarial, so follow it with what you'd do *with* a partner. Answer slot (F5): if a product partner was part of that decision, say how it went, in your own words. If not, say so plainly and stay with the principle | F5 is thin and the PM is the one person who will test it directly. CASE delivery with a peer framing |
| E2 | (Staff engineer) "When do you step into a technical decision, and when do you leave it to staff engineers?" | CASE | [generic] | Propose principles: you set the context and constraints, staff engineers own the technical call, and you step in when a decision is deadlocked, crosses squads, or carries delivery or people risk. If an example from your team of six comes to mind, tell it in your own words. If none does, say so plainly and stay with the principles | The core seam question for an EM with staff engineers. Their real question is whether you'll add to their load or reduce it |
| E3 | (Staff engineer) "Our roles sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Seam principles, not a claim to know their seam: technical direction is theirs, people and delivery commitments are yours, and the overlap (sequencing, quality bars) gets agreed explicitly. For disagreement: say it in private first, decide who owns the call, then commit in public. Pick a time you disagreed with a senior engineer and the relationship held. If no such time comes to mind, say so plainly, then give how you would handle it | The persona's signature stem, asked by the people you'd work alongside |
| E4 | (PM) "How do you handle credit when work spans hardware, product and your squads?" | VAL | [generic] | Pick a time shared work shipped and you made sure others got the credit. It needs a named piece of work, who did what, and what you said or did about credit. If no such time comes to mind, say so plainly, then give how you would handle it here. Say "we" for the work and "I" only for what you actually did | Credit-sharing is a standard Peer probe, and three-way partnership is in the role. VAL because it scores behavior, not capability |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | (Staff engineer) "What was actually in the reliability quarter, technically, and which parts did you do yourself?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your sentence names the quarter, not what was in it. Describe what was in it in your own words. Use "we" for the team's work and "I" for what you did: your sentence says you pushed the quarter through. If you don't remember a piece precisely, say so. Then reuse D1's slots on the 60%: how it was counted, the weakest assumption, and "after" rather than "because" | Staff engineers will test whether the story has technical substance and whether the credit is accurately split. EXP because it tests attribution |
| G2 | (Staff engineer) "How do you know your hiring loop works? What does it predict?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start at the quote: you run the backend hiring loop. Answer slot: if the loop has any measure of whether it works (calibration, follow-up on how hires did), say what it is, in your own words. If there's no such measure, say so plainly and say what you'd want to measure at Larkfield. Don't describe a calibration practice you didn't run | F3 means the staff engineers will price whether you'd raise or lower their hiring bar. EXP because it probes the edge of the claim |
| G3 | (Staff engineer) "How do you stay technical enough to make good calls on device-management services?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start with nine years in engineering, three as team lead, at a payments company. F8's answer slot: if any of your work has touched device management, say what it was and your part. If none has, say so plainly and say how you'd get close to the systems: reading the services' design docs, sitting in on incident reviews, pairing with the staff engineers in this room | F8 is the domain gap, and staff engineers own the domain you'd be joining. JD because "building device-management services" is the role's first line |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | (Staff engineer) "An update our device-management service pushed overnight takes a slice of the fleet offline. You're the EM. Walk us through the next 24 hours." | CASE | [generic] | Clarify scope (how many devices, which customers, is it still spreading?). Then stop the bleed (halt the rollout), assign roles (incident lead, comms, investigation), and bring in hardware or firmware early. Then customer communication through the right owners, recovery, and a blameless review with follow-ups that get scheduled. Your role: unblock, protect the responders, own the communication upward. Not debugging | A plausible device-management incident, set in the role. `[generic]` because the pack has no Larkfield incident history |
| H2 | (PM) "Two squads, and asks coming in from hardware, product and support. How would you run planning?" | CASE | [generic] | Clarify: what's the planning rhythm today, and how do the hardware release dates land? Structure: one shared intake, explicit capacity per squad including on-call and reliability time, hardware dependencies marked on the plan, a single trade-off conversation with product, and what you'd publish so support knows what's coming | Tests F2 (delivery), F5 and F6 together, live, with the PM in the room. CASE because it's a process to design, not a record |
| H3 | (Staff engineer) "How would you run on-call across two squads for these services?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Principles: rotation design, a page-quality bar, and on-call load tracked as a delivery cost and reviewed with the team. Keep your one example at its scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: if you changed how on-call ran on your team, say what you changed, in your own words. If not, say so plainly and stay with the principles | Your strongest example sits right next to this question. Practise not over-extending it into on-call practices you never described |

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | (PM) "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on your sentence: a reliability quarter, pushed through, against roadmap pressure, and the team's on-call burden dropped 60% after. Answer slot: the question asks about leadership, so expect a probe on who the pressure came from and how you made the case. If it was a conversation with leadership, say who and how, in your own words. If it wasn't, say so plainly and tell it as it was. Don't supply a confrontation that didn't happen | A standard behavioral stem, and your one story already has the beats. VAL because it scores behavior under pressure |
| J2 | (PM or staff engineer) "Tell me about a hire you got wrong, or nearly did." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Pick an actual case from the backend loop you run: what the signal was, what you missed or caught, and what changed afterwards. If no such case comes to mind, say so plainly, then give how you'd catch one in your own loop | Honesty about hiring mistakes is a common EM probe given F3. VAL because it scores candor, not capability |

### Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "What could a new EM do in their first month that would genuinely help your work?" | The reciprocity question. It turns the panel into what *they* need, which is what peers are scoring |
| (Staff engineers) "Where does the device-management platform hurt most today: reliability, delivery speed, or something else?" | Shows you're already thinking about their pain, and gives you material for Monday |
| (Staff engineers) "How are technical decisions across the two squads made today, and where does that break down?" | Shows you'll respect their seam rather than taking it over |
| (PM) "How does the roadmap get negotiated between product and hardware today?" | Puts F6 into investigation mode, and the PM will notice |
| (PM) "What would you want from an EM partner that you don't get today?" | Reciprocity for the cross-functional partner |
| "What's something about working here you only learned after joining?" | Usually draws out candid answers about culture and process |

---

## Round 3: Monday, VP Engineering ("values and leadership philosophy", 30 min)

The recruiter's words make this a values-style round. Larkfield's published values aren't in hand (the search was refused), so this pack has no values cheat sheet. The VAL questions below are themed on the recruiter's words and on standard behavioral stems. See the upgrade menu.

### Persona weights

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your philosophy?" plus scenario and story probes | High. The recruiter described the round in these words | Two or three principles you actually hold, each backed by one real example. Where you have no example, say so |
| Pressure | Time-boxed challenges: "sixty seconds", "how much was you" | Mid. The skip-level prior is altitude plus composure, and 30 minutes forces short answers | Pause, restate, hold through two follow-ups, concede specifically |
| Case / Strategist | One strategy-altitude question about the business | Low to mid. A VP may test whether you think beyond the team | Think out loud and ask what they see. Don't assert Larkfield facts you don't have |

### Bank

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What's your leadership philosophy, in a couple of minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" "I run our hiring loop for backend roles — about 40 interviews last year" | The pack can't supply your beliefs, so choose two or three principles you actually hold and draft them before Monday. Each needs one example. Two quotes can carry one: the reliability quarter, pushed through against roadmap pressure, and your team's on-call burden dropped 60% after; and running the backend hiring loop, about 40 interviews last year. For any principle neither carries, pick a real moment from your three years as lead. If none comes to mind, state the principle as how you intend to lead, not as a record | The recruiter named this round's topic, so this question is close to certain. VAL because the round is scored on values |
| K2 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on your sentence: the quarter, pushed through against roadmap pressure, and the drop after. Answer slot: expect a probe on who applied the pressure and how the relationship came out. If someone senior was involved, say who and how it ended, in your own words. If not, say so plainly and tell it as it was | A classic values stem with no recruiter detail behind it. It's here because your strongest story fits its shape, as long as you don't add a stake it didn't have |
| K3 | "How do you think about going from leading a team to leading through others?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I've never managed managers and never owned a hardware-adjacent roadmap" | Say it plainly first: "I haven't managed managers." Then three years as team lead of a team of six. Then your philosophy for the step, said as an intention: what you'd delegate, how you'd develop leads, how you'd keep context without micromanaging. A VP scores the self-awareness as much as the plan | F1's gap at VP altitude. VAL first (leadership philosophy) with JD content |
| K4 | "Tell me about a time you gave hard feedback to someone on your team." | VAL | [generic] | Pick a real one from your three years as lead. It needs the situation, what you said, how it landed, and what happened after. If no such time comes to mind, say so plainly, then give how you would handle it | The "growth for 11 engineers" line (F4) makes people development a likely VP probe. `[generic]` because your material doesn't carry this story |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, then three beats in under a minute: three years leading a team of six; the backend hiring loop you run, about 40 interviews last year; the on-call burden that dropped 60% after the reliability quarter you pushed through. Then one line on the outside view you'd bring from payments. Don't claim you know anything about their internal candidates | The persona's signature time-box, which suits a 30-minute round. JD because it scores fit to the role |
| L2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold, then concede. Hold: "It was my team's on-call burden, and I pushed the quarter through." Concede specifically: the work was the team's, and the drop came after the quarter. Say plainly what else might have contributed, if you know. Through two follow-ups, never take credit for the team's engineering and never upgrade "after" to "because" | The persona's attribution stem, aimed at your one headline figure. EXP because it tests what was yours |
| L3 | "You've never managed managers. Why should I give you two squads?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A1 under pressure. Agree with the fact: "I haven't managed managers." Hold on three years as team lead of a team of six, then give the plan for the first quarter. Follow-up: "So you're learning on our time." Concede that parts of it, yes, and name which. Hold that the plan and the evidence are real | The skip-level version of the pack's highest-ROI objection. JD because it scores readiness for the listed scope |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Where does device-management software matter most to a business like ours?" | CO | [generic] | Think out loud. Don't assert anything about Larkfield's business. Structure: who the device-management services serve, what goes wrong for them when it fails (downtime, field visits, security), and where engineering quality turns into customer value. Then turn it around: "How do you see it?" | A VP tests altitude. CO and `[generic]` because research didn't run. This is the slot strategy research would sharpen most |
| M2 | "If you had to cut one of your squads' commitments next quarter, how would you decide?" | CASE | [generic] | Clarify what forces the cut. Criteria: customer impact, dependencies (especially hardware), reversibility, and team load. Who you'd involve (product, hardware, the director). How you'd communicate it to the squad. A plan, so it makes no claim about your past | Delivery judgement at altitude (F2). CASE because it's a live decision |

### Reverse questions for the VP

| Question | Why it lands |
|---|---|
| "What do you expect from your EMs that's hardest to find?" | A values-round VP gets to state their values directly, and you get the real bar |
| "Where is engineering heading over the next year or two, and what does that ask of these two squads?" | Shows altitude, and it substitutes for the strategy research this pack couldn't do |
| "When an EM here disagrees with a roadmap decision, what does good look like to you?" | Ties to your reliability-quarter story without restating it, and tests their culture |
| "How do you think about growing engineers into leadership here?" | Matches the role's "growth" line and your own next step |
| "What would you want me to have learned by my first review?" | A forward-looking close that signals coachability |

---

## Prohibited claims

What this pack won't coach, and why. These hold in every round and every drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | The plain acknowledgment F1 gives: "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't owned a hardware-adjacent roadmap." No slot |
| Has led two squads, or eleven engineers | Inflated form of F1 | F1's quote at its own scope: three years as team lead of a team of six. The limit is the pack's observation: your material says one team of six. F1's slot stays inside those three years |
| Owned hiring decisions or headcount | Inflated form of F3 | F3's quote at its own scope: you run the backend hiring loop, about 40 interviews last year. D2's and G2's slots stay inside the loop. The 40 counts interviews, never hires |
| The reliability quarter caused the 60% drop | Inflated form of F2's quote, which says "after" | The quote's own logical form: the burden dropped 60% after the quarter. D1 and L2 keep it as "after" unless you know more |
| Owned the team's roadmap, or negotiated it with product | Inflated form of F5 | F5's quote at its own scope: you pushed a reliability quarter through against roadmap pressure. E1's slot asks only whether a product partner was part of that decision |

---

## Sources

**Provided documents:** your message (the role description, the three rounds, and four sentences of background). No CV, posting or dossier was provided.

**Searches sent (all refused: web search permission was not granted in this session):**

1. `Larkfield Systems industrial IoT values`: refused
2. `Larkfield Systems engineering manager interview process`: refused
3. `Larkfield Systems IoT device management news 2026`: refused

No fetches were sent.

**Loop:** established by your own words (three rounds, each with who runs it and its length). The values-style round is detected from the recruiter's description of Monday, as you relayed it.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have supplied the values cheat sheet for Monday, and VAL questions mapped to Larkfield's own value names |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have checked for case or technical formats in the panel. Your words already establish the three rounds, so persona weights don't depend on it |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The search was refused. It would have grounded M1, C2 and the VP reverse questions in Larkfield's current priorities instead of `[generic]` patterns |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form. There's no interviewer read, and reverse questions are role-based |
| 5. Representative Engineering Manager JD | skipped | The role description you supplied fixes the fit snapshot's requirements and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search in this session:** Larkfield's published values become a Monday cheat sheet (each value mapped to F1 to F8 or to a selection scaffold), and M1, C2 and the VP reverse questions move from `[generic]` to Larkfield's current strategy
- **The full job posting:** each "role description" requirement is checked against the posting's actual list, and any mid-list items (named tools, on-call expectations, location or travel terms) get their own rows and questions
- **Your CV:** more than four sentences to draw on. Several selection scaffolds (E3, E4, J2, K4) become story-mapped answers, and F2, F4, F5 and F7 may move out of `discovery`
- **Interviewer names:** a read of each interviewer's public professional footprint, persona weights tuned per person, and at least one reverse question tied to each interviewer's own path
- **The recruiter's guidance** (usually one email): whether the panel includes a case, system-design or technical element, and anything Monday's VP is known to focus on. A pre-declared exercise would get its own build section
- **Your answers to the answer slots** (outside a drill): F1, F2, F3, F4, F5, F7 and F8 regenerate with your words as evidence
- **Deep research (L2):** up to 6 more searches and 2 more fetches, several more minutes, covering a Larkfield strategy brief, interviewer talks and writing, candidate reports on this loop, and recent org changes. This mainly sharpens M1 and the Monday round. It only runs if you ask, and needs web search allowed
- **A tuesday-dossier.md from job-underwriter:** the highest-ROI objection would come from evidence you've confirmed rather than being inferred here, and each weak area would carry an agreed strategy. This pack is complete without one
