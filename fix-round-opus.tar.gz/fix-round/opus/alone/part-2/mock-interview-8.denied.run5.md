Pack is written; I'm fixing a few lines where the wording went past what you actually told me, then I'll hand it over.
Dara, your prep pack is saved as `ashgrove_member-experience-lead_interview_pack.md`. It has a separate section for each of the three rounds on 21 November, as the recruiter described them. I worked only from what you sent me (the JD, the values, the recruiter's email, your summary of the strategy brief and your background), and I didn't run any web searches.

What's in it:
- **A fit table.** It sets each JD requirement against your own words. Your two stated gaps, the contact centre and presenting above regional level, are treated as gaps. Each has a plain answer and a plan; neither is papered over.
- **The highest-value question to practise is E1** (Round 2, Head of Member Services): "You've handled one branch's complaints log and you haven't worked in a contact centre — why should I believe you can own the whole thing?" The pack scripts a calm answer and two likely follow-ups.
- **A prep section for the 20-minute case.** It gives a structure, three positions you could take and what each one has to concede, what to avoid, and how to stand out from the standard "apologise, investigate, resolve" answer.
- **A values sheet** for the panel, with one question for each of the four values.
- **Questions to ask them**, five for each round.
- **A list of claims the pack won't coach.** For example, "managed a branch" or "wrote the escalation script".

Several rows have an "answer slot": a point where only you know what happened. Two examples are what your monthly spreadsheet actually tracks, and whether your branch's formal complaints came under a regulator's rules. Decide your honest answer to each before the 21st. If you tell me those answers, I'll rebuild those rows around your own words.

Say the word and I'll play the Head of Member Services on E1, with real follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of interviews:** 21 November 2026, three rounds on one day (loop mode)
**Round 1:** 30 minutes with the recruiter
**Round 2:** 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural
**Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case; this is the values round, scored against the four values
**Interviewer names:** not yet assigned, so there is no interviewer read in this pack

---

## How to use this pack

- **Personas** describe *how* a question will be asked (friendly, sceptical, pressured, collegial). **Types** describe *what* is being scored. Rehearse both: the same question feels different from a friendly recruiter than from a sceptical manager.
- **Guidance is scaffolding, not a script.** Every claim about your past in this pack is either one of your own sentences, quoted, or an **answer slot**: an instruction to answer from your own experience in your own words, with an honest branch for when the thing never happened. Fill slots from memory, never from what sounds good.
- **Provenance labels:** `[grounded]` = traceable to what you gave me (JD, values, recruiter email, strategy brief, your background); `[inferred]` = this pack's derivation, with the derivation named; `[generic]` = a common pattern for this kind of role, not a fact about Ashgrove.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's four published values, not generic virtue |
| EXP | Whether what you say you did survives a close look at what was actually yours |
| JD | Whether you can do the listed job, including the parts you haven't done |
| CO | Whether you know where Ashgrove is going and can think at its level |
| CASE | How you structure a live problem from the actual job |

Question IDs: Round 1 = A, B, C. Round 2 = D, E, G, H. Round 3 = J, K, L, M. Fit-snapshot rows are F1 to F9.

---

## Prep triage: nine days to 21 November

In order. Do these well and stop.

1. **E1, the highest-ROI rehearsal in this pack.** Say the hold and the concession aloud until they bore you. Then have someone ask the two follow-ups.
2. **The answer slots in the fit snapshot (F1, F3, F4, F5, F7, F8, F9).** For each, decide now which branch is true for you, in one sentence of your own. These are where the interviewers will probe.
3. **The complaint-escalation case build** and L1, L2. Practise the structure out loud against a timer, 20 minutes.
4. **Values cheat sheet + J1 to J5.** One real story per value, picked by the scaffold. The panel scores these.
5. **A1, your 90-second arc.** It opens all three rounds in some form.
6. **Reverse questions**: pick two per round.

Everything else is insurance.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal log, not a process across branches. Keep the words at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" line makes a probe on the stages of a complaint likely. If any stage of a complaint at your branch, from arrival to close, was yours to handle beyond the log, say which and how, in your own words; if it was not, say so plainly and stay with the log you handled. Expect a probe: this is a line from your message with nothing behind it to inspect |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says you built a monthly complaints spreadsheet that your regional manager uses; it does not show what it counts or who reports from it. The derivation: monthly and complaints match the JD, volumes and resolution times are not stated. Answer slot: if the spreadsheet counts complaint volumes or resolution times, say what it counts, in your own words; if it does not, say so plainly and describe what it does hold. Keep "our regional manager uses" exactly: it is their use, not a report you delivered |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the escalation script, not that you coached supervisors, and it says "our" script. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you trained likely. If any part of how that training ran was yours to decide, say which and how; if the format was set for you, say so plainly and describe how you trained |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. Answer slot: if you have worked with a digital or online-banking team on anything, say what and what your part was, in your own words; if you have not, say so plainly and say how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap: six years clears four. Say it in your own terms and let the interviewer do the mapping: "Six years in retail banking, the last three as a branch supervisor." Don't relabel it with the JD's "customer operations" phrase. Expect a probe on what the work involved |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your sentence says "formal" complaints; it does not say whether they fell under a regulator's complaint rules. The derivation: formal logs are where regulated complaints usually sit, which is a pattern, not your fact. Answer slot: if those complaints followed rules a regulator set, say which rules and what they required of you, in your own words; if you don't know, or they did not, say so plainly and describe the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have said so. Words: "I haven't presented to anyone above regional level." Your sentence does not say you have presented at regional level, so the pack does not assume it. Answer slot: if you have presented at regional level, say what and to whom, in your own words; if you have not, say so plainly. Then how you would prepare, said as a plan |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says "spreadsheet", not which tool. Answer slot: if you built it in Excel, say so and say what it does, in your own words; if it was another tool, name it plainly and say what you'd need to learn |

---

## The loop

The recruiter's email establishes the loop: three named rounds on one day, each with who runs it and what it holds. Persona weights below follow those rounds, not a guessed pattern. The values round is documented (the panel scores against the four values), so the values cheat sheet sits with Round 3.

---

## Grounding brief: Ashgrove's vocabulary

From the materials you gave me. Use these words; don't recite them.

| Item | What it says | Source | Provenance | How to use it |
|---|---|---|---|---|
| Ownership | Member-owned, about 900 staff | JD | [grounded] | Say "members", never "customers", in every round |
| Digital shift | Move 40% of member service to digital channels by 2028 | July 2026 strategy brief, as you summarised it | [grounded] | The JD's digital line (F5) sits inside this. G2, C1 |
| Branch footprint | Consolidate eight branches into five hubs over 2027 | July 2026 strategy brief, as you summarised it | [grounded] | The panel are branch managers living through this. J5, K2, reverse questions |
| New product | Small-business lending product in Q1 2027 | July 2026 strategy brief, as you summarised it | [grounded] | Worth one reverse question in Round 2; don't build answers on it |
| Competition | Main pressure is app-only banks | July 2026 strategy brief, as you summarised it | [grounded] | C1, G2: the case for complaints handled well as something an app-only bank finds harder to copy is your own argument to make, offered as a view |
| Values | Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | ashgrovecu.org/about/values, as you copied it on 12 November 2026 | [grounded] | Use the exact names in Round 3 |

---

## Round 1: Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly opener, "walk me through", motivation | High: a 30-minute recruiter screen is mostly this, and it is still scored | Pre-scripted 90-second arc (A1); treat every casual question as scored |
| Skeptic (light) | Checks the JD's listed requirements one by one | Medium: recruiters screen against the requirements list, often literally | Short, plain answers on F2, F6, F7; save depth for Round 2 |
| Case / Strategist | "What do you know about us?" | Low: one homework question is likely in a short screen | Two strategy points, tied to the role |

### Question bank

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, only these beats, in your own words: six years in retail banking; the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Close with why this role. Answer slot: say what is drawing you to it, in your own words. Don't volunteer the contact-centre gap here; answer it plainly when asked (B3) | Every round opens with some version of this, and the arc sets up F1, F3, F4 and F6. EXP because the recruiter is checking the story matches the CV |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Answer slot: if something in your own banking work drew you to a member-owned model, say what, in your own words; if your reason is about where you want to go rather than where you have been, say that. Then one value, by its exact name, and why it matters to you. Don't claim to know how Ashgrove works inside | Motivation consistency is the recruiter's main check. CO because the answer shows whether you've read their values page and JD |
| A3 | "Why move on from the branch now?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Toward, not away. Answer slot: say your real reason in your own words; if part of it is wanting to work on complaints across more than one branch, say that. Never criticise your current employer | A predictable knockout check; JD because the honest answer ties to the role's scope (F1) |
| A4 | "This role works across branches and the contact centre. How do you feel about splitting your time across sites?" | JD | [generic] | Answer the real question: yes or no, and any limits, plainly. The question needs no claim about your past, so don't make one | The JD's "across branches and the contact centre" raises it; generic because the JD doesn't say how the time splits, and you can ask (Round 1 reverse question 4) |

**Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for four-plus years in financial-services customer operations. How does your background match that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say the sentence: six years in retail banking, the last three as a branch supervisor. Stop there and let the recruiter tick the box. Don't restate it in the JD's words | F6 has no gap; the only risk is over-talking a box that's already ticked |
| B2 | "Have you handled regulated complaints?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what you did: you handled the branch's formal complaints log. Answer slot: if those complaints followed rules a regulator set, say which and what they required of you; if you don't know, or they didn't, say so plainly and stay with the log. Never say "regulated" about them unless you know it's true | F7 is the requirement a recruiter is most likely to check literally. Inferred because "formal" doesn't show "regulated", and this pack can't fill that gap for you |
| B3 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't worked in a contact centre." Then one sentence of plan: how you'd learn it in your first weeks. Then stop. Keep it short here; the deep version is E1 for Round 2 | F2 is a stated gap against a headline JD line. A short, calm answer here keeps it from becoming the theme of the day |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Two points from the brief, in plain words: 40% of member service moving to digital by 2028, and eight branches becoming five hubs over 2027. Then one sentence linking them to the role, offered as your view or as a question: changes like these are when complaints processes get tested. Mention app-only banks as the pressure if there's time | The recruiter sent you the brief, so they will expect you to have read it. CO by definition |
| C2 | "If you started next month, what's the first thing you'd want to look at?" | CASE | [generic] | Structure: the complaints data first (volumes, how long they take, where they come from: which branches, contact centre, digital), then sit with the people handling them, then the escalation path. Say it as a plan. Ask what reporting exists today rather than assuming | A soft case to see if you think in the role's terms; generic because nothing in your materials says what Ashgrove's current reporting looks like |

### Reverse questions, Round 1

| Question | Why it lands |
|---|---|
| "Is the 20-minute case on the panel given on the day or in advance, and is it spoken or written?" | Practical, and it changes how you prepare the case build |
| "Is there anything the panel uses to score against the four values that I could read beforehand?" | Shows you took "scored against the four values" seriously |
| "What happens after 21 November, and when would I hear?" | Logistics a recruiter expects and respects |
| "How would the role's time split between branches and the contact centre?" | Turns A4 into information you need |
| "What made Ashgrove open this role now?" | Often reveals what the hiring manager will care about in Round 2 |

---

## Round 2: Head of Member Services (your future manager), 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" stories | High: the recruiter said this round is mostly behavioural, which overrides the usual hiring-manager tilt toward cases | One real story per likely theme, chosen by the scaffolds below; "we" for context, "I" for what you did |
| Skeptic | Quiet probing of the scope jump and the two stated gaps | High: a future manager is buying derisking, and F1, F2 and F8 are the gaps they'll see | E1 rehearsed until boring; plain concessions, then plans |
| Case / Strategist | One or two live problems from the role | Medium: "mostly behavioural" leaves room for some | Clarify, then structure, then answer |
| Data-Driven Prober | "Walk me through the spreadsheet" | Low to medium: the JD's monthly reporting and Excel lines point at F3 and F9 | Know exactly what the spreadsheet does and doesn't do |

### Question bank

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a complaint was escalated to you and you had to decide what to do." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick one complaint from your time handling the branch's formal log where the call was yours: it needs what the member wanted, what you decided, and what happened next. Tell it in your own words, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's escalation line makes this near-certain. VAL because the manager will hear it against "Members First, Always" and "Own the Fix"; F1 is the pool to pick from |
| D2 | "Tell me about a time you helped someone get better at handling difficult members." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: new tellers, trained on the escalation script. Those are the beats your sentence states; tell them in your own words and keep "our" script. Answer slot: the JD's coaching line makes a probe likely on what happened after training. If you watched a teller handle a real escalation afterwards and gave feedback, say how; if training was the script and nothing more, say so plainly and describe how you trained | F4 is your nearest evidence for coaching supervisors; this is the behavioural version. VAL delivery, JD content |
| D3 | "Tell me about a time you saw a problem nobody had asked you to fix." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3: you built the monthly complaints spreadsheet; your regional manager uses it. Answer slot: if you built it because you saw a gap, say what the gap was and how you noticed it; if you were asked to build it, say so plainly and tell it as a job you did well. Don't invent the origin | "Own the Fix" is a published value and this manager will know it; F3 is your one sentence that may carry it, if the slot's first branch is true |
| D4 | "Tell me about a time a member didn't understand something and you had to explain it differently." | VAL | [grounded] | Selection scaffold, themed on "Plain Words". Pick a time a member needed something explained twice: what they didn't get, what you changed in how you said it, and whether it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A published value, and the role writes member-facing journeys with digital teams. Grounded on the values page; the story has to be yours |

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "This role owns complaints across every branch and the contact centre. You've handled one branch's complaints log, and you haven't worked in a contact centre. Why should I believe you can own the whole thing?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** Hold only what your sentences carry: "I handled the branch's formal complaints log and trained new tellers on our escalation script. I built the monthly complaints spreadsheet our regional manager uses." Name the limit before it is pushed: "I haven't worked in a contact centre." Then the plan, said as a plan: in the first weeks, sit alongside the contact-centre team, listen to complaint calls, and follow a few complaints from first contact to close. Follow-up 1, "So what do you actually know about contact-centre complaints?": "Not from doing it," then what you'd want to learn first. Follow-up 2, "Why not hire someone from a contact centre?": hold, they would bring something you don't, and say what your sentences say you bring. Don't fold on the log, the training or the spreadsheet. Never say "complaints are complaints", and never call the log "running complaints" | F1 and F2 meet here: the JD's headline line asks for exactly the two things your material shows least. A future manager will ask this in some form. JD because it scores the stated requirement head-on |
| E2 | "You'd be reporting to senior leaders every month. You've told us you haven't presented above regional level. How will that go?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold, then concede, then plan. "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and to whom; if you have not, say so plainly. Then how you'd prepare: a draft run past your manager first, a rehearsal, one page leading with what changed and what you need from them. Don't claim confidence you haven't earned; say what you'd do to earn it | F8 is a stated gap against a listed requirement. The question's negative comes from your own sentence; you'd likely be asked it once you name it in B3 or E1 |
| E3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one, honestly, and give a plan. The contact centre (F2) or senior presenting (F8) both have your own words behind them. Or F5, digital: answer slot, if you have worked with a digital team, this isn't your pick; if you haven't, say so plainly and say how you'd start. Don't pick a fake weakness | A classic Skeptic stem; your stated gaps make the honest answer easy, which is the point. JD because the answer must name a listed requirement |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Suppose average resolution times went up 20% last quarter. How would you work out why?" | CASE | [generic] | Clarify first: across all channels or one? All complaint types? Was anything counted differently? Then split: by channel (branches, contact centre, digital), by type, by branch. Look for one source driving it before assuming a general slowdown. Then what you'd do about it and how you'd report it. Think aloud | The JD's "resolution times" line makes a version of this likely. Generic because it is a hypothetical, not a fact about Ashgrove |
| G2 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] | Your view, structured: complaints will arrive through new channels; some will be about the digital journey itself; the self-service journeys are where "Plain Words" applies first. Offer one idea: complaint reasons as input to the digital teams. Then ask what the digital team works with today | The brief and the JD's digital line both point here. CO because it tests whether you think at the strategy's level |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you built and who uses it, in those words. Answer slots: the JD's monthly-reporting line makes a probe likely on what it counts. If it counts volumes or resolution times, say what and how, in your own words; if it doesn't, say so plainly and describe what it does hold. The JD's Excel line makes a probe on the tool likely: if it's Excel, say so; if not, name the tool plainly. Don't describe features it doesn't have | F3 and F9 both rest on this one sentence, so it will be probed. Inferred because what the spreadsheet counts is not in your material |
| H2 | "How would you tell whether a complaint was resolved well, not just closed?" | JD | [generic] | Your thinking, as a plan: did the member come back with the same issue, did they get a plain-words answer, how long it took, and whether the cause was fixed. Answer slot: if you tracked any of this at your branch, say what; if you didn't, say so and give the plan | The JD's resolution-times line invites a "times aren't everything" probe. Generic because these are common measures, not Ashgrove's |

### Reverse questions, Round 2

| Question | Why it lands |
|---|---|
| "Is the complaints process today one process across branches and the contact centre, or several?" | It's the job's starting point, and the answer tells you what "own end to end" means here |
| "When eight branches become five hubs over 2027, what do you expect to happen to complaints?" | Uses their own strategy, and asks rather than tells |
| "Who reads the monthly complaints report, and what decisions does it drive?" | Shows you think of reporting as a tool for decisions, which links to F3 |
| "Where do complaints and the digital self-service work meet today?" | Covers F5 honestly by asking how it works here |
| "What would make the first six months a success for you?" | Standard for a future manager, and the answer is your onboarding plan |

---

## Round 3: Panel of two branch managers, 60 minutes, values round, with a 20-minute case

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Story questions mapped to the four values | High: the recruiter said the panel scores against the four values | One story per value from the cheat sheet; exact value names |
| Case / Strategist | The 20-minute complaint-escalation case | Certain: the recruiter announced it | The case build section below; clarify before structuring |
| Peer Evaluator | "What does this mean for my branch?" | Medium: they're branch managers whose supervisors you'd coach | Reciprocity: what you bring their branches; seam principles, not turf |
| Pressure | A sharp challenge on your scope | Low to medium: two interviewers make a sharper challenge more likely | Pause, restate, hold through two follow-ups, then concede what's real |

### Graded deliverable: the 20-minute complaint-escalation case

**Facts about you to build on:**
- F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- F3: "I built the monthly complaints spreadsheet our regional manager uses."
- F6: "6 years in retail banking, the last 3 as a branch supervisor."

**Structure (say it out loud first):** clarify what you know → what outcome the member needs → who owns it now → what you'd do today → what you'd fix so it doesn't recur → how you'd record and report it.

**Clarifying questions worth asking at the start** `[generic]`: What has the member been told or promised already? How many times and through which channels have they complained? Is there a deadline or a formal process this complaint must follow (ask; don't assume Ashgrove's rules)? Is the member in a vulnerable situation? Who currently holds the complaint?

| Thesis | Concession you must make | Value it shows |
|---|---|---|
| Fix the member's problem first, then the process. One named person keeps hold of it until it's solved | Speed can't skip a proper look at the facts, and any formal complaint rules come first | Members First, Always; Own the Fix |
| An escalation is a chance to coach the supervisor, not just a handoff upward | Sometimes you take it over yourself: when the member asks for someone senior, or the supervisor is stuck | Own the Fix |
| Every escalation is data: record it, look for a pattern, feed the monthly report and the digital teams | One case is not a trend; don't redesign a process on one complaint | Plain Words; Own the Fix |

**Differentiation:** the consensus answer is "apologise, investigate, resolve, follow up". Every prepared candidate will say it. Go beyond it on three points: (1) say *who* keeps hold of the complaint, by role, and when it passes (Own the Fix); (2) write the member's reply in plain words and say one sentence of it aloud (Plain Words); (3) close with what you'd change so it doesn't happen again, and how it shows up in the monthly report.

**The anti-pick:** don't promise an outcome or compensation before you know the facts, and don't take the complaint away from the branch supervisor in front of the member. Saying what you *wouldn't* do shows judgement.

**Close:** end on the member: what they'll hear from you, from whom, and by when.

### Question bank

**Values / Behavioral** (the scored part; see the cheat sheet)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Members First, Always. Tell me about a time you decided something from the member's side of the counter, even when it was harder for the branch." | VAL | [grounded] | Selection scaffold. It needs a decision that was yours, what made it harder for the branch, and what happened for the member. Tell it in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A published value the panel scores; the "harder for the branch" tension is what separates a real story from a slogan |
| J2 | "Plain Words. Tell me about a time something had to be explained twice, and what you changed." | VAL | [grounded] | Selection scaffold. It needs what wasn't understood, what you changed, and whether it landed. Answer slot: if training new tellers on the escalation script ever meant re-explaining it, that is your story, told in your own words; if not, pick a member conversation. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own wording, "explained twice", is a ready-made question |
| J3 | "Neighbours, Not Numbers. Tell me about a time you treated a member as part of the town, not a number." | VAL | [grounded] | Selection scaffold. It needs a member, something you knew or did because of the local context, and what happened. Keep it about them, not you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A published value the panel scores, and the one closest to the branches these two managers run; F6 is your branch background, but the story must come from you |
| J4 | "Own the Fix. Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3, if the slot's first branch is true: you built the monthly complaints spreadsheet, and your regional manager uses it. Answer slot: if you built it because you found a problem, say what it was and how you kept hold of it; if you were asked to build it, say so plainly and pick a different story by the same test: a problem you found, and you stayed with it until it was solved | The fourth scored value; F3 is the only sentence in your material that may carry it, so the slot decides whether it does |
| J5 | "Eight branches are becoming five hubs. How do you square that with 'Neighbours, Not Numbers' when a member complains that their branch is closing?" | VAL | [grounded] | No claim about your past needed. Acknowledge the tension plainly; don't defend or criticise the decision. Then the member: listen, explain in plain words what changes and what doesn't, make sure they know where to go, and log the complaint so the pattern reaches the people planning the hubs. Own the Fix: one person follows up | Uses their strategy and their values together, which branch managers living through consolidation are likely to raise. VAL first, CASE delivery |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You'd be coaching our supervisors on escalations. Why would they take that from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with what your sentences carry: the last three years as a branch supervisor; you trained new tellers on the escalation script. Then reciprocity: what you'd bring them, framed as what you'd offer, not what you've done. Don't claim you've coached supervisors | F4 is a transferability gap, and the panel's supervisors are the people you'd coach, so they'll test it. JD because it's a listed duty |
| K2 | "When a complaint lands in my branch, where does your job end and mine begin?" | CASE | [generic] | Propose principles, not a map you can't know yet: the branch keeps the member relationship; you own the process, the escalation path and the reporting; you agree with the manager when a complaint leaves the branch; no surprises either way. Then ask how it works today | A classic peer seam question; generic because Ashgrove's current split isn't in your materials |
| K3 | "What would you do if I disagreed with how you'd resolved a complaint from my branch?" | CASE | [generic] | Listen first; find out what they know that you don't; agree on the member outcome before the process; if you still disagree, say so, explain why, and escalate together, not around them. Answer slot: if you've disagreed with a manager over a complaint, say how it went, in your own words; if not, keep to the approach | Tests spine and tact with equals; generic because the conflict is hypothetical |

**Case / Strategist** (practice versions; the real case is unknown)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "A member has complained three times about the same issue, once in branch and twice by phone, and now wants to speak to someone senior. Talk us through what you'd do." | CASE | [generic] | Run the case build's structure aloud: clarify, the member's outcome, who owns it, what you do today, what you fix, how you record it. Include the anti-pick. Spend most of your time on today's action and the fix, less on clarifying | A practice run at the announced case, mixing branch and contact centre so F2 isn't avoided. Generic because the real scenario hasn't been shared |
| L2 | "A supervisor escalated a complaint to you that should have been resolved at the counter. What do you do with the supervisor?" | CASE | [generic] | Resolve the member's complaint first. Then a private conversation with the supervisor: what happened, what made them escalate, what they could have done, and what support they need. Coach, don't blame. Look for whether others are doing the same, which may be a process problem rather than a person problem | The JD's coaching line in case form; the panel manages these supervisors |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Sixty seconds: why you over someone who's worked in our contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause. Concede first, in one line: "I haven't worked in a contact centre." Then hold on what your sentences carry: six years in retail banking, three as a branch supervisor; the branch's formal complaints log; training tellers on the escalation script. End with one sentence on why the branch side matters as hubs form, offered as your view. Under 60 seconds | Pressure stem aimed at F2. Two interviewers make a time-boxed challenge more likely than in a one-to-one |
| M2 | "You built a spreadsheet. That's not owning a process. How much of the complaints work at your branch was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Hold, then concede what's real. Hold: you handled the branch's formal complaints log, trained new tellers on the escalation script, and built the monthly complaints spreadsheet your regional manager uses. Answer slot: if any stage of a complaint beyond the log was yours, say which; if not, say so plainly. Concede the limit in your own words: one branch, not a whole process. Don't fold on what you did, and don't widen it | Attribution probes exist to catch inflation; F1 and F3 are exactly where a candidate is tempted to widen. EXP because it tests what was yours |

### Values cheat sheet (Round 3)

| Value (official name) | Working meaning | Your mapped story | Questions |
|---|---|---|---|
| Members First, Always | Decide from the member's point of view, even when it's harder for us | Selection scaffold: a decision that was yours, made for the member at some cost to the branch. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | J1, D1 |
| Plain Words | If a member needs it explained twice, the explanation was the problem | Selection scaffold: something explained twice and what you changed. Nearest row, F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Use it only if re-explaining the script really happened. Otherwise say so plainly, then give the nearest thing your material does carry, or how you would handle it | J2, D4 |
| Neighbours, Not Numbers | Each branch belongs to its town; members aren't figures | Selection scaffold: a member treated in light of the local context. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | J3, J5 |
| Own the Fix | Whoever finds the problem keeps it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses." Mapped only if you built it because you found a problem (J4's slot). If you were asked to build it, pick another story by the scaffold: a problem you found and stayed with until it was solved; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | J4, D3 |

### Reverse questions, Round 3

| Question | Why it lands |
|---|---|
| "What could a new Member Experience Lead do in the first month that would really help your branches?" | Reciprocity: asks what you can give, which is what peers are scoring |
| "When an escalation goes wrong in your branch today, where does it usually break?" | Shows you want to learn from them before changing anything |
| "What do your supervisors need most when a complaint escalates?" | Speaks to the coaching duty without claiming expertise |
| "How do you see 'Neighbours, Not Numbers' working once branches become hubs?" | Uses their value and their strategy together; invites their view |
| "What would you want a monthly complaints report to tell you about your branch?" | Makes the report useful to them, not just to leadership |

---

## Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| Own the member complaints process end to end across branches | F1 | E1, M2, D1, L1 |
| and the contact centre | F2 | B3, E1, M1, L1 |
| Report monthly on complaint volumes and resolution times | F3 | H1, H2, G1, C2 |
| Coach branch supervisors on escalations | F4 | D2, K1, L2 |
| Work with digital teams on self-service journeys | F5 | G2, E3 |
| 4+ years in financial-services customer operations | F6 | B1, A1 |
| Experience handling regulated complaints | F7 | B2 |
| Confident presenting to senior leaders | F8 | E2, E3 |
| Comfortable with Excel reporting | F9 | H1 |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process, at your branch or across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not a process. The slots in F1 and M2 stay inside the branch |
| Has worked in, or handled complaints for, a contact centre | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leadership | Negative you stated, F8 | "I haven't presented to anyone above regional level." F8's slot asks only about regional level |
| Reported monthly to the region on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Your regional manager uses it; the pack doesn't turn that into a report you delivered. H1's slot asks only what it counts |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script." K1 offers coaching as a plan, never as a past |
| Wrote or designed the escalation script | Inflated form of F4 | Your sentence says "our escalation script", which you trained tellers on. The pack doesn't attribute authorship |
| Managed or ran a branch | Inflated form of F6 | F6's quote at its own scope: "the last 3 as a branch supervisor." With a panel of branch managers, the title matters |

---

## Sources

**Provided documents** (pasted by you, 12 November 2026):
- The job description for Member Experience Lead, Ashgrove Credit Union
- Ashgrove's values, which you copied from ashgrovecu.org/about/values on 12 November 2026 (pasted text used; the page was not fetched)
- The recruiter's email describing the three rounds on 21 November
- Your summary of Ashgrove's July 2026 strategy brief, which the recruiter sent you (the brief itself was not provided)
- Your background, in your message

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values you pasted already fix the values cheat sheet and J1 to J5 |
| 2. Ashgrove Credit Union interview process | skipped | The recruiter's email already fixes the loop: three rounds, who runs each, and the values-scored panel |
| 3. Ashgrove Credit Union strategy / recent news | skipped | The July 2026 brief (about four months old) already supplies the strategy behind C1, G2, J5 and the grounding brief |
| 4. Interviewer name + Ashgrove Credit Union | n/a | No interviewer names have been assigned, so there was no query to form |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your answers to the answer slots in F1, F3, F4, F5, F7, F8 and F9**, given to me outside a drill → those rows are rebuilt from your own words, and D1, D2, D3, E2, E3, H1, J2, J4, M2 and B2 move from slots to mapped stories
- **Interviewer names, once assigned** → a "Reading the interviewer" section, persona weights per person (especially for the two panel members), and a reverse question tied to each one's career path
- **Your CV** → dates, titles and anything your message didn't mention go into the fit snapshot, which may close F5 or move F7 or F9
- **The full July 2026 strategy brief** → the grounding brief and C1, G2, J5 use its own numbers and wording, not your summary
- **One email to the recruiter**: is the case given in advance or on the day, spoken or written, and is there a values scoring guide → the case build gets tuned to the format
- **Prep hours per day** → the prep triage gets sized to your actual time, not just the calendar
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes): recent Ashgrove news and organisation changes, plus candidate reports on credit-union member-experience interviews → a fresher grounding brief and loop-specific question patterns, labelled by source quality
- **A tuesday-dossier.md, if you have one** → the main objection comes from checked evidence rather than this pack's reading, with per-gap strategy and a prohibited-claims list built from verified facts. The pack is complete without it
