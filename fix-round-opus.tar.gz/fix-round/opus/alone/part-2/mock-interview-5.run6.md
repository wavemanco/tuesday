Still reading the skill's reference rules before I build your pack — a few more files, then I'll draft.
Web search was refused, so I'm building the pack from your message and the recruiter's email alone. Writing it now.
I've saved your prep pack to `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-5-denied-d5e0f551/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It's built only from your message and the recruiter's wording. The web searches were refused, so there's no outside research on Kelverton, Deepa or Ross, and I haven't seen the market report.

- **The 15-minute talk has its own section.** It has a minute-by-minute timing plan and three possible main arguments to pick two from, each with the concession you should say out loud. It also has one thing you would deliberately not do in 18 months, and an ending on what changes for the operators, as the recruiter asked.
- **Define "operator partnerships" in your first minute.** It could mean partnering with the operators themselves, or bringing in third parties who add to what operators get from Kelverton. Use the market report's meaning and say which reading you're going with, so the rest of the talk doesn't rest on a misreading.
- **The most valuable rehearsal is B1:** "You haven't sold into rail and you've never carried a quota — why should we trust you?" You said both of these yourself, so the pack has you say them first, plainly. Then you talk about what you did do, and say how you'd learn the rest as a plan.
- **Expect Ross to ask how your £4M was counted.** Write down for yourself how it was measured, over what period, and which part was yours. Keep "roughly" and "influenced" every time you say it. If you don't know how it was counted, saying so is better than a method you can't repeat when he asks again.
- **Get your timeline exact.** Your message has 9 years in partnerships, the last 4 at the payments company, and 5 years of consulting before that. Four plus five is nine, so the panel may hear your consulting years as partnership years. Say how it actually ran.
- **Use only the market report for facts about Kelverton or UK rail.** Don't rely on memory or general news you haven't checked. The panel circulated that report: agree with one point and push back on another, with your reasons, rather than summarising it.

The four hours are planned out at the top of the pack; most of the time goes on the talk and Ross's money questions. If you paste the report's key passages, I'll fill in the company facts and sharpen the talk around them.

I can play Deepa on B1, with follow-ups that react to what you actually say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I'll convert it.

Do you have the job description to paste? If not, I'll keep the pack built on the recruiter's wording. With it, the requirements I had to assume would come from the posting's own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round prep pack

**Round:** 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your spoken POV, with no slides. The other 45 are Q&A, and Ross will push on commercials.
**Built from:** your message and the recruiter's email as you quoted it. There was no JD. I don't have the market report's contents (you've read it, I haven't). Web research was refused, so nothing in this pack comes from outside sources about Kelverton.

---

## How to use this pack

- **Personas** describe how a question will be asked (the interviewer's style). **Types** describe what the answer is scored on.
- Type key:
  - **VAL**: values and behaviour
  - **EXP**: deep-dive on your own experience, including what was actually yours
  - **JD**: role-driven, covering the responsibilities the recruiter named
  - **CO**: company and market knowledge
  - **CASE**: a live problem set in this role
- Provenance labels: `[grounded]` means traceable to your words or the recruiter's. `[inferred]` means derived, and the derivation is named. `[generic]` means a pattern common to roles like this, with no claim about Kelverton.
- An **answer slot** is an instruction for your answer in the room. It's not a question for me. It tells you what to say if the thing happened and what to say if it didn't.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage (4 hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV. Choose 2 theses, write one line per minute of the timing plan, then talk it through out loud twice with a timer | Graded deliverable: the POV |
| 2 | 45 min | Rehearse B1 out loud through all three follow-ups until the opening acknowledgment sounds boring | B1 |
| 3 | 40 min | Write down, for your own use, how the £4M was counted, over what period, and which part was yours. Then rehearse C1, C2 and C4 | F4, C1, C2, C4 |
| 4 | 30 min | Go back to the market report. Pick one point you agree with and one you would push back on, with your reason | A5, the POV |
| 5 | 20 min | Your 90-second career story. Get the timeline exact (see F7) | F7, F1q |
| 6 | 15 min | Pick 3 reverse questions, at least one for each panellist | Reverse questions |
| 7 | 15 min | Buffer, or one live drill on B1 | — |

Everything else in this pack is insurance.

---

## Fit snapshot

There was no JD, so the requirements come from the recruiter's own words (`[grounded]`). Where I've added a requirement common to roles like this, it's written as plain prose and labelled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" — your message | medium | [grounded] | transferability | An ISV channel in payments is adjacent to operator partnerships in rail, not the same thing. Your partners were software vendors, and the operators here may be customers, partners or both. Keep the words at the quote's own scope: "At the payments company I ran the ISV channel and took it from 6 partners to 40." Answer slot: the 18-month brief makes a probe on *how* the channel grew likely. If you made choices about which partners to add or drop, say which and how you decided, in your own words. If growth came some other way, or that wasn't your call, say so plainly and stay with the channel you ran |
| F2 | "what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | This is your strongest asset for the close, at its own scope: five years of transport consulting on bus and light rail network planning. Your material doesn't say which operators or what kind of client you worked for, and it doesn't mention heavy rail or scheduling teams. Answer slot: the recruiter's close makes a probe on what operators care about likely. Name only concerns you actually saw from the other side, in your own words. If your planning work never touched timetabling or scheduling, say so plainly and stay with network planning |
| F3 | Selling into UK rail operators (role-family requirement) | "Never sold into rail specifically" — your message | none | [grounded] | capability | You've stated this gap yourself, and wording can't close it. Words: "I haven't sold into rail." Then say how you'd learn it, framed as a plan, never as a past. Add nothing to make the gap sound smaller |
| F4 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Keep both qualifiers, every time: *roughly*, and *influenced*. Your message doesn't say whether the £4M was annual or across the whole period, so don't call it annual unless it was. Answer slots, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you'd defend least, and which part was yours. "I don't know exactly how it was counted" is an honest answer if that's true |
| F5 | Owning a direct revenue target (role-family requirement, likely in Ross's line of questioning) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | You've stated this gap yourself. Words: "I've never carried a direct quota. My number was influenced revenue." Don't present influenced revenue as quota experience. How you'd want to be measured here is a forward proposal (see C4), not a past |
| F6 | Fluency in the company's own view of its market (role-family requirement) | "the market report their strategy team circulated internally last quarter, which I've read" — your message | medium | [generic] | discovery | The panel circulated the report, so reciting it scores as homework at best. Choosing from it: pick one point you would build on and one you would test or push back on. Each needs a reason you can defend in two sentences. If nothing in it strikes you as wrong, say what you would want to test first |
| F7 | Seniority to run a partner function (role-family requirement) | "9 years in partnerships" — your message | medium | [grounded] | none | No gap, but get the timeline exact. Your message gives 9 years in partnerships, the last 4 at the payments company, and 5 years of transport consulting before that. Four and five make nine, so a listener could read the consulting years as partnership years, or not. Say the timeline exactly as it ran |

---

## Graded deliverable: the 15-minute POV

**The brief, in the recruiter's words:** "a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

### What you have to build on

- **F1:** "last 4 at a payments company running the ISV channel — took it from 6 partners to 40"
- **F2:** "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- **F4:** "roughly £4M of influenced revenue"
- **The market report.** You hold its contents. Every fact about Kelverton or the UK rail market that you use should come from it, and you should say so ("your strategy team's report makes the point that…"). Don't use rail-market facts from memory or from general news unless you've checked them. Deepa and Ross know their market better than any candidate, and one stale fact costs more than it earns.

### Opening move: define the term

"Operator partnerships" could mean partnering *with* operators (the operators as strategic partners), or partnering *around* them (third parties who extend what operators get from Kelverton). The pack can't tell which Kelverton means. Use the report's usage, say in one sentence how you're reading it, and offer to adjust. The definition shows judgement, and it protects your remaining 14 minutes from resting on a misreading.

### Timing plan (15 minutes, spoken)

| Minutes | Beat |
|---|---|
| 0–1 | Your definition of operator partnerships, and the one-sentence answer: where you'd take them, in a line |
| 1–4 | What you see: one point from the report you'd build on, one you'd test, each with its reason |
| 4–11 | Two theses (below), each with its concession said out loud, sequenced across the 18 months: roughly first 90 days, then by month 9, then by month 18 |
| 11–13 | The commercial picture: how you'd want partnership value counted, which deliberately opens the door for Ross |
| 13–15 | The close: what it means for the operators themselves |

### Thesis options (pick 2, and keep the concession)

| Thesis | The argument | Mandatory concession | Where you stand on it |
|---|---|---|---|
| T1. Depth before breadth | Spend the first part of the 18 months making a small number of operator partnerships demonstrably valuable, then widen. Breadth without proof spreads a small team thin | "I haven't seen your partner or account data. The right number to start with could be different, and I'd want to look before committing to it" | F1. You can say you took the ISV channel from 6 partners to 40, which makes "I wouldn't optimise for partner count here" a judgement rather than inexperience. Use that line only if you believe it |
| T2. Judge partnerships by operator outcomes | Success is defined with the operator, in measures operators already care about, not by partnership activity | Say plainly: "My planning work was bus and light rail, so I'd test these measures with your operators before committing to them" | F2. Answer slot: name measures you actually saw operators use from the other side. If you can't name any, say what you'd ask operators first |
| T3. Make partnership value countable for Commercial | In the first 90 days, agree attribution rules with the Commercial team, so partnership value shows up in a number Ross recognises | "My number has always been influenced revenue, not a direct quota, so I'd want the counting rules agreed before the targets" | F4 and F5. This is the bridge into Ross's questions. It invites the commercial probe on ground you've chosen |

### Differentiation and the anti-pick

- **The consensus answer** is a fluent summary of the report the panel circulated. Bring one point from it to show you're grounded, then one divergence with a reason. Diverging respectfully, with reasons, scores as judgement.
- **The anti-pick:** name one thing you would *not* do in the first 18 months, and why. Two common candidates (`[generic]`, your choice): a broad tiered partner programme launched before the value is proven with a few operators, or committing to a revenue number before you've seen the pipeline. A partnerships lead who can say no is part of what a VP Partnerships is hiring for.

### The close: what it means for operators (minutes 13–15)

Land on two or three concrete things an operator would notice at month 18, said in operator language rather than partnership language. Draw them from your thesis choices and from the report. Answer slot (F2): if your consulting years showed you something operators struggle with that a better vendor relationship would help with, say what you saw, in your own words. If they didn't, say what you'd go and ask operators in your first weeks. End on the operator, not on Kelverton.

---

## Reading the interviewers

There's no public footprint here, because research didn't run. This section uses only what the recruiter wrote.

| Interviewer | What you know | What it implies |
|---|---|---|
| Deepa, VP Partnerships | Your future manager | She's assessing whether you can own the strategy she'll be accountable for. Expect the POV follow-ups (bank A) and the gap probes (bank B). Your definition of "operator partnerships" matters most to her |
| Ross, Commercial Director | "Ross will push on commercials" | Expect the £4M, the 6→40, and influenced-versus-quota to be probed, plus how partnerships and direct sales share operator accounts (banks C, D, E). Precise attribution matters more with him than polish does |

---

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Deepa extending your POV: first 90 days, trade-offs, metrics | Highest. A hiring manager plus a graded POV means live problems on the brief you just gave | Clarify, then objective, then structure, then answer, then risks. Use the report's vocabulary |
| B. Skeptic | Deepa probing rail and quota: "why you, why now" | High. F3 and F5 are gaps you stated yourself, and a future manager has to de-risk them | Plain acknowledgment first, then what your quotes carry, then a ramp plan framed as a plan |
| C. Data-Driven Prober | Ross on the £4M and the 6→40 | High. The recruiter said Ross will push on commercials, and F4 is your headline number | Know what you can and can't say about how each figure was counted, and name the weakest assumption first |
| D. Pressure | Ross time-boxing, playing devil's advocate | Medium. "Push" suggests a stress register for at least part of the hour | Pause, restate the question, hold for two follow-ups, then concede specifically |
| E. Peer Evaluator | Ross on where Commercial and Partnerships meet | Medium. A Commercial Director prices what a partnerships hire adds to, or costs, his team | Propose principles for where the two teams meet, and frame what you bring his team |
| F. Conversational | The opening minutes, or whoever chairs | Low. The format starts with your POV, but a "tell us about yourself" can still open the hour | A rehearsed 90-second career story, and treat casual questions as scored |
| Values / Behavioural | — | Not included. No values-style round was detected, and no values page is in hand | — |

---

## Question banks

### A. Case / Strategist (Deepa): 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've got 18 months. What do you actually do in the first 90 days?" | CASE | [generic] | Diagnose before you prescribe. Name what you'd want to know first: which operators are partnered today and on what terms, how value flows to Kelverton, what operators say is missing, and where Commercial sees friction. Then the two or three decisions you'd expect to make by day 90. The question needs no claim about your past, so the guidance makes none | The natural first follow-up to an 18-month POV. CASE because it scores sequencing and structure |
| A2 | "When you say operator partnership, what do you mean, exactly?" | CASE | [generic] | Give your definition from the POV opening. Name the other reading in one sentence, say why you chose yours (cite the report if it supports you), and say what would change if they mean the other one | The term is ambiguous and the brief turns on it. CASE because it tests clarifying before structuring |
| A3 | "An operator wants a bespoke integration that only they'll use. Do you take it?" | CASE | [generic] | Structure it: strategic value of that operator, cost and precedent, what other operators would ask for next, and alternatives (a configurable option, a paid engagement, a partner). Then give an answer, which can be no. Your anti-pick muscle in a live setting | Saying no is part of the job. CASE because it scores judgement under trade-offs |
| A4 | "How would we know at month 12 whether your strategy is working?" | CASE | [generic] | Leading and lagging indicators. The lagging ones are commercial (Ross's language), and the leading ones are operator outcomes (T2) and partnership health. Name one metric you'd refuse to be judged on, and why | Ties the POV to measurement, the bridge between Deepa and Ross. CASE, with CO in the details |
| A5 | "You've read our strategy team's report. Where do you think it's wrong, or at least incomplete?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Lead with one point you agree with and build on, then one you'd test, framed as a hypothesis to check rather than a correction. Keep the tone respectful: the panel circulated it. Answer slot: if your operator-side view (F2) disagrees with something in it, say which point and why, in your own words. If not, name what you'd want evidence on first | F6. The report is shared material, so departing from it with reasons is the differentiator. CO because it scores fluency in their own market view |

### B. Skeptic (Deepa): 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail and you've never carried a quota. Why should we trust you with operator partnerships and the commercials behind them?" | JD, EXP | [grounded] "Never sold into rail specifically" "never carried a direct quota, only influenced revenue" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" "roughly £4M of influenced revenue" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | **The highest-ROI rehearsal in this pack.** Name the limits before they're pressed: "I haven't sold into rail, and I've never carried a direct quota. My number was influenced revenue." Then what you do carry: you ran the ISV channel and took it from 6 partners to 40, with roughly £4M of influenced revenue, and before that five years of bus and light rail network planning. Then a ramp plan, framed as a plan. **Follow-up 1:** "So how do we know you can close?" Hold: you're not claiming closing. Answer slot: describe which part of the £4M was yours, in your own words. If you don't know how it was counted, say so. **Follow-up 2:** "Bus isn't rail." Hold the quote's scope: "My planning work was bus and light rail." Concede by naming what you'd need to learn about heavy-rail operators, as a plan. **Follow-up 3:** "Would you take a quota here?" Give your honest answer in your own words, and don't promise one you don't want | F3 and F5 are where the brief presses hardest, and you named both yourself, so this objection will come in some form. JD because it scores fit to the role, EXP because it tests what was actually yours |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Pick a real weakness, and the one your material states is F3: "I haven't sold into rail." Then a 90-day plan to close it: who you'd shadow, which operators you'd ask to speak to, what you'd read first. Don't pick a disguised strength | F3. The softer version of B1, often asked first. JD because it scores self-assessment against the role |
| B3 | "Why leave payments, and why rail now?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot: give your real reason in your own words, because the pack doesn't know it. If coming back to transport is part of it, the consulting years are the thread: "Before partnerships I spent five years in transport consulting." If it isn't part of it, don't use that thread. A consistent, specific reason beats a flattering one | The "why here, why now" stem. F2 is the only quoted thread toward transport. EXP because it tests motivation consistency |
| B4 | "Your consulting was bus and light rail. What actually transfers to our operators, and what doesn't?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Transfers, at the quote's scope: five years of bus and light rail network planning. Answer slot: name what you saw of how operators work, only what you saw, in your own words. Doesn't transfer: say "My planning work was bus and light rail," then name what you'd need to learn, as a plan. Saying where the line falls is the strength | F2's limits, rehearsed before they're pressed. EXP because it tests the claim in your own words |

### C. Data-Driven Prober (Ross): 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the £4M. How was it counted?" | EXP | [grounded] "roughly £4M of influenced revenue" | Keep "roughly" and "influenced". Answer slots, each in your own words: how the figure was counted, over what period, what it's sensitive to, the assumption behind it you'd defend least (name it before Ross does), and which part was yours. If you don't know how it was counted, say so plainly. That beats a method you can't repeat under a second question | F4 is the headline number, and the recruiter said Ross will push. EXP because it tests attribution precision |
| C2 | "Six to forty partners. How many of the forty actually produced revenue?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | Answer slot: give the denominator in your own words if you know it. If you don't, say so, and say what you'd use to find out. Don't estimate on the spot | F1's figure invites the denominator question. EXP because it tests whether you know your own numbers |
| C3 | "What's an operator partnership worth to us commercially? How would you model it?" | CASE | [generic] | Structure: direct revenue contribution, effect on retention and expansion, cost to serve, and the attribution rules that decide what counts. Ask how Kelverton prices before assuming anything. Saying "I'd need your pricing model to size it" is right | Ross's native ground. CASE because it scores commercial structure live |
| C4 | "Influenced revenue is soft. How would you want your number counted here?" | JD, CASE | [grounded] "never carried a direct quota, only influenced revenue" | Start with the plain fact: "My number has been influenced revenue, not a direct quota." Then a proposal: attribution rules agreed with Commercial up front, what counts as sourced versus influenced, and how disputes are settled. Present it as how you'd want to work here, not as something you've done before | F5. Turning the soft-number objection into a proposal is the commercial bridge. JD content, CASE delivery |

### D. Pressure (Ross): 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's sold rail software for ten years?" | JD | [grounded] "Never sold into rail specifically" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Pause first. Concede in one clause: "I haven't sold into rail." Then hold on what you carry: you ran an ISV channel and took it from 6 partners to 40, and you spent five years in transport network planning. Close on why that combination suits *this* brief. Hold through two pushes without adding to the claims | F3 in a stress register. JD because it scores fit, and the delivery test is composure |
| D2 | "That six to forty. How much of it was actually you?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | "I ran the channel." Answer slot: say which part of the growth was yours and who else contributed, in your own words. If a team or inbound demand drove much of it, say so plainly. Precision here builds credibility for everything else you say | F1's attribution, the standard pressure stem. EXP because it tests honesty under pressure |
| D3 | "Partnerships don't move revenue in 18 months. Your POV is too soft. Convince me." | CASE | [generic] | Hold the commercial thesis (T3) and point to the leading indicators you named. Concede specifically: you don't yet know Kelverton's sales cycle. Name what you'd show Ross at month 6 to earn the rest of the time | Ross will test whether the POV survives commercial pressure. CASE because it defends the plan |

### E. Peer Evaluator (Ross as commercial peer): 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "My team owns the operator accounts. Where's the line between us and you?" | CASE | [generic] | Propose principles rather than pretending to know where the line falls: who owns the operator relationship, when partnerships leads and when it supports, how credit is split, and how disagreements get escalated. Frame what you bring to his team, not only what you need from it | A Commercial Director prices what the hire adds to his team. CASE because it scores collaboration design |
| E2 | "A partner deal and a direct deal collide on the same operator. Who wins?" | CASE | [generic] | The operator's outcome decides, under rules agreed in advance. Walk through how you'd settle it this time, and what you'd change so it doesn't recur | The live version of E1. CASE because it scores judgement between equals |
| E3 | "Tell me about a time a partner and a direct sales team wanted the same deal." | EXP | [generic] | Selection scaffold: pick a time when partner and direct interests collided. It needs a named stake, what you did, and how the relationship looked afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | The credit-sharing stem. No quote carries such a story, so this is a scaffold. EXP because it asks for a real instance |

### F. Conversational: 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "Before we start, walk us through your background." | EXP | [grounded] "9 years in partnerships" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" "roughly £4M of influenced revenue" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second story in time order: transport consulting on bus and light rail network planning, then partnerships, with the last stretch at a payments company running the ISV channel (6 partners to 40, roughly £4M influenced). Answer slot: state the years exactly as they ran (see F7). End with why this role, in one sentence of your own | F7's timeline needs to be exact. EXP because even casual openers are scored |
| F2q | "What's drawing you to rail tech specifically?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot: your real reason, in your own words. If it connects to the consulting years, use that thread. If it doesn't, don't force it. Treat it as scored, because it is | The casual version of B3. EXP because it tests motivation consistency |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1. Where you'd take operator partnerships over 18 months | The POV, A1, A2, A3, A4, D3 |
| F2. What it means for operators | The POV close, A4, B4 |
| F3. Selling into rail | B1, B2, D1 |
| F4. Commercials (Ross) | C1, C2, C3, D2 |
| F5. Direct revenue target | B1, C4 |
| F6. The company's own market view | A5, the POV minutes 1–4 |
| F7. Seniority and timeline | F1q |
| Working with Commercial | E1, E2, E3 |

---

## Reverse questions

| # | Question | To | Why it lands |
|---|---|---|---|
| R1 | "At month 18, if this role has gone well, what would operators say is different?" | Deepa | It mirrors the brief's own close and shows you heard it |
| R2 | "How is partnership-influenced revenue counted today? Is that settled, or still a live argument?" | Ross | It goes to the F5 gap on your terms and tells you how you'd be measured |
| R3 | "Which conclusion in last quarter's report do you think will look wrong a year from now?" | Deepa | They circulated it, and it invites their judgement rather than a recital |
| R4 | "Where do partners and your direct team collide on operator accounts today?" | Ross | It's E1 turned around: you're asking about the line between the teams before you have to defend it |
| R5 | "What would the first 90 days need to show for you both to feel the hire was right?" | Both | It gets the success criteria on the table and ties back to A1 |
| R6 | "Is there anything in my background you'd want me to address before we finish?" | Both | It surfaces an unspoken objection while you can still answer it. Use it only if the hour has gone well |

---

## Prohibited claims

Built from the fit snapshot: the claims you're most likely to reach for under pressure, which this pack won't coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | A negative you stated (F3) | "I haven't sold into rail." |
| Has carried a quota or owned a revenue target | A negative you stated (F5) | "I've never carried a direct quota. My number was influenced revenue." |
| £4M of closed, sourced or direct revenue | Inflated form of F4 | F4's quote at its own scope: roughly £4M of *influenced* revenue. Don't call it annual unless it was |
| Heavy-rail or train-operator planning experience | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation (your material doesn't show heavy rail) and should not be said as a first-person negative |
| Advised or worked for train operating companies | Inflated form of F2 ("the other side") | F2's quote at its own scope. Your material doesn't say who the consulting clients were |
| Built the ISV channel from scratch | Inflated form of F1 | F1's quote at its own scope: you ran the channel and took it from 6 partners to 40 |
| 9 years of partnerships *plus* 5 of consulting, if that isn't how it ran | Ambiguity in F7 | Say the timeline exactly as it ran |

---

## Sources

**Provided documents:** your message, including the recruiter's email as you quoted it. The market report was not provided to me. You've read it, and the pack points you back to it rather than describing its contents.

**Searches sent (all refused, because web search permission wasn't granted):**
- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships": refused
- "Kelverton Rail scheduling software train operating companies news": refused
- "Deepa VP Partnerships Kelverton Rail; Ross Commercial Director Kelverton Rail": refused
- "\"Senior Partnerships Manager\" rail software job description UK": refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Search refused. Would have made a values cheat sheet possible and themed VAL questions |
| 2. Kelverton Rail interview process | unavailable | Search refused. The recruiter's email already sets this session (panel, POV, Q&A). Would have shown whether a values round sits elsewhere in the loop |
| 3. Kelverton Rail strategy and recent news | unavailable | Search refused. Would have grounded the CO questions and the POV in current, cited facts. The report you read can stand in for it |
| 4. Deepa, Ross at Kelverton Rail | unavailable | Search refused. Would have supplied a public-footprint interviewer read and a reverse question tied to each person's path |
| 5. Representative Senior Partnerships Manager JD | unavailable | Search refused. Would have turned F3, F5, F6 and F7's role-family requirements into quoted `[inferred]` ones |

---

## Upgrade menu

- **Key passages from the market report, pasted:** adds a grounding brief, turns A5 and the POV's "what you see" minutes into specific grounded content, and lets the theses cite Kelverton's own framing. This is the single biggest upgrade available.
- **The JD text:** F3, F5, F6 and F7 become `[grounded]` requirements, and the coverage table gets checked against the JD's own list.
- **Web search allowed:** runs the five L1 targets above, which unlocks an interviewer read from Deepa's and Ross's public profiles, a reverse question tied to each person's path, and a values cheat sheet if Kelverton publishes values. A deeper pass is also available after that: up to 6 more searches and 2 more fetches, several more minutes.
- **Your answers to the answer slots, told to me outside a drill** (how the £4M was counted, how the channel grew, what you saw of operators): F1, F2 and F4 and questions B1, B4, C1, C2 and D2 move from slots to story-mapped guidance.
- **A tuesday-dossier.md from job-underwriter:** would make the highest-ROI objection come from your evidence rather than be inferred, and would add strategy constraints per weak area. It's optional, and this pack doesn't depend on it.
