Reading the prep skill's reference rules; I'll build Dara's pack after that.
Dara, your prep pack is ready: `Ashgrove_member-experience-lead_interview_pack.md`. It has one section for each of the three rounds on 21 November, as the recruiter described them. I didn't run any web searches: what you pasted already covers Ashgrove's values, the interview format and the strategy.

What's in it:

- **A requirement-by-requirement fit check.** For each line of the job description it shows what you told me, how strong that is as evidence, and what to say. Two gaps you named yourself are handled as plain admissions with a plan for closing them: you've never worked in a contact centre, and you've never presented above regional level.
- **About 30 practice questions across the three rounds**, each with answer guidance.
- **The highest-value question to rehearse is D1, the "one branch vs. the whole network" objection.** It's likely to come up in every round. The guidance has you stick to what you actually did, name both gaps before you're asked, and give a ramp-up plan.
- **A plan for the 20-minute case** (a minute-by-minute outline tied to the four values) and a cheat sheet linking each value to one of your stories.
- **A list of claims to avoid**, such as "owned the complaints process" or "ran the region's reporting." These are the easy overstatements of what you told me.

Some answers can't be finished from what you've given me yet. The main ones are what your monthly spreadsheet tracks, whether your complaints log was covered by a regulator's complaint rules, and whether you've done any digital work. Your answers to those will strengthen a lot of the pack.

If you'd like a mock run, I can play your future manager and put D1 to you with live follow-ups. I can also save a `tuesday-dossier.md` file listing the gaps this prep found, to carry into later sessions. And I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date:** 21 November 2026, three rounds on one day (from the recruiter's email)
**Interviewers:** recruiter (30 min); Head of Member Services, your would-be manager (45 min, mostly behavioural); a panel of two branch managers (60 min, with a 20-minute complaint-escalation case, scored against the four values). No names assigned yet.
**Mode:** loop. One shared fit snapshot, then a mini-pack for each round.

---

## How to use this pack

- **Personas** describe *how* a question is asked: friendly, sceptical, time-pressured. **Types** describe *what* is being scored. Rehearse both. The same question can come at you warmly in round 1 and under pressure in round 3.
- **Type key**
  - **VAL**: behavioural or values. Does your past behaviour show *Ashgrove's* four published values?
  - **EXP**: work-experience deep-dive. What did you actually do?
  - **JD**: role-driven. Can you do the listed job, including the gaps?
  - **CO**: company and strategy. Do you know their plan (digital, hubs, lending, app-only banks)?
  - **CASE**: a live problem from the role, worked out loud.
- **Provenance labels:** `[grounded]` means it traces to something you or Ashgrove supplied. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a role-family pattern with no claim about you or Ashgrove.
- **Answer slots** mark places where your material doesn't say what happened. Each slot has two branches: say what you did, in your own words, or say plainly that it wasn't yours or never happened. Both branches are honest answers.
- Guidance is scaffolding, not a script. Every answer should be in your own words.

**Highest-ROI prep in this pack: D1** (round 2). It is the scope objection: one branch's complaints log against a role that runs end to end across branches and the contact centre and reports to senior leaders. It will come up in some form in every round.

---

## Fit snapshot (shared across all three rounds)

All evidence quotes come from your message. Requirements are quoted from the JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not a process across branches, and your words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what "handled" involved likely. If it meant investigating, replying to members or deciding outcomes, say which, in your own words. If it meant keeping the record and passing complaints on, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You've stated this gap, and no wording closes it. Words: "I haven't worked in a contact centre." Then describe how you would learn it (sitting in on calls, reading its complaint records, asking its team leads where escalations stall), said as a plan and never as a past. Add nothing to make the gap sound smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote says a monthly complaints spreadsheet. It doesn't say whether the spreadsheet counted volumes or resolution times, and it says the regional manager uses it, not that regional reporting was yours. Answer slot: if it tracked volumes, resolution times or both, say which and how a complaint got counted, in your own words. If it tracked something else, say what, and say what you would add |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Training new tellers on a script isn't coaching supervisors, so the bridge stays at its scope: "I trained new tellers on our escalation script." You can also state the fact that you've been a branch supervisor for the last three years, and let the interviewer draw any inference about the people you'd coach. Answer slot: the coaching line makes a probe on judgement calls likely. If your training went past the script into when and how to escalate, say how, in your own words. If it was the script itself, say so and stay with it |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't mention digital work. Answer slot: if you've worked with a digital or app team, or passed member feedback into an online journey, say what and what your part was, in your own words. If not, say so plainly, then say how you would start: bring the complaint records showing where members get stuck |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already covers the length requirement, so say it as it is: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer map retail banking onto "customer operations". Don't relabel your own history in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | The quote says formal, not regulated. Answer slot: if those complaints came under a regulator's complaint rules, name the rules and deadlines you worked to, in your own words. If they didn't, or you don't know which rules applied, say so plainly and say how you would learn the rules Ashgrove works under |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've stated this gap. Words: "I've never presented to anyone above regional level." Then the plan, said as a plan: a first monthly report reviewed with your manager before it goes up, a short format with a headline, and a request for feedback after the first two sessions. Never a claim to senior-level presenting |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel. Answer slot: if you built it in Excel, say so and describe the features you actually used, in your own words. If you used another tool, name it plainly |

---

## Graded deliverable: the 20-minute complaint-escalation case (round 3)

The recruiter announced the case: "a 20-minute case on a complaint escalation", run by the branch-manager panel, of whom the recruiter wrote "they score against the four values". You don't know the scenario yet, so this section builds a structure you can lay over any escalation.

**Facts about you that the case may draw on**

- F1: "I handled the branch's formal complaints log"
- F4: "trained new tellers on our escalation script"
- F2: "Never worked in a contact centre". If the scenario involves the contact centre, this is a limit to name, not to hide.

**A 20-minute shape**

| Minutes | Move | Value it shows |
|---|---|---|
| 0–3 | Clarify: what the member wants, what has already happened and where, what deadline or rule applies, who currently holds it | Members First, Always |
| 3–8 | Decide what happens for this member today, and who tells them, in what words | Plain Words |
| 8–13 | Name one owner until it's closed, and what the branch supervisor does next time | Own the Fix |
| 13–17 | Ask what the escalation says about the branch or journey, and whether it should show up in the monthly report | Neighbours, Not Numbers |
| 17–20 | Recommendation in one sentence, the risk you'd watch, and the member outcome | All four |

**Theses (pick one per scenario, each with its concession)**

| Thesis | Concession you say out loud |
|---|---|
| Resolve at the point of contact wherever the rules allow, and escalate on clear triggers rather than on how angry the member sounds | Some complaints should go up fast, and resolving everything locally can hide a pattern across branches |
| Treat the escalation as a signal as well as a case: fix it for this member, then check whether the cause sits in a branch habit or a self-service journey | Root-cause work doesn't help the member in front of you today, so it comes second |
| One named owner from first contact to close, with the member told what happens next in plain words | Sometimes the plain-words answer is "no", and the value is in how you say it, not in avoiding it |

**Differentiation**

- *Consensus answer* (what most candidates give): apologise, investigate, resolve, follow up. Use it as your skeleton to show grounding.
- *Your divergence:* say what the member would see at each step, and name the single owner. Ask which complaint rules and deadlines apply instead of assuming them; F7's slot covers what you can honestly say about rules you've worked under.
- *Anti-pick* (what to decline to do, with reasons): don't overrule the branch supervisor in front of the member, and don't promise redress before you have the facts. Say why: both cost trust that the branch has to rebuild.
- *Close:* the recruiter named no close, and the panel scores the four values. End on the member's outcome in one plain sentence.

---

## Grounding brief: Ashgrove's vocabulary and plan

Use these words. They come from the strategy brief Ashgrove published in July 2026 (as you summarised it), the JD and the values text.

| Item | What to know | Provenance |
|---|---|---|
| Members, not customers | Ashgrove is "member-owned" (JD), and its values speak of "the member's side of the counter" | [grounded] |
| Digital shift | Move "40% of member service to digital channels by 2028" | [grounded] |
| Hubs | "consolidate eight branches into five hubs over 2027" | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] |
| Competition | "the main competitive pressure is app-only banks" | [grounded] |
| What it means for complaints | Channel mix shifts toward digital, members in consolidating towns may complain about access, and a new product brings first-time complaint types. This is the pack's reasoning from the four lines above, not anything Ashgrove has said | [inferred] |
| Freshness | The brief is from July 2026, about four months before your interviews. Refer to it as "the July strategy brief" so it doesn't sound like inside knowledge | [grounded] |

---

## Round 1: Recruiter (30 min)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk through your background, motivation, logistics | High. The recruiter's own 30-minute slot is a screen, and screens run conversational | A pre-built 90-second arc (A1), and treat every casual question as scored |
| Skeptic (light) | Knockout checks against the JD: years, contact centre, presenting | Medium. Screens check the stated requirements before passing you on | Say the stated gaps plainly and early, so they read as self-awareness rather than discoveries |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, in order: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log and trained new tellers on your escalation script. You built the monthly complaints spreadsheet your regional manager uses. Close on why this role, in your own words; the pack has no sentence of yours on motivation, so don't borrow one from it | Every screen opens here. EXP because it sets which claims the later rounds will probe (F6, F1, F4, F3) |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Anchor on what Ashgrove published: member-owned, the four values by name, and the July brief's plan. Pick the one value that matches why you're applying, and say why in your own words. Avoid generic praise | Motivation-consistency check. CO because a specific answer needs their published material |
| A3 | "Why move on from branch supervision now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Your reason is yours to give; the pack has no sentence on it. Point it forward, toward the JD's work, not away from your current employer. If the honest reason is mixed, give the forward-looking part and leave it there | The premise is your current role (F6). It's asked in almost every screen, and a vague answer sounds like flight |
| A4 | "What did the complaints side of your job actually involve?" | EXP | [grounded] "I handled the branch's formal complaints log" | Start with the quote. Answer slot: the JD's end-to-end line makes it likely they'll ask what "handled" meant. If you investigated, replied to members or decided outcomes, say which and give one example, in your own words. If handling meant keeping the record and passing complaints on, say so plainly and describe how the log worked | F1 is your core evidence and gets probed in every round. Stating its scope here keeps the story consistent later |
| A5 | "This role reports monthly on complaint volumes and resolution times. Tell me about your reporting." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built it, and your regional manager uses it. Say both, in those words. Answer slot: if it tracked volumes or resolution times, say which. If it tracked something else, say what. If you built it in Excel, say so; if you used another tool, name it | Covers F3 and F9 at screen depth. JD because it maps onto two stated requirements |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then one plan sentence: how you would learn its complaint flow in the first weeks. Don't soften the gap with "but" | F2 is a stated gap against a line in the JD, and a recruiter is the most likely person to ask it as a yes/no |
| B2 | "The JD asks for four-plus years in financial-services customer operations. How does yours line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | "Six years in retail banking, the last three as a branch supervisor." Stop there. Let the recruiter map it, and don't call your own history "customer operations" | F6 is the threshold requirement. JD because it is the stated line |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level." | Pick one of the two gaps you've stated and say it plainly ("I've never presented to anyone above regional level"), then give the plan. Choosing a real gap reads as calibrated; choosing a fake one ("I care too much") reads as evasive | A standard Skeptic stem. F2 and F8 are your honest answers, and rehearsing here makes D1 easier |

### Reverse questions: recruiter

| Question | Why it lands |
|---|---|
| "How does the panel's values scoring work? Is each of the four values scored separately?" | You're using what they told you, and the answer shapes how you pace round 3 |
| "Will interviewer names be shared before the 21st?" | It's a fair logistics ask, and the answer upgrades your prep (see upgrade menu) |
| "Is the case a written scenario or spoken, and do I get time to read it?" | It shows you're preparing for the graded part |
| "Is this a new role or a backfill?" | It tells you whether you'd be building the complaints process or inheriting one |
| "Does the remit cover all branches and the contact centre from day one, or does it phase in with the hub changes?" | It ties the JD to the July brief and tells you what day one looks like |

---

## Round 2: Head of Member Services, your would-be manager (45 min, "mostly behavioural")

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" stories | High. The recruiter said "mostly behavioural", which overrides a hiring manager's usual case-first default | One complaint story, one training story and one hard-conversation story, each told with "we" for context and "I" for your part |
| Skeptic | Probes the scope gap and the stated gaps | Medium. As your future manager, they carry the risk if the gaps don't close | D1 rehearsed until it's boring: hold on your quotes, name the limits before you're asked, give a ramp plan |
| Case / Strategist | Short "how would you…" on digital and self-service | Low-medium. A hiring manager's prior, reduced by "mostly behavioural" | Clarify, structure, use their vocabulary (members, hubs, digital channels) |
| Data-Driven Prober | Asks what your spreadsheet counts | Low-medium. They will own the monthly report you'd produce | Know what the spreadsheet counts, and say plainly what you don't know |

### Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a complaint escalated. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: the branch's formal complaints log is your context. Pick one complaint where you can name what the member wanted, what you did yourself and how it ended. If no single one comes to mind, say so plainly, then describe how the log worked and your part in it | The JD's escalation line in behavioural form. F1 gives the setting but not the story, so you choose the instance |
| C2 | "Tell me about a time you taught someone how to handle an escalation." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers, on your escalation script. Tell it in your own words. Answer slot: the JD's coaching line makes a follow-up on judgement likely. If your training covered when to step off the script, say how. If it was the script itself, say so | It's the nearest evidence to "coach branch supervisors" (F4). VAL because it's told as a story |
| C3 | "Tell me about a time you had to tell someone more senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you held your view, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would raise a bad monthly number with a senior reader | A behavioural stem that tests the presenting-to-leaders requirement (F8) indirectly. No sentence of yours carries it, so it's a scaffold |
| C4 | "When did something members were telling you change how your branch did things?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the spreadsheet's figures, or a pattern in the log, ever led to a change, say what changed and what your part was, in your own words. If not, say so plainly and choose another time members' feedback changed something, or say how you'd make the monthly report lead to changes | Themed on "Members First, Always". F3 is the nearest artefact, but nothing shows it led to a change, hence the slot |

### Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your complaints experience is one branch. This job owns the process end to end, across branches and the contact centre, and reports to senior leaders. Why are you ready?" | JD | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses."; "trained new tellers on our escalation script"; "Never worked in a contact centre"; "I've never presented to anyone above regional level." | **Highest-ROI rehearsal.** *Hold, using only what you said:* "I handled the branch's formal complaints log. I built the monthly complaints spreadsheet our regional manager uses. I trained new tellers on our escalation script." *Name the limits before they're asked for:* "I haven't worked in a contact centre, and I've never presented to anyone above regional level." *Ramp plan, said as a plan:* sit in with the contact centre early, line up each branch's complaints records side by side, and take the first monthly report through your manager before it goes up. *Follow-up 1 ("one branch isn't a network"):* answer slot. If you ever compared your branch's complaints with other branches, say how. If not, say so and return to the plan. *Follow-up 2 ("so you'd be learning on the job?"):* "On the contact centre and senior presenting, yes." Hold on complaints handling and reporting, at your quotes' scope. *Follow-up 3 ("why not hire from a contact centre?"):* don't run down that candidate. Restate what you have, and stop. Never "owned the process", never "ran the region's reporting" | F1, F2, F3 and F8 meet here, so this objection is close to certain from your manager. JD because it scores the headline requirement. The deepest guidance in the pack is a set of exact limits, not more claims |
| D2 | "You haven't presented above regional level. This job reports to senior leaders every month. Convince me." | JD | [grounded] "I've never presented to anyone above regional level." | Agree first: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and to whom, in your own words. If not, say so. Then the plan: a one-page monthly format with the headline first, a dry run with your manager, and feedback after the first two. Hold-then-concede: you won't fold on being able to learn it, and you'll concede that you haven't done it yet | F8 is a stated gap that your manager will feel personally, because the report goes up with your name on it |
| D3 | "Regulated complaints come with hard rules. Which ones have you worked under?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if your branch's formal complaints came under a regulator's rules, name the rules and deadlines you worked to, in your own words. If they didn't, or you don't know which rules applied, say so plainly and say how you'd learn Ashgrove's in the first weeks. Never name a rule or deadline you didn't work to | F7 is the requirement your quote touches without reaching. A wrong rule stated confidently is worse than "I'd want to confirm which rules apply here" |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're moving 40% of member service to digital by 2028. What happens to complaints?" | CASE | [inferred] | Clarify which journeys move first. Then structure: complaints shift channel, so make sure digital complaints land in the same log. Review self-service screens against the Plain Words test. Watch members who won't or can't go digital. Concession: you don't know their current digital complaint volumes, so ask | Grounded in the July brief. The structure is the pack's reasoning from it, hence `[inferred]`. CASE because it's a live problem from their plan |
| E2 | "A self-service journey is generating complaints. How do you work with the digital team on it?" | JD | [grounded] | Structure: bring the complaint records showing where members drop out, agree one fix to test, then report whether complaints moved. Answer slot: if you've worked with a digital team before, say how. If not, say so plainly. The structure stands either way | Covers F5. JD content delivered as a CASE. Your material is silent here, so the slot keeps the answer honest |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through your monthly complaints spreadsheet. What's in it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built it, and your regional manager uses it. Answer slot: say what it counts, how one complaint becomes one row, and which tool it's in, in your own words. If there's a part you don't know (how another team counts), say so plainly. Don't describe it as the region's reporting | F3 and F9. The prober goes two levels down, and a spreadsheet you built is exactly where they'll go |
| G2 | "How would you count resolution time, and where could that number mislead?" | JD | [generic] | Answer as a design, not a past: when the clock starts, what counts as resolved, how reopened complaints are handled, and averages against the slowest cases. Name the assumption you'd defend least. If your spreadsheet already tracked this, say how; if it didn't, say so | The JD names resolution times. `[generic]` because the method is a pattern, not something you've said you did |

### Reverse questions: Head of Member Services

| Question | Why it lands |
|---|---|
| "Who reads the monthly complaints report today, and what do they do with it?" | It goes straight at the part of the role you'd be newest to (F8) |
| "How do branch and contact-centre complaints come together today, and who would I work with on the contact-centre side?" | It names your gap (F2) as something you're already planning for |
| "Which self-service journeys generate the most complaints now?" | It links the JD's digital line to the 40% target |
| "How do you expect the move to five hubs to change where complaints land in 2027?" | It shows you read the July brief and think about members in affected towns |
| "Six months in, what would tell you this hire worked?" | It's the manager's own success measure, and you'll want it before accepting |

---

## Round 3: Panel of two branch managers (60 min, values round with a 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One or more questions per value, scored | High. The recruiter wrote "they score against the four values" | The values cheat sheet below: one story or scaffold per value, named by its official name |
| Case / Strategist | The 20-minute escalation case, plus branch-level "what would you do" | High. The case is announced and takes a third of the hour | The graded-deliverable structure above |
| Peer Evaluator | Branch managers testing whether you'd help or burden their branches | Medium. The role coaches their supervisors and reports on their branches | Reciprocity: what you'd bring their branch, and seam principles rather than pretending to know the seam |
| Pressure | Pushback mid-case, time-boxing | Low-medium. A case invites "and if the member refuses that?" | Pause, restate, hold through two follow-ups, then concede specifically |

### Values cheat sheet

Value names and wording come from the values text you pasted (ashgrovecu.org/about/values, copied 12 November 2026).

| Value (official name) | Working meaning | Your mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's view, not the institution's | F1: "I handled the branch's formal complaints log". It gives the setting, not a decision. Selection scaffold: pick one complaint where you chose the member's outcome over the easier one. If no such time comes to mind, say so plainly, then describe how you'd decide from the member's side in the case | H1 |
| Plain Words | If it needs explaining twice, the wording is the problem | F4: "trained new tellers on our escalation script". Story-mapped: you trained new tellers, on the script. Answer slot: if you ever changed how something was worded because people didn't get it the first time, say what. If not, say so and stay with the training | H2 |
| Neighbours, Not Numbers | Each branch belongs to its town | F6: "6 years in retail banking, the last 3 as a branch supervisor." It gives context only. Selection scaffold: pick a time a member's local situation changed what you did. If none comes to mind, say so plainly, then say how you'd keep that in view during hub consolidation | H3 |
| Own the Fix | Whoever finds a problem keeps it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because you spotted a problem, say what it was. If it was assigned, say so plainly and pick another problem you kept hold of. If none, say so | H4 |

### Bank H: Values

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a call from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold on the log: one complaint, what the member needed, what you did, and the outcome for them. "We" for the branch, "I" for your part. If no such time comes to mind, say so plainly and give the nearest thing you have | Uses the value's own wording ("the member's side of the counter"), which the panel scores directly |
| H2 | "Tell me about a time you had to explain something so it landed first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: training new tellers on the escalation script. Answer slot: if you changed the wording, or how you taught it, because something didn't land, say what. If not, say so and describe how you trained | Plain Words. F4 is the one quote where explaining is the work itself |
| H3 | "Tell me about a time a member's local circumstances changed how you handled something." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold: a member, their town or situation, and what you did differently. If no such time comes to mind, say so plainly, then say how you'd keep that in view while branches become hubs | Neighbours, Not Numbers, asked by branch managers whose branches are part of the consolidation plan |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the spreadsheet came from a problem you spotted, tell it: the problem, what you built, and whether it's still in use (the quote says your regional manager uses it). If it was assigned, say so plainly and choose a different problem you kept hold of. If none comes to mind, say so | Own the Fix. F3 is the likeliest candidate story, but whether it started as your fix isn't shown, hence the slot |

### Bank J: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member's complaint was closed at the branch. They've rung the contact centre furious, and the branch supervisor thinks the member is wrong. Walk us through it." | CASE | [generic] | Use the 20-minute shape above: clarify (what the member wants, what was decided, which rules and deadlines apply), today's outcome and who tells them in plain words, one owner to close, what the supervisor does next time, and whether it belongs in the monthly report. Concede one thing you'd need to check. Don't claim contact-centre knowledge (F2) | A representative escalation for the announced case. `[generic]` because the real scenario isn't known |
| J2 | "Two branches merge into a hub next year and members are already complaining. What do you do in the first 90 days?" | CASE | [inferred] | Clarify what they're complaining about (distance, hours, staff). Log those complaints as their own category, explain changes in plain words before they happen, give branch staff a script for the hard question, and report the trend monthly to both branch managers. Concession: some members will leave, and you can't promise otherwise | The July brief's eight-to-five hub plan, put to the managers it affects. `[inferred]` because the complaint pattern is the pack's reasoning |
| J3 | "Small-business lending launches in Q1. What changes in complaints?" | CO | [inferred] | Expect new complaint types, so add a category before launch rather than after. Brief branch supervisors on the escalation path, and ask which rules apply to business-lending complaints instead of assuming. Concession: you haven't handled lending complaints, which your material doesn't mention, so you'd learn the product first | It tests the July brief's Q1 2027 launch. CO because it's about their plan |

### Bank K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "My supervisors already have their own way of escalating. How would you coach them without stepping on me?" | JD | [grounded] "trained new tellers on our escalation script"; "6 years in retail banking, the last 3 as a branch supervisor." | Start with the facts: you've been a branch supervisor for the last three years, and you trained new tellers on your escalation script. Then seam principles: agree the escalation triggers with the branch manager first, coach on real cases from their branch, and share what you see with them before it reaches a report. Ask what they'd want from you | F4's requirement, seen from the branch manager's side. The peer is pricing whether you add load or remove it |
| K2 | "When my branch's complaints look bad in the monthly report, how do you stop it turning into a league table?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built a monthly complaints spreadsheet, so say how you'd want to read one as a branch: see it before it goes up, get context next to the numbers, and focus on causes rather than rank. Answer slot: if your spreadsheet already did any of this, say what. If not, say so | Tests F3's reporting against Neighbours, Not Numbers, the tension a branch manager feels most |

### Bank L: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "You've never worked in a contact centre, and it's in your remit. Why should we trust your call on this case?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Pause. Concede at once and specifically: "I haven't worked in a contact centre." Hold on what you have: "I handled the branch's formal complaints log." Say what you'd check with the contact-centre team before deciding. Don't fold on the structure of your answer just to restore harmony | F2 under pressure, mid-case. Hold-then-concede is the scored behaviour |
| L2 | "We're out of time. Your recommendation in thirty seconds." | CASE | [generic] | One sentence of recommendation, one risk you'd watch, one member outcome. Rehearse saying it in under 30 seconds | Time-boxing is the commonest pressure move in a case. Rehearse it out loud |

### Reverse questions: branch managers

| Question | Why it lands |
|---|---|
| "When a complaint leaves your branch today, what do you wish happened that doesn't?" | Reciprocity: it asks what you can do for them |
| "What would make the monthly complaints report useful to you rather than a league table?" | Neighbours, Not Numbers, in their own terms |
| "What's one escalation your supervisors handle well that other branches should copy?" | It credits their teams and gives you coaching material |
| "How are members in your towns reacting to the hub plans?" | It shows you've read the July brief and care about local impact |
| "With small-business lending coming in Q1, what do you expect business members to raise at the counter?" | It uses their front-line view on the launch |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| F1 own complaints end to end across branches | A4, C1, D1, H1 |
| F2 contact centre | B1, B3, D1, L1, J1 |
| F3 monthly reporting on volumes and resolution times | A5, G1, G2, K2 |
| F4 coach branch supervisors on escalations | C2, K1, H2 |
| F5 digital self-service journeys | E2, E1 |
| F6 4+ years in financial-services customer operations | B2, A1 |
| F7 regulated complaints | D3, J1 |
| F8 presenting to senior leaders | D2, B3, C3, D1 |
| F9 Excel reporting | A5, G1 |
| Four published values | H1–H4, C4 |
| Strategy (digital, hubs, lending, app-only banks) | A2, E1, J2, J3 |

App-only banks have no dedicated question. They fit inside A2 and E1: if asked, compare member ownership and branches to an app-only service, using only what Ashgrove has published.

---

## Prohibited claims

This pack won't coach the claims below. Each appears with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process, or ran complaints across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation: your material says the branch's log, not a cross-branch process. A4's and D1's slots stay inside the log |
| Ran the region's complaints reporting | Inflated form of F3 | F3's quote at its own scope: you built the spreadsheet, and the regional manager uses it. G1's slot stays inside the spreadsheet |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote: "trained new tellers on our escalation script." The pack's observation: the material says tellers, not supervisors |
| Wrote or designed the escalation script | Inflated form of F4 ("our escalation script") | F4's quote as it stands. The material says you trained people on it, not who wrote it |
| Has contact-centre experience | Negative you stated, F2 | "I haven't worked in a contact centre." |
| Has presented to senior leaders above regional level | Negative you stated, F8 | "I've never presented to anyone above regional level." |

---

## Sources

**Provided documents**
- JD for Member Experience Lead, pasted
- Ashgrove values text, pasted (you copied it on 12 November 2026 from ashgrovecu.org/about/values; the page wasn't fetched)
- Recruiter's email about the three rounds on 21 November, pasted
- Ashgrove 2026 strategy brief (published July 2026, sent by the recruiter), as summarised in your message
- Your background, from your message
- No dossier was provided

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted this morning supplies all four names and definitions for the cheat sheet and bank H |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email sets out all three rounds, their interviewers and the case, which fixes loop mode and every persona weight |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 strategy brief, about four months old, supplies the priorities and competitive frame behind the CO and CASE questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names have been assigned, so no query could be formed. The interviewer read is absent; see the upgrade menu |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for each round from their public professional footprint, adjusted persona weights, and a reverse question tied to each person's path
- **Your answers to the answer slots in F3, F5, F7 and F9** (what the spreadsheet tracked, any digital work, which complaint rules applied, which tool) → those rows get regraded, and A5, D3, E2, G1 and G2 become story-mapped instead of slotted
- **Which regulator's complaint rules Ashgrove works under** (one email to the recruiter) → D3, J1 and the case build can name the actual deadlines instead of a structure that asks about them
- **The case format, if the recruiter will share it** (written or spoken, reading time, scenario type) → the case build tailored to it
- **Your CV text** → evidence cells can quote CV lines as well as your message, and more VAL rows may become story-mapped
- **A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes** → recent organisational context (which branches become hubs, leadership changes) and candidate reports on this kind of loop, making J2 and the reverse questions more specific
- **A tuesday-dossier.md from job-underwriter** → the highest-ROI objection derived from verified evidence instead of inferred, and a prohibited list built from an underwriting pass. Not needed for this pack
