Research found the official values page, the interview format (the "Outage Hour") and a talk by Tobias. Now I'm reading the two official pages in full.
Femi, your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. Saltmarsh's careers page says every candidate's 60-minute interview is the "Outage Hour" with the hiring manager, so I built the pack assuming that's Friday's session with Tobias.

**The format:** about half the hour is a tabletop exercise on a pretend outage during a live event, and the rest is a conversation about their three published values. There's no take-home. Banks A and B cover those two halves.

**The question to rehearse most (C1):** "You've run one title's content drops. This role runs live events across two titles and four teams. What makes you ready?" The pack gives you a way to state the limit before he does without folding. It doesn't claim any coordination you didn't describe.

**What's changing at the studio:** in September they announced Project Larkspur. Both titles move to a season pass and one shared events calendar from February 2027. That's why the pack rehearses your "never worked on a game with in-app purchases" plainly, with a plan for getting up to speed (C3).

**Tobias:** before this role he was a QA lead. His GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by whether its patch notes match what actually shipped. Your release checklist is the strongest thing to talk about with him, as long as you describe it exactly as it was.

I can play the Skeptic on C1, the question the pack names as its highest-ROI prep, whenever you want to run it.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Can you confirm Friday is the Outage Hour with Tobias as your hiring manager? Also, did the recruiter mention any focus areas or anything to prepare? Either answer would change how the question banks are weighted.

Would you like a deeper research pass? That's up to 6 more searches and 2 more page reads, taking several more minutes, covering Larkspur's details, Tobias's talk and reports from other candidates.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. This pack assumes he is your hiring manager and that Friday is Saltmarsh's "Outage Hour".
**Format:** 60 minutes. Per Saltmarsh's interviewing page: "a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."

---

## How to use this pack

Read the pack along two axes:

- **Personas** are *how* a question is asked: a live problem, a values probe, a quiet skeptic, a number-checker.
- **Types** are *what* the answer is scored on:
  - **CASE**: a live problem from the role, scored on structure and reasoning
  - **VAL**: whether your past behaviour shows Saltmarsh's *published* values
  - **JD**: whether you can do the listed job, gaps included
  - **EXP**: whether your own background holds up under scrutiny, and what was actually yours
  - **CO**: company knowledge, mainly Project Larkspur and the values

Every answer-guidance cell is scaffolding, not a script. Where a cell says **Answer slot**, the pack does not know the answer and will not guess it. The answer is yours, in your own words, and "no, that wasn't me" is always one of the honest branches.

Question IDs run A to E, then G, by persona. F is skipped so that F1–F8 always mean fit-snapshot rows.

---

## Prep triage: one evening, since the interview is tomorrow

1. **C1 out loud, three times.** This is the highest-ROI rehearsal in the pack. Time the hold and the concession.
2. **A1 and A2, the tabletop.** Practise the structure until you can say it without notes: scope, stop the damage, who to pull in, what players hear, the review afterwards. This is half the hour.
3. **B1–B3, one per published value.** Decide tonight which story goes with which value, or decide honestly that none fits.
4. **D1.** Before the interview, settle what you can and can't say about how the retention numbers were counted.
5. **Pick three reverse questions.** Make one of them R1.

Everything else in the pack is insurance.

---

## Fit snapshot

Your evidence comes from your message, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title. It does not say live events, two titles or mobile, and your words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "plan" makes a probe on how the calendar was planned likely. If deciding what went into which week was yours, say how you decided, in your own words. If the plan came to you, say so plainly and stay with running it |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a named update where you got several of those disciplines to a shared deadline. Answer slot: if running the calendar meant working with design, art, engineering or community on a drop, say which ones and what you did, in your own words. If it didn't, say so plainly and describe how you would set that coordination up. Note that coordinating is not the same as leading. Your "never led a team" is about leading, so don't let either side conflate the two |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers. It does not say you reviewed individual events or chose the KPIs, and your words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if any review of a specific drop was yours, say what you looked at. If none was, say so plainly and stay with the monthly numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist is adjacent to managing it release by release, and the quote carries the writing: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage" makes a probe on upkeep likely. If you revised it or ran it with QA on releases, say how, in your own words. If not, say so plainly and stay with writing it and QA still using it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Your material gives four years as an associate producer and two years running the calendar. It does not say whether the main title was a live-service game. Answer slot: if it was, say so in your own words and what made it one. If it wasn't, say plainly what it was. Keep each number on its own noun: four years is the associate-producer role, and two years is the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. It is still a sentence with nothing inspected behind it, so expect a probe. Lead with it in its own terms: weekly, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but expect the prober (D1). Answer slot: the JD's "the KPIs it reports" makes a probe on where the numbers came from likely. If you built them, say how they were counted, in your own words. If someone else built them, say so plainly and stay with presenting them. "I don't know exactly how retention was counted" is an honest branch |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist QA still uses touches written clarity, but it does not show it. Answer slot: if you know what made it usable, say what in your own words. If you have other written work that fits better, use that instead. If you have neither, say so and let A4 show the skill live |

None of the JD's requirements is a gate. "3+ years" is a length-of-experience requirement, so it is graded as fit (F5), not as a pass/fail term.

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar (F1) | C1, A3 |
| Coordinate design, art, engineering, community (F2) | C1, C2, A1 |
| Own the post-event review and its KPIs (F3) | D3, A4, A5 |
| Manage the release checklist with QA (F4) | E2, B3 |
| 3+ years producing live-service (F5) | E1, G1 |
| Running a content calendar (F6) | C1 |
| Player-retention metrics (F7) | D1, A5 |
| Clear written communication (F8) | A4 |

---

## Reading the interviewer

| What the research shows | Provenance | What it means for Friday |
|---|---|---|
| Head of Live Operations at Saltmarsh, previously a QA lead at a console studio | [grounded] GDC 2026 talk listing, see Sources | Release discipline and QA are his home ground. He will know a real checklist from a described one, so F4 should be told exactly as the quote has it |
| GDC 2026 talk "Patch Notes Are a Promise". Per the listing, his argument is that a live team is judged by how often its patch notes describe what actually shipped | [grounded] search-result summary of the talk, not his own words; the talk itself was not read | Accuracy is his stated standard. An answer that claims more than you did is the exact failure his talk describes. In A2 and B2, "say what is known, not what is hoped" is his language too |
| Mirror opportunity, shared vocabulary rather than a shared career jump: F4, "Wrote the release checklist our QA team still uses." | [grounded] | The checklist is the one thing in your material that sits in his former discipline. Let it come up naturally in A1 or B3 rather than forcing it |

---

## Persona weights

The loop structure comes from Saltmarsh's interviewing page: one 60-minute hiring-manager session, made up of a tabletop and then a values conversation.

| Persona | How it shows up on Friday | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The outage tabletop | High. It is half the documented session, and the hiring-manager prior puts it first | Clarify, then objective, then stop the damage, then owners, then player comms, then review. Think aloud and state your assumptions |
| Values / Behavioral | The values conversation, mapped to the three published values | High. It is the documented second half | One story per value where your material carries one. Where it doesn't, say so rather than stretch |
| Skeptic | Probes on F1, F2 and the season-pass move | Medium. The hiring-manager prior is de-risking gaps, and F2 is the biggest one | C1 rehearsed until boring. Build bridges only from your quotes, and give a concrete ramp plan |
| Data-Driven Prober | Pushes on the retention numbers (F7) | Medium. The JD names KPIs and retention, and his public theme is accuracy | Know what you can and can't say about how the numbers were counted, and say plainly where you don't know |
| Pressure | Time pressure inside the simulated outage | Low. The page describes a tabletop and says nothing about adversarial style | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Conversational | The opener and the close | Low. Short, but still scored | A 90-second arc built only from your quotes, and reverse questions ready |
| Peer Evaluator | Not included | The documented loop has no peer round. Cross-team seam questions are covered in A1 and C2 | — |

---

## Question banks

### A — Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a weekend event on one of our titles: event rewards stop granting for a chunk of players. Walk me through your first fifteen minutes." | CASE | [grounded] | Clarify first: which title, which players, since when, and whether it is still happening. Then stop the damage: is pausing or extending the event an option, and who decides. Then who you pull in: engineering to diagnose, QA to reproduce, community to watch the channels. Then what players are told, and when. Close with what the post-event review will need you to have captured. No claim about your past is needed, so make none | The documented format is a simulated outage during a live event, so this is the likeliest opening shape. CASE because it scores structure live. It also covers F2's coordination requirement as a decision rather than a record |
| A2 | "Community wants to post an ETA for the fix now. Engineering won't commit. What goes out?" | CASE | [grounded] | Use "Ship the Patch Not the Promise" in its own words: "we announce what is built, not what is hoped." Post what is known: the issue is acknowledged, who is affected, and when the next update will come. Do not post a fix time nobody will stand behind. Say who signs off the post and how quickly. Then name what you'd say once the fix lands | It joins the tabletop and the values half, and it puts the value straight into an outage decision. CASE delivery with VAL content, which the values page makes likely |
| A3 | "Both titles are moving to one shared events calendar. How would you plan the first quarter of it?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Lead with what you'd need to know first: each title's current cadence, the season-pass structure, and which teams are shared. Then the objective: one calendar that avoids collisions between the two titles' events. Then the approach: a shared view, slot rules, and a weekly review. Finish with the risks. You may say, in the quote's words, that you ran the weekly content-drop calendar for your main title. What from it you'd carry over is yours to say in your own words, and if nothing carries over cleanly, say so | Project Larkspur (Sources) makes this the role's real first problem. CO because it tests whether you know the move, with CASE delivery and the JD calendar line (F1) underneath |
| A4 | "After that outage, write me the first three lines of the post-event review." | JD | [grounded] | Line one: what happened and when, in plain words. Line two: player impact, stated as what you would measure. Don't make up figures, since the tabletop gives you none. Line three: what changes before the next event. Keep it short. Short is the written-communication answer | Covers F3's post-event review and F8's written communication at once. JD primary because it scores two stated requirements, with CASE delivery |
| A5 | "The event's day-seven retention came in below the last event's. Diagnose it." | CASE | [grounded] | Clarify how day-seven retention is defined here and which cohort it covers. Then segment: by title, new versus returning players, and players hit by the outage versus not. Then rule out seasonality and how the event was scheduled against the other title. Say what you'd check first and why. Name the assumption in your diagnosis you're least sure of | Covers F3 and F7 as a live problem, so nothing about your past is presupposed. CASE because a hiring manager in a metrics-heavy role diagnoses rather than asks for history |

### B — Values / Behavioral (the three published values)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] | Players Before Plans: "when the calendar and the players disagree, the players win." Pick a time a planned drop or date ran into what players were doing or saying. The story needs a named plan, the player signal, what changed, and what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Players Before Plans is a published value and the values half is documented. VAL by definition. No sentence in your material carries this story, so this is a selection scaffold |
| B2 | "When have you held back an announcement because the thing wasn't built yet?" | VAL | [grounded] | Ship the Patch Not the Promise. Pick a time something was announced, or about to be, before it was ready. The story needs what was at stake, what you did or said, and what happened next. If no such time comes to mind, say so plainly, then say how you would handle it. A2 gives you the reasoning | It is the value closest to the interviewer's own public theme, so expect it. VAL. This is a scaffold, because no quote carries the story |
| B3 | "Tell me about leaving a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats the quote states: you wrote the release checklist, and QA still uses it. Tell them in your own words. Answer slot: the value says every release leaves "the checklist better than it found" it, so expect a probe on whether you kept improving it. If you revised it release to release, say what changed and why. If you didn't, say so plainly and stay with writing it and its still being used | Leave the Build Greener names the checklist outright, and F4 is your closest story. VAL, and the strongest match in your material |
| B4 | "Which of our three values would you find hardest to live by in this role?" | VAL | [grounded] | Pick one honestly and say why for this role. For example, Players Before Plans pulls against owning a calendar. Then say what you would do about it. This needs no claim about your past | A common values-round close that tests whether the values were read, not memorised. VAL. It is also an opening to show you know the names |

### C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **Highest-ROI prep in this pack.** "You've run one title's content drops. This role runs live events across two titles and four teams. What makes you ready for that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Name the limit before he does:** "For the last two years I ran the weekly content-drop calendar for our main title. That was one title." Then the hold, which is only what the quote carries: weekly, for two years. Answer slot for the teams: if running the calendar meant working with design, art, engineering or community on a drop, say which and what you did, in your own words. If it didn't, say so plainly. Then the ramp, said as a plan and not a past: learn both titles' calendars, meet each discipline's lead, and sit in on a release with QA. **Follow-up 1:** "Who decided what shipped each week?" Use F1's answer slot, and hold on running the calendar. **Follow-up 2:** "So you haven't coordinated those teams?" Answer from whichever branch of the slot is true, without folding on the calendar | F1 and F2 are where this role presses hardest, so this objection will come in some form. JD because it scores the calendar, coordination and content-calendar lines (F1, F2, F6) together |
| C2 | "You mention you've never led a team. How do you get design, art, engineering and community moving on an update when none of them report to you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly first: "I haven't led a team." Then note that the role asks you to coordinate, not to manage. Answer slot: if you've got people in other disciplines to move on a drop or a release, say how, in your own words. If you haven't, say so plainly and describe how you would do it: shared dates, one owner per task, and a standing check-in. Never imply you ran people | F2's coordination line against the negative you stated. JD because it is a stated responsibility. The plain acknowledgment is sourced from your own sentence |
| C3 | "Both titles are going season-pass. You haven't worked on a game with in-app purchases. How do you get up to speed?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain first: "I haven't worked on a game with in-app purchases." Then a ramp plan, said as a plan: play both titles' passes from day one, learn which pass metrics the team watches, and pair with whoever owns monetisation. Don't bluff season-pass vocabulary you can't back. Keep it short and specific | Project Larkspur (Sources) puts a season pass at the centre of the role from February 2027, and your stated negative sits right on it. CO because it tests whether you know the move |
| C4 | "Why live ops, why Saltmarsh, why now?" | CO | [generic] | This is yours to answer, in your own words. Keep it to three beats: the work you want, why this studio's move (Larkspur) or values draw you, and why now. Make no claim about your past beyond your quotes | Standard Skeptic motivation probe. CO because "why here" is scored on knowing the company |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through those monthly retention numbers you presented. Who built them, and how was retention counted?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start with the quote: you presented the monthly retention numbers to the studio head. Answer slot, who built them: if you did, say how, in your own words. If someone else did, say so plainly. Answer slot, how they were counted: say it in your own words. If you don't know exactly, say so; that is an honest answer. Answer slot, the assumption you'd defend least: name it if you know one. Never describe a method you didn't use | F7, and F3's "KPIs it reports", put your one metrics line under the prober's lens. JD because it scores the retention requirement |
| D2 | "What changed after one of those presentations?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if a decision or change followed one of them, say what it was and what part was yours, in your own words. If nothing visibly changed, or you didn't see what did, say so plainly and stay with presenting them | Probers chase the outcome behind a reporting line. EXP because it tests what was actually yours. The premise is allowed to be false |
| D3 | "How did you tell whether a week's content drop had worked?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the quote. Answer slot: the JD's post-event review line makes this probe likely. If you looked at how individual drops performed, say what you looked at, in your own words. If you didn't, say so plainly and say what you'd look at here: a few event KPIs, chosen before the event, reviewed after it | F3's review requirement asked against F1's calendar. JD because it scores "own the post-event review and the KPIs it reports" |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds. Four years as an associate producer — how much of that was live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Pause first. Start with the quote: four years as an associate producer at a puzzle-game studio, and the last two running the weekly content-drop calendar. Answer slot: if the main title was a live-service game, say so and what made it one, in your own words. If it wasn't, say plainly what it was. Hold on the two quotes and don't round either number up | F5. JD because the 3+ years line is likely read literally. The time-box is the pressure. Prepare it so you don't freeze under the clock |
| E2 | "You wrote the checklist. This role manages it with QA every release. How much of that have you actually done?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote the release checklist our QA team still uses." Answer slot: if you ran it with QA on releases or kept it updated, say how, in your own words. If you didn't, say so plainly. The concession is specific and the hold stays intact | F4 under attribution pressure, from an interviewer whose background is QA. JD because it scores the checklist responsibility |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made only of those four sentences, in that order, in your own words. End with why this role, and leave the gaps for him to raise | The opener is scored on economy. EXP because every beat is checkable later in the hour |
| G2 | "What live-ops games are you playing at the moment?" | CO | [generic] | Answer truthfully. Name one game and one specific thing its live ops do well or badly, ideally a season pass or a recent event. If you're not playing one, say so and talk about one you've studied | A casual question on a hot topic in the role is still scored. CO because it tests how fluent you are in the genre |

---

## Values cheat sheet

Official values from saltmarshgames.com/values.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and player behaviour pull apart, change the calendar | No sentence in your material carries a story here. Pick a time a planned drop met a player signal that changed it. If none comes to mind, say so plainly and say how you would handle it (B1) |
| Ship the Patch Not the Promise | Only say publicly what has actually shipped | No sentence in your material carries a story here. Pick a time an announcement ran ahead of the build. If none comes to mind, say so and use A2's reasoning instead (B2) |
| Leave the Build Greener | Each release should improve the code and the checklist | F4: "Wrote the release checklist our QA team still uses." Whether you kept improving it is B3's answer slot |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from QA lead into running live ops. What from QA do you still see shaping how this team ships?" | It ties to his public path and turns the hour toward a peer conversation |
| R2 | "Your GDC talk was about patch notes matching what actually shipped. How does the team check that today?" | It shows you read *him*, not just the company. Only ask it if you are comfortable with the talk's title and summary, because you haven't heard the talk |
| R3 | "With both titles moving to one shared calendar in February, what does this producer own on day one, and what changes once the single live-ops group forms?" | It shows you know Larkspur, and it tells you what the job actually is |
| R4 | "What does a good post-event review look like here? Which KPIs does it report, and who reads it?" | It goes to the JD's KPI line, and his answer tells you what he will measure you on |
| R5 | "How does the release checklist work with QA now, and what would you want changed first?" | It speaks his language and invites him to describe the problem you'd be solving |
| R6 | "Six months in, what would tell you this hire was right?" | It tells you his success criteria, which is worth knowing before an offer |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar, or a calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation is that your material says weekly content drops for your main title, not live events across two |
| Owned post-event reviews or chose the KPIs | Inflated form of F3 | F3's quote at its own scope. D3's slot stays inside what you looked at |
| Built or analysed the retention numbers | Inflated form of F7 | F7's quote at its own scope: "presented". D1's slot asks who built them |
| Managed the QA process, or managed QA | Inflated form of F4 | F4's quote at its own scope: wrote the checklist, and QA still uses it |
| Four years producing live-service games, or four years as a producer | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer at a puzzle-game studio |
| Has led a team | A negative you stated: "Never led a team, and never worked on a game with in-app purchases." — your message | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases, or a season pass | A negative you stated, same sentence | "I haven't worked on a game with in-app purchases." No slot |

---

## Sources

**Provided:** your message, containing the JD text and your background.

**Searches sent:**

1. "Saltmarsh Games values" → https://saltmarshgames.com/values
2. "Saltmarsh Games interview process producer" → https://saltmarshgames.com/careers/interviewing
3. "Saltmarsh Games mobile studio news 2026" → https://saltmarshgames.com/news/project-larkspur (September 2026). Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and replaces per-title event teams with a single live-ops group. Search summary only; the page was not fetched
4. "Tobias Wrenfield Saltmarsh Games" → https://talks.gdconf.example/2026/patch-notes-are-a-promise. A GDC 2026 talk listing giving his title, prior QA-lead role and the talk's argument. Search summary only; the page was not fetched

**Fetched:** saltmarshgames.com/values (the three values and their definitions) and saltmarshgames.com/careers/interviewing (the Outage Hour format).

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and bank B: three values, by official name |
| 2. Saltmarsh Games interview process | yes | Established the loop: one 60-minute hiring-manager session, a tabletop then values. This set the persona weights, put bank A first, and detected the values round |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur: A3, C3, R3 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | The interviewer read, the F4 mirror, R1 and R2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Recruiter confirmation** that Friday is the Outage Hour with Tobias as hiring manager, plus any stated focus areas → firm persona weights instead of assumed ones, and a build section for any announced deliverable. Usually one email.
- **Your answers to the answer slots, told to me outside a drill** (coordination with other disciplines, reviews of individual drops, whether the main title was live-service, who built the retention numbers) → F2, F3, F5 and F7 can be re-graded, and C1, C2, D1, D3 and E1 rewritten on your actual words.
- **An inspectable artifact**, such as a sanitised copy of the release checklist or a retention deck you presented → F4 or F7 can rise from medium to high.
- **A tuesday-dossier.md from job-underwriter** → verified evidence and a prohibited-claims list checked against your confirmed record. This pack is complete without it.
