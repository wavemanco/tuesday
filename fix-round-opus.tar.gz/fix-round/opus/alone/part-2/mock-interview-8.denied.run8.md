I've built your prep pack for Ashgrove: one mini-pack for each of the three rounds on 21 November. I didn't run any web searches, because you'd already given me the JD, the values, the recruiter's process and the strategy.

**What's in it:**
- **Your experience against the JD:** each requirement is set against your own words. Every sentence the pack suggests about your past comes from the four sentences you gave me.
- **Question banks:** 30 likely questions with answer guidance, plus 5 questions for you to ask in each round.
- **The panel round:** a cheat sheet mapping the four values to stories, and a 20-minute structure for the complaint-escalation case.
- **Claims to avoid:** a list of things the pack won't coach you to say.

**The one to rehearse most is A3** (Head of Member Services round). It's the most likely objection: you've handled one branch's complaints log and never worked in a contact centre, but this job owns complaints across every branch and the contact centre. The answer has three moves:
1. Name the limit before they press: "It was one branch's log, and I haven't worked in a contact centre."
2. Hold only what you actually did.
3. Give a plan for learning the rest, said as a plan, never as experience.

**Gaps your own answers will decide.** Your notes don't say these things, so the pack gives you two honest ways to answer each one:
- whether the complaints you handled came under a regulator's rules;
- what handling the log involved beyond recording and tracking complaints;
- what your spreadsheet tracks, and whether it's built in Excel;
- whether you've worked with a digital team.

If you tell me the answers, I'll turn those rows into ready-made stories.

**Two things to know:**
- **Presenting to senior leaders:** "I haven't presented to anyone above regional level" is your honest line. The pack pairs it with a plan for preparing your first monthly report.
- **Complaint deadlines:** I don't know which regulator Ashgrove reports to. Don't quote a response deadline in the case unless you've checked it applies to them. The recruiter could tell you in one email.

Files are in /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-8-denied-59c54fe4:
- ashgrove-credit-union_member-experience-lead_interview_pack.md

Say the word and I'll play the Skeptic on A3 with live follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep turned up, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of interviews:** 21 November 2026, three rounds back to back
**Rounds (from the recruiter's email):** 1) Recruiter, 30 min. 2) Head of Member Services (your future manager), 45 min, mostly behavioural. 3) Panel of two branch managers, 60 min, including a 20-minute complaint-escalation case. This is also the values round, scored against the four values.
**Interviewers:** names not assigned yet, so there is no interviewer read in this pack.
**Mode:** loop. One shared fit snapshot, then a mini-pack for each round.

---

## How to use this pack

- **Personas** describe *how* a question is asked: the interviewer's style. **Types** describe *what* is being scored.
- **Type key:**
  - **VAL:** your behaviour measured against Ashgrove's *published* values.
  - **EXP:** a deep dive on your experience. Does what you said survive scrutiny, and what was actually yours?
  - **JD:** a stated requirement of the role, including the ones you're thin on.
  - **CO:** company and strategy knowledge (hubs, digital shift, app-only banks).
  - **CASE:** a live problem you solve in the room.
- **Provenance labels:** `[grounded]` means traceable to something you or Ashgrove supplied. `[inferred]` means derived, and the derivation is named. `[generic]` means a role-family pattern with no claim about Ashgrove or you.
- **Answer slots** are instructions for the interview, not questions for you to answer here. Each one has two honest branches. Either branch is a good answer.
- **Question IDs** go by persona letter: A Skeptic, B Values/Behavioural, C Case/Strategist, D Conversational, E Data-Driven Prober, G Pressure, H Peer Evaluator. F is skipped so that no question ID clashes with a fit-snapshot row (F1–F9).
- **Guidance is scaffolding, not a script.** Say it in your own words. Every sentence about your past is built from the four sentences you gave me, and from nothing else.
- **Highest-ROI prep in the pack: A3** (round 2). It is the objection most likely to come up in some form.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Six years is past four, and it was in retail banking. Say it in the quote's own terms: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer map it to "customer operations". It's your word with nothing inspected behind it, so expect a probe on what the supervisor role involved |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says *formal* complaints. It doesn't say whether they came under a regulator's rules. Words you can say: "I handled the branch's formal complaints log." Answer slot: the JD's "regulated complaints" line makes a probe on the rules likely. If those complaints were handled under rules a regulator set, name them and what they required of you, in your own words. If they weren't, or you don't know which applied, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | One branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: "end to end" makes a probe on what handling the log involved likely. If any step after a complaint reached the log was yours (looking into it, replying to the member, checking it was put right), say which, in your own words. If handling the log meant recording and tracking it, say so plainly and stay with that |
| F4 | "…and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You've stated this gap, and no wording closes it. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Add nothing to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote covers four things: monthly, complaints, built by you, used by your regional manager. It doesn't say what the spreadsheet tracks. Answer slot: if it tracks volumes or resolution times, say which and how each is counted, in your own words. If it tracks other things, say what, and stay with what you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says "spreadsheet", not "Excel". Answer slot: if you built it in Excel, say so and name what you used in it, in your own words. If you used another tool, name it plainly |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | New tellers, on an existing script. That isn't supervisors, and "our escalation script" doesn't say who wrote it. Words: "I trained new tellers on our escalation script." Answer slot, inside that training: if any of it was yours to shape (what you added, how you checked it had landed), say how, in your own words. If you delivered the script as written, say so plainly. Coaching supervisors is something you describe as a plan |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show this either way. Answer slot: if you've worked with a digital or online-banking team on anything, say what and what your part was, in your own words. If you haven't, say so plainly and say how you would start |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You've stated this gap. Words: "I haven't presented to anyone above regional level." Your sentence doesn't say whether you have presented *at* regional level. If you have, say so in your own words; if not, don't imply it. Then how you'd prepare for senior audiences, as a plan |

**Where the gaps are:** F4 and F9 are gaps you've stated. F3 and F7 are adjacent work at a smaller scope. F2, F5, F6 and F8 are answer slots: rows where your own answer decides what you can say.

---

## Grounding brief — Ashgrove's July 2026 strategy

This section is built from your summary of the brief, not the full document. Use Ashgrove's own words for these points, because the interviewers will.

| Point | Their vocabulary | Where it touches this loop | Provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | "digital channels", "self-service" | The JD's line on working with digital teams (F8). Comes up in C2, C3 and A6 | [grounded] strategy brief, July 2026, via your summary |
| Consolidate eight branches into five hubs over 2027 | "hubs", "consolidate" | The panel are branch managers, so it is their own branches being consolidated. Treat it with care and don't speculate about which branches. Comes up in H3 and C1 | [grounded] strategy brief, July 2026, via your summary |
| Launch a small-business lending product in Q1 2027 | "small-business lending" | New products can bring new kinds of complaint. Use it as a question, not a claim (reverse question R2-4) | [grounded] strategy brief, July 2026, via your summary |
| Main competitive pressure is app-only banks | "app-only banks" | C3. It also sets up "Neighbours, Not Numbers" as the counter-position | [grounded] strategy brief, July 2026, via your summary |

---

# Round 1 — Recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers, "walk me through", "why us" | High. A recruiter screen's prior is conversational, and the round is only 30 minutes | A pre-built 90-second arc (D1). Treat casual questions as scored |
| Skeptic (light) | Checks you against the JD's list: contact centre, years | Medium. Recruiters check against the requirements list, and F4 is a stated gap | Name the gap first, then one line of plan (A1) |
| Data-Driven Prober (light) | "How good are you in Excel?" | Low. One JD line, but an easy one to check | Say what you built, and nothing more than that (E1) |

### Question bank — Conversational (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds in three beats, each one of your sentences. First, six years in retail banking, the last three as a branch supervisor. Second, the branch's formal complaints log and training new tellers on the escalation script. Third, the monthly complaints spreadsheet your regional manager uses. Then why this role, in your own words and only what's true for you. The JD's complaints remit is the natural link. Stop at 90 seconds | Every screen opens here, and its casual tone hides that it's scored for economy. EXP because the arc sets what the next two rounds will probe (F1, F3, F5) |
| D2 | "Why Ashgrove — and why a credit union?" | CO | [grounded] | Two parts. First, one thing in Ashgrove's own words (member-owned, or one value by its name) and why it matters to you, in your own words. Second, the link to the job: the JD gives this role the whole complaints process. If you don't have a real reason yet, find one before the 21st. A reason made up in the room sounds made up | Motivation is checked in every screen. CO because the honest answer has to use Ashgrove's own material |
| D3 | "How much do you know about where we're heading?" | CO | [grounded] | Name the four points plainly: 40% of member service to digital channels by 2028; eight branches into five hubs over 2027; small-business lending in Q1 2027; app-only banks as the main pressure. Then one sentence, framed as your thinking: a change in how members are served is where you'd watch complaints most closely. Then stop | A cheap check of homework, and it was sent to you, so not knowing it costs more than knowing it gains. CO |
| D4 | "The role asks for experience handling regulated complaints — tell me about the complaints side of your current job." | JD | [grounded] "I handled the branch's formal complaints log" | Say what the quote says: you handled the branch's formal complaints log. Answer slot: expect a follow-up on the rules. If the complaints in that log came under rules a regulator set, name them and what they required of you, in your own words. If they didn't, or you don't know which applied, say so plainly and describe how the log worked | The F2 discovery gap. It's a listed requirement, so a screen will check it. JD content, EXP delivery |
| D5 | "This job takes you off one branch floor and across the whole organisation. How do you feel about that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say honestly what draws you and what you'd miss, in your own words. The draw the JD offers is scope: branches and the contact centre. Don't pretend there's nothing you'd miss. A real answer reads as more settled than an eager one | Checks whether a branch person wants a central role. It's JD-driven because the scope is the JD's. Draws on F1 |

### Question bank — Skeptic (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role covers the contact centre too. What's your contact-centre experience?" | JD | [grounded] "Never worked in a contact centre" | Say it first, plainly: "I haven't worked in a contact centre." Then one sentence of plan, as a plan: early on you'd follow complaints from the first call through to the reply, and sit in with contact-centre staff. Don't pile on branch credentials to make the gap look smaller. The recruiter only needs to see that you know the gap is there | F4 is a gap you've stated, against the JD's "branches and the contact centre" line. Saying it first takes the sting out early. JD |
| A2 | "The JD asks for four-plus years in financial-services customer operations. How does your background fit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Short and literal: six years in retail banking, the last three as a branch supervisor. Leave the mapping to "customer operations" to the recruiter. Don't relabel your title | F1, a knockout-style check on the requirements list. JD |

### Question bank — Data-Driven Prober (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the quote: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if you built it in Excel, name what you used in it, in your own words. If you used another tool, say which plainly. Don't list functions you'd have to look up | The F6 discovery gap. Easy for a recruiter to check. JD |

### Reverse questions — Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "For the panel's 20-minute case, will I get the scenario in advance or on the day, and is it spoken or written?" | Shows you're preparing for the graded part, and the answer changes how you prepare |
| R1-2 | "Will interviewer names be confirmed before the 21st?" | Practical, and it unlocks the persona tuning in the upgrade menu |
| R1-3 | "Is this a new role or a backfill?" | Tells you whether you'd be building the complaints process or inheriting one |
| R1-4 | "How is the role's time expected to split between branches and the contact centre?" | Lets you ready the A3 answer at the right scale |
| R1-5 | "What happens after the 21st, and on what timeline?" | Standard, and it closes the screen cleanly |

---

# Round 2 — Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scope gap: one branch against the whole organisation, plus the contact centre | High. The hiring-manager prior is Case and Skeptic, and F3, F4 and F9 are exactly where this role is widest | Rehearse A3 until it's boring. Concede the stated gaps in their own words, then give a plan |
| Values / Behavioural | "Tell me about a time…" | High. The recruiter said this round is "mostly behavioural", which raises this above the hiring-manager prior | Selection scaffolds with honest branches. "We" for context, "I" for your part |
| Data-Driven Prober | "What's in the spreadsheet?" "How would you count resolution time?" | Medium. Monthly reporting is a JD line, and F5 is your closest evidence | Say what you built. Name your own weakest assumption before they do |
| Case / Strategist | "First 90 days?" | Low. "Mostly behavioural" lowers the hiring-manager prior here. The case sits in round 3 | Clarify, then a plan in three stages |
| Pressure | Time-boxed "why you over…" | Low. No signal for it, but one rehearsal is cheap | Pause, concede, hold |

### Question bank — Skeptic (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A3 | "You've handled one branch's complaints log, and you've never worked in a contact centre. This job owns complaints end to end across every branch and the contact centre. Why should I believe you can make that jump?" | JD | [grounded] "I handled the branch's formal complaints log" "Never worked in a contact centre" | **Highest-ROI rehearsal in the pack.** Three moves, about 90 seconds. (1) Name the limit before they press: "It was one branch's log, and I haven't worked in a contact centre." (2) Hold only what the quote carries: "I handled the branch's formal complaints log." Answer slot: the first follow-up will be "what did handling it involve". If any step after a complaint reached the log was yours (looking into it, replying to the member, checking it was put right), say which, in your own words. If handling the log meant recording and tracking it, say so plainly and stay with that. (3) A plan, as a plan: in the first weeks, follow complaints from first contact in branches and the contact centre to the final reply, and learn where the two hand over. Rehearse two follow-ups. To "But that's one branch", agree, add nothing, and go back to the plan. To "Why not hire someone from a contact centre?", don't run them down. Say what you'd bring, in your quotes only, and what you'd need to learn. Hold through both. Never fold to "maybe I'm not ready", and never widen the scope | F3 and F4 together are where the JD's core line presses hardest on your material, so this comes in some form. It may come in the recruiter round or from the panel too. JD |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" "Never worked in a contact centre" | Pick one and name it. If A3 has already covered the contact centre, choose presenting: "I haven't presented to anyone above regional level." Then a plan, as a plan: how you'd prepare the first monthly report. Draft early, test it with your manager first, keep it to one page on what changed and why. Never give a fake weakness | F9 and F4 are your stated gaps. A real weakness, named exactly, scores better than a dressed-up one. JD |
| A5 | "Part of this job is coaching branch supervisors on escalations — people at your level today. Why would they listen to you?" | JD | [grounded] "trained new tellers on our escalation script" "6 years in retail banking, the last 3 as a branch supervisor." | Hold the quotes at their scope: three years as a branch supervisor, and you trained new tellers on your escalation script. Don't upgrade tellers to supervisors. Then how you'd coach peers, as a plan: start from their real escalations, ask before telling, and agree together what they own. Answer slot (F7): if any of the teller training was yours to shape, say how in your own words. If you delivered the script as written, say so plainly | F7 is adjacent work at a smaller scope. A manager will test whether a peer can coach peers. JD |
| A6 | "What have you done with digital or online-banking teams?" | JD | [grounded] | Answer slot (F8): if you've worked with a digital team on anything, say what and what your part was, in your own words. If you haven't, say so plainly, then say how you'd start: bring the complaint themes about the app or online banking to the digital team as input for their self-service work | F8 is silent in your material, and the 40% digital target makes this line live. JD |

### Question bank — Values / Behavioural (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a complaint showed you something was wrong with how things worked, and what you did about it." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, themed on "Own the Fix". It needs a specific complaint, the problem behind it, what *you* did, and whether it stayed fixed. The log you handled is the natural place to look. Use a complaint only if it really happened that way. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A behavioural round (from the recruiter) meets a published value, with F2 and F3 as the material. VAL |
| B2 | "Tell me about a hard escalation — one you raised, or one that came to you." | VAL | [grounded] | Selection scaffold: a named stake, what you decided, what happened next, and what you'd do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's escalation-coaching line, asked behaviourally. VAL |
| B3 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: someone above you (your regional manager counts, if it's true), a named stake, the moment you said it, and the relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem, chosen because F9 (senior audiences) is the requirement this round will want reassurance on. VAL |
| B4 | "You trained new tellers on the escalation script. How did you know it had worked?" | EXP | [grounded] "trained new tellers on our escalation script" | Premised on the quote. Answer slot: "how did you know" assumes there was a check. If there was one, say what it was, in your own words. If there wasn't, say so plainly and say how you'd check now. Don't claim the script as yours (see prohibited claims) | F7. EXP because it tests attribution: the script is "our", the training is yours |

### Question bank — Data-Driven Prober (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E2 | "Walk me through your monthly complaints spreadsheet. What's in it, and what does your regional manager do with it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Premised on the quote: you built it, and your regional manager uses it. Answer slot (F5): if it tracks volumes or resolution times, say which and how each is counted, in your own words. If it tracks other things, say what. Second slot: if you know what your regional manager uses it for, say so. If you don't, say what it shows and stop. Never call it "the region's reporting" | F5 is your closest match to the JD's monthly reporting line, and the Prober goes after any reporting artifact you mention. EXP |
| E3 | "How would you measure resolution time, and what would you put in front of me each month?" | JD | [generic] | A live problem, with no claim about your past. Cover: when the clock starts and stops; the median and the oldest open cases, not only the average; branches and contact centre side by side; volumes by cause, not just a total; one line on what changed and what you're doing about it. Then name, in your own words, the weakest assumption in your own measure | Scores the JD's "volumes and resolution times" line directly. JD content, CASE delivery. The structure is a common pattern, not a claim about Ashgrove |

### Question bank — Case / Strategist (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "If you started next month, what would your first 90 days look like?" | CASE | [grounded] | Clarify first: "What would success at 90 days look like to you?" Then a plan in three stages. Learn: follow complaints through branches and the contact centre, meet the supervisors, read recent reports. Baseline: volumes, resolution times, top causes. One visible fix, chosen with your manager. Connect it to the 2027 hubs and the digital target. It's a plan, so nothing in it is a claim about your past | The standard hiring-manager close. It's grounded because the JD and the brief supply the content. CASE |

### Question bank — Pressure (G)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you, over someone who's already run a contact-centre complaints team?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." | Pause. Don't attack the imaginary rival. Concede: "I haven't worked in a contact centre." Then what you bring, in your quotes only: you handled the branch's formal complaints log, and you built the monthly complaints spreadsheet your regional manager uses. Then a one-line plan. If they push, go back to the same sentences. Add nothing new under pressure | F4 again, under pressure this time. Hold, then concede. JD |

### Reverse questions — Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would you want on page one of the first monthly complaints report?" | Puts F9 and the reporting line in their terms, and shows you'd prepare for your audience |
| R2-2 | "Where do complaints get stuck today: between branches and the contact centre, or somewhere else?" | Shows you think about the hand-overs, which is where "end to end" lives |
| R2-3 | "How will the move to five hubs in 2027 change what this role needs to do?" | Uses their strategy vocabulary and asks rather than assumes |
| R2-4 | "When small-business lending launches in Q1 2027, will its complaints come through this process?" | Specific and current. Few candidates will ask it |
| R2-5 | "At six months, what would make you say this hire was the right one?" | Gets you their scorecard in their own words |

---

# Round 3 — Panel: two branch managers (60 minutes, values round, 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One question per value, scored | High. The recruiter said the panel "score against the four values" | The values cheat sheet below. Use each value's name once |
| Case / Strategist | The 20-minute complaint-escalation case, plus strategy questions | High. The case was announced by the recruiter | The case build below. Clarify, then structure, then think aloud |
| Peer Evaluator | "What do I get from you?" "Where's the seam between us?" | Medium. The JD has this role coach branch supervisors, so the panel's branches are on the receiving end of your process. That's an inference from the JD, and the recruiter said nothing about it | Reciprocity. Propose principles rather than pretend to know their branches |
| Pressure | "You've never presented above regional…" | Low. No signal for it, but F9 is an easy target | Hold, then concede (G2) |
| Data-Driven Prober | "What came up most in your log?" | Low. Branch managers know branch complaints | Say only figures you can stand behind (E4) |

### Values cheat sheet

Values copied from ashgrovecu.org/about/values on 12 November 2026.

| Value (official name) | Working meaning | Your mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from where the member stands, not where the branch stands | Selection scaffold: a specific member, the easier option, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | B5, C2 |
| Plain Words | If it needed explaining twice, the explanation was the problem | Possible material, from F7: "trained new tellers on our escalation script". Answer slot: if you ever changed how you explained it because it didn't land first time, tell that. If you didn't, choose another time, or say so plainly | B6 |
| Neighbours, Not Numbers | Each branch belongs to its town, and members are people there, not tickets | Selection scaffold: a member you dealt with as part of the community, and what that changed in what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | B7, H3 |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | Possible material, from F5: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if building it started with a problem you'd spotted, tell that: the problem, why you kept hold of it, whether it's solved. If it didn't start that way, choose another time. Also B1's scaffold, from F2 | B8, B1 |

### Graded deliverable — the 20-minute complaint-escalation case

**Facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| A 20-minute case on a complaint escalation, run by two branch managers who score against the four values | Recruiter's email | [grounded] |
| The role owns complaints end to end across branches and the contact centre, and coaches branch supervisors on escalations | JD | [grounded] |
| Eight branches into five hubs over 2027, and 40% of member service to digital by 2028 | Strategy brief, July 2026, via your summary | [grounded] |
| Your nearest material: F2 "I handled the branch's formal complaints log", F7 "trained new tellers on our escalation script" | Fit snapshot | [grounded] |
| Complaint deadlines and rules depend on the regulator. Don't quote a number in the room unless you've checked it applies to Ashgrove. Say "I'd check where we are against the response deadline" | Role-family pattern | [generic] |

**A 20-minute shape** `[generic]`
1. **Clarify (2 min):** what happened, who the member is, whether they're vulnerable or out of pocket, where you are against the deadline, who has touched it so far.
2. **The member today (4 min):** what you'd do for the member now, in plain words. *Members First, Plain Words.*
3. **Resolve the case (5 min):** get the facts, decide, reply, and check the fix held.
4. **Root cause and who keeps hold (5 min):** where it went wrong (branch, contact centre, or the hand-over between them) and who owns the fix until it's solved. *Own the Fix.*
5. **Record, report, coach (3 min):** log it so the monthly report shows patterns, and coach the supervisor who escalated. *Neighbours, Not Numbers* if it touches the town or the branch.
6. **Close (1 min):** one plain sentence on what the member got and what changes.

**Theses, each with its concession**

| Thesis | Mandatory concession |
|---|---|
| Fix the member's problem before the process's problem | Speed must not outrun the facts. Don't promise redress before you know what happened |
| An escalation is a coaching moment for the supervisor who raised it, not a takeover | If the member is vulnerable or the deadline is close, you take it directly and coach afterwards |
| Every escalation is data. Log it so the monthly report shows the pattern, especially through the hub changes | One case isn't a trend. Don't redesign the process from a single complaint |

**Differentiation:** the stock answer is "listen, apologise, solve, thank". Go one step past it. Name who keeps hold of the fix across the branch and contact-centre hand-over, and test your reply to the member against "Plain Words" out loud.
**Anti-pick:** don't blame the app, the branch or a colleague in front of the panel, and don't promise money in the room.
**Close:** the recruiter didn't name one. Use step 6.
**Your past in the case:** if you mention it, use only the F2 and F7 sentences above, at their own scope.

### Question bank — Values / Behavioural (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "Tell me about a time you made a call from the member's side of the counter, even though it was harder for the branch." | VAL | [grounded] | Selection scaffold: a specific member, the easier option, what you chose and why, and what it cost. Use the value's phrase once, not more. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always, in its own wording. A scored values round. VAL |
| B6 | "Tell me about a time you had to explain something so it landed the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Teller training is your nearest material. Answer slot: if you ever changed how you explained the escalation script because tellers didn't follow it, tell that, in your own words. If you didn't, choose another time. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plain Words, drawing on F7. VAL |
| B7 | "Tell me about a time you treated a member as part of the town, not as a number." | VAL | [grounded] | Selection scaffold: a named situation, what treating them as a neighbour changed in what you did, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers, scored by branch managers whose branches are part of their towns. VAL |
| B8 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if building the spreadsheet started with a problem you'd spotted, tell that: the problem, why you kept hold of it, and whether it's solved, in your own words. If it didn't start that way, choose another time. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix, in its own wording, drawing on F5. VAL |

### Question bank — Peer Evaluator (H)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "My branch handles complaints its own way. Why would I change for your process, and what do I get?" | CASE | [generic] | Reciprocity first: what their branch would get. Fewer escalations bouncing around, faster answers for members, and a monthly view of their own branch. Then principles, not pretended knowledge: one owner per complaint, whoever finds it keeps hold, plain words in replies. Ask what works in their branch today before changing anything | The seam between the role and the panel's own branches. CASE delivery |
| H2 | "If one of my supervisors keeps escalating things they could sort out themselves, what would you do?" | CASE | [grounded] "trained new tellers on our escalation script" | Structure: look at the escalations first, for patterns rather than personality. Ask the supervisor why. Coach on a real case. Agree what they own. Check back. If you mention the teller training, keep it at its own scope. Don't say you've coached supervisors (see prohibited claims) | The JD's coaching line, set in the panel's branches. CASE |
| H3 | "Eight branches become five hubs during 2027. What happens to complaints that year, and what would you do?" | CO | [grounded] | Clarify the timeline. Treat members' likely concerns as hypotheses to check in the data, not as facts. Plan: track complaints branch by branch through the change, write the letters in plain words, and keep a named contact for each town. Don't guess which branches close, because these managers may be affected | Strategy brief. Neighbours, Not Numbers under pressure. CO content, CASE delivery |

### Question bank — Case / Strategist (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C2 | "A long-standing member says they're being pushed onto the app and they don't want it. Take it from there." | CASE | [grounded] | Listen, then separate the complaint (what went wrong) from the preference (how they want to be served). Don't defend the strategy to the member. Offer whatever human route exists. Log it as a signal for the digital team. Use plain words throughout | The 40% digital target meets Members First and Neighbours, Not Numbers. CASE |
| C3 | "App-only banks are our main competition. What can complaints tell us about that?" | CO | [grounded] | Complaints as insight: the themes about the app and about speed, and the things members say they'd lose. Feed them into the self-service work. Don't claim to know Ashgrove's complaint data; frame it as what you'd look for | Strategy brief, and the JD's digital line (F8). CO |

### Question bank — Pressure (G) and Data-Driven Prober (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G2 | "This role presents to senior leaders. You've never presented above regional level. Convince us." | JD | [grounded] "I've never presented to anyone above regional level" | Concede up front, in the quote's own terms: "I haven't presented to anyone above regional level." Then a plan for the first report: early draft, a dry run with your manager, one page. Hold through two pushes without folding: "I haven't done it yet. Here's how I'd prepare the first one." Don't claim confidence you can't show | F9, under pressure. Hold, then concede. JD |
| E4 | "In your branch's complaints log, what came up most?" | EXP | [grounded] "I handled the branch's formal complaints log" | Premised on the quote. Answer slot: if you know the most common causes, or rough numbers, give them and say how you know. If you don't, say so plainly. Never estimate a figure in the room that you can't stand behind | F2 and F3. Branch managers know branch complaints well. EXP |

### Reverse questions — Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What could I do in my first month that would actually make your branches' week easier?" | Reciprocity, which is what a peer-style panel is weighing |
| R3-2 | "When a complaint escalates out of your branch today, where does it go, and how do you hear back?" | Shows you'd start from their reality, and gets you live data for your 90-day plan |
| R3-3 | "How are your teams and members feeling about the move to hubs?" | Neighbours, Not Numbers, asked rather than claimed. Ask it gently |
| R3-4 | "Which of the four values is hardest to live up to on a busy Saturday?" | Takes the values seriously and invites candour |
| R3-5 | "What would you want from the complaints lead that you don't get today?" | Gets you their scorecard and builds rapport |

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A1, A3, G1, C1, H1, the 20-minute case |
| Report monthly on complaint volumes and resolution times | E3, E2, E4 |
| Coach branch supervisors on escalations | A5, B2, H2 |
| Work with digital teams on self-service journeys | A6, C2, C3 |
| 4+ years in financial-services customer operations | A2, D1 |
| Experience handling regulated complaints | D4, the 20-minute case |
| Confident presenting to senior leaders | A4, G2, B3 |
| Comfortable with Excel reporting | E1 |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran or owned complaints across several branches, or the region | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit, as this pack observes it, is one branch's log |
| Built the region's complaints reporting | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is one spreadsheet that one regional manager uses |
| Wrote or designed the escalation script | Inflated form of F7 | F7's quote: "trained new tellers on our escalation script". "Our" doesn't say who wrote it |
| Has coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: new tellers. Coaching supervisors is spoken of only as a plan |
| Managed or ran a branch | Inflated form of F1 | F1's quote: "the last 3 as a branch supervisor". The panel are branch managers and will know the difference |
| Has contact-centre experience | A negative you stated, F4 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders above regional level | A negative you stated, F9 | "I haven't presented to anyone above regional level." No slot |

---

## Sources

**Provided documents:** the JD (pasted); Ashgrove's values (pasted, which you copied on 12 November 2026 from ashgrovecu.org/about/values; not fetched); the recruiter's email on the process (pasted); your summary of the July 2026 strategy brief; your background (your message). No dossier was provided.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | You pasted the four values, copied this morning, so they already fix the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email sets out all three rounds, so the persona weights and the case build come from it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Your summary of the July 2026 brief, about four months old, already gives the grounding brief and the CO questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names have been assigned, so there's nothing to search. There is no interviewer read |
| 5. representative `Member Experience Lead` JD | skipped | You supplied the JD, so it sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your answers to the answer slots** (F2 regulated rules, F3 what handling the log involved, F5 what the spreadsheet tracks, F6 Excel, F7 the training, F8 digital) → these rows and the questions that draw on them (D4, A3, E1, E2, A5, A6, B4) move from slots to story-mapped answers
- **Your CV** → more of your own sentences to quote, and the "tell me about a time" scaffolds can become mapped stories where a CV line carries one
- **Interviewer names, once assigned** → an interviewer read, persona weights tuned per person, and at least one reverse question tied to each interviewer's own path
- **The full strategy brief text** → a richer grounding brief and sharper C2, C3 and H3, in the brief's own numbers and wording
- **How many hours you have before the 21st** → a prep-triage schedule: the few things done well, in order
- **A mock-up of your monthly complaints spreadsheet with dummy data, never real member data** → the proof this kind of role keeps, which could raise F5 and F6 from medium to high
- **A recruiter answer on the case format, and on which complaint rules Ashgrove works under** → a case build tuned to the format, and a deadline line you can say with confidence
- **A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes** → loop reports for Ashgrove, recent organisational context, and public talks by the interviewers once named
- **A tuesday-dossier.md from job-underwriter** → evidence-checked confidence on each row, and a prohibited list based on verified evidence rather than one built here
