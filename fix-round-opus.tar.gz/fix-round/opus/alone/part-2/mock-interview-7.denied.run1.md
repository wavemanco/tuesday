Web search was blocked by this session's permissions, so I'm building the pack from your JD and background alone and marking every research gap.
I've saved your prep pack as `saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 practice questions, each with answer notes based on what you told me.

- **Built without research:** my four web searches (Saltmarsh's values, its interview process, its recent news and Tobias's public profile) were all blocked by this session's permissions. So nothing in the pack comes from Saltmarsh's website or Tobias's background, and the rows that would have used them are marked.
- **Assumed a hiring-manager round:** Tobias heads the team this role sits in, so I treated him as your likely future manager.
- **The question most worth rehearsing is A1:** *"The calendar you ran was for one title. This role runs live events for two titles and four teams. What makes you ready?"* Hold to what you did (two years running the weekly content-drop calendar, the release checklist QA still uses). Admit the limits before he raises them (one title, associate title). Then say how you'd get up to speed.
- **Answer slots:** where the pack doesn't know something, it leaves a slot for you to fill rather than guessing. Examples: whether you planned the calendar or just ran it, which teams fed your drops, and whether you built the retention numbers or presented someone else's. Each slot has two honest answers.
- **In-app purchases and leading a team:** the JD lists neither. If asked, the pack has you say plainly that you haven't done them, then give a plan for learning.

Say the word and I'll play the Skeptic on A1 with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and is this a first round or a later one? If the recruiter said what it will focus on or asked you to bring anything, tell me too, because that reweights every section.
If you allow web search, should I run those four checks again, and also the deeper pass (up to 6 more searches and 2 more page reads, several more minutes)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interview:** Friday, 60 minutes, with Tobias Wrenfield, Head of Live Operations
**Built on:** a hiring-manager round. He heads the function this role belongs to, so I've assumed he would be your manager. That is an inference, and if it's wrong the persona weights change.
**Research:** none ran. All four web searches were refused by this session's permissions (see Sources), so nothing here comes from Saltmarsh's website, its news coverage or Tobias's public profile.

---

## How to use this pack

Personas describe **how** a question gets asked: the tone, the pressure, the follow-ups. Types describe **what** is being scored. A friendly question can still be scored hard.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values the company publishes |
| EXP | Whether what you've said about your work holds up when probed, and how much of it was yours |
| JD | Whether you can do the job as the description lists it, gaps included |
| CO | Whether you've done your homework on the company, its games and its position |
| CASE | How you structure and reason through a live problem from the role |

Provenance labels: `[grounded]` means the row rests on your own words or the JD. `[inferred]` means it's this pack's reasoning from those. `[generic]` means it's a common pattern for the role, not a fact about Saltmarsh.

**The guidance is scaffolding, not a script.** Where a cell says **Answer slot**, the pack doesn't know the answer and won't guess. You fill it from what actually happened, and both branches are honest answers.

---

## Prep triage

I've sized this to one evening, since Friday is tomorrow. That's an assumption.

1. **A1, out loud, twice** (about 30 min). It's the highest-ROI question in the pack. Practise the hold, then the concession.
2. **Read the Prohibited claims list** (5 min). These are the claims you're most likely to reach for under pressure.
3. **Answer slots in F1, F3, F4 and F5, privately, in your own words** (20 min). Write a sentence for each branch that's true for you. These feed A1, A2, A4, B4, C1 and E1.
4. **B1, B2 and B3: say the structure aloud** (30 min). These are live problems, and the structure is what gets scored.
5. **D1: your 90-second arc** (10 min).
6. **Pick three reverse questions** (5 min).

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material covers one title's weekly content-drop calendar, not live events across two titles, so the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's word "plan" makes a question about how the calendar was planned likely. If deciding what went into which week was yours, say how you decided, in your own words. If the plan was handed to you, or there was no planning step beyond the weekly cadence, say so plainly and stay with running it |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap: the quote says exactly this. Nothing has been inspected behind it, so expect a probe. Lead with the quote's own terms: weekly, your main title, the last two years |
| F3 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material shows four years as an associate producer, two of them running a weekly content-drop calendar. It doesn't say whether the game was live and getting updates for all four years. Answer slot: if it was, say so in your own words. If the live part was the last two years, say that plainly and count those |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | Running a calendar touches update coordination, but your material doesn't show which teams were involved. Coordinating is also not the same as leading (see F10). Answer slot: if any of those four disciplines delivered into your drops, name which ones and what you did to keep them on the calendar, in your own words. If the calendar didn't involve them, or someone else handled them, say so plainly and describe what running the calendar did involve |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting monthly numbers is close to reporting KPIs. But your material shows no post-event review, and presenting numbers is not the same as building or owning the analysis behind them. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you built or analysed those numbers yourself, say which part, in your own words. If someone else prepared them and you presented them, say so plainly. Separately: if any drop was reviewed after it went live, describe the review and your part in it. If none was, say so plainly |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in wording: the quote is about retention numbers, presented at studio-head level. Expect a probe on which measures they were and how they were counted. Answer slot: name the measures in your own words. If you don't know how they were counted, say so plainly |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap: you wrote a release checklist, and QA still uses it. Lead with exactly that. Answer slot: the JD's word "manage" makes a question about who keeps the checklist current likely. If you updated it or ran it on releases, say how. If it passed to QA once it was written, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The checklist is a written document that a team still works from. Say it in those terms, "I wrote the release checklist our QA team still uses", and let the interviewer draw the conclusion about your writing |
| F9 | Live events on mobile titles commonly involve in-app offers. The JD doesn't mention this | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [generic] | capability | Words: "I haven't worked on a game with in-app purchases." The JD doesn't list monetisation, so don't raise it as a gap yourself. If you're asked, say it plainly, then say how you'd get up to speed, as a plan and never as past experience |
| F10 | Producer roles above associate level often involve leading people. The JD asks for coordination and doesn't mention leading | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [generic] | capability | Words: "I haven't led a team." The JD asks you to coordinate teams, not manage them, so an honest answer keeps the two apart. For the coordination side, use whatever your F4 answer slot gives you |

---

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent questions about the step up: one title to two, associate to producer, no monetisation | High. A hiring manager is reducing the risk of a hire, and your biggest gaps (F1's scope, F4, F5) sit right on the JD's headline lines | Rehearse A1 until it's boring. Hold only what your quotes carry, name the limit before he does, then give a plan |
| Case / Strategist | Live problems from the job: calendar clashes, late art, a retention drop, running a post-event review | High. The hiring-manager prior, and the JD is a list of operational problems | Clarify, set the objective, name the constraints, give options, decide, then say how you'd communicate it. Think aloud |
| Data-Driven Prober | "Which retention metric? How was it counted? What was yours?" | Medium. The JD names retention metrics and KPIs, and F5 and F6 are your evidence for them | Know what you can and can't say about those numbers. "I don't know how it was counted" is an honest answer |
| Conversational | A friendly opener, "walk me through your background", chat about games | Medium. Most 60-minute interviews open like this. It is still scored | A fixed 90-second arc (D1). Treat casual live-events questions as scored |
| Peer Evaluator | "What do you need from design, art, engineering and community?" | Low to medium. The JD's coordination line invites it even from a manager | Talk about principles for handoffs between teams rather than claiming to know Saltmarsh's teams |
| Pressure | Time limits, "how much was actually you?" | Low. Nothing points to a stress format, but one sharp follow-up is common | Pause, restate the question, hold through two follow-ups, then concede something specific |
| Values / Behavioural | "Tell me about a time…" questions | Low. No values round is documented, and Saltmarsh's published values couldn't be fetched | Pick real stories using the scaffolds. Where you have none, say so |

Weights are based on the hiring-manager relationship and the one session you described. Saltmarsh's interview process couldn't be researched.

---

## Question banks

### A — Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The calendar you ran was for one title. This role runs live events for two titles and coordinates four disciplines on every update. What makes you ready for that step?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "4 years as an associate producer at a puzzle-game studio" | **The highest-ROI rehearsal in this pack.** Hold with what the quotes carry: "For the last two years I ran the weekly content-drop calendar for our main title, and I wrote the release checklist our QA team still uses." Name the limit before he does: it was one title, and you were an associate producer. Answer slot (F4): if design, art, engineering or community delivered into your drops, say which and what you did to keep them on the calendar. If not, say so plainly. Then a ramp plan, said as a plan: how you'd get to know the second title's calendar in your first weeks. Follow-up 1, "two titles is double the load": hold. You ran a weekly cadence for two years. Don't claim you've run two calendars. Follow-up 2, "what breaks first?": concede specifically that you haven't balanced two calendars competing for the same teams, then say how you'd spot clashes early. Never give up the core claim: you ran that calendar | F1 is where the JD's headline line presses hardest, so this objection will come in some form. JD type because it scores the stated responsibility against your evidence |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Pick one real gap and own it. The post-event review is a likely honest choice. Say what you did: you presented the monthly retention numbers to the studio head. Answer slot (F5): if you ran a review of any drop after it went live, describe it and your part. If not, say plainly that this is the part you'd be newest at, then give the plan. Don't pick a fake weakness | F5 is the widest gap on a line the JD says you'd "own". A rehearsed, non-defensive answer here costs nothing and earns credibility |
| A3 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Plain acknowledgment: "No, I haven't worked on a game with in-app purchases." Then how you'd get up to speed, said as a plan. Don't apologise at length. The JD doesn't list monetisation, so answer and move on | F9 is a negative you stated yourself. Live events on mobile often involve offers (a `[generic]` pattern), so this question is likely even though the JD doesn't score it. EXP because it asks about your history directly |
| A4 | "How many of your four years were on a live game getting regular updates?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot (F3): if the title was live and updating for all four years, say so in your own words. If the live part was the last two years, say that plainly and count those. Don't stretch two years of calendar work into four years of live ops | F3 is how the "3+ years" requirement gets tested, and the honest answer has to be ready before the question comes. JD because it checks a listed requirement |
| A5 | "How much of running a puzzle game's content drops transfers to other kinds of mobile games, and what doesn't?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | What transfers, from your quotes: running a weekly calendar, and a release checklist QA still uses. What doesn't, said honestly: you'd be learning how events are designed in a different genre. Don't claim to know what genres Saltmarsh's titles are, because that couldn't be checked. Hold the transferable part through one push, then concede the genre-specific part plainly | Tests the transferability gap in F1 from another angle. JD because it asks whether your experience reaches the stated role |

### B — Case / Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Both titles want a big event in the same week next quarter. How do you decide?" | CASE | [generic] | Clarify first: what each event is meant to achieve, any fixed dates (holidays, marketing beats), and which teams are shared. Then constraints: art, engineering and QA capacity. Options: stagger the events, scale one down, or swap in a lighter event. Say who decides and how you'd write the decision up for both teams. This question doesn't need any claim about your past, so the guidance makes none | Comes straight from the JD's "two of our mobile titles" calendar line. A live problem, so CASE |
| B2 | "An event's art is a week late and launch is in ten days. What do you do?" | CASE | [generic] | Confirm the scope of the slip with art. Then options: cut scope, move the date, or reuse existing assets. Check the QA impact against the release checklist timeline. Tell community early if anything players can see changes. Say who makes the call and by when | Tests the JD's coordination and QA-checklist lines under a deadline. CASE because the reasoning is what's scored |
| B3 | "Day-1 retention on one title dropped after the last update. Diagnose it." | JD | [generic] | First check the drop is real: tracking, data delays, the time window. Segment it: new vs returning players, platform, region, app version. Ask what changed: the update's contents, bugs, store listing, other events running at the same time. Form hypotheses, test the cheapest first, then decide what to do. Say aloud which assumption you'd trust least | JD content (retention metrics), asked as a CASE. It's the most direct test of "comfortable with player-retention metrics" |
| B4 | "Walk me through how you'd run a post-event review: what's in it, who's in the room, what KPIs you'd report, and how you'd write it up." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Lay it out as a plan: the goals set before the event, results against those goals, what went wrong in delivery, player and community feedback, and the decisions for next time. Keep the write-up short and focused on decisions. Mention once what you've actually done: you presented the monthly retention numbers to the studio head. Answer slot (F5): if you've reviewed a drop after it went live, use it. If not, keep this a plan and don't describe it as something you've done | F5's gap, practised as a forward-looking plan. JD because the role says you'd "own" this. It also covers "clear written communication" |
| B5 | "Community says players hate the new event, but design says the numbers look fine. What do you do?" | CASE | [generic] | Find out what each side is actually seeing: which players and which numbers. Look for the overlap, such as a loud group of players versus the overall average. Decide what would change your mind, agree a short-term response (communicate, tweak, or hold), and set when you'll review it | Tests coordinating community and design, which are two of the JD's four named teams |

### C — Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention numbers were in your monthly presentation, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: name the measures, in your own words. Say how they were counted if you know. If you don't, say so plainly. Say which part was yours: building them, pulling them, or presenting them. Name the assumption behind them you'd defend least, in your own words. The pack doesn't name any metric for you | F6 and F5 rest on this one sentence, which makes it the first thing a prober will press on. EXP because it checks what you've said about your work |
| C2 | "Tell me about a time the numbers you presented changed what went into the calendar." | EXP | [grounded] "Presented the monthly retention numbers to the studio head"; "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: you need a number, a decision, and the calendar change that followed. If such a time exists, tell it with your part stated exactly. If none comes to mind, say so plainly, then say how you'd connect the review to the calendar here | The JD links reviews, KPIs and the calendar. This tests whether you've connected them before, without assuming you have |
| C3 | "What's on the release checklist you wrote, and why do you think QA still uses it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Describe what's on it in your own words. The pack doesn't know its contents. The fact that QA still uses it is your strongest point, so say it plainly. Answer slot: if you've seen it catch a problem before release, describe that one case. If you don't know of one, say so plainly | F7 and F8: your most concrete artefact. EXP because it checks a claim, though it also tests the JD's written-communication line |

### D — Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc with four beats, each from a quote: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for your main title for the last two years, the release checklist QA still uses, and presenting the monthly retention numbers to the studio head. Finish with why this role, in your own words. That reason is yours to supply and the pack won't write it | Almost certainly the opener. A tight arc signals the "clear communication" the JD asks for |
| D2 | "Have you played any of our games?" | CO | [generic] | If you have, name which, and one specific thing you noticed as a player. If you haven't, say so plainly and say what you'd look at first. I couldn't confirm Saltmarsh's titles, so play them tonight if you can find them | A CO question with no research behind it. The honest branch matters more than polish |
| D3 | "What are you playing at the moment, and what's a live event you thought was well run?" | JD | [generic] | Pick a game you really play. Name the event and what made it work for you as a player. Frame it as a player's observation, not insider knowledge | A casual question on the JD's core subject, live events, and it's still scored |

### E — Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design, art, engineering and community all feed an update. Where do handoffs usually break, and what do you need from each?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot (F4): if those teams delivered into your drops, say where handoffs slipped and what you did. If not, say so plainly. Then give principles rather than guesses about Saltmarsh's teams: clear dates for each handoff, one owner per asset, and early warning when something slips | F4's discovery gap, approached the way a colleague would ask it. JD because it's the named coordination line |
| E2 | "When designers and engineers disagree about what goes into an update, how do you reach a decision when none of them report to you?" | CASE | [generic] | Structure: lay out the trade-off, agree who has the final say, write the decision down, and keep the calendar date visible. Answer slot: if you've had a disagreement like this over a content drop, describe it and your part. If not, say so and walk through the approach | This tests coordination without authority, which is exactly what the JD asks for and what F10 leaves open |

### F — Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a producer who's already run live ops with monetisation?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "Never led a team, and never worked on a game with in-app purchases" | Pause. Don't argue down the other candidate. Three beats from your quotes: the weekly calendar for two years, the checklist QA still uses, and the monthly retention numbers you presented to the studio head. If he presses on monetisation, concede plainly: "I haven't worked on a game with in-app purchases." Hold the three beats through a second push | Tests composure on your F9 gap. JD because it compares you against the role |
| F2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: the quote says you wrote it. Answer slot: if others added sections or QA reshaped it later, say so plainly and say which part was yours. If it was all yours, say that simply. Hold through two follow-ups by repeating what you did, never by adding to it | F7 is your strongest claim, so it's the one a pressure question tests. EXP because it's about attribution |

### G — Values / Behavioural (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: you need a named stake, what you said, and how it landed. Your monthly presentations to the studio head are one place such a moment might be. Use one only if it actually happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common stem for this persona. Saltmarsh's values couldn't be fetched, so it isn't mapped to them |
| G2 | "Tell me about a time a release went wrong, and what you changed afterwards." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold: you need the problem, your part, and the change. Only tell the story of why the checklist was written if you know it, in its actual terms. Don't present it as a fix for a failure unless that's what it was. If no such time comes to mind, say so plainly and describe how you'd run a review after a bad release | Themed by the JD's release-checklist line. Tests ownership and learning |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A5, B1 |
| Coordinate design, art, engineering and community | E1, E2, B2, B5 |
| Own the post-event review and its KPIs | B4, A2, C2 |
| Manage the release checklist with QA | C3, F2, B2 |
| 3+ years producing live-service games or apps | A4, A5 |
| Experience running a content calendar | A1, D1 |
| Comfortable with player-retention metrics | B3, C1 |
| Clear written communication | B4, C3, D1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here, and who reads it?" | It's the JD line you'd "own". Asking shows you're already thinking about the deliverable |
| R2 | "Are the two titles' calendars planned together today, or each on its own?" | Goes straight to the two-title part of the role, and the answer tells you where clashes come from |
| R3 | "Where do updates most often get squeezed: design, art, engineering, community or QA?" | Shows you think about coordination as a system, and gives you material for your first month |
| R4 | "What would you want this person to have taken off your plate by month three?" | Gets the real success measure from the person who sets it |
| R5 | "How did you come into live ops, and what do you wish you'd known in your first year running it?" | Tied to his role. It turns the conversation into one between peers. His profile couldn't be researched, so it's open rather than specific |
| R6 | "Which KPIs does the review report today, and which ones do you wish it did?" | Shows comfort with metrics and invites him to describe the gaps he wants filled |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two or more titles | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation, not words for you: one title, weekly content drops |
| Four years of live-service producing | Inflated form of F3 | F3's quotes at their own scope. A4's slot stays inside the four years you stated |
| Owned the post-event review or the KPI analysis | Inflated form of F5 | F5's quote at its own scope: you presented the monthly retention numbers. C1's slot stays inside those numbers |
| Managed QA, or ran the QA release process | Inflated form of F7 | F7's quote at its own scope: you wrote the checklist QA still uses |
| Producer, rather than associate producer | Inflated form of F3 | "4 years as an associate producer at a puzzle-game studio" |
| Has led a team | Negative you stated, F10 | "I haven't led a team." |
| Has worked on a game with in-app purchases | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." |

---

## Sources

**Provided documents:** your message, which contained the JD text and your background. No dossier was available.

**Searches sent (all refused by this session's permissions, nothing returned):**
- "Saltmarsh Games mobile studio values": refused
- "Saltmarsh Games interview process producer": refused
- "Saltmarsh Games mobile games news 2026": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Search refused. Published values would have themed G1 and G2, and if a values round turned up, added a values cheat sheet |
| 2. Saltmarsh Games interview process | unavailable | Search refused. Would have confirmed or reweighted the persona table and flagged any case or take-home format. Your own description of the session stands in for it |
| 3. Saltmarsh Games strategy and recent news | unavailable | Search refused. Would have grounded D2 and added a CO or CASE question about their current titles |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Search refused. Would have added an interviewer read, adjusted the persona weights, and tailored R5 to his actual career path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied already sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Is Tobias your future manager, and is this a first or later round?** Confirming this would reweight every bank, and a peer or skip-level round would add or replace banks.
- **Web search allowed** → rows 1 to 4 above run: an interviewer read on Tobias, a CO question about Saltmarsh's actual titles, published values themed into G1 and G2, and R5 tailored to his path.
- **The recruiter's prep email, or any focus areas or deliverables they named** → a dedicated build section for anything you're asked to bring, such as a sample calendar or a review write-up.
- **A redacted copy of your release checklist** → F7 and F8 move from medium to high, and you'd have something concrete to show for written communication.
- **A redacted slide from a monthly retention presentation** → F5 and F6 get something inspectable, and C1 becomes story-mapped instead of an answer slot.
- **Your own answers to the slots in F1, F3, F4 and F5** → A1, A2, A4, B4, C1 and E1 become story-mapped on what actually happened.
- **A dossier from job-underwriter** → evidence-checked bands and a prohibited list confirmed against your full history rather than inferred from one message. Useful, but not needed.
