Working on your prep pack now. I'm running a few quick searches on Kelverton Rail and the panel before I build it.
I've built your prep pack for Tuesday. I couldn't do any web research because all five searches were refused, so it's based only on your message and the recruiter's email. Anything about Kelverton's strategy is marked as a general pattern for this kind of role, not a fact about them.

The pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/opus/alone/part-2/rooms/case-5-denied-0a155fae/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

- **How it fits your four hours:** a seven-step schedule. The first 75 minutes go on the 15-minute POV and the next 45 on the main objection.
- **The POV:** three possible theses to choose from, each with the concession you should make, a way to use the market report without just repeating it, a "what I wouldn't do" point, and a six-part outline. The last two minutes close on what it means for operators, as the recruiter asked.
- **Questions to rehearse:** 23 questions with answer guidance, grouped by interviewer style and weighted towards Deepa's planning cases and Ross's push on commercials.
- **Your hardest question is C1:** "You've never carried a direct quota. Why should we trust you with a commercial number?" The guidance is to admit it once in plain words, then stand on the 6-to-40 partners and roughly £4M of influenced revenue, then propose what you'd be measured on here.
- **Claims to avoid:** the pack lists what not to say. That includes describing the £4M as closed or annual revenue, saying you built the ISV channel from scratch, or implying your consulting work covered heavy rail.

Say the word and I'll play the Skeptic on C1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, and your CV if it's handy? Three of the six requirements in the pack (rail, quota, negotiation) are guesses about what the role needs, and the JD would replace them with its own words.
Could you share the market report's headline points, even paraphrased? Right now every reference to it in your POV is a placeholder for you to fill from memory.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel, Tuesday
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)
**Format, in the recruiter's words:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."

Built without a JD, a CV, the market report's contents, or web research (every search was refused). Requirements come from the recruiter's email where it gives them and are labelled `[generic]` where it does not.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who asks it and in what tone. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behavioural or values alignment
  - **EXP**: work-experience deep-dive (does your history hold up when probed, and what was actually yours)
  - **JD**: role-driven (can you do the job as described, gaps included)
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, worked through out loud
- Provenance labels: `[grounded]` traces to something you or the recruiter wrote; `[inferred]` is this pack's derivation, with the derivation named; `[generic]` is a pattern for this kind of role, with no claim about Kelverton.
- An **answer slot** is the place where the pack doesn't know what you did. It gives you two honest branches. Fill it from memory, in your own words, or take the branch that says the thing didn't happen.
- The guidance is scaffolding, not a script.

---

## Prep triage (about 4 hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV from section 5. Pick one thesis, write it as six beats on one card, and say it aloud twice, timed to 13 minutes so there is room for interruptions | Graded deliverable |
| 2 | 45 min | Rehearse C1 aloud until the concession sounds boring. Then defend B1 and B2: how each figure was counted, and what part was yours | C1, B1, B2 |
| 3 | 30 min | Ross's commercials: B3, B4 and D3 out loud, each in under two minutes | Bank B, D3 |
| 4 | 30 min | Deepa's cases: A2, A3 and A5, each worked through in the clarify, structure, answer order | Bank A |
| 5 | 20 min | C2 and D1, the rail gap, until you can concede and pivot in one breath | C2, D1 |
| 6 | 20 min | Choose three reverse questions, one aimed at each panellist and one about the report | Reverse questions |
| 7 | 20 min | One last timed run of the POV, ideally out loud to another person | Graded deliverable |

Everything else in this pack is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter | "9 years in partnerships" — your message; "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material describes an ISV channel at a payments company, not operator partnerships in rail, and the words should stay there: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: an 18-month plan for partnerships makes a probe on channel planning likely. If setting the channel's priorities or plan was your job, say how you did it, in your own words. If it wasn't, or there was no formal plan, say so plainly and stay with running the channel |
| F2 | "Ross will push on commercials" — recruiter | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Influenced revenue is commercial evidence, and it is not the same thing as a closed number. Words: "My number was roughly £4M of influenced revenue. I haven't carried a direct quota." Answer slots, in your own words: how the £4M was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of it was yours. "I don't know exactly how it was counted" is an honest branch |
| F3 | "land on what it means for the operators themselves" — recruiter | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, from consulting. It doesn't say train operating companies, and it doesn't say working inside an operator. Words: "Before partnerships I spent five years in transport consulting, on bus and light rail network planning." Answer slot: what "the other side" was, meaning who you worked for and what you saw of how operators make decisions, said in your own words. If it was further from operators' day-to-day decisions than the phrase suggests, say that plainly |
| F4 | Working with UK train operating companies as customers or partners (role-family requirement, no source) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap you have stated, and no wording closes it. Words: "I haven't sold into rail specifically." After that, say how you would learn the territory, framed as a plan and never as something you've done. Don't add anything to make the gap sound smaller |
| F5 | Owning a commercial target (role-family requirement, no source) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap you have stated. Words: "I haven't carried a direct quota; my number was influenced revenue." What you would be willing to be measured on here is a proposal about the future, never a claim about the past |
| F6 | Negotiating partner terms and managing senior stakeholders on both sides (role-family requirement, no source) | none given | none | [generic] | discovery | Strong evidence here is one specific negotiation: what was at stake, what you gave up, what you held, and whether the relationship was still intact afterwards. Selection scaffold: pick one partner negotiation or senior disagreement from the ISV channel that has a named stake and a clear outcome. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one |

---

## Graded deliverable: the 15-minute POV

**What the brief asks for, in the recruiter's words:** "where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", and "land on what it means for the operators themselves". Ross is also expected to "push on commercials", so expect him to interrupt the POV with a revenue question (D3).

**Facts about you that the POV can draw on.** Use each one only at the scope of its quote.

- F1: "last 4 at a payments company running the ISV channel" and "took it from 6 partners to 40, roughly £4M of influenced revenue"
- F3: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F4 and F5 are the limits. Say them before Ross does, once and briefly, and then move on.

**Differentiating from the market report.** Deepa and Ross have read the report too, so reciting it scores as homework. Use it this way: name one point from it that you agree with (to show you read it), then one point where you would go further or in a different direction, with your reasons. Answer slot: which report point is which is your call, from your own reading. If nothing in it strikes you as worth departing from, say what you would test first, not what you disagree with. Never correct the report as though its authors had got it wrong. Frame the divergence as where you would place the bet.

**Thesis options.** Pick one and build the 15 minutes around it. All three are `[generic]`, because the pack has no Kelverton strategy material. Sharpen whichever you pick against the report.

| # | Thesis | Mandatory concession | Provenance |
|---|---|---|---|
| T1 | Define each operator partnership by the operator problem it removes, not by the partner's logo. Every partnership has a named operator workflow before and after the scheduling software, and a measure the operator itself cares about | It is slower to show partner numbers, and some good-looking partnerships won't pass the test | [generic] |
| T2 | Go deep before going wide. Months 0 to 6: two or three anchor partnerships, each tied to a named operator. Months 6 to 18: turn what worked into a repeatable programme with standard terms | The pipeline looks thin in the first two quarters, and it all depends on picking the anchors well | [generic] |
| T3 | Agree on how partnerships are measured before scaling them. With Ross in month one, set what counts as partner-sourced versus partner-influenced, and report against that definition from then on | It exposes partnerships to a harder number earlier, and the first quarter of reporting may look worse than a softer definition would | [generic] |

**The anti-pick.** Say what you would *not* do, for example: "I wouldn't chase a big partner count in year one." Concession: a partner count is the easiest figure to show a board, and you are choosing not to lead with it. Give the reason in one sentence. If you use your own channel growth as a contrast, keep it at the scope of F1's quote ("took it from 6 partners to 40"), and don't characterise how that growth happened unless you fill F1's answer slot first.

**A six-beat spine (about 13 minutes):**

1. The frame in one sentence: your thesis.
2. What you'd keep from the report (consensus) and where you'd go further (your divergence).
3. Months 0 to 6: what you would do, with whom, and what you would need from Deepa.
4. Months 6 to 18: how it scales, and the anti-pick.
5. The commercials: how you would want it measured (T3 logic, whichever thesis you picked). State F2's words here before Ross raises them.
6. **The close Deepa asked for, on what it means for operators.** Spend the last two minutes here. Say it in the operator's terms: what an operator's team stops doing, gets sooner, or no longer has to reconcile because the partnership exists. Answer slot: if your consulting work (F3) gave you a concrete sense of where operator teams lose time, use it, at its own scope: bus and light rail, from consulting. If it didn't, frame the close as the questions you would ask operators in your first 90 days.

**Delivery.** With no slides, the panel is relying on your structure to follow you. Announce the six beats at the start ("three parts and a close") and signpost each transition out loud.

---

## Reading the interviewers

Public footprint research was refused in this session, so this section covers only what the recruiter wrote.

| Panellist | What's established | Practical implication | Provenance |
|---|---|---|---|
| Deepa | "VP Partnerships, your future manager" — recruiter | She is the one buying capability and judging your plan against her own. Expect Case and Skeptic questions, and treat A5 (what you'd need from her) as scored | [grounded] |
| Ross | "Commercial Director" and "Ross will push on commercials" — recruiter | Every figure you mention will be probed (Prober persona). Expect interruptions during the POV (Pressure persona), and expect him to come back to F2 and F5 | [grounded] |

There are no mirror opportunities (shared career moves) to offer, because no career history was found for either panellist.

---

## Persona table

The loop is established by the recruiter's email: one 60-minute panel, a 15-minute POV, then Q&A. No values round is named, so no values cheat sheet is included.

| Persona | How it shows up here | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa's follow-ups on the POV, and live operator problems | High. A hiring manager's dominant persona, plus a deliverable that is itself a plan | Clarify, then state the objective, then structure, then answer. Say the structure aloud, and respectfully challenge one premise per case |
| Data-Driven Prober | Ross on any figure you say | High. The recruiter wrote "Ross will push on commercials" | Know what you can and can't say about how each of your figures was counted. Name your weakest assumption before he does |
| Skeptic | Both of them, on rail and quota | High. F4 and F5 are the two stated gaps, and a manager's prior includes the Skeptic | Rehearse C1 until it's boring. Concede what you stated, hold what your quotes carry, then give a ramp plan |
| Pressure | Ross interrupting the POV, time-boxed questions | Medium. "push" is the recruiter's word, and an executive's prior includes Pressure | Pause, restate the question, and hold your position through two follow-ups before conceding anything real |
| Conversational | The opening minutes, and the hand-off from POV to Q&A | Low, but still scored | Have a 90-second biography arc ready |
| Peer Evaluator | Ross on the seam between partnerships and his commercial team | Low. This is an inference from the two roles, and nothing the recruiter wrote states it | Propose principles for the seam rather than pretending to know where it sits |
| Values / Behavioural | One or two "tell me about a time" questions | Low. No values round is named | Use the selection scaffolds, and take the honest branch if no story fits |

---

## Question banks

### Bank A: Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] "last 4 at a payments company running the ISV channel" | Run the six-beat spine from the graded-deliverable section. Mention your background only once, at the scope of the quote: four years running the ISV channel at a payments company. Close on the operators | This is the recruiter's own brief, so it will be asked. CASE because it's scored on structure as much as content |
| A2 | "If you could land only two operator partnerships in your first six months, how would you choose them?" | CASE | [generic] | Clarify first: which operators matter most to Kelverton, and what each partnership needs to prove. Then give your selection criteria (operator pain, how hard the integration is, whether a partner will co-invest, whether an operator will co-sponsor), pick, and name the risk of the pick. The question needs no claim about your past, so the guidance makes none | It tests T2-style thinking directly and comes naturally out of any 18-month plan. CASE because it's a live prioritisation problem |
| A3 | "An operator says they like the scheduling product but our partner integrations create more work for their team. What do you do?" | CASE | [generic] | Structure it: listen and quantify the extra work in the operator's own terms, find which handoff causes it, decide whether to fix it, redesign it, or end that partnership, and agree what you'll report back. End on the operator outcome. It presupposes nothing about your past | It tests the "what it means for operators" lens from F3's requirement. CASE because the problem is hypothetical |
| A4 | "What did you take from the market report, and where would you go further?" | CO | [grounded] | Bring one point you agree with and one place you'd push further, with reasons. Answer slot: which points those are comes from your own reading; if you'd depart from nothing, say what you'd test first. Don't recite the report, and don't correct its authors | The recruiter attached the report, so this question is the obvious check that you read it. CO because it tests strategy fluency |
| A5 | "What would you need from me in your first 90 days?" | CASE | [generic] | Name two or three concrete things: access to two or three operators to listen to, the history of current partnerships, and early agreement with Ross on how partnerships are measured (T3). Make each one specific, and make each one help her too | Deepa is your future manager, so this is a working-style probe dressed as a planning question. CASE because it's scored on judgment |

### Bank B: Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Six partners to forty. Walk me through that." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Start with the quote's own words: you took the channel from 6 partners to 40. Answer slots, in your own words: how a partner was counted in that figure, what the figure is sensitive to, the assumption behind it you'd defend least, and which part of the growth was yours. If you don't know how it was counted, say so | It's a headline metric, so expect a defend-the-number question (F1). EXP because it tests attribution |
| B2 | "How was the £4M of influenced revenue counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Keep "roughly" and keep "influenced". Answer slots, in your own words: how it was counted, over what period, what it is sensitive to, the assumption you'd defend least (say it before he asks), and which part was yours. "I don't know exactly how it was counted" is an honest branch, and it's better than a method you can't repeat under a second question | F2's figure, put to the Commercial Director. EXP because the probe is about counting, not strategy |
| B3 | "How would you want partnerships here measured, and what number would you sign up to?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Answer as a proposal: what you'd measure (partner-sourced versus influenced, agreed upfront, as in T3) and how you'd build a first-year target once you'd seen the data. If your background comes up, use exactly F5's words: "I haven't carried a direct quota; my number was influenced revenue." Don't invent a figure for Kelverton's pipeline | "push on commercials" is the raising source. JD because owning a number is likely part of the role |
| B4 | "How would you structure the commercials with a vendor that sells into the same operators as we do?" | CASE | [generic] | Lay out the options as a structure: referral fee, resale margin, co-sell with shared attribution, or a technology partnership with no money changing hands. Then say what each one optimises for and what would make you choose it. Answer slot: if you set partner terms at the payments company, say how, in your own words; if not, say so plainly and stay with the structure | It's Ross's native ground. CASE because it's scored on reasoning, not recall |
| B5 | "When do you kill a partnership?" | CASE | [generic] | Give your criteria: the cost to serve versus the revenue it sources or influences, operator outcomes, and strategic fit. Add a review cadence and how you'd exit cleanly, without damaging the relationship. It presupposes nothing about your past | It tests whether you'll say no, which is the anti-pick logic. CASE |

### Bank C: Skeptic (both panellists)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **Highest-ROI prep in this pack.** "You've never carried a direct quota. Why should we trust you with a commercial number?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | **Concede first, precisely:** "I haven't carried a direct quota; my number was influenced revenue." **Then hold on what your quote carries:** "I took the ISV channel from 6 partners to 40, and it was roughly £4M of influenced revenue." Answer slot: if you were measured against a target for that figure, say how, in your own words; if you weren't, say so plainly and stay with the figure. **Then move forward:** what you'd be willing to be measured on here, as a proposal (B3). **Follow-up 1, "So you've never closed anything?":** answer slot: if you negotiated or signed partner agreements, say which part was yours; if not, say so plainly and return to the channel. **Follow-up 2, "Influenced is a number anyone can claim":** name the assumption behind the £4M you'd defend least (B2's slot), in your own words, then hold the figure, with "roughly" kept. Concede uncertainty in how it was counted if you have to, but never deny the figure itself. Don't defend the gap at length: one concession, one hold, one forward step | The recruiter flagged commercials, and F5 is a gap you stated, so this objection will come in some form. JD because it scores the role's commercial core |
| C2 | "I don't see rail in your background. How would you win trust with operators?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | "I haven't sold into rail specifically." Then the quote at its own scope: five years in transport consulting on bus and light rail network planning. Answer slot: what that side of the operator world was, meaning who you worked for and what you saw of operators' decisions, in your own words. Then a 90-day plan to learn the territory, framed as a plan. Never say heavy rail, and never imply you worked inside an operator | F4 is your second stated gap. JD because domain fit is the role's other half |
| C3 | "Why leave payments for rail-tech, and why now?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer slot: your actual reasons, in your own words. The one link your material carries is the consulting background at its own scope. If a return to transport is part of the reason, say it plainly; if it isn't, don't put it on. Keep it under 60 seconds and point it forward | It's a standard motivation probe, sharpened by the industry switch. JD because motivation consistency is scored |
| C4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Pick one stated gap, F4 or F5, and say it in its plain words: "I haven't sold into rail specifically." Then give the concrete ramp plan. One gap, said once, without minimising it. Don't pick a fake weakness | It's a Skeptic stem. Answering with a stated gap earns credibility. JD |

### Bank D: Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's sold to train operators for ten years?" | JD | [grounded] "Never sold into rail specifically"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause first. Concede in one clause: "I haven't sold into rail specifically." Then hold on the quote: you took a channel from 6 partners to 40. Then your POV's thesis in one line. Stop before 60 seconds. If he pushes again, hold once more before conceding anything else | F4 asked under time pressure. JD content, Pressure delivery |
| D2 | "That six-to-forty: how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: which part was yours and which was the team's, the product's or the market's, in your own words. Use "we" for context and "I" for your contribution. If you're not sure where the line falls, say so. Don't fold to "it was the team" just to ease the tension, and don't claim the whole thing | It's a Pressure stem aimed at F1's figure. EXP because it tests attribution |
| D3 | (He interrupts the POV) "Fine, but what does that make us in 18 months?" | CASE | [generic] | Don't invent a figure. Say: "I'd want to see the current partner-influenced pipeline before naming a number, and here's how I'd build it." Then give two or three inputs in one breath and go back to the POV. Hold that line if he pushes, and offer a follow-up after the interview | "push on commercials" makes an interruption likely. CASE, because it's about building a number, not recalling one |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships"; "last 4 at a payments company running the ISV channel" | A 90-second arc from those sentences only: consulting on bus and light rail network planning, then partnerships, with the last four years running the ISV channel at a payments company. Answer slot: why each move happened, in your own words. Finish with why this role, in one line | It's the opener that's still scored. EXP because it sets up every later probe |
| E2 | "What kind of manager gets the best out of you?" | VAL | [generic] | Selection scaffold: give a concrete working preference and an example of it working. If no example comes to mind, say what you'd ask Deepa for in practice. Make it compatible with A5 | Deepa is your future manager, so it's asked casually but scored. VAL |

### Bank P: Peer Evaluator (Ross, on the seam)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Partnerships and my commercial team both touch operators. Where's the seam, and what happens when we disagree on a deal?" | CASE | [generic] | Propose principles for the seam, not a turf line: who owns the operator relationship, when a partner joins a deal, and how disagreements get escalated. Selection scaffold (F6): if you have a disagreement with a sales or commercial peer where you held your position and the relationship stayed intact, tell it; if none comes to mind, say so plainly and describe how you'd handle one | An inference from the two roles. CASE because it's a design problem |
| P2 | "When a partner-influenced deal closes through sales, how do you handle credit?" | CASE | [grounded] "never carried a direct quota, only influenced revenue" | Principle first: agree attribution rules before the deal starts, not after (T3). Answer slot: if there were attribution rules with sales for the influenced revenue at your last company, describe them in your own words; if not, say so plainly and stay with the principle | F2's influenced figure is exactly where credit gets contested. CASE |

### Bank V: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you told a partner something they didn't want to hear." | VAL | [generic] | Selection scaffold: choose a moment with a named stake, where the message actually landed and the relationship survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It's a Values stem about delivering a hard truth. VAL |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: choose a time the customer's outcome beat a number you were judged on, and say what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It echoes the recruiter's "what it means for the operators themselves". VAL |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 18-month operator partnerships POV | A1, A2, A5, B1, D2 |
| F2 commercials | B2, B3, B4, B5, C1, D3, P2 |
| F3 what it means for operators | A3, C2, C3, V2 |
| F4 working with train operating companies | C2, C4, D1 |
| F5 owning a commercial target | C1, B3 |
| F6 negotiation and senior stakeholders | P1, V1, B4 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (To Deepa) "What would make you say, 12 months from now, that this hire was the right one?" | It shows you're thinking about her definition of success, which matters because she would be your manager |
| R2 | (To Ross) "How are partnerships measured commercially today, and what would you change about that?" | It answers the measurement debate on his ground and sets up T3 without lecturing him |
| R3 | "Which operator partnership do you consider the best one you have today, and what makes it work?" | It gets you a real example to calibrate your POV against, and it signals operator focus |
| R4 | "The report your strategy team circulated: which part of it is most contested internally?" | It shows you read the report and want the debate behind it, not just the summary |
| R5 | "Where do partnerships and the commercial team overlap with operators today, and where does that friction show?" | It surfaces the P1 seam honestly, as a question rather than an assumption |
| R6 | "What does an operator say when they're unhappy with a partner integration?" | It brings things back to the operator outcome Deepa asked you to land on |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a revenue quota, or "owned a number" | A negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't carried a direct quota; my number was influenced revenue." No slot |
| Has sold into rail, or knows train operating companies as a seller | A negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't sold into rail specifically." No slot |
| £4M of sourced, closed or annual revenue | The inflated form of F2 | F2's quote at its own scope: "roughly £4M of influenced revenue". The pack observes that the material says influenced, not closed, and gives no period. B2's slots stay inside how that figure was counted |
| Built or founded the ISV channel | The inflated form of F1 | F1's quote at its own scope: "took it from 6 partners to 40". The pack observes that the channel already had 6 partners. D2's slot asks only which part of the growth was yours |
| Heavy-rail or train-operator experience from consulting | The inflated form of F3 | F3's quote at its own scope: bus and light rail network planning, in consulting. C2's slot stays with who you worked for |
| Worked inside an operator | The inflated form of F3 (relationship) | F3's quote at its own scope. The pack observes that the material says consulting, from "the other side" |

---

## Sources

**Provided material**
- Your message, including the recruiter's email as you quoted it.
- The internal market report: you have read it, but its contents were not shared with this session, so nothing in this pack draws on it. Every report reference is an answer slot.

**Searches sent** (all refused: web search permission was not granted)
1. `Kelverton Rail values`: refused
2. `Kelverton Rail interview process partnerships`: refused
3. `Kelverton Rail scheduling software train operating companies news 2026`: refused
4. `Kelverton Rail Deepa VP Partnerships Ross Commercial Director`: refused
5. `"Senior Partnerships Manager" rail software job description UK`: refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Refused. It would have given value names to theme the V bank. No values round is named, so there would be no cheat sheet either way |
| 2. `Kelverton Rail interview process` | unavailable | Refused. It would have checked loop structure, but the recruiter's email already establishes this session |
| 3. `Kelverton Rail` strategy and recent news | unavailable | Refused. It would have grounded A4, the theses and the CO questions. The market report could fill this gap, but its contents aren't in hand |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Refused. It would have given career patterns for the interviewer read, persona weights and one reverse question tied to a panellist's path |
| 5. Representative Senior Partnerships Manager JD | unavailable | Refused. It would have turned F4 to F6 from `[generic]` into `[inferred]` rows quoting a real posting |

---

## Upgrade menu

- **The JD text**: F4, F5 and F6 move from `[generic]` to `[grounded]`, any unlisted requirements get JD questions, and the coverage table is checked against the real list.
- **The market report's headline points** (paraphrased is fine): the theses T1 to T3, A4 and R4 get grounded in Kelverton's own framing, and the consensus-versus-divergence move in the POV gets real material.
- **Your CV**: the evidence cells gain dates, scope and titles, and E1's arc can be story-mapped rather than built only from the quotes in your message.
- **Allowing web search** (L1 rerun, up to 6 searches and 2 fetches): Kelverton's strategy and news for A4 and the CO questions, the panellists' public career paths for the interviewer read and a tailored reverse question, and a representative JD.
- **A deeper research pass** (L2, up to 6 more searches and 2 more fetches on top of L1, several more minutes, only if you consent): a strategy brief, the panellists' talks and writing, loop reports and recent org context.
- **Your answers to the answer slots** in F1, F2 and F3 (how the £4M was counted, which part of the 6-to-40 was yours, and what "the other side" was): this rebuilds C1, B1, B2, D2 and C2 on your own words.
- **A tuesday-dossier.md from the job-underwriter skill**: it would supply verified evidence and an evidence-derived top objection. It's optional, and this pack stands without one.
