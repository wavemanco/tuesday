Four research searches are back (values, the interview loop, recent news, and the interviewer). Next I'm reading the official values and interviewing pages, then I'll write the pack.
I'll use Edit instead.
Femi, your prep pack is ready: `saltmarsh-games_live-operations-producer_interview_pack.md`. I assumed Friday is the round Saltmarsh's careers page calls "the Outage Hour", with Tobias as the hiring manager. That page describes it as one 60-minute session: a tabletop exercise on a simulated outage during a live event, then a values conversation.

Three things from the research shaped the pack the most:
- **Project Larkspur.** Saltmarsh announced that from February 2027 both titles move to a season-pass model on one shared events calendar. You told me you've never worked on a game with in-app purchases, so I expect that objection. Question B1 is the deepest rehearsal in the pack: say the limit plainly first, then talk about the content-drop calendar you ran, then give a plan for learning the season-pass side.
- **Tobias's background.** He was a QA lead before live ops, and gave a GDC 2026 talk called "Patch Notes Are a Promise". That puts your release checklist at the centre (D2), and fits Saltmarsh's value "Ship the Patch Not the Promise".
- **The values.** There are three: Players Before Plans, Ship the Patch Not the Promise and Leave the Build Greener. Your checklist gives you a real story for the third. For the first two, the pack helps you choose a story, or say honestly that you don't have one.

Say the word and I'll play the sceptical interviewer on B1, the question the pack names as its highest-value prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Friday the Outage Hour with Tobias as the manager you'd report to, and did the recruiter name any focus areas? Your answer confirms or reshuffles the weighting of every question bank.
Would you like a deeper research pass (up to 6 more searches and 2 more page fetches, several more minutes) on Project Larkspur, the two titles' current events and Tobias's talk?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The pack treats him as the hiring manager, because Saltmarsh's careers page says the 60-minute interview is with the hiring manager. That is an inference, and it is unconfirmed.
**Format:** 60 minutes, Friday. Saltmarsh's careers page calls this round "the Outage Hour": "a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."

---

## How to use this pack

Each question has two labels. The **persona** describes how it will be asked. The **type** describes what is being scored.

| Type | What it's scoring |
|---|---|
| VAL | Whether your past behaviour shows Saltmarsh's *published* values |
| EXP | Whether your stated experience holds up under scrutiny, and which parts were yours |
| JD | Whether you can do what the job description lists, including its gaps |
| CO | Whether you know the company: its strategy and recent moves |
| CASE | How you structure and reason through a live problem from the role |

Question IDs use one letter per persona (A, B, C, D, E, G, H). Fit-snapshot rows are F1 to F9, so the letter F is not used for a bank.

Provenance labels: `[grounded]` means traceable to what you told me, the JD, or a source listed under Sources. `[inferred]` means derived, and the derivation is named. `[generic]` means a role-family pattern that makes no claim about you or Saltmarsh.

**The guidance is scaffolding, not a script.** Rehearse the structure and say it in your own words. An "answer slot" marks a place where only you know the answer. It has two honest branches, and either one is a good answer.

---

## Prep triage (the interview is tomorrow)

1. **B1 out loud, three times.** This is the highest-ROI prep in the pack: you have never worked on a game with in-app purchases, and both Saltmarsh titles are moving to a season pass. Get the plain acknowledgment and the ramp plan to the point where they bore you.
2. **A1 and A2 out loud, once each.** The outage tabletop is half the hour. Practise the structure (scope, stabilise, people, players, record) until you don't have to think about the order.
3. **The values cheat sheet, tonight.** Pick a real story for each of the three values, or decide on the honest branch. C1 and C2 have no story in your material yet, so the choosing is up to you.
4. **D1 and D2.** Know exactly what your release checklist contains and where the retention numbers came from. A former QA lead will ask about the checklist in detail.
5. **Pick three reverse questions**, including R1 or R2.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material describes one title's content-drop calendar, not a live-events calendar across two titles. The words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "two of our mobile titles" makes a probe on juggling titles likely. If any of your weeks involved planning around another title, say how in your own words. If none did, say so plainly and describe how you would plan two titles |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message, and "Never led a team" — your message | low | [inferred] | discovery | Running a calendar touches coordination without showing it, and the JD says coordinate, not lead. Answer slot: if your drops involved working with design, art, engineering or community, say which teams and what you did with them, in your own words. If they didn't, say so plainly and stay with the calendar. If you are asked about leadership, the words are "I haven't led a team" |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a post-event review. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you produced those numbers yourself, or read any of them against a specific content drop, say how. If someone else produced them, or they were never tied to a drop, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but it rests on your word alone, so expect a detailed probe, probably from a former QA lead. Lead with the quote's own terms: you wrote it, and QA still uses it. Answer slot: the JD's "manage" makes a probe on upkeep likely. If you maintained it with QA after writing it, say how. If you didn't, say so plainly |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message, and "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | The quotes show four years as an associate producer and two years running a weekly calendar. They don't show whether all four years were on a live game. Answer slot: if the main title was live throughout your four years, say so. If the live work was the last two years, say that plainly. Two years stated precisely beats four years stated loosely |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. This is your strongest row. Say it in its own words and expect a request for one specific week |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but expect a probe on which metrics they were and who calculated them. Know what you can and can't say about how the numbers were counted. "I didn't calculate them" is an honest answer if it's true |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The checklist is written work another team still relies on. Say just that: "I wrote the release checklist our QA team still uses." The tabletop's player-facing message (A5) is where they'll see your writing live |
| F9 | Running events inside a season-pass model. Not in the JD; derived from Saltmarsh's Project Larkspur announcement (Sources) | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | You have said this yourself, so wording can't close it. The words: "I haven't worked on a game with in-app purchases." Then say how you would learn it, as a plan and never as a past. Add nothing to make the gap feel smaller |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Live-events calendar, two titles (F1) | A3, B3 |
| Coordinate design, art, engineering, community (F2) | B2, H1, H2 |
| Post-event review and its KPIs (F3) | A4, D3 |
| Release checklist with QA (F4) | D2, E2, C3 |
| 3+ years live-service (F5) | B4 |
| Content calendar (F6) | A3, B3, G1 |
| Player-retention metrics (F7) | D1, A4 |
| Clear written communication (F8) | A5, H1 |
| Season-pass context, not in the JD (F9) | B1, E1 |

---

## Reading the interviewer

| Fact | Provenance | Source |
|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | [grounded] | GDC 2026 talk listing (search result, not fetched) |
| Gave a GDC 2026 talk, "Patch Notes Are a Promise", arguing that "a live team is judged by how often its patch notes describe what actually shipped" | [grounded] | Same listing |

What this means in practice:

- **Your release checklist (F4) will be read by someone who came up through QA.** Expect D2 to go two levels deep: what is on it, why it's in that order, and what it has caught. Know the document well.
- **His talk and the value "Ship the Patch Not the Promise" make the same point.** In the tabletop, any message to players should promise only what is confirmed. In A5, saying "we don't have a fix time yet" is the strong answer, not the weak one.
- **Shared vocabulary:** "what actually shipped". Use it in your reverse question (R1), not as flattery inside your answers.
- **No shared career jump.** His public path is QA to live ops, and your material describes no move from QA, so the pack doesn't suggest one.

---

## Persona table

The loop is established by Saltmarsh's careers page: one 60-minute session, an outage tabletop and then a values conversation. The weights below follow that page, not an archetype.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The outage tabletop itself | Very high: the careers page puts a live-incident tabletop in this exact hour, and hiring managers lean towards cases | Clarify, stabilise, people, players, record. Think aloud and question one premise per case |
| B. Skeptic | "Why you, without X" probes on the gaps | High: hiring-manager prior, and F9 is a gap you have stated yourself, sitting next to the company's biggest current change | Rehearse B1 until it bores you. Plain acknowledgment, then F6's quote, then a ramp plan |
| C. Values / Behavioral | The second half of the hour | High: the careers page documents a values conversation, and the three values are published | One story per value where your material carries one (C3). Otherwise use the selection scaffold and its honest branch |
| D. Data-Driven Prober | Depth on the checklist and the retention numbers | Medium: a former QA lead, plus a JD that asks you to own KPIs | Know what you can and can't say about F4 and F7. Name a limit before it's extracted |
| E. Pressure | Compressed "why you" moments | Low to medium: tabletops can be time-boxed, but his public profile shows no stress-interview signal | Pause, restate the question, anchor in your own sentences, hold through two follow-ups |
| G. Conversational | The opener, and the reverse-question slot | Low to medium: every hour has an opener, and it is still scored | A 90-second arc built only from your quoted sentences |
| H. Peer Evaluator | "You're between community and engineering" scenarios | Low: no peer is in this round, but the JD's coordination line brings it up in case form | Propose principles for the seam rather than claiming to know it |

---

## Question banks

### A. Case / Strategist (the outage tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Saturday evening, day two of a weekend event. Rewards have stopped granting for a chunk of players. Walk me through your first 30 minutes." | CASE | [inferred] | Five beats, said aloud. Scope: which players, which platform, since when, and whether it's still happening. Stabilise: options such as pausing the reward, extending the timer, or leaving it while engineering investigates, with the trade-off of each. People: engineering on-call, QA to reproduce, community to watch channels. Players: a first post saying what is known and when the next update comes. Record: a running log for the review. Ask one clarifying question before starting. The question needs no claim about your past, so the guidance makes none | The careers page names this exact exercise. The format is grounded; the scenario is the pack's own, so the row is `[inferred]` |
| A2 | "Engineering says the fix needs a client update that won't clear store review before the event ends. What do you do with the event?" | CASE | [grounded] | Set out the options: extend the event, end it on time and compensate affected players, or run a server-side workaround if one exists. Then choose one and give the reason. Saltmarsh's value "Players Before Plans" ("when the calendar and the players disagree, the players win") is the published tie-breaker, and you can name it. Say what you would tell players and when, promising only what is built | The usual second turn in an outage tabletop. `[grounded]` because the guidance's one factual claim is the published value |
| A3 | "From February both titles share one events calendar. How would you plan the first month so their events don't collide?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Structure: what each title's players expect week to week, shared dependencies (art, engineering, QA, store submissions), collision rules (no two launches on the same day, staggered reviews), and a single owner for the calendar. You can anchor once at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." Then make clear that two titles would be new to you, and say how you'd plan for it | The JD's two-title line plus Project Larkspur's shared calendar (Sources). CO because it tests whether you know the change that is coming |
| A4 | "The event's over. What goes in your post-event review, and which KPIs lead it?" | JD | [generic] | Structure: the goal set before the event, participation, retention around the event window, whatever the season pass measures, the incident log, checklist misses, and one change for next time. Give this as how you would build it. It is not a description of a review you ran (F3's slot governs that) | The JD's "own the post-event review" line. `[generic]` because the KPI list is a role-family pattern |
| A5 | "Mid-incident, players are asking on community channels when it'll be fixed, and you don't know yet. Give me the first post, out loud." | JD | [grounded] | Short and plain: what's happening, who's affected, what players should or shouldn't do, and when the next update will come. No fix time you don't have. This is "Ship the Patch Not the Promise" ("we announce what is built, not what is hoped") and the argument of Tobias's talk | JD content (written communication), CASE delivery, tested against a value and a talk he gave. `[grounded]` on both sources |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Both titles are moving to a season pass, and you've never worked on a game with in-app purchases. Why should I trust you with this calendar?" | JD | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years" | **Highest-ROI prep in the pack.** State the limit before he finishes the sentence: "I haven't worked on a game with in-app purchases." Then what you bring, at its scope: "For the last two years I ran the weekly content-drop calendar for our main title." Then a ramp plan, said as a plan: who owns the pass's economy, how pass tiers map onto event cadence, and which pass metrics the review should report. Follow-up 1 ("But monetisation is the point of Larkspur"): hold. The calendar is the job, and you're naming how you'd learn the pass side. Follow-up 2 ("How quickly?"): give the plan's first steps, not a date you can't back up. Never imply in-app purchase experience | F9 is a gap you've stated yourself, next to the company's largest current change, so some version of this is close to certain. JD-typed because it scores the calendar requirement under the new model |
| B2 | "This role coordinates design, art, engineering and community on every update. Have you led a team?" | JD | [grounded] "Never led a team" "I ran the weekly content-drop calendar for our main title for the last two years" | Plain acknowledgment: "I haven't led a team." Don't argue that coordinating isn't leading. Let the question move on. Answer slot: the JD's coordination line makes this probe likely. If your weekly drops involved working with design, art, engineering or community, say which teams and what you did with them, in your own words. If they didn't, say so plainly and describe how you ran the calendar | F2 is thin, and "associate producer" draws this question. Rehearsing the acknowledgment keeps it short |
| B3 | "You ran one title's calendar. This is two titles on one calendar. What's different?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Keep to the scope: one title, weekly drops, two years. Then name the differences as you see them (shared teams, collisions, two player bases) and how you'd plan for them. Don't claim multi-title experience | F1's transferability limit, asked directly |
| B4 | "How much of your four years was on a live game?" | JD | [inferred] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if the main title was live throughout the four years, say so in your own words. If the live calendar work was the last two years, say that plainly and give those two years precisely. Don't round up | JD because it scores a stated requirement. F5: the JD asks for 3+ years of live-service producing, and the quotes don't settle how many of your years count |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] | Selection scaffold for "Players Before Plans". Pick a time a planned drop changed, moved or was dropped because of what players did or said. It needs the plan, the signal, the call, and what your part was ("we" for context, "I" for your part). If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it | A published value in a round the careers page says includes values. No quoted sentence carries this story |
| C2 | "Tell me about a time something was about to be announced that wasn't actually built yet." | VAL | [grounded] | Selection scaffold for "Ship the Patch Not the Promise". It needs the announcement, the gap, what you did and the outcome. If no such time comes to mind, say so plainly. Then say how you would handle it, which Tobias's talk suggests he'll find a real answer | Value plus interviewer theme. No quoted sentence carries this story |
| C3 | "Tell me about something you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped for "Leave the Build Greener": you wrote the release checklist, and QA still uses it. Tell it in your own words. Answer slot: the value says "every release leaves… the checklist better". If you revised the checklist after releases, say what changed and why. If you didn't, or that was someone else, say so plainly and stay with having written it | F4 is the one quote that carries a values story directly, and the value names checklists |
| C4 | "When did you have to tell a senior person something they didn't want to hear?" | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold. It needs a named stake, the moment you said it, and an intact relationship afterwards. Your monthly presentations to the studio head are one place to look, if one of them carried news nobody wanted. If none did, and nothing else comes to mind, say so plainly and say how you'd handle it | A common values stem. The quote points to where a story might be without supplying one |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The monthly retention numbers you presented: which metrics, and where did they come from?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The beat the quote states: you presented them, monthly, to the studio head. Answer slot: name the metrics in your own words, say how they were counted and which part was yours, and name the assumption behind them you'd defend least. If you don't know how they were counted, or an analyst produced them, say so plainly. That is an honest and strong answer | F7 is a figure-shaped claim, and the JD asks you to own KPIs |
| D2 | "Walk me through the release checklist you wrote. What's on it?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | The beats: you wrote it, and QA still uses it. Describe what's on it from memory, in your own words. Answer slot: if you kept it updated with QA after writing it, say how. If you didn't, say so plainly | JD content (the checklist line), EXP delivery: F4, put to a former QA lead. This is the likeliest deep-dive in the hour |
| D3 | "On the weekly drops: how did you know whether one worked?" | JD | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: the JD's post-event review line makes this probe likely. If you looked at drops after they shipped, say what you looked at, in your own words. If there was no such review, or it wasn't yours, say so plainly and say what you'd measure first | F3's gap, approached through F6 |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live ops on a monetised game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "never worked on a game with in-app purchases" | Pause. Then: "For the last two years I ran the weekly content-drop calendar for our main title, and I wrote the release checklist our QA team still uses." Concede plainly: "I haven't worked on a game with in-app purchases." Hold the first two sentences through two follow-ups, and don't add to them | B1 under time pressure. The hold is only what the quotes carry |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote it." Answer slot: if others contributed items, say who and what, in your own words. Precise credit-sharing is a strength here | Attribution probe on the claim most likely to impress this interviewer |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Presented the monthly retention numbers to the studio head" | A 90-second arc built only from these four sentences, in this order. Answer slot: then say why live ops and why now, in your own words | The opener of nearly every hour, and still scored |
| G2 | "Why Saltmarsh?" | CO | [grounded] | You can name what you've read: Project Larkspur's shared calendar and the three values. Answer slot: what actually draws you, in your own words | Tests homework and motivation. Grounded on Sources |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Community wants to announce next event's dates. Engineering hasn't confirmed the build. You're in the middle. What do you do?" | CASE | [grounded] | Principles: nothing is announced until the build is confirmed ("we announce what is built, not what is hoped"), give community a date by which they'll know, and write down what each side needs. Plan, not past | The JD's coordination line, asked as a case against a published value |
| H2 | "Art can't hit the drop date. Walk me through the conversation." | CASE | [generic] | Clarify what's late and why, set out the options (cut scope, move the drop, swap content), decide who makes the call, and tell community. No claim about past disputes | The coordination seam, asked as a case |

---

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players conflict, the players win | Selection scaffold, C1. No fit-snapshot row carries this story. If none comes to mind, say so plainly and say how you'd handle it |
| Ship the Patch Not the Promise | Announce only what's built | Selection scaffold, C2. No row carries it. If none comes to mind, say so plainly and say how you'd handle it |
| Leave the Build Greener | Each release leaves the code and the checklist better | F4: "Wrote the release checklist our QA team still uses." C3's slot covers whether you revised it |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How does the team track that here today?" | Tied to his published work, and you learn how the team really works |
| R2 | "You moved into live ops from QA. Where would you draw the line between what the producer owns on the release checklist and what QA owns?" | Tied to his career path, and it answers F4's "manage" question for you |
| R3 | "With both titles on one calendar from February, what does the producer's first 90 days look like?" | Shows you know about Larkspur, and tells you what the job is |
| R4 | "Which KPIs does the post-event review report today, and who reads it?" | The JD's KPI line, turned into due diligence |
| R5 | "When the calendar and players last disagreed, who made the call?" | Turns the first value into a real question |
| R6 | "Six months in, what would tell you this hire worked?" | Gives you the scoring sheet for the job |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says one title's content-drop calendar |
| Has led a team | Negative you stated, F2 | "I haven't led a team." |
| Has worked on in-app purchases, monetisation or a season pass | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Owned the post-event review or the retention KPIs | Inflated form of F3 | F3's quote at its own scope. The pack's observation: the material says you presented the numbers. D1's slot stays inside presenting |
| Ran or managed QA | Inflated form of F4 | F4's quote: you wrote the checklist, and QA still uses it |
| Four years of live-service producing | Inflated form of F5 | Both F5 quotes, with B4's slot |

---

## Sources

**Provided:** the JD text and your background, both from your message.

**Research calls:**

- Search "Saltmarsh Games values" returned https://saltmarshgames.com/values
- Fetch https://saltmarshgames.com/values: three values with definitions
- Search "Saltmarsh Games interview process producer" returned https://saltmarshgames.com/careers/interviewing
- Fetch https://saltmarshgames.com/careers/interviewing: the Outage Hour format
- Search "Saltmarsh Games mobile studio news 2026" returned https://saltmarshgames.com/news/project-larkspur (snippet only, not fetched)
- Search "Tobias Wrenfield Saltmarsh Games Head of Live Operations" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only, not fetched)

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet, C1 to C3, A2, A5 and H1: three values by name |
| 2. Saltmarsh Games interview process | yes | Loop established (a tabletop, then values). Bank A leads, and bank C is included |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur: F9, A3, B1, E1, G2, R3 |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer read, A5, C2, D2, R1, R2 |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-typed questions |

---

## Upgrade menu

- Confirmation that Friday is the Outage Hour and that Tobias would be your manager → persona weights confirmed, or rebuilt if he's a skip-level or a peer
- The recruiter's focus areas, if they named any (usually one email) → coverage of those areas, and any declared deliverable gets its own section
- Your answers to the slots in B4, D1, B2 and C3 → rows F5, F3, F2 and F4 upgraded, with those slots turned into story maps
- The release checklist itself, a calendar export or a retention deck, where you're allowed to share them → F4, F6 and F7 move from `medium` to `high`
- Deep research (up to 6 more searches and 2 more fetches, several minutes): the full Larkspur announcement, the two titles' current events, Tobias's talk read in full, and recent org context → a grounding brief, a sharper B1 ramp plan, and A3 and the interviewer read resting on fetched pages instead of search snippets
- A tuesday-dossier.md from job-underwriter → the highest-ROI objection taken from verified evidence rather than inferred, plus a strategy constraint for each weak area
