Reading the skill's reference files before I build your pack. Four left, covering personas, research scope, the reframing audit and the evidence rules.
I've built your prep pack for Thursday's 45-minute hiring-manager conversation from the dossier, and saved it as `quartzline_product-manager-platform-apis_interview_pack.md`. It has 22 questions, nine fit rows (F1 to F9), five prohibited claims and six questions for you to ask.

- **Rehearse A1 first.** It's the objection the dossier named: you've never held the PM title or owned a roadmap, so why you over a PM with three years in the job? The guidance gives you three moves:
  1. Admit both gaps plainly, in the dossier's own words.
  2. Point to your 30+ API integrations and the playbook you wrote, as adjacent experience, and then stop.
  3. Lay out a 90-day plan, said as what you would do, never as something you've done.

  Two follow-ups are rehearsed too, including the prioritization one.
- **Ask about decision rights in every case question and at the end.** "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" The dossier's go is conditional on getting that answered.
- **Some questions are left for you to answer.** These cover API docs and schemas, sales, specs, adoption metrics and agile. The dossier doesn't show that work, so the pack leaves those parts for your own words. Each one also gives you an honest way to say it never happened.
- **There's nothing on Quartzline itself.** The three web searches I tried were refused, so the company-knowledge question (D2) and the case questions are generic. Skim their public developer docs yourself before the interview.
- **Check the date.** Today is Thursday 12 November. If you meant today, rehearse A1, A2 and B3, and read through the prohibited-claims table. Everything else in the pack is backup.

If you want, I'll play the Skeptic on A1 and push back on your answers.
I can also add what this prep turned up to your `tuesday-dossier.md`, so you can carry it into later sessions.
I can convert the pack to a Word document if you'd prefer that.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday. Interviewer name unknown.
**Built from:** your `tuesday-dossier.md` (v1.1, dated 2026-08-14). Web research was attempted and refused by this host, so everything about Quartzline beyond the dossier is labeled `[generic]`.

---

## How to use this pack

- **Personas** describe how a question is asked: register, pace, follow-ups. **Types** describe what is being scored. Rehearse both, because the same objection can come as a friendly aside or as a time-boxed challenge.
- **Type key:**
  - **JD**: can you do the listed job, gaps included.
  - **EXP**: does what you've done hold up under scrutiny, and how much of it was yours.
  - **CASE**: a live problem from the role, scored on structure and reasoning.
  - **CO**: company and strategy homework.
  - **VAL**: whether your past behavior shows the values the company publishes.
- **Provenance labels:**
  - `[grounded]`: traces to your dossier.
  - `[inferred]`: derived, with the derivation named.
  - `[generic]`: a role-family pattern that asserts nothing about Quartzline or you.
- **Your evidence IDs.** VE1, VE2 and VE3 are the three `verified_candidate_evidence` entries in your dossier, in order. Every sentence this pack gives you about your past is one of those three, quoted, or a plain acknowledgment taken from the dossier's `prohibited_claims` and `acknowledge_gap` entries. Anything else is an **answer slot**: an instruction for you to fill in your own words in the interview, with an honest branch for when the thing never happened.
- **Question IDs.** Banks run A, B, C, D, E, G, H. There is no bank F, because F1 to F9 are fit-snapshot rows.
- **Highest-ROI prep: A1.** The dossier named this objection, and it gets the deepest rehearsal in the pack.
- Guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

Requirements are the dossier's `role_profile` lines, which stand in for the JD. Confidence and gap type come from the dossier where it graded the row; the pack graded the rest.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Wrote the internal integration playbook her team uses" — dossier VE2 | low | [grounded] | transferability | The dossier's strategy here is to bridge, and its condition is that the bridge is positioned as adjacent and never as PM experience. Your words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live, and I wrote the integration playbook my team uses." The limit, from the dossier's `prohibited_claims`: "I haven't held a product manager title." Say it before they do. Then stop and let the interviewer make the connection. Don't call the work "PM-like" or "basically product" |
| F2 | "Own the roadmap for the partner-facing API platform" (dossier responsibility); roadmap ownership and prioritization authority (dossier R1 sub-claim) | none given | none | [grounded] | capability | The dossier records this as `acknowledge_gap`, so there is no bridge, and the nearby rows (F6 included) must not be used as one. Words, from `prohibited_claims`: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: how you'd learn the roadmap's inputs, who decides what with the squad leads, and what you'd want to be measured on. Nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" (dossier R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | transferability | Your material describes integrating clients onto an existing API, not shipping the API. Your words stay at VE1's scope. Answer slot: R2 makes a probe likely on whether any change to the API itself came out of your integrations. If any did, say what changed and what part was yours, in your own words. If none did, or it wasn't yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" (dossier R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | discovery | VE1 puts you inside REST API work, including architecture. It doesn't say whether that meant working from API docs and schemas. Answer slot: if you read, wrote or reviewed API docs or schemas in those integrations, say which and how, in your own words. If not, say so plainly and stay with the stages VE1 names |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | discovery | Client integrations from scoping to go-live put you with customers. Your material doesn't show who else you worked with. Answer slot: if engineering or sales were part of those integrations, say who and how you worked with them, in your own words. If they weren't, say so plainly and say how you would work with them here |
| F6 | "Run discovery with integration partners" (dossier responsibility) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | medium | [grounded] | transferability | The dossier marks this confirmed but with limited inspectable proof, and expects a probe, so volunteer that limit yourself. Words at the quote's scope: "I ran quarterly roadmap-input sessions that fed client evidence to product." Your material says you fed input to product, not that you ran product discovery. Answer slot: the JD's discovery line makes a probe likely on how the sessions were run. If you set what was asked or how evidence was gathered, say how in your own words. If not, say so plainly and stay with running the sessions. Never use this row to bridge F2 |
| F7 | "Write specs and drive delivery with two engineering squads" (dossier responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | discovery | VE1 names a requirements stage. It doesn't show whether that meant writing specs engineers built from. Answer slot: if you wrote requirements that engineers built against, say what form they took and how they were used, in your own words. If not, say so plainly and stay with the stages VE1 names. Prioritization for a squad is a prohibited claim, so nothing here touches it |
| F8 | "Define and track adoption metrics" (dossier responsibility) | none given | none | [grounded] | discovery | Your material doesn't show metric work. Answer slot: if you defined or tracked any measure of integration success, say what it counted and how, in your own words. If not, say so plainly and say what you would measure first (B2 rehearses this) |
| F9 | "Agile delivery experience" (dossier R5, preferred) | none given | low | [grounded] | discovery | The dossier's strategy is `clarify`, and no verified entry speaks to this. Answer slot: expect "tell me about your agile experience." If you worked in sprints, stand-ups or a similar cadence, say how in your own words. If you never worked that way, say so plainly. Either way, close with "here's what I'd want to confirm about how your squads run" |

---

## Persona table

The loop is set by your own words: one 45-minute conversation with the hiring manager. No interviewer profile exists, so the weights rest on the hiring-manager prior, adjusted by the dossier.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the PM-title and roadmap gap; "why should we take the risk" | Highest. The hiring-manager prior puts Skeptic near the top, and the dossier names a specific objection aimed at F1 and F2 | Rehearse A1 until it's boring. Concede what the dossier says you haven't done, bridge only with VE1 and VE2 at their own scope, and close with a ramp plan |
| Case / Strategist | Live problems from the role: adoption, squad trade-offs, partner requests | Highest. A hiring manager buying capability tests it on their roadmap, and the role's four responsibilities are all case-shaped | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Ask about decision rights and how adoption is counted, since the dossier lists both as unknowns |
| Data-Driven Prober | "How are you counting 30+?" and an integration walked end to end | Mid. VE1 carries a headline figure, and a hiring manager reading the dossier-equivalent CV will test it | Know what you can say about how the 30+ was counted, and say plainly what you don't know |
| Conversational | Opener, "walk me through your journey", casual technical asides | Mid. A 45-minute conversation almost always opens this way, and casual questions are still scored | A 90-second arc built only from VE1, VE2 and VE3 |
| Pressure | A time-boxed version of A1; "how much was actually you" on VE3 | Low. Nothing points to a stress format, but the gap invites it | Pause, restate, anchor on the quote, hold through two follow-ups |
| Peer Evaluator | Working with squad leads you won't manage | Low. Peers aren't in this round, but the hiring manager will price how you'd land with the two squads | Propose working principles; don't claim a past you don't have |
| Values / Behavioral | Generic behavioral prompts | Low. No values-style round is detected, and Quartzline's published values weren't retrieved | Selection scaffolds, each ending in an honest branch |

---

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; plus `prohibited_claims` items "Having held a product manager title or role" and "Having owned a product roadmap" | **Highest-ROI prep in the pack; the dossier named this objection.** Three moves. (1) Concede, plainly and first: "That's right. I haven't held a product manager title, and I haven't owned a product roadmap." No "sort of" and no "effectively." (2) Bridge, positioned as adjacent: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live, and I wrote the integration playbook my team uses." Then stop, and don't tell them what it proves. (3) Ramp plan, as a plan: what you'd do first to learn the roadmap's inputs, how decisions split with the two squad leads, and what you'd want to be measured on at 90 days. **Follow-up 1:** "A three-year PM has made prioritization calls." Hold, don't bridge: "Yes, and I haven't set prioritization for an engineering squad," which comes from `prohibited_claims`: "Having set prioritization for an engineering squad". Then the plan again. **Follow-up 2:** "So what's the risk in hiring you?" Name it yourself: owning the roadmap and its trade-offs is the new part. Then say how you'd de-risk it. Never fold on the integrations, and never stretch them | The dossier's named objection, aimed at F1 and F2, the two must-have pressure points. JD because it scores R1 directly. It gets the deepest follow-up ladder because the gap is real and the honest answer has to survive a second push |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] `prohibited_claims`: "Having owned a product roadmap" | Give the real one, F2: "Owning the roadmap. I haven't owned a product roadmap, so the trade-off calls would be new for me." Then two or three sentences of ramp plan. Don't offer a flattering fake weakness; a hiring manager hears it as evasion | F2 is the gap the dossier says to acknowledge, and a straight answer here earns trust for A1. JD because it maps the gap to the role |
| A3 | "Have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Stay at VE1's scope: you led client integrations of the vendor's REST APIs, scoping through go-live. Answer slot: R2's wording makes a probe likely on whether any change to the API itself came out of that work. If any did, say what changed and what part was yours, in your own words. If none did, or it wasn't yours, say so plainly and return to the integrations. Never describe integrations as shipping an API product | F3 is a must-have with only adjacent evidence. JD because it scores R2 |
| A4 | "Why move from integrations into product management, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your reasons, in your own words. The pack doesn't supply motivation. Answer slot: if running the roadmap-input sessions is part of why you want this, say how, in your own words. If it isn't, leave it out and give your real reason. Keep it to about 60 seconds and end on this role specifically, not on PM in general | Motivation consistency is the Skeptic's other half. It's tied to F6 only where your own reason runs through it. JD because it tests fit to the posting's move |
| A5 | "I don't see sales in your background — how would you work with our sales team on partner requests?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if sales were involved in the integrations you led, say how you worked with them, in your own words. If not, say so plainly. Then give how you'd do it here: a shared intake for partner requests, a clear yes, no or later with reasons, and early warning on anything promised to a partner | F5's sales leg is unshown. JD because R4 names sales explicitly |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has been flat for two quarters. Diagnose it." | CASE | [generic] | Clarify first: how is adoption counted today, and against what baseline? The dossier lists this as unknown, so asking is real diligence, not stalling. Then work a funnel: partner signs up, gets credentials, makes a first call, reaches production traffic, keeps using it. Find where the drop is, segment by partner type or size, form hypotheses (docs and onboarding friction, missing capability, pricing or commercial, reliability), then decide what data would separate them and what you'd do first. The question needs no claim about your past, so the guidance makes none | A live problem from the adoption responsibility (F8), and the most likely case for this role. `[generic]` because it's a pattern, not a fact about Quartzline |
| B2 | "How would you define adoption metrics for a partner API platform?" | CASE | [generic] | Split activation (time to first successful call), depth (call volume, endpoints used), breadth (number of active partners), retention (still active after N months) and partner outcome (what the integration does for them). Pick one leading and one lagging metric, say why, and name the instrumentation you'd need. Don't say you've defined metrics before | Covers F8 head-on, since your material is silent there. CASE because it's asked as a design problem |
| B3 | "Both squad leads want next quarter's capacity for different things. What do you do?" | CASE | [generic] | Open with decision rights: "First I'd want to know which calls are mine and which are the squad leads'." That's the dossier's open question, and asking it is the strongest move. Then make the criteria explicit (partner impact, adoption effect, cost, risk, dependencies), lay out the trade-off in writing, decide or escalate per those rights, and close the loop with whoever didn't get their way. Describe what you would do, never a time you did it, because prioritizing for a squad is a prohibited claim | Tests the specs-and-delivery responsibility (F7) and the dossier's unverified authority risk at once |
| B4 | "A large partner wants a custom endpoint only they would use. Sales is pushing. How do you handle it?" | CASE | [generic] | Clarify the underlying need, then ask whether others share it (can it be generalized?), what it costs to build and to maintain forever, what the commercial stake is, and what the alternatives are (an existing endpoint plus guidance, a parameter, a later roadmap slot). Give sales a clear answer with the reason. The platform-versus-one-off trade-off is the scored part | A classic platform-PM case, bringing in R4's sales and customer stakeholders |
| B5 | "Say you've joined. What do your first 90 days look like?" | CASE | [generic] | This is A1's ramp plan in full. Days 1 to 30: listen, meaning partner conversations, the squads' current work and the existing roadmap. Days 31 to 60: a baseline for adoption and agreed decision rights with the squad leads. Days 61 to 90: a first prioritized proposal and one spec through delivery. Say it all as "I would" | Lets you close F2's gap with a plan rather than a claim. Likely from a hiring manager weighing an adjacent hire |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30+ integrations: how are you counting that?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slots, all in your own words: how the 30+ was counted, what would change the count, the part of the count you'd defend least, and which of them were yours to lead end to end. If you don't know exactly how a figure was counted, say so. That's an honest answer, and the pack supplies no method | The figure in VE1 is the magnet for a prober. EXP because it tests attribution |
| C2 | "Walk me through one of those integrations end to end." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on VE1. Pick one integration you remember well and walk the stages the quote names: scoping, requirements, architecture, UAT, go-live. Answer slot, from R3: if you worked from the API docs or schemas in that integration, say how, in your own words. If not, say so plainly and stay with the stages | F3 and F4 both rest on VE1, so this is where its depth gets tested. EXP primary, touching JD (R3) |
| C3 | "Tell me about the playbook. What's in it, and how is it used?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | You wrote it and your team uses it; keep the scope to your team. Answer slot: what it covers and how your team uses it, in your own words. VE2 is your inspectable artifact, so if you're allowed to share it, or a redacted version, offer to | VE2 is high-confidence and inspectable, the strongest single proof you have. EXP because it tests ownership |

### D. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built from the three quotes at their own scope: the integrations you led, the playbook you wrote, the roadmap-input sessions you ran. End with why this role, in your own words. Answer slot: dates, employers and tenure in your own words. The pack has none, so don't borrow any figure from elsewhere | The near-certain opener, and it sets up A1 on your terms |
| D2 | "What do you know about our partner platform?" | CO | [generic] | The pack has no researched facts about Quartzline. Before the interview, read their public developer docs and any recent announcements yourself, and come with one concrete observation and one question. Don't recite what you haven't checked | The CO slot. It's generic because research was refused (see Sources) |
| D3 | "How have you worked with agile teams?" | JD | [grounded] | The dossier's strategy is `clarify`. Answer slot: if you worked in sprints, stand-ups or a similar cadence, say how in your own words. If you never worked that way, say so plainly. Then ask: "How do your squads run? I'd want to confirm how you define it here" | F9 is a preferred requirement with no verified evidence. JD because R5 is listed |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's done this exact job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; plus `prohibited_claims`: "Having held a product manager title or role" | A1 compressed to three sentences. Pause first. "I haven't held a product manager title. I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live. Here's how I'd close the gap in my first 90 days." If they interrupt, return to the same three sentences, not new claims | The same objection under a clock. Rehearse it so A1's shape survives compression |
| E2 | "Those roadmap-input sessions: how much of what came out of them was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold on the quote: you ran the sessions, and they fed client evidence to product. Volunteer the limit: what product did with the evidence was product's call. Answer slot: if you know of something that changed because of that input, say what and how you know. If you don't know, say so plainly. Hold through two follow-ups, and concede only that the decisions weren't yours | F6 is medium-confidence and the dossier expects this probe. Practicing the concession now keeps it calm live |

### G. Peer lens (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You'd work with two squad leads you don't manage. How do you get things built without authority?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if engineers were part of the integrations you led, say how you worked with them, in your own words. If not, say so plainly. Then give working principles: shared goals tied to partner outcomes, decisions written down with reasons, and disagreement settled early. Nothing about setting a squad's priorities | Tests F7 and F5's engineering leg. JD because "drive delivery with two engineering squads" is a stated responsibility |
| G2 | "An engineer tells you your spec is wrong. What happens next?" | CASE | [generic] | Treat it as a live problem: ask what they see, separate the problem from the solution in the spec, decide whether it changes the partner outcome, update or hold with reasons, and record the decision. The question needs no claim about your past | Tests the spec-writing half of F7 as a decision rather than a record |

### H. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: pick a time with a real stake, a moment you didn't soften the message, and a working relationship intact afterwards. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common behavioral stem. `[generic]` because Quartzline's values weren't retrieved |
| H2 | "When did you put a customer ahead of an internal metric or deadline?" | VAL | [generic] | Selection scaffold: a named customer need, the internal pull the other way, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Customer-facing work runs through VE1, so this stem is plausible. It's a scaffold because no quote carries such a story |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience (F1) | A1, A2, E1 |
| Own the roadmap and prioritization authority (F2) | A1, A2, B3, B5 |
| R2: Shipped API or platform products (F3) | A3 |
| R3: Technical fluency, API docs and schemas (F4) | C2 |
| R4: Stakeholder management across engineering, sales, customers (F5) | A5, G1, B4 |
| Run discovery with integration partners (F6) | E2, A4, B1 |
| Write specs and drive delivery with two squads (F7) | G1, G2, B3 |
| Define and track adoption metrics (F8) | B1, B2 |
| R5: Agile delivery experience (F9) | D3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | **Must-ask.** The dossier's go decision is conditional on verifying this. It reads as seriousness about the job, and the answer tells you whether "own the roadmap" is real |
| R-2 | "How is partner API adoption measured today, and what's the current baseline?" | The dossier flags adoption as a stated responsibility with no stated baseline. It shows you think in metrics and tells you what you'd inherit |
| R-3 | "What would a strong first six months look like to you?" | It turns the hiring manager's success criteria into something you can answer against in later rounds |
| R-4 | "Where does partner feedback enter the roadmap today, and who carries it in?" | It connects to the discovery responsibility and shows how product and partner-facing teams actually meet |
| R-5 | "How do sales and partner teams bring requests to product, and how often does the answer have to be no?" | It probes the R4 seam and the role's real pressure points, and signals you expect to say no |
| R-6 | "Is this a new role or a backfill, and what made you open it now?" | It tells you what the role is really for, and whether the roadmap has an owner today |

---

## Prohibited claims

Binding on every cell above. Items 1 to 3 come from your dossier and are absolute. Items 4 and 5 were built here from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The plain acknowledgment "I haven't held a product manager title," then VE1 and VE2 at their own scope as adjacent work (F1) |
| Having owned a product roadmap | Dossier `prohibited_claims`; also an `acknowledge_gap` area | "I haven't owned a product roadmap," then a ramp plan said as a plan. No bridge, and F6 is never used as one |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." Case answers (B3, G1) describe what you would do, never a past instance |
| Shipped an API or platform product | Inflated form of F3 | VE1 at its own scope. The limit is the pack's observation: your material says client integrations of the vendor's APIs, not shipping the API. A3's slot stays inside the integrations |
| Ran product discovery | Inflated form of F6 | VE3 at its own scope: roadmap-input sessions feeding client evidence to product. E2's slot stays inside the sessions |

---

## Sources

**Provided documents**
- `tuesday-dossier.md`, envelope v1.1, generated by job-underwriter on 2026-08-14 and about three months old today.
  - **Sections consumed:** `role_profile` (stands in for the JD), `decision` (context only), and `handoff_to_mock_interview` (verified evidence VE1 to VE3, weak areas with strategies, the named objection, risks, employer questions and prohibited claims).
  - **Not present:** `evidence_map`, `evidence_state` and `risk_register`. Grading comes from the handoff entries, and the confidence of rows the dossier didn't grade was set here from VE1 to VE3's stated bands.

**Searches sent**
| Query | Result |
|---|---|
| "Quartzline company values" | refused |
| "Quartzline interview process product manager" | refused |
| "Quartzline partner API platform news 2026" | refused |

**Target accounting**

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | The search was refused. It would have themed H1 and H2 with official value names. No values-style round is detected, so the cheat sheet would stay out either way |
| 2. Quartzline interview process, PM | unavailable | The search was refused. It would have shown whether a values or case round sits elsewhere in the loop. This session's shape comes from your own words, so the persona weights hold |
| 3. Quartzline strategy and recent news | unavailable | The search was refused. It would have grounded D2 and given B1 and B4 Quartzline's real context instead of `[generic]` |
| 4. Interviewer name at Quartzline | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative PM, Platform APIs JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** → targets 1 to 3 run. D2 becomes a real CO answer, B1 and B4 get Quartzline's context, and any published values theme H1 and H2.
- **Deeper research (L2)** → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, recent org context and role-family loop reports, which feed a sharper CO and CASE bank. Offered once.
- **The hiring manager's name** → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path.
- **How many hours you have before the interview** → a prep-triage schedule at the top of the pack, sized to that time.
- **Recruiter guidance** (focus areas, or any case or presentation they announced) → a build section for any graded deliverable, and coverage tuned to their stated focus.
- **Your answers to the slots in F3, F4, F5, F7, F8 and F9**, given here outside a drill → those rows gain quoted evidence and A3, A5, C2, D3, G1 and B2 become story-mapped.
- **Your CV, or your tenure and employers in your own words** → D1's arc gets dates and scope. Right now the pack can't say how long you did this work.
- **A current copy of the posting** → confirms the requirements haven't changed since the dossier was written in August.
