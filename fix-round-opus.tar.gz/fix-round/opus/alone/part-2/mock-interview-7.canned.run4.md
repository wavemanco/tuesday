I've read the skill's rules and am now checking the evidence conventions before running a quick research pass on Saltmarsh Games and Tobias Wrenfield.
I've built your prep pack and saved it as `saltmarsh-games_live-operations-producer_interview_pack.md`. It assumes Tobias is the hiring manager and that Friday is the interview Saltmarsh's careers page calls "the Outage Hour": a single 60-minute hiring-manager interview made of a live-incident tabletop on a simulated outage during a live event, then a values conversation. Your hour matches that on length and on Tobias's title.

- **The two halves:** bank A rehearses the outage tabletop. Bank B covers each of Saltmarsh's three published values: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener.
- **Highest-ROI prep is C1, the in-app purchase gap.** A search result says Saltmarsh announced in September 2026 that both titles move to a season pass on one shared events calendar from February 2027. That puts the role right on a gap you've named. The pack has you say it plainly, then return to the content-drop calendar you ran.
- **Your strongest material** is the release checklist QA still uses, and the weekly calendar you ran for two years. A talk-listing snippet says Tobias was a QA lead before this role, so expect him to dig into the checklist (D3).
- **Unconfirmed:** the season-pass news and Tobias's background both come from search snippets I didn't open. Read the news post and watch his GDC 2026 talk, "Patch Notes Are a Promise", before Friday.
- **Claims the pack won't coach:** that you've led a team, had "4 years as a producer", worked on a game with in-app purchases, or owned a post-event review. Each has an honest version you can say instead.

If you want, I'll play the interviewer on C1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and has the recruiter told you anything about how the tabletop runs? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Treated as the hiring manager, see the persona table for why
**Format:** 60 minutes, Friday. Saltmarsh's careers page describes this hour as "the Outage Hour", explained under Reading the loop below

---

## How to use this pack

Two axes. **Personas** describe how a question will be asked: the tone, the pressure, who is asking. **Types** describe what the answer is scored on. Rehearse both: a question you know the content of can still throw you if it arrives as an interruption.

| Type | What it's really testing |
|---|---|
| VAL | Whether what you have done fits Saltmarsh's *published* values, not virtue in general |
| EXP | Whether what you say about your past holds up under follow-up, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know where the company is heading |
| CASE | How you structure and reason through a live problem from the role |

Every row has a provenance label: `[grounded]` traces to what you told me or to a page cited in Sources; `[inferred]` is derived, and the derivation is named; `[generic]` is a common pattern for the role with no claim about Saltmarsh or you.

**The guidance is scaffolding, not a script.** Where it says "answer slot", the pack does not know the answer. It tells you what you are likely to be asked and gives you an honest way to answer either way. Fill it from your own memory or leave it empty; never fill it from the pack.

Question IDs: fit-snapshot rows are F1–F9. Question banks are lettered by persona, A–E, then G and H. There is no bank F, so it can't be confused with the fit rows.

---

## Reading the loop

| Fact | Provenance | Source |
|---|---|---|
| Saltmarsh's loop is "a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." | [grounded] | saltmarshgames.com/careers/interviewing, fetched |
| Your Friday hour matches that description: 60 minutes, with the Head of Live Operations | [inferred] | Your message's 60 minutes and Tobias's title, set against the page above. Not confirmed that Tobias is the hiring manager |
| Saltmarsh's three published values are Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener | [grounded] | saltmarshgames.com/values, fetched |
| Project Larkspur, announced September 2026, moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and replaces per-title event teams with one live-ops group | [inferred] | Search-result snippet of saltmarshgames.com/news/project-larkspur. The page itself was not read, so read it before Friday |

Practical upshot: plan for two halves, a **live-incident tabletop** (bank A, plus E2) and a **values conversation** (bank B). Everything else in this pack is follow-up material that can come up inside either half.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material covers a weekly content-drop calendar for one title. It does not cover live events across two titles, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's word "plan" makes a probe on who decided what went on the calendar likely. If those decisions were yours, say which and how you made them, in your own words. If the plan was set for you, or there was no such step, say so plainly and describe how you ran it |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material says nothing about working across these teams. Note that "never led a team" is a different statement: coordinating is not managing, so don't let either side merge the two. Answer slot: if running the calendar meant working with design, art, engineering or community, say who you worked with and what you did, in your own words. If it didn't, say so plainly and say how you would set that coordination up |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly numbers. It doesn't say you owned a post-event review, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you compiled or analysed those numbers yourself, say which part, in your own words. If someone else produced them and you presented them, say so plainly. If you ever wrote a review after a content drop, describe it; if you didn't, say so |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but this is a single line with nothing to inspect behind it, so expect a close probe, especially from an interviewer with a QA background. Lead with the quote's own terms: you wrote it, and QA still uses it. That's a specific artifact and it beats an adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | Weekly content drops already describe live service in other words, so say it as your quotes do: "Four years as an associate producer at a puzzle-game studio. For the last two, I ran the weekly content-drop calendar for our main title." Keep "associate" in, because the title is the part a reader checks |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | A direct match in the JD's own terms. Say it plainly and early |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | Presenting the numbers touches this requirement but doesn't show how deep your fluency goes. Answer slot: which retention measures were in those presentations and how they were counted, in your own words. If you don't know how they were counted, say so plainly; that is an honest answer |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | A checklist a team still uses is a written artifact, but your material doesn't show more of your writing than that. Answer slot: if you wrote other things people relied on, such as release notes, player-facing posts or summaries, name one in your own words. If not, stay with the checklist |
| F9 | Monetised live operations: Saltmarsh's announced move to a season-pass model, from a search snippet of the Larkspur news page. Not a JD line | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | A gap you have stated, and wording can't close it. Words: "I haven't worked on a game with in-app purchases." Then say how you would learn it, as a plan and never as past experience. Don't add anything to make the gap feel smaller |

---

## Reading the interviewer

| Fact | Provenance | Source |
|---|---|---|
| Tobias Wrenfield gave a GDC 2026 talk, "Patch Notes Are a Promise", as Head of Live Operations at Saltmarsh Games | [inferred] | Search snippet from talks.gdconf.example. Talk not watched |
| The snippet describes him as previously a QA lead at a console studio | [inferred] | Same snippet |
| The talk's argument, per the snippet: "a live team is judged by how often its patch notes describe what actually shipped" | [inferred] | Same snippet |

Practical implications, read from the rows above:

- **The talk's theme matches the value Ship the Patch Not the Promise.** Expect communication questions, such as what goes in a player post or patch note, to be scored on accuracy rather than polish. A2 and E2 rehearse this.
- **A QA background means the release checklist will be read by someone who knows checklists.** D3 is weighted up for that reason. Know your own checklist item by item.
- **A professional thread you share, not a career jump.** His path runs through QA, and F4's quote, "Wrote the release checklist our QA team still uses.", is work on the same seam. Let it come up through D3 or reverse question 2, in the quote's own terms. Don't claim QA experience the quote doesn't carry.
- **Watch the talk before Friday if you can find it.** Everything in this section rests on a snippet.

---

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop itself: a simulated outage during a live event, worked live | **Highest.** Saltmarsh's careers page names the tabletop as half the hour, and hiring-manager rounds lean this way anyway | Clarify, then contain, communicate, decide and record. Think aloud. Challenge one premise per case, respectfully |
| Values / Behavioural | The second half: a values conversation | **High.** The same page names a values conversation. Saltmarsh's three values are published and nameable | One prepared story or scaffold per value, below. "We" for context, "I" for your own contribution |
| Skeptic | Probes on F9 (season pass), F1 (one title vs two) and the associate title | **Mid-high.** Hiring managers derisk gaps, and Larkspur points this role at the exact area F9 covers | C1 rehearsed until it's boring. Bridges come only from your quotes, plus a ramp plan stated as a plan |
| Data-Driven Prober | Follow-ups on the retention numbers and the checklist | **Mid.** The JD's KPI and retention lines, plus an interviewer with a QA background | Know what you can and can't say about how each number was counted, and say plainly where you don't know |
| Pressure | Interruptions and time-boxing inside the outage simulation | **Mid-low.** A simulated outage is designed to add time pressure, but the page doesn't describe a stress style | Pause, restate, then hold a position through two follow-ups before conceding anything |
| Conversational | The opening few minutes and the reverse-question slot | **Low**, but scored | A pre-scripted 90-second arc built from your quotes. Never answer "I think you've covered everything" |
| Peer Evaluator | Cross-team seams inside the tabletop, such as community versus engineering | **Low.** No peer round, but the JD's coordination line brings the seam into the case | Propose principles for the seam rather than pretending to know Saltmarsh's org chart |

Weights assume Tobias is the hiring manager and that Friday is the Outage Hour. If either is wrong, the weights change.

---

## Question banks

### Bank A — Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event and event rewards have stopped granting for some players. Talk me through your first thirty minutes." | CASE | [inferred] | Clarify first: which title, which platforms, how many players, since when, and whether it's still happening. Contain: get the right engineer, then decide whether to pause, extend or leave the event running. Communicate: community team, a first player post that says what's known and when the next update comes. Make-good: hold the decision until you know who was affected. Record: start the timeline now for the post-event review. The question asks about no past, so the guidance makes no claim about yours | Shaped on the careers page's "simulated outage during a live event"; `[inferred]` because the scenario's details are the pack's. CASE because it is a live problem. JD content too, since it covers coordination and post-event review |
| A2 | "Players are asking when it'll be fixed and engineering can't give you a time. What goes in the post?" | CASE | [inferred] | Say what you know, what's being done, and when the next update will come. Give no fix time you can't keep. Name the make-good only once it's decided. Draft it aloud in three or four sentences, because the written answer is the test. This is the value Ship the Patch Not the Promise applied to a status post, and you can say so | Tests the JD's written-communication line inside the tabletop; `[inferred]` because the link to Tobias's talk rests on a snippet. CASE delivery, with VAL scoring underneath |
| A3 | "From February both titles share one events calendar. How would you build the first quarter?" | CASE | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify the goal (retention, season-pass progress) and the constraints (one live-ops group, art and engineering lead times). Then the structure: cadence per title, where the two calendars collide, buffer weeks, release-checklist gates, and a review after each event. You can say that for the last two years you ran the weekly content-drop calendar for your main title. Answer slot: any lesson from it is yours to name, in your own words; if none applies, leave it out | Premise comes from the Larkspur snippet, so `[inferred]`. CASE because you plan it live. It covers the JD's calendar line, F1 and F6 |
| A4 | "An event's ended and day-7 retention for players who joined during it is lower than last event. Diagnose it." | CASE | [generic] | Check the measurement first: same cohort definition, same window, any data issues. Then segment by title, platform, new versus returning players, and acquisition source. Then look at the event itself (difficulty, reward pacing) and outside factors (store featuring, an outage, a competing launch). Name the assumption you'd trust least. Close with what goes in the post-event review | The JD's KPI and retention lines, asked as a live problem; `[generic]` because it's a common diagnosis pattern, not Saltmarsh data |
| A5 | "Two days before release, one checklist item is unsigned: QA sign-off on a low-traffic device. Design wants it out for the event start. What do you do?" | CASE | [generic] | Clarify the risk: what fails, for how many players, and whether it can be reversed. Options: hold the release, ship with the issue disclosed, or stage the rollout. Say who makes the call and who you'd tell. Record it, and decide whether the checklist itself needs a change. No claim about your past is needed | Covers the JD's checklist line and pits the values Players Before Plans and Leave the Build Greener against a deadline; CASE because it's a live decision |

### Bank B — Values (the second half)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. One place to look is the weekly content-drop calendar you ran. A good story needs the plan, the player signal that contradicted it, what you did, and what happened. If such a time comes to mind, tell it in your own words. If none does, say so plainly, then give the nearest thing your material carries or how you'd handle it | The values page defines Players Before Plans as "when the calendar and the players disagree, the players win"; F1 is the likely place to find a story |
| B2 | "When have you had to stop something being announced before it was built?" | VAL | [grounded] | Selection scaffold: a time an announcement, patch note or date was ahead of what had been built, and what you did about it. It needs the gap, your move, and what got said in the end. If no such time comes to mind, say so plainly, then say how you'd handle it, and A2 is your worked version | Ship the Patch Not the Promise, from the fetched values page; probably close to Tobias's talk theme, per the snippet |
| B3 | "What have you left better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the release checklist, and QA still uses it. Those are the two beats your sentence states. Answer slot: the value says every release leaves the checklist better, so expect a probe on whether it changed over time. If you updated it after releases, say what changed and why, in your own words. If it hasn't changed, or the updates weren't yours, say so plainly and stay with writing it and its continued use | Leave the Build Greener names the checklist in its own definition, and F4 is your strongest row, so this is the most natural values story in the pack |
| B4 | "Tell me about a time you delivered news to leadership they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. One place to look: the monthly retention numbers you presented to the studio head. If a month you presented carried unwelcome news, tell that: what you said, how, and what happened next. If none did, say so plainly and pick another time, or say how you'd handle it | Common values stem; F3 gives the obvious place to look, without presupposing that bad news happened |

### Bank C — Skeptic

**C1 is the highest-ROI prep in this pack.** It will come up in some form, because Larkspur points the role straight at F9.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "From February this team runs season passes. You've never worked on a game with in-app purchases. Why should I trust you with that calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | **Concede first, specifically:** "I haven't worked on a game with in-app purchases." Don't soften it and don't pivot to playing habits. **Hold what's real:** "For the last two years I ran the weekly content-drop calendar for our main title." **Then a ramp plan, stated as a plan:** what you'd learn first (how the season pass and event calendar interact at Saltmarsh, who owns pricing, past post-event reviews) and who you'd learn it from. Follow-up 1, "So you'd learn on our live game?": hold. The calendar isn't new to you; the monetisation layer is, and here's how you'd close it in the first weeks. Follow-up 2, "What does a season pass change about a calendar?": reason aloud and say it's your thinking, not experience. Never claim monetisation experience | F9 is a gap you stated, and the snippet says the role is moving into it. JD primary because it scores readiness for the role, with CO underneath |
| C2 | "Four years as an associate producer. What makes you ready to be the producer?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." | Don't argue about the title. Say what your quotes say: four years as an associate producer; for the last two you ran the weekly content-drop calendar for your main title; you wrote the release checklist QA still uses. Answer slot: the JD says "plan" and "own", so if decisions on the calendar were yours, say which; if the plan was set for you, say so plainly and stay with running it | Step-up probes are routine when the title is one rung below; F5 and F1 are where it lands. JD because it scores the 3+ years line and the ownership words |
| C3 | "This role coordinates design, art, engineering and community on every update. Have you led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't led a team." Then point out, calmly, that the JD asks for coordination, not management. Answer slot: if running the calendar meant working with any of those teams, say who and what you did, in your own words. If it didn't, say so plainly and say how you'd set coordination up. Don't use phrases like "led without authority" unless your answer to the slot supports them | F2 is silent and the stated negative sits next to it, so the interviewer may merge the two. JD because it scores the coordination line |
| C4 | "You've run a calendar for one title. We run two on one calendar. What breaks?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Keep the quote's scope: your main title. Then reason aloud, as your thinking: events colliding for the same art or engineering capacity, players who play both titles, release-checklist windows overlapping, and two communities on one timeline. Close with the one safeguard you'd put in first | F1's main gap is one title versus two. JD because the two-title line is in the first sentence of the JD |

### Bank D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. Which ones, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slots, in your own words: which measures were in them and how they were counted; what moved them; the assumption behind them you'd defend least; which part was yours (compiling, analysing or presenting). "I don't know how that was counted" is an honest answer. The pack supplies no metric names or method | F3 and F7 rest on this line, and a prober will go two levels into it. EXP because it tests what was actually yours |
| D2 | "Did anything on the calendar change because of the retention numbers you presented?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." and "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if it did, say what changed and what part you played, in your own words. If it didn't, or you don't know, say so plainly and describe how you'd connect the two now | Tests whether F7's numbers and F1's calendar were connected; asked as a yes-or-no question, so the premise can be false |
| D3 | "Your release checklist: walk me through what's on it and why." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Go through it in your own words: its sections and why each is there. Answer slot: if it caught a problem before a release, describe it as it happened; if you don't recall one, don't invent one. Close with one thing you'd change in it now | F4 is your strongest row, and per the snippet the interviewer comes from QA, so expect detail. EXP because it tests the artifact |

### Bank E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run a season pass?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." | Pause, then hold on your quotes: two years running the weekly content-drop calendar for your main title, and the release checklist QA still uses. Concede plainly that they'd bring season-pass experience you don't have, per C1. Don't run down the other candidate. If pushed twice, hold the core and repeat the ramp plan | Short version of C1 under time pressure; JD because it scores fit |
| E2 | (Mid-tabletop) "It's now both titles and engineering says it's a third-party issue. Two minutes: what do players hear right now?" | CASE | [generic] | Restate the question in one line. Then speak the post: what's affected, that you know the cause is outside the game and are working on it, when the next update comes, no fix time. Then the internal step: who's escalating to the third party. Stay calm if interrupted, finish the sentence, then take the interruption | Escalation and interruption are common in outage simulations; `[generic]` because Saltmarsh's exact format isn't published |

### Bank G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey. Why live ops, and why Saltmarsh?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | 90-second arc using only your four sentences: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title for the last two; the release checklist QA still uses; the monthly retention numbers you presented to the studio head. Answer slot for "why Saltmarsh": your reasons, in your own words. A specific reference to the values page or the Outage Hour shows you prepared | Almost certain opener, and it is scored. JD because it covers the 3+ years line (F5) |
| G2 | "What live event in someone else's game impressed you lately?" | CO | [generic] | Answer slot: pick one you actually played. Say what the event was, why it worked for players, and one thing you'd borrow. If you haven't played one recently, say so and name the last one you did | Casual but scored, and it tests genuine interest in live ops; `[generic]` |

### Bank H — Peer seams

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Community wants the event extended. Engineering says extending it risks the next release. You're in the middle. What do you do?" | CASE | [generic] | Get the facts from each side: the risk to the release and the cost to players of not extending. Decide who makes the call. Propose an option, such as a partial extension or a make-good, and say how you'd tell both teams. Players Before Plans is a fair lens to name | The JD's coordination line, as a seam. CASE because it's a live decision |
| H2 | "What would you need from art and engineering to keep a steady cadence across two titles, and what would you give them back?" | CASE | [generic] | Need: lead times, a visible capacity view, early warning when something slips. Give: a stable calendar locked far enough ahead, one clear point of contact, and a review that credits their work. Principles, not a claim about Saltmarsh's org | Reciprocity framing for the coordination line (F2), with no past claimed |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A3, C4, H2 |
| Coordinate design, art, engineering and community | A1, C3, H1, H2 |
| Own the post-event review and its KPIs | A1, A4, D1, D2 |
| Manage the release checklist with QA | A5, B3, D3 |
| 3+ years producing live-service games or apps | C2, G1 |
| Experience running a content calendar | A3, C4, B1 |
| Comfortable with player-retention metrics | A4, D1, D2 |
| Clear written communication | A2, E2 |
| Season pass, not in the JD but from the Larkspur snippet | C1, E1 |

---

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased from the values page) | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and what players need conflict, players win | Selection scaffold, B1. One place to look is F1's "I ran the weekly content-drop calendar for our main title for the last two years.": a time the plan changed, or should have, because of players. If none comes to mind, say so plainly, then give the nearest thing or how you'd handle it |
| Ship the Patch Not the Promise | Only announce what is actually built | Selection scaffold, B2. None of your sentences carries a story here. If none comes to mind, say so plainly and use A2's reasoning for how you'd handle it |
| Leave the Build Greener | Each release should leave the codebase and the checklist better | Mapped from F4: "Wrote the release checklist our QA team still uses." Whether it improved over time is an answer slot, see B3 |

---

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "In your GDC talk you argued a live team is judged by how often its patch notes describe what actually shipped. How do you track that here?" | It's tied to his own published work and shows you prepared for *him*. Watch the talk first so you're not quoting only a summary | [inferred] |
| R2 | "You came to live ops from QA. What did that path teach you that you look for in a producer?" | Tied to his career path, and it gives him room to talk about the seam F4 sits on | [inferred] |
| R3 | "With Larkspur moving both titles onto one calendar and one live-ops group, what would this role own before February, and what after?" | Shows you're current, and gets you the real scope of the job | [inferred] |
| R4 | "What does a good post-event review look like here: who reads it, and which KPIs have mattered most?" | It's the JD's ownership line, and the answer tells you what you'd be judged on | [grounded] |
| R5 | "How does the release checklist change here, and who can add to it?" | Ties to Leave the Build Greener and to the JD's checklist line | [grounded] |
| R6 | "Six months in, what would tell you this hire worked?" | Shows you care how you'll be measured, and gives you a closing frame | [generic] |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on games with in-app purchases or season passes | Negative the candidate stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Has led or managed a team | Negative the candidate stated, F9's quote | "I haven't led a team." No slot |
| Four years as a producer | Inflated form of F5 | F5's quote at its own scope: "4 years as an associate producer at a puzzle-game studio." |
| Ran live events across multiple titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material says a weekly content-drop calendar for the main title. A3 and C2's slots stay inside that calendar |
| Owned the post-event review, or owned the retention KPIs | Inflated form of F3 and F7 | F3's quote at its own scope: "Presented the monthly retention numbers to the studio head." D1's slot asks only which part was yours |
| Managed the release process | Inflated form of F4 | F4's quote at its own scope: "Wrote the release checklist our QA team still uses." |

---

## Sources

Provided: the JD and your background, both pasted in your message.

Searches and fetches sent:

- Search `Saltmarsh Games values` → saltmarshgames.com/values
- Search `Saltmarsh Games interview process producer` → saltmarshgames.com/careers/interviewing
- Search `Saltmarsh Games mobile studio news 2026` → saltmarshgames.com/news/project-larkspur (snippet only)
- Search `Tobias Wrenfield Saltmarsh Games Head of Live Operations` → talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only)
- Fetch saltmarshgames.com/values → the three values with definitions
- Fetch saltmarshgames.com/careers/interviewing → the Outage Hour description

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and bank B: three values, by name and definition |
| 2. Saltmarsh Games interview process | yes | Established the loop: tabletop plus values conversation. Set persona weights with Case and Values at the top |
| 3. Saltmarsh Games strategy and recent news | yes | Larkspur snippet: moved C1, A3, E1 and R3, all `[inferred]` because the page itself wasn't fetched once the fetch budget was spent |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | GDC talk snippet: interviewer read, D3 weighting, R1 and R2, all `[inferred]` |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Confirm whether Tobias is the hiring manager, and any recruiter notes on the tabletop** → persona weights confirmed or recomputed. Usually one email to the recruiter
- **Your CV text** → the evidence column gains your CV's own wording. F2, F3 and F8 may move
- **Your answers to the slots in F1, F2, F3 and F7**, given here rather than in a drill → those rows are regenerated and may move from `discovery` or `transferability` toward `none`
- **The artifacts this field keeps: a redacted copy of your release checklist, or a sample monthly retention deck** → F4, F7 and F8 can move from `medium` to `high`, and D1 and D3 become walkthroughs of real material
- **Read the Larkspur post and watch the GDC talk** → C1, A3, R1, R2, R3 and the interviewer read move from `[inferred]` to `[grounded]`
- **A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes** → a strategy brief on Larkspur and the two titles, Tobias's talk in depth, candidate reports on the Outage Hour, and recent org context
- **How much prep time you have before Friday** → a prioritised prep schedule
- **A tuesday-dossier.md from the job-underwriter** → evidence-verified rows and an underwriter-built prohibited-claims list. Not needed for this pack
