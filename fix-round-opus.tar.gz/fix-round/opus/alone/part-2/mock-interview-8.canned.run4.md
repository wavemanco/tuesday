I've saved the pack; I'm doing one last wording check before handing it over.
Dara, your prep pack is ready, with a separate section for each of the three rounds on 21 November. Your recruiter's email, the JD, the values text and the strategy brief already covered everything I'd have asked about, so I didn't run any web searches. I have no questions for you right now.

**What's in it:**
- **How your experience lines up with the JD.** Each requirement is set against your own words. Two are clear gaps you named yourself: contact-centre work and presenting above regional level. Several others are things your notes don't show either way, like whether your complaints were regulated, whether the spreadsheet is in Excel, and any digital work. For those, the pack gives you an honest answer for both cases: "yes, and here's how" or "no, and here's what I did do."
- **The most important question to practise is B4** in the round with the Head of Member Services: "your experience is one branch, so why are you ready for this?" The pack has you name the gaps before they do, stick to what you've actually done, and give a plan. It includes three likely follow-ups.
- **The 20-minute case.** There's a suggested way to use the time, three positions to argue (each with a weakness to admit out loud), what to avoid promising, and a practice scenario. The pack doesn't know which complaint rules Ashgrove works under, so don't quote deadlines you're unsure of.
- **The four values.** None of the sentences you gave me contains a story that shows a value in action, so each value gets a guide to choosing your own story instead. A few more real examples from your branch would turn these into prepared answers.
- **Strategy notes.** The two branch managers on your panel probably run branches affected by the eight-to-five hub merger. Talk about it as a member problem to get right, never as good news.
- **Things not to claim.** For example, "coached supervisors" (you trained new tellers), "wrote the escalation script" (your words were "our escalation script"), and anything about presenting your spreadsheet to regional leadership.

If you'd like to practise, I can play the Head of Member Services on B4 and push back on your actual answers.
I can also save a tuesday-dossier.md recording the gaps this prep found, so you can bring it to later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union — Member Experience Lead — interview prep pack

**Candidate:** Dara
**Loop (from your recruiter's email):** three rounds on 21 November 2026 — Round 1, 30 minutes with the recruiter; Round 2, 45 minutes with the Head of Member Services, your prospective manager, mostly behavioural; Round 3, 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four values.
**Interviewers:** not yet assigned, so there is no interviewer read in this pack.
**Mode:** loop — one shared fit snapshot, then a mini-pack per round.

---

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each round has its own persona weights, bank and reverse questions.
- **Persona letters in question IDs:** A Conversational, B Skeptic, C Case/Strategist, D Values/Behavioral, E Pressure, G Data-Driven Prober, H Peer Evaluator. F-numbers are fit-snapshot rows; S-numbers are grounding-brief rows.
- **Type key:**
  - **VAL** — does your past behaviour show Ashgrove's four published values
  - **EXP** — does what you said about your experience survive close questioning
  - **JD** — can you do the listed job, gaps included
  - **CO** — do you know Ashgrove's strategy and can you think at its level
  - **CASE** — structure and reasoning on a live problem from the role
- **Provenance labels:** `[grounded]` traces to something you or Ashgrove provided; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about you or Ashgrove.
- **Answer slots.** Where an interviewer will probe something your material doesn't show, the guidance gives an answer slot: two honest branches — if you did it, say how in your own words; if you didn't, or it wasn't yours, say so plainly. Both branches are good answers.
- **Guidance is scaffolding, not a script.** Every sentence about your past rests on one of the four sentences you gave me, quoted. Say them in your own words; never say more than they do.
- **Highest-ROI prep in this pack: B4** — the readiness objection in Round 2. Rehearse it until it's boring.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (branch side) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material shows one branch's formal complaints log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If any steps were yours to decide — how complaints were recorded, chased or closed — say which and how, in your own words; if those steps weren't yours, or didn't exist in that form, say so plainly and stay with the log you handled |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (contact-centre side) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording can't close, and you've said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Monthly complaints reporting is in your sentence; what the spreadsheet tracked is not. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on volumes and resolution times. If the spreadsheet tracked either, say what and how it was counted, in your own words; if it didn't, say so plainly and say what it did track. Expect a probe on it either way, since nothing has been inspected behind it |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on an existing script, not that you coached supervisors. Words at their own scope: "I trained new tellers on our escalation script." Answer slot: you were a branch supervisor for the last three years, and the JD's escalation line makes a probe on escalations that reached you likely. If they did, say how you handled them, in your own words; if they didn't, or weren't yours to handle, say so plainly and stay with the training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. Strong evidence would be one named journey, what changed in it, and which part was yours. Answer slot: if you have worked with a digital team or on a member-facing online or app journey, say what and what part was yours; if you haven't, say so plainly and say how you would bring complaint patterns to a digital team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The sentence already meets the length and the sector; say it in its own terms and let the interviewer map it: "Six years in retail banking, the last three as a branch supervisor." Don't relabel it in the JD's phrase |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" is in your sentence; whether those complaints fell under regulatory rules is not, so the bridge isn't stretched. Words: "I handled the branch's formal complaints log." Answer slot: if those complaints were handled under regulatory rules, say which rules applied and what part of meeting them was yours, in your own words; if you don't know, or that wasn't part of your role, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you've stated. Words: "I haven't presented to anyone above regional level." Your sentence doesn't say whether you have presented at regional level, so the pack doesn't assume it. Answer slot: if you have presented to your regional manager or at a regional meeting, say what and to whom, in your own words; if not, say so plainly. Then how you'd build it, said as a plan |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not which tool. Answer slot: if you built it in Excel, say so and name the features you actually used; if it was another tool, name that tool plainly |

---

## Grounding brief

Built from the strategy brief as you summarised it (published July 2026, about four months old) and the JD. The full brief wasn't pasted, so there are no headline numbers beyond these.

| # | Fact or reading | Source | Provenance | What it changes in your answers |
|---|---|---|---|---|
| S1 | Ashgrove aims to move 40% of member service to digital channels by 2028 | Strategy brief, July 2026 | [grounded] | Use "digital channels" and "self-service journeys", their words. Feeds C1 and C2 |
| S2 | Eight branches consolidate into five hubs over 2027 | Strategy brief, July 2026 | [grounded] | Feeds C4 and the Round 3 case. Say "hubs", their word |
| S3 | A small-business lending product launches in Q1 2027 | Strategy brief, July 2026 | [grounded] | A new product means new kinds of complaint; worth one line in C1 or a reverse question |
| S4 | The main competitive pressure is app-only banks | Strategy brief, July 2026 | [grounded] | Feeds A2: why a member-owned, branch-based credit union, against app-only rivals |
| S5 | Member-owned, about 900 staff | JD | [grounded] | Say "members", never "customers" |
| S6 | Reading: the two branch managers on the panel run branches in a network that is about to consolidate, so the hub plan is likely live for them and may be personal | Derived from S2 and the recruiter's email | [inferred] | Treat consolidation as a member-experience problem to get right, never as something to welcome. Don't guess whose branch is affected |
| S7 | Reading: channel moves and branch closures are points where complaint volumes commonly rise | Role-family pattern | [generic] | Suggest tracking complaints by branch and by channel through 2027 as an idea, never as Ashgrove's data |
| S8 | Reading: against app-only banks, the values "Neighbours, Not Numbers" and "Members First, Always" are where Ashgrove sets itself apart | Derived from S4 and the values page you pasted | [inferred] | In CO answers, connect complaint handling to the values, not just to speed |
| S9 | The brief is four months old; the hub timeline or digital target may have moved | Date of the brief | [inferred] | Don't correct an interviewer who says something different; ask, as in Round 2's reverse questions |

---

## Graded deliverable — the 20-minute complaint-escalation case (Round 3)

**What's declared** `[grounded]`: a 20-minute case on a complaint escalation, inside a 60-minute panel of two branch managers, which also scores you against the four values. No close or format was named.

**Facts about you that the case can draw on** (quoted from the fit snapshot):
- F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- F3: "I built the monthly complaints spreadsheet our regional manager uses."

**A 20-minute shape** `[generic]`:
1. **Clarify (2 min).** Who is the member, what happened, which channel, what they're asking for, what has already been promised.
2. **Contain (4 min).** Make contact, acknowledge, name one owner, give a time they'll hear back.
3. **Investigate and decide (5 min).** Facts from the branch and any other channel involved; the policy and the rules that apply; the decision, reasoned from the member's side.
4. **Close in plain words (4 min).** What you tell the member and how you'd check they understood it first time.
5. **Fix the cause and report it (3 min).** What changes so it doesn't recur, who you'd coach, how it shows up in the monthly report.
6. **Their questions (2 min).**

**Three theses — pick one to lead with, each with its concession** `[inferred]` from the values page and the JD:

| Thesis | Values it serves | Concession to say out loud |
|---|---|---|
| One named person owns the escalation from first contact to close, whichever channel it started in | Own the Fix | Single ownership can bottleneck; the owner can hand off tasks but keeps the case |
| Decide from the member's side, then test the decision against policy and the rules | Members First, Always | The member's view can't override a regulatory duty, or fairness to the other members whose money it is |
| Every escalation is data: log it so the monthly report shows the pattern, then fix the pattern | Own the Fix, Plain Words | Logging must never slow down the case in front of you |

**Differentiation.** The answer most candidates give is apologise, investigate, resolve, follow up. Keep that spine, and add three things: ask your clarifying questions before structuring; say where the branch supervisor sits in the escalation and how you'd coach them rather than take the case off them (the JD's coaching line); and end on the cause and how it appears in monthly reporting.

**The anti-pick.** Say no, politely, to two things the case may tempt you towards: promising the member an outcome or a payment before the facts are in, and closing the complaint informally without logging it, even if a branch manager would prefer that. The role owns the process, so holding that line is part of the job.

**Regulation.** This pack doesn't know which complaint rules Ashgrove works under, so don't quote deadlines or rule names unless you know them. Answer slot, from F7: if you worked to specific regulatory complaint rules, you can say "in my bank we worked to…" and name them in your own words; if you didn't, or don't know them, say "I'd work to whatever timeframes apply here, and I'd confirm them on day one."

**Close.** None was named. Because the panel scores the four values, ending with one sentence on which values your decisions served is worth doing `[inferred]` — name them, don't lecture.

---

## Sources

**Provided documents:** the JD (pasted); Ashgrove's values text, which you pasted after copying it on 12 November 2026 from ashgrovecu.org/about/values (not fetched by me); the recruiter's email on the process (pasted); the July 2026 strategy brief, as you summarised it (full text not seen); your background (your message).

**Searches and fetches sent:** none. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted, copied today, fixes the values cheat sheet and the D bank |
| 2. Ashgrove Credit Union interview process | skipped | The recruiter's email establishes the loop — three rounds, who runs each, the case and the values scoring — and fixes every persona weight |
| 3. Ashgrove Credit Union strategy and recent news | skipped | The July 2026 strategy brief, under six months old, supplies priorities and the competitive frame for the CO questions and the grounding brief |
| 4. Interviewer names at Ashgrove Credit Union | n/a | No names assigned yet, so there was no query to form; no interviewer read |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD; it fixes the fit snapshot and the JD-tagged questions |

---

# Round 1 — Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, why Ashgrove, logistics | High — recruiter-screen prior; 30 minutes leaves room for little else | A rehearsed 90-second arc built only from your four sentences; treat casual questions as scored |
| Skeptic, light | Quick checks against the JD's requirements — contact centre, regulated complaints, Excel | Medium — recruiters screen for knockouts before passing you on | Short, plain answers; state your gaps calmly and once |
| Others | — | Low — the recruiter's email gives the depth to the later rounds | Don't over-prepare this round at their expense |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, three beats in your own words: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log and training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Then one line on why complaints work is where you want to go next — answer slot: your own reason, in your words | Every round opens with some version of this; it sets the frame for F1, F3 and F4. EXP because it is the claims everything later probes |
| A2 | "Why Ashgrove — and why a credit union?" | CO | [grounded] | Use what Ashgrove published: member-owned, the four values by name, and the July 2026 brief — digital channels, hubs, competition from app-only banks (S1, S2, S4). Answer slot: your own reason for a member-owned organisation, in your words; your material doesn't mention credit-union work, so don't imply any | Motivation is the recruiter's standard check. CO because a specific answer shows homework, which S4 makes easy |
| A3 | "Why move on from branch supervision now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Answer slot: your real reason, said forward — what you want to do more of — never a complaint about your current employer. Keep it under 45 seconds | Recruiters check motivation consistency so later rounds don't hear a different story. EXP because it tests your own account of your path |
| A4 | "How comfortable are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it was Excel, say so and name the features you actually used; if it was another tool, name it plainly | A listed requirement and an easy knockout check (F9). JD because it scores the stated requirement |
| A5 | "What do you understand about this role?" | JD | [grounded] | The JD's four duties in your own words — the complaints process across branches and the contact centre, monthly reporting, coaching branch supervisors on escalations, working with digital teams — tied to one strategy fact (S1 or S2) | Tests that you read the JD and know why the role exists now. JD content, with a CO flourish |
| B1 | "The role asks for experience with regulated complaints. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with the log, in the sentence's terms: you handled the branch's formal complaints log. Answer slot: if those complaints fell under regulatory rules, say which rules and what part of meeting them was yours, in your own words; if you don't know, or that wasn't yours, say so plainly and stay with the log | F7 is the thinnest bridge to a listed requirement; a recruiter may tick it literally. JD because the requirement is named |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain and short: "I haven't worked in a contact centre." Then one sentence of plan: how you'd learn it in your first weeks. Don't apologise twice | F2 is a stated gap against the JD's first line; recruiters check it so the manager doesn't have to. JD because it scores the requirement |
| B3 | "This looks like a step up from supervising one branch. What makes you ready?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The short version of B4: name the step — yes, it's wider than one branch — then the two sentences, then the plan. Save the full rehearsal for Round 2 | A preview of the loop's main objection (F1). JD because it prices you against the role's scope |

### Reverse questions

| Question | Why it lands |
|---|---|
| "Will I know the panel's names before the 21st?" | It's the recruiter's domain, and names let you prepare for the people, not just the roles |
| "Is the 20-minute case given on the day, or is there anything in advance?" | Shows you're planning for the graded part, and the answer changes how you prepare |
| "Is this a new role or a replacement?" | Tells you whether you'd be building the process or inheriting one; both answers help Round 2 |
| "What does the Head of Member Services most want this role to fix first?" | The recruiter often knows, and it gives you Round 2's agenda |
| "What happens after the 21st, and when would you expect to decide?" | A normal close the recruiter expects; it shows you're organised |

---

# Round 2 — Head of Member Services (your prospective manager), 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: contact centre, senior presenting, branch versus organisation-wide | High — hiring-manager prior, and F2 and F8 are stated gaps this person will own the risk of | B4 rehearsed until boring: name the limit first, hold on your sentences, give a plan |
| Values/Behavioral | "Tell me about a time…" questions | High — the recruiter said this round is mostly behavioural | Pick stories now; where your four sentences don't carry one, use the selection scaffold and its honest branch |
| Case/Strategist | Strategy-shaped questions: digital shift, self-service | Medium — hiring-manager prior, reduced by "mostly behavioural" | Clarify, then structure, in Ashgrove's words (S1) |
| Data-Driven Prober | Questions about your monthly spreadsheet | Medium — monthly reporting is a core duty and F3 is your nearest evidence | Know exactly what it tracked and how; say plainly what you don't know |
| Pressure | A time-boxed "why you" | Low — not signalled, but one rehearsal is cheap | Pause, restate, hold, concede only what's real |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "This role owns complaints across every branch and the contact centre, and reports to senior leaders. Your complaints experience is at branch level. Why are you ready for this?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." "6 years in retail banking, the last 3 as a branch supervisor." | **Highest-ROI rehearsal in the pack.** Name the limit before they do: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then hold on what your sentences carry: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log, trained new tellers on the escalation script, and built the monthly complaints spreadsheet your regional manager uses. Then the plan, said as a plan: time with the contact centre to see how their complaints are recorded and where they meet the branch log, and your first monthly report reviewed with your manager before it goes higher. Follow-up 1, "branch level isn't end to end": agree on scope; answer slot — if any steps of the branch process were yours to decide, say which; if not, say so and stay with the log. Follow-up 2, "how long until you're useful?": give a timeline you'd stand behind, in your words — the pack won't pick one. Follow-up 3, "why not hire someone from a contact centre?": concede they'd know the contact centre better; hold that the role also covers branches and branch supervisors, which is where your three years were. Never fold to "maybe I'm not ready" | F1, F2 and F8 together are the most predictable objection to this candidate, and the person asking will carry the risk of hiring you. JD because it prices you against the role's stated scope; Skeptic delivery with pressure follow-ups |
| B5 | "I don't see presenting to senior leaders in your background, and this role reports monthly to them. How would you handle that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | "I haven't presented to anyone above regional level." Then what you do have, at its own size: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if you have presented to your regional manager or at a regional meeting, say what and to whom; if not, say so plainly. Plan: ask your manager to review your first reports, sit in on a senior meeting before presenting, and keep reports to the few numbers that matter | F8 is a stated gap against a listed requirement, and this manager is the one who sends you upstairs. JD because it scores the requirement directly |
| B6 | "Tell me about a time a complaint escalated beyond what the branch could resolve." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one complaint with a clear stake for the member, your own action, and an outcome you can describe; "we" for the branch, "I" for your part. If no such case comes to mind, say so plainly, then describe how escalation worked from the branch log you handled, or how you would handle one | Behavioural round, and escalations are the JD's spine (F1, F4). JD theme, delivered as a behavioural open prompt |
| B7 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Describe the training in your own words — who, how, what you checked afterwards. The script is "our" script in your sentence, so don't claim you wrote it. Answer slot: if any of the training's content or method was yours to shape, say which; if not, say so and describe how you delivered it | F4 is your nearest evidence for the coaching duty; expect it to be tested. EXP because it tests what was actually yours |
| B8 | "This role coaches branch supervisors — people at the level you're at now — on escalations. How would you do that, and why would they listen?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold on the sentences: three years as a branch supervisor yourself, and you trained new tellers on the escalation script. Don't call that coaching supervisors. Answer slot: if escalations reached you as supervisor, say how you handled them; if not, say so. Then the plan: what you'd do with supervisors, said as future — start from their real cases, agree what "escalate" means, check back | F4 is a transferability gap on a named duty. JD because it scores the coaching requirement |
| G1 | "Tell me about the monthly complaints spreadsheet. What's in it, and how is it counted?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence. Answer slots, in your own words: what it tracks; how each figure is counted; the figure you'd defend least and why; which parts were yours. If you don't know how something was counted, say so plainly. Don't claim you present it or that decisions rest on it — your sentence says your regional manager uses it, no more | F3 is the evidence for monthly reporting (and F9 for Excel); a manager who will read your reports will test this. EXP because it defends a specific artifact |
| G2 | "Resolution times have got worse three months running. How would you find out why?" | CASE | [generic] | Clarify first: worse where — which branches, which channel, which complaint types. Then: split the data, check whether something changed in volume or in how cases are recorded, talk to the supervisors, pick the biggest cause, fix it, watch next month. The question needs no claim about your past, so the guidance makes none | Tests the monthly-reporting duty as a live diagnosis. CASE because it's a role problem, not a past |
| C1 | "We plan to move 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] | Use S1 and S3: more complaints will start in digital channels and new products bring new complaint types; the complaints process has to follow the member across channels; and complaint patterns are useful to digital teams designing journeys. Name one risk: members who prefer branches. The question needs no claim about your past | The required strategy-grounded question; the brief makes it likely. CO because it tests thinking at Ashgrove's level |
| C2 | "Our digital team is redesigning a self-service journey. How would you work with them?" | JD | [grounded] | F5 is silent. Answer slot: if you've worked with a digital team or on an online journey, say what and what part was yours; if not, say so plainly. Then the plan: bring them the complaints that start in that journey, sit in on testing, check afterwards whether complaints fell. Plain Words gives you a test to offer: does a member need it explained twice | A named duty with no evidence in your material (F5). JD content, CASE delivery |
| D1 | "Tell me about a time you disagreed with a manager's decision about a member." | VAL | [generic] | Selection scaffold: pick a time with a clear stake for the member, a moment you said what you thought, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | A behavioural staple, and Members First invites it. VAL because the published values are the yardstick |
| E1 | "Sixty seconds: why you over an internal candidate who already knows our contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause; concede first: they'd know the contact centre better. Hold on your sentences: three years as a branch supervisor, the branch's formal complaints log, training new tellers on the escalation script. Close on the plan for the contact centre. Under 60 seconds | Composure check against F2; cheap to rehearse once. JD because it prices you against the role |

### Reverse questions

| Question | Why it lands |
|---|---|
| "How do you know today whether the complaints process is working — what's in the monthly report, and who reads it?" | Shows you're thinking about the reporting duty, and tells you the bar you'd inherit |
| "Where do branch complaints and contact-centre complaints meet today, and where do they fall between the two?" | Goes straight at your gap (F2) as curiosity, not apology |
| "With 40% of service moving to digital by 2028, who owns a complaint that starts in the app?" | Uses the brief (S1) and asks a real ownership question the role will face |
| "What would you want from this role in the first 90 days?" | Lets you hear their priorities and answer later answers against them |
| "How much would I present to senior leaders myself, and how would you want to support that early on?" | Turns F8 into a planning conversation with the person who decides |
| "The strategy brief came out in July — has anything moved since, especially on the hub timeline?" | Keeps you current (S9) without correcting anyone |

---

# Round 3 — Branch-manager panel, 60 minutes, values round with the 20-minute case

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Questions mapped to the four values, scored | High — the recruiter said the panel scores against the four values | One story or scaffold per value (cheat sheet below); "I" for your part |
| Case/Strategist | The 20-minute escalation case | High — declared by the recruiter; a third of the round | The deliverable build above: clarify, contain, decide, close, fix, report |
| Peer Evaluator | How you'd work with their branches and coach their supervisors | Medium — inferred: branch managers are the people whose supervisors you'd coach and whose branches feed the complaints process | Reciprocity — what you bring their branches; principles for disagreement, not a claim to know the seam |
| Skeptic, light | Your standing with managers, coming from a supervisor role | Low-medium — the panel may revisit Round 2's objection | The short version of B4 |
| Conversational | Warm-up and close | Low | Have the A1 arc ready, cut to 60 seconds |

### Values cheat sheet

The four values are quoted from the text you pasted. None of your four sentences carries a story that shows a value in action, so each row is a selection scaffold; the nearest material in your sentences is named so you know where to start looking.

| Value (official name) | Working meaning | Your mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's side, not the organisation's | Selection scaffold: a decision where you took the member's side when the easier answer was the branch's. Needs a named member situation, your decision, and what it cost or saved. Nearest material, F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." If no such time comes to mind, say so plainly and say how you would decide | D2 |
| Plain Words | If it needs explaining twice, it was written wrong | Selection scaffold: a time you explained something complicated so it landed the first time, or rewrote something that kept confusing people. Nearest material, F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." If no such time comes to mind, say so plainly and give how you would do it | D3 |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold: a time your branch's link to its community mattered to a decision or a member. Nearest material, F6: "6 years in retail banking, the last 3 as a branch supervisor." If no such time comes to mind, say so plainly and say how you'd keep it alive as branches become hubs | D4 |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | Selection scaffold: a problem you found that wasn't strictly yours, which you kept hold of until it was solved. Nearest material, F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because you found a problem, that's this story; if not, pick another. If none comes to mind, say so plainly | D5 |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D2 | "Tell me about a time you made a decision from the member's side of the counter, even when it was harder for the branch." | VAL | [grounded] | Use the Members First scaffold. Structure: the situation in one line, the choice, what you did, what happened, what you'd do again. If no such time comes to mind, say so plainly, then say how you would decide in that situation | Members First is scored, and the question echoes the value's own wording. VAL by definition |
| D3 | "Tell me about a time you had to make something clear for a member — or rewrote something so it didn't need explaining twice." | VAL | [grounded] | Use the Plain Words scaffold. Show the before and after if you have one. If no such time comes to mind, say so plainly, then say how you'd test a letter or script for plain words | Plain Words is scored, and complaint responses are where it bites. VAL by definition |
| D4 | "How is a branch part of its town? Give us an example from your own branch." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Use the Neighbours scaffold; your material names your branch-supervisor years, not a particular community story, so pick one you can tell in your own words. If none comes to mind, say so plainly and say what you'd protect as branches become hubs. Two branch managers are asking: be specific and humble | Neighbours, Not Numbers is scored, and S6 makes it pointed for this panel. VAL by definition |
| D5 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Use the Own the Fix scaffold. Answer slot: if the spreadsheet was your answer to a problem you found, tell that — what the problem was, why you kept hold of it, what changed; if not, pick another story. If none comes to mind, say so plainly | Own the Fix is scored, and it is the value closest to the job's end-to-end ownership. VAL by definition |
| D6 | "A member's complaint is fair, but our policy says no. What do you do?" | VAL | [grounded] | Live dilemma, so no claim about your past. Structure: check the facts and the policy's purpose; decide from the member's side within the rules; explain the answer in plain words; if the policy is the problem, own getting it looked at. Name the tension rather than pretending there isn't one | Two values pull against policy here; panels use dilemmas to see which value wins. VAL content, CASE delivery |
| C3 | The 20-minute case. Practice prompt `[generic]`, not a prediction: "A long-standing member has complained twice at a branch about a fee charged during a card dispute. They've posted about it locally, and the contact centre promised a callback that didn't happen. Walk us through what you do." | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use the deliverable build above. Lead with one thesis and say its concession. Mention the log only in your sentence's terms if it helps: you handled the branch's formal complaints log. Answer slot for rules, from F7, as in the build | The declared graded deliverable. CASE by definition; the values score rides on it |
| C4 | "One of our branches becomes part of a hub next year and members are upset. How do you handle the complaints that come with that?" | CO | [grounded] | Use S2 and S6: acknowledge it's hard for members and staff; set up a clear route for those complaints and track them by branch; say plainly what is changing; feed patterns back to the consolidation team; keep the town link (Neighbours, Not Numbers). Never sound glad about closures; don't guess which branches | The required strategy question for this round, and the most sensitive one for this panel. CO because it tests the 2027 plan |
| H1 | "If you're coaching my supervisors on escalations and you and my supervisor disagree about a complaint, what happens?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Propose principles, not a claim to know their seam: agree the facts first; the member's outcome decides; the manager is told early; disagreements get logged so the pattern can be fixed. You can say you've been a branch supervisor for the last three years yourself, without claiming you've coached anyone in that role | The coaching duty seen from the people it touches (F4). JD content, Peer delivery |
| H2 | "What would you need from branch managers like us to make the complaints process work?" | JD | [generic] | Reciprocity first: what you'd bring them — fewer complaints bouncing between channels, monthly patterns for their branch, coaching for their supervisors. Then what you'd need: early sight of escalations, a named contact, honest feedback on the process | Peer Evaluators price what you cost and add to their week. JD because it scores how the process would actually run |
| B9 | "You'd be coaching supervisors and working with managers like us. Coming from a supervisor role, how do you make that work?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Short B4: name the step up, hold on the two sentences, give the plan. Credit their experience; position yourself as someone who supports supervisors, not who manages them | The panel version of the loop's main objection (F1, F4). JD because it prices you against the role |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would genuinely help your branches?" | Reciprocity — it tells two people you'd work with that you're there to reduce their load |
| "When a complaint escalates from your branch today, what happens next — and what would you change?" | Gets their view of the process you'd own, from the people who live with it |
| "How is the hub plan landing with members in your towns?" | Shows you know S2 and care about the member side, without assuming whose branch is affected |
| "Which of the four values do you see tested hardest by complaints?" | Turns the values round into a conversation, and their answer is useful on day one |
| "What do your supervisors find hardest about escalations?" | Shows you're already thinking about the coaching duty from their side |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches | B3, B4, B6, C3, B9 |
| … and the contact centre | B2, B4, E1 |
| Report monthly on complaint volumes and resolution times | G1, G2, B5 |
| Coach branch supervisors on escalations | B7, B8, H1, B9 |
| Work with digital teams on self-service journeys | C1, C2 |
| 4+ years in financial-services customer operations | A1, B3 |
| Experience handling regulated complaints | B1, C3 |
| Confident presenting to senior leaders | B5, B4 |
| Comfortable with Excel reporting | A4, G1 |
| Strategy, beyond the JD | A2, C1, C4 |
| The four values | D1 to D6 |

---

## Prohibited claims

What this pack will not coach, and why. Each one is the stretched version of something you said, or something you said you haven't done.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process across branches, or end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: your material shows one branch's log. Slots stay inside that log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." Slots stay with the training and with escalations that reached you as a supervisor |
| Wrote or designed the escalation script | Inflated form of F4 — your sentence says "our escalation script" | F4's quote as it stands. The pack doesn't know who wrote it, so it says nothing either way |
| Reported or presented complaints figures to regional leadership | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Your sentence says the manager uses it, nothing about you presenting it |
| "Financial-services customer operations" as a description of your past | Inflated form of F6 — the JD's words, not yours | F6's quote: "6 years in retail banking, the last 3 as a branch supervisor." Let the interviewer make the match |
| Contact-centre experience | Something you said you haven't done, F2 | "I haven't worked in a contact centre." No slot |
| Presenting to senior leaders | Something you said you haven't done, F8 | "I haven't presented to anyone above regional level." No slot for senior presenting |

---

## Upgrade menu

- **Answers to the answer slots** — what your spreadsheet tracked and in which tool, whether your log fell under regulatory complaint rules, whether escalations reached you as supervisor, any regional presenting, any digital work → F3, F4, F5, F7, F8 and F9 move from slots to story-mapped answers, and B1, B5, B8, C2, G1 and A4 get firmer guidance
- **Your CV, or a few more sentences about specific complaints you handled** → the values cheat sheet's four scaffolds can become mapped stories, and D1 to D5 and B6 get real beats
- **Interviewer names, once assigned** → an interviewer read per person, per-panellist persona weights, and at least one reverse question tied to each person's own path
- **How much prep time you have before the 21st** → a prioritised prep schedule, so you know what to do first and what is insurance
- **The full strategy brief text** → the grounding brief gains Ashgrove's own numbers and phrasing, and C1 and C4 sharpen
- **Deep research, L2** — up to 6 more searches and 2 more fetches, several more minutes → recent Ashgrove news and context (how the hub plan has been announced locally, any leadership changes), and loop reports for similar roles; offered once
- **A tuesday-dossier.md from an earlier evaluation of this role** → evidence already checked with you, and a named objection to rehearse instead of an inferred one; not needed for this pack
