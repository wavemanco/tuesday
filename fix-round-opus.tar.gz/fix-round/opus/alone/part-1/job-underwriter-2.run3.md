Reading the skill's reference rules before writing the assessment. A few more files to go.
Last reference: the worked report layout.
**No, you're not wasting your time on this one. The real obstacle is the "3+ years product management" must-have: by your own account you have no PM title, so no rewording of your resume will meet it as written. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (product-adjacent work toward 3+ years PM), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Experience with agile delivery) · absent: R1b (3+ years titled PM experience)
- `important`: adjacent: R6 (Run discovery with integration partners), R7 (Write specs, drive delivery with squads), R10 (Coordinate launches with sales and support) · unclear: R8 (Define and track adoption metrics), R9 (Own the roadmap)

R1b: no rewording fixes it, by your own statement; R2: the bridge the whole application stands on; R8, R9: rows the unconfirmed triage-tool lead could move.

**Opportunity ledger.** The employer isn't suspect, it just isn't verified yet: I couldn't check it because search was refused (RR1). Pay and location are unstated (RR2, RR3), and the posting states no success measures (RR5). One entry runs the other way: the delivery resources are named, two engineering squads (RR4).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the live posting verify (RR1). (2) R1b reaches a person rather than being screened out on the title (plan row P1). (3) R2 is framed as adjacent: never as having shipped an API product. (4) Your pay, location and authorization constraints fit the terms in RR2 and RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not checked against the company's own site, see RR1 |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-90-days outcomes | Likely partner discovery and a baseline for adoption metrics, since the role is asked to define those metrics rather than inherit them | `[inferred]` from "define and track adoption metrics" with no targets stated |
| Scope read | A full single-PM remit over one platform area: the roadmap, the delivery, the metrics and the launches all sit with this seat | `[inferred]` from the responsibilities list |
| Who the users are | Integration partners consuming the API. That is the same population your current work serves, from the vendor side | `[grounded]` JD "partner-facing API platform"; `[grounded]` your "30+ client integrations of our REST APIs" |
| Market calibration | Not established: the role-family sweep could not run, so I have no band to set this role against | none, nothing researched |
| Unknowns | Compensation, location and remote policy, work authorization terms, whether this seat is new or a backfill, success measures | `[grounded]` the JD is silent on each |
| Contradictions | None inside the JD; it was not compared against a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience: the product-adjacent work counted toward it | must_have | adjacent | medium | transferability | Seven years producing requirements documents, gathering roadmap input and coordinating PMs is real product-shaped work, but it was done alongside product rather than as product. Specific in your own words, nothing inspectable yet | `[grounded]` your background: "requirements documents", "roadmap-input sessions", "coordinated… product managers" | Frame as adjacent; see P2, P3 |
| R1b | 3+ years titled PM experience | must_have | absent | high | capability | You stated it directly ("never held a PM title"). That is not a gate under this skill's rules, but there is nothing to recover. `[generic]` A titled-years line marked must-have is often screened literally, so the risk is being filtered out before anyone reads the rest | `[grounded]` your statement; `[generic]` screening pattern | Closure path: route through a person (P1), or target APM, technical-PM or internal-transfer roles alongside this one |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led integrations of a vendor's REST APIs end to end, on the consuming and implementing side. Limit: nothing yet shows you owned decisions about the API product itself | `[grounded]` "Led 30+ client integrations of our REST APIs end to end" | G1 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading are stated, and integration architecture across 30+ builds supports it. Nothing inspectable yet, so expect a technical probe | `[grounded]` your background | none |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | Coordinated your engineers, the client's engineers and PMs on custom builds; ran scoping workshops with clients | `[grounded]` your background | none |
| R4b | Stakeholder management: sales | must_have | unclear | low | discovery | The background doesn't mention sales. `[generic]` Solutions engineers often work alongside sales, but nothing here says you did | `[grounded]` silence in your background; `[generic]` role-family pattern | G2 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | Silent. UAT and go-live suggest delivery cycles but not which method | `[grounded]` silence | G3 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | You ran quarterly roadmap-input sessions and scoping workshops. Limit: you collected the input and product decided what to build | `[grounded]` "Ran quarterly roadmap-input sessions collecting client feedback for product" | G4 |
| R7 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. Limit: these were client-specific builds, not a product backlog for squads you steered | `[grounded]` your background | G4 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Silent. The triage-tool lead could bear on it if it's true and had usage measured | `[grounded]` silence; memory lead is unconfirmed | G5 |
| R9 | Own the roadmap | important | unclear | low | discovery | The roadmap input went to product, which is not ownership. The integration playbook and the unconfirmed triage tool are the places you may have owned what came next | `[grounded]` "Wrote the internal integration playbook the whole team uses"; memory lead unconfirmed | G5 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | 30+ client go-lives are launches, but each one was a single-client launch, and sales and support aren't mentioned | `[grounded]` "UAT, go-live" | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped API or platform products (R2, must_have) | transferability | You implemented the vendor's API for clients; nothing shows influence on the API itself | Adjacent evidence carries R2. A real product contribution would make it far stronger | A custom build that became a standard endpoint or feature; a schema or auth change you specified that shipped to every customer; integration-pattern feedback that product adopted | A requirements doc whose ask later appeared in release notes; a sanitized spec | `[grounded]` your background; `[inferred]` that a shipped product change is the strongest version of this bridge |
| G2 | Sales stakeholders and launches (R4b, R10) | discovery | No mention of sales or support | One must-have and one important row | Pre-sale scoping with account executives; handover to support at go-live; enablement notes for support | Handover docs, enablement material | `[grounded]` silence |
| G3 | Agile delivery (R5, must_have) | discovery | Silent | A must-have that one sentence could likely settle | Sprints, ceremonies or a ticket workflow on custom builds | None needed | `[grounded]` silence |
| G4 | Discovery and specs (R6, R7) | transferability | Input-gathering and requirements writing, with others deciding | These carry the case that you've done PM work without the title | A roadmap-input synthesis you wrote and what came of it; a requirements doc engineers built from | The playbook; a sanitized synthesis | `[grounded]` your background |
| G5 | Roadmap ownership and adoption metrics (R8, R9) | discovery | An unconfirmed lead from earlier context: an internal request-triage tool that support agents adopted | If it's true, it's the closest thing here to owning a product: built, adopted, maybe measured | Deciding what the tool did and in what order; counting users or requests handled; changes made after feedback | A screenshot, usage numbers, a README | `[grounded]` the lead is unconfirmed and recorded only as a basis for a question |

R1b has no queue row. You've already answered it, and the closure path is in its Next action cell.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be as described, but nothing checked it: the search was refused | `[generic]` pattern, not a claim about this company | Can you point me at the role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation unstated | unknown | — | the JD gives no figure | The pay may or may not fit a pivot, and there's no band to compare it with yet | `[grounded]` JD silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and work arrangement unstated | unknown | — | the JD gives no location | Your constraints can't be checked against it | `[grounded]` JD silence | Is this role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Delivery resources named | positive_signal | — | "drive delivery with two engineering squads" | The role comes with people to deliver through, not just accountability | `[grounded]` JD | Is this a new seat or a backfill, and who owns the API roadmap today? | noted |
| RR5 | No stated success measures | unknown | — | "define and track adoption metrics" | The role is asked to set its own measures, so what success means is still open | `[inferred]` from the JD asking the role to define metrics, with no targets stated | What would success look like at six and twelve months? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Reach the hiring manager or get a referral rather than applying cold through the form | R1b | `[generic]` titled-years lines are often screened literally | pending your approval |
| P2 | Lead with your own words: "Led 30+ client integrations of our REST APIs end to end" and "Ran quarterly roadmap-input sessions collecting client feedback for product". Don't restate them as "ran partner discovery" or "shipped API products" | R2, R6, R1a | `[grounded]` your background; the reframing audit bars borrowing the JD's vocabulary for your history | pending your approval |
| P3 | Say the gap yourself, early: no PM title, seven years working beside product on API integrations | R1b, R1a | `[grounded]` your statement | pending your approval |
| W1 | A one-page work sample: a sanitized partner-feedback synthesis turned into a short API spec | R6, R7, R9 | `[inferred]` from the adjacent rows: it shows the step your record doesn't yet show | pending your approval |
| A1 | Verify the employer and the live posting before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions from RR1 through RR5 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: the request-triage tool from prior context. It is used only as the basis for the G5 question.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics API platform company" was refused. It would have resolved RR1 and the Organization and Contradictions rows in role reality |
| 2. Role-family sweep | unavailable | The search "product manager platform API Series B salary range 2026" was refused. It would have given the Market calibration row and a band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

Want me to save all this as `tuesday-dossier.md` so you can pick it up later or carry it into interview prep?

## Upgrade menu

- **Allow web search:** targets 1 and 2 run, RR1 can clear, and role reality gets a market band.
- **A deeper research pass on Quartzline** (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs once search is allowed.
- **Your constraints** (pay floor, location, work authorization) → gate rows get built and checked against RR2 and RR3.
- **The hiring manager's name** → a scope read and which story P2 should lead with.
- **The integration playbook or a sanitized requirements doc** → R3, R6 and R7 could rise to `high`.
- **An answer to G1** → R2 strengthens, or its limit is confirmed.

**Questions**

G5: Did you build an internal request-triage tool that support agents adopted? If so, what did you personally decide about what it did, how many people used it, and how did you know it was working?

G1: In any of the custom builds, did something you specified become a change to the product's API itself, like a new endpoint, a schema change or a standard feature, rather than a one-client build?

Constraints: What are your non-negotiables on pay, location and work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.