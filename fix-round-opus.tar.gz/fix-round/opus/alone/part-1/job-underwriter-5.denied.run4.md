Quick update: I've read the skill's rules, and now I'm checking that the posting is still live before I write up the assessment.
# Should Ines apply? Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R6, R7
- `important`: adjacent: R5 (dbt-modelled warehouse in BigQuery) · unclear: R8 (ingestion from our app and CRM), R9 (the data contracts our analysts depend on)

R5: a bridge from Snowflake to BigQuery, with its limit named; R8, R9: your background doesn't mention them, and one answer each could move them.

**Opportunity ledger.** The pay is published and sits at or above your report's range (RR2), and the stack is named. Three things are unverified: whether the posting itself is live, since my checks were refused (RR1); what the equity actually is (RR3); and who the role reports to (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Pellucid's own careers page (RR1); (2) you are in the US or can work from Denver (R1); (3) BigQuery is described as adjacent experience, never as experience you have (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the About text you pasted; not checked against the live site (RR1) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data-quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or the Denver office | `[grounded]` JD |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD is silent |
| Scope read | One engineer owning reporting data from ingestion to contracts. That's broad but coherent: one domain end to end, and no direct reports are mentioned | `[inferred]` from the JD's three named responsibilities and its silence on managing anyone |
| Market calibration | "Senior" usually means 5–8 years, owning one domain's pipelines with no direct reports; base median $151,000, IQR $139,000–$163,500. This role's title and scope match that norm. The band shows the market, not this employer's offer | `[generic]` Datawright 2026 Data Engineering Pay Report, US, n=2,310, Senior DE at Series B–D (the report your recruiter sent) |
| Unknowns | Reporting line and team size; equity terms; how student-data handling shapes the ingestion work | `[generic]` that K-12 platforms usually carry student-privacy obligations; the rest `[grounded]` JD silence |
| Contradictions | None between the pasted JD and the pasted About page | `[grounded]` pasted text only; the live pages weren't checked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you're authorized to work in the US, so the gate isn't settled either way | `[grounded]` JD term; your background is silent | Question R1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years of data engineering, which is over the bar. It's self-reported, so medium is the ceiling at intake | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both "daily". Specific, but there's nothing to inspect yet | `[grounded]` your background | Offer: a repo or code sample would raise this to high |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so this meets the stated requirement | `[grounded]` your background | Offer: sanitized dbt docs or a DAG screenshot would raise this to high |
| R5 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | You stated you've never used BigQuery. The dbt modelling carries over directly. The limit is BigQuery's own cost, partitioning and slot model, which Snowflake work didn't exercise | `[grounded]` your statement; `[inferred]` adjacency from dbt being warehouse-agnostic at the model layer | See G3 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated, with no qualifier | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the company's Great Expectations test suite | `[grounded]` your background | none |
| R8 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background covers modelling and orchestration but says nothing about which sources you ingested or how | `[grounded]` background silent on ingestion | See G1 |
| R9 | The data contracts our analysts depend on | important | unclear | low | discovery | Owning a test suite and a dbt project is close to this, but your background doesn't say whether you defined schemas or SLAs with the people who used the data | `[grounded]` background silent on contracts | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R8, important) | discovery | Strong warehouse-side evidence; no source-side evidence | It's one of the role's three named responsibilities, so it's likely to come up in interviews | Loading production database or event data from your payroll app; pulling from a CRM (Salesforce, HubSpot) via Fivetran, Airbyte or custom Python; CDC, API pagination, handling schema drift | A DAG, an ingestion repo, a design doc | `[grounded]` background silent; `[generic]` that named responsibilities get probed |
| G2 | Data contracts for analysts (R9, important) | discovery | A Great Expectations suite and a dbt project you owned; no mention of agreements with consumers | The JD names contracts specifically, and an answer could move R9 to `direct` | dbt model contracts or enforced schemas; freshness SLAs agreed with analysts; GE checks that blocked bad loads before analysts saw them; versioning a model analysts depended on | A contract YAML, an SLA doc, an incident write-up | `[grounded]` background silent; `[inferred]` that GE plus dbt ownership is adjacent |
| G3 | BigQuery (R5, important) | transferability | dbt on Snowflake at scale; BigQuery stated as never used | It's the warehouse you'd work in every day | The dbt modelling carries over. The limit is BigQuery-specific cost and partitioning. To narrow it, build a small dbt-on-BigQuery project | A public repo of that project | `[grounded]` your statement; `[generic]` that BigQuery offers a free sandbox tier |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not established from independent sources | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The text came from what you identified as the company's own pages, which is reassuring. But both of my checks were refused, so the posting could be stale or the details could differ from the live site | `[generic]` pattern for unverified postings, not a claim about this one | Is this role open now, and who would I be interviewing with? | unresolved |
| RR2 | Pay published and at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The bottom of the range is above the report's 25th percentile ($139,000), the top is above its 75th ($163,500), and the midpoint ($157,000) is above the median ($151,000) | `[grounded]` JD figure; `[generic]` Datawright band | Where in the range do you expect to place someone with six years of experience? | noted |
| RR3 | Equity unspecified | unknown | — | "plus equity" | It could be options or RSUs, of any size. At Series C, its value depends on the strike price and the exit | `[generic]` pattern for late-stage private equity grants | What form does the equity take, and what are the grant size and vesting terms? | unresolved |
| RR4 | Reporting line and team size unstated | unknown | — | "The posting names no hiring manager" (your note) | The role could be a solo owner of the stack or one member of a larger data team; the scope read changes with which | `[inferred]` from the JD's broad mandate against its silence on team | Who does this role report to, and how many data engineers and analysts are on the team? | unresolved |

## Application plan

These are proposals pending your approval. The approval covers the positioning advice in rows E1–E2 as well as the actions.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with: "Built the company's dbt project on Snowflake (about 180 models) and set up its Great Expectations test suite; orchestration in Airflow" | Covers R4, R6, R7 in your own words | `[grounded]` your background, clause by clause | resume_edits_pending_approval |
| E2 | List Snowflake, not BigQuery. If asked, say "dbt on Snowflake, not yet BigQuery" | R5 is adjacent; claiming BigQuery would be inflation | `[grounded]` your statement | pending your approval |
| W1 | Build a small dbt-on-BigQuery project and link it | Narrows G3's limit | `[generic]` that a linked sample offsets a missing tool | pending your approval |
| A1 | Check that the role is live on Pellucid's own careers page before applying | Clears RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR1–RR4 verification questions word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Pellucid Learning online tutoring K-12 Denver Series C" and a fetch of pellucidlearning.com/careers/senior-data-engineer were both refused for lack of permission. They would have settled RR1 and the contradictions row in Role reality |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save all of this as `tuesday-dossier.md` if you'd like a copy to keep or take into interview prep.

**Upgrade menu**
- Allow web search and fetch → RR1 resolves, and the posting and company facts get checked against the live site.
- Your location and US work status → R1 closes; any pay floor or other constraints get checked against the terms.
- Your CV → the R8 and R9 discovery work, plus anything your summary left out.
- A repo, sanitized dbt docs or a DAG screenshot → R3 and R4 move to high.
- The hiring manager's name → role reality's scope read, and which story to lead with.
- A deeper research pass on Pellucid Learning (funding and leadership churn, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches; it also needs search permission). Say the word and it runs.

**Questions**

R1: Are you based in the US with authorization to work here, or able to work from Denver?

G1: On the payroll platform, which sources did you ingest into Snowflake (the app's database, events, a CRM, third-party APIs), and what part of building those pipelines was yours?

G2: Did you ever agree schemas, freshness targets or breaking-change rules with the analysts who used your models, for example dbt contracts or GE checks that blocked bad loads?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.