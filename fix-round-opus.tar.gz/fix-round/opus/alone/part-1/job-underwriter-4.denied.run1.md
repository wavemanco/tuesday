## Decision snapshot

**Yes, go for it, but check a few things first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R6, R7a, R8 · unclear: R5 (monitor rating models), R7b (recommendations for product)
- `important`: adjacent: R10 (pet-insurance pricing), R11 (own pricing analytics for a whole product)
- `preferred`: direct: R9

R5, R7b: probably there but not stated yet; R10: the real gap, a motor-to-pet bridge with its limits named; R6 (`medium`): the tests are direct evidence, but who designed them is still open.

**Opportunity ledger.** The role reads as clear and well scoped (RR4), but nothing about it could be checked. I couldn't confirm the employer or that the posting is live (RR1). The JD gives no salary (RR2), and it doesn't say how big the pricing team is or how success is measured (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting check out (RR1); (2) R1 is confirmed: you're UK-based and can work here without sponsorship; (3) the pay is acceptable once you know it (RR2); (4) R10 is presented as adjacent motor experience, never as pet-insurance experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD only; not checked against any outside source (RR1) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager is Odile Varga, Director of Pricing | `[grounded]` your message |
| Line management | The JD mentions no reports, team leadership or mentoring. "Senior" here reads as an individual-contributor title | `[grounded]` JD has no management requirement; `[inferred]` IC reading, from a responsibilities list that is all hands-on analysis |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Models, tests and recommendations for one product line. That's the normal set of duties for a senior pricing analyst, not several jobs bundled together | `[generic]` role-family pattern; not checked by a sweep this run |
| Market calibration | Not available. The role-family sweep was refused, and I won't give a salary band from memory | — |
| Unknowns | Salary; team size; who signs off price changes; success measures; which pet products are covered (lifetime, time-limited, accident-only) | `[grounded]` JD is silent on each |
| Contradictions | None inside the JD. Not checked against a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK): based in the UK, with UK right to work | hard_gate | unclear | low | hard_gate | You work at a UK insurer, which makes it likely, but you haven't said where you live or whether you need sponsorship | `[grounded]` background names a UK employer only | Closing question 1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst. Specific, but nothing inspectable yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily. Stated, not yet shown | `[grounded]` your background; `[generic]` pricing roles often test this with a technical exercise | Have a code sample or exercise you can talk through |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book." This is the strongest single match | `[grounded]` your background | none |
| R5 | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include monitoring (drift, actual-vs-expected, refits), but you didn't say so | `[grounded]` background says "maintained" only; `[generic]` maintenance usually involves monitoring, which is why it's a lead and not a match | G2 |
| R6 | Design and read price tests | must_have | direct | medium | discovery | 14 tests in a year with underwriting. "Ran" doesn't settle whether you designed them (cells, sizes, duration) as well as read them | `[grounded]` your background | G1 |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | Tests run with the underwriting team, and you present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7b | Turn results into recommendations for product | must_have | unclear | low | discovery | You mention no product-team audience | `[grounded]` background is silent on product | G3 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance pricing knowledge | important | adjacent | medium | transferability | The GLM, testing and underwriting work carries across. Limit: no exposure to pet rating factors or pet claims patterns | `[inferred]` requirement, from "own pricing analytics for our pet-insurance product"; `[generic]` pet rating usually turns on species, breed, age and vet-fee trends, which motor doesn't use | G4 |
| R11 | Own pricing analytics for a whole product | important | adjacent | medium | transferability | You owned the model for one segment (young drivers), not pricing for a whole product | `[inferred]` from "own pricing analytics for our pet-insurance product" against a segment-level remit | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Who designed the price tests (R6, must_have) | discovery | 14 tests run with underwriting; your share of the design isn't stated | The JD says "design and read". If you designed them, R6 becomes the lead story | Choosing test cells or price points; sizing samples or setting durations; deciding when a test had read; writing the readout | A sanitized test plan or readout deck | `[grounded]` background says "ran"; `[generic]` interviewers for this kind of role probe test design |
| G2 | Model monitoring (R5, must_have) | discovery | "Maintained" the GLM; no monitoring detail | A must-have the background only implies | Actual-vs-expected tracking; drift or stability checks; triggering refits; a monitoring dashboard | A sanitized dashboard screenshot or monitoring pack | `[grounded]` background wording |
| G3 | Product-facing recommendations (R7b, must_have) | discovery | Only underwriting audiences are named | The JD names product alongside underwriting | Feeding into a product launch or redesign; working with marketing or distribution on pricing; changes to cover or excess options | A recommendation paper or meeting note | `[grounded]` background silence |
| G4 | Pet-insurance domain (R10, important) | transferability | Carries across: the GLM build, testing practice, presenting to underwriting. Doesn't carry across: pet rating factors, vet-fee inflation, how lifetime policies renew. Strengthener: a short note showing how you'd approach pet pricing (W1) | The likeliest objection to a motor candidate | Any non-motor or ancillary product you've touched; reading on pet pricing | W1 | `[inferred]` bridge from your motor work; `[generic]` pet-pricing factors |
| G5 | Whole-product ownership (R11, important) | transferability | Carries across: end-to-end ownership of one segment's model. Doesn't carry across: owning the whole product's pricing. Strengthener: examples where your work drove book-wide decisions | Sets how far your story can reach in the interview | Recommendations that changed rates across the motor book; the quarterly review covering the whole book | Quarterly review agenda (sanitized) | `[inferred]` from segment versus product scope |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not confirmed from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have much footprint, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; research was refused, not tried and failed | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | (no salary in JD) | The figure may sit below what a senior pricing role usually pays, or they may simply not publish salaries | `[inferred]` from the missing figure; no band to compare against this run | What salary range is budgeted for this role? | unresolved |
| RR3 | Team size and success measures not stated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" could mean you're the only pricing analyst, without the support a larger team gives | `[inferred]` from the ownership wording against the JD's silence on team | How big is the pricing team, who signs off price changes, and what does success look like in year one? | unresolved |
| RR4 | Clear duties and a named pricing leader | positive_signal | — | "build and monitor rating models, design and read price tests" | The role is concrete, and there's an established pricing function with a Director at its head | `[grounded]` JD and named Director of Pricing | What's the first pricing question you'd want this hire to answer? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with R4, R6 and R8 in your own words: "Built and maintained the GLM rating model for our young-driver book"; "Ran 14 price tests in a year with the underwriting team"; "Present the quarterly pricing review to the head of underwriting" | These are the must-haves where your evidence is strongest | `[grounded]` your background | pending your approval |
| P2 | Don't write "designed" for the tests or "monitored" for the model until G1 and G2 confirm them. Never claim pet-insurance experience. Don't apologize for not managing anyone, because the JD doesn't ask for it | Keeps every line something you can defend under probing | `[grounded]` R5, R6, R10 rows and the JD's line-management silence | pending your approval |
| W1 | A one-page note: "How I'd approach pet pricing coming from motor", with the limits stated plainly | Narrows R10 | `[inferred]` from the G4 bridge | pending your approval |
| A1 | Before tailoring anything, confirm the posting is live and ask the salary | RR1, RR2 | `[grounded]` register | pending your approval |
| Q1 | Ask the verification questions in RR1–RR4 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

The CV lines in P1 are `resume_edits_pending_approval`. Each one quotes your own sentences, and "last year" became "in a year" so it doesn't assert a date.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Brindlemoor pet insurance careers" was refused (permission not granted). It would have confirmed the organization and the live posting and cleared RR1 |
| 2. Role-family sweep | unavailable | The search "senior pricing analyst insurance UK remote salary 2026" was refused. It would have filled market calibration and given RR2 a band |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have informed the scope read and which story P1 leads with |

I can write all of this up as a `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- **Allow web search** → runs targets 1–3: RR1 resolves or firms up, role reality gets a market salary band, and P1 is tuned to the Director's background.
- **A link to the live posting or Brindlemoor's careers page** → RR1 can clear without search.
- **The salary, from the recruiter** → RR2 closes.
- **Answers to G2 and G3** (monitoring detail, any product-facing work) → R5 and R7b move from `unclear`.
- **A sanitized test readout or monitoring pack** → the matching rows can rise to `high`.
- **Deeper research on Brindlemoor** (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) → this needs search allowed; say the word and it runs.

## Questions

1. R1: Are you UK-based, with the right to work here without sponsorship?
2. G1: On the 14 price tests, which parts were yours: the design (cells, sample sizes, duration), the readout, the recommendation?
3. Constraints: Is there anything you wouldn't trade on this move, such as a salary floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.