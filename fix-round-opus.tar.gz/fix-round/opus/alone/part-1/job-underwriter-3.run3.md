Web search was declined, so I assessed this using only the posting and background you pasted.

## Decision snapshot

**No, this one isn't worth pursuing. R1 and R2 are both hard gates, and both fail. Status: `no_go`.** What feels off is real, and it's written in the posting itself (RR3–RR6).

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin 5 days a week), R2 (Base pay of at least $150k)
- `must_have`: direct: R3, R4, R5, R6 · unclear: R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops)
- `important`: adjacent: R11 (Team of one to start), R12 (Selling to merchants, B2B)

R1, R2: both fail against your own stated constraints · R3, R4, R5, R6: your strongest evidence, all `medium` until probed · R7, R8, R9, R10: functions your background doesn't speak to yet.

**Opportunity ledger.** The posting breaks both of your non-negotiables (RR1, RR2). On its own merits it also shows four classic warning patterns: seven functions handed to one person (RR3), always-on hours framed as culture (RR4), no defined success metrics on a mandate that owns all revenue (RR5), and pay that looks low for the seniority it asks for (RR6). I couldn't verify the employer (RR7). The one positive, profitability, is unverified (RR8), and the equity is undefined (RR9).

- **Hard gates:** failed: R1 (On-site in Austin 5 days a week), R2 (Base pay of at least $150k)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** Novaline would have to drop "no exceptions" and hire you remote from Portland, and raise the base to at least $150k, which is about 1.8× the top of its stated range. The other route is you changing a non-negotiable. Better wording can't fix either one.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; not verified (RR7) |
| Mandate | Own all revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Terms | $70–85k base plus "meaningful equity upside"; on-site in Austin 5 days a week, "no exceptions" | `[grounded]` JD |
| Working pattern | "Evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Scope read | This is at least three jobs in one (acquisition, brand/PR/comms, revenue ops/partnerships), and the pay is set like one mid-level hire | `[inferred]` from the function list against the stated band |
| First-year outcomes | Not stated; "success metrics will evolve as we learn" | `[grounded]` JD |
| Market calibration | Not established. The role-family sweep was refused, and I'm giving no band, because a figure from memory would have no source | none |
| Unknowns | Growth budget; equity size, vesting and strike price; who sets the metrics; what "when it matters" means in practice; whether the customers are merchants (B2B) | none |
| Contradictions | "8+ years growth leadership" and a board dotted line sit beside a $70–85k base and no team | `[inferred]` from the JD's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, no exceptions (vs. your remote-only constraint) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint: remote-only, living in Portland, not relocating. The fit fails because the JD rules out exceptions | `[grounded]` JD and your stated constraint | Surface it; only Novaline changing its terms resolves it |
| R2 | Base pay of at least $150k (JD states $70–85k) | hard_gate | hard_gate_fail | high | hard_gate | Your stated floor against the posting's own figure; the top of the range is $65k short. Equity doesn't count toward a base floor | `[grounded]` JD and your stated constraint | Surface it; only a change to the stated band resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | 9 years in growth as Growth Lead, then Head of Growth. This comes from intake prose, so the ceiling is `medium`. How many of the 9 years were in titled lead roles isn't stated | `[grounded]` your background | none for this role |
| R4 | Own all revenue growth end to end | must_have | direct | medium | none | Scaled ARR from $8M to $40M over three years with a budget you controlled. Specific, but nothing inspectable yet | `[grounded]` your background | none for this role |
| R5 | Paid acquisition | must_have | direct | medium | none | Owned paid at both companies | `[grounded]` your background | none for this role |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze | `[grounded]` your background | none for this role |
| R7 | SEO/content | must_have | unclear | low | discovery | Your background doesn't mention it either way | `[grounded]` background silent | G1 |
| R8 | Brand and PR | must_have | unclear | low | discovery | Your background doesn't mention it either way | `[grounded]` background silent | G2 |
| R9 | Partnerships | must_have | unclear | low | discovery | Your background doesn't mention it either way | `[grounded]` background silent | G3 |
| R10 | Sales ops | must_have | unclear | low | discovery | Your background doesn't mention it. Your companies were B2C subscription businesses | `[grounded]` background silent | G3 |
| R11 | Team of one to start, hands-on across every channel | important | adjacent | medium | transferability | Carries over: hands-on SQL, GA4 and Braze. Limit: your recent roles managed teams of 3–7, and the background doesn't show running all of these functions alone | `[grounded]` your background; `[inferred]` that the tool depth means you can do the work yourself | G4 |
| R12 | Selling to merchants, B2B (implied, not stated) | important | adjacent | medium | transferability | The requirement is inferred from "e-commerce enablement". Carries over: subscription growth and lifecycle. Limit: B2C only | `[inferred]` from the company description; `[grounded]` B2C history | Carry the limit in any similar application |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | Nothing either way | It can't change this decision. It matters for full-stack Head of Growth roles like this one | Owning organic as a channel in your growth model; briefing or managing content production; SEO experiments in your test backlog | A channel-mix dashboard, an experiment log | `[grounded]` background silent; `[generic]` that full-stack growth roles list this |
| G2 | Brand and PR (R8, must_have) | discovery | Nothing either way | Same as G1 | Running launches with a PR agency; owning positioning or messaging tests | A launch brief, a messaging test readout | `[grounded]` background silent |
| G3 | Partnerships and sales ops (R9, R10, must_have) | discovery | Nothing either way; B2C history | Same as G1 | Affiliate or influencer programs; co-marketing deals; CRM/attribution plumbing that sales or partner teams used | A partner program summary, a revenue attribution model | `[grounded]` background silent |
| G4 | Team of one (R11, important) | transferability | Hands-on tools, managed teams | Shows whether you're a fit for builder-stage roles in general | Early stretches before your team was hired; channels you ran personally | A dashboard or query you built yourself | `[inferred]` from your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay conflicts with your $150k floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The band is the budget. Closing a $65k+ gap at the top of the range is rare | `[grounded]` JD figure; `[generic]` that stated bands rarely stretch that far | Is the $70–85k base fixed, or is there a separate band for this level? | confirmed |
| RR2 | Five days on-site conflicts with remote-only (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out exactly the exception you would need | `[grounded]` JD | Is there any circumstance in which this role is remote? | confirmed |
| RR3 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | Several full functions folded into one seat and priced as one mid-level hire, which tends to mean spreading thin across all of them | `[inferred]` from the JD's function list against its band; `[generic]` bundling pattern | What growth budget and headcount are committed for the first year? | unresolved |
| RR4 | Always-on hours framed as culture | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Off-hours work is presented as identity, not as an exception | `[inferred]` from the JD's wording | How many weekends last quarter did the team work, and what triggered them? | unresolved |
| RR5 | Demanding mandate with no success metrics | risk_signal | medium | "success metrics will evolve as we learn" | You'd be accountable for all revenue with the target able to move under you, while reporting into the board | `[inferred]` from the JD's wording | What revenue or pipeline number would make this hire a success at 12 months? | unresolved |
| RR6 | Pay looks low for the seniority asked | risk_signal | medium | "8+ years growth leadership required… $70–85k base" | 8+ years of leadership plus a board dotted line, at this base, suggests the role is priced below its title. Not confirmed, because the market sweep couldn't run | `[inferred]` from the JD's own pairing | How was this band set, and what level is it benchmarked against? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR8 | Profitable since founding, direct CEO line | positive_signal | — | "profitable since day one… Report to the CEO" | If true, there's less runway pressure and real access to decision-makers | `[grounded]` JD; unverified | Is profitability measured monthly or annually, and has it held through the Series A spend? | noted |
| RR9 | Equity is undefined | unknown | — | "meaningful equity upside" | "Meaningful" has no number behind it, and the equity is being used to offset a low base | `[inferred]` from the JD's wording | What percentage, vesting schedule, and strike price, and what's the last 409A? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting | R1, R2; RR1, RR2 | `[grounded]` map and register | pending your approval |
| A2 | If Novaline or a recruiter contacts you, ask the RR1 and RR2 questions verbatim before investing any time. Only a change to the stated terms reopens this | RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | In future full-stack Head of Growth searches, lead with R4 ($8M→$40M ARR with your own budget) and screen out postings on the two gates first | R4; R1, R2 | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin" was refused. It would have confirmed that the company exists as described and the posting is live (RR7, role reality's organization row) |
| 2. Role-family sweep | unavailable | The search "Head of Growth Series A startup salary 2026 base compensation" was refused. It would have produced the market calibration line and confirmed or cleared RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search |

## Closing

I can put all of this into a `tuesday-dossier.md` file you keep for later, if you want one.

**Upgrade menu**
- Allow web search → targets 1 and 2 run: RR7 confirms or clears, and RR6 gets a sourced market band.
- A deeper research pass on Novaline (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs. It can't move this decision past R1 and R2.
- Your CV → R3–R6 can be checked against dates and titles, and G1–G4 become answerable for your next role like this.

I'm not asking any questions this turn. R1 and R2 decide the outcome, and nothing you could tell me would change it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.