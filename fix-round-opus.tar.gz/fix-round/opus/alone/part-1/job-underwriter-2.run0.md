Both web searches were refused for lack of permission, so this assessment uses only your JD and resume.

## Decision snapshot

**No, you're not wasting your time. This is a real stretch on one line (R1b), and a credible one everywhere else. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1a (product management experience), R2 (Shipped API or platform products), R7 (Run discovery with integration partners), R8 (Write specs and drive delivery with two squads) · unclear: R6 (Own the roadmap) · absent: R1b (3+ years with a PM title)
- `important` — direct: R4 · unclear: R5 (Agile delivery), R9 (Launches with sales and support), R10 (Define and track adoption metrics)

R1b — the one line no wording can fix; R2, R7, R8 — real bridges with their limits named; R6 — the row most likely to change how strong your case reads.

**Opportunity ledger.** I couldn't confirm the employer exists as described, because research was blocked (RR1). Pay and location are not stated (RR2, RR3), and it's unclear who has the final say on the roadmap (RR5). One entry points the other way: the posting gives the role real resources, two named squads, plus an adoption-metrics remit (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting checks out on Quartzline's own careers page (RR1); (2) you apply as a solutions engineer moving into PM, never as an uncredentialed PM, and expect R1b to be screened literally, so a referral is worth more than a cold application (R1b, plan A1); (3) pay and location clear your floor (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header, not yet checked against any outside source (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Resources | Two engineering squads | `[grounded]` JD |
| First-year outcomes | Not stated. Likely judged on partner adoption of the API platform | `[inferred]` from "define and track adoption metrics" being the only measurable thing the JD names |
| Scope read | One PM covering the full lifecycle of one platform surface, from discovery to launch | `[inferred]` from the responsibility list against the stated company size |
| Unknowns | Pay; location and remote policy; who sets priorities between partner asks and sales asks; who the PM reports to | — |
| Contradictions | None inside the JD. Not checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Product management experience, judged on the work | must_have | adjacent | medium | transferability | 7 years of scoping, requirements documents, coordinating engineering and PMs, and feeding the roadmap. That is next to PM work but is not PM work: no stated ownership of what gets built or why. Kept at `medium` because it is self-reported and not yet probed | `[grounded]` resume | see G1 |
| R1b | 3+ years with a PM title | must_have | absent | none | capability | You state you have never held a PM title. The JD marks this line must-have, and titled-years lines are often screened literally at the resume stage | `[grounded]` your statement and JD wording; `[generic]` that such lines are screened literally | closure path: referral (A1) or an internal PM move at your current employer; otherwise carry it as a material risk |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Carries over: 30+ end-to-end client integrations of your company's REST APIs. Limit: you integrated an API product others shipped, not one you shipped or prioritized yourself | `[grounded]` resume | see G5 |
| R3 | Strong technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs, and integration architecture across 30+ integrations. Specific, but unprobed, so `medium` for now | `[grounded]` resume | none; expect a technical probe |
| R4 | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your engineers, client engineers and PMs on custom builds. Sales is not mentioned, so it sits in R9 and this row doesn't stretch to cover it | `[grounded]` resume | none |
| R5 | Agile delivery experience | important | unclear | low | discovery | The resume says nothing about the delivery method | `[grounded]` resume silence | G3 |
| R6 | Own the roadmap for the platform | must_have | unclear | low | discovery | Roadmap input ("ran quarterly roadmap-input sessions") is not roadmap ownership. Earlier context suggests you built an internal request-triage tool that support agents adopted. That is unconfirmed and treated only as a lead. Kept at `low` rather than `none` because that lead gives a concrete question to ask | `[grounded]` resume; memory lead unverified | G1 |
| R7 | Run discovery with integration partners | must_have | adjacent | medium | transferability | Carries over: scoping workshops plus quarterly feedback sessions with clients. Limit: that discovery served a defined build or fed someone else's product decisions; you didn't turn it into a prioritized bet yourself | `[grounded]` resume | see G5 |
| R8 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | Carries over: requirements documents, UAT and go-live across 30+ projects. Limit: these were project-scoped client builds, not an ongoing backlog with standing squads | `[grounded]` resume | work sample W1 |
| R9 | Coordinate launches with sales and support | important | unclear | low | discovery | The resume doesn't say whether you worked with sales or support. The triage-tool lead touches support but is unconfirmed | `[grounded]` resume silence | G4 |
| R10 | Define and track adoption metrics | important | unclear | low | discovery | No metrics anywhere on the resume, including for the playbook the whole team uses | `[grounded]` resume silence | G2 |

On tiers: the JD tags only the years line "must-have". I tiered the other two listed technical requirements and the core responsibilities `must_have`, and the softer requirements `important`.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Roadmap ownership (R6, R1a) | discovery | Roadmap input, but no decision you owned about what got built | The clearest PM signal you could have; it decides whether R1a reads strong or thin | The triage tool, if real: deciding what it did, who it was for, what to cut; prioritizing the playbook's contents; choosing which client asks went forward to product | Screenshots or a description of the tool, a usage note, a prioritization doc | `[grounded]` resume; `[inferred]` that ownership evidence lifts R1a |
| G2 | Adoption metrics (R10) | discovery | No numbers anywhere | Metrics are named in the mandate | Time-to-go-live across integrations; the playbook's use across the team; the triage tool's adoption by support | A dashboard, a before-and-after figure, a team-adoption note | `[grounded]` resume silence |
| G3 | Agile delivery (R5) | discovery | Method not stated | It's a listed requirement, and cheap to close if true | Sprints, standups, or backlog grooming with your engineers on custom builds | A sprint board or ticket history | `[grounded]` resume silence |
| G4 | Sales and support coordination (R9) | discovery | Not mentioned | Launches run through sales and support here | Pre-sales technical support, handoffs to support at go-live, enablement | A handoff doc, an enablement deck | `[grounded]` resume silence |
| G5 | Platform product vs. integration (R2, R7) | transferability | Strong integration-side evidence | This bridge carries the application | Integration pain you turned into a product change request that shipped | The playbook (sanitized), a feature request you wrote | `[generic]` that SE-to-platform-PM is a recognized path; `[grounded]` your evidence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be real and simply not yet checked (research was blocked), the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this company | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | (no pay stated) | The figure may sit below what a platform PM role at this stage pays, or the company may just not publish pay | `[inferred]` from the posting's silence | What's the budgeted range for this role? | unresolved |
| RR3 | Location and remote policy unstated | unknown | — | (not stated) | It may conflict with constraints you haven't given yet | `[inferred]` from the posting's silence | Where is this role based, and what's the in-office expectation? | unresolved |
| RR4 | Resources and remit stated | positive_signal | — | "drive delivery with two engineering squads" | The mandate comes with real engineering capacity and a measurable remit | `[grounded]` JD | How are the two squads split across the platform today? | noted |
| RR5 | Roadmap authority vs. sales pressure | unknown | — | "Own the roadmap … coordinate launches with sales" | Partner-API roadmaps at sales-led B2B firms can be steered by deal-specific asks | `[generic]` role-family pattern | When a large partner or deal needs something off-roadmap, who decides? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume headline in your own words: "Solutions engineer / implementation lead, 7 years — led 30+ client integrations of our REST APIs end to end; wrote the integration playbook the team uses; ran quarterly roadmap-input sessions for product." | R2, R3, R7 stated without borrowing PM vocabulary for your history | `[grounded]` resume wording | resume_edits_pending_approval |
| P1 | Positioning: lead with the integration side of an API platform, which is exactly what this team builds for, and name the missing PM title yourself before the screener does. Don't describe the feedback sessions as "owning product discovery" | R1a, R1b, R7 | `[grounded]` map rows | pending your approval |
| W1 | A one-page sample spec for a partner-API improvement drawn from integration pain you saw (sanitized, nothing confidential) | Narrows the R8 limit with something they can inspect | `[grounded]` R8 | pending your approval |
| A1 | Look for a warm introduction before applying cold | A literal R1b screen tends to stop cold applications before anyone reads the bridge | `[generic]` hiring pattern | pending your approval |
| A2 | Confirm the posting on Quartzline's own site before you invest effort | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR1–RR5 verification questions verbatim in early calls | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: the request-triage tool support agents adopted (from earlier context, unconfirmed); it prompts G1 only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics API platform Series B careers" was refused (no permission). It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | The search "product manager platform APIs Series B B2B scope salary 2026" was refused (no permission). It would have added a market-calibration line and a pay band to set against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to run |

I can save all of this as a `tuesday-dossier.md` file you can reuse with the other Tuesday skills. Just say so.

## Upgrade menu

- Web search permission → targets 1 and 2 run: RR1 resolves either way, and you get a pay band for RR2.
- A link to the live posting or the recruiter's email domain → RR1 clears even without search.
- Your pay floor, location and work-authorization constraints → the hard-gates line becomes a real check instead of "unknown".
- The integration playbook (sanitized) or a requirements doc → R2, R7 and R8 can rise to `high`.
- The hiring manager's name → a sharper scope read, and which story to lead with.
- A deeper research pass on Quartzline (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1: Earlier context suggests you built an internal request-triage tool that support agents adopted. Is that right? If so, what did you personally decide about what it did and who it served, and how many people used it?

G2: Do you have any number tied to your work, such as go-live times, how many people use the playbook, or the tool's adoption?

Orientation: what's your pay floor, and do you have any location or remote constraints?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.