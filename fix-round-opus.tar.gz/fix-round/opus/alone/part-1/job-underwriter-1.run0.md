Reading the evaluation method is done. Next I'm running a few quick checks on Harborlight Health and on market norms for this role, then I'll give you the assessment.
I'm Arjun's underwriting pass on this role. Web search was refused in this session, so I couldn't check the company or market pay. Everything below rests on the JD and your background.

## Decision snapshot

**Yes, apply, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5, R7a · unclear: R6 (define and maintain the metrics layer), R7b (partner with clinicians)
- `important`: unclear: R8 (mentor two junior analysts)
- `preferred`: adjacent: R9 (healthcare data experience, HIPAA)

R6, R7b, R8: undocumented so far, not shown to be missing (see G1, G2, G3); R9: a real bridge with a named limit (G4).

**Opportunity ledger.** The role looks well defined: clear stack, scope and team size (RR5). But the employer couldn't be verified this session (RR1), pay and location aren't stated (RR2, RR3), and whether this is a senior IC role or the analytics lead is unclear (RR4).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live and Harborlight is what it says it is (RR1); (2) pay and work location meet your floor (RR2, RR3); (3) you have a real mentoring or coaching story for R8, or you present it honestly as a growth area.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C | `[grounded]` JD header; not checked independently (RR1) |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, work with PMs and clinicians, mentor two juniors | `[grounded]` JD |
| Scope read | One person owning the whole product analytics area with two juniors under them. That's a lead-shaped role under a Senior IC title | `[inferred]` from "own product analytics" plus "mentor two junior analysts" |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established. The pay and scope search was refused, and I won't give a band from memory | — |
| Unknowns | Pay; location and remote policy; who the role reports to; whether a metrics layer exists or is built from scratch; what working with clinicians involves | — |
| Contradictions | None in the JD as pasted | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years at a consumer-subscription company. Specific, but self-reported and not yet probed, so `medium` | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" will be tested live, not taken from a CV | `[grounded]` your background; `[generic]` that senior analyst loops usually include a live SQL exercise | Prepare for a live SQL round |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the experimentation program: 30+ A/B tests a year on a base of about 2M subscribers, including the pricing test behind an 11% retention lift | `[grounded]` your background | none |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards. Same tool as theirs | `[grounded]` your background | Dashboard screenshots (sanitized) would raise this to high |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | A redacted memo excerpt would raise this to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests modeled metric definitions, but you didn't say you built or own the semantic or metrics layer, and I won't assume it | `[grounded]` background silent on the metrics layer; `[inferred]` the link from "governed" | See G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | must_have | direct | medium | none | Monthly VP Product presentations, and a pricing test tied to a retention outcome. What you personally owned in the roadmap call is the thing to rehearse | `[grounded]` your background | none |
| R7b | Partner with clinicians | must_have | unclear | none | discovery | No clinical or domain-expert partnership in your background yet. The JD names clinicians as a partner group | `[grounded]` background silent | See G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention managing, mentoring or reviewing others' work | `[grounded]` background silent | See G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse's consent-state model. Limit: no HIPAA, no PHI, no clinical data | `[grounded]` your background; `[generic]` that HIPAA adds its own PHI rules beyond consumer-privacy regimes | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Looker built from scratch, 40+ governed dashboards; no statement about owning metric definitions | It's the first item in the JD's mandate; a yes moves R6 to direct | Writing LookML explores and measures; one canonical definition of "active subscriber" or "churn"; a dbt metrics or semantic layer; settling disputes between teams' numbers | A sanitized LookML snippet, a metrics dictionary, a definitions doc | `[grounded]` background silence; `[inferred]` that this is the JD's lead item, from its order |
| G2 | Partnering with clinicians (R7b, must_have) | discovery | No domain-expert partnership mentioned | It's a must-have and the furthest from consumer subscription work, so expect a direct question on it | Working with nutritionists, food-safety or culinary teams on what a metric should mean; ops or supply-chain experts who weren't analysts; turning expert judgment into a test hypothesis | A project brief or a memo written for a non-analyst expert audience | `[grounded]` background silence; `[generic]` that domain-expert partnership is probed in health-tech loops |
| G3 | Mentoring juniors (R8, important) | discovery | Nothing on mentoring | Two direct reports or mentees are part of the role; a "never" changes how you present the application | Onboarding a new analyst; reviewing others' SQL or test designs; running a Looker training; being the go-to reviewer for experiment readouts | Not needed; a specific instance is enough | `[grounded]` background silence |
| G4 | HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling plus a consent-state model you built | Preferred, not required. The bridge helps if presented as adjacent work | Carries over: consent modeling, PII access control, privacy-aware warehouse design. Limit: no PHI, no business associate agreements, no HIPAA de-identification rules. Strengthener: a one-paragraph explanation of how your consent-state model would map to PHI access tiers | A sanitized diagram of the consent-state model | `[grounded]` your background; `[generic]` HIPAA-specific concepts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Research couldn't run this session, so nothing points to a problem. Low rather than medium because what's missing is a check, not a warning sign | `[generic]` standing check, not a claim about this company | Can you point me to this role on your own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (JD silent) | The figure could fall below what a senior lead-shaped role pays, or the company may simply not publish salaries | `[inferred]` from the posting's silence | What salary range and equity are budgeted for this role? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | (JD silent) | Could be remote, hybrid or office-based | `[inferred]` from the posting's silence | Is this role remote, hybrid or office-based, and in which locations can you hire? | unresolved |
| RR4 | IC title with lead-shaped scope | risk_signal | low | "Own product analytics … mentor two junior analysts" | You may carry analytics-lead accountability without the title or pay | `[inferred]` from the JD's scope against its title | Who does this role report to, and is there an analytics lead above it, or is this the most senior analyst? | unresolved |
| RR5 | Concrete scope, named tool, named team | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The posting knows what it needs; the stack matches yours | `[grounded]` JD | Does the metrics layer exist today, or would I be building it? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program: "Designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | R3; your own wording, checked against the reframing rules: "behind" stays as you wrote it and is not upgraded to "drove" | `[grounded]` your background | pending your approval |
| P2 | Second, the Looker build: "Built the company's Looker instance from scratch — 40+ governed dashboards." Add "metrics layer" only if G1 confirms it | R4, R6 | `[grounded]` your background | pending your approval |
| P3 | Cite the monthly exec metrics memo as proof of writing for non-technical readers | R5 | `[grounded]` your background | pending your approval |
| P4 | Present privacy work as adjacent: "handled GDPR/CCPA consumer PII; built the warehouse consent-state model". Never "HIPAA experience" or "healthcare data" | R9, G4 | `[grounded]` your background | pending your approval |
| P5 | Ask the RR2, RR3 and RR4 questions in the first recruiter call, before investing in the full loop | Pay, location and level could each change the decision | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | "Harborlight Health care navigation app" was refused (no search permission). It would have confirmed the company exists and the posting is live, and could have cleared RR1 |
| 2. Role-family sweep | unavailable | "senior product analyst salary digital health 2026" was refused. It would have filled market calibration and tested RR2 and RR4 |
| 3. Hiring manager's public footprint | n/a | No name given |

If it would help, I can put all of this into a `tuesday-dossier.md` file you can keep and reuse in later steps.

## Upgrade menu

- **Web search permission:** runs targets 1 and 2, which could clear RR1 and add a pay band and scope norm to market calibration.
- **A one-line answer on whether you owned LookML or metric definitions:** R6 moves from unclear to direct (G1).
- **A sanitized LookML snippet, metrics dictionary or exec-memo excerpt:** R4, R5 or R6 rise from `medium` to `high`.
- **Your pay floor, location needs and work authorization:** turns the hard-gates line from "unknown" into real checks.
- **The hiring manager's name:** sharpens the scope read and which story to lead with.
- **A deeper pass on Harborlight** (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches): just say the word.

**Questions:**

1. **Constraints:** What's your pay floor, and do you need remote, a particular city, or visa sponsorship?
2. **G2:** Have you ever worked closely with a non-analyst expert group, like nutritionists, food-safety or ops specialists, to define what a metric or test should measure? What was your part?
3. **G3:** Have you onboarded, coached or regularly reviewed the work of another analyst, even informally?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.