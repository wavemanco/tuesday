I've read the skill's rules; next I'm running a few budgeted checks on Pellucid Learning before writing your assessment.
**Yes, it looks worth applying to, on the conditions below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R6, R7 · unclear: R8 (Ingestion from our app and CRM)
- `important`: adjacent: R5 (A warehouse in BigQuery) · unclear: R9 (Data contracts our analysts depend on)

R5: a Snowflake-to-BigQuery bridge with its limit named; R8, R9: responsibilities your background doesn't mention yet, which is a discovery question and not a capability gap.

**Opportunity ledger.** Clear and well calibrated. The posting is live on Pellucid's own careers page and matches what you pasted (RR1), and the stated salary sits at or above the pay report's middle range (RR2). Still open: no hiring manager or team is named (RR3), the equity isn't quantified (RR4), "data contracts" isn't defined (RR5), and student-data handling isn't mentioned (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work from the US or from Denver (R1); (2) your own pay floor is within $148,000–$166,000 (RR2); (3) you present BigQuery honestly as a bridge from Snowflake, never as experience you have (R5, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` About page, fetched; matches what you pasted |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 base, plus equity of unstated size | `[grounded]` JD |
| Scope read | One reporting domain, end to end, with no people-management language. A normal scope for a single senior IC | `[inferred]` from the JD's single-domain mandate and its silence on direct reports |
| Market calibration | The report's Senior Data Engineer at Series B–D companies: base median $151,000, middle range $139,000–$163,500, typically 5–8 years, owning one domain's pipelines with no direct reports. The posting's floor is $9,000 above the bottom of that range and its ceiling is $2,500 above the top. The title and scope fit the norm. This is a market band, not Pellucid's offer to you | `[generic]` Datawright 2026 report, US, n=2,310, as you pasted it; `[grounded]` JD, for the posting's figures |
| First-year outcomes | Not stated | `[grounded]` the JD is silent |
| Unknowns | Who you'd report to and team size; equity terms; what "data contracts" covers; student-data obligations | — |
| Contradictions | None between your pasted text and the live posting and About page | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | The posting limits where you can work from. Nothing you've said covers your location or US work authorization, so there's no claim to grade yet | `[grounded]` JD; your background is silent on it | Closing question R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | "6 years of data engineering" against 5+. Stated but not yet probed, so `medium` at intake. The report's typical 5–8 years for "Senior" brackets it | `[grounded]` your background; `[generic]` report band | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily". Stated, unprobed | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models". Snowflake is a cloud warehouse, which is what this line asks for. Expect a probe on which parts were yours | `[grounded]` your background | An inspectable artifact would raise this to `high` (see upgrade menu) |
| R5 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt modelling and SQL carry over directly. Limit: you've never used BigQuery itself. Moving between warehouses usually means relearning cost, partitioning and SQL dialect details, not modelling | `[grounded]` "Never used BigQuery"; `[inferred]` requirement, from the JD naming BigQuery as the warehouse; `[generic]` what a warehouse switch involves | G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration". Stated, unprobed | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite". Specific and in your own words | `[grounded]` your background | none |
| R8 | Ingestion from our app and CRM | must_have | unclear | low | discovery | The JD's first named responsibility, so tiered `must_have`. Your background covers orchestration and modelling but not which sources you ingested or who built that layer | `[grounded]` your background is silent on ingestion | G2 |
| R9 | Data contracts our analysts depend on | important | unclear | low | discovery | The Great Expectations suite is nearby context, but testing data is not the same as agreeing a contract with the teams that produce it | `[grounded]` your background; `[inferred]` the distance between testing and contracts | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery as the warehouse (R5, important) | transferability | About 180 dbt models on Snowflake; no BigQuery | It's the one named tool in the stack you haven't used, so it's the likeliest screening objection | Bridge: dbt and SQL modelling carry over. Limit: BigQuery's cost model, partitioning and dialect are untested. Strengthener: a small dbt project run against BigQuery | A public repo of that project | `[grounded]` your background; `[generic]` that a named tool gap draws the screening question |
| G2 | Ingestion from app and CRM (R8, must_have) | discovery | Pipelines are implied by Airflow and dbt, but no sources or ingestion ownership are stated | A `must_have` row at `unclear`; settling it firms up the fit on the first responsibility listed | Loading payroll-app database tables into Snowflake; pulling from a CRM or billing system through its API; setting up a managed connector, change-data-capture, or custom Python extract jobs | A DAG or architecture diagram, sanitized | `[grounded]` your background is silent on it |
| G3 | Data contracts (R9, important) | discovery | A Great Expectations suite; no contract-style agreements mentioned | The JD names contracts as something analysts depend on, so expect it in interviews | Schema agreements with app engineers; tests that fail a deploy when an upstream column changes; documented guarantees or SLAs on models analysts read | A contract spec, a dbt model-contracts config, a README | `[grounded]` your background; `[inferred]` that interviews will probe it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting check out as described | positive_signal | — | "Accepting applications." | The posting is live and current, and the company's stage and size match | `[grounded]` careers page and About page, fetched | Is this role a new position or a backfill? | noted |
| RR2 | Salary stated, at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The band is transparent and its ceiling is above the report's 75th percentile | `[grounded]` JD; `[generic]` report band | Where in the band do you expect to land someone with six years, and what moves an offer toward the top? | noted |
| RR3 | No hiring manager or team named | unknown | — | "The posting names no hiring manager" (your note) | Reporting line and team size are unknown. Postings often leave them out, and that's no evidence of a problem | `[generic]` pattern, not a claim about Pellucid | Who would this role report to, and how many data engineers and analysts are on the team? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | At a Series C company the value of a grant depends on type, size and strike price, none of which are stated | `[generic]` pattern for venture-backed equity | What would the grant be (type, share count, vesting schedule, strike price)? | unresolved |
| RR5 | "Data contracts" undefined | unknown | — | "the data contracts our analysts depend on" | The role may involve getting the app and CRM teams upstream to agree schemas, and that needs cross-team authority the JD doesn't mention | `[inferred]` from the JD naming contracts while staying silent on whose they are | Do the contracts bind the app and CRM teams upstream, or the models analysts read downstream, and who enforces a breach? | unresolved |
| RR6 | Student-data handling not mentioned | unknown | — | "live online tutoring for K-12 schools in 31 US states" | K-12 data usually carries student-privacy obligations that shape pipeline and access design | `[generic]` pattern for K-12 data | What student-privacy requirements does the warehouse have to meet, and who owns compliance? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dbt project in your own words: "Built our dbt project on Snowflake — about 180 models" | see R4 | `[grounded]` your background | pending your approval |
| P2 | Put the Great Expectations suite directly against "experience with data quality testing", as "set up our Great Expectations test suite" | see R7 | `[grounded]` your background | pending your approval |
| P3 | Say plainly that you haven't used BigQuery yet, and give the dbt/SQL carry-over as the bridge. Never write "BigQuery experience" or "familiar with BigQuery" | see R5, G1 | `[grounded]` "Never used BigQuery" | pending your approval |
| W1 | Optional: a small public dbt project run against BigQuery, to narrow G1 before interviews | see R5 | `[grounded]` R5 row | pending your approval |
| Q1 | Ask the verification questions for RR3, RR4, RR5 and RR6 word for word during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

All the proposed language above (P1–P3) is a proposal, not final. It stays pending until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring Denver" (no results) and "Pellucid Learning senior data engineer careers", which returned the careers page. Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about). Both match your pasted text and the posting reads "Accepting applications". This fed role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | yes | A check of the report you pasted: searched "Datawright 2026 Data Engineering Pay Report senior data engineer", which returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report) with the same figures. That address is on a reserved ".example" domain, so this shows the figures match, not where the report came from. Market calibration and RR2 use the figures as you pasted them |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to run. The upgrade menu says what a name would add |

I can save all of this as a `tuesday-dossier.md` you can carry into later steps, if that's useful.

## Upgrade menu

- **Your location, work authorization and pay floor:** closes R1 and condition (2), so the status likely settles to `go` or `no_go`.
- **An inspectable artifact** (a dbt docs or lineage export, a sanitized repo, a Great Expectations results page): raises R4 and R7 to `high`.
- **A small dbt-on-BigQuery repo:** narrows G1, and R5's bridge gets an artifact.
- **Your current CV:** lets me check whether it shows R4 and R7 the way your note does, or buries them, and propose edits.
- **The hiring manager's name:** runs target 3 and tells the plan which story to lead with for that reader.
- **A deeper research pass on Pellucid** (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

**R1:** Are you based in the US with the right to work here, and do you have a pay floor or location requirement this role would need to meet?

**G2:** At the payroll company, which sources did your pipelines ingest from (app databases, a CRM, third-party APIs), and which of those ingestion jobs did you build yourself?

**G3:** Have you set up anything analysts relied on as a formal guarantee, such as schema agreements with upstream engineers, tests that break a deploy on a column change, or documented SLAs on models? What part of it was yours?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.