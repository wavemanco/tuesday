Reading the skill's rules is done; next I'm checking that Pellucid's posting and company page match what you pasted, then writing the assessment.
**Yes, Ines, this looks worth applying to. Status: `conditional_go`.** The conditions are two terms you haven't told me about yet. They're listed below.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R9 (Remote (US) or our Denver office), R10 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R1, R2, R3, R5, R6
- `important` — adjacent: R4 (a dbt-modelled warehouse in BigQuery) · unclear: R7 (ingestion from our app and CRM), R8 (the data contracts our analysts depend on)

R4 — the Snowflake-to-BigQuery bridge, with its limit stated; R7, R8 — your background doesn't mention these, so each is worth one question.

**Opportunity ledger.** The employer and the posting both check out (RR1), and the pay is stated and sits at or above your report's market median (RR2). Some things are still open: who you'd report to and how big the team is (RR3), the equity terms (RR4), and whether the data contracts already exist or are yours to build (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or our Denver office), R10 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work from the US or Denver with US work authorization — R9; (2) the range clears your pay floor — R10; (3) you present BigQuery honestly as a transfer from Snowflake, never as experience you have — R4, G1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page, confirmed by search |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Stated requirements | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| First-year outcomes | Not stated. Likely the reporting pipelines and contracts running reliably | `[inferred]` from the mandate wording only |
| Scope read | One domain (reporting) with no direct reports mentioned | `[inferred]` from the JD's silence on people management |
| Market calibration | The report defines Senior as 5–8 years and one domain's pipelines with no reports, which matches this JD's scope and your 6 years. The posted $148k–$166k has a midpoint of $157k, against a $151k median. Its floor is above the 25th percentile ($139k) and its top is above the 75th ($163.5k). This is the market, not Pellucid's offer | `[generic]` Datawright 2026 report as you pasted it (I didn't check it); `[grounded]` JD for the posted range |
| Unknowns | Hiring manager and team size; equity terms; whether the data contracts exist yet; student-data privacy duties | — |
| Contradictions | None. The live careers page matches your pasted JD word for word | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years, which meets the requirement. This is your own account and hasn't been probed yet, so it's capped at medium | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use of both. Nothing inspectable yet | `[grounded]` your background | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so this is a direct match | `[grounded]` your background | none |
| R4 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt and warehouse modelling carry over. The limit: you've never used BigQuery. `[generic]` BigQuery differs from Snowflake in its pricing by bytes scanned, partitioning and clustering, and GCP access control | `[inferred]` requirement taken from the mandate wording; `[generic]` the platform differences | see G1 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You stated Airflow, which is a direct match | `[grounded]` your background | none |
| R6 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite | `[grounded]` your background | none |
| R7 | Ingestion from our app and CRM | important | unclear | none | discovery | Your background describes modelling, orchestration and testing, but no ingestion work. It may simply be left out | `[grounded]` background is silent | see G2 |
| R8 | The data contracts our analysts depend on | important | unclear | low | discovery | The GE suite is indirect context: tests are something analysts rely on, but that isn't the same as a contract | `[inferred]` from the GE suite | see G3 |
| R9 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You didn't give your location or work authorization, so this gate isn't settled either way | `[grounded]` JD; nothing from you on it | the R9 question below |
| R10 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You didn't give a pay floor, so I can't check the range against it | `[grounded]` JD; nothing from you on it | the R10 question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R4, important) | transferability | Strong dbt on Snowflake; no BigQuery at all | It's the one stack difference between your background and the posting | Warehouse cost and performance tuning on Snowflake; making a dbt project work on a different warehouse; any GCP use | A small dbt project on a BigQuery public dataset, in a public repo | `[grounded]` background; `[generic]` that a stack gap gets probed in screens |
| G2 | Ingestion from app and CRM (R7, important) | discovery | Ingestion isn't mentioned | It's a third of the mandate | Loading payroll app events or a production database; pulling from a CRM or HR SaaS API; running Fivetran or Airbyte-style connectors | A DAG excerpt or a design doc, sanitized | `[grounded]` background is silent |
| G3 | Data contracts (R8, important) | discovery | The GE suite is the nearest evidence | It's named in the mandate, and analysts depend on it | Schema or SLA agreements with analysts; CI checks that block breaking model changes; dbt model contracts or exposures | A test suite README, or a contract spec | `[inferred]` link from the GE suite |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting established | positive_signal | — | "Accepting applications" | The company exists as described and the role is live | `[grounded]` careers page and about page | — | noted |
| RR2 | Pay stated, at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent, and its midpoint is above the report's median | `[grounded]` JD; `[generic]` report band | Where in the range do you expect to land someone with 6 years' experience? | noted |
| RR3 | No hiring manager named and no team size given | unknown | — | "Build and run the pipelines" | The role may be the data team's only engineer, owning both building and on-call | `[inferred]` from "build and run" with no team mentioned | Who does this role report to, and how many data engineers are on the team today? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | `[generic]` After a Series C, equity is often options with unknown strike price and dilution | `[generic]` stage pattern | What form does the equity take, how many shares, and on what vesting schedule? | unresolved |
| RR5 | Whether the data contracts exist yet | unknown | — | "the data contracts our analysts depend on" | They may be mature, or informal and waiting to be written | `[inferred]` from the wording | Are the analysts' data contracts written down today, or would this role write them? | unresolved |
| RR6 | Student-data privacy duties | unknown | — | "K-12 schools" | `[generic]` K-12 data often carries FERPA and state privacy rules that affect pipeline design | `[generic]` sector pattern | What student-data compliance requirements does the warehouse have to meet? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead line: "Built our dbt project on Snowflake (about 180 models), orchestrated in Airflow; set up our Great Expectations test suite." | R3, R5, R6, in your own verbs | `[grounded]` your background | resume_edits_pending_approval |
| A1 | Say plainly in the application that you haven't used BigQuery yet, and point to the dbt and warehouse work that carries over | R4. Being upfront beats being found out at the screen | `[grounded]` R4 row | pending your approval |
| W1 | Build a weekend dbt-on-BigQuery project on a public dataset before the technical screen | Narrows the R4 limit | `[generic]` common way to close a stack gap | pending your approval |
| Q1 | Ask the verification questions for RR3, RR4, RR5 and RR6 in the recruiter call | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Searched "Pellucid Learning online tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). This checked your pasted material: the posting is live and both texts match. It moved Role reality's organization and contradictions rows, plus RR1 |
| 2. Role-family sweep | skipped | The Datawright figures you pasted already set the market calibration line and the pay-mismatch check |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save all of this as a `tuesday-dossier.md` file whenever you'd like one.

## Upgrade menu

- Your location and work authorization → R9 resolves.
- Your pay floor → R10 resolves, and the status can move to `go`.
- A GitHub repo or design doc from your dbt or GE work → R3 and R6 can rise to `high`.
- Answers to G2 and G3 → R7 and R8 resolve.
- The hiring manager's name → which story to lead with for that reader.
- A deeper research pass on Pellucid (leadership churn, hiring patterns, employee reviews, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

**R9** — Are you based in the US with US work authorization, or willing to work from Denver?

**R10** — Does a $148k–$166k base clear your floor?

**G3** — Have you set up anything like a contract with analysts, such as schema guarantees, SLAs, or CI checks that block breaking changes? What was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.