Web search permission was refused, so this assessment uses only what you told me and the JD.

## Decision snapshot

**Yes, go for it, but check two things first: whether the posting is live and whether you're UK-based for the remote setup. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6, R7 · unclear: R8 (Recommendations for product)
- `important`: adjacent: R9 (Pet-insurance pricing knowledge)
- `preferred`: direct: R10

R9 is a real bridge from motor to pet, but present it as adjacent experience, never as pet expertise. Your background doesn't mention the product-facing half of the brief (R8). R5 and R6 (`medium`) are direct, and you should expect probes on who designed the tests and how monitoring worked.

**Opportunity ledger.** The responsibilities are concrete and the hiring manager is named (RR4). Against that, the employer couldn't be checked because research didn't run (RR1), the posting gives no pay (RR2), and it doesn't say whether "own pricing analytics" comes with a team (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting shows up on Brindlemoor's own careers page (RR1); (2) you can work fully remote from the UK (R1); (3) the pet gap is framed honestly as adjacent (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not verified independently (RR1) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Odile Varga, Director of Pricing, is the hiring manager | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Line management | The JD names no reports and asks for no management experience | `[grounded]` JD silence |
| Scope read | A senior individual-contributor pricing role. "Own" may mean the whole pricing analytics function at a small insurtech, or one seat in the Director's team | `[inferred]` from "own pricing analytics" against the JD's silence on team size |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not established. The role-family sweep didn't run, so I've given no pay band rather than guess one | — |
| Unknowns | Salary; team size and whether there are reports; who the product counterparts are; how mature the data and models are | — |
| Contradictions | None in the JD as given | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You work for a UK motor insurer, but you haven't said where you live or whether you have UK right to work | `[inferred]` from your current employer | Question G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years of pricing analytics, the last 2 as senior analyst. This is self-report, so `medium` is the ceiling | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You stated "SQL and Python daily" | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your message | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building. You didn't describe what monitoring involved (drift, performance against plan), so expect a probe | `[grounded]` your message | Be ready to describe how the model was monitored |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 tests last year "with the underwriting team". Which parts of the design and the readout were yours isn't stated, so I've read it conservatively | `[grounded]` your message | Be ready to say which parts of the design and readout were yours |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R8 | Turning results into recommendations for product | must_have | unclear | low | discovery | Your underwriting-facing work is clear (R7). Nothing mentions product teams | `[grounded]` your background is silent on product | Question G2 |
| R9 | Pet-insurance pricing knowledge | important | adjacent | medium | transferability | GLM rating, price testing and underwriting work carry over. The limit is that you've never worked on pet, whose rating factors and claims patterns differ from motor | `[inferred]` adjacency from your motor work; `[generic]` that pet rating uses different factors from motor | See G3 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Fully remote (UK) (R1, hard_gate) | hard_gate | A UK employer, but no stated location or right-to-work status | This is the one gate on the map, and it's the only thing that could fail outright | Living in the UK with right to work and no sponsorship needed | None needed. Your word is the evidence | `[grounded]` the JD's location term; `[inferred]` UK base from your employer |
| G2 | Recommendations for product (R8, must_have) | discovery | Only underwriting-facing recommendations are mentioned | This is the one must-have the map can't yet call direct | Recommending a change to a product feature, excess option, add-on or cover limit based on test results; working with a product owner or pricing-engine team on how a test went live; a readout that went to product or commercial teams as well as underwriting | A sanitized test readout or review deck | `[grounded]` your background is silent on product; `[generic]` that insurtech pricing roles work closely with product teams |
| G3 | Pet-insurance pricing knowledge (R9, important) | transferability | Motor pricing only. **Carries over:** GLM rating structure, price testing, presenting to underwriting. **Limit:** no pet rating factors or pet claims experience. **Strengthener:** an honest bridge line, plus some reading on pet rating | It's the most obvious objection to a motor-only background | Any non-motor or small-line pricing; factors that change with age, as young-driver factors and pet age factors both do; telematics or new-data-source work | A short note on how you'd approach a pet rating review | `[inferred]` bridge from your motor work; `[generic]` that this is the most likely objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | It couldn't be verified because research didn't run, not because a search came back empty. Medium rather than high for that reason, even with pay withheld (RR2) | `[generic]` pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | "Fully remote (UK)" (the posting ends with no pay terms) | The figure may sit anywhere relative to market, or the company may simply not publish salaries | `[inferred]` from the posting's silence | What salary band is budgeted for this role? | unresolved |
| RR3 | "Own pricing analytics" with no team stated | unknown | — | "Own pricing analytics for our pet-insurance product" | This could be a solo function carrying the whole pricing workload, or one analyst in the Director's team | `[inferred]` from "own" against the JD's silence on team | Who works on pricing today, and does this role have any direct reports? | unresolved |
| RR4 | Concrete responsibilities and a named reporting line | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope is real and testable | `[grounded]` JD | Which price tests are planned for the first six months? | noted |

## Application plan

Every row below is proposed, and the framing language in P2 is pending your approval along with the rest. I haven't drafted any CV lines because I haven't seen your CV.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before applying, check the role is on Brindlemoor's own careers page | See RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Lead with the young-driver GLM, the 14 price tests and the quarterly review, in your own words. Frame pet like this: "I've priced motor, not pet. What carries over is GLM rating, price testing and presenting to underwriting." | See R4, R6, R7, R9 | `[grounded]` your message | pending your approval |
| P3 | If asked about management, say plainly that you haven't line-managed anyone. The JD doesn't ask for it | See role reality, RR3 | `[grounded]` JD silence | pending your approval |
| P4 | Ask the verification questions from RR1, RR2, RR3 and RR4 word for word during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Brindlemoor pet insurance careers" and the permission was refused. This would have confirmed or cleared RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | I searched "senior pricing analyst insurance UK salary remote GLM" and the permission was refused. This would have filled the market calibration row and given RR2 a band |
| 3. Hiring manager's public footprint | unavailable | I searched "Odile Varga Director of Pricing Brindlemoor" and the permission was refused. This would have refined the scope read and which story P2 leads with |

## Upgrade menu

- **Web search permission:** rows 1–3 above run, and RR1 can clear, which could turn this into a `go`.
- **The live posting link, or the recruiter's email domain:** RR1 can be resolved without any search.
- **Your CV:** I can check R2–R7 against how your CV presents them and propose specific edits.
- **A sanitized price-test readout:** R6 rises to `high`, and G2 may close.
- **Deeper research on Brindlemoor** (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

If it helps, I can save all of this as `tuesday-dossier.md` so you can pick it up later.

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

1. **G1:** Are you UK-based, with the right to work in the UK without sponsorship?
2. **G2:** Have any of your price-test readouts led to a recommendation for a product team rather than underwriting, such as a cover option, an excess structure or an add-on? What was yours, and what happened?
3. Is there a minimum salary or any other non-negotiable I should check this role against?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.