I'm checking Brindlemoor and the role against public sources (L1 research) before I write up the assessment.
**Yes, it's worth going for, on the conditions below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Monitor rating models)
- `important`: adjacent: R9 (Pet-insurance product knowledge) · unclear: R8 (Recommendations for underwriting and product)
- `preferred`: direct: R10

R6b: your background says "maintained" but not monitoring; R8: product-side recommendations aren't stated; R9: the move from motor to pet is a real bridge, and its limit is named below.

**Opportunity ledger.** I couldn't confirm that the employer exists as described (RR1). Pay isn't stated (RR2), and the team shape behind "own pricing analytics" isn't stated either (RR3). On the plus side, the mandate is concrete and names who it serves (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed, i.e. you're UK-based and can work here without sponsorship; (2) Brindlemoor and the live posting verify (RR1); (3) R9 framed honestly as adjacent: pricing discipline carried over, not pet-insurance experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product | `[grounded]` JD header; not independently verified (RR1) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, and make recommendations to underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Line management | None listed. The JD names no reports and no people-management duty | `[grounded]` JD silence on reports |
| Scope read | A senior individual-contributor role. "Own" suggests you'd be the main pricing analytics owner for one product, possibly without a team | `[inferred]` from "own pricing analytics" plus the absence of any team or reports in the JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not established. The role-family search was refused this session, so I'm giving no band rather than one from memory | — |
| Unknowns | Salary; team size and reporting line; whether price tests run on a live pet book; your stage (assumed evaluating) | — |
| Contradictions | None found within the JD; careers page not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK): based in the UK, with right to work | hard_gate | unclear | none | hard_gate | You work at a UK insurer, but you haven't said where you're based or whether you need sponsorship. Gates aren't inferred | `[grounded]` background silent on location and status | Question G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst, which clears the bar. Medium is the ceiling at intake: self-report with nothing inspectable yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily." Specific and plausible; nothing inspected | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for your young-driver book | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which matches the JD almost word for word | `[grounded]` your background | none |
| R6a | Build rating models | must_have | direct | medium | none | Built the young-driver GLM rating model. The qualifier stays: one book, motor | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" is stated; monitoring (tracking the model's performance after go-live) isn't. Reading monitoring into "maintained" would add a practice you never mentioned | `[grounded]` your wording | Question G2 |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. "Ran" covers running and reading. Who designed them isn't stated, so your own verb "ran" should carry it | `[grounded]` your background | Use "ran", not "designed", until confirmed (P1) |
| R8 | Turn results into recommendations for underwriting and product | important | unclear | low | discovery | The underwriting audience is established (R5, R7). Whether the recommendations were yours, and whether any went to a product team, isn't stated | `[grounded]` your background | Question G3 |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | GLM rating and price testing on a UK personal-lines book carry over. You stated no pet or non-motor experience | `[inferred]` requirement from "our pet-insurance product"; `[grounded]` your "never worked on pet insurance" | Bridge in G4; work sample W1 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Fully remote (UK) (R1, hard_gate) | hard_gate | No statement of your location, work status or other non-negotiables | It's a gate: unconfirmed, it caps the decision | Not applicable: this is a term you meet or don't, not experience | None needed; your word is the evidence | `[grounded]` background silent |
| G2 | Monitor rating models (R6b, must_have) | discovery | "Maintained" the young-driver GLM; nothing on watching how it performed after release | A must-have phrased as an ongoing duty: "build **and monitor**" | Tracking actual-vs-expected loss ratio on the young-driver book after a rate change; checking factor stability or drift between refreshes; deciding when the model needed a rebuild; watching conversion or retention after a test went live | A redacted monitoring dashboard screenshot or a monitoring-pack outline | `[grounded]` your wording; `[inferred]` that "maintained" may hide monitoring you didn't mention |
| G3 | Recommendations for underwriting and product (R8, important) | discovery | You present to the head of underwriting and run tests with underwriting; recommendations and any product audience aren't stated | The JD's last step is turning results into recommendations, which is the senior part of the job | A test readout where you recommended a rate change that was adopted; a recommendation on excess, discount or cover structure; any work with product or marketing on a price change | A redacted test readout or a quarterly review slide | `[grounded]` your background |
| G4 | Pet-insurance product knowledge (R9, important) | transferability | Bridge: GLM rating, price-test design and reading, and underwriting stakeholders on a UK personal-lines book. Limit: no pet book, so no direct knowledge of its rating factors, claims patterns or renewal dynamics. Strengthener: a short work sample (W1) | Likely the main objection to a motor-only candidate | Covered by the bridge; no question needed | A one-page note on how you'd approach a pet rating model (W1) | `[grounded]` your background; `[generic]` that pet pricing rests on different rating factors and claims behaviour than motor; `[generic]` that domain switch is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this kind, not a claim about this one; research was refused, not empty | Can you point me to this role on Brindlemoor's own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | (no compensation stated) | The figure may sit below market for a senior pricing role, or the company may simply not publish salaries | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Team shape behind "own pricing analytics" unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the sole pricing analyst, accountable for the whole function with limited support | `[inferred]` from "own" against the JD's silence on the team | Who else works on pet pricing today, and who would this role report to day to day? | unresolved |
| RR4 | Concrete mandate with named stakeholders | positive_signal | — | "build and monitor rating models, design and read price tests… recommendations for underwriting and product" | The scope is defined and the audience is clear | `[grounded]` JD | Is the pet book live and big enough to run price tests on now? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Brindlemoor's own site, or that the recruiter writes from a Brindlemoor domain, before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with your own words: "built and maintained the GLM rating model for our young-driver book" and "ran 14 price tests last year with the underwriting team". Keep "young-driver book", "with the underwriting team" and "ran" as written | R4, R6a, R7: the closest match to the mandate | `[grounded]` your background | pending your approval |
| P2 | Frame pet as a bridge: "pricing method and price testing on a UK personal-lines book; new to pet." Never "pet pricing experience" | R9 | `[grounded]` your "never worked on pet insurance" | pending your approval |
| P3 | Don't apologise for or pad around management. The JD asks for none, so don't claim it and don't raise it as a gap | Role reality: line management | `[grounded]` JD silence on reports | pending your approval |
| W1 | Optional one-page note: how you'd set up a pet rating model and a first price test, written as an approach, not as experience | R9, G4 | `[grounded]` R9 row | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3 and RR4 word for word in early calls; ask about pay (RR2) at the first conversation | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Brindlemoor pet insurance insurtech careers" was refused by permissions. It would have confirmed whether the company exists as described and whether the posting is live. It would have resolved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Search "senior pricing analyst insurance UK salary remote 2026" was refused. It would have filled the market calibration line and set a band against RR2 |
| 3. Hiring manager's public footprint | unavailable | Search "Odile Varga Director of Pricing" was refused. It would have informed the scope read and which verified story P1 leads with for this reader |

## Upgrade menu

- **Allow web search, and I'll rerun targets 1–3.** This would resolve or confirm RR1, add a market pay band, and sharpen P1 for Odile Varga as the reader.
- **A link to the live posting, or the recruiter's email domain:** RR1 closes and the decision cap lifts.
- **Your location, work status and any salary floor:** R1 resolves and the hard-gates line becomes complete.
- **A redacted price-test readout or monitoring dashboard screenshot** (the inspectable proof pricing work usually leaves behind): R6b, R7 and R8 can rise to `high`.
- **A deeper research pass** (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) whenever you say the word.

I can save all of this as a `tuesday-dossier.md` you can reuse later, if that's useful.

**Questions**

G1: Are you based in the UK with the right to work here without sponsorship, and is there any term you won't trade, such as a salary floor?

G2: After the young-driver GLM went live, did you track how it was performing, for example actual-vs-expected loss ratio or factor drift, and decide when it needed a refresh?

G3: In those 14 price tests or the quarterly review, were the recommendations yours, and did any go to a product team rather than underwriting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.