The page check was declined, so I won't retry it. I'm going ahead with the text you pasted.

## Decision snapshot

**Yes, it looks worth applying to, provided the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or our Denver office)
- `must_have` — direct: R2, R3, R4, R6, R7
- `important` — adjacent: R5 (BigQuery as the warehouse) · unclear: R8 (ingestion from our app and CRM), R9 (data contracts our analysts depend on)

R2, R3, R4, R6, R7 — each one is backed by a specific line from your background; R5 (`medium`) — Snowflake to BigQuery is a real bridge, and its limit is named in G1; R8, R9 — your background doesn't mention these, which means it's a discovery gap, not a capability gap.

**Opportunity ledger.** The posting publishes a pay range that sits around the market median (RR1). The open items are scope and team (RR2), what the equity is (RR4), and checking that the posting is still live (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you're US-based with US work authorization, or can be in Denver — R1; (2) the posting is still live on Pellucid's own careers page — RR3; (3) you present BigQuery as adjacent experience, never as experience you have — R5, G1; (4) the $148k–$166k range meets your pay floor. I don't know your floor yet.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring for schools in 31 US states; founded 2016 in Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` about-page text you pasted |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity | `[grounded]` JD |
| Location | Remote (US), or the Denver office | `[grounded]` JD |
| Scope read | One reporting domain, owned end to end from ingestion to the analyst-facing contracts. The JD mentions no direct reports | `[inferred]` from the JD's three-part mandate and its silence on managing anyone |
| Market calibration | Senior DE at Series B–D: median base $151k, IQR $139k–$163.5k; "Senior" usually means 5–8 years and ownership of one domain with no reports. The posting's 5+ years and single-domain mandate fit that norm. Its range starts $9k above the 25th percentile, and its top end is $2.5k above the 75th percentile (RR1). The band describes the market, not what this employer will offer | `[generic]` Datawright 2026 report as you pasted it (US, n=2,310); `[grounded]` JD for the posted range |
| Unknowns | Team size and reporting line; who uses the data contracts and how they're enforced; equity type and amount; any limits on which US states remote staff can live in; hiring manager | — |
| Contradictions | None between the JD and the about-page text as pasted. Neither has been checked against the live site | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You didn't say where you're based or whether you're authorized to work in the US, so this gate isn't settled either way | `[grounded]` JD terms; your background doesn't cover location | Question 1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company, which also falls in the report's 5–8 year "Senior" band. It's self-reported and not yet probed, so it stays at the intake ceiling of `medium` | `[grounded]` your background; `[generic]` the report's seniority norm | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" for 6 years is specific. Nothing inspectable has been seen yet | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project (about 180 models) on Snowflake, which is a cloud warehouse. That meets the requirement as written | `[grounded]` your background | none |
| R5 | BigQuery as the warehouse | important | adjacent | medium | transferability | The JD names BigQuery as the stack, but its requirement asks for "a cloud warehouse". Your dbt modelling, SQL and testing carry over. The limit is that you haven't used BigQuery itself | `[grounded]` JD wording, and your "Never used BigQuery"; `[generic]` what transfers between the two warehouses | see G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration" in your role. You didn't say whether you set it up or used it, so I've claimed use, not ownership | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, which is an ownership claim | `[grounded]` your background | none |
| R8 | Ingestion from our app and CRM | important | unclear | none | discovery | Your background doesn't say which sources you ingested from or what tooling you used | `[grounded]` your background is silent | see G2 |
| R9 | Data contracts our analysts depend on | important | unclear | none | discovery | Your GE suite and dbt project may hold relevant work. Contracts are a different thing from tests, so neither counts on its own | `[grounded]` your background is silent on contracts; `[inferred]` that the GE and dbt work is where evidence may sit | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5, important) | transferability | dbt, SQL and testing at depth on Snowflake; no BigQuery | This is the most visible mismatch between your stack and theirs | Any GCP exposure; cost or warehouse-sizing work on Snowflake; adapter-agnostic dbt macros. The limit: BigQuery's partitioning, clustering, slot or on-demand pricing and GCP IAM differ from Snowflake's warehouses | A small dbt project of yours running on the BigQuery sandbox (W1) | `[grounded]` your stated gap; `[generic]` the platform differences, and that this mismatch is the likeliest objection |
| G2 | Ingestion from app and CRM (R8, important) | discovery | Your background doesn't cover sources or how you ingested | It's a third of the stated mandate | Loading from a production app database; pulling a CRM or HR/payroll SaaS API into the warehouse; Fivetran, Airbyte, or custom Python extractors run by Airflow | A DAG, a design doc, a sanitized pipeline diagram | `[grounded]` JD mandate; your background is silent |
| G3 | Data contracts (R9, important) | discovery | GE suite and dbt project, with no mention of contracts | The JD names it as something analysts rely on | dbt model contracts or enforced schemas; agreed SLAs or schema-change rules with analysts or upstream teams; GE checks that block bad loads | A contract YAML, a schema-change runbook, an SLA doc | `[grounded]` JD wording; `[inferred]` where your evidence may sit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay published, and around the market median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The posted range covers the report's median and goes slightly past its 75th percentile, so the pay is market-normal for this seniority | `[grounded]` posted range; `[generic]` report band | Where in the range do you expect to place someone with 6 years? | noted |
| RR2 | End-to-end mandate with team size unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role could be one of several data engineers, or the only one running the whole reporting stack, including on-call | `[inferred]` from the JD's mandate and its silence on team and reporting line | How many data engineers are on the team, who would I report to, and how is on-call handled? | unresolved |
| RR3 | Posting not checked against the live site | risk_signal | low | "pellucidlearning.com/careers/senior-data-engineer" | The text came from the company's own domain and nothing else looks off. Low, not medium, for that reason. A posting can still be closed or out of date | `[generic]` how postings go stale, not a claim about this one | Is this role still open, and is the posted range current? | unresolved |
| RR4 | Equity mentioned but not described | unknown | — | "plus equity" | Type, size and vesting are unknown. At a later-stage private company, equity's value depends heavily on terms | `[generic]` equity pattern at later-stage private companies | What equity is offered for this role: type, number of shares or %, vesting, and the latest valuation? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with: "Built the company's dbt project on Snowflake (about 180 models); set up the Great Expectations test suite; Airflow for orchestration; Python and SQL daily." | Hits R4, R6, R7 and R3 in the JD's own order | `[grounded]` your own sentences, audited against them; no new facts | resume_edits_pending_approval |
| W1 | Port a handful of dbt models to the BigQuery sandbox, and be ready to describe what changed (partitioning, clustering, cost) | Narrows the limit in G1 and gives you an honest answer when BigQuery comes up | `[grounded]` R5; `[generic]` what the port exercises | pending your approval |
| P1 | Positioning: "dbt and data quality at depth on Snowflake; BigQuery is new to me, and here's what I've done to close it" | Presents R5 as adjacent, which condition 3 requires | `[grounded]` R4, R5, R7 rows | pending your approval |
| Q1 | Ask the RR1–RR4 verification questions as written | Settles scope, equity and whether the role is live | `[grounded]` register | pending your approval |
| A1 | Open the posting on Pellucid's own careers page yourself before applying | Clears RR3 | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A fetch of pellucidlearning.com/careers/senior-data-engineer was refused at the permission prompt. It would have cleared RR3 and confirmed the contradictions row in role reality |
| 2. Role-family sweep | skipped | The Datawright 2026 report you pasted already sets the market calibration line and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there's nothing to search for |

I can package all of this as a `tuesday-dossier.md` file that later steps (CV tailoring, interview prep) can pick up, if you'd like one.

**Upgrade menu**
- Your location, work authorization and pay floor → R1 settles, the "candidate constraints not given" flag drops off, and the decision can move to `go` or `no_go`.
- Answers to G2 and G3 → R8 and R9 move off `unclear`.
- A DAG, a contract or schema doc, or a sanitized GE suite (code in a repo is the proof this field keeps) → R4, R7 and R9 can rise to `high`.
- Allowing the careers-page fetch → RR3 closes.
- A hiring manager's name → the scope read, and which story E1 should lead with.
- A deeper research pass on Pellucid (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches) → feeds RR2 and RR4. Say the word and I'll run it.

**Questions**
1. R1: Are you US-based with US work authorization (or open to Denver)? Is there a pay floor or any other non-negotiable this role has to meet?
2. G2: What sources did you ingest from at the payroll company (app database, a CRM or SaaS API, files), and did you build those pipelines or inherit them?
3. G3: Have you ever set up something analysts or upstream teams relied on as a contract, such as dbt model contracts, enforced schemas, schema-change rules or SLAs? What was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.