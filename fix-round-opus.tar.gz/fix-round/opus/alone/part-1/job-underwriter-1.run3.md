I've read the evaluation framework. Next I'll check Harborlight Health and the market for this role on the web, then write up the assessment.
## Decision snapshot

**Yes, apply. You fit the core of this role: R1, R2, R3, R4 and R5 all match directly. Status: `conditional_go`, on the conditions below.**

**Fit ledger.**

- `must_have`: direct R1, R2, R3, R4, R5 · unclear R6 (Define and maintain the metrics layer)
- `important`: adjacent R8a (Partner with product managers on roadmap decisions), R8b (Partner with clinicians) · unclear R7 (Mentor two junior analysts)
- `preferred`: adjacent R9 (Healthcare data experience, HIPAA)

R6: the one must-have your background doesn't settle; R7: no evidence of mentoring yet; R9: privacy experience that carries over, but it isn't healthcare experience.

**Opportunity ledger.** The role is well defined: named tools, a named team and named stakeholders (RR5). What's unknown is whether the employer and posting are real and current (RR1), the pay (RR2), where you'd work (RR3), and what limits experiments face in a health product (RR6). One entry needs watching: you may be the only senior analyst carrying the whole function (RR4).

- **Hard gates:** none stated; you haven't given your constraints yet, so nothing has been checked against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight Health and this posting check out, see RR1; (2) you owned the metric definitions, not just the dashboards on top of them, see R6 and G1; (3) your GDPR/CCPA work is presented as related privacy experience, never as HIPAA or healthcare experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health company of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; not checked online (see RR1) |
| Mandate | Own product analytics: the metrics layer, A/B test design and analysis, self-serve Looker dashboards, turning analysis into roadmap decisions with PMs and clinicians | `[grounded]` JD |
| Team | Two junior analysts to mentor | `[grounded]` JD |
| Scope read | One senior owning the whole analytics stack while mentoring juniors is a function-lead scope at this title | `[inferred]` from the JD's list of responsibilities against the stated team |
| First-year outcomes | Not stated. Likely a trusted metrics layer and a working experimentation cadence | `[inferred]` from "define and maintain the metrics layer" and "design and analyze A/B tests"; nothing in the JD states a target |
| Working pattern | Not stated: no location, remote policy or schedule | `[grounded]` JD is silent |
| Market calibration | Not established. The searches were refused, so I have no market band for this title, and I won't estimate one from memory | — |
| Unknowns | Pay; location; whether experiments go through clinical review; who owns the metrics layer today | — |
| Contradictions | None inside the JD; it hasn't been checked against the company's careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | "6 years of product analytics at a consumer-subscription company" clears the bar. Medium because a background typed into chat is self-report with nothing to inspect yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" plus building the warehouse consent-state model. "Expert" will be tested live, not taken from a CV | `[grounded]` your background; `[generic]` that SQL depth is usually checked in a live exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | "Designed and ran the experimentation program: 30+ A/B tests a year", including "the pricing test behind an 11% retention lift", on about 2M subscribers | `[grounded]` your background | Have a test write-up you can talk through: hypothesis, power, guardrails, result |
| R4 | Looker or similar BI | must_have | direct | medium | none | "Built the company's Looker instance from scratch — 40+ governed dashboards." Exact tool match | `[grounded]` your background | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | "I write the monthly metrics memo the exec team reads." A sanitized excerpt would raise this to high | `[grounded]` your background | Prepare a sanitized memo excerpt (W1) |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests governed definitions but doesn't say you owned the metric definitions, the semantic model or the change process. Owning the dashboards isn't the same as owning the metric definitions they use | `[grounded]` your background says "governed", nothing more | G1 |
| R7 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring or managing anyone. At first pass that means "not yet asked", not "can't do it" | `[grounded]` background silent | G2 |
| R8a | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | discovery | You present monthly to the VP Product and ran the pricing test behind a retention lift, but you haven't said which roadmap decision your analysis changed | `[grounded]` your background | G5 |
| R8b | Partner with clinicians | important | adjacent | medium | transferability | You carry over writing for non-technical execs. What you lack is work with clinical domain experts, whose questions about evidence and safety differ from commercial ones | `[grounded]` your background; `[generic]` that clinical stakeholders weigh evidence differently from commercial ones | G3 |
| R9 | Healthcare data experience, HIPAA | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model you built carry over. What you haven't done: PHI handling, business associate agreements (BAAs), HIPAA de-identification standards | `[grounded]` your background; `[generic]` HIPAA-specific obligations named in the limit | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | discovery | You built a Looker instance with 40+ governed dashboards. It isn't stated who defined the metrics or kept them consistent | It's the one must-have below direct. Resolving it removes condition 2 | Writing the LookML model or explores others built on; settling disputed definitions such as "active subscriber" or "churn"; a metric dictionary or certification process; the consent-state model as a governed dimension | A sanitized LookML excerpt, a metric dictionary page, a definitions doc | `[grounded]` background wording; `[inferred]` that it removes condition 2 |
| G2 | Mentoring (R7, important) | discovery | Nothing either way | The JD names two juniors to mentor; this is likely where "senior" gets tested | Onboarding a new analyst; reviewing others' SQL or test designs; running a Looker or experimentation training; an intern you supervised | A training deck, a review checklist, a peer reference | `[grounded]` JD names two juniors; `[inferred]` that this is the seniority test |
| G3 | Clinician partnership (R8b, important) | transferability | You work with non-technical execs; no clinical or domain-expert partners | It's the stakeholder you've least worked with. A strong example from your work with non-analytics experts would narrow the gap | Working with food-safety, nutrition or operations experts on a metric or a test; turning an expert's concern into a guardrail metric | A test plan with a guardrail metric agreed with a non-analyst owner | `[grounded]` background; `[generic]` that domain-expert partnership is the transferable part |
| G4 | HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | It's only preferred, but it's the most visible domain gap | Access controls, PII masking, retention rules or deletion requests you implemented | A sanitized design note on the consent-state model | `[grounded]` background |
| G5 | Roadmap impact (R8a, important) | discovery | Monthly VP Product presentations; the pricing test | "Turn analysis into roadmap decisions" is exactly what the stated outcomes don't yet show | A feature shipped, killed or reprioritised because of your analysis; the pricing change itself if it was rolled out | The memo or deck that preceded the decision | `[grounded]` background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Here it simply couldn't be checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | none; the JD is silent | The figure may sit below what a senior lead scope commands, or the company may just not publish salaries | `[inferred]` from the posting's silence | What salary range and equity are budgeted for this role? | unresolved |
| RR3 | Location and remote policy not stated | unknown | — | none; the JD is silent | Could be office-based, hybrid or remote | `[grounded]` JD is silent | Where is this role based, and how many days a week in an office, if any? | unresolved |
| RR4 | One senior owning the whole analytics stack plus mentoring | risk_signal | low | "Own product analytics… define and maintain the metrics layer… mentor two junior analysts" | You may be the only senior analyst, carrying both the platform work and the team | `[inferred]` from the JD's list of responsibilities against a team of two juniors | Who else owns data infrastructure or analytics engineering, and who does this role report to? | unresolved |
| RR5 | Concrete, well-defined scope | positive_signal | — | "build self-serve dashboards in Looker… mentor two junior analysts" | The tools, team size and stakeholders are named, so the role is real enough to evaluate | `[grounded]` JD | What would a strong first six months look like? | noted |
| RR6 | Experiment limits in a health product | unknown | — | "experiment design at scale" | Tests touching care pathways may need clinical or ethics review, and traffic may be far below 2M subscribers | `[generic]` common pattern in health products, not a claim about this one | How many tests a quarter does the app run today, and what review do experiments touching care recommendations go through? | unresolved |

## Application plan

Everything below is a proposal: the CV lines and the advice alike are **pending your approval**.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before applying, confirm the role is on Harborlight's own careers page or comes from a recruiter at their domain | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with experimentation, in your own words: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Keep "behind"; don't upgrade it to "drove" | R3 | `[grounded]` your sentence, unchanged | resume_edits_pending_approval |
| E2 | "Built the company's Looker instance from scratch — 40+ governed dashboards." Add a metrics-layer clause only once G1 confirms it | R4, R6 | `[grounded]` your sentence | resume_edits_pending_approval |
| E3 | "Handled GDPR/CCPA consumer PII; built the consent-state model for our warehouse." Present it as privacy-regulated data work, never as HIPAA or healthcare experience | R9 | `[grounded]` your sentence | resume_edits_pending_approval |
| W1 | A sanitized one-page excerpt of a monthly metrics memo as a work sample | R5 | `[grounded]` R5 | pending your approval |
| Q1 | Ask the verification questions for RR2, RR3, RR4 and RR6 word for word in early calls | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers"; the call was refused because web search isn't permitted in this session. It would have settled RR1 and the organization and contradictions rows |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary 2026"; refused, same reason. It would have set the market calibration line and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can write all of this into a reusable `tuesday-dossier.md` file if you'd like.

## Upgrade menu

- **Allow web search (or paste the careers-page link):** settles RR1 and adds a market pay band. If RR1 checks out, condition 1 drops.
- **Your constraints** (pay floor, location, visa or work authorization): the hard-gates line can then actually check them.
- **An answer to G1:** R6 moves to direct or stays a gap, and condition 2 resolves either way.
- **A sanitized memo excerpt or LookML snippet:** R5 and R6 can rise to high.
- **The hiring manager's name:** sharpens the scope read and tells you which story to lead with.
- **A deeper research pass** (funding and leadership changes, employee reviews, recent news; up to 5 more searches and 2 more fetches): say the word and it runs, once search is allowed.

## Questions

**G1:** In the Looker build, did you define the metrics themselves (the model, definitions such as churn or active subscriber, how changes were approved), or did you build dashboards on definitions someone else owned?

**G2:** Have you onboarded, reviewed the work of, or trained other analysts, even informally?

**Constraints:** What's your pay floor, and do you have a location or remote requirement, or need visa sponsorship?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.