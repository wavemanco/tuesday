Checking the live posting now — the careers page appears to contradict the "fully remote" line in what you pasted.
**Yes, apply, with one thing to settle first. The live posting says "Leeds office four days a week", but your copy says "Fully remote (UK)" (R10, RR1). Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R10 (Working pattern: fully remote vs Leeds four days a week)
- `must_have`: direct: R1, R2, R3, R4, R5a, R6 · unclear: R5b (Designing price tests)
- `important`: adjacent: R8 (Pet-insurance pricing) · unclear: R7 (Recommendations to product)
- `preferred`: direct: R9

R5b: you ran the tests, but whether you designed them isn't confirmed yet; R8 (`medium`): a credible bridge from motor, with its limit named; R10: could stop this outright, depending on where you live and how you want to work.

**Opportunity ledger.** The employer is real and the posting is live (RR3). Your copy and the employer's page disagree on the working pattern (RR1). The salary isn't stated (RR2), and the size of the pricing team isn't stated either (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (Fully remote (UK) vs Leeds office four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor confirms the working pattern, and it works for you (R10, RR1); (2) the salary on offer meets your floor (RR2); (3) pet insurance is described as a new domain with a real modelling bridge, never as pet-pricing experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page; JD names her |
| Scope read | A senior individual-contributor post. No line management is mentioned anywhere, so "never managed anyone" matches no requirement | `[inferred]` from the JD's and careers page's silence on reports |
| Hiring manager's footprint | Director of Pricing at Brindlemoor. Spoke at the 2025 Insurance Pricing Forum: "Small Books, Loud Errors", on monitoring rating models in small books. Previously six years as head of pricing analytics at Calloway Re | `[grounded]` professional-profile search result, snippet only, not fetched |
| Market calibration | UK senior pricing analyst at insurers and insurtechs: median base £58,400, middle half £52,100–£64,900. This is a market band, not Brindlemoor's offer (RR2). The title and remit look normal for that band | `[generic]` Pricewell 2026 UK pay survey (n=612); `[grounded]` the JD states no salary |
| Unknowns | Salary; pricing team size; how much the role decides versus recommends; whether product recommendations go to a named owner | — |
| Contradictions | Working pattern: your copy says "Fully remote (UK)", the live careers page says "Leeds office four days a week" | `[grounded]` JD as you pasted it vs the careers page fetched today |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific, but stated at intake with nothing to inspect yet, so `medium` | `[grounded]` your message | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily." Expect a technical exercise or probe | `[grounded]` your message; `[generic]` that pricing loops usually test this hands-on | none |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your message | none |
| R4 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building it. Monitoring is what "maintained" most likely involved, but you didn't say it, so describe it in your own words when asked | `[grounded]` your message; `[inferred]` that maintaining included monitoring | Describe how you monitored the model, in your own words, before leading with it (P1) |
| R5a | Run and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your message | none |
| R5b | Design price tests | must_have | unclear | low | discovery | "Ran" doesn't settle whether you set the test design (cells, sample size, success metric) or carried out a design someone else set | `[grounded]` your wording; the gap is what it leaves open | G1 |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R7 | Turning results into recommendations for product | important | unclear | low | discovery | Underwriting is covered (R6). Nothing yet on recommendations to a product team | `[grounded]` your message is silent on product | G2 |
| R8 | Pet-insurance pricing (implied by the product) | important | adjacent | medium | transferability | GLM rating and price testing carry over directly. Limit: no exposure to pet rating factors or pet claims patterns | `[inferred]` requirement, from the product named in the JD; `[generic]` that pet pricing uses different rating factors (species, breed, age) and claims drivers from motor | G3 |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your message | none |
| R10 | Working pattern: "Fully remote (UK)" vs "Leeds office four days a week" | hard_gate | unclear | none | hard_gate | Two sources disagree on the term, and you haven't said where you are or what you'd accept. Confidence is `none` because no constraint has been stated yet, not because of the role | `[grounded]` your pasted JD vs the careers page; your message is silent | RR1's question to Brindlemoor; the R10 question below to you |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R5b, must_have) | discovery | 14 tests run with underwriting; who designed them is open | The JD says "design and read". Design ownership is the difference between running the test programme and being the one who sets it up | Choosing test and control cells; setting sample size or test duration; picking the KPI (conversion, loss ratio, retention); stopping or extending a test early | A sanitized test plan or a readout slide | `[grounded]` your wording; `[inferred]` that the JD weights design |
| G2 | Recommendations to product (R7, important) | discovery | Underwriting audience confirmed; product not mentioned | The JD names product as a second audience | A pricing finding that changed cover options, excess levels, discounts, or a quote-journey change | A recommendation memo or a review deck excerpt | `[grounded]` your message's silence |
| G3 | Pet-insurance pricing (R8, important) | transferability | A motor GLM and motor price testing; nothing pet-related | This is the gap an interviewer is most likely to raise | Modelling a thin-data or volatile segment; frequency/severity work; claims-inflation adjustments; any home or other non-motor exposure | A model monitoring note or a segment write-up, sanitized | `[inferred]` bridge from your GLM work; `[generic]` that domain change is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (see R10) | risk_signal | medium | Your copy: "Fully remote (UK)"; careers page: "Leeds office four days a week" | Your copy may come from an aggregator or an older version, or the terms may have changed since. One of the two is wrong | `[grounded]` both quotes; `[inferred]` the explanations | Is this role fully remote, or based in Leeds four days a week, and is that negotiable? | unresolved |
| RR2 | Salary not stated | unknown | — | (no figure in the JD or on the careers page) | The figure may sit anywhere in or outside the band in role reality | `[inferred]` from the silence, against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Employer and posting verified live | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | The role is real and current, and the named hiring manager matches the employer | `[grounded]` careers page fetched; profile search result | Who else would I be interviewing with? | noted |
| RR4 | "Own pricing analytics" with no team size stated | unknown | — | "Own pricing analytics for our pet-insurance product" | You could be the main or sole pricing analyst on the product | `[inferred]` from "own" against the silence on team | How large is the pricing team, and who else works on the pet rating model? | unresolved |

## Application plan

Every row below is a proposal, pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with Brindlemoor before investing in an application | RR1, R10 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the young-driver GLM you built and maintained, with monitoring at the front. Don't call that book "small" unless it was | R3, R4. Odile Varga's public talk was on monitoring rating models in small books | `[grounded]` your message; profile search result | pending your approval |
| P2 | Present pet insurance as a new domain: "the GLM and price-testing method transfers; pet rating factors would be new to me" | R8. An honest limit holds up better under questioning than a stretched claim | `[grounded]` R8 row | pending your approval |
| P3 | Say "ran 14 price tests with underwriting", not "designed", until G1 confirms it | R5b | `[grounded]` your wording | pending your approval |
| Q1 | Ask RR1, RR2 and RR4's verification questions verbatim if you get to interview | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Confirmed the employer and the live posting (RR3), and found the working-pattern contradiction (R10, RR1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary 2026 remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Set the market calibration band |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. Fed the scope read and P1 |

---

Whenever you want it, I can put all of this into a `tuesday-dossier.md` file you can keep.

**Upgrade menu**
- Your location and the working pattern you'd accept → R10 becomes met or failed, and the decision likely becomes `go` or `no_go`.
- Your salary floor → RR2 can be checked against the band once Brindlemoor gives a figure.
- Your CV → I can check whether it already shows R4, R5a and R6 well, and propose truthful edits.
- A sanitized test plan, model monitoring note or review deck → R4, R5b or R6 move toward `high`.
- A deeper research pass on Brindlemoor (funding, leadership churn, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R10: Where are you based, and would Leeds four days a week work for you, or is fully remote a must?

G1: For the 14 price tests, did you set the design (cells, sample size, success metric), or did someone else design them while you ran and read them?

G3: Has any of your motor work involved thin-data segments, frequency/severity modelling, claims-inflation adjustments, or any non-motor line?

For each, you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.