The page fetch was declined, so I'm finishing the assessment from what you pasted.

## Decision snapshot

**Yes, probably worth applying, if the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote within the US, or the Denver office)
- `must_have`: direct: R2, R3, R4, R6, R7
- `important`: adjacent: R5 (BigQuery as the warehouse) · unclear: R8 (Ingestion from app and CRM), R9 (Data contracts analysts depend on)

R5 (`medium`): a Snowflake-to-BigQuery bridge, with its limit stated; R8, R9: duties your background doesn't mention yet, not gaps found.

**Opportunity ledger.** The role looks sound and pays well. Pay is stated and sits at or above the market band (RR2), and the company is freshly funded (RR6). Several things are unknown: whether the posting is still live, since my check couldn't run (RR1); what the equity is (RR3); how big the team is and what on-call looks like (RR4); and who you'd report to (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote within the US, or the Denver office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed, meaning you're US-based or can work from Denver; (2) the posting confirmed live on Pellucid's careers page (RR1); (3) BigQuery presented honestly as adjacent experience, never as experience you have (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring for schools in 31 US states; founded 2016 in Denver; 264 employees; Series C of $52M in February 2026 | `[grounded]` about page as you pasted it; not independently checked (RR1) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years of data engineering; strong SQL and Python; dbt plus a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; remote (US) or the Denver office | `[grounded]` JD |
| Scope read | Covers the whole reporting chain from source ingestion to analyst-facing contracts. The JD mentions no direct reports | `[inferred]` from the JD's mandate sentence |
| Market calibration | "Senior" at Series B–D companies usually means 5–8 years and owning one domain's pipelines with no reports. Pay: median $151,000, interquartile range $139,000–$163,500. The posting's floor is $3k below the median, its midpoint ($157k) is $6k above it, and its top is $2.5k above the 75th percentile. This is the market band, not Pellucid's offer to you | `[generic]` Datawright 2026 Data Engineering Pay Report (US, n=2,310), as pasted; `[grounded]` JD for the posted range |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Team size and who else is on data; on-call for "run"; equity form and amount; hiring manager | none |
| Contradictions | None in the pasted material; I couldn't compare it with the live page (RR1) | `[grounded]` pasted JD and about page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote within the US, or the Denver office | hard_gate | unclear | none | hard_gate | The JD limits where you can work. You didn't say where you're based, so this gate is unsettled | `[grounded]` JD "Remote (US) or our Denver office"; your background silent | Closing question R1 |
| R2 | 5+ years of data engineering | must_have | direct | medium | none | 6 years, stated specifically. Your own unprobed account, so it's capped at `medium`. It also falls inside the report's 5–8 year norm for Senior | `[grounded]` your background; `[generic]` Datawright seniority norm | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" for 6 years. Nothing to inspect yet; expect a technical screen | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. The JD asks for "a cloud warehouse", and Snowflake is one | `[grounded]` your background; JD wording | none |
| R5 | BigQuery as the warehouse | important | adjacent | medium | transferability | Inferred from "a dbt-modelled warehouse in BigQuery"; the stated requirement is any cloud warehouse, so this is `important`, not `must_have`. What carries over: dbt modelling and warehouse SQL. The limit: you've never used BigQuery. You haven't worked with its partitioning and clustering, its slot/on-demand cost model, or GCP permissions | `[grounded]` your "Never used BigQuery"; `[generic]` that those are where BigQuery differs from Snowflake | Application plan A2 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated, matching the JD's named tool | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite": specific and yours | `[grounded]` your background | none |
| R8 | Ingestion from the app and a CRM | important | unclear | low | discovery | Your background covers the dbt and orchestration layers but doesn't say who built source ingestion. `low`, not `none`, because a 180-model project means sources were being loaded somehow, though not necessarily by you | `[grounded]` your background is silent on ingestion; `[inferred]` from the size of the dbt project | Gap queue G1 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Your background doesn't say who consumed your models or whether interfaces, tests or SLAs were agreed with them. A Great Expectations suite is close to this, but it isn't contract ownership | `[grounded]` your background is silent on consumers; `[inferred]` that the GE suite is related | Gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R8, important) | discovery | dbt, Airflow and GE are stated; nothing about where the data came from or who loaded it | Ingestion is the first item in the JD's mandate, so a real story here strengthens the application more than anything else | Airflow DAGs that pulled from a production Postgres/MySQL replica; setting up or maintaining Fivetran, Airbyte or Stitch connectors; Python extraction from a Salesforce, HubSpot or other SaaS API; handling schema drift or backfills at the source | A DAG or connector config (sanitized), a design doc, a runbook | `[grounded]` your background is silent; `[inferred]` from the JD listing it first |
| G2 | Data contracts (R9, important) | discovery | A GE suite exists; who relied on it, and what was promised to them, isn't stated | The JD names contracts "our analysts depend on", so this is the part of the job that faces other people | Agreeing column definitions or freshness SLAs with analysts or finance; dbt model contracts, `schema.yml` tests, or exposures; blocking a breaking upstream change; alerting consumers when a GE check failed | A schema.yml excerpt, a contract or SLA doc, an incident write-up | `[grounded]` your background is silent on consumers; `[grounded]` JD wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting and company facts not independently checked | unknown | — | "pellucidlearning.com/careers/senior-data-engineer" | The posting is probably genuine, since it came from the company's own domain, but it may have closed or changed since you copied it | `[inferred]` from the source URL you gave, against my refused fetch | Is the Senior Data Engineer role on your careers page still open, and is the posted range current? | unresolved |
| RR2 | Pay stated, and at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Publishing pay and setting the midpoint above the market median suggests they're competing for candidates, not underpaying | `[grounded]` JD figure; `[generic]` Datawright band | Where in the $148k–$166k range do candidates with 5–8 years usually land? | noted |
| RR3 | Equity not described | unknown | — | "plus equity" | After a Series C it's probably options or RSUs, but the amount and terms could mean a lot or very little | `[generic]` pattern for late-stage startups | What form is the equity, how many units, what is the vesting schedule, and what was the last valuation or strike price? | unresolved |
| RR4 | Full-chain mandate with no team or on-call described | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be one of very few data engineers, which would make it broader than the one-domain norm and put "run" on your pager | `[inferred]` from the mandate against the JD's silence on team; `[generic]` report's scope norm | How many data engineers are there today, and what does the on-call rotation look like? | unresolved |
| RR5 | No hiring manager named | unknown | — | (posting names none) | It's unclear whether the role reports to a data lead, an analytics head or engineering | `[grounded]` posting silent | Who would this role report to, and what does that person own? | unresolved |
| RR6 | Series C closed in February 2026 | positive_signal | — | "Series C ($52M, February 2026)" | Recent funding suggests near-term runway for the hire | `[grounded]` about page as pasted; not independently checked | How is the data team's headcount planned over the next year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with three things in your own words: "built our dbt project on Snowflake — about 180 models", Airflow orchestration, and "set up our Great Expectations test suite" | These map to R4, R6 and R7, which are the core of the JD | `[grounded]` your background | pending your approval |
| A2 | Name the BigQuery gap yourself ("my warehouse work is on Snowflake; I haven't used BigQuery yet"). Optionally, port a few dbt models to BigQuery's free sandbox with the dbt-bigquery adapter before interviews | R5. A small project turns the limit into something you can show | `[grounded]` your background; `[generic]` that a sandbox port is a cheap way to close the gap | pending your approval |
| A3 | Don't describe your GE work as "data contracts" unless G2 confirms you had agreements with consumers | R9. The JD uses that term; your history may not | `[grounded]` R9 row | pending your approval |
| A4 | Confirm R1 and RR1 before spending time on a cover letter | Both are cheap to check and decide whether to bother | `[grounded]` R1, RR1 | pending your approval |
| A5 | Ask the RR1–RR6 questions in the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Every row in the plan is a proposal. Nothing goes into a CV, cover letter or message until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One fetch of pellucidlearning.com/careers/senior-data-engineer was refused. It would have confirmed the posting is live and matches your copy, closing RR1 and the contradictions row |
| 2. Role-family sweep | skipped | The Datawright 2026 report you pasted already gives the market calibration row, R2's seniority norm and RR2's comparison |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was nothing to search for |

I can save all of this as a `tuesday-dossier.md` file whenever you'd like a copy to keep.

## Upgrade menu

- **Your CV:** turns A1 into specific resume edits and may answer G1 or G2 directly.
- **Your location:** settles R1, the only gate.
- **Your current pay or salary floor:** adds a pay row to the map. Only matters if your floor is above $148k.
- **Permission to fetch the careers page:** closes RR1 in one call.
- **Equity details from the recruiter:** closes RR3.
- **A hiring manager's name:** sharpens the scope read and which story A1 leads with.
- **A deeper research pass on Pellucid** (leadership churn, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions.** Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. R1: Are you based in the US, or able to work from Denver?
2. G1: Did you build or maintain any ingestion yourself, such as pulls from an app database, a CRM or SaaS API, or Fivetran/Airbyte connectors? What was yours, and what did it feed?
3. G2: Who relied on your dbt models and GE checks, and did you ever agree definitions, freshness or breaking-change rules with them?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.