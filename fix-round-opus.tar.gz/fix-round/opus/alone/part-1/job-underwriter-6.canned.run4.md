I'm reading the skill's reference rules for the fit and risk analysis. Next I'll fetch the posting.
**Yes, go for it, on the conditions below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week)
- `must_have`: direct: R2, R4, R5, R9 · adjacent: R7 (Own our CRM data), R10 (Experience owning a forecast) · unclear: R3 (at a B2B software company), R6 (spreadsheet modelling), R11 (working with finance on billing or revenue data) · absent: R8 (Own our billing data)

R10: your strongest bridge, and G1 decides how strong it is; R8: a real gap to name openly, not hide; R11: open, and G2 settles it.

**Opportunity ledger.** The employer and hiring manager are as described (RR1), and the salary sits inside the market band (RR3). Against that, the role spans revenue ops and billing-data ownership (RR4), I couldn't find the posting on Quillfield's own site (RR2), and the share options aren't specified (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) two days a week in Bristol works for you (R1); (2) you present the forecast as adjacent experience, "I run the monthly pipeline review", never as forecast ownership (R10); (3) you name the billing-data gap yourself rather than let it be found (R8); (4) the role is confirmed open (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 employees; £11M Series A in April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` JD |
| Working pattern | Bristol, hybrid: two days a week in the office | `[grounded]` JD |
| Compensation | £61,500–£67,000 plus share options | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations; previously sales operations manager at Corvane Payments for four years | `[grounded]` recruiter (name); public profile snippet (title, history) |
| Scope read | A "Lead" under a Head of RevOps, with a CFO-facing forecast and ownership of billing data. That reaches further into finance than a sales-ops role usually does | `[inferred]` from the mandate's finance-facing clauses set against the title |
| Market calibration | UK B2B software revenue operations leads: median base £64,200, interquartile range £57,800–£70,400 (n=438). The posted range sits inside that band, near the middle. The survey is UK-wide, not Bristol-specific | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` JD for the posted figure |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Team size and whether the role manages anyone; billing system and who configures it today; option terms; success measures | — |
| Contradictions | None between the JD and the About page. Quillfield's careers page returned no page, so the posting is only confirmed on the aggregator (RR2) | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether two Bristol days work, so the gate isn't settled either way | `[grounded]` JD terms; your message is silent on location | Closing question R1 |
| R2 | 4+ years in revenue operations or sales operations | must_have | direct | medium | none | 5 years in sales operations, the last 2 running RevOps for the UK team. Stated and specific, but not yet probed | `[grounded]` your message | none |
| R3 | …at a B2B software company | must_have | unclear | low | discovery | "B2B payments company" may or may not be a software-product company; the JD names software specifically | `[grounded]` your wording; `[inferred]` that the distinction could matter on a literal screen | G4 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, and you rebuilt the pipeline and renewal dashboards. The certificate is inspectable but hasn't been inspected | `[grounded]` your message | Optional: certification verification link raises this to high |
| R5 | Strong SQL | must_have | direct | medium | none | "SQL weekly" is stated. How deep it goes isn't established, so expect a probe | `[grounded]` your message | none |
| R6 | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" could mean reporting or modelling, and the JD asks for modelling | `[grounded]` your wording | G5 |
| R7 | Own our CRM data | must_have | adjacent | medium | transferability | You run RevOps for the UK team with an admin certification. Limit: it isn't stated whether you are the admin of record or own company-wide CRM data, versus the UK team's slice | `[grounded]` your message; `[inferred]` the scope limit from "for the UK team" | G6 |
| R8 | Own our billing data | must_have | absent | none | capability | You said you've never worked on billing data. This is a stated fact, not a discovery gap | `[grounded]` your message | Closure path in G3 |
| R9 | Build pipeline and renewal reporting sales and finance run on | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards, which is the same artefact. The finance audience is covered under R11 | `[grounded]` your message | Optional: a sanitized dashboard screenshot raises this to high |
| R10 | Experience owning a forecast; run the quarterly forecast with the CFO | must_have | adjacent | medium | discovery | You run the monthly pipeline review with the sales director, and pipeline review is an input to a forecast. Limit: finance owned the company forecast and you've had no CFO-facing ownership. Whether you produced a UK team number is still open | `[grounded]` your message; `[generic]` that pipeline review feeds forecasting | G1 |
| R11 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | The JD says billing *or* revenue data. Renewal dashboards and a finance-owned forecast suggest some touchpoint, but none is stated | `[grounded]` your message; `[inferred]` the touchpoint from the renewal and forecast context | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R10, must_have) | discovery | You run the monthly pipeline review. It's unknown whether you call or submit a number | The core of the role's CFO-facing mandate; it decides whether R10 is adjacent or direct | Calling a UK commit or best-case number each month; building the roll-up finance uses; tracking forecast accuracy against actuals; reconciling pipeline to finance's forecast | A sanitized forecast roll-up, a pipeline-review deck, a forecast-vs-actual sheet | `[grounded]` your message; `[inferred]` that it moves R10 |
| G2 | Finance on revenue data (R11, must_have) | discovery | Renewal dashboards exist; no finance collaboration is stated | The "or" means revenue data alone satisfies the requirement, so this row is recoverable | Reconciling CRM bookings to finance's figures; renewal or ARR numbers finance consumed; supplying pipeline data to finance's forecast | A reconciliation sheet, a renewal report finance used | `[grounded]` JD's "or"; `[inferred]` recoverability |
| G3 | Billing data (R8, must_have) | capability | You've stated none | A gap on a must-have that interviews will reach | Closure path: learn how invoicing-to-CRM data flows (invoice, payment and renewal objects); a small worked sample on dummy data | A short note or model showing the CRM-to-billing reconciliation you'd build | `[grounded]` your statement; `[generic]` closure path |
| G4 | B2B software company (R3, must_have) | discovery | "B2B payments company" | Determines whether the experience line matches literally | Your employer sells a software platform or API, or is SaaS-priced | The company's own product description | `[inferred]` from the wording gap |
| G5 | Spreadsheet modelling (R6, must_have) | discovery | "Excel daily" | Separates reporting from modelling | Capacity, quota or territory models; renewal or churn models; scenario planning | A sanitized model | `[grounded]` your wording |
| G6 | CRM ownership (R7, must_have) | transferability | UK team scope | Company-wide ownership is the ask | Being the Salesforce admin of record; owning field and object design or data hygiene beyond the UK team | Change log, design doc | `[inferred]` scope limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and hiring manager established | positive_signal | — | "Quillfield, Bristol" | The company exists as described, and the recruiter's named manager holds the matching title | `[grounded]` About page and the hiring manager's public profile | Does this role report directly to Tamsin Achebe? | noted |
| RR2 | Posting not found on Quillfield's own site | unknown | — | Tallyboard listing; quillfield.co.uk/careers returned no page | The posting may be aggregator-only, or the careers page may sit at another path | `[grounded]` fetch result; `[generic]` that aggregator-only listings are common | Is this role still open, and are you hiring for it directly? | unresolved |
| RR3 | Salary stated and within band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is transparent and market-normal | `[grounded]` JD; `[generic]` Ledgerline band | Where in the range would someone with my profile land? | noted |
| RR4 | Scope spans RevOps and billing-data ownership | risk_signal | low | "own our CRM and billing data… run the quarterly revenue forecast with the CFO" | The role may carry finance-systems work without finance-systems support. Rated low because it is still one coherent function | `[inferred]` from the mandate's breadth set against its silence on team | Who configures the billing system today, and does this role have analyst or finance-systems support? | unresolved |
| RR5 | Share options unspecified | unknown | — | "plus share options" | Grant size and vesting are unknown | `[grounded]` JD | What's the option grant, vesting schedule and strike basis? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm two Bristol office days work before applying | R1 | `[grounded]` JD terms | pending your approval |
| E1 | CV line, in your words: "Rebuilt the pipeline and renewal dashboards" plus "Run the monthly pipeline review with the sales director", with no added metrics | R9, R10 | `[grounded]` your message | resume_edits_pending_approval |
| E2 | Never write "owned the forecast" or "billing data experience". Both contradict what you told me | R8, R10 | `[grounded]` your statements | pending your approval |
| A2 | In the cover note, name billing data as the area you'd be learning, and pair it with G3's closure plan | R8 | `[grounded]` R8 | pending your approval |
| A3 | With the hiring manager, lead with the payments-company RevOps work; her own background is also payments sales ops | R2, R9 | `[grounded]` her public profile; `[inferred]` shared domain context | pending your approval |
| W1 | Optional one-page sample: a forecast built from pipeline data, reconciled to a dummy billing extract | R6, R8, R10 | `[inferred]` from the rows it targets | pending your approval |
| Q1 | Ask the verification questions for RR1–RR5 word for word | Register | `[grounded]` register | pending your approval |

The positioning advice in A2 and A3 is pending your approval too, not just the CV table.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page, so the posting isn't established on the company's own site. Moved the Organization and Contradictions rows, RR1 and RR2 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved Market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the Hiring manager row, A3 and RR1 |

I can save all of this as a `tuesday-dossier.md` file you can keep and bring back later, if that's useful.

## Upgrade menu

- Your location, or a yes or no on two Bristol days → R1 is settled, and the status becomes `go`-eligible or `no_go`.
- An answer to G1 → R10 moves to direct, or its limit is confirmed.
- An answer to G2 → R11 resolves.
- Your Salesforce certification link or a sanitized dashboard screenshot → R4 or R9 moves to `high`.
- Quillfield's own listing for this role, or the recruiter's email domain → RR2 closes.
- A deeper research pass on Quillfield: leadership changes, hiring patterns, employee reports and recent news, using up to 5 more searches and 2 more fetches. Say the word and it runs.

## Questions

R1: Can you work from Quillfield's Bristol office two days a week?

G1: In your monthly pipeline review, do you produce or call a number, such as a UK commit or forecast, and where does it go? What part was yours and what part was finance's?

G2: Have you worked with finance on revenue data, for example reconciling CRM bookings or renewals to their figures, or supplying pipeline data into their forecast?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.