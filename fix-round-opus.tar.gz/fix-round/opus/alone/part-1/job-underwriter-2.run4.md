Quick update: I've loaded the evaluation framework and am now checking whether Quartzline exists as described and what this role usually looks like in the market, before I write up the assessment.
**No, you aren't wasting your time. One must-have, R1b (3+ years as a PM), is a requirement you can't meet, and no rewording changes that. The rest of your background is a real bridge to this role. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (product-shaped work toward "3+ years product management"), R2 (shipped API or platform products) · unclear: R4b (stakeholder management with sales), R5 (experience with agile delivery) · absent: R1b (3+ years titled product management)
- `important`: adjacent: R6 (own the roadmap), R7 (run discovery with integration partners), R8 (write specs and drive delivery with two squads), R10 (coordinate launches with sales and support) · unclear: R9 (define and track adoption metrics)

R1b: you don't have the titled years, so the risk is getting past the screen, not whether you can do the job. R2, R6, R7, R8, R10: real bridges, each with a limit you should state. R4b, R5, R9: each could move with one answer from you.

**Opportunity ledger.** I couldn't confirm the employer, because both research calls were refused (RR1). Pay and work arrangement aren't stated (RR2, RR3), and the reporting line is unknown (RR5). One entry runs the other way: the resources are named, with two engineering squads, and adoption metrics are in scope (RR4).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline exists as described and the posting is live (RR1). (2) R5 and R4b come back at `adjacent` or better. (3) You deal with R1b by reaching a person, through a referral or the hiring manager, and you say plainly that you've never held a PM title. (4) Pay and location suit you (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, about 150 people, Series B. Not verified (RR1) | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs; drive delivery; define and track adoption metrics; coordinate launches | `[grounded]` JD |
| Resources | Two engineering squads | `[grounded]` JD |
| Scope read | "Own the roadmap" points to one accountable PM for the platform, not a contributor to someone else's roadmap | `[inferred]` from the JD's word "own" and the single-owner phrasing |
| First 90 days / first year | Not stated. Defining adoption metrics is likely early work, because the JD names it as a responsibility and gives no baseline | `[inferred]` from the JD listing "define and track adoption metrics" with no current figures |
| Market calibration | Not available: the role-family sweep couldn't run, and I'm not quoting a pay band from memory. In general, API and platform PM roles are a common move for people coming from solutions engineering or implementation | `[generic]` role-family pattern, not a claim about Quartzline |
| Unknowns | Pay; location and remote policy; reporting line; whether this PM role is new or a backfill; API maturity and number of partners | — |
| Contradictions | None inside the JD. Not checked against a careers page (RR1) | `[grounded]` JD text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience: the product-shaped work | must_have | adjacent | medium | transferability | 7 years of requirements documents, scoping workshops, coordinating engineers and PMs on custom builds, and running roadmap-input sessions. Limit: product decisions and prioritization sat with the PMs you fed, not with you | `[grounded]` your stated background | Bridge in the application plan (A1) |
| R1b | 3+ years PM experience: the titled years | must_have | absent | none | capability | You say you've never held a PM title. That's a fact about the title. The work you've done is covered in R1a. Keyword and years-of-experience screens often apply a "must-have" literally | `[grounded]` your statement; `[generic]` the screening pattern | Closure path: reach a person through a referral or the hiring manager (P1). Never describe the work as PM-titled |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ end-to-end integrations of your company's REST APIs. Limit: you worked on the integrator side of the API. Nothing yet shows you owned the API product itself: versioning, deprecation, partner onboarding at scale | `[grounded]` your stated background | G4. A work sample (W1) narrows the limit |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs, and integration architecture across 30+ builds. Specific and on point; nothing inspectable yet | `[grounded]` your stated background | An interviewer may probe it live; no action needed |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your own engineers, the client's engineers, and product managers on custom builds | `[grounded]` your stated background | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Your background doesn't mention sales. Solutions engineers often work alongside sales, but that's a pattern, not evidence about you | `[grounded]` your background is silent on this; `[generic]` the role pattern | G2 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | UAT and go-live are named. Sprints, backlogs or squad rituals are not | `[grounded]` your background is silent on agile | G1 |
| R6 | Own the roadmap | important | adjacent | medium | transferability | You ran quarterly roadmap-input sessions. That's feeding a roadmap, not owning it, and that difference is the limit | `[grounded]` your stated background | Name the limit in A1 |
| R7 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops plus quarterly sessions collecting client feedback. Limit: the workshops scoped individual builds, which is different from deciding what to build for all partners | `[grounded]` your stated background | Describe it accurately in E1; don't call it "product discovery" |
| R8 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents, plus an integration playbook the whole team uses. Limit: those were client-specific requirements and an internal process document, not product specs that run a squad's backlog | `[grounded]` your stated background | W1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Your background says nothing about metrics. A memory lead (an internal triage tool that support agents adopted) is unconfirmed and isn't evidence | `[grounded]` your background is silent; memory lead only | G3 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You ran go-lives for client integrations. Limit: per-client go-lives are not a product launch coordinated with sales and support | `[grounded]` your stated background | Covered by G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Agile delivery (R5, must_have) | discovery | UAT and go-live, with no delivery method named | A must-have row at `unclear`. Resolving it removes a condition for go | Joining sprint planning for custom builds; writing tickets or acceptance criteria into the engineers' backlog; running UAT inside a sprint cadence | A sanitized ticket, an acceptance-criteria excerpt, a sprint board screenshot | `[grounded]` your background is silent |
| G2 | Working with sales (R4b, must_have; also R10) | discovery | Nothing about sales | Bears on a must-have and on launch coordination | Scoping a deal with an account executive; handing implementation estimates to sales; briefing support before a go-live | An email thread summary, a handover document, a launch checklist | `[grounded]` your background is silent |
| G3 | Adoption metrics (R9), and any product you shipped (R1a, R2) | discovery | Only an unconfirmed memory lead about a triage tool | If it's true and you measured usage, it's the strongest product-ownership story you have | Building the tool yourself; picking who used it; counting usage or ticket-routing time before and after | A screenshot, a usage chart, an internal announcement | `[grounded]` memory lead, unconfirmed |
| G4 | Owning an API product (R2) | transferability | Integrator-side work on a vendor's API | This is the gap between "integrated APIs" and "shipped a platform" | Feeding integration pain points into API changes that then shipped; writing up endpoints you asked for | Your playbook, a sanitized feedback-to-product write-up | `[generic]` that platform PM interviews probe ownership of the API itself |
| G5 | Titled PM years (R1b) | capability | You've never held a PM title | Likely screened literally | None. Closure is about routing (P1) or, later, an internal PM move | — | `[grounded]` your statement; `[generic]` the screening pattern |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from sources I could attribute | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Research couldn't run. The company may be exactly as described, or the posting may be stale or aggregated | `[generic]` pattern, not a claim about Quartzline | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (JD silent) | It may be published later or withheld. No band is available to compare it with | `[grounded]` JD is silent | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | (JD silent) | Could be on-site, hybrid or remote | `[grounded]` JD is silent | Where is this role based, and what's the in-office expectation? | unresolved |
| RR4 | Resources and success measure named | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The mandate comes with people to deliver it and a measure of success | `[grounded]` JD | How is API adoption measured today? | noted |
| RR5 | Reporting line and history of the role unknown | unknown | — | "Own the roadmap for our partner-facing API platform" | This could be the first platform PM or a backfill, which changes how much is already built | `[inferred]` from the JD's silence on reporting line | Who does this role report to, and who owns the API roadmap today? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Apply through a referral or a direct note to the hiring manager, alongside the online application | R1b. Years-of-experience screens often filter before a person reads the application | `[generic]` hiring pattern | pending your approval |
| E1 | Headline line: "Solutions engineer who has led 30+ REST API client integrations end to end — scoping workshops, requirements documents, integration architecture, UAT and go-live — and ran quarterly roadmap-input sessions for product." | R1a, R2, R7. Every clause traces to your own sentences; there's no PM title and no "product discovery" | `[grounded]` your stated background | resume_edits_pending_approval |
| A1 | Positioning: lead with the integrations and the roadmap-input sessions, and say plainly that you fed the roadmap rather than owned it | R1a, R6. The limit you state yourself is one an interviewer can't use against you | `[grounded]` R1a, R6 rows | pending your approval |
| W1 | A one-page sample spec or partner-discovery write-up for a public logistics API | R2, R8. Gives the reviewer something to read for the limits named in those rows | `[generic]` common practice for people changing careers | pending your approval |
| Q1 | Ask the verification questions from RR1 to RR5 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: the triage tool from agent memory, details unconfirmed; it only prompts G3. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform Series B careers product manager". The call was refused (search permission not granted). It would have settled RR1 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | Searched "platform API product manager 3 years experience salary range scope Series B B2B 2026". The call was refused. It would have filled market calibration and given a band to compare RR2 against |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save all of this as a `tuesday-dossier.md` file if you'd like to keep it.

**Upgrade menu**
- **Allow web search:** checks targets 1 and 2, then closes or confirms RR1 and fills in market calibration.
- **A link to the live posting or Quartzline's careers page:** closes RR1 without searching.
- **Your non-negotiables (pay floor, location, remote):** turns the hard-gates line from "unknown" into a real check.
- **An answer to G3, or a screenshot of the tool or its usage:** R9 and R2 could move, and it could become your lead story.
- **The hiring manager's name:** shows which story to lead with for that reader.
- **A deeper research pass** (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G3: Did you build an internal request-triage tool that support agents adopted? If so, which parts were yours, and how did you know it was being used?

G1: On custom builds, did you work inside the engineers' sprints, for example writing tickets, acceptance criteria or attending planning?

G2: Where did sales come into your integrations, for example scoping deals, giving estimates or handing over before go-live?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.