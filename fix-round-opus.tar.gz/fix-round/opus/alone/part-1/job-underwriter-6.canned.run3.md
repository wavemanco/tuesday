I'm fetching the Quillfield posting now so I can map it against your background.
**Yes, it's worth going for, with conditions. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week), R2 (£61,500–£67,000 salary)
- `must_have`: direct: R3a, R4, R5a · adjacent: R6 (Experience owning a forecast) · unclear: R3b (At a B2B software company), R5b (Spreadsheet modelling), R7 (Working with finance on billing or revenue data)
- `important`: direct: R8a, R9 · absent: R8b (Own billing data)

R6: a real bridge from your pipeline review, but you've never owned the forecast number; R7 and R8b: billing data is the real gap; R3b and R5b: what you've told me doesn't settle them yet.

**Opportunity ledger.** The posting holds up as far as it goes. Pay is published and sits near the role-family median (RR2). The open points are who owns the billing data and who owns the forecast number (RR3, RR4), the lack of any stated success measures (RR5), and the posting not appearing on Quillfield's own site (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week), R2 (£61,500–£67,000 salary); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 work for you; (2) you present R6 honestly as adjacent: you run the pipeline review, but you haven't owned the forecast; (3) G2 turns up some finance-facing revenue-data work for R7, or you treat billing as the gap you'll be learning (R8b); (4) RR3 and RR4 come back concrete in interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A in April 2025 | `[grounded]` Quillfield About page (search result) |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two days a week in the office; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` recruiter, plus public profile |
| Scope read | A senior individual-contributor post under a Head of RevOps, with a finance-facing remit (forecast, billing) on top of the usual CRM and reporting work | `[inferred]` from the hiring manager's title and the posting's forecast and billing clauses |
| Market calibration | Ledgerline 2026 puts UK B2B software RevOps leads at a median base of £64,200 (IQR £57,800–£70,400; n=438). The posted range sits around that median. This is a market band, not Quillfield's offer | `[generic]` role-family pay sweep, 2026 guide; `[grounded]` posting, for the range |
| First-year outcomes | None stated | `[grounded]` posting silent |
| Unknowns | Who owns the billing system; who signs off the forecast; option terms; right-to-work terms (unstated) | — |
| Contradictions | None between the posting and the About page. The posting wasn't found on any Quillfield page (see RR1) | `[grounded]` careers fetch and site search |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't said where you are or what working pattern you need. The term is clear, but whether you meet it isn't | `[grounded]` posting; no candidate statement | Closing question on R1/R2 |
| R2 | £61,500–£67,000 salary against your floor | hard_gate | unclear | none | hard_gate | No pay floor given, so the stated range can't be checked against it | `[grounded]` posting; no candidate statement | Closing question on R1/R2 |
| R3a | 4+ years in revenue ops, sales ops or similar analytics | must_have | direct | medium | none | 5 years in sales ops, the last 2 running UK RevOps. Stated but not yet probed, so `medium` | `[grounded]` your background | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | You described a "B2B payments company". Whether it sells software isn't stated, and the posting's wording may be screened literally | `[grounded]` your wording; `[generic]` that a stated sector is often screened literally | Upgrade menu: say what the company's product is |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. A certificate is inspectable but hasn't been seen | `[grounded]` your background | Have the certification ID ready |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly, alongside the dashboard rebuilds | `[grounded]` your background | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" doesn't establish modelling (scenario, driver-based or forecast models). The lower reading is taken | `[grounded]` your wording | Upgrade menu: an example model |
| R6 | Experience owning a forecast (the role runs the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director: the same pipeline data and inspection work. The limit, in your own words, is that you've never owned the company forecast; finance did | `[grounded]` your background | See G1 |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data. Whether you've worked with finance on revenue data in another form (renewals, bookings) isn't stated | `[grounded]` your background | See G2 |
| R8a | Own CRM data | important | direct | medium | none | Salesforce admin who rebuilt the pipeline and renewal dashboards | `[grounded]` your background | none |
| R8b | Own billing data | important | absent | none | capability | You've said you've never worked on billing data. Carried as the material gap, with a closure path in G3 | `[grounded]` your statement | See G3 |
| R9 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them isn't stated | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | A monthly pipeline review run with the sales director; finance owned the company forecast | It's the posting's headline duty (with the CFO), and the bridge's limit is what decides how you frame it | Commit / best-case calls you made for the UK team; a renewal or churn forecast; pipeline coverage or slippage figures you gave finance; a forecast-accuracy check you ran | A redacted pipeline-review deck or forecast-call sheet | `[grounded]` your background; `[inferred]` that this row decides the framing |
| G2 | Finance on revenue data (R7, must_have) | discovery | Billing data ruled out; any other finance-facing revenue work unknown | A must-have. Turning up adjacent work moves R7 off `unclear` | Reconciling closed-won against booked revenue; renewal-value or ARR reporting finance relied on; commission data shared with finance | A dashboard screenshot or a reconciliation sheet, redacted | `[grounded]` your silence on finance work |
| G3 | Billing data ownership (R8b, important) | capability | No billing-data work, by your own account | It's part of the core mandate; it's an `important` row, not a listed requirement | Closure path: learn how billing records link to CRM data (invoice and subscription objects, revenue recognition basics) before interviews, and say plainly that it's the gap you'd be learning | A short self-study note or a Salesforce-to-billing data map you've drafted | `[grounded]` your statement |
| G4 | Sector and modelling wording (R3b, R5b, must_have) | discovery | "B2B payments company" and "Excel daily" don't settle either | A literal screen may read both requirements word for word | Your company's product being software; any model you built rather than maintained | A model screenshot, redacted | `[generic]` that requirements are often screened literally |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Quillfield's own channels | risk_signal | low | "Revenue Operations Lead — Quillfield \| Tallyboard Jobs" | The company may simply have no careers page and hire through job boards and recruiters, or the listing may be stale | `[generic]` pattern for companies of this size, not a claim about Quillfield | Is this role open now, and is it advertised on any Quillfield channel? | unresolved |
| RR2 | Salary published and around the market median | positive_signal | — | "£61,500–£67,000 plus share options" | Transparent pay, priced at the market for this role | `[grounded]` posting; `[generic]` band | What are the vesting schedule and terms of the share options? | noted |
| RR3 | Billing data "owned" by RevOps, but the billing system's owner is unstated | unknown | — | "You will own our CRM and billing data" | Finance may hold the billing system, leaving this role responsible for data quality without authority over the system | `[inferred]` from the posting pairing billing ownership with a finance-collaboration requirement | Who owns the billing system today, and which billing-data decisions would this role make? | unresolved |
| RR4 | Forecast split with the CFO | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may assemble the forecast while the CFO owns the number | `[inferred]` from the "with the CFO" wording | Who signs off the quarterly forecast, and which part of it would this role own? | unresolved |
| RR5 | No success measures stated | unknown | — | (posting lists duties and requirements only) | Success may be undefined, or just not written down | `[inferred]` from the posting's silence | What would a successful first year in this role look like? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Open with your own words: "I rebuilt our pipeline and renewal dashboards and run the monthly pipeline review with our sales director" | R8a, R9, R6. The hiring manager's previous role was sales ops at a payments company, the same function and sector as yours, so lead with the work and skip explaining the sector | `[grounded]` your background and public profile; `[inferred]` the ordering | pending your approval |
| P2 | Say R6 exactly as you said it to me: "I run the monthly pipeline review; I've never owned the company forecast — finance did." Don't reword it as "forecasting" | R6 is `adjacent`; wording can't close it | `[grounded]` your background | pending your approval |
| P3 | Name billing data as the gap you'd be learning, and do G3's groundwork first | R8b, R7 | `[grounded]` your statement | pending your approval |
| Q1 | Ask the verification questions from RR1, RR3, RR4 and RR5 as written, in the loop | They settle the mandate's real authority | `[grounded]` register | pending your approval |
| A1 | Ask the recruiter to confirm the role is live, from a Quillfield email address or by naming the internal contact | RR1 | `[grounded]` RR1 | pending your approval |

Every row above is a proposal, the wording in P1 and P2 included. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1, searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers Revenue Operations Lead", which returned "About Quillfield" (quillfield.co.uk/about). Searched "quillfield.co.uk jobs revenue operations lead Bristol": no results. Fetched quillfield.co.uk/careers: no page. Moved role reality's organization and contradictions rows, plus RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B SaaS 2026", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved market calibration and RR2. It gave pay only, no scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved role reality's scope read and P1 |

I can save all of this as a `tuesday-dossier.md` file you can keep and bring to later sessions; just ask.

## Upgrade menu

- Your location, working pattern and pay floor → R1 and R2 close, and the hard-gates line becomes final.
- An answer to G1 → R6's bridge gets firmer, and P2's wording can say more.
- An answer to G2 → R7 moves off `unclear`, possibly to `adjacent`.
- What your company's product is, and an example spreadsheet model → R3b and R5b resolve.
- Your Salesforce certification ID, or a redacted dashboard or pipeline-review deck → R4, R9 or R6 can rise to `high`.
- A deeper research pass on Quillfield (leadership and finance-team changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

G1: When your UK pipeline review fed into finance's forecast, what did you produce for it yourself: commit or best-case calls, a renewal forecast, a number you had to defend?

G2: Apart from billing, have you worked with finance on revenue data in any form, such as reconciling closed-won deals against booked revenue, renewal or ARR figures, or commission data?

R1/R2: Can you work two days a week in Bristol, and does £61,500–£67,000 meet your floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.