Two web searches were refused, so I've built the assessment from your message and the posting alone. Writing it up now.

## Decision snapshot

**No, it's not worth pursuing. R1 and R2 are both hard gates, and both fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay $70–85k), R2 (On-site in Austin 5 days a week, no exceptions)
- `must_have`: direct: R3a, R4, R5 · unclear: R3b (8+ years growth *leadership*), R6 (SEO/content, brand, PR), R7 (Partnerships and sales ops)
- `important`: adjacent: R8 (Team of one to start) · unclear: R9 (Growth for a business with a sales motion)

R1, R2: each fails on terms the posting states itself; R3a, R4, R5: the core of your growth record maps directly; R6, R7: the parts of the mandate your background doesn't yet cover.

**Opportunity ledger.** The sense that "something feels off" is backed by the posting's own wording. One title covers about seven functions with no team (RR3) and no stated budget (RR7). The pay is low for an 8+ year, board-facing role (RR4). It expects evenings and weekends (RR5), and success metrics are undefined (RR6). The employer couldn't be checked (RR8). One entry points the other way: it claims to be profitable and the role reports to the CEO (RR9).

- **Hard gates:** failed: R1 (Base pay $70–85k), R2 (On-site in Austin 5 days a week, no exceptions).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would have to be different:** Novaline would have to offer at least $150k base *and* remote work from Portland, or you would have to change one of your non-negotiables. Even then, RR3, RR5, RR6 and RR7 would need clean answers before this became a `go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting text; not independently checked (RR8) |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Structure | "Team of one to start"; reports to the CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity terms given | `[grounded]` posting |
| First-90-days / first-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | A department-level remit (several specialist functions plus a sales-ops function) assigned to one person | `[inferred]` from the posting's function list against "team of one" |
| Market calibration | Not established. The role-family sweep was refused, so no market band is stated here. | `[grounded]` posting figure only |
| Unknowns | Growth budget; equity size and terms; who owns quota or sales; how success is judged; customer model (B2B or B2C) | — |
| Contradictions | "8+ years growth leadership" and a board-facing mandate, alongside a $70–85k base and no team | `[inferred]` from the posting's terms read together |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay $70–85k (your floor: $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor, which is specific and your own. The fit fails because the top of the posted band is under your floor. | `[grounded]` posting and your stated constraint | Shown in the snapshot. Only a change in the terms or in your floor resolves it. |
| R2 | On-site in Austin 5 days a week, "no exceptions" (you: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The fit fails because the posting rules out exceptions. | `[grounded]` posting and your stated constraint | Shown in the snapshot. Only a change in the terms or in your constraint resolves it. |
| R3a | 8+ years in growth | must_have | direct | medium | none | 9 years in growth, self-reported and not yet probed. Intake caps it at `medium`. | `[grounded]` your message | none |
| R3b | 8+ years specifically in growth *leadership* | must_have | unclear | low | discovery | You list Growth Lead, then Head of Growth, but not how many of the 9 years were in those roles. | `[grounded]` your message is silent on the split | See G1 |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid at both companies, and scaled one from $8M to $40M ARR with a budget you controlled. Self-reported, with no artifact yet. | `[grounded]` your message | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and work deeply in Braze. Self-reported. | `[grounded]` your message | none |
| R6 | SEO/content, brand, PR | must_have | unclear | low | discovery | None of these appear in your background. That may be omission rather than absence. | `[grounded]` your message is silent | See G2 |
| R7 | Partnerships and sales ops | must_have | unclear | low | discovery | Neither appears in your background. | `[grounded]` your message is silent | See G2 |
| R8 | Team of one: hands-on execution across every channel | important | adjacent | medium | transferability | You built and managed teams of 3–7. Doing every channel yourself with no team is a different job. | `[grounded]` your message; `[inferred]` that management and solo execution differ | See G3 |
| R9 | Growth for a business with a sales motion | important | unclear | low | discovery | Inferred from "sales ops" and "e-commerce enablement"; the posting doesn't state the customer model. Your record is B2C subscription. | `[inferred]` from the posting's "sales ops" and company description | See G2 |

## Gap recovery queue

These gaps don't affect the decision, which the gates settle. They matter only if you reuse this map for a similar role.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leadership years (R3b, must_have) | discovery | 9 years in growth, two leadership titles, no dates | Screens for "8+ years leadership" tend to be read literally | Dates of the Growth Lead and Head of Growth roles; any earlier role where you led a channel or people | LinkedIn dates, offer letters | `[grounded]` your message; `[generic]` that years requirements are often screened literally |
| G2 | SEO/content, brand, PR, partnerships, sales ops, sales motion (R6, R7, R9) | discovery | Not mentioned | These are must-haves in this posting's mandate | Content programs you ran or commissioned; affiliate or channel partnerships; any B2B or sales-assisted funnel you supported | Program briefs, partner dashboards | `[grounded]` your message is silent |
| G3 | Solo execution (R8, important) | transferability | Experience managing teams of 3–7 | A team-of-one role is judged on hands-on output | Periods where you ran a channel yourself before or while hiring | Campaign builds, SQL work, Braze flows you built yourself | `[inferred]` from the posting's "team of one" against your team history |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted top is under your $150k floor, and the equity has no stated size or terms. | `[grounded]` posting figure and your stated floor | Is the $70–85k base fixed, and what is the equity grant: shares, percentage, strike, vesting? | confirmed |
| RR2 | On-site only, against remote-only (see R2) | red_flag | high | "5 days a week — no exceptions" | The posting rules out remote work. | `[grounded]` posting and your stated constraint | Is five days in Austin final for this role? | confirmed |
| RR3 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… team of one" | Several specialist roles appear folded into one title. Rated medium rather than high because hiring plans aren't stated. | `[inferred]` from the function list against "team of one" | Which of these functions do you expect this person to run personally in year one, and when does hiring start? | unresolved |
| RR4 | Seniority and pay mismatch | risk_signal | medium | "8+ years growth leadership required" / "$70–85k base" | The years and board-facing mandate may not match the stated pay. This stays unconfirmed because the market sweep couldn't run. | `[inferred]` from the posting's terms read together | How was the base band set for this role? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Off-hours work is presented as culture, not as an exception. | `[inferred]` from the wording | In the last quarter, how many weekends did the leadership team work? | unresolved |
| RR6 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | The role would be accountable for "all revenue growth" with no stated definition of success. | `[inferred]` from the mandate against the metrics language | What revenue or growth number would make this hire a success at 12 months? | unresolved |
| RR7 | Responsibility without stated resources | risk_signal | medium | "Own all revenue growth end to end… team of one" | Neither budget nor decision rights are mentioned. | `[inferred]` from the posting's silence on budget | What growth budget is committed, and who approves spend? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a public footprint, the posting may be stale, or it may not be a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Profitability and CEO reporting line | positive_signal | — | "profitable since day one… Report to the CEO" | If true, there is real revenue and direct access to the decision-maker. | `[grounded]` posting claim, unverified | What were revenue and margin last year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | R1, R2 | `[grounded]` evidence map | pending your approval |
| A2 | If a recruiter reaches out anyway, ask RR1's and RR2's questions in the first five minutes, before any take-home work | Only a change in the terms reopens this | `[grounded]` register | pending your approval |
| A3 | In similar postings, check pay, location and team size before fit | RR1, RR2, RR3 are the screening pattern here | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth"; the call was refused. It would have confirmed or cleared RR8 and the organization row. |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026"; the call was refused. It would have filled the market calibration row and confirmed or cleared RR4. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

---

If you'd like a `tuesday-dossier.md` of this assessment to keep or reuse, I can produce it.

**Upgrade menu**
- Allowing web search → targets 1 and 2 run: RR8 resolves, and the market calibration row gets a sourced band, which confirms or clears RR4. The decision would not change.
- A deeper research pass on Novaline (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches) → fills out RR3 through RR9. The decision would not change.
- Your resume with role dates → G1 closes and R3b resolves.
- A different posting that clears your two constraints → a fit-first assessment where your strengths (R3a, R4, R5) count.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.