Reading the assessment method done; now running a few quick checks on Brindlemoor and the market before writing your assessment.
**Yes, on fit you're a strong match. Before you spend time on it, check whether the job is really remote. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Working location: fully remote, UK)
- `must_have`: direct: R2, R3, R4, R6a, R7 · unclear: R5 (Monitor rating models), R6b (Design price tests)
- `important`: adjacent: R9 (Pet-insurance product knowledge) · unclear: R8 (Recommendations for product)
- `preferred`: direct: R10

R5, R6b: your background doesn't show this yet, but the work may well be there; R9: you can bridge from motor, with a stated limit.

**Opportunity ledger.** The working pattern differs between the JD and the live careers page (RR1). The salary isn't stated (RR2). The company's size and the scale of the pet book aren't known (RR3, RR5). One entry runs the other way: the hiring manager is a pricing specialist who has spoken publicly about monitoring rating models (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Working location: fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed and works for you (R1, RR1); (2) the budgeted salary meets your floor (RR2); (3) R9 is presented as motor pricing that transfers, not as pet-pricing experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product | `[grounded]` JD header and careers page |
| Mandate | Own pricing analytics for pet insurance: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page; name from your message |
| Line management | The JD doesn't ask for any. Never having managed anyone is not a gap against this posting | `[grounded]` JD silence |
| Scope read | "Own" suggests you'd lead pet pricing analytics, possibly as the only analyst on it. No team is mentioned | `[inferred]` from "Own pricing analytics" and the lack of any team mention |
| Hiring manager | Director of Pricing; previously six years as head of pricing analytics at Calloway Re; gave the 2025 Insurance Pricing Forum talk "Small Books, Loud Errors" on monitoring rating models in small books | `[grounded]` public profile search result |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, middle half £52,100–£64,900 (n=612). This is the market rate, not Brindlemoor's offer. The search found pay data only, nothing on what the role normally covers | `[generic]` Pricewell 2026 pay survey; `[grounded]` JD, for the missing salary |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Salary; working pattern; size of the pet book; pricing team size; whether "product" means a separate product team | — |
| Contradictions | JD says "Fully remote (UK)". The live careers page says "Leeds office four days a week" | `[grounded]` JD vs. fetched careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Working location: "Fully remote (UK)" (the careers page says Leeds four days a week) | hard_gate | unclear | none | hard_gate | You haven't stated a location constraint, so confidence is `none`. The fit is `unclear` because the employer's two sources disagree on the term itself | `[grounded]` JD vs. careers page; no constraint stated by you | Closing question R1; RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific, but nothing inspectable yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". Specific about frequency, nothing to inspect | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5 | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include performance monitoring but doesn't say so. `[grounded]` the hiring manager's public talk is on monitoring rating models | `[grounded]` your wording; talk title from search result | See G1 |
| R6a | Run and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | none |
| R6b | Design price tests | must_have | unclear | low | discovery | You said "ran", which doesn't establish who designed the tests (cells, sample sizes, success metric). The wording stays "ran" until you confirm | `[grounded]` your verb | See G2 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Recommendations for product | important | unclear | low | discovery | Your recommendations go to underwriting. Nothing mentions a product team | `[grounded]` your silence on product | See G4 |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Inferred from "our pet-insurance product". GLM rating and price testing transfer. `[generic]` Pet rating factors and claims patterns are a different domain from motor | `[inferred]` requirement from the JD's product; `[generic]` domain difference | See G3 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R5, must_have) | discovery | "Built and maintained" the young-driver GLM; monitoring isn't stated | A must-have, and the hiring manager's published topic, so it's likely the story to lead with | Actual-vs-expected tracking by factor or segment; drift or stability checks after a rate change; spotting a model going wrong on a thin segment (young drivers are a small book) | A redacted monitoring dashboard, A-vs-E pack, or model-review note | `[grounded]` your wording and the talk title; `[inferred]` that it suits this reader |
| G2 | Design price tests (R6b, must_have) | discovery | 14 tests "ran" with underwriting; your part in the design isn't clear | The JD says "design and read", and the difference between the two is easy to probe | Choosing test cells or rate splits; setting sample size or run length; defining the success metric; deciding when to stop a test | A redacted test plan or readout deck | `[grounded]` your verb vs. the JD's |
| G3 | Pet-insurance product knowledge (R9, important) | transferability | Motor only | A bridge with an honest limit is better than silence on the domain | What carries over: GLM rating structure, testing discipline, small-segment work on young drivers. The limit: no pet rating factors or vet-claims experience | A short, honest note on how you'd approach a pet book | `[grounded]` your background; `[generic]` what differs between domains |
| G4 | Recommendations for product (R8, important) | discovery | Only underwriting is mentioned | Lower priority. Not asked this turn | Feeding pricing into product design, cover options, or excess structures | Any memo to a product owner | `[grounded]` your silence on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts itself (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source is out of date, or the terms changed after one was written | `[inferred]` from the two employer sources disagreeing | Is this role fully remote, or Leeds four days a week, and is that fixed? | unresolved |
| RR2 | Salary not stated | unknown | — | No figure in the JD or on the careers page | The figure may sit anywhere relative to the £52–65k middle range | `[inferred]` from the missing figure, against the `[generic]` band | What salary is budgeted for this role? | unresolved |
| RR3 | Company stage and size not known | unknown | — | "Brindlemoor (insurtech)" | `[generic]` Small insurtechs often have little public footprint. The careers page and live posting do confirm the company exists | `[generic]` pattern; `[grounded]` careers page live | How large is the pet book today, and how is the business funded? | unresolved |
| RR4 | Hiring manager is a pricing specialist with public work on model monitoring | positive_signal | — | Careers page: "reports to the Director of Pricing" | You'd report to someone who knows the craft | `[grounded]` careers page and profile search result | What does good model monitoring look like here in year one? | noted |
| RR5 | Ownership without a stated team | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only pricing analyst, with thin data or tooling support | `[inferred]` from "Own" and the lack of any team mention | Who else works on pet pricing, and what data and tooling support is there? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with: built and maintained the GLM rating model for the young-driver book; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting. Keep your own verbs ("ran", not "designed") until G2 is answered | See R4, R6a, R7 | `[grounded]` your words | pending your approval |
| E2 | If G1 confirms monitoring work, put it first for this reader | See R5, RR4 | `[grounded]` the hiring manager's published talk | pending your approval |
| A1 | Get RR1's question answered before applying (the careers contact or recruiter) | See R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Prepare the G3 bridge with its limit: what carries over from motor, and that pet is new to you | See R9 | `[grounded]` your background; `[generic]` domain difference | pending your approval |
| Q1 | Ask the verification questions for RR1–RR5 word for word during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results, so stage and size are not established) and "Brindlemoor careers senior pricing analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved: the posting is live; the contradictions row; RR1; RR3 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: market calibration (pay only) and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Moved: the hiring-manager row, RR4, E2 |

I can also produce all of this as a `tuesday-dossier.md` file you can keep and bring back later; just say so.

**Upgrade menu**
- **Your location and non-negotiables (office days, pay floor):** R1 gets resolved, and RR1 and RR2 can be checked against you.
- **Answers to G1 and G2:** R5 and R6b move to direct, or stay as named gaps.
- **A redacted price-test readout, A-vs-E monitoring pack, or model documentation:** these are the proof pricing work actually produces. Any one would raise R4, R5 or R6a above `medium`.
- **Your CV:** I can check these rows against your written record and draft E1 as real CV lines.
- **The budgeted salary:** RR2 closes against the £52–65k band.
- **A deeper research pass** (funding, leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

R1: What are your non-negotiables on working location and pay? In particular, would Leeds four days a week work, or does it have to be fully remote?

G1: When you maintained the young-driver GLM, did you track how it performed after go-live (actual vs. expected, drift, segments going wrong)? What exactly was yours?

G2: Across the 14 price tests, which parts did you design yourself (test cells, sample size or run length, success metric), and which came from underwriting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.