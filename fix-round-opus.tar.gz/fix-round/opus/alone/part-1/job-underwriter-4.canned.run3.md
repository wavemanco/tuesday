**Yes, it's worth going for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK) working pattern)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (Monitor rating models), R7b (Recommendations to product)
- `important`: adjacent: R9 (Pet-insurance product knowledge)
- `preferred`: direct: R10 (Insurance experience)

R9: your motor background carries over, with its limits named; R5b, R7b: your background doesn't yet say either way; R1: the employer's own sources disagree on the working pattern.

**Opportunity ledger.** The employer is real and the posting is live (RR3), and the job is clearly defined, with named counterparts and a reporting line (RR4). But the working pattern contradicts itself across sources (RR1), pay isn't stated (RR2), and the resources behind "own" are unknown (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK) working pattern); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor confirms the working pattern, and it's one you can do: R1, RR1. (2) The budgeted pay meets your floor: RR2. (3) The motor-to-pet bridge is presented as adjacent experience, never as pet-insurance experience: R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics for pet insurance: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` JD and careers page |
| Line management | None stated. The JD asks for no people management, so never having managed anyone isn't a gap against this posting | `[grounded]` JD's requirements list |
| Scope read | A senior individual-contributor role. "Own" suggests this person is the pricing analytics function for this product | `[inferred]` from "own pricing analytics" and the absence of any team mentioned |
| Hiring manager | Director of Pricing at Brindlemoor. Spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books). Previously head of pricing analytics at Calloway Re for six years | `[grounded]` public professional profile |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900. That's what to expect, not Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 UK pay survey, n=612; `[grounded]` JD, for the unstated pay |
| Unknowns | Pay; whether anyone else does pricing analytics; who owns the price-test design sign-off; how the product team takes recommendations | — |
| Contradictions | The JD says "Fully remote (UK)". Brindlemoor's own careers page for the same role says "Leeds office four days a week" | `[grounded]` JD vs. fetched careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working pattern | hard_gate | unclear | none | hard_gate | You haven't stated a location or working-pattern constraint, so there's nothing yet to grade. The role's own terms are contested: remote in the JD, Leeds four days a week on the careers page | `[grounded]` JD vs. careers page; no candidate constraint given | Question on R1 below; RR1's question to the recruiter |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, stated specifically. Self-reported at intake, so `medium` until a CV or artifact is seen | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", stated. Expect a technical test or probe | `[grounded]` your background; `[generic]` that pricing roles commonly test this | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5a | Build rating models | must_have | direct | medium | none | The same young-driver GLM, built by you | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", which doesn't say what monitoring you did (drift, actual vs. expected, refits). Reading it as monitoring would widen your claim | `[grounded]` wording of your background | See G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team." Which part of the design was yours versus the team's isn't stated, so describe that precisely when asked | `[grounded]` your background | none |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7b | Turn results into recommendations for product | must_have | unclear | low | discovery | Your background names only underwriting as an audience; nothing on product teams | `[grounded]` your background is silent | See G2 |
| R8 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | The methods carry over directly: GLM rating, price testing, underwriting partnership. Limit: none of it covered pet-specific rating factors or claims patterns | `[inferred]` requirement from "our pet-insurance product"; `[generic]` that pet and motor rating factors differ | See G3 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | "Built and maintained" the young-driver GLM; no detail on monitoring | It's in the mandate, and it's the subject of the hiring manager's public talk | Actual-vs-expected tracking by segment; drift or stability checks on rating factors; triggering or running a refit; alerts when a segment's loss ratio moved | A sanitized monitoring dashboard screenshot, a refit memo, a model-review pack | `[grounded]` your background's wording; `[grounded]` the talk title from the public profile |
| G2 | Recommendations to product (R7b, must_have) | discovery | Only underwriting is named as an audience | Half of the stated recommendation audience | Feeding price-test results into product features, cover levels, excess options or a new channel's pricing; working with a product owner on a launch | A deck or memo written for a product audience | `[grounded]` your background is silent on product |
| G3 | Pet-insurance knowledge (R9, important) | transferability | Strong motor pricing skills; no pet exposure | It's the clearest objection to a motor-only background | Carries over: GLM build, price testing, underwriting partnership. Doesn't: pet rating factors (breed, age at inception), vet-cost inflation, lifetime vs. time-limited cover. Narrows it: a short write-up of how you'd approach a pet rating structure, or knowing public market material well | A one-page approach note (W1 below) | `[generic]` pet rating-factor patterns; `[inferred]` that this is the likeliest objection, from the motor-only background against a pet-only mandate |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One version is stale, or the arrangement changed after the posting was written. Medium, not high, because a single answer settles it | `[grounded]` both quotes; `[inferred]` the stale-copy reading | Is this role fully remote, or based in the Leeds office four days a week as the careers page says? | unresolved |
| RR2 | Pay not stated | unknown | — | (no figure in the JD or on the careers page) | It may sit inside the market band in role reality, or Brindlemoor may simply not publish pay | `[inferred]` from the missing figure, against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Employer and posting verified live | positive_signal | — | "Accepting applications" | The entity exists as described and the role is open | `[grounded]` fetched careers page | — | noted |
| RR4 | Clear mandate, counterparts and reporting line | positive_signal | — | "reports to the Director of Pricing"; "recommendations for underwriting and product" | Scope is concrete, with named audiences | `[grounded]` JD and careers page | How are pricing recommendations decided between pricing, underwriting and product? | noted |
| RR5 | "Own" with no team or resources named | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be a one-person function, carrying all of the work alone | `[inferred]` from "own" against the JD's silence on team | Who else works on pet pricing, and what data engineering or actuarial support does the role have? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter before investing in applications | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with these two, in your own words: "built and maintained the GLM rating model for our young-driver book" and "ran 14 price tests last year with the underwriting team" | see R4, R5a, R6; they match the mandate's first two verbs | `[grounded]` your background | pending your approval |
| P2 | Prepare a precise, honest account of what model monitoring you actually did (or didn't) do | see R5b, G1; it's the subject of the hiring manager's published talk | `[grounded]` public profile | pending your approval |
| W1 | A one-page note on how you'd approach a pet rating structure, framed as an outsider's approach, not experience | see R9, G3 | `[grounded]` R9 row | pending your approval |
| Q1 | Ask the verification questions in RR1, RR2, RR4 and RR5 word for word during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

All proposed wording above is `resume_edits_pending_approval` / pending your approval. I won't finalize anything until you say so.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved: role reality's contradictions row, RR1, RR3 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary remote GLM"; returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: market calibration, RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor"; returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Moved: role reality's hiring-manager row, G1's importance, P2 |

If you'd like, I can save all of this as a `tuesday-dossier.md` file you can come back to.

**Upgrade menu**
- Your working-pattern and location constraints → R1 becomes met or failed, and the decision settles to `go` or `no_go` on that term.
- Your salary floor → RR2 can be checked against the market band once Brindlemoor gives a figure.
- Your CV → every `medium` row gets checked against how you actually present it, and any wording gaps get flagged.
- A sanitized monitoring pack or price-test write-up → R5b and R6 toward `high`.
- An answer to G2 → R7b resolves.
- A deeper research pass on Brindlemoor (funding, leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1: Could you work from the Leeds office four days a week, or is fully remote a must for you?

RR2: What's the lowest base salary you'd accept for this move?

G1: On the young-driver GLM, what did "maintained" involve? Did you track actual vs. expected, check factor stability, or trigger refits, and which parts were yours?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.