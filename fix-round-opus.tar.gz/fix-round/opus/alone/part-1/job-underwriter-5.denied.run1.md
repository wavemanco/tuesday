Your approval for the posting check didn't come through, so I've built this from what you pasted.

## Decision snapshot

**Yes, it's worth applying, once you clear the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5, R7, R8
- `important`: adjacent: R6 (BigQuery as the warehouse) · unclear: R9 (ingestion from our app and CRM), R10 (the data contracts our analysts depend on)

R6: a Snowflake-to-BigQuery bridge, with its limits stated; R9, R10: your background doesn't mention either yet, so one question each.

**Opportunity ledger.** The pay is published and lines up with your pay report (RR2), and the company says it raised a Series C in February 2026 (RR6). Four things are still open: I couldn't confirm the posting is live (RR1), nobody is named as the hiring manager (RR3), the on-call load behind "build and run" isn't stated (RR4), and it's unclear who owns the data contracts (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Pellucid's own careers page (RR1); (2) you're US-based or can work from Denver, and have US work authorization (R1); (3) you present BigQuery honestly as a platform you haven't used yet, bridged from Snowflake, and never as experience you have (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` pasted About page |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for the analysts | `[grounded]` JD |
| Must-haves | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Hard gate | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | A pipeline-owner role with no people management: the JD lists build, run and contract work, and mentions no direct reports | `[inferred]` from the JD's responsibilities and its silence on reports |
| Market calibration | Your report says "Senior" typically means 5–8 years and owning one domain's pipelines with no reports. This role fits that, and your 6 years sits inside the range. On pay, the posting's bottom ($148,000) is $9,000 above the report's 25th percentile ($139,000), its top ($166,000) is $2,500 above the 75th percentile ($163,500), and its midpoint ($157,000) is $6,000 above the median ($151,000). This is the market band, not Pellucid's offer to you | `[generic]` Datawright 2026 report, US, n=2,310, Series B–D segment (Pellucid's Series C is inside it); `[grounded]` JD for the posted range |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Hiring manager and reporting line; on-call expectations; who owns the data contracts on the producer side; whether the posting is still live | — |
| Contradictions | None between the pasted JD and the pasted About page | `[grounded]` both pastes |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | Nothing you shared says where you're based or whether you have US work authorization. The gate isn't failed, only not yet established | `[grounded]` JD term; background silent | Closing question R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. That's specific, but self-reported with nothing to inspect yet, which is the ceiling at intake | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is stated plainly. Expect it to be tested live rather than taken on trust | `[grounded]` your background; `[generic]` that this role family tests both live | none |
| R4 | dbt | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models" is specific about scale. The number is yours and stays "about" | `[grounded]` your background | none |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the JD asks for one generically | `[grounded]` JD wording, your background | none |
| R6 | BigQuery as the warehouse | important | adjacent | medium | transferability | The JD names BigQuery as the stack, not as a requirement. You've said you've never used it. What carries over: warehouse modelling in dbt on Snowflake. What doesn't: anything specific to BigQuery, such as its cost model, partitioning and clustering, and its SQL dialect | `[inferred]` requirement drawn from the JD's description of the stack; `[generic]` what transfers between the two warehouses | Gap queue G1; plan row W1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You stated Airflow for orchestration, which is the exact tool the JD names | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite": the verb is "set up", and it stays that verb | `[grounded]` your background | none |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background lists modelling, orchestration and testing, but says nothing about which sources you ingested or whether you built that ingestion | `[grounded]` background silent on sources | Closing question G2 |
| R10 | The data contracts our analysts depend on | important | unclear | low | discovery | The Great Expectations suite is related but isn't evidence of contracts. Contracts usually mean agreed schemas or SLAs with producers or consumers | `[grounded]` background; `[generic]` what "data contracts" usually means | Closing question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | A dbt project of about 180 models on Snowflake; you've never used BigQuery | It's the only stack term in the JD you don't have, so it's the gap most likely to be raised | Any GCP exposure at all; switching dbt adapters; tuning warehouse cost or performance on Snowflake | A small public dbt-on-BigQuery repo (plan row W1) | `[grounded]` your background; `[generic]` that a missing stack term draws the first probe |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Your background is silent on sources and on who built ingestion | It's the first item in the JD's mandate | Loading a production app database into Snowflake, whether by CDC, replication or batch extract; pulling from a CRM's API or a managed connector; deciding how you'd handle schema changes coming from upstream | A pipeline diagram, a README, or a sanitized DAG | `[grounded]` JD lists ingestion first; background silent |
| G3 | Data contracts (R10, important) | discovery | Great Expectations is set up, but nothing shows agreements with producers or analysts | The JD names contracts as something the analysts depend on | Agreeing schemas or freshness SLAs with application engineers; dbt model contracts or enforced schemas; turning test failures into alerts that a named owner fixes | A contract spec, a dbt `contract:` config, a runbook | `[grounded]` JD wording; `[generic]` what contracts usually look like in dbt stacks |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "pellucidlearning.com/careers/senior-data-engineer" | The posting check was refused, so neither the posting being live nor the company matching the pasted description has been confirmed. The posting could be stale, or the company may simply not have been checked yet | `[generic]` pattern for unverified postings, not a claim about this company | Is this role still open, and who would I be interviewing with? | unresolved |
| RR2 | Pay published and in line with the market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The posted range covers the report's median and goes above its 75th percentile; see market calibration | `[grounded]` JD; `[generic]` report band | How is the equity structured, and where in the range do offers usually land? | noted |
| RR3 | No hiring manager named | unknown | — | the posting names no manager | Who you'd report to, and whether they're in data, engineering or analytics, would shape both the role and the pitch | `[inferred]` from the posting's silence | Who does this role report to, and how big is the data team? | unresolved |
| RR4 | "Build and run" with no stated on-call terms | unknown | — | "Build and run the pipelines" | Running the pipelines may come with on-call duty that the posting doesn't describe | `[inferred]` from "run" alongside silence on support terms | What does on-call look like for this role, and how often do pipelines page someone? | unresolved |
| RR5 | Contracts the role owns but the producers control | unknown | — | "the data contracts our analysts depend on" | Contracts with the app and the CRM need the upstream teams to cooperate, and the posting doesn't say the role has that authority | `[generic]` responsibility-without-authority pattern | When an app change breaks a contract, who has to fix it, and what is this role able to require of them? | unresolved |
| RR6 | Recent Series C | positive_signal | — | "Series C ($52M, February 2026)" | Fresh funding often pays for data-platform hires | `[grounded]` About page; `[generic]` the funding pattern | What reporting does the company need from this role in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the posting URL yourself, or let me run the one fetch, before you apply | RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the dbt project and the test suite in your own words: "built our dbt project on Snowflake — about 180 models" and "set up our Great Expectations test suite". Keep "built", "set up" and "about" exactly as they are | R4, R8 | `[grounded]` your background | pending your approval |
| P2 | Say "I haven't used BigQuery; I've modelled on Snowflake in dbt" plainly, rather than leaving it unsaid | R6 | `[grounded]` your statement "Never used BigQuery" | pending your approval |
| W1 | A small public dbt project on BigQuery as a work sample | R6, G1 | `[generic]` that a work sample narrows a stack gap | pending your approval |
| Q1 | Ask the register's questions for RR1, RR3, RR4 and RR5 word for word in your screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1, searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One fetch of pellucidlearning.com/careers/senior-data-engineer was refused. It would have confirmed the posting is live and matches your paste, which would close RR1 |
| 2. Role-family sweep | skipped | The Datawright 2026 report you pasted already gives the pay band, the years for "Senior" and the usual scope, so the market calibration doesn't need a search |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can also package all of this as `tuesday-dossier.md` if you'd like a copy to keep.

**Upgrade menu**
- Approve the posting fetch, or paste a screenshot of the live page: closes RR1 and lifts condition (1).
- Your location and work authorization: settles R1.
- A pay floor: puts it on the map as a constraint and checks it against the $148,000–$166,000 range.
- A pipeline diagram, a README or a sanitized dbt repo: raises R4, R8 and R9 to `high`.
- The hiring manager's name: sharpens the scope read and tells me which story to lead with for that person.
- Deeper research on Pellucid Learning (leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches): just say so and it runs.

**Questions**

R1: Are you based in the US, or able to work from Denver, with US work authorization that needs no sponsorship?

G2: At the payroll company, did you build ingestion from an application database or a SaaS tool like a CRM? If so, what was the source, and which part was yours?

G3: Have you agreed schemas, freshness targets or dbt model contracts with the engineers upstream or the analysts downstream, beyond the Great Expectations suite?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.