I've read the skill's rules and am now checking that Harborlight Health is a real company with a live posting before I write the assessment.
I couldn't check the company online: the web searches were blocked by this session's permission settings. Everything below comes from the job description (JD) and your background as you described it.

## Decision snapshot

**Yes, apply, but only after you confirm Harborlight is a real employer with this role open (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important` — direct: R7a · adjacent: R7b (Partner with clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience (HIPAA))

R6 is a must-have that one recall question could settle. R8 is the senior-level duty you haven't mentioned yet. R7b and R9 are real bridges from your experience, with their limits named.

**Opportunity ledger.** The employer is unverified, not suspicious: I couldn't check it because search was blocked (RR1). Pay and location are not stated (RR2, RR3). One senior analyst owning the whole product-analytics stack with two juniors may be the entire function (RR4). One entry is positive: the requirements are specific and hang together (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight and the live posting check out (RR1). (2) Pay and location work for you (RR2, RR3). (3) Your privacy work is presented as adjacent to HIPAA, never as HIPAA experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health: a digital-health scale-up, about 400 people, Series C, with a care-navigation app. Unverified (RR1) | `[grounded]` JD header |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, turning analysis into roadmap decisions with PMs and clinicians | `[grounded]` JD |
| Team shape | You plus two junior analysts you mentor | `[grounded]` JD, "mentor two junior analysts" |
| Scope read | This is the full product-analytics stack (definitions, experimentation, BI, influence) in one seat. That is broad but normal for a senior analyst who owns a product area | `[inferred]` from the JD's five responsibilities; `[generic]` that this is normal for the title |
| Domain read | A care-navigation app's metrics are likely tied to care access or health outcomes, not subscription retention. Experiments may need clinical-safety review | `[generic]` digital-health role-family pattern, not a claim about this employer |
| Unknowns | Pay; location or remote; reporting line; whether Looker and a metrics layer already exist or you'd build them; traffic available for experiments; first-90-day outcomes | `[grounded]` the JD doesn't state these |
| Contradictions | None inside the JD. Not checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years of product analytics | must_have | direct | medium | none | You stated 6 years of product analytics at a consumer-subscription company. This is a specific claim, but self-reported with nothing inspected yet, so it stops at `medium` | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | You use SQL daily on a Snowflake warehouse, and you built the consent-state model for that warehouse. Both are specific, but nothing has been inspected | `[grounded]` your background | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift, at a company with about 2M subscribers. It's specific and has a stated outcome. Expect a probe on methods | `[grounded]` your background | Offer: a sanitized readout of the pricing test would raise this to high |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. Their tool, exactly | `[grounded]` your background | Offer: a dashboard screenshot or LookML excerpt would raise this to high |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads, and you present to the VP Product monthly | `[grounded]` your background | Offer: a sanitized memo excerpt would raise this to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" points toward governed metric definitions, but you haven't said whether you defined and maintained them (in LookML, dbt or elsewhere) or whether someone else did. Low rather than none, because there is a concrete thread to pull | `[grounded]` your background is silent on metric definitions | See G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | The pricing test behind an 11% retention lift is analysis that reached a shipped decision, and you present to the VP Product monthly | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | adjacent | low | transferability | The bridge: writing and presenting for non-technical executives. The limit: you've had no clinical audience, and clinicians tend to weigh evidence and patient-safety risk differently from commercial executives | `[grounded]` no clinical exposure stated; `[generic]` that clinical stakeholders hold different evidence standards | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring, managing or onboarding analysts. This is a first pass, so it's unclear, not absent | `[grounded]` your background is silent | See G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | The bridge: handling GDPR/CCPA consumer PII and building the warehouse's consent-state model. The limit: HIPAA-specific practice (protected health information, business associate agreements, de-identification standards) was not part of that work | `[grounded]` your background; `[generic]` what HIPAA-specific practice involves | See G4. Never claim HIPAA experience |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | A Looker build with governed dashboards, but nothing on who wrote and maintained the metric definitions | It's the one must-have below `direct`, and it's the first item in their responsibility list | Writing the LookML model or explores behind those dashboards; owning definitions of "active subscriber" or churn that teams had to use; a metrics catalog, dbt metrics, or a sign-off process for changing a definition | A LookML excerpt, a metric definitions doc, a governance process note | `[grounded]` silence in your background; `[inferred]` that its first-listed position signals priority |
| G2 | Mentoring juniors (R8, important) | discovery | No mention of mentoring or leading analysts | It's a named duty of the role, and the gap between senior and lead is what this line tests | Onboarding new analysts onto the Looker instance; reviewing others' SQL or test designs; teaching PMs to self-serve; formally managing or informally guiding anyone | A peer-review note, an onboarding doc you wrote, a performance-review line | `[grounded]` silence in your background |
| G3 | Clinician partnership (R7b, important) | transferability | You have exec and VP-level audiences, but no clinical ones | Clinicians are a named partner for this role | Work with food-safety, nutrition or ops specialists whose standards limited what you could test; any regulated or safety-reviewed experiment | A memo or readout written for a specialist audience | `[inferred]` bridge from your exec communication; `[generic]` that specialist audiences are the closest analogue |
| G4 | HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | It's a plus rather than a requirement, but it lets you show you'll handle health data responsibly from day one | Your consent-state model design; data-minimization or access-control decisions you made | A schema diagram or design doc for the consent-state model | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here the check couldn't run at all | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | No compensation appears in the JD | The posting may withhold a band that sits below senior market rates, or the company may simply not publish pay. I couldn't pull a market band | `[inferred]` from the missing figure | What base salary range and equity are budgeted for this role? | unresolved |
| RR3 | Location and working pattern not stated | unknown | — | No location appears in the JD | The role may require on-site or hybrid work that you'd only find out about later | `[inferred]` from the missing term | Is this role remote, hybrid or on-site, and where? | unresolved |
| RR4 | One senior seat owns the whole product-analytics stack | risk_signal | low | "Own product analytics for our care-navigation app… mentor two junior analysts" | You plus two juniors may be the entire analytics function, which means broad accountability with thin support | `[inferred]` from the scope against the stated team | Who does this role report to, and who else works on product analytics today? | unresolved |
| RR5 | Specific, coherent requirements | positive_signal | — | "design and analyze A/B tests, build self-serve dashboards in Looker" | Named tools and duties suggest a real, defined role | `[grounded]` JD | Which roadmap decision did analytics most recently change? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program in your own words: "designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Keep "behind" rather than "drove" until you've confirmed what was yours | See R3 | `[grounded]` your background | pending your approval |
| P2 | Pair it with "built the company's Looker instance from scratch — 40+ governed dashboards." Don't claim metrics-layer ownership until G1 is answered | See R4, R6 | `[grounded]` your background | pending your approval |
| P3 | Describe your privacy work as "handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse", as adjacent groundwork for health data, never as HIPAA experience | See R9 | `[grounded]` your background | pending your approval |
| W1 | Prepare a sanitized excerpt of a monthly metrics memo as a writing sample | See R5, and a bridge for R7b | `[grounded]` R5, R7b rows | pending your approval |
| A1 | Confirm the live posting on Harborlight's own careers page before tailoring anything | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions from RR1–RR5 word for word on the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Harborlight Health care navigation app", but the host's permission settings refused it. It would have confirmed or cleared RR1 and filled role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | I searched "senior product analyst digital health salary 2026", but it was refused the same way. It would have added a market calibration line and set RR2 against a pay band |
| 3. Hiring manager's public footprint | n/a | You didn't give a name, so there was nothing to search for |

If you'd like, I can save all of this as `tuesday-dossier.md` so the map and register carry into later steps.

**Upgrade menu**
- **Allow web search, or paste the posting's link or the careers-page URL:** RR1 could clear, possibly moving the status to `go`. The role-family sweep would add a pay band for RR2.
- **A sanitized readout of the pricing test:** raises R3 to high.
- **A LookML excerpt or a metric-definitions doc:** raises R4 to high and may settle R6.
- **A sanitized metrics-memo excerpt:** raises R5 to high and supports W1.
- **Your actual CV:** checks whether this story comes through on paper, and shows any presentation gaps.
- **The hiring manager's name:** sharpens the scope read and P1's choice of which story to lead with.
- **A deeper research pass on Harborlight** (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches, and it needs search allowed): just say so.

**G1:** For the Looker instance you built, did you write and maintain the metric definitions underneath it (LookML, dbt or a definitions doc), and how did changes to a definition get agreed?

**G2:** Have you mentored, reviewed the work of, or onboarded other analysts, formally or informally? Who was it, and what did you do?

**Constraints:** What are your non-negotiables on pay, location or remote work, and work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.