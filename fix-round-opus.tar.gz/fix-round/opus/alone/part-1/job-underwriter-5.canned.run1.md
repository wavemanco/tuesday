I'm working through the skill's reference rules now. Next I'll check Pellucid's own site to confirm the posting is live, then write up the assessment.
I'd apply, Ines. Pellucid checks out and the pay is at or above market. Two things are still open: whether you meet the location rule, and whether the pay clears your own minimum, which you haven't given me.

## Decision snapshot

**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office)
- `must_have` — direct: R2, R3, R4, R5, R6
- `important` — adjacent: R7 (BigQuery, the warehouse this team runs) · unclear: R8 (Ingestion from app and CRM), R9 (Data contracts analysts depend on)

R7 — Snowflake carries over to BigQuery, but only partly, and you should say so; R8, R9 — responsibilities your background doesn't speak to yet.

**Opportunity ledger.** The role looks sound. The posting is live and matches the company page (RR2), and the pay is at or above the market band (RR1). What's unknown is who you'd report to and how big the team is (RR3), the student-privacy rules on this data (RR4), and what the equity is (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you live in the US or can work from Denver — R1; (2) $148,000–$166,000 is at or above your own minimum — RR1; (3) you present BigQuery honestly as a skill you'd transfer from Snowflake, not one you have — R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page, pasted and checked live |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data-quality testing | `[grounded]` JD |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One domain (reporting) with three parts. No direct reports are mentioned. | `[inferred]` from the JD's list of responsibilities and its silence on managing people |
| Market calibration | Senior usually means 5–8 years and owning one domain's pipelines with no reports, which matches this posting. Series B–D base pay: median $151,000, middle half $139,000–$163,500. The posted $148,000–$166,000 starts above the bottom of that middle half, ends above its top, and its midpoint ($157,000) is above the median. | `[generic]` Datawright 2026 Data Engineering Pay Report (US, n=2,310), as you supplied it; `[grounded]` JD, for the posted band |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Who the hiring manager is; team size; whether the BigQuery/dbt stack already exists or you'd build it; on-call duties; details of the equity | — |
| Contradictions | None. The live careers page and about page match what you pasted. | `[grounded]` pages checked this session |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The JD limits where you can work. Your background doesn't say where you're based or whether you're authorized to work in the US. | `[grounded]` JD; background silent | The R1 question below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | "6 years of data engineering at a B2B payroll company" clears 5+, and sits in the report's 5–8 Senior range. You stated it, but there's no document to check yet. | `[grounded]` your background; `[generic]` the 5–8 range, from the report | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily." Specific, but nothing to inspect yet, so expect a technical screen to test it. | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models." Snowflake meets "a cloud warehouse" as written. Keep the "about." | `[grounded]` your background | Offer: a sanitized dbt docs page or a DAG screenshot would raise this to high |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration." Exactly the tool named. | `[grounded]` your background | none |
| R6 | Experience with data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite." That's your own setup, not just use. | `[grounded]` your background | Offer: a sanitized suite config or a test report would raise this to high |
| R7 | BigQuery, the warehouse this team runs | important | adjacent | medium | transferability | The JD names BigQuery as their warehouse but only asks for "a cloud warehouse." You stated "Never used BigQuery." dbt and warehouse SQL carry over from Snowflake. What doesn't carry over: BigQuery's pay-per-bytes-scanned billing, partitioning and clustering design, and its permissions model. | `[grounded]` JD and your background; `[generic]` what carries between warehouses | See gap queue G1 |
| R8 | Ingestion from the app and a CRM | important | unclear | low | discovery | The JD lists it as a core duty. Your background covers modelling, orchestration and testing, but not where the data comes from or who built the loaders. | `[grounded]` JD; background silent | The G2 question below |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | The JD names "data contracts" explicitly. Your background doesn't say whether you've set schema or freshness agreements with the people who use the data. | `[grounded]` JD; background silent | The G3 question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | **What carries over:** a dbt project of about 180 models on a cloud warehouse, plus Airflow and Great Expectations, all of which work on BigQuery. **The limit:** you haven't run BigQuery's cost model, partitioning or permissions. **What would strengthen it:** a small hands-on sample. | It's the one row where your stack differs from theirs | Moving a few dbt models to a BigQuery sandbox; any migration between warehouses you worked on; tuning Snowflake costs, which is a similar discipline | A public repo with a small dbt + BigQuery project | `[grounded]` your background; `[generic]` that this is the likeliest objection for a candidate switching warehouses |
| G2 | Ingestion from the app and CRM (R8, important) | discovery | Ingestion sources aren't mentioned | It's a core duty in the JD, and a payroll company has similar sources | Loading data from your product's database or event stream; pulling from a CRM or HR/payroll SaaS API; using Fivetran, Airbyte or a custom Python loader; change-data-capture | A loader repo, a pipeline diagram, a runbook | `[grounded]` JD and your silence on it |
| G3 | Data contracts (R9, important) | discovery | Your Great Expectations suite is related, but agreements with data users aren't mentioned | The JD calls out contracts by name | Schema or freshness agreements with analysts or upstream app teams; dbt model contracts or versioning; alerts set up to tell people downstream when something breaks | A contract YAML, a schema-change process doc, an incident write-up | `[grounded]` JD; `[inferred]` that a Great Expectations suite may sit close to this work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay is at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The band starts above the report's 25th percentile and ends above its 75th, so the pay is transparent and competitive | `[grounded]` JD; `[generic]` Datawright report | Where in the band do offers usually land for someone with 6 years? | noted |
| RR2 | Employer and posting verified | positive_signal | — | "Accepting applications" | The company exists as described and the role is live | `[grounded]` careers and about pages checked this session | — | noted |
| RR3 | No hiring manager, reporting line or team size given | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role could be a lone data engineer covering all three parts, or one person on a team | `[inferred]` from the JD's scope against its silence on the team | Who does this role report to, and how many data engineers and analysts are there today? | unresolved |
| RR4 | Student-data privacy duties unstated | unknown | — | "live online tutoring for K-12 schools" | K-12 data usually comes with student-privacy obligations, which affect contracts, access controls and on-call | `[generic]` ed-tech pattern, not a claim about Pellucid | What student-data privacy rules does the warehouse work under, and who owns compliance? | unresolved |
| RR5 | Equity unspecified | unknown | — | "plus equity" | Could be options or RSUs of any size, so it can't be valued yet | `[grounded]` JD gives no detail | What form and size of equity grant comes with this level, and what's the vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with what you built, in your own words: "Built our dbt project on Snowflake — about 180 models" and "set up our Great Expectations test suite" | See R4 and R6, the two closest matches to the JD's warehouse and testing lines | `[grounded]` your background | pending your approval |
| P2 | State the warehouse difference plainly: "Snowflake, not BigQuery." Don't let the CV imply BigQuery experience. | See R7 | `[grounded]` "Never used BigQuery" | pending your approval |
| W1 | Optional: build a small dbt + BigQuery sandbox project before the screen, so the R7 bridge has something to point at | See R7, G1 | `[generic]` warehouse switchers often get probed on this | pending your approval |
| Q1 | Ask the RR1, RR3, RR4 and RR5 verification questions in the recruiter or hiring-manager call | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Checked the pasted material. Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, "Accepting applications", text matches. Searched "Pellucid Learning online tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about): matches. This filled role reality's contradictions row and RR2. |
| 2. Role-family sweep | skipped | The Datawright 2026 report figures you supplied already fix the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there's nothing to search |

I can package all of this as a `tuesday-dossier.md` file for later turns, if that's useful.

## Upgrade menu

- **Your location, work authorization and pay minimum:** closes R1 and condition (2). The decision would likely firm up to `go` or `no_go`.
- **Answers to G2 and G3:** R8 and R9 move from `unclear`.
- **A sanitized dbt docs page, DAG screenshot or Great Expectations config:** R4 and R6 rise to `high`.
- **A small dbt + BigQuery repo:** strengthens R7's case.
- **The hiring manager's name, from the recruiter:** improves role reality's scope read and tells me which story to lead with for that reader.
- **A deeper research pass on Pellucid:** leadership changes, hiring patterns, employee reports and recent news, using up to 5 more searches and 2 more fetches. Say the word and it runs.

## Questions

**R1** — Are you based in the US, or able to work from Denver, without needing visa sponsorship, and is there a salary minimum below which you wouldn't move?

**G2** — In the payroll job, did you build or own any ingestion, such as pulling from your app's database, events, or a CRM or HR SaaS API, and which tool did you use?

**G3** — Have you ever agreed schema or freshness guarantees with analysts or upstream teams, and if so, how were they written down and enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.