Read the posting; now running quick checks on Quillfield, the market band for the role, and the hiring manager's public profile.
**Yes, it's worth going for, with conditions.** Two of the must-haves need careful handling: forecasting (R6) and billing/revenue data (R7). Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid, two office days a week), R2 (£61,500–£67,000 plus share options)
- `must_have`: direct: R3a, R4, R5a · adjacent: R6 (experience owning a forecast) · unclear: R3b (at a B2B software company), R5b (spreadsheet modelling), R7 (working with finance on billing or revenue data)
- `important`: direct: R8a, R9 · absent: R8b (own billing data)

R3a, R4, R5a, R8a, R9: your stated experience covers these directly; R6 (`medium`): a real bridge, but you need to say where it stops; R7: depends on whether you've worked on revenue data with finance, since you've ruled out billing; R8b: no billing-data evidence, so it's a gap to plan around.

**Opportunity ledger.** The company checks out and the pay is fair. Quillfield exists as described (RR5) and the salary sits inside the market band (RR4). Still open: I couldn't find the posting on Quillfield's own site (RR1). The role combines billing and forecasting work without saying what decisions it can make (RR2, RR3). And it states no measure of success (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two office days a week), R2 (£61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 work for you; (2) the recruiter confirms the role is live and comes directly from Quillfield (RR1); (3) you present R6 as adjacent: you run the pipeline review, you didn't own the forecast; (4) R7 is either backed by revenue-data work you did with finance (G2) or you name it openly as a gap.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) in April 2025 | `[grounded]` quillfield.co.uk/about, via search snippet |
| Mandate | Own the CRM and billing data. Build the pipeline and renewal reporting that sales and finance use. Run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Reporting line | Probably reports to Tamsin Achebe, Head of Revenue Operations | `[grounded]` her public profile gives that title; `[inferred]` that the Lead reports to her, from the recruiter naming her as hiring manager |
| Scope read | A "Lead" under an existing Head of RevOps, but the remit reaches into finance's territory (billing data, the CFO forecast) | `[inferred]` from the mandate wording against the company's size and the existing head-of-function role |
| Market calibration | UK B2B software RevOps Lead: median base £64,200, middle half £57,800–£70,400. The posting's range sits right in the middle of that | `[generic]` Ledgerline 2026 UK RevOps Pay Guide (n=438, UK-wide, not Bristol-specific, read from the search snippet only); `[grounded]` posting figure |
| First-90-days / first-year outcomes | Not stated | `[grounded]` posting is silent (RR6) |
| Unknowns | Who owns the billing system today. Who signs off the forecast number. What the share options are worth. Your location and pay floor | — |
| Contradictions | None between the posting and Quillfield's about page. The posting wasn't found on Quillfield's own site (RR1) | `[grounded]` searches and fetch below |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The posting states it. You haven't said where you're based or what you'll accept | `[grounded]` posting; your intake is silent | Closing question 3 |
| R2 | £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The posting states the range. Your pay floor isn't given | `[grounded]` posting | Closing question 3 |
| R3a | 4+ years in revenue ops / sales ops | must_have | direct | medium | none | 5 years of sales ops, the last 2 running RevOps for the UK team. You stated this, but nothing has been checked yet | `[grounded]` your intake | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | You describe your employer as a "B2B payments company". Whether it sells software isn't stated | `[grounded]` your intake wording | Describe the product in the CV header (see G4) |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You're Salesforce admin certified. That's checkable but hasn't been checked | `[grounded]` your intake | Optional: a credential verification link would raise this to high |
| R5a | Strong SQL | must_have | direct | medium | none | Weekly SQL use, stated. "Strong" isn't tested | `[grounded]` your intake | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" is usage. It doesn't say you've built models (drivers, scenarios) | `[grounded]` your intake | See G3 |
| R6 | Experience owning a forecast (the role runs the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | What carries over: you run the monthly pipeline review with the sales director, and that review feeds a forecast. The limit: you've never owned the company forecast; finance did | `[grounded]` your intake | See G1 |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You've ruled out billing. Revenue data (renewal values, bookings) shared with finance isn't established either way | `[grounded]` your intake | See G2 |
| R8a | Own the CRM data | important | direct | medium | none | Salesforce admin, and you rebuilt the pipeline and renewal dashboards | `[grounded]` your intake | none |
| R8b | Own the billing data | important | absent | none | capability | You said you've never worked on billing data | `[grounded]` your intake | Plan to close it: learn how a billing system's data fits together (invoices, credits, MRR movements) before interviews, and say plainly that this is new ground |
| R9 | Pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt both dashboards. Whether finance used them isn't stated | `[grounded]` your intake | Optional: a sanitized dashboard screenshot would raise this to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | Monthly pipeline review with the sales director. The company forecast sat with finance | The role runs the quarterly forecast with the CFO, so this is the core of the role and the gap most likely to be questioned | Giving commit or best-case calls in the pipeline review; checking those calls against what actually closed; supplying the pipeline or renewal numbers finance's forecast was built on | A sanitized pipeline-review deck; a call-versus-actual comparison | `[grounded]` your intake; `[generic]` that a must-have tied to the CFO gets probed |
| G2 | Revenue data with finance (R7, must_have) | discovery | Billing ruled out. Your renewal dashboards may involve contract values | Billing *or* revenue data meets this requirement, so revenue work could close the row | Reconciling bookings or renewal values against finance's figures; definitions of ARR or churn agreed with finance; month-end data requests from finance | A sanitized reconciliation or a definitions doc | `[grounded]` your intake; `[inferred]` that renewal dashboards may touch contract values |
| G3 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use, with no models described | Separates "uses Excel" from "builds models" | Capacity or quota models; renewal-risk scoring; territory or headcount scenarios | A sanitized model | `[grounded]` your intake |
| G4 | B2B software company (R3b, must_have) | discovery | "B2B payments company" | It's in the literal requirement, and a keyword screen may read it literally | Your employer sells a software platform or API, not only payment processing | Your company's own product description | `[grounded]` your intake; `[generic]` that screens read company type literally |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Quillfield's own site | unknown | — | Hosted on "Tallyboard Jobs" | It may only be advertised through the board or the recruiter. It could also be stale | `[generic]` pattern for small companies using job boards, not a claim about this one | Is this role currently open, and is it advertised anywhere on Quillfield's own channels? | unresolved |
| RR2 | Billing data bundled with CRM ownership | risk_signal | low | "own our CRM and billing data" | The role may also cover finance-systems work. Low because there's already a Head of RevOps above it | `[inferred]` from the mandate wording | Who owns the billing system today: does this role own the billing data's quality, or only the reporting on it? | unresolved |
| RR3 | Forecast authority unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build the forecast while the CFO owns the number | `[inferred]` from "with the CFO" | Who signs off the quarterly forecast number, and what does this role own in it? | unresolved |
| RR4 | Salary stated, within market band | positive_signal | — | "£61,500–£67,000 plus share options" | The pay is transparent and sits at market | `[grounded]` posting; `[generic]` band | What do the share options consist of: number, strike price, vesting? | noted |
| RR5 | Employer verifiable as described | positive_signal | — | "Quillfield" / invoicing | It's a real funded company matching the posting | `[grounded]` about page | — | noted |
| RR6 | No success measures stated | unknown | — | Posting lists duties only | Expectations for the forecast and reporting are undefined | `[inferred]` from the posting's silence | What would a successful first two quarters in this role look like? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV/summary wording: "Run the monthly pipeline review with our sales director; rebuilt our pipeline and renewal dashboards in Salesforce (admin certified). The company forecast was owned by finance." | See R6, R9. It uses your own sentences, says where the forecast experience stops, and doesn't claim forecast ownership | `[grounded]` your intake | resume_edits_pending_approval |
| A1 | Lead with R9 and R6's pipeline review; name R7/R8b as the area you'd learn fastest, not hide it | Tamsin Achebe's public profile shows four years in sales ops at a payments company, so she knows this background firsthand and will probe its limits | `[grounded]` her public profile; `[generic]` that interviewers probe gaps in their own home territory | pending your approval |
| A2 | Ask the recruiter about RR1, and confirm R1/R2 work for you, before investing in the process | See RR1, R1, R2 | `[grounded]` register | pending your approval |
| Q1 | Ask the RR2, RR3, RR4 and RR6 questions word for word in interviews | The register doubles as interview prep | `[grounded]` register | pending your approval |

Every row above, including E1's wording, is a proposal and needs your approval.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about). Searched "quillfield.co.uk careers Revenue Operations Lead": no results. Fetched quillfield.co.uk/careers: no page. This moved the Organization and Contradictions rows, RR1 and RR5 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B SaaS 2026", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). This moved the Market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). This moved the Reporting line row and A1 |

I can also put all of this into a `tuesday-dossier.md` file you can keep and add to later, if you'd like.

## Upgrade menu

- Your location and pay floor → closes R1 and R2, and the hard-gates line settles.
- Answers to G1 and G2 → R6's bridge firms up and R7 resolves. These two most affect how strong the application reads.
- A sanitized dashboard screenshot, pipeline-review deck or Salesforce credential link → R9, R6 and R4 rise toward `high`.
- Your employer's product description → resolves R3b (G4).
- A deeper research pass on Quillfield (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches) → would add to the risk register. Say the word and it runs.

## Questions

**G1:** In the monthly pipeline review, do you make a forecast call yourself (commit, best case), and have you ever compared those calls against what actually closed, or supplied the numbers finance built its forecast on?

**G2:** Setting billing aside, have you worked with finance on revenue figures: renewal values, bookings, ARR or churn definitions, or reconciling your dashboards against their numbers?

**R1/R2:** Do Bristol with two office days a week and £61,500–£67,000 both work for you?

For any of these you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.