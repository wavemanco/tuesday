Reading the skill's rules is done. Next I'll run one quick check that the Pellucid posting is live, then write up the assessment.
I'd apply. Your background matches every core requirement, and the pay sits at or above the market report your recruiter sent. Before you put in much effort, two things need settling: your location, and whether the posting is still live. I tried to check the posting online, but both web requests were declined, so it isn't verified yet.

## Decision snapshot

**Yes, it's worth applying to, if the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or our Denver office)
- `must_have` — direct: R2, R3, R4, R5, R7, R8
- `important` — adjacent: R6 (dbt-modelled warehouse in BigQuery) · unclear: R9 (ingestion from our app and CRM), R10 (the data contracts our analysts depend on)

R6: Snowflake carries over to BigQuery, but you have no BigQuery hours yet. R9 and R10: your background doesn't mention them either way, which is different from showing a gap.

**Opportunity ledger.** The terms look sound. The pay range is at or above market (RR2), and the company raised a Series C nine months ago (RR3). The open items are whether the posting is live (RR1), how big the team is (RR4), what the equity is (RR5) and who the hiring manager is (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 is met: you can work remotely from the US or from Denver; (2) the posting is confirmed live on Pellucid's own careers page (RR1); (3) R6 is presented honestly as Snowflake experience, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring for schools in 31 US states. Founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page as pasted |
| Mandate | Build and run the reporting pipelines: ingestion from the app and the CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | The JD describes the whole reporting path, from ingestion through to analyst contracts, not one domain. It doesn't say whether other data engineers share it | `[inferred]` from the mandate's breadth set against the JD saying nothing about team size |
| Market calibration | "Senior" at Series B–D usually means 5–8 years and owning one domain's pipelines with no direct reports. Base median is $151,000, interquartile range $139,000–$163,500. The posting's floor is above the IQR floor and its ceiling is above the IQR top | `[generic]` Datawright 2026 report, n=2,310, as pasted; `[grounded]` JD for the posted range |
| First-90-days outcomes | Not stated | — |
| Unknowns | Team size, hiring manager, equity terms, success measures, whether the posting is live | — |
| Contradictions | None found between the JD and the about page as pasted. The live pages weren't checked (see Evidence status) | `[grounded]` pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | `[grounded]` You haven't said where you're based or whether you're authorized to work in the US, so the gate isn't established either way | `[grounded]` JD; intake doesn't mention location | Closing question on R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | `[grounded]` You stated 6 years at a B2B payroll company. That's self-reported at intake, so `medium`. `[generic]` 6 years sits inside the 5–8 years the report gives for "Senior" | `[grounded]` intake message; `[generic]` pay report | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | `[grounded]` "Python and SQL daily". Specific, but nothing inspectable yet | `[grounded]` intake message | none |
| R4 | dbt | must_have | direct | medium | none | `[grounded]` "Built our dbt project on Snowflake — about 180 models" | `[grounded]` intake message | none |
| R5 | A cloud warehouse | must_have | direct | medium | none | `[grounded]` The JD asks for "a cloud warehouse", and Snowflake is one | `[grounded]` JD and intake message | none |
| R6 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | `[grounded]` "Never used BigQuery". The Snowflake and dbt work carries over. Limit: no hands-on BigQuery cost model, partitioning or clustering, or BigQuery-specific SQL | `[inferred]` requirement taken from the stack the JD names; `[grounded]` your statement | See G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | `[grounded]` "Airflow for orchestration" | `[grounded]` intake message | none |
| R8 | Data quality testing | must_have | direct | medium | none | `[grounded]` "I set up our Great Expectations test suite" | `[grounded]` intake message | none |
| R9 | Ingestion from the app and the CRM | important | unclear | none | discovery | `[grounded]` Your background doesn't say which sources you ingested or how | `[grounded]` JD; intake doesn't mention it | See G2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | `[grounded]` Your background doesn't mention contracts, SLAs or schema agreements with analysts | `[grounded]` JD; intake doesn't mention it | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Strong dbt-on-Snowflake work, no BigQuery | The JD names BigQuery as the stack, so the bridge needs a stated limit and something that narrows it | A dbt adapter switch or a cross-warehouse model you've done; reasoning about cost and clustering in Snowflake; a small personal dbt project on BigQuery's free tier | A public repo running dbt on BigQuery, even a small one | `[grounded]` your statement; `[generic]` that a hands-on sample narrows a warehouse-switch objection |
| G2 | App and CRM ingestion (R9, important) | discovery | Pipelines and orchestration are clear, but the sources aren't | It's the first part of the mandate, and a payroll company probably ingested from its own product and third-party systems | Ingesting from the payroll app's production database; pulling from a CRM such as Salesforce or HubSpot; Fivetran, Airbyte or custom extractors you set up | A pipeline diagram or a sanitized design doc | `[inferred]` that payroll work likely involved app and third-party sources |
| G3 | Data contracts (R10, important) | discovery | A test suite, but nothing on agreements with consumers | The JD names contracts as something analysts depend on. Great Expectations suites are often where those agreements get enforced | dbt model contracts or `schema.yml` constraints you enforced; agreed freshness SLAs; a schema-change process with analysts or upstream engineers | A sanitized contract spec, dbt `contract: enforced` configs, a runbook | `[generic]` that GE suites often enforce consumer agreements; `[grounded]` the JD's wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The posting may be stale or copied from somewhere else. Most likely it's simply live and I couldn't check it, because the web calls were declined. Funding and headcount are stated, which makes it less likely to be fake | `[generic]` pattern for companies of this size, not a claim about this one | Is this role still open, and who would I be interviewing with? | unresolved |
| RR2 | Posted range at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is transparent and competitive for the title | `[grounded]` JD; `[generic]` Datawright band | Where in the range do you expect to land someone with 6 years? | noted |
| RR3 | Recent Series C | positive_signal | — | "Series C ($52M, February 2026)" | Runway is likely to support the hire | `[grounded]` about page as pasted; `[inferred]` the runway reading | How is the data team's headcount planned over the next year? | noted |
| RR4 | Breadth of the mandate versus team size | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | If you'd be the only data engineer, the role is wider than the one-domain norm at this pay | `[inferred]` from the mandate against the `[generic]` scope norm | How many data engineers are there today, and which pipelines would I own? | unresolved |
| RR5 | Equity terms unstated | unknown | — | "plus equity" | Could be options of very different value | `[inferred]` from the posting giving no detail | What's the equity grant, its vesting schedule and strike basis? | unresolved |
| RR6 | No hiring manager named | unknown | — | (the posting names none) | Usual for a posting; it just leaves the reader unknown | `[generic]` common in postings | Who does this role report to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with "built our dbt project on Snowflake — about 180 models" in your own words | R4, R5 | `[grounded]` intake message | pending your approval |
| P2 | Put "set up our Great Expectations test suite" against "data quality testing" | R8 | `[grounded]` intake message | pending your approval |
| P3 | Say plainly that you haven't used BigQuery yet; don't list it as a skill | R6 | `[grounded]` your statement | pending your approval |
| W1 | Optional: a small public dbt-on-BigQuery repo to narrow the R6 limit | G1 | `[generic]` hands-on samples narrow a warehouse-switch objection | pending your approval |
| A1 | Open the posting on pellucidlearning.com yourself before applying | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions for RR1, RR4, RR5 and RR6 word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

Each row above is a proposal. None of it is final until you approve it, and that includes the positioning advice in P1–P3, not only the table.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Pellucid Learning online tutoring Denver Series C" and the fetch of pellucidlearning.com/careers/senior-data-engineer were both refused for lack of permission. A result would have confirmed the posting is live and cleared RR1 |
| 2. Role-family sweep | skipped | The pasted Datawright 2026 report already sets the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

---

I can save all this as `tuesday-dossier.md` if you'd like a copy to keep.

**Upgrade menu**
- Allow web access, or confirm yourself that the posting is live → RR1 clears, and conditional (2) drops out.
- Your location and work authorization → R1 settles.
- Your pay floor and any other non-negotiables → each one gets checked against the role's terms.
- Answers to G2 and G3 → R9 and R10 move off `unclear`.
- A dbt-on-BigQuery repo, or any inspectable work sample → R6 strengthens, and repo-backed rows can rise to `high`.
- The hiring manager's name → sharpens the scope read and which story you lead with.
- A deeper research pass on Pellucid (leadership changes, hiring patterns, employee reports, recent news), up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

R1 — Are you based in the US and authorized to work there without sponsorship? (Denver works too.)

G2 — At the payroll company, which sources did you personally build ingestion from, such as the product database or a CRM, and with what tooling?

G3 — Did any of your work set or enforce agreements with analysts, such as dbt contracts, freshness SLAs or a schema-change process, and which part was yours?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.