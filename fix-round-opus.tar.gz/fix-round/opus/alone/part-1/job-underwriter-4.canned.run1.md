Searches are back, and the employer's own careers page says the job is office-based, which contradicts the remote listing you pasted. I'm opening that page to confirm before I write this up.
# Should you apply? Senior Pricing Analyst at Brindlemoor

## Decision snapshot

**Yes, apply, as long as you're happy with the working pattern. Brindlemoor's own careers page contradicts the remote listing you pasted. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R6, R7 · unclear: R5 (Monitor rating models)
- `important`: adjacent: R8 (Our pet-insurance product) · unclear: R9 (Recommendations for product)
- `preferred`: direct: R10

R8: a credible bridge from motor, with its limit stated; R5 and R9: possible experience your summary didn't mention, one question each.

**Opportunity ledger.** The employer and the live posting check out (RR3), and the hiring manager's public talk is on the same work as the role (RR4). But the working pattern in your copy contradicts the employer's own page (RR1), and the salary isn't stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed and works for you (R1, RR1); (2) the pet-insurance bridge is framed honestly as adjacent, never as pet experience (R8); (3) the budgeted salary meets your floor (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, and make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page; name from you |
| Line management | None stated. "Own pricing analytics" describes the work, not a team, so never having managed anyone is not a requirement here | `[grounded]` JD silent on reports; `[inferred]` individual-contributor scope, from that silence |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, middle half £52,100–£64,900. This is market context, not Brindlemoor's offer, and the posting gives no salary (RR2) | `[generic]` Pricewell 2026 pay survey, n=612; `[grounded]` JD has no salary |
| Unknowns | Salary; the actual working pattern; how large the pet book is; whether product decisions sit with this role or only take its recommendations | — |
| Contradictions | Your copy says "Fully remote (UK)"; the careers page says "Leeds office four days a week" | `[grounded]` JD as pasted vs. careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The two sources disagree on the working pattern, and you haven't said what you need, so there's no stated constraint to grade | `[grounded]` JD vs. careers page; no constraint given | Question 1 below; RR1's question to the recruiter |
| R2 | 4+ years of pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific, but self-reported and nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily." Specific, but not inspected | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5 | Monitor rating models | must_have | unclear | low | discovery | You wrote "maintained", which could include performance monitoring but doesn't say so. Taking the weaker reading | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | See G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. Whether the design was yours or shared with underwriting isn't stated, so expect a probe on ownership | `[grounded]` your background | Be ready to say which parts of the design were yours |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Pricing for "our pet-insurance product" | important | adjacent | medium | transferability | What carries over: GLM rating, price testing, insurance pricing analytics. The limit: you've never worked on pet. `[generic]` Pet rating factors (breed, age, vet-cost trends) and claims patterns differ from motor | `[grounded]` your background, "never worked on pet insurance"; `[inferred]` requirement, from the product named in the mandate; `[generic]` motor vs. pet difference | See G3 |
| R9 | Turn results into recommendations for product | important | unclear | low | discovery | Recommendations to underwriting are covered by the quarterly review. Nothing yet on working with product teams | `[grounded]` your background is silent on product | See G2 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R5, must_have) | discovery | "Built and maintained" the young-driver GLM; nothing on tracking how it performed after launch | It's the only `must_have` row below `direct`, and it's the topic of the hiring manager's public talk (RR4) | Actual-vs-expected tracking by factor; drift or stability checks on the young-driver book; a monitoring dashboard or monthly pack; spotting a factor going off and deciding to refit | A sanitized monitoring pack, a dashboard screenshot with figures removed, a refit memo | `[grounded]` your wording; `[grounded]` the talk title |
| G2 | Recommendations to product (R9, important) | discovery | Underwriting audience confirmed; product audience not mentioned | The JD names product as a second audience | Price-test results that changed a product feature or excess level; input on a new cover tier; work with marketing or product on rate changes | A recommendation paper or deck with figures removed | `[grounded]` JD names product; `[grounded]` your background is silent |
| G3 | Pet-insurance knowledge (R8, important) | transferability | Strong motor pricing; no pet-insurance work | `[generic]` A move to a different line usually draws a question in interview | A small-book or thin-data modelling problem on young drivers; any non-motor line you've touched; reading you've done on pet pricing | A short, honest note on how you'd approach the first 90 days on a pet book | `[inferred]` bridge, from your young-driver work; `[generic]` that interviews probe it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts itself between sources | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One copy is out of date, or the version you pasted came from an aggregator that mislabelled it. Medium rather than high, because a stale copy is the likelier explanation | `[grounded]` both quotes; `[generic]` that aggregator copies drift | Is this role fully remote, or Leeds four days a week, and has that changed since it was posted? | unresolved |
| RR2 | Salary not stated | unknown | — | No salary in the JD or on the careers page | The figure may sit anywhere in or below the market band in role reality | `[grounded]` both sources silent; `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Employer and posting confirmed live | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | A real, current vacancy with a clear reporting line | `[grounded]` careers page fetched | How large is the pet book today? | noted |
| RR4 | Hiring manager's public work matches the mandate | positive_signal | — | Talk: "Small Books, Loud Errors", on monitoring rating models in small books, 2025 Insurance Pricing Forum | The "monitor" part of the role is a real priority, not boilerplate | `[grounded]` public profile; `[inferred]` priority, from the talk topic | How is model monitoring done on the pet book today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with "Built and maintained the GLM rating model for the young-driver book" and "Ran 14 price tests with the underwriting team in [year]", in your own words. Please fill in the year: "last year" could mean 2025 or the past 12 months | R4, R6 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Say plainly in your summary or cover note: motor pricing, no pet-insurance experience yet. Don't use "pet" in any sentence about your own past | R8 | `[grounded]` your background | pending your approval |
| A1 | Confirm the working pattern with the recruiter before you invest in the process | R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | If G1 turns up a real monitoring story, make it the lead example for this reader. If it doesn't, lead with the price tests | R5, RR4 | `[grounded]` talk title; `[inferred]` relevance to this reader | pending your approval |
| Q1 | Ask the RR1–RR4 verification questions word for word during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

Every line above is a proposal. Nothing goes on your CV or into a message until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). This confirmed the employer and live posting (RR3) and turned up the Leeds contradiction (RR1, R1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary 2026"; it returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). That gave the market band. Its address is a `.example` domain, so check the survey yourself before quoting the figure |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor"; it returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). That gave RR4 and A2. Also a `.example` address, so treat it as a lead until you've seen the profile yourself |

I can save all of this as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- **Your working pattern and pay floor:** R1 resolves, RR2 becomes a real check, and the status could change.
- **An answer to G1, and ideally a sanitized monitoring pack:** R5 moves, and R4 or R5 could rise to `high`.
- **An answer to G2:** R9 moves.
- **The recruiter's answer on remote vs. Leeds:** RR1 closes.
- **A deeper research pass on Brindlemoor** (funding, leadership turnover, hiring pattern, staff reviews, recent news; up to 5 more searches and 2 more fetches): just say the word.

## Questions

**R1:** Do you need fully remote, or would Leeds four days a week work for you?

**G1:** On the young-driver GLM, did you track how the model performed after launch, for example actual-vs-expected, drift checks or a monitoring pack, and what did you do when something went off?

**G2:** Has any of your pricing or price-test work gone to a product team as a recommendation, rather than to underwriting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.