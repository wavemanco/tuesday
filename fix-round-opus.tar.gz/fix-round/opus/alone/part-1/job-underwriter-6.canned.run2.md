Got the posting. Now checking the company, the market rate, and the hiring manager's public profile.
**Yes, it's worth going for, on the conditions below. Status: `conditional_go`.** Your sales-ops core (R3a, R4, R5a, R8, R10) matches what they ask for. The two real gaps are the forecast (R6) and billing data (R7, R9).

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two days a week in the office), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3a, R4, R5a · adjacent: R6 (Experience owning a forecast) · unclear: R3b (At a B2B software company), R5b (Spreadsheet modelling), R7 (Working with finance on billing or revenue data)
- `important`: direct: R8, R10 · absent: R9 (Own billing data)

R6: the forecast requirement, which your pipeline review only gets close to; R7, R9: billing is the second real gap, though R7 also accepts revenue data; R3b, R5b: unclear only because your background doesn't say yet.

**Opportunity ledger.** The company is real and the salary is stated and in line with the market (RR6, RR3). Still open: the forecast and billing mandate and the help that comes with it (RR1, RR4), the option terms (RR5), and the fact that the posting isn't on Quillfield's own careers page (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two days a week in the office), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1, R2: two days a week in Bristol and this salary range work for you; (2) R6: you describe the forecast honestly as adjacent work (you ran the pipeline review, finance owned the forecast); (3) RR1, RR4: interviews confirm the forecast and billing work comes with finance access and support; (4) RR2: the recruiter confirms the role is live.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield. Previously sales operations manager at Corvane Payments for four years | `[grounded]` recruiter, plus her public professional profile |
| Working pattern | Bristol, hybrid: two days a week in the office | `[grounded]` JD |
| Compensation | £61,500–£67,000 plus share options | `[grounded]` JD |
| First 90 days | Not stated. A quarterly forecast cycle probably comes up within your first quarter | `[inferred]` from "quarterly revenue forecast" |
| Scope read | About half sales ops (CRM, pipeline reporting) and half finance-facing (billing data, forecast with the CFO). Your experience is all on the first half | `[inferred]` from the JD's four responsibilities |
| Market calibration | UK B2B software RevOps lead: median base £64,200, middle 50% £57,800–£70,400 (n=438). The posted range sits inside that and straddles the median. This is a market band, not Quillfield's offer | `[generic]` Ledgerline 2026 UK RevOps Pay Guide; `[grounded]` JD for the posted range |
| Unknowns | Team and support behind the role; who owns the forecast today; which billing system; option terms | — |
| Contradictions | None between the JD and Quillfield's About page. The posting wasn't found on Quillfield's own careers page (RR2) | `[grounded]` quillfield.co.uk/careers fetched, returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or what you'll commute to | `[grounded]` JD; intake silent | Closing question on R1 and R2 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No salary floor given, so there's nothing to check the range against | `[grounded]` JD; intake silent | Closing question on R1 and R2 |
| R3a | 4+ years in revenue ops, sales ops or similar | must_have | direct | medium | none | 5 years in sales operations, the last 2 running UK revenue operations. Self-reported, nothing inspected yet | `[grounded]` intake | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | Your employer is a "B2B payments company". Whether it sells software isn't stated | `[grounded]` intake wording | G4 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certificate is checkable but hasn't been inspected | `[grounded]` intake | none |
| R5a | Strong SQL | must_have | direct | medium | none | "SQL weekly", stated plainly | `[grounded]` intake | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows heavy use but not modelling (drivers, scenarios, a forecast model) | `[grounded]` intake | G3 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director. You've never owned the company forecast; finance did. Pipeline review feeds a forecast without being one. Taken at the lower band, with that limit named | `[grounded]` intake, your own words | G1; closing question |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | No billing data, by your own account. The requirement also accepts revenue data, and renewal dashboards may involve revenue figures. Not stated either way | `[grounded]` intake; `[inferred]` that renewal work may touch revenue data | G2; closing question |
| R8 | Own the CRM data | important | direct | medium | none | Salesforce admin, and you rebuilt the pipeline and renewal dashboards on it | `[grounded]` intake | none |
| R9 | Own billing data | important | absent | none | capability | You've never worked on billing data, by your own account. No adjacent work stated | `[grounded]` intake, your own words | G5 closure path |
| R10 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them isn't stated | `[grounded]` intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | **Carries over:** a monthly pipeline review you run with the sales director. **Limit:** you've never owned the company number or presented it to a CFO. **Would help:** a sales-side commit call you made, or a one-page forecast model built as a work sample | This is a stated requirement and the JD has the role "run the quarterly revenue forecast with the CFO", so it's the claim most likely to be tested | Calling commit/best-case in the review; tracking how far called deals slipped against close dates; giving finance the pipeline input for their forecast | A sanitized pipeline-review deck, a commit-versus-actual sheet | `[grounded]` intake; `[inferred]` that this is the most-tested claim, from the JD's own wording |
| G2 | Finance on revenue data (R7, must_have) | discovery | No billing data. Nothing yet on revenue data with finance | A yes here would move R7 to adjacent or direct | Renewal values or ARR in your renewal dashboards; matching closed-won deals to finance's numbers; answering finance's questions about bookings | A dashboard screenshot with figures removed, a reconciliation sheet | `[grounded]` intake |
| G3 | Spreadsheet modelling (R5b, must_have) | discovery | "Excel daily", with no modelling stated | Separates spreadsheet use from modelling, which the forecast part of the role relies on | Capacity or quota models; renewal-rate projections; scenario sheets for the sales director | A model with figures removed | `[grounded]` intake; `[inferred]` link to the forecast |
| G4 | B2B software employer (R3b, must_have) | discovery | "B2B payments company" | A literal screen against "B2B software company" could filter you out if the CV doesn't say what the company sells | The company sells a platform, API or software product to businesses | Your current CV line | `[grounded]` intake; `[generic]` that title and industry wording gets screened literally |
| G5 | Billing data (R9, important) | capability | No billing work, by your own account | It's half of "own our CRM and billing data" | — closure path: learn how invoice and subscription data links to CRM records, e.g. a small reconciliation exercise on sample data | — | `[grounded]` intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Broad mandate, team and resources unstated | unknown | — | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The role may carry CRM, billing, reporting and the forecast without analysts or finance support | `[inferred]` from four responsibilities alongside no mention of a team | Who works on revenue operations and billing data today, and what does this role take over? | unresolved |
| RR2 | Posting not on Quillfield's own careers page | unknown | — | Tallyboard listing, "Revenue Operations Lead — Quillfield" | The careers page may live at another address, or the listing may be aggregated or stale. A named hiring manager who matches a real Head of RevOps makes this less likely to matter | `[grounded]` careers fetch returned no page; `[generic]` pattern for aggregated listings | Is this role still open, and is it the one Tamsin Achebe is hiring for? | reduced |
| RR3 | Salary stated and market-normal | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is transparent and inside the market band | `[grounded]` JD; `[generic]` Ledgerline band | — | noted |
| RR4 | Forecast accountability with no success measure | unknown | — | "run the quarterly revenue forecast with the CFO" | It's unclear who owns the forecast now and how accuracy will be judged | `[inferred]` from the JD's silence on measures | Who owns the forecast today, and how will forecast accuracy be judged in this role? | unresolved |
| RR5 | Share option terms unstated | unknown | — | "plus share options" | Option value can't be assessed without the grant size, strike price and vesting terms | `[grounded]` JD silence | What is the option grant, the strike price and the vesting schedule? | unresolved |
| RR6 | Employer established as described | positive_signal | — | "Quillfield, the invoicing software company" (your description) | The company exists and matches your description; funded in 2025 | `[grounded]` quillfield.co.uk/about | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with what you've told me: "rebuilt our pipeline and renewal dashboards" and "run the monthly pipeline review with our sales director" | see R10, R8, R6 | `[grounded]` intake, your words | pending your approval |
| P2 | Raise the forecast gap yourself, in your own words: "I run the monthly pipeline review with our sales director; finance owned the company forecast." Don't describe yourself as having owned or contributed to the forecast unless G1 confirms it | see R6, G1 | `[grounded]` intake | pending your approval |
| P3 | Say plainly that you haven't worked on billing data, and pair it with the G5 closure step | see R9, G5 | `[grounded]` intake | pending your approval |
| P4 | Make sure your CV says what your current company sells, if it's software | see R3b, G4 | `[grounded]` intake | pending your approval |
| P5 | Lead with the payments-company sales-ops context. Tamsin Achebe's public profile lists four years as sales ops manager at a payments company | see R3a, role reality | `[grounded]` her public profile; `[inferred]` that this context needs no translating for this reader | pending your approval |
| P6 | Ask the verification questions from RR1, RR2, RR4 and RR5 word for word during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

All of the language above is a proposal. Nothing goes on a CV or into an application until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers Revenue Operations Lead Bristol", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers: no page there. Moved the organization row, the contradictions row, RR2 and RR6 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B SaaS 2026 Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration and RR3. It gave pay only, no scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring-manager row and P5 |

## Next steps

I can write all of this up as a `tuesday-dossier.md` file whenever you'd like it.

**Upgrade menu**
- Your location, commute limits and salary floor: settle R1 and R2, which are the only things that could turn this into a no.
- An answer to G1 or G2: could move R6 or R7 and change the conditions.
- Your current CV: settles R3b and R5b, and lets me propose specific line edits.
- Your Salesforce certificate, or a dashboard screenshot with figures removed: raises R4, R8 or R10 from `medium` to `high`.
- A deeper research pass on Quillfield (leadership changes since the Series A, hiring patterns, employee reports, recent news), up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

R1, R2: Can you work two days a week in the Bristol office, on a salary in the £61,500–£67,000 range?

G1: In your monthly pipeline review, did you make a call on the number, like a commit or best case that the sales director or finance then used? What part of that was yours?

G2: Have you worked with finance on revenue figures, such as renewal values, ARR or matching bookings, even if not billing data? What did you own?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.