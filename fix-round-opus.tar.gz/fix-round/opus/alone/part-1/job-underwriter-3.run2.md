I'm reading the assessment rules, and next I'll run a quick check on the company.
**No, I wouldn't pursue this one. R1 and R2 are both hard gates and both fail. Status: `no_go`.** What feels off is real, and it shows up in the posting's own wording, not only in your constraints.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin 5 days a week), R2 (Base $70–85k)
- `must_have`: direct: R4, R5, R6 · unclear: R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops)
- `important`: adjacent: R11 (E-commerce enablement context), R12 (Team of one to start)

R1, R2: the decision rests here; R4, R5, R6: your core growth work matches; R7, R8, R9, R10: functions your background doesn't speak to yet.

**Opportunity ledger.** Leave your constraints aside and the posting still shows a pattern. Seven functions go to one person with no team or stated budget (RR3, RR4). The base looks low for the seniority it asks for (RR2). Hours are always-on (RR5), success metrics are undefined (RR6) and the equity has no number on it (RR7). I couldn't verify the employer (RR8). One entry runs the other way: you'd report straight to the CEO and be seen by the board (RR9).

- **Hard gates:** failed: R1 (On-site in Austin 5 days a week), R2 (Base $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would have to be different:** Novaline would have to offer the role fully remote from Portland **and** a base of at least $150k. Either change alone still leaves a failed gate. "No exceptions" (R1) and a $85k top (R2) are each a long way from that.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting; not checked independently (RR8) |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Team and resources | "A team of one to start"; no budget mentioned | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", equity not quantified | `[grounded]` posting |
| Scope read | The title says "Head of", but the job is a solo operator covering both marketing and sales ops. Leadership-level accountability with no one to lead | `[inferred]` from "team of one" next to the 7-function list and the board line |
| Market calibration | Not established. The role-family sweep was refused (Evidence status, row 2), so I have no band to set $70–85k against. The comparison below is with your floor, not with the market | — |
| Unknowns | Marketing and paid budget; equity size and terms; how success is judged in year one; whether a team will be hired, and when | — |
| Contradictions | None in the text itself. The tension is between "Head of Growth" with board exposure and a team of one at this base | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" (your hard constraint: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit, which is specific. The fit fails because the posting rules out any exception and you rule out relocating | `[grounded]` posting and your intake message | Surface it; only you or the employer changing terms resolves it |
| R2 | Base $70–85k (your hard constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The posting's top figure is $65k under it | `[grounded]` posting and your intake message | Surface it; equity can't replace base under your stated floor |
| R4 | 8+ years growth leadership | must_have | direct | medium | none | 9 years in growth, as growth lead and then Head of Growth at two companies. It stays `medium` because this is self-report at intake and the years in leadership titles aren't broken out | `[grounded]` your background as stated | none |
| R5 | Paid acquisition | must_have | direct | medium | none | You owned paid with a budget you controlled, and scaled $8M to $40M ARR over three years. Specific, but unprobed | `[grounded]` your background as stated | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle, deep in Braze | `[grounded]` your background as stated | none |
| R7 | SEO/content | must_have | unclear | low | discovery | Your background as stated doesn't mention it either way | `[grounded]` silence in your background | G1 |
| R8 | Brand and PR | must_have | unclear | low | discovery | Not mentioned | `[grounded]` silence in your background | G2 |
| R9 | Partnerships | must_have | unclear | low | discovery | Not mentioned | `[grounded]` silence in your background | G3 |
| R10 | Sales ops | must_have | unclear | low | discovery | Not mentioned. Both your companies were B2C subscription, where a sales function may not have existed | `[grounded]` your background; `[inferred]` that B2C subscription often has no sales team | G4 |
| R11 | Growth for an e-commerce enablement business, which likely sells to merchants | important | adjacent | medium | transferability | The bridge: subscription growth mechanics (acquisition, lifecycle, experimentation). The limit: nothing stated about B2B or merchant-facing buyers | `[inferred]` that "enablement" means a merchant-facing (B2B) buyer | G5 |
| R12 | "Team of one to start": hands-on execution across every channel | important | adjacent | medium | transferability | The bridge: your SQL, GA4 and Braze depth suggests you work hands-on. The limit: your recent roles led teams of 3–7 | `[inferred]` from tool depth versus team size | G6 |

## Gap recovery queue

These rows only matter for similar roles in future. None of them can move this decision.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | Nothing either way | Full-funnel Head of Growth postings bundle it | Owning an organic channel's targets; briefing writers; landing-page programs you tested | An organic traffic dashboard, a content calendar | `[generic]` that full-funnel growth roles often include SEO |
| G2 | Brand and PR (R8, must_have) | discovery | Nothing either way | Shows up in roles that put "brand" under growth | Launch campaigns, agency management, press for funding or milestones | A launch brief, press coverage | `[grounded]` silence in your background |
| G3 | Partnerships (R9, must_have) | discovery | Nothing either way | A frequent channel for enablement and platform businesses | Affiliate, co-marketing, integration or referral programs | A partner deck, program results | `[generic]` that platform businesses lean on partner channels |
| G4 | Sales ops (R10, must_have) | discovery | Nothing either way | Separates B2C growth leaders from B2B revenue leaders | Owning lead routing, CRM hygiene, or handoff from product-led growth to sales | A funnel or CRM pipeline report | `[inferred]` from the B2C context |
| G5 | Merchant-facing context (R11, important) | transferability | Strong B2C subscription mechanics; nothing B2B stated | Merchant buyers have longer cycles and different channels | B2B-adjacent experiments, an SMB tier, any merchant-facing work | A case writeup | `[generic]` that B2B and B2C funnels differ in cycle length |
| G6 | Solo execution (R12, important) | transferability | Hands-on tooling, but team-lead roles | Team-of-one roles test whether you can run channels yourself | Periods where you ran channels personally before or between hires | Queries or dashboards you built | `[inferred]` from tool depth versus team size |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The employer has ruled out flexing on location in advance | `[grounded]` posting wording | Is there any scenario where this role is fully remote? | confirmed |
| RR2 | Base far below your floor, and possibly below what the seniority asks (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside"; "8+ years growth leadership required" | The cash may be set for a mid-level operator while the job description asks for head-level years and board exposure. The market gap isn't established because the band check didn't run | `[grounded]` posting figures against your floor; `[inferred]` that the pricing doesn't match the years asked | What is the full cash range, and how was it benchmarked? | confirmed |
| RR3 | Several functions bundled into one role | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | The role may be several roles' worth of work at one person's cost. I rated it `medium` rather than `high` because early-stage generalist roles are common | `[inferred]` from the 7-function list; `[generic]` that early-stage roles are broad | Which two or three of these does the CEO expect results from in the first six months? | unresolved |
| RR4 | Responsibility without resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench" | You'd be accountable for all revenue with no team and no stated budget | `[inferred]` from the posting's silence on budget and hiring plans | What paid and tooling budget comes with the role, and when is the first hire approved? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Overtime is presented as part of the culture, not as an exception | `[grounded]` posting wording | How often did "when it matters" happen in the last quarter, and for whom? | unresolved |
| RR6 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You'd be judged by the board on targets that aren't defined yet | `[inferred]` from the end-to-end revenue mandate set against undefined metrics | What revenue or pipeline number would make year one a success? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The equity may or may not make up for the cash gap. Nothing in the posting tells you which | `[grounded]` posting gives no grant size or terms | What is the grant, as a percentage of fully diluted shares, with what vesting and strike price? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | low | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too small to have much public footprint, or the posting may be stale. Most small companies are simply small. Rated `low` because the decision is already `no_go` | `[generic]` pattern for companies this size, not a claim about this one | Can you point me to this role on your careers page, and who would I interview with? | unresolved |
| RR9 | Direct CEO reporting line, with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has real access to decision-makers | `[grounded]` posting | What decisions would this role make without the CEO's sign-off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | see R1, R2, RR1, RR2 | `[grounded]` map and register | pending your approval |
| A2 | If you'd like to be sure, send one note to the recruiter asking whether remote work and a base of $150k or more are possible. Spend nothing more on it unless both answers are yes | The only path that clears R1 and R2 | `[grounded]` RR1, RR2 | pending your approval |
| A3 | Watch for RR3–RR6 wording when screening future postings | Your "something feels off" picked up on this pattern | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Novaline e-commerce enablement startup Austin Head of Growth" and the permission was refused. It would have confirmed the company and whether the posting is live (RR8) |
| 2. Role-family sweep | unavailable | I searched "Head of Growth Series A startup base salary 2026" and the permission was refused. It would have placed $70–85k against a market band (RR2, market calibration) |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save this as `tuesday-dossier.md` if you'd like to keep it.

**What would add to this:**
- **Allowing web search:** confirms the company exists as described (RR8) and gives a market band to compare the pay against (RR2).
- **Answers to G1–G4:** sharpen your fit for other full-funnel Head of Growth roles. They won't change this decision.
- **A deeper research pass on Novaline**, covering funding, leadership turnover and employee reports (up to 5 more searches and 2 more fetches): say the word and it runs once search is allowed.

I have no questions this turn, because no answer could change the status.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.