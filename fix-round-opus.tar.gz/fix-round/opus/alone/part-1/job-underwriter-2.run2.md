Still working: I've read the evaluation method. Next I'll run a few quick searches to confirm Quartzline exists and to check what PM platform roles usually look like.
# Job Underwriting — Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, you're not wasting your time. The one row that could sink the application is R1b (3+ years under a PM title), a `must_have` you don't meet. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (PM-equivalent work under another title), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery) · absent: R1b (3+ years under a PM title)
- `important`: adjacent: R6 (Run discovery with integration partners), R7 (Write specs, drive delivery with two squads), R9 (Coordinate launches with sales and support), R10 (Own the roadmap) · unclear: R8 (Define and track adoption metrics)

R1b: absent, and the JD calls it a must-have; R2, R6, R7, R10: real bridges, each with its limit named; R5, R8: the CV says nothing, and one answer each could close them.

**Opportunity ledger.** The employer is not confirmed. My search to check Quartzline was refused, so nothing about the company has been verified (RR1). The posting doesn't state pay (RR2), location (RR3) or how much say this role has over the roadmap (RR5). One entry is good news: it names two engineering squads (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer check out (RR1). (2) Your application reaches someone who will read your PM-equivalent case instead of filtering on title (R1b, plan row A1). (3) You present R2 honestly as adjacent: you integrated APIs, you didn't own an API product.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline: B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header. Not confirmed independently (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; partner discovery; specs and delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD is silent |
| Scope read | A platform PM role with real engineering capacity. The partner-facing focus makes integration-partner discovery the core of the job, which is the work closest to Nadia's | `[inferred]` from the JD's responsibilities list |
| Market calibration | Not established. The role-family sweep couldn't run (search refused), and I won't supply a pay band from memory | — |
| Unknowns | Pay; location and remote policy; who sets roadmap priorities; reporting line; adoption targets | — |
| Contradictions | None inside the JD. No careers page was available to compare against | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management: PM-equivalent work done under another title | must_have | adjacent | medium | transferability | Seven years of requirements docs, scoping workshops, cross-team coordination with PMs, and quarterly roadmap-input sessions. All of it is product-adjacent. The limit: the PMs decided what got built, not Nadia | `[grounded]` resume as typed; not yet probed | see G4 |
| R1b | 3+ years of product management under a PM title | must_have | absent | none | capability | Nadia says she has never held a PM title. This is a stated fact, not a gap more information could close. It isn't a hard gate (it's an experience length, not a legal or credential bar), but titled-years requirements are often screened literally | `[grounded]` user's statement; `[generic]` that such requirements are often screened literally | Closure path: plan rows A1 and A3. Carry as a material risk |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ REST API integrations end to end, which covers the consumer side of an API platform in depth. The limit: she integrated the vendor's API and didn't own its design, versioning or roadmap | `[grounded]` resume | see G4 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs, and integration architecture across 30+ builds. The CV already says this in the JD's terms | `[grounded]` resume | Expect a technical probe. No other action |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | Coordinated her company's engineers, the client's engineers and PMs on custom builds | `[grounded]` resume | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The CV doesn't mention sales. Solutions engineers often work alongside sales, but that's a pattern, not her stated history | `[grounded]` CV silent; `[generic]` the SE–sales pattern | Q in closing block, if budget allows (see G3) |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The CV doesn't mention sprints, backlogs or squad rituals | `[grounded]` CV silent | Question G1 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly roadmap-input sessions collecting client feedback are partner discovery in practice. The limit: the feedback went to PMs, who turned it into decisions | `[grounded]` resume | see G4 |
| R7 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Wrote requirements documents and drove engineering through UAT to go-live. The limit: these were per-client custom builds, not a product backlog shared across customers | `[grounded]` resume | Work sample W1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The CV has no metrics. A memory lead from an earlier conversation suggests she built a request-triage tool that support agents adopted. It is unconfirmed and isn't evidence | `[grounded]` CV silent; memory lead only | Question G2 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Coordinated go-lives for 30+ integrations. The limit: a client go-live isn't a product launch involving sales and support | `[grounded]` resume | none beyond honest framing |
| R10 | Own the roadmap for the API platform | important | adjacent | medium | transferability | Provided structured roadmap input every quarter. The limit: she never owned prioritization or trade-offs | `[grounded]` resume | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Agile delivery (R5, must_have) | discovery | Nothing about how your engineering teams ran their work | A must-have that one sentence might close | Working in sprints with the vendor's engineers on custom builds; writing tickets or user stories for integration work; joining planning or retros | Ticket or story examples (sanitized), a sprint board screenshot | `[grounded]` CV silent |
| G2 | Adoption metrics (R8, important) | discovery | An unconfirmed memory lead about a triage tool support agents adopted; no numbers on the CV | Could be your one example of building something, getting it adopted, and measuring it, which is the core PM story | How many agents used it; what it replaced; whether you tracked usage or resolution time; who asked for it and who decided its scope | A screenshot, a usage figure you actually measured, an internal announcement | `[grounded]` CV silent; memory lead only |
| G3 | Sales stakeholders (R4b, must_have) | discovery | The CV doesn't mention sales | Part of a must-have | Pre-sales scoping calls; supporting deal-stage technical questions; handing off from sales at contract signature | Any deal-support note or handoff document | `[grounded]` CV silent |
| G4 | PM-equivalent bridge (R1a, R2, R6, R7, R10) | transferability | Strong integration-side work; product decisions sat with PMs | Together these rows are the case that answers R1b | Did any roadmap input you gathered ship as a product feature? Does the playbook count as a product you defined, wrote and got adopted? | Sanitized roadmap-input summary, the playbook's table of contents, a requirements doc | `[grounded]` resume; `[inferred]` that these together make the case against R1b |
| G5 | Titled PM years (R1b, must_have) | capability | Zero years under a PM title, by your own statement | Wording can't fix this, and it may filter you out before anyone reads further | — | — | `[grounded]` user's statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may simply have a small footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. No check could run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Quartzline's careers page, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (JD has no pay line) | The figure may be below what an experienced SE earns now, or the company may just not publish pay | `[inferred]` from the JD's silence | What's the budgeted salary range for this role? | unresolved |
| RR3 | Location and remote policy not stated | unknown | — | (JD has no location line) | Could conflict with constraints you haven't told me | `[inferred]` from the JD's silence | Is this role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Named engineering resources | positive_signal | — | "drive delivery with two engineering squads" | The role has people to build with, not just a mandate | `[grounded]` JD | How are the two squads split across the platform? | noted |
| RR5 | Roadmap authority unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | Roadmap priorities might actually be set by sales commitments to partners | `[inferred]` from "own" against no mention of decision rights | Who decides what the API roadmap prioritizes, and how are partner requests from sales handled? | unresolved |

## Application plan

**Everything in this section, the table and any wording, is `resume_edits_pending_approval`: proposed, not final until you approve it.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with: "Led 30+ client integrations of our REST APIs end to end — scoping workshops, requirements documents, integration architecture, UAT, go-live." Don't claim "product management" or "owned roadmap" | R2, R3, R7. Your own sentence, unchanged | `[grounded]` resume | pending your approval |
| E2 | Move "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Wrote the internal integration playbook the whole team uses" into the top three bullets | R6, R10, R1a: the most product-shaped lines you have, worded as you wrote them | `[grounded]` resume | pending your approval |
| A1 | Get a referral or contact the hiring manager instead of applying only through the form | R1b: a person reading the case beats a title filter | `[generic]` how titled-years screens often work, not a fact about Quartzline | pending your approval |
| A2 | Interview framing: "I haven't held the PM title. Here's the product work I've done from the integration side, and here's where the PM made the call instead of me." | R1a, R2, R10: naming the limits holds up better under a probe than overreaching | `[grounded]` the map's adjacent rows | pending your approval |
| W1 | Optional work sample: a one-page spec for a partner-facing API improvement drawn from integration pain you've actually seen | R7, R2 | `[grounded]` resume | pending your approval |
| A3 | In parallel: an internal move to PM at your current vendor, or "technical/partner PM" postings with lower titled-years bars | R1b's closure path: a PM title, even briefly, removes the filter | `[generic]` common SE-to-PM pivot routes | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3, RR4 and RR5 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a memory from an earlier conversation about an internal request-triage tool that support agents adopted. It's unconfirmed and only the basis for question G2.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform Series B". The call was refused (search permission not granted). It would have checked RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Searched "product manager platform APIs B2B SaaS Series B salary scope solutions engineer transition". The call was refused. It would have filled market calibration and compared pay against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search |

I can save all of this as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- **Allow web search:** targets 1 and 2 run. RR1 closes or escalates, and role reality gets a market pay band.
- **The live posting link or the recruiter's email domain:** RR1 closes without a search.
- **Your non-negotiables (pay floor, location):** hard-gate checks against RR2 and RR3 become possible.
- **The playbook's table of contents, or a sanitized requirements doc:** R1a, R7 and R6 can move from `medium` toward `high`.
- **The hiring manager's name:** sharpens the scope read and tells me which story to lead with.
- **A deeper research pass on Quartzline** (funding, leadership churn, hiring patterns, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs once search is allowed.

## Questions

**G2:** Is the triage tool real as I remember it? What did you build, who used it, what did you decide versus what was decided for you, and did you measure anything?

**G1:** Did your engineering teams work in sprints or a similar agile setup, and what was your part in it (writing stories, joining planning, accepting work)?

**Constraints:** Do you have a pay floor or a location/remote requirement this role would need to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.