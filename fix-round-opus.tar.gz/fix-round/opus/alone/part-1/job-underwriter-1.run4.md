I've read the skill's rules. Next I'll run a few searches to check that Harborlight Health is real and to see what similar roles usually look like.
I'd apply. You meet every must-have, but two things need confirming before you put real effort in: that Harborlight Health is what the posting says it is, and what it pays. My two web searches (one on the company, one on market pay) were refused by permissions, so everything here comes from the job description (JD) and your summary of your background.

## Decision snapshot

**Yes, you're a fit and it's worth applying. R1, R2, R3, R4 and R5, every `must_have` row, are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R7a (Partner with product managers on roadmap decisions), R7b (Partner with clinicians) · unclear: R6 (Define and maintain the metrics layer), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience (HIPAA))

R6, R8 — your summary doesn't mention them; one answer each could settle them; R7b, R9 — honest bridges from consumer data, with their limits named.

**Opportunity ledger.** Unverified rather than unsound. The employer couldn't be checked (RR1), pay isn't in the posting (RR2), and the testing constraints and success measures are unknown (RR4, RR5). One entry points the other way: the team and tooling are named (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting check out (RR1); (2) the pay meets your floor (RR2); (3) R9 is described as adjacent privacy work, never as HIPAA or healthcare experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health: digital-health scale-up, about 400 people, Series C | `[grounded]` JD header; not checked independently (RR1) |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, self-serve dashboards in Looker, turning analysis into roadmap decisions | `[grounded]` JD |
| Team and resources | Two junior analysts to mentor; Looker is the BI tool | `[grounded]` JD |
| Stakeholders | Product managers and clinicians | `[grounded]` JD |
| First-90-days outcomes | Not stated. Likely: take over or rebuild the metrics layer and set up the testing process | `[inferred]` from "define and maintain the metrics layer" next to "design and analyze A/B tests" |
| Scope read | A normal senior individual-contributor mandate with light mentoring, not a manager role | `[inferred]` from "mentor" (not "manage") and a team of two juniors; `[generic]` that "Senior Product Analyst" usually means this |
| Market calibration | Couldn't be set: the pay search was refused. No band is given here | — |
| Unknowns | Pay; reporting line; success measures; which parts of the app can be A/B tested and what review a test needs; work location and arrangement | — |
| Contradictions | None inside the pasted JD; not checked against the company's careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years of product analytics against a 5-year bar. Self-reported, so `medium` until probed | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse, plus building a governed Looker instance on top of it. "Expert" is the employer's word, and a live SQL screen will test it | `[grounded]` your background; `[generic]` that senior analyst loops usually include a live SQL exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran an experimentation program running 30+ A/B tests a year across about 2M subscribers, including the pricing test behind an 11% retention lift. This is your strongest row | `[grounded]` your background | none — a sanitized test write-up would raise it to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. Same tool the JD names | `[grounded]` your background | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your background | none — a redacted memo excerpt would raise it to `high` |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" suggests you defined shared metrics, but your summary doesn't say you owned metric definitions or a LookML/semantic model. Taking the lower band rather than assuming it | `[inferred]` from "governed" and "from scratch" | Gap queue G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | Monthly VP Product presentations and a pricing test that produced a retention lift show your analysis reaching decisions. Day-to-day PM partnership isn't stated | `[grounded]` your background | Raise in interviews with a specific test-to-launch story |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | You communicate with non-technical execs, but haven't worked with clinicians. Limit: clinicians weigh evidence by clinical standards, and none of your work tested that | `[grounded]` you said you have no healthcare work; `[generic]` that clinical stakeholders hold analysis to evidence standards different from commercial ones | Gap queue G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your summary says nothing about mentoring or managing anyone | `[grounded]` your summary doesn't mention it | Gap queue G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You've handled GDPR/CCPA consumer PII and built the warehouse's consent-state model. That's real privacy-engineering work. Limit: it isn't HIPAA. Protected health information (PHI) comes with its own rules: de-identification standards, "minimum necessary" access, and contracts with vendors who handle the data | `[grounded]` your background; `[generic]` HIPAA's PHI rules as a regime | Gap queue G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | A Looker instance with "governed" dashboards; no explicit ownership of metric definitions | It's the first responsibility the JD lists, and confirming it moves R6 to `direct` | Writing the LookML model or explores; defining canonical metrics (active subscriber, churn, retention cohorts) that every dashboard shares; settling disputes between teams' versions of a number; dbt or Snowflake views feeding Looker | A sanitized LookML snippet, a metric-definitions doc, or a data-dictionary page | `[inferred]` from "governed"; `[inferred]` that confirming it moves the row |
| G2 | Mentoring juniors (R8, important) | discovery | Nothing either way | A JD responsibility with no evidence; an interview will ask for an example | Onboarding a new analyst; reviewing others' SQL or test designs; running an experimentation review or office hours; being a go-to reviewer for analysts outside your team | A review checklist, onboarding doc, or a manager's feedback note | `[grounded]` your summary doesn't mention it; `[generic]` that mentoring requirements get probed with "tell me about a time" questions |
| G3 | Clinician partnership (R7b, important) | transferability | Exec and VP-level communication; no clinical stakeholders | The bridge holds for clarity and influence, not for clinical evidence standards | Working with any domain-expert group that pushed back on method (food safety, nutrition, ops); explaining test limits to sceptical stakeholders | A memo section where you set out caveats or limits | `[grounded]` you said you have no healthcare work |
| G4 | HIPAA (R9, preferred) | transferability | GDPR/CCPA PII and a consent-state model | Preferred only, so it helps you stand out but won't block you; the honest version is "privacy-by-design in the warehouse" | Access controls, data masking, deletion/DSAR handling, consent propagation into analytics | A sanitized diagram or description of the consent-state model | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be exactly as described. The check couldn't run because the searches were refused, so this records an unchecked employer, not a missing one. Kept at `medium` rather than `high` despite the missing pay (RR2), because a paste can drop the pay line | `[generic]` pattern for unverified postings, not a claim about this one | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no pay figure in the posting) | Pay may have been left out of the copy you pasted, or the employer may not publish it | `[inferred]` from the pasted JD's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Team and tooling named | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The resources are real and match your stack | `[grounded]` JD | How are the two junior analysts' time split today? | noted |
| RR4 | No success measures for the mandate | unknown | — | "Own product analytics for our care-navigation app" | Ownership is broad, and the JD doesn't say what success looks like | `[inferred]` from the JD's scope against its silence on outcomes | What would make this hire a success at 90 days and at a year? | unresolved |
| RR5 | How far experimentation can go in a care product | unknown | — | "design and analyze A/B tests" | Some care-related surfaces may need clinical or compliance review before a test, which would cap how many tests can run | `[generic]` pattern in health products, not a claim about this one | Which parts of the app can be A/B tested, and what review does a test go through? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Open with the experimentation program: "Designed and ran an experimentation program of 30+ A/B tests a year, including the pricing test behind an 11% retention lift." The 30+ figure counts the program's tests; the lift belongs to the pricing test | see R3 | `[grounded]` your own words | pending your approval |
| P2 | Second, building the Looker instance from scratch (40+ governed dashboards). Say "metrics layer" only if G1 confirms you owned the definitions | see R4, R6 | `[grounded]` your background | pending your approval |
| P3 | Describe the privacy work as "GDPR/CCPA consumer PII; built the warehouse consent-state model". Never "HIPAA" or "healthcare data" | see R9 | `[grounded]` your background | pending your approval |
| P4 | Before the full loop, confirm with the recruiter that the role is live and what the pay range is | see RR1, RR2 | `[grounded]` register | pending your approval |
| P5 | Ask the RR4 and RR5 questions word for word in the loop; RR5 decides whether your strongest skill gets used | see RR4, RR5 | `[grounded]` register | pending your approval |

Every line above that you'd say or write (P1–P3) is a proposal and waits for your approval, the advice in this table included.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Harborlight Health care navigation app" was refused by host permissions. It would have moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary 2026" was refused by host permissions. It would have moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you'd like, I can write all of this into a `tuesday-dossier.md` file you can keep and bring to later steps.

**Upgrade menu**
- Allow web search → targets 1 and 2 run: RR1 can clear and a pay band gets set.
- The live posting link or the recruiter's email domain → RR1 clears.
- The pay range, plus your floor, location and work-authorization constraints → the hard-gates line gets checked against you, and RR2 closes.
- A sanitized LookML snippet or metric-definitions doc → R6 to `direct`.
- A redacted metrics memo or test write-up → R3 and R5 to `high`.
- The hiring manager's name → the scope read, and which of your stories to lead with.
- A deeper research pass on Harborlight Health (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

When you get to interview prep, the mock-interview skill handles rehearsal.

**Questions**

G1: Did you personally define the shared metrics behind those governed dashboards, for example by writing the LookML model or a canonical metrics doc that settled competing numbers?

G2: Have you onboarded, reviewed or coached other analysts, even informally? Who, and what did you do?

Constraints: What's your pay floor, and do you have location, remote or work-authorization requirements I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.