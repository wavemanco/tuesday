I've read the skill's method. Next I'm running the default light research pass: checking that Brindlemoor and the posting exist, then market norms, then Odile Varga's public profile.
**Yes, apply. Your background fits this role closely. Before you put time into it, check whether it is really remote. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK) working pattern), R2 (Based in the UK for a UK-remote role)
- `must_have`: direct: R3, R4, R5, R6, R7a, R8 · unclear: R7b (Monitor rating models)
- `important`: adjacent: R10 (Pet-insurance product knowledge) · unclear: R9 (Recommendations to underwriting and product)
- `preferred`: direct: R11

R7b is the only `must_have` row below `direct`; R10 is a bridge from motor, with its limit stated; R9's product side has no evidence yet; R5 (`medium`) holds your strongest claim, and one document would back it.

**Opportunity ledger.** The role is real and the posting is live (RR3). But the posting and the company's own careers page disagree on where you'd work (RR1). Pay isn't stated (RR2), and the company's size and stage aren't established (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK) working pattern), R2 (Based in the UK for a UK-remote role); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed and suits you (R1, RR1); (2) you're UK-based (R2); (3) you frame pet insurance honestly as a new product for you, with motor pricing carrying over (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, which describes itself as an insurtech with a pet-insurance product | `[grounded]` JD; careers page on brindlemoor.co.uk confirms the pet product |
| Mandate | Build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` careers page and your message |
| People management | The JD asks for none. "Senior" here has no line-management requirement, so not having managed anyone isn't a gap against this posting | `[grounded]` JD lists no management requirement |
| Scope read | A senior individual-contributor pricing role covering one product from start to finish. That is ordinary scope for the title, not several jobs bundled into one | `[inferred]` from the JD's mandate against its requirements |
| Hiring manager | Public profile: spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books; previously head of pricing analytics at Calloway Re for six years | `[grounded]` profile search snippet (not fetched) |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, middle half £52,100–£64,900. That's what to expect, not this employer's offer | `[generic]` Pricewell 2026 pay survey (n=612) |
| Unknowns | Salary; company stage, size and funding; how big the pet book is; whether "product" means a product team that acts on pricing recommendations | — |
| Contradictions | The JD says "Fully remote (UK)"; the live careers page says "Leeds office four days a week" | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working pattern | hard_gate | unclear | none | hard_gate | The employer's own sources contradict each other (RR1), and you haven't said what working pattern you need. That leaves the gate unsettled from both sides | `[grounded]` JD against careers page; no constraint stated | Closing question on R1/R2; RR1's question to the recruiter |
| R2 | Based in the UK for a UK-remote role | hard_gate | unclear | low | hard_gate | You work at a UK motor insurer, which suggests UK residence but doesn't state it. "(UK)" in the JD implies the location requirement | `[inferred]` from "Fully remote (UK)" and your current employer | Folded into the R1/R2 closing question |
| R3 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years in pricing analytics, the last 2 as senior analyst. It's specific, but from your prose with nothing to inspect yet, so it can't go above `medium` | `[grounded]` your message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily." Specific but self-reported | `[grounded]` your message | none |
| R5 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book." A direct match. Documentation would raise it to `high` | `[grounded]` your message | Upgrade menu: sanitized model documentation |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | "I present the quarterly pricing review to the head of underwriting." Matches the requirement as written | `[grounded]` your message | none |
| R7a | Build rating models | must_have | direct | medium | none | You built the young-driver GLM | `[grounded]` your message | none |
| R7b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include monitoring, but it doesn't say so. Read conservatively, monitoring isn't established yet | `[grounded]` your wording; `[inferred]` that maintaining may have included monitoring | Gap queue G1 |
| R8 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team." Running tests covers the requirement. Who designed them is open, so don't write "designed" until you confirm it | `[grounded]` your message | Keep to "ran" in any application text unless you confirm design |
| R9 | Turn results into recommendations for underwriting and product | important | unclear | low | discovery | The underwriting side is evidenced through R6. No product-team audience is mentioned | `[grounded]` your message is silent on product | Gap queue G2 |
| R10 | Pet-insurance product knowledge | important | adjacent | medium | transferability | GLM rating, price testing and book monitoring carry over from motor. What doesn't carry over: you haven't priced pet's risk factors (breed, age, claims patterns), and you've said so yourself | `[inferred]` requirement from "own pricing analytics for our pet-insurance product"; `[grounded]` that you haven't worked on pet | Gap queue G3 |
| R11 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R7b, must_have) | discovery | "Built and maintained", with no description of monitoring | R7b is the only must-have below `direct`; confirming it makes every must-have direct | Actual-vs-expected tracking on the young-driver book; drift or stability checks; deciding when to refit; flagging a factor that stopped behaving | A sanitized monitoring pack, an actual-vs-expected chart, a refit decision note | `[grounded]` your wording; `[grounded]` the hiring manager has spoken publicly on rating-model monitoring |
| G2 | Recommendations to product (R9, important) | discovery | Underwriting is the only audience evidenced | The JD names two audiences, and product is half of R9 | A price-test result that changed a product feature, a cover tier or an excess option; working with marketing or product owners on a launch price | A sanitized test readout or recommendation paper | `[grounded]` the JD names both audiences |
| G3 | Pet-insurance knowledge (R10, important) | transferability | Motor pricing only | The posting is single-product, so the domain gap is the obvious one an interviewer would see | Any non-motor book you've touched; what you already know about how pet pricing differs, read up before applying | A short note on how you'd approach a pet rating structure, as a possible work sample | `[inferred]` bridge from motor GLM work; `[generic]` that a domain switch gets probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The posting and the careers page contradict each other on working pattern | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One copy may be stale, or the role may have changed after the posting went out. Rated medium, not high, because you haven't said whether remote is a must for you | `[grounded]` both texts; `[inferred]` the causes | Is this role fully remote, or based in Leeds four days a week, and has that changed since the ad went out? | unresolved |
| RR2 | Salary not stated | unknown | — | (no figure in JD) | The figure may sit anywhere in or outside the market band in role reality | `[inferred]` from the missing figure, against the `[generic]` band | What base salary range is budgeted for this role? | unresolved |
| RR3 | Live posting on the company's own domain, with a named and publicly visible hiring manager | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | The employer exists and is hiring for this role now | `[grounded]` careers page fetched; profile snippet | How large is the pet book today, and how is the pricing team staffed? | noted |
| RR4 | Insurtech stage and size not established | unknown | — | "Brindlemoor (insurtech)" | A search on the company's description returned nothing. Small companies often have thin footprints | `[generic]` pattern, not a claim about Brindlemoor | What stage is Brindlemoor at, and how many people are in pricing? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the remote-vs-Leeds question with the recruiter or Brindlemoor before writing the application | RR1, R1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with "built and maintained the GLM rating model for our young-driver book" and "ran 14 price tests last year with the underwriting team", in your own words. If G1 confirms monitoring work, put it up front: it is the topic of Odile Varga's public talk | R5, R7a, R8, R7b | `[grounded]` your message and the talk title | pending your approval |
| P2 | Present pet insurance as a new product with transferable pricing method. Don't claim pet-insurance knowledge | R10 | `[grounded]` your statement that you haven't worked on pet | pending your approval |
| P3 | Don't raise "never managed anyone" as a weakness. The JD doesn't ask for it | Role reality, people management row | `[grounded]` JD | pending your approval |
| Q1 | Ask the RR1, RR2, RR3 and RR4 questions word for word in early conversations | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results, so company stage and size are not established) and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved: the contradictions row, RR1, RR3, RR4 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary remote 2026", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. Moved: the hiring manager row and P1 |

I can save all of this as a `tuesday-dossier.md` file you can reuse later, if you'd like.

**Upgrade menu**

- Your CV: checks every row against what an application screen will actually see, and finds any presentation gaps.
- A sanitized model documentation pack or monitoring report: raises R5 and R7a to `high`, and could close R7b.
- A sanitized price-test readout: raises R8 to `high` and may close R9.
- Your working-pattern needs and location: settles R1 and R2, which turns the decision into `go` or `no_go`.
- A deeper research pass on Brindlemoor (funding, leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): settles or sharpens RR4. Say the word and I'll run it.

**R1, R2:** What working pattern can you take on from where you live: fully remote only, or Leeds four days a week as well?

**G1 (R7b):** Once the young-driver GLM was live, what did you personally do to monitor it (for example actual-vs-expected tracking, drift checks, deciding when to refit), and is there a sanitized version you could show?

**G2 (R9):** Has any of your price-test work gone to product people as well as underwriting, and what changed because of it?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.