Reading the skill's rules is done. Next I'm checking that the posting is still live, then I'll write up the assessment.
**Yes, it looks worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office)
- `must_have` — direct: R2, R3, R4a, R4b, R6, R7
- `important` — adjacent: R5 (BigQuery as the warehouse) · unclear: R8 (Ingestion from app and CRM), R9 (Data contracts analysts depend on)

R5: you can bridge from Snowflake, but say plainly what it doesn't cover; R8, R9: duties in the posting that your background doesn't speak to yet.

**Opportunity ledger.** The employer and the posting both check out (RR2). The posted pay sits at or above the market band you were sent (RR1). Still open: the reporting line and scope (RR3), the equity terms (RR4) and how student data is handled (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work from the US or Denver (R1); (2) the scope turns out to be ownership of one domain, which fits the title (RR3); (3) you describe R5 honestly as Snowflake experience and never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016 in Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` about page, matches what you pasted |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Stated requirements | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; remote (US) or the Denver office | `[grounded]` JD |
| Scope read | Reporting pipelines for one platform, with no direct reports mentioned: one domain, not a whole data function | `[inferred]` from the mandate's single focus (reporting) and its silence on managing people |
| Market calibration | The report defines Senior as 5–8 years, owning one domain's pipelines, no direct reports. Its base is a $151,000 median with an interquartile range of $139,000–$163,500. This posting's title, years and scope match that pattern, and its band runs from $9,000 above the 25th percentile to $2,500 above the 75th percentile | `[generic]` Datawright 2026 report (pasted), a market pattern and not this employer's offer; `[grounded]` JD for the posted figures |
| First 90 days / first year | Not stated | — |
| Unknowns | Hiring manager and reporting line; how mature the data contracts are (exist or still to be built); equity terms; student-data handling requirements | — |
| Contradictions | None. The live careers page and the about page match what you pasted | `[grounded]` both pages read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you work from, so the gate isn't established yet | `[grounded]` JD terms; your background is silent on location | Closing question on R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. That's specific but not yet probed, and `medium` is the most a first pass gives | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", self-reported | `[grounded]` your background | none |
| R4a | dbt | must_have | direct | medium | none | You built the dbt project yourself, about 180 models. Specific, but nothing inspectable yet | `[grounded]` your background | A sanitized model graph or project README would raise this to high |
| R4b | A cloud warehouse | must_have | direct | medium | none | Snowflake meets "a cloud warehouse" as the requirement is written | `[grounded]` your background against the JD's wording | none |
| R5 | BigQuery specifically (the stated warehouse) | important | adjacent | medium | transferability | dbt-on-Snowflake carries over: modelling, testing, the dbt workflow. You haven't worked with BigQuery itself, so name that wherever you make the bridge. `[generic]` The warehouse-specific differences are mostly cost and partitioning models, not a different discipline | `[inferred]` requirement taken from the responsibilities line, not the requirements list; `[generic]` on the size of the difference | see gap queue G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, self-reported | `[grounded]` your background | none |
| R7 | Data quality testing experience | must_have | direct | medium | none | You set up the Great Expectations suite, which is ownership, not just use | `[grounded]` your background | none |
| R8 | Ingestion from an app and a CRM | important | unclear | low | discovery | You describe the dbt and orchestration work but not where the data came from or who built the ingestion | `[grounded]` your background is silent on ingestion | Closing question G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is nearby, but contracts with consumers (schemas, SLAs, change management) aren't mentioned | `[grounded]` your background is silent on contracts; `[inferred]` closeness to the test-suite work | Closing question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery as the warehouse (R5, important) | transferability | dbt on Snowflake at real scale; no BigQuery | Carries over: dbt modelling, testing, the Airflow-dbt workflow. Limit: no hands-on BigQuery cost, partitioning or slot experience. Strengthener: a small public dbt-on-BigQuery project | Any GCP exposure at all; Snowflake cost or clustering tuning you did yourself | A short repo running a few of your model patterns on BigQuery | `[grounded]` your background; `[generic]` that a stated warehouse is a common screening filter |
| G2 | Ingestion from app and CRM (R8, important) | discovery | Your background starts at the warehouse | Half the mandate is ingestion; your answer decides whether this becomes `direct` | Pulling product-database or event data into Snowflake; CRM or HRIS/payroll-system extracts (Salesforce, HubSpot, Fivetran, custom Python loaders); handling schema changes upstream | A DAG description, a loader repo, an architecture diagram | `[grounded]` your silence on ingestion; `[inferred]` that payroll products have comparable source systems |
| G3 | Data contracts (R9, important) | discovery | Data quality tests that you own; nothing about agreements with consumers | Named in the mandate; it could become a differentiator or stay a gap | Agreeing schemas or freshness SLAs with analysts; source/exposure definitions in dbt; breaking-change alerts or a review process for model changes | A contract spec, a dbt exposures file, an incident write-up | `[grounded]` your silence on contracts; `[inferred]` closeness to the Great Expectations work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, and at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The band's midpoint ($157,000) is above the report's $151,000 median; this is open pay, not a lowball | `[grounded]` JD figures; `[generic]` Datawright band | Where in the band do you expect a 6-year candidate to land? | noted |
| RR2 | Employer and posting verified, recently funded | positive_signal | — | "Series C ($52M, February 2026)" | A real entity matching its description, with the posting live ("Accepting applications") | `[grounded]` careers and about pages read | How is the data team's headcount planned after the Series C? | noted |
| RR3 | No hiring manager or reporting line named | unknown | — | "The posting names no hiring manager" (your note) | Scope could be one domain or the whole data platform; the JD leans toward one domain | `[inferred]` from the JD's reporting-only mandate against its silence on team structure | Who does this role report to, and does it own the reporting pipelines or the whole data platform? | unresolved |
| RR4 | Equity unspecified | unknown | — | "plus equity" | The form (options or RSUs), the size and the vesting are all unstated | `[grounded]` JD silence | What form and size of equity comes with this role, and on what vesting schedule? | unresolved |
| RR5 | Student-data handling unstated | unknown | — | "live online tutoring for K-12 schools" | `[generic]` K-12 platforms usually carry student-privacy obligations that shape warehouse access and retention. Your payroll background may carry over as experience with sensitive data | `[generic]` sector pattern, not a claim about this employer | What student-data privacy requirements does the warehouse operate under, and who owns compliance? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV summary with what you said yourself: "Built our dbt project on Snowflake (about 180 models); Airflow orchestration; set up our Great Expectations test suite". Use only your own verbs and figures | see R4a, R6, R7 | `[grounded]` your background, quoted | resume_edits_pending_approval |
| E2 | Name the warehouse plainly as "Snowflake", never "BigQuery-ready" or "cloud warehouses" in the plural | see R5 | `[grounded]` your background | pending your approval |
| W1 | Optional: a small public dbt-on-BigQuery project to narrow R5's limit | see G1 | `[generic]` common way to close a single-tool gap | pending your approval |
| Q1 | Ask the verification questions from RR1, RR3, RR4 and RR5 word for word in early calls | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Confirm R1 (US work location) before you spend effort on the application | see R1 | `[grounded]` JD terms | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none. Stage assumed: evaluating.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Checked the pasted material. Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): it is live and matches the JD you pasted. Searched "Pellucid Learning online tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), matching your text. This moved role reality's organization and contradictions rows and RR2 |
| 2. Role-family sweep | skipped | Your pasted Datawright report already supplies the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can save all of this as a `tuesday-dossier.md` file to pick up later or use for interview prep, if you'd like.

## Upgrade menu

- **Your location and non-negotiables (pay floor, office days):** R1 resolves, and the hard-gates line can check your own constraints.
- **Answers to G2 and G3:** R8 and R9 could move to `direct`, which would leave R5 as the only non-direct duty.
- **A sanitized dbt model graph, project README or Great Expectations config:** R4a and R7 rise to `high`.
- **The hiring manager's name:** a scope read for RR3, and which verified story to lead with for that reader.
- **A deeper research pass on Pellucid Learning** (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

R1: Where will you be working from, and are there any non-negotiables (a pay floor, office days) I should check this against?

G2: Where did the data feeding your Snowflake warehouse come from (the product database, a CRM or HR system, third-party APIs), and which parts of getting it in did you build yourself?

G3: Have you ever agreed formal or informal guarantees with analysts (schemas, freshness, notice before a breaking change), and how were they enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.