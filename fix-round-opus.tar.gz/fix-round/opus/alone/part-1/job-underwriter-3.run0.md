I'm reading the skill's reference rules first. Next I'll run a few quick searches on the company and the market, then give you the full assessment.
**No. Your instinct is right, and it's about the terms, not your fit. R1 and R2, both hard gates, fail · `no_go`**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Base compensation $70–85k), R2 (On-site in Austin 5 days a week, no exceptions)
- `must_have` — direct: R3, R4, R5 · unclear: R6 (SEO/content), R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops)
- `important` — adjacent: R10 (E-commerce enablement context) · unclear: R11 (Hands-on execution as a team of one)

R1, R2 — these two settle it, whatever the other rows say; R6, R7, R8, R9 — breadth your background doesn't show yet, which only matters if R1 and R2 ever change.

**Opportunity ledger.** Apart from your own constraints, the posting has several warning signs: the cash looks low for the seniority it asks for (RR1), one person owns seven functions with no budget or team (RR4), it expects evenings and weekends (RR5), success metrics are left undefined (RR6), and the pay leans on equity (RR7). The employer couldn't be checked (RR8). One entry is positive: you'd report straight to the CEO with board visibility (RR9).

- **Hard gates:** failed: R1 (Base compensation $70–85k), R2 (On-site in Austin 5 days a week, no exceptions)
- **Severe red flags:** RR2 (`severity: high`), RR3 (`severity: high`)
- **What would have to be different:** Novaline would need to raise the base to at least $150k *and* offer fully remote work from Portland. The posting says "no exceptions" to on-site, and the top of its range is roughly half your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting; not checked independently (RR8) |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and resources | "A team of one to start"; no budget, headcount plan or decision rights stated | `[grounded]` posting; silence on budget `[grounded]` |
| Reporting | To the CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" (no equity terms) | `[grounded]` posting |
| Success metrics | "Will evolve as we learn" (none stated) | `[grounded]` posting |
| Scope read | Seven functions held by one person, which usually means several roles in one job, at a price that looks junior for "8+ years growth leadership" | `[inferred]` from the function count and the years required, against the stated base |
| Market calibration | Not established. The role-family sweep couldn't run (search was refused), so there's no market band to compare R1 against | `[generic]` no band; posting's figure `[grounded]` |
| Unknowns | Growth budget; hiring plan beyond "to start"; equity size, vesting and strike; how "when it matters" plays out week to week; who sets the targets | — |
| Contradictions | The title says "Head of", but the job is a team of one. A profitable company is still asking for below-market cash in exchange for equity | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base compensation $70–85k (carries your $150k base floor) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor, which is your own stated limit and specific. The fit fails because the top of the range ($85k) is $65k below it | `[grounded]` posting plus your stated constraint | Shown here in the snapshot. Only a change in terms by you or Novaline resolves it |
| R2 | On-site in Austin 5 days a week, no exceptions (carries your remote-only, Portland, no-relocation constraint) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your constraint, which is your own and specific. It fails because the posting rules out exceptions and you rule out relocating | `[grounded]` posting plus your stated constraint | Shown here in the snapshot. Only a change in terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You stated 9 years, from growth lead to Head of Growth at two companies. That's self-report from intake, so it caps at `medium` until probed | `[grounded]` your stated background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You stated you owned paid acquisition and controlled the budget while scaling one company from $8M to $40M ARR. Specific, but nothing inspectable yet | `[grounded]` your stated background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You stated you owned lifecycle and work deeply in Braze. Specific, not yet inspected | `[grounded]` your stated background | none |
| R6 | SEO/content | must_have | unclear | low | discovery | Your background doesn't mention it either way. Not having it in your summary doesn't mean you lack it | `[grounded]` silence in your background | G1 |
| R7 | Brand and PR | must_have | unclear | low | discovery | Your background doesn't mention it | `[grounded]` silence in your background | G1 |
| R8 | Partnerships | must_have | unclear | low | discovery | Your background doesn't mention it | `[grounded]` silence in your background | G1 |
| R9 | Sales ops | must_have | unclear | low | discovery | Your background doesn't mention it, and B2C subscription growth often has no sales function | `[grounded]` silence in your background; `[generic]` that B2C subscription teams often lack sales ops | G1 |
| R10 | E-commerce enablement (merchant-facing) context | important | adjacent | medium | transferability | Your paid, lifecycle and experimentation work carries over. The limit: all of it was at B2C subscription companies, and selling to merchants changes the funnel and the sales motion | `[inferred]` that the role sells to merchants, from "e-commerce enablement"; `[grounded]` your B2C history | G3 |
| R11 | Hands-on execution as a team of one | important | unclear | low | discovery | You managed teams of 3–7. How much you executed yourself, versus directing others, isn't stated | `[grounded]` your stated team sizes; `[inferred]` that a team of one is all execution | G2 |

## Gap recovery queue

These would matter for a similar role on terms you can accept. They can't change this decision.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Full-funnel breadth (R6, R7, R8, R9, must_have) | discovery | Paid, lifecycle and experimentation are established; SEO, brand, PR, partnerships and sales ops aren't mentioned | Postings for broad Head of Growth roles list these, and your summary covers three of the seven areas | Briefing a content or SEO agency; running a launch press push; affiliate, co-marketing or channel deals; owning CRM pipeline hygiene or a sales handoff | A channel-mix dashboard, a partnership deck, a press plan | `[grounded]` silence in your background; `[inferred]` that it matters for broad-mandate roles |
| G2 | Individual execution (R11, important) | discovery | Team leadership is clear; your own hands-on work isn't stated | Single-person growth roles reward people who build the campaigns themselves | Building campaigns in Braze yourself; writing your own SQL for attribution; running ad accounts directly | Sample queries, a campaign build, an experiment write-up | `[grounded]` team sizes you stated; `[generic]` what solo growth roles value |
| G3 | Merchant-facing context (R10, important) | transferability | Strong B2C subscription results | The bridge carries over; its limit is a merchant sales cycle | Any B2B pilot, a merchant or creator program, account-based campaigns | A case write-up | `[inferred]` from "e-commerce enablement" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Seniority and pay don't match | risk_signal | medium | "8+ years growth leadership required … $70–85k base" | The cash may sit well below what this seniority and mandate command elsewhere. Not confirmed, because the market sweep couldn't run | `[inferred]` from the posting's years and mandate against its own figure | How did you set the $70–85k band for a role requiring 8+ years of leadership? | unresolved |
| RR2 | Base far below your floor (see R1) | red_flag | high | "$70–85k base" | Unacceptable to you whatever the market says: $65k short at the top of the range | `[grounded]` posting plus your constraint | Is there room for the base to reach $150k? | confirmed |
| RR3 | On-site only, against your remote-only constraint (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Rules you out unless the terms change, and the posting says they won't | `[grounded]` posting plus your constraint | Is fully remote from Portland possible for this role? | confirmed |
| RR4 | Bundled functions with no team or budget stated | risk_signal | medium | "Own all revenue growth end to end … team of one … we believe in players who don't need a bench" | Several roles folded into one, accountable for everything with no stated resources | `[inferred]` from the seven-function mandate against silence on budget and headcount | What growth budget and hiring plan come with this role in year one? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work presented as company culture, without defining "when it matters" | `[inferred]` from the posting's wording | In a typical month, how often does "when it matters" happen? | unresolved |
| RR6 | Demanding mandate with no success metrics | risk_signal | medium | "success metrics will evolve as we learn" | The person in the role answers for revenue while the targets can move | `[inferred]` from the posting's wording | What revenue or growth target would make year one a success? | unresolved |
| RR7 | Pay leans on undefined equity | risk_signal | medium | "meaningful equity upside" | The low cash may be offset with equity whose size and terms aren't stated, even though the company says it's profitable | `[inferred]` from the posting's wording | What percentage, vesting schedule and strike price does the equity carry? | unresolved |
| RR8 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too small to have much public footprint, or the posting may be stale or aggregated. Not checked, because search was refused | `[generic]` pattern for companies this size, not a claim about this one | Can you point me to this role on your own careers page? | unresolved |
| RR9 | Direct CEO reporting with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | Suggests real access and a voice in strategy | `[grounded]` posting | What decisions would this role make without CEO sign-off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | see R1, R2, RR2, RR3 | `[grounded]` map and register | pending your approval |
| A2 | If Novaline contacts you anyway, ask the RR2 and RR3 questions before spending any time on the process | Both answers are on the posting's face; only a change in the terms reopens this | `[grounded]` RR2, RR3 | pending your approval |
| A3 | In future searches, screen out postings that don't state remote and a base of $150k or more before reading further | Your constraints decided this case on the posting's terms alone | `[grounded]` R1, R2 | pending your approval |

## Evidence status

Verified: R1, R2 claims (your stated constraints). The career claims behind R3, R4, R5 and R10 are intake self-report: leads until probed, held at `medium`. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A". The call was refused (web search permission not granted). It would have confirmed the company and that the posting is live (RR8) |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026". The call was refused. It would have set a market band for role reality and confirmed or cleared RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to run |

I can save this as a `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**
- A link to the live posting or Novaline's careers page → resolves RR8.
- Allowing web search → the market sweep sets a band for RR1. It could also run a deeper pass (funding, leadership churn, employee reports; up to 5 more searches and 2 more fetches).
- Your answers on G1 and G2 → R6, R7, R8, R9 and R11 resolve. That's useful for the next Head of Growth posting, not this one.

Questions: none. Nothing I could ask would change this decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.