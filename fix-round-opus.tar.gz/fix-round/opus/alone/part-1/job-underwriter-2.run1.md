## Decision snapshot

**No, you're not wasting your time, but this is a stretch application. The row most likely to stop it is R1a (3+ years with a PM title), not your skills. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-type work under another title), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery) · absent: R1a (3+ years product management experience)
- `important` — adjacent: R6 (Discovery with integration partners), R7 (Write specs and drive delivery with two engineering squads), R9 (Coordinate launches with sales and support), R10 (Own the roadmap) · unclear: R8 (Define and track adoption metrics)

R1a — a title problem that wording cannot fix, only the route you apply by; R3, R4a — your strongest rows, right at the centre of this role; R2, R6, R7, R10 — real bridges, each with a limit you need to name; R5, R8 — open, and your answers could move them.

**Opportunity ledger.** I couldn't confirm the employer because the search was refused (RR1). Pay is not stated (RR2) and nothing defines success (RR4). One entry points the other way: the posting names real resources, two engineering squads (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the posting are confirmed real and live (RR1). (2) You have a way past R1a's screen, such as a referral or a recruiter confirming they'll consider someone without the PM title (A1). (3) Your answers to G1 and G2 bring R5 and R8 up to at least `adjacent`. (4) R2, R6, R7 and R10 are presented as adjacent work, never as PM experience you've already had.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header; not checked independently (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | A platform PM who owns both the strategy and the delivery for one product surface, with two squads under one PM | `[inferred]` from the responsibility list and the squad count |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not established, because the role-family sweep couldn't run | — |
| Unknowns | Pay; location and remote policy; whether the API platform exists already or is being built; who owns it today; how success is measured | `[grounded]` JD silence |
| Contradictions | None inside the JD; no careers page was read to compare against | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (the titled years) | must_have | absent | none | capability | You say you've never held a PM title, so no evidence can turn up for this specific clause. A "must-have" years-in-title line is often screened literally by recruiters or ATS filters, so a cold application may stop here before anyone reads the rest | `[grounded]` your statement "never held a PM title"; `[generic]` literal screening of titled-years lines | Closure path: a warm route (A1), or a parallel search for roles titled as PM-adjacent (A3) |
| R1b | PM-type work under another title | must_have | adjacent | medium | transferability | Requirements documents, quarterly roadmap-input sessions for product, and coordinating engineers and PMs on custom builds are all real PM-type activities. Limit: you fed product decisions rather than making them. Confidence is specific self-report, unprobed, with no artifact | `[grounded]` resume prose | Sanitized excerpt of a requirements doc or the playbook (upgrade menu) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ integrations *of* your company's REST APIs end to end. Limit: you implemented the API product for clients; you didn't own its design, versioning or roadmap | `[grounded]` resume prose | Bridge framing in E1; G2 may add an owned-product example |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL and reading OpenAPI specs, stated directly, plus integration architecture work. Medium only because nothing has been inspected yet | `[grounded]` resume prose | none |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | You coordinated your engineers, the client's engineers and product managers across 30+ integrations | `[grounded]` resume prose | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Your resume says nothing about sales. In vendor implementation roles, sales handoffs are common, but I'm not assuming you had them | `[grounded]` resume silence; `[generic]` that vendor implementation often touches sales | Small question, outside this turn's budget; it can ride a later turn |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | Your resume says nothing on sprints, backlogs or ceremonies | `[grounded]` resume silence | G1 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Your roadmap-input sessions collecting client feedback are close. Scoping workshops for one client's integration are a different kind of work from product discovery across partners. Limit: you collected input for someone else to prioritize | `[grounded]` resume prose | Bridge framing in E1, using your own words, not "discovery" |
| R7 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents, integration architecture, UAT, and a playbook your whole team uses. Limit: these were project-scoped builds, not a standing backlog for permanent squads | `[grounded]` resume prose | W1; a playbook excerpt would raise confidence |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Your resume has no metrics work. A note from a past conversation says you built a request-triage tool that support agents adopted, but that is unconfirmed and isn't evidence | `[grounded]` resume silence; memory lead only | G2 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You ran go-lives for 30+ client integrations. Limit: those were per-client launches; coordinating with sales and support isn't stated | `[grounded]` resume prose | none beyond R4b |
| R10 | Own the roadmap for the API platform | important | adjacent | medium | transferability | Running quarterly roadmap-input sessions is next to roadmap ownership, but it isn't ownership | `[grounded]` resume prose | Name the limit wherever this bridge is used |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Agile delivery (R5, must_have) | discovery | No mention of sprints, backlogs, or how your company's engineers worked | A `must_have` row at `unclear`; resolving it removes a second must-have doubt next to R1a | Joining sprint planning or reviews for custom builds; writing tickets or acceptance criteria into Jira; running UAT within a sprint cycle | Sanitized tickets, a sprint board screenshot, acceptance criteria you wrote | `[grounded]` resume silence |
| G2 | Adoption metrics and owned product (R8, important; also R2, R1b) | discovery | Your resume has nothing on metrics. A past-conversation note mentions a request-triage tool support agents adopted, unconfirmed | If it's true and the tool was yours, it would be the one example where you built something and got people to use it, which is the PM story R1b and R2 lack | Building the triage tool and getting support agents onto it; tracking integration time-to-live or API call volumes after go-live; usage reports you pulled with SQL | Usage numbers, a screenshot, a rollout note, an internal announcement | `[grounded]` resume silence; `[inferred]` from an unconfirmed memory lead that this could be an owned-product example |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Here the search was refused, so nothing was checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation withheld | unknown | — | No pay figure in the posting | The band may sit below what a 7-year solutions engineer earns now, which matters because SE-to-PM moves sometimes involve a pay reset | `[generic]` pay resets in SE-to-PM pivots; `[grounded]` the JD's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Resources named: two engineering squads | positive_signal | — | "drive delivery with two engineering squads" | The role comes with real engineering capacity, not a mandate without a team | `[grounded]` JD | How are the two squads split today, and who sets their priorities? | noted |
| RR4 | No success measures for a demanding mandate | unknown | — | "define and track adoption metrics" | The role may be expected to define what success means as well as deliver it | `[inferred]` from the JD asking for metrics while stating no outcomes | What would a successful first year in this role look like to you? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Apply through a referral or a direct note to the hiring manager or recruiter, not a cold portal submission | see R1a | `[generic]` warm routes get past literal title screens more often | pending your approval |
| E1 | Lead your summary with your own words, e.g.: "Solutions engineer and implementation lead, 7 years: led 30+ client integrations of our REST APIs end to end, wrote the team's integration playbook, and ran quarterly roadmap-input sessions collecting client feedback for product." Every clause comes from your resume text. It deliberately avoids "product discovery", "owned the roadmap" and "shipped APIs" | see R2, R6, R7, R10 | `[grounded]` resume prose | resume_edits_pending_approval |
| E2 | Say outright in your cover note that you haven't held the PM title, and that the bridge is customer-facing API work plus input into product. Don't let a reviewer find the gap themselves | see R1a, R1b | `[grounded]` your statement | pending your approval |
| W1 | Optional work sample: a one-page spec for a hypothetical partner-facing API feature, including adoption metrics. Clearly label it as an exercise, not shipped work | see R7, R8 | `[inferred]` that the sample answers R7 and R8 directly | pending your approval |
| A3 | Run a parallel search for roles where your experience clears the title screen: technical PM for integrations, a solutions-to-product internal transfer, product ops | see R1a | `[generic]` common SE-to-PM routes | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3 and RR4 word for word | the register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a past-conversation note about an internal request-triage tool adopted by support agents. It is unconfirmed and only prompts G2. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform careers", but the call was refused (no search permission). It would have confirmed the company and posting (RR1) and filled role reality's contradictions row |
| 2. Role-family sweep | unavailable | Searched "product manager platform APIs Series B salary range 2026", but the call was refused. It would have filled market calibration and given RR2 a band |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

## Closing

If it's useful, I can save this as a `tuesday-dossier.md` you can bring back as you apply to more roles.

**Upgrade menu**
- Allow web search → targets 1–2 run: Quartzline gets verified (RR1 closes or escalates) and a salary band goes against RR2. A deeper pass (funding, leadership changes, employee reports, news) is up to 5 more searches and 2 more fetches; just say the word.
- A sanitized excerpt of your integration playbook or one requirements doc → R1b and R7 can reach `high`. In PM hiring, a written spec is the proof people expect to see.
- Answers to G1 and G2 → R5 and R8 resolve, and maybe R2 gains a product you owned.
- Your constraints (pay floor, location, start date) → hard-gate checks that currently can't run.
- The hiring manager's name → target 3, and a choice of which story to lead with for that reader.

**Questions**

G2 — A past conversation suggests you built a request-triage tool that support agents adopted. Did you? What part was yours, roughly how many people used it, and how did you know they were using it?

G1 — Have you worked inside sprints or another agile process, for example writing tickets, joining planning, or running UAT in a sprint? What was your role in it?

Orientation — What are your non-negotiables (pay floor, location or remote, start date), and are you just weighing this role or about to apply?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.