I've read the skill's rules; now I'll fetch the posting.
**Yes, it's worth applying, on the conditions below. Most of the posting matches your background; the stretch is the forecast and billing side (R5, R6, R7b). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week)
- `must_have`: direct: R2a, R3, R4a · adjacent: R5 (Experience owning a forecast) · unclear: R2b (at a B2B software company), R4b (Spreadsheet modelling), R6 (Working with finance on billing or revenue data)
- `important`: direct: R7a, R8 · absent: R7b (Own billing data)

R5: you have a real bridge to it, and its limit is stated; R6 and R7b: the billing side, which is the main thing to resolve; R2b and R4b: probably fine, not yet shown.

**Opportunity ledger.** The employer checks out, the pay is stated and sits at the market median (RR1), and the role reports into a Head of Revenue Operations (RR5). Still open: who else works in the function (RR2), who owns the forecast number (RR4), and whether this third-party listing is the live version (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: you can be in Bristol two days a week; (2) R6 is answered, either with finance-facing revenue-data work you've done or by going in knowing R6 and R7b are open gaps; (3) R5 is framed as adjacent: you run the pipeline review, you haven't owned the forecast; (4) RR3: the recruiter confirms the listing is current.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A in April 2025 | `[grounded]` quillfield.co.uk/about, search result |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` JD |
| Terms | Bristol, hybrid, two days a week in the office; £61,500–£67,000 plus share options | `[grounded]` JD |
| Reporting line | The hiring manager is Tamsin Achebe, Head of Revenue Operations. Her public profile lists four years as sales operations manager at Corvane Payments before this | `[grounded]` recruiter, via you; public profile search result |
| Scope read | Half the role is revenue operations (CRM, reporting). The other half is finance-facing (billing data, the forecast with the CFO). The second half is what separates it from your current job | `[inferred]` from the JD's responsibilities set against each other |
| First-90-days outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | UK revenue operations lead, B2B software: median base £64,200, middle half £57,800–£70,400 (n=438). The posting's £61.5–67k sits inside that range and spans the median | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` JD for the posted figure |
| Unknowns | Team size and who else is in RevOps; which billing system is used and who runs it today; whether the forecast number is this role's or the CFO's | — |
| Contradictions | None between the posting, the recruiter's information and the company's About page. The role did not turn up on Quillfield's own site in search (RR3) | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The JD states the term; you haven't said where you live or whether two Bristol days work | `[grounded]` JD; intake silent | Question below |
| R2a | 4+ years in revenue operations, sales operations or similar | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team. Stated, not yet inspected | `[grounded]` intake | none |
| R2b | …at a B2B software company | must_have | unclear | low | discovery | "B2B payments company" may or may not be a software business. `[generic]` A literal screen may read this qualifier strictly | `[grounded]` intake wording; `[generic]` screening pattern | G3 |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certificate can be checked but hasn't been inspected here | `[grounded]` intake | Offer: certification ID or badge link raises this to high |
| R4a | Strong SQL | must_have | direct | medium | none | "SQL weekly", stated | `[grounded]` intake | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" says you use spreadsheets, not that you build models (scenarios, drivers, forecasts). Rated on the lower reading | `[grounded]` intake wording | G4 |
| R5 | Experience owning a forecast (the role runs the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | Bridge: you run the monthly pipeline review with your sales director. Limit: you've never owned the company forecast, which finance did. Both are stated by you, and both must travel together | `[grounded]` intake, both clauses | G1 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You've ruled out billing. "Or revenue data" is still open: renewal dashboards are revenue-adjacent, but working with finance on them isn't stated | `[grounded]` intake ("never worked on billing data") | G2; question below |
| R7a | Own CRM data | important | direct | medium | none | You run RevOps for the UK team, hold the Salesforce admin certification and rebuilt the dashboards | `[grounded]` intake | none |
| R7b | Own billing data | important | absent | none | capability | You said directly that you've never worked on billing data | `[grounded]` intake | Closure path in G5 |
| R8 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance also used them isn't stated, so the "for finance" part isn't claimed | `[grounded]` intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R5, must_have) | transferability | You run the pipeline review but have never owned the forecast | The JD's forecast duty sits with the CFO, so this is the requirement most likely to be probed | Pipeline numbers or commit calls that finance pulled into its forecast; a UK-team forecast or call you made yourself, even informally; forecast-accuracy tracking you ran | A sanitized pipeline-review pack or commit sheet | `[grounded]` intake; `[generic]` that a stated duty like this is what interviews probe |
| G2 | Finance revenue data (R6, must_have) | discovery | Billing is ruled out; other revenue data with finance is unknown | If it resolves, a must-have moves from unclear toward direct or adjacent | Reconciling CRM bookings or renewals with finance's numbers; commission or quota data; ARR or churn figures you supplied for board or finance packs | A redacted reconciliation sheet or renewal report that finance used | `[grounded]` intake |
| G3 | B2B software employer (R2b, must_have) | discovery | Your employer's business model isn't stated | Settles a literal screen on the qualifier | Your company sells a platform, an API or a subscription product | Your company's own product page | `[grounded]` intake wording |
| G4 | Spreadsheet modelling (R4b, must_have) | discovery | Daily Excel use; modelling not stated | Separates a model-builder from a heavy user | Capacity, quota or territory models; renewal-rate scenarios; pipeline-coverage models | A sanitized model | `[grounded]` intake wording |
| G5 | Billing data (R7b, important) | capability | You state you have no billing-data experience | Carried as a known gap; it can't be talked around | Closure path: learn how billing records join to CRM accounts and contracts, and how that rolls up to recognised revenue; ask in interview which billing system Quillfield uses | Notes from that self-study, if you do it | `[grounded]` intake; `[generic]` closure path |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and at market | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The range is transparent and sits inside the role-family middle range | `[grounded]` JD; `[generic]` Ledgerline band | How are share options sized for this level, and on what vesting? | noted |
| RR2 | Team and resources behind the mandate are unstated | unknown | — | "You will own our CRM and billing data" | The role may be a one- or two-person function at a 96-person company | `[inferred]` from the JD's ownership language against its silence on team | Who else works in revenue operations, and who runs the billing system day to day today? | unresolved |
| RR3 | Listing not found on Quillfield's own site | unknown | — | Tallyboard listing, ref 2291 | The listing may simply not be indexed, or it may be stale | `[grounded]` a targeted search returned nothing; `[generic]` that third-party boards lag | Is this the current version of the role, and is it on your own careers page? | unresolved |
| RR4 | Forecast accountability is split | unknown | — | "run the quarterly revenue forecast with the CFO" | It's unclear whether the number belongs to this role, the CFO or the Head of RevOps | `[inferred]` from "with the CFO" | Who signs off the forecast number, and what does this role own in that process? | unresolved |
| RR5 | Role sits inside a named RevOps function | positive_signal | — | Hiring manager's title: Head of Revenue Operations | You'd have a RevOps manager above you, not a sales or finance leader | `[grounded]` public profile search result | What would you want this role to have taken off your plate by month three? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the pipeline and renewal dashboard rebuild and running the monthly pipeline review | see R8, R7a, R3 | `[grounded]` intake | pending your approval |
| P2 | On the forecast, use your own words: "I run the monthly pipeline review with our sales director; I haven't owned the company forecast, which sat with finance." Don't add that your numbers fed the forecast unless G1 confirms it | see R5 | `[grounded]` intake, quoted | pending your approval |
| P3 | Name billing as a gap before they do, and mention any self-study from G5 | see R7b, R6 | `[grounded]` intake | pending your approval |
| P4 | Be precise about your payments sales-ops detail: the hiring manager spent four years in sales ops at a payments company | see role reality, reporting line | `[grounded]` public profile; `[inferred]` that precision matters more for this reader | pending your approval |
| P5 | Ask the RR2, RR3 and RR4 questions in the recruiter screen and the first interview | The register doubles as interview prep | `[grounded]` register | pending your approval |
| P6 | Confirm with the recruiter that the listing is current before you invest in a tailored CV | see RR3 | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about). It confirms the entity and fed role reality's organization row. Also searched `Quillfield "Revenue Operations Lead" Bristol`, which returned nothing, so the posting isn't established on the company's own site (RR3) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B SaaS 2026", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Fed market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Fed the reporting-line row, RR5 and P4 |

I can save all of this as a `tuesday-dossier.md` file to carry into later sessions. Just say so.

**Upgrade menu**
- Your location and pay floor would settle R1, and set the pay range against your number.
- An answer to G1 or G2 would firm up R5 and possibly move R6 out of unclear.
- Your company's product page would settle R2b.
- A Salesforce certification link or badge would raise R3 to high.
- A sanitized pipeline-review pack or model would raise R5 or R4b.
- A deeper research pass on Quillfield (funding since the Series A, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) runs if you say so.

**Questions**

R1: Can you be in the Bristol office two days a week?

G2: Have you worked with finance on any revenue data other than billing, such as reconciling bookings, renewals, ARR or commission figures? What was your part, and what was finance's?

G1: When finance built the forecast, did they take anything from your pipeline review, such as commit numbers, coverage or a UK call? Who made the call?

You can answer any of these in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.