Still working on this: I've read the skill's rules and am now checking that Pellucid Learning and the posting are real and live before I write up the assessment.
# Senior Data Engineer at Pellucid Learning: should you apply?

## Decision snapshot

**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7
- `important`: adjacent: R5b (A dbt-modelled warehouse in BigQuery) · unclear: R8 (Ingestion from our app and CRM), R9 (The data contracts our analysts depend on)

R5b: your Snowflake work bridges to it, but there's a limit to name; R8 and R9: your background doesn't mention them yet.

**Opportunity ledger.** The posting holds up. The pay range is published and sits at or above the market band (RR1), and the posting is live and matches what you pasted (RR4). Three things are unknown: who you'd report to and how big the team is (RR2), how wide the scope is (RR3), and what the equity terms are (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work from the US or Denver (R1); (2) a base of $148,000–$166,000 clears your own pay floor; (3) you present BigQuery honestly as a bridge from Snowflake, not as experience you have (R5b, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning. Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` about page you pasted, which matches the live about page |
| Mandate | "Build and run the pipelines behind our tutoring platform's reporting": ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Must-haves | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Implied requirements | BigQuery specifically, ingestion work, and data-contract work. All three come from the responsibilities sentence, not the requirements list | `[inferred]` from the JD's mandate sentence |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| Scope read | You'd likely own the reporting data stack end to end (ingest, model, contract). The JD doesn't say whether that's one domain or the whole platform, or whether anyone else works on it | `[inferred]` from the mandate sentence and the JD's silence on team |
| Market calibration | The report's "Senior" means 5–8 years and ownership of one domain's pipelines with no direct reports. This JD's 5+ years and lack of any reports fit that. The posted base runs $148,000–$166,000. Against the report's median of $151,000 and its middle range of $139,000–$163,500, both ends of the posting are above the middle range, before equity. The band describes the market, not this employer's offer | `[generic]` Datawright 2026 Data Engineering Pay Report, US, n=2,310, Series B–D (the report your recruiter sent); `[grounded]` JD for the posted figures |
| Unknowns | Hiring manager and reporting line; team size; how many sources and models are in scope; equity type and vesting; first-90-day outcomes (none stated) | — |
| Contradictions | None. The live careers page matches your pasted JD word for word, and the about page matches | `[grounded]` both pages checked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You didn't say where you're based or what your work status is. This is a term you either meet or don't, and nothing you've told me settles it | `[grounded]` JD terms; background silent | Closing question on R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You report 6 years at a B2B payroll company. That's specific, but it's your own account, with nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You say "Python and SQL daily". Specific about how often, nothing inspected yet. An interview will likely test this live | `[grounded]` your background; `[generic]` that interviews in this field test SQL and Python live | none |
| R4 | dbt | must_have | direct | medium | none | You say you built the dbt project, about 180 models. Specific and clearly yours, nothing inspected yet | `[grounded]` your background | Offer a sanitized model diagram or project layout to raise this to high |
| R5a | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the JD's requirements line asks for "a cloud warehouse" without naming one | `[grounded]` JD wording and your background | none |
| R5b | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | You state you've never used BigQuery. The same dbt approach on Snowflake carries over. What it doesn't cover: BigQuery's pricing model, partitioning and clustering choices, and its own SQL dialect | `[grounded]` your own "Never used BigQuery"; `[generic]` that those are where the two warehouses differ | See G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow for orchestration, which is the tool the JD names. Your own account, nothing inspected yet | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You say you set up the Great Expectations test suite. Specific and yours, nothing inspected yet | `[grounded]` your background | none |
| R8 | Ingestion from our app and CRM | important | unclear | none | discovery | Your background covers modelling and orchestration but says nothing about where your data came from or who built the extraction | `[grounded]` background silent on ingestion | Closing question on G2 |
| R9 | The data contracts our analysts depend on | important | unclear | none | discovery | Your Great Expectations suite tests data. A contract is an agreement with the people who use it. Those are different kinds of work, so the tests don't count as evidence here | `[grounded]` background silent on contracts | Closing question on G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5b, important) | transferability | About 180 dbt models on Snowflake; no BigQuery | It's the platform you'd run from day one, so it's the gap an interviewer is most likely to probe | Any GCP exposure; dbt adapter or dialect work; warehouse cost tuning on Snowflake, which is the same kind of thinking BigQuery pricing needs | A small public repo that ports a handful of your dbt patterns onto the BigQuery free tier | `[grounded]` your own statement; `[generic]` that interviews probe whichever stack you lack |
| G2 | Ingestion from app and CRM (R8, important) | discovery | Modelling and orchestration only | One of the three named jobs in the mandate | Pulling from a production app database or event stream; syncing an HR or CRM system through its API, or with tools like Fivetran or Airbyte; handling schema changes from upstream | A DAG structure, a design note, a runbook | `[grounded]` background silent; `[inferred]` from the mandate sentence that it's core |
| G3 | Data contracts (R9, important) | discovery | Testing, but no agreements with consumers | Named as something "our analysts depend on" | Agreed schemas or service-level expectations with the finance or analytics teams; dbt model contracts or versioning; a process for announcing breaking changes | A contract spec, a dbt `contract:` config, a change-notice template | `[grounded]` JD wording and background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay published, at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The base is competitive for the stated seniority | `[grounded]` JD; `[generic]` the Datawright band | Where in the range do you expect to land someone with 6 years? | noted |
| RR2 | No hiring manager or reporting line named | unknown | — | (posting names no hiring manager) | You might sit in analytics, in engineering, or alone | `[inferred]` from the JD's silence | Who does this role report to, and who else works on the data stack today? | unresolved |
| RR3 | Scope may be wider than one domain | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | It may be the whole reporting stack for one person, which is wider than the report's typical "one domain" | `[inferred]` from the mandate sentence; `[generic]` the report's scope norm | How many sources, models and analysts does this role support, and what's already built? | unresolved |
| RR4 | Employer and posting check out | positive_signal | — | "Accepting applications" | The role is live and the company is as you described it | `[grounded]` live careers and about pages | What changed after the February 2026 raise that opened this role? | noted |
| RR5 | Equity terms not stated | unknown | — | "plus equity" | The type, size and vesting are open | `[inferred]` from the JD's silence | What kind of equity is it, how much, and on what vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with: "Built our dbt project on Snowflake — about 180 models — orchestrated with Airflow; set up our Great Expectations test suite." | R4, R6 and R7, in your own words | `[grounded]` your background | resume_edits_pending_approval |
| E2 | State the stack plainly: "Snowflake; no production BigQuery yet." Don't fold BigQuery into a skills list | R5b, so the gap is honest from the start | `[grounded]` your own statement | resume_edits_pending_approval |
| W1 | A small BigQuery free-tier repo with a few of your dbt patterns ported over | Narrows G1 with something they can inspect | `[grounded]` R5b row | pending your approval |
| Q1 | Ask the verification questions from RR2, RR3 and RR5 word for word in the screen | Fills the opportunity unknowns | `[grounded]` register | pending your approval |

None of this wording is final. Each line above, and the positioning advice it carries, waits for your approval.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Checked your pasted text against the live pages. I fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): it says "Accepting applications" and matches your JD. I searched "Pellucid Learning online tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), matching your company facts. These moved role reality's Contradictions row and RR4 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names nobody, so there was no search to run |

## Upgrade menu

- Your location, work status and pay floor → R1 settles, and the hard-gates check runs against your real constraints.
- Answers to G2 and G3 → R8 and R9 move off `unclear`.
- A sanitized dbt project layout, a Great Expectations suite excerpt, or the W1 repo → R4, R7 and R5b can rise to `high`.
- The hiring manager's name → a sharper scope read, and which of your stories to lead with for that reader.
- A deeper research pass on Pellucid Learning (leadership and hiring changes since the raise, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

If you'd like, I can put this into a `tuesday-dossier.md` you can keep.

**R1:** Where will you work from, and does a base of $148,000–$166,000 clear your pay floor?

**G2:** At the payroll company, which sources did you personally get data out of (the app database, an HR or CRM tool, event streams), and did you build the extraction or only consume it?

**G3:** Did you ever agree schemas, freshness or breaking-change rules with the analysts or finance team who used your models, and is any of it written down?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.