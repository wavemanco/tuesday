I've read the method references and am running the L1 research checks: does the employer exist, and what's the market band.
# Senior Product Analyst at Harborlight Health: should you apply?

## Decision snapshot

**Yes, apply. You are a fit, as long as the employer checks out. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R7a (Partner with product managers to turn analysis into roadmap decisions), R7b (Partner with clinicians) · unclear: R6 (Define and maintain the metrics layer), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience (HIPAA))

R8: your background doesn't mention mentoring; R7b, R9: real bridges from consumer data to clinical data and health records, with their limits named; R6: the Looker build may cover it, but you haven't said so yet.

**Opportunity ledger.** I couldn't confirm the employer because my searches were blocked (RR1). Pay and work location aren't stated (RR2, RR3). One person carries a lot of scope here (RR4). In its favour, the role has a concrete mandate, named tools and a stated team size (RR5).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight Health and this posting check out as real and live (RR1); (2) pay and location work for you once known (RR2, RR3); (3) you frame R9 as GDPR/CCPA and consent-modelling work, never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not checked independently (RR1) |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, self-serve dashboards in Looker, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor analyst who also mentors. It owns the analytics stack end to end for one product | `[inferred]` from the responsibility list plus "mentor two junior analysts" |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD is silent |
| Market calibration | Not established, because the role-family search was refused. A senior product analyst who owns experiments and the BI layer is a normal remit for this title | `[generic]` role-family pattern, no band figures |
| Unknowns | Pay; location or remote policy; who the role reports to; whether "metrics layer" means LookML/semantic-layer ownership; the clinical data environment | n/a |
| Contradictions | None inside the JD; not checked against a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years at a meal-kit subscription company (~2M subscribers). Clear and specific, but self-reported only | `[grounded]` intake background | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse". Daily use is stated; "expert" will be tested, not read off a CV | `[grounded]` intake; `[generic]` that SQL depth is usually screened with a live exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program, 30+ tests a year, on a ~2M-subscriber base, including a pricing test behind an 11% retention lift. Expect probes on method: power, guardrail metrics, novelty effects | `[grounded]` intake; `[generic]` that these are standard probes | Have the pricing test's design ready to walk through |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards. Same tool as the JD | `[grounded]` intake | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads, and presents to the VP Product monthly. A sanitized memo would raise this to high | `[grounded]` intake | Offer a redacted memo as a work sample |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" may mean you built a semantic layer (LookML models, metric definitions), but you haven't said so. I won't assume it | `[grounded]` intake wording; `[inferred]` that a from-scratch Looker build may include it | Closing question G2 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | You present to the VP Product monthly, and the pricing test led to a decision. Which roadmap calls your analysis changed isn't stated yet | `[grounded]` intake | Name one or two decisions your analysis moved, in your application |
| R7b | Partner with clinicians | important | adjacent | low | transferability | Bridge: you translate analysis for non-technical executives. Limit: no clinical stakeholders and no clinical-outcome or care-quality metrics. Strengthener: show how you'd learn the domain fast | `[grounded]` background is silent on clinical work; `[generic]` that clinician partners judge metrics by clinical validity | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring, code review, onboarding or people leadership. Not yet a capability gap, just undiscovered | `[grounded]` background silence | Closing question G1 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Bridge: you handled GDPR/CCPA consumer PII and built the warehouse's consent-state model. Limit: no work with HIPAA protected health information. HIPAA has its own rules (minimum-necessary access, de-identification standards, business associate agreements) | `[grounded]` intake; `[generic]` the HIPAA specifics | Frame as privacy engineering, not HIPAA (Application plan E2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring junior analysts (R8, important) | discovery | No mentoring or people leadership mentioned | It's a named responsibility, and senior interviews often ask about it | Onboarding a new analyst to your Looker setup; reviewing others' SQL or experiment designs; running an analytics guild or office hours; training PMs to self-serve | A review checklist, onboarding doc, or experiment-design template you wrote | `[grounded]` background silence; `[generic]` that senior loops ask about mentoring |
| G2 | Metrics-layer ownership (R6, important) | discovery | A Looker build with "governed" dashboards, but no explicit semantic layer or metric definitions | It's the first item in the JD's mandate | Writing the LookML model; owning canonical definitions (active subscriber, churn, retention); a metric-change process; dbt models feeding Looker | A redacted LookML snippet, a metrics dictionary, or a definitions doc | `[grounded]` intake wording |
| G3 | Clinician partnership (R7b, important) | transferability | Non-technical executive audience only | It's a responsibility, and the stakeholders are a different kind of audience | Working with an ops or supply-chain team whose expertise you didn't share; metrics where a domain expert disagreed with the data | Any memo where you reconciled a domain expert's view with the data | `[inferred]` bridge from the exec-memo work |
| G4 | Health data handling (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | It's preferred, so it can set you apart but won't block you | Access controls, PII masking, deletion workflows, consent flags propagated into analysis tables | A design doc for the consent model | `[grounded]` intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The searches were refused, so nothing is confirmed either way. Most likely the company is real and simply unverified this turn | `[generic]` pattern, not a claim about this company | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (JD silent on pay) | The figure may or may not meet your floor. With no band researched, there's nothing to compare it to | `[inferred]` from the posting's silence | What salary band and equity range are budgeted for this role? | unresolved |
| RR3 | Location / work arrangement not stated | unknown | — | (JD silent on location) | Could be on-site, hybrid or remote, which matters if you have constraints | `[inferred]` from the posting's silence | Is this role remote, hybrid or on-site, and from which locations? | unresolved |
| RR4 | Broad scope for one senior IC plus mentoring | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards … and mentor two junior analysts" | Possibly the whole analytics function in one seat. Low because you've already done this combination at your current company | `[inferred]` from the responsibility list | Who else works on analytics engineering or data infrastructure, and how is the juniors' time split with you? | unresolved |
| RR5 | Concrete mandate, named tools, stated team | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The role is specified well enough to judge fit | `[grounded]` JD | How will success in the first six months be measured? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with your own line: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | see R3. It's the strongest direct match, kept in your own words | `[grounded]` intake | resume_edits_pending_approval |
| E2 | Add a line on the consent-state model and GDPR/CCPA PII work, described as privacy and consent modelling, not as HIPAA experience | see R9 | `[grounded]` intake | resume_edits_pending_approval |
| A1 | Before investing effort, confirm the posting on Harborlight's own careers page or through a recruiter's company email domain | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3, RR4 and RR5 word for word during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |
| W1 | Optional: a redacted monthly metrics memo as a writing sample | see R5 | `[grounded]` R5 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Harborlight Health care navigation app Series C" and the search permission was refused. It would have confirmed the company and the live posting and cleared RR1 |
| 2. Role-family sweep | unavailable | I searched "senior product analyst digital health salary range 2026" and that was refused too. It would have produced the market band for the calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so I had nothing to search for |

I can save all of this as a `tuesday-dossier.md` file if you want to keep it.

**What more input would unlock:**
- **Search permission:** targets 1 and 2 would run, which could clear RR1 and give a real pay band for comparison.
- **The live posting link or a recruiter email:** RR1 closes even without search.
- **Your pay floor and location constraints:** turns the hard-gates line from "unknown" into an actual check.
- **A redacted metrics memo or LookML snippet:** R5 or R6 rises toward `high`.
- **The hiring manager's name:** tells you which of your stories to lead with.
- **A deeper research pass:** funding, leadership turnover, employee reports and recent news on Harborlight; up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions:**

**G1:** Have you mentored, onboarded or reviewed the work of other analysts, even informally? What did you do, and for how many people?

**G2:** When you built the Looker instance, did you also own the LookML model and the official metric definitions (churn, retention, active subscriber)? Or did someone else define those?

**RR2/RR3:** Do you have a pay floor, a location or remote requirement, or a work-authorization constraint I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.