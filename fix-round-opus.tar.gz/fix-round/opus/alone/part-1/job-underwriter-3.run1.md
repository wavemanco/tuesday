Here's the full underwriting.

## Decision snapshot

**No, this posting isn't worth pursuing. R1 and R2 are both hard gates, and both fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Compensation: $70–85k base), R2 (On-site in our Austin office 5 days a week)
- `must_have`: direct: R4, R5 · adjacent: R10 (a team of one to start) · unclear: R3 (8+ years growth leadership), R6 (SEO/content), R7 (brand, PR), R8 (partnerships), R9 (sales ops)
- `important`: unclear: R11 (B2B, sales-assisted growth motion), R12 (Report to the CEO with a dotted line to the board)

R1, R2: each one fails on its own, whatever the rest of the map says. R4, R5: your strongest rows. R6, R7, R8, R9: breadth this mandate demands that your stated background doesn't show yet.

**Opportunity ledger.** Your sense that "something feels off" is borne out by the register. One title bundles seven functions (RR4) at a base that conflicts with your floor (RR1) and may sit below this seniority (RR2). The posting adds always-on hours (RR5) and success metrics it says will move (RR6). The equity is unquantified (RR7), and the employer could not be checked (RR8). One entry runs the other way: the CEO reporting line with board visibility (RR9).

- **Hard gates:** failed: R1 (Compensation: $70–85k base), R2 (On-site in our Austin office 5 days a week).
- **Severe red flags:** RR1 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** Novaline would have to change *both* terms: a base of at least $150k (R1, RR1) *and* fully remote work from Portland (R2, RR3). Changing one alone leaves a failed gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup at Series A, described as "profitable since day one" | `[grounded]` JD; not checked (see Evidence status) |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Resourcing | "A team of one to start." No budget, agencies or hiring plan stated | `[grounded]` JD; silence on budget `[grounded]` |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| First-year outcomes | None stated: "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | Seven functions with one owner amounts to several roles under one title. Sales ops and partnerships suggest the buyer is a merchant business, not a consumer | `[inferred]` from the function list and "e-commerce enablement" |
| Market calibration | Not established. The role-family sweep couldn't run, and no pay band is given here because model memory isn't a source for pay figures | — |
| Unknowns | Growth budget; equity terms; whether the motion is B2B; what "when it matters" means in practice; how success will be judged | — |
| Contradictions | "Profitable since day one" sits beside a $70–85k base for an 8+-year leadership mandate. That's tension, not proof of anything | `[inferred]` from the JD's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base (your floor: $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor, which is specific and confirmed. The fit fails because the posting's top figure is about $65k below it | `[grounded]` JD figure and your stated constraint | Only Novaline changing its terms resolves it (RR1) |
| R2 | On-site in Austin 5 days a week, "no exceptions" (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The fit fails because the JD rules out the exception you need, in those words | `[grounded]` JD and your stated constraint | Only Novaline changing its terms resolves it (RR3) |
| R3 | 8+ years growth leadership | must_have | unclear | low | discovery | You state 9 years in growth, as growth lead and then Head of Growth. How many of those years were in a lead role isn't stated, so the lower band applies | `[grounded]` your background, silent on the split | G1 |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid, plus the $8M to $40M ARR scale-up "with a budget I controlled." Specific, but nothing inspectable yet | `[grounded]` your background | Optional: a channel report would raise it to high |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and are "deep in" Braze. Specific, nothing inspected yet | `[grounded]` your background | Optional: a lifecycle program summary |
| R6 | SEO/content | must_have | unclear | low | discovery | Not mentioned in your background | `[grounded]` your background is silent | G2 |
| R7 | Brand, PR | must_have | unclear | low | discovery | Not mentioned | `[grounded]` your background is silent | G2 |
| R8 | Partnerships | must_have | unclear | low | discovery | Not mentioned | `[grounded]` your background is silent | G2 |
| R9 | Sales ops | must_have | unclear | low | discovery | Not mentioned. Sales ops is uncommon in B2C subscription growth | `[grounded]` your background is silent; `[generic]` that B2C subscription growth rarely includes sales ops | G2 |
| R10 | "A team of one to start" (hands-on execution across every channel) | must_have | adjacent | medium | transferability | Being deep in SQL, GA4 and Braze points to hands-on skill. But you describe leading teams of 3 to 7, not running every channel yourself. The limit is execution breadth without a bench | `[grounded]` your background | G3 |
| R11 | B2B, sales-assisted growth motion | important | unclear | low | discovery | Implied, not stated: "e-commerce enablement" plus sales ops and partnerships. Your stated background is B2C subscription only | `[inferred]` requirement, from the product description and function list | G4 |
| R12 | Report to the CEO with a dotted line to the board | important | unclear | low | discovery | Your reporting lines aren't stated | `[grounded]` your background is silent | None while R1 and R2 fail |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leadership years (R3, must_have) | discovery | 9 years in growth, split between lead and head roles, with no dates given | Doesn't move this decision. It matters for any similar role where 8+ years is screened literally | Years where you held a budget, set the roadmap, or managed people, whatever the title | Dated titles on your CV or LinkedIn | `[grounded]` the split is unstated; `[generic]` that years requirements tend to be screened literally |
| G2 | Channel breadth (R6, R7, R8, R9, must_have) | discovery | Paid, lifecycle and experimentation stated; nothing on SEO/content, brand, PR, partnerships or sales ops | Doesn't move this decision. It decides how you position for "own everything" roles | Content programs your team ran; co-marketing or affiliate deals; launch PR you coordinated; CRM-to-sales handoffs | A content calendar, a partner deal summary, a press list | `[grounded]` your background is silent |
| G3 | Solo execution (R10, must_have) | transferability | Hands-on tool depth, but you led through teams | Carries over: you can do the analysis and the CRM work yourself. Limit: no stated period of running several channels alone. Strengthener: an early-stage stint where you did the work yourself | An early period before your team was hired | A dated example of work you shipped yourself | `[grounded]` your background |
| G4 | B2B motion (R11, important) | discovery | Your stated background is B2C subscription only | Matters if you target enablement or SaaS companies next | Selling to merchants or SMBs; any sales-assisted funnel | Funnel dashboards that show a sales stage | `[inferred]` from the JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay conflicts with your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The range would have to nearly double to meet your floor | `[grounded]` JD figure against your stated constraint | Is the base range fixed, or is there budget above $85k for this hire? | confirmed |
| RR2 | Seniority–pay mismatch | risk_signal | medium | "8+ years growth leadership required" | The base may sit below what this seniority and seven-function mandate usually pay. Not confirmed, because the market sweep didn't run | `[inferred]` from the JD's own seniority bar against its figure | How did you set the base range for this role, and against what benchmark? | unresolved |
| RR3 | On-site with no exceptions conflicts with remote-only (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out remote work in its own words | `[grounded]` JD against your stated constraint | Is there any scenario where this role is fully remote? | confirmed |
| RR4 | Bundled specializations, no resources | risk_signal | medium | "Own all revenue growth end to end … You will be a team of one to start" | Several roles under one title, with no budget or hiring plan stated | `[inferred]` from the function list against the JD's silence on budget and headcount | What budget, agency support and hiring plan come with the role in year one? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work is framed as identity, not exception | `[grounded]` JD wording; `[inferred]` that it describes a norm | How often in the last quarter did "when it matters" happen? | unresolved |
| RR6 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held accountable against a target that moves | `[inferred]` from the JD's own wording | What would make the first year a success, in numbers? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The equity may not offset the base gap. No grant size, vesting or valuation is given | `[grounded]` the JD gives no terms | What grant size, strike price and vesting terms come with the offer? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Direct CEO line with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | Real access and visibility for the role | `[grounded]` JD | What does the board expect to see from growth each quarter? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | See R1, R2 | `[grounded]` the map | pending your approval |
| A2 | If you want it settled for certain, ask the recruiter only the RR1 and RR3 questions, before any other effort | Only Novaline changing those terms reopens the decision | `[grounded]` RR1, RR3 | pending your approval |
| A3 | If you go ahead against the `no_go`, use every register question verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1 and R2 constraint claims. Verified refers to your statement of each constraint, not to fit: both rows still fail. Unverified leads: your background behind R3 through R12, which is self-report at `medium` at most. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin careers Head of Growth" was refused. It would have tested role reality's organization row and RR8 |
| 2. Role-family sweep | unavailable | The search "Head of Growth Series A startup base salary 2026" was refused. It would have filled the market calibration row and confirmed or cleared RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to run |

I can save this as `tuesday-dossier.md` if you'd like a record to come back to.

## Upgrade menu

- **Permission for web search:** confirms whether Novaline exists as described (RR8), and gives a market pay band to test RR2 against.
- **A link to the live posting or Novaline's careers page:** checks RR8 directly.
- **The hiring manager's name:** sharpens the scope read.
- **Dated titles for your 9 years:** settles R3 for this and similar roles.
- **A growth artifact, such as a channel P&L, experiment log or lifecycle dashboard:** raises R4 and R5 to `high` for your next application.
- **A deeper research pass on Novaline,** covering funding, leadership churn and employee reports. It uses up to 5 more searches and 2 more fetches. Say the word and it runs.

No questions this turn. Nothing you could answer changes R1 or R2; only Novaline changing its terms would. If you later want to work through the gap queue for a role that fits your constraints, the mock-interview skill handles rehearsal once you have one.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.