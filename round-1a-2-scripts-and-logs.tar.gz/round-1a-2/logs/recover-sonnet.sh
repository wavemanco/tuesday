#!/bin/bash
# Round 1a-2, Sonnet quality step: recovery after the container restart of 20 November ~01:05 UTC (manifest
# section 14: killed runs re-run at once after a restart, under their own stems, on the same pins, models,
# flags and bar; finished but ungraded runs graded in place). The step's own command lines from run_step.sh's
# part_argv/e23_argv, with --stems added; each wrapped in logged.sh, under the stop rule and the guard, as the
# step ran. Part-5 alone and Tuesday: regrade then rerun, the two arms in parallel; then the seven E23 replays
# (never started) in section 5's order. Never writes over files that exist. Seals the whole step at the end.
#   recover-sonnet.sh            the step: stop rule, driver in its own process group, guard, seal
#   recover-sonnet.sh --driver   (internal) the commands
set -u
K=/var/tmp/tuesday-measure/1a2/frozen/kit
source "$K/kit.env"
SELF=$M/logs/recover-sonnet.sh
LABEL=sonnet-quality-recovery; ST="$STATUS_DIR/$LABEL.status"
now() { date -u +%Y-%m-%dT%H:%M:%SZ; }
log() { echo "$(now) $LABEL: $*" >> "$LOG"; echo "$*"; }
status() { echo "$(date -u +%H:%M:%S) $*" >> "$ST"; }
SID=claude-sonnet-5-5
SH=(--runs 5 --retry-runs 0 --graders 2 --grader-model claude-sonnet-5-5 --workers 3 --timeout 900)
MI_NEW=(--skill mock-interview --eval 9 --eval 10 --eval 11 --eval 12 --eval 13)
declare -A ARMF=([alone]="--via skill --layout plugin" [tuesday]="--via tuesday")
declare -A REGRADE=([alone]=$RUNS/sonnet/alone/part-5/killed/regrade-20261120T011726Z.txt
                    [tuesday]=$RUNS/sonnet/tuesday/part-5/killed/regrade-20261120T011727Z.txt)
declare -A RERUN=([alone]=$RUNS/sonnet/alone/part-5/killed/rerun-20261120T011646Z.txt
                  [tuesday]=$RUNS/sonnet/tuesday/part-5/killed/rerun-20261120T011647Z.txt)

if [ "${1:-}" = --driver ]; then
  run_one() {  # run_one <label> <worktree> <log file> <argv...>
    local lab=$1 wt=$2 lf=$3; shift 3
    [ -e "$lf" ] && { status "$lab not started: its log $lf exists"; return; }
    (cd "$wt" && "$K/tools/logged.sh" "$lab" "$PY" "$@" > "$lf" 2>&1); local code=$?
    if grep -q '^Refused before any call\|^refused:' "$lf" 2>/dev/null; then status "$lab REFUSED by the runner (exit $code): see $lf"
    elif grep -q '^Traceback (most recent call last)' "$lf" 2>/dev/null; then status "$lab CRASHED (exit $code): see $lf"
    else status "$lab exit $code"; fi
  }
  arm() {
    local a=$1 OUT=$RUNS/sonnet/$1/part-5
    local ARGV=(evals/run_fixtures.py "${MI_NEW[@]}" --model $SID ${ARMF[$a]} "${SH[@]}"
                --expect "$M/frozen/expect/sonnet/$a/mi-new.json" --out "$OUT")
    run_one "sonnet-$a-mi-new-regrade" "$WT_CAND" "$OUT.regrade-1.log" "${ARGV[@]}" --stems "${REGRADE[$a]}" --skip-execute
    run_one "sonnet-$a-mi-new-rerun" "$WT_CAND" "$OUT.rerun-1.log" "${ARGV[@]}" --stems "${RERUN[$a]}"
  }
  status "start $LABEL"
  arm alone & arm tuesday & wait
  for e in "${E23[@]}"; do
    OUT="$RUNS/sonnet/${E23_FOLDER[$e]}"; mkdir -p "$(dirname "$OUT")"
    run_one "sonnet-e23-$e" "$WT_BASE" "$OUT.log" evals/run_fixtures.py --skill "${e%-*}" --cases "$M/frozen/e23/e23-$e.json" \
      --model $SID --via skill --layout plugin "${SH[@]}" --expect "$M/frozen/expect/sonnet/e23/$e.json" --out "$OUT"
  done
  status "done"
  exit 0
fi

[ -f "$M/logs/preflight/ok-$(claude --version 2>/dev/null | head -1 | tr ' ()' '_').json" ] || ls "$M/logs/preflight/" | grep -q "ok-$(claude --version | head -1 | cut -d' ' -f1)" \
  || { log "NOT STARTED: no passing preflight for this CLI"; exit 1; }
for a in alone tuesday; do for f in "${REGRADE[$a]}" "${RERUN[$a]}"; do [ -s "$f" ] || { log "NOT STARTED: $f missing"; exit 1; }; done; done
for e in "${E23[@]}"; do OUT="$RUNS/sonnet/${E23_FOLDER[$e]}"
  [ -e "$OUT" ] && [ -n "$(ls -A "$OUT" 2>/dev/null)" ] && { log "NOT STARTED: $OUT exists"; exit 1; }; done
TUESDAY_SCAN_ACCOUNT_EMAIL=$(python3 -I -B "$K/lib/account_email.py")
[ -n "$TUESDAY_SCAN_ACCOUNT_EMAIL" ] || { log "NOT STARTED: no account email for the scan"; exit 1; }
export TUESDAY_SCAN_ACCOUNT_EMAIL
line=$($METER "before-$LABEL" 2>&1 | tail -1); u=$(echo "$line" | sed -n 's/.*seven-day \([0-9.]*\).*/\1/p')
log "before: $(now), CLI $(claude --version | head -1), meter: $line"
[ -n "$u" ] || { log "NOT STARTED: no meter reading"; exit 1; }
rule=$(python3 -I -B "$K/lib/stop_rule.py" start sonnet "$u"); rc=$?; log "$rule"
[ $rc -eq 0 ] || { log "NOT STARTED: the stop rule bars recovery at this reading"; exit 1; }
: > "$ST"; start=$(date -u +%s)
setsid bash "$SELF" --driver > "$ST.driver.log" 2>&1 < /dev/null &
DRV=$!; sleep 1; PG=$(ps -o pgid= -p "$DRV" 2>/dev/null | tr -d ' '); [ -n "$PG" ] || PG=$DRV
log "started: driver $DRV, process group $PG; guard every ${GUARD_INTERVAL}s, stop at $GUARD_STOP; status in $ST"
"$K/tools/guard.sh" "$LABEL" "$PG" "$ST" > /dev/null 2>&1 &
GUARD=$!
wait "$DRV"; dcode=$?
if ! grep -q ' done$' "$ST" && grep -q 'stopping the step' "$ST"; then wait "$GUARD" 2>/dev/null
else pkill -P "$GUARD" 2>/dev/null; kill "$GUARD" 2>/dev/null; wait "$GUARD" 2>/dev/null; fi
secs=$(( $(date -u +%s) - start ))
line=$($METER "after-$LABEL" 2>&1 | tail -1)
log "after: $(now), $((secs/3600))h$(( (secs%3600)/60 ))m, CLI $(claude --version | head -1), meter: $line"
grep -E ' exit [0-9]+$| REFUSED | CRASHED | not started' "$ST" | sed "s/^/  /" | tee -a "$LOG"
grep -q ' stopped$' "$ST" && { log "STOPPED BY THE GUARD"; exit 4; }
bad=$(( $(grep -E ' exit [0-9]+$' "$ST" | grep -vE ' exit (0|1|3)$' | wc -l) + $(grep -c ' CRASHED \| REFUSED ' "$ST") ))
[ "$dcode" -eq 0 ] && [ "$bad" -eq 0 ] || { log "recovery ended with exit $dcode and $bad command(s) outside exit 0, 1 or 3"; exit 5; }
# Seal the whole Sonnet step as run_step.sh does: every part of both arms and the seven replays, with logs.
SEAL="$M/sealed/sonnet-quality-$(date -u +%Y%m%dT%H%M%SZ)"; mkdir -p "$SEAL/sonnet"
for a in alone tuesday; do for p in part-1 part-4 part-2 part-5; do
  mkdir -p "$SEAL/sonnet/$a/$p"; cp -a "$RUNS/sonnet/$a/$p/." "$SEAL/sonnet/$a/$p/"
  cp -a "$RUNS/sonnet/$a/$p".*log "$SEAL/sonnet/$a/" 2>/dev/null; done; done
for e in "${E23[@]}"; do f=${E23_FOLDER[$e]}; mkdir -p "$SEAL/sonnet/$f"; cp -a "$RUNS/sonnet/$f/." "$SEAL/sonnet/$f/"
  cp -a "$RUNS/sonnet/$f.log" "$SEAL/sonnet/$f.log" 2>/dev/null; done
cp -a "$STATUS_DIR/sonnet-quality.status" "$ST" "$SEAL/"; chmod -R a-w "$SEAL"
sl=$(cd "$SEAL" && find . -type f | sed 's|^\./||' | LC_ALL=C sort | while read -r f; do
  echo "$f $(sha256sum "$f" | cut -c1-64)"; done | sha256sum | cut -c1-64)
log "sealed: $SEAL ($(find "$SEAL" -type f | wc -l) files, listing sha256 $sl)"
log "recovery done"
