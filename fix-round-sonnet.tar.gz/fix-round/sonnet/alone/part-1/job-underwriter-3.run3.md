I'll read the skill's reference files before building the assessment.
**Is this worth pursuing? No. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in our Austin office 5 days a week — no exceptions), R2 ($70–85k base)
- `must_have` — direct: R3, R4, R5, R6 · unclear: R7 (SEO/content), R8 (brand, PR, partnerships), R9 (sales ops)

R3, R4, R5, R6 — your evidence matches the core growth mandate; R7, R8, R9 — functions your summary doesn't mention; R1, R2 — these fail however strong the rest is.

**Opportunity ledger.** Your "something feels off" has support in the posting: several full functions bundled into a team of one with no stated budget or success definition (RR1, RR5, RR6), expectations of evenings and weekends (RR4), and unquantified equity (RR7). The employer is unverified (RR8). The posting does disclose pay and reporting line (RR9).

- **Hard gates:** failed: R1 (On-site in our Austin office 5 days a week — no exceptions), R2 ($70–85k base).
- **Severe red flags:** RR2 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** R1 would need remote-from-Portland terms, and R2 a base of $150k or more. The posting says "no exceptions" on the first and states its range for the second.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, "e-commerce enablement startup, Series A, profitable since day one"; existence, stage and profitability unverified (RR8) | `[grounded]` JD header |
| Mandate | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin five days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; no equity figure given | `[grounded]` JD |
| Success metrics | None stated, "success metrics will evolve as we learn"; no first-90-day or first-year outcomes | `[grounded]` JD silent |
| Scope read | Seven functions under one title for one person reads as several roles bundled together | `[inferred]` from the function list against "team of one" |
| Market calibration | Not established. The role-family sweep did not run, so no market band is offered for this title and scope | `[grounded]` research unavailable this run |
| Unknowns | Budget, hiring plan, equity terms, who the customers are (which sets how close your B2C subscription background sits), board composition | `[grounded]` JD silent |
| Contradictions | None inside the posting. Not checked against a careers page | `[grounded]` target 1 unavailable |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in our Austin office 5 days a week — no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your constraint (remote-only, Portland, not relocating), which is your own, specific and confirmed. Fit fails because the JD allows no exceptions | `[grounded]` JD quote and your stated constraint | Surface in snapshot; only the employer changing terms or you revising the constraint resolves it |
| R2 | $70–85k base, against your floor of $150k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor, which is your own and confirmed. Fit fails because the top of the range is $65k below it, and the posting gives no equity figure to weigh | `[grounded]` JD figure and your stated floor | Surface in snapshot; same resolution as R1 |
| R3 | Own all revenue growth end to end | must_have | direct | medium | none | You stated scaling one company from $8M to $40M ARR over three years with a budget you controlled. Confirmed and specific, but no inspectable artifact yet, so expect a probe on your share of that growth. Function-by-function breadth is carried by R5–R9. The posting doesn't say who Novaline's customers are, so how closely a B2C subscription context transfers is open | `[grounded]` your intake statement; `[inferred]` context difference from "e-commerce enablement" | For other roles: a board deck or ARR dashboard would raise to high |
| R4 | 8+ years growth leadership | must_have | direct | medium | none | You stated 9 years in growth with Growth lead, then Head of Growth titles and teams of 3–7. The split between leadership-titled years and total years isn't stated, so I read it at the lower claim | `[grounded]` your intake statement | none |
| R5 | Paid acquisition | must_have | direct | medium | none | You stated owning paid at both companies. Confirmed, no inspectable proof yet | `[grounded]` your intake statement | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You stated owning lifecycle, with Braze depth. Confirmed, no inspectable proof yet | `[grounded]` your intake statement | none |
| R7 | SEO/content | must_have | unclear | none | discovery | Your summary doesn't mention SEO or content. Discovery rather than capability, since a summary isn't a full history | `[grounded]` intake silent | none for this posting; revisit for other roles listing it |
| R8 | Brand, PR, partnerships | must_have | unclear | none | discovery | Same: nothing in your summary either way | `[grounded]` intake silent | none for this posting; revisit for other roles |
| R9 | Sales ops | must_have | unclear | none | discovery | Same: nothing in your summary either way | `[grounded]` intake silent | none for this posting; revisit for other roles |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | No mention in your summary | Doesn't move this decision, since the gates fail; it would matter for other postings that list it | Owning organic landing pages or content for a subscription funnel; briefing writers or agencies; reporting organic share of acquisition | A GA4 organic-channel report or a content calendar | `[grounded]` intake silent; `[inferred]` this doesn't move the status, from R1 and R2 failing |
| G2 | Brand, PR, partnerships (R8, must_have) | discovery | No mention in your summary | Same | Affiliate, influencer or co-marketing deals; launch or funding press; a partner integration you brokered | A partnership agreement, a press hit, a co-marketing results recap | `[grounded]` intake silent; `[inferred]` as G1 |
| G3 | Sales ops (R9, must_have) | discovery | No mention in your summary | Same | Lead routing or lifecycle-to-sales handoffs; pipeline or CRM reporting; trial-to-paid sales assist | A pipeline dashboard or routing doc | `[grounded]` intake silent; `[inferred]` as G1 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles may be folded into one title and priced below it. Medium, not high, since no market band was researched | `[generic]` bundled roles tend to be priced junior; `[inferred]` function count from the JD | Which of these functions are expected in the first six months, and which would this role own with budget or contractors? | unresolved |
| RR2 | On-site five days, no exceptions, against remote-only (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The terms are incompatible with your stated remote-only, Portland-based position, whatever the role's merits | `[grounded]` JD quote and your constraint | Is the five-day on-site requirement fixed for this role, as the posting says? | confirmed |
| RR3 | Base pay below your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The top of the range is $65k below $150k, and no equity figure is stated | `[grounded]` JD figure, your floor, subtraction | Is the $70–85k base range fixed for this role? | confirmed |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine rather than occasional, set against sole ownership of the whole function | `[inferred]` from the phrasing and "team of one" | How many evenings or weekends did the team work last quarter, and how was that time recognized? | unresolved |
| RR5 | Success undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You would be accountable for all revenue growth with no stated definition of success | `[inferred]` from the JD's mandate against its silence on metrics | What outcome would count as success at six and at twelve months, and who sets it? | unresolved |
| RR6 | Authority and resources unstated | unknown | — | "we believe in players who don't need a bench" | No budget, hiring plan or decision rights are stated | `[grounded]` JD silent | What budget and hiring plan are committed to this role in year one? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | Percentage, vesting and strike are not stated | `[grounded]` JD silent | What percentage, vesting schedule and strike price does the grant carry? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | low | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Low, because the search was refused rather than returning nothing | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Pay disclosed and reporting line named | positive_signal | — | "Report to the CEO with a dotted line to the board"; "$70–85k base" | Terms are disclosed rather than withheld | `[grounded]` JD | Who holds the board dotted line, and how often would you meet them? | noted |

## Application plan

`resume_edits_pending_approval`: every row below is proposed, not applied, and nothing is final without your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on this posting as written | see R1, R2, RR2, RR3 | `[grounded]` the two failed gate rows | pending your approval |
| A2 | Before reading future postings in full, filter on remote eligibility and a base of $150k or more | These are your two stated hard constraints | `[grounded]` your stated constraints | pending your approval |
| A3 | If you apply anyway, ask the register's verification questions verbatim, starting with RR2 and RR3 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| E1 | For other applications: lead the relevant entry with "Scaled the company from $8M to $40M ARR over three years, with the budget under my control", after you confirm which role and company it belongs to | Traces to your sentence "Scaled one company from $8M to $40M ARR over three years with a budget I controlled"; see R3 | `[grounded]` your intake statement | pending your approval |

## Evidence status

Stage assumed: evaluating. Verified: your own constraints on R1 and R2 (your own statements, nothing inspectable exists). Unverified leads: the claims behind R3, R4, R5 and R6, which are intake prose awaiting a probe or an artifact. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Series A Austin Head of Growth"; the host refused it. Would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A base salary range 2026"; the host refused it. Would have moved role reality's market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, only "the CEO", so there was no query to form |

I can write this up as `tuesday-dossier.md` if you want it to carry into later steps.

**Upgrade menu**

- Search permission granted: verifies whether Novaline exists as described and whether the posting is live (RR8, role reality), and adds a market band for this title and scope (RR1). Neither can change the status, since R1 and R2 are your own confirmed gates.
- The CEO's name: role reality's scope read, and which of your stories to lead with for that reader.
- A board deck, ARR dashboard or finance recap behind the $8M to $40M scale-up: raises R3 from `medium` to `high`. The same goes for a Braze or paid-channel report for R5 and R6.
- Examples of SEO/content, brand/PR/partnerships or sales-ops work (G1, G2, G3): moves R7, R8 and R9 for postings that list them.

No questions this turn: R1 and R2 rest on your own confirmed constraints, and no answer I could ask for would change the status.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.