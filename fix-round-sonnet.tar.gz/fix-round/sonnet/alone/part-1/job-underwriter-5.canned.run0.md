Checking that the posting and company are live and match what you pasted, then I'll write the assessment.
Yes, I'd apply. The Pellucid role is live on its own careers page and the text matches what you pasted. Your background lines up with the posting, and the open items are things to check, not reasons to hold back.

## Decision snapshot

**Yes, it's worth applying. Your background lands directly on R3, R4, R5, R6, R7 and R8, and the pay is posted. Two gates, R1 and R2, are still unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 against your floor)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (a dbt-modelled warehouse in BigQuery) · unclear: R10 (ingestion from our app and CRM), R11 (the data contracts our analysts depend on)

R9 — BigQuery is new to you, a tooling ramp; R10, R11 — the posting's ingestion and contract duties are not covered by anything you've told me yet.

**Opportunity ledger.** The terms are sound where they are stated: the posted range straddles the report's median (RR1), and the employer and posting check out on the company's own site (RR5). The open items are scope breadth (RR2), no named manager, team or success measures (RR3), and unstated equity terms (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You can work from the US, or from Denver (R1).
  2. $148,000 clears your pay floor (R2).
  3. The ingestion and data-contract duties turn out to be work you can credibly take on, which you can check by asking RR2 and RR3 in the loop (R10, R11).
  4. BigQuery is framed honestly as new to you (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016 in Denver, 264 employees, Series C of $52M in February 2026. Stated only on its own about page. | `[grounded]` company about page, fetched via search result |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Location and pay | Remote (US) or Denver office; $148,000–$166,000 plus equity | `[grounded]` JD, matches the live careers page |
| First-90-day and first-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | Broader than a single domain: ingestion, warehouse modelling and contract ownership are listed together, with no team, manager or boundary named | `[inferred]` from the JD's three duty areas against the report's typical scope of one domain's pipelines |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500; "Senior" typically means 5–8 years. The posted range runs from just under the median to above the top of the interquartile range. Your 6 years sits mid-band. This is a norm, not Pellucid's offer. | `[grounded]` Datawright 2026 report as you supplied it, n=2,310; `[generic]` as a norm for the role family |
| Unknowns | Hiring manager, team size and the split between ingestion and modelling; success measures; equity terms; whether "salary" means base | `[grounded]` JD silence |
| Contradictions | None found between the pasted posting and the live page | `[grounded]` careers page fetched |

## Evidence map

I have not seen a CV, only your description of your background. Every candidate claim below rests on that, so none is above `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or what you can work from, so there is no statement of yours to grade and the gate is unsettled | `[grounded]` JD, your message silent | Question R1 below |
| R2 | Salary $148,000–$166,000 plus equity, against your pay floor | hard_gate | unclear | none | hard_gate | You haven't stated a floor. The posted range is above the report's median at its top and slightly below it at its bottom, so a floor around current market would likely clear. That is a reading, not a settled fact. | `[grounded]` JD and report figures; `[inferred]` that a market-level floor clears | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You described 6 years at a B2B payroll company. This is a length-of-experience requirement, not a gate, and it clears the stated minimum. Self-report only. | `[grounded]` your message; `[generic]` that 5–8 years is typical for "Senior" per the report | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is unprobed, so expect a technical screen. | `[grounded]` your message | Offer: a sanitized query or pipeline sample would raise this to `high` |
| R5 | dbt | must_have | direct | medium | none | You built the project, about 180 models. Scale and ownership are specific, but nothing is inspectable yet. | `[grounded]` your message | Offer: dbt docs screenshots or a sanitized model list would raise this to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake satisfies "a cloud warehouse", the wording used in the requirements list. BigQuery appears only in the duties, which is R9. | `[grounded]` JD requirement wording and your message | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is your orchestrator, named in the JD's own wording. Depth is not described yet. | `[grounded]` your message | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. "Set up" is your word and I keep it, with no wider claim about coverage. | `[grounded]` your message | Offer: GE data docs or a sanitized checkpoint config would raise this to `high` |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The duty names BigQuery, and you've never used it. Carries over: dbt modelling and warehouse design on Snowflake. Limit: BigQuery's cost model, partitioning and tooling are unexercised. Strengthener: a small personal BigQuery project, only if you actually build one. | `[inferred]` adjacency derived from your Snowflake and dbt work | G1 |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Your message does not describe ingestion from outside systems. Work in a payroll company may include it, but I have no confirmed claim. | `[grounded]` your message silent | Question G2/G3 below |
| R11 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing in your message mentions agreements with downstream analysts. Your dbt tests and GE suite may be adjacent, but I won't treat that as a claim. | `[grounded]` your message silent | Question G2/G3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake plus dbt, with no BigQuery use | The posting names it in the duties, not the requirements list, so it reads as a ramp-up item rather than a screen | A BigQuery sandbox project where you rebuild a slice of your dbt models; any shared-warehouse migration you took part in | A repo or short write-up of the personal project, if you build one | `[grounded]` JD placement of BigQuery in the duties; `[generic]` that a warehouse switch is usually a ramp for someone with another warehouse and dbt |
| G2 | Ingestion from external systems (R10, important) | discovery | No description of source ingestion | This is the first duty the posting lists, and an interviewer would ask about it | Loading from a vendor API or a CRM; building or owning a connector; handling schema drift or late data from a source you didn't control | A pipeline diagram, DAG screenshot or runbook, sanitized | `[grounded]` JD lists ingestion first; `[generic]` that interviews for this family probe source-system work |
| G3 | Data contracts (R11, important) | discovery | No description of agreements with analysts | The posting names the contract work as something analysts "depend on" | Agreed schemas or freshness expectations with analytics; dbt contracts or tests that gate a model; named owners for a table | A contract doc, dbt schema file or model-ownership list, sanitized | `[grounded]` JD wording; `[inferred]` that your dbt tests and GE suite may overlap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, and positioned across the market median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | No seniority-pay mismatch: the range straddles the report's $151,000 median and its top passes the $163,500 upper quartile. "Salary" is assumed to mean base. | `[grounded]` JD figures and the report you supplied; `[inferred]` that salary means base | Where in the range would someone with 6 years land, and is the figure base? | noted |
| RR2 | Scope breadth: ingestion, warehouse and contracts in one role | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The role may fold several functions into one seat, against a typical one-domain remit. It could also be a team with this as the shared mandate. | `[inferred]` from the JD's duty list against the report's typical scope | Is this the only data engineer, or one of a team, and who owns ingestion versus modelling today? | unresolved |
| RR3 | No named manager, team size or success measures | unknown | — | "The posting names no hiring manager"; the JD states no outcomes | Cannot judge authority, support or what success means in year one | `[grounded]` JD silence | Who would I report to, how large is the data team, and what should be true at 90 days and at a year? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The grant type, size and vesting may materially change the offer's value | `[grounded]` JD states equity without terms | What is the equity grant, type, vesting schedule and strike or share count? | unresolved |
| RR5 | Employer and posting confirmed on the company's own site | positive_signal | — | "Accepting applications"; "Series C ($52M, February 2026)" | The posting is live and consistent. The funding and headcount are stated only by the company itself, with no independent source found. | `[grounded]` careers and about pages; `[inferred]` that self-reported figures remain unverified | What is the current data team size and runway context, as you can share it? | noted |

## Application plan

All rows below, and the positioning advice in the prose after the table, are proposals pending your approval. I haven't seen your CV, so none of the wording is final.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the dbt project: "Built the dbt project, about 180 models, on Snowflake" | R5, with your own figures | `[grounded]` your message | pending your approval |
| E2 | Name "Great Expectations" and "Airflow" in outcome bullets, not a tools list: "Set up the Great Expectations test suite"; "Orchestrated pipelines in Airflow" | R7, R8, in the JD's own terms | `[grounded]` your message | pending your approval |
| P1 | State plainly that your warehouse experience is Snowflake and that BigQuery is new to you. Don't write BigQuery into skills. | R9, honest adjacency | `[grounded]` your message | pending your approval |
| W1 | Optional: rebuild a small slice of your dbt work on a BigQuery sandbox, and claim only what you complete | G1, R9 | `[inferred]` from the gap | pending your approval |
| Q1 | Ask RR1 to RR4 verbatim in the loop, especially RR2 and RR3 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Contact the recruiter about the manager and team size before the first screen, since the posting names neither | RR3 | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet. The claims behind R3, R4, R5, R6, R7, R8 and R9 rest on your own account in this message.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The call checked your pasted material. It moved role reality's organization and contradictions rows and RR5: the posting is live and the text matches. Both pages are the company's own, so funding and headcount remain self-reported. |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration row and RR1, RR2. A search could not change those outputs. |
| 3. Hiring manager's public footprint | n/a | The posting names no manager, so there is no query to form. |

## Dossier offer

If you'd like, I can write all of this up as a `tuesday-dossier.md` you can keep.

## Upgrade menu

- Your CV: lets me check whether the evidence for R3 to R8 is buried (presentation gaps) and turn E1 and E2 into reviewed edits.
- Inspectable artifacts (dbt docs or a sanitized model list for R5; GE data docs for R8; a sanitized query or DAG for R4, R7): each would lift its row from `medium` to `high`.
- Your answers on where you can work and your pay floor: close R1 and R2, the two hard-gate rows.
- Any ingestion or contract work you can describe (G2, G3): could move R10 and R11 off `unclear`.
- A BigQuery project you actually build: strengthens R9's bridge.
- The hiring manager's name, once you know it: would feed the role-reality scope read and which story the plan leads with.
- A deeper company pass (funding, leadership changes, recent news, public employee reports; up to 5 more searches and 2 more fetches): say the word and I'll run it.

## Questions

R1 — Where will you work from: are you in the US with the right to work there, or able to be in Denver?

R2 — What is your pay floor for a move, and does $148,000 clear it?

G2, G3 — At your payroll company, what did you personally own when data arrived from outside systems (an app, a CRM, a vendor feed), or when you handed tables to analysts under agreed schemas or freshness expectations?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.