I'll read the reference files the skill requires before building the assessment.
Yes, it looks worth applying to, on conditions. R1 and R2, the location and pay terms, haven't been checked against you yet, and I couldn't confirm the posting is live. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R7, R8 · unclear: R9 (Ingestion from app and CRM)
- `important` — adjacent: R6 (BigQuery warehouse) · unclear: R10 (Data contracts analysts depend on)

R1, R2 — location and pay terms not yet checked against you; R9, R10 — your evidence is silent on ingestion sources and on contracts; R6 — a Snowflake-to-BigQuery bridge with its limit named.

**Opportunity ledger.** The posted pay sits inside the market band you supplied (RR1), and equity is unquantified (RR2). Team shape and reporting line are unstated (RR3, RR4). The employer and posting are unverified because my check was refused (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 meet your own constraints; (2) the posting verifies as live — RR5; (3) the BigQuery bridge is framed as adjacent, never as BigQuery experience — R6.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026. Taken from the about-page text you pasted; I could not check it against the live site | `[grounded]` pasted about page |
| Mandate | Pipelines behind reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Terms | Remote (US) or Denver office; $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | Three linked areas (ingestion, warehouse modelling, contracts) for one reporting platform, which is broader than one domain's pipelines. "Build and run" may include on-call, which the JD doesn't say | `[inferred]` from the JD's three areas against the report's scope norm |
| Market calibration | Senior at Series B–D: base median $151,000, interquartile range $139,000–$163,500; "Senior" typically 5–8 years; typical scope is one domain's pipelines, no direct reports. The posted range runs from just under the median to above the upper quartile. This is a pattern, not this employer's offer | `[generic]` the Datawright report, supplied by your recruiter, n=2,310; `[grounded]` the JD's posted range |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Team size; whether this is a backfill or new headcount; hiring manager (none named); equity terms; on-call expectations; how much BigQuery ramp-up is expected | `[grounded]` JD silence |
| Contradictions | None visible between the JD and about text; not cross-checked against the live site | `[grounded]` the two pasted texts |

## Evidence map

Your background is typed prose, so it carries the standing of a CV: leads, with `medium` as the ceiling until something inspectable is attached.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you are or your location constraints, so nothing settles whether the terms fit | `[grounded]` JD term; no constraint from you | Gate question, Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor from you. The equity part of the term is unquantified in the posting | `[grounded]` JD term; no constraint from you | Gate question, Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company, confirmed and specific but with no inspectable artifact | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both; strength of use is not shown by an artifact | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse | `[grounded]` your background | A repo, DAG screenshot or model-lineage view would raise it to `high` |
| R6 | A BigQuery warehouse | important | adjacent | medium | transferability | The dbt-on-Snowflake work carries over. Limit: you haven't used BigQuery, so its own cost model and table-design features are untested by you. Name that limit wherever the bridge is used | `[grounded]` your statement; `[generic]` that warehouses differ in those features | Gap queue G3 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow for orchestration. The JD names Airflow itself | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations suite. Its coverage and scope are not stated | `[grounded]` your background | none |
| R9 | Ingestion from the app and CRM | must_have | unclear | low | discovery | Pipelines are confirmed under Airflow, but you haven't said what they ingested from. Whether any were product-app or CRM sources is open | `[grounded]` your background is silent on sources | Gap queue G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is a lead, since tests on tables analysts used may count. No agreement or ownership arrangement with analysts is stated | `[inferred]` from the suite, which is not itself a contract | Gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, must_have) | discovery | Pipelines under Airflow, with no sources named | A `must_have` row at `unclear`; the answer could move it to `direct` | Loading product-database or event data into the warehouse; syncing a CRM or other third-party API; building a connector or using a managed one | A DAG file, a source list, a pipeline diagram | `[grounded]` background silent on sources; `[inferred]` that the answer strengthens the case |
| G2 | Data contracts (R10, important) | discovery | A Great Expectations suite, with nothing on agreements with analysts | Contracts are named in the JD's opening mandate, and the suite may or may not be the same kind of work | A schema or column agreement with analysts; a change-notice process for models they depend on; checks you ran on tables analysts used | A README, a model doc, the suite's config | `[grounded]` background; `[inferred]` suite adjacency |
| G3 | BigQuery (R6, important) | transferability | Snowflake dbt experience, no BigQuery | Carries over, with the limit named in R6. A small dbt project run on BigQuery would narrow it | A personal project on BigQuery with dbt, if you choose to build one | A repo link | `[grounded]` R6; `[generic]` that a work sample narrows a tool-specific gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay vs. market | positive_signal | — | "$148,000–$166,000 plus equity" | The range is in line with the market band you supplied, so it doesn't look under-priced for the seniority | `[grounded]` JD range; `[generic]` the report's band | What does the full compensation package look like, equity included? | noted |
| RR2 | Equity unquantified | unknown | — | "plus equity" | Grant size, vesting and strike may be unstated at posting stage | `[generic]` pattern: postings often omit equity terms | What equity is offered for this level, and on what vesting and strike terms? | unresolved |
| RR3 | Team shape and scope | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Scope may exceed one domain, or the role may be the first or only data engineer | `[inferred]` from the three areas against the report's scope norm | How many data engineers are on the team, and who owns the warehouse today? | unresolved |
| RR4 | No hiring manager or reporting line | unknown | — | "Senior Data Engineer — Pellucid Learning" | Reporting line unknown, so the role's authority is unclear | `[grounded]` the JD names no manager | Who does this role report to, and who will I interview with? | unresolved |
| RR5 | Employer and posting not established | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)" | The company description and posting could not be checked against their live pages. My check was refused, and the pasted text may be stale. I took the lower severity because the text you pasted is detailed and internally consistent | `[generic]` pattern: a pasted posting can be stale; not a claim about this company | Is this role currently open, and is it a backfill or new headcount? | unresolved |

## Application plan

All rows are proposed language or actions, each pending your approval, and the edits are `resume_edits_pending_approval`. Each line traces to your own sentences, and none borrows the JD's vocabulary for your history.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with your dbt work as you described it: built the dbt project on Snowflake, about 180 models. Keep "Snowflake" explicit; don't blur it into BigQuery | R5, R6 | `[grounded]` your wording | `resume_edits_pending_approval` |
| E2 | Describe the testing work as you did: set up the Great Expectations suite. Don't upgrade the verb, and don't relabel it as data contracts | R8, R10 | `[grounded]` your wording | `resume_edits_pending_approval` |
| P1 | In the cover note or recruiter call, say plainly your warehouse experience is Snowflake, that you haven't used BigQuery, and that the dbt and orchestration work carries over | R6 | `[grounded]` your statement of no BigQuery use | pending your approval |
| A1 | Before investing effort, ask the employer the RR5 question and the RR3 and RR4 questions in the first call | RR3, RR4, RR5 | `[grounded]` register | pending your approval |
| A2 | If the posting verifies and Q1 clears, apply with the gaps G1 and G2 answered from your own history if you can | R9, R10 | `[inferred]` that answers would raise those rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried to fetch the careers page and run one search for the company. Both were refused. It would have moved whether the posting is live and the about text current, role reality's contradictions row, and RR5 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration and RR1; a search could not change them |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Closing

I can write this up as a `tuesday-dossier.md` if you want a file to keep.

**Upgrade menu**

- Your location and pay floor → R1 and R2 move to `direct` or `hard_gate_fail`. A failure would change the status.
- A source list or DAG for your ingestion work → R9 moves toward `direct`, and G1 closes.
- A README, model doc or the Great Expectations config showing analyst-facing checks → R10 moves toward `direct`, and R8 can rise to `high`.
- A repo or lineage screenshot of the dbt project → R5 to `high`.
- Permission for web checks, or the recruiter's confirmation that the posting is live → RR5 closes.
- A deeper research pass on Pellucid Learning (funding, leadership changes, public reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- R1, R2 — Do the posting's terms, Remote (US) or Denver and $148,000–$166,000 plus equity, fit your own non-negotiables?
- G1 — Which sources did your Airflow pipelines ingest from, and did any come from a product app or a CRM, and what part was yours?
- G2 — Did you agree any schema or change rules with the analysts who used your models, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.