I'll read the skill's reference files before building the assessment.
**Yes, worth applying to, once two things check out: R1 (fully remote in the UK) is confirmed and RR1 (that Brindlemoor and the posting are real as described) is verified. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R8 · adjacent: R7a (Recommendations to underwriting) · unclear: R5b (Monitor rating models), R7b (Recommendations to product)
- `preferred` — direct: R9

R1 — location term not yet confirmed; R5b, R7b — below `direct` on specifics the background doesn't cover; R7a — nearest to `direct` but unproven; R4 (`medium`) — GLM claim rests on typed background, no artifact.

**Opportunity ledger.** Not yet established: whether the employer and posting are real as described (RR1), the pay (RR2), reports (RR3), decision rights (RR4) and success measures (RR6). One entry runs the other way: responsibilities are concrete and a senior manager is named (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, via the careers page or recruiter, with RR1 answered; (2) R1 is confirmed as workable for you; (3) the recommendation work with underwriting and with product (R7a, R7b) is stated at exactly what you did.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; existence, stage and size not established | `[grounded]` JD header; checks were not run (see Evidence status) |
| Title and mandate | Senior Pricing Analyst: own pricing analytics for the pet product, build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Odile Varga, Director of Pricing | `[grounded]` supplied by you |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Compensation | No figure in the JD as pasted | `[grounded]` JD |
| Scope read | A single-product pricing analytics post whose four stated duties all sit within modelling, experimentation and stakeholder reporting, so not an obviously bundled role | `[inferred]` from the responsibility list |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not run. Four years, GLM and SQL/Python together are an ordinary shape for a senior pricing analytics post, as a pattern only; no pay band is offered because the salary search did not run | `[generic]` role-family pattern |
| Unknowns | Employer facts; pay; direct reports; team size; decision rights over rate changes; what already exists versus what is built from scratch | `[grounded]` JD silence on each |
| Contradictions | None found between the pasted JD and your background; the JD was not checked against a careers page | `[grounded]` the two inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | The JD states the term. You have not stated where you're based or any limit, so the confidence grades the absence of a stated constraint. A UK employer is indirect context only. | `[grounded]` JD term; `[inferred]` UK location from the UK insurer | G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years in pricing analytics at a UK motor insurer, the last 2 as senior analyst. Typed background is self-report, so `medium` is the ceiling. Years of experience are not a gate. | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" shows use, not depth, and "strong" is the JD's word. No artifact has been inspected. | `[grounded]` your background | offer: a sanitized query or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book" is specific. The model is motor, and nothing has been inspected. | `[grounded]` your background | offer: model documentation or a sanitized spec would raise to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same claim as R4, read against the JD's "build". | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". That does not establish what was monitored or how, and attributing monitoring practice to you would be a guess. | `[grounded]` background wording | G3 |
| R6 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team" confirms the activity. It does not separate design from reading results, so expect a probe on which parts were yours. | `[grounded]` your background | none |
| R7a | Turn results into recommendations for underwriting | must_have | adjacent | medium | discovery | You worked tests with underwriting and present the quarterly pricing review to the head of underwriting. Presenting results is not stated as recommending, and the two are different kinds of work. | `[grounded]` your background | G2 |
| R7b | Turn results into recommendations for product | must_have | unclear | low | discovery | Product is not mentioned anywhere in your background, and the JD names it as a second audience. | `[grounded]` JD names product, background silent | G2 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | "I present the quarterly pricing review to the head of underwriting" meets the underwriting half of the JD's "or". | `[grounded]` your background | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer meets the requirement as the JD words it. Pet insurance is not asked for, and you have none. Pet rating typically weighs different risk factors from motor, such as breed and age, so that part is untested. | `[grounded]` background and JD wording; `[generic]` pet versus motor factors | none; say plainly the work was motor |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Fully remote (UK) (R1, hard_gate) | hard_gate | The JD states the term; your location and right to work are not given | A gate the inputs don't settle stays open; it is the one fact that can move the status | Not recovery work; a plain yes or no on whether the term works for you | None needed | `[grounded]` JD term, constraints not given |
| G2 | Recommendations for underwriting and product (R7a, R7b, must_have) | discovery | Tests run with underwriting and a quarterly review presented; no stated recommendation and no product contact | Two must-have rows sit below `direct`; an answer could move both | A test result that led to a rate or rule change; a pricing paper recommending an action; work with a product owner on cover, an excess option or an add-on | A test readout deck, a pricing-review paper, a change request | `[grounded]` background silent on recommendations and product; `[inferred]` an answer could raise both rows |
| G3 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" is stated; what was tracked and how often is not | A named duty in the JD; smaller decision impact than G2 | Actual-versus-expected tracking by segment; drift or recalibration checks; a dashboard or alert you set up | A monitoring dashboard screenshot or model review pack, sanitized | `[grounded]` wording of your claim; `[inferred]` lower impact than G2 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Nothing was checked, because the searches were refused. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | none: the JD as pasted has no figure | The figure may be unpublished, or the paste may have omitted it | `[grounded]` JD silent as pasted; `[generic]` pay is often withheld in postings | What is the salary range for this role? | unresolved |
| RR3 | Reports and team size unstated | unknown | — | "Own pricing analytics" | "Senior" and "own" could carry mentoring or reports; the JD lists none. This matters to you only if they exist. | `[inferred]` from scope wording against silence on reports | Does this role have direct reports or mentoring duties, and how big is the pricing team? | unresolved |
| RR4 | Decision rights unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend while others decide rate changes | `[inferred]` from the word "recommendations" against silence on authority | Who decides on rate changes, and what does this role control versus recommend? | unresolved |
| RR5 | Concrete responsibilities and a named senior manager | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope reads as coherent and the reporting line is a Director of Pricing | `[grounded]` JD text and the manager named by you | What is already in place — rating models, test framework, data — and what would I be building from scratch? | noted |
| RR6 | Success measures unstated | unknown | — | none: the JD gives no first-year outcomes | A demanding "own" mandate comes with no stated definition of success | `[grounded]` JD silent | What would a successful first six months look like? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role on Brindlemoor's own careers page, or with the recruiter, before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Settle R1 for yourself before applying (answer G1) | see R1 | `[grounded]` R1 | pending your approval |
| E1 | Resume line: "Built and maintained the GLM rating model for the young-driver book at a UK motor insurer" | see R4, R5a; every clause is your sentence | `[grounded]` your background | pending your approval |
| E2 | Resume line: "Ran 14 price tests with the underwriting team last year" (use the calendar year) | see R6; "14" stays on tests | `[grounded]` your background | pending your approval |
| E3 | Resume line: "Present the quarterly pricing review to the head of underwriting" | see R8 | `[grounded]` your background | pending your approval |
| P1 | Positioning: lead a cover note with E1 to E3 in that order, and say early that your insurance work is motor and you haven't worked on pet insurance | see R9; no claim is added | `[grounded]` your background and R9 | pending your approval |
| Q1 | Ask the RR2, RR3, RR4 and RR6 questions verbatim once in a conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Everything in this table is proposed and not applied: your approval covers the resume lines E1 to E3 (`resume_edits_pending_approval`) and the positioning advice P1.

## Evidence status

Verified: none yet. Every claim in the map comes from your typed background, which stands as unverified self-report until you confirm specifics or share an artifact. No memory leads were used, and nothing has been rejected.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused: "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst". Would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The search "senior pricing analyst UK insurance salary remote pet insurance" was refused. Would have moved the market calibration row and the pay comparison in RR2 |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing Brindlemoor" was refused; a name was given, so this is not `n/a`. Would have moved the scope read and the application plan's positioning |

I can save this as `tuesday-dossier.md` if you'd like to keep it or carry it into later steps.

## Upgrade menu

- Permission to run the refused web searches, up to 5 searches and 2 fetches, would verify the employer (RR1), set pay against a market band (RR2), add Odile Varga's published professional footprint to the scope read and positioning, and fill the market calibration row. A deeper pass could follow after that, up to 5 more searches and 2 more fetches.
- Your CV would let the map be checked against your actual wording and let E1 to E3 be proposed against real text.
- A sanitized query or notebook, model documentation, or a test readout would raise R3, R4 and R6 toward `high`.
- Your pay floor and any other non-negotiables would let R1 and RR2 be checked against you, and would clear the "constraints not given" flag.
- A link to the live posting would help close RR1.

## Questions

G1 — Does fully remote working within the UK work for you, with nothing about where you're based or your right to work getting in the way?

G2 — Which test or model results did you turn into a recommendation, who acted on it (underwriting, a product team, or both), and what changed?

G3 — What did you actually monitor on the young-driver rating model, how often, and with what (dashboards, actual-versus-expected checks, recalibrations)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.