Research is finished (three searches). Here is the write-up.

## Decision snapshot

**Yes, worth going for. You cover most of what the posting asks, and the stretch areas are forecasting and billing data (R8, R9, R10). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, hybrid, two office days), R2 (Pay £61,500–£67,000 plus share options)
- `must_have` — direct: R3, R5, R7 · adjacent: R4 (at a B2B software company), R6 (Strong SQL and spreadsheet modelling), R8 (Owning a forecast; quarterly forecast with the CFO), R9 (Working with finance on billing or revenue data)
- `important` — absent: R10 (Own billing data)

R8 — adjacent through the monthly pipeline review, company forecast not owned; R9 and R10 — billing and finance data are thin; R1 and R2 — unconfirmed, not failed.

**Opportunity ledger.** Employer established (RR1) and pay inside the market band (RR3). Unknowns to put to the employer: the listing on Quillfield's own site (RR2), option terms (RR4), success measures (RR6) and who owns billing data today (RR7). The bundled mandate is a low-severity risk signal (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two office days), R2 (Pay £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Bristol office days and the pay and options work for you — R1, R2, RR4; (2) you confirm what forecast work you have owned below company level, and present it as adjacent, never as company-forecast ownership — R8; (3) interviews show real support for billing data, since you have none of your own — R9, R10, RR7; (4) the listing is confirmed on Quillfield's own careers page — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` "About Quillfield" (quillfield.co.uk/about), seen as a search result |
| Role and terms | Revenue Operations Lead; Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Stated requirements | 4+ years in revenue operations, sales operations or similar analytics at a B2B software company; HubSpot or Salesforce administration; strong SQL and spreadsheet modelling; experience owning a forecast; experience working with finance on billing or revenue data | `[grounded]` posting |
| First-year outcomes | None stated. The earliest visible outputs would be a first quarterly forecast cycle with the CFO and a baseline of CRM against billing data | `[grounded]` posting silent; `[inferred]` outputs from the mandate's quarterly cadence |
| Hiring manager | Tamsin Achebe per the recruiter. A public profile lists Tamsin as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. The footprint is a title and one earlier role | `[grounded]` recruiter via you; profile (linkedin.example/in/tamsin-achebe), seen as a search result |
| Scope read | One "Lead" post carrying CRM, billing data, reporting and forecast, with no team stated. Tamsin's title suggests the role sits inside a RevOps function, but the posting gives no reporting line | `[inferred]` from the mandate list and the posting's silence on team, set against the Head of RevOps title |
| Market calibration | A UK B2B software revenue operations lead has a median base of £64,200, interquartile range £57,800–£70,400 (n=438). The posted £61,500–£67,000 sits inside that range around the median. Basis: one pay-guide result for 2026, not Bristol-specific, not fetched. Scope norms for the title were not researched. This is a band to expect, never Quillfield's offer | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` posting for the range |
| Unknowns | Team size; reporting line; success measures; option terms; who owns billing data today; whether the listing is on Quillfield's own site | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the about page on what the company does. The careers page itself was not returned | `[grounded]` about page against posting |

## Evidence map

Your background arrived as prose, so it stands at CV-equivalent self-report. That is why the candidate-claim rows sit at `medium` or lower.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The posting states the term. Your location and any limits were not given, so it is neither met nor failed; confidence is `none` because there is no statement of yours to grade | `[grounded]` posting; no candidate statement | Gate question G6 |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The posting states the figure. No pay floor was given, so fit is not established. The range sits inside the market band (RR3) | `[grounded]` posting; no candidate statement | Gate question G6 |
| R3 | 4+ years in revenue operations, sales operations or similar analytics | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team, clears the four stated. Self-reported, nothing inspected yet | `[grounded]` your intake message | none |
| R4 | The role to be at a B2B software company | must_have | adjacent | medium | discovery | Your five years were at a B2B payments company. Whether its product counts as software the posting's way is not established, so it is adjacent with that limit | `[grounded]` your intake message against posting wording | Describe the product on the CV; no question asked this turn |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certificate is not inspected, so `medium` | `[grounded]` your intake message | A Trailhead or credential record would raise to `high` |
| R6 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | You use SQL weekly and Excel daily. That shows use of the tools, not strength or modelling work specifically, so it is adjacent with that limit | `[grounded]` your intake message | A sanitized model or query sample |
| R7 | Build the pipeline and renewal reporting sales and finance run on | must_have | direct | medium | none | You rebuilt your company's pipeline and renewal dashboards and run the monthly pipeline review with your sales director. Whether finance used them is unstated, so that part is not claimed | `[grounded]` your intake message | A sanitized dashboard screenshot would raise to `high` |
| R8 | Experience owning a forecast; run the quarterly revenue forecast with the CFO | must_have | adjacent | medium | discovery | You have not owned the company forecast; finance did. The monthly pipeline review is the nearest confirmed work. Any forecast owned below company level is unknown | `[grounded]` your intake message | Question G1 |
| R9 | Experience working with finance on billing or revenue data | must_have | adjacent | low | discovery | The renewal dashboards are the nearest work, but whether they carried finance-sourced data or involved finance is unstated. You have never worked on billing data | `[grounded]` your statement on billing; `[inferred]` renewal data as revenue-adjacent from the dashboards described | Question G2 |
| R10 | Own billing data (a mandate responsibility, not a stated requirement) | important | absent | none | capability | You confirmed you have never worked on billing data, so there is no direct or adjacent evidence. The closure path is in G3 | `[grounded]` your intake message; `[inferred]` tier from the mandate wording | Closure path G3; carry as a material risk |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R8, must_have) | discovery | The company forecast was finance's. The monthly pipeline review is confirmed. Nothing says whether you built or maintained a forecast of your own | The posting makes the CFO forecast a core duty, so this decides how R8 is framed and whether it narrows | A UK-team pipeline or renewal forecast; a commit or best-case call; numbers you supplied to finance's forecast; a forecast-versus-actual tracker | A sanitized forecast sheet, a pipeline-review deck, an accuracy tracker | `[grounded]` your statements; `[inferred]` that an answer could move R8 |
| G2 | Finance and billing data (R9, must_have) | discovery | Renewal dashboards exist. Finance involvement and data source are unknown | R9 is a `must_have` row at `adjacent` with `low` confidence | Renewal values reconciled with finance; contract or invoice extracts feeding the dashboards; a CRM-to-finance data mismatch you chased | A sanitized dashboard spec, a reconciliation sheet | `[grounded]` your statements; `[inferred]` renewal data as the likeliest overlap |
| G3 | Billing data ownership (R10, important) | capability | You confirmed no billing-data work | The posting names it as part of the mandate | Closure path, not recall: learn how invoices and credit notes flow into recurring revenue figures, and reconcile CRM renewals against an invoice-style extract on data you already hold. Ask in interviews who owns billing data today (RR7) | A one-page sanitized reconciliation, if you build one | `[grounded]` your statement; `[inferred]` closure path |
| G4 | Gates (R1, R2, hard_gate) | hard_gate | Posting terms known; your location and pay floor not given | A failed gate would make the status `no_go` however strong the fit | Not applicable; this is a yes-or-no fact | None needed | `[grounded]` posting terms; no candidate statement |

R4 and R6 are `discovery` gaps with next actions in the map. They are not asked this turn, because G1, G2 and G4 could move the status.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer attributable to a real company | positive_signal | — | "Revenue Operations Lead, Quillfield" | The company exists as described: invoicing and payments software, Bristol, 96 employees, Series A | `[grounded]` quillfield.co.uk/about, seen as a search result | Is this a new post or a replacement, and who does it report to? | noted |
| RR2 | Posting not seen on Quillfield's own careers page | unknown | — | Posting hosted on the Tallyboard jobs board | The role is probably live, but the search did not return a careers listing to cross-check | `[inferred]` from the search returning the about page and no listing | Can you confirm this role is open and listed on Quillfield's own careers page? | unresolved |
| RR3 | Pay inside the market band | positive_signal | — | "£61,500–£67,000" | No seniority-pay mismatch visible | `[grounded]` posting range; `[generic]` band, single pay-guide result | What are the bonus or review terms on top of base? | noted |
| RR4 | Share option terms unstated | unknown | — | "plus share options" | Value depends on grant size, vesting and strike, none of which the posting gives | `[inferred]` from the posting naming options without terms | What is the grant size, vesting schedule and strike price for the options? | unresolved |
| RR5 | Several mandates in one "Lead" post | risk_signal | low | "own our CRM and billing data … reporting … run the quarterly revenue forecast" | One post may carry CRM, billing data, reporting and forecast with no stated team. Tamsin's Head of RevOps title may mean there is support. Rated low because that is unconfirmed either way | `[inferred]` from the mandate list and silence on team, against the Head of RevOps title | Is there a team under or beside this role, and which of these duties does someone else do today? | unresolved |
| RR6 | No success measures stated | unknown | — | Posting lists duties, no outcomes | Success at six and twelve months is undefined in the posting | `[grounded]` posting silent | What would a good first six months and first year look like? | unresolved |
| RR7 | Billing data ownership today unclear | unknown | — | "own our CRM and billing data" | Billing data may currently sit with finance, which affects how much of R10 is learned on the job | `[inferred]` from the posting naming billing data as a handover | Which system holds billing data today, and who owns it? | unresolved |

## Application plan

All of these are proposals; the plan, the edits table and the positioning advice below are each pending your approval.

**Proposed CV lines — `resume_edits_pending_approval`**

| # | Proposed line | Traces to your words |
|---|---|---|
| E1a | Ran revenue operations for the UK team, the last two of five years in sales operations at a B2B payments company | "5 years in sales operations at a B2B payments company, the last 2 running revenue operations for the UK team" |
| E1b | Salesforce admin certified; rebuilt the pipeline and renewal dashboards | "Salesforce admin certified; I rebuilt our pipeline and renewal dashboards" |
| E1c | Run the monthly pipeline review with the sales director | "I run the monthly pipeline review with our sales director" |
| E1d | Use SQL weekly and Excel daily | "SQL weekly, Excel daily" |

I audited these clause by clause. They add no forecast, finance or billing claim and no team-leadership claim. The sector is kept as "payments company", not "software". No CV was supplied, so I have not compared them with your current wording.

**Positioning advice — pending your approval.** Lead with the UK revenue operations role, the Salesforce certification, the dashboards and the monthly pipeline review. Then name the two gaps yourself, in your own words: "I haven't owned the company forecast — finance did that — and I haven't worked on billing data." Follow each with what you do bring. This is `[grounded]` in your statements and responds to R8, R9 and R10. Don't assume any overlap between Tamsin's earlier payments-company role and yours.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for the office-day expectation, the pay and option terms, and a link to the listing on Quillfield's own careers page | R1, R2, RR2, RR4 | `[grounded]` register | pending your approval |
| Q1 | Ask the verification questions of RR5, RR6 and RR7 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | A sanitized dashboard screenshot or forecast-versus-actual sheet, only if it exists and is shareable | Raises R7 or informs R8 | `[grounded]` R7, R8 rows | pending your approval |

## Evidence status

Verified: none yet. Your background arrived as prose, so it stands at CV-equivalent self-report and no claim reaches `high`. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol careers", which returned "About Quillfield" (quillfield.co.uk/about). Moved role reality's organization row and RR1. No careers listing was returned, which created RR2 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B SaaS Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR3; scope norms for the title were not covered |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring-manager and scope-read rows and the positioning advice. The footprint is thin: a title and one earlier role |

I can also write this up as `tuesday-dossier.md` if you want a file to keep.

## Upgrade menu

- Your CV → each row's gap type can be checked against your actual wording, and E1 becomes a side-by-side edit.
- A Salesforce credential record or sanitized dashboard screenshot → R5 or R7 to `high`.
- A sanitized SQL or Excel model sample → R6 resolves.
- A description of what the payments company's product was → R4 resolves.
- A forecast or reconciliation artifact → R8 or R9 firms up.
- Your location and pay floor → R1 and R2 resolve, and the hard-gates line closes.
- Recruiter answers on options, reporting line and the careers listing → RR2, RR4, RR5 and RR7 close.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**G1** — Have you personally built or maintained any forecast, even below company level, such as a UK-team pipeline or renewal forecast, a commit call, or numbers you gave finance for theirs? What did you own versus finance, and how did you track accuracy?

**G2** — On the renewal dashboards, did you work with finance or use finance-sourced data such as contract values or invoice extracts? Who owned the numbers, and what did you do with them?

**G4** — Are Bristol two days a week and £61,500–£67,000 plus options workable for you, or is there a pay floor or location limit I should treat as non-negotiable?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.