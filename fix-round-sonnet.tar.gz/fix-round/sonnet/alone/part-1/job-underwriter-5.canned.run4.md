I'll read the reference files first.
# Job Underwriting — Senior Data Engineer at Pellucid Learning

Stage wasn't stated, so I treated this as evaluating. Your background came from your message, so I read it as CV-equivalent self-report.

## Decision snapshot

**Yes, worth applying to, on conditions. R1 and R2 (hard gates) are unconfirmed and R9 is a real but bridgeable gap. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (US remote or Denver office), R2 (Pay $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (a dbt-modelled warehouse in BigQuery) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R9 — a credible bridge, its limit named; R10, R11 — evidence not yet surfaced, not shown absent; R1, R2 — waiting on your constraints.

**Opportunity ledger.** The employer and live posting are confirmed (RR1), and the stated pay sits inside the pasted market band (RR2). Breadth of mandate and reporting line (RR3) and the equity terms (RR4) are unresolved.

- **Hard gates:** none failed; unconfirmed: R1 (US remote or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 are met; (2) R9 is framed as adjacent, never as BigQuery experience; (3) RR3 verifies in the screen. A failed R1 or R2 would make this `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026). These are the company's own statements | `[grounded]` About page, from search result |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` careers page fetched |
| Posting status | "Accepting applications" | `[grounded]` careers page fetched |
| Working pattern | Remote (US) or the Denver office | `[grounded]` careers page |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` careers page |
| Market calibration | The Datawright 2026 report (n=2,310, Series B–D Senior Data Engineers) gives a base median of $151,000 and an interquartile range of $139,000–$163,500. The posted floor is $3,000 below that median and the top is $2,500 above its upper quartile. Pellucid is Series C, inside the report's stage range. The band is a pattern, never this employer's offer | `[generic]` the report's band; `[grounded]` the posted figures and the report you were sent |
| Seniority read | "5+ years" falls inside the report's typical 5–8 years for the title | `[grounded]` JD and report |
| Scope read | The JD names three areas: ingestion, warehouse modelling and contracts. The report calls ownership of one domain's pipelines typical, so this may be broader | `[inferred]` from the JD's three named areas against the report's typical scope |
| First 90 days / first year | Not stated | `[grounded]` JD silence |
| Hiring manager | Not named, so no reporting line or team size to read | `[grounded]` posting |
| Unknowns | Team size, reporting line, equity grant, which location suits you | — |
| Contradictions | None. The careers and About pages agree with the text you pasted | `[grounded]` both pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You gave no location or work-authorization constraint, so there is nothing to grade and the gate is not established. The term itself is clear | `[grounded]` JD text; your message is silent | Question G1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You gave no pay floor, so fit against the range is not established. Equity terms are unstated | `[grounded]` JD text; your message is silent | Question G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Your 6 years at a B2B payroll company clear the stated length. Self-reported, nothing inspected yet. Length of experience is a requirement, not a gate | `[grounded]` your background text | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is confirmed in your words. "Strong" rests on that alone, so expect a probe | `[grounded]` your background text | none |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. Specific and plausible, with no artifact inspected | `[grounded]` your background text | Sanitized dbt docs or a lineage graph would raise this to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The BigQuery named in the mandate is carried by R9 | `[grounded]` your background text | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. Your sentence does not say how much of it you owned, so I take the reading that claims less | `[grounded]` your background text | A sanitized DAG screenshot would raise this to `high` |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Specific, with no artifact inspected | `[grounded]` your background text | A sanitized suite excerpt would raise this to `high` |
| R9 | A dbt-modelled warehouse in BigQuery (named in the mandate, not the requirements list) | important | adjacent | medium | transferability | Adjacent: the same dbt modelling work on Snowflake. Limit: you have never used BigQuery, in your words. Cost and table-design mechanics generally differ between warehouses, so the ramp is real | `[grounded]` your statement; `[generic]` that warehouse mechanics differ | Say it plainly; a small personal BigQuery project is an option (W1) |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Six years of data engineering gives indirect context, but the sources you ingested are not stated | `[grounded]` your text is silent on sources; `[inferred]` that the work likely touched ingestion | Question G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | A 180-model project and a test suite suggest downstream users, but contracts are not stated | `[grounded]` your text is silent on contracts; `[inferred]` downstream users from the project size | Question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Terms of the role (R1, R2, hard_gate) | hard_gate | Terms stated by the posting; none of your constraints given | A failed gate ends the case whatever the fit elsewhere | Not applicable; this is whether the terms work for you | Not applicable | `[grounded]` JD terms; your constraints not given |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Data engineering for a payroll company; ingestion sources not stated | The mandate leads with ingestion, so this row decides whether the fit is complete | Loading product-database or event data into the warehouse; CRM or payroll-system extracts; third-party API feeds; managed connector tools | An architecture diagram, a DAG screenshot, or a source list | `[grounded]` the mandate's wording; `[generic]` that ingestion roles probe source diversity |
| G3 | Data contracts (R11, important) | discovery | A dbt project and a test suite; no stated agreement with consumers | The JD says analysts depend on contracts | Agreed schemas with upstream teams; tests guarding published models; freshness commitments to analysts; a change process when a source column moves | dbt docs, a schema agreement, or a runbook | `[grounded]` the JD's wording |
| G4 | BigQuery (R9, important) | transferability | Snowflake plus dbt, no BigQuery. Bridge: the modelling layer carries over. Limit: warehouse-specific mechanics were not exercised. Strengthener: a small public-data BigQuery and dbt project | R9 is the one named-platform gap | Not applicable; you stated none | A public repository of the small project | `[grounded]` your statement; `[generic]` that platform mechanics differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting established | positive_signal | — | "Accepting applications." | The employer exists as described and the posting is live. Size and funding are the company's own statements, not independently verified | `[grounded]` careers page fetched; About page from search | Who would I interview with, and what is the process? | noted |
| RR2 | Stated pay sits at or above the market median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range straddles the pasted $151,000 median and its top passes the $163,500 upper quartile, so no seniority-pay mismatch shows | `[grounded]` posting and the report you were sent; `[generic]` that the report describes the market, not this employer | Where in the range does an offer for this role typically land? | noted |
| RR3 | Scope breadth and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting: ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on." | The post may span ingestion, modelling and contracts end to end, possibly as the sole data engineer, and no hiring manager is named | `[inferred]` from the JD's three areas against the report's one-domain norm; `[grounded]` the posting names no manager | How many data engineers and analysts are there, who owns ingestion and the models today, and who does this role report to? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Grant size, vesting and valuation are unknown, so the equity cannot be valued | `[grounded]` posting silence | What is the equity grant for this level, and on what vesting terms? | unresolved |

## Application plan

Both rows' wording is audited against your own sentences. Every proposed line below is proposed, never applied.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with what you stated: "Built our dbt project on Snowflake, about 180 models"; "set up our Great Expectations test suite"; "used Airflow for orchestration"; "Python and SQL daily" | R5, R7, R8, R4 | `[grounded]` your background text | `resume_edits_pending_approval` |
| P2 | Say BigQuery plainly: "My warehouse and dbt work has been on Snowflake; I haven't used BigQuery." Never describe it as BigQuery experience | R9 | `[grounded]` your statement | pending your approval |
| W1 | A small personal BigQuery and dbt project on public data, labeled as a personal project and not as work experience | R9, G4 | `[grounded]` R9 row | pending your approval |
| Q1 | Ask the RR3 and RR4 questions verbatim in the screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your claims are intake prose, self-report of the same standing as a CV, so they sit at `medium` at most. No CV was provided.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It moved role reality's organization, posting-status and contradictions rows, and RR1. No failed-attribution entry is needed |
| 2. Role-family sweep | skipped | The pasted Datawright report is in hand and fixes the market calibration and the pay comparison this target feeds |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Upgrade menu

- Your answer to G1 closes R1 and R2, and the decision becomes `go` or `no_go`.
- Answers to G2 and G3 move R10 and R11 off `unclear`.
- Your CV would let me check for `presentation` gaps and tighten P1.
- A sanitized dbt lineage graph, DAG screenshot or Great Expectations excerpt would raise R5, R7 and R8 to `high`.
- The hiring manager's name, if the recruiter has it, would feed role reality's scope read and the plan's lead story.
- A deeper pass on Pellucid (funding and leadership churn, hiring patterns, public employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can also save all of this as `tuesday-dossier.md` if you'd like to keep it.

**Questions**

G1 — Do the role's terms (US remote or Denver, $148,000–$166,000 plus equity) work for you as stated, including US work authorization?

G2 — Have you owned loading data from an app database, a CRM or a similar source into your warehouse? Which sources, and what was yours?

G3 — Have you set up or kept any agreement with the people who consume your models, such as schema promises, freshness commitments or a change process? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.