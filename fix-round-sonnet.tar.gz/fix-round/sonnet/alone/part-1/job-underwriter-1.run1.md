I'll read the reference files the skill points to before building the assessment.
Web searches were declined, so this runs on your pasted JD and your background alone. Every target is accounted for in Evidence status.

## Decision snapshot

**Yes, apply, on conditions. You are a fit on R1, R2, R3, R4 and R6, which are `direct`. Healthcare experience (R9b) is the open gap. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R6 · adjacent: R5 (Define and maintain the metrics layer)
- `important`: adjacent: R7a (Partner with product managers on roadmap decisions) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9a (HIPAA, health-data handling) · absent: R9b (Healthcare data and domain experience)

What matters: R5 — the posting's lead duty, and your Looker evidence stops short of naming it; R7b, R8 — no evidence given yet; R9b — a confirmed absence on a preferred row.

**Opportunity ledger.** Unverified rather than troubling. The employer could not be checked (RR1). Pay (RR2), location and authorization terms (RR3) and first-year outcomes (RR5) are not stated. One entry runs the other way: named duties and a named team (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer and a live posting verify (RR1).
  2. Your pay, location and authorization terms are checked against the posting once you give them (RR2, RR3).
  3. Metrics-layer experience is confirmed, or framed as adjacent (R5).
  4. The healthcare bridge is framed as adjacent privacy work (R9a), never as healthcare experience (R9b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app. Existence not established (RR1) | `[grounded]` your pasted JD header |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated. Likely a maintained metrics layer, a running test cadence and self-serve dashboards | `[inferred]` from the JD's duty list |
| Scope read | A senior individual contributor with light people-leadership: two juniors to mentor, five named duties | `[inferred]` from the mentoring clause and duty list |
| Market calibration | Not established. The role-family sweep was refused, so no pay or scope band is stated here | none |
| Unknowns | Pay, location or remote terms, work authorization, reporting line, experimentation tooling, who the clinicians are | `[grounded]` the pasted JD is silent on each |
| Contradictions | None visible within the pasted text. It was not checked against a careers page | `[grounded]` paste read only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a consumer-subscription company (meal-kit delivery, ~2M subscribers), in your own words. It is intake prose, so `medium` is the ceiling | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse". Daily use is stated and "expert" is the JD's level word. Expect a live SQL exercise | `[grounded]` your background; `[generic]` analyst loops often test SQL live | a sanitized query or data-model sample would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The basis of the 11% (relative or points, window) is not stated, so carry it exactly as you gave it | `[grounded]` your background | a sanitized readout of the pricing test would raise to high |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards. "Governed" is stated; self-serve usage is not | `[grounded]` your background | dashboard usage figures or screenshots would raise to high |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | The Looker build and the warehouse consent-state model are adjacent. Defining and maintaining a metric set is not stated, and "governed" does not establish it. Low is the lower of two plausible bands | `[grounded]` what you stated; `[inferred]` adjacency from the Looker build | see gap queue G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. Whether those readers are non-technical is not stated | `[grounded]` your background | a sanitized memo sample would raise to high |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | Monthly presentations to the VP Product and a pricing test tied to a retention lift. Partnering with PMs on roadmap decisions is not stated | `[grounded]` your background | one roadmap decision your analysis changed, in the upgrade menu |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in the background touches clinician-style domain experts | `[grounded]` background silent | see gap queue G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | The background is silent on mentoring or reviewing others' work | `[grounded]` background silent | see gap queue G2 |
| R9a | Health-data privacy handling (HIPAA a plus) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. Limit: no health data and no HIPAA-covered handling, which you have not exercised | `[grounded]` your background | see gap queue G4 |
| R9b | Healthcare data and domain experience | preferred | absent | none | capability | You state you have never worked in healthcare. Closure path: HIPAA-fundamentals training and care-navigation metrics reading, claimed only once done | `[grounded]` your statement; `[generic]` the closure path | carry as a minor risk; closure path named |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | A Looker build with 40+ governed dashboards. No mention of who defined the metrics or how they were maintained | The JD's lead duty and the one must-have below `direct`. Resolving it could move R5 to `direct` | A LookML model you wrote or governed; a metric dictionary others relied on; settling a dispute between two teams' numbers; certified explores | A sanitized metric dictionary, a LookML excerpt, an explore screenshot | `[grounded]` your Looker statements; `[generic]` that these artifacts are what a metrics layer looks like in BI stacks |
| G2 | Mentoring juniors (R8, important) | discovery | No mention of mentoring or reviewing others' work | The JD names two junior analysts, so the role includes it | Onboarding a new analyst; reviewing queries or dashboards; coaching someone through a first A/B test. Informal counts | An onboarding doc, a review checklist, a sanitized note from a mentee | `[grounded]` background silent; `[inferred]` from the JD's named juniors |
| G3 | Clinician partnership (R7b, important) | discovery | No domain-expert stakeholders mentioned | The role pairs analysts with clinicians, and the closest analogue may sit in your history | Working with a specialist, such as nutrition, operations or support leads, who shaped what a metric or test measured | A co-authored test brief or metric spec | `[grounded]` background silent; `[inferred]` analogue is possible |
| G4 | Health-data bridge (R9a, preferred) | transferability | Consumer PII handling and a consent-state model. No health data | A credible bridge with a stated limit narrows the likeliest objection to a candidate with no healthcare background | A data-handling policy you followed or wrote; access controls or consent schema decisions you owned | A sanitized consent-state schema or policy summary | `[grounded]` your PII statements; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Taken at medium because no other flag stands beside it | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | no pay figure appears in the pasted JD | The posting may withhold pay, or the paste may have dropped it. Pay cannot be set against a floor or a band until it is known | `[inferred]` from the pasted text's silence | What is the budgeted salary range for this role? | unresolved |
| RR3 | Location, arrangement and work-authorization terms not stated | unknown | — | no location or remote terms appear in the pasted JD | These could matter if your non-negotiables bind | `[inferred]` from the pasted text's silence | Where is this role based, is remote or hybrid allowed, and are there work-authorization requirements? | unresolved |
| RR4 | Named duties and a named team | positive_signal | — | "mentor two junior analysts" | The role appears resourced and defined, not a one-person function | `[inferred]` from the JD's named team and duties | Who do the two junior analysts and this role report to? | noted |
| RR5 | No outcomes stated for a senior "own" mandate | unknown | — | "Own product analytics for our care-navigation app" | "Own" may mean decision rights or may mean workload. No first-year outcomes are stated | `[inferred]` from the JD's scope language against its silence on outcomes | What should this role have delivered by the end of year one, and which decisions does it own? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | R3, your sentence verbatim | `[grounded]` your background | `resume_edits_pending_approval` |
| E2 | Resume line: "Built the company's Looker instance from scratch — 40+ governed dashboards." | R4, your sentence verbatim | `[grounded]` your background | `resume_edits_pending_approval` |
| E3 | Resume line: "Handled GDPR/CCPA consumer PII; built the consent-state model for our warehouse." Do not add "HIPAA" or "healthcare" | R9a, with its limit kept | `[grounded]` your background | `resume_edits_pending_approval` |
| E4 | Resume line: "Write the monthly metrics memo the exec team reads; present to the VP Product monthly." | R6, from your own sentence | `[grounded]` your background | `resume_edits_pending_approval` |
| N1 | Cover-note sentence: "I have not worked in healthcare; I have handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse." | R9a and R9b, naming the gap in your own words | `[grounded]` your background | pending your approval |
| A1 | Confirm the live posting on the company's careers page, or via the recruiter's email domain, before investing in the application | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the register's verification questions in the loop, verbatim | The register doubles as interview preparation | `[grounded]` RR2, RR3, RR5 | pending your approval |

## Evidence status

Verified: none yet. Everything above is your self-reported background, so it is a lead rather than proof. Stage assumed: evaluating.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Harborlight Health care navigation app digital health company" and "Harborlight Health careers Senior Product Analyst". They would have fed role reality's organization and contradictions rows and RR1, so RR1 stands as a standing entry |
| 2. Role-family sweep | unavailable | One search was refused: "senior product analyst digital health salary range experimentation Looker". It would have fed the market calibration line and RR2's band, so both are unstated |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Dossier offer

If you want a saved record of this, I can write it to `tuesday-dossier.md` whenever you say.

## Upgrade menu

- Permission for web search: confirms whether Harborlight Health exists as described and whether the posting is live (RR1). It also gives a pay and scope band for RR2 and the market calibration line.
- A link to the live posting or careers page, which I can read as an input: checks the JD against the source.
- A sanitized metric dictionary or LookML excerpt: lifts R5 toward `direct` and `medium` or better.
- A sanitized pricing-test readout: raises R3 to `high`.
- A sample monthly metrics memo: raises R6 to `high`.
- Dashboard usage figures: raise R4 to `high` and show the self-serve part.
- One roadmap decision your analysis changed: firms up R7a.
- The hiring manager's name: sharpens the scope read and which story to lead with.
- A deeper pass on the company (funding, leadership churn, public reports, recent news; up to 5 more searches and 2 more fetches): worth running only after the first-level checks above.

## Questions

Constraints — What are your non-negotiables for this move (pay floor, location or remote, work authorization), so I can check them against the posting?

G1 — Did you write or govern the metric definitions behind those Looker dashboards, for example a LookML model or a metric dictionary others relied on, and is there anything you can share?

G2 — Have you mentored, onboarded or reviewed the work of other analysts? What did you do, for whom, and for how long?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.