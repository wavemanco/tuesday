I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**No, you're not wasting your time, but this is a stretch, not a fit. R1a (3+ years of product management, never held in title) is absent, while R1b, R2, R7 and R8 are adjacent work with limits named. The substance maps; the title does not. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R4 · adjacent: R1b (Own the roadmap), R2 (Shipped API or platform products), R8 (Write specs, drive delivery with two squads) · absent: R1a (3+ years PM, held role)
- `important` — direct: R5a · adjacent: R7 (Discovery with integration partners) · unclear: R3 (Adoption metrics), R5b (Sales and support launches), R6 (Agile delivery)

R1a — no titled PM years; R1b, R2, R7, R8 — adjacent work, limits named; R4 (`medium`) — technical fluency lands; R3, R5b, R6 — unclear, waiting on your answers.

**Opportunity ledger.** Plausible on its face but unverified: the employer could not be checked (RR1), pay is unstated (RR2), and success measures and decision rights are unstated (RR3). One entry runs the other way: the scope is concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify — RR1; (2) the recruiter or hiring manager confirms adjacent product work can count toward the 3+ years — R1a, R1b, RR3; (3) your answers on G1 and G2 surface real ownership evidence, or the framing stays honestly adjacent — R2, R3, R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B; not checked against any outside source | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stated requirements | 3+ years PM (marked must-have); shipped API or platform products; technical fluency; stakeholder management across engineering, sales and customers; agile delivery | `[grounded]` JD |
| Seniority read | A 3+ year floor, with no direct reports mentioned, reads as a mid-level individual-contributor post, not a lead or senior one | `[inferred]` from the years floor and the JD's silence on managing people |
| First-year outcomes | Not stated. Adoption metrics are a duty with no target. Early work plausibly includes setting the baseline | `[grounded]` JD silence; `[inferred]` from "define and track adoption metrics" |
| Working terms | Location, remote policy, pay and employment type are not stated | `[grounded]` JD silence |
| Market calibration | Not set: no role-family search returned, so title, scope and pay are not placed against norms | `[grounded]` no research result in hand |
| Unknowns | Roadmap decision rights; how success is measured; why the seat is open; pay; location | `[grounded]` JD silence |
| Contradictions | None inside the JD; not checked against a careers page | `[grounded]` JD only |

## Evidence map

I worked from your summary, not the resume file, so every claim here is confirmed-in-prose at best (`medium` is the ceiling).

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, read as time in a held PM role | must_have | absent | none | transferability | You've never held a PM title, so a titled-years reading is not met. The bridge is R1b, R7 and R8. A years-of-experience term is graded here, not treated as a gate. Screens often read this line by title, which is a pattern about postings of this kind, not about Quartzline | `[grounded]` your statement and the JD quote; `[generic]` how such lines are screened | Ask whether adjacent product work counts (plan A1) |
| R1b | Own the roadmap for the partner-facing API platform | must_have | adjacent | medium | transferability | Carries over: you ran quarterly roadmap-input sessions collecting client feedback for product, and coordinated with product managers on custom builds. Limit: nothing says you set priorities or owned a roadmap. Collecting input is not owning the roadmap. Confirmed in prose, no artifact, so expect a probe | `[grounded]` your summary | G2; a roadmap-input summary would raise it |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Carries over: 30+ client integrations of your employer's REST APIs, scoped through go-live, plus the integration playbook the team uses. Limit: this is implementing an API product others built. Nothing says you designed, versioned or launched an API | `[grounded]` your summary | G1 and G2 may surface owned work; otherwise keep it framed as adjacent |
| R3 | Define and track adoption metrics | important | unclear | low | discovery | Your summary is silent on metrics. An earlier-conversation lead (an internal request-triage tool that support agents adopted) is unconfirmed, so it prompts a question and is not used as a claim | `[grounded]` summary silence; `[inferred]` lead from agent memory, unconfirmed | G1 |
| R4 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus 30+ REST integrations, match the ask. Confirmed in prose with no artifact yet | `[grounded]` your summary | Offer a sanitized slice of the playbook to raise it to `high` |
| R5a | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your engineers, the client's engineers and product managers. Limit: sales is not covered here (R5b) | `[grounded]` your summary | none |
| R5b | Working with sales and support; coordinating launches with them | important | unclear | low | discovery | Your summary is silent on sales and support. Solutions roles often sit near sales, but that is a pattern and cannot be asserted as yours | `[grounded]` summary silence; `[generic]` role-family pattern | G4 |
| R6 | Experience with agile delivery | important | unclear | low | discovery | UAT and go-live coordination is delivery, but nothing mentions sprints, backlogs or squads, and I won't infer them | `[grounded]` summary silence | G3 |
| R7 | Run discovery with integration partners | important | adjacent | medium | transferability | Carries over: scoping workshops and quarterly roadmap-input sessions put you in direct contact with API users. Limit: scoping served a client's integration, and nothing says you framed problems across partners or validated solutions | `[grounded]` your summary | A roadmap-input summary would strengthen it |
| R8 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | Carries over: requirements documents, integration architecture, coordinating engineers on custom builds. Limits: these were specs for client implementations, not a product backlog; "coordinated" is not "drove"; squads are not mentioned | `[grounded]` your summary | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics and anything adopted that you built (R3, important) | discovery | Nothing on metrics; one unconfirmed lead about an internal tool | A confirmed owned-and-adopted story would give R2 and R3 something stronger than adjacent work. PM interviews tend to probe how success was measured | An internal tool, template or process others adopted; usage numbers you tracked (integrations live per quarter, time to go-live); a SQL report others relied on | A usage export or screenshot, a short write-up, evidence the team adopted the playbook | `[grounded]` summary silence; `[inferred]` from the R2 and R3 limits; `[generic]` that interviews probe measurement |
| G2 | Deciding scope and priority, not only coordinating (R1b, R8, both must_have) | transferability | Coordination and spec-writing are stated; deciding what gets built and in what order is not | R1b and R8 sit at `adjacent`, and the line between coordinating and deciding is where a hiring panel is likely to press | A custom build where you chose what was in scope and what was deferred; a client request you turned into product feedback; a spec engineers built from | A sanitized requirements document, a roadmap-input summary, a ticket thread | `[grounded]` summary wording; `[generic]` where panels press on PM-adjacent claims |
| G3 | Agile delivery (R6, important) | discovery | UAT and go-live only | An explicit JD requirement the summary leaves unaddressed | Sprint planning or backlog grooming with engineers; running a board of integration tickets; release coordination | A sanitized board or ticket export | `[grounded]` summary silence |
| G4 | Sales and support launch coordination (R5b, important) | discovery | Silent | The JD names sales and support in two places | Joint calls with sales before go-live; handoff to support after go-live; a launch checklist | A handoff document or launch checklist | `[grounded]` summary silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be real and simply small, the posting may be stale or aggregated, or it may not be a live employer. No outside check returned, so none of these is established | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Pay and location not stated | unknown | — | JD lists no pay, location or remote terms | The posting may simply not publish them, or the pay may sit below what you would accept; you haven't told me your floor | `[inferred]` from the JD's silence, with no market band in hand | What is the budgeted pay range, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Roadmap ownership and success measures unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | Accountability for the roadmap may come without stated decision rights, and no first-year target is named | `[inferred]` from the JD's scope language against its silence on authority and targets | What would this role be measured on in the first year, and who decides trade-offs when sales wants custom work? | unresolved |
| RR4 | Scope is concrete | positive_signal | — | "run discovery with integration partners; write specs and drive delivery with two engineering squads" | Named squads, named partner-facing work and named cross-functional partners suggest a defined seat | `[grounded]` JD wording | Why is the seat open, and who owned the roadmap before? | noted |

## Application plan

Every row below is proposed and pending your approval: the resume lines (`resume_edits_pending_approval`), the outreach text, and the positioning advice alike. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Summary line: "Solutions engineer and implementation lead with seven years taking clients' REST API integrations from scoping to go-live, working with engineers and product managers on custom builds." | Leads with what you did, in product-adjacent terms, without claiming a PM title (R2, R8) | `[grounded]` your summary | pending your approval |
| E2 | Standalone bullet, verbatim from your summary: "Ran quarterly roadmap-input sessions collecting client feedback for product." | Surfaces R1b and R7 evidence that is easily buried | `[grounded]` your summary | pending your approval |
| E3 | Standalone bullet, verbatim: "Wrote the internal integration playbook the whole team uses." | Surfaces R2 and R4 evidence | `[grounded]` your summary | pending your approval |
| A1 | Before investing in the loop, send the recruiter: "The posting asks for 3+ years of product management. I have seven years in solutions engineering and implementation, leading REST API integrations and running quarterly roadmap-input sessions that collected client feedback for product, but I haven't held a PM title. Would that background be considered?" | Settles R1a directly, and the answer moves the decision | `[grounded]` R1a row and your summary | pending your approval |
| A2 | Seek a referral or a short conversation with someone on the platform team before applying cold | Postings with a title-based screen are often reached more easily through a person than a form; a pattern, not a fact about Quartzline | `[generic]` role-family pattern | pending your approval |
| A3 | Treat this posting as one attempt within a wider pivot search, not the whole plan | R1a is a title term that no wording fixes, and routes that count technical and customer-facing work toward product experience may weigh it differently | `[generic]` role-family pattern | pending your approval |

Beyond this posting, I can compare pivot routes for you (an internal move at your current employer, technical or partner-facing product roles, or this posting). It's offered because your question is about the pivot as much as this one role. I'll build it only if you approve.

## Evidence status

Verified: none yet. Unverified leads: an earlier-conversation mention of an internal request-triage tool adopted by support agents, unconfirmed, used only to prompt G1. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics technology partner API platform careers Product Manager" was refused by the host. It would have set the role-reality organization and contradictions rows and could have cleared RR1 |
| 2. Role-family sweep | unavailable | The search "platform API product manager salary Series B B2B SaaS requirements transition from solutions engineer" was refused by the host. It would have set the market calibration row and the pay check in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier and upgrade menu

I can save this assessment as `tuesday-dossier.md` whenever you want it.

- Search permission → targets 1 and 2: whether Quartzline exists as described and the posting is live (RR1), plus a market calibration and pay band (RR2).
- The hiring manager's name → the scope read, and which of your stories to lead with for that reader.
- Your constraints (pay floor, location or remote, work authorization) → hard-gate rows I can check the role against; today the hard-gates line cannot.
- Your actual resume file → I worked from your summary, and the real wording could raise R4 and R5a or expose presentation gaps.
- A sanitized slice of the integration playbook, a requirements document or a roadmap-input summary → R4 toward `high`, and R1b, R7 and R8 firmer.
- Answers on G3 (agile) and G4 (sales and support) → R6 and R5b; I held them back this turn to stay within three questions.

**Questions**

G1 — Have you built or led anything (a tool, template or process) that other people adopted, such as an internal request-triage tool that support agents used? An earlier conversation hinted at something like it, and I haven't confirmed it. What did you own, how did you know it was adopted, and is there a number or screenshot?

G2 — On a custom build, was there a time you decided what went into scope and what was left out, or turned a client request into product feedback? What did you decide yourself, what did you hand to a PM, and what happened?

O1 — Where are you in this: just evaluating, or already in touch with Quartzline? And do you have non-negotiables I should check the role against, such as a pay floor, location or remote, or work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.