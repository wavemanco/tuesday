I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Yes, apply. You're a credible fit on the substance, and the open items are R2, R8b, R9 and R10. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R3, R4, R5, R6, R7 · adjacent: R2 (Define and maintain the metrics layer)
- `important` — direct: R8a · unclear: R8b (Partner with clinicians), R9 (Mentor two junior analysts)
- `preferred` — adjacent: R10 (Healthcare data experience, HIPAA)

R2 — whether "governed" dashboards meant a defined metrics layer is unconfirmed; R8b, R9 — no evidence yet on clinician partnership or mentoring; R10 — a consumer-privacy bridge, limit named.

**Opportunity ledger.** The employer could not be checked this run (RR1), pay is unstated in the pasted JD (RR2), and who owns data pipelines is unstated (RR3). On the other side, the JD names concrete duties, a stack and a team (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify as real and live — RR1; (2) your pay, location and work-authorization terms are compatible, which I can't check until you give them — RR2; (3) the mentoring and clinician rows, R8b and R9, are answered or framed honestly as not yet done — G2, G3; (4) the healthcare bridge is framed as adjacent, never as HIPAA experience — R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C. The entity is not independently verified | `[grounded]` JD header; not checked against any outside source |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve dashboards, PM and clinician partnership, mentoring | `[grounded]` JD |
| Team | Mentor two junior analysts, so an analytics function already exists | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | Metrics layer, experimentation, BI build and mentoring sit in one senior individual-contributor post, with no mention of analytics-engineering support | `[inferred]` from the duty list against the JD's silence on data engineering |
| Market calibration | Not established: no role-family sweep ran, so there is no pay band to hold against the posting or against your floor | `[grounded]` research unavailable this run |
| Unknowns | Pay; location or remote terms; work-authorization terms; who owns data pipelines; success measures; reporting line | `[grounded]` JD silent |
| Contradictions | None visible within the JD text; no second source to compare it against | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Own product analytics for the care-navigation app | must_have | direct | medium | none | Six years of product analytics, plus you built the Looker instance, ran the experimentation program and write the exec metrics memo. Confirmed and specific, but nothing inspectable yet. Domain differs (meal kit versus care navigation) | `[grounded]` your background; domain gap is R10's | none |
| R2 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | You built "40+ governed dashboards" in Looker from scratch. That implies metric definitions, but you did not say you defined and maintained a shared metrics layer, so it is read at the lower claim | `[grounded]` your background; `[inferred]` that governed dashboards imply defined metrics | G1 |
| R3 | Design and analyze A/B tests at scale | must_have | direct | medium | none | You designed and ran the program, 30+ tests a year, including the pricing test behind an 11% retention lift. Healthcare tests often can't randomize every care pathway, so expect a probe on small samples and ethics constraints | `[grounded]` your background; `[generic]` healthcare experimentation constraints | offer: a sanitized test brief or readout would raise to high |
| R4 | Build self-serve dashboards in Looker | must_have | direct | medium | none | You built the company's Looker instance from scratch. "Self-serve" usage was not stated, only "governed" | `[grounded]` your background | none |
| R5 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is a self-grade with no artifact | `[grounded]` your background | offer: a sanitized query or model sample would raise to high |
| R6 | 5+ years of product analytics | must_have | direct | medium | none | Six years stated | `[grounded]` your background | none |
| R7 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads | `[grounded]` your background | offer: a sanitized memo would raise to high |
| R8a | Partner with product managers on roadmap decisions | important | direct | medium | presentation | You present to the VP Product monthly, and the pricing test led to a retention lift. Which roadmap decisions your analysis changed is not stated, so the decisions-changed framing is the missing piece | `[grounded]` your background | surface one decision your analysis changed; see E1 |
| R8b | Partner with clinicians | important | unclear | none | discovery | Nothing in the background touches clinical or domain-expert partners | `[grounded]` background silent | G2 |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring or line management is not mentioned; no evidence either way | `[grounded]` background silent | G3 |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Bridge: GDPR/CCPA consumer-PII handling and a warehouse consent-state model. Limit: this is not HIPAA work. PHI handling, access controls for clinical data and de-identification were not exercised | `[grounded]` your background; limit is `[inferred]` from "never worked in healthcare" | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R2, must_have) | discovery | "Governed" dashboards, but not who defined metrics or how they were kept consistent | R2 is the one `must_have` row below `direct`; resolving it may lift R2 to direct | Writing LookML or a shared metric-definition model; a metric dictionary; resolving a "two teams, two numbers" dispute; versioning a definition change | LookML excerpt, metric dictionary, a governance doc (sanitized) | `[grounded]` background silent on metric definitions |
| G2 | Clinician partnership (R8b, important) | discovery | No domain-expert stakeholder work mentioned | The JD names clinicians as partners, and the background has none | Working with nutritionists, food-safety, ops or medical-adjacent specialists; translating findings for a non-analytics expert who challenged the method | A readout or brief co-owned with a domain expert | `[grounded]` background silent; `[generic]` that clinician partners often challenge methods |
| G3 | Mentoring (R9, important) | discovery | No mention of mentoring or managing | The JD names it as a duty, and silence reads as none | Reviewing juniors' queries or analyses; onboarding; running a team analysis review; informal mentoring counts, framed as what it was | Onboarding doc, review checklist, a junior's promotion note | `[grounded]` background silent |
| G4 | HIPAA and PHI (R10, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | Preferred only, but healthcare employers tend to probe the line between consumer PII and PHI | Access controls, retention rules, de-identification, vendor or legal reviews you were part of | Consent-model schema or design doc (sanitized) | `[grounded]` background; `[generic]` that healthcare employers probe this line |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small for a footprint, or the posting may be stale. Nothing here shows a problem; it is unchecked, not suspect | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | no compensation in the pasted JD | The posting may omit pay, or the pasted copy may have dropped it. No band was available to compare | `[grounded]` JD silent; no band, since research did not run | What is the salary range budgeted for this role? | unresolved |
| RR3 | Pipeline and metrics-layer support unstated | unknown | — | "define and maintain the metrics layer" | The role may carry data-modeling work beside the analysis with no engineering support | `[inferred]` from the duty list against the JD's silence on data engineering | Who owns the data pipelines and models the metrics layer sits on? | unresolved |
| RR4 | Concrete scope, named tool and a named team | positive_signal | — | "mentor two junior analysts"; "build self-serve dashboards in Looker" | Scope and team context look genuine, and the tool matches your Looker work | `[grounded]` JD | What does success look like at 12 months? | noted |

## Application plan

Every row below, the table and the notes under it alike, is proposed and pending your approval; nothing is final until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the employer and live posting on the company's own careers page before investing in a tailored application | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | see R3, R8a | `[grounded]` your sentences | resume_edits_pending_approval |
| E2 | Pair it with: "Built the company's Looker instance from scratch — 40+ governed dashboards." | see R4 | `[grounded]` your sentences | resume_edits_pending_approval |
| E3 | Add: "Write the monthly metrics memo the exec team reads; present to the VP Product monthly." | see R7, R8a | `[grounded]` your sentences | resume_edits_pending_approval |
| E4 | Add, as consent and privacy evidence: "Built the consent-state model for our warehouse; handled GDPR/CCPA consumer PII." Do not use the words HIPAA or PHI | see R10 | `[grounded]` your sentences | resume_edits_pending_approval |
| P1 | In the cover note, say plainly that you haven't worked in healthcare and name the consent model as your nearest privacy work | see R10; the limit is stated, not hidden | `[grounded]` your sentences | pending your approval |
| Q1 | Ask RR1 to RR4's questions verbatim in the screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app Series C" and "Harborlight Health careers Senior Product Analyst"; both were refused. It would have moved role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range scope 2026"; it was refused. It would have moved the market-calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No hiring manager's name was given, so there was no query to form |

## Dossier offer

If you'd like, I can save this as `tuesday-dossier.md`, so it carries forward as you answer the questions below.

## Upgrade menu

- Search access, or a link to the live posting and the company's careers page → RR1 and the employer row resolve, and the market-calibration row and RR2 get a pay band.
- Your pay floor, location or remote needs, and work authorization → the hard-gate checks run; today they are unknown.
- A sanitized test brief, metrics memo or query sample → R3, R5 and R7 move toward `high`.
- A hiring manager's name → role reality's scope read, and which story to lead with for that reader.

## Questions

1. **Constraints** — What is your pay floor, your location or remote needs, and your work-authorization status for this role? Any of these could be a hard gate I can't check yet.
2. **G1** — Did you personally define and maintain shared metric definitions, for example in LookML or a metric dictionary, or were definitions set by someone else?
3. **G3** — Have you mentored, onboarded or reviewed the work of junior analysts, even informally? What did you actually do, and who was involved?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.