I'll read the reference files the skill requires before building the assessment.
**Not a waste of time to apply, but this is a stretch application, not a strong one: R1a (3+ years of PM experience, a `must_have`) is absent. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-shaped work in place of titled years), R2a (Shipped API or platform products), R6b (Own the roadmap) · unclear: R2b (Shipped any product you built), R4b (Launches with sales and support), R7 (Agile delivery) · absent: R1a (3+ years PM experience, titled)
- `important` — direct: R5 · adjacent: R6a (Write specs) · unclear: R8 (Define and track adoption metrics)

R1a — titled PM years, absent, and no wording closes it; R2b, R4b, R7, R8 — unclear until you answer; R1b, R2a, R6a, R6b — real adjacent work, limits named in the map.

**Opportunity ledger.** The mandate is concrete, with named squads, partners and metrics (RR5). The employer is unverified (RR1), compensation is unstated (RR2), it is unclear whether the experience bar reads as titled years or equivalent work (RR3), and roadmap decision rights are unspecified (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify — RR1; (2) the experience bar proves flexible on substance — R1a, RR3; (3) the PM-shaped work is presented as adjacent, never as PM experience — R1b, R2a, R6b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B, as the posting describes itself; not externally checked | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stated requirements | 3+ years PM experience (must-have); shipped API or platform products; technical fluency; stakeholder management across engineering, sales and customers; agile delivery | `[grounded]` JD |
| Scope read | A mid-level, single-product PM post owning a developer-facing platform, not a team-leading role: no reports are mentioned and the experience bar is 3+ years | `[inferred]` from the JD's scope and its 3+ year bar |
| First-90-day and first-year outcomes | Not stated | `[grounded]` JD silent |
| Compensation, location, work pattern | Not stated | `[grounded]` JD silent |
| Market calibration | Not available: the role-family sweep did not run (see Evidence status), so there is no band to set the title, scope or pay against | `[grounded]` research tier line |
| Unknowns | Experience-bar flexibility; decision rights over the roadmap; compensation; location; hiring manager | `[inferred]` from the JD's silences |
| Contradictions | None visible within the posting | `[grounded]` JD read against itself |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (titled) | must_have | absent | none | capability | You confirmed you have never held a PM title, so there is no titled PM experience. Postings that mark a years bar "must-have" are often screened on titles before substance is read. That is a risk, not a legal gate | `[grounded]` your statement; `[generic]` screening pattern | Ask the employer how the bar is read (RR3); closure paths in plan row A3 |
| R1b | 3+ years PM experience, via PM-shaped work | must_have | adjacent | medium | transferability | Seven years of integration leadership that overlaps PM work: requirements documents, roadmap-input sessions, coordinating engineers and PMs. Limit: you coordinated with PMs and fed their roadmap; no evidence you made prioritization calls or owned a product outcome. Confirmed in prose only, so medium | `[grounded]` your resume summary | Frame as adjacent; propose E1 |
| R2a | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ client integrations of your employer's REST APIs, end to end. Limit: you delivered integrations on a platform; nothing says you shipped or owned the API product | `[grounded]` your resume summary | See G1 |
| R2b | Shipped API or platform products, via anything you built and released | must_have | unclear | low | discovery | A prior-conversation lead suggests an internal request-triage tool that support agents adopted. Unconfirmed: nothing says what you owned, its scope or its outcome | `[inferred]` from agent memory, not confirmed | G1 question |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs and REST integration architecture on your resume. Expect a probe, as there is nothing inspectable yet | `[grounded]` your resume summary | The integration playbook, sanitized, would raise this to high |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and led scoping workshops and UAT with 30+ clients | `[grounded]` your resume summary | none |
| R4b | Stakeholder management with sales, and coordinating launches with sales and support | must_have | unclear | low | discovery | The resume is silent on sales and support. Solutions roles in vendors often sit beside sales, but that is not established for you | `[grounded]` resume silence; `[generic]` role-family pattern | G2 question |
| R5 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly roadmap-input sessions are discovery work, in solutions-engineer vocabulary. Limit: your clients were customers of your employer's APIs, not partners building on a platform you owned | `[grounded]` your resume summary | Propose E1 |
| R6a | Write specs | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture for client builds. Limit: those were client-facing delivery documents, not specs for your own product team's backlog | `[grounded]` your resume summary | Offer a sanitized requirements document |
| R6b | Own the roadmap for the API platform | must_have | adjacent | medium | transferability | You ran quarterly sessions collecting client feedback for product. Limit: input to someone else's roadmap, not ownership or prioritization | `[grounded]` your resume summary | Frame as input, never ownership |
| R7 | Agile delivery experience | must_have | unclear | low | discovery | The resume describes delivery (UAT, go-live) but never names agile practices or squad ceremonies | `[grounded]` resume silence | Ask later if it matters |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | SQL helps, but the resume names no adoption measures. The triage-tool lead, if confirmed, may bear on this | `[grounded]` resume silence; `[inferred]` lead unconfirmed | G1 question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Anything you built and shipped; adoption measures (R2b, R8) | discovery | A lead about a request-triage tool support agents adopted, with no confirmed scope, ownership or outcome | R2b is a `must_have` at `unclear`; a confirmed answer is the one thing that could make your "shipped a product" case direct rather than adjacent | A tool or workflow you specified, built or configured that others adopted; usage counts or time saved you tracked | A screenshot, a one-page description, a usage number or a note of thanks | `[inferred]` lead from agent memory; `[generic]` that hiring panels weigh built-and-adopted evidence |
| G2 | Sales and support in launches (R4b) | discovery | Silence on sales and support | A `must_have` at `unclear`; the JD names both functions | Joining pre-sales calls, handing a go-live to support, writing release or enablement notes | A handoff doc or a runbook | `[grounded]` resume silence |
| G3 | Titled PM years (R1a) | capability | No titled PM role; adjacent work is in R1b | A `must_have`; no question can change a confirmed absence | PM-titled interim or acting roles, if any exist | n/a | `[grounded]` your statement. Closure path is plan row A3 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be real and simply unchecked here, because the web check was refused. The posting may also be stale or aggregated | `[generic]` pattern for companies of this size, not a claim about this one | Where is this role listed on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (posting contains no compensation) | The figure may sit below what the scope implies, or the company may not publish pay | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Experience bar: titled years or equivalent work | unknown | — | "3+ years product management experience (must-have)" | The bar could be a firm title screen or a proxy for demonstrated PM-type work | `[inferred]` from the bar's wording against R1a | Would you consider equivalent product work from a solutions background toward the 3+ years? | unresolved |
| RR4 | Roadmap decision rights unspecified | unknown | — | "Own the roadmap for our partner-facing API platform" | Ownership may be shared with a product head or founders, with the PM accountable without authority | `[inferred]` from the JD's silence on authority | Which roadmap decisions does this role make alone, and which need sign-off? | unresolved |
| RR5 | Concrete, defined mandate | positive_signal | — | "two engineering squads"; "define and track adoption metrics" | Scope and success measures look genuine and bounded | `[grounded]` JD states squads, partners and metrics | Which adoption metrics does the team track today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting and employer on Quartzline's own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Before applying, or at the recruiter screen, ask the RR3 question and the RR4 question verbatim | The bar is the biggest uncertainty on this role | `[grounded]` register | pending your approval |
| E1 | Replace the opening summary line with: "Solutions engineer and implementation lead, 7 years, at an enterprise-software vendor: led 30+ client integrations of our REST APIs end to end, and ran quarterly roadmap-input sessions collecting client feedback for product." Every clause is your own wording from the summary you gave me. The title stays | Puts R5 and R6b where a PM reader sees them first, without changing any fact | `[grounded]` your resume summary | `resume_edits_pending_approval` |
| E2 | Positioning: state plainly in the first lines of any note that you have not held a PM title, then lead with R4a and R5 | A claim you did not make cannot be probed, and your own sentence is the baseline | `[grounded]` your statement | pending your approval |
| A3 | Alongside this role, consider PM-adjacent targets: titled associate or technical PM roles, or an internal move into product at your current vendor where you already work with PMs | Paths with a lower titled-years bar often exist for this background | `[generic]` role-family pattern | pending your approval |

Nothing in this plan, prose and tables alike, is final until you approve it.

## Evidence status

Verified: none yet. Unverified lead: a request-triage tool, from agent memory, unconfirmed (R2b, R8). Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched for Quartzline's careers page and role; the host refused the call. It would have confirmed the employer, size, stage and that the posting is live (role reality, RR1) |
| 2. Role-family sweep | unavailable | Searched for PM API-platform norms and solutions-to-PM transitions; the host refused the call. It would have given the market calibration and any pay band (role reality, RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

I can write this up as `tuesday-dossier.md` for later turns whenever you want it.

**Upgrade menu**

- Permission to run web search → RR1 and the market calibration resolve, within up to 5 searches and 2 fetches.
- Your actual resume text → the E1 line and R5 and R6a presentation gaps get checked against your real wording rather than the summary.
- A sanitized integration playbook or requirements document → R3 to `high`, R6a firmer.
- Anything inspectable on the triage tool → R2b and R8 could move from `unclear`.
- Your constraints (pay floor, location, seniority) → the hard-gates line becomes a real check.
- The hiring manager's name → role reality's scope read and which story to lead with.

**Questions**

G1 — Did you build or specify an internal request-triage tool that support agents adopted? What exactly did you own, who used it, and how did you know it worked?

G2 — In your integrations, did you work with sales before a deal or hand off to support at go-live? What did you own in those handoffs?

Constraints — What is your pay floor, your location or remote requirement, and would you accept a PM role at a more junior level than the 3+ year bar implies?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.