I'll read the reference files the skill points to before building the assessment.
# Job Underwriting Assessment: Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, it's worth applying, once R1 and R2 check out against your own terms. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R8, R9
- `important`: adjacent: R7 (BigQuery) · unclear: R10 (ingestion from app and CRM), R11 (data contracts analysts depend on)

R7: a Snowflake-to-BigQuery bridge with its limit named; R10, R11: your background says nothing on either yet; R1, R2: unconfirmed because your terms weren't given.

**Opportunity ledger.** The posting is live and states its pay (RR1). Scope, reporting line and team are unspecified (RR2), the equity terms are missing (RR3), and the company facts are self-reported only (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are US-based and the $148,000–$166,000 range meets your floor (R1, R2); (2) the BigQuery gap is framed as adjacent, never as BigQuery experience (R7); (3) RR2's scope question gets a concrete answer in the loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` company About page, found by search; self-reported, with no independent source checked (RR4) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD, live careers page |
| Terms | Remote (US) or Denver office; $148,000–$166,000 plus equity (no equity terms stated) | `[grounded]` JD |
| Posting status | Live ("Accepting applications"), text identical to what you pasted | `[grounded]` careers page fetched |
| Scope read | Three areas in one post: ingestion, warehouse modelling, and contracts. The posting names no team, reporting line or hiring manager, so I can't tell whether this is a solo owner or one of several engineers | `[inferred]` from the JD's three-part scope and its silence on team |
| First-90-day outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Datawright (n=2,310): Senior Data Engineer at Series B–D companies has a base median of $151,000 and an IQR of $139,000–$163,500. "Senior" typically means 5–8 years, and the usual scope is one domain's pipelines with no direct reports. The posted range starts just below that median and ends above the IQR's top; it is a posted range, not an offer. Your 6 years sits inside the typical band | `[grounded]` the report you supplied and the JD's figures; `[generic]` that these are role-family norms, not claims about this employer |
| Unknowns | Equity type and size; team size and reporting line; new headcount or backfill; whether the contracts work is mostly tooling or mostly stakeholder negotiation | `[grounded]` JD silent |
| Contradictions | None between your pasted JD and the live careers page | `[grounded]` page fetched |

## Evidence map

Your background was typed into the conversation and no CV was seen. That is self-report, so `medium` is the ceiling on every row below.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The JD's location term is stated. Confidence grades your own statement of the constraint, and you haven't given one | `[grounded]` JD quote; your location not given | G1 question |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay term is stated. Your floor isn't given. Against Datawright the range is in line with the market, but that says nothing about your floor | `[grounded]` JD; `[generic]` market band | G1 question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company, which exceeds 5+. Stated, specific, no inspectable artifact yet. This is a years requirement, not a gate. Datawright's typical senior range is 5–8 years | `[grounded]` your prose background; `[generic]` typical senior years | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. Nothing inspectable. Expect a technical probe | `[grounded]` your prose background | offer a sanitized query or code sample to raise to `high` |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Specific, with ownership stated | `[grounded]` your prose background | offer docs site or repo excerpt to raise to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the requirement as written is met. BigQuery itself is handled separately in R7 | `[grounded]` your prose background | none |
| R7 | BigQuery (named in the mandate, not in the requirements list) | important | adjacent | medium | transferability | Snowflake and dbt carry over: both are cloud warehouses with SQL modelling on top. Limit: you haven't used BigQuery, so you haven't touched its partitioning and clustering, its cost model or its permissions. Which tier it sits in is my reading of the JD | `[inferred]` from the mandate's wording and your Snowflake work; `[generic]` that these platforms share a modelling approach | G4 bridge; optional small BigQuery sample, pending approval |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration; scope and ownership of the DAGs aren't stated | `[grounded]` your prose background | offer a sanitized DAG excerpt to raise to `high` |
| R9 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, so ownership is stated | `[grounded]` your prose background | offer a data-docs screenshot or suite excerpt to raise to `high` |
| R10 | Ingestion from the app and CRM (from the mandate) | important | unclear | low | discovery | Your background names no ingestion work or source types. Payroll platforms commonly pull from product databases and CRM-type systems, but that is a pattern, not your history | `[grounded]` background silent; `[generic]` typical source mix | G2 question |
| R11 | Data contracts analysts depend on (from the mandate) | important | unclear | low | discovery | A 180-model dbt project likely had analyst consumers, but you haven't said whether you defined schemas, tests or ownership agreements with them | `[inferred]` from your dbt scale; unconfirmed | G3 question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whether you meet the posting's location and pay terms (R1, R2) | hard_gate | The JD gives terms, and no constraints were stated | A failed gate caps the decision however strong the fit | Not applicable; this is a yes/no fact | Not applicable | `[grounded]` JD terms, your constraints not given |
| G2 | Ingestion from product and CRM sources (R10, important) | discovery | The background names transformation, orchestration and testing, but not how data arrived in the warehouse | The mandate lists ingestion first, and an unresolved row changes what the application should lead with | Loading from an application database or a CRM or billing system; a vendor connector or a custom Python extractor; handling schema changes or late data in a feed | A pipeline diagram, an ingestion DAG excerpt, a source list | `[grounded]` background silence; `[generic]` that ingestion is a common probe area for this role family |
| G3 | Data contracts with analysts (R11, important) | discovery | A large dbt project, with no word on agreements with its consumers | Contracts are named in the mandate; this could move R11 to `direct` | Defining model schemas or dbt tests analysts relied on; agreeing a change process with a reporting team; versioning or deprecating a model | A dbt contract or schema file, a model-ownership doc, a change-notice example | `[inferred]` from the dbt scale; `[generic]` that contracts are a probe area |
| G4 | BigQuery bridge (R7, important) | transferability | Snowflake plus dbt, with no BigQuery use | The one named platform you haven't used | Bridge: warehouse modelling carries over. Limit: BigQuery-specific cost and partitioning habits weren't exercised. Strengthener: a small public-dataset dbt-on-BigQuery project | A repository link, if you choose to build one | `[inferred]` bridge from Snowflake and dbt; `[generic]` that BigQuery's cost model differs |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay in line with the market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is disclosed and the range overlaps Datawright's IQR | `[grounded]` JD and the report you supplied; `[generic]` for the band | Where in this range would someone with six years of experience land, and what decides it? | noted |
| RR2 | Scope, team and reporting line unspecified | unknown | — | "Build and run the pipelines … ingestion … a dbt-modelled warehouse in BigQuery, and the data contracts" | Datawright's typical scope is one domain's pipelines. This post spans three areas and names no team or manager, so it may be a solo owner of a platform | `[inferred]` from the JD's scope and its silence on team; `[generic]` for the typical scope | Who else does data engineering today, who would I report to, and which of ingestion, warehouse and contracts would I own alone? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The grant could be material or nominal; the posting doesn't say | `[grounded]` JD gives no terms | What type of equity is it, roughly what range for this level, and what are the vesting and strike terms? | unresolved |
| RR4 | Company facts self-reported only | unknown | — | "264 employees. Series C ($52M, February 2026)" | The facts appear on the company's own pages and match the posting. I didn't seek independent corroboration of the round or headcount, and nothing found suggests a problem | `[grounded]` company pages fetched; no outside source read | Is this new headcount or a backfill, and what does the data team's roadmap look like after the February round? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the dbt project (about 180 models), the Great Expectations suite you set up and your Airflow orchestration, using the JD's own terms | See R4, R5, R8, R9 | `[grounded]` your prose background | pending your approval, to be drafted from your CV |
| E2 | State the warehouse accurately: "dbt on Snowflake", with BigQuery not yet used; never imply BigQuery experience | See R6, R7 | `[grounded]` R6, R7 rows | pending your approval |
| W1 | Optional: a small public-dataset dbt-on-BigQuery project, labelled as a personal sample | Narrows R7's stated limit, and proves nothing about production use | `[inferred]` from the R7 limit | pending your approval |
| Q1 | Ask the verification questions in RR1 to RR4 in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C funding", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Moved role reality's organization, posting-status and contradictions rows; the posting is live and matches your paste. The about page is the only source for the company facts (RR4) |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand and fixes the market calibration and RR1's comparison |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

The dossier file is available whenever you want it; saying so produces it.

## Upgrade menu

- Your CV: checks the presentation gaps and lets me draft E1 and E2 in your own bullet wording.
- A sanitized dbt docs page or repo excerpt, a Great Expectations data-docs screenshot, an Airflow DAG excerpt: each can raise its row (R5, R9, R8) to `high`.
- Your answer on G1: closes R1 and R2, which could confirm or end the decision.
- Answers to G2 and G3: could move R10 and R11 to `direct` or `adjacent`.
- The recruiter's answers on RR2, RR3 and RR4: scope, equity and headcount.
- A hiring manager's name: sharpens the scope read and which story to lead with.
- A deeper research pass (independent corroboration of the Series C, leadership changes, public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1 — Are you US-based, and does $148,000–$166,000 plus equity meet your floor, with either Remote (US) or Denver acceptable to you?

G2 — Which data sources did you ingest into your Snowflake warehouse, and was any of that ingestion your own work (connectors, Python extractors, CDC)?

G3 — Did you define or enforce any agreement with the analysts consuming your dbt models, such as tests, schemas or a change process, and who owned it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.