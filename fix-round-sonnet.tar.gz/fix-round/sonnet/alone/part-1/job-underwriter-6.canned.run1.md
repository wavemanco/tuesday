I'll read the posting and the skill's reference files together.
Checking Quillfield, the salary range and Tamsin Achebe's public profile. I'll run those searches now.
## Decision snapshot

**Yes, apply, but as a stretch. R6b (owning a forecast) and R8b (owning billing data) are absent, and they are two of the role's headline duties. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days), R2 (salary £61,500–£67,000)
- `must_have`: direct: R3, R4, R5a, R9 · adjacent: R6a (forecast work), R8a (own CRM data) · unclear: R5b (spreadsheet modelling), R7 (finance, billing or revenue data) · absent: R6b (owning a forecast), R8b (own billing data)

R6b and R8b are both things you told me you haven't done; R6a (`medium`) is a credible bridge with its limit named; R5b and R7 are open and answerable from your own history.

**Opportunity ledger.** Sound so far: the employer matches its description (RR7) and the pay is stated and in band (RR5). Support, forecast decision rights and billing-data state are unknown (RR1, RR2, RR3), as are success measures (RR4) and option terms (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days), R2 (salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol hybrid and the salary work for you — R1, R2; (2) interviews show forecast and billing-data work can be learned on the job with support — RR1, RR2, RR3; (3) the bridge is framed honestly, with R6b and R8b stated as not yet done.
- **What would flip it to `no_go`:** R1 or R2 failing for you, or the employer expecting day-one ownership of both the forecast and billing data with no support (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. The posting names no manager; the link comes from your recruiter | `[grounded]` public profile result; `[grounded]` recruiter, via you |
| Scope read | CRM, billing data, reporting and a CFO-facing forecast in one title, with a Head of RevOps above it. Whether this role has reports is not stated | `[inferred]` from the posting's duty list and the manager's title |
| Market calibration | Posted range brackets the median for UK B2B software revenue operations leads, so no seniority-pay mismatch. Survey is UK-wide, base pay only | `[generic]` Ledgerline 2026 pay guide (median £64,200, interquartile range £57,800–£70,400, n=438); `[grounded]` posting for the range |
| Unknowns | Reporting line and team; who owns the forecast number; which billing system and its data state; first-year outcomes; option terms; which CRM Quillfield runs | — |
| Contradictions | None found. The posting is not confirmed on Quillfield's own site: the careers address I tried returned no page | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol office, hybrid, two days a week | hard_gate | unclear | none | hard_gate | The term is stated; your location and constraints are not. Confidence is `none` because you have stated no constraint | `[grounded]` posting; your message silent | Question 1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your floor was not given. The range sits inside the market band, see RR5 | `[grounded]` posting; `[generic]` band | Question 1 |
| R3 | 4+ years in revenue ops, sales ops or similar at a B2B software company | must_have | direct | medium | none | 5 years sales ops, the last 2 running revenue operations for the UK team. You described the employer as a B2B payments company, not a software company, so state it as you said it | `[grounded]` your background | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, self-reported. Which CRM Quillfield runs is unknown | `[grounded]` your background | Credential record or screenshot would raise to `high` |
| R5a | Strong SQL | must_have | direct | medium | discovery | "SQL weekly" shows use, not strength | `[grounded]` your background | A sanitized query or analysis would raise it |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows use; modelling is not stated | `[grounded]` your background | G5 |
| R6a | Forecast work: pipeline inputs and review | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director and rebuilt the pipeline dashboards. Limit: finance owned the forecast, so you did not own the number or its method | `[grounded]` your background | G1 |
| R6b | Experience owning a forecast | must_have | absent | none | capability | You confirmed you have never owned the company forecast | `[grounded]` your message | G2 |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Renewal dashboards touch revenue, but whose numbers fed them and whether finance reviewed them is unstated. You have not worked on billing data | `[grounded]` your background | G3 |
| R8a | Own CRM data | must_have | adjacent | medium | discovery | Admin certification, dashboards, and running UK revenue operations. "Own" and company-wide versus UK-team scope are not stated | `[grounded]` your background | G6 |
| R8b | Own billing data | must_have | absent | none | capability | You confirmed you have never worked on billing data | `[grounded]` your message | G4 |
| R9 | Build the pipeline and renewal reporting sales and finance run on | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Who consumed them, finance included, is not stated | `[grounded]` your background | A sanitized screenshot would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast work (R6a, must_have) | transferability | Pipeline review and dashboards feed forecast conversations. Finance owned the number | This is the bridge to R6b, your largest gap | Pipeline views finance used; reconciling pipeline to the finance number; renewal or conversion assumptions you supplied; explaining a variance | Pipeline review pack, dashboard screenshot | `[grounded]` your background; `[inferred]` that these could count |
| G2 | Owning a forecast (R6b, must_have) | capability | Never done, confirmed | The posting names the CFO forecast as a duty | A scoped-down stretch is the closure path: build the forecast model on your own pipeline data | A worked forecast model | `[grounded]` your message |
| G3 | Finance on revenue data (R7, must_have) | discovery | Renewal dashboards exist; finance interaction unknown | Could move R7 and strengthen R6a | Renewal figures finance validated; agreeing revenue definitions; month-end reconciliation | Renewal dashboard spec | `[grounded]` your background |
| G4 | Own billing data (R8b, must_have) | capability | Never worked on billing data | One of the posting's named duties | Learning the billing system's data once known; an interview question on onboarding support | None yet | `[grounded]` your message |
| G5 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use; no model described | "Modelling" is more than reporting | A model with assumptions and scenarios, not a report | Sanitized workbook | `[grounded]` your background |
| G6 | Own CRM data (R8a, must_have) | discovery | Admin certified; ownership and scope unstated | Company-wide ownership is the posting's wording | Data-quality rules, field and process changes, user permissions | Admin change log or a description | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Reporting line, team and tooling not stated | unknown | — | "You will own our CRM and billing data" | The title is Lead under a Head of RevOps, so support may exist | `[inferred]` posting and manager title | Who does this role report to, and what team and tools support it? | unresolved |
| RR2 | Forecast decision rights unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The CFO may own the number and the role runs the process | `[inferred]` "with the CFO" | Who owns the forecast number, and how would someone new to owning it be supported? | unresolved |
| RR3 | Billing data source and state unknown | unknown | — | "own our CRM and billing data" | Billing data quality may be a clean-up job | `[generic]` pattern for roles taking over billing data | Which billing system holds the data, and what state is it in? | unresolved |
| RR4 | No stated success measures | unknown | — | Posting lists duties, no outcomes | First-year outcomes may be undefined | `[grounded]` posting silence | What does success look like at 90 days and at one year? | unresolved |
| RR5 | Pay stated and inside the market band | positive_signal | — | "£61,500–£67,000" | Transparent and market-aligned | `[grounded]` posting; `[generic]` Ledgerline band | Is the range fixed for this role, or negotiable? | noted |
| RR6 | Share option terms unstated | unknown | — | "plus share options" | Value depends on strike price and vesting | `[generic]` how options usually work | What are the option terms: number, strike price, vesting? | unresolved |
| RR7 | Employer matches its description | positive_signal | — | "Quillfield, the invoicing software company" | Established, funded, Bristol-based | `[grounded]` "About Quillfield" page | Is this role new or a replacement? | noted |

## Application plan

Every row is a proposal. None is final until you approve it.

**resume_edits_pending_approval**

| # | Current basis (your words) | Proposed line | Status |
|---|---|---|---|
| E1 | "last 2 running revenue operations for the UK team" | Ran revenue operations for the UK team (last 2 of 5 years in sales operations) | resume_edits_pending_approval |
| E2 | "I run the monthly pipeline review with our sales director" | Run the monthly pipeline review with the sales director | resume_edits_pending_approval |
| E3 | "I rebuilt our pipeline and renewal dashboards" | Rebuilt the pipeline and renewal dashboards | resume_edits_pending_approval |

I left out "forecast", "billing" and "finance" on purpose: none of those is a claim you made.

**Interview framing** (pending your approval): "I haven't owned the company forecast — finance did that — and I haven't worked on billing data. I have run the monthly pipeline review with our sales director and rebuilt our pipeline and renewal dashboards."

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the UK RevOps run, the pipeline review and the dashboards; state R6b and R8b plainly. Her prior role was in payments sales operations, so your background may read as familiar to her. Do not claim overlap | see R3, R6a, R6b | `[grounded]` her public profile; `[inferred]` that it will read as familiar | pending your approval |
| Q1 | Ask RR1, RR2, RR3, RR4 and RR6 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Ask the recruiter whether forecast and billing-data experience is required on day one or learnable on the job | see R6b, R8b, RR2 | `[grounded]` register | pending your approval |
| W1 | Prepare a sanitized pipeline or renewal dashboard screenshot | see R9, R6a | `[grounded]` map rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol"; result "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers: no page. Moved role reality's organization and contradictions rows, and RR7 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software"; result "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example). Moved market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the scope read and P1 |

I can write all of this up as `tuesday-dossier.md` if you want a file to keep.

## Upgrade menu

- Your Bristol and salary position, plus your floor → R1 and R2 move to `direct` or `hard_gate_fail`.
- A sanitized dashboard screenshot or pipeline review pack → R9 and R6a toward `high`.
- A credential record for the Salesforce admin certification → R4 to `high`.
- An answer on finance's role in your renewal numbers → R7, G3.
- A deeper research pass on Quillfield (funding and leadership churn, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. R1, R2 — Do Bristol with two office days a week and £61,500–£67,000 both work for you, or is either a limit?
2. G3 (R7) — On your renewal dashboards, whose revenue numbers fed them, and did finance check or reconcile them with you?
3. G1 (R6a) — When you run the monthly pipeline review, do your numbers feed the forecast finance produces, and what did you supply?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.