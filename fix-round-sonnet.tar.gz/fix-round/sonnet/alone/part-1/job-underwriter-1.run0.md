I'll read the reference files the skill requires before building the assessment.
**Yes, apply. You're a fit on the core asks, and the decision is `conditional_go`.** R1, R2, R3, R4, R6 and R7a are `direct`. The conditions are listed below.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (Define and maintain the metrics layer)
- `important` — direct: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R5 — a bridge, its limit named; R7b, R8 — nothing stated yet, asked below; R9 — adjacent, limit named.

**Opportunity ledger.** The employer and posting could not be verified (RR1), compensation is withheld (RR2), and the scope bundles several jobs with no resourcing stated (RR3). One entry runs the other way: the responsibilities and tools are concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer and live posting verify (RR1).
  2. Your answers on R5, R8 and R7b hold up (G1, G2, G3).
  3. The salary and your constraints are checked before the loop (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app. Not independently verified. | `[grounded]` JD header |
| Mandate | Own product analytics: the metrics layer, A/B test design and analysis, Looker self-serve dashboards, roadmap partnership with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Location, working pattern, compensation | Not stated | `[grounded]` JD silence |
| Scope read | Senior individual contributor with two mentees, not a people-manager role. The JD says "mentor" and has no line-management language. | `[inferred]` from the JD's wording |
| Market calibration | Not run, because research was unavailable. No band is stated, and none is guessed from memory. | `[grounded]` the Research tier line below |
| Unknowns | What "metrics layer" means in their stack, which experimentation tooling exists, how much clinician involvement there is, salary, remote or onsite | `[inferred]` from what the JD leaves out |
| Contradictions | None inside the JD text. It was not checked against a careers page. | `[grounded]` JD only |

## Evidence map

All of this is your own prose, which counts as self-report like a CV. Nothing here has been inspected yet, so `medium` is the ceiling.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a meal-kit subscription company, stated, specific and unprobed | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is stated. "Expert" is a self-rating. Analyst loops often include a live SQL exercise. | `[grounded]` your background; `[generic]` on loop format | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. "At scale" is judged against their traffic, which is unknown. Expect a probe on test volumes and methods. | `[grounded]` your background | A sanitized experiment readout or the pricing-test write-up would raise it |
| R4 | Looker or similar BI | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your background | A dashboard screenshot, sanitized, would raise it |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards and a monthly metrics memo sit near this. You haven't said you owned the metric definitions themselves. Resolved downward to `low` until confirmed. | `[inferred]` from the governed-dashboards claim | G1 |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads | `[grounded]` your background | A sanitized memo would raise it |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | none | You present to the VP Product monthly. Which roadmap decisions your analysis drove is not stated. | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing stated about clinicians or other domain-expert partners | `[grounded]` background silence | G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing stated about mentoring | `[grounded]` background silence | G2 |
| R9 | Healthcare data experience (HIPAA) is a plus | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model. Limit: that is consumer data under privacy law, not health data under HIPAA. | `[grounded]` your background | Say it plainly as adjacent; see E4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, must_have) | discovery | Governed dashboards, but no statement that you owned the metric definitions underneath them | A `must_have` at `adjacent`; confirming ownership could turn it `direct` | Writing or approving the definitions for retention, activation or churn; a LookML model or shared metric spec you maintained; resolving "two dashboards, two numbers" disputes | A sanitized metric dictionary, a LookML excerpt, or a metrics spec | `[grounded]` background silence on definition ownership; `[inferred]` that confirmation moves R5 |
| G2 | Mentoring (R8, important) | discovery | No mention | The JD names two direct mentees | Reviewing junior analysts' queries or analyses, onboarding a new analyst, running an analytics office hour | None required; a short description is enough | `[grounded]` background silence |
| G3 | Clinician partnership (R7b, important) | discovery | No mention | Clinicians are named stakeholders | Working with subject-matter experts such as ops, nutrition, culinary or customer-care leads to turn analysis into decisions | A decision memo that shows a non-product expert's input | `[grounded]` background silence; `[generic]` that domain-expert partnership is the nearest analogue to clinician partnership |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation withheld | unknown | — | The JD gives no figure | The salary may sit below what the seniority implies, or may simply not be published | `[inferred]` from the JD's silence | What salary band is budgeted for this role? | unresolved |
| RR3 | Bundled scope with no resourcing stated | unknown | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards … mentor two junior analysts" | One person may carry metrics governance, experimentation, BI and mentoring without named engineering support | `[inferred]` from the length of the responsibility list against the JD's silence on support | What analytics-engineering or data-platform support does this role have, and who owns the experimentation tooling today? | unresolved |
| RR4 | Concrete responsibilities, named tooling, named team structure | positive_signal | — | "Looker", "two junior analysts", "design and analyze A/B tests" | The role's day-to-day is defined, and the tools overlap what you've used | `[grounded]` JD | What would a strong first 90 days look like? | noted |

## Application plan

Everything in this table is a proposal, `resume_edits_pending_approval`. That covers the language in E1 to E4 and the strategy rows. Nothing is final until you approve it. Each language line is your own sentence, reordered but not widened.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | See R3. It is your own wording and your strongest direct match. | `[grounded]` your background | pending your approval |
| E2 | Second bullet: "Built the company's Looker instance from scratch — 40+ governed dashboards." | See R4 | `[grounded]` your background | pending your approval |
| E3 | Third bullet: "Write the monthly metrics memo the exec team reads; present to the VP Product monthly." | See R6, R7a | `[grounded]` your background | pending your approval |
| E4 | Cover-letter or screen line: "I haven't worked in healthcare. I have handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse." | See R9. It states the limit and does not imply HIPAA experience. | `[grounded]` your background | pending your approval |
| A1 | Confirm the posting is live on Harborlight's own careers page before writing tailored material | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter for the salary band and location policy at first contact | See RR2, and your constraints (not given) | `[grounded]` RR2 | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your claims are self-reported prose and no artifact has been inspected. There are no memory leads or rejected inferences.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused (search permission not granted). It would have settled RR1 and role reality's organization and contradictions rows, so RR1 stands unresolved. |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range scope Looker experimentation 2026"; the call was refused. It would have supplied the market calibration line and a salary band to set against RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I can offer a dossier file (`tuesday-dossier.md`) of this assessment whenever you want one.

## Upgrade menu

- Search permission granted → I run the targets above. RR1 closes or confirms, and role reality gets a market calibration line.
- Your CV, a sanitized experiment readout or pricing-test write-up, a Looker dashboard screenshot, or a sanitized metrics memo → R3, R4 and R6 move toward `high`.
- A metric dictionary or LookML excerpt → R5 moves toward `direct`.
- Your non-negotiables (salary floor, location or remote, authorization) → the hard-gates line stops saying "checks unknown".
- The hiring manager's name → role reality's scope read and which story to lead with.
- A deeper research pass on Harborlight Health (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**G1** — In your Looker and Snowflake setup, did you personally define and maintain the metric definitions behind the 40+ dashboards (in LookML, a shared spec, or elsewhere)? Which metrics, and who else could change them?

**G2** — Have you mentored or reviewed the work of more junior analysts? How many, over what period, and in what form?

**Constraints** — Do you have non-negotiables I should check this role against, such as a salary floor, remote or hybrid, location or work authorization? The JD states none of them.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.