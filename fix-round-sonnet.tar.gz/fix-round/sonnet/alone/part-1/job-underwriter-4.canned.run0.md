I'll read the skill's reference files before building the assessment.
**Yes, apply once the posting verifies. R2, R3, R4, R5 and R6 (the `must_have` rows) are `direct` on your account, and the JD asks for neither pet-insurance experience nor people management. Status: `conditional_go`.**

I'm assuming you're evaluating the role, and I worked from your written background, not a CV.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6
- `important` — direct: R8a · unclear: R7 (Monitor rating models), R8b (recommendations for product)
- `preferred` — direct: R9

R2, R3, R4, R5, R6 — direct on your account, no artifact inspected yet; R7, R8b — the monitoring and product-facing halves of the JD are unstated in your background; R1 — location unconfirmed.

**Opportunity ledger.** The employer could not be established from search (RR1). Pay is withheld (RR2), and team, tooling and first-year outcomes are unstated (RR3, RR5). One entry runs the other way: the JD names concrete deliverables (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is live on Brindlemoor's own site and the employer checks out (RR1); (2) the UK-based, fully remote set-up is confirmed as met (R1); (3) your pet-insurance inexperience is stated plainly and not worked around (see the application plan).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. I could not confirm it exists as described (RR1) | `[grounded]` JD header; not established by research |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Requirements stated | 4+ years pricing or actuarial analytics; strong SQL and Python; GLM; presenting to underwriting or actuarial leads; insurance a plus | `[grounded]` JD |
| Pet and management | The JD asks for insurance experience generally, not pet. It lists no people-management requirement and no reports | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. Her profile lists a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books, and six years as head of pricing analytics at Calloway Re. It is a self-published page, not corroborated elsewhere | `[grounded]` profile page fetched |
| Scope read | The JD says "build and monitor", and her published talk is about monitoring, so monitoring may carry real weight in this role | `[inferred]` from the JD's wording beside her talk title |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Pay is withheld. A 2026 UK survey of senior pricing analysts at insurers and insurtechs (n=612) gives a median base of £58,400 and an interquartile range of £52,100 to £64,900. That is what to expect, not this employer's offer. I did not sweep scope norms, only pay | `[generic]` role-family survey snippet; `[grounded]` JD for the withheld pay |
| Unknowns | Salary; team size and reporting line; data and tooling; first-year outcomes; product maturity | — |
| Contradictions | None found, but there is no careers page to check the JD against | `[grounded]` careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You stated no location or right-to-work constraint. A UK motor-insurer job points to a UK base but settles nothing | `[grounded]` your background silent on location; `[inferred]` UK base from your employer | Ask R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics", the last 2 as senior analyst. Specific, but your own prose with no artifact. A years requirement is not a gate | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". "Strong" has no inspectable proof yet | `[grounded]` your background | A sanitised query or notebook would raise it |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book". Specific, with no artifact inspected | `[grounded]` your background | A sanitised model spec would raise it |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | "I present the quarterly pricing review to the head of underwriting". The JD says underwriting or actuarial, so this meets the underwriting side | `[grounded]` your background | A review-deck slide would raise it |
| R6 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team". You said "ran", not "designed". Reading the results is implied, not stated, so claim only "ran" until you confirm more | `[grounded]` your background | A test readout would raise it |
| R7 | Monitor rating models | important | unclear | low | discovery | You said "maintained", which may or may not include tracking the model after release. The lower reading is taken | `[grounded]` your wording; `[inferred]` that monitoring is part of maintaining | See G1 |
| R8a | Recommendations for underwriting | important | direct | medium | none | The quarterly review to the head of underwriting and the tests run with underwriting fit this | `[grounded]` your background | none |
| R8b | Recommendations for product | important | unclear | none | discovery | Nothing in your background touches product teams | `[grounded]` your background silent | See G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. Pet is not what the JD asks for | `[grounded]` your background and JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R7, important) | discovery | "Built and maintained" the GLM model. Nothing says whether that included performance tracking, or who owned it | The JD says "build and monitor", and the hiring manager's published talk is on monitoring. Resolving this is what lets you say "monitored" truthfully | Actual-versus-expected reviews of the young-driver model; refit decisions you made or ran; a monitoring pack or dashboard others used; investigating a performance drop | A sanitised monitoring pack, refit note or dashboard screenshot | `[grounded]` your wording; `[inferred]` weight from the JD and her talk title |
| G2 | Product-facing recommendations (R8b, important) | discovery | Underwriting is covered. No product audience appears | The JD names product as a recipient of results | A test result that informed a cover, excess or limit decision; a recommendation to a product or commercial owner; a review item product attended | A sanitised memo or review slide | `[grounded]` your background silent on product |
| G3 | UK-based fully remote (R1, hard_gate) | hard_gate | The JD says "Fully remote (UK)". Your background suggests a UK base but does not state it | An unconfirmed gate is still a gate. This one is a term you meet or don't, not experience | n/a — a term, not experience | Your own answer is enough | `[grounded]` JD text; `[inferred]` UK base from your employer |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too small or new to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Severity stays at the lower value because the only result was a person's profile naming it | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` a search returned nothing and the careers page I tried returned none | Can you point me to this role on Brindlemoor's own careers page, and tell me who would be on my interview panel? | unresolved |
| RR2 | Pay not stated | unknown | — | The JD as pasted contains no salary | Pay may sit below the survey band in role reality, or the employer may simply not publish it | `[inferred]` from the JD's silence against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Team, tooling and data unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean the sole analyst, without data engineering or tooling support | `[inferred]` from the JD's "own" against its silence on team and tooling | Who else is in the pricing team, and what data and tooling does this role own versus depend on others for? | unresolved |
| RR4 | Concrete deliverables named | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The activities are defined, so you can check your evidence against them | `[grounded]` JD | Which underwriting and product leads would I present results to? | noted |
| RR5 | First-year outcomes unstated | unknown | — | The JD describes activities, with no outcome or measure of success | The role may carry an open mandate with no agreed definition of success | `[inferred]` from the JD's silence on outcomes | What would a good first year look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV summary with your own claims: "5 years in pricing analytics at a UK motor insurer, the last 2 as senior analyst. Built and maintained the GLM rating model for the young-driver book. Ran 14 price tests with the underwriting team. Present the quarterly pricing review to the head of underwriting. SQL and Python daily." Put the actual year in place of "last year" | see R2, R4, R5, R6 | `[grounded]` each clause traces to your sentence | resume_edits_pending_approval |
| E2 | Keep "ran" and "maintained" as your wording. Don't write "designed", "monitored" or "advised product" until G1 and G2 are answered | see R6, R7, R8b | `[grounded]` your wording | resume_edits_pending_approval |
| P1 | For the pet gap, a plain line in any cover note: "My pricing experience is in UK motor insurance; I haven't worked on pet insurance." | The JD does not require pet | `[grounded]` your statement and the JD | pending your approval |
| A1 | Verify the posting and the employer on Brindlemoor's own site before investing application effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Be ready to say exactly what "maintained" covered in monitoring terms, since monitoring is where the JD and her talk title meet | see R7, G1 | `[grounded]` JD and fetched profile | pending your approval |
| Q1 | Ask RR1 to RR5's verification questions verbatim in any screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

The approval status on each row covers the prose advice here as well as the table.

## Evidence status

Verified: none yet. Unverified leads: none. Your background is CV-equivalent prose, so `medium` is the ceiling on first pass.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech", which returned no results, and fetched www.brindlemoor.com/careers, which returned no page. Not established, so RR1 and the `conditional_go` cap |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). I read only the snippet. It set the market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor" and fetched "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It moved the scope read and A2 |

I can write this up as `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**

- Confirmation that you meet the UK-based, fully remote term → R1 closes.
- Your salary floor and any other non-negotiables → the hard-gate checks against pay and terms stop being unknown.
- A link to the live posting on Brindlemoor's own careers page, or the recruiter's email domain → RR1 closes and the cap lifts.
- Your CV → buried evidence may surface and sharpen the map.
- A sanitised model spec, a test readout or a review-deck slide (the artifacts pricing work leaves) → R4, R5 and R6 can move toward `high`.
- The posted salary range → RR2 closes against the survey band.
- A deeper research pass on Brindlemoor (funding, leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- R1 — Is the UK-based, fully remote set-up something you meet today?
- G1 — When you maintained the young-driver GLM model, did that include tracking how it performed after release, such as actual versus expected, and who set up or reviewed that tracking?
- G2 — Has a price-test result of yours ever gone to a product owner or a commercial team, and what did they do with it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.