I'll read the reference files before building the assessment.
**Yes, apply, with two things to confirm first (R1 and RR1). Status: `conditional_go`.** Your lack of pet-insurance experience (R9) doesn't rule you out, and neither does never having managed anyone (RR3). Web search was refused in this session, so nothing here has been checked against Brindlemoor's own site.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based remote working)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: unclear: R7 (Recommendations for product)
- `preferred`: direct: R8 · adjacent: R9 (Pet-insurance domain knowledge)

R9 is a motor-to-pet bridge with its limit named; R5 (`medium`) has design-versus-execution unconfirmed; R7 has its product audience unconfirmed.

**Opportunity ledger.** The mandate is concrete and has a named director-level manager (RR4). The employer is unchecked (RR1) and pay is unstated (RR2). The posting names no reports, so your having managed nobody doesn't collide with anything it states (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based remote working); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed as met; (2) the post verified live on Brindlemoor's own careers page (RR1); (3) the pet-insurance gap stated plainly as adjacent, never as pet experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described in the posting as an insurtech with a pet-insurance product; not checked externally (RR1) | `[grounded]` JD header |
| Title and manager | Senior Pricing Analyst; hiring manager Odile Varga, Director of Pricing | `[grounded]` JD |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Stated requirements | 4+ years pricing or actuarial analytics; strong SQL and Python; GLM; experience presenting to underwriting or actuarial leads; insurance a plus | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A single-product ownership role reporting to the pricing director; whether it manages people is unknown | `[inferred]` from "own" and the manager's title, against the JD's silence on reports |
| Market calibration | Not established: the role-family sweep did not run, and the posting gives no pay, so there is no band to set against anything | `[grounded]` JD silent on pay; research target 2 unavailable |
| Unknowns | Salary; direct reports; first-year success measures; whether the posting is live on the employer's own site; your location and right to work | `[grounded]` gaps in the JD and your message |
| Contradictions | None between the pasted JD and what you told me; the posting was not compared with a careers page | `[grounded]` target 1 unavailable |

## Evidence map

Your background was typed into the conversation, so it counts as self-report with no inspectable artifact. That caps the claims below at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK): UK-based, able to work remotely for a UK employer | hard_gate | unclear | low | hard_gate | You haven't stated where you live or your right to work. A UK motor-insurer career suggests it but doesn't establish it | `[grounded]` JD term, candidate silent; `[inferred]` UK location from UK employer | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst" clears the stated 4+. It's specific but self-reported | `[grounded]` your background as typed | none; a CV would confirm dates |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is specific on frequency. The depth behind "strong" (data volumes, modelling libraries) isn't described, so `medium` | `[grounded]` your background as typed | A sanitized query or notebook would raise it to `high` |
| R4 | GLM experience, including building and monitoring rating models | must_have | direct | medium | none | Your words are "built and maintained the GLM rating model for our young-driver book". The JD's "monitor" isn't your verb, and maintenance is the nearest of your words | `[grounded]` your background as typed | Sanitized model documentation or a factor summary would raise it to `high` |
| R5 | Design and read price tests | must_have | direct | medium | discovery | "Ran 14 price tests last year with the underwriting team" fits the requirement. Whether you designed them (cells, sample size, duration) or read the results isn't in your sentence, so it resolves downward | `[grounded]` your sentence; `[inferred]` that "ran" may or may not cover design | Q2 |
| R6 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | "Quarterly pricing review to the head of underwriting" meets the underwriting side of an either-or requirement | `[grounded]` your background as typed | A sanitized review deck would raise it to `high` |
| R7 | Turn results into recommendations for product, as well as underwriting | important | unclear | low | discovery | You describe underwriting as your audience. Nothing places you in front of a product team, so the only support is indirect context | `[grounded]` your background silent on product; `[inferred]` from the JD's wording | Q3 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background as typed | none |
| R9 | Pet-insurance domain knowledge (not a stated requirement; the JD's scope is the pet product) | preferred | adjacent | medium | transferability | You've said you've never worked on pet insurance. What carries over: GLM rating and price tests in a personal-lines book. The limit: none of it touched pet data or pet-specific rating drivers | `[inferred]` adjacency from your motor work; `[generic]` that pet pricing has its own rating drivers | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based remote working (R1, hard_gate) | hard_gate | Nothing states your location or right to work | A gate that is unsettled caps the decision, and no wording solves it | Not experience-based; it's a status you confirm | None needed | `[grounded]` candidate silent; `[inferred]` that a "no" would make this `no_go` |
| G2 | Design and read price tests (R5, must_have) | discovery | 14 tests run with underwriting; your role in design and readout is not stated | A must-have you'll be asked to describe; it decides whether "designed" can appear on your CV | Choosing test cells or a holdout; sizing the sample or run length; writing the readout and recommendation; calling a test inconclusive | A test design note, a readout deck or a results summary (sanitized) | `[grounded]` your sentence silent on design; `[generic]` that tests are usually probed on design |
| G3 | Recommendations to product (R7, important) | discovery | Your audience is underwriting; no product-side work stated | The JD names product as a second audience | Taking a test result to a product owner, a commercial lead or finance; a pricing change that shaped a product decision | A recommendation paper or deck | `[grounded]` your background silent on product |
| G4 | Pet-insurance domain (R9, preferred) | transferability | Motor GLM and price testing carry over; pet data and rating drivers weren't exercised | It's your own flagged gap; stating the bridge and its limit reads stronger than leaving it unsaid | Any work on frequency/severity modelling, a thin-data segment or a book with long-tail claims; your young-driver book may be the closest | An optional one-page note on how your GLM approach would adapt to pet data, only if you want to write one | `[inferred]` bridge from your young-driver work; `[generic]` that thin-data segments are the nearest analogue |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | `low` | "Brindlemoor (insurtech)" | The check didn't run, so nothing was found either way. A new or small insurtech may simply have a thin footprint, or the posting may be stale. Severity is `low` because this is an unrun check, not a negative result | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` searches refused | Which careers page lists this role, and who would be on the interview panel? | unresolved |
| RR2 | Pay not stated | unknown | — | The posting gives no salary | The figure may sit in the full advert, or be withheld. I can't calibrate it because the sweep didn't run | `[grounded]` JD silent on pay | What salary range is budgeted for this post? | unresolved |
| RR3 | Direct reports unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean sole owner or lead of a small team; the second is where your not having managed anyone would matter | `[inferred]` from "own" against the JD's silence on reports | Does this post have direct reports now, and is any expected in the first year? | unresolved |
| RR4 | Specific mandate and named reader groups | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The responsibilities are concrete and match the day-to-day of pricing work | `[inferred]` from the JD's wording | How will success in this role be measured in the first year? | noted |

## Application plan

**Resume edits.** All four use only your own sentences and add no verbs, scope or numbers. Status: `resume_edits_pending_approval`. Nothing here is final until you approve it, and that covers the edits table and the advice below it.

| # | Your current framing | Proposed | Source |
|---|---|---|---|
| E1 | 5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst | "Pricing analyst, five years at a UK motor insurer, the last two as senior analyst; GLM rating, price testing, SQL and Python" | Your background |
| E2 | Built and maintained the GLM rating model for our young-driver book | "Built and maintained the GLM rating model for the young-driver book" (moved first) | Your background |
| E3 | Ran 14 price tests last year with the underwriting team | "Ran 14 price tests with the underwriting team" (put the calendar year in place of "last year"; no "designed" or outcome until Q2 is answered) | Your background |
| E4 | I present the quarterly pricing review to the head of underwriting | "Present the quarterly pricing review to the head of underwriting" | Your background |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Order the CV lines as E2, E3, E4 after E1, mirroring the JD's own order of activities | See R4, R5, R6 | `[grounded]` JD wording and your sentences | pending your approval |
| P2 | Say it plainly: "I haven't worked on pet insurance; I've built and maintained a GLM rating model for a young-driver book and run price tests with the underwriting team" | See R9; every clause traces to your sentences | `[grounded]` your sentences | pending your approval |
| P3 | If asked about managing people, say you haven't; hold any further framing until RR3 is answered | You told me you've never managed anyone | `[grounded]` your statement | pending your approval |
| P4 | Confirm the role is live on Brindlemoor's own careers page before sending an application | See RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Ask the RR1, RR2, RR3 and RR4 questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P6 | Reader-specific positioning for Odile Varga: not available. Her public footprint wasn't researched, and I'm not guessing what she values | Target 3 unavailable | `[grounded]` research accounting | not available |

## Evidence status

Verified: none yet. Unverified leads: none. Stage assumed: evaluating. Your background is typed prose, so it carries CV-equivalent standing.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech UK" and "Brindlemoor careers Senior Pricing Analyst"; both refused (permission not granted). Would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; refused. Would have moved the market calibration line and the RR2 comparison |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. Would have moved role reality's scope read and P6's positioning |

I can write all of this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Search permission in this session would re-run the three targets above: employer and posting check (RR1), a pay band (RR2 and market calibration), and the hiring manager's public professional footprint (P6).
- A link to the live posting on Brindlemoor's careers page, or the recruiter's email domain, would settle RR1 without any search.
- Your CV would let me check E1 to E4 against the document rather than your typed summary.
- A sanitized model summary (R4), test readout (R5) or review deck (R6) would raise those rows toward `high`.
- Your salary floor and any other non-negotiables would turn the pay row and the other constraint checks from unknown into real checks.

## Questions

**Q1 (G1, R1).** Are you UK-based and able to work remotely for a UK employer without needing visa sponsorship?

**Q2 (G2, R5).** Across your 14 price tests, which parts did you personally own: designing the test (cells, sample size, duration), running it, or reading the result and recommending? What did underwriting do with your recommendation?

**Q3 (G3, R7).** Have you taken a pricing result to anyone outside underwriting, such as product, finance or a commercial lead? What did you recommend, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.