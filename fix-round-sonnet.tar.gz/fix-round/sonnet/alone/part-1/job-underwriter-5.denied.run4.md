I'll read the reference files the skill requires before building the assessment.
**Yes, it's worth applying to. The five `must_have` rows, R2, R3, R4, R5 and R6, all land `direct` on your account, and the posted pay sits at or above the market band. The open items are R1 (your location) and the BigQuery gap, R7. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office)
- `must_have` — direct: R2, R3, R4, R5, R6
- `important` — adjacent: R7 (BigQuery); unclear: R8 (ingestion from app and CRM), R9 (data contracts)

R7 — adjacent, the same dbt-modelled warehouse work on a different engine; R8 and R9 — your background says nothing either way.

**Opportunity ledger.** The pay is stated and market-aligned (RR3). Team, reporting line and authority are unknown (RR2), as are equity terms (RR4). I couldn't verify the posting or employer from my side (RR1). Success measures are not stated (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed; (2) RR1 closed and RR2 answered in the loop; (3) the BigQuery gap (R7) framed honestly as new, never as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not checked against the live site |
| Mandate | Build and run the pipelines behind reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| Scope read | End to end from ingestion through modelling to contracts, with no team, reporting line or hiring manager named, which reads wider than a single domain | `[inferred]` from the JD's mandate against its silence on team |
| Market calibration | Senior at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500, typically 5–8 years, owning one domain's pipelines with no reports. The posted range runs from $3,000 under the median to $2,500 over the upper quartile, and your 6 years sits inside the usual band. Basis: the Datawright 2026 report (n=2,310) your recruiter sent, not a search I ran | `[generic]` the pay report pattern; `[grounded]` the posting's figures |
| Unknowns | Team size and reporting line; equity terms; first-year outcomes; the data stack beyond what's named | — |
| Contradictions | Not checked: the live careers page could not be read (see Evidence status) | `[grounded]` research refused |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or your US work eligibility, so the term can't be settled either way | `[grounded]` background gives no location | Question R1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company; a typed background is a self-report, so `medium` | `[grounded]` your stated background | Offer: a dated CV or LinkedIn history would raise it to `high` |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily; "strong" is untested without an artifact, so expect a technical screen | `[grounded]` your stated background; `[generic]` that screens for this title usually test both | Offer: a code sample you're free to share would raise it to `high` |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake, which is a cloud warehouse; the JD's phrase is "a cloud warehouse", not BigQuery specifically (that's R7) | `[grounded]` your stated background; `[grounded]` JD wording | Offer: a model count or lineage screenshot, sanitized, would raise it to `high` |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration; the JD names Airflow | `[grounded]` your stated background | Offer: a sanitized DAG excerpt would raise it to `high` |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite | `[grounded]` your stated background | Offer: suite structure or check categories, sanitized, would raise it to `high` |
| R7 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Carries over: modelling and testing in dbt on a cloud warehouse. Limit: you've never used BigQuery, so its engine behaviour and cost model are untested for you. Strengthener: a small dbt project on BigQuery | `[grounded]` your "never used BigQuery"; `[inferred]` the bridge from the dbt-on-Snowflake work | See G1 |
| R8 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background mentions pipelines at a payroll company but doesn't say what sources fed them | `[grounded]` your background silent on sources | Question R8 below |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing in your background mentions contracts, schemas agreed with consumers, or analyst-facing guarantees; the Great Expectations suite may be adjacent, but I won't assume it | `[grounded]` your background silent on contracts | Question R9 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | dbt on Snowflake, no BigQuery use | It is the warehouse in the mandate's first line, so interviewers will probe it | A side project, a migration you scoped, or a sandbox dbt project on BigQuery | A small public repo or a short write-up of what differed from Snowflake | `[grounded]` your "never used BigQuery"; `[generic]` that a named platform gets probed in a technical loop |
| G2 | App and CRM ingestion (R8, important) | discovery | Pipelines at the payroll company, sources unstated | It is half of the mandate's first clause and could be direct or absent | Loading from a product database, event stream or API; syncing a CRM such as Salesforce or HubSpot; payroll-system or customer-data feeds | A source inventory, a DAG excerpt, or a design note | `[grounded]` your background silent on sources |
| G3 | Data contracts (R9, important) | discovery | The Great Expectations suite exists; contracts with consumers unstated | The JD names contracts analysts depend on as a deliverable | Agreed schemas or SLAs with analysts; breaking-change processes; Great Expectations checks run as agreed guarantees | A sanitized schema agreement, a changelog, or the suite's structure | `[grounded]` your background silent on contracts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting and employer not verified from my side | unknown | — | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)" | The pasted copies may be stale, or may differ from the live pages | `[grounded]` the pasted text; the check was refused | Can you confirm the role is open and who it reports to? | unresolved |
| RR2 | Team and authority unstated against a broad mandate | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole data engineer owning ingestion, modelling and contracts, more than the usual single domain | `[inferred]` from the JD's scope against its silence on team; `[generic]` the pay report's single-domain norm | Who else is on the data team, and who owns the contracts with analysts? | unresolved |
| RR3 | Pay stated and in line with the market | positive_signal | — | "$148,000–$166,000 plus equity" | Transparent pay at the median or higher; the top sits above the upper quartile | `[grounded]` JD figures; `[generic]` Datawright band | Where in the range would my level land? | noted |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The grant size, vesting and valuation could change the real offer materially | `[inferred]` from "plus equity" with no terms given | What is the equity grant structure, vesting schedule and current valuation basis? | unresolved |
| RR5 | No first-year outcomes stated | unknown | — | "Build and run the pipelines" | Success may be undefined for a demanding mandate | `[inferred]` from the JD listing duties and no outcomes | What would a successful first year look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume lines: "Built the dbt project on Snowflake — about 180 models" and "Set up the Great Expectations test suite"; Airflow, SQL and Python stay as you stated them | see R4, R5, R6; each traces to your own sentences | `[grounded]` your background | resume_edits_pending_approval |
| P1 | In the cover note, say it plainly: "I haven't used BigQuery; my dbt project of about 180 models ran on Snowflake." Add nothing on contracts or ingestion until R8 and R9 are answered | see R7, R8, R9 | `[grounded]` your background | pending your approval |
| P2 | Build a small dbt-on-BigQuery project before the technical loop, and link it only if you complete it | see G1 | `[inferred]` from the transferability gap | pending your approval |
| Q1 | In the loop, ask the verification questions of RR1, RR2, RR4 and RR5 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. No claim of yours has been confirmed against an artifact, so R2 through R6 stay at `medium`.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent a fetch of pellucidlearning.com/careers/senior-data-engineer and a search for "Pellucid Learning online tutoring K-12 Denver Series C"; both were refused for lack of permission. It would have checked whether the posting is live and the employer exists as described, feeding role reality's contradictions row and RR1 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line and the pay comparison in RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

I can also write this up as `tuesday-dossier.md` if you want to keep or reuse it.

**Upgrade menu**

- Search permission, so the live careers page and employer get checked → RR1 closes and the contradictions row fills.
- A deeper research pass on Pellucid Learning (up to 5 more searches and 2 more fetches) → funding, leadership and hiring-pattern signals feed the register.
- A dated CV or work history → R2 to `high`.
- A sanitized dbt lineage view, DAG excerpt or Great Expectations suite outline → R3 through R6 to `high`.
- Your answers on sources and contracts → R8 and R9 move off `unclear`.
- The hiring manager's name, if the recruiter has it → role reality's scope read and which story to lead with.

**Questions**

- R1 — Where are you based, and are you eligible to work in the US without sponsorship, so that remote (US) or Denver is open to you? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- R8 — Did any pipeline you built or ran ingest from a product database, event stream, API, or a CRM, and what did you own in it?
- R9 — Did analysts or other teams depend on agreed schemas or guarantees from your pipelines, and did your Great Expectations suite serve as that agreement?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.