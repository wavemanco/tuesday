I'll read the reference files before building the assessment.
## Decision snapshot

**Should you go for it? Probably yes on fit, but not before one term is settled. The JD says "Fully remote (UK)" (R1) and the company's own careers page says "Leeds office four days a week". Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (Monitor rating models)
- `important` — unclear: R7b (Recommendations for product)
- `preferred` — direct: R9

R1 — the posting contradicts itself on where the work happens, and your constraints weren't given; R5b (`low`) — "maintained" doesn't yet show monitoring; R7b — no product-facing evidence yet.

**Opportunity ledger.** The duties are clearly scoped, but the posting contradicts itself on location (RR1), withholds salary (RR3), and has a thin public footprint beyond its careers page (RR2). Pet-specific expectations (RR4) and team scope (RR5) are unstated. One entry runs the other way: the hiring manager has a published pricing-analytics background (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** two answers, yours on G1 and the employer's on RR1. If you need remote and Brindlemoor confirms Leeds four days, R1 becomes `hard_gate_fail` and the status `no_go`. If the working pattern suits you, the status moves to `conditional_go`, with R5b and RR3 still to close.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor has a live careers page for this role on its own domain, with a pet-insurance product matching the JD. A general company search returned nothing, so stage, size and funding are not established | `[grounded]` careers page fetched; general search empty |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both texts |
| Reports to | The Director of Pricing | `[grounded]` careers page |
| First-year outcomes, authority, team | None stated: no success measures, no decision rights over recommendations, no direct reports mentioned | `[grounded]` JD silence |
| Scope read | One analyst owning rating, testing and recommendations end to end for a single product | `[inferred]` from the JD's "own" and its list of duties |
| Pet experience | Not required. The JD lists "insurance experience a plus" | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books). Previously head of pricing analytics at Calloway Re for six years | `[grounded]` search-result summary of her profile page (page not opened) |
| Market calibration | UK senior pricing analysts at insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 (Pricewell 2026, n=612). The posting withholds salary, so this is a band to expect, never Brindlemoor's offer | `[generic]` role-family survey, read from a search summary only; `[grounded]` JD silent on salary |
| Contradictions | JD says fully remote; careers page says Leeds four days a week (RR1) | `[grounded]` careers page fetched |

## Evidence map

Your background was typed in, so it has the same standing as a CV: leads, not proof. That caps these rows at `medium` until something inspectable exists.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD states remote and the careers page states Leeds four days. Confidence grades your own statement of the constraint, and none was given. UK residence is not stated either | `[grounded]` the two texts; `[inferred]` UK base from a UK employer | G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst" exceeds the stated four. Typed claim, not yet inspected | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Depth beyond "daily" is not described, so expect a probe | `[grounded]` your background | Offer: a sanitised query or notebook would raise this to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Confirmed and specific, no artifact yet | `[grounded]` your background | Offer: a sanitised model spec or factor-review pack would raise this to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: "built" the young-driver GLM | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". That is adjacent to monitoring but does not state it. Monitoring is not carried over as a claim until you describe it | `[grounded]` the word "maintained"; `[inferred]` that it may include monitoring | G2 |
| R6 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team". "Ran" does not say how much of the design versus the readout was yours, and this resolves downward until you say. Expect a probe | `[grounded]` your background | Offer: a sanitised test readout would raise this to `high` |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You work with underwriting on the tests and present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in your background mentions a product team. Low rather than none because motor pricing work often touches product | `[grounded]` silence; `[generic]` that pricing work often touches product | G3 |
| R8 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | Offer: the sanitised review deck would raise this to `high` |
| R9 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer. Pet is new to you, and the JD does not require it (RR4) | `[grounded]` your background and JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD and the careers page disagree, and your location and remote requirement aren't stated | The posting's own term decides eligibility; the gate is settled by the facts, not by wording | Nothing to recall. It turns on where you are based and whether four office days in Leeds are workable | Your own constraint; the employer's confirmation of the true terms | `[grounded]` the two texts |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" the young-driver GLM, with no detail on what was watched or how often | A must-have, and the hiring manager's published talk is on monitoring rating models, so this is where a probe is most likely | Tracking actual versus expected by factor, drift in inputs, periodic model reviews, alerts or thresholds, a re-fit after something moved | A sanitised monitoring pack or dashboard screenshot, or a model review note | `[grounded]` your wording and her talk title; `[inferred]` that this row will be probed |
| G3 | Recommendations for product (R7b, important) | discovery | The underwriting audience is covered, and no product audience is mentioned | Moves one `important` row; low impact on the decision | A test result that changed a product feature, a bundle or an eligibility rule; a paper written for a product owner | A recommendation note or test readout that names the product audience | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | JD and careers page disagree on location (R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | The copy you saw may be older than the careers page, or the remote claim may be loosely meant. Medium, not high, because your constraint isn't stated | `[inferred]` from the two texts differing | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Thin company footprint beyond the careers page | unknown | — | "Brindlemoor (insurtech)" | Early-stage insurtechs often have little public presence, which is a pattern and not a finding about this one | `[generic]` pattern; `[grounded]` general search returned nothing | What stage is the company at, and which regulated insurer underwrites the pet product? | unresolved |
| RR3 | Salary withheld | unknown | — | No figure in the posting | The offer may sit inside or outside the `[generic]` band above; the withholding is itself worth a question | `[inferred]` from the posting's silence set against the survey band | What salary range is budgeted for this role? | unresolved |
| RR4 | Pet-specific knowledge expectations unstated | unknown | — | "insurance experience a plus" | Pet is new to you, so the question is how much pet knowledge is expected from day one and how it is taught | `[grounded]` JD wording and your background | What pet-specific knowledge do you expect in the first six months, and what onboarding exists? | unresolved |
| RR5 | Team scope unstated | unknown | — | "Own pricing analytics" | The JD lists no direct reports; whether any are planned is unknown. You have not line-managed | `[grounded]` JD silence and your background | Does this role have direct reports now, or are any planned? | unresolved |
| RR6 | Hiring manager has a published pricing-analytics record | positive_signal | — | "Director of Pricing", reports-to line on the careers page | Her listed talk and prior head-of-pricing-analytics role suggest the manager can assess the work you do | `[grounded]` search-result summary of her profile | What does she expect the first rating-model monitoring cycle to look like? | noted |

## Application plan

Every row is proposed, not applied. Each carries its own approval status.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the working pattern with Brindlemoor before investing in an application | R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV edit: lead with three lines in your own words — "Built and maintained the GLM rating model for the young-driver book"; "Ran 14 price tests last year with the underwriting team"; "Present the quarterly pricing review to the head of underwriting". Nothing added | R4, R6, R8 | `[grounded]` your sentences, restated | `resume_edits_pending_approval` |
| P1 | In the application and the first call, lead with the GLM build and maintenance, then the tests with underwriting. Mention monitoring only after G2 is answered | R4, R5a, R5b, R6 | `[grounded]` your claims; `[inferred]` ordering from the JD's own duty order and the manager's published talk topic | pending your approval |
| P2 | State plainly that your pricing work is motor and you haven't priced pet. The JD asks for insurance experience as a plus, not pet-specific | R9, RR4 | `[grounded]` JD and your background | pending your approval |
| P3 | If direct reports turn out to be in scope, say you haven't line-managed. The posting as written lists none | RR5 | `[grounded]` JD silence and your background | pending your approval |
| Q1 | Ask RR1, RR3, RR4 and RR5 verbatim at the first conversation. They double as interview preparation | The register | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst", which returned "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst); fetched that page. Moved R1, the contradictions row, RR1 and RR2 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read from the search summary only. Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read from the search summary only. Moved the hiring-manager row, RR6 and P1 |

I can write all of this up as `tuesday-dossier.md` if you'd like to keep it or carry it into later steps.

## Upgrade menu

- Your own constraints (where you're based, whether remote is firm, your salary floor): R1 becomes a firm pass or fail, and RR3 can be set against your floor.
- Brindlemoor's answer on working pattern: R1 and RR1 close, and the decision likely settles to `conditional_go` or `no_go`.
- A sanitised model monitoring pack or review note: R5b moves up, and R4 can reach `high`.
- A sanitised test readout or the quarterly review deck: R6 and R8 can reach `high`.
- The budgeted salary: RR3 closes.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news, candidate and employee reports; up to 5 more searches and 2 more fetches). Given how little the general search returned, say the word and it runs.

## Questions

1. **G1** — Could you work four days a week from the Leeds office, or is remote a firm requirement for you?
2. **G2** — When you maintained the young-driver GLM, what did you personally monitor, how often, and what did you do when something moved?
3. **G3** — Have you taken test or model results to a product team as well as underwriting, and what did they decide?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.