I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Possibly, but not until the work location is settled. R1 (Fully remote (UK)) is unconfirmed: the JD you pasted says fully remote, and Brindlemoor's own careers page says "Leeds office four days a week". Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7, R8a · unclear: R6b (Monitor rating models)
- `important` — unclear: R8b (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R6b, R8b: monitoring and product-facing work are not yet evidenced; R7: ran the tests, design ownership unconfirmed; R10: transfers by method, not by product.

**Opportunity ledger.** The work-location terms contradict each other across two sources (RR1), pay is unstated (RR2), and management scope is unstated (RR4). The company's size and stage are not established (RR5). One entry runs the other way: duties and a reporting line are concrete (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the hold waits on two answers. First, which working pattern is actually true (R1, RR1). Second, your answer on whether Leeds four days a week is workable (G1). If the role is confirmed remote, I'd expect `conditional_go`, with R6b evidence and pay as the conditions. If it is Leeds four days and that doesn't work for you, R1 becomes `hard_gate_fail` and the status `no_go`.

I've assumed you're at the evaluating stage. Your background came as typed prose, with no CV or artifacts, so every claim below is self-report.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, offering a pet-insurance product; the role is live on its own careers site | `[grounded]` JD header; fetched careers page "Senior Pricing Analyst — Brindlemoor careers" |
| Mandate | "Own pricing analytics for our pet-insurance product": build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD; careers page repeats the first clause |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` JD; careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week". Both recorded, neither resolved | `[grounded]` both quotes |
| First-90-day and first-year outcomes | Not stated in either source | `[grounded]` absence in the JD and the page read |
| Scope read | A single-product individual-contributor analytics post; the JD names no direct reports | `[inferred]` from the JD's duty list and its silence on reports |
| Market calibration | Pricewell's 2026 survey of UK insurer and insurtech senior pricing analysts (n=612) gives a median base of £58,400 and an interquartile range of £52,100–£64,900. The posting states no pay, so this is the band to expect, never Brindlemoor's offer (RR2). Remit and title norms were not searched | `[generic]` survey result (snippet read, not fetched) |
| Hiring manager | Odile Varga: Director of Pricing; previously head of pricing analytics at Calloway Re for six years; gave the 2025 Insurance Pricing Forum talk "Small Books, Loud Errors" on monitoring rating models in small books | `[grounded]` public profile result (snippet read) |
| Unknowns | Pay; team size and stage; direct reports; first-year outcomes | `[grounded]` absent from the sources read |
| Contradictions | Working pattern, as above | `[grounded]` JD against careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't said whether location is a constraint, so there is no statement to grade. The JD and the careers page disagree on the term itself | `[grounded]` JD quote against careers page quote | Ask G1; ask RR1's question of the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, 2 of them as senior analyst. Specific and plausible, but prose self-report with nothing inspectable yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | low | discovery | "SQL and Python daily" establishes use, not the depth "strong" implies. Taking the lower band and carrying the nuance here | `[grounded]` your background | A sanitised query or notebook sample would raise it |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, with no artifact yet | `[grounded]` your background | A sanitised model summary or documentation would raise it |
| R5 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which is underwriting leadership. Nothing inspectable yet | `[grounded]` your background | A sanitised review deck would raise it |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM evidence as R4, read against the "build" verb. Scope is the young-driver book only | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained" the model, which does not say whether you ran monitoring. Odile Varga's published talk topic is monitoring rating models, so the row matters | `[grounded]` your wording and the talk title; `[inferred]` that this makes it worth having evidence ready | Ask G2 |
| R7 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" does not settle who designed them, so I read it at the lower claim | `[grounded]` your background | Ask G3 |
| R8a | Turn results into recommendations for underwriting | must_have | direct | medium | none | Tests run with the underwriting team and a quarterly review to its head both point the same way | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing you said mentions a product audience | `[grounded]` silence in your background | G4 in the queue; not asked this turn |
| R9 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge (implied by the product, not stated as a requirement) | preferred | adjacent | medium | transferability | Rating-model and test methodology carries over. Limit: no pet-specific work, and pet rating typically involves different factors from motor, such as species, breed, age and vet-cost trend | `[inferred]` requirement from the product named in the role; `[generic]` on pet rating factors | G5 in the queue |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Work location (R1, hard_gate) | hard_gate | Two sources disagree and your own constraint is unknown | It can turn the status to `no_go` or release it to `conditional_go` | Not an experience gap. It is a term you either can meet or cannot | The employer's own answer to RR1 | `[grounded]` the two quotes |
| G2 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" the GLM, with nothing on monitoring | It is a `must_have` row at `unclear` | Tracking actual versus expected, drift checks, a periodic model-health review, or deciding when to refit or recalibrate | A sanitised monitoring report, a review slide, a refit note | `[grounded]` your wording; `[generic]` that monitoring is the part of the role Odile Varga has published on |
| G3 | Design of the price tests (R7, must_have) | discovery | 14 tests "run", with no design ownership stated | It tests whether you meet the "design" half of the requirement | Choosing what to test and the split, sizing the sample, setting the success measure, writing the readout | A test plan, a sanitised readout | `[grounded]` your wording |
| G4 | Recommendations to product (R8b, important) | discovery | Underwriting audience evidenced, product audience not | An `important` row, with no question asked this turn | A pricing change taken to a product owner, or a roadmap input from test results | A sanitised recommendation memo | `[grounded]` silence in your background |
| G5 | Pet-insurance knowledge (R10, preferred) | transferability | Method transfers, product specifics not | A bridge with a stated limit narrows an objection a pet insurer may raise | Any non-motor line you priced, or any read-across work on a different product | A short note on how you'd adapt the young-driver model to a new book | `[generic]` that a pet insurer may raise this; `[grounded]` your stated lack of pet work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Work-location terms contradict | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | The pasted JD may be an older or different version, or the careers page may be the current terms. Medium rather than high because staleness is a live possibility (see R1) | `[inferred]` from two sources disagreeing | Is this role fully remote, or based at the Leeds office four days a week — and which is in the contract? | unresolved |
| RR2 | Pay unstated | unknown | — | Neither the JD nor the careers page read states a salary | The figure could sit anywhere in or outside the survey band | `[inferred]` from the silence against the `[generic]` £52,100–£64,900 interquartile range | What salary range is budgeted for this role? | unresolved |
| RR3 | Duties and reporting line concrete | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The scope is defined at product level with a named reporting line | `[grounded]` JD and careers page | What does success look like in the first year? | noted |
| RR4 | Management scope unstated | unknown | — | "Own pricing analytics" — no direct reports named | The role may carry or grow into line management, which you haven't done | `[inferred]` from the JD's silence | Does this role have direct reports now, or is that expected? | unresolved |
| RR5 | Company size and stage not established | unknown | — | "Brindlemoor (insurtech)" in your JD header; the fetched page gave only role details | The role is real on the company's own site, but its stage, size and team size are unconfirmed | `[grounded]` the fetched page's contents | How large is the pricing team, and what stage is the company at? | unresolved |

## Application plan

Everything here is proposed, not applied: every row and the prose inside it is pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the work pattern with Brindlemoor before investing in an application: ask RR1's question verbatim | R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with: "Built and maintained the GLM rating model for the young-driver book; ran 14 price tests with the underwriting team last year; present the quarterly pricing review to the head of underwriting." Every clause comes from your own sentences, and it adds nothing about design or monitoring | R4, R6a, R7, R8a, R5 | `[grounded]` your background | resume_edits_pending_approval |
| P1 | Be plain that your pricing work is motor and that you haven't worked on pet insurance. Describe it as the same rating and testing method applied to a new book, not as pet experience | R10 | `[inferred]` from your stated lack of pet work and the JD asking only for "insurance experience a plus" | pending your approval |
| M1 | If management comes up, say you haven't line-managed. Your leadership is two years as senior analyst and the quarterly presentation to the head of underwriting | RR4 | `[grounded]` your background | pending your approval |
| A2 | Hold any monitoring story back until G2 is answered, then have the evidence ready. Odile Varga's published talk is on monitoring, so R6b is the row to firm up | R6b | `[grounded]` the talk title; `[inferred]` that this makes it worth preparing | pending your approval |
| Q1 | Ask the questions in RR2, RR3, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the role is live with the same product and reporting line, and it moved the working-pattern and contradictions rows, R1 and RR1. It said nothing on size or stage (RR5) |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst insurance UK salary remote pet insurance", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It moved the market calibration and RR2. Pay only; scope and title norms were not covered |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. It moved role reality's hiring-manager row, R6b's reasoning and A2 |

## Upgrade menu

- Your pay floor and other non-negotiables (remote-only, commute, start date) → the hard-gate checks run against them, and the hard-gates line stops flagging constraints as not given.
- Your CV, or sanitised artifacts such as a model-monitoring report, a price-test readout, the quarterly pricing review deck, or a query or notebook sample → R3, R4, R5, R6b and R7 can move from `low` or `medium` toward `high`. `[generic]` that these are the artifacts pricing analysts typically keep.
- An answer to G4 → R8b closes or stays a named gap.
- The recruiter's answers on work pattern and pay → R1, RR1 and RR2 close, and the decision should resolve to `conditional_go` or `no_go`.
- A deeper research pass on Brindlemoor (funding and leadership changes, hiring pattern, candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) → RR5 and the risk register get sourced. Say the word and it runs.

If it would help to keep this, I can save the assessment as `tuesday-dossier.md`, with no pressure to.

Three questions follow, most decision-moving first.

**G1** — Is fully remote a must for you, and would Leeds four days a week be workable (commuting or relocating), or does it rule the role out?

**G2** — Beyond building and maintaining the young-driver GLM, did you set up or run regular monitoring of it, and if so what did you own, how often did it run, and what did it catch or change?

**G3** — On the 14 price tests, which parts did you personally own (choosing what to test, the design and sample, the readout), and what happened to the results?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.