I'll read the reference files the skill requires before building the assessment.
I've read the skill's rules. Next I'm running the allowed research on Brindlemoor, the pricing-analyst market and the hiring manager, then I'll write the assessment.
The careers page says "Leeds office four days a week", which contradicts the JD's "fully remote". I'm fetching that page to check.
**Yes, apply, but find out the working pattern first: `conditional_go`.** The role doesn't ask for pet-insurance experience or for managing people, and your background matches most of what it does ask. The unresolved point is where you'd work. The JD you pasted says fully remote, but the company's own careers page says "Leeds office four days a week" (R1, RR1).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R6, R7 · unclear: R5 (Monitoring rating models)
- `preferred` — direct: R9

R5 (`low`) — monitoring is the one must-have your evidence doesn't yet reach; R1 — the JD and the careers page disagree on working pattern; R4, R6 and R7 — direct on your own account, with no document inspected yet.

**Opportunity ledger.** The role is live and sits under a pricing specialist (RR5), but its working pattern contradicts the JD (RR1), the employer has little independent footprint (RR2), no salary is stated (RR3), and the team around the "own" mandate is unspecified (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed as something you can accept (R1, RR1); (2) Brindlemoor is corroborated beyond its own careers page (RR2); (3) you can describe truthfully what monitoring you did on the young-driver GLM (R5, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described in the JD as a pet-insurance insurtech. The company's own careers page lists this role as "Accepting applications". Stage, size and product are not independently corroborated: a search on the company and product returned nothing | `[grounded]` careers page fetched; `[grounded]` company search returned no results |
| Mandate | "Own pricing analytics for our pet-insurance product": build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD and careers page agree on the mandate |
| Reporting line | The Director of Pricing, Odile Varga. Her public profile lists a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books, and six years as head of pricing analytics at Calloway Re | `[grounded]` careers page and profile search result; the profile page itself was not fetched |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` JD against fetched careers page, a contradiction (RR1) |
| Not required by the JD | Pet-insurance experience and people management. Insurance experience is listed as "a plus" | `[grounded]` JD text |
| Compensation | Not stated in the JD as you gave it, nor in the careers page text returned | `[grounded]` JD and fetched page |
| Market calibration | The Pricewell 2026 pay survey of senior pricing analysts at UK insurers and insurtechs (n=612) gives a median base of £58,400, with an interquartile range of £52,100 to £64,900. This is a market pattern, not Brindlemoor's offer, and not specific to pet insurance | `[generic]` role-family sweep, one salary search, survey snippet only |
| Scope read | An ordinary senior individual-contributor scope. No team, reports or first-year outcomes are stated | `[inferred]` from the JD's silence on team and outcomes |
| Unknowns | Working pattern, salary, team and reports, success measures | — |
| Contradictions | The JD's remote term against the careers page's Leeds four days a week | `[grounded]` fetched careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't said whether remote working is a constraint for you, so the band has no claim to grade. The posting itself is contradictory, so I can't tell whether it meets any constraint | `[grounded]` JD against careers page; `[grounded]` no constraint given | Q1; surface to the recruiter before investing in the loop |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, 2 of them as senior analyst. Confirmed by you, no document inspected | `[grounded]` your message | CV already carries it |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Confirmed, with no artifact inspected, so expect a technical probe | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your message | A sanitized model document would raise this to `high` |
| R5 | Monitor rating models | must_have | unclear | low | discovery | "Maintained" is the only link to monitoring. What you actually did after launch (tracking performance, spotting drift, deciding on refits) is not stated. Read at the lower claim | `[grounded]` your message; `[generic]` that monitoring is a core part of owning rating models | G1 / Q2 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Which parts you designed, sized or analysed is not stated, so don't claim more than "ran" until it is | `[grounded]` your message | Be ready to say which parts were yours |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD also mentions recommendations to product, and you've given no product-side audience | `[grounded]` your message; `[grounded]` JD | none |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer. Pet insurance specifically is not asked for | `[grounded]` your message and JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5, must_have) | discovery | You maintained the young-driver GLM. Nothing says how you tracked its performance after launch, or what you did when it moved | A must-have at `unclear`. The hiring manager's published talk is about monitoring rating models, so a probe is likely | Actual-versus-expected tracking you built or ran; a drift or segment check; a refit or rebase you decided on or contributed to; a monitoring pack someone else relied on | A sanitized monitoring dashboard or report, model documentation, a refit note | `[grounded]` your message and profile snippet; `[inferred]` that resolving it could raise the row |
| G2 | Working pattern (R1, hard_gate) | hard_gate | The JD says fully remote and the careers page says Leeds four days a week. You haven't stated a location constraint | If remote is a constraint for you, this may fail. I can't tell yet | Not applicable, since this is a term and not experience | The recruiter's written confirmation of the working pattern | `[grounded]` fetched careers page against JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale, or the role may be hybrid with the JD copy wrong. Which is true is not known | `[grounded]` both quotes; `[inferred]` the explanations | Is this role fully remote, or four days a week in the Leeds office? | unresolved |
| RR2 | Employer's independent footprint not found | risk_signal | low | "Senior Pricing Analyst — Brindlemoor careers … Accepting applications" | The company may simply be new or small. The live careers page lowers this from the standing entry's medium | `[generic]` pattern for companies of this size, not a claim about this one | Can you share the company's registration and regulatory details, and who I would be interviewing with? | unresolved |
| RR3 | Salary not stated | unknown | — | No figure in the JD or in the careers page text | It may sit below, within or above the market band in role reality, or the company may not publish pay | `[inferred]` from the withheld figure against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR4 | "Own" mandate with no team or resources stated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be a sole analyst, or may sit in a team. This also settles whether the post has reports | `[inferred]` from the JD's silence on team | Who else is in the pricing team, and does this role have any reports? | unresolved |
| RR5 | Role sits under a specialist hiring manager | positive_signal | — | "Director of Pricing … previously head of pricing analytics at Calloway Re for six years" | Your pricing work would be read by someone who has done it | `[grounded]` profile search result, snippet only | How does the pricing team currently monitor its rating models? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: put three lines near the top of your CV, in your own words: "Built and maintained the GLM rating model for the young-driver book"; "Ran 14 price tests with the underwriting team last year"; "Present the quarterly pricing review to the head of underwriting". Do not use "designed", "owned" or "led" until you've told me which of those you did | R4, R6, R7; each line traces to your sentence | `[grounded]` your message | pending your approval |
| P1 | Positioning in the cover note, pending your approval: say plainly that your experience is motor and not pet insurance, and that it is 5 years of pricing analytics at a UK motor insurer | R9; nothing here goes beyond what you told me | `[grounded]` your message | pending your approval |
| A1 | Ask the recruiter to confirm the working pattern in writing before you invest in interviews | RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Prepare your answer on monitoring the young-driver GLM, since the hiring manager has spoken publicly on that topic | G1, RR5 | `[grounded]` profile snippet | pending your approval |
| Q-ask | Ask RR1 to RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results, so stage, size and product are not established) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It moved role reality's working-pattern and contradictions rows, RR1 and RR2 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. It moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. It moved role reality's reporting-line row, RR5 and plan rows A2 |

If you'd like, I can save this as `tuesday-dossier.md` so it carries forward.

## Upgrade menu

- A sanitized model document or monitoring pack for the young-driver GLM, a price-test readout, or your quarterly pricing review deck → R4, R6 and R7 to `high`, and R5 resolved or confirmed as a gap.
- The recruiter's written answer on working pattern → R1 and RR1 close.
- Your own constraints (location, pay floor, notice) → the hard-gate checks stop reading "candidate constraints not given".
- A stated salary range → RR3 closes against the market band.
- A link to Brindlemoor's registration details or independent coverage → RR2 closes.
- A deeper research pass on Brindlemoor (leadership, funding, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Q1 (R1)** — Is working fully remotely a requirement for you, and would four days a week in Leeds be workable or a dealbreaker?
**Q2 (R5/G1)** — After the young-driver GLM went live, what did you personally do to track how it performed, and did that ever lead to a refit or a change you were involved in?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.