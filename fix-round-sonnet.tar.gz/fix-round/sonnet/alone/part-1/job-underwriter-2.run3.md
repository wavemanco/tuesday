Putting the assessment together from the JD and your resume.

## Decision snapshot

**No, this posting isn't a waste of your time, but it's a reach. R1a (3+ years of PM experience) is absent, while R3 and R4a land `direct`. Status: `conditional_go`.** One posting can't settle the wider pivot. This answers for this role only.

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-type work without the title), R2 (Shipped API or platform products), R5 (Own the roadmap) · unclear: R9 (Agile delivery) · absent: R1a (3+ years of PM experience)
- `important` — adjacent: R6 (Specs and delivery with two squads), R8 (Discovery with integration partners) · unclear: R4b (Launches with sales and support), R7 (Adoption metrics)

R1a — the titled-years row, absent; R1b, R2, R5, R6, R8 — adjacent, limits named in the map; R3, R4a — what the resume already supports; R7, R9 — unclear, one answer each could move them.

**Opportunity ledger.** The scope reads as defined and resourced (RR3). Four things are unestablished: the employer is unchecked (RR1), pay and location are unstated (RR2), decision rights over the roadmap are unstated (RR4), and the success measures are undefined (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies on Quartzline's own careers page — RR1; (2) the employer's reading of "3+ years" allows product work done under another title — R1a, A2; (3) the G1 and G2 answers hold up, since they could lift R7, R5 and R9 — and none of this is framed as having owned a roadmap unless you confirm it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header, not independently checked |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Must-haves as written | 3+ years PM experience (marked must-have), shipped API or platform products, technical fluency, stakeholder management across engineering, sales and customers, agile delivery | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | One full PM remit (roadmap, discovery, delivery, metrics, launches), not several roles folded into one title | `[inferred]` from the responsibility list against the two named squads |
| Market calibration | Not established. The role-family sweep did not run, so there is no title, scope or pay band to set this against | `[grounded]` no sweep result in hand |
| Likely probes | A platform-API PM post usually draws questions on what you shaped and shipped as the product owner, not only on API fluency | `[generic]` role-family pattern, not a claim about Quartzline |
| Unknowns | Pay, location or remote policy, reporting line, success targets, whether the post is new or a backfill | `[grounded]` JD silence |
| Contradictions | None visible inside the JD; not checked against the careers page | `[grounded]` JD text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (held as a PM role) | must_have | absent | none | capability | You say you have never held a PM title, so titled years are absent. The adjacent work is carried in R1b. A years-in-title line is often screened literally by employers | `[grounded]` your statement; `[generic]` literal-screening pattern | Wording can't close this. Test how the employer reads it (A2) |
| R1b | PM-type work done without the PM title | must_have | adjacent | medium | transferability | Requirements documents, roadmap-input sessions, and coordinating engineers and PMs on custom builds sit near PM work. Limit: none of it is described as done with decision rights, so expect the question of what was yours | `[grounded]` your resume summary; `[generic]` that this is the usual probe | G1, G2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ client integrations of your employer's REST APIs show deep use of an API product from the integrator's side. Nothing says you shaped, versioned or released the API itself. Limit named wherever the bridge is used | `[grounded]` your resume summary | G1; a sanitized artifact would narrow the limit |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture across 30+ integrations are specific but self-reported, with no inspectable artifact | `[grounded]` your resume summary | A sanitized Postman collection or architecture doc would raise to high |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran workshops, UAT and go-live with clients. Sales is not part of this claim (see R4b) | `[grounded]` your resume summary | none |
| R4b | Coordinate launches with sales and support | important | unclear | none | discovery | The resume summary names neither sales nor support | `[grounded]` resume silence | none this turn; ranks below G1 and G2 |
| R5 | Own the roadmap | must_have | adjacent | low | discovery | Quarterly roadmap-input sessions are input into a roadmap, not ownership of one. Low rather than none because scoping workshops may have involved prioritisation | `[grounded]` your resume summary; `[inferred]` that scoping may include prioritisation | G2 |
| R6 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and coordination of engineers on custom builds. Coordination is not ownership of a squad's backlog. The limit is named | `[grounded]` your resume summary | G2 |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | The resume summary has go-live counts but no adoption measures. A prior-context lead about a request-triage tool is unconfirmed, so it only prompts a question | `[grounded]` resume silence; memory lead, unconfirmed | G1 |
| R8 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and feedback sessions with clients are close. Limit: the sessions collected feedback for product, and the summary doesn't show you choosing what to investigate | `[grounded]` your resume summary | none beyond G2 |
| R9 | Agile delivery experience | must_have | unclear | none | discovery | Nothing in the summary mentions sprints, backlogs or agile ceremonies | `[grounded]` resume silence | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Built something users adopted (R7 important, also R2, R1b) | discovery | No adoption measure in the resume summary. A memory lead mentions a request-triage tool support agents adopted, unconfirmed | R7 is a stated responsibility, and a confirmed example would also narrow the R2 limit | An internal tool or process you defined; how you knew people used it; what you chose to build or leave out; a usage or ticket-volume change | A screenshot, usage numbers, a short write-up, a note from the support lead | `[grounded]` resume silence; unconfirmed memory lead; `[inferred]` that it could move R7 and narrow R2 |
| G2 | Prioritisation and agile working (R5 must_have, R9 must_have, R6 important) | discovery | Roadmap input is described. Who decided scope, and whether you worked inside sprints or backlogs, is not | R5 and R9 are must-haves, and answers could move both rows | Deciding what made a custom build's scope when requests exceeded capacity; sitting in sprint planning or refinement; writing tickets or stories; negotiating priority with a PM | A sanitized scope document showing cut items, a ticket-board export, sprint notes | `[grounded]` resume silence; `[generic]` that these two rows are commonly probed together |
| G3 | Titled PM years (R1a must_have) | capability | No PM title held | The one row wording can't fix. Only the employer's reading can | Not applicable. Closure is a different target or a different reading of the requirement | None | `[grounded]` your statement |
| G4 | Sales and support launch coordination (R4b important) | discovery | The resume summary is silent | Lower impact than G1 and G2 | Joint go-lives with account teams; escalation handoffs to support | A launch checklist or go-live handoff note | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company or posting may be hard to confirm, or simply small. Severity stays low because nothing adverse was found, only nothing confirmed | `[generic]` pattern for companies of this size, not a claim about this one | Where is this role listed on your own careers site, and who would the PM report to? | unresolved |
| RR2 | Pay and location unstated | unknown | — | "no salary, location or work arrangement appears in the posting as pasted" | The posting may withhold them, or the paste may have dropped them | `[grounded]` JD silence | What is the salary band, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Scope and resourcing stated | positive_signal | — | "Own the roadmap for our partner-facing API platform … drive delivery with two engineering squads … define and track adoption metrics" | The mandate, squads and metrics are concrete | `[grounded]` JD | What does success look like at 6 and 12 months? | noted |
| RR4 | Decision rights over the roadmap unstated | unknown | — | "Own the roadmap" beside "coordinate launches with sales and support" | Sales or partners may pull the roadmap while the PM carries accountability | `[inferred]` from the ownership wording against silence on how requests are prioritised | When a deal needs a partner-specific API feature, who decides whether it goes on the roadmap? | unresolved |
| RR5 | Success measures not yet defined | unknown | — | "define and track adoption metrics" | The role may be defining the metrics, not inheriting them | `[inferred]` from "define" with no baseline named | Which adoption metrics exist today, and who tracks them? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Quartzline's own careers page before drafting anything | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Before applying, ask a recruiter or contact: "Is 3+ years read as titled PM years, or does product work done under another title count?" | see R1a, G3 | `[grounded]` R1a | pending your approval |
| A3 | Position it on what your resume already says: 30+ client integrations of your employer's REST APIs, the playbook, the roadmap-input sessions. Describe the roadmap work as input unless G2 shows you decided priorities. In interviews, say plainly that you integrated the API and fed input to product | see R2, R5, R1b | `[grounded]` those rows | pending your approval |
| A4 | Offer a sanitized excerpt of your integration playbook, or a sanitized scope document, as the inspectable artifact | see R3, R6 | `[grounded]` the playbook is in your resume summary | pending your approval |
| A5 | Ask RR2 to RR5 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

**Resume edits, `resume_edits_pending_approval`:**

| # | Current line | Proposed | Audit | Status |
|---|---|---|---|---|
| E1 | "Ran quarterly roadmap-input sessions collecting client feedback for product" | Same wording, moved up beside the integrations line | Order only. No new fact. Stronger verbs such as "owned" or "shaped" trace to nothing you've said | pending your approval |
| E2 | "Coordinated our engineers, the client's engineers, and product managers on custom builds" | Same wording, kept | Unchanged. Words like "led squads" would trace to nothing you've said | pending your approval |

## Evidence status

Verified: none yet. Intake prose is treated as CV-equivalent, so `medium` is the ceiling on a first pass. Unverified leads: a prior-context mention of an internal request-triage tool that support agents adopted. It is unconfirmed and prompts G1 only. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was refused. It would have moved role reality's organization and contradictions rows and RR1's standing entry, which now reads unresolved |
| 2. Role-family sweep | unavailable | Same refusal. It would have moved the market calibration row and a pay band for RR2, which now read "not established" |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you'd like, I can save this as `tuesday-dossier.md`.

## Upgrade menu

- Search permission, or a link to the role on Quartzline's own careers page → RR1 and role reality's organization row resolve, and market calibration gets a pay band.
- The recruiter's email domain → a second check on RR1.
- Your G1 answer, plus any usage artifact → R7 firms up, and the R2 limit narrows or stays.
- A sanitized Postman collection, OpenAPI example or playbook excerpt → R3 to `high`.
- A sanitized scope document or ticket sample → R5, R6 and R9 move off `unclear` or `low`.
- A prior resume → it may hold PM-type items the current one dropped (R1b, R7).
- The hiring manager's name → role reality's scope read, and which story the plan leads with.

G1 — An earlier conversation suggested you built an internal request-triage tool that support agents adopted. Is that right, and if so, what was yours, who used it, and how did you know they'd adopted it?

G2 — On custom builds, who decided what went into scope when requests exceeded capacity, and did you work inside your engineers' sprints or backlog? Say what was yours.

C1 — Do you have any non-negotiables on pay floor, location or remote work, or on taking a step down in title for a first PM role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.