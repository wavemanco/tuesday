I'll read the skill's reference files before building the assessment.
Both research calls were refused (a fetch of the posting and a search for the company), so I checked nothing live. Everything below rests on what you pasted.

## Decision snapshot

**Yes, it's worth applying, on conditions. Status: `conditional_go`.** The pasted material shows a close skills match and a stated pay range at or above the market median in your report. Two things stay open: the employer and posting are unchecked (RR1), and your own pay, location and authorization terms haven't been stated (R10, R11).

**Fit ledger.**

- `hard_gate` — unclear: R10 (Remote (US) or Denver office), R11 (Pay $148,000–$166,000 plus equity)
- `must_have` — direct: R1, R2, R3, R4, R5, R6
- `important` — adjacent: R7 (BigQuery warehouse); unclear: R8 (Ingestion from app and CRM), R9 (Data contracts analysts depend on)

R1, R2, R3, R4, R5, R6 — rest on your own account, not yet inspected; R7 — Snowflake, not BigQuery, so a bridge with a stated limit; R8, R9 — your background is silent on them.

**Opportunity ledger.** The stack and deliverables are concrete and the pay range is posted (RR3). The employer and live posting are unchecked (RR1), the team shape and reporting line are unstated (RR2), and the equity terms are missing (RR4).

- **Hard gates:** none failed (R10, R11); unconfirmed: R10 (Remote (US) or Denver office), R11 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies live on the company's own careers site, and the employer matches what you pasted — RR1; (2) the location, authorization and pay terms suit you — R10, R11; (3) the team shape and who you'd report to turn out sound — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` text you pasted from the about page; not independently checked, because research was refused |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silent |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Broader than the report's "one domain's pipelines": ingestion, warehouse modelling and contracts are named together, and the JD gives no team size or reports | `[inferred]` from the JD's three named areas against the report's typical scope; `[grounded]` JD silent on team |
| Seniority read | 5+ years asked and 6 years held; the report puts "Senior" at 5–8 years | `[grounded]` JD and the pay report you supplied |
| Market calibration | Posted $148,000–$166,000 against a Series B–D Senior Data Engineer base median of $151,000 and interquartile range of $139,000–$163,500 (n=2,310). The low end is $3,000 under the median and the high end is $2,500 over the top of the interquartile range. Equity isn't covered by the report, so it can't be compared | `[grounded]` JD figure and the report you supplied; `[generic]` that the report's figures are a role-family pattern, never this employer's offer |
| Unknowns | Hiring manager (the posting names none), team size, reporting line, first-year outcomes, equity terms, posting date | `[grounded]` JD silent on each |
| Contradictions | None between the JD and about-page text you pasted; neither was compared with the live pages | `[grounded]` pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. This is a years requirement, so it is graded on fit, not treated as a gate. Self-reported, so `medium`: expect the years to be checked | `[grounded]` your background as typed | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You state using both daily. Nothing inspectable yet | `[grounded]` your background as typed | none |
| R3 | dbt | must_have | direct | medium | none | You state building the dbt project, about 180 models. The count stays attached to models. No artifact yet | `[grounded]` your background as typed | offer: a sanitized dbt docs or lineage screenshot would raise to `high` |
| R4 | A cloud warehouse | must_have | direct | medium | none | The requirement says "a cloud warehouse", and your dbt work ran on Snowflake. BigQuery is named separately in the mandate and carried as R7 | `[grounded]` JD wording and your background | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. The scale and what it ran are not stated, so none is claimed | `[grounded]` your background as typed | offer: a sanitized DAG listing would raise to `high` |
| R6 | Data quality testing | must_have | direct | medium | none | You state setting up the Great Expectations test suite. Coverage and how failures were handled are not stated | `[grounded]` your background as typed | offer: a sanitized suite config or checkpoint list would raise to `high` |
| R7 | BigQuery as the warehouse the dbt project models | important | adjacent | medium | transferability | You state never having used BigQuery, so only the dbt-on-Snowflake work carries over. The limit: nothing you did exercised BigQuery itself. Project structure and test practice usually carry across warehouses, while SQL dialect and cost and partitioning behaviour usually do not | `[grounded]` JD text and your statement; `[generic]` what carries across warehouses | see gap queue G1 |
| R8 | Ingestion from the app and the CRM | important | unclear | none | discovery | Your background doesn't mention ingestion sources, so nothing can be asserted. Not read as absent, since a CV-level summary often omits it | `[grounded]` JD text; your background silent | see gap queue G2 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Your background is silent. Tests and a dbt project are nearby, but a contract is an agreement with consumers or producers, and nothing you said says you had one | `[grounded]` JD text; your background silent | see gap queue G3 |
| R10 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you are, your authorization to work in the US, or any location limit. Confidence is `none` because there is no stated constraint to grade; fit is `unclear` because nothing settles it | `[grounded]` JD term; your constraints not given | the closing question tagged R10 |
| R11 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor. The range itself is calibrated in role reality, but whether it clears your floor is unknown | `[grounded]` JD term; your floor not given | the closing question tagged R11 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Six years of dbt and a cloud warehouse, on Snowflake; no BigQuery use | The JD names BigQuery in the mandate; the requirement list says only "a cloud warehouse". It is the most visible difference from your stack | Any query or load job you ran in BigQuery, a side project, or work on a team that used it. Only things you actually did count | A small dbt project run against BigQuery, which you would do and then show; until then the claim stays adjacent | `[grounded]` your statement and the JD; `[generic]` that a stack difference is a likely screening question |
| G2 | Ingestion from the app and CRM (R8, important) | discovery | Background silent on where data came from | It is the first item in the mandate. Resolving it could move R8 to `direct` or confirm a real gap | Loading product-database or event data into the warehouse; syncing a CRM or another SaaS source through a connector or custom code; owning a source-schema change | A pipeline diagram, a connector list, an ingestion README | `[grounded]` background silent; `[inferred]` that payroll work likely involved some source loading, which is a lead to ask about, not a claim |
| G3 | Data contracts (R9, important) | discovery | Background silent; nearby work is the dbt project and test suite | The JD says analysts depend on the contracts | A written agreement with analysts or a source team on fields and freshness; tests that blocked a release when a source changed; a schema-change process | A contract doc, a test config, a schema-change note | `[grounded]` background silent; `[inferred]` that the test suite may be adjacent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not established | risk_signal | low | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The posting may be stale or aggregated, or the pasted text may differ from the live pages. Severity is `low`, the lower of two candidate calls, because the pasted JD and about page agree and the stated stage fits the pay report's Series B–D band | `[generic]` pattern for unverified postings, not a claim about this company | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope, team and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole or first data engineer, with ownership broader than the report's typical single domain | `[inferred]` from the JD's three named areas and its silence on team, against the report's typical scope | Who else is on the data team, who would I report to, and what should be true after a year? | unresolved |
| RR3 | Pay range posted, at or above the report's median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The posted range is transparent and sits around the report's median, with the top above its interquartile range | `[grounded]` JD figure and the report you supplied | How is level set within this range? | noted |
| RR4 | Equity stated without terms | unknown | — | "plus equity" | The grant size, vesting and valuation basis may differ a lot from the headline | `[inferred]` from the JD naming equity and giving no terms | What is the equity grant, vesting schedule and latest valuation basis for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume bullet: "Built the dbt project on Snowflake — about 180 models." | R3 and R4; each clause traces to your sentence "Built our dbt project on Snowflake — about 180 models" | `[grounded]` your sentence | resume_edits_pending_approval |
| E2 | Resume bullet: "Set up the Great Expectations test suite." | R6; traces to "I set up our Great Expectations test suite" | `[grounded]` your sentence | resume_edits_pending_approval |
| E3 | Resume summary: "Six years of data engineering at a B2B payroll company; dbt on Snowflake, Airflow, Great Expectations, Python and SQL daily." | R1 to R6; each clause traces to your sentences | `[grounded]` your background as typed | resume_edits_pending_approval |
| E4 | Cover-note sentence: "I haven't used BigQuery; my dbt work was on Snowflake." | R7; says the limit first, so an interviewer has nothing to uncover | `[grounded]` your statements | pending your approval |
| W1 | A small dbt project run against BigQuery, shown only after you've done it | G1; narrows R7's limit. Until you've done it, nothing about BigQuery goes in a claim | `[grounded]` G1 | pending your approval |
| A1 | Check the posting on the company's own careers page, or ask the recruiter, before investing in the application | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 verbatim in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Fetch of pellucidlearning.com/careers/senior-data-engineer and a search for "Pellucid Learning online tutoring K-12 Denver Series C"; both refused. It would have confirmed the employer exists as described and the posting is live. It stands as RR1 and the upgrade menu offers it |
| 2. Role-family sweep | skipped | The Datawright pay report you pasted fixes the market calibration in role reality and the pay mismatch check (RR3) |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can package all of this as `tuesday-dossier.md` whenever you want it, with no need to decide now.

## Upgrade menu

- A link to the live posting on the company's careers page, or the recruiter's email domain → RR1 closes. Re-running the official-site check needs search permission granted here.
- A deeper pass on the company (funding and leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches) → fills the register further. Say the word and it runs, once permission is granted.
- A sanitized dbt docs or lineage screenshot, a DAG listing, or a Great Expectations suite config → R3, R5, R6 can reach `high`.
- Your CV or a prior resume → rows move from your typed account to a document; E1 to E3 get checked against it.
- Your answers to G2 and G3 → R8 and R9 become `direct`, adjacent or confirmed gaps.
- The hiring manager's name, from the recruiter → role reality's scope read and which story the application leads with.

Questions:

1. R10, R11 — Are you based in the US or near Denver, and does $148,000–$166,000 plus equity clear your minimum? Tell me if there are other terms you won't trade.
2. G2 (R8) — Have you personally owned loading data from an application database, product events or a CRM into your warehouse? What did you own, with what tooling, and how did you know it worked?
3. G3 (R9) — Have you agreed field, freshness or schema guarantees with analysts or an upstream team? What did you own, and what happened when a source changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.