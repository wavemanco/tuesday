I'll read the reference files the skill points to before building the assessment.
**No, you're not wasting your time. But this is a stretch application, and R1a (no titled PM years) is the obstacle to clear. Status: `conditional_go`.**

You gave no stated constraints, so I assumed you're evaluating, not yet applying.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R8, R9a · adjacent: R1b (PM-type work), R2 (Own the roadmap), R3 (discovery with integration partners), R4 (specs, drive delivery with squads), R7 (Shipped API or platform products) · absent: R1a (3+ years PM experience)
- `important` — adjacent: R6 (launches with sales and support) · unclear: R5 (adoption metrics), R9b (stakeholders in sales), R10 (agile delivery)

R1a — no PM title, the posting's stated must-have; R2, R3, R4, R7 — adjacent work with the limits named; R5 (`low`) — a memory lead waiting on your confirmation.

**Opportunity ledger.** The scope is concrete (RR6), but the employer is unverified (RR1) and the flexibility of the 3+ years bar is unknown (RR2). Pay, work arrangement and success measures are unstated (RR3, RR4, RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) a recruiter or referral confirms that equivalent product work counts toward the 3+ years (R1a, RR2), asked before you invest in a full application; (3) the application presents R1b, R2, R3, R4 and R7 as adjacent work and never as PM tenure.
- **What would change this:** a recruiter saying titled years are strictly required moves it toward `no_go` for this role (R1a, RR2). Confirming the request-triage tool, with an artifact, could lift R5 and strengthen R1b and R7. An unverifiable employer keeps it at `conditional_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B, as the posting describes itself | `[grounded]` JD header; not checked against the company's own site |
| Mandate | Own the roadmap of a partner-facing API platform; run partner discovery; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Must-haves stated | 3+ years PM experience (marked must-have); shipped API or platform products; technical fluency; stakeholder management across engineering, sales and customers; agile delivery | `[grounded]` JD |
| First-90-day and first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A full-cycle product post (roadmap, discovery, specs, delivery, metrics, launch) for one platform area | `[inferred]` from the JD's responsibility list |
| Market calibration | Not run, and the posting states no compensation, so there is no band to compare against | `[grounded]` JD silent on pay; the market sweep did not run (see Evidence status) |
| Unknowns | Pay; location or remote policy; first-year success measures; whether equivalent product work counts toward the 3+ years | `[grounded]` JD silent on each |
| Contradictions | None visible inside the posting text; not cross-checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management experience (titled PM years) | must_have | absent | none | capability | You said you have never held a PM title, so no titled years exist. Employers often screen a stated years requirement literally, though people from adjacent roles do get through | `[grounded]` your statement; `[generic]` screening pattern | Ask RR2's question before investing; carried as a material risk |
| R1b | Product management work over time (roadmap input, requirements, working with PMs) | must_have | adjacent | medium | transferability | CV: "Ran quarterly roadmap-input sessions collecting client feedback for product"; wrote requirements documents; coordinated with PMs on custom builds. Limit: you fed input to product's decisions and did not make the prioritization calls | `[grounded]` CV, unprobed so capped at `medium` | Answer G2 |
| R2 | Own the roadmap for the partner-facing API platform | must_have | adjacent | medium | transferability | The roadmap-input sessions are real adjacency. Limit: the CV shows collecting feedback, not owning priorities or trade-offs | `[grounded]` CV | Answer G2 |
| R3 | Run discovery with integration partners | must_have | adjacent | medium | transferability | Scoping workshops across 30+ client integrations resemble discovery conversations. Limit: they served delivery of a known integration, not the choice of what the platform should build | `[grounded]` CV; limit `[inferred]` from the CV's delivery framing | Answer G2 |
| R4 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | Requirements documents, integration architecture, and coordinating your engineers and the client's on custom builds. Limit: the CV does not say you owned a backlog or led a squad's delivery | `[grounded]` CV | Answer G2 |
| R7 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ client integrations of your employer's REST APIs and wrote the internal integration playbook. Limit: that is the implementer's side of the API, and the CV does not say you shipped or owned one | `[grounded]` CV; limit `[inferred]` from CV wording | Answer G1 (the triage tool lead) |
| R8 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus 30+ REST integrations. Specific, but nothing has been inspected, so `medium` | `[grounded]` CV | Offer: a sanitized playbook excerpt would raise it to `high` |
| R9a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, the client's engineers and PMs, and collected client feedback | `[grounded]` CV | none |
| R9b | Stakeholder management with sales | important | unclear | none | discovery | The CV does not mention sales | `[grounded]` CV silence | Answer G3 |
| R5 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent. A prior-conversation note suggests you built a request-triage tool that support agents adopted, but that is an unconfirmed lead and not evidence | `[grounded]` CV silence; the lead is `memory_lead` | Answer G1 |
| R6 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives (UAT through go-live) are adjacent. Limit: they are client-side deployments, not product launches, and sales and support involvement is not stated | `[grounded]` CV; limit `[inferred]` | Answer G3 |
| R10 | Agile delivery | important | unclear | none | discovery | The CV is silent on agile ceremonies or sprint work | `[grounded]` CV silence | Answer G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product ownership and adoption (R5, R7) | discovery | A prior-conversation lead about a request-triage tool support agents adopted; the CV does not mention it | It could be the one item that shows you building a thing and measuring its adoption, touching R5, R7 and R1b | Who asked for it and what you decided to build; what you specified; how you knew agents used it; what changed afterward | A screenshot, a short spec, usage counts, or a note from a support lead | `[grounded]` CV silence; `[inferred]` that it touches R1b and R7 |
| G2 | Prioritization and spec ownership (R1b, R2, R3, R4) | discovery | Input, requirements and coordination are on the CV, but not who decided what got built | These are the rows where "adjacent" could become "direct" or stay adjacent | A roadmap-input session that changed what product built; a requirements document an engineering team built from; a trade-off you argued for | A roadmap-session summary, a requirements document (sanitized) | `[grounded]` CV; `[generic]` that these are the rows interviews for this title usually probe |
| G3 | Sales and support coordination (R6, R9b) | discovery | Nothing on sales or support in the CV | Both are named in the posting's responsibilities | Joint calls with sales on a client's scope; handing a go-live to support; a client escalation | A handover document or go-live checklist | `[grounded]` CV silence |
| G4 | Agile delivery (R10) | discovery | The CV is silent | A stated requirement, though lower in impact than G1 and G2 | Sprint work with client or internal engineers; backlog refinement on a custom build | A board export or sprint note | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too small for a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | A must-have years requirement against a pivot profile | unknown | — | "3+ years product management experience (must-have)" | It may be applied literally, or may accept equivalent product work | `[generic]` pattern, not a claim about this employer | How do you assess the 3+ years, and does product work done under a different title count? | unresolved |
| RR3 | Compensation not stated | unknown | — | no pay figure in the posting | Pay may be withheld or simply unpublished; with no band run, there is no comparison | `[grounded]` posting silent | What salary range and level is budgeted for this role? | unresolved |
| RR4 | Location and work arrangement not stated | unknown | — | no location in the posting | Unknown; matters once you state your constraints | `[grounded]` posting silent | Is the role remote, hybrid or on-site, and where? | unresolved |
| RR5 | First-year outcomes and success measures not stated | unknown | — | "define and track adoption metrics" | Adoption metrics are part of the job, so a baseline may not yet exist | `[inferred]` from the JD asking the hire to define metrics | What adoption numbers exist today, and what should be true in a year? | unresolved |
| RR6 | Concrete scope: named platform, two squads, listed responsibilities | positive_signal | — | "drive delivery with two engineering squads" | The post looks defined, not a vague "own everything" mandate | `[grounded]` JD | Who sets the platform's priorities today, and where does the hire's authority start? | noted |

## Application plan

Every row is proposed language or action and is pending your approval. Nothing here is final.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Edit `resume_edits_pending_approval`: move your existing line "Ran quarterly roadmap-input sessions collecting client feedback for product" into its own bullet near the top of the experience section, wording unchanged | R1b, R2 | `[grounded]` CV | pending your approval |
| E2 | Summary line `resume_edits_pending_approval`: "Solutions engineer and implementation lead, 7 years; led 30+ client integrations of our REST APIs and ran quarterly roadmap-input sessions for product." Every clause is your own wording from your CV | R7, R8, R1b | `[grounded]` CV | pending your approval |
| E3 | Do not write or say "PM experience" or "owned the roadmap"; describe the work as input, requirements and coordination | R1a, R2 | `[grounded]` your statement of no PM title | pending your approval |
| W1 | A sanitized excerpt of your integration playbook as a work sample | raises R8 | `[grounded]` CV | pending your approval |
| A1 | Before a full application, ask the recruiter or a referral RR2's question, and verify RR1 on the company's own careers page | R1a, RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Use a referral, if you can find one, rather than a cold application | titled-years bars are often screened more strictly without a human vouching | `[generic]` pattern, not a claim about this employer | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-conversation mention of a request-triage tool support agents adopted, which is unconfirmed and used only to prompt G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform careers Product Manager"; the call was refused. It would have established whether Quartzline exists as described and the posting is live, feeding RR1, role reality's organization and contradictions rows, and the decision cap |
| 2. Role-family sweep | unavailable | Searched "platform API product manager salary requirements transition from solutions engineer to product manager"; the call was refused. It would have supplied the market calibration line and a pay band to set against RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'll offer a dossier of this assessment as `tuesday-dossier.md`, if you want it.

## Upgrade menu

- Permission to run searches → RR1 resolves or hardens, and role reality gets its market calibration and a pay band for RR3.
- The hiring manager's name → role reality's scope read, and which of your stories to lead with for that reader.
- An answer and artifact on the triage tool (a screenshot, spec or usage note) → R5 and R7 move up from their current bands, and R1b may strengthen.
- A requirements document or roadmap-session summary, sanitized → R1b, R2, R3 and R4 can move from adjacent toward direct.
- A sanitized playbook excerpt → R8 to `high`.
- Your non-negotiables (pay floor, location, remote) → hard-gate checks against RR3 and RR4 stop being unknown.
- The recruiter's answer on RR2 → R1a and RR2 settle, and the decision likely simplifies to `go` or `no_go`.

G1 — Can you tell me about the request-triage tool support agents used: who asked for it, what you decided to build and specify, and how you knew agents were using it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Has any roadmap-input session, or any requirements document you wrote, led to something your engineering team built, and which part of that call was yours? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Constraints — Do you have any non-negotiables (pay floor, location or remote, start date) I should check this role against? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.