I'll read the reference files the skill requires before building the assessment.
**No, you aren't wasting your time on this role, but it's a stretch application and not a safe one. R1a (3+ years of PM-titled experience) is absent, and R1b and R2 are adjacent, not direct. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (product-management work done under another title), R2 (shipped API or platform products) · unclear: R4b (stakeholder work with sales, launch coordination), R5 (agile delivery) · absent: R1a (3+ years PM-titled experience)
- `important` — adjacent: R7 (discovery with integration partners) · unclear: R6 (define and track adoption metrics)

R1a — the titled years are the one thing wording cannot supply; R1b, R2, R7 — credible bridges, limits named in the map; R4b, R5, R6 — the resume is silent, and your answers could move them.

**Opportunity ledger.** The scope is concrete: one API surface, two squads, named responsibilities (RR4). It still has open items: the employer is unverified (RR1), the 3+ years requirement's strictness is unknown (RR2), pay is unstated (RR3), and reporting line and priority-setting authority are unstated (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) the recruiter confirms equivalent product work can stand in for titled years, asked before you invest in tailoring (R1a, RR2); (3) R1b is framed as adjacent, never as a PM title or roadmap ownership you haven't confirmed.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not cross-checked against any company source | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs; delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| First-90-day and first-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Compensation | Not stated in the JD you pasted | `[grounded]` JD silence |
| Scope read | One product surface, two squads and a bounded responsibility list read as a single-product PM post, not a bundle of roles | `[inferred]` from the responsibility list against the squad count |
| Market calibration | Not performed. The role-family sweep did not run, so there is no title, scope or pay band to set this against | `[grounded]` research accounting below |
| Unknowns | Salary; reporting line; new post or backfill; how strictly 3+ years is applied; who sets partner priorities, product or sales | `[inferred]` from JD silence |
| Contradictions | None between the JD and your background. The JD was not checked against the employer's careers page | `[grounded]` JD and your summary |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM-titled experience | must_have | absent | none | capability | You confirm you have never held a PM title. The JD calls this a must-have, but a length-of-experience requirement is graded on fit, not treated as a gate. Work near it is R1b. Wording cannot change the titled-year count | `[grounded]` your statement and the JD; `[generic]` that titled-year requirements are often applied literally at resume screening | Ask the recruiter early whether equivalent product work counts (RR2); claim no PM title |
| R1b | Product-management work done under another title | must_have | adjacent | medium | transferability | Your own sentences: scoping workshops, requirements documents, coordinating your engineers, client engineers and product managers, quarterly roadmap-input sessions. Limit: the resume shows you feeding product's roadmap, not owning it, and writing client-integration requirements, not product specs for a delivery squad. It says nothing on prioritization decisions or squad delivery | `[grounded]` resume prose, no inspectable artifact yet; the limit is `[grounded]` resume silence | Bridge case in G4; offer a work sample (W1) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ end-to-end integrations of your vendor's REST APIs and the playbook the team uses show deep implementation-side knowledge of an API product. Limit: nothing stated on designing, documenting, versioning or releasing an API. Integrating clients onto an API is not shipping one | `[grounded]` resume prose; the limit is `[grounded]` resume silence | Bridge case in G5 |
| R3 | Strong technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI-spec reading, plus integration architecture across 30+ integrations, is the same kind of work the JD names. Confirmed in your summary, with no artifact inspected | `[grounded]` resume prose | Offer: a sanitized slice of the playbook would raise to high |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and product managers on custom builds, with client-facing workshops and UAT. Sales is not in this row | `[grounded]` resume prose | none |
| R4b | Stakeholder management with sales; launch coordination with sales and support | must_have | unclear | low | discovery | The resume mentions neither sales nor support. Client go-lives are indirect context, not the same as coordinating a product launch with those teams | `[grounded]` resume silence | G3 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The resume gives no delivery method. Coordinating engineers on custom builds is indirect context | `[grounded]` resume silence; `[inferred]` that the builds may have run in sprints | G2 question |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent on metrics. An earlier conversation mentioned an internal request-triage tool that support agents adopted. That is a memory lead, unconfirmed, and no claim rests on it | `[grounded]` resume silence; memory lead | G1 question |
| R7 | Run discovery with integration partners | important | adjacent | medium | transferability | Quarterly roadmap-input sessions collecting client feedback for product, and scoping workshops, are discovery-type work with API integrators. Limit: the sessions fed a roadmap you did not own, and your clients may differ from Quartzline's partners | `[grounded]` resume prose; the limit is `[grounded]` resume silence | E1 repositioning; G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics (R6, important) | discovery | The resume shows no metrics work; a memory lead suggests an adopted internal tool | A confirmed, specific tool-with-adoption story would be your closest evidence of owning something others used | A support-team tool you built or specified; usage counts, ticket-handling time, or agent feedback you tracked; any dashboard you watched | A screenshot, a usage summary, a README, or a short write-up | `[grounded]` resume silence; `[inferred]` that it could move R6 from `unclear` |
| G2 | Agile delivery (R5, must_have) | discovery | The resume names no method or cadence | A must-have the resume leaves open, and the cheapest one to settle | Sprint reviews with a client or your own engineers; backlog or acceptance-criteria work; stand-ups on a custom build | A project plan, a sprint board export, or a UAT sign-off list | `[grounded]` resume silence; `[generic]` that PM roles of this kind expect it |
| G3 | Sales and support partnership (R4b, must_have) | discovery | No sales or support interaction is stated | Part of the stakeholder requirement is currently unevidenced | A launch you coordinated with account executives or support; enablement material you wrote; escalations you routed between support and engineering | A launch checklist, an enablement doc, or a handover note | `[grounded]` resume silence |
| G4 | PM-type ownership (R1b, R7) | transferability | Carries over: requirements, workshops, roadmap-input sessions, cross-team coordination. Limit: roadmap ownership, prioritization and squad delivery are not evidenced | This is the row the hiring decision most likely turns on, because it is the nearest evidence to the titled years in R1a | Choices about what a custom build included; trade-offs you argued; input you gave that visibly changed a product plan | A requirements document or roadmap-input summary (sanitized), or a short sample brief (W1) | `[grounded]` resume; `[generic]` that hiring screens look hardest at the nearest-to-title evidence |
| G5 | Shipped API product (R2, must_have) | transferability | Carries over: 30+ integrations and the playbook. Limit: no design, documentation, versioning or release role is stated | Without it the "shipped" requirement stays adjacent | API feedback you gave that engineering acted on; developer docs or a quick-start you wrote; a breaking-change migration you ran with clients | A doc page, a changelog entry, or a migration guide | `[grounded]` resume silence |
| G6 | PM-titled years (R1a, must_have) | capability | No titled PM years, confirmed by you | Wording cannot close it; the realistic paths are an employer that accepts equivalent work, or a title-bearing step first | An internal PM or product-owner stint, even part-time, that earns the title | A role change or a recruiter's confirmation of equivalence | `[grounded]` your statement; `[generic]` that these two paths are the usual closures |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a live hiring employer. It was not checked: the search was not permitted | `[generic]` pattern for companies of this size, not a claim about this one | Could you point me to this role on Quartzline's own careers site, and tell me who I would report to? | unresolved |
| RR2 | Strictness of the 3+ years PM must-have is unknown | unknown | — | "3+ years product management experience (must-have)" | The requirement may be applied literally at resume screening, or it may be a proxy that equivalent product work satisfies | `[generic]` how titled-year requirements are commonly applied, not a claim about this employer | Is 3+ years of PM-titled experience firm, or would you weigh equivalent product work done under another title, such as roadmap input and cross-team delivery? | unresolved |
| RR3 | Compensation not stated | unknown | — | JD gives no figure | The pay may sit outside your needs, or may simply not be in the text you pasted | `[inferred]` from the pasted JD's silence | What salary band is budgeted for this role? | unresolved |
| RR4 | Scope concrete and bounded | positive_signal | — | "Own the roadmap for our partner-facing API platform … drive delivery with two engineering squads" | Responsibilities, surface and delivery capacity are named, so the mandate is not obviously inflated | `[inferred]` from the responsibility list against the squad count | Which outcomes would define success in the first year? | noted |
| RR5 | Reporting line and priority-setting authority unstated | unknown | — | "coordinate launches with sales and support" | Partner priorities may be driven by sales requests, leaving a PM accountable without final say on the roadmap | `[inferred]` from the JD's silence on decision rights against "own the roadmap" | Who decides roadmap priorities when sales and partner requests conflict, and is this a new role or a backfill? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Reorder with wording unchanged: move "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Wrote the internal integration playbook the whole team uses" up beside "Led 30+ client integrations of our REST APIs end to end" | See R7, R2, R1b | `[grounded]` your own sentences, none reworded | resume_edits_pending_approval |
| E2 | Summary line: "Solutions engineer and implementation lead, 7 years, leading client integrations of REST APIs end to end: scoping workshops, requirements documents, integration architecture, UAT, go-live." Keeps your actual titles; no PM title appears | See R3, R4a | `[grounded]` each clause traces to a sentence you wrote | resume_edits_pending_approval |
| W1 | Optional work sample: a one-page product brief for an API improvement drawn from a recurring integration problem you saw, labeled as a sample and never as shipped work | Narrows the limit in R1b and R6 | `[inferred]` from R1b's limit | pending your approval |
| A1 | Send me the live posting link or Quartzline's careers page, or grant search access, to settle the employer question before tailoring effort | See RR1 | `[grounded]` register | pending your approval |
| A2 | Put RR2's question to the recruiter before investing in the loop | See R1a, RR2 | `[grounded]` register | pending your approval |
| Q1 | Ask RR3, RR4 and RR5's questions verbatim in interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Every row above, the resume wording and the strategy rows alike, is proposed and pending your approval. Nothing is final until you say so.

## Evidence status

Verified: none yet. Unverified lead: an internal request-triage tool that support agents adopted, recalled from an earlier conversation. It is unconfirmed, prompts G1 only, and is not used as evidence anywhere above.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform careers"; the call was refused (permission not granted) and returned nothing. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "platform API product manager career transition from solutions engineer without PM title requirements 2026"; the call was refused and returned nothing. It would have moved the market calibration row and RR2's grounding |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` if you'd like to carry it forward.

## Upgrade menu

- Search permission, or a link to the live posting or Quartzline's careers page → RR1 resolves, which lifts the `conditional_go` cap on employer grounds; market calibration and a salary band for RR3 become possible. After that, a deeper pass (up to 5 more searches and 2 more fetches) can run if you want it.
- Your actual resume file → E1 and E2 become line-by-line, and R3, R4a and R7 can be checked against the real wording.
- A sanitized slice of the integration playbook, a requirements document, or a roadmap-input summary → R3 and R1b can reach `high`.
- A usage summary or README for the triage tool, if it exists → R6 and the "shipped" bridge in R2 firm up.
- A sprint board export or project plan from a custom build → R5 settles.
- A launch checklist or enablement doc → R4b settles.
- The hiring manager's name → role reality's scope read, and which story the plan leads with.
- Your non-negotiables → hard-gate rows are added to the map and checked against the role.

**Questions**

G1 — An earlier conversation suggested you built an internal request-triage tool that support agents adopted. Is that right? If so, what did you own, who used it, and how did you know they adopted it?

G2 — On your integration projects, did you work in sprints or another agile cadence with engineering, and what did you do in it, such as backlog, acceptance criteria or stand-ups?

C1 — Which non-negotiables should I check this role against: pay floor, remote or on-site, work authorization, anything else?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.