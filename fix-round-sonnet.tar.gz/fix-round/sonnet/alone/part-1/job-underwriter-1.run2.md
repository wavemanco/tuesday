I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, apply. You read as a fit on R1, R2, R3, R4 and R8, which map `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R8 · unclear: R5 (Define and maintain the metrics layer)
- `important` — direct: none · adjacent: R6a (Partner with product managers, analysis into roadmap decisions) · unclear: R6b (Partner with clinicians), R7 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R5 — ownership of shared metric definitions isn't stated yet; R6b, R7 — no clinician or mentoring evidence yet; R9 — a credible bridge, its limit named.

**Opportunity ledger.** Mostly unknowns, no red flags. The employer and posting are unverified because my searches were refused (RR1). Pay and location are not stated (RR2). Whether you would manage or only mentor the two juniors is open (RR3), as is what success looks like (RR5). One entry runs the other way: the responsibilities are specific and checkable (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify live — RR1; (2) pay, location and remote terms clear your own constraints once you state them — RR2; (3) the healthcare gap is framed as adjacent, never as health-data experience — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, as the posting describes itself; not independently checked | `[grounded]` JD header |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B test design and analysis, self-serve Looker dashboards, analysis into roadmap decisions with product managers and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Requirements stated | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, strong written communication with non-technical stakeholders; healthcare data (HIPAA) "a plus" | `[grounded]` JD |
| Scope read | A senior individual-contributor post with a mentoring remit over a single product area | `[inferred]` from the mentoring clause and the single-app scope |
| First 90 days | Not stated. Plausibly inheriting and auditing existing metric definitions and dashboards before new tests | `[inferred]` from "define and maintain", which implies something already exists |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Compensation, location, remote policy, employment type | Not stated in the JD as pasted | `[grounded]` JD as pasted |
| Market calibration | Not established: the role-family search was refused, so no pay band or title norm is given | — |
| Unknowns | Pay; location or remote policy; reporting lines; manage versus mentor; first-year outcomes; current metrics layer and warehouse | — |
| Contradictions | None visible inside the JD; it was not compared with the company's careers page | `[grounded]` JD text |

## Evidence map

Your background was typed into the conversation, so it counts as self-report. That caps `medium` on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company; specific, nothing inspectable yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state SQL daily on Snowflake. "Expert" is the JD's word; your evidence shows sustained daily use, not a level, so expect it to be tested | `[grounded]` your background; `[generic]` that a live SQL exercise is a common screen for this title | Offer: a sanitized query or a data-model excerpt (for example from the consent-state model) would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You state you designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift, on about 2M subscribers | `[grounded]` your background | Offer: a sanitized readout of the pricing test would raise it to `high` |
| R4 | Looker or similar BI; self-serve dashboards in Looker | must_have | direct | medium | none | You state you built the Looker instance from scratch with 40+ governed dashboards. "Self-serve" use by others isn't stated, so don't claim adoption figures | `[grounded]` your background | Offer: a sanitized screenshot or model excerpt would raise it to `high` |
| R5 | Define and maintain the metrics layer | must_have | unclear | low | discovery | Governed dashboards and the consent-state model are nearby, but neither is described as a shared set of metric definitions others built on. No such practice is asserted | `[grounded]` what you stated and what it omits; `[generic]` that "metrics layer" usually means shared, governed metric definitions | G1 question below |
| R6a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | You present monthly to the VP Product, and the pricing test sits behind a retention lift. That your analysis changed a roadmap decision is not stated, so it is not asserted | `[grounded]` your background | Offer: a sanitized readout plus the decision it drove (G3) |
| R6b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background involves clinicians or other domain-expert partners | `[grounded]` your background silent | Offer: any example of working with domain specialists (G4) |
| R7 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring or managing anyone | `[grounded]` your background silent | G2 question below |
| R8 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You state you write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | Offer: a sanitized memo would raise it to `high` |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | Bridge: GDPR/CCPA consumer PII handling and the consent-state model you built. Limit: no healthcare or identifiable health data handled, so no HIPAA-specific practice is claimed | `[grounded]` your stated PII and consent work; the limit is the absence of healthcare in your background | Offer: a write-up of the consent-state model (G5) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Define and maintain the metrics layer (R5, must_have) | discovery | 40+ governed dashboards and a warehouse consent-state model; neither is described as shared metric definitions | A `must_have` at `unclear`, and the JD's first listed responsibility. Resolving it is the likeliest route from `conditional_go` toward `go` | Shared LookML measures reused across dashboards; one definition of retention or churn that finance and product both used; a metric dictionary or definition-change process; reconciling conflicting numbers between teams | A metric dictionary page, a sanitized LookML excerpt, a definition-change log | `[grounded]` your background's silence; `[inferred]` that resolving it could move the status |
| G2 | Mentoring two junior analysts (R7, important) | discovery | No mention of mentoring or managing | The JD names two juniors, so formal versus informal experience changes how to frame it | Onboarding a new analyst; reviewing a teammate's queries or test designs; coaching someone through a first experiment; running training for product managers; supervising an intern | An onboarding doc, a review checklist, a training deck | `[grounded]` background silent |
| G3 | Analysis into roadmap decisions with product managers (R6a, important) | discovery | Monthly VP Product presentations and a pricing test tied to a retention lift; the decision link isn't stated | The JD's wording is about decisions, not readouts | A test result that stopped, shipped or reshaped a feature; a memo that redirected a quarter's priorities | A sanitized readout alongside the decision it informed | `[grounded]` background; the decision link is not stated |
| G4 | Working with clinicians (R6b, important) | discovery | No domain-expert partner appears in your background | The JD names clinicians as partners | Working with nutrition, culinary, logistics or privacy specialists on a metric or test, if your company had them | A joint brief or a metric definition agreed with a specialist | `[grounded]` background silent |
| G5 | Healthcare data, HIPAA (R9, preferred) | transferability | Adjacent: GDPR/CCPA PII handling and the consent-state model. Limit: no health data, no HIPAA practice. Strengthener: a short write-up of the consent-state model | A preferred row, so a minor risk rather than a blocker | Access controls, retention rules or consent-driven filtering you built into the warehouse | A sanitized model diagram or consent-state documentation | `[grounded]` your stated work and its limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "digital-health scale-up, ~400 people, Series C" | The stated stage and size would normally leave a public footprint, but no search ran, so nothing here is checked. Severity is `low` because the check was not made, not failed | `[inferred]` from the JD's stated stage and size; `[generic]` pattern, not a claim about this company | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Pay, location and remote policy not stated | unknown | — | "Senior Product Analyst" (the JD as pasted carries no terms) | The terms may sit outside the posting or in an excerpt you didn't paste | `[grounded]` the JD as pasted | What is the salary range, and what are the location and remote expectations for this post? | unresolved |
| RR3 | Manage versus mentor unclear | unknown | — | "mentor two junior analysts" | The remit may be mentoring without line authority, or full management | `[inferred]` from the verb "mentor" against silence on reporting lines | Do the two junior analysts report to this role, or does someone else manage them? | unresolved |
| RR4 | Responsibilities are specific and checkable | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The scope is concrete enough to test in interviews | `[grounded]` JD lists them | What does the metrics layer look like today: which tool, and how many metrics are governed? | noted |
| RR5 | No success definition stated | unknown | — | "turn analysis into roadmap decisions" | The JD gives responsibilities but no outcomes, so success is undefined | `[grounded]` JD silent on outcomes | What would you want this role to have achieved by the end of its first year? | unresolved |

## Application plan

Proposed, not final: nothing below is applied or sent until you approve it. That covers the resume edits and the positioning advice alike.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: lead the CV with your experimentation program, the Looker build and the exec metrics memo, using your own figures as you stated them (30+ A/B tests a year, the pricing test behind an 11% retention lift, 40+ governed dashboards, about 2M subscribers) | See R3, R4, R8 | `[grounded]` your background | pending your approval |
| E2 | Positioning: name the GDPR/CCPA work and the consent-state model as adjacent to healthcare, and make no HIPAA or health-data claim | See R9 | `[grounded]` R9 row | pending your approval |
| E3 | Hold any wording on metrics-layer ownership and on mentoring until G1 and G2 are answered | See R5, R7 | `[grounded]` R5, R7 rows | pending your approval |
| W1 | A one-page sanitized experiment readout or metrics memo as a work sample | See R3, R8 | `[grounded]` R3, R8 rows | pending your approval |
| A1 | Confirm the posting is live on Harborlight's own careers page before investing in the application | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions of RR2, RR3 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search was sent ("Harborlight Health care navigation app careers Senior Product Analyst") and was refused. It would have moved RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | One search was sent ("senior product analyst digital health salary range Looker experimentation") and was refused. It would have moved role reality's market calibration and the pay calibration in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If useful, I can write this up as `tuesday-dossier.md` so a later turn picks up where this leaves off.

## Upgrade menu

- Permission to run the searches, or a link to the live posting on Harborlight's careers page → RR1 closes, and role reality's organization row and the market band get filled.
- Your non-negotiables (pay floor, location or remote, work authorization) → the hard-gates line gets real rows, and the status can move to `go` or `no_go`.
- An answer to G1 → R5 moves off `unclear`.
- An answer to G2 → R7 moves off `unclear`.
- A sanitized pricing-test readout, a LookML or dashboard screenshot, or a sanitized metrics memo → R3, R4 and R8 can move to `high`.
- The hiring manager's name → role reality's scope read, and which story the application leads with for that reader.

**Constraints** — What are your non-negotiables for this move: pay floor, location or remote, work authorization, and anything else you'd walk away over? The posting states none of these, so nothing can be checked against yours yet.

**G1** — Have you personally defined and maintained shared metric definitions that other dashboards or analysts built on, in LookML, dbt or a metrics doc? If so, which metrics, who used them, and what happened when a definition changed?

**G2** — Have you mentored or managed analysts, formally or informally, and what was your part in their work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.