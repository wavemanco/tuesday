I'll read the reference files the skill points to before building the assessment.
**Yes, apply, on the three conditions below. Status: `conditional_go`.**

I couldn't search the web: all three research calls were refused. Nothing below has been checked against Brindlemoor's own site, and every claim about the market or the employer is labelled accordingly.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based, fully remote)
- `must_have`: direct: R2, R3, R4a, R5, R6, R7 · unclear: R4b (Designing price tests, reading results independently)
- `important`: direct: R8a · unclear: R8b (Recommendations to product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance pricing)

R4b: a must-have row your background leaves open, and a question can probably close it; R10: a bridge from motor, with its limit named; R1: a gate to confirm, not a capability gap.

**Opportunity ledger.** The mandate is concrete (RR4). The employer couldn't be checked (RR1), the pay isn't in the posting (RR2), and the team shape, decision rights (RR3) and first-year outcomes (RR5) are unknown.

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) you confirm you are UK-based, see R1; (3) the pet-insurance gap is presented honestly as adjacent, never as pet experience, see R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; not verified externally | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; her public footprint was not researched | `[grounded]` your message |
| People management | The JD lists no line-management requirement or direct reports, so "never managed anyone" isn't a stated gap | `[grounded]` JD silence |
| Scope read | "Own" plus a single product suggests a one-product remit; whether it is a team or a sole analyst, and what decisions it holds, is unstated | `[inferred]` from "own" and the JD's silence on team and authority |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Market calibration | Not established: the role-family sweep did not run, so no title, scope or salary band is given | `[grounded]` Research tier line in Evidence status |
| Unknowns | Salary; team size; decision rights; first-year success measures | `[grounded]` JD silence |
| Contradictions | None between the JD and your account; JD against the company's careers page not checked | `[grounded]` pasted JD and your message only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You haven't stated where you are based. A UK motor insurer suggests UK-based but doesn't establish it | `[grounded]` JD; `[inferred]` from the UK employer | G3 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer is specific but self-reported, with no artifact yet. Years are not a gate, and you exceed the stated figure | `[grounded]` your background | none |
| R3 | Build and monitor rating models | must_have | direct | medium | none | You stated "built and maintained the GLM rating model for our young-driver book". Building is stated and scope is one book, so carry that limit. Monitoring is not claimed until you say what you monitored | `[grounded]` your background | State only the monitoring you actually did; a sanitized model document would raise this to `high` |
| R4a | Price-test work (running tests) | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team, which is the activity the JD names. Your specific part is not yet stated, so no ownership is claimed | `[grounded]` your background | none |
| R4b | Designing price tests and reading results independently | must_have | unclear | low | discovery | Nothing says whether you chose test cells, set the success measure, or wrote the readout, or ran tests someone else designed | `[grounded]` background silent on design | G1 question |
| R5 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. The depth the JD means by "strong" hasn't been probed | `[grounded]` your background | none |
| R6 | GLM experience | must_have | direct | medium | none | Same evidence as R3: a GLM you built and maintained, in one book | `[grounded]` your background | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8a | Recommendations for underwriting | important | direct | medium | none | Tests with underwriting and the quarterly review are the channel. Whether the recommendations were yours is not stated | `[grounded]` your background | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing in your background mentions a product team | `[grounded]` background silent | G2 question |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance pricing (inferred from the product in the mandate; the JD does not require it) | preferred | adjacent | medium | transferability | Motor GLM rating carries over as method. The limit: no exposure to the pet product's own rating factors or claims patterns. Pet rating factors usually differ from motor ones | `[grounded]` your stated gap; `[generic]` pet versus motor differences | Bridge case in the plan; the sample note W1 would narrow the limit |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R4b, must_have) | discovery | 14 tests run with underwriting; your part is not stated | A must-have, and "design" is in the JD's own wording; closing it could remove the only unclear must-have | Choosing which customers get which price; deciding test length with underwriting; agreeing the success measure; writing the readout with a recommendation | A sanitized test plan, a readout page, or a slide from the quarterly review | `[grounded]` background silent on design; `[inferred]` that closing it removes the unclear must-have |
| G2 | Recommendations for product (R8b, important) | discovery | The only audiences named are underwriting and its head | The JD names product as a second audience | A pricing recommendation that fed a product or cover change; working with a proposition or commercial team; presenting results to a product owner | A sanitized review slide or recommendation email | `[grounded]` background silent on product |
| G3 | UK-based remote working (R1, hard_gate) | hard_gate | UK employer suggests, but doesn't establish, where you work from | A gate: a no would end this at `no_go` | Not applicable, since this is a yes/no fact | Nothing to attach | `[grounded]` JD term against your silence |
| G4 | Pet-insurance pricing (R10, preferred) | transferability | Motor GLM and test work; no pet exposure | Likeliest objection a hiring manager would raise on this CV | Any non-motor line, add-on cover, or claims-cost trend analysis you have touched | A one-page sample note (proposed W1) | `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Severity is held at medium because no other warning signs are present | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated in the posting as pasted | unknown | — | (no figure in the JD) | The figure may be withheld, or may be missing from the text you copied | `[grounded]` JD silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Team shape and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be sole-analyst with recommendations only, or part of a team with rating sign-off | `[inferred]` from "own" against silence on team and authority | Is this a team of analysts or a sole pricing analyst, and which rating decisions does the role make versus recommend? | unresolved |
| RR4 | Concrete mandate with named deliverables | positive_signal | — | "build and monitor rating models, design and read price tests" | The work is defined and maps to named outputs | `[grounded]` JD | Who consumes the price-test readouts today? | noted |
| RR5 | First-year outcomes unstated on a senior "own" mandate | unknown | — | "Own pricing analytics" | Success measures may be undefined or may exist outside the posting | `[inferred]` from the JD's silence against the "own" scope | What would a successful first year look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify Brindlemoor and the live posting on its own careers page before spending effort | See RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Edit the CV opening to lead with three facts in your own words: "Built and maintained the GLM rating model for the young-driver book", "Ran 14 price tests last year with the underwriting team", "Present the quarterly pricing review to the head of underwriting". Keep "ran" as "ran" and use "designed" only if G1 confirms it | See R3, R4a, R6, R7; each clause traces to your sentences | `[grounded]` your background | `resume_edits_pending_approval` |
| E2 | Add one honest line on pet: "My pricing work has been motor, in a young-driver book; I haven't priced pet insurance." | See R10 | `[grounded]` your stated gap | pending your approval |
| W1 | Optional one-page note on how you would structure a pet rating model, labelled as a sketch, not experience | Narrows R10's limit | `[inferred]` from G4 | pending your approval |
| Q1 | Ask the RR1, RR2, RR3 and RR5 questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | If asked about managing people, say plainly that you haven't; the JD lists no such requirement | See the role reality People management row | `[grounded]` JD silence | pending your approval |

All language in this plan, the E1 and E2 lines and the P1 and W1 advice included, is proposed and is finalized only on your approval.

## Evidence status

Verified: none yet. Your background is self-reported, which caps most rows at `medium`. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech"; the call was refused. It would have moved the contradictions row and RR1 |
| 2. Role-family sweep | unavailable | Searched "Senior Pricing Analyst pet insurance UK remote salary"; the call was refused. It would have moved the market-calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing"; the call was refused. It would have moved the scope read and which of your stories to lead with |

I can write this up as a `tuesday-dossier.md` if you want a file to keep or reuse.

## Upgrade menu

- Search permission, or the careers-page link and the recruiter's email domain → RR1 closes, and `conditional_go` may become `go`.
- Salary range, or a stated floor → RR2 closes, and I can check pay against your floor.
- A sanitized model document, test readout, or quarterly review slide → R3, R4a, R6 and R7 move toward `high`, and G1 and G2 may close.
- Your CV itself, since I only have your summary → rows firm up and the E1 wording can be audited against it.
- Odile Varga's public talks or writing, if search is granted → which of your verified stories to lead with for her.

## Questions

G3 — Are you based in the UK and able to work from there on a fully remote basis?

G1 — On the 14 price tests, what was yours: choosing the test design, setting the success measure, analysing the results, or running tests someone else had designed?

G2 — Have you made a pricing recommendation that fed a product or cover change, or presented results to a product team? What was your part, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.