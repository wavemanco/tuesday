I'll read the reference files first.
**Decision snapshot**

**Yes, this is worth applying to, with conditions. R3, R4, R5, R6 and R7 (the whole `must_have` tier) land `direct` on what you told me, but R1 and R2 (the two gates) are unanswered and the employer is unverified (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or the Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts)

R8 — a tool gap with a real bridge; R9, R10 — duties the JD names, with no evidence from you yet; R1, R2 — nothing in hand to settle them.

**Opportunity ledger.** The posted pay range straddles the report's median (RR3), but the employer is unverified (RR1). Team shape and scope (RR2), equity terms (RR4) and on-call (RR5) are all unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or the Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 work for you; (2) the posting is confirmed live and the company as described (RR1); (3) the BigQuery bridge is framed honestly as adjacent (R8), never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not checked against the live site (see Evidence status) |
| Mandate | "Build and run the pipelines behind our tutoring platform's reporting": ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Must-haves | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Implied requirement | Working fluency in BigQuery: the requirements say "a cloud warehouse", but the mandate names BigQuery as the warehouse | `[inferred]` from the mandate's "dbt-modelled warehouse in BigQuery" against the requirements' "a cloud warehouse" |
| Terms | Remote (US) or Denver office; $148,000–$166,000 plus equity | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silent |
| Scope read | The listed duties run from ingestion through modelling to contracts. The posting names no team size, no reports and no hiring manager | `[inferred]` from the JD's duty list and its silence on team |
| Market calibration | For Senior Data Engineers at Series B–D companies, the report gives median $151,000 and IQR $139,000–$163,500. "Senior" typically means 5–8 years, and typical scope is one domain's pipelines with no direct reports. Your 6 years sit inside that span, the posted range straddles the median and runs past the upper quartile, and whether the scope exceeds one domain is unknown (RR2) | `[generic]` pattern from the Datawright report you supplied (n=2,310), not a claim about this employer; `[grounded]` JD figures |
| Unknowns | Hiring manager; team size; equity grant and vesting; on-call; whether BigQuery experience is required or learnable on the job | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the about text as pasted | `[grounded]` pasted material only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization are not in your message, so the gate is unsettled. Confidence is `none` because no statement of the constraint exists yet | `[grounded]` JD terms; intake silent | G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor is not in your message, so I can't say the range clears it. Confidence is `none` because no constraint has been stated | `[grounded]` JD figures; intake silent | G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. Confirmed and specific, with no inspectable artifact yet. Expect a probe on titles and scope | `[grounded]` your intake message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Daily use shows the work, but "strong" is the JD's word and not yet shown by an artifact | `[grounded]` your intake message | offer: a sanitized code sample or repo would raise to `high` |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models, and the requirement asks for a cloud warehouse, not BigQuery specifically. No artifact inspected yet | `[grounded]` your intake message | offer: dbt docs lineage graph or model list |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. Whether you wrote the DAGs or ran others' is not stated, so the row claims only the use | `[grounded]` your intake message | offer: a sanitized DAG |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Coverage and who owned it afterward are not stated | `[grounded]` your intake message | offer: a sanitized expectation suite |
| R8 | BigQuery, the warehouse the role runs on | important | adjacent | medium | transferability | Adjacent: the same dbt modelling work on Snowflake. Limit: you have never used BigQuery, so none of its platform-specific features, cost model or access setup has been exercised | `[grounded]` your intake message; `[inferred]` that the bridge is credible, from dbt on a cloud warehouse | G4 |
| R9 | Ingestion from the app and the CRM | important | unclear | low | discovery | Airflow orchestration implies pipelines, but your message does not say what sources you ingested or who built the loads. Low, not none, because there is a thread to pull | `[grounded]` intake silent on sources; `[inferred]` thread from the Airflow work | G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is quality testing, not shown to be a contract with consumers. Whether any schema or freshness agreements existed is unknown | `[grounded]` intake silent on consumer agreements | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location, authorization and pay floor (R1, R2; hard_gate) | hard_gate | Your message states none of the three | Both are gate terms. Until they are answered, `conditional_go` rests on assumptions | Not experience: a yes or no on each term | Your own statement is the strongest evidence a constraint can have | `[grounded]` intake silent |
| G2 | Ingestion from app and CRM (R9; important) | discovery | Airflow work is stated, but not which sources fed the warehouse or who built the loads | The JD lists ingestion first among its duties, and resolving this could lift R9 to `direct` | Loading an application database or event stream into the warehouse; syncing a SaaS system through its API or a connector; backfills and schema-change handling; owning the load DAGs | A sanitized DAG, an architecture diagram, a runbook | `[grounded]` intake silent; `[inferred]` that the JD gives this duty priority, from its order of listing |
| G3 | Data contracts (R10; important) | discovery | A Great Expectations suite is stated; nothing about agreements with analysts or other consumers | The JD names contracts as something analysts depend on, so this decides whether R10 is adjacent or unresolved | Agreeing column definitions or freshness expectations with the analysts who used your models; announcing breaking changes; failing a pipeline on a violated expectation others relied on | A sanitized expectation suite plus any consumer-facing doc or change notice | `[grounded]` intake silent; `[inferred]` that contracts means consumer-facing agreements, from the JD's "contracts our analysts depend on" |
| G4 | BigQuery (R8; important) | transferability | dbt on Snowflake, about 180 models; no BigQuery use | The JD's mandate names BigQuery, and "never used" is the likeliest first objection to your application | Not recoverable by recall. The bridge is the dbt and warehouse work; the limit is that no BigQuery-specific work has been done | Optional: a small dbt project run on BigQuery as a work sample (W1) | `[grounded]` never used BigQuery; `[generic]` that a stated tool in a mandate is usually probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Series C ($52M, February 2026)", "264 employees" | The pasted pages may be stale, or the posting may no longer be live. Taken at low rather than medium: the pasted text is specific and names a real-looking domain, and only the check was refused | `[generic]` pattern for any posting I could not verify, not a claim about this company | Is this role still open, and who would I report to? | unresolved |
| RR2 | Team shape and scope unstated | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | The duty list may exceed the one-domain scope the report calls typical for the title. Taken at low: nothing says a team is absent | `[inferred]` from the JD's duty list against the report's typical scope | How many data engineers are on the team, who owns ingestion today, and who do analysts and this role report to? | unresolved |
| RR3 | Pay posted, and in line with the supplied market band | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is disclosed and the range straddles the report's median ($151,000), reaching past its upper quartile ($163,500) | `[grounded]` JD figures against the provided report | Where in the range would this role be leveled, and what drives that? | noted |
| RR4 | Equity named without terms | unknown | — | "plus equity" | The grant size, vesting and strike are not in the posting, so its value cannot be weighed | `[grounded]` JD states no terms | What is the equity grant size and vesting schedule, and what is the current share count? | unresolved |
| RR5 | "Run" pipelines: on-call unstated | unknown | — | "Build and run the pipelines" | Operating pipelines may carry alerting duty, but the posting does not say | `[generic]` pattern for roles that own pipelines in production | Is there an on-call rotation, and how often are engineers paged? | unresolved |

## Application plan

All rows below are proposed and pending your approval. I have not seen your CV, so every line is traced to your own sentences in this message.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume lines, in your own scope: "Built our dbt project on Snowflake (about 180 models)"; "Airflow for orchestration"; "Set up our Great Expectations test suite". Don't relabel the test suite as "data contracts" unless G3 confirms it | R3, R5, R6, R7; the relabel would change the kind of work (R10) | `[grounded]` your intake sentences | `resume_edits_pending_approval` |
| E2 | Application note on BigQuery: "I built our dbt project on Snowflake (about 180 models); I haven't used BigQuery yet." | R8: names the limit up front and claims only what you stated | `[grounded]` your intake sentences | pending your approval |
| A1 | Ask your recruiter to confirm the posting is live and who the hiring manager is, before investing in an application | RR1; the posting names no hiring manager | `[grounded]` you have a recruiter and the posting names no manager | pending your approval |
| Q1 | Put the register's verification questions (RR1 to RR5) to the recruiter or interviewers verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | Optional: a small dbt project run on BigQuery, as a work sample. Do this only if G1 clears | R8's limit is the BigQuery gap itself | `[inferred]` from R8's limit | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Calls refused: a fetch of pellucidlearning.com/careers/senior-data-engineer and a search for "Pellucid Learning online tutoring K-12 Denver Series C $52M". Nothing returned, so the live posting and the about-page facts are unchecked. This would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | skipped | The pay report you pasted is in hand and fixes the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Closing

I can save all of this as `tuesday-dossier.md` if you want a copy to keep or to build on later.

**Upgrade menu**

- Your location, work authorization and pay floor → R1 and R2 resolve (G1).
- Answers to G2 and G3 → R9 and R10 move from `unclear` toward `direct` or `adjacent`.
- Your résumé, or sanitized artifacts (a dbt docs lineage graph, a DAG, a Great Expectations suite) → R4 to R7 rise toward `high`, and E1 can be checked against your actual CV.
- The hiring manager's name (the recruiter may have it) → the role-reality scope read and which story to lead with.
- Permission for web search and page fetch, or the recruiter's confirmation that the posting is live → RR1 resolves.

**Questions**

G1 — Are these two terms workable for you: working from the US (remote or Denver) without sponsorship, and a base in the $148,000–$166,000 range?

G2 — Which sources did you personally load into your warehouse (application database, events, SaaS APIs), and did you write those loads?

G3 — Did analysts or other teams rely on agreed schemas, definitions or freshness for your models, and did anything fail a pipeline when it was violated?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.