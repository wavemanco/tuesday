I'll read the reference files the skill points to before building the assessment.
**Not worth pursuing on these terms: R1 and R2, the two hard gates, fail. Status: `no_go`.**

Your instinct that something is off is right. Your background isn't the problem. The posting's terms rule you out, and they say so themselves.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin five days a week), R2 (Base pay $70–85k)
- `must_have` — direct: R4, R5 · unclear: R3 (8+ years growth leadership)
- `important` — unclear: R6 (SEO/content), R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Team of one)

R1, R2 — fail on terms no wording fixes; R4, R5 — the core channels fit on your account; R3, R6, R7, R8, R9 — left open by what you gave me.

**Opportunity ledger.** Two terms conflict outright with your constraints (RR1, RR2). The posting adds pay-versus-scope tension (RR3), seven functions in one seat with no stated budget (RR4), an out-of-hours norm (RR5) and undefined success (RR6). The employer is unverified (RR7). The CEO reporting line runs the other way (RR8).

- **Hard gates:** failed: R1 (On-site Austin office five days a week), R2 (Base $70–85k vs your $150k floor).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posting's own terms would have to differ. R1 would have to allow remote work from Portland, and R2 would have to reach a $150k base. The posting says "no exceptions" on R1 and gives no sign the base is negotiable.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header (the posting's claim, not verified; see RR7) |
| Mandate | Own all revenue growth: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting line | CEO, with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; equity amount unstated | `[grounded]` JD |
| First-90-days / first-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | Reads as several specialist roles folded into one seat, with a team of one to start | `[inferred]` from seven named functions plus "team of one" |
| Market calibration | Not run. Both searches were refused, so no market band is stated. The posted figure is set against your floor in R2 and RR2, and against the posting's own seniority in RR3 | `[grounded]` search refusal |
| Unknowns | Marketing budget, hiring plan, decision rights, equity size and vesting, how success is measured | `[grounded]` JD silence |
| Contradictions | A "Head of" title with board visibility sits beside a $70–85k base and a one-person bench | `[inferred]` from JD title and scope against stated pay |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin office 5 days a week, no exceptions (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own specific statement of the constraint. Fit fails because the JD rules out exceptions and you are remote-only | `[grounded]` JD quote and your intake message | Surface only; no workaround sought. Only a change of terms by the employer or by you resolves it |
| R2 | Base $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The top of the posted band is $65k below it, and the posting's equity is unquantified, so it cannot close a base-pay floor | `[grounded]` JD quote and your intake message | Surface only; same as R1 |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | You report 9 years in growth, as Growth lead then Head of Growth at two B2C subscription companies. How many of those years were in leadership roles isn't stated, so 8+ on leadership years isn't established. Intake prose, no inspectable artifact | `[grounded]` your intake message | Confirm start and end dates of the lead and head roles from your CV |
| R4 | Paid acquisition | must_have | direct | medium | none | You report owning paid, with a budget you controlled, while scaling one company from $8M to $40M ARR over three years. Confirmed and specific, but nothing inspectable yet, so expect a probe on ownership | `[grounded]` your intake message | A channel budget summary or P&L excerpt would raise this to high |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You report owning lifecycle and name Braze, SQL and GA4. Same limit as R4: confirmed, no artifact | `[grounded]` your intake message | A Braze program or lifecycle results export would raise this to high |
| R6 | SEO/content | important | unclear | none | discovery | Your account doesn't mention SEO or content. Silence isn't absence | `[grounded]` intake silence | See G2 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Not mentioned in your account | `[grounded]` intake silence | See G3 |
| R8 | Sales ops | important | unclear | none | discovery | Not mentioned in your account | `[grounded]` intake silence | See G3 |
| R9 | Works as a team of one across all functions | important | unclear | low | discovery | You built and managed teams of 3–7. That shows management, not solo execution across seven functions, so the evidence is indirect | `[grounded]` your intake message | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Posted terms vs your non-negotiables (R1, R2; hard_gate) | hard_gate | The posting's location and pay terms conflict with your stated constraints | Decides the status; experience cannot close a term | None applies | Only the employer's written change of terms, which I'm not suggesting you seek | `[grounded]` JD and your constraints |
| G2 | SEO/content (R6, important) | discovery | Nothing in your account | Likely moot given G1; it would only matter if the terms changed | Owning organic or content programs for a subscription funnel; working with an SEO agency or writers; owning a blog or landing-page testing program | A traffic report, a content calendar, an experiment log | `[grounded]` intake silence |
| G3 | Brand, PR, partnerships, sales ops (R7, R8; important) | discovery | Nothing in your account | Same as G2 | Affiliate or partner programs; launch PR; handing leads to sales or maintaining a CRM pipeline | A partner program summary, a launch brief | `[grounded]` intake silence |
| G4 | Solo execution (R9, important) | discovery | Evidence is team-building, not solo execution | Same as G2 | Early-stage stints before a team existed; running several channels yourself | A role history with dates | `[grounded]` your intake message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Five-day on-site against remote-only (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The posting closes the door itself, so the terms are incompatible with your constraint | `[grounded]` JD and your constraint | Is the five-day Austin requirement fixed for this role, and has Novaline hired anyone outside Austin? | confirmed |
| RR2 | Base pay against your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The top of the band is $65k below your floor, and equity is unquantified | `[grounded]` JD and your constraint | Is the base range fixed, and what is the equity grant in percent and vesting terms? | confirmed |
| RR3 | Seniority–compensation tension | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | The base may sit below what a mandate over all revenue growth, with board visibility, is priced at, with equity carrying the difference. The size of the gap isn't established because no market band was run | `[inferred]` from the JD's title, years and scope against its stated base | How was the base range set for a role that asks for 8+ years and owns all revenue growth? | unresolved |
| RR4 | Seven functions, one person, no stated resources | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | The seat may carry accountability without a stated budget, headcount plan or decision rights | `[inferred]` from the JD's scope against its silence on resources | What budget and hiring plan come with this role, and which decisions does it make without the CEO? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be a standing norm rather than an exception | `[inferred]` from the phrase "just who we are" against the absence of any limit | In the last quarter, how many evenings or weekends did the growth function work, and what triggered them? | unresolved |
| RR6 | No defined success metrics | risk_signal | medium | "success metrics will evolve as we learn" | A mandate over all revenue growth with no definition of success can be judged after the fact | `[inferred]` from the JD's silence on outcomes | What would a good first 90 days and first year look like, in numbers? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you show me this role on Novaline's own careers site, and who would I interview with? | unresolved |
| RR8 | CEO reporting line with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board." | Seniority and visibility look real in the structure, not just in the title | `[inferred]` from the stated reporting structure | How often does the growth lead present to the board? | noted |

## Application plan

Everything in this plan is proposed. Nothing, including the advice in the rows, is final until you approve it. The user decides; this is a recommendation.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't submit an application on the posted terms | see R1, R2, RR1, RR2 | `[grounded]` R1, R2 rows | pending your decision |
| P2 | If you proceed against `no_go`, ask the verification questions of RR1 through RR7 verbatim before investing further | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: the constraints behind R1 and R2, stated by you and specific. Unverified: the experience claims behind R3, R4, R5 and R9 are intake prose, not yet probed or backed by an artifact.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin Series A Head of Growth" was refused. It would have moved role reality's organization row and RR7 |
| 2. Role-family sweep | unavailable | The search "Head of Growth salary startup Series A base compensation 2026" was refused. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

I'm offering a saved copy of this assessment as `tuesday-dossier.md` if you want one.

**Upgrade menu**
- Search access, or a link to the live posting on Novaline's own careers page, would let me run the two blocked checks. That would settle RR7 and give RR3 a market band.
- Your CV, with role dates, would settle R3 and show whether R6 to R9 have evidence your summary left out.
- A channel budget summary, a P&L excerpt, a Braze results export or an experiment log would raise R4 and R5 to `high`.
- A hiring manager's name would let me read their public professional footprint for the scope read. The posting doesn't give one.

No questions this turn. Nothing I could ask would move R1 or R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.