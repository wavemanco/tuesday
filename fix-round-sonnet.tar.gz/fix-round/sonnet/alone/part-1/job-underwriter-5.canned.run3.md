I'll read the reference files the skill points to before building the assessment.
**Yes, apply. Status: `conditional_go`.** R3, R4, R5, R6 and R7 are all met on your account. The condition is that the two hard gates, R1 (location) and R2 (pay), are confirmed against your own constraints, which you haven't given me.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R9 (BigQuery) · unclear: R8 (Data contracts analysts depend on), R10 (Ingestion from app and CRM)

R3, R4, R5, R6, R7 — the posting's listed requirements, each met on your account; R9 — Snowflake-to-BigQuery is a bridge with a stated limit; R8, R10 — nothing you've told me yet speaks to data contracts or app and CRM ingestion.

**Opportunity ledger.** The checkable parts hold up: the employer and live posting are established (RR1) and the pay is at market (RR2). What the posting leaves out is the equity terms (RR3), the team and reporting line (RR4) and the success measures (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and US work authorization fit "Remote (US) or our Denver office" — R1; (2) $148,000–$166,000 clears your pay floor — R2; (3) BigQuery is presented as new to you, with the Snowflake bridge stated as adjacent — R9; (4) equity, team and success measures check out in interviews — RR3, RR4, RR5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` About page, matched by search result |
| Posting status | Live: "Accepting applications" | `[grounded]` careers page fetched |
| Mandate | Pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Listed requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silence |
| Scope read | Looks like one domain's pipelines, with no direct reports mentioned, which matches the report's typical senior scope | `[inferred]` from the JD's scope language against the report's "ownership of one domain's pipelines with no direct reports" |
| Market calibration | Datawright 2026, US, n=2,310, Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500; "Senior" typically 5–8 years. The posting's range starts $3,000 below that median, tops out $2,500 above the IQR's upper bound, and has a $157,000 midpoint. I'm reading "Salary" as base, which the posting doesn't confirm. Your 6 years sits inside the typical seniority span | `[generic]` provided pay report (recruiter-supplied, not searched), a pattern and not this employer's practice; `[grounded]` posting figures |
| Unknowns | Equity size and terms; reporting line and team; on-call; success measures; how long BigQuery ramp-up is expected to take | `[grounded]` JD silence on each |
| Contradictions | None between your pasted text and the live pages | `[grounded]` careers and About pages checked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you live or your work authorization. The JD names neither authorization nor sponsorship, so the role's terms don't settle it | `[grounded]` JD; no candidate constraint given | Closing question G4 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given, so I can't say whether the range meets it. Equity is unquantified | `[grounded]` JD; no candidate constraint given | Closing question G4 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, per your own account. Self-report, with no document yet | `[grounded]` your prose; `[generic]` the report's 5–8 years for the title | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" over six years, plus a roughly 180-model dbt project. "Strong" has no inspectable artifact yet, so expect a probe on depth | `[grounded]` your prose | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the company's dbt project on Snowflake, about 180 models. The requirement says "a cloud warehouse", not BigQuery specifically (that is R9) | `[grounded]` your prose | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. You didn't say you set it up, so I claim use only | `[grounded]` your prose | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is stated ownership | `[grounded]` your prose | none |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | The dbt models and GE suite are nearby work. You haven't said whether consumers had agreed schemas, freshness guarantees or change notices | `[grounded]` your prose silent on contracts; `[inferred]` from the JD's mandate line | See G2 |
| R9 | BigQuery warehouse | important | adjacent | medium | transferability | Snowflake dbt work is the closest equivalent; you've never used BigQuery. Limit: warehouse-specific cost and performance tuning is not exercised | `[grounded]` your prose; `[generic]` that tuning is warehouse-specific | See G1 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | The JD's mandate names it. Your background doesn't say what sources fed your warehouse | `[grounded]` JD; `[inferred]` that six years of pipeline work may include it, which is unconfirmed | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | A Snowflake dbt project; no BigQuery | The JD names BigQuery as the stack, and the bridge needs a stated limit | Any GCP or BigQuery exposure, even a connector or export; cost or performance tuning on Snowflake (clustering, warehouse sizing) | A small dbt project run against BigQuery would narrow the limit | `[grounded]` your own statement; `[generic]` that warehouse tuning differs by vendor |
| G2 | Data contracts (R8, important) | discovery | dbt models and GE tests exist; consumers' expectations unstated | It's a named deliverable in the mandate | Analysts relying on agreed columns; documented freshness expectations; a process for announcing breaking changes; dbt exposures or schema tests tied to a consumer | Sanitized dbt YAML or docs, a runbook, a change log | `[grounded]` your prose silent; `[inferred]` that an answer could move R8 |
| G3 | App and CRM ingestion (R10, important) | discovery | Sources not stated | Ingestion is the first item in the mandate | Pulling from a product database or event stream; CRM syncs; managed connectors versus custom Python extractors | Sanitized architecture diagram or DAG list | `[grounded]` your prose silent |
| G4 | Location, authorization and pay floor (R1 and R2, hard gates) | hard_gate | None of your constraints were given | A gate not settled is unresolved, whatever the fit elsewhere | — | — | `[grounded]` nothing given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting established | positive_signal | — | "Accepting applications." | The employer exists as described and the role is open | `[grounded]` careers and About pages retrieved | Is this a new position or a backfill, and who would I report to? | noted |
| RR2 | Pay disclosed and in line with the pay report | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range brackets the report's median ($151,000), so no seniority-pay mismatch appears | `[grounded]` posting and report figures; `[generic]` the Series B–D band is a pattern | Is the $148,000–$166,000 base salary, and what places a hire within the range? | noted |
| RR3 | Equity unquantified | unknown | — | "plus equity" | The grant could be material or nominal; the posting doesn't say | `[inferred]` from the posting's silence | What is the grant size, valuation basis and vesting schedule? | unresolved |
| RR4 | Team, reporting line and on-call unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the sole or one of few data engineers, and "run" may carry on-call duty | `[inferred]` from the scope language against silence on team, manager and on-call | Who is on the data team today, who would I report to, and what is the on-call arrangement for pipelines? | unresolved |
| RR5 | No success measures stated | unknown | — | (the posting states no first-year outcomes) | Priorities for the first year may be unset or simply unpublished | `[inferred]` from the posting's silence | What would success look like at six and twelve months? | unresolved |

## Application plan

All of this is proposed and pending your approval. That covers the table and the framing note beneath it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with your own stated facts: built the dbt project on Snowflake (about 180 models), set up the Great Expectations suite, Airflow for orchestration, Python and SQL daily, six years in data engineering | See R3, R4, R5, R6, R7 | `[grounded]` your prose | `resume_edits_pending_approval` |
| E2 | Say in the application or the first call that your warehouse experience is Snowflake and BigQuery is new to you, with the Snowflake dbt work as the adjacent bridge | See R9; a limit named up front is harder to probe | `[grounded]` your statement | pending your approval |
| W1 | Optional work sample: a small dbt project run on BigQuery | See G1; narrows the R9 limit and does not close it | `[grounded]` G1 | pending your approval |
| Q1 | Ask the RR1, RR3, RR4 and RR5 questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Do not claim data-contract or ingestion experience in E1 until G2 and G3 are answered.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Both checked your pasted copies. Moved: the contradictions row (none found), RR1, and the live-posting status. The employer-not-established cap does not apply |
| 2. Role-family sweep | skipped | Your pasted Datawright report already fixes the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

I can write this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- A statement of your location, work authorization and pay floor → R1 and R2 resolve, and the decision simplifies to `go` or `no_go`.
- A sanitized dbt YAML or docs excerpt, or a runbook → R8 rises from `low` and may move to `direct`.
- A sanitized architecture diagram or DAG list → R10 resolves.
- Any BigQuery or GCP exposure, or a small dbt project on BigQuery → R9's limit narrows.
- Your CV file → R3 to R7 can be checked against the document and the confidence bands re-graded.
- The hiring manager's name, once you have it → role reality's scope read and which story the plan leads with.
- A deeper research pass on Pellucid Learning (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

1. G4 — Where are you based, are you authorized to work in the US without sponsorship, and what is your pay floor (base)? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. G2 — When analysts or other teams used your dbt models, did you have any agreed schema, freshness expectation or change-notice process with them, and what did you own? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. G3 — What sources fed your warehouse (product database, event stream, CRM or other), and did you build the ingestion yourself or use managed connectors? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.