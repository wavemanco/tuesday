I'll read the reference files the skill requires before building the assessment.
**Not worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.**

Your match on paper is real, and so is your instinct that something is off. The posting asks for a senior mandate at a junior price, with terms you have already ruled out.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin, 5 days), R2 (Base pay $70–85k)
- `must_have` — direct: R3a, R4, R5, R6 · unclear: R3b (Growth leadership within those years)
- `important` — unclear: R7 (SEO and content), R8 (Brand, PR, partnerships, sales ops), R9 (Team of one, hands-on)

R1, R2 — location and pay fail whatever the fit; R4, R5, R6 — the core growth substance matches on paper; R3b, R7, R8, R9 — unproven rather than disproven.

**Opportunity ledger.** The posting folds seven functions into one person with no bench (RR4), sets a pay band that may not match its own seniority ask (RR3), gives no success definition (RR6) and expects after-hours work (RR5). The CEO reporting line and the stated profitable footing run the other way (RR9), and the employer is unverified (RR8).

- **Hard gates:** failed: R1 (On-site in Austin, 5 days), R2 (Base pay $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posting would have to allow remote work from Portland (R1) and carry a base of at least $150k (R2). It says "no exceptions" on the first and states a band on the second.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" — the employer's own description, not yet verified | `[grounded]` JD header |
| Mandate | Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Resources | "A team of one to start"; the posting states no budget, headcount plan or tooling | `[grounded]` JD for the team of one; `[inferred]` that resources are unstated from their absence in the text |
| Reporting | To the CEO, with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site Austin, 5 days, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity terms given | `[grounded]` JD |
| Success outcomes | No 90-day or first-year outcomes stated; "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | Seven functions under one title with no bench reads as a bundled role | `[inferred]` from the function list set against "team of one" |
| Market calibration | Not established. The role-family sweep did not run, so no market band is offered | `[grounded]` search refused, see Evidence status |
| Unknowns | Equity terms, budget, hiring plan, what the board line means in practice, whether the posting is live on Novaline's own site | `[grounded]` absent from the JD |
| Contradictions | None found inside the posting; it was not checked against a careers page | `[grounded]` JD text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, "no exceptions" (your constraint: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit. The fit fails because the posting rules out remote work in terms | `[grounded]` JD quote and your stated constraint | Surface only; only the employer changing terms or you revising your constraint resolves it |
| R2 | Base pay $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The top of the posted band is $65k below it. Equity is unquantified and your floor is a base figure | `[grounded]` JD quote and your stated constraint | Surface only; same resolution path as R1 |
| R3a | 8+ years in growth | must_have | direct | medium | none | You state 9 years in growth. It is self-report with no dated CV yet | `[grounded]` your intake message | Dated CV or LinkedIn history would raise to `high` |
| R3b | Growth leadership within those 8+ years | must_have | unclear | low | discovery | You state "Growth lead, then Head of Growth", but not when the first leadership role began, so leadership years cannot be counted. Resolved downward | `[grounded]` your titles; start dates absent | See G3 |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at two B2C subscription companies. No channel mix, spend or channel-level outcome is stated | `[grounded]` your intake message | Channel performance report would raise to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and name Braze. No program outcomes are stated | `[grounded]` your intake message | Lifecycle program summary would raise to `high` |
| R6 | Own revenue growth end to end, with budget | must_have | direct | medium | none | You state scaling one company from $8M to $40M ARR over three years with a budget you controlled. The budget size and your share of the growth are not stated. A company-level ARR figure is not channel attribution | `[grounded]` your claim and its limits; `[generic]` that attribution of company-level growth is a common probe | An ARR bridge or growth review deck would raise to `high` |
| R7 | SEO and content | important | unclear | none | discovery | Nothing you gave covers SEO or content, so no claim exists to grade. This is not a finding that none exists | `[grounded]` absence from your intake | See G4 |
| R8 | Brand, PR, partnerships, sales ops | important | unclear | none | discovery | Same position as R7 for four functions at the same strength of evidence, so one row | `[grounded]` absence from your intake | See G5 |
| R9 | Team of one, hands-on execution of everything | important | unclear | low | discovery | You managed teams of 3–7 and owned paid, lifecycle and experimentation, which suggests hands-on work. Solo execution across seven functions is not stated | `[inferred]` from your team sizes and ownership claims | See G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | On-site Austin, 5 days (R1, hard_gate) | hard_gate | Posting says "no exceptions"; you are remote-only | Failed gate; the status rests on it | Nothing closes it by wording | None; only a change of terms resolves it | `[grounded]` JD and your constraint |
| G2 | Base $70–85k (R2, hard_gate) | hard_gate | Posted ceiling is $65k below your floor | Failed gate; the status rests on it | Nothing closes it by wording | None; only a change of terms resolves it | `[grounded]` JD and your constraint |
| G3 | Leadership years (R3b, must_have) | discovery | Titles stated; first leadership start date not | The posting names an 8+ year requirement and it may be read literally | Date you became Growth lead; any earlier team-lead or owner-of-channel period | Dated CV, LinkedIn history | `[grounded]` missing dates; `[generic]` that a stated-years requirement is often screened literally |
| G4 | SEO and content (R7, important) | discovery | No SEO or content work stated | One of seven functions you would own | Owning an organic channel; commissioning content; GA4 or SQL work attributing organic revenue | Traffic report, content calendar | `[grounded]` absence from intake |
| G5 | Brand, PR, partnerships, sales ops (R8, important) | discovery | None stated | Four functions the posting bundles in | Partner or affiliate programs; handing leads to sales; press or launch work | Partner program brief, launch plan | `[grounded]` absence from intake |
| G6 | Solo hands-on execution (R9, important) | discovery | Team management is stated; solo execution is not | The role starts with no bench | Periods before your team existed; channels you ran personally | Account-level work samples, dashboards | `[inferred]` from your team-building history |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | For you, the role is unavailable as stated | `[grounded]` JD and your constraint | Is five-day on-site attendance in Austin a fixed term of this role? | unresolved |
| RR2 | Pay conflicts with your $150k floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | Posted base stays below your floor in every reading of the band | `[grounded]` JD figure against your floor | What is the full base range budgeted for this role? | unresolved |
| RR3 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required"; "dotted line to the board" | A Head-level mandate with board access may be priced below its seniority ask. Market band was not checked, so taken at the lower severity | `[inferred]` from the ask against the band; `[generic]` that bundled roles are often priced junior | How was the $70–85k band set for a role reporting to the CEO and owning seven functions? | unresolved |
| RR4 | Bundled specializations, no bench | risk_signal | medium | "Own all revenue growth end to end... a team of one to start" | Accountability for seven functions without resources or decision rights stated | `[inferred]` from the function list against the posting's silence on budget | Which functions do you expect me to run myself in the first six months, and what budget and headcount are committed? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine. You stated no hours constraint, so this is a risk and not a gate | `[inferred]` from the phrasing; `[generic]` that "when it matters" framing is often open-ended | In the last year, how often has the team worked evenings or weekends, and for what? | unresolved |
| RR6 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability without a fixed definition of success | `[inferred]` from the JD's wording against its mandate | What would success look like at 90 days and at 12 months? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | Percentage, vesting and strike are not given | `[grounded]` JD silence | What percentage, vesting schedule and strike price does the equity carry? | unresolved |
| RR8 | Employer not yet verified | risk_signal | low | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Stage, profitability and the live posting are unchecked. Low because nothing contradicts them, only that the check did not run | `[generic]` pattern for early-stage companies, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | CEO reporting line and stated profitability | positive_signal | — | "Report to the CEO"; "profitable since day one" | If true, the role has senior access and a commercially sound footing; both are the employer's own statements | `[grounded]` JD states both, unverified | What does the dotted line to the board involve day to day? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't submit this application | R1 and R2 fail | `[grounded]` R1, R2 | pending your approval |
| P2 | If you proceed against `no_go`, ask the register's verification questions verbatim | The register travels with a proceed decision | `[grounded]` register | pending your approval |
| P3 | Screen future postings on location and pay terms before reading responsibilities | Your two constraints are the ones this posting fails | `[grounded]` your constraints | pending your approval |

No resume edits are proposed: R4, R5 and R6 carry no presentation gap. Every row above is a proposal and nothing is final until you approve it.

## Evidence status

Verified: R1, R2 — the constraints are your own specific statements. The experience claims behind R3a, R3b, R4, R5, R6 and R9 are self-report from your message and stay unverified.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Series A Austin Head of Growth"; the call was refused. It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup 2026 base compensation range"; the call was refused. It would have moved the market calibration row and RR3's severity |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Search permission: runs targets 1 and 2, which check whether Novaline and the live posting match the description and give a market band for RR3. Neither can move the status while R1 and R2 stand.
- Your first leadership start date → R3b.
- Any SEO, content, brand, PR, partnership or sales-ops work, or periods running channels solo → R7, R8 and R9.
- An ARR bridge, channel performance report or growth review deck → R4, R5 and R6 to `high`.
- The CEO's name → role reality's scope read.
- A deeper research pass on Novaline (funding, leadership, public employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs once search is permitted.

I can also save this as `tuesday-dossier.md` if you'd like a copy to keep.

Questions: none this turn. R1 and R2 decide the status, and no answer from you would change either.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.