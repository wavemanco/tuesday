**No, it isn't worth pursuing. R1 and R2, both hard gates, fail · `no_go`.**

You do match on paper. What feels off is the terms: the role is on-site in Austin and pays below your floor.

I tried to run two research searches (the company's site, and a pay band for the role), but search permission wasn't granted, so I couldn't verify Novaline or calibrate the pay. Both gate failures come from the posting's own words and your stated constraints, so neither depends on that research.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin office five days a week), R2 (Base pay $70–85k)
- `must_have` — direct: R3a, R4, R5, R6 · unclear: R3b (8+ years growth leadership)
- `important` — unclear: R7 (SEO/content), R8 (Brand, PR, partnerships, sales ops), R9 (Team of one, no bench)

R1, R2 — the terms fail outright, whatever the fit elsewhere; R3a, R4, R5, R6 — your stated experience lines up, in your words and with no artifact seen yet; R3b — the leadership share of your nine years isn't dated; R7, R8, R9 — breadth beyond your stated paid, lifecycle and experimentation scope is unevidenced.

**Opportunity ledger.** The mandate is broad and under-resourced: a team of one across many functions (RR4), pay unquantified against the seniority asked for (RR3), always-on hours (RR5), success metrics left undefined (RR6), unquantified equity (RR7) and an employer I couldn't verify (RR8). The CEO reporting line runs the other way (RR9).

- **Hard gates:** failed: R1 (On-site Austin office five days a week), R2 (Base pay $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posting would need to allow remote work from Portland (R1), and the base would need to reach $150k or more (R2). The posting says "On-site in our Austin office 5 days a week — no exceptions", and wording on your side cannot change either term.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one". These are the posting's own claims and are unverified | `[grounded]` JD header; verification did not run |
| Mandate | Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | A team of one to start. Reports to the CEO, with a dotted line to the board | `[grounded]` JD |
| Location and hours | On-site in Austin five days a week, no exceptions. "Evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figure | `[grounded]` JD |
| Success measures | "Success metrics will evolve as we learn". No first-90-days or first-year outcomes are stated | `[grounded]` JD |
| Market calibration | Not established. The role-family sweep did not run, so I state no band. The posted figure is set against your $150k floor in RR2 and RR3 | `[grounded]` JD figure and your stated floor |
| Unknowns | Equity size, budget, decision rights, who the role inherits from, and what "evolve" means for the metrics | `[inferred]` from the JD's silence on each |
| Contradictions | The careers-page check did not run, so JD-versus-site consistency is untested | `[grounded]` research status |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin five days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own constraint: remote-only, based in Portland, not relocating. The fit fails because the posting rules remote work out | `[grounded]` JD quote and your statement | None; only the employer changing terms could resolve it |
| R2 | Base pay of $70–85k, against your floor of $150k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The posted top of range is $65k below it | `[grounded]` JD figure and your statement | None; only the employer changing terms could resolve it |
| R3a | 8+ years in growth | must_have | direct | medium | none | You state 9 years in growth. This is your own account with no document, so `medium` | `[grounded]` your intake statement | Offer: dated CV or LinkedIn history would raise it to high |
| R3b | Leadership years within those 8+ | must_have | unclear | low | discovery | You state growth lead, then Head of Growth, at two companies, but not the dates of each role. A literal screen may count only titled leadership years | `[grounded]` your statement omits dates; `[generic]` that postings of this kind often screen years literally | See gap queue G1 |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at both B2C subscription companies. No inspectable artifact yet | `[grounded]` your intake statement | Offer: a channel report or budget summary would raise it to high |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze, GA4 and SQL. No artifact yet | `[grounded]` your intake statement | Offer: a sanitized lifecycle map or Braze flow summary would raise it to high |
| R6 | Revenue growth ownership at scale, with a controlled budget | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. The claim covers paid, lifecycle and experimentation, not the posting's wider end-to-end scope, which R7 and R8 carry | `[grounded]` your intake statement | Offer: an ARR bridge or board-deck excerpt would raise it to high |
| R7 | SEO/content | important | unclear | none | discovery | Nothing in your background as stated mentions SEO or content | `[grounded]` your statement is silent | See gap queue G2 |
| R8 | Brand, PR, partnerships, sales ops | important | unclear | none | discovery | Nothing in your background as stated mentions any of these four | `[grounded]` your statement is silent | See gap queue G3 |
| R9 | Operating with no bench | important | unclear | low | discovery | You built and managed teams of 3–7. Solo operation across these functions is not evidenced | `[grounded]` your statement; `[inferred]` that team-building is adjacent, not the same | See gap queue G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Dated leadership years (R3b, must_have) | discovery | Two companies and two titles, with no start and end dates | A literal "8+ years leadership" screen would read this row | The date you first led a growth team or owned a channel P&L, and the date of each title change | A dated CV or LinkedIn history | `[grounded]` dates absent from your statement; `[generic]` that years requirements are screened literally |
| G2 | SEO/content (R7, important) | discovery | No mention in your stated background | The posting folds it into one title | Owning organic landing pages, content calendars or SEO tooling alongside paid, even part-time | A content roadmap or organic-traffic report | `[grounded]` silence in your statement |
| G3 | Brand, PR, partnerships, sales ops (R8, important) | discovery | No mention in your stated background | Four more functions are folded into the one role | Running affiliate or co-marketing deals, press moments, or sales-CRM and pipeline reporting | A partner deal list or a pipeline dashboard | `[grounded]` silence in your statement |
| G4 | Solo operation (R9, important) | discovery | Team-builder, not yet shown as a solo operator | The posting says "team of one to start" | Any stretch you ran growth without a team, such as an early-stage period or an interim gap | A short description of a solo stretch | `[grounded]` your statement; `[inferred]` adjacency from team-building |

These rows carry no question in the closing block, because R1 and R2 fix the decision while they stand.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts with your remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The role is incompatible with your living in Portland | `[grounded]` JD and your constraint | Is there any scenario in which this role is performed remotely? | confirmed |
| RR2 | Base pay below your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The cash offer sits $65k or more below your floor at the top of range | `[grounded]` JD figure and your floor | What is the maximum base budgeted for this role? | confirmed |
| RR3 | Seniority–compensation mismatch | risk_signal | medium | "8+ years growth leadership required" against "$70–85k base" | The mandate and years requested may not match the pay offered. Severity is held at medium because no market band could be established | `[inferred]` from the JD's years and scope against its stated figure; band not established | How was the base range set for this level of experience? | unresolved |
| RR4 | Responsibility without resources | risk_signal | medium | "Own all revenue growth end to end"; "a team of one to start" | A bundle of specializations is accountable to one person, with no budget or headcount stated | `[inferred]` from scope breadth against the JD's silence on budget | What budget and headcount are committed for the first year? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Overtime may be a standing expectation, not an exception | `[generic]` pattern for postings with this phrasing, not a claim about this employer | How often have evenings and weekends been required in the last quarter? | unresolved |
| RR6 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for all revenue growth without a stated target | `[inferred]` from the JD's scope against its silence on targets | What does success look like at 6 and 12 months, and who sets it? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The equity may be too small, or too illiquid, to offset the pay gap | `[inferred]` from the JD's silence on any figure | What percentage, strike price and vesting terms apply? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR9 | Reporting line to the CEO, with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | Seniority and visibility look real, though the "profitable since day one" claim is unverified | `[grounded]` JD | Who would the CEO say owns growth decisions today? | noted |

## Application plan

Every row is a proposal pending your approval, and nothing here becomes final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't invest application effort on the current terms | see R1, R2 | `[grounded]` JD terms and your constraints | pending your approval |
| A2 | If you apply anyway, ask RR1, RR2 and RR8 first, verbatim, before any interview time | The register's questions become essential when you proceed against a `no_go` | `[grounded]` register | pending your approval |
| A3 | Filter future searches for remote-eligible growth leadership with a posted base of $150k or more | Your two constraints are the filter. A role that clears both lets R3a, R4, R5 and R6 lead | `[grounded]` your constraints and the map's rows | pending your approval |

No CV edits or outreach text are proposed here.

## Evidence status

Verified: the candidate-side claims of R1 and R2, which are your own stated constraints. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin Series A" was refused for permission. It would have confirmed the employer and the live posting, moving role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | The search "Head of Growth salary Series A startup base compensation 2026" was refused for permission. It would have given the market calibration a band and RR3 a basis |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

I can save this as `tuesday-dossier.md` if you want to keep it. Just say so.

Upgrade menu:
- **Search permission, or a link to the posting on Novaline's own careers page.** This would settle RR8 and the organization row.
- **The same permission for a role-family pay sweep.** This would give RR3 a market band to sit against.
- **A dated CV or LinkedIn history.** This resolves R3b and raises R3a.
- **A channel report, an ARR bridge or a sanitized Braze flow summary.** These lift R4, R5 and R6 from `medium` to `high`.
- **Anything on SEO/content, brand, PR, partnerships or sales ops, or a solo stretch.** These would move R7, R8 and R9, though they matter only if the terms change.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.