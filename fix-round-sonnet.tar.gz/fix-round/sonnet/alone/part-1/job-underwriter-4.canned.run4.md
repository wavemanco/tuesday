I'll read the skill's reference files before building the assessment.
Research is finished, so I'm writing up the assessment now.

## Decision snapshot

**Yes, apply, but confirm the working pattern first. The JD you pasted says fully remote (UK), and Brindlemoor's own careers page says Leeds office four days a week (R1, RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R8 · adjacent: R7 (Recommendations for underwriting and product) · unclear: R5b (Monitor rating models)
- `important` — adjacent: R9 (Pet-insurance pricing familiarity)
- `preferred` — direct: R10

R1 — the term the JD and the careers page state differently; R5b — monitoring is not yet shown by what you told me; R7 — the product-side half of the recommendations requirement; R9 — a bridge from motor, limit named.

**Opportunity ledger.** The posting is live and names its reporting line (RR4). The working pattern conflicts between sources (RR1), pay is unstated (RR2), and the company's footprint beyond its own pages is thin (RR3). Decision rights over rate changes are not stated (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed as one you can accept: R1, RR1; (2) the pay range is checked against your floor: RR2; (3) the pet-insurance bridge is framed honestly as adjacent, never as pet-pricing experience: R9.

You have no line-management experience, and the JD does not ask for any (see the Role reality table).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described in your JD as an insurtech selling pet insurance. The careers page confirms a live posting for this title and the pet-insurance product. The page text fetched does not describe the company's stage or size. | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week". The two sources contradict each other. | `[grounded]` both texts |
| People management | The JD lists no direct reports and no line-management requirement | `[grounded]` JD silence |
| Scope read | A senior individual-contributor post that owns one product's pricing analytics, not a team lead role | `[inferred]` from "Own pricing analytics for our pet-insurance product" and the absence of any reports |
| First-year outcomes | Not stated. The early work reads as taking over the rating model's monitoring and the price-test pipeline. | `[inferred]` from "build and monitor" and "design and read price tests" |
| Market calibration | Median base £58,400, interquartile range £52,100–£64,900 for senior pricing analysts at UK insurers and insurtechs (Pricewell 2026, n=612). The survey is not specific to pet insurance, remote work or Leeds. It is what to expect, never Brindlemoor's offer (RR2). | `[generic]` role-family sweep: one search, one survey page fetched; `[grounded]` JD silence on pay |
| Hiring manager | Odile Varga, Director of Pricing at Brindlemoor. She was previously head of pricing analytics at Calloway Re for six years. She spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. | `[grounded]` search-result profile snippet, page not fetched |
| Unknowns | Pay; whether the role is remote or Leeds-based; who approves rate changes; pricing team size; who carries the underwriting risk for the product | `[grounded]` JD and careers page silence |
| Contradictions | Working pattern, as above | `[grounded]` JD against careers page |

## Evidence map

Your background was typed into the conversation, so it carries the same standing as a CV. That caps every claim at `medium` until you answer a probe or share an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated a location or working-pattern constraint, so there is nothing to grade at `high`. Fit is unclear because the JD says fully remote and the careers page says Leeds four days a week. | `[grounded]` JD quote; careers page fetched | Gate question G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics at a UK motor insurer, stated by you. `medium` because the claim is unprobed and has no artifact behind it. | `[grounded]` intake message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You said "daily". "Strong" has not been probed and there is no artifact. | `[grounded]` intake message | offer: a sanitized query or notebook would raise this to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your insurer's young-driver book. | `[grounded]` intake message | offer: sanitized model documentation would raise this to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM young-driver model as R4. | `[grounded]` intake message | as R4 |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", which may include monitoring but does not say so. Ambiguity resolves downward. | `[grounded]` intake wording; `[inferred]` that maintenance may include monitoring | G2 question |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" does not say who designed them or who read the results, so the fit is for the tests and the gap is the design ownership. | `[grounded]` intake message | G3 question |
| R7 | Turn results into recommendations for underwriting and product | must_have | adjacent | medium | discovery | You present the quarterly pricing review to the head of underwriting and ran tests with the underwriting team. The product side and the word "recommendations" are not evidenced. | `[grounded]` intake message | G3 question |
| R8 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. | `[grounded]` intake message | offer: a sanitized review deck would raise this to `high` |
| R9 | Pet-insurance pricing familiarity | important | adjacent | medium | transferability | The JD does not list this. It is derived from the product being priced. Your motor GLM work is the bridge. The limit is your own statement that you have never worked on pet insurance. Pet rating factors usually differ from young-driver motor's. | `[inferred]` requirement from the JD's product wording; `[grounded]` your statement; `[generic]` on rating factors | G4 bridge case |
| R10 | Insurance experience, a plus | preferred | direct | medium | none | Five years at a UK motor insurer. | `[grounded]` intake message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD says fully remote and the careers page says Leeds four days a week. Nothing from you says which you need. | A term, not experience. Wording cannot solve it, and only the employer's real terms or your constraint settle it. | Not applicable, since this is a term | The recruiter's written confirmation of the working pattern | `[grounded]` both texts; `[inferred]` that the gate may resolve either way |
| G2 | Monitoring rating models (R5b, must_have) | discovery | You maintained the GLM model. Nothing says what you tracked or acted on after launch. | A must-have at `unclear`. Resolving it firms up the lead story for the hiring manager's area. | Tracking actual against expected; segment or drift checks; deciding when to refit; a dashboard others used | A sanitized monitoring pack, dashboard screenshot or refit note | `[grounded]` intake wording; `[generic]` that these are typical monitoring activities |
| G3 | Test design ownership and product-facing recommendations (R6, R7, must_have) | discovery | You ran 14 tests with underwriting and present the quarterly review. Test design ownership and any product-side audience are not stated. | R6 is `direct`, with its design half unconfirmed, and R7 is `adjacent`. The answer decides how much of "design and read" you can claim. | Choosing what to test and sizing it; writing the readout; a result that changed something product acted on | A test readout or a quarterly review deck, sanitized | `[grounded]` intake wording |
| G4 | Pet-insurance pricing (R9, important) | transferability | Motor young-driver GLM work, with no pet exposure by your own account. | A named limit reads better than a hidden one. | Carries over: GLM method, test discipline, and presenting to underwriting. The limit is that none of it touched pet-specific factors. | A short sanitized note on how you would adapt your approach, if you choose to write one | `[grounded]` your statement; `[inferred]` bridge from the GLM work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One text may be out of date, or the real term may be Leeds-based. It is rated `medium` pending your constraint, and it is higher if you need remote. | `[inferred]` from the two texts | Is this role fully remote, or Leeds-based four days a week, and has that changed? | unresolved |
| RR2 | Pay unstated | unknown | — | JD gives no figure; the careers page text fetched gives none | The figure may sit anywhere against the survey band, or the company may not publish pay | `[inferred]` from the silence against the `[generic]` Pricewell band | What salary range is budgeted for this post? | unresolved |
| RR3 | Thin footprint beyond the company's own pages | unknown | — | JD: "Brindlemoor (insurtech)" | A search for the company returned no results, and the careers page confirms the live role. Small companies often have thin footprints. | `[grounded]` search result and careers page; `[generic]` pattern for small firms, not a claim about this one | How large is the pricing team, and who carries the underwriting risk for the pet product? | unresolved |
| RR4 | Reporting line named | positive_signal | — | "reports to the Director of Pricing" | The role has a named senior owner whose public work is in the same field | `[grounded]` careers page; hiring-manager profile snippet | How does the price-test process work today, and who else works on pet pricing? | noted |
| RR5 | Decision rights over rate changes unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role recommends, and who approves rate changes is not stated | `[inferred]` from the JD's wording against its silence on authority | Who approves rate changes, and how often do pricing's recommendations go live unchanged? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with Brindlemoor before investing in the application | R1, RR1 | `[grounded]` the two texts | pending your approval |
| P1 | Open the application with three facts exactly as you stated them: built and maintained the GLM rating model for the young-driver book; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting. Do not say "designed" tests or "monitored" the model until G2 and G3 are answered. | R4, R5a, R6, R8 | `[grounded]` your intake message | pending your approval |
| P2 | State plainly that your rating work is in motor, not pet. The bridge is the GLM method, and the limit is that you have not worked on pet-specific pricing. | R9 | `[grounded]` your statement | pending your approval |
| P3 | Do not raise line management, since the JD does not ask for it. If it is asked, say plainly that you have not managed anyone. | JD silence; your statement | `[grounded]` JD and your intake message | pending your approval |
| P4 | If G2 confirms real monitoring work, lead with it. Odile Varga's published talk is about monitoring rating models in small books. | R5b | `[grounded]` profile snippet; `[inferred]` that this makes R5b the row to firm up first | pending your approval |
| Q1 | Ask the verification questions from RR1 to RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

I have not seen your CV, so I'm proposing no bullet-level edits. P1 to P4 are positioning advice only, and each is marked pending your approval above.

## Evidence status

Verified: none yet. Every claim above comes from your intake message and is unprobed. Prior-context leads: none.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved: the live-posting and contradictions rows in role reality, R1, RR1 and RR3. |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary". Fetched "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: the market calibration row and RR2. |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Only the snippet was read, and no page was fetched. Moved: the hiring-manager row in role reality and P4. |

I can write a `tuesday-dossier.md` of this assessment whenever you want it.

## Upgrade menu

- Your working-pattern constraint and pay floor: R1 resolves to `direct` or `hard_gate_fail`, and RR2 gets compared to your floor.
- Your CV: bullet-level proposals for R2 to R8, each pending your approval.
- A sanitized monitoring pack, test readout or quarterly review deck: raises R5b, R6 and R8 toward `high`.
- Brindlemoor's answer on remote versus Leeds: closes RR1 and R1.
- A deeper research pass on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

G1 — The JD you pasted says fully remote (UK), but Brindlemoor's own careers page says Leeds office four days a week. Is remote a firm requirement for you, or could you work from Leeds four days a week?

G2 — After the young-driver GLM model went live, did you do any ongoing monitoring of it, and if so, what did you track and what did you do with it?

G3 — Across the 14 price tests, who chose what to test and how to read the result, and did any result you presented lead to a change that someone beyond underwriting acted on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.