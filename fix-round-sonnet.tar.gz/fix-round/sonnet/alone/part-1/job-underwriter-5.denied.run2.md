I'll read the reference files the skill requires before building the assessment.
**Yes, it's worth applying — R3, R4, R5, R6, R7 and R8 each land `direct` on your background. Status: `conditional_go`.**

I could not independently check the employer or the live posting. Both of my check calls were refused, so the conditions below cover that.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (a dbt-modelled warehouse in BigQuery) · unclear: R10 (ingestion from our app and CRM), R11 (the data contracts our analysts depend on)

R1, R2 — your location and pay floor weren't given; R9 — adjacent, Snowflake rather than BigQuery; R10, R11 — your background doesn't address them yet.

**Opportunity ledger.** The stated range straddles the quoted market median rather than sitting below it (RR4). The manager, the team and the on-call load, and the equity terms are unstated (RR1, RR2, RR3). The employer and live posting have not been independently checked (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you are US-based or willing to be in Denver, and that the base pay clears your floor — R1, R2; (2) the posting is confirmed live on Pellucid's own careers page — RR5; (3) BigQuery is presented as new to you, never as a skill you hold — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not checked against the live site |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Stated requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Market calibration | Datawright 2026, US, n=2,310, Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500. The posted range's low end is under the median, its midpoint ($157,000) is above it, and its top ($166,000) is above the IQR's upper bound. The report puts "Senior" typically at 5–8 years, so your 6 sits inside that range | `[grounded]` the recruiter's report as you pasted it; the report itself not independently checked |
| Scope read | The posting names ingestion, warehouse and contracts together, which may be broader than the report's typical ownership of one domain's pipelines, or may simply be one domain (reporting). No direct reports are mentioned, consistent with the report's typical scope | `[inferred]` from the JD's three named areas against the report's scope description |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Hiring manager and reporting line; team size; on-call expectations; equity terms; whether the posting is still open | `[grounded]` JD silence |
| Contradictions | None between the JD and the about text you pasted | `[grounded]` the two pasted texts only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or where you'd work, so the gate is not established either way | `[grounded]` JD terms; your constraints not given | G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No floor was stated, so the posted range can't be checked against one. Against the market, see RR4 | `[grounded]` JD figure; your floor not given | G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. Specific, but self-reported with no inspectable artifact | `[grounded]` your message | CV or LinkedIn history would raise to high |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. The claim is specific but unprobed, so expect a technical screen to test it | `[grounded]` your message; `[generic]` that screens for this title usually test both | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Specific and your own, but no artifact inspected | `[grounded]` your message | a sanitized project structure or docs page would raise to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the requirement as written is met. The BigQuery question is carried separately as R9 | `[grounded]` your message and the JD wording "a cloud warehouse" | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. How much of it you built versus used isn't stated, so claim only what you said | `[grounded]` your message | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Specific and your own, but nothing inspectable yet | `[grounded]` your message | a sanitized suite layout would raise to high |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake with dbt carries over: SQL, modelling and dbt practice. The limit is that you've never used BigQuery, so its cost model, partitioning and permissions are untested by your history | `[grounded]` your message; `[generic]` that the two warehouses differ on those points | G4 |
| R10 | Ingestion from our app and CRM | important | unclear | low | discovery | Your message doesn't describe the sources you ingested or how | `[grounded]` your message's silence | G2 |
| R11 | The data contracts our analysts depend on | important | unclear | low | discovery | The Great Expectations suite is related work, but you haven't described agreements with data producers or consumers, so I can't claim the match | `[grounded]` your message's silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2; hard_gate) | hard_gate | The posting allows Remote (US) or Denver and states a range; your location and floor are not given | Gates; if either fails, no strength elsewhere rescues the application | Not applicable; these are terms you meet or don't | Your own statement | `[grounded]` JD terms; your constraints absent |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Your pipelines' sources are not described | The posting names it as the first responsibility; a concrete answer could turn R10 to `direct` | Loading product or event data into a warehouse; pulling a CRM or billing or payroll system's data via API, export or a loader tool; writing Python loaders you owned | A sanitized pipeline diagram or DAG screenshot, a README | `[grounded]` your message's silence; `[generic]` that ingestion is routinely probed in screens for this role family |
| G3 | Data contracts (R11, important) | discovery | The test suite is described, agreements with producers or consumers are not | The JD names analysts as dependents of the contracts, so this is a stated responsibility | Agreed schemas or column definitions with an upstream team; freshness or volume expectations for analysts' tables; dbt tests or Great Expectations checks that analysts relied on and that were agreed with them | A schema doc, an agreed-SLA note, a dbt YAML excerpt (sanitized) | `[grounded]` your message's silence; `[inferred]` from the JD's wording that the term may mean agreements, not only tests |
| G4 | BigQuery (R9, important) | transferability | Strong Snowflake and dbt history; no BigQuery | The only tool in the stack's named warehouse that you haven't used | A hands-on exercise: rebuild a small dbt project against a free BigQuery account | A small public or sanitized repo | `[inferred]` bridge from your Snowflake and dbt work; `[generic]` that the warehouses differ on cost model and partitioning |

G4's bridge, stated whole: your Snowflake and dbt work carries over; BigQuery's own behaviour hasn't been exercised by your history; a small project on BigQuery would narrow that limit. There is no question on G4 because the facts are given.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and reporting line unknown | unknown | — | You note the posting names no hiring manager | The reporting line and whether a data team exists can't be told from the posting | `[grounded]` posting silence | Who would this role report to, and who else is on the data team? | unresolved |
| RR2 | Scope breadth and operations load unknown | unknown | — | "Build and run the pipelines … ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | One engineer may own ingestion through contracts, and "run" may imply on-call; the report's typical scope is one domain's pipelines. Reporting may also be a single domain | `[inferred]` from the JD's scope against the report's scope description | How many engineers own these pipelines today, and is there an on-call rotation? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | The equity's value can't be estimated from the posting | `[grounded]` posting silence | What is the equity grant for this level: instrument, size, strike or latest valuation, and vesting? | unresolved |
| RR4 | Pay against the market (seniority-compensation check) | positive_signal | — | "$148,000–$166,000 plus equity" | The range straddles the quoted median of $151,000 and its midpoint of $157,000 is above it, so there is no seniority-compensation mismatch. Equity is extra | `[grounded]` JD figure against the recruiter's pasted report, not independently checked | Where in the range would an offer land for six years' experience? | noted |
| RR5 | Employer and posting not independently checked | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The pasted text comes from the company's own pages, so this is a check not yet run, not a suspicion; the posting may have been filled or changed since you copied it. Severity kept low for that reason | `[generic]` pattern: copied postings can go stale; not a claim about this one | Is this role still open, and who runs the interview process? | unresolved |

## Application plan

`resume_edits_pending_approval` — nothing here is final until you approve it, and that covers both the rows and the advice in them.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Built our dbt project on Snowflake (about 180 models)" | R5; traced word for word to your sentence, with "built" kept because you didn't say "maintained" or "owned" | `[grounded]` your message | pending your approval |
| E2 | Resume line: "Set up our Great Expectations test suite" | R8; traced to your sentence | `[grounded]` your message | pending your approval |
| E3 | Positioning advice: keep BigQuery out of your skills list. If it comes up, say "my warehouse work has been on Snowflake; I haven't used BigQuery" | R9; the adjacency stays named as adjacent | `[grounded]` your message | pending your approval |
| A1 | Ask your recruiter for the hiring manager's name, team size and the equity terms before you apply | RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Open the role on Pellucid's own careers page and confirm it's live | RR5 | `[grounded]` register | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is prose I've treated as CV-equivalent, so every claim above is unprobed.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A fetch of pellucidlearning.com/careers/senior-data-engineer and a search for Pellucid Learning's funding were both refused. It would have confirmed the posting is live and the company is as described, feeding role reality's organization and contradictions rows and RR5 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration and the pay check (role reality's calibration row, RR4) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Your CV, or a LinkedIn history → I check R3, R4, R5, R7 and R8 against your own words and build E1 and E2 from them.
- A sanitized dbt project structure, DAG screenshot or Great Expectations suite layout → R5, R7 and R8 move from `medium` toward `high`.
- Answers to G2 and G3 → R10 and R11 move from `unclear`.
- Your location and pay floor → R1 and R2 resolve.
- The hiring manager's name → role reality's scope read and which story to lead with.
- Search and fetch access → target 1 runs, which could close RR5.
- A deeper pass on Pellucid (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you'd like, I can save this as `tuesday-dossier.md` so you can carry it into later steps.

G1 — Are you US-based or willing to be in Denver, and does $148,000 base clear your pay floor?
G2 — Which source systems did you ingest into the warehouse, how did the data arrive, and which parts of that did you build yourself?
G3 — Did you agree schemas, freshness or definitions with the teams that produced or consumed your tables, and what happened when one changed?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.