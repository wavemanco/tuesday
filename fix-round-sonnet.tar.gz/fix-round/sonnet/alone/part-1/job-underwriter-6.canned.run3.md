I've read the posting and most of the skill's rules. Next I'm reading its evidence vocabulary, then running the company, salary and hiring-manager research before I write the assessment.
**Yes, it's worth applying, provided you go in honest about R7b (billing data), which is a real gap, and R6 (owning a forecast), which is a bridge you have to frame carefully. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3a, R4, R5a · adjacent: R6 (Owning a forecast) · unclear: R3b (At a B2B software company), R5b (Spreadsheet modelling), R7a (Working with finance on revenue data) · absent: R7b (Billing data)
- `important` — direct: R8

R6 (`medium`) — a credible bridge through your monthly pipeline review, its limit being that finance owned the forecast; R7b — no evidence yet, and the JD's billing-data ownership leans on it; R1, R2 — unconfirmed until you give your terms.

**Opportunity ledger.** The employer is established and the posting states its salary (RR3). Open items are who owns the forecast (RR1), whether the posting is live on Quillfield's own site (RR2), what success looks like (RR4), and the reporting line and team (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay range both work for you — R1, R2; (2) you present forecast experience as adjacent, never as ownership — R6; (3) you name billing data as new and answer the revenue-data question honestly — R7a, R7b; (4) the posting verifies on Quillfield's own careers page and the forecast decision rights are clarified — RR2, RR1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025. | `[grounded]` Quillfield "About Quillfield" page, fetched |
| Role | Revenue Operations Lead, Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Responsibilities | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Compensation | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield. The profile snippet lists four years as sales operations manager at Corvane Payments. Consistent with what the recruiter told you. | `[grounded]` search-result snippet for "Tamsin Achebe — Head of Revenue Operations, Quillfield"; the profile page itself was not fetched |
| Scope read | A hands-on operator role: owns the data and the reporting, with the forecast shared with the CFO. It likely sits beside or under a Head of RevOps. | `[inferred]` from the title "Lead" against Achebe's title "Head", and from the verb "run … with the CFO" |
| First-year outcomes | Not stated | `[grounded]` posting is silent |
| Market calibration | The posted range sits inside the pay guide's interquartile range (£57,800–£70,400) and just below its median (£64,200). The sweep returned pay only, so title and scope norms are not established. | `[grounded]` posting figures; `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide (revenue operations lead, UK B2B software, n=438), a pattern and not Quillfield's offer |
| Unknowns | Reporting line and team size; forecast decision rights; option terms; 90-day and 12-month success measures | `[inferred]` from the posting's silence |
| Contradictions | None found between the posting and Quillfield's About page. The listing itself was not found on a Quillfield careers page. | `[grounded]` About page fetched; careers search returned no listing |

## Evidence map

Your background was given as prose, so it is treated as CV-equivalent: leads, capped at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid: two days a week in the office | hard_gate | unclear | none | hard_gate | A location and schedule term. You gave no location or limit on office days, so the gate is not established. Confidence grades your statement of the constraint, and none was made. | `[grounded]` posting; no constraints given | Closing question on R1, R2 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | A pay term. No floor was given, so it is not established. The range sits inside the survey band (`[generic]`), which says nothing about your floor. | `[grounded]` posting; `[generic]` survey band | Closing question on R1, R2 |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team. A length-of-experience requirement is graded on fit and is not a gate. Self-reported; no CV read. | `[grounded]` your account | Share the CV so dates can be checked |
| R3b | …at a B2B software company | must_have | unclear | medium | discovery | Your employer is a B2B payments company. Whether it is a software business is not stated. The claim itself is specific and confirmed. | `[grounded]` your account | See G5 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; the posting accepts either system. | `[grounded]` your account | The certification record would raise this to `high` |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly, by your account. How strong is not probed. | `[grounded]` your account | A sanitized query sample would raise this to `high` |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily, but the kind of modelling is not described: forecast, scenario, commission or capacity. | `[grounded]` your account; modelling not stated | See G4 |
| R6 | Experience owning a forecast (the posting also has the role run the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director. Finance owned the forecast and you have never owned it. Bridge: pipeline-review work. Limit: no forecast ownership. | `[grounded]` your statements of both; `[inferred]` bridge from the pipeline review | See G1 |
| R7a | Experience working with finance on revenue data | must_have | unclear | low | discovery | You built renewal dashboards, and finance owned the forecast. What you did with finance on revenue figures is not stated. | `[grounded]` your account; silence on the rest | See G2 |
| R7b | Experience working with finance on billing data (the role also owns billing data) | must_have | absent | none | capability | You say you have never worked on billing data. No direct or adjacent evidence is in hand. | `[grounded]` your statement | See G3 |
| R8 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your team's pipeline and renewal dashboards. Whether finance used them is not stated. | `[grounded]` your account | A sanitized dashboard screenshot would raise this to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | A monthly pipeline review with your sales director. Finance built the forecast. | The posting has this role run the quarterly forecast with the CFO. An honest bridge with its limit stated is the strongest position available. | Supplying the coverage or stage-conversion inputs finance used; challenging deal commits in the review; preparing a forecast-versus-actual comparison; maintaining forecast-category fields in Salesforce | A sanitized pipeline-review pack or a forecast-accuracy view | `[grounded]` your statements; `[inferred]` bridge from the pipeline review |
| G2 | Working with finance on revenue data (R7a, must_have) | discovery | Renewal dashboards exist; your dealings with finance over the numbers are not described. | Resolving it may move R7a toward `adjacent` and soften R7b's weight. | Reconciling renewal or ARR figures with finance; agreeing metric definitions (ARR, churn, renewal date); dashboards finance relied on; bookings or commission data | A metric-definitions document or a dashboard screenshot | `[grounded]` your account; `[inferred]` that this could soften R7b |
| G3 | Billing data (R7b, must_have) | capability | You have no billing-data experience and nothing adjacent has surfaced. | The posting names billing data as something the role owns, and Quillfield's product is invoicing. | None to offer unless G2 turns up something | None | `[grounded]` your statement and the posting |
| G4 | Spreadsheet modelling (R5b, must_have) | discovery | Excel daily; modelling type unknown. | A direct requirement that your description doesn't yet cover. | Pipeline or renewal scenario models; capacity or quota models; commission calculators | A sanitized workbook | `[grounded]` your account |
| G5 | B2B software employer (R3b, must_have) | discovery | A B2B payments company; its product type is not established. | The posting names a B2B software company explicitly. | A platform or software product your employer sells; SaaS-style recurring revenue | A product page describing the offering | `[grounded]` your account |

G3 is a plain statement: no credible direct or adjacent evidence exists. The closure path is to carry it openly as a stated gap (A3 below). The alternative is a scoped learning step on how invoicing data reconciles to CRM, once you decide how much weight to give it.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast authority split between this role, the CFO and the Head of RevOps | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may share forecast decisions with the Head of RevOps or the CFO | `[inferred]` from the posting's wording against Achebe's title | Which parts of the quarterly forecast does this role own, and which stay with the Head of RevOps or the CFO? | unresolved |
| RR2 | Posting not seen on Quillfield's own careers page | unknown | — | Listing hosted at jobs.tallyboard.example | The role may be live and simply not indexed, or the listing may be stale | `[grounded]` About page fetched with no listing; careers search returned none | Is this role open on your own careers site, and since when? | unresolved |
| RR3 | Salary stated, inside the pay band | positive_signal | — | "£61,500–£67,000 plus share options" | The range looks realistic for the title | `[grounded]` posting; `[generic]` survey band | Does the range flex with experience, and where would my profile sit in it? | noted |
| RR4 | No success measures stated | unknown | — | Posting lists responsibilities with no 90-day or first-year outcomes | The mandate may be broad with no defined outcomes | `[inferred]` from the posting's silence | What would success look like at 90 days and at twelve months? | unresolved |
| RR5 | Reporting line and team size not stated | unknown | — | "Revenue Operations Lead" | The role may report to the Head of RevOps with no direct reports | `[inferred]` from the title pair | Who does this role report to, and does it manage anyone? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your two terms first: Bristol with two office days, and your pay floor against the range | See R1, R2 | `[grounded]` posting terms | pending your approval |
| A2 | Ask the recruiter RR2 and RR5 before investing in the loop | See RR2, RR5 | `[grounded]` register | pending your approval |
| A3 | Lead with RevOps ownership for the UK team, Salesforce admin certification, the dashboard rebuild and the monthly pipeline review. Say plainly that finance owned the forecast and that billing data is new. Your payments background overlaps with the sales-operations-at-a-payments-company history on the hiring manager's public profile. | See R3a, R4, R6, R8, R7b | `[grounded]` your statements; `[grounded]` profile snippet | pending your approval |
| A4 | Once you share a CV, I'll propose edits that surface the certification and dashboards as outcome lines, with no invented figures | See R4, R8 | `[grounded]` your account | pending your approval |
| A5 | Use RR1 and RR4 verbatim as questions in your first interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Two limits are in your own words and will not be claimed on your behalf: you have not owned the company forecast, and you have never worked on billing data. `[grounded]` your statements.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers Revenue Operations Lead Bristol"; fetched "About Quillfield" (quillfield.co.uk/about). Confirmed the organization row. Found no careers listing, which became RR2. |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software UK", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR3. No title or scope norms came back. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. Moved the hiring-manager row, the scope read, RR1, RR5 and A3. |

## Dossier offer

I can write this up as `tuesday-dossier.md` to keep or carry forward; say the word.

## Upgrade menu

- Your CV (only your prose summary was read) → R3a dates can be checked, and the presentation edits in A4 become possible.
- Your terms on location, office days and pay floor → R1 and R2 settle, and the hard-gates line stops reading "constraints not given".
- Your Salesforce certification record → R4 to `high`.
- A sanitized dashboard screenshot → R8 to `high`.
- A sample query or model → R5a and R5b strengthen.
- An answer on revenue data and finance → R7a and G2 resolve.
- A product description of your current employer → R3b resolves.
- The recruiter's answers on RR1, RR2, RR4 and RR5 → the register closes and the conditions for go resolve.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

R1, R2 — Is Bristol with two office days a week workable for you, and is there a salary below which this wouldn't be worth it?

G2 (R7a) — Have you worked with finance on revenue figures, such as reconciling renewal or ARR numbers or agreeing how a metric is defined? What did you own, and what happened?

G1 (R6) — In the monthly pipeline review, did your numbers or judgement feed the forecast finance built? What did you own: coverage, stage conversion, deal commits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.