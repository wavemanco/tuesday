**Is this worth pursuing? No. R1 and R2, both hard gates, fail on the posting's own words. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin 5 days a week), R2 (Base $70–85k)
- `must_have` — direct: R3, R4, R5, R6
- `important` — unclear: R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops), R11 (Team of one)

R1, R2 — failed gates that fit elsewhere cannot offset; R3, R4, R5, R6 — the match on paper you felt; R7, R8, R9, R10, R11 — silent in your background, not shown absent.

**Opportunity ledger.** Your sense that something is off is borne out by the posting itself. A six-function mandate for a team of one (RR3), no definition of success (RR5), and always-on expectations (RR4) sit beside pay far under your floor (RR1) and a fixed on-site rule (RR2). The employer is also unverified (RR6). One entry runs the other way: the role reports to the CEO with board access (RR7).

- **Hard gates:** failed: R1 (On-site Austin 5 days a week), R2 (Base $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the employer would have to offer a base of at least $150k and a Portland-based remote arrangement. Both are terms they state as fixed or leave unstated, and only they can change them. The other route is you revising your own non-negotiables, which is your call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, described as an e-commerce enablement startup, Series A, profitable since day one. Not verified here (see Evidence status) | `[grounded]` JD header, as claimed by the posting |
| Mandate | Head of Growth owning revenue growth across paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Location | "On-site in our Austin office 5 days a week — no exceptions" | `[grounded]` JD |
| Schedule | "Evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; equity amount and terms not stated | `[grounded]` JD |
| Success outcomes | No first-90-day or first-year outcomes stated; "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | A leadership title ("Head", 8+ years) on a hands-on generalist seat with no reports | `[inferred]` from the title and years against "team of one" |
| Market calibration | Not established: the role-family sweep was refused, so no band is given and nothing here is a market figure | `[grounded]` search refused, see Evidence status |
| Unknowns | Equity size, budget, headcount plan, who owns each function today, how targets get set | — |
| Contradictions | "Head of Growth" and "8+ years growth leadership" sit beside "players who don't need a bench" | `[inferred]` from the JD's own language |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin office, 5 days a week, "no exceptions" (your hard constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint. The fit fails because the JD rules out any remote work and you will not relocate | `[grounded]` your statement and JD quote | Surface only; the employer changing terms is the only resolution |
| R2 | Base $70–85k (your hard constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The posting's top figure is $65k under it. Equity is not base, and your floor is stated as base | `[grounded]` your statement and JD figures | Surface only; no wording closes a pay gap |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years, as growth lead, then Head of Growth. Prose self-report, so `medium` | `[grounded]` your stated background | none |
| R4 | Own revenue growth end to end | must_have | direct | medium | none | Scaled one company from $8M to $40M ARR over three years with a budget you controlled. Confirmed and specific, but no inspectable artifact yet, so expect a probe | `[grounded]` your stated background | offer: a sanitized ARR-by-channel view would raise it to `high` |
| R5 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at two B2C subscription companies. Confirmed, no artifact yet | `[grounded]` your stated background | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Confirmed, no artifact yet | `[grounded]` your stated background | none |
| R7 | SEO/content | important | unclear | low | discovery | Your background lists paid, lifecycle, experimentation, SQL and GA4, and says nothing of SEO or content. It may exist and be unlisted | `[grounded]` silence in what you gave me | see G1 |
| R8 | Brand and PR | important | unclear | low | discovery | Nothing stated | `[grounded]` silence in what you gave me | see G2 |
| R9 | Partnerships | important | unclear | low | discovery | Nothing stated | `[grounded]` silence in what you gave me | see G2 |
| R10 | Sales ops | important | unclear | low | discovery | Nothing stated | `[grounded]` silence in what you gave me | see G2 |
| R11 | Operating as a team of one | important | unclear | low | discovery | You managed teams of 3–7. Nothing shows you executing every channel yourself, and the JD implies it | `[inferred]` from "team of one" against your team sizes | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, important) | discovery | Nothing on SEO or content in your background | It is one of the posting's listed functions, but the decision rests on R1 and R2 | A content program you commissioned or directed; organic traffic you tracked in GA4 | A traffic report or content calendar | `[grounded]` silence in your input; `[inferred]` that it cannot move the decision |
| G2 | Brand, PR, partnerships, sales ops (R8, R9, R10, important) | discovery | Nothing stated | The posting folds four disciplines into this seat | A press launch; a co-marketing or affiliate deal; a CRM or pipeline clean-up with sales | A deal summary or a press link | `[grounded]` silence in your input |
| G3 | Hands-on solo execution (R11, important) | discovery | Team leadership is stated, hands-on solo execution is not | The seat has no bench | Periods before you had a team, or startups where you ran several channels alone | A channel plan from that period | `[inferred]` from your team sizes against the JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay far below your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The base is about half your floor, and a six-function mandate at 8+ years is likely priced above it at market | `[grounded]` figures against your stated floor; `[generic]` market pattern, no sweep run | Is the base range for this seat fixed, and what is the equity grant? | unresolved |
| RR2 | On-site rule against remote-only (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The employer says the rule is fixed | `[grounded]` JD wording against your stated constraint | Is the five-day on-site requirement fixed for this role? | unresolved |
| RR3 | Bundled specializations on a team of one | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops … a team of one to start" | Several full roles are folded into one seat with no stated budget or headcount | `[inferred]` from the function list against the team size | What budget and headcount are committed for the first year, and who owns each function today? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be a standing expectation, not an exception | `[inferred]` from the JD's wording | In the last quarter, how many evenings or weekends did the team actually work? | unresolved |
| RR5 | No success definition on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may be set after the fact | `[inferred]` from the JD's silence on outcomes | What would a good first-90-days result look like, in numbers? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Reporting line to the CEO and board | positive_signal | — | "Report to the CEO with a dotted line to the board" | Senior access and some real authority | `[grounded]` JD | How often does this role present to the board, and who sets growth targets? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't spend application effort on the current terms | see R1, R2 | `[grounded]` the map's two failed gates | pending your approval |
| P2 | No CV edits proposed: the blockers are terms, not presentation, so repositioning cannot help | see R1, R2 | `[grounded]` the map's gap types | pending your approval |
| P3 | If you proceed anyway, put the verification questions of RR1 to RR6 to the employer verbatim before any interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A Head of Growth"; the call was refused. It would have moved role reality's organization and contradictions rows and RR6 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A base compensation 2026"; the call was refused. It would have moved the market calibration row and the market clause of RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A link to the live posting, Novaline's own careers page, or the recruiter's email domain → RR6 and role reality's organization row can close.
- Permission for the company check and the salary sweep → RR6 closes or stays open, and RR1 gets a market band.
- Your CV, plus an inspectable artifact such as an ARR-by-channel view or a channel P&L → R3 to R6 can rise, and R4 can reach `high`.
- Any SEO, brand, PR, partnership, sales ops or solo-execution history → R7 to R11 and G1 to G3 get evidence.
- The hiring manager's name → role reality's scope read and the plan's positioning.

I can also save this as `tuesday-dossier.md` if you want a record of the reasoning; say the word.

No questions this turn: no answer to G1, G2 or G3 can move a decision that R1 and R2 fix.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.