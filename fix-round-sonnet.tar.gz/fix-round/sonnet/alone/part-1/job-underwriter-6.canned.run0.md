I'll fetch the posting and read the skill's reference files together.
# Job Underwriting — Revenue Operations Lead, Quillfield

## Decision snapshot

**Yes, go for it, with two real stretches: R7 (forecast ownership, `adjacent`) and R8 (billing data, `absent`). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid two days in office), R2 (Salary £61,500–£67,000 plus share options)
- `must_have`: direct: R3, R4, R5, R9 · adjacent: R7 (Experience owning a forecast) · unclear: R6 (Spreadsheet modelling), R11 (Working with finance on revenue data) · absent: R8 (Billing data)
- `important`: unclear: R10 (B2B software company)

R7: the monthly pipeline review is a bridge, but finance owned the forecast; R8: billing data is untouched on your own account; R6, R11: unproven rather than missing; R1, R2: your location and pay floor are not yet checked.

**Opportunity ledger.** The posting is sound on what it states: pay is stated and sits inside the market range (RR5), and the hiring manager matches the recruiter's attribution (RR6). Forecast authority and success measures (RR2), the reporting line (RR3) and the option terms (RR4) are left open, and the posting is not yet confirmed on Quillfield's own careers page (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid two days in office), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay band both work for you — R1, R2; (2) Quillfield confirms who owns the forecast number and that it will hire someone new to billing data — RR2, R8; (3) R7 is presented as adjacent and R8 as a gap to learn, never as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about), consistent with the posting |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe) |
| First-90-days and first-year outcomes | Not stated in the posting | `[grounded]` JD silence |
| Scope read | CRM, billing data, reporting and a forecast sit in one post, and the JD names no direct reports | `[inferred]` from the JD's responsibility list and its silence on team |
| Market calibration | UK revenue operations leads at B2B software firms: median base £64,200, interquartile range £57,800–£70,400 (n=438). The posting's midpoint is £64,250. This is a market pattern, not Quillfield's offer, and the guide's regional split is not shown | `[generic]` "Ledgerline 2026 UK Revenue Operations Pay Guide"; `[grounded]` JD for the range |
| Unknowns | Careers-page listing, forecast ownership, reporting line and team, option terms, success measures | `[grounded]` JD silence on each |
| Contradictions | None found between the posting and the About page | `[grounded]` About page result; the careers page did not load (RR1) |

## Evidence map

Your background is typed self-report, so nothing is above `medium`. No CV or artifact has been inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | The posting states the term. You have not said where you live or whether two Bristol days work, so there is no constraint statement to grade | `[grounded]` JD; your constraints not given | Closing question R1, R2 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor has been given. The range sits inside the pay guide's interquartile range, but whether it clears your floor is unknown | `[grounded]` JD; `[generic]` pay guide band | Closing question R1, R2 |
| R3 | 4+ years in revenue operations, sales operations or similar analytics | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team. Self-reported with no artifact inspected. A length-of-experience term is graded on fit, not as a gate | `[grounded]` your background | Share your CV to confirm titles and dates |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The credential itself has not been inspected, so `medium` | `[grounded]` your background | A Trailhead or credential link would raise this to `high` |
| R5 | Strong SQL | must_have | direct | medium | none | SQL weekly is real use. "Strong" is not evidenced beyond that, and a technical exercise is a normal probe for it | `[grounded]` your background; `[generic]` role-family practice of testing SQL | None |
| R6 | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily establishes use, not modelling. What you built in it is unstated | `[grounded]` your background, silent on models | Gap queue G4; queued behind higher-impact questions |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | You ran the monthly pipeline review with the sales director and rebuilt the pipeline dashboards, but have never owned the company forecast; finance did. Limit: accountability for the number and CFO-level forecasting are unexercised | `[grounded]` your own statements | Gap queue G1; closing question R7 |
| R8 | Billing data: own it, and experience working with finance on it | must_have | absent | none | capability | You say you have never worked on billing data. The JD's "billing or revenue data" wording means R11 is a second route for the experience line, but "own our … billing data" stays a stated responsibility | `[grounded]` your statement; `[grounded]` JD | Gap queue G2: closure path, carried as a material risk |
| R9 | Build pipeline and renewal reporting for sales and finance | must_have | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is not stated, so the finance half is carried by R11 | `[grounded]` your background | A sanitized screenshot would raise this to `high` |
| R10 | At a B2B software company | important | unclear | medium | discovery | You said "B2B payments company"; whether its product is software is not stated, so it is not assumed. The hiring manager's published prior role was at a payments company, which suggests payments-sector operations experience is familiar to her; whether she counts it as software is hers to say | `[grounded]` your background; `[inferred]` from the search-result career path | One line on what the company sells settles it |
| R11 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | Renewal dashboards plausibly draw on revenue data, but whether you worked with finance on them is unstated | `[inferred]` from "renewal dashboards" | Gap queue G3; closing question R8, R11 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R7, must_have) | transferability | A monthly pipeline review with the sales director and rebuilt pipeline dashboards, with finance owning the forecast | The JD has the role running the quarterly forecast with the CFO, so this is the largest stretch on the fit side | A pipeline-to-forecast roll-up finance or your director relied on; coverage or commit-versus-actual analysis; forecast-accuracy reviews; a scenario model built for the pipeline review | A sanitized roll-up spreadsheet or review deck | `[grounded]` JD and your statements; `[inferred]` that a roll-up is the nearest bridge |
| G2 | Billing data (R8, must_have) | capability | You state you have never worked on billing data | The JD makes billing data an owned responsibility | None claimed. Closure path: ask what billing system and finance process the role inherits, and arrive with a 90-day learning plan | A short note on what you would learn first, offered as a plan, not as experience | `[grounded]` your statement; `[generic]` billing and finance setups differ by company |
| G3 | Finance working on revenue data (R11, must_have) | discovery | Renewal dashboards exist; finance involvement is unstated | It is the second route to the JD's finance experience line, and it could move R8's weight | Renewal figures reconciled with finance; shared definitions of renewal or churn; a report finance used at month end | A dashboard screenshot or a definitions doc | `[grounded]` your background; `[inferred]` from "renewal dashboards" |
| G4 | Spreadsheet modelling (R6, must_have) | discovery | Excel daily, with no models named | "Modelling" is named in the JD requirement | Forecast, scenario, quota or commission models; a model others reused | A sanitized workbook | `[grounded]` your background silent on models |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on Quillfield's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | Quillfield may list roles on another path or only through the job board; one failed fetch of one URL does not show the role is absent | `[grounded]` fetch of quillfield.co.uk/careers returned "No page"; `[generic]` small firms often use a board listing | Where is this role listed on Quillfield's own careers site, and when did it open? | unresolved |
| RR2 | Forecast authority and success measures unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may be accountable for the forecast without final say, with no first-year outcomes defined | `[inferred]` from "with the CFO" and the JD's silence on outcomes | Who owns the quarterly forecast number, this role or the CFO, and how is success measured in year one? | unresolved |
| RR3 | Reporting line and team unstated | unknown | — | "You will own our CRM and billing data" | The post may be a sole contributor reporting to the Head of Revenue Operations | `[inferred]` from the JD's silence on reports and the hiring manager's published title | Who does this role report to, and what analyst or admin support does it have? | unresolved |
| RR4 | Share options unquantified | unknown | — | "plus share options" | Their value depends on terms and valuation the posting does not give | `[grounded]` £11M Series A on the About page; `[generic]` option value at early-stage firms depends on terms | What are the option terms: number or percentage, vesting, strike price, exit treatment? | unresolved |
| RR5 | Salary stated and inside the market range | positive_signal | — | "£61,500–£67,000" | A stated range is transparent, and its midpoint is close to the guide's median | `[grounded]` JD; `[generic]` Ledgerline band | Where in this range would an offer for this role normally land? | noted |
| RR6 | Hiring manager's published role matches the recruiter's attribution | positive_signal | — | "the hiring manager is Tamsin Achebe" (your recruiter) | The attribution is consistent with a published Quillfield title | `[grounded]` search result, Head of Revenue Operations at Quillfield | Does this role report to you, Tamsin? | noted |

## Application plan

Everything here is proposed, not applied. That covers the CV lines, the work sample, the positioning rows and the outreach rows, and each row carries its own status. The CV rows are `resume_edits_pending_approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Ran revenue operations for the UK team (two years, within five in sales operations at a B2B payments company); rebuilt the pipeline and renewal dashboards; run the monthly pipeline review with the sales director." Every clause traces to your message, and it claims neither forecast ownership nor finance partnership | R3, R9 | `[grounded]` your own sentences | pending your approval |
| E2 | CV line: "Salesforce administrator (certified)", with the credential name from your records | R4 | `[grounded]` your statement | pending your approval |
| W1 | A one-page pipeline-to-forecast roll-up on dummy data, labelled as a sample, with a note that finance owned the live forecast | Narrows R7's limit | `[inferred]` from R7 | pending your approval |
| Q1 | Ask the verification questions of RR1 to RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the careers-page listing with the recruiter before investing in the loop | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the dashboard rebuild and the Salesforce certification (R9, R4). The hiring manager's published path runs from sales operations to Head of Revenue Operations | R9, R4 are your strongest rows | `[grounded]` her published roles; `[inferred]` choice of lead story | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report, CV-equivalent until you answer a specific probe or share an artifact. No memory leads were used.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" and read "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned "No page". Moved role reality's organization row and RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR5. Role scope norms were not swept |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring manager row, RR6 and A2 |

I can also save all this as `tuesday-dossier.md` to carry into later steps, if you want it.

## Upgrade menu

- Your CV, or a Trailhead or credential link → R3, R4 and E1 move from your typed summary to inspected text, and R4 can reach `high`.
- A sanitized renewal-dashboard screenshot → R9 can reach `high`, and G3 may resolve.
- A sanitized roll-up or model workbook → R6 and R7 firm up.
- Where you live and your pay floor → R1 and R2 close, and the hard-gates line becomes confirmed.
- The recruiter's link to the role on Quillfield's own site → RR1 closes.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. R1, R2 — Do Bristol with two office days a week and £61,500–£67,000 both work for you?
2. R7 — Have you built or maintained a pipeline-to-forecast roll-up that your sales director or finance relied on, even though finance owned the forecast, and what did you own and what did it feed?
3. R8, R11 — Did your renewal dashboards pull from invoice, subscription or payment data, and did anyone in finance work with you on them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.