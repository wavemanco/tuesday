Search permission was declined, so this runs on the JD and your background alone.

## Decision snapshot

**Yes, apply. You are a fit on the core requirements (R1, R2, R3, R4 and R6 are `direct`), and healthcare (R9a) is your one stated gap. Status: `conditional_go`.** It is conditional because the employer could not be verified (RR1).

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (Define and maintain the metrics layer)
- `important` — adjacent: R7a (Partner with product managers on roadmap decisions) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9b (HIPAA-adjacent privacy and consent data handling) · absent: R9a (Healthcare data experience)

R5 — your dashboards are evidenced, "metrics layer" itself is not yet; R7b and R8 — your background says nothing either way; R9a — no healthcare work, a preferred item, partly bridged by R9b.

**Opportunity ledger.** The role is concrete on tooling and stakeholders (RR4). The employer is unverified (RR1), pay is unstated (RR2), and the scope is broad with no stated success measures (RR3, RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies as live on Harborlight's own careers site (RR1); (2) your pay, location and sponsorship terms are checked against the role once you state them (R-rows for them would be added); (3) the metrics-layer and mentoring scope is confirmed, not assumed (R5, R8, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app | `[grounded]` JD header, not externally verified |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, partnering with product managers and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Seniority shape | Senior individual contributor with informal mentoring of two juniors, not a stated people-manager role | `[inferred]` from "mentor two junior analysts" with no mention of reports or line management |
| Unknowns | Compensation, location or remote policy, reporting line, warehouse and modelling stack beneath the metrics layer, experimentation tooling, first-year outcomes | `[grounded]` JD is silent on each |
| Healthcare weight | In digital health, product analytics often touches regulated patient data, which is why the JD calls HIPAA a plus rather than required | `[generic]` role-family pattern, not a claim about this employer |
| Market calibration | Not run, and no band is offered, because the sweep did not execute | `[grounded]` see Evidence status |
| Contradictions | Posting not cross-checked against Harborlight's careers page | `[grounded]` see Evidence status |

## Evidence map

Your background is typed prose, which counts as CV-equivalent self-report. That is why the confidence column stops at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. Confirmed and specific, with no inspectable artifact | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse." Daily use is stated, but "expert" is a level only a work sample or a live exercise shows. Expect a SQL test | `[grounded]` your background; `[generic]` that analyst loops commonly include one | Be ready for a live SQL exercise; a sanitized query set would raise this to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | "Designed and ran the experimentation program: 30+ A/B tests a year," including the pricing test behind an 11% retention lift. The base of the 11% (relative or points) is not stated, so it is carried as you wrote it. Subscriber scale is stated (about 2M); Harborlight's traffic and sample sizes are unknown | `[grounded]` your background; `[inferred]` that care-navigation sample sizes may differ from consumer-subscription ones | Confirm what the 11% measures; a sanitized experiment readout would raise this to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | "Built the company's Looker instance from scratch — 40+ governed dashboards." Looker is named in the JD, so this is the same tool | `[grounded]` your background | A dashboard screenshot or sanitized LookML sample would raise this to `high` |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | Confidence grades your stated claim of 40+ governed dashboards. Fit is `adjacent` because you did not say you defined shared metric definitions beyond the dashboards. Whether your Looker build included that is the open question. I am not borrowing the JD's term for your work | `[grounded]` your background's silence on metric definitions | See G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your background | A sanitized memo would raise this to `high` |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | Presenting to the VP Product monthly is stated. A roadmap decision that followed from your analysis is not, though the pricing test may be one | `[grounded]` your background | See G3 |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background touches clinical stakeholders | `[grounded]` your background's silence | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background does not mention mentoring or leading analysts | `[grounded]` your background's silence | See G2 |
| R9a | Healthcare data experience (HIPAA) | preferred | absent | none | capability | You state you have never worked in healthcare | `[grounded]` your statement | Carry it as a preferred-tier gap, stated plainly |
| R9b | Handling regulated personal data | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse's consent-state model. Limit: this is consumer-privacy regulation, not HIPAA or health data, which carry different obligations | `[grounded]` your background; `[generic]` that HIPAA obligations differ in kind from GDPR/CCPA | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, must_have) | discovery | 40+ governed dashboards, but no statement of who defined the underlying metrics or where definitions lived | A must-have at `adjacent`; the answer could move it to `direct` | Writing LookML models or shared measures; owning a metric dictionary; resolving conflicting definitions between teams; defining retention or conversion once for all dashboards | LookML excerpt, metric-definition doc, a metrics glossary | `[grounded]` background silence; `[generic]` that "governed" dashboards usually rest on shared definitions, not proof you wrote them |
| G2 | Mentoring junior analysts (R8, important) | discovery | No mention of mentoring | The JD names it as a duty | Reviewing others' queries; onboarding a new analyst; a formal or informal mentee; leading an intern | A mentee's name or role, a review process you set up | `[grounded]` background silence |
| G3 | Clinician partnership and roadmap influence (R7a, R7b, important) | discovery | PM-facing monthly presentations; no domain-expert or clinical partners stated | The JD lists clinicians next to product managers | A roadmap or pricing change that followed your analysis; working with a domain expert such as a nutritionist, dietitian or food-safety lead | A decision memo, a pricing-test readout | `[grounded]` background silence; `[inferred]` that the pricing test may qualify |
| G4 | Healthcare and HIPAA exposure (R9a, R9b, preferred) | transferability | Consent-state model and GDPR/CCPA PII handling; no health data | Preferred item. The bridge is real; the limit is that it is not health data | Any health-adjacent data (nutrition or dietary-restriction data, wellness features); working with a DPO or privacy counsel; de-identification | A consent-model diagram, a privacy review you took part in | `[grounded]` background; `[generic]` that interviewers in health settings will probe the HIPAA limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (the posting states no pay) | The posting may withhold pay, or the pasted text may have dropped it | `[inferred]` from the JD text's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Broad scope in one title | unknown | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker … mentor two junior analysts" | Data modelling, experimentation, BI and mentoring may be folded into one post | `[inferred]` from the responsibility list | Does an analytics engineering or data platform team own the warehouse models beneath the metrics layer? | unresolved |
| RR4 | Concrete tools and stakeholders | positive_signal | — | "build self-serve dashboards in Looker" | The stack and partners are named, and two junior analysts imply an existing team | `[inferred]` from the JD's named tool and mentoring duty | How is the analytics team structured today, and who do the two junior analysts report to? | noted |
| RR5 | No stated success measures | unknown | — | "turn analysis into roadmap decisions" | The posting gives no first-year outcomes | `[inferred]` from the JD's silence | What would make this hire a success twelve months in? | unresolved |

## Application plan

Everything in this table is a proposal. Rows E1 to E3 are `resume_edits_pending_approval`, and the positioning rows P1 and A1 are also pending your approval. I audited each line against your own sentences, and nothing becomes final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Harborlight's own careers site before spending application effort | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Keep your own wording, and say whether 11% is relative or in points | see R3 | `[grounded]` your sentence, unchanged | resume_edits_pending_approval |
| E2 | "Built the company's Looker instance from scratch — 40+ governed dashboards." Do not rename it "metrics layer" unless G1 confirms that work | see R4, R5 | `[grounded]` your sentence, unchanged | resume_edits_pending_approval |
| E3 | "Write the monthly metrics memo the exec team reads; present monthly to the VP Product." Add the consent-state model and GDPR/CCPA PII handling as stated, without the word HIPAA | see R6, R9b | `[grounded]` your sentences, unchanged | resume_edits_pending_approval |
| P1 | In any note or interview, state plainly that you have not worked in healthcare, then offer the consent-state model as the nearest real experience, with its limit | see R9a, R9b | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused, so nothing was read. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range 2026"; the call was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

I can also write all of this up as `tuesday-dossier.md` if you want to keep it or carry it forward.

**Upgrade menu**

- Stating your pay floor, location or remote needs, and any work-authorization limits → hard-gate rows are added and checked against the role.
- The posting link on Harborlight's careers page, or the recruiter's email domain → RR1 closes and the decision can move from `conditional_go` toward `go`.
- Search access, if you grant it → targets 1 and 2 run, and I can add a market calibration and verify the employer. A deeper pass (up to 5 more searches and 2 more fetches) is also on offer, once.
- A dashboard screenshot or LookML excerpt, a sanitized experiment readout, a sanitized metrics memo, or a short query set → R3, R4, R6 and R2 can rise to `high`.
- The hiring manager's name → role reality's scope read and which story to lead with.

**Questions**

1. Do you have any non-negotiables for this move (pay floor, location or remote, work authorization or sponsorship, start date)? Any of these could turn into a hard gate.
2. RR1 — can you share the link to this posting on Harborlight's own careers site, or the recruiter's email domain?
3. G1 — in the Looker build, did you define the shared metrics (retention, conversion and similar) that the dashboards sat on? If so, where did those definitions live, and who else used them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.