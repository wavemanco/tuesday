Fetched the posting and ran three quick checks on Quillfield and the hiring manager. Here's the assessment.

# Revenue Operations Lead at Quillfield: Underwriting

## Decision snapshot

**Yes, worth applying, but as a stretch rather than a safe fit. R8, R9 and R10 are the biggest distances between you and the posting. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol office, hybrid two days), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R5, R6 · adjacent: R8 (owning a forecast) · unclear: R4 (at a B2B software company), R7 (spreadsheet modelling), R9 (working with finance on billing or revenue data)
- `important`: direct: R11 · absent: R10 (own the company's billing data)

R8: nearest bridge is your monthly pipeline review, and the limit is that finance owned the company forecast; R9: unconfirmed, the renewal dashboards may count; R10: you have not worked on billing data; R1, R2: gates not yet answered.

**Opportunity ledger.** Quillfield and the named hiring manager check out publicly (RR6), and the salary is stated and sits inside the market band (RR5). The posting leaves team and authority (RR2), first-year outcomes (RR3) and option terms (RR4) open, and I could not find it on Quillfield's own careers page (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol office, hybrid two days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed as workable for you; (2) the role confirmed live and the interview panel named — RR1; (3) R8, R9 and R10 presented as what they are (adjacent or absent, never as equivalents), and what is expected of you on forecast and billing from day one established early — RR2, RR3.
- **What would change this:** R1 or R2 failing moves it to `no_go`. So would RR2 and RR3 showing that owning billing data and the CFO forecast is expected from day one with no ramp, because R8 and R10 are your two largest distances.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 employees; £11M Series A closed April 2025 | `[grounded]` "About Quillfield" (quillfield.co.uk/about), search result text only, page not opened |
| Mandate | Own the CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Compensation | £61,500–£67,000 plus share options; option terms not given | `[grounded]` posting |
| Market calibration | Ledgerline's 2026 UK pay guide puts a revenue operations lead in UK B2B software at a median base of £64,200, interquartile range £57,800–£70,400 (n=438). The posted range sits inside that range, near the median. The band is UK-wide, not Bristol-specific, and is not this employer's offer | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide, search result text only; `[grounded]` posting figure |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, and was previously a sales operations manager at Corvane Payments for four years | `[grounded]` "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), search result text only; public professional footprint only |
| Scope read | A "Lead" under a Head of Revenue Operations suggests a function that already has a head. Whether you would have reports, and who sets revenue definitions, is not stated | `[inferred]` from the two titles; team size is `[grounded]` unstated in the posting |
| First-year outcomes | None stated. A likely first visible output is taking over the quarterly forecast cycle with the CFO | `[grounded]` posting silent; `[inferred]` from the responsibilities list |
| Unknowns | Whether HubSpot or Salesforce is the CRM; the billing system; team size; how the forecast is built today; option terms; whether the posting is live on Quillfield's own site | `[grounded]` posting silent on each |
| Contradictions | None found between the posting and the About page on company type or city. The company's own careers address I tried returned no page, which is not a contradiction | `[grounded]` About page result; careers fetch |

## Evidence map

Your background is typed prose, so it carries the standing of a CV and is capped at `medium` until something inspectable is seen.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol office, hybrid, two days a week | hard_gate | unclear | none | hard_gate | The posting states the term. You have not said where you are based or whether two office days works, so the gate is unsettled | `[grounded]` posting; your constraints not given | Question R1 below |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | You have not given a floor. The range sits near the market median, which makes a mismatch less likely but does not settle it | `[grounded]` posting; `[generic]` Ledgerline band | Your floor (see upgrade menu); RR4 for the options |
| R3 | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team. Self-reported, nothing inspectable yet | `[grounded]` your background message | none |
| R4 | At a B2B software company | must_have | unclear | medium | discovery | You name a B2B payments company. Whether it sold software, so that Quillfield reads it as the same sector, is not stated | `[grounded]` your message; posting wording | Gap G4 |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The posting accepts either platform. The credential has not been inspected | `[grounded]` your message | A link to the credential record would raise this to `high` |
| R6 | Strong SQL | must_have | direct | medium | none | You use SQL weekly. Frequency is stated, depth is not | `[grounded]` your message | A sanitized query example would raise it |
| R7 | Spreadsheet modelling | must_have | unclear | low | discovery | You use Excel daily. Nothing describes a model others relied on, so I took the lower band | `[grounded]` your message | Gap G5 |
| R8 | Experience owning a forecast | must_have | adjacent | medium | transferability | You confirm finance owned the company forecast. The bridge is your monthly pipeline review with the sales director. The limit is that a review is not ownership of a forecast number | `[grounded]` your statements | Gap G1 and question G1 |
| R9 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | You have not worked on billing data. The renewal dashboards might count as revenue data, but finance's involvement is not stated | `[grounded]` your statements | Gap G2 and question G2 |
| R10 | Own the company's billing data (a responsibility in the posting) | important | absent | none | capability | You confirm you have never worked on billing data. Nothing adjacent has been offered | `[grounded]` your statement | Gap G3 |
| R11 | Pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your team's pipeline and renewal dashboards. That finance used them is not stated. No CV was provided, so its wording is unchecked | `[grounded]` your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R8, must_have) | transferability | You run the monthly pipeline review. Finance owned the company forecast | The posting has this role run the quarterly forecast with the CFO. A stronger bridge narrows your largest must-have distance | Producing the UK team's commit or best-case number for the review; supplying pipeline figures into finance's model; tracking forecast against actual | A sanitized pipeline review pack, a forecast-versus-actual tracker | `[grounded]` your statement on finance; `[inferred]` that a team-level number may exist |
| G2 | Finance on billing or revenue data (R9, must_have) | discovery | Renewal dashboards rebuilt; finance's use of them unknown; billing data never touched | A must-have, and an answer could move R9 from `unclear` to `adjacent` | Agreeing renewal or revenue definitions with finance; reconciling dashboard figures to finance's numbers; finance sign-off on a report | A definitions document, a reconciliation sheet | `[grounded]` your message; `[inferred]` that finance contact may exist |
| G3 | Owning billing data (R10, important) | capability | No direct or adjacent evidence after your statement | The posting lists it first among responsibilities | Closure path: ask what the billing system is and what handover exists (RR2). Otherwise carry it as a material risk | None to offer yet | `[grounded]` your statement |
| G4 | Sector: B2B software (R4, must_have) | discovery | "B2B payments company" | The posting says software, and the sector fit decides whether R3's years read in its terms | Selling a platform or subscription product rather than processing services | Your CV's company description | `[grounded]` your wording against the posting's |
| G5 | Spreadsheet modelling (R7, must_have) | discovery | Excel daily, no model described | "Modelling" is a distinct requirement from daily use | A forecast, renewal or capacity model other people relied on | A sanitized model | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not seen on the employer's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The address I tried may not be Quillfield's real careers path, or the role may be listed only via the job board and recruiter | `[grounded]` careers fetch returned no page; `[generic]` roles are often routed through boards and recruiters | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Three domains under one Lead title; team and authority unstated | unknown | — | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The role may carry CRM, billing data and forecast accountability without stated reports or decision rights over revenue definitions | `[inferred]` from three domains in the posting against its silence on team and authority | Does this role have direct reports, and who decides the revenue definitions the forecast runs on? | unresolved |
| RR3 | No first-year outcomes stated | unknown | — | The posting states none | Success measures may be set after hire | `[grounded]` posting silent | What would a good first ninety days look like, and who owns the forecast process today? | unresolved |
| RR4 | Share options without terms | unknown | — | "plus share options" | The options' value is unknowable from the posting | `[grounded]` no terms given; `[generic]` option terms vary widely at funded companies | What is the grant size, strike price and vesting schedule for this role? | unresolved |
| RR5 | Salary stated and inside the market band | positive_signal | — | "£61,500–£67,000 plus share options" | A transparent, market-consistent range | `[grounded]` posting figure; `[generic]` Ledgerline band | Where in the range do you expect to land an offer for this role? | noted |
| RR6 | Employer and hiring manager corroborated publicly | positive_signal | — | "Revenue Operations Lead, Quillfield" | Quillfield exists as described, and the named hiring manager holds a revenue operations post there | `[grounded]` About page and profile search results, neither opened | Will Tamsin be my direct manager, and who does she report to? | noted |

## Application plan

Each block is proposed language, not applied. Every line below traces to a sentence you wrote, and none is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Rebuilt the pipeline and renewal dashboards" and "Ran revenue operations for the UK team for the last 2 of 5 years in sales operations at a B2B payments company" | R11, R3 | `[grounded]` your background message | resume_edits_pending_approval |
| E2 | Skills line: "Salesforce admin certified", with the credential link if you have one | R5 | `[grounded]` your background message | resume_edits_pending_approval |
| E3 | CV line: "Run the monthly pipeline review with the sales director". Do not word it as forecasting or forecast ownership | R8 | `[grounded]` your background message | resume_edits_pending_approval |
| P1 | In the application and first call, say plainly that finance owned the company forecast and that you have not worked on billing data. Then point to the pipeline review and the dashboards without presenting them as equivalents | R8, R9, R10 | `[grounded]` your own statements | pending your approval |
| P2 | Ask the verification questions of RR1 to RR4 verbatim with the recruiter and in the first interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm Bristol attendance and your salary floor against the posting before investing in the loop | R1, R2 | `[grounded]` posting terms | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved: role reality's organization and contradictions rows, RR1, RR6 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration, RR5. Result text only, page not opened |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: role reality's hiring manager and scope read rows, RR6. Result text only, page not opened |

I can save this as a `tuesday-dossier.md` to update as your answers come in. Say the word and I will.

**Upgrade menu**

- Your salary floor → R2 settles.
- Your CV → R3 and R11 confirm, and E1 to E3 can be checked against its actual wording.
- A link to your Salesforce credential → R5 to `high`.
- A sanitized pipeline review pack or forecast-versus-actual tracker → R8's bridge strengthens.
- A sanitized query or spreadsheet model → R6 and R7 firm up.
- Quillfield's own careers link for this role → RR1 closes.
- A deeper research pass on Quillfield (funding and leadership changes, reported hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- R1: Where are you based, and can you do two days a week in the Bristol office?
- G1: In the monthly pipeline review, did you produce a forecast number for the UK team that fed finance's company forecast, and what was yours versus finance's?
- G2: When you rebuilt the renewal dashboards, did finance use or reconcile the revenue figures, and what did you agree with them or own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.