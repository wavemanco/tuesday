I'll read the reference files the skill points to before building the assessment.
**Yes, worth applying to, on conditions. R1 (a hard gate) is unconfirmed and RR1 (employer not established) is open. Status: `conditional_go`.**

You listed two worries: never worked on pet insurance, and never managed anyone. Neither is a requirement in the posting. It asks for pricing analytics experience, SQL and Python, GLMs and presenting to underwriting or actuarial leads, and calls insurance experience "a plus". It says nothing about line management or pet-specific experience.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R6, R7, R8a · unclear: R8b (Recommendations for product)
- `preferred`: direct: R9

R1: UK location and right to work not yet stated; R5 (`medium`): "maintained" is the only monitoring evidence; R8b: nothing yet on product-side work.

**Opportunity ledger.** Open rather than bad. The employer is unverified (RR1), pay is not in the pasted text (RR2) and team shape is unstated (RR3). One entry runs the other way: the JD names concrete work (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify (RR1); (2) you confirm you are UK-based and eligible to work there (R1); (3) the product-side recommendation work (R8b) is described exactly as it happened, or left out.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product. Its existence and the posting's liveness are not established | `[grounded]` JD header, as you pasted it |
| Title and seniority | Senior Pricing Analyst, the same seniority as your current title | `[grounded]` JD header and your stated title |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | An analytics-ownership seat for one product under a Director, with no reports or team size stated | `[inferred]` from "Own pricing analytics" and a named Director, against the JD's silence on reports |
| Market calibration | Not produced. The role-family sweep could not run, so there is no band for title, scope or pay | `[generic]` no band stated, because model memory is not a source for market values |
| Unknowns | Salary; direct reports now or planned; data stack and test tooling; whether pet-specific knowledge is expected from day one; first-90-days outcomes | `[grounded]` none of these appear in the pasted JD |
| Contradictions | None within the material provided; the JD against the careers page is unchecked | `[grounded]` provided text only |

## Evidence map

Your background was typed into the conversation, so it counts as self-report at intake. That caps rows at `medium`, and R2–R9 rest on it.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | Your location and right to work are not stated. A UK motor insurer is indirect context only, so low | `[grounded]` JD term; `[inferred]` UK base from a UK employer | Question R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst; self-reported, not yet inspected. A years requirement is not a gate | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated; no code or query sample seen | `[grounded]` your stated background | offer: a sanitized query or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Scope is that book, stated that way wherever the claim is used | `[grounded]` your stated background | offer: a sanitized model summary would raise to high |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained; "maintained" is the only basis for "monitor", and which monitoring you ran is unstated. The model was motor, the role's is pet. `[generic]` rating-model methods are shared across personal-lines products, but the rating factors differ | `[grounded]` your stated background; `[generic]` method transfer | use "built and maintained", not "monitored", unless you confirm monitoring specifics |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. Whether you designed them, read them or both is unstated | `[grounded]` your stated background | offer: a sanitized test write-up (hypothesis, design, readout, decision) would raise to high |
| R7 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your stated background | none |
| R8a | Turn results into recommendations for underwriting | must_have | direct | medium | none | Price tests run with the underwriting team and the quarterly review to its head are the evidence. Whether your recommendations were adopted is unstated | `[grounded]` your stated background | none |
| R8b | Turn results into recommendations for product | must_have | unclear | low | discovery | Nothing you described involves a product or proposition team. Low, not none, because pricing work often reaches product somewhere and a thread may exist | `[grounded]` silence in your background; `[generic]` that pricing work often touches product teams | Question G1 below |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance is insurance; pet insurance is not claimed and the posting does not require it | `[grounded]` your stated background and the JD's wording | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations for product (R8b, must_have) | discovery | Pricing work with underwriting is established; work with a product, proposition or commercial team is not | R8b is the one `must_have` row below `direct`; an answer here could remove the gap from the decision | Taking a test result to a product owner; agreeing a rating-factor or discount change with a commercial team; a pricing input to a new-product or renewal-strategy paper | A sanitized recommendation note, a slide from a pricing review, or a change log | `[grounded]` silence in your background; `[inferred]` that resolving it firms up the case for this role |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Senior Pricing Analyst — Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. No search succeeded here, so nothing has been established either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Salary not in the pasted posting | unknown | — | the pasted JD has no pay line | Pay may be withheld, omitted from the paste, or set at interview | `[inferred]` from the JD text as provided, with no band to compare it to | What salary range is budgeted for this post? | unresolved |
| RR3 | Team shape and ownership boundaries unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean sole analyst, or lead of a small team; whether the role has direct reports now or planned is unknown | `[inferred]` from "Own" against the JD's silence on reports and tooling | Does this role have direct reports now or planned, and who owns the rating engine and test platform? | unresolved |
| RR4 | Concrete named work | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | Scope is defined by activities and named audiences, not by buzzwords | `[grounded]` JD wording | What would a successful first year look like for the person in this seat? | noted |

## Application plan

Everything in this section is proposed. The resume edits are `resume_edits_pending_approval` and every other row is pending your approval. Nothing is final until you approve it. Each proposed line below traces to your own sentences, quoted.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with "5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst", your words | R2 and the title match | `[grounded]` your sentence | `resume_edits_pending_approval` |
| E2 | Keep your verbs: "built and maintained the GLM rating model for the young-driver book", "ran 14 price tests last year with the underwriting team", "present the quarterly pricing review to the head of underwriting". Don't change "ran" to "designed", or "young-driver book" to a wider scope, without confirming | R4, R5, R6, R7; the plan can't claim more than the evidence does | `[grounded]` your sentences | `resume_edits_pending_approval` |
| P1 | In any cover note, say plainly that your pricing work is motor and you haven't worked on pet insurance. Then point to the GLM, price-test and presenting evidence as the work you'd bring | R5 and R9 are adjacent in product, not direct | `[grounded]` your sentences, R5, R9 | pending your approval |
| A1 | Before investing in an application, find the role on Brindlemoor's own careers page and note the recruiter's email domain | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Put RR2, RR3 and RR4's verification questions to the interviewer verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | A one-page sanitized price-test write-up: hypothesis, design, readout, decision | R6; also the best artifact for Odile Varga's role to read | `[grounded]` R6 row | pending your approval |

## Evidence status

Verified: none yet. Everything above comes from your typed background, which is self-report until you confirm specifics. Unverified leads: none from prior context. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused, so the employer and the posting's liveness are not established (RR1). It would have moved role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | The search was refused, so there is no market calibration line and no pay band to set against RR2. It would have moved role reality's market calibration and scope read |
| 3. Hiring manager's public footprint | unavailable | The search was refused, so Odile Varga's public professional footprint is unread. It would have moved role reality's scope read and which story the plan leads with |

I can write this up as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Search permission granted → targets 1–3 run: RR1 can resolve, role reality gets a market calibration and a pay band for RR2, and Odile Varga's public footprint informs the scope read and what the plan leads with.
- A deeper pass on Brindlemoor (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) → more entries for the register. Say the word and it runs after the first-round targets.
- A link to the live posting on Brindlemoor's careers site, or the recruiter's email domain → RR1 closes and the `conditional_go` cap lifts.
- Your CV → R2–R9 get checked against its wording, and edits are proposed against what it actually says.
- A sanitized price-test write-up → R6 to `high`. A sanitized model summary → R4 and R5 to `high`. A sanitized query or notebook → R3 to `high`.
- An answer to G1 → R8b closes or stays as a named gap.
- Your answers to R1 and C1 → the hard-gates line stops flagging unconfirmed checks.

R1 — Are you based in the UK with the right to work there without sponsorship?

G1 — Have you taken a pricing result to a product, proposition or commercial team, as opposed to underwriting? What did you own, who was involved, and what changed?

C1 — Is there a pay floor, contract type, or hours pattern that this role would have to meet for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.