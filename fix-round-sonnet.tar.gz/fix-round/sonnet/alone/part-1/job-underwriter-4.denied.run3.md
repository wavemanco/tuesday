I'll read the reference files the skill requires before building the assessment.
**Yes, apply, on conditions. Status: `conditional_go`.** Your two flagged gaps: pet insurance is R10 (`preferred`, `adjacent`), and managing people has no row because the JD names no management duty (see Role reality, "People management").

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important`: unclear: R8 (Recommendations for product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance pricing)

R1 — gate not yet confirmed; R5b, R8 — claims not yet probed; R10 — a bridge with its limit named.

**Opportunity ledger.** The role is unverified and under-specified rather than troubling. The employer is unchecked (RR1), and salary (RR2), decision rights (RR3), success measures (RR4) and team/tooling (RR5) are unstated. One entry runs the other way: the duties list is specific and coherent (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify (RR1); (2) R1 is confirmed met; (3) the salary clears your floor (RR2); (4) the pet-insurance gap is framed as adjacent, never as pet-pricing experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Its existence and the live posting are unchecked. | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. Public footprint not researched. | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| People management | No direct reports or team-leadership duty appears in the JD's duties or requirements | `[grounded]` JD |
| Compensation | No figure in the posting as provided | `[grounded]` JD silence |
| First-year outcomes | Not stated. Early work likely means inheriting existing models and in-flight tests. | `[inferred]` from "build and monitor rating models" and "read price tests" |
| Scope read | One product's pricing analytics with a four-year floor, no reports stated | `[inferred]` from the JD's duties and requirements |
| Market calibration | Not run: the role-family search was refused, so no salary band is offered | — |
| Unknowns | Salary; who approves rate changes; team size; modelling and test tooling; success measures | `[grounded]` JD silence |
| Contradictions | None inside the JD. The cross-check against Brindlemoor's own site did not run. | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You have not stated where you live or your right to work. A UK motor insurer employer is indirect context only. Confidence grades your statement of the constraint, and none exists yet. | `[grounded]` JD; your background names a UK employer | Gate question Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst. It is confirmed and specific, but nothing inspectable has been seen. | `[grounded]` your background statement | A CV with dates would raise to high |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is stated. How deep the use goes ("strong") is not. Expect a probe on what you built with them. | `[grounded]` your statement | A sanitised query or notebook sample would raise it |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. It is motor, not pet, and no artifact has been seen. | `[grounded]` your statement | A sanitised model spec or factor summary would raise to high |
| R5a | Build rating models | must_have | direct | medium | none | "Built" the young-driver GLM, the same evidence as R4 | `[grounded]` your statement | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". Monitoring (actual vs expected, drift, refit triggers) is not stated, and maintenance may or may not have included it. | `[grounded]` "maintained"; `[inferred]` that it may include monitoring | Q3 |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You "ran" 14 tests with underwriting last year. Whether you also designed them (cells, control, sizing) and read the results is not stated, so the lower reading holds. | `[grounded]` your statement | Q2 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. You also ran the tests with the underwriting team. | `[grounded]` your statement | none |
| R8 | Recommendations for underwriting and product | important | unclear | low | discovery | Underwriting-facing work is evidenced under R7. Product-facing work is not mentioned. | `[grounded]` JD quote against your silence | Carried; not asked this turn (question budget) |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your statement | none |
| R10 | Pet-insurance pricing knowledge (inferred from the pet product named in the JD header) | preferred | adjacent | medium | transferability | You confirm no pet-insurance work. What carries over is GLM rating and price-test method in another insurance line. The limit is no exposure to pet-specific rating structure or claims behaviour. | `[inferred]` from your motor work; `[generic]` that pet and motor rating differ in factors and claims patterns | Honest bridge framing (E2); optional work sample (W1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" is stated. Tracking and refit work is not. | It is a must-have that sits at `unclear`. Resolving it likely lifts the rating-model duty to fully evidenced. | Actual-vs-expected tracking on the young-driver model; a refit or recalibration after drift; a post-implementation review of a rate change; a performance dashboard | A sanitised monitoring pack, a refit memo, a dashboard screenshot | `[grounded]` the CV-equivalent silence; `[generic]` that monitoring is a standard duty of rating-model ownership |
| G2 | Design and read price tests (R6, must_have) | discovery | Fourteen tests "ran". Your design role and the results are not stated. | Price testing is one of the JD's named duties, so ownership detail decides how strongly to lead with it | Choosing test and control cells; sizing and duration; reading uplift on conversion or loss ratio; recommending a rollout | A sanitised test plan or readout | `[grounded]` your wording; `[generic]` that interviews for this duty probe design ownership |
| G3 | Pet-insurance pricing (R10, preferred) | transferability | Adjacent: GLM rating and price tests in motor. Limit: no pet-specific exposure. | It is preferred-tier, so it is a ramp-up risk and not a blocker | Any personal-lines product work beyond young-driver motor; self-study of pet rating factors | A short approach note as a work sample (W1) | `[inferred]` bridge from your motor work |
| G4 | Product-facing recommendations (R8, important) | discovery | Underwriting-facing work only | The JD pairs underwriting and product | Rate or price-test recommendations taken to a product or commercial owner | A product-facing pricing paper or test readout | `[grounded]` JD pairing against your silence |
| G5 | UK location and right to work (R1, hard_gate) | hard_gate | Not stated; indirect context only | A gate the inputs do not settle stays open | Not applicable; the gate is met or it is not | None needed | `[grounded]` JD quote; your background silent on residence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)… pet-insurance product" | Research could not run, so the entity, the live posting and the match to its careers page are unchecked. That is unverified, not failed. Severity stays at medium: salary is unstated (RR2), but nothing in the material shows urgency pressure. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | The posting as provided names no salary | The figure may not clear your floor, or Brindlemoor may simply not publish one. No band could be retrieved to judge. | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Decision rights over rate changes unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend without deciding, and the approval chain for rating changes is unstated. | `[inferred]` from the JD's "recommendations" against its silence on authority | Who approves a rating change or a test rollout, and what does this role own versus recommend? | unresolved |
| RR4 | Success measures absent | unknown | — | "Own pricing analytics for our pet-insurance product" | Ownership is stated without a definition of success. | `[inferred]` from the JD's silence | What would a successful first year look like in this role? | unresolved |
| RR5 | Team shape and tooling unstated | unknown | — | "build and monitor rating models, design and read price tests" | Who else sits in pricing, and the modelling and test stack, are not described. | `[inferred]` from the JD's silence | Who else is in pricing, and what do you use for modelling and price tests? | unresolved |
| RR6 | Duties are specific and coherent | positive_signal | — | "build and monitor rating models, design and read price tests" | The duties read as one coherent pricing discipline, not several roles bundled into one title | `[inferred]` from the JD's duties list | Who owns the price-testing calendar today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV summary line: "Pricing analytics for five years at a UK motor insurer, the last two as senior analyst: built and maintained the GLM rating model for the young-driver book; ran 14 price tests with the underwriting team last year; present the quarterly pricing review to the head of underwriting." | R2, R4, R5a, R6, R7 | `[grounded]` your background statement | resume_edits_pending_approval |
| E2 | Cover-letter sentence for the pet gap: "I haven't priced pet insurance; my rating-model and price-test work has been in motor." Don't describe your motor work as pet-pricing experience. | R10 | `[grounded]` your statement | pending your approval |
| W1 | A one-page note on how you would approach monitoring and price testing for a new pet product, as an optional work sample | G3 | `[inferred]` from R10's limit | pending your approval |
| A1 | Confirm the posting is live on Brindlemoor's own site, and who you would interview with, before investing in the application | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions of RR2, RR3, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Nothing in this table (the draft line, the sentence, or the positioning advice) is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches ("Brindlemoor pet insurance insurtech", "Brindlemoor careers Senior Pricing Analyst") were refused. It would have settled whether the employer exists as described and the posting is live (RR1, role reality). |
| 2. Role-family sweep | unavailable | The search ("senior pricing analyst pet insurance UK salary remote") was refused. It would have given the market calibration row and a salary band against RR2. |
| 3. Hiring manager's public footprint | unavailable | The search ("Odile Varga Director of Pricing Brindlemoor") was refused. It would have informed role reality's scope read and which verified story the plan leads with. |

I can save this assessment as `tuesday-dossier.md` if you want it.

## Upgrade menu

- Permission to run the three research targets above: RR1 closes or escalates, a salary band is set against RR2, and Odile Varga's published roles and talks shape the lead story.
- Your CV with dates: R2 to `high`.
- A sanitised model spec or factor summary: R4 and R5a to `high`.
- A sanitised query or notebook sample: R3 toward `high`.
- A sanitised test plan or readout: R6 to `high` and G2 closes.
- A sanitised monitoring pack or refit memo: R5b resolves.
- Your salary floor or any other non-negotiable: it becomes its own gate row and RR2 is checked against it.
- The posting link, or a salary range from the recruiter: RR1 and RR2 close.

## Questions

Q1 (G5, R1): Are you UK-based with the right to work in the UK, for a fully remote UK role?

Q2 (G2, R6): Across the 14 price tests, what did you personally own (choosing cells and control, sizing, reading results, recommending the rollout), and what happened to the results?

Q3 (G1, R5b): What did maintaining the young-driver GLM involve day to day: what you tracked, and, if anything did, what made you refit or recalibrate it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.