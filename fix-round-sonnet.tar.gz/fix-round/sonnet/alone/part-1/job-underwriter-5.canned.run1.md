I'll read the reference files the skill requires before building the assessment.
**Yes, it looks worth applying to, on a few conditions (`conditional_go`).** Your answer comes from R3, R4, R5, R6, R7 and R8, the six `must_have` rows. I rated each `direct` from your own account of the work. The open items are your location and pay floor (R1, R2) and a BigQuery gap (R9).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (dbt-modelled warehouse in BigQuery); unclear: R10 (ingestion from our app and CRM), R11 (data contracts our analysts depend on)

R1, R2 — your location and pay floor were not given; R9 — Snowflake to BigQuery is a real bridge with a limit; R10, R11 — nothing you've told me speaks to them yet.

**Opportunity ledger.** The pay is stated and sits inside the report's band (RR4). The reporting line, the breadth of "build and run", and the equity terms are open (RR1, RR2, RR3), and the company's size and funding come only from its own pages (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you can work from the US or Denver (R1) and that the band clears your floor (R2); (2) BigQuery is framed as adjacent and never as experience (R9); (3) reporting line, scope and equity verify acceptable in interviews (RR1, RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched in research |
| Posting status | Live and "Accepting applications"; the text matches what you pasted | `[grounded]` careers page, fetched |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity (size unstated); Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | The JD spans three layers (ingestion, modelling, contracts) plus running them. The report's typical senior scope is one domain's pipelines with no reports. The JD mentions no reports, and its scope could be wider than a single domain | `[inferred]` from the JD's three named layers against the report's typical scope |
| Market calibration | Datawright 2026 (n=2,310), Senior DE at Series B–D: median $151,000, IQR $139,000–$163,500; "Senior" typically 5–8 years. The posted low end is $3,000 under the median and the high end $2,500 over the upper quartile, so the range sits mid-to-upper band. Your 6 years falls in the typical span. This is a market band and not this employer's offer | `[grounded]` the report you supplied; `[inferred]` the comparison arithmetic |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Hiring manager and reporting line; team size; on-call expectations; equity size; success measures | `[grounded]` JD and your note that no manager is named |
| Contradictions | None between the JD and the careers page | `[grounded]` page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work eligibility were not given, so the gate is not established. Confidence is `none` because no statement of yours exists to grade | `[grounded]` JD term; no candidate statement | Ask: closing question R1/R2 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor was not given. The band itself sits mid-to-upper in the report, but whether it clears your floor is unknown | `[grounded]` JD figure and report; no candidate statement | Ask: closing question R1/R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Confirmed in prose only, so `medium` is the intake ceiling. A years requirement is graded on evidence and is not a gate | `[grounded]` your stated background | A CV or LinkedIn history would raise it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily. Nothing inspectable yet, so expect a technical probe | `[grounded]` your stated background | Offer: a sanitized query or pipeline sample would raise it |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models. The number is your own figure, unverified | `[grounded]` your stated background | Offer: a model-lineage screenshot or sanitized repo structure |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD's wording is generic and Snowflake is a cloud warehouse, so this meets it. The BigQuery specifics are R9 | `[inferred]` from the JD's generic wording against your Snowflake work | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You name Airflow as your orchestrator, the exact tool the JD names. The extent of your ownership is not stated | `[grounded]` your stated background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations suite. Coverage and outcomes are not yet stated | `[grounded]` your stated background | Offer: suite structure or the number of checks, sanitized |
| R9 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The same dbt and SQL modelling work carries over from Snowflake. The limit is that you have never used BigQuery. The JD's requirements line says "a cloud warehouse" and does not require BigQuery by name | `[grounded]` your stated Snowflake work and the JD's wording; `[generic]` that cost and storage mechanics differ between warehouses | See G1 |
| R10 | Ingestion from our app and CRM | important | unclear | low | discovery | Your payroll work likely involved ingestion, but the sources, tools and ownership are not stated. Low because it is only a plausible thread | `[inferred]` from a pipeline role at a payroll company; nothing confirmed | Ask: closing question G2 |
| R11 | Data contracts our analysts depend on | important | unclear | low | discovery | You describe a test suite, which is adjacent, but agreed schemas or SLAs with producers and consumers are not stated | `[inferred]` from the Great Expectations work; nothing confirmed | Ask: closing question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Carries over: dbt modelling on a cloud warehouse, about 180 models, with SQL daily. Limit: no BigQuery use, so no hands-on cost, partitioning or access-model experience there. Strengthener: a small dbt project on BigQuery using a public dataset, claimed as a practice project and not as production work | The JD names BigQuery in its mandate, and the usual objection is "have you run it?", so a stated limit plus a small artifact narrows it | Any work where you queried or loaded BigQuery in passing; any warehouse migration or cost-tuning work on Snowflake | A repo or short write-up of the practice project | `[grounded]` Snowflake and dbt work and the BigQuery absence; `[generic]` that this is the likely objection |
| G2 | Ingestion from app and CRM sources (R10, important) | discovery | The sources, connectors and ownership of your payroll pipelines are not stated | An important row at `unclear`; a match would likely lift it to `direct` | Pulling product-event or API data into the warehouse; a CRM sync such as Salesforce or HubSpot; building or owning an ingestion layer | A pipeline diagram, DAG list or ingestion README | `[grounded]` background is silent on sources; `[inferred]` that this could move the row |
| G3 | Data contracts (R11, important) | discovery | The Great Expectations suite is stated, but agreed schemas, SLAs or change processes with upstream teams or analysts are not | The JD names the contracts analysts depend on, so owning that interface looks central to the role | Schema-change agreements with app engineers; checks that block a load; dbt model contracts or tests analysts relied on | A sanitized contract doc, a check list or a schema-change policy | `[grounded]` background is silent on contracts; `[generic]` that contract ownership is typically a cross-team agreement and not just testing |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Reporting line and team unstated | unknown | — | "The posting names no hiring manager" (your note); JD: "Build and run the pipelines" | You may be one of few data engineers, or join an established team. The posting does not say | `[inferred]` from the JD's silence on reporting line and team | Who does this role report to, and how large is the data team today? | unresolved |
| RR2 | Broad build-and-run mandate, no success measures | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | Three layers plus running them may carry on-call or support load, and the JD gives no first-year outcomes | `[inferred]` from the three named layers and the silence on outcomes | What does success look like at 90 days and one year, and who is on call when a pipeline fails? | unresolved |
| RR3 | Equity size and terms unstated | unknown | — | "plus equity" | The grant, vesting and valuation could be anything, so the total package can't be priced | `[inferred]` from the JD naming equity with no figure | What is the equity grant for this level, and what are the vesting terms and latest valuation basis? | unresolved |
| RR4 | Pay stated and inside the reported band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The stated range is transparent and sits mid-to-upper in the report, so no seniority-pay mismatch appears | `[grounded]` JD figure against the Datawright report you supplied | Where in the range do offers for this role usually land? | noted |
| RR5 | Size and funding only on the employer's own pages | unknown | — | "264 employees. Series C ($52M, February 2026)" | The stated facts may be accurate, but both pages I fetched are the employer's own, so nothing independent corroborates them | `[grounded]` both fetched pages are pellucidlearning.com | Where is the data team growing after the February round, and what is this hire's budget tied to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the dbt project (about 180 models, Snowflake), the Great Expectations suite you set up, and Airflow orchestration in your top bullets, using your own wording and no added metrics | See R5, R7, R8 | `[grounded]` your stated background | pending your approval |
| E2 | Name Snowflake as your warehouse and do not list BigQuery as a skill or experience | See R9 | `[grounded]` your stated Snowflake-only history | pending your approval |
| W1 | Optional small dbt-on-BigQuery practice project, labelled as practice | See G1 | `[grounded]` G1 | pending your approval |
| Q1 | Ask the register questions RR1 to RR3 verbatim in interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm your location and pay floor against the posting before you invest effort | See R1, R2 | `[grounded]` gate rows | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported, so nothing has been confirmed with an artifact.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and searched "Pellucid Learning online tutoring Series C Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about). The employer exists as described and the posting is live with matching text. The contradictions row came back clean and the failed-attribution entry was not triggered. Both pages are the employer's own, hence RR5 |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand and fixes the market calibration and the pay mismatch check (RR4) |
| 3. Hiring manager's public footprint | n/a | No hiring manager is named, so no query could be formed |

I can write this up as `tuesday-dossier.md` whenever you'd like it.

## Upgrade menu

- Your CV, or a LinkedIn history → R3 to R8 get checked against what you actually wrote, and presentation gaps become visible.
- A sanitized dbt lineage, a Great Expectations suite structure, or a DAG list → R5, R7 and R8 can reach `high`, and R4 gets its inspectable artifact.
- Your location and pay floor → R1 and R2 resolve, and the decision becomes `go` or `no_go` on those terms.
- The hiring manager's name, once the recruiter has it → role reality's scope read and the plan's choice of story to lead with.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, public candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) → RR5 and the register get independent corroboration. Say the word and it runs.

## Questions

1. **R1 / R2:** Are you based in the US, or able to be in Denver, and what is your pay floor? A reply of "yes and yes" is enough.
2. **G2:** Have you owned ingestion from a product app or a CRM into your warehouse? If so, which sources, which tools, and what part was yours?
3. **G3:** Have you set up agreed schemas, SLAs or blocking checks with the people producing or consuming your data? If so, what did you own and what happened when a check failed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.