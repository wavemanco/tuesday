I'll read the skill's reference files before building the ledger.
Short version: I don't think keyword matching is the main problem. The bigger issue is that most of this JD's tools aren't on your resume, and I can't write them in for you. Below is what I can change honestly, what I can't, and the resume-parsing risks I can see from your description.

## The ATS premise

Content-based auto-rejection exists but looks uncommon. In one small vendor sample of 25 US recruiters, "We only saw 2 of 25 using it." (cite C25). The same source says "When automated filters are used, they're almost always knockout questions" (cite C26). Those are yes/no form questions such as work authorization or location, and a resume edit doesn't touch them. Where match scores exist they mostly decide who gets read first: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). That sample is small and from a résumé-builder vendor, so treat it as a lead and not a rate. That the scores run on keywords is an inference.

What this means for you: I'll place truthful keywords where your history already supports them, and I won't invent any. A resume that scores low on this JD is partly telling the truth. Whether this role is worth applying to is job-underwriter's question, and I haven't tried to answer it.

Assumptions I built on:
- Your resume text is what you pasted, including "never went to production".
- The JD doesn't tier its requirements, so I read priority from its order and its closing sentence.

## The edit ledger

resume_edits_pending_approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring, Kubernetes (two-month proof-of-concept, not in production)." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your PoC sentence; qualifier kept | pending your approval |
| E2 | Skills | "Bash and Python scripting" | "Python and Bash scripting" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` | pending your approval |
| E3 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | Two lines: "Built our deploy pipeline in Jenkins." and "Maintain about 30 Jenkins jobs." | `split` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` | pending your approval |
| E4 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged — moved to directly after the deploy-pipeline line, above "Maintain about 30 Jenkins jobs.")* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` | pending your approval |
| E5 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins. Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` | pending your approval |

- E1 and E5 put "Kubernetes" in two places a parser or reader will meet early. Both keep "not in production", because cutting it would make the claim bigger than your sentence.
- E5 is built from your own sentences and stays as three separate claims. "Last year" will go stale, so you may want a real date there. I haven't supplied one.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Kubernetes | must-have | `surfaced_by_edit` | E1, E4, E5. PoC only, and the line says so. | `[grounded]` PoC sentence; `[inferred]` priority from JD order |
| M2 | AWS EKS | must-have | `not_evidenced` | Resume says AWS (EC2, S3, RDS, IAM) and never says where the PoC ran. See C1. | `[grounded]` |
| M3 | Terraform | must-have | `not_evidenced` | Ansible is config management, a different kind of work. See C3. | `[grounded]` |
| M4 | GitOps / ArgoCD | must-have | `not_evidenced` | Nothing on the resume. See C1. | `[grounded]` |
| M5 | CI/CD pipelines | must-have | `surfaced_by_edit` | E3, E5. Your Jenkins deploy pipeline is the evidence. | `[grounded]` |
| M6 | GitLab CI | must-have | `not_evidenced` | Jenkins is not GitLab. Named absence below. | `[grounded]` |
| M7 | Python | important | `already_evidenced` | "Bash and Python scripting" is already there. E2 only reorders it. | `[grounded]` |
| M8 | Prometheus, Grafana, observability | must-have | `not_evidenced` | You have CloudWatch for monitoring. See C3. | `[grounded]` |
| M9 | SRE practices, platform reliability, developer experience | must-have | `not_evidenced` | Nothing on incidents, SLOs, on-call, or who uses your pipeline. See C2. | `[grounded]` |
| M10 | Helm | important | `not_evidenced` | See C1. | `[grounded]` |
| M11 | Istio / service mesh | important | `not_evidenced` | Named absence below. | `[grounded]` |
| M12 | Vault | important | `not_evidenced` | Named absence below. | `[grounded]` |
| M13 | Go | preferred | `not_evidenced` | Named absence below. | `[grounded]` |

## Recovery per gap

Recall prompts, where you may have something to pull:

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes depth: EKS, Helm, ArgoCD | must-have | A two-month PoC that never reached production. It doesn't say where it ran or with what tooling. | This JD's core stack is EKS, Helm and ArgoCD, so what the PoC used decides how much of it you can claim. | The PoC ran on EKS; you packaged something with Helm; you tried Argo CD or a pull-based deploy | A repo, README or architecture note from the PoC | `[grounded]` what the resume says and omits; `[generic]` what a platform JD weighs |
| C2 | SRE practices, reliability, developer experience | must-have | You built and maintain Jenkins pipeline and jobs, with no mention of who depends on them or of incidents. | The JD ends on owning reliability and developer experience, and nothing here speaks to either. | On-call or incident work; developers who use your pipeline; alerts you set up | A runbook, post-incident write-up or alert config | `[grounded]` what the resume omits; `[generic]` what screeners look for in such roles |
| C3 | IaC and metrics tooling: Terraform, Prometheus, Grafana | must-have | Ansible and CloudWatch are listed. Nothing is named for provisioning or dashboards. | Three named JD tools have no match on the resume. | Terraform used for any AWS resources; Prometheus or Grafana at work or in the PoC | A module, a dashboard export, a screenshot | `[grounded]` what the resume says; `[generic]` what screeners look for in such roles |

Named absences, where there's nothing to pull and I'm saying so plainly:
- **Go (M13).** Nothing on your resume. It's listed as a language alongside Python, not as the main one. Closing it takes building something small in Go and publishing it. Skip it if the rest of the stack matters more to you.
- **Istio / service mesh (M11) and Vault (M12).** Nothing on your resume. Closing either takes hands-on work, for example deploying a mesh or secret store on a cluster you control. That is weeks of effort, so I wouldn't prioritise it for one application.
- **GitLab CI (M6).** Jenkins covers the CI/CD idea, not the tool. Closing it takes rebuilding one pipeline in GitLab CI, which is a small project.

## Not written, and why

- **"Platform Engineer" as your title.** You're a DevOps Engineer. Retitling to the target role is an upgrade, not an equivalent.
- **"Production Kubernetes", or dropping "not in production".** Your own sentence says it never went to production.
- **"Infrastructure as code" or "Terraform-style" for Ansible.** Config management and provisioning are different kinds of work.
- **"Observability" for CloudWatch monitoring.** That's the JD's word for your history. You wrote monitoring.
- **"CI/CD" as a standalone claim.** You said you built a deploy pipeline and maintain Jenkins jobs. Whether those jobs include CI is ambiguous, so I took the reading that claims less.
- **EKS, Helm, ArgoCD, Istio, Vault, Prometheus, Grafana, GitLab, Go, SRE practices.** None appear in anything you've shown me. They stay as gaps until you tell me otherwise.
- **Hidden keyword blocks.** You didn't ask for one. I wouldn't write one, and it would be a line you couldn't defend if it were found.

## Parse-safety check

I only have your description, not the PDF. Checks I couldn't run: hidden text from a template (worth knowing about, since you may be carrying text you didn't write), file type and text layer, and section-heading names.

| Check | What I can observe | What breaks | What it costs |
|---|---|---|---|
| Multi-column layout | Two columns, per your description | Parsers read linearly and can interleave the columns | Dates may detach from the roles they belong to |
| Images, icons | An icon for each skill | Icons render as garbage characters or get skipped | Skills shown only as icons are absent |
| Content in the header | Contact details in the header | Headers can be discarded as page furniture | Your email and phone may be lost, and you become unreachable |

This is a report and not a redesign. If the header contact loss is real, it would explain silence even for roles where you do match.

## Upgrade menu

- **The PDF itself.** I could run the parse check on what a parser actually extracts, and check for hidden text you didn't author.
- **The PoC repo, README or architecture notes.** These would move M2, M4 and M10 from `not_evidenced` toward real rows if the PoC used them.
- **A Jenkinsfile or pipeline diagram.** This would back up the pipeline lines with something inspectable.
- **Prior resume versions.** They often contain evidence a later version dropped.
- **A runbook, alert config or dashboard screenshot.** This is the kind of proof that would carry M8 and M9.

Offer (not built unless you approve): a version of the resume reordered to lead with the Jenkins and Kubernetes evidence, for roles that name those tools. This engagement could use it, because your two strongest real matches are the pipeline and the PoC.

## Questions

C1 — When you ran the Kubernetes PoC, where did it run (EKS or something else), and did it use Helm or Argo CD?
C2 — Do developers outside your team depend on your Jenkins pipeline, and have you been on call or worked incidents for it?
C3 — Have you used Terraform, Prometheus or Grafana anywhere, even in the PoC or a personal project?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.