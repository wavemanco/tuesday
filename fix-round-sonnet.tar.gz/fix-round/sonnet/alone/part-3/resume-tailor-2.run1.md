I built this from your pasted background only: there was no resume document, no dossier and no earlier version. Your sentences are treated as self-report, and every "Current line" below is your wording from your message. Nothing is applied until you approve specific rows.

The honest shape of this application is that your resume supports analytics work with real data-engineering-adjacent pieces. It does not support "3+ years data engineering", which the JD lists as a must-have. The ledger reorders and surfaces what you have, and the gaps are named below instead of being written around.

## Edit ledger (resume_edits_pending_approval)

Pronouns ("I") are dropped in E1 to E5 to fit resume voice. E3's "breaks" becomes "broke" for tense. Nothing else in those lines was altered.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." Moved to first bullet. | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your background | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | "Built and maintained about 25 dbt models including the core orders mart." Moved to second bullet. | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your background | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke and added tests to it." Moved to third bullet. | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your background | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." Moved to fourth bullet. | `reorder` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your background | pending your approval |
| E5 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | Unchanged. Moved to fifth bullet. | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your background | pending your approval |
| E6 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail, moving into data engineering from analytics. Built and maintained about 25 dbt models including the core orders mart." Kept as two sentences. | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your background | pending your approval |

- **Job title:** your title stays "Senior Data Analyst". No row retitles it.
- **E3 and E4:** these two bullets keep your own limits ("fixed", "added tests", "some scripting"), so they can't turn into "owned pipelines".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Five years as an analyst, with adjacent work in E1 to E3. It is not data engineering experience, so the gap stays visible. See G1. | `[grounded]` your background; `[generic]` postings ask for this by years in role |
| R2 | Production Python | important | `not_evidenced` | E4 shows analysis Python and cron-scheduled API pulls. Nothing yet says they ran in production. See C2. | `[grounded]` your background |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | You have a nightly dbt job and cron scripts, and no Airflow. Whether the nightly job runs on a scheduler counts as "equivalent" is open. See C1. | `[grounded]` your background |
| R4 | Dimensional modelling | important | `surfaced_by_edit` | E1, E2. The star schema is for one mart, not the whole warehouse. | `[grounded]` your background |
| R5 | Build and own batch pipelines | important | `not_evidenced` | You fixed and tested the nightly job, and pulled vendor data on a cron. Building and owning pipelines is not stated. See C2. | `[grounded]` your background |
| R6 | Data quality and SLAs | important | `surfaced_by_edit` | E3 covers the tests. No SLA is stated anywhere. See C3. | `[grounded]` your background |
| R7 | Partner with analytics on requirements | important | `already_evidenced` | "Senior Data Analyst" plus E1's work with the then-DE. | `[grounded]` your background |
| R8 | Streaming, Spark, Kafka | preferred | `not_evidenced` | You have not used them. See G2. | `[grounded]` your background |

## Gap handling

**Recall-prompt rows** (the questions are asked once, at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | important | A "nightly dbt job" with no stated scheduler. | The JD names Airflow or equivalent, and "equivalent" is only claimable if something real schedules your jobs. | dbt Cloud jobs; a CI/CD scheduler; cron on a server; a job with dependencies or retries | The job config, a scheduler screenshot, a runbook | `[grounded]` the resume doesn't say what runs it; `[generic]` postings accept equivalents |
| C2 | Production Python; batch pipelines | important | Python "for analysis" and "some scripting" on a cron. | The JD's two most DE-shaped asks sit on this evidence. | Vendor pulls others depend on; failure alerts or retries; loading into Redshift; a script you wrote that someone else uses | The script repo, an alert or log, a short README | `[grounded]` the resume doesn't say who relies on them; `[generic]` screeners look for run-in-production evidence |
| C3 | Data quality and SLAs | important | Tests added to the nightly job. | Quality is evidenced and SLAs aren't. | A deadline the job had to meet; a freshness test; a consumer who depended on the mart by a set time | The dbt test config, a freshness check, a Slack thread | `[grounded]` tests only; `[generic]` DE postings pair quality with SLAs |

**Named absences:**

- **G1, 3+ years data engineering.** Your work is analytics with some pipeline-adjacent pieces, and that gap can't be closed by wording. What would narrow it is evidence that part of your last five years was pipeline work (C1 to C3), or a scoped-down target such as analytics-engineer roles. Whether this posting is worth applying to at all is job-underwriter's question, not this ledger's.
- **G2, Spark, Kafka and streaming.** You've never used them, and the JD lists streaming as a plus. A small personal project would be real, checkable evidence: for example, an Airflow DAG that runs your dbt build and an API pull, then a toy Kafka consumer. Until it exists, it isn't on the resume. If you skip it, you can still apply on the batch and modelling strengths.

## Not written, and why

- "3+ years of data engineering experience". Your title and years are analytics, and this is the JD's must-have.
- Any retitle such as "Analytics Engineer" or "Data Engineer". That's an upgrade, not an equivalent.
- "Built and owned batch pipelines". You fixed and tested the nightly job. Building and owning it is not what you wrote.
- "Production Python" or "production pipelines". Your sentence says analysis plus some scripting.
- "Orchestrated with Airflow-style scheduling" for the cron scripts. A cron is not orchestration unless C1 shows otherwise.
- "Modelled the warehouse". You designed one mart's star schema, with the then-DE.
- "Owned data quality and SLAs". You added tests, and no SLA appears.
- Anything on Spark, Kafka or streaming. You have never used them.

## Parse-safety check

The resume arrived as pasted text, so layout checks could not run: columns, tables, text boxes, icons or skill bars, header and footer content, section headings, and file type. Send the actual file and I'll run them. On what I can see, there is no hidden text, and the proposed lines are plain.

## Upgrade menu (proposal for later, nothing built yet)

These would raise your evidence from self-report to something inspectable:

- The actual resume file, for the parse checks and the exact wording to quote.
- The dbt project or a link to the orders mart and its tests.
- Your vendor-API cron scripts or a README for them.
- An older resume version, in case it has pipeline work this one dropped.

## Questions

C1. What actually runs your nightly dbt job (dbt Cloud, cron, a CI tool, Airflow-like something), and does it have dependencies or retries?
C2. Do the vendor-API scripts run unattended, and does anyone depend on their output or get alerted when they fail?
C3. Did the nightly job have a deadline or freshness expectation, and who relied on the mart by then?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.