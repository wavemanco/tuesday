I'll read the reference files the skill points to before building the ledger.
I can't make this resume match this JD by rewording it, and part of your guess is off. Below is a ledger of changes you can approve one by one, and nothing is applied yet.

**On the keyword theory.** The best evidence I have is thin. It's a vendor's interviews with 25 US recruiters, which the vendor calls themes rather than representative statistics. In it, "AI/content auto-rejection configured: 8% of recruiters" (cite C25), which is two people. Most automatic rejection came from forms: "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are work-authorization or location checks, and they're answered on the application form, not in your resume. Keywords may affect order: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). So I wouldn't treat this as a keyword-stuffing problem. The coverage map shows why: most of the JD's tools (V2, V3, V5, V8–V13) aren't in what you've told me, and no wording fixes that without claiming experience you don't have.

I haven't seen your file. I'm treating the sentences in your message as your resume text, and every quote below comes from them. Priority tiers are my reading, because the JD doesn't tier its list. The role is a Platform Engineer position at Ridgemount Health.

## The coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| V1 | Kubernetes, hands-on exposure | must-have | surfaced_by_edit | E2, E3, E4 carry the PoC with its "never went to production" qualifier intact | `[grounded]` |
| V2 | Running Kubernetes in production on AWS EKS | must-have | not_evidenced | The PoC never went to production and EKS isn't mentioned. See C1 | `[grounded]` |
| V3 | Terraform | must-have | not_evidenced | Ansible config management is a different kind of work. See N1 | `[grounded]` |
| V4 | CI/CD pipelines | must-have | surfaced_by_edit | E1 and E2 lift the Jenkins deploy pipeline. "CI/CD" isn't written because your sentence says deploy pipeline. See C2 | `[grounded]` |
| V5 | GitLab CI | important | not_evidenced | Only Jenkins is evidenced. See N2 | `[grounded]` |
| V6 | AWS | important | already_evidenced | "AWS (EC2, S3, RDS, IAM)" as written. EKS is V2 | `[grounded]` |
| V7 | Python | important | already_evidenced | "Bash and Python scripting" as written | `[grounded]` |
| V8 | Go | important | not_evidenced | Not on the resume. See N3 | `[grounded]` |
| V9 | Prometheus, Grafana, observability | important | not_evidenced | "CloudWatch for monitoring" stays as written, and "observability" isn't applied to it. See N4 | `[grounded]` |
| V10 | GitOps, ArgoCD, Helm | important | not_evidenced | Not on the resume. See N5 | `[grounded]` |
| V11 | Istio and service mesh | preferred | not_evidenced | Not on the resume. See N6 | `[grounded]` |
| V12 | Vault | preferred | not_evidenced | Not on the resume. See N7 | `[grounded]` |
| V13 | SRE practices and owning platform reliability | must-have | not_evidenced | Nothing on the resume about incidents, on-call, SLOs or reliability ownership. See C3 | `[grounded]` |
| V14 | Developer experience | important | not_evidenced | The pipeline you built is the nearest thing, but the resume doesn't say who uses it. See N8 | `[grounded]` |

## The edit ledger

`resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | Two lines: "Built our deploy pipeline in Jenkins." and "Maintain about 30 Jenkins jobs." | `split` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` | pending your approval |
| E2 | Experience | I can't see where these two sit in your file | *(unchanged text)* The Jenkins pipeline line and the Kubernetes proof-of-concept line move to the top two bullets of the role | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | Same line with "Kubernetes (proof-of-concept only)" added | `surface` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` | pending your approval |
| E4 | Summary | *(no current line, if your resume has none)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` | pending your approval |

- **E3:** this is the only place "Kubernetes" would reach a skills-section keyword scan, and the "(proof-of-concept only)" qualifier is what keeps it honest. If you'd rather not have the word in a skills list at all, reject it.
- **E4:** the three claims stay as three separate sentences, and the Kubernetes line keeps its qualifier. "Last year" is relative to whenever you wrote the resume, so check it still reads right today.

## Recovery per gap

Questions for these rows are in the closing block, tagged by row.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Running Kubernetes in production on AWS EKS (V2, with V10 and V9 if the PoC touched them) | must-have | A two-month proof-of-concept that "never went to production". It says nothing about where it ran or what it deployed. | Kubernetes and EKS lead the JD, and a PoC is the only evidence you have for them. | The PoC cluster ran on EKS; workloads deployed with Helm charts; Prometheus or Grafana ran inside it; a team demo or handover write-up | A repo, a design doc, a demo recording, PoC notes | `[grounded]` what the resume says; `[generic]` what a thin Kubernetes claim costs on postings like this |
| C2 | CI/CD pipelines (V4) | must-have | "Built our deploy pipeline in Jenkins". It establishes deployment and doesn't say whether it also builds or tests on commit. | "CI/CD (GitLab)" is on the JD's list, and I can't write "CI/CD" until the pipeline is shown to be both halves. | The Jenkins pipeline also runs builds or tests on commit; a Jenkinsfile you wrote | A Jenkinsfile or a pipeline screenshot | `[grounded]` what the resume says; `[generic]` why the literal term matters for matching |
| C3 | SRE practices and owning platform reliability (V13) | must-have | Nothing on reliability work. "CloudWatch for monitoring" is the nearest line. | The JD closes with "You will own platform reliability and developer experience". | Handling production incidents or on-call; writing a post-mortem; setting up alerts you responded to | A post-mortem, an alert config, an incident write-up | `[grounded]` what the resume says; `[generic]` what an absent reliability record costs on a role like this |

**Named absences**

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| N1 | Terraform (V3) | You have no Terraform on the resume, and Ansible config management is not a substitute. | A small Terraform-managed AWS stack in a public repo, after which it's a real project line | `[grounded]` |
| N2 | GitLab CI (V5) | Only Jenkins appears. | A GitLab CI pipeline for a side project, or moving one of your Jenkins jobs onto GitLab | `[grounded]` |
| N3 | Go (V8) | Nothing on the resume. | A small Go tool of your own, in a repo | `[grounded]` |
| N4 | Prometheus and Grafana (V9) | Only CloudWatch appears. | Prometheus and Grafana dashboards, which could come out of the C1 PoC if you rebuild it | `[grounded]` |
| N5 | GitOps, ArgoCD, Helm (V10) | Nothing on the resume. | ArgoCD syncing a Helm chart onto a local or EKS cluster, with a repo | `[grounded]` |
| N6 | Istio and service mesh (V11) | Nothing on the resume. For a preferred item, probably not worth closing for this application. | A lab cluster with Istio, if you want it for later roles | `[grounded]` |
| N7 | Vault (V12) | Nothing on the resume. Preferred, so not worth closing for this application. | A dev-mode Vault feeding secrets to a PoC workload | `[grounded]` |
| N8 | Developer experience (V14) | The resume doesn't say anyone else uses your pipeline. | A sentence from you on who uses it, and a number for how many | `[grounded]` |

## Not written, and why

- "Platform Engineer" as your title. You're a DevOps Engineer, and retitling to the target's title would be an upgrade, not an equivalent.
- "Production Kubernetes experience", "Kubernetes administration" or "orchestration at scale". Your own sentence says "never went to production".
- "CI/CD" or "GitLab CI/CD" for the Jenkins pipeline. You wrote a deploy pipeline, and Jenkins is not GitLab.
- "Infrastructure as code" or "Terraform" for Ansible. Config management is a different kind of work.
- "Observability", Prometheus or Grafana for CloudWatch. Monitoring in CloudWatch is what you wrote.
- "SRE practices", "owned platform reliability" or "developer experience". Nothing in what you gave me supports them.
- Any of ArgoCD, Helm, Istio, Vault, EKS, GitOps or Go dropped into the skills list as keywords. A tool listed isn't a tool owned.
- Hidden or white-text keyword blocks. I wouldn't write them in any case, since they'd be a line you couldn't defend, and recruiters have been found turning candidates down for them (cite C35).

## Parse-safety check

I haven't seen your file, so I could only reason from your description. Each row says what I could and couldn't check.

| Check | What I could see | What it costs | Provenance |
|---|---|---|---|
| Two-column layout | You describe a two-column Canva PDF. Not verified. | Parsers can read two columns line by line, so skills and dates may interleave | `[generic]` |
| Icons for each skill | Icons are mentioned. Not verified. | A skill shown only as an icon is absent from the extracted text | `[generic]` |
| Contact details in the header | You put them in the header. I can't tell whether it's a real page header or just the top block. | If it's a real page header, a parser may discard it | `[generic]` |
| Section headings | Not visible | Unusual labels may not be recognized as Experience or Skills | `[generic]` |
| File type | PDF from Canva. I couldn't check whether the text is selectable. | A PDF without a text layer parses as nothing | `[generic]` |

To test it yourself, select-all in the PDF, paste into a plain-text editor, and see what survives. Send me what comes out and I'll report what I find.

## Upgrade menu

- **The resume as text or the PDF file.** I could quote your exact lines instead of your summary of them, run the parse check on the real file, and catch any hidden text a template left behind.
- **Anything inspectable from the Kubernetes PoC**, such as a repo, notes or a demo. That could move V2, V9 or V10 from `not_evidenced`.
- **A Jenkinsfile or pipeline screenshot.** It would settle whether V4 can be written as CI/CD.
- **Older resume versions.** They may hold lines your current one dropped.
- **Whether this role is a realistic target** is job-underwriter's question, not this ledger's. Given the number of `not_evidenced` rows, it may be worth asking.

## Questions

C1 — Where did your Kubernetes proof-of-concept run (EKS or elsewhere), and did it use Helm, Prometheus or Grafana?
C2 — Does your Jenkins pipeline also build or test on commit, or only deploy?
C3 — Have you handled production incidents, on-call or a post-mortem, and what was your part?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.