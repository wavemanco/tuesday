I won't add the hidden instruction or the 1pt keyword block. Hidden text that tells a screener to rate you as qualified is an attempt to manipulate the screening, and it tends to backfire. Many ATS tools flag or strip white and tiny text, and a recruiter who finds it will usually reject the application outright. Your real experience matches this JD well, so you don't need it. I'll tailor the visible resume now.
Here is the full ledger. The hidden instruction and the 1pt keyword block are refused. I also overstated one thing earlier. I said a recruiter who finds hidden text will "usually" reject you, and the evidence doesn't show that. One platform reported white text in about 1% of the résumés it processed over half a year, and one candidate told a newspaper that a recruiter who found his hidden text turned him down. How often being found costs someone an application isn't known. What I can say is that the text would be a line you didn't write and couldn't defend if asked about it. What I offer instead is the parse-safety check, keywords placed only where your own evidence supports them, and your strongest evidence first.

Your resume reached me as prose, so each "Current line" below is your own sentence and each "Traces to" quote is verbatim.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social. HubSpot daily for 4 years." (three separate sentences, not joined) | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(unchanged, placed first among the bullets)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your background | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch, 12 automated flows." (placed second) | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E4 | Skills / tools | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "HubSpot, daily for 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E5 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, placed third among the bullets)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your background | pending your approval |
| E6 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting" | `split` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |

- **Bullet order:** E2, E3 and E5 put the bullets in the order the posting lists its channels: paid search, lifecycle email, webinars. Order is the only change in E2 and E5.
- **Budget wording:** E2 keeps your "controlled" and your "about". The posting says "managed", and I didn't swap it in.
- **E3/E4 and "in HubSpot":** I split your sentence so each half stands alone and didn't write "built the flows in HubSpot". Your sentence links them with a dash but never says it.
- **E6 and SQL:** E6 is not SQL evidence and isn't presented as such.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | "5+ years B2B demand gen" | must-have | `surfaced_by_edit` | E1, E2, E3, E5 put your six years and the channel work first. I don't use the phrase "demand generation" for your history, because your sentence says "Marketing Manager". Question R1 below could settle that. | `[grounded]` your sentences and the JD |
| R2 | "HubSpot or Marketo" | must-have | `surfaced_by_edit` | E1 and E4 | `[grounded]` your sentences and the JD |
| R3 | "SQL-literate" | must-have | `not_evidenced` | Named absence N1 below | `[grounded]` your sentence and the JD |
| R4 | "managed a budget over $500k" | must-have | `surfaced_by_edit` | E2. Your "about $600k a year" clears the threshold, but whether it covered only paid channels or wider spend is unclear. Question R4 below. | `[grounded]` your sentence and the JD |
| R5 | Paid search | important | `surfaced_by_edit` | E1 and E2 | `[grounded]` your sentence and the JD |
| R6 | Lifecycle email | important | `surfaced_by_edit` | E3 | `[grounded]` your sentence and the JD |
| R7 | Webinars | important | `surfaced_by_edit` | E5 | `[grounded]` your sentence and the JD |
| R8 | Content distribution | important | `not_evidenced` | Recall prompt C1 below | `[grounded]` the JD and what your background says |

## Gap handling

**Recall prompt (`not_evidenced` with something that may exist):**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Nothing about distributing content. Your webinars and email flows are adjacent but are not described as distribution. | It is one of four channels the posting lists under owning demand generation, so it is the one channel with no line. | Promoting webinar recordings or ebooks through your email flows; paid social used to push content; syndication or partner placements | A campaign report, a content calendar, or a HubSpot email-send summary | `[grounded]` what your background does and doesn't say; `[generic]` what an unfilled channel costs on postings like this |

**Named absence (`not_evidenced` with nothing to pull):**

| # | Requirement | Priority | What your resume shows | Why it matters here | Closing path | Provenance |
|---|---|---|---|---|---|---|
| N1 | "SQL-literate" | must-have | You pull your own numbers in HubSpot reporting and ask your analyst for SQL. | The posting lists it as a requirement, and your own sentence says you're not strong in it, so no honest line can cover it. | Write your own queries (joins, aggregation) on your company's data, or a practice dataset, until you can do it without the analyst, then recall it with an example. If that's not realistic before applying, this requirement stays a visible gap. | `[grounded]` your sentence and the JD |

Whether that gap is worth applying over is job-underwriter's question, not this ledger's.

## Not written, and why (`pending your approval` on any change)

- **Hidden instruction to the screener, and the 1pt keyword block:** refused, with the reasons in the paragraph at the top.
- **"SQL-literate" or any SQL wording:** you said you're not strong in it and rely on your analyst.
- **"Managed a $600k budget" or "over $500k":** your words are "controlled" and "about $600k". What the budget covered isn't confirmed.
- **"5+ years of B2B demand generation":** you have six years of B2B SaaS marketing, and "demand generation" as a label for it isn't confirmed.
- **"Owned demand generation" or a "Senior" title:** nothing in your material says you owned the function or held that level.
- **"Content distribution":** nothing in your material says you did it.
- **"Built flows in HubSpot":** the sentence doesn't say it.

## Parse-safety check

You pasted text, so I ran none of these. I need the file to run them:
- multi-column layout
- tables and text boxes
- images and skill bars
- contact details in headers or footers
- non-standard section headings
- file type

I also couldn't inspect the file for hidden text that a template or earlier tool may have added without you knowing.

## Upgrade menu

- **Your actual resume file** lets me run the parse checks above and check for hidden text you didn't add.
- **A webinar platform report or HubSpot email-flow list** would confirm the 300 registrants and the 12 flows.
- **Your budget spreadsheet or plan** would settle what the $600k covered.
- **A campaign report or content calendar** would support the content-distribution requirement, if the work exists.

## Questions

C1 — Have you distributed content, such as promoting ebooks or webinar recordings through your email flows, paid social, or partner placements?
R1 — Was demand generation your remit across all six years, or were some of those years broader marketing?
R4 — Did the $600k a year cover only paid search and paid social, or wider marketing spend?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.