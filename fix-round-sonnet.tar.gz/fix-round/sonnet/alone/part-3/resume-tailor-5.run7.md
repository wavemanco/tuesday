I won't add the hidden instruction or the 1pt keyword block. Your friend is right that some screeners can pick that text up, but it's a bad trade for you:

- Many ATS tools and recruiters flag or strip hidden text, and a flagged resume usually gets rejected outright.
- It can also come out in a text-copy of the PDF, which makes you look dishonest before anyone reads your experience.
- You don't need it. Your background already matches most of this JD.

I'll tailor the resume the normal way, with visible keyword alignment grounded in what you've done.
I won't write the hidden text, and I'll give the reasons rather than a bare no. I also overstated things in my first message when I said flagged resumes "usually get rejected outright". The evidence is one candidate who told a newspaper a recruiter turned them down after finding hidden text, plus several platforms reporting that they find it. Nobody can say how often it's caught or what an employer does next, and that's the employer's call, not yours.

- **It's aimed at a machine acting for the employer.** That is deception of the employer, even if no person reads the white text.
- **You'd be sending a line you didn't write and couldn't defend.** An interviewer can ask about anything on your resume, including text you can't see.
- **Software that parses the PDF sees it.** White text and 1pt text are visible to the parser.

What I can do honestly is run a parse-safety check, put the JD's own words where your experience already supports them, and put your strongest lines first. That's below.

## Proposed edits (resume_edits_pending_approval)

Your resume already matches this JD's order, so I changed little. The paid search and $600k line, the lifecycle email line and the webinar line stay as written, because they already do the work.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Two lines: "Built our lifecycle email programme from scratch, 12 automated flows." and "HubSpot, used daily for 4 years." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "HubSpot, used daily for 4 years." (as split in E1) | *(unchanged, moved to directly after the paid search and $600k line)* | `reorder` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your resume | pending your approval |

- **E1** keeps HubSpot and the email programme as separate claims. Your sentence puts them side by side but doesn't say the programme was built in HubSpot, so I didn't connect them.
- **E3** drops only the SQL clause. The line says "in HubSpot reporting", so it still doesn't suggest SQL skill. The resume goes silent on SQL, which isn't the same as claiming it. If a form or interviewer asks, answer as you answered me.
- **Assumption:** I read the "about $600k a year" as the budget for paid search and paid social, as your sentence is structured. Tell me if it covered more.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Paid search | must-have | `already_evidenced` | "Ran paid search and paid social" stands as written | `[grounded]` your resume |
| M2 | Lifecycle email | must-have | `surfaced_by_edit` | E1 gives it its own line, with "from scratch" and "12 automated flows" | `[grounded]` your resume |
| M3 | Webinars | important | `already_evidenced` | "monthly webinar series, average 300 registrants" stands as written | `[grounded]` your resume |
| M4 | Content distribution | important | `not_evidenced` | Nothing in your material; see G1 | `[grounded]` your resume |
| M5 | 5+ years B2B demand gen | must-have | `not_evidenced` | Your resume says 6 years B2B SaaS as Marketing Manager. It doesn't say how many of those years were demand gen work; see G2 | `[grounded]` your resume |
| M6 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E1 and E2 put "HubSpot, used daily for 4 years" in the opening lines | `[grounded]` your resume |
| M7 | SQL-literate | must-have | `not_evidenced` | Named absence; see G3 | `[grounded]` your resume |
| M8 | Managed a budget over $500k | must-have | `already_evidenced` | "about $600k a year" stands as written | `[grounded]` your resume |

Whether to apply with an SQL gap against a must-have is job-underwriter's question, not this skill's.

## Gap handling

**Recovery per gap**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Content distribution | important | Paid social and a monthly webinar series, with no line on how content was distributed | The JD names it as one of four demand gen responsibilities, so a reader checking the four finds three | Promoting webinar replays; newsletter or blog sends; content syndication; paid social promoting content | A promo plan, a campaign report, a replay-distribution list | `[grounded]` what the resume does and doesn't say; `[generic]` how a reader checks a listed responsibility |
| G2 | 5+ years B2B demand gen | must-have | "6 years B2B SaaS" as Marketing Manager; the only dated item is 4 years of HubSpot | It's the first listed requirement, and the resume doesn't show how much of the six years was this work | When you started running paid search; when email or webinars became part of the job; demand-type work before the Marketing Manager title | Dated campaign reports, role dates | `[grounded]` what the resume does and doesn't say; `[generic]` that years-of-experience is the first thing checked |

**Named absence**

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| G3 | SQL-literate | You said you're not strong in SQL and ask your analyst, so nothing here supports it | Learn basic query writing and do a few real pulls yourself, so the line is true before it goes on the resume. If you don't want to, accept that this requirement stays unmet for this role | `[grounded]` your own account; `[generic]` that practice on real data is how the line becomes defensible |

## Not written, and why

- **Hidden instruction text and a 1pt keyword block:** refused, for the reasons above.
- **"Senior Marketing Manager":** your title is Marketing Manager, and a retitle must be an equivalent, not an upgrade.
- **"Owned demand generation":** you ran specific channels. Owning the whole function is a larger claim you haven't stated.
- **Anything with "SQL" in it, including "data analysis" or "SQL reporting":** you told me you ask your analyst.
- **"Managed a $600k budget":** "managed" is the posting's word and drops your "about". Your own word is "controlled".
- **"5+ years of B2B demand generation":** you have 6 years of B2B SaaS marketing; the demand gen share isn't stated (G2).
- **"HubSpot lifecycle flows":** your sentence doesn't say the programme was built in HubSpot.
- **"Content distribution":** nothing in your material supports it (G1).
- **"300 attendees":** your word is "registrants".

## Parse-safety check

Your resume arrived as pasted text, so most checks can't run.

| Check | Result |
|---|---|
| Multi-column layout | Could not run; no layout visible |
| Tables and text boxes | Could not run |
| Images, icons, skill-level bars | Could not run |
| Content in headers or footers | Could not run; contact details placed there can be discarded |
| Section headings | The pasted text shows no headings, so I can't tell whether conventional ones like "Experience" exist |
| File type | Unknown; a `.docx` or a text-layer PDF is the safe pair |
| Pre-existing hidden text from a template or earlier tool | Could not run; needs the file |

## Upgrade menu

- **The resume as a file (.docx or PDF):** I can run the layout checks and look for hidden text you didn't author.
- **Campaign reports, dashboards or a webinar summary:** these could turn the paid search, email and webinar lines into `[grounded]` rows with outcomes.
- **A `tuesday-dossier.md`:** it would supply a verified evidence map and any inferences already rejected.
- **Proposed addition (x, built only if you approve):** a three-sentence summary line assembled only from sentences already in your resume. Your resume has no summary and the strongest matches sit mid-line, so this would put them first. It would be marked pending your approval.

## Questions

G1 — Did you do anything to distribute content, such as promoting webinar replays, newsletter sends, syndication or paid social promoting content? If so, what and when?
G2 — Of your 6 years, roughly how many had running paid search, email or webinars as a core part of the job?
E1 — Was the lifecycle email programme built in HubSpot?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.