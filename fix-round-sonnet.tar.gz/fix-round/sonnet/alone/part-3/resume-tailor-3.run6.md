I've built the full ledger below. Nothing is applied yet. I'm using the Tuesday dossier for the `evidence_map`, `rejected_inferences` and the pending edit E1, and I'm treating its Quartzline `role_profile` as the JD. Your CV came as prose, so the "current line" quotes are your sentences, not your document's layout. I haven't seen the real file.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own line (inherited from the dossier's E1, re-audited) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged — moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged — moved to the third bullet, after E2 and E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." as its own technical line, "Comfortable in" kept | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer and implementation lead at an enterprise software vendor for 7 years. Led 30+ client integrations of our REST APIs end to end. Wrote the internal integration playbook the whole team uses." Kept as three sentences. | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor"; "Led 30+ client integrations of our REST APIs end to end."; "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV | pending your approval |

- **E2 and E3:** only position changes. No "primary", "owned" or "product" language is added.
- **E4:** I kept "Comfortable in" because dropping it would turn comfort into ownership.
- **E5:** the summary opens with your real title and does not say "product manager".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years as a PM | must-have | `not_evidenced` | You've never held the title. The dossier rates this adjacent (transferability, medium). E1, E2 and E3 show the adjacent work and none of them claims PM years. | `[grounded]` your CV and the dossier's R1 |
| M2 | Shipped API or platform products | important | `not_evidenced` | The dossier rates this adjacent (medium). E2 shows you led client integrations of your vendor's APIs, which is not shipping them. | `[grounded]` your CV and the dossier's R2 |
| M3 | Technical fluency | important | `surfaced_by_edit` | E4, with E2 as supporting evidence | `[grounded]` your CV |
| M4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 show client-facing and product-facing work. The phrase "stakeholder management" is not used. | `[grounded]` your CV |
| M5 | Own the roadmap and prioritisation | important | `not_evidenced` | E3 shows roadmap input only. The dossier says ownership and prioritisation authority are not evidenced. | `[grounded]` your CV and the dossier |
| M6 | Discovery with integration partners | important | `surfaced_by_edit` | E3. Your counterparts were clients, not partners, and the line keeps that word. | `[grounded]` your CV |
| M7 | Specs and delivery with two engineering squads | important | `not_evidenced` | Comfort with OpenAPI specs (E4) is not product specs or delivery ownership. | `[grounded]` your CV |
| M8 | Define adoption metrics | important | `not_evidenced` | Nothing in your material covers it. | `[grounded]` your CV |

## Gap handling

| # | Requirement | Priority | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership and prioritisation (M1, M5) | must-have | Quarterly sessions that collected client feedback "for product". Nothing about who decided what was built. | The dossier already flags this as the weakest point of fit. | Ranking client requests for the product team; arguing a client-requested API change onto a release; a decision log from the sessions | Session notes, a ranked request list, a release note citing a client request | `[grounded]` what your CV says; `[generic]` what this costs on PM applications |
| C2 | Shipped API work and specs with engineers (M2, M7) | important | Led integrations of your vendor's REST APIs; comfortable with OpenAPI specs. No spec or release you wrote is stated. | The role is spec-and-delivery work with two squads. | An OpenAPI spec or change request an engineering team built from; a deprecation notice you drafted; beta testing you coordinated | The spec, a ticket thread, a release note | `[grounded]` what your CV says; `[generic]` what this costs on PM applications |
| C3 | Adoption metrics (M8) | important | No metric of any kind is stated. | The role asks you to define adoption metrics. | Integration go-live counts; time from kickoff to first live call; share of clients on a given endpoint | A dashboard, a spreadsheet, a QBR slide | `[grounded]` what your CV says; `[generic]` what this costs on PM applications |

**Named absence — M1, the title.** You have never held a PM title, and the 3+ years of PM experience is a must-have. Evidence of PM-type work under another title (C1 and C2) could narrow that gap, but it won't make the years literal. That's why the dossier says `conditional_go`. I haven't written around it.

## Not written, and why

- **"Product Manager" or any retitle of your role.** You have never held the title, and I only retitle to an equivalent, not an upgrade.
- **"3+ years of product management."** There is no PM role in your history.
- **"Owned the roadmap".** You ran sessions that fed product, and E3 stays at that.
- **"Shipped API products".** You led client integrations of APIs your vendor shipped. That's a different side of the work.
- **"Partnered with integration partners" / "partner discovery".** The JD says partners and you say clients. You also worked vendor-side, so the word would shift which side of the table you sat on.
- **"Wrote specs and drove delivery with engineering".** Being comfortable with OpenAPI specs doesn't show you wrote product specs or drove delivery.
- **"Defined adoption metrics" and "managed stakeholders".** The first has no support in your material. The second borrows the JD's phrase for your history.
- **Dossier rejected inference, unaltered:** "built an internal request-triage tool — memory lead, candidate could not confirm ownership".
- **Dossier rejected inference, unaltered:** "has been the customer of a partner API platform — candidate worked vendor-side".

## Parse-safety check

Your CV arrived as pasted prose, so I couldn't run the layout checks: multi-column layout, tables and text boxes, images and icons, header and footer content, and file type. Section headings are the only check I can speak to. When the rows are applied I'd use conventional labels, for example Summary, Experience, Skills. I haven't redesigned anything.

## Upgrade menu (offered, not built)

- **Your actual CV file** would let me run the parse checks and quote your real lines instead of your message's sentences.
- **Artifacts** such as the integration playbook, an OpenAPI spec or the roadmap-session notes would turn some `not_evidenced` rows into grounded ones.
- **Answers to C1–C3** are the most valuable input. Each answer comes back as a confirmation card before any row is written.

## Questions

C1 — Did you ever rank or argue for which client requests made it into product's plans, and if so, what was your role in the decision?
C2 — Did you write or contribute to an API spec, change request or release that engineering built from?
C3 — Did you track anything like go-live counts or time-to-first-call across your integrations?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.