Here's the tailoring ledger for Quartzline. I built it from your pasted CV, which has no separate lines, so "moved" below means relative to the order you gave me. From the dossier I used `role_profile` as the JD, R1 and R2 from `evidence_map` (their `adjacent` / `medium` judgments carry over unchanged), the pending edit E1, and both `rejected_inferences`. I used `decision: conditional_go` only as context. The dossier excerpt doesn't cover the JD's technical-fluency or stakeholder items, so I derived those two from your CV.

Nothing is applied. Every row is `pending your approval`.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (one sentence among the others) | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses."; dossier E1: "surface the integration playbook authorship into its own line" | `[grounded]` your CV; inherited from the dossier and re-audited | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to sit after E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved to sit after E3)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." (kept as two sentences) | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |

- **E1** keeps "the whole team", with no widening to company-wide.
- **E2** keeps "30+" attached to integrations, and "our REST APIs" stays as written.
- **E3** and **E4** change position only. I did not turn "feedback for product" into roadmap ownership, or "comfortable in OpenAPI specs" into having written them.
- **E5** states your real title up front, with no PM wording, so a reader sees the adjacent background accurately.

## Coverage map

Here "Where it lands" is where the requirement is met or missed, and any nuance goes in that column. Row IDs R1–R2 follow the dossier. Rows R3–R8 are derived from the JD.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Dossier: "integration leadership is adjacent; roadmap ownership and prioritisation authority not evidenced". E1–E5 show the adjacent work, and you wrote "Never held a PM title." Confidence stays medium. | `[grounded]` dossier evidence_map and your CV |
| R2 | Shipped API or platform products | important | `not_evidenced` | Dossier: adjacent, medium. You led client integrations of REST APIs (E2). Nothing in the CV says an API product or change of yours shipped, so E2 makes no such claim. | `[grounded]` dossier and your CV |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4 and E2. Tools are self-reported as "comfortable", and the REST integrations are the stronger evidence. | `[grounded]` your CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2, E3 and E1 show client-facing and product-facing work. Working with engineering squads is not evidenced (see R7). | `[grounded]` your CV |
| R5 | Run discovery with integration partners | important | `surfaced_by_edit` | E3 only, and partially. Your sessions were with clients and collected feedback. They were not with integration partners, and you did not decide what got built. | `[grounded]` your CV |
| R6 | Own the roadmap | important | `not_evidenced` | Covered by the R1 gap and recall prompt C1. | `[grounded]` dossier and your CV |
| R7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | Nothing in the CV shows specs written or delivery driven with engineers. "Comfortable in OpenAPI specs" is not authorship. See C2. | `[grounded]` your CV |
| R8 | Define adoption metrics | important | `not_evidenced` | "30+ client integrations" is a count of work you led, not an adoption metric. See C3. | `[grounded]` your CV |

## Gap handling

| # | Requirement | Priority | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap and prioritisation authority | must-have | "Ran quarterly roadmap-input sessions collecting client feedback for product." This shows you collected feedback. It does not show you influenced or decided what was built. | The dossier names this as the exact missing piece under the must-have, and a screener reads it to tell adjacent from direct. | A feedback theme product acted on; a client request you carried to product and what came of it; a priority you argued for | Session notes, a product doc citing your input, a release note | `[grounded]` what the CV and dossier say; `[generic]` how it reads to a screener |
| C2 | Shipped API products and specs | important | You led integrations of the REST APIs. No API change, spec or doc of yours is shown reaching release. | Dossier R2 is adjacent at medium confidence. A confirmed example is what could lift it. | An API change or fix request you wrote up that engineering shipped; an OpenAPI spec you edited or wrote; a changelog entry you drove | Ticket, spec file, changelog | `[grounded]` the CV and dossier; `[generic]` what it costs on API-platform PM applications |
| C3 | Adoption metrics | important | "30+ client integrations" counts what you led. Nothing shows how clients used the API afterwards. | The role's job includes defining adoption metrics, and the CV currently has none. | A count of live integrations you tracked over time; time to go live; a usage report you passed to product | The report, a spreadsheet, a dashboard | `[grounded]` the CV; `[generic]` what the role asks of adoption metrics |

Named absences:
- **PM title and years.** You have never held a PM title, and 3+ years is the must-have. No edit closes that. At most, answers to C1–C3 would show more PM-shaped work, and the years requirement would still stand as an adjacent-experience case. Whether that is worth pursuing is the underwriter's decision, which the dossier already marks `conditional_go`.
- **Two engineering squads.** Nothing in the CV mentions delivery with engineering teams. A confirmed answer to C2 could cover part of this, and otherwise it stays a gap.

## Not written, and why

Pending your approval, like the rows above.

- "Product Manager" or "3+ years PM experience": you never held the title and the JD makes it a must-have.
- "Owned the roadmap" or "roadmap ownership": your sessions collected feedback for product. The dossier marks ownership and prioritisation authority as not evidenced.
- "Ran discovery with integration partners": the posting says partners and your sessions were with clients. That would change which side of the table you sat on.
- "Shipped API products" or "launched an API platform": you led client integrations of REST APIs, which is different work from shipping the API.
- "Wrote or authored OpenAPI / API specs", or "wrote specs": your CV says "comfortable in", not authored.
- "Drove delivery with engineering squads", "defined adoption metrics", "drove adoption": nothing in the CV supports any of them.
- From the dossier, unaltered: "built an internal request-triage tool — memory lead, candidate could not confirm ownership".
- From the dossier, unaltered: "has been the customer of a partner API platform — candidate worked vendor-side".

## Parse-safety check

Your CV arrived as pasted text, so I could not run any of these checks:
- multi-column layout
- tables and text boxes
- images or skill bars
- content in headers or footers
- section headings
- file type

I could not inspect for hidden text either. If you send the actual file (.docx or a text-layer PDF), I can run all of them and also swap my assumed "current lines" for your real ones.

## Upgrade menu

These are x offers, built only if you say yes:
- **Answer C1–C3.** Each confirmed answer becomes a new row, and C1 is the one most likely to move the must-have.
- **Send the CV file.** This gives a real parse-safety check and exact current lines.
- **Send work samples.** The playbook (even an excerpt) or an OpenAPI file would turn E1 and E4 from self-report into inspectable evidence.

C1 — In the quarterly roadmap-input sessions, did any client feedback you collected change what product built, and what was your part in that?
C2 — Have you written or edited an API spec, requirement or change request that engineering then shipped?
C3 — Did you or your team track how clients used the API after go-live, such as number live, time to go live, or usage?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.