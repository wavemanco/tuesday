I'll read the reference files the skill points to before building the ledger.
Your premise needs one correction before the edits. It's a common worry, but the evidence doesn't support it as stated.

**The keyword-rejection premise.** In the one sample available, a vendor interview study of 25 US recruiters, only 8% (two people) said they had content-based auto-rejection configured. The same study says that when automated filters are used, they're "almost always knockout questions": yes/no checks on work authorization, licences or location, answered in the application form rather than the resume. Where match scores exist, they mostly decide who gets reviewed first, and 56% of those recruiters ignore the feature or don't have it. The sample is small, so I can't say how rare keyword rejection really is. Keywords may still affect ranking, so the work below is worth doing. It just may not be the whole explanation.

Everything below is built from your own message. I only have your summary, not the resume text, so each "current line" is your wording. Nothing is applied yet.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(no line I can see)* | "Kubernetes (two-month proof-of-concept, not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your summary | pending your approval |
| E2 | Skills | "Bash and Python scripting" | "Python (scripting)" and "Bash (scripting)" as two separate items | `split` | "Bash and Python scripting" | `[grounded]` your summary | pending your approval |
| E3 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | "Built our deploy pipeline in Jenkins" and, as its own bullet, "Maintain about 30 Jenkins jobs" | `split` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your summary | pending your approval |
| E4 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Docker, Kubernetes (two-month proof-of-concept, not in production), Python (scripting), Bash (scripting), Jenkins, Ansible for config management, CloudWatch for monitoring." (assumes E1 and E2 are approved) | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your summary | pending your approval |

- **E1** keeps "not in production". Dropping it would turn a proof-of-concept into production experience, and a Kubernetes question in an interview would expose that straight away.
- **E3** deliberately does not say "CI/CD". You described a deploy pipeline in Jenkins, and the JD asks for GitLab CI/CD. Putting the JD's term on your history would be borrowing its vocabulary.
- **E4** only moves items. It adds no claim.

## Coverage map

I treated the JD as unranked: it is a tools list with one duty sentence. The priorities below are my reading, not the posting's.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E1 and E4. It is a proof-of-concept only, so this is weak evidence | `[grounded]` your summary |
| R2 | AWS EKS | must-have | `not_evidenced` | Your summary says nothing about EKS. See C2 | `[grounded]` your summary |
| R3 | AWS | important | `already_evidenced` | "AWS (EC2, S3, RDS, IAM)" | `[grounded]` your summary |
| R4 | Terraform | must-have | `not_evidenced` | Ansible is adjacent but isn't Terraform. See C1 | `[grounded]` your summary |
| R5 | ArgoCD, GitOps, Helm | important | `not_evidenced` | Nothing in your summary. See C2 for the proof-of-concept | `[grounded]` your summary |
| R6 | Istio, service mesh | important | `not_evidenced` | Named absence below | `[grounded]` your summary |
| R7 | Prometheus, Grafana, observability | important | `not_evidenced` | CloudWatch is monitoring but not these tools. Named absence below | `[grounded]` your summary |
| R8 | Vault | important | `not_evidenced` | Named absence below | `[grounded]` your summary |
| R9 | CI/CD (GitLab) | important | `surfaced_by_edit` | E3. This is Jenkins, not GitLab | `[grounded]` your summary |
| R10 | Python | important | `surfaced_by_edit` | E2 and E4 | `[grounded]` your summary |
| R11 | Go | preferred | `not_evidenced` | Named absence below | `[grounded]` your summary |
| R12 | SRE practices, owning reliability and developer experience | must-have | `not_evidenced` | Nothing in your summary. See C3 | `[grounded]` your summary |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform | must-have | Ansible for config management, no infrastructure-as-code tool named | The JD lists it and the duty is owning the platform, so its absence is visible | Terraform modules for AWS resources; importing existing infrastructure into Terraform; a Terraform pipeline step | A repo, a PR, a module README | `[grounded]` what the resume says; `[generic]` how a missing listed tool is read |
| C2 | EKS, GitOps and Helm in the Kubernetes proof-of-concept | must-have | A two-month proof-of-concept with no stack detail | If the proof-of-concept used EKS, Helm or a GitOps tool, that would move R2 and R5 | Cluster built on EKS; charts written or used; manifests deployed from Git | A design doc, a repo, a write-up of the proof-of-concept | `[grounded]` what the resume says; `[generic]` how detail changes a proof-of-concept line |
| C3 | SRE practices and owning reliability | must-have | CloudWatch for monitoring, about 30 Jenkins jobs maintained | The duty sentence is "own platform reliability and developer experience", and nothing yet speaks to it | On-call rotation; alerts you wrote or tuned; incident reviews; helping developers with the deploy pipeline | An alert config, an incident write-up, a runbook | `[grounded]` what the resume says; `[generic]` what a duty sentence signals |

**Named absences, and what would close each:**
- **Istio and service mesh:** nothing in your history touches this. Closing it takes hands-on work, for example a small cluster with a mesh you configure yourself, after which it becomes real evidence.
- **Prometheus and Grafana:** CloudWatch is your monitoring experience. Closing it takes running both against something you operate, a work service or a personal cluster.
- **Vault:** there's no related work in your summary. A small project that stores and reads secrets from Vault is a realistic way to close it.
- **Go:** same shape, so a small tool written in Go would close it. It's the lowest priority here.

Taken together, five of the must-haves and important items are `not_evidenced`, and Kubernetes rests on a two-month proof-of-concept. No wording change fixes that. Whether the role is worth applying to as it stands is job-underwriter's question, and I'd run it before you spend more time tailoring.

## Not written, and why

- **"Platform Engineer" as your title:** you hold "DevOps Engineer, 4 years", and the JD's title isn't an equivalent of it.
- **"Production Kubernetes" or "orchestrated containers at scale":** your proof-of-concept never went to production.
- **"Terraform", "GitOps", "Helm", "ArgoCD", "Prometheus", "Grafana", "Istio", "Vault", "Go":** none appears in your material. Adding them to a skills list is the keyword stuffing you were hoping for, and an interviewer would test it in the first question.
- **"CI/CD (GitLab)":** you have Jenkins. Writing GitLab would be a different tool.
- **"Owned platform reliability" or "improved developer experience":** nothing you wrote says you did either.
- **Hidden keyword text (white-on-white and similar):** not written, and I won't write it. It deceives the employer's own software, and it puts a line on your resume that you didn't write and couldn't defend. It can also be found, because the parsers that read it are the ones that flag it. The legitimate version is the parse-safety fix below plus the evidenced keywords in E1 to E4.

## Parse-safety check

I haven't seen the file, so this rests on how you described it. These are risks, not design advice.

| Check | What I found | What it costs |
|---|---|---|
| Two-column layout | Present, per your description | Parsers read linearly, so skills can interleave with job text and dates can detach from roles |
| Icons for each skill | Present | Icon-only information is skipped or becomes garbage characters, so it's absent to the parser |
| Contact details in the header | Present | Header content is often discarded as page furniture, which can leave you unreachable |

A Canva PDF may or may not have a selectable text layer, and I can't tell from here. I also couldn't check section headings, hidden text or the file type. A text-layer PDF or a `.docx` is the safe pair. If you send me the file or the pasted text, I can run those checks.

## What would sharpen this

- **Your full resume text.** I only have your summary, so every quote above is from that. The real wording could change the rows.
- **Details of the Kubernetes proof-of-concept**, such as a doc, repo or write-up.
- **Any Terraform, alerting or on-call material**, even from side projects.

## Questions

C1 — Have you written any Terraform, at work or on your own, even a small module or one imported resource?
C2 — What did your Kubernetes proof-of-concept run on, and did it involve EKS, Helm charts or deploying from a Git repo?
C3 — Have you done on-call, written or tuned alerts, or run an incident review, and if so, what?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.