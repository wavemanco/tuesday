I've built your tailoring ledger below. Your CV is already close to this JD, so I made four edits and left the rest alone. Nothing is applied until you approve specific rows.

Your bullets already run in the order the JD does: services and volume, then p99, then on-call and incidents, then onboarding. So there are no `reorder` rows.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years, currently at a payments company. Go and Rust daily for 4 years, Python before that. Own three services in the ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Two bullets: "On-call rotation every fourth week for two years." and "Run six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |
| E4 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Go, Rust, Kafka, Postgres, Terraform, gRPC, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV | pending your approval |

- **E1:** the summary stays as three separate sentences, so "7 years" is not stretched into "7 years of backend". It also doesn't say the three services are written in Go, because your CV doesn't say which language they use.
- **E2:** splitting puts "incident commander" on its own line, which is what the JD's incident-response requirement looks for. The split doesn't assert that the six incidents happened during those two on-call years, or that the rotation covered your own services.
- **E3:** "onboard" and "pairing" are your words. I did not write "mentor", because the JD says mid-level engineers and your CV doesn't say the hires' level.
- **E4:** this moves Go and Rust into the skills line so keyword scanning can find them. It adds no tool you didn't already list.
- **Unchanged:** the 40k requests/minute line and the 380ms to 95ms p99 line already say what they need to.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1. Your CV says 7 years as a Senior Software Engineer and ledger-pipeline services, but never the word backend or how many of the 7 years were backend. | `[grounded]` your CV |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1 and E4. Four years of daily Go is stated. Which language the three services use is not. | `[grounded]` your CV |
| R3 | Services handling high request volume | must-have | `already_evidenced` | Unchanged line: "one handles about 40k requests/minute at peak". | `[grounded]` your CV |
| R4 | Distributed systems at scale | must-have | `not_evidenced` | Gap row C1. Kafka sits in a tools list with no description of how it's used. | `[grounded]` your CV |
| R5 | Strong incident response | must-have | `already_evidenced` | The CV already says six incidents as incident commander. E2 gives it its own line. | `[grounded]` your CV |
| R6 | Experience mentoring | must-have | `surfaced_by_edit` | E3. It shows onboarding and pairing for a first month. It does not show mentoring mid-level engineers. | `[grounded]` your CV |
| R7 | Drive down p99 latency | important | `already_evidenced` | Unchanged line: 380ms to 95ms on the balance-read path. | `[grounded]` your CV |
| R8 | Own on-call for your services | important | `already_evidenced` | E2. Your CV says "every fourth week for two years", and doesn't say the rotation covers only your three services. | `[grounded]` your CV |
| R9 | Design and ship Go services | important | `not_evidenced` | Gap row C3. Your CV says you "own" the services, not whether you designed or built them. | `[grounded]` your CV |
| R10 | Partner with product on roadmap sequencing | important | `not_evidenced` | Gap row C2. Nothing in your CV touches product or roadmap work. | `[grounded]` your CV |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Three services in one pipeline, one at about 40k requests/minute, and Kafka in a tools list. It never says what Kafka does in the pipeline or how the services depend on each other. | This is a must-have, and a reader can't tell from the CV whether it's met. | Kafka between your services; retries or idempotency on ledger writes; handling a service or dependency failing mid-pipeline | A design doc, an architecture diagram, or a postmortem that shows the service boundaries | `[grounded]` what the CV does and does not say; `[generic]` what an unmet must-have costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | Nothing about product or roadmap work. | The role lists this as a core duty, and nothing on your CV speaks to it. If the honest answer is none, that is a gap to leave visible rather than word around. | Deciding with a PM which of several projects goes first; pushing back on or re-ordering a roadmap item for technical reasons; scoping a project with product | A planning doc, a roadmap thread, or a project brief | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Design and ship Go services | important | "I own three services". It doesn't say whether you designed and built them or took them over, or which language they use. | "Own" and "design and ship" are different claims, and I won't write the second from the first. | Building one of the three from scratch; a major redesign of one; a service you launched | A design doc, a launch note, or repo history | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |

## Not written, and why

- **"7 years of backend experience":** your title says Software Engineer, and the CV doesn't say how many of the 7 years were backend.
- **"Mentored mid-level engineers":** your CV says you onboard new hires and pair with them. The word "mentor" and the level "mid-level" are the JD's, not yours.
- **"Designed and shipped Go services":** your CV says you own them. It says nothing about designing them or which language they use.
- **"Distributed systems experience":** this is the JD's own phrase. Kafka in a tools list doesn't show it.
- **"Owned on-call for my services":** your CV says you were on a rotation every fourth week. It doesn't say the rotation was limited to your services.
- **"Partnered with product":** nothing in your CV supports this.
- **"High-volume Go services":** this would put your 40k requests/minute figure on Go before we know the services are Go.

## Parse-safety check

You sent plain text, so I could not check layout. That covers multi-column layouts, tables and text boxes, images or skill bars, content in headers or footers, and the file type. If you send the actual file, I'll run those checks. One check I could run: your section names, such as Summary, Experience and Skills, are standard ones that parsers recognize.

## Upgrade menu

These are offers, and I'd build them only if you ask.

- **A link or file for the p99 work:** a Datadog before/after graph or design doc would let me raise the p99 claim from your word alone to a documented one.
- **A sanitized postmortem from an incident you commanded:** it would back the "incident commander" line with something checkable.
- **Any earlier version of your CV:** earlier versions often hold evidence that a later edit dropped.

## Questions

C1 — How does Kafka fit into your ledger pipeline, and how do your three services depend on each other?
C2 — Have you worked with product on what to build or in what order? If so, what's one example?
C3 — For the three services you own, did you design and build any of them, and which language are they written in?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.