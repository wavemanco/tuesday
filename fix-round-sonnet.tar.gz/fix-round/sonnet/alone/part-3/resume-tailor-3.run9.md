I've built the ledger from the CV you gave me and the dossier. Nothing is applied yet. Every row is `pending your approval`, and the tailored CV is only produced once you approve rows.

**Assumptions:**
- I treated each sentence you gave me as its own CV line, in the order you listed them. I haven't seen the real layout or any file, so tell me if a line sits somewhere else.
- The dossier matches this role and decision (`conditional_go`), so I used it as is. Its pending edit E1 is carried in as row E1 and was audited again like the others. Its two rejected inferences go straight into the prohibited list.
- None of the edits retitles you. You never held a PM title, and the ledger doesn't hint that you did.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own separate line, wording unchanged | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV; inherited from dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second bullet, directly after E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Experience or Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved up to sit after the playbook line from E1, if it is currently a low skills line)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |

- E1: if the playbook is already its own line on your CV, this row does nothing.
- E2: the "30+" stays attached to client integrations. It does not become a count of APIs or products.
- E2 and E3: both keep your exact words. "Led" and "Ran" stay as written, and neither line gains a roadmap or discovery claim.
- E4: it stays "Comfortable in", not "expert in". Having a tool listed is not the same as owning a product spec.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Dossier has this as adjacent, transferability gap, medium confidence. E2, E3 and E1 are the adjacent work. Roadmap ownership and prioritisation authority aren't evidenced. See C1. | `[grounded]` your CV and dossier evidence_map |
| R2 | Shipped API or platform products | must-have | `not_evidenced` | Dossier has this as adjacent, medium. E2 shows you led client integrations of your employer's REST APIs, not that you shipped one. See C2. | `[grounded]` your CV and dossier evidence_map |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4, with E2 | `[grounded]` your CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 carry the client-facing work. Your CV doesn't use that phrase, so I haven't written it. | `[grounded]` your CV |
| R5 | Run discovery with integration partners | important | `surfaced_by_edit` | E3. Those sessions were with clients, not integration partners, and "discovery" is the JD's word, not yours. | `[grounded]` your CV |
| R6 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | Nothing on your CV covers product specs or squad delivery. OpenAPI fluency is not the same thing. See C3. | `[grounded]` your CV |
| R7 | Define adoption metrics | important | `not_evidenced` | Named absence, below. | `[grounded]` your CV |

**Named absence, R7:** Nothing on your CV says you defined or tracked adoption measures. To close it, you'd need a real example of one you set or tracked, even informally, such as how many of the 30+ integrations went live or stayed active. If there isn't one, it's best carried as a known gap for this role.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM | must-have | 7 years in solutions engineering and implementation, with quarterly roadmap-input sessions. No PM title, and no statement of who decided what got built. | It's the must-have, and the dossier already flagged prioritisation authority as the unevidenced part. | A time you decided or argued which client request went to product first; a roadmap item you pushed through; a trade-off you made between clients' asks | A roadmap doc, a prioritised feedback list, a product ticket you authored | `[grounded]` what the CV does and doesn't say; `[generic]` must-have gaps usually decide whether a CV is read closely |
| C2 | Shipped API or platform products | must-have | You led integrations of your employer's REST APIs and used OpenAPI specs. It doesn't say you built or released any API or API feature. | It's the second must-have, and "led integrations" can read as consumer-side work. | An API feature or endpoint you helped define or test before release; a partner-facing integration pattern that became standard; OpenAPI work that fed the product | An OpenAPI spec you contributed to, a release note, a changelog | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs on applications of this kind |
| C3 | Write specs and drive delivery with two engineering squads | important | OpenAPI fluency and an integration playbook. No product spec, and no work with engineering squads on delivery. | The role centres on this, and a CV with no trace of it gets read as implementation-side only. | Requirements you wrote that engineering built from; a fix or feature you chased through engineering for clients; a cross-team delivery you coordinated | A spec, a ticket thread, a launch checklist | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs on applications of this kind |

## Not written, and why

- "Built an internal request-triage tool". The dossier rejected this because it was a memory lead and you couldn't confirm you owned it.
- "Has been the customer of a partner API platform" and "you know this from the partner's side". The dossier rejected this because you worked vendor-side, so it would flip which side of the table you sat on.
- "Product manager" in any title or summary. You never held the title, and R1 is a must-have, so the gap is named, not papered over.
- "Owned the roadmap" or "set priorities". Your line says you ran sessions collecting feedback, and that is a different kind of work.
- "Shipped API products". You led integrations of existing APIs, and shipping a product is a different job.
- "Partnered with integration partners" and "ran discovery". Your word is "clients" and your activity is feedback sessions, which are different relationships and activities.
- "Managed stakeholders". That's the JD's phrase. Your line is client integrations.
- "Wrote product specs" and "defined adoption metrics". Nothing on your CV supports either, and OpenAPI fluency is not product-spec authorship.

## Parse-safety check

I could not run the layout checks, because the CV came as pasted prose and not a file. That means multi-column layout, tables or text boxes, icons or skill bars, contact details in headers or footers, and file type are all unchecked. Section headings are also unchecked, though you could name them standard (Experience, Skills). I found no hidden text, but I couldn't inspect a file for it either.

## Upgrade menu (offered, built only on approval)

- **The CV as a file:** this would let me run the parse-safety and hidden-text checks for real, and see where lines actually sit.
- **The integration playbook itself, or a section of it:** it's an inspectable artifact that could raise confidence in E1 and support C3.
- **An older CV version:** it might hold evidence the current one dropped.
- **A summary section:** I could draft one built only from your existing sentences, as its own row.

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

C1 — Have you ever decided which client request got into product's queue ahead of others, or pushed a specific item onto the roadmap? If so, what was it?
C2 — Did you help define, test, or release any API feature or endpoint your company shipped, beyond integrating it for clients?
C3 — Have you written requirements or tickets that engineering built from, or tracked a client-driven change through delivery with an engineering team?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.