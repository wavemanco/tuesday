I'll read the reference files the skill points to before building the ledger.
I've built the ledger from your CV, using your own sentences. Nothing is applied yet, and every row is `pending your approval`.

**Assumption:** you gave me prose rather than a file, so I treated it as self-report. Each "Traces to" cell quotes your message word for word. The ledger only reorders and surfaces what you wrote, so it adds no claims. A few of the JD's words (backend, distributed systems, mentoring, partnering with product) aren't things you said about yourself, so I left them out of your lines. They appear in the coverage map below as gaps.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. Own three services in our ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline" | `[grounded]` your message | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(text unchanged except dropping "I" — moved to the first bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years. Ran six incidents as incident commander." | `reorder` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboarding for new hires on my team — usually two or three a year; pair with them for their first month." | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your message | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Kafka, gRPC, Postgres, Datadog, Terraform" | `surface` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your message | pending your approval |

- E2 to E5 put the bullets in the order that matches the JD's own order of concerns: scale, latency, on-call and incidents, then onboarding.
- E4 changes "I've run" to "Ran". Check that you still want it in the past tense.
- E6 moves Go to the front of the skills line and Terraform to the end. It lists tools only and does not claim you own anything with them.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 puts "7 years" up top and E2 shows the services. Your material never uses the word "backend", so I haven't written it. | `[grounded]` your sentences |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1 and E6 show Go daily for 4 years. Your material doesn't say which of your three services are in Go, so no line says "production Go". | `[grounded]` your sentences |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | Kafka and gRPC appear only as listed tools (E6). Recall prompt C1. | `[grounded]` what you wrote |
| R4 | Own services handling high request volume | must-have | `surfaced_by_edit` | E2. You say "own" and I kept "own". "Design and ship" is the JD's wording and I did not borrow it. | `[grounded]` your sentence |
| R5 | Drive down p99 latency | must-have | `surfaced_by_edit` | E3 (380ms to 95ms) | `[grounded]` your sentence |
| R6 | Own on-call for your services | must-have | `surfaced_by_edit` | E4 | `[grounded]` your sentence |
| R7 | Strong incident response | must-have | `surfaced_by_edit` | E4 (six incidents as incident commander) | `[grounded]` your sentence |
| R8 | Mentoring mid-level engineers | important | `surfaced_by_edit` | E5. Your material says "new hires", not their level, and "onboarding" and "pair with them", not "mentoring". I kept your words. | `[grounded]` your sentence |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material covers it. Recall prompt C2. | `[grounded]` what you wrote |

## Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Kafka and gRPC listed as tools, a ledger pipeline of three services, 40k requests/minute at peak. It doesn't say how the services depend on each other or what your cache rework had to coordinate. | The JD lists it as a requirement and your CV has only tool names for it. | Ordering or consistency work across services in the ledger pipeline; a Kafka consumer or retry design you owned; a failure mode you diagnosed across more than one service; a cache invalidation problem in the balance-read rework | A design doc, an incident postmortem, an architecture diagram | `[grounded]` what your material does and does not say; `[generic]` what a tools-only listing costs on applications like this |
| C2 | Partner with product on roadmap sequencing | important | Nothing about working with product or planning. | The JD names it as part of the role and your CV gives nothing to match it. | Deciding what to build first alongside a product manager; pushing back on or reshaping a request; trading reliability work against feature work | A roadmap doc, a planning thread, a written proposal | `[grounded]` what your material says; `[generic]` what a missing planning line costs on applications like this |

If nothing is behind C2, I'd carry it as a gap and not reach for it. It is listed as important rather than as a requirement, and the rest of your match is strong.

## Not written, and why

- "Production Go services" — you wrote "Go and Rust daily", and you didn't say which services run Go.
- "7 years of backend experience" — your sentence is "Senior Software Engineer, 7 years". It names no domain, so I resolved the ambiguity downward and left "backend" out.
- "Designed and shipped high-volume services" — you wrote "own". Designing and shipping is the JD's phrase, not yours.
- "Distributed systems experience" — Kafka and gRPC are tools you list, not evidence of that work.
- "Mentored mid-level engineers" — you wrote onboarding and pairing with new hires. "Mentored" and "mid-level" are the JD's words.
- "Partnered with product on roadmap" — nothing in your material mentions product work.
- Hidden text or keyword blocks — you didn't ask for any, so this is only a note that I don't write them.

## Parse-safety check

You sent plain text, so I couldn't check layout. I couldn't run the multi-column, table or text-box, image, or header and footer checks. I also couldn't check the file type or for hidden text left by a template. Every heading and section I proposed uses a conventional label, such as Summary, Experience and Skills. If you send the file itself, I'll run the full check.

## Upgrade menu

- **The CV as a file (docx or text-layer PDF):** lets me run the layout and hidden-text checks above.
- **Your current CV's exact wording:** E2 to E5 are built from your prose, so your CV's own bullets would let me quote the real lines.
- **A postmortem, design doc, or architecture diagram from the ledger pipeline:** the artifact that could turn C1 into a grounded row.
- **A planning doc or roadmap thread:** the equivalent for C2.

## Questions

C1 — Did any of your three services or the cache rework involve coordination across services (event ordering through Kafka, retries, consistency between the cache and Postgres)? If so, what was it and what was your part?
C2 — Have you worked with product on what to build or in what order? If so, what was a specific case?
R2 — Which of your three services are written in Go, and is the 40k requests/minute one among them?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.