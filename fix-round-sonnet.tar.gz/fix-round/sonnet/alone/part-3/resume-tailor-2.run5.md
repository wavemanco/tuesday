I'll read the references the skill requires before building the ledger.
Dev, your material doesn't support the posting's one must-have, "3+ years data engineering". You have five years as a Senior Data Analyst, and the engineering work you describe is real but adjacent: dbt models, a star schema, a nightly job you fixed. I won't write the missing years into the resume. The ledger below is what your own sentences can honestly carry, and the gaps are named after it. Whether this posting is worth applying to with that gap is job-underwriter's question, not this ledger's.

I worked from your prose as self-report, so "Current line" quotes your own sentences. Nothing is applied until you approve specific rows.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your summary | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first Experience bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your summary | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your summary | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke and added tests to it." | `surface` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your summary | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Line 1: "Python for analysis (pandas)." Line 2: "Some scripting to pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your summary | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved below E2 to E5)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your summary | pending your approval |

Notes on the rows:
- **E1** keeps three separate sentences. "Built models" and "designed the schema with the DE" stay two claims. "Our then-DE" stays in, because dropping it would make you the sole designer.
- **E2, E3, E4, E6** are position and voice only. The only wording change is dropping "I", plus the tense in E4. No qualifier is removed: "about 25" stays and "with our then-DE" stays.
- **E5** keeps "some scripting". Splitting it out stops the cron line from borrowing weight from pandas analysis, and it doesn't develop either half.
- The star schema is left as "star schema", your term, not the posting's "dimensional modelling".
- Reorder puts dbt and the schema first and SQL fifth, so the engineering-adjacent evidence is read first.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | No row can carry it. Your material shows five years as an analyst and no data-engineer role. Named in N2. | `[grounded]` JD and your summary |
| R2 | Production Python | important | `not_evidenced` | E5 surfaces the cron scripting as you wrote it. Your sentence says Python "for analysis", so no row claims production. See C1. | `[grounded]` your summary |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | No row. Neither the nightly dbt job nor the cron is described as orchestration in your material. See C2. | `[grounded]` your summary |
| R4 | Dimensional modelling, model the warehouse | important | `surfaced_by_edit` | E1 and E3 for the star schema, E2 for the dbt models, E6 for Redshift. | `[grounded]` your summary |
| R5 | Own data quality | important | `surfaced_by_edit` | E4 shows tests added to the nightly job. Ownership is not claimed. | `[grounded]` your summary |
| R6 | Own SLAs | important | `not_evidenced` | No row. Nothing in your material mentions a deadline or service level. See C3. | `[grounded]` your summary |
| R7 | Build and own batch pipelines | important | `not_evidenced` | E4 and E5 sit nearby, but "built" and "owned" are not in your sentences. See C3. | `[grounded]` your summary |
| R8 | Spark | important | `not_evidenced` | You said you have never used it. Named in N1. | `[grounded]` your summary |
| R9 | Kafka, streaming | preferred | `not_evidenced` | You said you have never touched Kafka. Named in N1. | `[grounded]` your summary |
| R10 | Partner with analytics on requirements | important | `not_evidenced` | E3 shows you working with a data engineer from the analytics side. No row claims the reverse relationship. | `[grounded]` your summary |

## Recovery per gap

Recall prompts, where something may exist to pull:

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | important | "some scripting to pull vendor APIs on a cron", framed as Python "for analysis" | The posting lists production Python as a requirement. Your sentence shows scripts that run on a schedule, but not whether anything downstream depends on them. | The cron scripts feed a table other teams query; they have retries or failure alerts; they live in a shared repo with review | A repo link, a README, or an alert config | `[grounded]` what your sentence does and does not say; `[generic]` interviewers for pipeline roles commonly probe failure handling |
| C2 | Airflow or equivalent orchestration | important | A "nightly dbt job" and a "cron", with no scheduler named | The posting names Airflow and accepts an equivalent, so what runs your jobs decides whether anything here counts. | The scheduler behind the nightly dbt job; job dependencies or ordering you configured; a retry or alert setup you wrote | A job config, a DAG-like file, or a scheduler screenshot | `[grounded]` what your sentence does and does not say; `[generic]` what "equivalent" is usually read to mean is the employer's call |
| C3 | Build and own batch pipelines; own SLAs | important | Models built and a job fixed, with ownership of ingestion and scheduling unstated | Duties 1 and 3 of the posting are pipelines and SLAs, so this is the largest unanswered part of the posting. | Ingestion or scheduling you owned after or alongside the then-DE; a morning deadline someone downstream relied on; who was told when the nightly job failed | A runbook, an incident note, or a dashboard others used | `[grounded]` what your sentence does and does not say; `[generic]` pipeline roles commonly ask who was paged and what the deadline was |

Named absences, where you've said there's nothing to pull or it can't be recalled into existence:

| # | Requirement | What your material shows | What closing it would take | Provenance |
|---|---|---|---|---|
| N1 | Spark; Kafka and streaming | You said "Never used Airflow or Spark. Never touched Kafka." | Hands-on work you can link, such as a small Spark batch job and a Kafka producer and consumer. Streaming is the posting's plus, but Spark is in its duties. No wording on a resume closes this. | `[grounded]` your statement; `[generic]` what closing it takes |
| N2 | 3+ years data engineering | Five years as Senior Data Analyst, with a dbt, schema and nightly-job profile | Time doing the work, not phrasing. A confirmed C3 answer might show engineering work you can describe in specific lines, but those lines would show the work, not three years of the title. Otherwise the honest path is a posting that doesn't make this a must-have. | `[grounded]` your summary and the JD; `[generic]` what closing it takes |

## Not written, and why

```text
Not written, and why:

- "3+ years of data engineering experience" — the posting's must-have; your material
  shows five years as an analyst. The adjacent work is in E1 to E4; the gap is named in
  R1 and N2 rather than papered over.
- "Built and owned batch pipelines" — you built and maintained dbt models and fixed a
  nightly job. "Owned" and "pipelines" are the posting's words, not yours.
- "Production Python" or "Python data pipelines" — you wrote "I write Python for
  analysis"; the cron scripting is "some".
- "Airflow", "orchestration", or "scheduling experience" — you wrote "Never used
  Airflow". "Or equivalent" is the posting's door; I did not walk through it for you.
- "Spark", "Kafka", "streaming", "familiar with", "exposure to" — you said never used
  and never touched. Softening to "exposure" would still be a claim.
- "Owned data quality and SLAs" — you added tests to a job. Nothing in your material
  mentions an SLA.
- "Designed the orders mart schema" without "with our then-DE" — dropping that phrase
  makes you the sole designer.
- "Data Engineer" or "Analytics Engineer" as a retitle — your title is Senior Data
  Analyst, and a retitle would be an upgrade, not an equivalent.
- "Partnered with analytics on requirements" — you sat on the analytics side; the
  posting's role would sit across from it.
```

## Parse-safety check

Your resume arrived as pasted prose, not a file, so none of these could be run: multi-column layout, tables and text boxes, images or skill bars, content in headers or footers, non-standard section headings, and file type. Send the file and I'll run them.

## Upgrade menu

These are offers only. Nothing here is built until you ask.
- **Your full resume file.** I've only seen your summary, so I can't propose cuts, check the remaining lines against the audit, or run the parse check.
- **A link to your dbt project or its test config.** This would anchor E2 and E4 in something inspectable.
- **The cron scripts or their repo.** This would settle C1.
- **A scheduler config, runbook, or incident note.** This would settle C2 and C3.

## Questions

C1 — Where do the vendor-API cron scripts live, does anything downstream depend on their output, and what happens when one fails?

C2 — What runs your nightly dbt job (a scheduler, dbt Cloud, a cron on a server), and what triggers the vendor-API scripts?

C3 — Who owned the ingestion and scheduling that feeds the orders mart, and was any of it yours, including anything with a deadline someone downstream relied on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.