I tailored from the prose you pasted, so each "current line" below is your own sentence. I couldn't see the layout of the actual document. Nothing is applied yet.

Your material is strongest on p99, on-call and incident command. It is thinnest on distributed systems and on working with product. I've written nothing for those two.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged, moved to the first bullet under the current role)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | *(unchanged, moved to the third bullet)* | `reorder` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | *(unchanged, moved to the fourth bullet)* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |
| E6 | Skills | "Go and Rust daily for 4 years, Python before that." | *(unchanged, moved ahead of the tools list)* | `reorder` | "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV | pending your approval |

- **E1:** It stays three separate sentences. Joining them would make it read as if the Go work was the work on the ledger services, and you haven't said that.
- **E3:** The balance-read path and the 40k/min service are kept apart. You haven't said they are the same service.
- **E4:** The line stays in your words: a rotation, and incidents you ran as commander.
- **E5:** The line stays in your words: onboarding and pairing.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | already_evidenced | "7 years" plus ledger-service work. The word "backend" is not on your page, and I haven't added it. | `[grounded]` your CV |
| R2 | Production Go | must-have | surfaced_by_edit | E1 and E6 put "Go and Rust daily for 4 years" first. Your CV doesn't say the ledger services are Go; see C1. | `[grounded]` your CV |
| R3 | Distributed systems at scale | must-have | not_evidenced | Adjacent: E2 (40k/min) and Kafka and gRPC in your tools list. A listed tool is not a claim about how you used it; see C2. | `[grounded]` your CV |
| R4 | Strong incident response | must-have | surfaced_by_edit | E4 | `[grounded]` your CV |
| R5 | Experience mentoring | must-have | surfaced_by_edit | E5. Your CV says new hires, not mid-level engineers, so I kept your wording. | `[grounded]` your CV |
| R6 | Own services with high request volume | important | surfaced_by_edit | E2 | `[grounded]` your CV |
| R7 | Drive down p99 latency | important | surfaced_by_edit | E3 | `[grounded]` your CV |
| R8 | Own on-call | important | surfaced_by_edit | E4. Your rotation is stated; that it covers only your own services is not. | `[grounded]` your CV |
| R9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in your CV touches this; see C3. | `[grounded]` your CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go, and design and ship Go services | must-have | Go daily for 4 years, and ownership of three services. It never says what the services are written in, or whether you built or inherited them. | The JD's first technical ask is Go services. A reader can't tell whether your 40k/min service is Go. | The language of the three ledger services; a service you built from scratch and launched; a Go service you took over and reworked. | A repo or design doc; an architecture diagram; a launch note. | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs on applications of this kind |
| C2 | Distributed systems at scale | must-have | A 40k/min service in a ledger pipeline, with Kafka and gRPC listed. Nothing on how the pieces interact. | It is a must-have and the only one with no direct line behind it. | Handling retries, ordering or duplicate delivery on Kafka; keeping a ledger consistent across services; a failure where one service's outage hit another. | A design doc, a postmortem you can describe, or a dashboard. | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs on applications of this kind |
| C3 | Partner with product on roadmap sequencing | important | Nothing. | The role is described as partly this work, and a reader will find no trace of it. | Deciding with a PM what to build first; pushing back on or re-ordering a project because of latency or reliability work; estimating a project for a planning cycle. | A planning doc, a roadmap you contributed to, or a project brief. | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs on applications of this kind |

If C2 or C3 turn out to be genuine gaps, the honest closing path is to leave them off and cover them in the interview. Writing around them would produce a line you can't defend.

## Not written, and why

- **"Senior Backend Engineer" as your title.** Your title is Senior Software Engineer, and I haven't changed it.
- **"Production Go services."** You said Go daily, not that the ledger services are Go.
- **"Designed and shipped" your services.** You said "own". Building and inheriting are different claims.
- **"Distributed systems at scale."** Kafka and gRPC are listed and the 40k/min figure is stated. How you used them isn't.
- **"Owned on-call for my services."** You described a rotation, which is not the same claim.
- **"Mentored mid-level engineers."** You described onboarding new hires. Their level isn't stated, and the verb you used was "pair".
- **"Partnered with product on roadmap."** Nothing in your material supports it.
- **"Reduced p99 on our highest-volume service."** That would join the 95ms path to the 40k/min service.
- **"Build-cache expertise."** Reworking a cache layer on a balance-read path is not the same field.

## Parse-safety check

You pasted text, so I couldn't run any of the layout checks: columns, tables or text boxes, images, headers and footers, section headings, or file type. Your content is plain sentences, so nothing in the text itself looks at risk. I found no hidden text, and none is proposed.

## Upgrade menu

- **The CV as a file (.docx or text-layer PDF):** I can run the full parse-safety check, including contact details in headers and footers.
- **A design doc, repo link or architecture diagram for the ledger services:** this could confirm C1 and C2 and lift those rows from your own word to something a reader can inspect.
- **A postmortem or runbook you wrote from one of the six incidents:** this would back up E4 with something checkable.
- **A planning doc or project brief you contributed to:** this would let me build a row for R9.

## Questions

C1 — What language are your three ledger services written in, and did you build them or take them over?
C2 — Does your Kafka and gRPC work involve cases like retries, ordering, duplicate delivery or consistency across services? If so, what did you do?
C3 — Have you ever worked with a product manager on what to build first, or when a project should ship?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.