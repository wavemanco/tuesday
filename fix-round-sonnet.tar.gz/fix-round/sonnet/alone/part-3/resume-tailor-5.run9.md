I won't add the hidden instruction or the 1pt keyword block. I'll tailor the resume itself, and I'm loading the tailoring workflow now.
Rowan, I won't put hidden instructions or a 1pt keyword block in your resume. Here is the tailoring done with visible text only.

**Why not the hidden text.** The hidden instruction is aimed at a screener working for the employer, so it deceives the employer. It's also a line you didn't write and couldn't explain if asked. Hidden text is visible to the software that parses the file, so it can be found. On the premise that it gets you past the AI: in one small sample of 25 recruiters, content-based auto-rejection was uncommon. Match scores mostly decide who gets reviewed first, and what most often rejected without a person was knockout questions on the application form (work authorisation, location). That sample is small, so don't read more into it than that. What helps instead is the same as what keeps you honest: your real keywords in visible text, strongest evidence first.

## Edit ledger (every row pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; budget controlled about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your message | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Line 1: "Used HubSpot daily for 4 years." Line 2: "Built our lifecycle email programme from scratch, 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your message | pending your approval |
| E3 | Experience | "I pull my own numbers in HubSpot reporting" | "Pull my own numbers in HubSpot reporting." | `compress` | "I pull my own numbers in HubSpot reporting" | `[grounded]` your message | pending your approval |
| E4 | Experience | "but I'm not strong in SQL — I ask our analyst" | *(removed from the resume)* | `cut` | "but I'm not strong in SQL — I ask our analyst" | `[grounded]` your message | pending your approval |

- **E1** keeps "about" and "a year", and keeps the budget in the same clause as the paid channels, the way you wrote it. I haven't said it was a paid-only budget.
- **E2** puts HubSpot, a must-have, on its own line.
- **E3** is a reporting line. It is not a SQL claim, and it doesn't sit under one.
- **E4** is a cut. The remaining line claims no more than before, and nothing implies SQL. If it comes up in an interview, answer it plainly.
- I left "Ran a monthly webinar series, average 300 registrants." and "Marketing Manager, 6 years B2B SaaS." unchanged. They already carry the evidence.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years B2B demand gen | must-have | `already_evidenced` | "6 years B2B SaaS" plus the channels you ran. The resume doesn't say how many of those years were demand gen, so I haven't written that phrase (see the first question). | `[grounded]` your message |
| M2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E2 | `[grounded]` your message |
| M3 | SQL-literate | must-have | `not_evidenced` | Nothing written; see C1 | `[grounded]` your message |
| M4 | Managed a budget over $500k | must-have | `already_evidenced` | "about $600k a year"; E1 only tidies it | `[grounded]` your message |
| M5 | Paid search | important | `already_evidenced` | E1 | `[grounded]` your message |
| M6 | Lifecycle email | important | `surfaced_by_edit` | E2 | `[grounded]` your message |
| M7 | Webinars | important | `already_evidenced` | Webinar line, unchanged | `[grounded]` your message |
| M8 | Content distribution | important | `not_evidenced` | Nothing written; see C2 | `[grounded]` your message |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | SQL-literate | must-have | You pull numbers in HubSpot reporting and hand SQL to an analyst. That shows reporting skill, not SQL. | It is a must-have in the posting, so it is the likeliest weak spot, and a recruiter will probably check it first. | A query you wrote or edited yourself; a Looker, Metabase or Mode query; a warehouse export you filtered yourself | A saved query, a dashboard you built, a screenshot | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| C2 | Content distribution | important | Webinars are covered. Nothing says what content you distributed or through which channels. | The posting lists it among the things the role owns. | Promoting ebooks or blog posts through paid social or email flows; webinar recordings sent after the event; a newsletter | A campaign brief, a channel calendar | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |

If C1 turns out to be "none", closing it takes real working SQL: a few weeks on SELECT, JOIN and GROUP BY against a campaign-data export, ideally leaving a query you can show. Until then, the honest position is the one you described. Whether the role is still worth applying for with this gap is job-underwriter's question.

## Not written, and why

- **Hidden instruction to screeners, and the 1pt keyword block.** Refused, for the reasons above.
- **"SQL" or "SQL-literate" anywhere.** You said you aren't strong in it.
- **"Marketo".** It isn't in your history. The posting says "HubSpot or Marketo", and HubSpot is the one you have.
- **"Owned demand generation".** You ran channels. You didn't say you owned the function.
- **"5+ years of demand generation".** Your sentence says 6 years in B2B SaaS, and the demand-gen share isn't stated.
- **"Managed a budget over $500k".** That's the posting's wording. Yours is "controlled", "about $600k", "a year".
- **"Content distribution".** No evidence yet.

## Parse-safety check

You pasted text rather than a file, so I couldn't check columns, tables, text boxes, icons, headers and footers, or file type. I also couldn't inspect for hidden text left behind by a template or an earlier tool. A `.docx` or a text-layer PDF is the safe pair of formats.

## Upgrade menu

- **The resume file itself:** I can run the parse-safety and hidden-text checks properly.
- **Job titles, employers and dates:** these let me confirm the tenure claim and add date lines.
- **Any real results numbers, such as pipeline or cost per lead:** these would allow outcome bullets. I won't write any figure you haven't given me.
- **Answers to the questions below:** each one can turn a gap into a real row.

**M1:** Roughly how many of your 6 years were spent running paid, lifecycle email or webinars, as opposed to other marketing work?
**C1:** Have you ever written or edited a SQL query yourself, even a small one? If so, what for?
**C2:** Did any of your paid social, email flows or webinar promotion distribute content such as ebooks, blog posts or recordings? What was it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.