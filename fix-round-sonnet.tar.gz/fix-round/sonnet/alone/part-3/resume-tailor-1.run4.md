I'll read the reference files the skill requires before building the ledger.
Priya, your CV already says most of what this posting asks for. The ledger is short because I only rearranged and split lines you'd already written, and added nothing. Two requirements have no evidence in what you sent: distributed systems at scale, and partnering with product on roadmap sequencing.

The CV came as pasted text, so I quote your sentences exactly as you wrote them. Nothing below is applied yet.

## Edit ledger: pending your approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Currently at a payments company. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your text | pending your approval |
| E2 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Line 1: "On-call rotation every fourth week for two years." Line 2: "I've run six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your text | pending your approval |

- **E1 keeps three separate sentences.** Joining them could read as 7 years at the payments company, or 7 years as a senior, and you wrote neither.
- **E2 gives incident command its own line.** Neither half claims more than your sentence did. The split doesn't say the six incidents fell inside the two years, or that the rotation covers your three services.
- **No rows for your other lines.** Services and 40k/min, the p99 cut, and the onboarding line stay word for word. They already sit in the order the JD asks for them.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `already_evidenced` | "Senior Software Engineer, 7 years." E1 keeps it first. The word "backend" isn't in your material. | `[grounded]` your text |
| R2 | Production Go | must-have | `already_evidenced` | "Go and Rust daily for 4 years" (E1). Your material doesn't say which language the three services are in, so I haven't linked them. | `[grounded]` your text |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | Kafka and gRPC appear only in a tools list. See C1. | `[grounded]` your text |
| R4 | Go services handling high request volume | important | `already_evidenced` | "one handles about 40k requests/minute at peak". Design and ship aren't stated. | `[grounded]` your text |
| R5 | Strong incident response | must-have | `surfaced_by_edit` | E2 | `[grounded]` your text |
| R6 | Own on-call for your services | important | `surfaced_by_edit` | E2 shows the rotation. It doesn't say whether the rotation covers your own three services. | `[grounded]` your text |
| R7 | Drive down p99 latency | important | `already_evidenced` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your text |
| R8 | Experience mentoring | must-have | `already_evidenced` | The onboarding line. It says onboarding and pairing, and doesn't say what level the hires were. | `[grounded]` your text |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material. See C2. | `[grounded]` your text |

## Recovery per gap: pending your approval

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Three services in a ledger pipeline, one at about 40k requests/minute at peak, and Kafka and gRPC in a tools list. It doesn't say how the services connect or what you owned in that design. | The JD lists it as a requirement. A tools list on its own doesn't show you designed or ran anything distributed. | How the three services hand work to each other; what happened on a retry, replay or backlog; a consistency problem in the balance-read cache rework | An architecture doc, design review, runbook or postmortem | `[grounded]` what your CV says and omits; `[grounded]` the JD lists it; `[generic]` a tools list rarely shows ownership |
| C2 | Partner with product on roadmap sequencing | important | Nothing on working with product or planning. | The JD names it as a responsibility. Nothing on your CV currently answers it. | Choosing between the cache rework and other work; arguing a quarter's priorities; a planning or scoping discussion with a PM | A planning doc, RFC, roadmap or ticket thread | `[grounded]` what your CV says and omits; `[grounded]` the JD lists it |

## Not written, and why

- **"Mentored mid-level engineers".** You wrote onboarding new hires and pairing with them for a month. The JD's words are "mentor" and "mid-level", and you didn't state the hires' level.
- **"Owned on-call for my services".** You wrote a rotation every fourth week, not that it covers your three services.
- **"Go services" for the ledger services.** You haven't said what language they're in.
- **"Designed and shipped" the services.** You wrote "own".
- **"Distributed systems" experience.** Kafka and gRPC are tools you list, and a tool listed isn't a system you built.
- **"Partnered with product".** Nothing in your material supports it.
- **Joining the p99 cut to the 40k/min service.** You didn't say the balance-read path is that service, so I kept the two figures apart.
- **"7 years of Go" or "7 years backend".** Go is 4 years. The 7 is "Senior Software Engineer, 7 years".
- **"Led incident response".** You wrote six incidents as incident commander.
- **Datadog tied to the latency work.** It's in your tools list, and nothing says it was used for the p99 cut.

## Parse-safety check

You pasted text, not a file, so I couldn't run these checks: multi-column layout, tables or text boxes, images or skill bars, contact details in headers or footers, file type, and hidden text carried over from a template. The headings I'd use are Summary and Experience, both conventional.

## Upgrade menu

- **Your CV as a `.docx` or text-layer PDF:** lets me run the parse checks above and quote your exact wording.
- **An architecture doc, design review or runbook for the ledger pipeline:** could move R3 from `not_evidenced`.
- **A postmortem you led as incident commander:** gives R5 inspectable proof.
- **A planning doc or RFC where you and product sequenced work:** could move R9.

## Questions

R2 — Are the three services you own written in Go, Rust, or a mix?
C1 — Can you describe how your three ledger services pass work to one another, and which part of that was yours?
C2 — Was there a time you and a product manager decided together what to build or fix first, and what did you contribute to that call?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.