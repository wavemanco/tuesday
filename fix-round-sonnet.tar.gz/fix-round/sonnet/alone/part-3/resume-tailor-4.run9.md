I'll read the reference files before building the ledger.
You're probably right that keywords are part of it, but not the way you think. For this JD the bigger issue is that most of the posting's stack isn't in your experience, and I won't write it into your resume. Below is the full ledger: four small edits, a coverage map, the gaps, and what I refused to write.

## One premise to correct first

Most of the evidence I can cite says automatic rejection for missing keywords is uncommon. In one vendor's interviews with 25 US recruiters, "AI/content auto-rejection configured: 8% of recruiters" (cite C25). That is two people, in a sample the vendor itself calls themes rather than representative statistics. In the same interviews, "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are yes/no checks on work authorisation, licence or location, answered in the application form rather than on the resume. Where match scores exist, "Many teams use match scores/filters to prioritize who gets reviewed first" (cite C27), and "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27). In that sample, "56% either ignore the feature or don’t have it available" (cite C27). That keywords drive those scores is an inference. I can't tell from here why you've been rejected.

My position: put truthful keywords where your evidence already supports them so you're findable, and never invent one. Whether to apply for a role this far from your stack is job-underwriter's question, not this skill's.

I only have your description of the resume, not the file. The "current line" quotes below are your own sentences from this message.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(Kubernetes appears only in the experience bullet)* | "Kubernetes (two-month proof-of-concept, not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` | pending your approval |
| E2 | Skills | "Bash and Python scripting" | "Python scripting; Bash scripting" | `split` | "Bash and Python scripting" | `[grounded]` | pending your approval |
| E3 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to the first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` | pending your approval |
| E4 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, moved directly after the pipeline bullet)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` | pending your approval |

- **E1** keeps "not in production" and "proof-of-concept". The qualifier is the part you can defend in an interview.
- **E2** only makes Python visible as its own item. Both words keep "scripting".
- **E3 and E4** change position only, because a reader who stops early still meets your strongest evidence.

## Coverage map

The posting doesn't tier its requirements. I ranked them by its order and its closing sentence, which is `[inferred]`, so correct me if you know better.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes (plus Helm, AWS EKS) | must-have | `surfaced_by_edit` | E1 and E4 surface the proof-of-concept only. EKS and Helm are not evidenced and the work was never in production. | `[grounded]` resume; `[inferred]` priority |
| R2 | Terraform | must-have | `not_evidenced` | C1. Ansible is config management, not infrastructure provisioning. | `[grounded]` |
| R3 | SRE practices and owning platform reliability | must-have | `not_evidenced` | C2 | `[grounded]` |
| R4 | CI/CD | must-have | `surfaced_by_edit` | E3 moves the Jenkins pipeline to the top. | `[grounded]` |
| R5 | Python | must-have | `already_evidenced` | Your resume says "Bash and Python scripting"; E2 makes Python its own item. | `[grounded]` |
| R6 | AWS | important | `already_evidenced` | "AWS (EC2, S3, RDS, IAM)" | `[grounded]` |
| R7 | GitLab (the CI/CD tool named) | important | `not_evidenced` | Named absence below. Your pipeline is Jenkins. | `[grounded]` |
| R8 | ArgoCD, GitOps | important | `not_evidenced` | C3 | `[grounded]` |
| R9 | Prometheus, Grafana, observability | important | `not_evidenced` | C2. You have CloudWatch for monitoring, a different tool and kind of work. | `[grounded]` |
| R10 | Istio, service mesh | important | `not_evidenced` | Named absence below | `[grounded]` |
| R11 | Vault | preferred | `not_evidenced` | Named absence below | `[grounded]` |
| R12 | Go | preferred | `not_evidenced` | Named absence below | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform | must-have | Ansible for config management, and AWS resources you work with. Nothing says you provisioned them as code. | A listed tool with no mention on the resume gives a reader nothing to match it to. | Terraform or similar used for any AWS resource, even a side project; modules you wrote or edited; reviewing Terraform changes for others | A repo, a pull request, a module | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| C2 | SRE practices, platform reliability, Prometheus/Grafana/observability | must-have | "CloudWatch for monitoring", and a pipeline you built and maintain | The role's closing sentence is about owning reliability, and nothing on your resume yet speaks to it. | On-call rotation; incident write-ups; alerts you set up or tuned; any Prometheus or Grafana use; tooling other engineers rely on | An incident review, an alert config, a dashboard | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| C3 | Kubernetes detail: EKS, Helm, GitOps/ArgoCD | must-have | A two-month proof-of-concept that never reached production, with no detail on how it was run | The detail decides whether the proof-of-concept reads as relevant or as a footnote. | Which platform it ran on; manifests or Helm charts written; how deploys were handled; what you tested | A write-up, a repo, a demo | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |

**Named absences**
- **GitLab:** you've used Jenkins, and this is a different tool. Closing it takes real use, such as a personal project pipeline or a work migration. For this application I'd treat the Jenkins evidence as the honest stand-in.
- **Istio and service mesh:** you have no mesh experience, and a mesh only makes sense on top of running Kubernetes for real. Closing it means running a cluster with a mesh in a lab. That is a months-long project, probably not worth it for this one application.
- **Vault:** there's nothing on your resume about secrets management. A small lab or work project using Vault would close it. It's preferred rather than core, so I'd skip it for now.
- **Go:** there's no mention of it on your resume. Closing it takes a small shipped tool or contribution, which is a longer path than this application allows.

## Not written, and why

- **"Kubernetes experience" with the qualifier removed, or "production Kubernetes":** it was a two-month proof-of-concept that never went to production.
- **"Platform Engineer" as a title:** you're a DevOps Engineer, and a retitle would be an upgrade rather than an equivalent.
- **"GitOps" for the Jenkins pipeline:** that's a different practice, and the posting's word isn't yours.
- **"Observability" for CloudWatch monitoring:** that changes the kind of work you did.
- **"Developer experience" for the pipeline:** it's the posting's phrase, and nothing you wrote says developers were the audience.
- **"Owned platform reliability" or "SRE practices":** nothing you wrote says you did either.
- **Terraform, ArgoCD, Helm, Istio, Vault, Prometheus, Grafana, EKS, GitLab, Go:** none of these appear in your material. A tools-list entry for any of them would be a claim you couldn't defend.

## Parse-safety check

I couldn't inspect the PDF, so these come from your description. I couldn't check the PDF's text layer, section headings, or any hidden text a Canva template might carry.

| Check | What breaks | What it costs | Provenance |
|---|---|---|---|
| Two-column layout | A parser reads the columns linearly and may interleave them. | Skills and dates can detach from the roles they belong to. | `[generic]` |
| Icons for each skill | Icons can be skipped or turn into garbage characters. | Any information carried by the icon alone is absent. | `[generic]` |
| Contact details in the header | Page headers and footers are often discarded. | The resume can reach a recruiter with no way to contact you. | `[generic]` |

## Upgrade menu

- **The PDF itself:** I could run the parse-safety check on the real file and check for hidden text left by the template.
- **Your full resume text:** I only have your summary, so I'd see every bullet, employer, date and the section headings.
- **A write-up of the Kubernetes proof-of-concept, or any repo or home lab:** this would turn C1 and C3 into grounded rows.
- **A real incident, alert config or on-call history:** this would do the same for C2.

## Questions

C1 — Have you written or reviewed Terraform for anything, at work or on your own?

C2 — Beyond CloudWatch, have you carried on-call, run incident reviews, set alerts or SLOs, or used Prometheus or Grafana?

C3 — What did your Kubernetes proof-of-concept run on, and did it involve Helm, GitOps tooling or EKS?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.