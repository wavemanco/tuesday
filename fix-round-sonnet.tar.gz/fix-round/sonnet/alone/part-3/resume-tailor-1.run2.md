I've built the ledger from your pasted CV. I've assumed it has no summary section and that your bullets run in the order you gave them. Nothing is applied yet.

Most of your CV already matches this role, so the ledger is short. The bigger finding is that two of the JD's requirements aren't evidenced in what you sent: distributed systems at scale, and partnering with product on roadmap sequencing.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year, pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |

- **E1** is built from your own sentences and kept as three. It drops "Python before that", which only leaves out context and adds nothing.
- **E1 does not say the 40k-requests/minute service is written in Go.** Your CV doesn't say which of the three services are Go, so the two facts stay in separate sentences.
- **E2 and E3** only change the voice. "Incident commander" and "pair with them" stay exactly as you wrote them. I did not turn "onboarding" into "mentoring".
- **Unchanged lines:** the "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." bullet and the ownership bullet already read as they should and already sit near the top. The tools line (Kafka, Postgres, Terraform, gRPC, Datadog) also stays as is.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `already_evidenced` | "Senior Software Engineer, 7 years." The word "backend" never appears, and I won't write it in until you confirm all 7 years fit. E1 keeps the 7 years. | `[grounded]` your CV |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1 puts "Go and Rust daily for 4 years" at the top. It's partial: it isn't stated which of your services are Go (question Q3). | `[grounded]` your CV |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | Kafka and gRPC are listed as tools, but nothing describes a distributed system you owned. See C1. | `[grounded]` your CV |
| R4 | Own services, high request volume | must-have | `surfaced_by_edit` | E1 carries "own three services" and "about 40k requests/minute at peak". | `[grounded]` your CV |
| R5 | Drive down p99 latency | must-have | `already_evidenced` | The 380ms to 95ms bullet, unchanged. | `[grounded]` your CV |
| R6 | Incident response and on-call | must-have | `surfaced_by_edit` | E2. The CV doesn't say the rotation covers your own services, so I haven't claimed that. | `[grounded]` your CV |
| R7 | Experience mentoring | must-have | `surfaced_by_edit` | E3. The new hires' level is unstated, so "mid-level" isn't claimed. | `[grounded]` your CV |
| R8 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in the CV touches this. See C2. | `[grounded]` your CV |
| R9 | Design and ship Go services | important | `not_evidenced` | See the named absence below. | `[grounded]` your CV |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Services, a ledger pipeline, and Kafka and gRPC in a tools list. It doesn't say what is distributed or how. | It is a listed requirement and is currently carried only by tool names. | A pipeline where services hand off through Kafka; a failure mode you handled across services; a consistency or ordering problem in the ledger; a cache layer shared across instances | An architecture diagram, a design doc, a postmortem | `[grounded]` what the CV does and doesn't say; `[generic]` tools lists don't establish ownership of a system |
| C2 | Partnering with product on roadmap sequencing | important | No product-facing work is mentioned. | The JD names it as a duty, and the CV is silent on it. | Deciding what to build or cut first with a product manager; trading a latency project against feature work; a planning session where you changed an order | A roadmap doc, a planning ticket, a retro note | `[grounded]` what the CV doesn't say; `[generic]` the posting treats it as part of the role |

**Named absence (R9):** your CV says you "own" three services. It never says you designed or shipped any of them. If you did, say so and I'll look at a row. If you inherited them, that is a real gap for this JD. Closing it would take a service you designed or launched, or an honest conversation about it in the interview.

## Not written, and why

- **"7 years of backend experience":** your CV says 7 years as a Senior Software Engineer. It doesn't say all of that was backend, or that all of it was at senior level.
- **"Distributed systems at scale" or "high-throughput":** Kafka is a tool you list, not a system you've described. Your own number is about 40k requests/minute at peak, and I added no scale adjectives to it.
- **"Production Go services handling 40k requests/minute":** it isn't stated that this service is written in Go.
- **"Mentored mid-level engineers":** "mentor" is the posting's word. Yours is "onboarding" and "pair". The hires' level is also unknown.
- **"Owned on-call for my services":** your CV says a rotation every fourth week, with six incidents run as incident commander. It doesn't say the rotation covers only services you own.
- **"Designed and shipped Go services":** your CV says "own", not "designed" or "shipped".
- **"Partnered with product on roadmap sequencing":** your CV has no basis for it.

## Parse-safety check

I only had pasted text, so I could not check layout (columns, tables, text boxes), content in headers or footers, section heading names, or the file type. Send the actual file and I'll run those checks, including whether it contains any hidden text you didn't author. In the pasted text I found nothing that would break a parser.

## Upgrade menu

Each of these is an offer that I'd build only if you approve it.
- **Your CV file (.docx or PDF):** adds the parse-safety check on the real layout.
- **A postmortem, design doc or dashboard screenshot:** gives me evidence to close C1 and possibly R9.
- **Answers to the questions below:** each one that confirms something turns a `not_evidenced` row into a row I can propose.

## Questions

C1 — In your ledger pipeline, what is distributed: do services pass work through Kafka, run across multiple instances or regions, or share state? Say whichever applies.

C2 — Have you worked with product or a PM on what to build first, or on trading one project off against another? If so, what was one case?

Q3 (R2) — Which of your three services are written in Go, and is the 40k requests/minute one among them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.