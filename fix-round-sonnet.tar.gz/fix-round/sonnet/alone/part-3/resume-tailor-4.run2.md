I'll read the skill's reference files before building the ledger.
Short version: a keyword pass can't fix most of this, because the JD's core stack isn't in your material. I can make what you do have easier to find. I can't write the missing tools in without putting claims on your resume that you couldn't defend in an interview.

I only have your description of the resume, not the file. Every quote below comes from your message, so rows map to those sentences. I don't know which section each sits in.

## On the "keyword auto-reject" idea

The one source this skill holds is a résumé-builder vendor's interviews with 25 US recruiters. The vendor calls its findings themes rather than representative statistics.

- **Content-based auto-rejection exists but is uncommon.** The sample reports "AI/content auto-rejection configured: 8% of recruiters", which is two people.
- **Knockout questions are what most often reject without a person.** The same interviews say "When automated filters are used, they’re almost always knockout questions", such as work authorization, licence, or location. These are answered in the application form, not on the resume.
- **Match scores mostly order the review queue.** The report says "Many teams use match scores/filters to prioritize who gets reviewed first", and "Low score ≠ auto-reject".

I can't tell from here which of these hit you. Keywords can still help you rank, but only where the evidence is real. Whether this role is worth applying to, given the gap below, is job-underwriter's question, not this skill's.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to the first bullet of your current role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." (position unknown) | *(unchanged, placed as the second bullet, qualifier kept)* | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring, Kubernetes (two-month proof-of-concept, not in production)" | `surface` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |

- **E2 and "last year":** E2 keeps your words, so "last year" will go stale as the resume ages. If you want a year there, add it yourself; I won't supply a date you didn't give me.
- **E3 and the qualifier:** E3 puts the word "Kubernetes" where a parser looks for it, and the qualifier stays attached so the line doesn't claim more than the PoC was.
- **No summary row:** I'm not proposing a summary line. Any summary I'd write now would need claims your material doesn't carry. Once your answers below come back, I can draft one from them.

## Coverage map

The JD doesn't tier its requirements. Priority is my reading of the posting's order and its closing sentence ("You will own platform reliability and developer experience").

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E2, E3. The evidence is a proof-of-concept only, never in production. | `[grounded]` your resume line says "never went to production" |
| R2 | AWS (core services) | must-have | `already_evidenced` | Skills line already names EC2, S3, RDS, IAM. | `[grounded]` your resume |
| R3 | AWS EKS | must-have | `not_evidenced` | Nothing in your material names EKS. See C1. | `[grounded]` absent from your resume |
| R4 | Terraform | must-have | `not_evidenced` | Ansible is configuration management, which is a different kind of work. See C2. | `[grounded]` your resume lists Ansible only |
| R5 | CI/CD pipelines | must-have | `surfaced_by_edit` | E1. Your own words, "deploy pipeline in Jenkins", stay as written. | `[grounded]` your resume |
| R6 | GitLab (CI/CD) | must-have | `not_evidenced` | Your pipeline tool is Jenkins. See C2. | `[grounded]` your resume |
| R7 | GitOps, ArgoCD | must-have | `not_evidenced` | Nothing in your material. See C1. | `[grounded]` absent from your resume |
| R8 | Observability (Prometheus, Grafana) | must-have | `not_evidenced` | "CloudWatch for monitoring" stays exactly as written. See C1. | `[grounded]` your resume |
| R9 | SRE practices, platform reliability, developer experience | must-have | `not_evidenced` | You maintain jobs and built a pipeline. Nothing says you owned reliability or who uses it. See C3. | `[grounded]` your resume; `[generic]` the JD's last sentence makes this the job |
| R10 | Python | important | `already_evidenced` | "Bash and Python scripting" is already on the page. | `[grounded]` your resume |
| R11 | Go | important | `not_evidenced` | Named absence N1. | `[grounded]` absent from your resume |
| R12 | Helm | important | `not_evidenced` | See C1. | `[grounded]` absent from your resume |
| R13 | Istio, service mesh | important | `not_evidenced` | Named absence N2. | `[grounded]` absent from your resume |
| R14 | Vault | important | `not_evidenced` | Named absence N3. | `[grounded]` absent from your resume |

Rows R3, R4, R6, R7, R8 and R9 are must-haves marked `not_evidenced`. No keyword placement closes those.

## Gap handling

### Recall prompts (questions are in the closing block)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Hands-on depth behind the Kubernetes PoC: EKS, Helm, ArgoCD or GitOps, Prometheus and Grafana | must-have | A two-month Kubernetes proof-of-concept that never reached production. It names no platform, tooling or monitoring. | These are the JD's headline tools, and a PoC with none of them named gives a reviewer nothing to match against. | The PoC cluster ran on EKS; apps were installed with Helm charts; a dashboard or alert was built; deploys were driven from a Git repo | PoC write-up, repo, architecture notes, demo recording | `[grounded]` what the resume does and doesn't say; `[generic]` what an unnamed PoC costs on a stack-specific posting |
| C2 | Terraform; GitLab CI | must-have | Ansible for config management and a Jenkins pipeline. No infrastructure-as-code provisioning tool and no GitLab. | The JD names both outright, and each is a separate keyword and skill to a reader. | Terraform modules you applied or edited; CloudFormation templates you wrote; a GitLab CI pipeline on a past job or side project | Repo, a module, a `.gitlab-ci.yml` | `[grounded]` the resume lists neither; `[generic]` named tools are what a stack-specific posting is read for |
| C3 | SRE practices, platform reliability, developer experience | must-have | You built the deploy pipeline and maintain about 30 Jenkins jobs. It doesn't say who relies on them or whether you handled failures. | The JD's closing sentence says you will "own platform reliability and developer experience", so this is the role's core. | Being on call for the pipeline; diagnosing an outage or failed deploys; runbooks you wrote; improving how developers use the pipeline | Runbook, postmortem, pipeline dashboard | `[grounded]` what the resume says; `[generic]` a role's closing sentence is usually its core |

### Named absences

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| N1 | Go | Nothing in your material uses Go. | Build and publish a small Go tool, or accept that this posting lists Go and Python together and lean on Python. | `[grounded]` absent from your resume |
| N2 | Istio, service mesh | You have no mesh experience, and a two-month PoC doesn't cover it. | Run Istio in a lab cluster on a real workload and write it up. Without that, this stays a gap on this application. | `[grounded]` absent from your resume; `[generic]` mesh depth is hard to show without a real workload |
| N3 | Vault | Nothing in your material touches Vault. | A small hands-on Vault project, such as dynamic secrets for an app, with a repo. For this role it is probably not worth closing before the larger gaps. | `[grounded]` absent from your resume; `[inferred]` order of priority |

## Not written, and why

- **"Platform Engineer", or any claim of owning a platform.** You are titled DevOps Engineer, and the JD wants ownership of platform reliability. A retitle here would be an upgrade, not an equivalent.
- **"CI/CD pipelines" as a line about your history.** You wrote "deploy pipeline", and CI/CD is the JD's word. It would also claim the build-and-test half, which your sentence doesn't say.
- **"Kubernetes experience", "production Kubernetes", or "container orchestration".** The proof-of-concept never reached production, so the qualifier stays on every line that mentions it.
- **"Observability" or "Prometheus and Grafana".** You wrote "CloudWatch for monitoring". Observability is a different kind of work, and the tools are different.
- **"Infrastructure as code" or "Terraform".** Ansible for config management is a different kind of work from provisioning.
- **EKS, Helm, ArgoCD, GitOps, Istio, Vault and Go**, as skills-list entries, even with "familiar with" or "exposure to". Nothing in your material supports any of them.
- **"Owned reliability", "SRE practices", or "improved developer experience".** Maintaining jobs and building a pipeline is not the same as owning reliability, and no outcome is stated.

## Parse-safety check (reported from your description only; I haven't seen the file)

| Check | What I can see | What it costs | Provenance |
|---|---|---|---|
| Multi-column layout | Yours is a two-column PDF. | Parsers read linearly and can interleave the columns, and dates can detach from their roles. | `[grounded]` your description; `[generic]` how parsers fail |
| Contact details in the header | They sit in a "header", but I can't tell if that's a plain text banner at the top or a true page-header or image. | A true page header or an image can be discarded, and then you're unreachable. A plain text banner is fine. Could not check. | `[grounded]` your description; `[generic]` how parsers treat page headers |
| Icons for each skill | Icons are used per skill. | If a skill appears only as an icon, with no text label, the skill is absent to a parser. Could not check. | `[grounded]` your description; `[generic]` how parsers treat images |
| Text layer, section headings, text boxes | Not visible from a description. | Could not check. | `[generic]` |

To test it yourself, open the PDF, select all, paste into a plain-text editor, and read the order. If the columns interleave or your contact details are missing, that is a parse problem. A text-layer PDF or a .docx is the safe file type.

## Upgrade menu

- **The resume file itself (PDF or .docx):** I could quote your exact sentences and run the parse checks on the real file instead of a description.
- **A repo, PoC write-up, or any inspectable artifact:** it would let me write `[grounded]` rows for C1 to C3.
- **Answers to the questions below:** each one that confirms something becomes a row, after a confirmation card where I restate your answer for you to check. Anything you say you didn't do closes that requirement.

## Questions

C1 — When you ran the Kubernetes proof-of-concept, what did it run on (EKS or something else), and did you use Helm, Argo CD, or Prometheus and Grafana with it?
C2 — Have you ever used Terraform or GitLab CI, at work or on the side, even something small?
C3 — Who depends on your Jenkins pipeline, and were you ever on call or the person fixing it when it broke?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.