I'll read the reference files the skill points to before building the ledger.
Dev, here's the ledger. Nothing is applied. The JD's one hard must-have, 3+ years of data engineering, isn't something your five years as an analyst can support, and I haven't written around it. Each row below is a change to your own wording, and every row traces to a sentence of yours.

Whether this role is worth applying to with that must-have unmet is job-underwriter's question, so I've left it out of this ledger.

## Edit ledger (pending your approval)

Target order for Experience: star schema, dbt models, nightly job, SQL, then Python.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience, bullet 1 | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to the first bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E2 | Experience, bullet 2 | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the second bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| E3 | Experience, bullet 3 | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks; added tests to it." | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E4 | Experience, bullet 4 | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved to the fourth bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` resume | pending your approval |
| E5 | Experience, bullets 5 and 6 | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis: pandas." and, as its own bullet, "Some scripting to pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E6 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |

- **E1:** "with our then-DE" stays. The design was shared, and dropping the qualifier would make it a solo claim.
- **E3:** "when it breaks" stays. It describes repair work, and I haven't turned it into ownership of the job.
- **E5:** "for analysis" and "some" stay. Splitting only puts the cron/API scripting where a reader will see it. It doesn't make it production Python.
- **E6:** I kept it as three separate sentences, each from your own, so none reads as bigger than it is.
- **Title:** your title stays as it is, with no retitle row.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years data engineering | must-have | not_evidenced | Nowhere. Your five years are titled Senior Data Analyst. See A1. | `[grounded]` resume title and "5 years"; `[generic]` a years-of-experience must-have is checked by whoever reads the resume first |
| M2 | Production Python | important | not_evidenced | E5 shows what exists: analysis, plus some cron scripting. Neither is stated as production. See C2. | `[grounded]` resume's Python sentence |
| M3 | Airflow or equivalent orchestration | important | not_evidenced | The resume doesn't say what runs the nightly dbt job. See C1. | `[grounded]` "Never used Airflow or Spark." |
| M4 | Dimensional modelling, model the warehouse | important | surfaced_by_edit | E1, E2, E6 | `[grounded]` resume |
| M5 | Own data quality | important | surfaced_by_edit | E3 shows tests added. Ownership isn't claimed. | `[grounded]` resume |
| M6 | Own SLAs | important | not_evidenced | See C3. | `[grounded]` resume doesn't mention deadlines or owners |
| M7 | Build and own batch pipelines | important | not_evidenced | E3 shows repair work on one job. Building and owning it isn't stated. See C3. | `[grounded]` resume |
| M8 | Spark (named in the duties, not in Requirements) | preferred | not_evidenced | See A2. | `[grounded]` "Never used Airflow or Spark." |
| M9 | Streaming, Kafka | preferred | not_evidenced | See A2. | `[grounded]` "Never touched Kafka." |
| M10 | Partner with analytics on requirements | important | not_evidenced | See A3. | `[grounded]` resume |

## Gap handling

**Recall prompts (pending your approval).** Each of these could become a real row if you can supply evidence.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | important | "I've fixed our nightly dbt job when it breaks", but not what schedules or runs it | The JD's "or equivalent" is the only route to this requirement, and it needs a tool the resume names | what triggers the nightly dbt run (a dbt scheduler, cron, another tool) and whether you configured it; retries or failure alerts you set up; ordering between your vendor-API pulls and the dbt run | scheduler config, a repo, a screenshot of the job's run history | `[grounded]` what the resume does and doesn't say; `[generic]` an orchestration requirement is read as "have you run scheduled, dependent jobs" |
| C2 | Production Python | important | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." That is analysis use, with scheduling unstated beyond cron | The JD says production Python, and the resume currently shows analysis scripts | vendor-pull scripts that feed a table other people depend on; logging, retries or error handling in them; code kept in version control or reviewed | the script repo, a pull request, the cron entry | `[grounded]` what the resume does and doesn't say; `[generic]` "production" is read as other people depending on the code |
| C3 | Own batch pipelines and SLAs | important | Repairs and tests on one nightly job; ownership and deadlines unstated | The JD's duties are "own data quality and SLAs", and a repair story doesn't show ownership | whether you were the named owner or the first person pinged when it broke; a deadline by which the data had to be ready; a specific failure you diagnosed and fixed | a runbook, an alert channel, a post-incident note | `[grounded]` what the resume does and doesn't say; `[generic]` ownership questions are probed in interviews |

**Named absences.** For each of these I have nothing to pull.

| # | Requirement | Priority | The gap | What closing it would take | Provenance |
|---|---|---|---|---|---|
| A1 | 3+ years data engineering | must-have | Your five years are titled Senior Data Analyst, and the adjacent work in E1 to E3 isn't stated as data-engineering work. | Only a period of data-engineering work you haven't listed would close it. If there isn't one, the honest closing path is a different target: roles asking for fewer years, or analytics-engineering roles. For this posting it likely can't be closed now. | `[grounded]` resume; `[generic]` must-have years requirements are the ones a reader checks first |
| A2 | Spark, Kafka, streaming | preferred | You've never used any of them. | A small hands-on project, such as consuming a Kafka topic and landing it in Redshift. It would be listed as a personal project, never as work experience. Or leave it, since it's a plus rather than a requirement. | `[grounded]` "Never used Airflow or Spark. Never touched Kafka." |
| A3 | Partner with analytics on requirements | important | You sat on the analytics side, and the resume has no sentence about gathering or handing over requirements. | Nothing to write. The honest place for this is the interview, in your own words. | `[grounded]` resume |

## Not written, and why

- **"3+ years of data engineering experience"**: your five years are as an analyst.
- **"Built and owned batch pipelines"** or **"ELT/ETL pipelines"**: the JD's word is "pipelines", but you built dbt models and repaired and tested one nightly job. That is a different kind of work.
- **"Airflow or equivalent orchestration experience"**: you've never used Airflow, and the resume doesn't say what schedules the dbt job.
- **"Production Python"**: what you wrote is analysis and some cron scripting.
- **"Owned data quality and SLAs"**: you added tests to a job. You didn't say you owned quality or any deadline.
- **"Partnered with analytics on requirements"**: you were the analytics side, so the word would flip which side of the table you stood on.
- **"Designed the warehouse"**: you designed one star schema for the orders mart, with the then-DE.
- **Spark, Kafka or streaming in any skills list**: you've never used them.
- **Any "Data Engineer" or "Analytics Engineer" title**: a retitle may only be an equivalent, never an upgrade.

## Parse-safety check

Your resume arrived as pasted prose, so I could not run any of these checks: multi-column layout, tables and text boxes, images or skill bars, contact details in headers or footers, non-standard section headings, and file type. Send the file and I'll run them. I have no parsing findings to report.

## Upgrade menu

- **Evidence that would help:** a dbt project docs or lineage view of the orders mart, the vendor-API script repo, and the nightly job's schedule config. Any of these would back M2, M3, M4 and M5 with something inspectable.
- **Proposal, built only if you approve:** a one-line objective such as "Moving from analytics into data engineering." It would trace to your own statement of intent, not to experience, and it adds a line the ledger rules would otherwise not allow, so it needs your explicit yes.

## Questions

C1 — What actually triggers your nightly dbt run, and did you set up or change that scheduling or its failure alerts?
C2 — Do your vendor-API cron scripts feed tables other people rely on, and do they have logging, retries or code review?
C3 — When the nightly job breaks, are you the named owner or first responder, and is there a deadline the data has to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.