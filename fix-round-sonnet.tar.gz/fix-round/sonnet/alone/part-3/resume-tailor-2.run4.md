Dev, here is the full ledger. Nothing is applied. Every row is pending your approval.

- **Your text.** I worked from the prose you pasted, not from the resume file. Each "Current line" is one of your own sentences. If your real bullets are worded differently, tell me and I'll re-trace.
- **What the map shows.** R4 and R6 are the only rows `surfaced_by_edit`. The 3+ years of data engineering, production Python, orchestration and Spark/streaming rows are `not_evidenced`, and I have not written around any of them.
- **Whether to apply.** Whether to apply with that must-have gap is job-underwriter's question, not this ledger's.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your resume text | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to second bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume text | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | *(unchanged, moved to third bullet)* | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume text | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Bullet A (fourth): "Some scripting to pull vendor APIs on a cron". Bullet B (fifth): "Python for analysis — pandas" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume text | pending your approval |
| E5 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved to sixth bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your resume text | pending your approval |
| E6 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume text | pending your approval |

- **Order:** E1–E3 put the dbt, modelling and nightly-job work first, and E4 Bullet A puts the cron scripting directly below them. These are the bullets closest to this posting, so a reader who stops early meets them first.
- **Qualifiers kept:** "about" stays on the 25 models and "some" stays on the scripting. "With our then-DE" stays on the star schema.
- **The only wording change** is that E4 and E6 drop the "I" for resume voice. The summary is kept as three separate sentences, so no claim is joined into a bigger one.
- **The title** stays "Senior Data Analyst".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Your title and years are analytics. The adjacent work (dbt, star schema, nightly job) is in E1–E3, but no years of it are stated. Length of experience is not a hard gate. See C1. | `[grounded]` your resume says Senior Data Analyst, 5 years |
| R2 | Production Python | important | `not_evidenced` | You describe Python "for analysis" plus "some scripting" on a cron. Nothing says those scripts run in production. See C2. | `[grounded]` your resume text |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | You have never used Airflow. The nightly dbt job and the cron are adjacent (E3, E4), but what schedules the dbt job isn't stated. See C3. | `[grounded]` your resume text |
| R4 | Dimensional modelling / model the warehouse | important | `surfaced_by_edit` | E2 and E6 lift the star schema to the top. It is a shared design ("with our then-DE"), not a sole one. | `[grounded]` your resume text |
| R5 | Data quality | important | `surfaced_by_edit` | E3 carries "added tests". It says tests, not a data-quality framework. | `[grounded]` your resume text |
| R6 | SLAs | important | `not_evidenced` | Nothing stated about delivery deadlines. Named absence below. | `[grounded]` your resume text |
| R7 | Spark (batch pipelines) | important | `not_evidenced` | You have never used it. The posting lists it in the duties, not in the requirements list. Named absence below. | `[grounded]` your resume text |
| R8 | Streaming (Kafka) | preferred | `not_evidenced` | You have never touched Kafka. Named absence below. | `[grounded]` your resume text |
| R9 | Partner with analytics on requirements | important | `not_evidenced` | You sat on the analytics side. Nothing says you gathered requirements as an engineer. Named absence below. | `[grounded]` your resume text |

## Gap handling: recall prompts (rows only; questions are in the closing block)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | 5 years as a Senior Data Analyst, with dbt, star-schema and nightly-job work. It does not say how much of those years was pipeline work. | It is the posting's only must-have, and the page currently has no data-engineering years on it. | Weeks where fixing failed loads or modelling was most of your job; time working beside the then-DE; ingestion or scheduling you handled yourself | A dbt repo history, a runbook, an on-call or incident thread, a handover note | `[grounded]` what the resume does and does not say; `[generic]` what a must-have gap costs on applications of this kind |
| C2 | Production Python | important | "Python for analysis", plus "some scripting to pull vendor APIs on a cron". | The word "production" is what the posting asks for, and the page doesn't say whether these scripts feed anyone. | Vendor-API scripts whose output a dashboard or team relied on; scripts that alerted when they failed | The script repo, the cron entry, the downstream table or dashboard | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Airflow or equivalent orchestration | important | You fix and test a "nightly dbt job", and you run a cron. What triggers and monitors the dbt job isn't stated. | The posting accepts "equivalent" orchestration, so what actually runs your job decides whether anything counts. | A scheduler (dbt Cloud, cron, another tool) running the nightly job; retries, dependencies or alerts you configured | Scheduler config, the job definition, an alert history | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Gap handling: named absences

- **R6, SLAs:** nothing in your material mentions a delivery deadline. Closing it means a job where someone depended on a finish time. If the nightly job had one, send me the deadline and who consumed the output, and it becomes a row. Otherwise it stays out.
- **R7, Spark:** you have never used it. Closing it takes a Spark job you build on a public dataset and keep in a repo you can show. Until then it stays out of the resume.
- **R8, Kafka and streaming:** you have never touched it, and it is listed as a plus. Closing it takes a small producer/consumer project you can show. Until then it stays out, and not carrying it is acceptable for this role.
- **R9, partnering with analytics:** you were the analytics partner, not the engineer being partnered with, and writing it the other way round would flip which side of the table you stood on. Closing it needs a case where you gathered requirements from analysts for data work you built. That is covered by C1.

## Not written, and why (`pending your approval` for none; these are refusals)

- **"Data Engineer" as a title, or "5 years of data engineering":** your title is Senior Data Analyst and your years are analytics.
- **"Built and owned batch pipelines":** you fixed and tested a nightly dbt job and wrote some cron scripts. Building and owning pipelines is a different job.
- **"Production Python":** you said Python for analysis and some scripting. Production is the posting's word, not yours.
- **"Orchestrated workflows" or "Airflow-equivalent experience":** you wrote "cron" and "nightly dbt job". Equating them with orchestration would be the posting's word on your history.
- **"Ingestion pipelines from vendor APIs":** your word is "scripting to pull".
- **"Owned the warehouse model" or "led dimensional modelling":** you designed the orders-mart star schema with the then-DE, which is not sole ownership of the warehouse.
- **"Owned data quality and SLAs":** you added tests. Nothing says you owned a quality framework or any SLA.
- **Spark, Kafka or streaming in any skills list:** you have never used them. A listed tool would read as an owned tool.
- **"Partnered with analytics":** you were the analyst.
- **Hidden keywords or white text:** not requested, and never offered.

## Parse-safety check

The resume arrived as pasted text, so I could not run any of these. Your real file would let me check them.

| Check | Result |
|---|---|
| Multi-column layout | Could not run (pasted text) |
| Tables and text boxes | Could not run |
| Images, icons, skill-level bars | Could not run |
| Contact details in headers or footers | Could not run |
| Non-standard section headings | Could not run; the proposed Summary and Experience headings are conventional |
| File type | Could not run; a `.docx` or text-layer PDF is the safe pair |
| Hidden text already in the file | Could not run |

## Upgrade menu (offers, nothing built)

- **Attach the resume file:** unlocks the parse-safety checks above and verbatim traces to your actual bullets.
- **Link or screenshot of the dbt project docs or lineage for the orders mart:** upgrades the 25 models and the star schema from self-report to inspectable.
- **The vendor-API script repo or README:** gives C2 something to stand on.
- **Answers to C1–C3:** each one can turn a `not_evidenced` row into a real one.

## Questions

C1: Were there stretches in your five years when pipeline work (ingestion, scheduling, fixing failed loads, modelling) was most of your week, and for roughly how long?
C2: Do the vendor-API cron scripts feed something other people depend on, and if so, what?
C3: What triggers and monitors the nightly dbt job: dbt Cloud, cron, another scheduler, something else?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.