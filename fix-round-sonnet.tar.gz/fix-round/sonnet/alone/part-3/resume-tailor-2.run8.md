I'll read the reference files the skill requires before building the ledger.
Dev, here is the ledger. Nothing is applied yet. Every row waits for your approval, and I haven't built a resume.

I worked from your prose only, so I don't have your real section order, dates, or employer names. Positions below are relative to the bullets you described. The one hard point is that the JD's only must-have, 3+ years of data engineering, is not evidenced in what you gave me. A resume can still lead with your pipeline-adjacent work, and it does that below (E1 to E6). Whether to apply with that gap is job-underwriter's question, not this skill's.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line, assumed)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your prose | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your prose | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to the second bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your prose | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | *(unchanged, moved to the third bullet)* | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your prose | pending your approval |
| E5 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks and added tests to it." | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your prose | pending your approval |
| E6 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `compress` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your prose | pending your approval |

- **E5 and E6** only drop the first person. "For analysis", "some scripting", and "when it breaks" stay, because those qualifiers are the honest part.
- **E3** keeps "with our then-DE". Removing it would turn a shared design into a solo one.
- **E1** repeats E2 and E3 on purpose, so a reader who stops early still meets your strongest DE-adjacent evidence. The SQL and window-function line stays where it is, as there is nothing to change on the page.

## Coverage map

The JD labels only the 3+ years as must-have. I rated the other listed requirements and responsibilities `important`, and streaming `preferred` because the JD says "a plus".

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | `not_evidenced` | Your material shows five years as an analyst with some pipeline-adjacent work. No DE role or DE-time share is stated. See C1. | `[grounded]` |
| 2 | Production Python | important | `not_evidenced` | Your Python is described as "for analysis", plus cron scripts. E6 shows it exactly as written. See C2. | `[grounded]` |
| 3 | Airflow or equivalent orchestration | important | `not_evidenced` | You named a nightly dbt job and cron, but nothing says what schedules or monitors the job. See C3. | `[grounded]` |
| 4 | Dimensional modelling | important | `surfaced_by_edit` | E1 and E3 | `[grounded]` |
| 5 | Model the warehouse (dbt models) | important | `surfaced_by_edit` | E1 and E2. It is one mart plus about 25 models, and the rows say that. | `[grounded]` |
| 6 | Data quality | important | `surfaced_by_edit` | E4 and E5 ("added tests"). The claim stays at tests, not ownership. | `[grounded]` |
| 7 | SLAs | important | `not_evidenced` | Named absence N1 | `[grounded]` |
| 8 | Spark and Kafka pipelines | important | `not_evidenced` | Named absence N2 | `[grounded]` |
| 9 | Partner with analytics on requirements | important | `not_evidenced` | Named absence N3 | `[grounded]` |
| 10 | Streaming experience | preferred | `not_evidenced` | Named absence N2 | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | Five years as a Senior Data Analyst. DE-type work appears as dbt models, a star schema, and nightly-job fixes. It never states how long or how much of your time that was. | A titled-years must-have is plausibly read literally by whoever screens, so unstated DE time risks reading as none. | Time spent maintaining the dbt project and nightly job; the stretch where you built the orders mart; any period when pipeline work was a large share of your week | dbt repo history, PR dates, a run-failure log, a team doc listing who maintained what | `[grounded]` what the resume does and does not say; `[generic]` how a stated years requirement tends to be screened |
| C2 | Production Python | important | "Python for analysis" and "some scripting to pull vendor APIs on a cron". That reads as analysis scripting, and nothing says anyone depended on the scripts. | The JD says "production", and your current wording does not show whether the scripts ran unattended for others. | Cron scripts feeding a table a team or dashboard used; scripts with retries or alerts; scripts someone else was relying on | The script repo, cron config, a failure alert, a dashboard fed by the pulls | `[grounded]` what the resume says; `[generic]` what "production" is usually read to mean |
| C3 | Airflow or equivalent orchestration | important | A nightly dbt job you fixed and added tests to. It does not say what triggers, schedules, or monitors it. | The JD accepts "or equivalent", but your material doesn't yet show any scheduler, so the claim has nothing to rest on. | A scheduler running the nightly dbt job (dbt Cloud, cron, or another tool); dependencies between runs; alerts when it failed | The job config, scheduler screenshots, a failure notification, a runbook | `[grounded]` what the resume says; `[generic]` what a screener may accept as "equivalent" |

## Named absences

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| N1 | SLAs | Nothing in your material mentions a delivery deadline or an agreement for the nightly job. | A stated time or a stakeholder who relied on the job finishing by then would be enough to write a row. Without that, there is nothing to say. | `[grounded]` the gap; `[generic]` what closing it takes |
| N2 | Spark, Kafka, streaming | You said "Never used Airflow or Spark. Never touched Kafka." No streaming work is evidenced. | A small public project running a Spark batch job and a Kafka consumer would turn this into evidence. Until you have it, it stays off the resume. Streaming is "a plus", so it isn't blocking. | `[grounded]` the gap; `[generic]` what closing it takes |
| N3 | Partner with analytics | Your material shows you on the analytics side, plus one design done with a DE. It shows no work in a DE role serving analysts. | There is no line to write. E3 already carries the one collaboration you stated, and flipping which side you stood on is what the audit forbids. | `[grounded]` the gap; `[generic]` what closing it takes |

## Not written, and why

- **A "Data Engineer" or "Analytics Engineer" title.** You are a Senior Data Analyst, and a retitle has to be an equivalent, not an upgrade.
- **"3+ years of data engineering experience."** Your material doesn't state it, and C1 is how it could become true on paper.
- **"Built production pipelines" or "production Python".** You wrote "for analysis" and "some scripting on a cron".
- **"Orchestrated pipelines" or "workflow orchestration".** That is the JD's word. You fixed a nightly job and ran cron scripts.
- **"Owned data quality" or "owned SLAs".** You added tests. Nothing in your material mentions an SLA.
- **"Modelled the warehouse".** You designed one mart's star schema with a DE.
- **"dbt models on Redshift".** You wrote SQL on Redshift and built dbt models, but never linked the two.
- **Any Spark, Kafka, or streaming claim.** You said you haven't used them.
- **"Partnered with analytics".** It changes which side of the table you were on.

## Parse-safety check

You pasted plain text, so I couldn't run the layout checks (columns, tables, text boxes, icons, headers and footers). I can't assess the file type or heading names either. If you send the actual file, I'll run them. I found no hidden text in what you pasted, and I wouldn't add any. Keep contact details in the page body, not the header, so they survive parsing.

## Upgrade menu

- **Your actual resume file.** It would unlock the parse-safety checks, real section order, dates, and employer names, so the reorders (E2 to E4) can name exact positions.
- **A dbt project snapshot or PR history.** It could turn E1 to E5 into dated, checkable evidence and might answer C1.
- **The vendor-API cron scripts or their config.** They could support or rule out a production-Python line (C2).
- **A scheduler config or runbook for the nightly dbt job.** It could support an orchestration line (C3) or confirm it isn't there.
- **A small Spark or Kafka project.** It would convert N2 from an absence into a row.

## Questions

C1 — Roughly how many years, and what share of your time in them, went on dbt, pipeline, or modelling work rather than analysis?
C2 — Did your vendor-API cron scripts run unattended, and did anyone or any dashboard depend on their output?
C3 — What actually triggers your nightly dbt job (dbt Cloud, cron, something else), and what tells you when it fails?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.