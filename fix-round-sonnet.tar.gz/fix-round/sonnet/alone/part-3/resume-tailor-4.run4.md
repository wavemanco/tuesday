Your premise is only partly supported by the evidence, so I'll start there.

**"The ATS is rejecting me on keywords."**
- **Auto-rejection is uncommon.** One vendor interviewed 25 US recruiters and reported "AI/content auto-rejection configured: 8% of recruiters". That is two people, in a sample the vendor itself says shows themes rather than representative statistics.
- **Knockout questions reject more often.** The same interviews say "When automated filters are used, they're almost always knockout questions", meaning work authorization, a required license or location, answered on the application form. Nothing on your resume changes those.
- **Match scores mostly set review order.** "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile". In that sample, "56% either ignore the feature or don't have it available". Keywords probably feed those scores, but that part is inference.
- **Parsing is the more likely silent failure.** A two-column Canva PDF with icons and contact details in the header can lose content before anyone reads it. I couldn't inspect the file, so the check is below.
- **This sample is small, so none of this is certain.** It can't tell you why *you* were rejected.

**Why keyword edits won't do much here.** Most of this JD's stack isn't in what you've told me: Terraform, EKS, ArgoCD, Istio, Prometheus/Grafana, Vault, Helm, GitLab and Go. I can't write those in, and I won't. What I can do is make what you have findable, keep your Kubernetes proof-of-concept's qualifier attached, and ask about things you may have done but not written down. Whether this role is worth applying to is job-underwriter's question; I haven't tried to answer it.

I worked from your description, not the file, so the quotes below come from your message.

## Edit ledger

Every row is `pending your approval`.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | *(unchanged — moved directly under the Jenkins pipeline bullet)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | `[grounded]` your description | pending your approval |
| E2 | Skills | "Bash and Python scripting" | "Python and Bash scripting" | `reorder` | "Bash and Python scripting" | `[grounded]` your description | pending your approval |
| E3 | Skills | *(Kubernetes not in the skills list)* | "Kubernetes (two-month proof-of-concept, not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | `[grounded]` your description | pending your approval |
| E4 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |

- **E3:** the qualifier stays in the skills line, because a tool listed isn't a tool owned.
- **E4:** it stays three separate sentences, so none of the claims fuse. If you'd rather not lead with "never went to production", reject E4 and keep E1 and E3, which carry the same qualifier lower down.

## Coverage map

I read the JD as unranked and treated the core stack plus reliability ownership as `must-have` and the rest as `important`. Correct me if you know otherwise.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | surfaced_by_edit | E1, E3, E4; proof-of-concept only, and the lines say so | `[grounded]` your PoC sentence |
| R2 | AWS | must-have | already_evidenced | "AWS (EC2, S3, RDS, IAM)" as written; EKS is R3 | `[grounded]` your skills line |
| R3 | AWS EKS | must-have | not_evidenced | C3 asks whether the PoC ran on EKS | `[grounded]` EKS appears nowhere in your description |
| R4 | Terraform | must-have | not_evidenced | C1; you list Ansible for config management, which is not the same tool or job | `[grounded]` Ansible line; `[generic]` Terraform provisions infrastructure where Ansible configures it |
| R5 | CI/CD | must-have | surfaced_by_edit | E4 puts the Jenkins pipeline in the top lines; I did not add the string "CI/CD" | `[grounded]` Jenkins pipeline sentence |
| R6 | GitLab | important | not_evidenced | Named absence below | `[grounded]` you list Jenkins only |
| R7 | Python | must-have | surfaced_by_edit | E2 | `[grounded]` "Bash and Python scripting" |
| R8 | Go | important | not_evidenced | Named absence below | `[grounded]` Go appears nowhere in your description |
| R9 | Helm, ArgoCD, GitOps | important | not_evidenced | C3 | `[grounded]` none appear in your description |
| R10 | Prometheus, Grafana, observability | important | not_evidenced | C2 and C3; CloudWatch for monitoring is on your resume but I haven't relabelled it | `[grounded]` CloudWatch line |
| R11 | Istio, service mesh | important | not_evidenced | Named absence below | `[grounded]` not in your description |
| R12 | Vault | important | not_evidenced | Named absence below | `[grounded]` IAM is listed; secrets management is not |
| R13 | SRE practices; owning reliability and developer experience | must-have | not_evidenced | C2 | `[grounded]` not in your description |

## Recovery per gap

Three of these gaps may be things you've done but didn't write down.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform | must-have | Ansible for config management; no infrastructure-as-code tool for provisioning | It's listed second in the JD and nothing on your resume answers it | A module or stack for a side project; Terraform written by a teammate that you edited; a migration from console-built resources | A repo, a PR, a plan output | `[grounded]` what the resume says; `[generic]` a missing listed tool costs most when it's one of the first named |
| C2 | SRE practices; owning reliability and developer experience | must-have | Maintaining about 30 Jenkins jobs and CloudWatch monitoring; no incidents, on-call, alerting or developer-facing work stated | The JD closes on "own platform reliability and developer experience", so this is the role itself | On-call rotations; alerts you set up; a post-incident write-up; developers relying on your pipeline or jobs | An alert config, a post-mortem, a runbook | `[grounded]` what the resume says; `[generic]` a closing responsibility line tends to describe the role's core |
| C3 | AWS EKS, Helm, ArgoCD/GitOps, Prometheus/Grafana | must-have (EKS), important (rest) | A two-month Kubernetes proof-of-concept with no stated contents | The JD lists these around Kubernetes, so what the proof-of-concept contained decides how much of R3, R9 and R10 is real | The cluster ran on EKS; you deployed with Helm charts; you tried a GitOps tool; you scraped metrics with Prometheus | A PoC write-up, a repo, a diagram | `[grounded]` the PoC sentence; `[generic]` stack items cluster around Kubernetes work |

**Named absences.** Each says what closing it would take.

| Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|
| R6 GitLab | You have Jenkins pipeline experience and no GitLab CI. | A small project with a `.gitlab-ci.yml` would make it a true line, about a weekend of work. | `[grounded]` your description; `[generic]` the effort estimate |
| R8 Go | No Go anywhere. | Real Go means a small tool you wrote and can talk about, weeks rather than days. It's the cheapest gap to leave open if the rest matches. | `[grounded]` your description; `[generic]` the effort estimate |
| R11 Istio, service mesh | Nothing near it. | It needs production Kubernetes first, so it isn't closable without R1 becoming real. Not worth chasing for this application. | `[grounded]` your description; `[generic]` mesh work presupposes a running cluster |
| R12 Vault | Nothing stated. IAM is access control, not secrets management. | A local Vault setup in your proof-of-concept or a home lab would give you something honest to say. | `[grounded]` your IAM line; `[generic]` IAM and Vault do different jobs |

## Not written, and why

**Nothing below is applied.** These were the lines a less careful rewrite would have produced.

- **"Terraform / infrastructure-as-code experience"**: you have Ansible. Different tool, and the JD's word would be going into your history.
- **"Kubernetes in production" or "managed Kubernetes"**: you ran a two-month proof-of-concept that never shipped. An interviewer will ask what it served.
- **"EKS", "Helm", "ArgoCD", "GitOps", "Prometheus", "Grafana"**: none is in your description. C3 asks whether any is true.
- **"Observability"** for CloudWatch monitoring: the JD's word, and it widens what you did.
- **"CI/CD with GitLab"**: your pipeline is in Jenkins.
- **"Platform Engineer"** as a retitle for DevOps Engineer: an upgrade, not an equivalent.
- **"SRE practices" or "owned reliability"**: nothing in your description says you did it.
- **"Developer experience"** for maintaining 30 Jenkins jobs: it's a different kind of work, unless C2 shows otherwise.

## Parse-safety check

I couldn't inspect the file, so some of this rests on your description.

| Check | Finding | What it costs |
|---|---|---|
| Multi-column layout | Risk: you described two columns | Parsers read linearly, so the columns can interleave and detach dates from roles |
| Icons per skill | Risk, and I can't tell which kind: icons next to text are probably skipped, but icons standing in for skill names or levels would be absent | Skills could vanish from the parsed text |
| Contact details in header | Risk | Headers are often treated as page furniture and dropped, so you could become unreachable |
| Hidden text | Could not run; I need the file | Inherited from a template, it would be a liability you can't see |
| Section headings, file type | Could not run; I need the file | A Canva PDF may be a text layer or flattened images |

A quick check is to open the PDF, select all, paste into a plain-text editor, and see what survives and in what order.

## Upgrade menu

These are offers, not part of the ledger:
- **The PDF itself.** It would let me run the headings, hidden-text and text-layer checks.
- **Answers to C1–C3.** These are the most valuable input. Each answer turns a `not_evidenced` row into a real line, after a confirmation step.
- **The PoC write-up, repo, or an older resume version.** Any of these would add `[grounded]` rows.

## Questions

- **C1** — Have you written any Terraform, even a small module, a side project, or edits to someone else's code?
- **C2** — Have you been on-call, built alerts, or written up an incident, and do other developers depend on your pipeline or jobs?
- **C3** — What did the Kubernetes proof-of-concept actually include: EKS or something else, Helm charts, any GitOps tool, any Prometheus or Grafana?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.