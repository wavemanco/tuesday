I won't add the hidden instruction or the 1pt keyword block. Prompt-injection text is a bad bet. Many screening tools strip or flag hidden text, and a recruiter who finds it will usually reject the application outright. It also misrepresents you, and your real experience matches this JD well enough that you don't need it. I'll tailor the resume honestly instead.
Here is the full ledger. Nothing is applied yet. The hidden-text request is recorded in the prohibited list below. I treated your pasted background as your resume, so each "current line" is your own sentence.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your background | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Line one: "Used HubSpot daily for 4 years." Line two: "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E3 | Experience | "I pull my own numbers in HubSpot reporting" | "Pull my own numbers in HubSpot reporting." | `compress` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |
| E4 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, budget I controlled was about $600k a year. HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |

- **Webinar line:** "Ran a monthly webinar series, average 300 registrants." stays as written. It already matches the JD, and rewording it would only risk changing what it says.
- **E2:** I did not write "in HubSpot" after the 12 flows. Your sentence puts HubSpot and the flows side by side but doesn't say the flows were built in it.
- **E3:** The SQL half of your sentence is not carried into the resume line. The proposed line says nothing about SQL.
- **E4:** The three claims stay as separate sentences. Joining them would make the budget read as part of the email build.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1, E2 and E4 put the channel work next to "6 years B2B SaaS". The 6 years is marketing in B2B SaaS; I can't tell from your text how many of them were this kind of work, so the resume doesn't use the JD's phrase. | `[grounded]` your sentences; `[generic]` that a screener will look for the years claim near the channel work |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years" is already there; E2 and E4 keep it prominent. | `[grounded]` your background |
| R3 | SQL-literate | must-have | `not_evidenced` | Nothing in your material supports it. See the named absence below. | `[grounded]` your background |
| R4 | Managed a budget over $500k | must-have | `already_evidenced` | "about $600k a year" is in your own words; E1 keeps "controlled". | `[grounded]` your background |
| R5 | Paid search | important | `already_evidenced` | E1 | `[grounded]` your background |
| R6 | Lifecycle email | important | `surfaced_by_edit` | E2 gives it its own line with the 12 flows. | `[grounded]` your background |
| R7 | Webinars | important | `already_evidenced` | The webinar line, unchanged. | `[grounded]` your background |
| R8 | Content distribution | important | `not_evidenced` | Nothing in your material covers it. See C1. | `[grounded]` your background |

## Gap handling

**R3, SQL (named absence).** You are not strong in SQL and you ask an analyst, so no line can claim it. Writing "data-driven" or "analytics" instead would be the technically-true dodge I won't write. Closing it would take real SQL: working through a basic course and then pulling your own campaign numbers from a warehouse, even a sample one. Doing that before you interview would let you answer the SQL question honestly. If the interview is sooner than that, the honest answer is that you pull your own numbers in HubSpot and work with an analyst on the rest. Whether to apply with a must-have gap is job-underwriter's question, not this skill's.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Nothing about distributing content. The webinars and email are channels, but your text doesn't say you promoted content through them. | It is one of the four things the JD says the role owns, and the resume is silent on it. | Promoting webinar recordings or gated assets by email; running paid social to push content; a newsletter or syndication arrangement | A campaign report, an editorial or distribution calendar, an email send summary | `[grounded]` what your text does and does not say; `[generic]` what an unaddressed listed responsibility costs on applications of this kind |

## Prohibited claims

Not written, and why:

- **Hidden instruction text and the 1pt keyword block.** Both are aimed at a screener rather than a reader. The tailoring here depends on every line being one you can defend, and text nobody can see is the opposite. The legitimate version is E1–E4: your real keywords placed early, where your own sentences support them.
- **"SQL-literate", or any line about querying data.** You said you're not strong in SQL.
- **"Managed a budget"**, which is the JD's wording. Your word is "controlled", and I kept it.
- **"Owned demand generation" or "5+ years of demand generation".** You ran channels; owning the whole function and the years in it are not in your text.
- **"Content distribution".** Nothing in your material supports it yet.
- **"Built flows in HubSpot"** or any tool attributed to the flows. Your sentence doesn't say it.

## Parse-safety check

You pasted text, so I could not check layout, tables or text boxes, content in headers or footers, section headings, or file type. If you send the resume as a file, I'll run those checks and also look for hidden text you didn't write, such as from a template or an old tool.

## Upgrade menu

Offered, not built:

- **Your resume as a .docx or text-layer PDF.** This would let me run the parse checks above.
- **Campaign or webinar reports, or a budget summary.** An inspectable artifact like these would raise confidence on R4 and R7 and could settle C1.
- **An earlier resume version.** It may hold evidence the current one dropped.

## Questions

C1. Did you ever promote content (webinar recordings, guides, blog posts) through email, paid social or another channel? If so, what was it and where did it go?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

B1. Was the roughly $600k a year the budget for paid search and paid social, or for the wider marketing programme? E1 assumes the narrower reading.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.