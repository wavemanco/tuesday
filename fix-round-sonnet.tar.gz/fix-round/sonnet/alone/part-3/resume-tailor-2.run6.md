Dev, the main finding comes first. The JD's one hard must-have is "3+ years data engineering", and your resume doesn't show that. You have 5 years as a Senior Data Analyst, with real data-engineering-adjacent work inside the role. Nothing I can reword turns that into 3 years in a data engineering role. The ledger below is therefore small: it reorders and surfaces what you wrote and adds no claims. The gaps are named in the coverage map, not written around. Whether to apply at all, given that must-have, is a separate question for job-underwriter.

Nothing below is applied. Every row is pending your approval.

## Edit ledger (pending your approval)

Your lines stay in your own words. I haven't dropped "I" or tightened any bullet, because each such change risked shifting a verb or a qualifier.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to the first bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the second bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | *(unchanged, moved to the third bullet)* | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | *(unchanged, moved to the fourth bullet)* | `reorder` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved to the last bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your resume | pending your approval |

- **E1** repeats three of your sentences as three separate sentences. I did not join the modelling to the dbt models in one clause. "With our then-DE" stays attached to the star schema, so the co-design is visible.
- **E2–E6** change position only. E2–E4 lead with the lines nearest the JD (modelling, dbt and warehouse work, and nightly job upkeep). SQL moves last because the JD doesn't ask for it.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years data engineering | must-have | `not_evidenced` | No row can carry it. Your title is Senior Data Analyst, and the named absence is G1. | `[grounded]` your title and "5 years"; `[inferred]` a years-in-title requirement may be read literally |
| M2 | Production Python: Python itself | must-have | `already_evidenced` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." Moved up by E5. | `[grounded]` your resume |
| M3 | Production Python: "production" | must-have | `not_evidenced` | Your words are "for analysis" and "some scripting", so I haven't claimed more. See C2. | `[grounded]` your resume |
| M4 | Airflow or equivalent orchestration | must-have | `not_evidenced` | You wrote "Never used Airflow". The nightly dbt job is adjacent, but fixing a job is not orchestrating it. See C1. | `[grounded]` your resume |
| M5 | Dimensional modelling | must-have | `surfaced_by_edit` | Star schema bullet, via E1 and E2. The co-design with the then-DE stays visible. | `[grounded]` your resume |
| M6 | Build and own batch pipelines | important | `not_evidenced` | The vendor-API cron scripts and nightly dbt job are adjacent, but "build and own" isn't claimed. See C2 and C3. | `[grounded]` your resume |
| M7 | Data quality: tests | important | `surfaced_by_edit` | "added tests to it", via E4. This is as far as the line goes. | `[grounded]` your resume |
| M8 | Data quality: SLAs | important | `not_evidenced` | Nothing on SLAs appears in your material. Named absence G2. | `[grounded]` your resume |
| M9 | Partner with analytics on requirements | important | `not_evidenced` | You sit on the analytics side, and your resume describes working with the DE, not as the DE. I haven't flipped that. | `[grounded]` your resume |
| M10 | Streaming, Spark and Kafka | preferred | `not_evidenced` | "Never used Airflow or Spark. Never touched Kafka." Named absence G3. | `[grounded]` your resume |

## Gap handling: recall prompts (the questions are in the closing block)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | must-have | A "nightly dbt job" you fix and add tests to. It doesn't say what schedules or triggers it. | The JD lists orchestration as a must-have, and your resume currently has no line a reader could count toward it. | Configuring the dbt Cloud or other scheduler; setting job dependencies or run order; setting up alerts or retries on the nightly run | The job config, a schedule screenshot, a run history | `[grounded]` what the resume does and doesn't say; `[generic]` what an unmet must-have costs on a posting like this |
| C2 | Production Python / build batch pipelines | must-have | "some scripting to pull vendor APIs on a cron" under "Python for analysis". It doesn't say where the data lands, who depends on it, or what happens when it fails. | This is your best candidate for batch-pipeline evidence, but at the moment it reads as an analyst's side script. | Loading the pulled data into Redshift for others' use; handling failures or retries; other people or dashboards depending on it | The scripts in a repo, the cron setup, a failure postmortem | `[grounded]` what the resume says; `[generic]` what thin pipeline evidence costs here |
| C3 | 3+ years data engineering | must-have | You wrote "with our then-DE", which could mean the DE has since left. Your material doesn't say. | If you took over pipeline work from them, that could be the one thing that moves M1 and M6. If you didn't, the gap stands. | Taking over the DE's jobs or models; being the person who fixed pipelines when they broke; on-call or support for data loads | A handover note, a team announcement, a prior resume version | `[grounded]` the "then-DE" wording; `[inferred]` that it may mean a departure, which is a question and not a claim |

**Named absences**

- **G1: 3+ years data engineering.** You haven't held a data engineering role. Closing it would mean either showing that part of your 5 years was genuinely DE-shaped work (C3), or targeting roles that ask for fewer titled years, or analytics-engineering scopes. For this posting, wording can't close it.
- **G2: SLAs.** You haven't written about any. Closing it would mean a service-level commitment you owned for a pipeline or the nightly job, such as a "data ready by 7am" expectation. If one existed, it's one question away. If not, it's a gap.
- **G3: Streaming, Spark and Kafka.** You've never used them, and streaming is only "a plus". Closing it would take a real project, such as a small Kafka-to-Redshift pipeline, which means months of work and not a rewrite. For this application it isn't worth closing, because the must-haves matter more.

## Not written, and why

- **"Data Engineer" as a title, or "3+ years data engineering"**: never held. The coverage map names the gap.
- **"Built and owned batch pipelines"**: you wrote cron scripts that pull vendor APIs and you fix a nightly job. Owning a pipeline is different work, and it would be the first interview follow-up.
- **"Production Python"**: your own words are "for analysis" and "some scripting".
- **"Orchestrated pipelines (Airflow-equivalent)"**: fixing a job when it breaks is not orchestrating it, and you've never used Airflow.
- **"Owned data quality and SLAs"**: you added tests to one job and wrote nothing about SLAs.
- **"Modelled the warehouse"**: you designed one star schema, for one mart, with the then-DE.
- **"Partnered with data engineering"**: that's the JD's word, and it would reverse which side of the table you described.
- **Streaming, Spark or Kafka anywhere, including in a skills list**: you've never used them.
- **"Analytics engineer"**: not your word, and not something your resume says.

## Parse-safety check

You pasted the resume as text, so I could only check what's visible. The section headings I can see are conventional, and the "—" characters are plain text. I **couldn't** run the multi-column, table or text-box, image or skill-bar, header or footer, or file-type checks. If you send the file itself, I'll run them, and I'll also look for hidden text from an old template.

## Upgrade menu

- **dbt project or job config**: models, tests and the schedule for the nightly job. It could move M4 and M7 and raise confidence on E3 and E4.
- **The vendor-API scripts, or a description of where they write**: it could move M3 and M6, and turn the cron scripting into a stronger line.
- **A prior resume version, performance review or handover note mentioning pipeline work**: it could move M1 and M6.
- **Offer, built only if you say yes**: a second ledger aimed at analytics-engineer or junior-DE roles. It would add a version scoped to what your resume can honestly carry, and this posting's must-have shows the gap is real.

## Questions

C1 — What triggers your nightly dbt job (dbt Cloud scheduler, cron, another tool), and did you set up or change its schedule, dependencies or alerts?
C2 — For the vendor-API scripts, where does the data land, who or what relies on it, and what happens when a pull fails?
C3 — When you wrote "our then-DE", did that person leave, and if so, what pipeline work did you pick up?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.