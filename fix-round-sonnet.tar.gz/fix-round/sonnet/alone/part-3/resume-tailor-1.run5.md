I'll read the reference files the skill requires before building the ledger.
I tailored your CV to the Tessellate role. The ledger, coverage map and open gaps are below, and nothing is applied until you approve rows.

I worked from your message, so each "current line" is your sentence as you wrote it, not your actual CV bullet. If you send the CV file, I'll re-run the ledger against its real lines. I added nothing you didn't say, and I used your wording rather than the JD's.

## Edit ledger

`resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV | pending your approval |
| E2 | Experience (1st) | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E3 | Experience (2nd) | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, placed second, directly under E2)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV | pending your approval |
| E4 | Experience (3rd) | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E5 | Experience (4th) | *(second half of the sentence in E4)* | "Have run six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E6 | Experience (5th) | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on the team, usually two or three a year; pair with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |
| E7 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Languages: Go, Rust, Python. Also: Kafka, Postgres, Terraform, gRPC, Datadog." | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV | pending your approval |

- **E4 and E5:** your sentence doesn't say whether the six incidents fall inside the two on-call years. Splitting them keeps each claim at what you stated.
- **E6:** it keeps "usually". It also uses your "onboard" and "pair", not "mentor".
- **E7:** the tools are listed, not claimed as owned.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 gives the 7 years. Your sentence says "Senior Software Engineer", not backend, so I didn't relabel it. E2 shows the services work. | `[grounded]` |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1 and E7 carry "Go and Rust daily for 4 years". You didn't say which language the three services use, so I didn't link them. | `[grounded]` |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | The 40k requests/minute service (E2) is adjacent. Nothing you wrote describes distributed design, and Kafka is only a listed tool. See C1. | `[grounded]` |
| R4 | Owning high-volume services | important | `surfaced_by_edit` | E2. You say "own", not "design and ship". | `[grounded]` |
| R5 | Driving down p99 latency | important | `already_evidenced` | Already in your bullet as written. E3 only moves it up. | `[grounded]` |
| R6 | Owning on-call | important | `surfaced_by_edit` | E4. You didn't say the rotation covers your own services, so I didn't write that. | `[grounded]` |
| R7 | Strong incident response | must-have | `surfaced_by_edit` | E5, "six incidents as incident commander". | `[grounded]` |
| R8 | Experience mentoring | must-have | `surfaced_by_edit` | E6. It shows onboarding and a month of pairing. Whether the new hires were mid-level isn't stated. | `[grounded]` |
| R9 | Partnering with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material touches this. See C2. | `[grounded]` |
| R10 | Build-cache or developer-tools domain | preferred | `not_evidenced` | Named absence below. | `[grounded]` |

## Gaps

| # | Requirement | Priority | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | A service at about 40k requests/minute at peak, and Kafka in a tools list. It doesn't say how the services interact or what Kafka does for you. | It's a must-have, and the only support on the page is a number and a tool name. | A service that consumes or produces Kafka events; a ledger write path spanning several services; handling retries, duplicates or ordering between services | A design doc, an architecture diagram, a post-incident review involving more than one service | `[grounded]` what your CV does and doesn't say; `[generic]` what a must-have with thin support costs on applications of this kind |
| C2 | Partnering with product on roadmap sequencing | important | No mention of product work. | It's a named duty in the posting. | Pushing back on or reordering a product request for technical reasons; a quarter where you and a PM chose what ships first | A planning doc, a roadmap thread, a launch note | `[grounded]` what your CV doesn't say; `[generic]` what an unaddressed duty costs on applications of this kind |

**R10, named absence.** Nothing you've written touches build systems or developer tooling. Closing it would take real work on build or CI infrastructure. The posting lists no requirement tied to it, so I'd leave it open and not stretch the balance-read cache work to cover it. That work is a different kind of cache problem.

## Not written, and why

- **"Senior Backend Engineer" as your title:** your title is "Senior Software Engineer", and the JD's title would be the posting's word for your history.
- **"Production Go services":** you said Go daily and you said you own three services, but never that those services are Go.
- **"Designed and shipped Go services":** you said "own", which is a different verb.
- **"Distributed systems at scale":** that's the JD's phrase. You gave a request rate, not an architecture.
- **"Mentored mid-level engineers":** the word is "mentored" instead of your "onboarding" and "pair", and you never gave the new hires' level.
- **"Owned on-call for my services":** you described a rotation, not whose services it covered.
- **"Six incidents in two years":** the window isn't stated.
- **"Partnered with product on roadmap":** there's nothing behind it.
- **A percentage for the p99 drop, or any MTTR or incident-impact figure:** the 380ms to 95ms figures are yours, and the rest would be mine.
- **Build-cache or developer-tools experience:** none stated.

## Parse-safety check

I couldn't run any of the six checks because the CV came as pasted text, not a file. Those checks cover layout, tables, images, headers and footers, section headings and file type. Send the actual file and I'll run them.

## Upgrade menu

- **Your actual CV file:** the ledger gets built against your real bullets, and the parse-safety check can run.
- **A design doc or post-incident review for the ledger pipeline:** it could support the distributed-systems row (C1).
- **A dashboard screenshot or write-up of the balance-read p99 work:** it would back the 380ms to 95ms figures with something inspectable.
- **A planning doc or roadmap thread:** it could support the product-partnership row (C2).

## Questions

C1 — In your ledger pipeline, how do your three services interact (for example Kafka events, calls between them), and what part did you own?
C2 — Have you worked with a product manager on what to build or what ships first? If so, give one concrete example.
E6 — Were any of the new hires you onboarded mid-level engineers, and did you keep supporting them after the first month?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.