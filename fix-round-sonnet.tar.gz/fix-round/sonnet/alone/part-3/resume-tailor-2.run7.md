I'll read the reference files before building the ledger.
Dev, here's the tailoring for the Bellhaven Data Engineer role. Your material supports a tighter resume: the star schema, dbt and nightly-job work move to the top. It does not support the posting's must-have of 3+ years of data engineering, and no wording changes that. The gaps are in the coverage map below. Whether to apply with that must-have unmet is job-underwriter's question, not this ledger's.

You gave me prose rather than a file, so the "Current line" column quotes your own sentences. Nothing here is applied.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | "Senior Data Analyst, 5 years, retail." | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models, including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E2 | Experience | Order as written: SQL, dbt models, Python, nightly job, star schema | New order: star schema, dbt models, nightly job, Python, SQL. Wording unchanged except E3 to E5. | `reorder` | "I designed the star schema for the orders mart with our then-DE."; "Built and maintained about 25 dbt models including the core orders mart."; "I've fixed our nightly dbt job when it breaks and added tests to it."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron."; "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` resume | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks." and "Added tests to our nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `compress` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E5 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." | `compress` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E6 | Experience | "Never used Airflow or Spark. Never touched Kafka." | *(removed from the resume)* | `cut` | "Never used Airflow or Spark. Never touched Kafka." | `[grounded]` resume | pending your approval |

What the rows keep:
- **E1, E5:** "with our then-DE" stays. You co-designed the schema, so no row says you led it.
- **E3:** the line says "fixed" and "added tests", not "owned", "maintained" or "monitored".
- **E4:** "some scripting" keeps its "some", and the line does not say "production".
- **E6:** this is a note to me, not resume content. Dropping it adds no claim.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years data engineering | must-have | `not_evidenced` | Your five years are an analyst title and nothing in your material describes data engineering work. E1 to E5 show adjacent work, which is not the same thing. | `[grounded]` resume title and sentences; `[generic]` titled-years requirements are often read against job titles |
| M2 | Production Python | important | `not_evidenced` | Your Python is analysis plus "some scripting" on a cron. Nothing says it ran in production. See C2. | `[grounded]` resume |
| M3 | Airflow or equivalent orchestration | important | `not_evidenced` | You never used Airflow. Nothing says what scheduled the nightly dbt job, so an equivalent can't be claimed. See C1. | `[grounded]` resume |
| M4 | Dimensional modelling | important | `surfaced_by_edit` | E1 and E5 put the star schema first. I kept your words, "star schema", rather than the posting's "dimensional modelling". | `[grounded]` resume |
| M5 | Build and own batch pipelines | important | `not_evidenced` | The nightly dbt job and the vendor API scripts are nearby, but you fixed and tested the job and wrote "some scripting". Neither is "build and own". See C3. | `[grounded]` resume |
| M6 | Data quality | important | `surfaced_by_edit` | E3 puts "Added tests to our nightly dbt job" on its own line. It shows tests on one job, not ownership of data quality. | `[grounded]` resume |
| M7 | SLAs | important | `not_evidenced` | Nothing in your material mentions a freshness or delivery commitment. See C3. | `[grounded]` resume |
| M8 | Streaming experience, Kafka | preferred | `not_evidenced` | You never touched Kafka. Named absence below. | `[grounded]` resume |
| M9 | Partner with analytics on requirements | important | `not_evidenced` | You sat on the analytics side for five years. Nothing describes you gathering requirements as the engineer. Named absence below. | `[grounded]` resume |

## Recovery per gap

Recall prompts, where something might exist to pull:

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | important | A "nightly dbt job" and scripts "on a cron", with no mention of what scheduled or monitored them. | The posting names Airflow or an equivalent, and today the resume gives a reader nothing to count as one. | dbt Cloud or another scheduler running the nightly job; dependencies between the job and the cron scripts; alerting or retries you configured; an orchestrator someone else ran that you worked inside | The job's scheduler config, a dbt lineage graph, a screenshot of the run history | `[grounded]` what the resume does and does not say; `[generic]` orchestration is a core duty of roles like this |
| C2 | Production Python | important | Python "for analysis" and "some scripting to pull vendor APIs on a cron". | "Production" is the posting's qualifier, and your sentence is the only evidence for it. | Other people or dashboards depending on the API scripts; the scripts in version control; failure handling or logging you added; how long they ran unattended | The scripts in a repo, a README, a commit history | `[grounded]` what the resume does and does not say; `[generic]` what screeners tend to look for under this phrase |
| C3 | Build and own batch pipelines, and SLAs | important | You fixed a job and added tests. "Our then-DE" implies the DE is no longer there, but your material doesn't say what passed to you. | This is the closest your history gets to the 3+ years must-have, so the real scope of your work there matters most. | Taking over the DE's jobs or backfills; being the person paged when the orders mart was late; a morning-freshness expectation from stakeholders | A handover note, an on-call or incident thread, a stakeholder message about the mart's timing | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

Named absences:
- **Spark:** it appears in the posting's duties, not its requirements list, and you have never used it. Closing it would take hands-on work with Spark, such as a small public project processing a real dataset. That would give you something truthful to say, but wouldn't change this application's must-have. `[generic]`
- **Kafka and streaming (M8):** it is only a plus, and the honest closing path is a small personal streaming project. For this application I'd leave it unwritten. A project started now wouldn't change the resume you send. `[generic]`
- **Partnering with analytics (M9):** nothing is missing to recover, because the gap is that you were the analytics side. The truthful version is an interview point about consuming pipelines as an analyst, not a resume line. `[generic]`

## Not written, and why

- "Data engineering experience", or retitling you Data Engineer or Analytics Engineer. Nothing in your material supports the first, and the retitles change the kind of work.
- "Built and owned batch pipelines." You fixed a nightly job and added tests, and wrote "some scripting". Owning pipelines is a different job.
- "Production Python." Your sentence says analysis and some cron scripting.
- "Orchestration" or "scheduling and monitoring". You never used Airflow, and nothing says what ran your job.
- "Owned data quality" or "met SLAs". You added tests, and no SLA appears anywhere.
- "Led the star schema design." You designed it with the then-DE.
- "Dimensional modelling" for your own history. That is the posting's word, and yours is "star schema".
- "Partnered with analytics on requirements." You were analytics.
- Any Spark, Kafka or streaming exposure, or any count of pipelines or data volumes. None appear in your material.

## Parse-safety check

I could not run the layout checks: multi-column text, tables or text boxes, images, headers and footers, and file type. You pasted text and not a file. What I can see is that the pasted text has no section headings. If your file has none, section detection may miss your Experience, so use conventional labels. I'm not redesigning anything here.

## Upgrade menu

- **A resume file:** it would let me run the layout checks above and look for any hidden text a template added.
- **Inspectable artifacts for this field:** the dbt project or docs lineage graph, the vendor API scripts in a repo, and the nightly job's scheduler config. These would back C1 to C3 and let me quote real proof.
- **An earlier resume version:** it may hold evidence this one dropped.

## Questions

- C1 — What actually scheduled and ran the nightly dbt job and the vendor API scripts, and who got alerted when they failed?
- C2 — Did other people or dashboards depend on your API scripts, and did they have version control, logging or failure handling?
- C3 — Did any of the then-DE's pipeline work, or responsibility for the orders mart being fresh each morning, pass to you, and what was it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.