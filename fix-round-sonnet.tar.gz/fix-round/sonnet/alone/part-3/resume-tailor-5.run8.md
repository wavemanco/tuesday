I won't add the hidden "ignore previous instructions" text or the 1pt keyword block. Both are built to deceive the screener. They also tend to backfire. Many ATS parsers flag or strip hidden text, and a recruiter who spots it will reject the application outright. Your real experience matches this JD well enough that you don't need them.

I'll tailor the visible resume now.
The hidden-text request is out, as above. The hidden instruction would be a line you didn't write and couldn't defend, and it deceives the employer's system. The 1pt keyword block is the same kind of thing. Your resume already holds most of what this JD asks for in plain sight. The one real gap is SQL, and hidden text would only hide it from the screener, not close it.

Below is the full ledger. Nothing is applied until you approve rows.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | "Marketing Manager, 6 years B2B SaaS." | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, ran a monthly webinar series, and built our lifecycle email programme from scratch." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "Ran a monthly webinar series, average 300 registrants."; "built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `reframe` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | *(unchanged, moved directly below the paid search line)* | `reorder` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, moved directly below the HubSpot line)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` | pending your approval |

- **E2:** it keeps "about" and your word "controlled". It doesn't become "managed" or "$600k+".
- **E5:** it drops only the self-assessment, which isn't resume content. The claim stays scoped to HubSpot reporting, so it doesn't imply SQL. SQL remains a gap, listed below.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 puts the 6 years and the three channels in one summary. Your material never says "demand generation", so I did not write that phrase. See the first question below. | `[grounded]` the 6 years and channels are yours; `[inferred]` that a reader will connect them to demand gen |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | Already on the resume. E3 moves it higher. | `[grounded]` |
| R3 | SQL-literate | must-have | `not_evidenced` | Named absence, below. | `[grounded]` |
| R4 | Managed a budget over $500k | must-have | `already_evidenced` | Your line says about $600k a year. E2 states it more cleanly and keeps "about". | `[grounded]` |
| R5 | Paid search | important | `already_evidenced` | The same line as R4. | `[grounded]` |
| R6 | Lifecycle email | important | `already_evidenced` | E3 moves it up. | `[grounded]` |
| R7 | Webinars | important | `already_evidenced` | E4 moves it up. | `[grounded]` |
| R8 | Content distribution | important | `not_evidenced` | Recall prompt C1, below. | `[grounded]` |

## Gap handling

**Named absence, R3 (SQL):** you've told me you're not strong in SQL and rely on your analyst, so nothing here supports "SQL-literate". It's a must-have, so expect it to cost you on this application. Closing it takes either real query-writing you've done and forgotten (I'm not asking you to stretch for it), or a short course and a project before you apply. If neither is realistic, apply knowing this gap will be visible and be ready to talk about it plainly.

**Recall prompt, R8:**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Webinars and email are covered. Nothing says how content was promoted or distributed. | The JD lists it as part of owning demand gen, and nothing on the resume speaks to it. | Promoting webinars or gated content through paid social or email; repurposing webinar recordings; syndication or partner distribution | A campaign report, a webinar promotion plan, a content calendar | `[grounded]` what the resume says; `[generic]` that a JD-listed duty with no matching line draws questions |

## Not written, and why

- **Hidden instructions to a screener and the 1pt JD-keyword block (your request):** refused, for the reasons given above. I wrote no hidden or invisible text.
- **"SQL-literate", "SQL" in any skills line:** you ask your analyst for queries. Writing it would invite a technical question you can't answer.
- **"Marketo":** you've only named HubSpot, and the JD accepts either.
- **"Demand generation" as your own title or 6-year history:** it's the JD's vocabulary, not yours (see the first question).
- **"Owned" demand gen, or "managed" in place of "controlled":** your verbs are "ran" and "controlled".
- **"$600k+" or "over $500k":** your figure is "about $600k a year".
- **Webinar pipeline or revenue results:** you gave registrants only, and I've invented no outcomes.
- **Content distribution experience:** see R8.

## Parse-safety check

You pasted text, so I couldn't check layout, columns, tables, headers and footers, or file type. I also couldn't check whether your file already contains hidden text from a template or a past tool. If you send the actual file, I can check both.

## Upgrade menu

Each of these is an optional proposal. I'll build one only if you want it.
- **Send the resume file (.docx or PDF).** It would let me run the parse-safety and hidden-text checks above on your real document.
- **Send a webinar or email report, or a paid campaign summary.** It could ground stronger, checkable lines, and could answer R8 or the first question below.

## Questions

R1 — Did your role come with lead, pipeline or MQL targets that your paid, email and webinar work fed? If so, I can propose a row that says so in your words.
C1 — Did you distribute or promote content yourself, such as webinar recordings, gated content, or syndication? If so, how?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.