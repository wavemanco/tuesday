I'll read the reference files the skill points to before building the ledger.
Short version: I don't think keyword matching is your main problem, and I won't write the missing keywords into your resume. Below are the evidence on screening, the ledger, and what your material does and doesn't cover.

## What the evidence says about ATS rejection

| # | Claim | Source | Provenance |
|---|---|---|---|
| P1 | Content-based auto-rejection exists but is uncommon in the one small sample available: "AI/content auto-rejection configured: 8% of recruiters" (cite C25), two people in a sample the vendor calls themes, not representative statistics | Résumé-builder vendor's interviews of 25 US recruiters | `[grounded]` citations.md C25 |
| P2 | What most often rejects without a person is the application form: "When automated filters are used, they’re almost always knockout questions" (cite C26), such as work authorization, licence and location. Nothing in your resume changes those | Same interviews | `[grounded]` citations.md C26 |
| P3 | Match scores mostly order who gets reviewed first: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27). That keywords drive those scores is an inference | Same interviews | `[grounded]` citations.md C27; `[inferred]` keyword effect on scores |

Truthful keywords placed where your evidence supports them can help you rank. Invented ones can't, and I haven't written any. Hidden or white-text keyword blocks are something I won't do. They deceive the employer's software, and they put a line on your resume you couldn't defend if asked about it.

The parse-safety check below does find a real risk. The bigger issue is in the coverage map: most of this JD's stack isn't in your material, so a person reading it would see the gaps too.

## Edit ledger

Everything is limited to what your own sentences support. Nothing is applied.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | Same items as plain text, one per line, with Python listed ahead of Bash: "Python and Bash scripting" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` resume | pending your approval |
| E2 | Skills | *(Kubernetes not listed)* | "Kubernetes (two-month proof-of-concept, not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E3 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | "Built our deploy pipeline in Jenkins" | `split` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` resume | pending your approval |
| E4 | Experience | *(second half of the same line)* | "Maintain about 30 Jenkins jobs" | `split` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` resume | pending your approval |
| E5 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, moved to directly after the Jenkins bullets)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |

- **E2 and E5 keep "not in production" and "never went to production."** Removing the qualifier would turn a trial into operating experience.
- **E3 and E4 are one sentence split into two bullets.** The pipeline and the 30 jobs are both yours, and a short bullet is easier for a parser or a person to take in. Neither half is developed further.
- **No title change.** "DevOps Engineer" stays. "Platform Engineer" would be the JD's title, not yours.

## Coverage map

The JD doesn't tier its requirements. I treated the headline platform stack as must-have and the rest as important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Kubernetes | must-have | `surfaced_by_edit` | E2, E5. This shows a two-month trial, not production operation, and a reader will see that. | `[grounded]` resume |
| M2 | Terraform | must-have | `not_evidenced` | C1 | `[grounded]` absent from resume |
| M3 | AWS EKS | must-have | `not_evidenced` | C3. Your AWS list has no EKS. | `[grounded]` absent from resume |
| M4 | ArgoCD, GitOps | must-have | `not_evidenced` | C1 | `[grounded]` absent from resume |
| M5 | Prometheus, Grafana, observability | must-have | `not_evidenced` | C2. CloudWatch is adjacent, not the same. | `[grounded]` resume says "CloudWatch for monitoring" only |
| M6 | SRE practices, owning platform reliability and developer experience | must-have | `not_evidenced` | C2 | `[grounded]` absent from resume |
| M7 | CI/CD pipelines | must-have | `surfaced_by_edit` | E3, E4. This is a Jenkins pipeline, not GitLab. | `[grounded]` resume |
| M8 | Python | must-have | `already_evidenced` | E1 moves it earlier | `[grounded]` resume |
| M9 | AWS | important | `already_evidenced` | EC2, S3, RDS and IAM are listed as written | `[grounded]` resume |
| M10 | Helm | important | `not_evidenced` | C1 | `[grounded]` absent from resume |
| M11 | GitLab CI | important | `not_evidenced` | Named absence below | `[grounded]` absent from resume |
| M12 | Go | important | `not_evidenced` | Named absence below | `[grounded]` absent from resume |
| M13 | Istio, service mesh | important | `not_evidenced` | C3, then a named absence if the PoC didn't touch it | `[grounded]` absent from resume |
| M14 | Vault | important | `not_evidenced` | Named absence below | `[grounded]` absent from resume |

## Gap handling: recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform, Helm, ArgoCD or GitOps | must-have | Ansible for config management and a Jenkins pipeline. No infrastructure-as-code or declarative-delivery tool is named. | Terraform is the second tool in the JD and has no counterpart on your resume. | Terraform modules at work or in a side project; Helm charts used in the PoC; a Git-driven deploy flow of any kind | A repo, a module, a PR, a diagram | `[grounded]` what the resume does and doesn't say; `[generic]` what an unmatched headline tool costs on applications of this kind |
| C2 | Prometheus, Grafana, SRE practices | must-have | "CloudWatch for monitoring" is the only observability item. | The JD ends on owning reliability, and nothing on your resume shows reliability work beyond monitoring. | Dashboards or alerts you built; on-call or incident work; any SLO or error-budget conversation | A dashboard screenshot, an alert-rule list, a postmortem | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on applications of this kind |
| C3 | EKS, Istio and service mesh | must-have | A two-month Kubernetes proof-of-concept that never reached production. Where it ran and what it included isn't stated. | If the PoC ran on EKS, that is the closest honest match you have to the JD's cluster platform. | EKS versus self-managed; ingress or a mesh trial; what you demoed and to whom | The PoC write-up or repo | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on applications of this kind |

## Gap handling: named absences

- **Go.** Nothing in your material shows it. Closing it means writing something in Go that you can show, for example a small tool replacing one of your Bash scripts. For this role it's a smaller gap than Terraform or observability.
- **GitLab CI.** Your pipeline experience is Jenkins. Closing it means building one real pipeline in GitLab, even a personal one. Until then, the Jenkins pipeline is your honest equivalent.
- **Vault.** Nothing in your material shows it. Closing it means a hands-on secrets-management project, or accepting it as a learn-on-the-job item. It's listed last in the JD, so it's a poor use of effort first.
- **Istio and service mesh.** This closes only if C3 turns up mesh work in the PoC. If not, it stays a named absence, closed by a mesh trial on a test cluster.

## Not written, and why

- "Platform Engineer": that's the JD's title, not yours.
- "Terraform", "IaC", "Helm", "ArgoCD", "GitOps": nothing in your material shows them.
- "Kubernetes in production", "container orchestration", "EKS": you ran a two-month PoC that never went to production, and EKS isn't stated.
- "Observability", "Prometheus", "Grafana": CloudWatch monitoring is adjacent work, not the same kind of work.
- "SRE practices" and "owned platform reliability": nothing you wrote describes reliability ownership, on-call, or SLOs.
- "Developer experience": maintaining 30 Jenkins jobs is not the same as owning how developers work.
- "CI/CD (GitLab)": you built a Jenkins deploy pipeline, and GitLab isn't mentioned.
- "Go": absent from your material.
- "Service mesh" and "Vault": absent from your material.

## Parse-safety check

I could only check what you described. I didn't see the PDF, so I couldn't check its file type, whether it has a text layer, or whether it contains hidden text, and I haven't looked for any.

| Check | What breaks | What it costs for your resume | Ran? |
|---|---|---|---|
| Multi-column layout | Parsers read linearly and interleave the columns | Dates can detach from the roles they belong to, and skills can mix into experience | Yes, from your description |
| Icons for each skill | Rendered as garbage characters or skipped | Any skill shown only by an icon or level graphic is absent to a parser | Yes, from your description |
| Contact details in the header | Header content is often treated as page furniture and discarded | A recruiter could lose your email and phone | Yes, from your description |
| Section headings | Parsers look for conventional labels | Can't judge without the text | No |
| File type | Varies by parser | A `.docx` or a text-layer PDF is the safe pair | No |

This skill reports parse risks and doesn't redesign documents.

## Upgrade menu (offered, built only if you ask)

- **Your actual resume file.** It would let me run the hidden-text and file-type checks properly, and it would show whether the Canva export has a real text layer.
- **The PoC write-up or repo.** It could move C1 and C3 from missing to evidenced.
- **Anything on dashboards, alerts or on-call.** It could move C2 from missing to evidenced.
- **An older resume version.** Earlier versions often hold evidence the current one dropped.

Whether to keep applying to roles with this many unmatched requirements is job-underwriter's question, not this skill's.

## Questions

C1 — Have you used Terraform, Helm or ArgoCD anywhere, including in a side project or as part of the PoC?
C2 — Beyond CloudWatch, have you built dashboards or alerts, been on call, or taken part in incident reviews?
C3 — Did the Kubernetes PoC run on EKS, and did it include anything like Istio or ingress?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.