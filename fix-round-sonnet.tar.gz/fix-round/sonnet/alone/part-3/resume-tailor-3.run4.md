I've built the ledger below. Nothing is applied yet, and every row is pending your approval.

- **Dossier use:** The dossier's `role_profile` matches this JD, so I used it in place of a separate JD intake.
- **E1:** This is the dossier's pending edit. It still traces to your sentence, so I kept it, and it went through the same audit as my own rows.
- **Layout:** I only have your CV as prose, not the document. Each "Current line" is your sentence as you gave it. The reorder rows assume your lines currently sit in a different order, so tell me if that's wrong.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV; dossier E1 | pending your approval |
| E2 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged — moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged — moved to third bullet, after the playbook line)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E5 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged — placed directly after the Experience bullets)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |

- **E2:** It stays two sentences. Joining them would make the 30+ integrations read as the whole seven years.
- **Titles:** No row retitles you. "Never held a PM title" stays true on the page.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | The dossier marks this `adjacent`, with a transferability gap and `medium` confidence. "Never held a PM title" and no roadmap or prioritisation authority is evidenced. No edit closes it; see G1. | `[grounded]` your CV; dossier evidence_map R1 |
| R2 | Shipped API or platform products | important | `not_evidenced` | The dossier marks this `adjacent` at `medium`. E3 puts your integration work first, but leading integrations of your employer's APIs doesn't establish shipping them. See G2. | `[grounded]` your CV; dossier evidence_map R2 |
| R3 | Technical fluency | important | `already_evidenced` | REST integrations, Postman, SQL and OpenAPI specs are on the page as written. E3 and E5 only move them earlier. | `[grounded]` your CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | The client side is covered by E3 and E4. Nothing in your material covers stakeholders inside a product or engineering organisation. | `[grounded]` your CV |
| R5 | Own the roadmap (JD responsibility) | important | `not_evidenced` | E4 shows you collected client feedback for product, which is input to a roadmap and not ownership of one. See G3. | `[grounded]` your CV; dossier evidence_map R1 reasoning |
| R6 | Run discovery with integration partners (JD responsibility) | important | `not_evidenced` | Closest is E4, but its line stays "collecting client feedback". See G3. | `[grounded]` your CV |
| R7 | Write specs and drive delivery with engineering squads (JD responsibility) | important | `not_evidenced` | Your CV says you're comfortable in OpenAPI specs. It says nothing about writing specs or working with engineering on delivery. See G2. | `[grounded]` your CV |
| R8 | Define adoption metrics (JD responsibility) | important | `not_evidenced` | Nothing in your material mentions measuring adoption. See G4. | `[grounded]` your CV |

## Recovery per gap

**G1 is a named absence.** Seven years in a different role doesn't count as the 3+ years of PM the posting lists as a must-have. Closing it would take PM-scope work you've already done, such as owning a prioritisation decision, which G2 to G4 below may surface. Otherwise it only closes by holding the title. It can't be closed by wording.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G2 | Shipped API or platform products; specs and delivery with engineering squads | important | You led client integrations of your employer's APIs. It doesn't say you specified, built or released any API or feature. | Two engineering squads sit under this role, and an API-product role leaves less room to be taken on trust for shipping. | A feature or API change you specified that reached release; an OpenAPI spec you wrote for something that went out; a client-driven change you carried through with engineers | a spec, release note, changelog entry or ticket trail | `[grounded]` what your CV does and doesn't say; `[generic]` what this costs on applications of this kind |
| G3 | Roadmap ownership; discovery with integration partners | important | Quarterly sessions collecting client feedback "for product". It doesn't say what you decided or influenced afterwards. | Roadmap ownership is the first responsibility the JD lists, and the dossier already flagged prioritisation authority as not evidenced. | Feedback from your sessions that changed what product built; a prioritisation call you made or argued for; a structured set of partner conversations you ran | session notes, a feedback summary, a roadmap item you can point to | `[grounded]` what your CV does and doesn't say; `[generic]` what this costs on applications of this kind |
| G4 | Adoption metrics | important | Nothing about measuring how clients used the APIs. | The JD names defining adoption metrics as a responsibility. | Integrations live per quarter; time to first successful call; a go-live tracker you kept | a spreadsheet, dashboard or report | `[grounded]` what your CV does and doesn't say; `[generic]` what this costs on applications of this kind |

## Not written, and why

- **"Product management experience" or "3+ years PM"**: you've never held the title and the JD makes it a must-have. The gap is named in R1 and G1.
- **"Owned the roadmap"**: you ran sessions that collected feedback for product. Feeding someone's roadmap is a different job from owning it.
- **"Shipped API products"**: you led client integrations of your employer's APIs, which is a different kind of work from shipping the product.
- **"Ran discovery with integration partners"**: the posting's words are "discovery" and "partners". Yours are "collecting client feedback" and "client".
- **"Wrote or defined specs"**: your sentence is "Comfortable in … OpenAPI specs", which doesn't say you wrote them.
- **"Defined or drove adoption metrics"**: nothing in your material mentions it.
- **"Worked with engineering squads"**: not in your material.
- **Dossier rejected inference, carried unaltered:** "built an internal request-triage tool — memory lead, candidate could not confirm ownership".
- **Dossier rejected inference, carried unaltered:** "has been the customer of a partner API platform — candidate worked vendor-side".

## Parse-safety check

You gave me pasted prose, so I could not run any of the checks: columns, tables or text boxes, images or icons, header or footer content, section headings, or file type. I also couldn't look for hidden text inherited from a template. If you send the file itself, I'll run all of them.

## Upgrade menu

These are offers, built only if you say yes.

- **Your CV as a `.docx` or PDF:** it unlocks the parse-safety checks above and lets me replace my layout assumptions with your real line order.
- **The integration playbook, or an excerpt:** it would turn E1 from your self-report into something inspectable.
- **Answers to G2 to G4:** each confirmed answer can become a new traced row, or close a gap for good.
- **Prior CV versions or a work sample:** they would add more rows grounded in your own wording.

## Questions

G2 — Did you ever write a spec or request that engineers built and released, and what was your part in it?
G3 — In your quarterly roadmap-input sessions, did you have any say in what product prioritised afterwards?
G4 — Did you track anything about how clients adopted the APIs, even informally?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.