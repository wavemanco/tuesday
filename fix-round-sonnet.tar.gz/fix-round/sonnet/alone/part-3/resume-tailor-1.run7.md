I've loaded the tailoring rules and built the ledger from the CV text you pasted. Every row traces to a sentence of yours, and nothing is applied until you approve it.

**Reading of the JD** (the requirement priorities used in the map below)
- **Must-have:** 5+ years backend, production Go, distributed systems at scale, strong incident response, mentoring experience.
- **Important:** owning services, high request volume, p99 latency, on-call ownership, product partnership on roadmap sequencing.

## Edit ledger — `resume_edits_pending_approval`

The lines keep your wording as you pasted it, so they are not yet converted to resume voice.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Currently at a payments company. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV text | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged — moved to the first bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV text | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV text | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Line 1: "On-call rotation every fourth week for two years". Line 2: "Have run six incidents as incident commander" | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV text | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | *(unchanged — moved to the last bullet)* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV text | pending your approval |
| E6 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Go, Rust, Python; Kafka, Postgres, Terraform, gRPC, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV text | pending your approval |

- **E4:** the split pulls the incident-commander claim out so it can be read on its own. Both halves keep your qualifiers.
- **E6:** the tools stay in your order and are only listed, not described as owned.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `not_evidenced` | Your CV says 7 years as a software engineer and 4 years of daily Go/Rust. It never says how many of those years were backend. E1 states the 7 years as you wrote them. See C1. | `[grounded]` the CV text states 7 years and 4 years of Go/Rust and no backend count; `[generic]` a reader counts only what is stated |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1, E2 and E6 put Go and the services you own where a first read meets them. | `[grounded]` your CV text |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | E2 shows one service at about 40k requests/minute and E6 lists Kafka. Neither says what you designed or ran across systems. See C2. | `[grounded]` the CV text gives a request rate and a tool list only |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E4 makes six incidents as incident commander a line of its own. | `[grounded]` your CV text |
| R5 | Experience mentoring | must-have | `surfaced_by_edit` | E5 shows onboarding and pairing for the first month. It doesn't claim mentoring of mid-level engineers, because the level of your new hires isn't stated. | `[grounded]` your CV text |
| R6 | High request volume in Go services | important | `surfaced_by_edit` | E2 | `[grounded]` your CV text |
| R7 | Drive down p99 latency | important | `surfaced_by_edit` | E3 | `[grounded]` your CV text |
| R8 | Own services and on-call | important | `surfaced_by_edit` | E2 for the three services, E4 for the rotation | `[grounded]` your CV text |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material touches it. See C3. | `[grounded]` the CV text has no product-facing line |

## Recovery per gap — pending your approval

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years backend | must-have | 7 years as a software engineer, with Go and Rust daily for 4 of them and Python before that. It doesn't say what the Python years were spent on. | It is a numeric must-have, and only the 4 Go/Rust years are confirmed as service work. | Server-side Python (APIs, batch jobs, internal services); backend work at an earlier employer; any service you ran before the ledger pipeline | Earlier job titles and dates, a repo, a design doc | `[grounded]` what the CV text says and omits; `[generic]` numeric must-haves are checked against stated years |
| C2 | Distributed systems at scale | must-have | One service at about 40k requests/minute, three owned services, and Kafka in a tools list. | It is a must-have that currently rests on a request rate and a tool name. | How your three ledger services exchange data, including whether Kafka carries events between them; handling ordering, retries or duplicates in the pipeline; running Postgres under peak load | An architecture diagram, a design doc, a dashboard | `[grounded]` what the CV text says and omits; `[generic]` tool lists alone rarely show who designed what |
| C3 | Partner with product on roadmap sequencing | important | No line touches product work. | The JD names it as a core duty of the role. | Agreeing with product what to build first on one of your services; re-sequencing work because of latency or on-call load; the cache-layer rework: how it got prioritised | A planning doc, a ticket, a roadmap note | `[grounded]` the CV text has no such line; `[generic]` senior roles often include roadmap input |

## Not written, and why

- **"7 years of backend experience" and the title "Senior Backend Engineer":** your 7 years are software engineering, and the backend share is unconfirmed. I took the reading that claims less. See C1.
- **"Distributed systems expertise" or "at scale":** this is the JD's phrase, and your sentences give a request rate and a tool list. Kafka is listed, not described as something you ran.
- **"Mentored mid-level engineers":** you wrote onboarding new hires and pairing for their first month. Mentoring is a different kind of work, and the new hires' level isn't stated.
- **"Partnered with product on the roadmap":** nothing in your material supports it.
- **"Handled 40k requests/minute across three services":** the figure belongs to one service, so it stays attached to that service in E2.
- **"Build-cache" or "caching platform" experience:** your cache work is on a payments balance-read path, which is a different system, so I haven't borrowed the JD's product.
- **Owning or designing an incident process:** you ran six incidents as commander. You never said you wrote the process or the postmortems.

## Parse-safety check

You pasted text rather than a file, so I could not check layout, columns, tables, images, headers or footers, section headings or file type. Every proposed line is plain text with no tables or icons. If you send the file, I can run those checks and look for hidden text carried in from a template.

## Upgrade menu

- **Your CV as a file:** this would run the checks above. It would also let me quote your actual current lines, which are your pasted sentences for now.
- **Answers to C1–C3:** each one converts a `not_evidenced` row into a real, traceable line.
- **A design doc, dashboard or earlier CV version:** this would give C2 and C3 something inspectable.
- **A `tuesday-dossier.md`:** this would add verified evidence and any inferences you've already rejected.

## Questions

C1 — Which of your 7 years were spent on backend services, including what you built in Python?
C2 — How do your three ledger services talk to each other and to other systems, and is Kafka part of that?
C3 — Have you worked with product on what gets built and when for your services, and what is one example?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.