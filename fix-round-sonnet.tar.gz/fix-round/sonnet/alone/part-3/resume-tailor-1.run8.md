I loaded the resume-tailoring skill and built the ledger below from the details you pasted. Nothing is applied yet.

I only have your description, not the CV file. So "Current line" quotes your sentences, and I can't see your layout or your real bullet wording.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. Own three services in the ledger pipeline at a payments company, one handling about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Currently at a payments company." | `[grounded]` your CV description | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged wording, moved to the first bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV description | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged wording, moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV description | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Bullet one: "On-call rotation every fourth week for two years." Bullet two: "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV description | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV description | pending your approval |
| E6 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Go, Rust, Kafka, gRPC, Postgres, Datadog, Terraform, Python" | `reorder` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV description | pending your approval |

- **E4:** "Ran" is "I've run" with the verb kept as it was. The on-call line does not say you owned on-call for your services, because you described a rotation.
- **E5:** the word "usually" stays. Dropping it would turn a typical year into a guaranteed one.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 carries "7 years". Your sentence says software engineering, and the backend part comes from the services you own. | `[grounded]` JD text and your CV description |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1 and E6 show Go daily for 4 years. Nothing you wrote says the three services are in Go, so I haven't written "production Go" (see C2). | `[grounded]` JD text and your CV description |
| R3 | Distributed systems at scale | must-have | `surfaced_by_edit` | E2 carries about 40k requests/minute at peak, and E6 lists Kafka and gRPC. Your CV doesn't use the phrase, so I haven't written it. | `[grounded]` JD text and your CV description |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E4 shows six incidents as incident commander. | `[grounded]` JD text and your CV description |
| R5 | Go services at high request volume | must-have | `surfaced_by_edit` | E2. You wrote "own", not "design and ship", so the proposed lines say "own". | `[grounded]` JD text and your CV description |
| R6 | Drive down p99 latency | important | `surfaced_by_edit` | E3 moves the 380ms to 95ms bullet up. | `[grounded]` JD text and your CV description |
| R7 | Own on-call for your services | important | `surfaced_by_edit` | E4 shows an every-fourth-week rotation for two years. | `[grounded]` JD text and your CV description |
| R8 | Mentor mid-level engineers | important | `surfaced_by_edit` | E5 shows onboarding and pairing for new hires. That is related to mentoring, not the same thing, and your sentence doesn't say what level those hires were. | `[grounded]` JD text and your CV description |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material covers this. See C1. | `[grounded]` JD text; `[grounded]` your CV description has no product or roadmap work |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Partner with product on roadmap sequencing | important | Services, latency, on-call and onboarding. Nothing about product or planning. | It is the one JD duty with no support in your CV. | Deciding what to build first with a product manager; trading off the cache rework against feature work; sizing or pushing back on a request | A planning doc, a ticket thread, a roadmap note | `[grounded]` your CV description; `[generic]` roadmap partnership is usually a named duty on senior roles |
| C2 | Production Go | must-have | Go daily for 4 years, but no link to the three services. | Without that link, "production Go" is a claim I can't write. | The ledger services themselves; the balance-read path | A repo language breakdown or a design doc | `[grounded]` your CV description; `[generic]` screeners usually look for the language next to the service work |
| C3 | Mentor mid-level engineers | important | Onboarding new hires, with levels not stated. | "Mentoring" is currently a word I would be supplying. | Mentoring a mid-level engineer beyond the first month; code-review coaching; growing someone toward a promotion | A peer-review note or a promotion write-up | `[grounded]` your CV description; `[generic]` mentoring is often judged on follow-through past onboarding |

## Not written, and why

- "Production Go" and "Go services": nothing says which language the three services use (C2).
- "Designed and shipped": you wrote "own".
- "Mentored mid-level engineers": you onboarded new hires, and their level is unstated (C3).
- "Owned on-call for my services": you described a rotation.
- "Distributed systems at scale": this is the JD's phrase, not yours. The 40k requests/minute figure carries that evidence without the label.
- "Partnered with product" or "drove roadmap": no support in your material (C1).
- "Led incident response" or "built the incident process": you said you ran six incidents as incident commander, nothing more.
- A percentage for the p99 cut: I kept your 380ms to 95ms figures as you gave them.

## Parse-safety check

I couldn't run this, because I have pasted text and not the file. When you send the CV, I'll check for multi-column layout, tables or text boxes, skill-level bars or icons, contact details in headers or footers, and non-standard section headings. I'll also check whether any hidden text is already in the file. Hidden-text tricks are not something I'd add. A `.docx` or a text-layer PDF is the safest format.

## Upgrade menu

These are offers, and I'll build them only if you say yes.
- **Send the actual CV file or text.** The rows would then quote your real lines, and the parse-safety check could run.
- **Add a design doc, repo link or incident write-up.** It could back the Go claim and the incident-commander line with something inspectable.

## Questions

- C1: Have you ever helped decide what your team builds and in what order, with a product manager or anyone else? Describe it, even if it was informal.
- C2: Which language are the three ledger services written in?
- C3: Have you mentored anyone beyond a new hire's first month, such as a mid-level engineer you helped grow?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.