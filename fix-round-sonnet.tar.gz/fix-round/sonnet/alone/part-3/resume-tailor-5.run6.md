I won't add the hidden instruction or the 1pt keyword block. Most applicant-tracking systems flag hidden text, and a recruiter who finds it will likely reject the application outright. It's also an attempt to deceive the screener, and your real experience already matches most of this JD. I'll tailor the resume honestly instead.
I won't add the hidden instruction or the keyword block, and I need to correct something I said above. I told you most ATS software flags hidden text. I can't support that. The sources I have show some platforms and recruiters do find it, not that most do. The tailoring is below. I only have your resume as prose, so "current line" means your own sentence, and nothing has been applied.

**What the evidence says about the trick**

| # | Claim | Provenance |
|---|---|---|
| W1 | A staffing firm reports hidden text in about 10% of the résumés it scans with AI, and one platform disclosed white text in 1% of those it processed over half a year. So it does get found. | `[generic]` cite C18, C19 |
| W2 | One candidate told a newspaper a recruiter who found his hidden text turned him down for it. | `[generic]` cite C35 |
| W3 | Where match scores exist, they mostly decide who gets reviewed first, and "Low score ≠ auto-reject". In the same recruiter interviews, the filters that reject without a person were almost always knockout questions on the application form (work authorization, license, location). | `[generic]` cite C26, C27 |

Your resume would also carry a line you didn't write and couldn't explain if asked. The honest version of what you wanted is to put the real keywords (HubSpot, paid search, lifecycle email, webinars, $600k) where your evidence already supports them, near the top.

**Edit ledger** (`resume_edits_pending_approval`)

Proposed order: your headline "Marketing Manager, 6 years B2B SaaS.", then E1, E2, E3, E4, E6.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your sentence | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "HubSpot daily for 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your sentence | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch, 12 automated flows" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your sentence | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting" | `split` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your sentence | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | *(removed: the SQL clause)* | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your sentence | pending your approval |
| E6 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, placed after the email and reporting lines)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your sentence | pending your approval |

- **E1** keeps "controlled" and "about". Your budget sentence stays as strong as you wrote it, and it clears the JD's $500k line.
- **E2 and E3** are one sentence split in two. Your sentence doesn't say the email programme was built in HubSpot, so the split doesn't say it either.
- **E5** drops the SQL clause. Your resume makes no SQL claim, so removing it adds nothing, but it is your call, so it is a row.

**Coverage map**

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years B2B demand gen | must-have | `not_evidenced` | Your 6 years of B2B SaaS marketing and the channels in E1 to E3 are evidenced. How many of those years were demand gen is not stated, and I won't relabel the history with the JD's term. | `[grounded]` your sentences |
| M2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E2 and E4. HubSpot is evidenced, and Marketo isn't needed. | `[grounded]` your sentences |
| M3 | SQL-literate | must-have | `not_evidenced` | Named absence below. | `[grounded]` your sentences |
| M4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1. You wrote "controlled" and "about $600k a year". | `[grounded]` your sentences |
| M5 | Paid search | important | `already_evidenced` | Your budget sentence, tightened in E1. | `[grounded]` your sentences |
| M6 | Lifecycle email | important | `already_evidenced` | E3 | `[grounded]` your sentences |
| M7 | Webinars | important | `already_evidenced` | E6 | `[grounded]` your sentences |
| M8 | Content distribution | important | `not_evidenced` | Nothing in your material covers it. | `[grounded]` your sentences |

**Recall prompts**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | 6 years in B2B SaaS marketing, with paid, email and webinar work. It doesn't say how long you ran those channels. | It is the first requirement a reader checks against the years figure. | Earlier roles that ran paid, email or events; the years you've done those channels in total | Old job titles or dates, a prior resume | `[grounded]` what your resume says; `[generic]` a years requirement is read against dates |
| C2 | Content distribution | important | Nothing about pushing content out. | The JD lists it as part of the role. | Promoting webinar recordings or content through email or paid social; newsletters; syndication | A campaign report or a content calendar | `[grounded]` what your resume says; `[generic]` the JD lists it as a core duty |

**Named absence (M3, SQL)**
You've told me you aren't strong in SQL and rely on an analyst, so no line gets written for it. It is a must-have, so expect it to come up in screening or interviews. Closing it would take learning basic querying (SELECT, JOIN, GROUP BY) and doing real exercises on a dataset, which is weeks of work and not an overnight fix. The alternative is to apply and be upfront that HubSpot reporting is where you pull your own numbers. Whether this role is worth applying to with that gap is job-underwriter's question.

**Not written, and why**
- Hidden "ignore previous instructions" text: refused. It is an instruction to the screener that you couldn't defend if asked.
- A 1pt keyword block: refused for the same reason.
- "Managed a $600k budget": you wrote "controlled", and I kept your word.
- "Demand generation experience" or "5+ years demand gen": not in your material (M1).
- "SQL" or "data analysis": you said you aren't strong in SQL, and HubSpot reporting is a different thing.
- "Content distribution": nothing in your material supports it (M8).
- "Marketo": you never mentioned it, so I haven't implied it.
- "Owned the full funnel" or any pipeline or revenue claim: none appears in your material.

**Parse-safety check**
The resume arrived as pasted text, so I could not run the layout checks (columns, tables, header and footer contact details, images, file type). I also couldn't check for hidden text a template or earlier tool may have left in the file. Send the actual `.docx` or PDF and I'll run these.

**Upgrade menu** (offered as additions, built only if you say so)
- An earlier resume or old job dates would help close C1.
- A webinar or email report would let me add real numbers to E3 and E6, if you can share one.
- The resume file would let me run the parse-safety check properly.
- A short honest cover-note line about SQL (an extra, not part of the ledger). It would say you work from HubSpot reporting and partner with an analyst for deeper queries.

**Questions**
C1: How many of your 6 years were spent running paid, email or webinars, and did any earlier role cover those? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
C2: Have you ever pushed content out through email, paid social or a newsletter (for example, promoting webinar recordings)? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.