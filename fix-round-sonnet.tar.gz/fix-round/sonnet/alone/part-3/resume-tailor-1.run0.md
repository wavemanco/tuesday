I've tailored your CV below as a ledger of proposed edits. Nothing is applied until you approve specific rows. I treated your pasted text as the CV, so each "current line" is your own sentence.

Your material already covers most of this JD: the volume, the p99 work, on-call and incident command, and onboarding. The edits mostly bring those forward in the order the JD asks for them. Three requirements your CV does not yet support, and I did not write around them: production Go services, distributed systems at scale, and partnering with product on the roadmap.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged — moved to first line of the current role)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to second line)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | *(unchanged — moved to third line)* | `reorder` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | *(unchanged — moved to fourth line, before E6 rewrites it)* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |
| E5 | Skills | "Go and Rust daily for 4 years, Python before that." | *(unchanged — moved into the skills block, directly above the tools list)* | `reorder` | "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV | pending your approval |
| E6 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team (usually two or three a year), pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |

E4 and E6 are alternatives for the same line: E4 changes only its position, and E6 also tightens its wording. Approve one, or both if you want the shorter wording in the new position.

Notes on the audit:
- **"Usually" stays in E6.** Compressing the line must not turn "usually two or three a year" into a flat count.
- **No "mentor" in E6.** You wrote onboarding and pairing, and I kept your words.
- **"Mid-level" is not in any row.** Your CV does not say who the new hires were.
- **E2 is not attached to E1.** Your CV does not say the balance-read path is the 40k requests/minute service, so the two lines stay separate.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | already_evidenced | "Senior Software Engineer, 7 years" as written. The CV does not say all 7 were backend, so no row writes "7 years backend". | `[grounded]` your CV |
| R2 | Go experience | must-have | surfaced_by_edit | E5 | `[grounded]` your CV |
| R3 | Production Go services, the JD's "design and ship Go services" | must-have | not_evidenced | Your CV says Go daily and owned services, but not that the services are Go, or that you designed them. See C1. | `[grounded]` what the CV does and does not say |
| R4 | Services at high request volume | must-have | surfaced_by_edit | E1 | `[grounded]` your CV |
| R5 | Drive down p99 latency | important | surfaced_by_edit | E2, a move only; the line stays in your own words | `[grounded]` your CV |
| R6 | Distributed systems at scale | must-have | not_evidenced | Kafka appears only in a tools list, and a tool listed is not a tool owned. See C2. | `[grounded]` what the CV does and does not say |
| R7 | Strong incident response | must-have | surfaced_by_edit | E3 | `[grounded]` your CV |
| R8 | Own on-call for your services | important | surfaced_by_edit | E3. Your CV gives the rotation but not whether it covers the three services you own. | `[grounded]` your CV |
| R9 | Experience mentoring (the JD says mid-level engineers) | must-have | surfaced_by_edit | E4 or E6, in your words of onboarding and pairing. The CV does not say the new hires were mid-level. | `[grounded]` your CV |
| R10 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in the CV touches product or roadmap work. See C3. | `[grounded]` what the CV does and does not say |

## Gap handling (recall prompts)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go services (R3) | must-have | Go and Rust daily for 4 years, and three owned services. It does not say which language the services are in. | The JD's first duty is shipping Go services, so a reader cannot tell whether your 40k requests/minute service is Go. | The ledger services written in Go; a Go service you wrote from scratch; a Go service you took over and changed substantially | A repo, a design doc, or a service README showing the language | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Distributed systems at scale (R6) | must-have | A ledger pipeline with a 40k requests/minute service. Kafka and gRPC appear only as tool names. | "Distributed systems at scale" is a must-have, and tool names alone leave the claim to the reader. | Services that communicate over Kafka or gRPC; a failure or consistency problem you solved across services; capacity or partitioning work | An architecture doc, a design review, or a postmortem | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Partner with product on roadmap sequencing (R10) | important | No product or planning work appears. | The role includes roadmap sequencing, and the CV is silent on it. | Deciding the order of work with a product manager; trading a feature against reliability work; writing or reviewing a quarterly plan | A planning doc, a roadmap, or a decision log | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |

If any of these genuinely does not apply, say skip. A skipped prompt stays a named gap rather than becoming a line.

## Not written, and why

- **"Production Go services" or "Go services at 40k requests/minute":** your CV does not say what language the services use, and I read ambiguity in the direction that claims less.
- **"Designed and shipped":** you wrote "own", and designing is a different claim.
- **"Distributed systems at scale" or any Kafka-based line:** Kafka is only in a tools list.
- **"Mentored mid-level engineers" or "mentor":** you wrote onboarding and pairing with new hires, and "mid-level" is the JD's word, not yours.
- **"Owned on-call for my services":** you wrote an on-call rotation, and your CV does not say it covers your three services.
- **"Led incident response":** you wrote "run six incidents as incident commander", and I kept that.
- **"Partnered with product" or "roadmap sequencing":** nothing in your CV supports either.
- **"Reduced p99 on a 40k requests/minute service":** this would join two lines your CV keeps separate.
- **A retitle to "Senior Backend Engineer", or "7 years backend":** your title is Senior Software Engineer, and the CV does not say how many of the 7 years were backend.

## Parse-safety check

You pasted text rather than a file, so I could not check layout: columns, tables, text boxes, headers and footers, images, or file type. The one thing I can see is that your tools list is plain text, which reads cleanly. Send the file and I can run the rest.

## Upgrade menu

- **Your CV as a file (docx or PDF):** this lets me run the layout checks above.
- **A Datadog screenshot or write-up of the p99 work:** this is inspectable proof for E2, which today rests on your word alone.
- **One of your six incident postmortems:** it would back E3 with something a reader can check.
- **A service README or design doc for any of the three services:** it would settle C1 and C2, and show how much you designed.
- **An earlier version of your CV:** it may hold evidence the current one dropped.

## Questions

C1 — Are any of your three ledger services written in Go, and if so, did you design them or take them over?
C2 — Does the 40k requests/minute service use Kafka or gRPC to talk to other services, and what did you do with them?
C3 — Have you ever helped a product manager decide what gets built first, or traded a feature against reliability work?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.