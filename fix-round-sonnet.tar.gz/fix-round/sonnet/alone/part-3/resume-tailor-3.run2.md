Here is the full ledger for the Quartzline role. Nothing is applied, and every row is pending your approval.

I used the dossier's `role_profile`, so I didn't need the JD again. I inherited E1 from its `resume_edits_pending_approval` and re-audited it against your sentences. I also took the `evidence_map` judgments as they stood: R1 and R2 are adjacent with a transferability gap, at medium confidence. I'm not acting on the `conditional_go` decision. I only have your CV as prose, so "Current line" below is your own sentence and I can't see how it sits on the page.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV (inherited dossier edit E1) | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved directly after the playbook line)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." as its own line under the role | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years, at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |

- **E3:** the sentence stays "roadmap-input sessions". It does not become "informed the roadmap" or "roadmap ownership".
- **E5:** the summary is built from your two sentences and kept as two. It names no PM title and no PM years.

## Coverage map (pending your approval)

The JD marks only the 3+ years PM requirement as must-have. I treated the other three as `important`; correct me if the posting says otherwise.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ yrs PM | must-have | `not_evidenced` | Adjacent per the dossier: integration leadership, with E3 as the nearest work. Roadmap ownership and prioritisation authority aren't evidenced. No PM title in 7 years. | `[grounded]` dossier evidence_map R1 and your CV |
| R2 | Shipped API or platform products | important | `not_evidenced` | Adjacent per the dossier. E2 shows you led integrations of your vendor's REST APIs, which is not shipping an API product. | `[grounded]` dossier evidence_map R2 and your CV |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4, with E2 carrying the REST integration work | `[grounded]` your CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 put the client-facing work early. The phrase "stakeholder management" is not written anywhere. | `[grounded]` your CV |

## Gap handling

### Recall prompts (pending your approval)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM, roadmap ownership and prioritisation | must-have | You ran roadmap-input sessions and collected client feedback. It doesn't say who decided what product built. | The posting's first duty is owning the roadmap, and the dossier flags prioritisation authority as the missing piece. | A client request you got into a release; a trade-off you argued to product; a call on which integration blockers got escalated | A roadmap-session summary, a ticket or release note that traces back to a session | `[grounded]` what your CV does and doesn't say; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API or platform products | important | You integrated clients onto your vendor's REST APIs. It doesn't say you built or released API surface. | The role is partner-facing API platform work. | OpenAPI specs or API docs you wrote that went to clients; a client-facing API feature you helped launch; an API change you shepherded into a release | A spec, a changelog entry, a client-facing doc | `[grounded]` what your CV does and doesn't say; `[generic]` what this costs on applications of this kind |

### Named absence (pending your approval)

You have never held a PM title, and the posting's must-have is 3+ years in the role.

- **Wording can't close this.** Only evidence of PM-scope work done under other titles can, and C1 and C2 are how I'd look for it.
- **If they turn up nothing,** the gap stays open. For this must-have, honest wording can't cover it.

## Not written, and why

- **"Built an internal request-triage tool"** — rejected earlier, carried over from the dossier. It was a memory lead and you couldn't confirm you owned it.
- **"Has been the customer of a partner API platform"** — rejected earlier, carried over from the dossier. You worked vendor-side.
- **Any PM title, or "3+ years of product management"** — you never held the title and the JD makes it a must-have.
- **"Owned the roadmap" or "prioritised the roadmap"** — you ran feedback sessions for product.
- **"Shipped API products"** — you led client integrations of your vendor's REST APIs, which is different work.
- **"Partners" or "partner discovery"** — the posting's word is partner; yours is client. Swapping it changes which side of the table you sat on.
- **"Wrote specs" or "drove delivery with engineering squads"** — you said you're comfortable in OpenAPI specs, not that you authored them or ran delivery.
- **"Defined adoption metrics"** — nothing in your material mentions metrics.
- **Playbook scope beyond "the whole team uses"** — nothing says it was company-wide or customer-facing.
- **"Technical fluency" and "stakeholder management" as stated claims** — they're the JD's labels, and your lines should show the work instead.

## Parse-safety check

You gave me prose, so none of the six checks could run: layout columns, tables and text boxes, images and icons, headers and footers, section headings, and file type. I also couldn't look for hidden text you didn't author, such as leftovers from a template.

## Upgrade menu

- **The CV as a file:** lets me run the parse check and use your real current lines in the ledger.
- **An answer to C1 or C2:** the only thing that can turn a `not_evidenced` row into a real one.
- **Artifacts:** an OpenAPI spec or API doc you wrote, a roadmap-session summary, or the playbook itself would each raise a medium-confidence claim.

## Questions

C1 — Did any client request from your roadmap-input sessions end up in a release, and what was your part in deciding that?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Have you written OpenAPI specs or API docs that went out to clients, or helped launch a client-facing API feature?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.