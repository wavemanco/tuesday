I've read the posting and your background. I worked from the text you pasted, not a resume file, so the "Current line" column quotes your own sentences. A rewrite can't create the must-have **3+ years data engineering**, so the map marks it `not_evidenced` and I haven't written around it. Everything below is proposed only, and nothing is applied until you approve specific rows.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks and added tests to it." | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis (pandas); some scripting to pull vendor APIs on a cron." | `compress` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved below the pipeline and modelling bullets)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` | pending your approval |

- **E3** keeps "with our then-DE". Dropping it would turn co-designing into designing alone.
- **E4** keeps "when it breaks" and "added tests". It does not become "owned data quality" or "on-call".
- **E5** keeps "some scripting" and "for analysis". "Production" is not in it.
- **Title:** your title stays Senior Data Analyst. No row retitles it.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years data engineering | must-have | `not_evidenced` | Your five years are analytics, with adjacent pipeline and modelling work (E2–E4). See R1. | `[grounded]` |
| M2 | Production Python | must-have | `not_evidenced` | E5 states the Python you actually do, without the word "production". See R2. | `[grounded]` |
| M3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | You've never used Airflow. The nightly dbt job (E4) and the cron pulls (E5) are adjacent, and I can't call either orchestration. See R3. | `[grounded]` |
| M4 | Dimensional modelling | must-have | `surfaced_by_edit` | E3 and E2 | `[grounded]` |
| M5 | Own data quality | important | `surfaced_by_edit` | E4 covers "added tests" only. SLAs and ownership are not claimed. | `[grounded]` |
| M6 | Own SLAs | important | `not_evidenced` | Named absence A1 | `[grounded]` |
| M7 | Batch and streaming pipelines (Spark, Kafka) | important | `not_evidenced` | Named absence A1 | `[grounded]` |
| M8 | Streaming experience | preferred | `not_evidenced` | Named absence A1 | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | Five years as an analyst. Pipeline and modelling work is present, but no data-engineering role or duties are stated. | It is the posting's stated must-have, and the stated tenure is the thing a reviewer checks first. | A stretch where pipeline upkeep was a formal part of your duties; being the person who took over the then-DE's models; ingestion you owned end to end | Job description or performance review wording, a repo history, a handover doc | `[grounded]` what the resume says and omits; `[generic]` what a missed must-have costs on applications of this kind |
| R2 | Production Python | must-have | Python "for analysis"; some API-pull scripts on a cron. Nothing says they run unattended or that others depend on them. | A "production Python" requirement with only analysis scripts reads as a gap on one pass. | The vendor-API pulls feeding tables others use; retries or alerting you added; code review or a shared repo | The script repo, a cron or scheduler config, an incident note | `[grounded]` what the resume says and omits; `[generic]` how reviewers read this requirement |
| R3 | Airflow or equivalent orchestration | must-have | A nightly dbt job you fixed and added tests to, and a cron. It doesn't say what schedules the dbt job or whether you changed it. | "Or equivalent" leaves room, but only for something you can describe accurately. | Setting up or editing the nightly dbt schedule; dependencies between jobs; failure alerts you wired up | dbt Cloud or scheduler config, a job definition, a runbook | `[grounded]` what the resume says and omits; `[generic]` how "or equivalent" is typically read |

**Named absence A1: Spark, Kafka, streaming, SLAs.** You have never used Spark or Kafka, and your resume shows no SLA ownership. These are claims I can't write. Closing them takes real work: a small end-to-end project, say Kafka into a warehouse table with a Spark or dbt transform and a freshness check, with a repo you can link. You could also define an explicit freshness SLA on the orders mart and document it. Until that exists, the honest route is to leave them off, or to say plainly in the interview that you haven't done them yet. Streaming is only preferred, so it is the cheapest of these to leave open.

## Not written, and why (pending your approval)

- **"3+ years data engineering" or a Data Engineer title.** Five years of analytics doesn't count as data-engineering years. Adjacent work is in E2–E4, and the gap stays visible in M1.
- **"Built and owned batch pipelines" for the vendor-API cron.** That upgrades analysis scripts to pipeline ownership, which is a different kind of work.
- **"Production Python" and "orchestrated pipelines".** Those are the posting's words, not yours. A cron and a nightly dbt job you fixed are not orchestration.
- **"Owned data quality and SLAs".** You added tests. Nothing in your material mentions SLAs or ownership.
- **"Designed the warehouse" or "led dimensional modelling".** You designed the star schema with your then-DE, and the one orders mart is the scope.
- **"Partnered with analytics on requirements".** You sat on the analytics side, so the word would flip which side of the table you were on.
- **Spark, Kafka and streaming.** You said you've never used them, so they can't appear as skills or in a tools list.

## Parse-safety check

You gave me pasted text, not a file. I could not run the checks for columns, tables, text boxes, icons or skill bars, headers and footers, or file type. If you send the file, I'll run all of them. I can check the plain-text points now. Use standard headings (Summary, Experience), keep contact details out of the header and footer, and put the dbt and modelling lines first. E1 and E2 do that.

## Upgrade menu (labelled proposals, built only if you ask)

- **Artifact-backed bullets:** a dbt project export or lineage screenshot, the cron script repo, and the test config would let me tie E2–E5 to inspectable evidence.
- **A gap-closing project:** a small Kafka and Spark or dbt pipeline with a freshness check, scoped as a weekend or two. It would turn A1 from absent into something real.
- **Apply-or-not call:** with three must-haves unevidenced, the question of whether this role is worth applying to is one for job-underwriter.

## Questions

R1 — Did any role you held formally include data-engineering duties, such as owning ingestion or models after the then-DE left? If so, for how long?
R2 — Do the vendor-API scripts run unattended, feed tables other people use, and have retries or alerts?
R3 — What schedules the nightly dbt job, and did you ever set up or edit that schedule yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.