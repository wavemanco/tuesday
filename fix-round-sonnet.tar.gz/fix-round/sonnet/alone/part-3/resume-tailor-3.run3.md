Nadia, I built the ledger from your CV text and the dossier excerpt. Nothing is applied. Every row below is pending your approval.

**Inputs used.**
- **Dossier:** The role matches (Quartzline, Product Manager, Platform APIs), so I used it. I took R1 and R2 (both `adjacent`, `medium`) unchanged, the pending edit E1, and the two rejected inferences. The `conditional_go` decision I left alone.
- **CV:** It reached me as prose, not a file. So "Current line" is your wording as you gave it, and I've assumed an Experience section.
- **Confidence:** `medium` stays `medium`. Tailoring doesn't verify anything.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 (from dossier) | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to third bullet, after E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Experience or Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved directly below the integration bullets)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |

- **E1** was drafted by the earlier assessment. I re-audited it against your sentence and it still traces. "The whole team" keeps your original scope.
- **E5** keeps your two sentences separate. It adds no PM framing and no new numbers. It repeats E2, so drop it if you'd rather not repeat yourself.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | `not_evidenced` | The dossier's R1 (`adjacent`, `transferability`, `medium`) is carried over. E2 and E3 are the nearest evidence, but no row claims PM years. See C1. | `[grounded]` your CV says you never held a PM title; the dossier assessed this requirement |
| 2 | Shipped API or platform products | important | `not_evidenced` | The dossier's R2 (`adjacent`, `medium`) is carried over. E2 shows you led integrations of your employer's APIs, not that you shipped them. See C2. | `[grounded]` CV and dossier |
| 3 | Technical fluency | important | `surfaced_by_edit` | E4 and E2 | `[grounded]` CV |
| 4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 show client-facing work only. Work with engineering is not evidenced. | `[grounded]` CV |
| 5 | Own the roadmap for the API platform | important | `not_evidenced` | E3 is the nearest evidence. The dossier says roadmap ownership and prioritisation authority are not evidenced. See C1. | `[grounded]` CV and dossier |
| 6 | Run discovery with integration partners | important | `not_evidenced` | E3 is feedback from clients, not partners. See C1. | `[grounded]` CV |
| 7 | Write specs and drive delivery with two squads | important | `not_evidenced` | "Comfortable in … OpenAPI specs" is tool familiarity, not authorship. See C2. | `[grounded]` CV |
| 8 | Define adoption metrics | important | `not_evidenced` | Nothing in your material covers it. See C3. | `[grounded]` CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership, prioritisation, discovery (rows 1, 5, 6) | must-have | Quarterly roadmap-input sessions that collected client feedback for product. It does not say who decided what got built. | The must-have is PM years, and prioritisation authority is the nearest thing that could support it. | Deciding or co-deciding what went into a release; sessions with partners rather than clients; feedback you turned into a ranked list that product used | Session notes, a roadmap doc, a product-team message crediting an input | `[grounded]` what the CV says and omits; `[generic]` PM postings of this kind weigh prioritisation authority heavily |
| C2 | Shipped API products, specs, delivery with engineering (rows 2, 7) | important | Integrations of existing APIs and a playbook. No authored specs or release ownership. | The role has you writing specs and driving two squads. | Specs or API changes you wrote or reviewed; a release you coordinated with engineering; a beta with clients | An OpenAPI diff, a spec doc, release notes | `[grounded]` CV; `[generic]` same pattern as C1 |
| C3 | Adoption metrics (row 8) | important | No metrics mentioned. | The role is to define adoption metrics. | Tracking integration go-lives or time-to-first-call; reporting on which clients used which endpoints | A dashboard, a report, a QBR slide | `[grounded]` CV; `[generic]` same pattern as C1 |

**Named absence, requirement 1.** You never held a PM title, and that can't be written around. What would close it is evidence from C1 or C2 that you did PM work under another title. If nothing turns up, the honest position is that this is a transferability case, which the dossier already says, and the cover letter has to carry it.

## Not written, and why

- **"Product management experience" or "3+ years PM"**: you never held the title, and it is a must-have. E2 and E3 are the honest neighbours.
- **"Owned the roadmap"**: your sentence says you ran sessions collecting feedback "for product". Prioritisation authority isn't evidenced.
- **"Shipped API products"**: you led client integrations of your employer's APIs, which isn't the same as shipping them.
- **"Ran discovery with integration partners"**: "discovery" and "partners" are the posting's words. Yours are "client feedback" and "clients". Clients of a vendor and integration partners sit on different sides of the table.
- **"Wrote specs" or "drove delivery with engineering squads"**: "Comfortable in … OpenAPI specs" names a skill, not work you authored.
- **"Defined adoption metrics"**: nothing in your material mentions metrics.
- **"Built an internal request-triage tool"** (dossier rejected inference): it was a memory lead and you couldn't confirm ownership.
- **"Has been the customer of a partner API platform"** (dossier rejected inference): you worked vendor-side.

## Parse-safety check

Your CV came as pasted text, so I could not check layout, columns, tables, text boxes, headers or footers, icons or skill bars, or file type. I can only say that the section headings I assumed are conventional ones.

## Upgrade menu

- **Your CV as a `.docx` or PDF:** this would let me run the parse-safety checks and quote your lines exactly as written.
- **The integration playbook, or a client-feedback session summary:** either would move E1 or E3 from `medium` toward inspectable evidence.
- **Earlier CV versions:** these may contain lines your current CV dropped.

## Questions

- **C1.** Did you ever decide, or co-decide, what product built from those roadmap-input sessions, or meet with integration partners rather than clients?
- **C2.** Did you write, review or change an API spec, or coordinate a release, with engineering?
- **C3.** Did you track or report integration usage, such as go-lives or endpoint use, that product or leadership relied on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.