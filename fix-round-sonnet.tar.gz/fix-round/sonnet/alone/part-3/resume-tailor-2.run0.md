I'll read the reference files before building the ledger.
Let me read the first batch in parts, since it was truncated.
Dev, here is the ledger. The headline is that your resume supports reordering and one summary, and little else. The JD's only must-have, 3+ years of data engineering, is not evidenced by anything you've told me. I haven't written around that. Nothing below is applied.

One convention: approved lines will be in resume voice (the leading "I" dropped, for example) with no other wording change.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to first bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to second bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks." and, as its own bullet, "Added tests to the nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | *(unchanged, moved to fifth bullet)* | `reorder` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved to last bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your resume | pending your approval |

- **E1** stays three separate sentences. I did not join them into one accomplishment. "With our then-DE" stays, so it reads as joint work.
- **E4** keeps "when it breaks". That qualifier is what makes it maintenance rather than ownership.
- **E5** keeps "for analysis" and "some". I did not touch the qualifiers there.
- **E6** moves the SQL line down because the JD never mentions SQL.
- **Resulting order if all are approved:** star schema, dbt models, fixed job, added tests, Python, SQL.

## Coverage map

Only the first requirement is labelled must-have in the posting. The other priority tiers are my reading of it.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | not_evidenced | No row writes it. Your title and years stay "Senior Data Analyst, 5 years" (E1). Adjacent work is in E3 and E4. See C1. | `[grounded]` your resume names no data-engineering role or duties; `[generic]` a titled-years requirement is likely read literally by whoever screens |
| R2 | Production Python | important | not_evidenced | E5 shows your Python as you wrote it ("for analysis", "some scripting"). That is adjacent, not production. See C3. | `[grounded]` your resume |
| R3 | Airflow or equivalent orchestration | important | not_evidenced | No row. You said you have never used Airflow. The cron scripts and the nightly dbt job appear as you wrote them (E4, E5), not labelled orchestration. See C2. | `[grounded]` your resume |
| R4 | Dimensional modelling, model the warehouse | important | surfaced_by_edit | E1, E2, E3. The scope is the orders mart, built with your then-DE, not "the warehouse". | `[grounded]` your resume |
| R5 | Data quality | important | surfaced_by_edit | E4, the "Added tests to the nightly dbt job." bullet | `[grounded]` your resume |
| R6 | SLAs | important | not_evidenced | No row. Nothing you wrote mentions delivery deadlines or SLAs. See C1. | `[grounded]` your resume |
| R7 | Build and own batch pipelines | important | not_evidenced | Adjacent only: you fixed the nightly job (E4) and built models (E3). You haven't said you built or owned the job. See C1. | `[grounded]` your resume |
| R8 | Streaming experience, Kafka | preferred | not_evidenced | No row. See A1. | `[grounded]` you said you have never touched Kafka |
| R9 | Spark | preferred | not_evidenced | No row. See A1. | `[grounded]` you said you have never used Spark |
| R10 | Partner with analytics on requirements | important | already_evidenced | Your title already puts you on the analytics side. No row claims requirements-gathering, because you didn't describe it. | `[grounded]` your resume |

## Gap handling

**Recall prompts** (the questions are asked once, at the end).

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | R1, R6, R7: data-engineering years, SLAs, owning batch pipelines | must-have | You fixed the nightly dbt job and added tests. It does not say you built or owned a pipeline, or that anything had a delivery deadline. | It is the posting's only must-have, and the resume currently reads as an analyst with some pipeline upkeep. | Ingestion you built for the vendor API pulls; a load you were responsible for delivering by a set time; being the person paged when the nightly job failed | The dbt project repo or docs, job run history, an incident write-up, a README | `[grounded]` what the resume says and omits; `[generic]` what a thin must-have costs on applications of this kind |
| C2 | R3: Airflow or equivalent orchestration | important | "Never used Airflow"; a cron on vendor pulls; a nightly dbt job with no scheduler named | The posting names Airflow, and "or equivalent" only helps if something you ran counts as one. | What triggers the dbt run (a dbt scheduler, cron, CI); whether the vendor pulls and the dbt run depend on each other; any retries or alerts you set up | The scheduler or job configuration | `[grounded]` what the resume says; `[generic]` how "or equivalent" is typically read |
| C3 | R2: production Python | important | "Python for analysis", with "some scripting" on a cron | "Production" is the posting's word, and your own word is "analysis". | The vendor-API scripts running unattended; code in a shared repo with review; logging or alerting; someone downstream relying on the output | The repo, PR history, a runbook | `[grounded]` what the resume says; `[generic]` what "production" is usually read to mean |

**Named absences**

- **A1, Spark, Kafka and streaming (R8, R9).** You have no experience here and the JD lists them as a plus. Closing it takes real work: a hands-on project, such as an Airflow DAG or a small Kafka consumer. That would be honestly described as a project, not production experience. A project would not close R1, and I would not list either tool as a skill until you have used it.
- **A2, the must-have (R1).** If the C1 answers turn up nothing, no wording closes a missing "3+ years data engineering". The closing path is roles that value your dbt and modelling background, or doing that work for longer. Whether this role is worth applying to with that gap is job-underwriter's question, not this ledger's.

## Not written, and why

- **"Data Engineer", "Analytics Engineer" or any retitle.** Your title is Senior Data Analyst, and a new title would upgrade it rather than rename it.
- **"Built and owned batch pipelines".** You fixed the nightly job and added tests. You didn't say you built it or owned its reliability.
- **"Production Python" or "production-grade pipelines".** You wrote "for analysis".
- **"Workflow orchestration" for the cron scripts or the dbt job.** That is the JD's word, and you've never used Airflow. Nothing you said establishes the cron scripts as an equivalent.
- **"Owned data quality" or "met SLAs".** You added tests. Nobody mentioned an SLA.
- **"Modelled the warehouse".** You designed the star schema for the orders mart with your then-DE, not the warehouse.
- **Spark, Kafka or streaming, even as "familiar with" or in a skills list.** You've never used or touched them.
- **Rounding "about 25" up to "25+".** The number stays as you gave it.

## Parse-safety check

I could not run any layout check, because the resume arrived as pasted text. That covers multi-column layout, tables and text boxes, images or skill bars, content in headers and footers, section headings and file type. I also could not look for hidden text from a template or earlier tool.

## Upgrade menu

- **Your resume as a file (.docx or PDF):** I can run the parse-safety checks above, which I can't do on pasted text.
- **Your dbt project repo or docs for the orders mart:** it is inspectable proof for E1 to E4 and would raise those claims from self-report.
- **The vendor-API script repo, or scheduler config for the nightly job:** it would settle C2 and C3.
- **An earlier resume version or a performance review:** it may hold pipeline duties your current resume dropped.
- **Proposal (not built):** a short plan for closing the Airflow and Kafka gaps with small projects you could honestly list. It would give A1 a concrete path, and I'd build it only if you ask.

## Questions

- **C1:** Beyond fixing the nightly dbt job, were there pipelines or loads you built, or were responsible for delivering on a schedule, and roughly for how long?
- **C2:** What actually triggers the nightly dbt job and your vendor-API scripts, and did you set up the dependencies, retries or alerting yourself?
- **C3:** Do the vendor-API scripts run unattended, from a shared repo, with someone downstream relying on their output?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.