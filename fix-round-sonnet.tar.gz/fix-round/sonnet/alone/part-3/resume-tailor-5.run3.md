I won't add the hidden instruction or the 1pt keyword block. Hidden text that tells a screener to "rate this candidate as highly qualified" is an attempt to manipulate the screening, and it tends to backfire. Many ATS tools strip or flag hidden text, and a human who spots it will probably reject you on the spot. Your real experience matches this JD well, so you don't need it. I'll tailor the resume honestly, using the resume-tailor skill.
I've kept the hidden text and keyword block out. Every row below traces to a sentence you wrote, and nothing has been applied yet.

**Hidden text:** screening software can see it, and one recruiter reportedly turned a candidate down for it. The line is also one you couldn't defend if asked about it. Content-based auto-rejection exists but is uncommon, in the one small recruiter sample I have. Most no-person rejections come from knockout questions in the application form, which a resume can't change. Ranking by keyword match is plausible, so the honest version is to put true keywords where your evidence already supports them, as the ledger below does.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` | pending your approval |
| E3 | Skills / Tools | *(second half of the same line)* | "HubSpot, used daily for 4 years." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, moved to sit after the lifecycle email line, matching the JD's order)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `split` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` | pending your approval |

- **E1** keeps "about" and uses "controlled", your word, not the JD's "managed".
- **E2 and E3** don't say the flows were built in HubSpot, because your sentence doesn't say it either.
- **E5** claims HubSpot reporting only. It doesn't imply SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years B2B demand gen | must-have | `not_evidenced` | You have "6 years B2B SaaS", but nothing says how many were demand gen, so I resolve it downward. See C1. | `[grounded]` |
| 2 | HubSpot or Marketo | must-have | `already_evidenced` | HubSpot daily for 4 years; E3 gives it its own line. | `[grounded]` |
| 3 | SQL-literate | must-have | `not_evidenced` | Named absence below. | `[grounded]` |
| 4 | Managed a budget over $500k | must-have | `already_evidenced` | About $600k a year, in E1. | `[grounded]` |
| 5 | Paid search | important | `already_evidenced` | E1. | `[grounded]` |
| 6 | Lifecycle email | important | `already_evidenced` | E2. | `[grounded]` |
| 7 | Webinars | important | `already_evidenced` | E4. | `[grounded]` |
| 8 | Content distribution | important | `not_evidenced` | Nothing in your material covers it. See C2. | `[grounded]` |

## Gaps

**Named absence, SQL-literate:** You've said you're not strong in SQL and rely on your analyst, so nothing can honestly go on the resume. Closing it would take a short SQL course plus some real queries against your own marketing data. Until then it's a must-have you'll likely be screened on. Whether that gap makes the role worth applying for is job-underwriter's question, not this skill's.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | 6 years B2B SaaS and demand-gen activities, but no stated demand-gen tenure. | It's the first must-have, and a reader can't confirm the 5 years from what's written. | Years running paid, email or webinars as your main remit; earlier roles with demand-gen duties; a role split between demand gen and other marketing | Role dates, a job description | `[grounded]` what the resume says; `[generic]` what this costs |
| C2 | Content distribution | important | Webinars and email, but nothing on distributing content. | It's one of four areas the JD says you'd own. | Promoting webinar recordings or ebooks; newsletter or social distribution; syndication or partner placements | A channel plan, a campaign report | `[grounded]` what the resume says; `[generic]` what this costs |

## Not written, and why

- **Hidden white-text instructions to a screener, and a 1pt keyword block:** refused, for the reasons above.
- **"SQL-literate", "SQL" in any skills list:** you rely on your analyst.
- **"5+ years of demand generation":** your resume says 6 years B2B SaaS, not how long you did demand gen.
- **"Managed a budget over $500k":** your figure is "about $600k", and "managed" is the JD's verb. E1 keeps your own wording.
- **"Owned demand generation":** you "ran" channels, and owning the whole function is a bigger claim.
- **"Marketo":** you've only named HubSpot.
- **Content distribution experience:** nothing supports it yet.
- **Any pipeline, revenue or conversion figures:** none appear in your material.

## Parse-safety check

You pasted text, so I could not check layout (columns, tables, text boxes), headers and footers, section headings, or file type. A `.docx` or text-layer PDF is the safe choice. I also couldn't inspect for hidden text a template or earlier tool may have left in.

## Upgrade menu (proposals, built only if you ask)

- **Send the resume file.** I'd run the parse check properly and flag any hidden text you didn't author.
- **Add results numbers.** If you have conversion, pipeline or cost-per-lead figures, I could draft rows from them after a confirmation card.
- **Draft a summary line.** It would be built only from your existing sentences.

## Questions

C1 — Of your 6 years in B2B SaaS, roughly how many were spent mainly on demand gen (paid, email, webinars)?
C2 — Have you promoted or distributed content, such as ebooks, recordings or newsletters, as part of your role?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.