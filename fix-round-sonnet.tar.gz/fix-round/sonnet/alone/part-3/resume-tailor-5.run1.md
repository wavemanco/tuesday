I won't add the hidden instruction or the 1pt keyword block. Hidden prompt-injection text is deceptive. It also tends to backfire: many ATS and screening tools flag white or tiny text, and a recruiter who spots it will likely reject you on the spot. Your real experience matches this JD well, so you don't need it. I'll tailor the resume honestly, which is better for you anyway.
I've written the tailoring below, without the hidden text. Whether the hidden instruction works depends on the screener. Where it does work, it is deception aimed at a system acting for the employer. It also puts a line on your resume that you didn't write and couldn't defend if someone asked about it. The 1pt keyword block is the same thing. The honest version of what you asked for is truthful keywords in visible text, placed where your own sentences already support them. The ledger does that, and your real match is strong without tricks: HubSpot, a budget over the $500k line, and three of the four named channels.

Nothing is applied. Every row waits for your approval.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social. Built our lifecycle email programme from scratch. Ran a monthly webinar series." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Line 1: "Used HubSpot daily for 4 years." Line 2: "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your resume | pending your approval |

- **E1** adds nothing new. Each sentence is one of yours, kept separate, so "controlled" and "built" haven't turned into "owned".
- **E2** keeps "about" and "a year", and keeps your verb "controlled".
- **E3** only separates the HubSpot tenure from the email programme so both are easy to scan.
- **E4** drops the SQL aside. It claims nothing about SQL, but expect a SQL question in the interview.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 leads with "6 years B2B SaaS". Your sentences don't say how many of those years were on these channels (see question R1). | `[grounded]` your resume |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years" is already in your resume; E3 only separates it. | `[grounded]` your resume |
| R3 | SQL-literate | must-have | `not_evidenced` | Named absence A1 below. | `[grounded]` your resume |
| R4 | Managed a budget over $500k | must-have | `already_evidenced` | "about $600k a year" is in your resume; E2 tightens the line. | `[grounded]` your resume |
| R5 | Paid search | important | `already_evidenced` | Current line, tightened in E2. | `[grounded]` your resume |
| R6 | Lifecycle email | important | `already_evidenced` | Current line, separated in E3. | `[grounded]` your resume |
| R7 | Webinars | important | `already_evidenced` | "Ran a monthly webinar series, average 300 registrants." Leave it as is. | `[grounded]` your resume |
| R8 | Content distribution | important | `not_evidenced` | Recall prompt C1 below. | `[grounded]` your resume |

## Gap handling

**C1: recall prompt (R8)**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Webinars, paid and email are covered. Nothing says how content got in front of an audience beyond those channels. | It is the fourth channel the JD names, and it is currently blank. | Promoting webinar recordings or gated content through email or paid social; running a newsletter or syndication; repurposing and pushing content across channels | A distribution plan, a campaign recap, a channel report | `[grounded]` what the resume does and does not say; `[generic]` what an unfilled named channel costs on applications like this |

**A1: named absence (R3)**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | What closing it would take | Provenance |
|---|---|---|---|---|---|---|
| A1 | SQL-literate | must-have | You pull numbers in HubSpot reporting and ask your analyst for SQL work. | It is a must-have, so a screener or hiring manager will look for it. | A few weeks of hands-on SQL, such as querying your own HubSpot exports or a warehouse, and then actually writing queries you can speak to. Until then the resume can't claim it. Whether the role is still worth pursuing with this gap is job-underwriter's question. | `[grounded]` your words on SQL; `[generic]` how must-haves are read |

## Not written, and why

- **Hidden text and the keyword block.** The instruction to the AI screener and the 1pt keyword block are refused for the reasons above.
- **"SQL-literate" or "proficient in SQL."** You told me you're not strong in SQL.
- **"Managed a budget over $500k."** Your figure is "about $600k a year", in your verb "controlled". I kept both rather than adopting the JD's words.
- **"Owned demand generation" or "demand generation" as your title or scope.** You wrote that you ran specific channels. "Own" and "demand generation" are the JD's words and would widen your scope.
- **"Content distribution."** Nothing in your material supports it yet (C1).
- **"Senior."** Your title is Marketing Manager.

## Parse-safety check

Your resume arrived as pasted text, so I couldn't check layout, columns, tables, headers and footers, file type, or whether the file already contains hidden text from a template. If you attach the file, I'll run those checks.

## Upgrade menu

These are offers, not part of the ledger.
- **Attach the resume file.** It unlocks the parse-safety check, including a scan for hidden text you didn't author.
- **Answer C1 or R1.** A confirmed answer becomes a real row.
- **Share outcome numbers you actually have for the email flows or webinars.** Conversion or pipeline figures would give me rows I can trace. I won't estimate them.

## Questions

R1: Of your 6 years, roughly how many were spent running paid search, lifecycle email and webinars, as opposed to other marketing work?
C1: Have you distributed content beyond those channels, for example promoting webinar recordings or gated content, or running a newsletter?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.