I built this from the summary you pasted, not your actual CV text. Each "Current line" below is your own sentence as you wrote it to me. Nothing is applied yet.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in our ledger pipeline, one handling about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "one handles about 40k requests/minute at peak" | `[grounded]` your CV summary | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer" | *(unchanged, moved to the first bullet under your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer" | `[grounded]` your CV | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak" | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak" | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak" | `[grounded]` your CV | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander" | "On-call rotation every fourth week for two years" | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander" | `[grounded]` your CV | pending your approval |
| E5 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander" | "Ran six incidents as incident commander" | `split` | "I've run six incidents as incident commander" | `[grounded]` your CV | pending your approval |
| E6 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month" | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month" | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month" | `[grounded]` your CV | pending your approval |
| E7 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Kafka, Postgres, gRPC, Terraform, Datadog" | `surface` | "Go and Rust daily for 4 years"; "Kafka, Postgres, Terraform, gRPC, Datadog" | `[grounded]` your CV | pending your approval |

- **E1:** I kept "7 years" attached to the title exactly as you wrote it. Your sentence doesn't say whether it means 7 years total or 7 as a senior, and I took the reading that claims less.
- **E5:** the sentence you wrote doesn't say you were on call for those six incidents. It says only that you ran them as incident commander.
- **E6:** I used "onboard" and "pairing" and did not write "mentor". The JD asks for mentoring mid-level engineers, and you described onboarding new hires. I don't know their level.
- **E7:** this only moves Go and Rust into your skills line. I did not add a "Go services" claim.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | already_evidenced | "Senior Software Engineer, 7 years" is already in your CV. E1 moves it to the top. | `[grounded]` your CV |
| 2 | Production Go | must-have | surfaced_by_edit | E1 and E7 surface "Go and Rust daily for 4 years". Your material doesn't say which of the three services are Go, so "production Go services" is not written. See the first question below. | `[grounded]` your CV; `[inferred]` that a payments ledger pipeline is production work |
| 3 | Distributed systems at scale | must-have | not_evidenced | E3 surfaces the scale (about 40k requests/minute at peak). "Distributed" appears nowhere in your material, and Kafka in a tools list isn't evidence of it. See C1. | `[grounded]` the scale figure; `[generic]` that this phrase usually means multi-node or multi-service design |
| 4 | Strong incident response | must-have | surfaced_by_edit | E5 | `[grounded]` your CV |
| 5 | Experience mentoring | must-have | surfaced_by_edit | E6 covers onboarding and a month of pairing. It does not show mentoring mid-level engineers. | `[grounded]` your CV |
| 6 | Own Go services at high request volume | important | surfaced_by_edit | E3 | `[grounded]` your CV |
| 7 | Drive down p99 latency | important | surfaced_by_edit | E2 | `[grounded]` your CV |
| 8 | Own on-call | important | surfaced_by_edit | E4. You wrote "rotation every fourth week", so I did not write "own on-call". | `[grounded]` your CV |
| 9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in your material touches product or roadmap. See C2. | `[grounded]` your CV |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Request volume (40k/min) and Kafka and Postgres in a tools list. It does not say how the services depend on each other or fail. | It is a must-have, and the volume figure alone leaves the "distributed" half unanswered. | Your services consuming or producing Kafka topics; a service that coordinates with other ledger services; a failure or consistency problem across services that you worked through | An architecture doc, a design review, a postmortem | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | No product-facing work appears. | It is a named duty of the role, and a reader would find no sign of it. | Deciding with a PM what to build first; pushing back on or re-ordering a deadline because of latency or reliability work; scoping the cache-layer rework with non-engineers | A planning doc, a roadmap thread, a project brief | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on applications of this kind |

If C1 or C2 doesn't hold up, the honest position is that it is a real gap against the JD. I will not write a hedged line to cover it.

## Not written, and why

- **"Distributed systems at scale":** your material gives volume and a Kafka listing, not distributed design. The gap is named in C1.
- **"Production Go services handling 40k requests/minute":** you haven't said that service is written in Go.
- **"Mentored mid-level engineers":** you onboarded new hires of unstated level. "Mentored" and "mid-level" would both be upgrades.
- **"Owned on-call for my services":** you are on a rotation. Owning on-call is a different claim.
- **"Partnered with product" or "drove roadmap":** nothing supports it.
- **"Designed and shipped" the services:** you wrote "own", not "designed" or "shipped".
- **"Reduced latency across the platform":** the 380ms to 95ms figure is for the balance-read path only.

## Parse-safety check

I could not run this properly because I have only your pasted summary, not the CV file. Send the file and I'll check its section headings, date formats, and whether any tables or columns will trip a parser. Nothing in the proposed lines uses anything unusual: plain text, no special characters beyond the dashes you already used.

## Upgrade menu

These are offers, not part of the ledger:

- **p99 evidence:** a dashboard screenshot or write-up of the 380ms to 95ms change would turn E2 from a self-reported number into one an interviewer can inspect.
- **Incident evidence:** a postmortem from one of the six incidents would back E5.
- **Onboarding evidence:** a checklist or doc from the onboarding pairing would back E6. It would also show whether any of the new hires were mid-level.
- **A drafted cover-letter paragraph:** I can write one that uses only the approved rows, if you want it.

## Questions

E3 — Which of your three ledger services are written in Go, and is the 40k requests/minute one among them?
C1 — Do any of your services depend on each other or on Kafka topics in a way that has caused a failure or consistency problem you worked through?
C2 — Have you ever sequenced or scoped work with a product manager, even informally, such as trading a feature against the cache rework?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

To approve, list the rows (for example "Approved: E1, E2, E3, E7; Rejected: E5"). I'll then produce the tailored CV from the approved rows only.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.