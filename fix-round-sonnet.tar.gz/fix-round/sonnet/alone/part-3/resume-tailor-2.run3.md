Dev, here is the ledger. Nothing in it is applied. I worked from the sentences you pasted and treated each as its resume line, so if the resume words them differently, send it and I'll redo the quotes. I did not put your analyst title or a "data engineering" claim anywhere in the ledger, because your material doesn't support one.

**Where this stands:** the resume as written carries dimensional modelling and your dbt work well. It does not carry the 3+ years of data engineering the posting lists as must-have, and it carries no orchestration, streaming, Spark or Kafka. The ledger puts your real evidence first and names the gaps. Whether to apply anyway is job-underwriter's question, not this ledger's.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience, Senior Data Analyst | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your resume | pending your approval |
| E2 | Experience, Senior Data Analyst | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to the second bullet; "with our then-DE" stays)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E3 | Experience, Senior Data Analyst | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke." and "Added tests to the nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E4 | Experience, Senior Data Analyst | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `compress` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |
| E5 | Summary | *(no current line)* | "Senior Data Analyst, retail, 5 years. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E6 | Experience, Senior Data Analyst | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved below the Python bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your resume | pending your approval |

How I audited the rows:
- **E3:** the two halves are separate claims. I did not turn them into "owned pipeline reliability" or "data quality ownership". "Tests" stays "tests". "Breaks" became "broke" so the line doesn't imply you were on call.
- **E4:** "some scripting" stays. Dropping "some" would be the quiet upgrade.
- **E5:** it has three sentences and joins nothing. "Senior Data Analyst, 5 years, retail" is ambiguous (5 years in the role or as an analyst overall), and I kept your wording rather than pick the bigger reading. I did not add "on Redshift" to the dbt line, since you didn't say the models run there.
- **E2:** keeping "with our then-DE" matters. Without it the line would claim you designed the schema alone.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Your title and years are analyst work. The nearest adjacent work is E1–E3. See C1. | `[grounded]` |
| R2 | Production Python | important | `not_evidenced` | E4 shows pandas and cron scripts. Your material doesn't say "production". See C2. | `[grounded]` |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | You have never used Airflow. The nightly dbt job (E3) is the nearest thing. See C3. | `[grounded]` |
| R4 | Dimensional modelling, and modelling the warehouse | important | `surfaced_by_edit` | E2 and E5. This is one mart's star schema, designed with a data engineer, not the whole warehouse. | `[grounded]` |
| R5 | Data quality | important | `surfaced_by_edit` | E3 shows you added tests. It shows no ownership of data quality. | `[grounded]` |
| R6 | SLAs | important | `not_evidenced` | Named absence below. | `[grounded]` |
| R7 | Build and own batch pipelines | important | `not_evidenced` | You built and maintain dbt models (E1) and fix the nightly job (E3). You haven't said you built or own the pipeline. See C1 and C3. | `[grounded]` |
| R8 | Partner with analytics on requirements | important | `not_evidenced` | You were on the analytics side. E2 shows you working with a data engineer, which is the reverse seat. | `[grounded]` |
| R9 | Streaming experience | preferred | `not_evidenced` | Named absence below. | `[grounded]` |
| R10 | Spark and Kafka (named in the duties, not the requirements) | preferred | `not_evidenced` | Named absence below. | `[grounded]` |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | Five years as an analyst, 25 dbt models, a star schema, and a nightly job you repair. No role or task described as data engineering. | The posting marks years as its one must-have, so this is the line a reader checks first. | A load into Redshift that other people's reports depended on; ingestion or transformation work done in the gaps of an analyst role; time spent as the person fixing the pipeline rather than reading its output | A repo, a dbt project, an architecture note, a manager's description of the work | `[grounded]` what the resume does and does not say; `[generic]` years requirements usually act as a first filter |
| C2 | Production Python | important | pandas for analysis and "some scripting" on a cron. That shows scripts that run, not that anyone depends on them. | The posting asks for "production" Python, and your resume doesn't say that word or describe the stakes. | A vendor-API pull that feeds a table other people use; a script that alerts someone when it fails; a script with retries or logging | The script repo, a cron or scheduler entry, a failure alert | `[grounded]` what the resume does and does not say; `[generic]` what screeners look for behind this phrase |
| C3 | Airflow or equivalent orchestration | important | A nightly dbt job you fix and extend. Nothing says what schedules it or who set that up. | "Or equivalent" leaves room for a scheduler you have used, but only if it is named. | dbt Cloud jobs; GitHub Actions or Jenkins running dbt; a scheduler you configured or changed | Job config, a schedule file, a run history | `[grounded]` what the resume does and does not say; `[generic]` what counts as "equivalent" varies by employer |

Named absences (nothing in your material to pull):
- **SLAs:** you have not described owning a delivery commitment on a job. Closing it means running a job with a stated delivery time and an alert when it misses, for example your nightly dbt job if one exists. If none exists, setting it up on a side project would count.
- **Streaming, Spark, Kafka:** you have never used them, and streaming is listed as a plus. Closing it means a small hands-on project, for example Kafka into a table, done properly enough to explain. For this role these are the cheapest gaps to leave open.
- **Partnering with analytics on requirements:** you stood on the analytics side. Closing it would take a project where you scoped data needs for analysts. It is not worth forcing into a bullet.

## Not written, and why (prohibited claims)

- "3+ years of data engineering experience" or any "Data Engineer" title. Your work was analyst work, and years are not something wording can change.
- "Built and owned batch pipelines". You maintain dbt models and fix a job. Building and owning a pipeline is a different claim.
- "Production Python" or "production-grade ETL". Your words are "some scripting to pull vendor APIs on a cron".
- "Orchestrated pipelines" for the cron scripts or the dbt job. That would present scheduling as orchestration, and you have never used Airflow.
- Spark, Kafka or streaming, in a skills list or anywhere else.
- "Owned data quality and SLAs". You added tests.
- "Partnered with analytics". You were the analytics partner, and the word would flip which side of the table you sat on.
- "Designed the warehouse" or "modelled the warehouse". You designed one mart's star schema with the then-DE.

## Parse-safety check

Your resume reached me as pasted prose, so I could not run any of the checks: multi-column layout, tables and text boxes, images or icons, content in headers or footers, non-standard headings, and file type. I also could not look for hidden text from a template or earlier tool. Send the file and I'll run all of them.

## Upgrade menu

- **The actual resume file:** this would let me propose cuts of lines that don't help here (retail-specific analysis, say), match your real bullet order, and run the parse check.
- **A link or excerpt of the dbt project (the orders mart models and tests) or the vendor-API script repo:** this would tie E1–E4 to something inspectable instead of your word alone.
- **Answers to C1–C3:** an answered recall prompt is the one thing that can turn a `not_evidenced` row into a real line. I'll confirm what I heard before writing anything from it.

## Questions

C1 — Outside your analyst duties, have you done work that was data engineering in substance, such as building or running a load that other people's reports depended on, and roughly for how long?

C2 — For the vendor-API scripts on cron, does anyone depend on their output, and what happens or who finds out when one fails?

C3 — What runs your nightly dbt job (dbt Cloud, GitHub Actions, Jenkins, cron or something else), and did you set up or change that schedule yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip. Tell me which of E1–E6 you approve or reject.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.