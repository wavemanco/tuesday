I've read the skill's rules. I'm building the ledger from your CV and the dossier excerpt you pasted. Nothing below is applied.

**What I'm working from.** I have only your CV as prose, not the document itself. So each "current line" is your sentence as you gave it, and the reorder rows assume your current order differs from the one proposed. I haven't seen the dossier's `role_profile`, so the JD is the one you pasted. I inherited the dossier's R1 and R2 judgments (adjacent, medium) without upgrading them. The other coverage rows and E2–E5 are mine. E1 is the dossier's pending edit; I re-audited it against your sentences and it still traces.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience (inherited from dossier E1) | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged — moved to the first line under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged — moved directly after the integrations line)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged — kept as its own line, placed straight after the Experience lines)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Wrote the internal integration playbook the whole team uses." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV | pending your approval |

- **E5** is three sentences kept separate, in your wording, with your real title first. I did not add "product" anywhere. If you approve it, its lines repeat E1 and E2, so tell me if you'd rather drop it.
- **E2 and E3** change position only. "Led" stays "Led". "Collecting client feedback" stays that and does not become "discovery".
- **E4** keeps "Comfortable in". It does not become "wrote OpenAPI specs".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Dossier: adjacent, transferability, medium. Integration leadership (E2, E1) is adjacent; roadmap ownership and prioritisation authority are not evidenced. See the named absence below and C1. | `[grounded]` dossier evidence_map; your CV says you never held a PM title |
| R2 | Shipped API or platform products | important | `not_evidenced` | Dossier: adjacent, medium. E2 shows you led integrations of your vendor's REST APIs; nothing in your CV says you shipped one. See C2. | `[grounded]` dossier evidence_map and your CV |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4 (Postman, SQL, OpenAPI specs) and E2 (REST APIs end to end). The evidence is tool comfort and integration delivery. | `[grounded]` your CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 puts client-facing delivery first. Your CV does not mention working with engineering, product or executives, so this is evidenced on the client side only. | `[grounded]` your CV |
| R5 | Own the partner-API roadmap | important | `not_evidenced` | E3 shows you collected client input for product, not that you decided what was built. Dossier: roadmap ownership not evidenced. See C1. | `[grounded]` dossier evidence_map and your CV |
| R6 | Run discovery with integration partners | important | `not_evidenced` | E3 is the adjacent work. Your sessions were with clients and your CV doesn't describe them as discovery. See C1. | `[grounded]` your CV |
| R7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | Nothing in your CV says you specced work or worked with engineering squads. The playbook (E1) is internal documentation, not a product spec. See C2. | `[grounded]` your CV |
| R8 | Define adoption metrics | important | `not_evidenced` | No metrics work in your CV. See C3. | `[grounded]` your CV |

## Gap handling

**Recall prompts, pending your answers**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own the roadmap and prioritise; run discovery (R1, R5, R6) | must-have | You ran quarterly roadmap-input sessions collecting client feedback. It doesn't say what happened to that input or who made the prioritisation calls. | The dossier's own reasoning is that prioritisation authority is not evidenced. This is the row that could move R1. | A request from the sessions that got scheduled; a ranked list you handed to product; a trade-off you argued for; a client you interviewed one-on-one about what they needed | Session notes, the feedback summary you sent to product, a ticket or roadmap item that cites it | `[grounded]` what the CV says and doesn't say; `[generic]` what this costs on PM applications |
| C2 | Shipped API product; specs and delivery with engineers (R2, R7) | important | You led integrations of your vendor's REST APIs and you're comfortable in OpenAPI specs. It doesn't say you shaped or released a change to the API itself. | The dossier has R2 at adjacent, medium. Confirmed specifics are what would move it. | An API change a client integration pushed you to request; a spec or ticket you wrote for engineers; testing or signing off a release; a playbook step that changed how the API got used | A ticket, a spec doc, release notes, an API changelog entry | `[grounded]` what the CV says and doesn't say; `[generic]` what this costs on applications of this kind |
| C3 | Define adoption metrics (R8) | important | No metric work stated; "30+" counts integrations, not usage. | The JD lists it as a core duty and nothing in your CV speaks to it. | Tracking time-to-live per integration; counting which endpoints clients used; a go-live checklist with success criteria; any dashboard or report you built or read | A dashboard screenshot, a tracking sheet, a report | `[grounded]` what the CV says and doesn't say; `[generic]` what this costs on applications of this kind |

**Named absence**

| # | Requirement | The gap, and what closing it would take | Provenance |
|---|---|---|---|
| R1 | 3+ years PM | You have never held a PM title, and the JD makes this a must-have. No wording closes that. It can only be narrowed by confirmed PM-type work from C1–C3, or by testing the same ask on a role that doesn't require years of titled PM. A titled-years requirement is likely read literally by whoever screens, so this is a risk to carry into the application, not a gate. | `[grounded]` your CV and the dossier; `[generic]` how titled-years requirements tend to be read |

## Not written, and why

- **"Product manager" or "3+ years product management"** — you never held the title and R1 is the JD's must-have. Adjacent work is in E1–E3 and the gap is named above.
- **"Owned the API roadmap" or "owned prioritisation"** — you ran input sessions. The dossier says roadmap ownership isn't evidenced.
- **"Shipped API products"** — you led client integrations of your vendor's REST APIs. Integrating an API is a different job from releasing one.
- **"Partnered with integration partners" or "ran partner discovery"** — your words are "clients" and "collecting client feedback". The JD's "partner" and "discovery" would change who you sat across from and what the sessions were.
- **"Wrote API specs" or "authored OpenAPI specs"** — "comfortable in" is not authorship, and the playbook isn't a product spec.
- **"Drove delivery with engineering squads" and "defined adoption metrics"** — neither appears in your CV (R7, R8).
- **"30+ clients"** — the 30+ counts integrations. A client may have had more than one.
- **From the dossier, unaltered:** "built an internal request-triage tool — memory lead, candidate could not confirm ownership". This stays out, and I'm not asking about it again.
- **From the dossier, unaltered:** "has been the customer of a partner API platform — candidate worked vendor-side". You were on the vendor's side, so no line should imply a partner's-eye view.

## Parse-safety check

Your CV arrived as prose, not a file. I could not check layout (columns, tables or text boxes, images, headers and footers, file type). I could not check for hidden text a template might have added. What I can say: keep contact details out of the header or footer, use standard headings (Summary, Experience, Skills), and send a `.docx` or a text-layer PDF. Nothing here asks for hidden text and none will be added.

## Upgrade menu

- **Your CV as a file.** This runs the parse checks and lets me quote your exact current lines. It would also show any older bullets or earlier versions that carry evidence this prose dropped.
- **An inspectable artifact for C1–C3.** The things PM-type work leaves behind are a spec or PRD, a roadmap doc, a launch note, an API changelog entry, or an adoption dashboard. Any one of them would take a claim from medium toward high.
- **The playbook or an OpenAPI spec you wrote.** This would let E1 and E4 point at something a reader can open.
- **The dossier's `role_profile` section.** I could then check my reading of the JD tiers against the one it was built on.

## Questions

C1 — After a roadmap-input session, what happened to the feedback, and who decided what got built? What exactly did you do in that decision?

C2 — Did any client feedback or integration problem lead to a change that shipped in your vendor's API? If so, what was your part: writing the request, speccing it, testing it, or something else?

C3 — Did you track anything about how clients used the API or how their integrations went live, such as time-to-live or usage? What was it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.