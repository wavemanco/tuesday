I'll read the reference files the skill names before building the ledger.
Nothing in this is applied yet. Every row is a proposal. I used your dossier, so I did not re-derive its judgments.

Your CV came as prose, not a file. I treated each sentence you gave me as a current line, and I haven't seen your layout. "Current line" below means your sentence, not necessarily how it sits on the page.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience (inherited from dossier E1, re-audited) | "Wrote the internal integration playbook the whole team uses" | "Wrote the internal integration playbook the whole team uses" as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end" | *(unchanged, moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product" | *(unchanged, moved directly below the integrations bullet)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs" | "Comfortable in Postman, SQL, OpenAPI specs" as its own line | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead at an enterprise software vendor for 7 years. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |

- **Wording:** every proposed line keeps your own wording. That is why the verbs stay "led", "wrote", "ran" and "comfortable in", and why the title stays as you hold it.
- **E5:** it keeps three separate sentences. "7 years" is read as your time in that role, which is the smaller reading of your sentence. Reject E5 if you don't want a summary.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | `not_evidenced` | The dossier has this as adjacent, transferability gap, medium confidence. E2, E3 and E5 put the adjacent work first but do not close it. See C1. | `[grounded]` dossier R1 and your "Never held a PM title." |
| 2 | Shipped API or platform products | must-have | `not_evidenced` | The dossier has this as adjacent, medium confidence. Integrating the APIs is not the same as shipping them as products. See C2. | `[grounded]` dossier R2 |
| 3 | Technical fluency | important | `surfaced_by_edit` | E4, E2 and E1. | `[grounded]` your CV |
| 4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 show client-facing work. I do not use the phrase, because you never wrote it about yourself. | `[grounded]` your CV |
| 5 | Own the partner API roadmap | important | `not_evidenced` | This is the same gap as row 1. The dossier says roadmap ownership and prioritisation authority are not evidenced. | `[grounded]` dossier R1 reasoning |
| 6 | Run discovery with integration partners | important | `surfaced_by_edit` | E3. The line stays "collecting client feedback", because that is what you wrote. | `[grounded]` your CV |
| 7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | Only "OpenAPI specs" is in your material, and that is "comfortable in". See C3. | `[grounded]` your CV |
| 8 | Define adoption metrics | important | `not_evidenced` | No metric work appears in your material. This is a named absence below. | `[grounded]` your CV |

## Recovery per gap (recall prompts)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership and prioritisation authority | must-have | You ran quarterly roadmap-input sessions that collected client feedback for product. It does not say who decided what got built. | The dossier flags exactly this as not evidenced, and it sits under the 3+ years PM requirement. | Deciding which client requests you pushed to product and which you didn't; a ranked list you handed over; a feature that shipped because of your sessions | A session summary or deck, a request backlog, a product-team reply | `[grounded]` what your sentence says and omits; `[generic]` that PM screens look for decision authority |
| C2 | Shipped API or platform products | must-have | You led 30+ client integrations of REST APIs. Nothing says you took part in an API's release. | A "shipped API products" requirement is a must-have, and integrating a product differs from shipping one. | Writing or reviewing an OpenAPI spec before release; a launch or deprecation you ran from the client side; a docs or sandbox change you drove | A spec file, release note, changelog entry or launch checklist | `[grounded]` what your sentence says; `[generic]` what this costs on applications of this kind |
| C3 | Specs and delivery with engineering | important | "Comfortable in OpenAPI specs" is the only spec-related line. | The role asks for spec-writing and delivery with two squads. | A client-driven change you wrote up for engineering and followed through; an integration blocker you escalated with a written description | A ticket, a write-up or a spec you authored | `[grounded]` your CV; `[generic]` what the role asks |

**Named absence, adoption metrics (row 8):** nothing in your material defines or tracks adoption. Closing it would take a concrete case, such as how you judged whether a client's integration was live and healthy, or a metric you reported to product. If no such case exists, it is a real gap for this role. It is one of the lesser ones, because the posting lists it as a responsibility rather than a must-have.

## Not written, and why

- **"Product Manager" title or "3+ years PM"**: you have never held the title, and the posting makes the years a must-have. The adjacent work is in E2, E3 and E5, and the gap is named in the map.
- **"Owned the roadmap" or "set priorities"**: your sentence says you collected client input. Who decided what to build isn't stated.
- **"Shipped API products"**: you led client integrations of APIs, which is a different activity.
- **"Ran discovery with integration partners"**: that is the posting's wording. Yours is client feedback collected on the vendor side, and the substitution would change who sat on which side of the table.
- **"Authored OpenAPI specs"**: your sentence says "comfortable in".
- **"Managed stakeholders" or "drove delivery with engineering"**: you never said either.
- **Adoption figures or metrics**: none were given, so none can be written.
- **From the dossier's rejected_inferences, unaltered:** "built an internal request-triage tool — memory lead, candidate could not confirm ownership"
- **From the dossier's rejected_inferences, unaltered:** "has been the customer of a partner API platform — candidate worked vendor-side"

## Parse-safety check

Your CV arrived as pasted text, so I could not run any of these checks: multi-column layout, tables and text boxes, images or skill bars, contact details in headers or footers, section headings, and file type. If you send the actual file, I can run them. I also can't flag any hidden text you didn't write, because that needs the file.

## Upgrade menu (offered, built only on approval)

- **Your CV as a .docx or text-layer PDF:** this adds the parse-safety check and replaces my guessed layout with your real current lines.
- **The integration playbook itself, or a roadmap-input session summary:** these are inspectable artifacts, and either could raise the medium confidence on those lines.
- **Answers to C1 to C3:** each answer turns a `not_evidenced` row into a real one, after a confirmation card.

## Questions

C1 — Across your quarterly roadmap-input sessions, did you decide which client requests went to product, or did you hand over everything and product chose?
C2 — Did you ever write, review or sign off on an API spec, release or deprecation before clients saw it?
C3 — Did you ever write a change up for engineering and follow it through to delivery?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.