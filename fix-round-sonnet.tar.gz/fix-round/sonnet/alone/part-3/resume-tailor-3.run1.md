I've built the ledger from your CV text and the dossier excerpt. Nothing is applied yet.

- **Dossier:** I used `evidence_map` R1 and R2, the E1 edit, and the two rejected inferences as pasted. The dossier is for the same role, Product Manager, Platform APIs at Quartzline, so I treated it as current. I did not re-judge R1 or R2: both stay adjacent with medium confidence, and the claims are no stronger for being written into a CV.
- **Your CV:** I only have it as prose, so I can't see its actual section order or bullet layout. I've assumed the lines are separate sentences in a single Experience section. Please correct me if not.

## Edit ledger — `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (dossier E1: currently not on its own line) | "Wrote the internal integration playbook the whole team uses." as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV; inherited from dossier E1 and re-audited | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second bullet, above E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." as its own Skills line | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |

Notes on the rows:
- **E1:** I left the wording unchanged. "Whole team" stays "whole team" and does not become company-wide.
- **E3:** The sessions *collected feedback*. The row does not say you prioritised anything or owned the roadmap, because the dossier marks that as not evidenced.
- **E4:** Listing a tool is not the same as authoring with it. "Comfortable in" stays, and it does not become "wrote OpenAPI specs".
- **E5:** The two sentences stay separate and your real title stays first. The summary does not say "product" anywhere.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ yrs PM | must-have | not_evidenced | You have not held a PM title. The dossier rates it adjacent, a transferability gap with medium confidence: the integration leadership is adjacent, but roadmap ownership and prioritisation authority are not evidenced. Recall prompt C1. | `[grounded]` your CV and dossier R1 |
| R2 | Shipped API or platform products | important | not_evidenced | The dossier rates it adjacent with medium confidence. You led integrations of your vendor's REST APIs, which is not the same as shipping an API product. Recall prompt C2. | `[grounded]` your CV and dossier R2; `[inferred]` the priority tier, since the JD lists no tiers |
| R3 | Technical fluency | important | surfaced_by_edit | E4, E2 | `[grounded]` your CV; `[inferred]` the priority tier |
| R4 | Stakeholder management | important | surfaced_by_edit | E3, E2. The evidence is client-facing integration work and feedback sessions with clients, not internal stakeholders. | `[grounded]` your CV; `[inferred]` the priority tier |
| R5 | Define adoption metrics | important | not_evidenced | Nothing in the CV mentions metrics. Recall prompt C3. | `[grounded]` your CV; `[inferred]` the priority tier |
| R6 | Write specs and drive delivery with engineering squads | important | not_evidenced | Named absence, below. | `[grounded]` your CV; `[inferred]` the priority tier |

## Gap handling — recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM, specifically roadmap ownership and prioritisation authority | must-have | You ran the roadmap-input sessions and collected client feedback. It does not say what happened to that feedback or who decided. | This is the must-have, and the dossier names this as the missing piece. | Deciding or helping decide which client requests went to product; a ranked list you handed over that product acted on; an API change or fix that came out of your sessions | A session summary or feedback digest, a ticket or roadmap item you raised, a note from product | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API or platform products | important | You led client integrations of your vendor's REST APIs. Nothing shows you releasing an API, SDK, connector or platform feature. | The dossier rates this adjacent only. A shipped item would move it. | A connector, sample app, SDK piece or API change you specified or released; a reusable integration template clients adopted | A release note, changelog entry, repo link or doc page | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Define adoption metrics | important | Nothing in the CV mentions measurement. | The JD has the role defining adoption metrics, so a bare absence is visible. | Tracking time-to-integrate, integrations completed or live usage across your 30+ clients; success criteria built into the playbook | A tracker, dashboard, or the playbook's milestone section | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |

**R6, named absence:** Nothing you've told me shows you writing specs that engineering built from, or driving delivery with an engineering squad. Postman and OpenAPI comfort is adjacent, not the same. Closing it would take either a past example you can describe, such as a request you specified that engineering then built, or a short spec you write for a partner-API feature as a work sample.

## Not written, and why — pending your approval

- **"Product Manager" in any title, summary or retitle, and "3+ years of product management":** you have never held the title and this is the JD's must-have. Your title stays as written. The gap is in the coverage map.
- **"Owned the roadmap" or "prioritised the roadmap":** the dossier says roadmap ownership and prioritisation authority are not evidenced. Collecting feedback is not deciding.
- **"Shipped API products":** you led integrations of your vendor's APIs. That is not the same as releasing one.
- **"Ran discovery with partners":** that is the JD's vocabulary. Your words are "roadmap-input sessions" and "clients", and I have not relabelled them.
- **"Wrote OpenAPI specs", "defined adoption metrics", "drove delivery with engineering squads":** none of these is in your material. Comfort with a tool is not authorship.
- **Rejected inference, unaltered from the dossier:** "built an internal request-triage tool". This was a memory lead and you could not confirm ownership, so it does not appear anywhere.
- **Rejected inference, unaltered from the dossier:** "has been the customer of a partner API platform". You worked vendor-side, so the CV won't say you know this from the client's side.

## Parse-safety check

Your CV arrived as pasted text, so I could not check multi-column layout, tables or text boxes, images or skill bars, content in headers or footers, section headings, or file type. All the lines above are plain sentences. No hidden text is proposed anywhere.

## Upgrade menu

- **Your CV as a file (.docx or PDF):** this would let me run the parse-safety checks above and confirm the real section order, so E1–E4 can be placed against your actual layout.
- **An excerpt of the integration playbook:** this would be inspectable proof for E1 and might support C3, if it has milestones or success criteria.
- **A Postman collection or OpenAPI file you wrote:** this would back E4 and R3 with something a reader can open.
- **Notes or a summary from the roadmap-input sessions:** this would show what happened to the feedback, which is what C1 asks.
- **Prior CV versions:** they may hold lines this version dropped.

## Questions

C1 — When your quarterly client feedback went to product, did you have any say in which items made it onto the roadmap, and can you name one that did?
C2 — Did anything you specified or built around your vendor's APIs ever ship as a release, connector, SDK piece or sample that other clients then used?
C3 — Across the 30+ integrations, did you or your team track anything like time-to-integrate or live usage, and who set it up?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.