Nothing below is applied. Every row is pending your approval, and the tailored CV is only produced from the rows you approve.

I built this from the CV summary you pasted, so "current line" means the sentences you typed. I haven't seen your actual layout. The dossier matches this role, so I used its R1 and R2 judgments (both `adjacent`, `medium`) as they stand. E1 below is the dossier's pending edit, audited again against your text.

The main finding is that the one must-have, 3+ years as a PM, can't be written for you. You have never held a PM title, and the dossier found roadmap ownership and prioritisation authority not evidenced. The ledger puts your integration, playbook, feedback-session and technical evidence first, in your own words, and doesn't try to make it read as PM tenure.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (not seen as its own line in what you sent) | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` cv, self-report; this is dossier edit E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv, self-report | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to the third bullet, after the playbook line)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv, self-report | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved to a line directly under the role instead of the foot of the CV)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` cv, self-report | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead at an enterprise software vendor for 7 years. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv, self-report | pending your approval |

- **E1** is a `surface`. It restores nothing and adds nothing, and "the whole team" stays exactly as you wrote it.
- **E2 to E4** change position only, and no verb moves with them. "Ran" stays "ran" and "Comfortable in" stays "comfortable in". A tool you are comfortable in is not a tool you shipped with.
- **E5** keeps the years and the title as yours (solutions engineer / implementation lead), and the two claims stay as two sentences.
- I proposed no cut because I haven't seen the rest of the CV. If there are older or off-target bullets, paste them and I'll add `cut` rows.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | `not_evidenced` | No row can write it. Nearest work is in E1 to E3. Dossier R1 is adjacent, transferability, medium. A years-titled requirement may be screened literally, so name it as a risk, not a gate. | `[grounded]` your "Never held a PM title" and dossier R1; `[inferred]` literal screening, derived from the requirement being phrased as a count of years |
| 2 | Shipped API or platform products | important | `not_evidenced` | You led client integrations of the APIs; the material doesn't say you shipped them. Dossier R2 is adjacent, medium. See C1. | `[grounded]` your integration line and dossier R2 |
| 3 | Technical fluency | important | `surfaced_by_edit` | E4, with E2 and E1 | `[grounded]` your tools and integration lines |
| 4 | Stakeholder management | important | `surfaced_by_edit` | E2, E3 and E1 evidence client-facing work only. Internal engineering and product stakeholders are not evidenced. | `[grounded]` your lines as quoted in the ledger |
| 5 | Own the partner-API roadmap | important | `not_evidenced` | Only the input-collection sessions in E3 exist. Prioritisation authority is not evidenced, per dossier R1. See C2. | `[grounded]` your sessions line and dossier R1 |
| 6 | Discovery with integration partners | important | `not_evidenced` | E3 is client feedback for product, which is a different kind of activity. Your word is "client", not "partner", and E3 keeps it. | `[grounded]` your sessions line |
| 7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | OpenAPI comfort in E4 is not authorship of specs. See C3. | `[grounded]` your tools line |
| 8 | Define adoption metrics | important | `not_evidenced` | Nothing in your material. See the named absence below. | `[grounded]` nothing in your material |

## Recovery per gap (recall prompts)

| # | Requirement | Priority | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Shipped API or platform products | important | You led client integrations of your vendor's REST APIs. Nothing says you shipped API features or products. | The JD asks for a shipped API or platform product, and your CV currently shows only the consumption side. | Taking part in a beta or early release of an API feature with named clients; writing release notes, migration guides or deprecation comms for an API change; being the person whose integration feedback changed an endpoint before release | A release note, changelog entry, migration guide or beta-programme brief | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Own the roadmap, including prioritisation | important | You ran quarterly feedback sessions for product. Who decided what was built is not stated. | The dossier already flags prioritisation authority as not evidenced, and the JD's first duty is roadmap ownership. | Ranking or recommending items from the sessions to product; having a say in what got scheduled; a case where your feedback was or wasn't taken up | A session summary, a ranked list, or a roadmap doc with your input in it | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Specs and delivery with engineering squads | important | OpenAPI "comfort" is listed. Writing specs or working with engineers on delivery is not stated. | The JD names specs and two squads, so this is where a reader will look for hands-on delivery. | Writing or reviewing an OpenAPI spec for a client integration; filing and following through on defects or feature requests with engineering; unblocking a delivery with a squad | An OpenAPI file or spec excerpt, a ticket thread, a design note | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |

**Named absence, adoption metrics (requirement 8).** Nothing in your material measures adoption, and I won't write one. Closing it would take a real figure from your own integrations that you could stand behind, such as a count, a timeline or a usage number. That is only worth the effort if such a figure exists. If it doesn't, carry it as an open gap and expect the question in interviews.

## Not written, and why

- "Product Manager" or any PM title, and "3+ years of product management": you have never held the title.
- "Owned the roadmap", "set priorities", "drove prioritisation": your line says you ran sessions that collected feedback, not that you decided what was built.
- "Shipped API products" or "launched APIs": you led client integrations of the APIs, which is a different kind of work.
- "Ran discovery with integration partners": your word is "client feedback", and the JD's "discovery" and "partners" are the employer's vocabulary.
- "Wrote specs" or "managed engineering squads": OpenAPI comfort is not authorship, and no squad work is stated.
- "Drove adoption" or any adoption metric: no figure is evidenced.
- From the dossier, `rejected_inferences`, carried unaltered: "built an internal request-triage tool — memory lead, candidate could not confirm ownership".
- From the dossier, `rejected_inferences`, carried unaltered: "has been the customer of a partner API platform — candidate worked vendor-side". This one is a relationship inversion, because you stood on the vendor side.

## Parse-safety check

You pasted plain text, so I could not run any of the layout checks: columns, tables or text boxes, images, header or footer content, or file type. Your own sentences contain no hidden text. The one check I can make from text is headings, so keep conventional labels such as Experience and Skills. If you send the file, I'll run the full check.

## Upgrade menu

- **Your actual CV as a .docx or text-layer PDF:** I'd run the real parse check, quote your lines exactly, and find cuts.
- **Answers to C1 to C3:** each one that you confirm becomes a traced row and moves a `not_evidenced` requirement.
- **Artifacts:** a playbook excerpt, an OpenAPI file you wrote, roadmap-session notes or a release note. These would move rows from self-report to inspectable evidence.

## Questions

C1: Did you take part in releasing any API feature or change, for example a beta with clients, release notes, or a migration guide, and what exactly did you do?
C2: When you brought client feedback to product, did you recommend priorities, and did any of it change what got built?
C3: Have you written or reviewed an OpenAPI spec, or worked through a delivery with engineers, and what was your part?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.