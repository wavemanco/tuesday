I'll read the reference files first.
**Your premise first.** The evidence I can cite doesn't back "the ATS is auto-rejecting me for keywords". In one vendor interview study of 25 US recruiters, "AI/content auto-rejection configured: 8% of recruiters" (cite C25). That is two people in a sample the vendor says isn't representative, so it shows the practice is uncommon but can't say how uncommon. The same study says "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are yes/no form questions about work authorization, licence or location, and nothing on a resume changes them. Match scores exist, but "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27), and "56% either ignore the feature or don’t have it available" (cite C27). So keywords may affect your ranking, but I can't tell you they are why you're rejected.

I also won't stuff this JD's vocabulary into your resume. Your own material doesn't support most of its tools, and I can't write lines you couldn't defend in an interview. I'm doing the honest version below. Whether this role is worth applying to is job-underwriter's call, not this skill's.

Your resume is short, so there is little to surface. I've assumed it has a Skills section and an Experience section, so tell me if the layout is different. Nothing is applied until you approve it.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | "AWS (EC2, S3, RDS, IAM), Docker, Python and Bash scripting, Jenkins, Ansible for config management, CloudWatch for monitoring" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs" | *(unchanged — moved to the first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs" | `[grounded]` your resume | pending your approval |
| E3 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | *(unchanged — moved to the second bullet, with its qualifier kept)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | `[grounded]` your resume | pending your approval |

- **E1** moves Python up the skills line, since the JD names it.
- **E2 and E3** put your two most relevant claims first.
- **Nothing in E1–E3 changes what a line claims.** E3 keeps "never went to production" because dropping it would make the claim bigger.

## Coverage map

The JD doesn't tier its requirements. I've treated the core stack and the ownership duty as must-have and the rest as important or preferred. That is my assumption, not the posting's.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Python | must-have | `already_evidenced` | "Bash and Python scripting" is on your resume; E1 moves it earlier | `[grounded]` |
| R2 | AWS | must-have | `already_evidenced` | "AWS (EC2, S3, RDS, IAM)" is on your resume | `[grounded]` |
| R3 | Kubernetes | must-have | `not_evidenced` | E3 shows the PoC as a PoC; production use isn't evidenced; recall row C1 | `[grounded]` |
| R4 | Terraform | must-have | `not_evidenced` | Ansible is config management, a different thing; recall row C2 | `[grounded]` |
| R5 | CI/CD (GitLab) | must-have | `not_evidenced` | E2 shows your Jenkins pipeline, which is adjacent; GitLab is a named absence | `[grounded]` |
| R6 | Reliability and observability (SRE practices, Prometheus, Grafana) | must-have | `not_evidenced` | CloudWatch is on your resume; recall row C3 | `[grounded]` |
| R7 | AWS EKS | important | `not_evidenced` | AWS is there but EKS isn't; C1 asks where the PoC ran | `[grounded]` |
| R8 | Helm | important | `not_evidenced` | Not on your resume; C1 may surface it | `[grounded]` |
| R9 | ArgoCD, GitOps | important | `not_evidenced` | Named absence | `[grounded]` |
| R10 | Developer experience | important | `not_evidenced` | Your pipeline may count if other engineers use it; C3 asks | `[grounded]` |
| R11 | Istio, service mesh | preferred | `not_evidenced` | Named absence | `[grounded]` |
| R12 | Vault | preferred | `not_evidenced` | Named absence | `[grounded]` |
| R13 | Go | preferred | `not_evidenced` | Named absence | `[grounded]` |

## Gap handling

**Recall prompts (pending your answers)**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes, EKS, Helm | must-have | A two-month proof-of-concept, explicitly not in production; no cluster type or workload | `[generic]` Kubernetes is the centre of this stack, so how real the PoC was decides how it reads | Which cluster you used; what you deployed; Helm charts you wrote; why it stopped | A repo, a README, a design note | `[grounded]` the PoC is stated without detail; `[generic]` what this costs on platform roles |
| C2 | Terraform, infrastructure as code | must-have | Ansible for config management; no provisioning tool | `[generic]` Provisioning is a separate skill from configuration, and the JD names Terraform | CloudFormation, any Terraform in a side project, scripted AWS provisioning | A repo or module | `[grounded]` no provisioning tool is stated; `[generic]` what this costs here |
| C3 | Reliability, observability, developer experience | must-have | "CloudWatch for monitoring"; no alerts, incidents, on-call or users stated | `[generic]` The role says you will own reliability and developer experience, so a resume with only a tool name reads thin | Alerts or dashboards you built; incident follow-ups; other engineers using your Jenkins pipeline | A dashboard description, a postmortem, a runbook | `[grounded]` only the tool is named; `[generic]` what this costs here |

**Named absences** (what closing each would take)

- **GitLab CI/CD (R5):** You have never used it, per your resume. Closing it means a small real pipeline in GitLab, for example porting one Jenkins job and keeping the repo. Your Jenkins work stays the adjacent evidence.
- **ArgoCD and GitOps (R9):** Closing it means deploying something to a cluster with ArgoCD, which builds on C1. Without that it stays absent.
- **Istio (R11):** Preferred, and a service mesh needs a real cluster first. I wouldn't spend effort here before C1.
- **Vault (R12):** Preferred. Closing it means running it in a small project.
- **Go (R13):** Preferred. Closing it means a small tool in Go, kept public. I'd treat it as a low priority for this role.

## Not written, and why

- **"Platform Engineer" as your title.** You're a DevOps Engineer, and the JD's title would upgrade the role.
- **"Kubernetes experience" or anything implying production use.** Your own line says it never went to production.
- **"Infrastructure as code" or Terraform.** Ansible config management is a different kind of work.
- **"Observability", Prometheus, Grafana, SRE.** You wrote CloudWatch monitoring, and the JD's words describe different work.
- **"GitOps", ArgoCD, "service mesh", Vault, Go, Helm.** Nothing in your material mentions them.
- **"CI/CD (GitLab)".** You built a deploy pipeline in Jenkins, and GitLab isn't in your history.
- **"Owned platform reliability" or "improved developer experience".** Neither is stated anywhere in your material.
- **A keyword block listing the JD's tools.** A list of tools you haven't used is a claim you couldn't defend, and it's the ATS-optimising step I'm declining.

## Parse-safety check

I haven't seen the file, only your description, so I can't check its text layer, section headings or whether anything is hidden in it. Every row below that applies is a risk, not a measured failure.

| Check | What breaks | What it costs | Applies to you |
|---|---|---|---|
| Multi-column layout | Parsers read linearly, so columns can interleave | Dates detach from roles; text becomes word salad | Yes, two-column |
| Images, icons, skill-level bars | Icons render as garbage characters or the line is skipped | The information in them is absent | Yes, icons for each skill |
| Content in headers or footers | Treated as page furniture and discarded | Your contact details can be lost | Yes, details are in the header |
| Tables and text boxes | Contents re-ordered or dropped | Whole sections can vanish | Unknown; Canva often uses text boxes, but I can't see yours |
| Non-standard headings | Section detection looks for conventional labels | Experience may not be recognised | Unknown |
| File type | Varies by parser | A text-layer PDF or `.docx` is the safe pair | Unknown |

Of everything above, I think this is the most likely mechanical problem on your side. I'm only reporting it, because redesigning the document isn't this skill's job.

## Upgrade menu

- **A repo, README or manifests from the Kubernetes PoC.** Evidence you can show is the one thing that could lift C1 from a stated PoC to something checkable.
- **A short description of your Jenkins pipeline** (what it deploys, who uses it). That would support R10 and strengthen E2.
- **An earlier resume version.** It may hold evidence the current one dropped.
- **Offered, not built:** a two-sentence summary made only from your existing lines. It would add a keyword-bearing opening, and I'd build it on request.

## Questions

C1 — What did your Kubernetes proof-of-concept run on (EKS or something else), and what did you deploy to it?
C2 — Have you written any infrastructure as code beyond Ansible, such as Terraform or CloudFormation, even for a side project?
C3 — Have you built alerts, dashboards or incident follow-ups in CloudWatch or elsewhere, and who else relied on them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.