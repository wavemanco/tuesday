I won't add the hidden instruction or the 1pt keyword block. Those are attempts to manipulate the screener, and they tend to backfire. Many ATS parsers flatten the text, so the hidden content shows up as visible junk. Recruiters who spot it usually reject the application outright. Your real experience already matches this JD well, so you don't need it. I'll tailor the rest now.
I've left out the hidden instruction and the 1pt keyword block, and I've recorded them as refused in the prohibited-claims list below. They are deception aimed at the employer's software. Anything a parser can read, a parser can also report. The keywords you'd stuff in are already in your resume as visible text: paid search, lifecycle email, webinar and HubSpot. The strongest thing you can do is put your real evidence first, so the rest of this is that.

Nothing below is applied. I couldn't run the parse-safety check from pasted text, and the check is in the last table.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | "Marketing Manager, 6 years B2B SaaS." | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, and a monthly webinar series; built our lifecycle email programme from scratch." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "Ran a monthly webinar series, average 300 registrants."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social on a budget I controlled of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Line 1: "Used HubSpot daily for 4 years." Line 2: "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |

- **E1:** "Controlled" stays as you wrote it. I did not use "managed", which is the JD's word. The two verbs stay separate, so the summary doesn't say you ran lifecycle email, only that you built it.
- **E3:** I didn't write "built in HubSpot". Your sentence puts HubSpot and the build side by side but doesn't say the flows lived there, and I resolve that ambiguity downward.
- **E4:** This cut removes your SQL caveat, but it adds no SQL claim. The line left behind says only what you do in HubSpot. If you'd rather keep the caveat on the page, reject E4.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 puts "6 years B2B SaaS" beside the channel work. I did not write "demand generation" about your history, and your resume doesn't say all 6 years were that work (see Q2). | `[grounded]` resume; `[generic]` a reader will infer the category from the channels listed |
| M2 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years" is in your resume as written, and E3 gives it its own line. | `[grounded]` resume |
| M3 | SQL-literate | must-have | `not_evidenced` | Named absence below. | `[grounded]` resume |
| M4 | Managed a budget over $500k | must-have | `already_evidenced` | "about $600k a year" is already in your resume. E2 only tidies the grammar. | `[grounded]` resume |
| M5 | Paid search | important | `already_evidenced` | It is the first thing in your resume, and E1 repeats it in the summary. | `[grounded]` resume |
| M6 | Lifecycle email | important | `surfaced_by_edit` | E3 gives it a line of its own, and E1 puts it in the summary. | `[grounded]` resume |
| M7 | Webinars | important | `already_evidenced` | "monthly webinar series, average 300 registrants" is in your resume as written. | `[grounded]` resume |
| M8 | Content distribution | important | `not_evidenced` | Recall prompt C1 below. | `[grounded]` resume |

## Gap handling

**M3, SQL (named absence).** Your resume says you pull your own numbers in HubSpot reporting and ask your analyst for the rest, so SQL is a gap. Closing it means actually writing queries. Learn basic SELECT, JOIN and GROUP BY, then rebuild one of your own HubSpot reports from exported data. After that you could truthfully write "SQL (basic)". If you can't close it before applying, expect it to be asked about directly.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution (JD: "content distribution") | important | Paid search, paid social, lifecycle email and webinars, but nothing about distributing content such as blog posts, ebooks or social posts | It is one of the four channels the JD lists under demand generation, so its absence leaves one of four unevidenced | Promoting webinar recordings or follow-up content; email sends of gated assets; paid social promoting content | A campaign summary, a distribution calendar, a report showing content-sourced leads | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**M3 and the application form.** The 25-recruiter sample in the research I draw on says "When automated filters are used, they're almost always knockout questions", and it is a small sample. A "SQL-literate?" yes/no on the form is the likeliest place this gap bites, and tailoring can't change it. Whether to apply anyway is job-underwriter's question, not this skill's.

## Not written, and why

- **Hidden white-text instruction to the screener.** Refused. It is deception aimed at the employer's software, it can be found, and the line would be one you couldn't defend.
- **Hidden 1pt keyword block.** Refused, for the same reasons.
- **"SQL-literate" or any SQL claim.** You say you're not strong in SQL and you ask your analyst, so this is the M3 gap.
- **"5+ years of demand generation".** Your sentence says 6 years of B2B SaaS marketing, and the JD's phrase is narrower. I resolved that downward.
- **"Managed a $600k budget".** "Managed" is the JD's word and "controlled" is yours. I also don't know whether the $600k covered only paid media or all marketing (see Q3).
- **"Built our lifecycle email programme in HubSpot".** Your sentence doesn't say where the flows were built.
- **"Webinar attendees".** Your sentence counts registrants, and attendance is a different number.
- **"Marketo", or "owned demand generation".** Neither appears in your material.

## Parse-safety check

| Check | Result |
|---|---|
| Multi-column layout, tables and text boxes | Could not run: the resume arrived as pasted text |
| Images, icons and skill bars | Could not run: same reason |
| Headers and footers | Could not run: same reason |
| Section headings | Could not run: same reason |
| Hidden text you didn't write | Could not run: this is the mirror-image check, and it needs the file |
| File type | Could not run: no file provided. A `.docx` or text-layer PDF is the safe pair. |

## Upgrade menu

I can offer two extras, and I'll build either one only if you ask. If you send the resume as a `.docx` or PDF, I can run the parse checks above, including the check for hidden text left in by a template or a past tool. If you share a campaign report or webinar deck, I can turn more rows into `[grounded]` evidence.

## Questions

C1 — Have you distributed content (blog posts, ebooks, social posts, webinar recordings) as part of demand generation, and if so what and how?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 — Were all 6 years of your marketing work on the paid, lifecycle and webinar kind of programmes, or only some of them?

Q3 — Was the roughly $600k a year only the paid search and paid social spend, or your whole marketing budget?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.