I'll read the reference files first.
Inputs are enough to build the whole pack, so I'm building it now and asking nothing first. It covers three scheduled rounds, so it's in loop mode.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-canned-6c8d2322/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a loop pack for the three rounds on 20 November, with one shared fit snapshot and a bank of questions for each round. It has 29 questions, a values cheat sheet, reverse questions for each round, and a table mapping every JD requirement to the questions that cover it. It rests on the documents you pasted. I ran no web searches and have only your summary of the strategy brief, not its full text. There is no interviewer read yet because no names are assigned.

Your highest-ROI prep is question D1: you've stated you haven't worked in a contact centre, and the JD asks you to own the process across branches and the contact centre. Expect it in some form in all three rounds. The pack has you say the gap once, plainly, stay with what your own sentences carry, and then give a plan in the future tense.

Other gaps:
- **Presenting to senior leaders:** you've never presented above regional level, and the pack has you say so plainly and give a preparation plan.
- **Coaching supervisors:** your material says new tellers, not supervisors.
- **Digital self-service:** nothing in your material covers this, so it's an answer slot.

Several of your answers are slots because your sentences don't show the practice. These are what the spreadsheet held, whether it was in Excel, and whether the complaints log worked to an external rule. The pack won't write those in for you.

Say the word and I'll run a live drill, playing the Skeptic on D1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack — Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Built 11 November 2026 for a three-round loop on 20 November 2026.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| R1 | The recruiter | 30 minutes | Conversation |
| R2 | Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| R3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; "the values round — they score against the four values" |

Interviewer names are not assigned yet. Mode: loop. A shared fit snapshot comes first, then one mini-pack per round.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: every line of suggested wording is pending your approval, and you should say only what is true for you.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether what you say you did survives follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Each slot has two branches: say how you did it in your own words, or say plainly that you did not or it was not yours, and return to what your own sentences carry. The second branch is a limit, not a confession.

The highest-ROI prep in the pack is D1, the contact-centre objection. It will arrive in some form in all three rounds (see B1, D1 and J2). Rehearse it until it is boring.

## Fit snapshot

Your sentences are quoted exactly as you wrote them. Requirements are quoted from the JD you supplied. No row is a hard gate: the 4+ years requirement is a length of experience, not a licence or credential.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end and not branches in the plural. Words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any stage beyond the log was yours, say which and what you did, in your own words; if the log was the part that was yours, or you held no other stage, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn the channel, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet and does not show what it held. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed. If it carried volumes or resolution times, say which and how each was counted, in your own words; if it did not, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Derivation: the pack reads your "spreadsheet" as possibly Excel, and your sentence does not say which tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was in Excel, say so and what you built in it, in your own words; if it was another tool, or you would not call yourself comfortable in Excel, say so plainly and stay with the spreadsheet |
| F5 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says formal, and the JD says regulated; your material does not show whether the log worked to an external rule. Words: "I handled the branch's formal complaints log." Answer slot: expect a probe on the rules or deadlines the log worked to. If it was kept to a rule or deadline you worked with, name it in your own words; if you do not know the rule behind it, or none applied, say so plainly and stay with the log |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on length. It is still a line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: 6 years in retail banking, the last 3 as a branch supervisor |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated the limit. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first senior presentation, said as a plan and never as a past. Your material does not show what you presented at regional level or below; that is in the upgrade menu |
| F8 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your quote says new tellers, not supervisors. Words at that scope: "I trained new tellers on our escalation script." Answer slot: the JD aims at supervisors, so expect a probe on whether you have coached someone at your own level on an escalation. If you did, say who and what you did, in your own words; if all of it was tellers' training, say so plainly and stay with that |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here, and the 40% digital target in the strategy brief makes a probe likely. Answer slot: if you have worked with a digital team or on a self-service route for members, say what it was and which part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |

## Grounding brief

You gave me a summary of the July 2026 strategy brief, not its full text. Bring one fact and your own reason in an answer; do not recite the brief, because the recruiter sent it to you.

Facts:

| Fact | Source | Provenance |
|---|---|---|
| Ashgrove is member-owned, with about 900 staff | The JD | [grounded] |
| Move 40% of member service to digital channels by 2028 | The 2026 strategy brief, as you summarised it | [grounded] |
| Consolidate eight branches into five hubs over 2027 | The 2026 strategy brief, as you summarised it | [grounded] |
| Launch a small-business lending product in Q1 2027 | The 2026 strategy brief, as you summarised it | [grounded] |
| The main competitive pressure is app-only banks | The 2026 strategy brief, as you summarised it | [grounded] |

Readings for your rounds. These are the pack's derivations, not Ashgrove statements:

| Reading | Derived from | Provenance |
|---|---|---|
| More complaints may start in digital channels, which ties the JD's self-service duty to the 40% target | The 40% fact plus the JD's digital-teams line | [inferred] |
| Escalation paths and branch-level reporting may change during 2027, and the R3 panel's own branches sit inside that change | The eight-to-five fact | [inferred] |
| A new lending product in Q1 2027 may bring new complaint types into the process you would own | The Q1 2027 fact | [inferred] |
| App-only competitors set a speed-and-simplicity standard, which the Plain Words value echoes | The competitor fact plus the pasted values | [inferred] |

## Persona table

No interviewer names exist yet, so weights rest on the round type and the recruiter's own description of each round, not on anyone's public footprint.

| Round | Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|---|
| R1 | Conversational | Friendly walk through your journey, motivation, Ashgrove knowledge | Top. A recruiter screen's prior is Conversational plus a light Skeptic, and the risk is treating it as unscored | A rehearsed 90-second arc built on A1's quoted sentences; treat casual questions about JD topics as scored |
| R1 | Skeptic, light | Quiet knockout-style checks on the contact centre and presenting | Low. The prior says light, and you have stated both negatives, so a recruiter has an easy question to ask | Say each gap once, plainly, then the plan (B1, B2, B3) |
| R2 | Values/Behavioral | Scenario prompts about senior people, escalations and members | Top. The recruiter calls this round "mostly behavioural", which beats the hiring-manager prior of Case plus Skeptic | Quote-led stories where your sentences carry one; selection scaffolds with an honest branch where none does |
| R2 | Skeptic | Cross-examines the contact-centre and branch-scope gaps | High. A manager buys capability and derisks gaps, and F2 is a stated gap | Rehearse D1 to the third follow-up |
| R2 | Case/Strategist | Strategy-linked live problems | Mid. The hiring-manager prior is raised by the brief's hubs and digital target, lowered by "mostly behavioural" | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| R2 | Data-Driven Prober | Goes through the spreadsheet and the clock on resolution times | Low to mid. The JD names monthly reporting, and F3 and F4 are the rows it probes | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| R3 | Values/Behavioral | Stories scored against the four values by name | Top. The recruiter says the panel is the values round and scores against the four values | The cheat sheet below; one story per value, or an honest scaffold |
| R3 | Case/Strategist | The 20-minute complaint-escalation case | High. The recruiter names a 20-minute case, and the content is not known in advance | Practise the structure on H1 to H3; the real case will differ |
| R3 | Peer Evaluator | Seam-splitting between a branch manager and the role | Mid. This is derived from the JD: the role coaches branch supervisors and reports across branches, so branch managers are its counterparts | Reciprocity: what you would give the branches, not only what you need |
| R3 | Skeptic | The gaps again, in a panel's register | Low to mid. The gaps carry over from R2, and the panel is scoring values first | The same hold-then-concede as D1 |

Pressure is not weighted in any round: nothing in the recruiter's description signals a stress-interview style, so no bank is built for it.

## Question banks

### Round 1 — recruiter, 30 minutes

#### A. Conversational (suggested wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career so far, and why this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F6, F1 and F3, using only the beats those sentences state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log and the escalation-script training; the monthly complaints spreadsheet. Tell it in your own words in about 90 seconds, then give your reason for this role, which only you can supply. Say only reasons that are true for you | The opener of the loop, and the arc every later answer has to be consistent with. EXP because it tests whether the story stays inside what you did |
| A2 | "What do you know about Ashgrove, and what draws you to us?" | CO | [grounded] | Choose one or two facts from the grounding brief that you can speak to, such as member-owned, one value by name, or one item from the July 2026 brief. Say why it matters to you, only if it does. The recruiter sent you the brief, so reciting it adds nothing; one fact plus your reason is the answer | Motivation and homework in a recruiter's register. CO because it scores what you know of Ashgrove, not your history |
| A3 | "Tell me about handling formal complaints at your branch." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 and F5: you handled the branch's formal complaints log, and you trained new tellers on the escalation script. Those are the beats; tell them in your own words. Answer slot: the JD says regulated and end to end, so expect a probe on what the log worked to and on what happened after a complaint was logged. If the log was kept to a rule or deadline you worked with, or any later stage was yours, say which; if not, or you do not know the rule behind it, say so plainly and stay with the log and the training | F5 and F1 are where the JD presses hardest on your complaints work. EXP because it tests what was actually yours |
| A4 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats the quote states: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: the JD names volumes, resolution times and Excel, so expect a probe on what was in it and what it was built in. If it carried volumes or resolution times, say which and how each was counted; if it was in Excel, say so; if either is not true, say so plainly and stay with what you built | F3 and F4 are the rows this probes. EXP because it tests whether the claim survives a follow-up |
| A5 | "What are you actually playing with in digital self-service these days?" | JD | [grounded] | Answer slot: the JD names digital teams and self-service journeys, and the 40% digital target in the brief makes this likely. If you have worked with a digital team or on a self-service route for members, say what it was and which part was yours; if you have not, say so plainly and say what you would ask a digital team first | F9 has no evidence, so this is the likeliest unprepared question in the round. JD because it scores a stated responsibility, in a casual register |

#### B. Skeptic, light (suggested wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. How do you feel about that half of it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say the gap once, plainly: "I haven't worked in a contact centre." Then what your material carries, at its own scope: you handled the branch's formal complaints log and trained new tellers on the escalation script. Then a plan in the future tense, with steps you would actually take. Never describe contact-centre work as something you have done. This is D1 in a lighter register | F2 is a stated gap, and a recruiter can ask about it without any follow-up. JD because the contact centre is in the role's first line |
| B2 | "How comfortable are you presenting to senior leaders, and what is the most senior group you have presented to?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Say it plainly: "I've never presented to anyone above regional level." Answer slot: your material does not show what you presented at regional level or below. If you presented the spreadsheet or anything else to your regional manager or a regional group, say what and how it went, in your own words; if the spreadsheet was only sent and never presented, say so plainly. Then a plan, said as a plan: how you would prepare a first senior presentation | F7 is a stated gap and the JD says confident presenting to senior leaders. JD because it scores a stated requirement |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose the answer that is honestly yours. F2, F7 and F9 are the thin rows in your material, and F2 and F7 are your own stated limits: "I haven't worked in a contact centre" or "I've never presented to anyone above regional level". Then what you would do first, as a plan. Do not offer a weakness that is really a strength | The Skeptic's standard stem; the answer should be ready before it is asked. JD because it scores honest self-assessment against the listed duties |

### Round 2 — Head of Member Services, 45 minutes

#### C. Values/Behavioral (suggested wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you had to give someone senior to you a message they did not want to hear." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: none of your sentences names such a time, so pick one with a named stake, a moment you did not back down, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry only if it fits: "I built the monthly complaints spreadsheet our regional manager uses." Or say how you would handle it | A standard behavioural stem, and F7 makes upward messages the area your material covers least. VAL because it is scored as behaviour |
| C2 | "Tell me about a time you helped someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F8 at its own scope: "I trained new tellers on our escalation script." Answer slot: the JD asks about coaching on escalations, so expect a probe on a particular case. If you walked a particular person through an escalation, say what happened and what part was yours; if the training was the only form it took, say so plainly and stay with the training | F8 is adjacent evidence for a requirement aimed at supervisors. JD because it scores the coaching duty, in a behavioural delivery |
| C3 | "When did you put a member ahead of an internal measure?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time with a named member situation, an internal measure or process that pulled the other way, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the branch's formal complaints log, at its own scope, or how you would handle it | A standard behavioural stem that also lines up with Members First. VAL because it scores the published value |

#### D. Skeptic (suggested wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across branches and the contact centre, and you have not worked in a contact centre. How do you own a channel you haven't worked in?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Highest-ROI rehearsal in the pack. Level 1, the hold: say the gap once — "I haven't worked in a contact centre." — then stay with what you did, at its own scope: you handled the branch's formal complaints log and trained new tellers on the escalation script. Do not add to it. Level 2, expect "what would you not know on day one". Answer slot: if you have seen how a contact-centre complaint reaches a branch, say what you saw; if you have not, say so plainly and name what you would ask to be shown first. Level 3, expect "why should we believe you will close it". Give a plan in the future tense with steps you would really take; general options are listening to live contacts, reading that channel's complaints before changing anything, and asking the team where handoffs break. These are not Ashgrove facts. Concede the gap once and specifically, and never fold the branch record into a claim about the channel | F2 is your stated gap and F1 is the requirement it presses on. This manager would carry the cost of the gap, so the objection arrives here in its sharpest form. JD because it scores a stated requirement |
| D2 | "The role spans every branch. How would you find out how complaints are handled in branches you haven't worked in?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Anchor on what your material carries, the branch's formal complaints log, then give a plan in the future tense, choosing steps you would actually take: asking each branch how a complaint reaches its log, talking to supervisors before reading figures, comparing branches only after you understand each one. Do not claim to know other branches' practice | F1 is the row where "across branches" stretches your material. JD because it scores the end-to-end reach of the role |
| D3 | "You would be coaching branch supervisors, which is the level you are at now. What is different about coaching a peer from training new tellers?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what your quotes carry: the last three years as a branch supervisor, and training new tellers on the escalation script. Answer slot: if you have coached someone at your own level on an escalation, say who and what you did, in your own words; if you have not, say so plainly and stay with the tellers' training. Then say how you would approach it: ask the supervisor to walk you through what happened before offering anything | F8 is adjacent evidence, and this question presses on the exact difference. JD because it scores the coaching duty |

#### E. Case/Strategist (suggested wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Eight of our branches become five hubs over 2027, so complaints will arrive in new places. What would you want to know first, and what would you protect in the process?" | CASE | [inferred] | Think aloud in order. Clarify: how complaints reach the process today by branch and channel, and what the transition timetable is. Objective: no complaint lost or delayed in the move. Approach: map each branch's route into the log, then keep one named owner per complaint through the move. Metrics: the JD's own two measures, volumes and resolution times, by branch and by hub. Risk: handoff gaps while routes change. Challenge one premise respectfully, for instance whether branches are the only entry point | Derived from the brief's eight-to-five fact and the JD's reporting duty. CASE because it sets a live problem from the role and presupposes nothing about your past |
| E2 | "By 2028 we want 40% of member service to move to digital channels. How should that change how we handle complaints?" | CO | [inferred] | Clarify what the 40% counts, and whether complaints sit inside it. Then which complaint types suit self-service and which need a person, and how plain the wording must be: the Plain Words value says that if a member needs it explained twice, Ashgrove wrote it wrong. Measure the effect with the same volume and resolution-time reports. Make no claim to digital experience; F9 has none in your material | Derived from the brief's 40% fact, the JD's digital-teams line and the Plain Words value. CO because it scores whether you can think at Ashgrove's altitude |

#### F. Data-Driven Prober (suggested wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats the quote states: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect a probe on how each was counted. If it carried them, say how each was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours; if you do not know how a figure was counted, say so plainly. If it was not in Excel, say so plainly | F3 and F4 are the rows this probes, and the defend-the-number habits are the same ones. EXP because it tests attribution |
| F2 | "When we report resolution time, where does the clock start and stop?" | JD | [generic] | Say what you would confirm first: how Ashgrove defines it, and any rule it must follow. Then name how a different definition changes the number, and the assumption you would defend least: that every complaint has one clear start. Say plainly that you would confirm the definition here before reporting anything. Claim no past definition you did not state | The JD asks for monthly reporting on resolution times, and F3 gives no definition. JD because it scores a stated duty; the question is general and asserts nothing about you |

### Round 3 — panel of two branch managers, 60 minutes, includes a 20-minute case

#### G. Values/Behavioral (suggested wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Members First, Always: use your C3 story if it fits. Pick a time with a named member situation, a pull the other way, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the branch's formal complaints log, at its own scope, or how you would handle it | The first of the four published values. VAL because the panel scores against it by name |
| G2 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Plain Words: pick a time a member needed it explained again and what you changed. Answer slot: if you shaped or reworded any part of the escalation script or how you taught it, say what and why, in your own words; if the script was given and you taught it as written, say so plainly and use a member-facing instance you can recall, or say how you would approach it | Plain Words puts the failure on the writer, so expect a probe on your own words. The nearest sentence is F8's at its own scope. VAL because it scores the value |
| G3 | "Tell me about a time you thought of your branch as part of its town and not as a set of figures." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold for Neighbours, Not Numbers: pick a time what served your branch's members differed from what a figure said. Nothing in your material names such a time. If none comes to mind, say so plainly, then give the nearest thing your material carries, the last three years as a branch supervisor, or say how you would weigh a number against what a town needs. The brief's eight-to-five consolidation sits behind this value; treat it as Ashgrove's decision and ask how complaints from affected towns are heard, rather than offering a view on it | The panel's own branches sit inside the consolidation (grounding brief reading). VAL because it scores the third value |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 at its own scope: you handled the branch's formal complaints log. Answer slot: pick one complaint that stayed with you and say what the problem was, what you did and where it ended, in your own words; if the log was the part that was yours and no single case stands out, say so plainly and say how you would keep hold of one across a handoff | Own the Fix is the value that fits your log work most closely. VAL because the panel scores against the published wording |

#### H. Case/Strategist (suggested wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member has complained three times about the same fee dispute. The branch told them to call the contact centre, and the contact centre told them to go back to the branch. A branch manager escalates it to you. Where do you start?" | CASE | [generic] | The recruiter names a 20-minute case on a complaint escalation; the real one will differ, so rehearse the structure. Clarify: what the member is disputing, what has been promised, what rule or deadline applies, how the member is now. Objective: one named owner today and a fix, said in plain words. Approach: contact the member, resolve, record, then fix the loop. Metrics: resolution time and repeat contact. Risk: the handoff loop itself. Own the Fix says whoever finds the problem keeps hold of it, so the finder keeps it. Think aloud and challenge one premise | The recruiter's case, rehearsed. CASE because it is a live problem and presupposes nothing about your past |
| H2 | "A branch supervisor escalates a complaint to you, but how they handled it first made it worse. How do you coach them?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Fix the member's problem first. Then have the supervisor walk you through what happened before judging it, agree one change, and follow up. You can say you spent the last three years as a branch supervisor; claim nothing beyond that sentence about coaching peers | F8 in a live setting, in front of managers whose supervisors this is. CASE because it asks for a method |
| H3 | "A branch's complaint numbers jump in one month. Where do you look first?" | CASE | [generic] | Clarify first: how complaints are defined and logged, and whether logging changed, since a rise can mean better logging and not worse service. Then segment by branch, product, channel, complaint type and week. Separate a one-off from a trend, look at volumes beside resolution times, and decide what you would tell the supervisor. Weakest assumption to name: that the log is complete | The JD's two measures used as a diagnosis. CASE because it is a live problem and presupposes nothing about your past |

#### I. Peer Evaluator (suggested wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Our supervisors are busy and already have escalation rules. What would you need from branch managers like us, and what would we get from you?" | JD | [grounded] | Reciprocity, at the level of principles. What the branches would get is what the JD describes: coaching for supervisors on escalations and a monthly view of volumes and resolution times. What you would need: time with supervisors, access to branch logs, and honest feedback. Say nothing about how you did this before | The panel are branch managers and the JD's duties land on their branches (a reading from the JD). JD because it scores the coaching and reporting duties, in a peer's packaging |
| I2 | "When you and a branch manager disagree about how a complaint should be handled, what happens?" | JD | [generic] | Principles, not a claimed past: the member's problem is fixed first, who owns it today is settled, and the disagreement about process comes afterwards. Say you would raise it with the Head of Member Services only after raising it with the branch manager first. Show spine and tact together | The recruiter says the Head of Member Services would be your manager, which gives the escalation route. JD because it scores partnership with the branches |

#### J. Skeptic (suggested wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You have never presented above regional level, and this role reports monthly to senior leaders. What will be different the first time?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Say it plainly: "I've never presented to anyone above regional level." What your material carries is "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you have presented at regional level or below, say what and to whom, in your own words; if not, say so plainly. Then the plan: agree with the Head of Member Services what leaders need, lead with the headline, rehearse, and ask for feedback | F7 is a stated limit, and the panel will want to know the branches' view will be carried upward. JD because it scores a stated requirement |
| J2 | "A branch and the contact centre each think a complaint is the other's to own. You have not worked in the contact centre. How do you referee?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold the gap in one line: "I haven't worked in a contact centre." Then reason from the published value: Own the Fix says whoever finds the problem keeps hold of it until it is solved, so the finder keeps it, and you would ask the contact centre side what it sees before ruling. Concede that you would need to learn how that channel works, as a plan. Do not describe contact-centre work as done | D1's objection in the panel's packaging, tied to a published value. CASE because it is a live problem, and the premise is a stated limit |

## Values cheat sheet

A values-style round is established by the recruiter's own words: the panel "is also the values round — they score against the four values." Official names are as you pasted them from ashgrovecu.org/about/values on 11 November 2026.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's view of the counter | F1 offers only "I handled the branch's formal complaints log and trained new tellers on our escalation script." as the nearest sentence. Selection scaffold ending in its honest branch at C3 and G1 |
| Plain Words | If a member had to be told twice, the writer failed | F8: "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message. Use at its own scope; the answer slot at G2 says what you need to confirm |
| Neighbours, Not Numbers | A branch belongs to its town | F6: "6 years in retail banking, the last 3 as a branch supervisor." — your message. That sentence names the role, not a story; G3 is a selection scaffold ending in its honest branch |
| Own the Fix | Whoever finds a problem keeps it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message. Story-mapped at its own scope at G4 |

## Reverse questions

These are for your turn at the end of each round. No interviewer profile exists yet, so none is tied to anyone's career path.

| Round | Question | Why it lands |
|---|---|---|
| R1 | "Is there a regulator or complaints framework I should know by name before the panel?" | It shows you take the word regulated seriously, and it fills a fact your material does not carry |
| R1 | "Once the interviewers are confirmed, could you share their names and roles?" | It lets the later rounds be tuned to them |
| R1 | "Will I get any time with the contact-centre team as part of the process?" | It shows you are taking the channel gap seriously and not hiding it |
| R2 | "What would you want to see from the complaints process by the end of my first 90 days?" | It asks for a definition of success, which the manager will have |
| R2 | "How do complaints from branches and from the contact centre reach the same place today?" | It goes to the end-to-end line and to the gap you carry, as a learner |
| R2 | "What changes do you expect in the complaints process as eight branches become five hubs?" | It uses the brief's consolidation fact and asks for the manager's own view |
| R2 | "Where would you most want a new lead to push back on how things are done now?" | It invites candour and signals you will not simply adopt the existing way |
| R3 | "What would you most want from someone coaching your supervisors on escalations, and what would make you stop calling them?" | It is reciprocity: it asks what the branches need, not only what you need |
| R3 | "What kind of escalation from your branch do you most wish had gone better?" | It invites real cases, which feeds your next answer |
| R3 | "How do you picture the branch voice staying in the process once branches become hubs?" | It ties to Neighbours, Not Numbers and to the brief |
| R3 | "What should I know about your town and your members that a report would not show?" | It puts the value into a question and invites a story |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A3, B1, D1, D2, H1, J2 |
| Report monthly on complaint volumes and resolution times | A4, F1, F2, H3, J1 |
| Coach branch supervisors on escalations | C2, D3, H2, I1 |
| Work with digital teams on self-service journeys | A5, E2 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A3, F2 |
| Confident presenting to senior leaders | B2, C1, J1 |
| Comfortable with Excel reporting | A4, F1 |

## Prohibited claims

These are the claims this pack will not coach. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The limit is the pack's observation: the material says the branch's log, not the process end to end |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot. Source: "Never worked in a contact centre, and I've never presented to anyone above regional level." |
| Has presented to senior leaders | Negative you stated, F7 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |
| Handled regulated complaints | Inflated form of F5, the JD's word in place of yours | F5's quote at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The limit is the pack's observation: the material says formal, not regulated |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: the material says new tellers, not supervisors |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material does not show what the spreadsheet held |
| Built Excel reports | Inflated form of F4, tool named where your sentence says spreadsheet | F4's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material does not name the tool |

## Sources

Provided documents: the JD; the values text you pasted, copied 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the process; your summary of the 2026 strategy brief published in July 2026; your background in your message. No dossier was present.

No searches or fetches were sent. The URL you named is only where the pasted text came from, so it was not read.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove values` | skipped | The pasted values text fixes the four value names and wording used in the cheat sheet and G1 to G4 |
| 2. `Ashgrove interview process member services` | skipped | The recruiter's email fixes the three sessions, who runs each and the case, which set the persona weights |
| 3. `Ashgrove strategy` / recent news | skipped | Your summary of the July 2026 brief fixes the grounding facts; its full text was not in hand |
| 4. `{interviewer name} Ashgrove` | n/a | No interviewer names exist yet, so there was no query to form; the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewers' names once assigned → an interviewer read, persona weights adjusted to what they have published, and a reverse question tied to their own path
- Your CV → F1, F3 and F6 move beyond what your message alone carries
- An anonymised view of the monthly complaints spreadsheet's layout, with no member data → F3 and F4 can move from medium or low toward high, and F4's tool question is settled
- Your answers to the answer slots on F1, F3, F4, F5, F8 and F9 → each answer enters the snapshot in your own words and regenerates the rows and questions that draw on it
- Any presentation you have given at regional level or below → F7, B2 and J1
- The full text of the July 2026 strategy brief → the grounding rows become grounded in the brief itself, not in a summary
- The recruiter's one-line view on the R3 case topic and on which complaints framework applies → the H bank and F5 become more specific
- Hours you can give to prep before 20 November → a prioritised prep schedule
- Deeper research, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent organisation context for the CO and CASE banks
- An evidence file from an earlier review of your background (tuesday-dossier.md) → verified evidence and prohibited-claim constraints in place of the ones built here
