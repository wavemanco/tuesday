I'll read the reference files the skill requires before writing anything.
I've read the skill's reference files and am now running the first-tier research: the company's values, its interview process, recent strategy, and Tobias Wrenfield's public footprint.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-canned-a0ab063d/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it assuming Tobias runs the round Saltmarsh's interviewing page calls the Outage Hour. That round is a live-incident tabletop followed by a values conversation. The pack names C2, the season-pass and in-app-purchase question, as your highest-ROI prep.

The interviewer details come from a single search result on an odd domain, so check them before relying on them. The pack's Sources section covers this.

Say the word and I'll play the Skeptic on C2 and run the follow-ups live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager who runs your Outage Hour, and did your recruiter say anything about its format? The answer reweights the persona banks and could change the Case questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** a 60-minute interview on Friday 13 November 2026. Built on the assumption that Tobias is the hiring manager running the round Saltmarsh's interviewing page calls the Outage Hour (a live-incident tabletop, then a values conversation). That assumption is not confirmed. If it is wrong, the persona weights and the interviewer read are the sections that change.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every question carries both, so you can see at a glance what a question is for and how it will feel.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Whether your CV claims survive a follow-up, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you did your homework on the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the actual role |

- Answer guidance is scaffolding, not a script. Say it in your own words.
- An **answer slot** is an instruction addressed to your answer in the room. It is not a question for me, and nothing needs replying to. Take the branch that is true for you. The second branch of every slot is a legitimate answer.
- Anything quoted from you is quoted exactly. If a line of guidance says something about your past, it is one of your own sentences or an answer slot.

## Prep triage

You have two days (today is Wednesday 11 November). In this order:

| Order | Do this | Where |
|---|---|---|
| 1 | Say the answer to the season-pass and in-app-purchase question out loud, with all three follow-ups. This is the highest-ROI prep in the pack: it is the question most likely to be asked in some form, and it is aimed at a gap you stated yourself | C2, then C1 |
| 2 | Run the tabletop structure out loud twice, changing the failure each time. The tabletop is the documented half of the hour | A1, A2 |
| 3 | For each of the three published values, decide whether you have a story. Where you do not, prepare the honest branch | B1, B2, B3, B4 |
| 4 | Find out how the monthly retention numbers you presented were counted, so you can say it or say plainly that you do not know | D1 |
| 5 | Pick three reverse questions and rehearse the wording | R1, R3, R5 |

Everything else is insurance.

## Fit snapshot

Gate check: no requirement in the JD is a term the candidate meets or does not (authorization, licence, location, schedule, pay, travel, a credential). "3+ years" is experience, so it is graded like any other row. No `hard_gate` rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's line on live events across two titles makes a probe on both likely. If any of the drops had a start and an end as an event, say which and how you scheduled them; if none had that shape, or only the one title was yours, say so plainly and stay with the weekly calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [inferred] | discovery | The quote speaks to leading and the JD asks for coordinating, and your material is silent on coordination, so this is silence and not a gap you stated. Answer slot: if you coordinated any of design, art, engineering or community on a drop, say which and what you did, in your own words; if you did not, or someone else did, say so plainly and answer as an approach and not as a past |
| F3 | "own the post-event review" — JD | none given | none | [grounded] | discovery | Your material does not show a post-event review either way. Answer slot: the JD names the review as owned, so expect a probe on it. If you ran or contributed to any review after a content drop, say what it covered and what part was yours, in your own words; if there was no such review, or it was not yours, say so plainly and say what you would put in one first |
| F4 | "the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting is what the quote says, and the words stay at presenting: "I presented the monthly retention numbers to the studio head." Owning the KPIs is wider than the quote. Answer slot: if you also chose which numbers went into the monthly set or how they were defined, say so; if someone else did, or the set was fixed, say so plainly and stay with presenting them |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the words, but a CV line with nothing inspected behind it, so expect a probe on it. Lead with the checklist in the quote's own terms: you wrote it, and your QA team still uses it. A named document beats an adjective. Running each release against it is wider than the quote, and the pack does not coach it |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | The years are in your quote, and the title is associate producer. Your material does not say whether the studio's games ran as live-service. Answer slot: the JD asks for live-service, so expect a probe on what live meant at your studio. If the main title ran as a live service, say what made it live, in your own words; if it did not, say so plainly and stay with the weekly calendar you ran |
| F7 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap in the words. Lead with the quote's own terms: weekly, content drops, your main title, two years. Expect a probe because nothing inspected sits behind the line |
| F8 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in the words, but presenting is what the quote says, and how the numbers were built is what a probe tests (D1). Lead with: you presented the monthly retention numbers to the studio head |
| F9 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Your material offers one written artifact in the quote's terms: you wrote the release checklist, and your QA team still uses it. Say that and let the interviewer draw the inference. Do not call it clear communication on your own behalf |
| F10 | "to a season-pass model with one shared events calendar from February 2027" — Saltmarsh news post on Project Larkspur (search result; company context, not a JD line) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller. The pack's own observation: your material says in-app purchases and says nothing about season passes specifically |

## Reading the interviewer

Public professional footprint only. Nothing else was searched.

| # | What is public, or what follows | Implication for you | Provenance |
|---|---|---|---|
| I1 | Tobias Wrenfield is Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio (one search result, page not fetched) | The release-checklist and QA ground is close to his own history, so expect those answers to be listened to closely (A2, B3, D3) | [grounded] |
| I2 | He gave a GDC 2026 talk titled "Patch Notes Are a Promise", arguing that a live team is judged by how often its patch notes describe what actually shipped (same single result) | Precision about what shipped is a theme of his, so claims at their true scope are what a careful listener rewards | [grounded] |
| I3 | Saltmarsh's own value "Ship the Patch Not the Promise" (we announce what is built, not what is hoped) sits beside I2's theme | The two published statements share a theme, which is why the pack keeps every answer at the scope of your own sentences. This is a reading of two public statements, not something about him personally | [inferred] |
| I4 | Mirror opportunity: his public path (I1) meets F5's quote "Wrote the release checklist our QA team still uses." | Bring the checklist into A2, B3 and D3 in the quote's own words and let him draw the connection. Do not claim a shared background beyond it | [inferred] |
| I5 | If you have watched or read the talk before Friday, a question about it is a strong reverse question (R2). If you have not, do not cite it | A cited talk you have not seen fails on the first follow-up | [generic] |

## Persona table

Weighting passes, shown so you can recalibrate if you know something I do not:

| Pass | Input | Effect | Provenance |
|---|---|---|---|
| 1 | Relationship prior: hiring manager (assumed) | Case/Strategist and Skeptic dominate | [generic] |
| 2 | Saltmarsh's interviewing page: "a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." | The loop is established as one session. Case/Strategist goes first and Values/Behavioral is guaranteed. No graded-deliverable section is needed | [grounded] |
| 3 | Interviewer signals I1 to I3 | Prober moves up a little, because the interviewer's public theme is what shipped against what was claimed. No personality inference is made | [inferred] |

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event, plus planning questions | High. Pass 2 documents the tabletop as half of the hour | Clarify, then objective, then who you pull in, then what players are told, then metrics and risks. Think aloud. Challenge one premise respectfully | A (5) |
| Values/Behavioral | The second half of the hour, mapped to three published values | High. Pass 2 documents the values conversation, so the three values are asked somewhere in it | Map a story to each value where one of your sentences carries one. Where none does, take the honest branch | B (4) |
| Skeptic | Your two stated limits and the scope jump to two titles and four disciplines | Medium to high. Pass 1 makes it a hiring-manager staple, and F2, F3 and F10 are where the material is thin | Rehearse C2 until it is boring. Bridges come from your own sentences only | C (3) |
| Data-Driven Prober | Retention numbers, the calendar, the checklist | Medium. F4 and F8 rest on one line each, and pass 3 raises it a little | Know how the numbers were counted, or say plainly that you do not | D (3) |
| Pressure | Time-boxed answers inside the tabletop, and "why you" in sixty seconds | Low to medium. The tabletop format invites interruption but the sources document no stress style | Pause, restate, hold through two follow-ups, concede specifically | E (2) |
| Conversational | The opener and the "what are you playing" question | Low. Likely at the start, still scored | A 90-second arc built from your own quotes | F (2) |
| Peer Evaluator | Not included | The loop source names one interviewer, the hiring manager | None | none |

## Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a weekend event. Players are reporting they cannot claim rewards, support tickets are climbing, and engineering says the fix needs about three hours. Walk me through your first thirty minutes." | CASE | [inferred] | Structure it aloud. Clarify first: what is broken, who it touches, since when, whether it can be switched off or rolled back. Objective: protect players before keeping the calendar, which is the company's own phrasing in Players Before Plans. Then who you pull in from design, art, engineering and community, and what you ask each. Then what players are told, when, and only what is known, since Ship the Patch Not the Promise sets the standard of announcing what is built and not what is hoped. Last, what you record for the post-event review. Challenge one premise respectfully, such as the three-hour estimate. The question needs no claim about your past, so the guidance makes none | The tabletop is documented, but its scenario is not, so this one is derived from the documented format and the real one will differ. CASE because it scores structure under a live problem. F2 and F3 are the requirements it presses on |
| A2 | "The next drop is scheduled for Thursday, QA has not signed off, and engineering says it is probably fine. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure: what sign-off means and what is still open, what is at risk for players if it ships and if it slips, the options (ship, ship a reduced version, hold), who decides, and what players are told. You may refer to the checklist in the quote's own words: you wrote it and your QA team still uses it. Answer slot: the JD asks you to manage the checklist with QA, so expect a probe on a case like this. If the checklist had a step for a missing sign-off, say what it was and how it worked; if it did not, or this never came up, or the decision was not yours, say so plainly and answer as a decision | F5 is the strongest row and it sits on the interviewer's own ground (I1, I4). CASE because it asks for a decision and not a record |
| A3 | "From February 2027 Tidepool Tactics and Lantern Row share one events calendar. How would you plan the first quarter of it?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: what the shared calendar is for, how much the two player groups overlap, which teams are shared. Then constraints (shared engineering, QA and community capacity), collisions between events, cadence, and what you would measure. For your own side the quote carries one thing, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD asks for two titles and for coordinating four disciplines, so expect a probe on whether anything you scheduled competed with other work for the same people. If it did, say what happened and what part was yours; if it did not, or you were not the one to resolve it, say so plainly and answer as an approach | The Larkspur post is the current-strategy hook, and the JD's per-title wording differs from it, so R3 asks how the role sits and does not correct anyone. F1 is the row it draws on. CASE with CO content |
| A4 | "Day-7 retention for players who joined during last weekend's event is down 20 percent on the previous event. What do you look at first?" | CASE | [generic] | Clarify before diagnosing: how the cohort and the comparison are defined, whether anything else changed (version, acquisition, tracking), and whether the data can be trusted. Segment: new against returning, platform, source. Then hypotheses (the event design, a bug, the reward economy, something concurrent), what you would check first for each, what you would report and to whom, and what goes into the post-event review. Think aloud and say which assumption you would test first. The question needs no claim about your past, so the guidance makes none | F3 and F8 are the requirements it tests, as a live problem. CASE because it asks for a diagnosis structure, with the data-handling a prober would also score |
| A5 | "Design wants an event bigger than the calendar can hold, engineering says no, and community says players expect it. You are the producer. What happens?" | CASE | [generic] | Structure: what each side's real constraint is, the smallest version that keeps the part players care about, the criteria for escalating and to whom, and how the decision is told to each team and to players. Where you land matters less than showing how you would decide. Answer as an approach. The question needs no claim about your past, so the guidance makes none | F2 is the requirement. CASE because it is a live conflict between teams the JD names, which asks for approach and not for authority |

### B. Values/Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the plan and the players pulled in different directions. What did you do?" (Players Before Plans) | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The quote carries a calendar, not a conflict, so this is a selection scaffold. Pick a time something on the weekly calendar was changed because of what players were experiencing. It needs a named thing that changed, who decided, and what players saw. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the weekly calendar you ran, or how you would handle it | The value is published on Saltmarsh's values page. F7 is the nearest evidence and it does not show a conflict, so the question is a scaffold and not a story map. VAL because it scores one named value |
| B2 | "Tell me about a time you had to decide what to say publicly about something that was not finished." (Ship the Patch Not the Promise) | VAL | [grounded] | Selection scaffold: choose a time you chose your words about unfinished work. It needs the thing that was unfinished, what you chose to say or hold back, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Keep every claim at its true scope, which I2 and I3 suggest is the standard this interviewer listens for | The value is published. The pack has no quoted sentence that carries this story, so it does not map one. VAL because it scores one named value |
| B3 | "Tell me about a time you left a process or a document better than you found it." (Leave the Build Greener) | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F5: the checklist you wrote, and that your QA team still uses it, which are the beats the quote states. Tell them in your own words. Answer slot: the value says every release leaves the checklist better, so expect a probe on whether yours changed after you wrote it. If it did, say what changed and what prompted it; if it did not, or the changes were not yours, say so plainly and stay with the checklist you wrote | F5 is the one row that carries a story for this value, and it sits on the interviewer's own ground (I4). VAL because the value names the checklist directly |
| B4 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | The quote carries presenting to a senior person each month, and says nothing about the numbers being unwelcome. Tell the beats it states: monthly, retention numbers, the studio head. Answer slot: if any month's numbers were unwelcome, say what the number was, how you presented it, and what happened; if none was, say so plainly and stay with how you presented them each month | F4 is the only row that puts you in front of someone senior. VAL because it scores candor, which sits beside Ship the Patch Not the Promise |

### C. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years." | Pick the one that bears hardest on this role and say it plainly in your own words. One honest candidate is your stated limit on in-app purchases. Then give the ramp, said as a plan and never as a past: what you would learn first, who you would learn it from, and what you would hold off judging. Then what you already have, at its own scope: the weekly calendar you ran | The persona stem for the Skeptic, and the JD is the raising source. F6, F3 and F10 are the rows with the least behind them. JD because it scores whether you can do the listed job, gaps included |
| C2 | "Tidepool Tactics and Lantern Row are moving to a season pass from February, and you have not worked on a game with in-app purchases. How do you plan a calendar around a monetization model you have not run?" | CO | [grounded] "never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years.", "Wrote the release checklist our QA team still uses." | **The highest-ROI rehearsal in this pack**, and the hold is only what your quotes carry. Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you bring, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then the ramp, as a plan: what you would learn first about how the season pass shapes the calendar and who you would learn it from. Follow-up 1, "so what do you actually bring?": return to the calendar and the checklist, in the quotes' words, and add nothing. Follow-up 2, "what would you get wrong first?": name in your own words the call you would be least sure of before you had seen how purchases move the calendar; if none comes to mind, say so plainly. Follow-up 3, "why take the risk over someone who has?": concede the limit exactly, that you have not worked on a game with in-app purchases, and hold on what the quotes carry. Never fold on the calendar, and never describe monetization work you did not do | Inferred, not dossier-derived: the combination of a publicly announced season-pass move and a limit you stated yourself makes this the objection most likely to arrive in some form. CO because it needs the Larkspur facts, delivered as a Skeptic question. F10 is the row |
| C3 | "Your background says you have not led a team, and this role coordinates design, art, engineering and community on each update. What is the hardest part of that for you?" | JD | [grounded] "Never led a team" | Plain acknowledgment first, in your words: "I haven't led a team." Answer slot: the JD asks for coordinating four disciplines. If you coordinated any of them on a drop, say which and what you did; if you did not, or someone else did, say so plainly and answer as an approach. Then name the hardest part honestly and say how you would handle it | F2 is the row, and the stated negative is the quote. JD because the requirement is the JD's own list of four disciplines |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented each month were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The quote says you presented them, and the answer is built in your own words on four slots: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you presented numbers that someone else produced, say so plainly and say what you understood about how they were counted. If you do not know how a figure was counted, say so plainly. Name the weakest assumption before the interviewer does | F4 and F8 rest on one line each, and the JD makes retention a requirement. EXP because it tests whether the claim survives scrutiny and what was actually yours |
| D2 | "How did you tell whether a weekly drop worked?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: the JD makes you own the KPIs a post-event review reports, so expect this. If you tracked any measure per drop, say what it was and who set it; if none was tracked per drop, or it was set by someone else, say so plainly and say what you would track first | F3 and F4 are the rows. JD because it scores the review-and-KPI requirement |
| D3 | "You say your QA team still uses the checklist you wrote. What is your evidence that it works?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Stay with what the quote carries: you wrote it, and your QA team still uses it. Answer slot: if there is any record of what the checklist caught or changed, say what it was; if there is none, say so plainly and say what you would look at to find out | F5 is a CV line with nothing inspected behind it, and the interviewer's own path makes it a likely probe (I1). EXP because it tests the claim, not the job |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over a candidate who has already run live events on two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years.", "Wrote the release checklist our QA team still uses.", "Presented the monthly retention numbers to the studio head.", "Never led a team", "never worked on a game with in-app purchases" | Hold, then concede. Hold with three of your own sentences at their scope: you ran the weekly content-drop calendar for your main title for two years, you wrote the checklist your QA team still uses, and you presented the monthly retention numbers to the studio head. Concede the two limits you stated, plainly and specifically. On two titles, stay with the main-title calendar as the quote words it. Through two follow-ups return to the quotes and never add to them. Pause and restate the question before answering | The persona stem for Pressure. F1, F5 and F8 are the holds, and F2 and F10 are the concessions. JD because it scores the fit to the listed job |
| E2 | "You have ninety seconds. Players are angry on the forum and engineering has not confirmed a cause. What do you post?" | CASE | [generic] | Structure it: what is known, what is not known, what players should do now, when the next update will come, and who owns it. Promise no fix time that you cannot back, since Ship the Patch Not the Promise sets the standard. If you are interrupted, restate the question and finish the structure. The question needs no claim about your past, so the guidance makes none | F9 is the requirement, since the post is the written communication, and the Pressure delivery tests it under a clock. CASE because it is a live problem with a time-box |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you get from puzzle games to wanting live ops here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio.", "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc with three beats. One: four years as an associate producer at a puzzle-game studio. Two: for the last two years you ran the weekly content-drop calendar for your main title. Three: why this role, in your own words. If one of Saltmarsh's three published values is part of the reason, say which and why; if none is, say what is | F6 and F7 carry the first two beats, and the third is yours. EXP because it tests the CV story, with the Conversational register that makes it feel unscored |
| F2 | "What are you playing at the moment, ours or anyone's, and what do you notice about how its live events run?" | CO | [grounded] | If you have played Tidepool Tactics or Lantern Row, say what you noticed about their events. If you have not, say so plainly and pick a live-service game you do play, and describe how its event calendar looks. Do not say you play something you do not | The JD names the live-events calendar, and the question is the persona's casual probe on it. The two titles are named on Saltmarsh's Project Larkspur post. CO because it tests whether you can look at a calendar closely |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, D2, E1, F2 |
| "coordinate design, art, engineering and community teams on each update" | A1, A5, C3 |
| "own the post-event review and the KPIs it reports" | A4, B4, D1, D2 |
| "manage the release checklist with QA" | A2, B3, D3 |
| "3+ years producing live-service games or apps" | C1, E1, F1 |
| "experience running a content calendar" | A3, B1, D2, F1 |
| "comfortable with player-retention metrics" | A4, B4, D1 |
| "clear written communication" | A1, B2, E2 |

## Values cheat sheet

A values-style round is detected: Saltmarsh's interviewing page describes a values conversation as the second half of the hour. The three values are quoted by name from the company's published page.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players disagree, the players win | F7: "I ran the weekly content-drop calendar for our main title for the last two years." That sentence carries a calendar and not a conflict, so B1 is a selection scaffold that ends in its honest branch |
| Ship the Patch Not the Promise | Say what is built, not what is hoped | F4: "Presented the monthly retention numbers to the studio head." It carries presenting and not a hard message, so B4 is a slot and B2 is a selection scaffold that ends in its honest branch |
| Leave the Build Greener | Each release should leave the codebase and the checklist better than it found them | F5: "Wrote the release checklist our QA team still uses." B3 maps it, with a slot for whether the checklist changed afterwards |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You moved from QA lead into running live ops. What did the QA years change about how you run an event, that you would want a new producer to pick up early?" | Tied to his own path, and it asks him for the lesson and not for a status. It turns a probe into a peer conversation | [grounded] |
| R2 | "Your GDC talk argues that patch notes are a promise. How does your team check that the notes matched what shipped?" Ask only if you have watched or read it | It shows you took his public thinking seriously, and it invites him to talk about what he cares about. If you have not seen it, drop it | [grounded] |
| R3 | "With Project Larkspur moving the titles to one shared calendar and one live-ops group, how does this role sit in it: on a title, or on the shared calendar?" | It shows you read the news, and it clears up how the role relates to the JD's "two of our mobile titles" without correcting anyone | [grounded] |
| R4 | "What would a first quarter that went well look like for this producer?" | The question every hiring manager can answer, and it tells you what you would be measured on | [generic] |
| R5 | "How are post-event reviews done today, and who reads them?" | It presses on F3, the row with the least behind it, and tells you what you would inherit | [generic] |
| R6 | "What would you expect someone new to season-pass monetization to need to learn in the first month?" | It turns C2 into a plan the interviewer can add to, and it shows you are already thinking about the ramp | [grounded] |

## Prohibited claims

What this pack will not coach, and why. There is no dossier, so the list is built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F2 | Your words: "Never led a team". The plain acknowledgment is "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or on monetization | Negative you stated, F10 | Your words: "never worked on a game with in-app purchases". The plain acknowledgment is "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for one main title |
| Owned the post-event review and the KPIs | Inflated form of F3 and F4 | F4's quote at its own scope: you presented the monthly retention numbers. The material says presented, and it does not say owned or defined |
| Managed each release with QA | Inflated form of F5 | F5's quote at its own scope: you wrote the checklist and your QA team still uses it. The material says wrote and still uses, and it does not say managed each release |

Coordinating design, art, engineering and community (F2), the post-event review (F3) and live-service (F6) are silences and not claims, so they are answer slots in the banks and are not listed here.

## Sources

**Provided:** the JD text and your background note, both pasted into the conversation. No dossier was present.

**Searches sent (4):**
- `Saltmarsh Games values` → https://saltmarshgames.com/values
- `Saltmarsh Games interview process live operations producer` → https://saltmarshgames.com/careers/interviewing
- `Saltmarsh Games strategy news mobile` → https://saltmarshgames.com/news/project-larkspur
- `Tobias Wrenfield Saltmarsh Games` → https://talks.gdconf.example/2026/patch-notes-are-a-promise

**Fetches sent (2):** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both returned.

**Notes on the sources:** the Larkspur post (September 2026) and the interviewer's talk were read from search results only, and neither page was fetched. The talk result is a single source on a domain ending in `.example`, so I could not confirm it is the conference's own page. Treat I1 and I2 as leads to check before you rely on them in the room.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, B1 to B4, and the value names used in A1, A2 and E2 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | The loop (a recruiter call, then one 60-minute interview with the hiring manager, a tabletop and a values conversation, no take-home), the persona weights, banks A and B, and the dropped graded-deliverable section |
| 3. `Saltmarsh Games strategy news mobile` | yes | A3, C2, F2 and R3, R6; one search, result only, page not fetched |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, R1 and R2; one result |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is the hiring manager running your round → the persona weights and the interviewer read stop resting on an assumption
- The recruiter's guidance on the Outage Hour (what kind of incident, whether any material comes in advance, how the hour splits) → the Case bank moves from a derived scenario shape to the documented one; usually one email to the recruiter
- Your answers to the answer slots in A2, A3, B1 to B4, C3, D1 to D3 → F1, F2, F3, F4 and F6 are regenerated from your own words, and the thin rows firm up
- A copy of the release checklist or a sample monthly retention report → F5 and F8 move from `medium` to `high`, since a release checklist document and a retention report are what this field treats as inspectable proof
- A full CV → the fit snapshot has more of your sentences to draw on, and more questions move from selection scaffolds to story maps
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Project Larkspur, more on the interviewer's talk, and reported loop experiences for this role family
- A tuesday-dossier.md from an earlier evidence pass → the highest-ROI objection would come from recorded evidence and not from inference, and each weak area would carry a strategy constraint
